var __wxAppData=__wxAppData||{};var __wxAppCode__=__wxAppCode__||{};var global=global||{};var __WXML_GLOBAL__=__WXML_GLOBAL__||{entrys:{},defines:{},modules:{},ops:[],wxs_nf_init:undefined,total_ops:0};var Component=Component||function(){};var definePlugin=definePlugin||function(){};var requirePlugin=requirePlugin||function(){};var Behavior=Behavior||function(){};var __vd_version_info__=__vd_version_info__||{};var __GWX_GLOBAL__=__GWX_GLOBAL__||{};if(this&&this.__g===undefined)Object.defineProperty(this,"__g",{configurable:false,enumerable:false,writable:false,value:function(){function D(e,t){if(typeof t!="undefined")e.children.push(t)}function S(e){if(typeof e!="undefined")return{tag:"virtual",wxKey:e,children:[]};return{tag:"virtual",children:[]}}function v(e){$gwxc++;if($gwxc>=16e3){throw"Dom limit exceeded, please check if there's any mistake you've made."}return{tag:"wx-"+e,attr:{},children:[],n:[],raw:{},generics:{}}}function e(e,t){t&&e.properities.push(t)}function t(e,t,r){return typeof e[r]!="undefined"?e[r]:t[r]}function u(e){console.warn("WXMLRT_"+g+":"+e)}function r(e,t){u(t+":-1:-1:-1: Template `"+e+"` is being called recursively, will be stop.")}var s=console.warn;var n=console.log;function o(){function e(){}e.prototype={hn:function(e,t){if(typeof e=="object"){var r=0;var n=false,o=false;for(var a in e){n=n|a==="__value__";o=o|a==="__wxspec__";r++;if(r>2)break}return r==2&&n&&o&&(t||e.__wxspec__!=="m"||this.hn(e.__value__)==="h")?"h":"n"}return"n"},nh:function(e,t){return{__value__:e,__wxspec__:t?t:true}},rv:function(e){return this.hn(e,true)==="n"?e:this.rv(e.__value__)},hm:function(e){if(typeof e=="object"){var t=0;var r=false,n=false;for(var o in e){r=r|o==="__value__";n=n|o==="__wxspec__";t++;if(t>2)break}return t==2&&r&&n&&(e.__wxspec__==="m"||this.hm(e.__value__))}return false}};return new e}var A=o();function T(e){var t=e.split("\n "+" "+" "+" ");for(var r=0;r<t.length;++r){if(0==r)continue;if(")"===t[r][t[r].length-1])t[r]=t[r].replace(/\s\(.*\)$/,"");else t[r]="at anonymous function"}return t.join("\n "+" "+" "+" ")}function a(M){function m(e,t,r,n,o){var a=false;var i=e[0][1];var p,u,l,f,v,c;switch(i){case"?:":p=x(e[1],t,r,n,o,a);l=M&&A.hn(p)==="h";f=A.rv(p)?x(e[2],t,r,n,o,a):x(e[3],t,r,n,o,a);f=l&&A.hn(f)==="n"?A.nh(f,"c"):f;return f;break;case"&&":p=x(e[1],t,r,n,o,a);l=M&&A.hn(p)==="h";f=A.rv(p)?x(e[2],t,r,n,o,a):A.rv(p);f=l&&A.hn(f)==="n"?A.nh(f,"c"):f;return f;break;case"||":p=x(e[1],t,r,n,o,a);l=M&&A.hn(p)==="h";f=A.rv(p)?A.rv(p):x(e[2],t,r,n,o,a);f=l&&A.hn(f)==="n"?A.nh(f,"c"):f;return f;break;case"+":case"*":case"/":case"%":case"|":case"^":case"&":case"===":case"==":case"!=":case"!==":case">=":case"<=":case">":case"<":case"<<":case">>":p=x(e[1],t,r,n,o,a);u=x(e[2],t,r,n,o,a);l=M&&(A.hn(p)==="h"||A.hn(u)==="h");switch(i){case"+":f=A.rv(p)+A.rv(u);break;case"*":f=A.rv(p)*A.rv(u);break;case"/":f=A.rv(p)/A.rv(u);break;case"%":f=A.rv(p)%A.rv(u);break;case"|":f=A.rv(p)|A.rv(u);break;case"^":f=A.rv(p)^A.rv(u);break;case"&":f=A.rv(p)&A.rv(u);break;case"===":f=A.rv(p)===A.rv(u);break;case"==":f=A.rv(p)==A.rv(u);break;case"!=":f=A.rv(p)!=A.rv(u);break;case"!==":f=A.rv(p)!==A.rv(u);break;case">=":f=A.rv(p)>=A.rv(u);break;case"<=":f=A.rv(p)<=A.rv(u);break;case">":f=A.rv(p)>A.rv(u);break;case"<":f=A.rv(p)<A.rv(u);break;case"<<":f=A.rv(p)<<A.rv(u);break;case">>":f=A.rv(p)>>A.rv(u);break;default:break}return l?A.nh(f,"c"):f;break;case"-":p=e.length===3?x(e[1],t,r,n,o,a):0;u=e.length===3?x(e[2],t,r,n,o,a):x(e[1],t,r,n,o,a);l=M&&(A.hn(p)==="h"||A.hn(u)==="h");f=l?A.rv(p)-A.rv(u):p-u;return l?A.nh(f,"c"):f;break;case"!":p=x(e[1],t,r,n,o,a);l=M&&A.hn(p)=="h";f=!A.rv(p);return l?A.nh(f,"c"):f;case"~":p=x(e[1],t,r,n,o,a);l=M&&A.hn(p)=="h";f=~A.rv(p);return l?A.nh(f,"c"):f;default:s("unrecognized op"+i)}}function x(e,t,r,n,o,a){var i=e[0];var p=false;if(typeof a!=="undefined")o.ap=a;if(typeof i==="object"){var u=i[0];var l,f,v,c,s,y,b,d,h,_,g;switch(u){case 2:return m(e,t,r,n,o);break;case 4:return x(e[1],t,r,n,o,p);break;case 5:switch(e.length){case 2:l=x(e[1],t,r,n,o,p);return M?[l]:[A.rv(l)];return[l];break;case 1:return[];break;default:l=x(e[1],t,r,n,o,p);v=x(e[2],t,r,n,o,p);l.push(M?v:A.rv(v));return l;break}break;case 6:l=x(e[1],t,r,n,o);var w=o.ap;h=A.hn(l)==="h";f=h?A.rv(l):l;o.is_affected|=h;if(M){if(f===null||typeof f==="undefined"){return h?A.nh(undefined,"e"):undefined}v=x(e[2],t,r,n,o,p);_=A.hn(v)==="h";c=_?A.rv(v):v;o.ap=w;o.is_affected|=_;if(c===null||typeof c==="undefined"||c==="__proto__"||c==="prototype"||c==="caller"){return h||_?A.nh(undefined,"e"):undefined}y=f[c];if(typeof y==="function"&&!w)y=undefined;g=A.hn(y)==="h";o.is_affected|=g;return h||_?g?y:A.nh(y,"e"):y}else{if(f===null||typeof f==="undefined"){return undefined}v=x(e[2],t,r,n,o,p);_=A.hn(v)==="h";c=_?A.rv(v):v;o.ap=w;o.is_affected|=_;if(c===null||typeof c==="undefined"||c==="__proto__"||c==="prototype"||c==="caller"){return undefined}y=f[c];if(typeof y==="function"&&!w)y=undefined;g=A.hn(y)==="h";o.is_affected|=g;return g?A.rv(y):y}case 7:switch(e[1][0]){case 11:o.is_affected|=A.hn(n)==="h";return n;case 3:b=A.rv(r);d=A.rv(t);v=e[1][1];if(n&&n.f&&n.f.hasOwnProperty(v)){l=n.f;o.ap=true}else{l=b&&b.hasOwnProperty(v)?r:d&&d.hasOwnProperty(v)?t:undefined}if(M){if(l){h=A.hn(l)==="h";f=h?A.rv(l):l;y=f[v];g=A.hn(y)==="h";o.is_affected|=h||g;y=h&&!g?A.nh(y,"e"):y;return y}}else{if(l){h=A.hn(l)==="h";f=h?A.rv(l):l;y=f[v];g=A.hn(y)==="h";o.is_affected|=h||g;return A.rv(y)}}return undefined}break;case 8:l={};l[e[1]]=x(e[2],t,r,n,o,p);return l;break;case 9:l=x(e[1],t,r,n,o,p);v=x(e[2],t,r,n,o,p);function O(e,t,r){var n,o;h=A.hn(e)==="h";_=A.hn(t)==="h";f=A.rv(e);c=A.rv(t);for(var a in c){if(r||!f.hasOwnProperty(a)){f[a]=M?_?A.nh(c[a],"e"):c[a]:A.rv(c[a])}}return e}var s=l;var j=true;if(typeof e[1][0]==="object"&&e[1][0][0]===10){l=v;v=s;j=false}if(typeof e[1][0]==="object"&&e[1][0][0]===10){var P={};return O(O(P,l,j),v,j)}else return O(l,v,j);break;case 10:l=x(e[1],t,r,n,o,p);l=M?l:A.rv(l);return l;break;case 12:var P;l=x(e[1],t,r,n,o);if(!o.ap){return M&&A.hn(l)==="h"?A.nh(P,"f"):P}var w=o.ap;v=x(e[2],t,r,n,o,p);o.ap=w;h=A.hn(l)==="h";_=N(v);f=A.rv(l);c=A.rv(v);snap_bb=K(c,"nv_");try{P=typeof f==="function"?K(f.apply(null,snap_bb)):undefined}catch(t){t.message=t.message.replace(/nv_/g,"");t.stack=t.stack.substring(0,t.stack.indexOf("\n",t.stack.lastIndexOf("at nv_")));t.stack=t.stack.replace(/\snv_/g," ");t.stack=T(t.stack);if(n.debugInfo){t.stack+="\n "+" "+" "+" at "+n.debugInfo[0]+":"+n.debugInfo[1]+":"+n.debugInfo[2];console.error(t)}P=undefined}return M&&(_||h)?A.nh(P,"f"):P}}else{if(i===3||i===1)return e[1];else if(i===11){var l="";for(var D=1;D<e.length;D++){var S=A.rv(x(e[D],t,r,n,o,p));l+=typeof S==="undefined"?"":S}return l}}}function e(e,t,r,n,o,a){if(e[0]=="11182016"){n.debugInfo=e[2];return x(e[1],t,r,n,o,a)}else{n.debugInfo=null;return x(e,t,r,n,o,a)}}return e}var f=a(true);var c=a(false);function i(e,t,r,n,o,a,i,p){{var u={is_affected:false};var l=f(t,r,n,o,u);if(JSON.stringify(l)!=JSON.stringify(a)||u.is_affected!=p){console.warn("A. "+e+" get result "+JSON.stringify(l)+", "+u.is_affected+", but "+JSON.stringify(a)+", "+p+" is expected")}}{var u={is_affected:false};var l=c(t,r,n,o,u);if(JSON.stringify(l)!=JSON.stringify(i)||u.is_affected!=p){console.warn("B. "+e+" get result "+JSON.stringify(l)+", "+u.is_affected+", but "+JSON.stringify(i)+", "+p+" is expected")}}}function y(e,t,r,n,o,a,i,p,u){var l=A.hn(e)==="n";var f=A.rv(n);var v=f.hasOwnProperty(i);var c=f.hasOwnProperty(p);var s=f[i];var y=f[p];var b=Object.prototype.toString.call(A.rv(e));var d=b[8];if(d==="N"&&b[10]==="l")d="X";var h;if(l){if(d==="A"){var _;for(var g=0;g<e.length;g++){f[i]=e[g];f[p]=l?g:A.nh(g,"h");_=A.rv(e[g]);var w=u&&_?u==="*this"?_:A.rv(_[u]):undefined;h=S(w);D(a,h);t(r,f,h,o)}}else if(d==="O"){var g=0;var _;for(var O in e){f[i]=e[O];f[p]=l?O:A.nh(O,"h");_=A.rv(e[O]);var w=u&&_?u==="*this"?_:A.rv(_[u]):undefined;h=S(w);D(a,h);t(r,f,h,o);g++}}else if(d==="S"){for(var g=0;g<e.length;g++){f[i]=e[g];f[p]=l?g:A.nh(g,"h");h=S(e[g]+g);D(a,h);t(r,f,h,o)}}else if(d==="N"){for(var g=0;g<e;g++){f[i]=g;f[p]=l?g:A.nh(g,"h");h=S(g);D(a,h);t(r,f,h,o)}}else{}}else{var j=A.rv(e);var _,P;if(d==="A"){for(var g=0;g<j.length;g++){P=j[g];P=A.hn(P)==="n"?A.nh(P,"h"):P;_=A.rv(P);f[i]=P;f[p]=l?g:A.nh(g,"h");var w=u&&_?u==="*this"?_:A.rv(_[u]):undefined;h=S(w);D(a,h);t(r,f,h,o)}}else if(d==="O"){var g=0;for(var O in j){P=j[O];P=A.hn(P)==="n"?A.nh(P,"h"):P;_=A.rv(P);f[i]=P;f[p]=l?O:A.nh(O,"h");var w=u&&_?u==="*this"?_:A.rv(_[u]):undefined;h=S(w);D(a,h);t(r,f,h,o);g++}}else if(d==="S"){for(var g=0;g<j.length;g++){P=A.nh(j[g],"h");f[i]=P;f[p]=l?g:A.nh(g,"h");h=S(e[g]+g);D(a,h);t(r,f,h,o)}}else if(d==="N"){for(var g=0;g<j;g++){P=A.nh(g,"h");f[i]=P;f[p]=l?g:A.nh(g,"h");h=S(g);D(a,h);t(r,f,h,o)}}else{}}if(v){f[i]=s}else{delete f[i]}if(c){f[p]=y}else{delete f[p]}}function N(e){if(A.hn(e)=="h")return true;if(typeof e!=="object")return false;for(var t in e){if(e.hasOwnProperty(t)){if(N(e[t]))return true}}return false}function b(e,t,r,n,o){var a=false;var i=K(n,"",2);if(o.ap&&i&&i.constructor===Function){t="$wxs:"+t;e.attr["$gdc"]=K}if(o.is_affected||N(n)){e.n.push(t);e.raw[t]=n}e.attr[t]=i}function d(e,t,r,n,o,a){a.opindex=r;var i={},p;var u=c(z[r],n,o,a,i);b(e,t,r,u,i)}function h(e,t,r,n,o,a,i){i.opindex=n;var p={},u;var l=c(e[n],o,a,i,p);b(t,r,n,l,p)}function p(e,t,r,n){n.opindex=e;var o={};var a=c(z[e],t,r,n,o);return a&&a.constructor===Function?undefined:a}function l(e,t,r,n,o){o.opindex=t;var a={};var i=c(e[t],r,n,o,a);return i&&i.constructor===Function?undefined:i}function _(e,t,r,n,o){var o=o||{};n.opindex=e;return f(z[e],t,r,n,o)}function w(e,t,r,n,o,a){var a=a||{};o.opindex=t;return f(e[t],r,n,o,a)}function O(e,t,r,n,o,a,i,p,u){var l={};var f=_(e,r,n,o);y(f,t,r,n,o,a,i,p,u)}function j(e,t,r,n,o,a,i,p,u,l){var f={};var v=w(e,t,n,o,a);y(v,r,n,o,a,i,p,u,l)}function P(e,t,r,n,o,a){var i=v(e);var p=0;for(var u=0;u<t.length;u+=2){if(p+t[u+1]<0){i.attr[t[u]]=true}else{d(i,t[u],p+t[u+1],n,o,a);if(p===0)p=t[u+1]}}for(var u=0;u<r.length;u+=2){if(p+r[u+1]<0){i.generics[r[u]]=""}else{var l=c(z[p+r[u+1]],n,o,a);if(l!="")l="wx-"+l;i.generics[r[u]]=l;if(p===0)p=r[u+1]}}return i}function M(e,t,r,n,o,a,i){var p=v(t);var u=0;for(var l=0;l<r.length;l+=2){if(u+r[l+1]<0){p.attr[r[l]]=true}else{h(e,p,r[l],u+r[l+1],o,a,i);if(u===0)u=r[l+1]}}for(var l=0;l<n.length;l+=2){if(u+n[l+1]<0){p.generics[n[l]]=""}else{var f=c(e[u+n[l+1]],o,a,i);if(f!="")f="wx-"+f;p.generics[n[l]]=f;if(u===0)u=n[l+1]}}return p}var m=function(){if(typeof __WXML_GLOBAL__==="undefined"||undefined===__WXML_GLOBAL__.wxs_nf_init){x();C();k();U();I();L();E();R();F()}if(typeof __WXML_GLOBAL__!=="undefined")__WXML_GLOBAL__.wxs_nf_init=true};var x=function(){Object.defineProperty(Object.prototype,"nv_constructor",{writable:true,value:"Object"});Object.defineProperty(Object.prototype,"nv_toString",{writable:true,value:function(){return"[object Object]"}})};var C=function(){Object.defineProperty(Function.prototype,"nv_constructor",{writable:true,value:"Function"});Object.defineProperty(Function.prototype,"nv_length",{get:function(){return this.length},set:function(){}});Object.defineProperty(Function.prototype,"nv_toString",{writable:true,value:function(){return"[function Function]"}})};var k=function(){Object.defineProperty(Array.prototype,"nv_toString",{writable:true,value:function(){return this.nv_join()}});Object.defineProperty(Array.prototype,"nv_join",{writable:true,value:function(e){e=undefined==e?",":e;var t="";for(var r=0;r<this.length;++r){if(0!=r)t+=e;if(null==this[r]||undefined==this[r])t+="";else if(typeof this[r]=="function")t+=this[r].nv_toString();else if(typeof this[r]=="object"&&this[r].nv_constructor==="Array")t+=this[r].nv_join();else t+=this[r].toString()}return t}});Object.defineProperty(Array.prototype,"nv_constructor",{writable:true,value:"Array"});Object.defineProperty(Array.prototype,"nv_concat",{writable:true,value:Array.prototype.concat});Object.defineProperty(Array.prototype,"nv_pop",{writable:true,value:Array.prototype.pop});Object.defineProperty(Array.prototype,"nv_push",{writable:true,value:Array.prototype.push});Object.defineProperty(Array.prototype,"nv_reverse",{writable:true,value:Array.prototype.reverse});Object.defineProperty(Array.prototype,"nv_shift",{writable:true,value:Array.prototype.shift});Object.defineProperty(Array.prototype,"nv_slice",{writable:true,value:Array.prototype.slice});Object.defineProperty(Array.prototype,"nv_sort",{writable:true,value:Array.prototype.sort});Object.defineProperty(Array.prototype,"nv_splice",{writable:true,value:Array.prototype.splice});Object.defineProperty(Array.prototype,"nv_unshift",{writable:true,value:Array.prototype.unshift});Object.defineProperty(Array.prototype,"nv_indexOf",{writable:true,value:Array.prototype.indexOf});Object.defineProperty(Array.prototype,"nv_lastIndexOf",{writable:true,value:Array.prototype.lastIndexOf});Object.defineProperty(Array.prototype,"nv_every",{writable:true,value:Array.prototype.every});Object.defineProperty(Array.prototype,"nv_some",{writable:true,value:Array.prototype.some});Object.defineProperty(Array.prototype,"nv_forEach",{writable:true,value:Array.prototype.forEach});Object.defineProperty(Array.prototype,"nv_map",{writable:true,value:Array.prototype.map});Object.defineProperty(Array.prototype,"nv_filter",{writable:true,value:Array.prototype.filter});Object.defineProperty(Array.prototype,"nv_reduce",{writable:true,value:Array.prototype.reduce});Object.defineProperty(Array.prototype,"nv_reduceRight",{writable:true,value:Array.prototype.reduceRight});Object.defineProperty(Array.prototype,"nv_length",{get:function(){return this.length},set:function(e){this.length=e}})};var U=function(){Object.defineProperty(String.prototype,"nv_constructor",{writable:true,value:"String"});Object.defineProperty(String.prototype,"nv_toString",{writable:true,value:String.prototype.toString});Object.defineProperty(String.prototype,"nv_valueOf",{writable:true,value:String.prototype.valueOf});Object.defineProperty(String.prototype,"nv_charAt",{writable:true,value:String.prototype.charAt});Object.defineProperty(String.prototype,"nv_charCodeAt",{writable:true,value:String.prototype.charCodeAt});Object.defineProperty(String.prototype,"nv_concat",{writable:true,value:String.prototype.concat});Object.defineProperty(String.prototype,"nv_indexOf",{writable:true,value:String.prototype.indexOf});Object.defineProperty(String.prototype,"nv_lastIndexOf",{writable:true,value:String.prototype.lastIndexOf});Object.defineProperty(String.prototype,"nv_localeCompare",{writable:true,value:String.prototype.localeCompare});Object.defineProperty(String.prototype,"nv_match",{writable:true,value:String.prototype.match});Object.defineProperty(String.prototype,"nv_replace",{writable:true,value:String.prototype.replace});Object.defineProperty(String.prototype,"nv_search",{writable:true,value:String.prototype.search});Object.defineProperty(String.prototype,"nv_slice",{writable:true,value:String.prototype.slice});Object.defineProperty(String.prototype,"nv_split",{writable:true,value:String.prototype.split});Object.defineProperty(String.prototype,"nv_substring",{writable:true,value:String.prototype.substring});Object.defineProperty(String.prototype,"nv_toLowerCase",{writable:true,value:String.prototype.toLowerCase});Object.defineProperty(String.prototype,"nv_toLocaleLowerCase",{writable:true,value:String.prototype.toLocaleLowerCase});Object.defineProperty(String.prototype,"nv_toUpperCase",{writable:true,value:String.prototype.toUpperCase});Object.defineProperty(String.prototype,"nv_toLocaleUpperCase",{writable:true,value:String.prototype.toLocaleUpperCase});Object.defineProperty(String.prototype,"nv_trim",{writable:true,value:String.prototype.trim});Object.defineProperty(String.prototype,"nv_length",{get:function(){return this.length},set:function(e){this.length=e}})};var I=function(){Object.defineProperty(Boolean.prototype,"nv_constructor",{writable:true,value:"Boolean"});Object.defineProperty(Boolean.prototype,"nv_toString",{writable:true,value:Boolean.prototype.toString});Object.defineProperty(Boolean.prototype,"nv_valueOf",{writable:true,value:Boolean.prototype.valueOf})};var L=function(){Object.defineProperty(Number,"nv_MAX_VALUE",{writable:false,value:Number.MAX_VALUE});Object.defineProperty(Number,"nv_MIN_VALUE",{writable:false,value:Number.MIN_VALUE});Object.defineProperty(Number,"nv_NEGATIVE_INFINITY",{writable:false,value:Number.NEGATIVE_INFINITY});Object.defineProperty(Number,"nv_POSITIVE_INFINITY",{writable:false,value:Number.POSITIVE_INFINITY});Object.defineProperty(Number.prototype,"nv_constructor",{writable:true,value:"Number"});Object.defineProperty(Number.prototype,"nv_toString",{writable:true,value:Number.prototype.toString});Object.defineProperty(Number.prototype,"nv_toLocaleString",{writable:true,value:Number.prototype.toLocaleString});Object.defineProperty(Number.prototype,"nv_valueOf",{writable:true,value:Number.prototype.valueOf});Object.defineProperty(Number.prototype,"nv_toFixed",{writable:true,value:Number.prototype.toFixed});Object.defineProperty(Number.prototype,"nv_toExponential",{writable:true,value:Number.prototype.toExponential});Object.defineProperty(Number.prototype,"nv_toPrecision",{writable:true,value:Number.prototype.toPrecision})};var E=function(){Object.defineProperty(Math,"nv_E",{writable:false,value:Math.E});Object.defineProperty(Math,"nv_LN10",{writable:false,value:Math.LN10});Object.defineProperty(Math,"nv_LN2",{writable:false,value:Math.LN2});Object.defineProperty(Math,"nv_LOG2E",{writable:false,value:Math.LOG2E});Object.defineProperty(Math,"nv_LOG10E",{writable:false,value:Math.LOG10E});Object.defineProperty(Math,"nv_PI",{writable:false,value:Math.PI});Object.defineProperty(Math,"nv_SQRT1_2",{writable:false,value:Math.SQRT1_2});Object.defineProperty(Math,"nv_SQRT2",{writable:false,value:Math.SQRT2});Object.defineProperty(Math,"nv_abs",{writable:false,value:Math.abs});Object.defineProperty(Math,"nv_acos",{writable:false,value:Math.acos});Object.defineProperty(Math,"nv_asin",{writable:false,value:Math.asin});Object.defineProperty(Math,"nv_atan",{writable:false,value:Math.atan});Object.defineProperty(Math,"nv_atan2",{writable:false,value:Math.atan2});Object.defineProperty(Math,"nv_ceil",{writable:false,value:Math.ceil});Object.defineProperty(Math,"nv_cos",{writable:false,value:Math.cos});Object.defineProperty(Math,"nv_exp",{writable:false,value:Math.exp});Object.defineProperty(Math,"nv_floor",{writable:false,value:Math.floor});Object.defineProperty(Math,"nv_log",{writable:false,value:Math.log});Object.defineProperty(Math,"nv_max",{writable:false,value:Math.max});Object.defineProperty(Math,"nv_min",{writable:false,value:Math.min});Object.defineProperty(Math,"nv_pow",{writable:false,value:Math.pow});Object.defineProperty(Math,"nv_random",{writable:false,value:Math.random});Object.defineProperty(Math,"nv_round",{writable:false,value:Math.round});Object.defineProperty(Math,"nv_sin",{writable:false,value:Math.sin});Object.defineProperty(Math,"nv_sqrt",{writable:false,value:Math.sqrt});Object.defineProperty(Math,"nv_tan",{writable:false,value:Math.tan})};var R=function(){Object.defineProperty(Date.prototype,"nv_constructor",{writable:true,value:"Date"});Object.defineProperty(Date,"nv_parse",{writable:true,value:Date.parse});Object.defineProperty(Date,"nv_UTC",{writable:true,value:Date.UTC});Object.defineProperty(Date,"nv_now",{writable:true,value:Date.now});Object.defineProperty(Date.prototype,"nv_toString",{writable:true,value:Date.prototype.toString});Object.defineProperty(Date.prototype,"nv_toDateString",{writable:true,value:Date.prototype.toDateString});Object.defineProperty(Date.prototype,"nv_toTimeString",{writable:true,value:Date.prototype.toTimeString});Object.defineProperty(Date.prototype,"nv_toLocaleString",{writable:true,value:Date.prototype.toLocaleString});Object.defineProperty(Date.prototype,"nv_toLocaleDateString",{writable:true,value:Date.prototype.toLocaleDateString});Object.defineProperty(Date.prototype,"nv_toLocaleTimeString",{writable:true,value:Date.prototype.toLocaleTimeString});Object.defineProperty(Date.prototype,"nv_valueOf",{writable:true,value:Date.prototype.valueOf});Object.defineProperty(Date.prototype,"nv_getTime",{writable:true,value:Date.prototype.getTime});Object.defineProperty(Date.prototype,"nv_getFullYear",{writable:true,value:Date.prototype.getFullYear});Object.defineProperty(Date.prototype,"nv_getUTCFullYear",{writable:true,value:Date.prototype.getUTCFullYear});Object.defineProperty(Date.prototype,"nv_getMonth",{writable:true,value:Date.prototype.getMonth});Object.defineProperty(Date.prototype,"nv_getUTCMonth",{writable:true,value:Date.prototype.getUTCMonth});Object.defineProperty(Date.prototype,"nv_getDate",{writable:true,value:Date.prototype.getDate});Object.defineProperty(Date.prototype,"nv_getUTCDate",{writable:true,value:Date.prototype.getUTCDate});Object.defineProperty(Date.prototype,"nv_getDay",{writable:true,value:Date.prototype.getDay});Object.defineProperty(Date.prototype,"nv_getUTCDay",{writable:true,value:Date.prototype.getUTCDay});Object.defineProperty(Date.prototype,"nv_getHours",{writable:true,value:Date.prototype.getHours});Object.defineProperty(Date.prototype,"nv_getUTCHours",{writable:true,value:Date.prototype.getUTCHours});Object.defineProperty(Date.prototype,"nv_getMinutes",{writable:true,value:Date.prototype.getMinutes});Object.defineProperty(Date.prototype,"nv_getUTCMinutes",{writable:true,value:Date.prototype.getUTCMinutes});Object.defineProperty(Date.prototype,"nv_getSeconds",{writable:true,value:Date.prototype.getSeconds});Object.defineProperty(Date.prototype,"nv_getUTCSeconds",{writable:true,value:Date.prototype.getUTCSeconds});Object.defineProperty(Date.prototype,"nv_getMilliseconds",{writable:true,value:Date.prototype.getMilliseconds});Object.defineProperty(Date.prototype,"nv_getUTCMilliseconds",{writable:true,value:Date.prototype.getUTCMilliseconds});Object.defineProperty(Date.prototype,"nv_getTimezoneOffset",{writable:true,value:Date.prototype.getTimezoneOffset});Object.defineProperty(Date.prototype,"nv_setTime",{writable:true,value:Date.prototype.setTime});Object.defineProperty(Date.prototype,"nv_setMilliseconds",{writable:true,value:Date.prototype.setMilliseconds});Object.defineProperty(Date.prototype,"nv_setUTCMilliseconds",{writable:true,value:Date.prototype.setUTCMilliseconds});Object.defineProperty(Date.prototype,"nv_setSeconds",{writable:true,value:Date.prototype.setSeconds});Object.defineProperty(Date.prototype,"nv_setUTCSeconds",{writable:true,value:Date.prototype.setUTCSeconds});Object.defineProperty(Date.prototype,"nv_setMinutes",{writable:true,value:Date.prototype.setMinutes});Object.defineProperty(Date.prototype,"nv_setUTCMinutes",{writable:true,value:Date.prototype.setUTCMinutes});Object.defineProperty(Date.prototype,"nv_setHours",{writable:true,value:Date.prototype.setHours});Object.defineProperty(Date.prototype,"nv_setUTCHours",{writable:true,value:Date.prototype.setUTCHours});Object.defineProperty(Date.prototype,"nv_setDate",{writable:true,value:Date.prototype.setDate});Object.defineProperty(Date.prototype,"nv_setUTCDate",{writable:true,value:Date.prototype.setUTCDate});Object.defineProperty(Date.prototype,"nv_setMonth",{writable:true,value:Date.prototype.setMonth});Object.defineProperty(Date.prototype,"nv_setUTCMonth",{writable:true,value:Date.prototype.setUTCMonth});Object.defineProperty(Date.prototype,"nv_setFullYear",{writable:true,value:Date.prototype.setFullYear});Object.defineProperty(Date.prototype,"nv_setUTCFullYear",{writable:true,value:Date.prototype.setUTCFullYear});Object.defineProperty(Date.prototype,"nv_toUTCString",{writable:true,value:Date.prototype.toUTCString});Object.defineProperty(Date.prototype,"nv_toISOString",{writable:true,value:Date.prototype.toISOString});Object.defineProperty(Date.prototype,"nv_toJSON",{writable:true,value:Date.prototype.toJSON})};var F=function(){Object.defineProperty(RegExp.prototype,"nv_constructor",{writable:true,value:"RegExp"});Object.defineProperty(RegExp.prototype,"nv_exec",{writable:true,value:RegExp.prototype.exec});Object.defineProperty(RegExp.prototype,"nv_test",{writable:true,value:RegExp.prototype.test});Object.defineProperty(RegExp.prototype,"nv_toString",{writable:true,value:RegExp.prototype.toString});Object.defineProperty(RegExp.prototype,"nv_source",{get:function(){return this.source},set:function(){}});Object.defineProperty(RegExp.prototype,"nv_global",{get:function(){return this.global},set:function(){}});Object.defineProperty(RegExp.prototype,"nv_ignoreCase",{get:function(){return this.ignoreCase},set:function(){}});Object.defineProperty(RegExp.prototype,"nv_multiline",{get:function(){return this.multiline},set:function(){}});Object.defineProperty(RegExp.prototype,"nv_lastIndex",{get:function(){return this.lastIndex},set:function(e){this.lastIndex=e}})};m();var J=function(){var e=Array.prototype.slice.call(arguments);e.unshift(Date);return new(Function.prototype.bind.apply(Date,e))};var B=function(){var e=Array.prototype.slice.call(arguments);e.unshift(RegExp);return new(Function.prototype.bind.apply(RegExp,e))};var Y={};Y.nv_log=function(){var e="WXSRT:";for(var t=0;t<arguments.length;++t)e+=arguments[t]+" ";console.log(e)};var G=parseInt,X=parseFloat,H=isNaN,V=isFinite,$=decodeURI,W=decodeURIComponent,Q=encodeURI,q=encodeURIComponent;function K(e,t,r){e=A.rv(e);if(e===null||e===undefined)return e;if(typeof e==="string"||typeof e==="boolean"||typeof e==="number")return e;if(e.constructor===Object){var n={};for(var o in e)if(Object.prototype.hasOwnProperty.call(e,o))if(undefined===t)n[o.substring(3)]=K(e[o],t,r);else n[t+o]=K(e[o],t,r);return n}if(e.constructor===Array){var n=[];for(var a=0;a<e.length;a++)n.push(K(e[a],t,r));return n}if(e.constructor===Date){var n=new Date;n.setTime(e.getTime());return n}if(e.constructor===RegExp){var i="";if(e.global)i+="g";if(e.ignoreCase)i+="i";if(e.multiline)i+="m";return new RegExp(e.source,i)}if(r&&typeof e==="function"){if(r==1)return K(e(),undefined,2);if(r==2)return e}return null}var Z={};Z.nv_stringify=function(e){JSON.stringify(e);return JSON.stringify(K(e))};Z.nv_parse=function(e){if(e===undefined)return undefined;var t=JSON.parse(e);return K(t,"nv_")};function ee(e,t,r,n){e.extraAttr={t_action:t,t_rawid:r};if(typeof n!="undefined")e.extraAttr.t_cid=n}function te(){if(typeof __globalThis.__webview_engine_version__=="undefined")return 0;return __globalThis.__webview_engine_version__}function re(e,t,r,n,o,a){var i=ne(t,r,n);if(i)e.push(i);else{e.push("");u(n+":import:"+o+":"+a+": Path `"+t+"` not found from `"+n+"`.")}}function ne(e,t,r){if(e[0]!="/"){var n=r.split("/");n.pop();var o=e.split("/");for(var a=0;a<o.length;a++){if(o[a]=="..")n.pop();else if(!o[a]||o[a]==".")continue;else n.push(o[a])}e=n.join("/")}if(r[0]=="."&&e[0]=="/")e="."+e;if(t[e])return e;if(t[e+".wxml"])return e+".wxml"}function oe(e,t,r,n){if(!t)return;if(n[e][t])return n[e][t];for(var o=r[e].i.length-1;o>=0;o--){if(r[e].i[o]&&n[r[e].i[o]][t])return n[r[e].i[o]][t]}for(var o=r[e].ti.length-1;o>=0;o--){var a=ne(r[e].ti[o],r,e);if(a&&n[a][t])return n[a][t]}var i=ae(r,e);for(var o=0;o<i.length;o++){if(i[o]&&n[i[o]][t])return n[i[o]][t]}for(var p=r[e].j.length-1;p>=0;p--)if(r[e].j[p]){for(var a=r[r[e].j[p]].ti.length-1;a>=0;a--){var u=ne(r[r[e].j[p]].ti[a],r,e);if(u&&n[u][t]){return n[u][t]}}}}function ae(e,t){if(!t)return[];if($gaic[t]){return $gaic[t]}var r=[],n=[],o=0,a=0,i={},p={};n.push(t);p[t]=true;a++;while(o<a){var u=n[o++];for(var l=0;l<e[u].ic.length;l++){var f=e[u].ic[l];var v=ne(f,e,u);if(v&&!p[v]){p[v]=true;n.push(v);a++}}for(var l=0;u!=t&&l<e[u].ti.length;l++){var c=e[u].ti[l];var s=ne(c,e,u);if(s&&!i[s]){i[s]=true;r.push(s)}}}$gaic[t]=r;return r}var ie={};function pe(e,t,r,n,o,a,i){var p=ne(e,t,r);t[r].j.push(p);if(p){if(ie[p]){u("-1:include:-1:-1: `"+e+"` is being included in a loop, will be stop.");return}ie[p]=true;try{t[p].f(n,o,a,i)}catch(n){}ie[p]=false}else{u(r+":include:-1:-1: Included path `"+e+"` not found from `"+r+"`.")}}function ue(e,t,r,n){u(t+":template:"+r+":"+n+": Template `"+e+"` not found.")}function le(e){var t=false;delete e.properities;delete e.n;if(e.children){do{t=false;var r=[];for(var n=0;n<e.children.length;n++){var o=e.children[n];if(o.tag=="virtual"){t=true;for(var a=0;o.children&&a<o.children.length;a++){r.push(o.children[a])}}else{r.push(o)}}e.children=r}while(t);for(var n=0;n<e.children.length;n++){le(e.children[n])}}return e}function fe(e){if(e.tag=="wx-wx-scope"){e.tag="virtual";e.wxCkey="11";e["wxScopeData"]=e.attr["wx:scope-data"];delete e.n;delete e.raw;delete e.generics;delete e.attr}for(var t=0;e.children&&t<e.children.length;t++){fe(e.children[t])}return e}return{a:D,b:S,c:v,d:e,e:t,f:u,g:r,h:s,i:n,j:o,k:A,l:T,m:a,n:f,o:c,p:i,q:y,r:N,s:b,t:d,u:h,v:p,w:l,x:_,y:w,z:O,A:j,B:P,C:M,D:J,E:B,F:Y,G:G,H:X,I:H,J:V,K:$,L:W,M:Q,N:q,O:K,P:Z,Q:ee,R:te,S:re,T:ne,U:oe,V:ae,W:ie,X:pe,Y:ue,Z:le,aa:fe}}()});Object.freeze(__g);g="";	__wxAppCode__['pages/amend/amend.json'] = {"usingComponents":{}};
		__wxAppCode__['pages/area-rank/area-rank.json'] = {"usingComponents":{}};
		__wxAppCode__['pages/exam-result/exam-result.json'] = {"usingComponents":{}};
		__wxAppCode__['pages/exam/exam.json'] = {"usingComponents":{}};
		__wxAppCode__['pages/index/index.json'] = {"usingComponents":{}};
		__wxAppCode__['pages/loading/loading.json'] = {"usingComponents":{}};
		__wxAppCode__['pages/login-default/login-default.json'] = {"usingComponents":{}};
		__wxAppCode__['pages/login/login.json'] = {"usingComponents":{}};
		__wxAppCode__['pages/logs/logs.json'] = {"navigationBarTitleText":"查看启动日志","usingComponents":{}};
		__wxAppCode__['pages/notice/notice.json'] = {"usingComponents":{}};
		__wxAppCode__['pages/ranking/ranking.json'] = {"usingComponents":{}};
		__wxAppCode__['pages/record/record.json'] = {"usingComponents":{}};
		__wxAppCode__['pages/review/review.json'] = {"usingComponents":{}};
		__wxAppCode__['pages/rule/rule.json'] = {"usingComponents":{}};
		__wxAppCode__['pages/tellogin/tellogin.json'] = {"usingComponents":{}};
		__wxAppCode__['pages/test-paper/test-paper.json'] = {"usingComponents":{}};
		__wxAppCode__['pages/usermsg/usermsg.json'] = {"usingComponents":{}};
		__wxAppCode__['pages/vote/details/details.json'] = {"usingComponents":{"txv-video":"plugin://wxa75efa648b60994b/video"},"navigationBarTitleText":"通用投票系统"};
		__wxAppCode__['pages/vote/home/home.json'] = {"usingComponents":{"txv-video":"plugin://wxa75efa648b60994b/video"},"navigationStyle":"custom","navigationBarTitleText":"通用投票系统"};
		__wxAppCode__['pages/vote/rank/rank.json'] = {"usingComponents":{},"navigationStyle":"custom","navigationBarTitleText":"通用投票系统"};
	;var __WXML_DEP__=__WXML_DEP__||{};var __wxAppData=__wxAppData||{};var __wxRoute=__wxRoute||"";var __wxRouteBegin=__wxRouteBegin||"";var __wxAppCode__=__wxAppCode__||{};var global=global||{};var __WXML_GLOBAL__=__WXML_GLOBAL__||{entrys:{},defines:{},modules:{},ops:[],wxs_nf_init:undefined,total_ops:0};var __wxAppCurrentFile__=__wxAppCurrentFile__||"";var Component=Component||function(){};var definePlugin=definePlugin||function(){};var requirePlugin=requirePlugin||function(){};var Behavior=Behavior||function(){};var __vd_version_info__=__vd_version_info__||{};var __GWX_GLOBAL__=__GWX_GLOBAL__||{};
	definePlugin("plugin://wxa75efa648b60994b", function(define, require, module, exports, global, wx, App, Page, Component, Behavior, getApp, getCurrentPages) {			/*v0.6vv_20180522_fbi*/global.__wcc_version__='v0.6vv_20180522_fbi';global.__wcc_version_info__={"customComponents":true,"fixZeroRpx":true,"propValueDeepCopy":false};
var $gwxc
var $gaic={}
$gwx_wxa75efa648b60994b=function(path,global){
if(typeof global === 'undefined') global={};
if(typeof __WXML_GLOBAL__ === 'undefined') __WXML_GLOBAL__={};
function _(a,b){if(typeof(b)!='undefined')a.children.push(b);}
function _v(k){if(typeof(k)!='undefined')return {tag:'virtual','wxKey':k,children:[]};return {tag:'virtual',children:[]};}
function _n(tag){$gwxc++;if($gwxc>=16000){throw 'Dom limit exceeded, please check if there\'s any mistake you\'ve made.'};return {tag:'wx-'+tag,attr:{},children:[],n:[],raw:{},generics:{}}}
function _p(a,b){b&&a.properities.push(b);}
function _s(scope,env,key){return typeof(scope[key])!='undefined'?scope[key]:env[key]}
function _wp(m){console.warn("WXMLRT_$gwx_wxa75efa648b60994b:"+m)}
function _wl(tname,prefix){_wp(prefix+':-1:-1:-1: Template `' + tname + '` is being called recursively, will be stop.')}
$gwn=console.warn;
$gwl=console.log;
function $gwh()
{
function x()
{
}
x.prototype = 
{
hn: function( obj, all )
{
if( typeof(obj) == 'object' )
{
var cnt=0;
var any1=false,any2=false;
for(var x in obj)
{
any1=any1|x==='__value__';
any2=any2|x==='__wxspec__';
cnt++;
if(cnt>2)break;
}
return cnt == 2 && any1 && any2 && ( all || obj.__wxspec__ !== 'm' || this.hn(obj.__value__) === 'h' ) ? "h" : "n";
}
return "n";
},
nh: function( obj, special )
{
return { __value__: obj, __wxspec__: special ? special : true }
},
rv: function( obj )
{
return this.hn(obj,true)==='n'?obj:this.rv(obj.__value__);
},
hm: function( obj )
{
if( typeof(obj) == 'object' )
{
var cnt=0;
var any1=false,any2=false;
for(var x in obj)
{
any1=any1|x==='__value__';
any2=any2|x==='__wxspec__';
cnt++;
if(cnt>2)break;
}
return cnt == 2 && any1 && any2 && (obj.__wxspec__ === 'm' || this.hm(obj.__value__) );
}
return false;
}
}
return new x;
}
wh=$gwh();
function $gstack(s){
var tmp=s.split('\n '+' '+' '+' ');
for(var i=0;i<tmp.length;++i){
if(0==i) continue;
if(")"===tmp[i][tmp[i].length-1])
tmp[i]=tmp[i].replace(/\s\(.*\)$/,"");
else
tmp[i]="at anonymous function";
}
return tmp.join('\n '+' '+' '+' ');
}
function $gwrt( should_pass_type_info )
{
function ArithmeticEv( ops, e, s, g, o )
{
var _f = false;
var rop = ops[0][1];
var _a,_b,_c,_d, _aa, _bb;
switch( rop )
{
case '?:':
_a = rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && ( wh.hn(_a) === 'h' );
_d = wh.rv( _a ) ? rev( ops[2], e, s, g, o, _f ) : rev( ops[3], e, s, g, o, _f );
_d = _c && wh.hn( _d ) === 'n' ? wh.nh( _d, 'c' ) : _d;
return _d;
break;
case '&&':
_a = rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && ( wh.hn(_a) === 'h' );
_d = wh.rv( _a ) ? rev( ops[2], e, s, g, o, _f ) : wh.rv( _a );
_d = _c && wh.hn( _d ) === 'n' ? wh.nh( _d, 'c' ) : _d;
return _d;
break;
case '||':
_a = rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && ( wh.hn(_a) === 'h' );
_d = wh.rv( _a ) ? wh.rv(_a) : rev( ops[2], e, s, g, o, _f );
_d = _c && wh.hn( _d ) === 'n' ? wh.nh( _d, 'c' ) : _d;
return _d;
break;
case '+':
case '*':
case '/':
case '%':
case '|':
case '^':
case '&':
case '===':
case '==':
case '!=':
case '!==':
case '>=':
case '<=':
case '>':
case '<':
case '<<':
case '>>':
_a = rev( ops[1], e, s, g, o, _f );
_b = rev( ops[2], e, s, g, o, _f );
_c = should_pass_type_info && (wh.hn( _a ) === 'h' || wh.hn( _b ) === 'h');
switch( rop )
{
case '+':
_d = wh.rv( _a ) + wh.rv( _b );
break;
case '*':
_d = wh.rv( _a ) * wh.rv( _b );
break;
case '/':
_d = wh.rv( _a ) / wh.rv( _b );
break;
case '%':
_d = wh.rv( _a ) % wh.rv( _b );
break;
case '|':
_d = wh.rv( _a ) | wh.rv( _b );
break;
case '^':
_d = wh.rv( _a ) ^ wh.rv( _b );
break;
case '&':
_d = wh.rv( _a ) & wh.rv( _b );
break;
case '===':
_d = wh.rv( _a ) === wh.rv( _b );
break;
case '==':
_d = wh.rv( _a ) == wh.rv( _b );
break;
case '!=':
_d = wh.rv( _a ) != wh.rv( _b );
break;
case '!==':
_d = wh.rv( _a ) !== wh.rv( _b );
break;
case '>=':
_d = wh.rv( _a ) >= wh.rv( _b );
break;
case '<=':
_d = wh.rv( _a ) <= wh.rv( _b );
break;
case '>':
_d = wh.rv( _a ) > wh.rv( _b );
break;
case '<':
_d = wh.rv( _a ) < wh.rv( _b );
break;
case '<<':
_d = wh.rv( _a ) << wh.rv( _b );
break;
case '>>':
_d = wh.rv( _a ) >> wh.rv( _b );
break;
default:
break;
}
return _c ? wh.nh( _d, "c" ) : _d;
break;
case '-':
_a = ops.length === 3 ? rev( ops[1], e, s, g, o, _f ) : 0;
_b = ops.length === 3 ? rev( ops[2], e, s, g, o, _f ) : rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && (wh.hn( _a ) === 'h' || wh.hn( _b ) === 'h');
_d = _c ? wh.rv( _a ) - wh.rv( _b ) : _a - _b;
return _c ? wh.nh( _d, "c" ) : _d;
break;
case '!':
_a = rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && (wh.hn( _a ) == 'h');
_d = !wh.rv(_a);
return _c ? wh.nh( _d, "c" ) : _d;
case '~':
_a = rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && (wh.hn( _a ) == 'h');
_d = ~wh.rv(_a);
return _c ? wh.nh( _d, "c" ) : _d;
default:
$gwn('unrecognized op' + rop );
}
}
function rev( ops, e, s, g, o, newap )
{
var op = ops[0];
var _f = false;
if ( typeof newap !== "undefined" ) o.ap = newap;
if( typeof(op)==='object' )
{
var vop=op[0];
var _a, _aa, _b, _bb, _c, _d, _s, _e, _ta, _tb, _td;
switch(vop)
{
case 2:
return ArithmeticEv(ops,e,s,g,o);
break;
case 4: 
return rev( ops[1], e, s, g, o, _f );
break;
case 5: 
switch( ops.length )
{
case 2: 
_a = rev( ops[1],e,s,g,o,_f );
return should_pass_type_info?[_a]:[wh.rv(_a)];
return [_a];
break;
case 1: 
return [];
break;
default:
_a = rev( ops[1],e,s,g,o,_f );
_b = rev( ops[2],e,s,g,o,_f );
_a.push( 
should_pass_type_info ?
_b :
wh.rv( _b )
);
return _a;
break;
}
break;
case 6:
_a = rev(ops[1],e,s,g,o);
var ap = o.ap;
_ta = wh.hn(_a)==='h';
_aa = _ta ? wh.rv(_a) : _a;
o.is_affected |= _ta;
if( should_pass_type_info )
{
if( _aa===null || typeof(_aa) === 'undefined' )
{
return _ta ? wh.nh(undefined, 'e') : undefined;
}
_b = rev(ops[2],e,s,g,o,_f);
_tb = wh.hn(_b) === 'h';
_bb = _tb ? wh.rv(_b) : _b;
o.ap = ap;
o.is_affected |= _tb;
if( _bb===null || typeof(_bb) === 'undefined' || 
_bb === "__proto__" || _bb === "prototype" || _bb === "caller" ) 
{
return (_ta || _tb) ? wh.nh(undefined, 'e') : undefined;
}
_d = _aa[_bb];
if ( typeof _d === 'function' && !ap ) _d = undefined;
_td = wh.hn(_d)==='h';
o.is_affected |= _td;
return (_ta || _tb) ? (_td ? _d : wh.nh(_d, 'e')) : _d;
}
else
{
if( _aa===null || typeof(_aa) === 'undefined' )
{
return undefined;
}
_b = rev(ops[2],e,s,g,o,_f);
_tb = wh.hn(_b) === 'h';
_bb = _tb ? wh.rv(_b) : _b;
o.ap = ap;
o.is_affected |= _tb;
if( _bb===null || typeof(_bb) === 'undefined' || 
_bb === "__proto__" || _bb === "prototype" || _bb === "caller" ) 
{
return undefined;
}
_d = _aa[_bb];
if ( typeof _d === 'function' && !ap ) _d = undefined;
_td = wh.hn(_d)==='h';
o.is_affected |= _td;
return _td ? wh.rv(_d) : _d;
}
case 7: 
switch(ops[1][0])
{
case 11:
o.is_affected |= wh.hn(g)==='h';
return g;
case 3:
_s = wh.rv( s );
_e = wh.rv( e );
_b = ops[1][1];
if (g && g.f && g.f.hasOwnProperty(_b) )
{
_a = g.f;
o.ap = true;
}
else
{
_a = _s && _s.hasOwnProperty(_b) ? 
s : (_e && _e.hasOwnProperty(_b) ? e : undefined );
}
if( should_pass_type_info )
{
if( _a )
{
_ta = wh.hn(_a) === 'h';
_aa = _ta ? wh.rv( _a ) : _a;
_d = _aa[_b];
_td = wh.hn(_d) === 'h';
o.is_affected |= _ta || _td;
_d = _ta && !_td ? wh.nh(_d,'e') : _d;
return _d;
}
}
else
{
if( _a )
{
_ta = wh.hn(_a) === 'h';
_aa = _ta ? wh.rv( _a ) : _a;
_d = _aa[_b];
_td = wh.hn(_d) === 'h';
o.is_affected |= _ta || _td;
return wh.rv(_d);
}
}
return undefined;
}
break;
case 8: 
_a = {};
_a[ops[1]] = rev(ops[2],e,s,g,o,_f);
return _a;
break;
case 9: 
_a = rev(ops[1],e,s,g,o,_f);
_b = rev(ops[2],e,s,g,o,_f);
function merge( _a, _b, _ow )
{
var ka, _bbk;
_ta = wh.hn(_a)==='h';
_tb = wh.hn(_b)==='h';
_aa = wh.rv(_a);
_bb = wh.rv(_b);
for(var k in _bb)
{
if ( _ow || !_aa.hasOwnProperty(k) )
{
_aa[k] = should_pass_type_info ? (_tb ? wh.nh(_bb[k],'e') : _bb[k]) : wh.rv(_bb[k]);
}
}
return _a;
}
var _c = _a
var _ow = true
if ( typeof(ops[1][0]) === "object" && ops[1][0][0] === 10 ) {
_a = _b
_b = _c
_ow = false
}
if ( typeof(ops[1][0]) === "object" && ops[1][0][0] === 10 ) {
var _r = {}
return merge( merge( _r, _a, _ow ), _b, _ow );
}
else
return merge( _a, _b, _ow );
break;
case 10:
_a = rev(ops[1],e,s,g,o,_f);
_a = should_pass_type_info ? _a : wh.rv( _a );
return _a ;
break;
case 12:
var _r;
_a = rev(ops[1],e,s,g,o);
if ( !o.ap )
{
return should_pass_type_info && wh.hn(_a)==='h' ? wh.nh( _r, 'f' ) : _r;
}
var ap = o.ap;
_b = rev(ops[2],e,s,g,o,_f);
o.ap = ap;
_ta = wh.hn(_a)==='h';
_tb = _ca(_b);
_aa = wh.rv(_a);	
_bb = wh.rv(_b); snap_bb=$gdc(_bb,"nv_");
try{
_r = typeof _aa === "function" ? $gdc(_aa.apply(null, snap_bb)) : undefined;
} catch (e){
e.message = e.message.replace(/nv_/g,"");
e.stack = e.stack.substring(0,e.stack.indexOf("\n", e.stack.lastIndexOf("at nv_")));
e.stack = e.stack.replace(/\snv_/g," "); 
e.stack = $gstack(e.stack);	
if("undefined"!==typeof debugInfo)
e.stack += "\n "+" "+" "+" at "+debugInfo[g.opindex][0]+":"+debugInfo[g.opindex][1]+":"+debugInfo[g.opindex][2];
throw e;
}
return should_pass_type_info && (_tb || _ta) ? wh.nh( _r, 'f' ) : _r;
}
}
else
{
if( op === 3 || op === 1) return ops[1];
else if( op === 11 ) 
{
var _a='';
for( var i = 1 ; i < ops.length ; i++ )
{
var xp = wh.rv(rev(ops[i],e,s,g,o,_f));
_a += typeof(xp) === 'undefined' ? '' : xp;
}
return _a;
}
}
}
return rev;
}
gra=$gwrt(true); 
grb=$gwrt(false); 
function TestTest( expr, ops, e,s,g, expect_a, expect_b, expect_affected )
{
{
var o = {is_affected:false};
var a = gra( ops, e,s,g, o );
if( JSON.stringify(a) != JSON.stringify( expect_a )
|| o.is_affected != expect_affected )
{
console.warn( "A. " + expr + " get result " + JSON.stringify(a) + ", " + o.is_affected + ", but " + JSON.stringify( expect_a ) + ", " + expect_affected + " is expected" );
}
}
{
var o = {is_affected:false};
var a = grb( ops, e,s,g, o );
if( JSON.stringify(a) != JSON.stringify( expect_b )
|| o.is_affected != expect_affected )
{
console.warn( "B. " + expr + " get result " + JSON.stringify(a) + ", " + o.is_affected + ", but " + JSON.stringify( expect_b ) + ", " + expect_affected + " is expected" );
}
}
}

function wfor( to_iter, func, env, _s, global, father, itemname, indexname, keyname )
{
var _n = wh.hn( to_iter ) === 'n'; 
var scope = wh.rv( _s ); 
var has_old_item = scope.hasOwnProperty(itemname);
var has_old_index = scope.hasOwnProperty(indexname);
var old_item = scope[itemname];
var old_index = scope[indexname];
var full = Object.prototype.toString.call(wh.rv(to_iter));
var type = full[8]; 
if( type === 'N' && full[10] === 'l' ) type = 'X'; 
var _y;
if( _n )
{
if( type === 'A' ) 
{
var r_iter_item;
for( var i = 0 ; i < to_iter.length ; i++ )
{
scope[itemname] = to_iter[i];
scope[indexname] = _n ? i : wh.nh(i, 'h');
r_iter_item = wh.rv(to_iter[i]);
var key = keyname && r_iter_item ? (keyname==="*this" ? r_iter_item : wh.rv(r_iter_item[keyname])) : undefined;
_y = _v(key);
_(father,_y);
func( env, scope, _y, global );
}
}
else if( type === 'O' ) 
{
var i = 0;
var r_iter_item;
for( var k in to_iter )
{
scope[itemname] = to_iter[k];
scope[indexname] = _n ? k : wh.nh(k, 'h');
r_iter_item = wh.rv(to_iter[k]);
var key = keyname && r_iter_item ? (keyname==="*this" ? r_iter_item : wh.rv(r_iter_item[keyname])) : undefined;
_y = _v(key);
_(father,_y);
func( env,scope,_y,global );
i++;
}
}
else if( type === 'S' ) 
{
for( var i = 0 ; i < to_iter.length ; i++ )
{
scope[itemname] = to_iter[i];
scope[indexname] = _n ? i : wh.nh(i, 'h');
_y = _v( to_iter[i] + i );
_(father,_y);
func( env,scope,_y,global );
}
}
else if( type === 'N' ) 
{
for( var i = 0 ; i < to_iter ; i++ )
{
scope[itemname] = i;
scope[indexname] = _n ? i : wh.nh(i, 'h');
_y = _v( i );
_(father,_y);
func(env,scope,_y,global);
}
}
else
{
}
}
else
{
var r_to_iter = wh.rv(to_iter);
var r_iter_item, iter_item;
if( type === 'A' ) 
{
for( var i = 0 ; i < r_to_iter.length ; i++ )
{
iter_item = r_to_iter[i];
iter_item = wh.hn(iter_item)==='n' ? wh.nh(iter_item,'h') : iter_item;
r_iter_item = wh.rv( iter_item );
scope[itemname] = iter_item
scope[indexname] = _n ? i : wh.nh(i, 'h');
var key = keyname && r_iter_item ? (keyname==="*this" ? r_iter_item : wh.rv(r_iter_item[keyname])) : undefined;
_y = _v(key);
_(father,_y);
func( env, scope, _y, global );
}
}
else if( type === 'O' ) 
{
var i=0;
for( var k in r_to_iter )
{
iter_item = r_to_iter[k];
iter_item = wh.hn(iter_item)==='n'? wh.nh(iter_item,'h') : iter_item;
r_iter_item = wh.rv( iter_item );
scope[itemname] = iter_item;
scope[indexname] = _n ? k : wh.nh(k, 'h');
var key = keyname && r_iter_item ? (keyname==="*this" ? r_iter_item : wh.rv(r_iter_item[keyname])) : undefined;
_y=_v(key);
_(father,_y);
func( env, scope, _y, global );
i++
}
}
else if( type === 'S' ) 
{
for( var i = 0 ; i < r_to_iter.length ; i++ )
{
iter_item = wh.nh(r_to_iter[i],'h');
scope[itemname] = iter_item;
scope[indexname] = _n ? i : wh.nh(i, 'h');
_y = _v( to_iter[i] + i );
_(father,_y);
func( env, scope, _y, global );
}
}
else if( type === 'N' ) 
{
for( var i = 0 ; i < r_to_iter ; i++ )
{
iter_item = wh.nh(i,'h');
scope[itemname] = iter_item;
scope[indexname]= _n ? i : wh.nh(i,'h');
_y = _v( i );
_(father,_y);
func(env,scope,_y,global);
}
}
else
{
}
}
if(has_old_item)
{
scope[itemname]=old_item;
}
else
{
delete scope[itemname];
}
if(has_old_index)
{
scope[indexname]=old_index;
}
else
{
delete scope[indexname];
}
}

function _ca(o)
{ 
if ( wh.hn(o) == 'h' ) return true;
if ( typeof o !== "object" ) return false;
for(var i in o){ 
if ( o.hasOwnProperty(i) ){
if (_ca(o[i])) return true;
}
}
return false;
}
function _da( node, attrname, opindex, raw, o )
{
var isaffected = false;
if ( o.is_affected || _ca(raw) ) 
{
node.n.push( attrname );
node.raw[attrname] = raw;
var value = $gdc( raw, "", 2 );
return value;
}
else
{
var value = $gdc( raw, "", 2 );
return value;
}
}
function _r( node, attrname, opindex, env, scope, global ) 
{
global.opindex=opindex;
var o = {}, _env;
var a = grb( z[opindex], env, scope, global, o );
a = _da( node, attrname, opindex, a, o );
node.attr[attrname] = a;
}
function _o( opindex, env, scope, global )
{
global.opindex=opindex;
var nothing = {};
var r = grb( z[opindex], env, scope, global, nothing );
return (r&&r.constructor===Function) ? undefined : r;
}
function _1( opindex, env, scope, global, o )
{
var o = o || {};
global.opindex=opindex;
return gra( z[opindex], env, scope, global, o );
}
function _2( opindex, func, env, scope, global, father, itemname, indexname, keyname )
{
var o = {};
var to_iter = _1( opindex, env, scope, global );
wfor( to_iter, func, env, scope, global, father, itemname, indexname, keyname );
}


function _m(tag,attrs,generics,env,scope,global)
{
var tmp=_n(tag);
var base=0;
for(var i = 0 ; i < attrs.length ; i+=2 )
{
if(base+attrs[i+1]<0)
{
tmp.attr[attrs[i]]=true;
}
else
{
_r(tmp,attrs[i],base+attrs[i+1],env,scope,global);
if(base===0)base=attrs[i+1];
}
}
for(var i=0;i<generics.length;i+=2)
{
if(base+generics[i+1]<0)
{
tmp.generics[generics[i]]="";
}
else
{
var $t=grb(z[base+generics[i+1]],env,scope,global);
if ($t!="") $t="wx-"+$t;
tmp.generics[generics[i]]=$t;
if(base===0)base=generics[i+1];
}
}
return tmp;
}

var nf_init=function(){
if(typeof __WXML_GLOBAL__==="undefined"||undefined===__WXML_GLOBAL__.wxs_nf_init){
nf_init_Object();nf_init_Function();nf_init_Array();nf_init_String();nf_init_Boolean();nf_init_Number();nf_init_Math();nf_init_Date();nf_init_RegExp();
}
if(typeof __WXML_GLOBAL__!=="undefined") __WXML_GLOBAL__.wxs_nf_init=true;
};
var nf_init_Object=function(){
Object.defineProperty(Object.prototype,"nv_constructor",{writable:true,value:"Object"})
Object.defineProperty(Object.prototype,"nv_toString",{writable:true,value:function(){return "[object Object]"}})
}
var nf_init_Function=function(){
Object.defineProperty(Function.prototype,"nv_constructor",{writable:true,value:"Function"})
Object.defineProperty(Function.prototype,"nv_length",{get:function(){return this.length;},set:function(){}});
Object.defineProperty(Function.prototype,"nv_toString",{writable:true,value:function(){return "[function Function]"}})
}
var nf_init_Array=function(){
Object.defineProperty(Array.prototype,"nv_toString",{writable:true,value:function(){return this.nv_join();}})
Object.defineProperty(Array.prototype,"nv_join",{writable:true,value:function(s){
s=undefined==s?',':s;
var r="";
for(var i=0;i<this.length;++i){
if(0!=i) r+=s;
if(null==this[i]||undefined==this[i]) r+='';	
else if(typeof this[i]=='function') r+=this[i].nv_toString();
else if(typeof this[i]=='object'&&this[i].nv_constructor==="Array") r+=this[i].nv_join();
else r+=this[i].toString();
}
return r;
}})
Object.defineProperty(Array.prototype,"nv_constructor",{writable:true,value:"Array"})
Object.defineProperty(Array.prototype,"nv_concat",{writable:true,value:Array.prototype.concat})
Object.defineProperty(Array.prototype,"nv_pop",{writable:true,value:Array.prototype.pop})
Object.defineProperty(Array.prototype,"nv_push",{writable:true,value:Array.prototype.push})
Object.defineProperty(Array.prototype,"nv_reverse",{writable:true,value:Array.prototype.reverse})
Object.defineProperty(Array.prototype,"nv_shift",{writable:true,value:Array.prototype.shift})
Object.defineProperty(Array.prototype,"nv_slice",{writable:true,value:Array.prototype.slice})
Object.defineProperty(Array.prototype,"nv_sort",{writable:true,value:Array.prototype.sort})
Object.defineProperty(Array.prototype,"nv_splice",{writable:true,value:Array.prototype.splice})
Object.defineProperty(Array.prototype,"nv_unshift",{writable:true,value:Array.prototype.unshift})
Object.defineProperty(Array.prototype,"nv_indexOf",{writable:true,value:Array.prototype.indexOf})
Object.defineProperty(Array.prototype,"nv_lastIndexOf",{writable:true,value:Array.prototype.lastIndexOf})
Object.defineProperty(Array.prototype,"nv_every",{writable:true,value:Array.prototype.every})
Object.defineProperty(Array.prototype,"nv_some",{writable:true,value:Array.prototype.some})
Object.defineProperty(Array.prototype,"nv_forEach",{writable:true,value:Array.prototype.forEach})
Object.defineProperty(Array.prototype,"nv_map",{writable:true,value:Array.prototype.map})
Object.defineProperty(Array.prototype,"nv_filter",{writable:true,value:Array.prototype.filter})
Object.defineProperty(Array.prototype,"nv_reduce",{writable:true,value:Array.prototype.reduce})
Object.defineProperty(Array.prototype,"nv_reduceRight",{writable:true,value:Array.prototype.reduceRight})
Object.defineProperty(Array.prototype,"nv_length",{get:function(){return this.length;},set:function(value){this.length=value;}});
}
var nf_init_String=function(){
Object.defineProperty(String.prototype,"nv_constructor",{writable:true,value:"String"})
Object.defineProperty(String.prototype,"nv_toString",{writable:true,value:String.prototype.toString})
Object.defineProperty(String.prototype,"nv_valueOf",{writable:true,value:String.prototype.valueOf})
Object.defineProperty(String.prototype,"nv_charAt",{writable:true,value:String.prototype.charAt})
Object.defineProperty(String.prototype,"nv_charCodeAt",{writable:true,value:String.prototype.charCodeAt})
Object.defineProperty(String.prototype,"nv_concat",{writable:true,value:String.prototype.concat})
Object.defineProperty(String.prototype,"nv_indexOf",{writable:true,value:String.prototype.indexOf})
Object.defineProperty(String.prototype,"nv_lastIndexOf",{writable:true,value:String.prototype.lastIndexOf})
Object.defineProperty(String.prototype,"nv_localeCompare",{writable:true,value:String.prototype.localeCompare})
Object.defineProperty(String.prototype,"nv_match",{writable:true,value:String.prototype.match})
Object.defineProperty(String.prototype,"nv_replace",{writable:true,value:String.prototype.replace})
Object.defineProperty(String.prototype,"nv_search",{writable:true,value:String.prototype.search})
Object.defineProperty(String.prototype,"nv_slice",{writable:true,value:String.prototype.slice})
Object.defineProperty(String.prototype,"nv_split",{writable:true,value:String.prototype.split})
Object.defineProperty(String.prototype,"nv_substring",{writable:true,value:String.prototype.substring})
Object.defineProperty(String.prototype,"nv_toLowerCase",{writable:true,value:String.prototype.toLowerCase})
Object.defineProperty(String.prototype,"nv_toLocaleLowerCase",{writable:true,value:String.prototype.toLocaleLowerCase})
Object.defineProperty(String.prototype,"nv_toUpperCase",{writable:true,value:String.prototype.toUpperCase})
Object.defineProperty(String.prototype,"nv_toLocaleUpperCase",{writable:true,value:String.prototype.toLocaleUpperCase})
Object.defineProperty(String.prototype,"nv_trim",{writable:true,value:String.prototype.trim})
Object.defineProperty(String.prototype,"nv_length",{get:function(){return this.length;},set:function(value){this.length=value;}});
}
var nf_init_Boolean=function(){
Object.defineProperty(Boolean.prototype,"nv_constructor",{writable:true,value:"Boolean"})
Object.defineProperty(Boolean.prototype,"nv_toString",{writable:true,value:Boolean.prototype.toString})
Object.defineProperty(Boolean.prototype,"nv_valueOf",{writable:true,value:Boolean.prototype.valueOf})
}
var nf_init_Number=function(){
Object.defineProperty(Number,"nv_MAX_VALUE",{writable:false,value:Number.MAX_VALUE})
Object.defineProperty(Number,"nv_MIN_VALUE",{writable:false,value:Number.MIN_VALUE})
Object.defineProperty(Number,"nv_NEGATIVE_INFINITY",{writable:false,value:Number.NEGATIVE_INFINITY})
Object.defineProperty(Number,"nv_POSITIVE_INFINITY",{writable:false,value:Number.POSITIVE_INFINITY})
Object.defineProperty(Number.prototype,"nv_constructor",{writable:true,value:"Number"})
Object.defineProperty(Number.prototype,"nv_toString",{writable:true,value:Number.prototype.toString})
Object.defineProperty(Number.prototype,"nv_toLocaleString",{writable:true,value:Number.prototype.toLocaleString})
Object.defineProperty(Number.prototype,"nv_valueOf",{writable:true,value:Number.prototype.valueOf})
Object.defineProperty(Number.prototype,"nv_toFixed",{writable:true,value:Number.prototype.toFixed})
Object.defineProperty(Number.prototype,"nv_toExponential",{writable:true,value:Number.prototype.toExponential})
Object.defineProperty(Number.prototype,"nv_toPrecision",{writable:true,value:Number.prototype.toPrecision})
}
var nf_init_Math=function(){
Object.defineProperty(Math,"nv_E",{writable:false,value:Math.E})
Object.defineProperty(Math,"nv_LN10",{writable:false,value:Math.LN10})
Object.defineProperty(Math,"nv_LN2",{writable:false,value:Math.LN2})
Object.defineProperty(Math,"nv_LOG2E",{writable:false,value:Math.LOG2E})
Object.defineProperty(Math,"nv_LOG10E",{writable:false,value:Math.LOG10E})
Object.defineProperty(Math,"nv_PI",{writable:false,value:Math.PI})
Object.defineProperty(Math,"nv_SQRT1_2",{writable:false,value:Math.SQRT1_2})
Object.defineProperty(Math,"nv_SQRT2",{writable:false,value:Math.SQRT2})
Object.defineProperty(Math,"nv_abs",{writable:false,value:Math.abs})
Object.defineProperty(Math,"nv_acos",{writable:false,value:Math.acos})
Object.defineProperty(Math,"nv_asin",{writable:false,value:Math.asin})
Object.defineProperty(Math,"nv_atan",{writable:false,value:Math.atan})
Object.defineProperty(Math,"nv_atan2",{writable:false,value:Math.atan2})
Object.defineProperty(Math,"nv_ceil",{writable:false,value:Math.ceil})
Object.defineProperty(Math,"nv_cos",{writable:false,value:Math.cos})
Object.defineProperty(Math,"nv_exp",{writable:false,value:Math.exp})
Object.defineProperty(Math,"nv_floor",{writable:false,value:Math.floor})
Object.defineProperty(Math,"nv_log",{writable:false,value:Math.log})
Object.defineProperty(Math,"nv_max",{writable:false,value:Math.max})
Object.defineProperty(Math,"nv_min",{writable:false,value:Math.min})
Object.defineProperty(Math,"nv_pow",{writable:false,value:Math.pow})
Object.defineProperty(Math,"nv_random",{writable:false,value:Math.random})
Object.defineProperty(Math,"nv_round",{writable:false,value:Math.round})
Object.defineProperty(Math,"nv_sin",{writable:false,value:Math.sin})
Object.defineProperty(Math,"nv_sqrt",{writable:false,value:Math.sqrt})
Object.defineProperty(Math,"nv_tan",{writable:false,value:Math.tan})
}
var nf_init_Date=function(){
Object.defineProperty(Date.prototype,"nv_constructor",{writable:true,value:"Date"})
Object.defineProperty(Date,"nv_parse",{writable:true,value:Date.parse})
Object.defineProperty(Date,"nv_UTC",{writable:true,value:Date.UTC})
Object.defineProperty(Date,"nv_now",{writable:true,value:Date.now})
Object.defineProperty(Date.prototype,"nv_toString",{writable:true,value:Date.prototype.toString})
Object.defineProperty(Date.prototype,"nv_toDateString",{writable:true,value:Date.prototype.toDateString})
Object.defineProperty(Date.prototype,"nv_toTimeString",{writable:true,value:Date.prototype.toTimeString})
Object.defineProperty(Date.prototype,"nv_toLocaleString",{writable:true,value:Date.prototype.toLocaleString})
Object.defineProperty(Date.prototype,"nv_toLocaleDateString",{writable:true,value:Date.prototype.toLocaleDateString})
Object.defineProperty(Date.prototype,"nv_toLocaleTimeString",{writable:true,value:Date.prototype.toLocaleTimeString})
Object.defineProperty(Date.prototype,"nv_valueOf",{writable:true,value:Date.prototype.valueOf})
Object.defineProperty(Date.prototype,"nv_getTime",{writable:true,value:Date.prototype.getTime})
Object.defineProperty(Date.prototype,"nv_getFullYear",{writable:true,value:Date.prototype.getFullYear})
Object.defineProperty(Date.prototype,"nv_getUTCFullYear",{writable:true,value:Date.prototype.getUTCFullYear})
Object.defineProperty(Date.prototype,"nv_getMonth",{writable:true,value:Date.prototype.getMonth})
Object.defineProperty(Date.prototype,"nv_getUTCMonth",{writable:true,value:Date.prototype.getUTCMonth})
Object.defineProperty(Date.prototype,"nv_getDate",{writable:true,value:Date.prototype.getDate})
Object.defineProperty(Date.prototype,"nv_getUTCDate",{writable:true,value:Date.prototype.getUTCDate})
Object.defineProperty(Date.prototype,"nv_getDay",{writable:true,value:Date.prototype.getDay})
Object.defineProperty(Date.prototype,"nv_getUTCDay",{writable:true,value:Date.prototype.getUTCDay})
Object.defineProperty(Date.prototype,"nv_getHours",{writable:true,value:Date.prototype.getHours})
Object.defineProperty(Date.prototype,"nv_getUTCHours",{writable:true,value:Date.prototype.getUTCHours})
Object.defineProperty(Date.prototype,"nv_getMinutes",{writable:true,value:Date.prototype.getMinutes})
Object.defineProperty(Date.prototype,"nv_getUTCMinutes",{writable:true,value:Date.prototype.getUTCMinutes})
Object.defineProperty(Date.prototype,"nv_getSeconds",{writable:true,value:Date.prototype.getSeconds})
Object.defineProperty(Date.prototype,"nv_getUTCSeconds",{writable:true,value:Date.prototype.getUTCSeconds})
Object.defineProperty(Date.prototype,"nv_getMilliseconds",{writable:true,value:Date.prototype.getMilliseconds})
Object.defineProperty(Date.prototype,"nv_getUTCMilliseconds",{writable:true,value:Date.prototype.getUTCMilliseconds})
Object.defineProperty(Date.prototype,"nv_getTimezoneOffset",{writable:true,value:Date.prototype.getTimezoneOffset})
Object.defineProperty(Date.prototype,"nv_setTime",{writable:true,value:Date.prototype.setTime})
Object.defineProperty(Date.prototype,"nv_setMilliseconds",{writable:true,value:Date.prototype.setMilliseconds})
Object.defineProperty(Date.prototype,"nv_setUTCMilliseconds",{writable:true,value:Date.prototype.setUTCMilliseconds})
Object.defineProperty(Date.prototype,"nv_setSeconds",{writable:true,value:Date.prototype.setSeconds})
Object.defineProperty(Date.prototype,"nv_setUTCSeconds",{writable:true,value:Date.prototype.setUTCSeconds})
Object.defineProperty(Date.prototype,"nv_setMinutes",{writable:true,value:Date.prototype.setMinutes})
Object.defineProperty(Date.prototype,"nv_setUTCMinutes",{writable:true,value:Date.prototype.setUTCMinutes})
Object.defineProperty(Date.prototype,"nv_setHours",{writable:true,value:Date.prototype.setHours})
Object.defineProperty(Date.prototype,"nv_setUTCHours",{writable:true,value:Date.prototype.setUTCHours})
Object.defineProperty(Date.prototype,"nv_setDate",{writable:true,value:Date.prototype.setDate})
Object.defineProperty(Date.prototype,"nv_setUTCDate",{writable:true,value:Date.prototype.setUTCDate})
Object.defineProperty(Date.prototype,"nv_setMonth",{writable:true,value:Date.prototype.setMonth})
Object.defineProperty(Date.prototype,"nv_setUTCMonth",{writable:true,value:Date.prototype.setUTCMonth})
Object.defineProperty(Date.prototype,"nv_setFullYear",{writable:true,value:Date.prototype.setFullYear})
Object.defineProperty(Date.prototype,"nv_setUTCFullYear",{writable:true,value:Date.prototype.setUTCFullYear})
Object.defineProperty(Date.prototype,"nv_toUTCString",{writable:true,value:Date.prototype.toUTCString})
Object.defineProperty(Date.prototype,"nv_toISOString",{writable:true,value:Date.prototype.toISOString})
Object.defineProperty(Date.prototype,"nv_toJSON",{writable:true,value:Date.prototype.toJSON})
}
var nf_init_RegExp=function(){
Object.defineProperty(RegExp.prototype,"nv_constructor",{writable:true,value:"RegExp"})
Object.defineProperty(RegExp.prototype,"nv_exec",{writable:true,value:RegExp.prototype.exec})
Object.defineProperty(RegExp.prototype,"nv_test",{writable:true,value:RegExp.prototype.test})
Object.defineProperty(RegExp.prototype,"nv_toString",{writable:true,value:RegExp.prototype.toString})
Object.defineProperty(RegExp.prototype,"nv_source",{get:function(){return this.source;},set:function(){}});
Object.defineProperty(RegExp.prototype,"nv_global",{get:function(){return this.global;},set:function(){}});
Object.defineProperty(RegExp.prototype,"nv_ignoreCase",{get:function(){return this.ignoreCase;},set:function(){}});
Object.defineProperty(RegExp.prototype,"nv_multiline",{get:function(){return this.multiline;},set:function(){}});
Object.defineProperty(RegExp.prototype,"nv_lastIndex",{get:function(){return this.lastIndex;},set:function(v){this.lastIndex=v;}});
}
nf_init();
var nv_getDate=function(){var args=Array.prototype.slice.call(arguments);args.unshift(Date);return new(Function.prototype.bind.apply(Date, args));}
var nv_getRegExp=function(){var args=Array.prototype.slice.call(arguments);args.unshift(RegExp);return new(Function.prototype.bind.apply(RegExp, args));}
var nv_console={}
nv_console.nv_log=function(){var res="WXSRT:";for(var i=0;i<arguments.length;++i)res+=arguments[i]+" ";console.log(res);}
var nv_parseInt = parseInt, nv_parseFloat = parseFloat, nv_isNaN = isNaN, nv_isFinite = isFinite, nv_decodeURI = decodeURI, nv_decodeURIComponent = decodeURIComponent, nv_encodeURI = encodeURI, nv_encodeURIComponent = encodeURIComponent;
function $gdc(o,p,r) {
o=wh.rv(o);
if(o===null||o===undefined) return o;
if(o.constructor===String||o.constructor===Boolean||o.constructor===Number) return o;
if(o.constructor===Object){
var copy={};
for(var k in o)
if(o.hasOwnProperty(k))
if(undefined===p) copy[k.substring(3)]=$gdc(o[k],p,r);
else copy[p+k]=$gdc(o[k],p,r);
return copy;
}
if(o.constructor===Array){
var copy=[];
for(var i=0;i<o.length;i++) copy.push($gdc(o[i],p,r));
return copy;
}
if(o.constructor===Date){
var copy=new Date();
copy.setTime(o.getTime());
return copy;
}
if(o.constructor===RegExp){
var f="";
if(o.global) f+="g";
if(o.ignoreCase) f+="i";
if(o.multiline) f+="m";
return (new RegExp(o.source,f));
}
if(r&&o.constructor===Function){
if ( r == 1 ) return $gdc(o(),undefined, 2);
if ( r == 2 ) return o;
}
return null;
}
var nv_JSON={}
nv_JSON.nv_stringify=function(o){
JSON.stringify(o);
return JSON.stringify($gdc(o));
}
nv_JSON.nv_parse=function(o){
if(o===undefined) return undefined;
var t=JSON.parse(o);
return $gdc(t,'nv_');
}

function _af(p, a, c){
p.extraAttr = {"t_action": a, "t_cid": c};
}

function _ai(i,p,e,me,r,c){var x=_grp(p,e,me);if(x)i.push(x);else{i.push('');_wp(me+':import:'+r+':'+c+': Path `'+p+'` not found from `'+me+'`.')}}
function _grp(p,e,me){if(p[0]!='/'){var mepart=me.split('/');mepart.pop();var ppart=p.split('/');for(var i=0;i<ppart.length;i++){if( ppart[i]=='..')mepart.pop();else if(!ppart[i]||ppart[i]=='.')continue;else mepart.push(ppart[i]);}p=mepart.join('/');}if(me[0]=='.'&&p[0]=='/')p='.'+p;if(e[p])return p;if(e[p+'.wxml'])return p+'.wxml';}
function _gd(p,c,e,d){if(!c)return;if(d[p][c])return d[p][c];for(var x=e[p].i.length-1;x>=0;x--){if(e[p].i[x]&&d[e[p].i[x]][c])return d[e[p].i[x]][c]};for(var x=e[p].ti.length-1;x>=0;x--){var q=_grp(e[p].ti[x],e,p);if(q&&d[q][c])return d[q][c]}var ii=_gapi(e,p);for(var x=0;x<ii.length;x++){if(ii[x]&&d[ii[x]][c])return d[ii[x]][c]}for(var k=e[p].j.length-1;k>=0;k--)if(e[p].j[k]){for(var q=e[e[p].j[k]].ti.length-1;q>=0;q--){var pp=_grp(e[e[p].j[k]].ti[q],e,p);if(pp&&d[pp][c]){return d[pp][c]}}}}
function _gapi(e,p){if(!p)return [];if($gaic[p]){return $gaic[p]};var ret=[],q=[],h=0,t=0,put={},visited={};q.push(p);visited[p]=true;t++;while(h<t){var a=q[h++];for(var i=0;i<e[a].ic.length;i++){var nd=e[a].ic[i];var np=_grp(nd,e,a);if(np&&!visited[np]){visited[np]=true;q.push(np);t++;}}for(var i=0;a!=p&&i<e[a].ti.length;i++){var ni=e[a].ti[i];var nm=_grp(ni,e,a);if(nm&&!put[nm]){put[nm]=true;ret.push(nm);}}}$gaic[p]=ret;return ret;}
var $ixc={};function _ic(p,ent,me,e,s,r,gg){var x=_grp(p,ent,me);ent[me].j.push(x);if(x){if($ixc[x]){_wp('-1:include:-1:-1: `'+p+'` is being included in a loop, will be stop.');return;}$ixc[x]=true;try{ent[x].f(e,s,r,gg)}catch(e){}$ixc[x]=false;}else{_wp(me+':include:-1:-1: Included path `'+p+'` not found from `'+me+'`.')}}
function _w(tn,f,line,c){_wp(f+':template:'+line+':'+c+': Template `'+tn+'` not found.');}function _ev(dom){var changed=false;delete dom.properities;delete dom.n;if(dom.children){do{changed=false;var newch = [];for(var i=0;i<dom.children.length;i++){var ch=dom.children[i];if( ch.tag=='virtual'){changed=true;for(var j=0;ch.children&&j<ch.children.length;j++){newch.push(ch.children[j]);}}else { newch.push(ch); } } dom.children = newch; }while(changed);for(var i=0;i<dom.children.length;i++){_ev(dom.children[i]);}} return dom; }
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules;
var p_={}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_wxa75efa648b60994b || [];
if ( !__WXML_GLOBAL__.ops_init.$gwx_wxa75efa648b60994b){
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'autoplay']]);Z([3,'__onTvpEnded']);Z([3,'__onTvpError']);Z([3,'__onTvpPause']);Z([3,'__onTvpPlay']);Z([3,'__onTvpTimeupdate']);Z([3,'player_video']);Z([1,false]);Z([[2,'?:'],[[7],[3,'tvpIsAd']],[1,false],[[7],[3,'enableProgressGesture']]]);Z([1,true]);Z([[2,'=='],[[7],[3,'tvpState']],[1,'error']]);Z([3,'tvp']);Z([[2,'?:'],[[7],[3,'tvpIsAd']],[1,0],[[7],[3,'initialTime']]]);Z([[7],[3,'loop']]);Z([[7],[3,'muted']]);Z([[7],[3,'objectFit']]);Z([[7],[3,'pageGesture']]);Z([[7],[3,'poster']]);Z([[7],[3,'showCenterPlayBtn']]);Z([[7],[3,'showFullscreenBtn']]);Z([[7],[3,'showPlayBtn']]);Z([[2,'!'],[[7],[3,'tvpIsAd']]]);Z([[7],[3,'tvpUrl']]);Z([[2,'&&'],[[7],[3,'tvpIsAd']],[[7],[3,'progressSkipTime']]]);Z([3,'mod_skipad']);Z([[2,'!'],[[2,'&&'],[[2,'!='],[[7],[3,'progressSkipTime']],[[2,'-'],[1,1]]],[[2,'<='],[[7],[3,'progressSkipTime']],[[2,'+'],[[7],[3,'progressTime']],[[7],[3,'progressBaseTime']]]]]]);Z(z[25]);Z([[2,'&&'],[[2,'!='],[[7],[3,'progressSkipTime']],[[2,'-'],[1,1]]],[[2,'<='],[[7],[3,'progressSkipTime']],[[2,'+'],[[7],[3,'progressTime']],[[7],[3,'progressBaseTime']]]]]);Z(z[0]);Z(z[1]);Z(z[2]);Z(z[3]);Z(z[4]);Z(z[5]);Z(z[6]);Z([[2,'!'],[[2,'&&'],[[7],[3,'autoplay']],[[7],[3,'tvpIsAd']]]]);Z(z[7]);Z(z[8]);Z(z[9]);Z(z[10]);Z(z[11]);Z(z[12]);Z(z[13]);Z(z[14]);Z(z[15]);Z(z[16]);Z(z[17]);Z(z[18]);Z(z[19]);Z(z[20]);Z([[2,'!'],[[2,'&&'],[[2,'!'],[[7],[3,'autoplay']]],[[7],[3,'tvpIsAd']]]]);Z(z[22]);Z(z[23]);Z(z[24]);Z(z[25]);Z(z[25]);Z(z[27]);})(z);__WXML_GLOBAL__.ops_set.$gwx_wxa75efa648b60994b=z;
__WXML_GLOBAL__.ops_init.$gwx_wxa75efa648b60994b=true;
}
var nv_require=function(){var nnm={};var nom={};return function(n){return function(){if(!nnm[n]) return undefined;try{if(!nom[n])nom[n]=nnm[n]();return nom[n];}catch(e){e.message=e.message.replace(/nv_/g,'');var tmp = e.stack.substring(0,e.stack.lastIndexOf(n));e.stack = tmp.substring(0,tmp.lastIndexOf('\n'));e.stack = e.stack.replace(/\snv_/g,' ');e.stack = $gstack(e.stack);e.stack += '\n    at ' + n.substring(2);throw e;}
}}}()
var x=['./component/live/live.wxml','./component/noad-video/noad-video.wxml','./component/video/video.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
d_[x[1]]={}
var m1=function(e,s,r,gg){
var xC=_m('video',['autoplay',0,'bindended',1,'binderror',1,'bindpause',2,'bindplay',3,'bindtimeupdate',4,'class',5,'danmuBtn',6,'enableProgressGesture',7,'enableDanmu',8,'hidden',9,'id',10,'initialTime',11,'loop',12,'muted',13,'objectFit',14,'pageGesture',15,'poster',16,'showCenterPlayBtn',17,'showFullscreenBtn',18,'showPlayBtn',19,'showProgress',20,'src',21],[],e,s,gg)
var oD=_v()
_(xC,oD)
if(_o(23,e,s,gg)){oD.wxVkey=1
var fE=_n('cover-view')
_r(fE,'class',24,e,s,gg)
var cF=_v()
_(fE,cF)
if(_o(25,e,s,gg)){cF.wxVkey=1
}
var hG=_v()
_(fE,hG)
if(_o(26,e,s,gg)){hG.wxVkey=1
}
var oH=_v()
_(fE,oH)
if(_o(27,e,s,gg)){oH.wxVkey=1
}
cF.wxXCkey=1
hG.wxXCkey=1
oH.wxXCkey=1
_(oD,fE)
}
oD.wxXCkey=1
_(r,xC)
return r
}
e_[x[1]]={f:m1,j:[],i:[],ti:[],ic:[]}
d_[x[2]]={}
var m2=function(e,s,r,gg){
var oJ=_m('video',['autoplay',28,'bindended',1,'binderror',2,'bindpause',3,'bindplay',4,'bindtimeupdate',5,'class',6,'controls',7,'danmuBtn',8,'enableProgressGesture',9,'enableDanmu',10,'hidden',11,'id',12,'initialTime',13,'loop',14,'muted',15,'objectFit',16,'pageGesture',17,'poster',18,'showCenterPlayBtn',19,'showFullscreenBtn',20,'showPlayBtn',21,'showProgress',22,'src',23],[],e,s,gg)
var lK=_v()
_(oJ,lK)
if(_o(52,e,s,gg)){lK.wxVkey=1
var aL=_n('cover-view')
_r(aL,'class',53,e,s,gg)
var tM=_v()
_(aL,tM)
if(_o(54,e,s,gg)){tM.wxVkey=1
}
var eN=_v()
_(aL,eN)
if(_o(55,e,s,gg)){eN.wxVkey=1
}
var bO=_v()
_(aL,bO)
if(_o(56,e,s,gg)){bO.wxVkey=1
}
tM.wxXCkey=1
eN.wxXCkey=1
bO.wxXCkey=1
_(lK,aL)
}
lK.wxXCkey=1
_(r,oJ)
return r
}
e_[x[2]]={f:m2,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
}catch(err){
console.log(err)
}
return root;
}
}
}

				global.__wxAppCode__['plugin-private://wxa75efa648b60994b/component/live/live.json'] = {
  "component": true
};
		global.__wxAppCode__['plugin-private://wxa75efa648b60994b/component/live/live.wxml'] = $gwx_wxa75efa648b60994b( './component/live/live.wxml' );
		global.__wxAppCode__['plugin-private://wxa75efa648b60994b/component/noad-video/noad-video.json'] = {
  "component": true
};
		global.__wxAppCode__['plugin-private://wxa75efa648b60994b/component/noad-video/noad-video.wxml'] = $gwx_wxa75efa648b60994b( './component/noad-video/noad-video.wxml' );
		global.__wxAppCode__['plugin-private://wxa75efa648b60994b/component/video/video.json'] = {
  "component": true
};
		global.__wxAppCode__['plugin-private://wxa75efa648b60994b/component/video/video.wxml'] = $gwx_wxa75efa648b60994b( './component/video/video.wxml' );
		global.__wxAppCode__['plugin-private://wxa75efa648b60994b/plugin.json'] = {
  "publicComponents": {
    "video": "component/video/video",
    "noad-video": "component/noad-video/noad-video",
    "live": "component/live/live"
  },
  "main": "component/txv-context.js"
}
;
		global.__wxAppCode__['plugin-private://wxa75efa648b60994b/plugin.wxml'] = $gwx_wxa75efa648b60994b( './plugin.wxml' );
	
				define("component/txv-context.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";var t={};module.exports={getTxvContext:function(e){if(!t[e])throw new Error("找不到playerid为"+e+"的txv-video组件");return t[e]},txvAttached:function(e,r){t[e]=r},txvDetached:function(e){delete t[e]}}; 
 			}); 
		define("index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";var e=require("./src/video");module.exports=e; 
 			}); 
		define("lib-inject.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";var e="./src/lib/es6-promise",r="./src/lib/request";try{var s=require("../tvp.js");e=s.Promise||e,r=s.request||r}catch(e){}module.exports={Promise:require(e),request:require(r).get}; 
 			}); 
		define("src/classes/Content.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";function t(t,e){if(!(t instanceof e))throw new TypeError("Cannot call a class as a function")}var e="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(t){return typeof t}:function(t){return t&&"function"==typeof Symbol&&t.constructor===Symbol&&t!==Symbol.prototype?"symbol":typeof t},i=function(){function t(t,e){for(var i=0;i<e.length;i++){var n=e[i];n.enumerable=n.enumerable||!1,n.configurable=!0,"value"in n&&(n.writable=!0),Object.defineProperty(t,n.key,n)}}return function(e,i,n){return i&&t(e.prototype,i),n&&t(e,n),e}}(),n=require("../lib/message"),r=1;module.exports=function(){function o(e){var i=this;t(this,o),this.mockUpdate=0,this._urlIndex=0,Object.defineProperties(this,{_url:{value:e.url instanceof Array?e.url:[e.url]},_id:{value:r++},_duration:{value:e.duration},_filesize:{value:e.filesize},_charged:{value:e.charged},_preview:{value:e.preview},isad:{value:e.isad}}),(new n).assign(this);var u=null,a=null;this.on("play",function(){u=setTimeout(function(){i.emit("timeout",1e4)},1e4),a=setTimeout(function(){i.emit("timeout",2e4)},2e4)},!0),this.on("start",function(){clearTimeout(u),clearTimeout(a)},!0)}return i(o,[{key:"url",get:function(){return this._url[this._urlIndex]}},{key:"id",get:function(){return this._id}},{key:"duration",get:function(){return this._duration}},{key:"filesize",get:function(){return this._filesize}},{key:"preview",get:function(){return this._preview}},{key:"charged",get:function(){return this._charged}}]),i(o,[{key:"onContentEnd",value:function(){this.emit("end")}},{key:"onContentPlay",value:function(){this.emittedPlay=!0,this.emit("play")}},{key:"onContentPause",value:function(){}},{key:"onContentTimeupdate",value:function(t){this.emittedPlay&&(t&&t.target&&(t=t.detail.currentTime),!this.emittedStart&&((void 0===t?"undefined":e(t))==e(void 0)?this.mockUpdate++>5:t>0)&&(this.emit("start"),this.emittedStart=!0),this.emit.apply(this,["timeupdate",t]))}},{key:"onContentError",value:function(){if(this._url.length>this._urlIndex+1)return this._urlIndex++,void this.emit("change",this.url);this.emit.apply(this,["error"].concat([].slice.call(arguments,0)))}},{key:"onContentSkip",value:function(){this.isad&&this.emit("skip")}}]),o}(); 
 			}); 
		define("src/classes/Controller.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";function t(t,e){if(!(t instanceof e))throw new TypeError("Cannot call a class as a function")}function e(t){var e={};return(t instanceof Array?t:[].slice.call(arguments,0)).forEach(function(t){var n=t.initialize;Object.defineProperty(e,t.name,{get:function(){return n},set:function(e){var r=n;n=e,t.onChange&&t.onChange(e,r)}})}),e}var n=function(){function t(t,e){for(var n=0;n<e.length;n++){var r=e[n];r.enumerable=r.enumerable||!1,r.configurable=!0,"value"in r&&(r.writable=!0),Object.defineProperty(t,r.key,r)}}return function(e,n,r){return n&&t(e.prototype,n),r&&t(e,r),e}}(),r=require("../lib/message"),i=require("../../lib-inject").Promise;module.exports=function(){function o(){for(var n=this,a=arguments.length,s=Array(a),c=0;c<a;c++)s[c]=arguments[c];t(this,o),this.started=i.defer(),(new r).assign(this);var u=this.model=new e([{name:"state",onChange:function(t,e){n.emit("statechange",t,e)},initialize:"loading"},{name:"currentContent",initialize:null}]);Object.defineProperties(this,{currentContent:{get:function(){return u.currentContent}},state:{get:function(){return u.state}}}),this.flow=this.createFlow.apply(this,s),this.flow.catch(function(t){n.emit("error",t)}),["End","Play","Pause","Timeupdate","Error","Skip"].forEach(function(t){n["onContent"+t]=function(){for(var e=arguments.length,r=Array(e),i=0;i<e;i++)r[i]=arguments[i];n.emit.apply(n,["content"+t.toLowerCase()].concat(r))},n["on"+t]=function(){console.warn("不建议再使用video.on"+t+"，请使用onContent"+t),this["onContent"+t].apply(this,arguments)}})}return n(o,[{key:"createFlow",value:function(){}},{key:"start",value:function(){return this.started.resolve(),this}},{key:"stop",value:function(){return this.started.reject(),this.flow&&this.flow.stop(),this.off(),this}}]),o}(); 
 			}); 
		define("src/classes/State.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";function e(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}function t(){}var n=function(){function e(e,t){for(var n=0;n<t.length;n++){var r=t[n];r.enumerable=r.enumerable||!1,r.configurable=!0,"value"in r&&(r.writable=!0),Object.defineProperty(e,r.key,r)}}return function(t,n,r){return n&&e(t.prototype,n),r&&e(t,r),t}}(),r=require("../lib/message"),s=require("../../lib-inject").Promise;module.exports=function(){function a(n,s){e(this,a),this.destroyed=!1;var i=Object.keys(n);i.forEach(function(e){!(n[e].to instanceof Array)&&(n[e].to=[]),!("function"==typeof n[e].beforeLeave)&&(n[e].beforeLeave=t),!("function"==typeof n[e].beforeEnter)&&(n[e].beforeEnter=t),!("function"==typeof n[e].afterLeave)&&(n[e].afterLeave=t),!("function"==typeof n[e].afterEnter)&&(n[e].afterEnter=t)}),this.message=new r,this.states=n,this._state=i[0],this._laststate="",Object.defineProperties(this,{state:{get:function(){return this._state}},lastState:{get:function(){return this._laststate}}})}return n(a,null,[{key:"create",value:function(e,t){return new a(e,t)}}]),n(a,[{key:"setState",value:function(e,t){var n=(t=t||{}).force||!1,r=t.silent||!1,s=this.states;if(n||~s[this._state].to.indexOf(e)){var a=this._state;if(r)this._laststate=this._state,this._state=e;else{var i=!1;if(n||(i=!1===s[a].beforeLeave(e),i=!1===s[e].beforeEnter(a)||!0===i),i)return;this._laststate=this._state,this._state=e,this.message.emit("change",e,a),s[a].afterLeave(e),s[e].afterEnter(a)}return 0==s[e].to.length&&(this.message.emit("end",e),this.message.off()),this}}},{key:"getStatePromise",value:function(e){var t=this;if("function"!=typeof e){var n=e;e=function(e){return e==n}}return new s(function(n,r){var s=t.message.on("change",function(t){e(t)&&(s(),n())});t.message.on("end",function(e){s(),r(new Error("state ended:"+e))},!0)})}},{key:"onChange",value:function(e){return this.message.on("change",e),this}}]),a}(); 
 			}); 
		define("src/controller-live/flow-getinfo/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";var e=require("../../util/platform-config").APP_PLATFORM,i=require("../../../lib-inject").request,r=require("../../module/cache"),t=require("../../lib/algorithm/qvsec"),o=require("../../lib/algorithm/fillTimeStamp"),u=r.get("tvp_guid");u||(u=Math.random().toString(16).substring(2),r.set("tvp_guid",u)),module.exports=function(r,m,l,n){var q=o(),s=t["v4138"==l?"$xxzb":"$xxzbf"](e[l],r,1,1,q),d="";return s&&(d="encver="+("v4138"==l?"201":"301")+"&_qv_rmtv2="+s),i("https://info.zb.video.qq.com/?host=qq.com&cmd=2&qq=0&guid="+u+"&appVer=7&stream=2&ip=&system=1&sdtfrom="+e[l]+"&livepid="+m+"&cnlid="+r+"&_rnd="+q+"&"+d,{needlogin:!0})}; 
 			}); 
		define("src/controller-live/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";function t(t,e){if(!(t instanceof e))throw new TypeError("Cannot call a class as a function")}function e(t,e){if(!t)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return!e||"object"!=typeof e&&"function"!=typeof e?t:e}function n(t,e){if("function"!=typeof e&&null!==e)throw new TypeError("Super expression must either be null or a function, not "+typeof e);t.prototype=Object.create(e&&e.prototype,{constructor:{value:t,enumerable:!1,writable:!0,configurable:!0}}),e&&(Object.setPrototypeOf?Object.setPrototypeOf(t,e):t.__proto__=e)}var r=function(){function t(t,e){for(var n=0;n<e.length;n++){var r=e[n];r.enumerable=r.enumerable||!1,r.configurable=!0,"value"in r&&(r.writable=!0),Object.defineProperty(t,r.key,r)}}return function(e,n,r){return n&&t(e.prototype,n),r&&t(e,r),e}}(),o=function t(e,n,r){null===e&&(e=Function.prototype);var o=Object.getOwnPropertyDescriptor(e,n);if(void 0===o){var i=Object.getPrototypeOf(e);return null===i?void 0:t(i,n,r)}if("value"in o)return o.value;var u=o.get;if(void 0!==u)return u.call(r)},i=require("./flow-getinfo/index"),u=require("../classes/Controller"),a=require("../classes/Content"),l=function(l){function c(){return t(this,c),e(this,(c.__proto__||Object.getPrototypeOf(c)).apply(this,arguments))}return n(c,u),r(c,[{key:"createFlow",value:function(t,e){var n=this,r=t.sid,o=t.from,u=t.pid;t.defn,t.noad;"v4138"!=o&&"";var l=null,c=i(r,u,o).then(function(t){l=new a({url:t.data.playurl}),n.emit("contentchange",{currentContent:l})});return["End","Play","Pause","Timeupdate","Error","Skip"].forEach(function(t){n.on("content"+t.toLowerCase(),function(e){for(var n=arguments.length,r=Array(n>1?n-1:0),o=1;o<n;o++)r[o-1]=arguments[o];l&&l["onContent"+t].apply(l,r)})}),c}},{key:"stop",value:function(){o(c.prototype.__proto__||Object.getPrototypeOf(c.prototype),"stop",this).call(this),this.playflow&&this.playflow.stop()}}]),c}();module.exports=function(t,e){return new l(t,e)}; 
 			}); 
		define("src/controller-video/flow-getinfo/data/ad.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";function r(r){u(r,{header:{Cookie:"appuser="+d+"; Lturn="+a}}).then(function(r){console.log("上报成功"),console.log(r)},function(e){console.log("上报失败"),console.log(e),r=r+"&appuesr="+d,y.emit("report",{reportUrl:r}),console.log("用message抛出上报事件")})}function e(){a=h.get("Lturn"),console.log("Lturn:"+a),a?(a+=1,console.log("Lturn+1:"+a)):(a=Math.floor(1e3*Math.random()),console.log("create Lturn:"+a)),a>999&&(a=0),h.set("Lturn",a,72e5)}function t(r){var e=[];return r.item.forEach(function(r,t){e.push(r)}),e}function o(r){console.log("开始检查trueview贴片状态");for(var e=r.length,t=[],o=0,l=0;l<e;l++)r[l].trueviewTurn=!1,1==r[l].order_id||"FT"==r[l].type?t[l]=0:(i(r[l])&&(r[l].trueviewTurn=!0),t[l]=1,o+=1);n=1==o,console.log("trueviewCheckArr内容是："+t+",trueviewCount值是："+o)}function i(r){if(console.log("开始检查trueview开关"),r.params&&void 0!=r.params&&""!=r.params){var e=r.params;if(-1!=e.indexOf("richdata=")){var t=e.substr(e.indexOf("richdata=")+9);-1!=t.indexOf("&")&&(t=t.substr(0,t.indexOf("&"))),t=decodeURIComponent(t.replace(/\+/g," ")),console.log("转换出来的richdata参数是："+t);try{var o=JSON.parse(t);if(console.log("转换成json后的对象是："+o),o.plugins&&void 0!=o.plugins&&o.plugins.trueview&&void 0!=o.plugins.trueview&&"Y"==o.plugins.trueview)return console.log("trueview开关是打开的Y！"),!0}catch(r){console.log("richdata解析出错！")}}}return!1}function l(r){O=0;for(var e=0;e<r.length;e++)1!=r[e].order_id&&(O+=r[e].duration/1e3);console.log("广告总时长为："+O)}var n,p,a,d,s,u=require("../../../../lib-inject").request,c=require("../../../lib/message"),h=require("../../../module/cache"),g=require("./adReport"),v=require("./md5"),m="",U=0,f="",D=0,w=-1,L=1,T=-1,O=0,S="",K="",y=new c;(module.exports=function(i){console.log("ad video onLoad"),console.log(i),console.log("当前rfid:"+S),i.vid&&(m=i.vid),i.live&&(U=i.live),i.chid&&(D=i.chid),i.coverid&&(f=i.coverid),i.pu&&(w=i.pu),i.openid&&(K=i.openid),console.log("openid:"+K),d=String(v(K).substr(0,16)).toUpperCase(),console.log("appuesr:"+d),e();var c={};return p=(new Date).getTime(),u("https://livew.l.qq.com/livemsg?ty=web&ad_type=WL&pf=H5&lt=wx&pt=0&live="+U+"&pu="+w+"&rfid="+S+"&openid="+K+"&v=TencentPlayerV3.2.19.358&plugin=1.0.0&speed=0&adaptor=2&musictxt=&chid="+D+"&st=0&resp_type=json&_t=1478361546359&rfid=&vid="+m+"&vptag=&url=&refer=&pid=&mbid=&oid=&guid=&coverid="+f,{needlogin:!0,header:{Cookie:"appuser="+d+"; Lturn="+a}}).then(function(r){s=r,r.data.adLoc&&r.data.adLoc.tpid&&(L=r.data.adLoc.tpid),c={t:"0",url:"",vid:m,coverid:f,pf:"H5",vptag:"",pid:"",chid:D,tpid:L};var e=(new Date).getTime()-p;console.log("livew请求完成，进行dp3上报,时间为:"+e),g.reportDp3(2,"WL",e,1,100,0,K,c),p=(new Date).getTime();var i=t(r.data.adList);return console.log("最终adList:"+i),o(i),l(i),i},function(r){console.log("livew error，再试一次");var e=(new Date).getTime()-p;return console.log("livew请求失败，进行dp3上报,时间为:"+e),g.reportDp3(2,"WL",e,1,202,0,K,c),p=(new Date).getTime(),u("https://livew.l.qq.com/livemsg?ty=web&ad_type=WL&pf=H5&lt=wx&pt=0&live="+U+"&pu="+w+"&rfid="+S+"&v=TencentPlayerV3.2.19.358&plugin=1.0.0&speed=0&adaptor=2&musictxt=&chid="+D+"&openid="+K+"&st=0&resp_type=json&_t=1478361546359&rfid=&vid="+m+"&vptag=&url=&refer=&pid=&mbid=&oid=&guid=&coverid="+f,{needlogin:!0,header:{Cookie:"appuser="+d+"; Lturn="+a}}).then(function(r){s=r,r.data.adLoc&&r.data.adLoc.tpid&&(L=r.data.adLoc.tpid),c={t:"0",url:"",vid:m,coverid:f,pf:"H5",vptag:"",pid:"",chid:D,tpid:L};var e=(new Date).getTime()-p;console.log("livew重试请求完成，进行dp3上报,时间为:"+e),g.reportDp3(2,"WL",e,1,100,0,K,c),p=(new Date).getTime();var i=t(r.data.adList);return console.log("最终adList:"+i),o(i),l(i),i},function(r){var e=(new Date).getTime()-p;return console.log("livew error，订单获取失败，返回空数组，进行dp3上报,时间为:"+e),g.reportDp3(2,"WL",e,1,202,0,K,c),p=(new Date).getTime(),[]})}).then(function(e){return e=e.map(function(e,t){return function(){var t=[];if(e.reportUrlOther.reportitem)for(i=0;i<e.reportUrlOther.reportitem.length;i++)t[i]={url:e.reportUrlOther.reportitem[i].url,time:e.reportUrlOther.reportitem[i].reporttime,isReported:!1};var o=[];if(e.reportUrlSDK.reportitem)for(var i=0;i<e.reportUrlSDK.reportitem.length;i++)o[i]={url:e.reportUrlSDK.reportitem[i].url,time:e.reportUrlSDK.reportitem[i].reporttime,isReported:!1};return console.log("当前广告的trueview开关是否打开："+e.trueviewTurn),console.log("当前广告是否符合trueview条件："+n),n?(console.log("allAdDuration:"+O),T=O<=5?0:5):T=-1,console.log("skipable:"+T),{oid:e.order_id,url:e.image[0].url,reportUrl:{url:e.reportUrl,time:e.ReportTime,isReported:!1},reportUrlOther:t,reportUrlSDK:o,skipable:T,duration:e.duration/1e3,allDuration:O,onSkip:function(){console.log("当前广告被跳过了，上报智慧点10237"),g.reportWisdomPoint(10237,e.order_id,e.order_id,"");var r=(new Date).getTime()-p;console.log("当前广告被跳过，进行dp3上报,时间为:"+r),g.reportDp3(4,"WL",r,1,"",0,K,c),p=(new Date).getTime()},onTimeupdate:function(r){},onEnd:function(){var r=(new Date).getTime()-p;console.log("当前广告播放结束，进行dp3上报,时间为:"+r),g.reportDp3(5,"WL",r,1,"",0,K,c),p=(new Date).getTime(),s.data.adLoc&&s.data.adLoc.rfid&&(S=s.data.adLoc.rfid,console.log("rfid赋值成功："+S))},onStart:function(){console.log("当前广告开始播放"+e),console.log("当前广告的oid是："+this.oid);var t=(new Date).getTime()-p;if(console.log("素材加载完成，开始播放，进行dp3上报,时间为:"+t),g.reportDp3(3,"WL",t,1,"",0,K,c),p=(new Date).getTime(),this.reportUrl.url=g.updateUrlParam(this.reportUrl.url,c),this.reportUrl.time>=0&&!this.reportUrl.isReported){this.reportUrl.isReported=!0;try{r(this.reportUrl.url)}catch(r){}}for(o=0;o<this.reportUrlOther.length;o++)if(this.reportUrlOther[o].url=g.updateUrlParam(this.reportUrlOther[o].url,c),this.reportUrlOther[o].time>=0&&!this.reportUrlOther[o].isReported){this.reportUrlOther[o].isReported=!0;try{g.pingUrl(this.reportUrlOther[o].url)}catch(r){}}for(var o=0;o<this.reportUrlSDK.length;o++)if(this.reportUrlSDK[o].url=g.updateUrlParam(this.reportUrlSDK[o].url,c),this.reportUrlSDK[o].time>=0&&!this.reportUrlSDK[o].isReported){this.reportUrlSDK[o].isReported=!0;try{g.pingUrl(this.reportUrlSDK[o].url)}catch(r){}}},onError:function(){var r=(new Date).getTime()-p;console.log("当前广告播放出错，进行dp3上报,时间为:"+r),g.reportDp3(4,"WL",r,1,"",0,K,c),p=(new Date).getTime()},onReportEmpty:function(){console.log("我是空单上报，当前广告的上报地址是："+this.reportUrl.url),this.reportUrl.url=g.updateUrlParam(this.reportUrl.url,c);try{r(this.reportUrl.url)}catch(r){}for(e=0;e<this.reportUrlOther.length;e++)if(this.reportUrlOther[e].url=g.updateUrlParam(this.reportUrlOther[e].url,c),this.reportUrlOther[e].time>=0&&!this.reportUrlOther[e].isReported){this.reportUrlOther[e].isReported=!0;try{g.pingUrl(this.reportUrlOther[e].url)}catch(r){}}for(var e=0;e<this.reportUrlSDK.length;e++)if(this.reportUrlSDK[e].url=g.updateUrlParam(this.reportUrlSDK[e].url,c),this.reportUrlSDK[e].time>=0&&!this.reportUrlSDK[e].isReported){this.reportUrlSDK[e].isReported=!0;try{g.pingUrl(this.reportUrlSDK[e].url)}catch(r){}}}}}}),{adList:e}}).catch(function(r){return{}})}).reporter=g.reporter; 
 			}); 
		define("src/controller-video/flow-getinfo/data/adReport.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";function r(r){var e=r.indexOf("?"),t=new Object,o=r;if(e>=0)for(var i,n=(o=o.substr(e+1)).split("&"),l=0;l<n.length;l++)(i=n[l].split("=")).length>1?t[i[0]]=i[1]:t[i[0]]="null";return t}var e=require("../../../lib/message"),t=(require("../../../module/cache"),new e);(module.exports={updateUrlParam:function(e,t){try{var o=r(e),i=e,n=!0;if(-1!=e.indexOf("?")){i=e.substring(0,e.indexOf("?"));var l;for(l in t)o[l]=t[l];for(l in o)n?(n=!1,i+="?"+l+"="+o[l]):i+="&"+l+"="+o[l]}}catch(r){i=""}return i},reportDp3:function(r,e,t,o,i,n,l,s){console.log("开始dp3上报");var c="https://dp3.qq.com/stdlog/?bid=weixin&step="+r+"&merged="+o+"&errorcode="+i+"&trycount="+n+"&openid="+l;c=this.updateUrlParam(c,s);try{this.pingUrl(c)}catch(r){console.log("dp3上报失败")}},reportWisdomPoint:function(r,e,t,o){console.log("开始智慧点上报");var i="https://t.l.qq.com?t=s&actid="+r;i+="&oid="+e+"&mid="+t+"&locid="+o;try{this.pingUrl(i)}catch(r){}},pingUrl:function(r,e,o,i){console.log("ping上报地址："+r);var n=(new Date).getTime();r=this.updateUrlParam(r,{reportTime:n}),t.emit("report",{reportUrl:r}),console.log("用message抛出上报事件")}}).reporter=t; 
 			}); 
		define("src/controller-video/flow-getinfo/data/getinfo-status.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";var e={};e[10001]=e[50]=e[68]=e[71]=e[73]=e[74]=e[76]=e[77]=e[445]=e[444]="啊哦，没能找到你要的节目信息~",e[51]=e[52]=e[64]=e[61]=e[62]=e[63]=e[65]=e[66]=e[69]=e[81]=e[82]=e[84]=e[86]=e[94]="啊哦，本来在这儿的视频不见了~",e[80]=e[83]="啊哦，版权原因，该视频暂时无法播放~",module.exports=e; 
 			}); 
		define("src/controller-video/flow-getinfo/data/getinfo.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";function e(e,c,p){t=c,p=p||"auto";var a=o(),s=i["v4138"==c?"$xx":"$xxf"](f[c],e,t,1,a),m="";s&&(m="encver="+("v4138"==c?2:300)+"&_qv_rmtv2="+s),console.log("getinfo waiting");return new l(function(e,t){e()}).then(function(){return console.log("request start"),n("https://h5vv.video.qq.com/getinfo?"+m+"&defn="+p+"&platform="+f[c]+"&otype=json&sdtfrom="+c+"&_rnd="+a+"&appVer=7&"+(u?"dtype=3&":"")+"vid="+e+"&newnettype=0",{needlogin:!0})}).catch(function(){return n("https://bkvv.video.qq.com/getinfo?"+m+"&defn="+p+"&platform="+f[c]+"&otype=json&sdtfrom="+c+"&_rnd="+a+"&appVer=7&"+(u?"dtype=3&":"")+"vid="+e+"&newnettype=0",{needlogin:!0})}).catch(function(){var e=new Error(r[444]);throw e.em=444,e.code="G.444",e}).then(function(e){return e=e.data,console.log("getinfo result:",e),e})}var t,r=require("./getinfo-status"),n=require("../../../../lib-inject").request,i=require("../../../lib/algorithm/qvsec"),o=require("../../../lib/algorithm/fillTimeStamp"),l=require("../../../../lib-inject").Promise,u="devtools"!=wx.getSystemInfoSync().platform,f=require("../../../util/platform-config").APP_PLATFORM;module.exports=function(){return e.apply(this,arguments).then(function(e){if(e.em){var t=new Error(r[e.em]);throw t.em=e.em,t.code="G."+e.em,t}return e}).then(function(e){var r=e.vl.vi[0],n={duration:+r.td,dltype:e.dltype,fmid:e.fl.fi.filter(function(e){return+e.sl})[0].id,filesize:e.fl.fi.filter(function(e){return+e.sl})[0].fs,preview:e.preview,charge:r.ch,raw:e};return r.ch<1&&(n.preview=e.preview,n.charged=r.ch),3==e.dltype?(n.url=r.ul.ui.map(function(e){return e.hls.pt?e.url+e.hls.pt+"?platform="+f[t]+"&sdtfrom="+t:""}),n.url=n.url.filter(function(e){return e})):n.url=r.ul.ui.map(function(e){return e.url+r.fn+"?vkey="+r.fvkey+"&br="+r.br+"&fmt=auto&level="+r.level+"&platform="+f[t]+"&sdtfrom="+t}),n})}; 
 			}); 
		define("src/controller-video/flow-getinfo/data/md5.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";var n="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(n){return typeof n}:function(n){return n&&"function"==typeof Symbol&&n.constructor===Symbol&&n!==Symbol.prototype?"symbol":typeof n};!function(t){function r(n,t){var r=(65535&n)+(65535&t);return(n>>16)+(t>>16)+(r>>16)<<16|65535&r}function o(n,t){return n<<t|n>>>32-t}function e(n,t,e,u,f,c){return r(o(r(r(t,n),r(u,c)),f),e)}function u(n,t,r,o,u,f,c){return e(t&r|~t&o,n,t,u,f,c)}function f(n,t,r,o,u,f,c){return e(t&o|r&~o,n,t,u,f,c)}function c(n,t,r,o,u,f,c){return e(t^r^o,n,t,u,f,c)}function i(n,t,r,o,u,f,c){return e(r^(t|~o),n,t,u,f,c)}function d(n,t){n[t>>5]|=128<<t%32,n[14+(t+64>>>9<<4)]=t;var o,e,d,l,a,h=1732584193,m=-271733879,y=-1732584194,p=271733878;for(o=0;o<n.length;o+=16)e=h,d=m,l=y,a=p,m=i(m=i(m=i(m=i(m=c(m=c(m=c(m=c(m=f(m=f(m=f(m=f(m=u(m=u(m=u(m=u(m,y=u(y,p=u(p,h=u(h,m,y,p,n[o],7,-680876936),m,y,n[o+1],12,-389564586),h,m,n[o+2],17,606105819),p,h,n[o+3],22,-1044525330),y=u(y,p=u(p,h=u(h,m,y,p,n[o+4],7,-176418897),m,y,n[o+5],12,1200080426),h,m,n[o+6],17,-1473231341),p,h,n[o+7],22,-45705983),y=u(y,p=u(p,h=u(h,m,y,p,n[o+8],7,1770035416),m,y,n[o+9],12,-1958414417),h,m,n[o+10],17,-42063),p,h,n[o+11],22,-1990404162),y=u(y,p=u(p,h=u(h,m,y,p,n[o+12],7,1804603682),m,y,n[o+13],12,-40341101),h,m,n[o+14],17,-1502002290),p,h,n[o+15],22,1236535329),y=f(y,p=f(p,h=f(h,m,y,p,n[o+1],5,-165796510),m,y,n[o+6],9,-1069501632),h,m,n[o+11],14,643717713),p,h,n[o],20,-373897302),y=f(y,p=f(p,h=f(h,m,y,p,n[o+5],5,-701558691),m,y,n[o+10],9,38016083),h,m,n[o+15],14,-660478335),p,h,n[o+4],20,-405537848),y=f(y,p=f(p,h=f(h,m,y,p,n[o+9],5,568446438),m,y,n[o+14],9,-1019803690),h,m,n[o+3],14,-187363961),p,h,n[o+8],20,1163531501),y=f(y,p=f(p,h=f(h,m,y,p,n[o+13],5,-1444681467),m,y,n[o+2],9,-51403784),h,m,n[o+7],14,1735328473),p,h,n[o+12],20,-1926607734),y=c(y,p=c(p,h=c(h,m,y,p,n[o+5],4,-378558),m,y,n[o+8],11,-2022574463),h,m,n[o+11],16,1839030562),p,h,n[o+14],23,-35309556),y=c(y,p=c(p,h=c(h,m,y,p,n[o+1],4,-1530992060),m,y,n[o+4],11,1272893353),h,m,n[o+7],16,-155497632),p,h,n[o+10],23,-1094730640),y=c(y,p=c(p,h=c(h,m,y,p,n[o+13],4,681279174),m,y,n[o],11,-358537222),h,m,n[o+3],16,-722521979),p,h,n[o+6],23,76029189),y=c(y,p=c(p,h=c(h,m,y,p,n[o+9],4,-640364487),m,y,n[o+12],11,-421815835),h,m,n[o+15],16,530742520),p,h,n[o+2],23,-995338651),y=i(y,p=i(p,h=i(h,m,y,p,n[o],6,-198630844),m,y,n[o+7],10,1126891415),h,m,n[o+14],15,-1416354905),p,h,n[o+5],21,-57434055),y=i(y,p=i(p,h=i(h,m,y,p,n[o+12],6,1700485571),m,y,n[o+3],10,-1894986606),h,m,n[o+10],15,-1051523),p,h,n[o+1],21,-2054922799),y=i(y,p=i(p,h=i(h,m,y,p,n[o+8],6,1873313359),m,y,n[o+15],10,-30611744),h,m,n[o+6],15,-1560198380),p,h,n[o+13],21,1309151649),y=i(y,p=i(p,h=i(h,m,y,p,n[o+4],6,-145523070),m,y,n[o+11],10,-1120210379),h,m,n[o+2],15,718787259),p,h,n[o+9],21,-343485551),h=r(h,e),m=r(m,d),y=r(y,l),p=r(p,a);return[h,m,y,p]}function l(n){var t,r="",o=32*n.length;for(t=0;t<o;t+=8)r+=String.fromCharCode(n[t>>5]>>>t%32&255);return r}function a(n){var t,r=[];for(r[(n.length>>2)-1]=void 0,t=0;t<r.length;t+=1)r[t]=0;var o=8*n.length;for(t=0;t<o;t+=8)r[t>>5]|=(255&n.charCodeAt(t/8))<<t%32;return r}function h(n){return l(d(a(n),8*n.length))}function m(n,t){var r,o,e=a(n),u=[],f=[];for(u[15]=f[15]=void 0,e.length>16&&(e=d(e,8*n.length)),r=0;r<16;r+=1)u[r]=909522486^e[r],f[r]=1549556828^e[r];return o=d(u.concat(a(t)),512+8*t.length),l(d(f.concat(o),640))}function y(n){var t,r,o="";for(r=0;r<n.length;r+=1)t=n.charCodeAt(r),o+="0123456789abcdef".charAt(t>>>4&15)+"0123456789abcdef".charAt(15&t);return o}function p(n){return unescape(encodeURIComponent(n))}function g(n){return h(p(n))}function v(n){return y(g(n))}function b(n,t){return m(p(n),p(t))}function s(n,t){return y(b(n,t))}function S(n,t,r){return t?r?b(t,n):s(t,n):r?g(n):v(n)}"function"==typeof define&&define.amd?define(function(){return S}):"object"===("undefined"==typeof module?"undefined":n(module))&&module.exports?module.exports=S:t.md5=S}(void 0); 
 			}); 
		define("src/controller-video/flow-getinfo/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";var e=require("../../../lib-inject").Promise,i=require("./data/ad"),r=require("./data/getinfo");module.exports=function(d){var n=(d=d||{}).vid,o=d.cid,t=d.from,a=d.openid,u=d.defn,v=d.noad;return e.all([v?e.resolve({}):i({coverid:o,vid:n,live:0,chid:41,pu:1,openid:a||""}),r(n,t,u)]).then(function(e){return{ad:e[0],videoinfo:e[1]}})}; 
 			}); 
		define("src/controller-video/flow-play/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";var n=require("../../../lib-inject").Promise,e=require("../../lib/message"),o=require("../../classes/Content");module.exports=function(t,i,r){var u={time:0,duration:0,skipable:!1},a={},c={},f=[],d=n.defer(),s=d.promise,l=new e,p=null,m=function(n){console.log("contentchange:",n,c);var e={currentContent:n=n||p,preloadContents:f.filter(function(e){return!c[e.id]&&e!=n}),getinforaw:h.raw};n&&n.isad&&(e.progress=u),p=n,r(e)},v=t.ad,h=t.videoinfo,g=!1;(v.adList||[]).forEach(function(e){var t=e(),i=new o({url:t.url,duration:t.duration,isad:!0}),r=new n(function(n){g||(i.on("end",function(){n(),t.onEnd()},!0),i.on("error",function(){n(),t.onError()},!0),i.on("timeout",function(){n(),t.onError()},!0),i.on("skip",function(){g=!0,n(),t.onSkip()},!0),i.on("start",function(){l.emit("adplaying",i),t.onStart()},!0),i.on("timeupdate",function(n){t.onTimeupdate(n)},!0),l.on("_terminate",function(){n()}))}).then(function(n){return c[i.id]=!0,n});a[i.id]=i,f.push(i),u.duration+=t.duration,u.skipable=t.skipable,s=s.then(function(){return console.info("playflow: ad."+t.url),"1"==t.oid?(console.log("这是一个空单，往下走"),void t.onReportEmpty()):(m(i),r.then(function(n){u.time+=i.duration}))})});var w=new o({url:h.url,duration:h.duration,filesize:h.filesize,isad:!1,preview:h.preview,charged:h.charged});a[w.id]=w,f.unshift(w);var y=new n(function(n,e){function o(o){!t&&o.on("start",function(){l.emit("videoplaying",o),t=!0},!0),o.on("play",function(){l.emit("videoplay",o)}),o.on("pause",function(){l.emit("videopause",o)}),o.on("timeupdate",function(n){l.emit("videotimeupdate",n,h.duration)}),o.on("error",function(n){var o=new Error(n?n.detail&&n.detail.errMsg||n.message:"播放出错");o.code="P.0",e(o)},!0),o.on("end",n,!0),o.on("timeout",function(n){l.emit("videotimeout",n)})}var t=!1;o(w),l.on("_terminate",function(){n()}),l.on("_changevideocontent",function(n){w.off(),c[w.id]=!0,f.every(function(e,o){return e!=w||(f.splice(o,1,n),!1)}),o(n),m(p==w?n:null),a[n.id]=n,w=n})}).then(function(n){return c[w.id]=!0,n});s=s.then(function(){return w.off("change"),w.on("change",function(){m(w)}),l.on("_changevideocontent",function(n){w.off("change"),n.on("change",function(){m(n)})}),m(w),y}).then(function(){l.emit("end")}).catch(function(n){throw l.emit("error",n),n}),m(null);var E={progress:s,stop:function(){return l.emit("_terminate"),l.emit("terminate"),Object.keys(a).forEach(function(n){a[n].off()}),l.off(),this},start:function(){return d.resolve(),s},on:function(){return l.on.apply(l,arguments)},switchVideo:function(n){var e=n.videoinfo;h=e;var t=new o({url:e.url,duration:e.duration,filesize:e.filesize,isad:!1,preview:e.preview,charged:e.charged});l.emit("_changevideocontent",t)}};return["End","Play","Pause","Timeupdate","Error","Skip"].forEach(function(n){i.on("content"+n.toLowerCase(),function(e){for(var o=e&&a[e]?a[e]:p,t=arguments.length,i=Array(t>1?t-1:0),r=1;r<t;r++)i[r-1]=arguments[r];o&&o["onContent"+n].apply(o,i)})}),E}; 
 			}); 
		define("src/controller-video/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";function e(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}function t(e,t){if(!e)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return!t||"object"!=typeof t&&"function"!=typeof t?e:t}function n(e,t){if("function"!=typeof t&&null!==t)throw new TypeError("Super expression must either be null or a function, not "+typeof t);e.prototype=Object.create(t&&t.prototype,{constructor:{value:e,enumerable:!1,writable:!0,configurable:!0}}),t&&(Object.setPrototypeOf?Object.setPrototypeOf(e,t):e.__proto__=t)}var r=function(){function e(e,t){for(var n=0;n<t.length;n++){var r=t[n];r.enumerable=r.enumerable||!1,r.configurable=!0,"value"in r&&(r.writable=!0),Object.defineProperty(e,r.key,r)}}return function(t,n,r){return n&&e(t.prototype,n),r&&e(t,r),t}}(),o=function e(t,n,r){null===t&&(t=Function.prototype);var o=Object.getOwnPropertyDescriptor(t,n);if(void 0===o){var i=Object.getPrototypeOf(t);return null===i?void 0:e(i,n,r)}if("value"in o)return o.value;var a=o.get;if(void 0!==a)return a.call(r)},i=require("../../lib-inject").Promise,a=require("./flow-getinfo/index"),u=require("./flow-play/index"),f=require("./reporter"),c=require("../module/reporter/index"),l=require("../classes/Controller");require("./flow-getinfo/data/ad").reporter.on("report",function(e){c.any(e)});var p=function(c){function p(){return e(this,p),t(this,(p.__proto__||Object.getPrototypeOf(p)).apply(this,arguments))}return n(p,l),r(p,[{key:"createFlow",value:function(e,t){var n=this;e=e||{},t=t||{};var r=e,o=r.vid,c=r.from,l=r.cid,p=r.defn,s=r.noad,d=t.getReportParam,y=new i(function(e){d?d(function(t,n){e(n&&n.hc_openid||"")}):e("")}),h=f({cid:l,vid:o},{getReportParam:d}),v=this.model,w=y.then(function(e){return a({vid:o,from:c,cid:l,openid:e,defn:p,noad:s})}).then(function(e){v.state="ready";var t=n.playflow=u(e,n,function(e){v.currentContent=e.currentContent,n.emit("contentchange",e)});return h.setPlayFlow(t),h.setVideoInfo(e.videoinfo),t.on("videotimeupdate",function(){for(var e=arguments.length,t=Array(e),r=0;r<e;r++)t[r]=arguments[r];n.emit.apply(n,["videotimeupdate"].concat(t))}),n.started.promise}).then(function(){return v.state="playing",n.playflow.start()}).then(function(e){v.state="ended"}).catch(function(e){throw v.state="error",n.playflow&&n.playflow.stop(),h.error(e),e});return this.switchDefn=function(e){return y.then(function(t){return a({vid:o,from:c,cid:l,openid:t,defn:e,noad:!0})}).then(function(e){n.playflow.switchVideo(e)})},w}},{key:"stop",value:function(){this.model.state="ended",o(p.prototype.__proto__||Object.getPrototypeOf(p.prototype),"stop",this).call(this),this.playflow&&this.playflow.stop()}}]),p}();module.exports=function(e,t){return new p(e,t)}; 
 			}); 
		define("src/controller-video/report-play.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";var e="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(e){return typeof e}:function(e){return e&&"function"==typeof Symbol&&e.constructor===Symbol&&e!==Symbol.prototype?"symbol":typeof e},o=require("./../module/reporter/report-queue"),t=wx.getSystemInfoSync();module.exports=function(n){var r=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{},p=arguments[2],i=arguments[3];p(function(p,l){p&&(l={}),delete l.val1,delete l.val2,delete l.val3,"object"==e(l[n])&&(["val1","val2","val3"].forEach(function(e){l[e]=l[n][e]}),delete l[n]);var a=[],c=a.pop(),u=a.pop(),f={},d={BossId:4327,Pwd:944465292,app_version:"1.1.1",platform:t.platform,client_model:t.model,wx_version:t.version,network:f&&f.networkType?f.networkType:"",step:n,page_url:c&&c.$name||"",page_query:c&&c.$query||"",page_ref:u&&u.$name||""};["hc_vuserid","hc_openid","hc_appid","ptag","iformat","duration","defn","tpay","adid","playtime","page_url","page_query","page_ref","cid","vid","isvip","val1","val2","val3","appname","nick","rmd","scene","additional"].forEach(function(e){e in r&&(d[e]=r[e]),e in l&&(d[e]=l[e]),void 0==d[e]&&(d[e]="")}),i&&"function"==typeof i?i(null,{reportUrl:"https://btrace.qq.com/kvcollect?"+Object.keys(d).map(function(e){return e in d?e+"="+encodeURIComponent(d[e]):""}).filter(function(e){return e}).join("&")}):o.push({reportUrl:"https://btrace.qq.com/kvcollect?"+Object.keys(d).map(function(e){return e in d?e+"="+encodeURIComponent(d[e]):""}).filter(function(e){return e}).join("&")})})}; 
 			}); 
		define("src/controller-video/reporter.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";function n(n){return{1:1,2:1,10001:4,10002:3,10003:2,10201:4,10202:3,10203:2,100001:2,320089:2,320091:3,320092:4,320093:5}[n]}function e(n){var e=!1,o=function(){e||(e=!0,n.done=e,n.apply(this,arguments))};return o.done=e,o}var o=require("./report-play"),t=require("../module/reporter/index"),r=[5,30];module.exports=function(a,i){function u(){return{iformat:d?d.dltype:0,duration:d?Math.floor(d.duration):"",defn:d?n(d.fmid):"",playtime:s+(c?Date.now()-c:0),vid:l||"",cid:f||""}}var c,l=a.vid,f=a.cid,v=i.getReportParam||function(n){return n({})},d=null,p=0,s=0,m=!1,w=!1,y=e(function(n){var e=u();e.val1=0,e.val2=0,e.val3=n,o(7,e,v)}),D=e(function(n){var e=u();e.val1=p?Date.now()-p:0,e.val2=m?0:1,e.val3=n,o(6,e,v)}),h=e(function(n,e){var t=u();t.val1=p?Date.now()-p:0,t.val2={error:3,complete:1,incomplete:w?2:0}[n],void 0==t.val2&&(t.val2=2),t.val3=e,o(5,t,v)}),g=null,C=e(function(n,e){t.reportCache.del("step30");var r=u();r.val1=n,r.val2=e,o(30,r,v)}),q=function(n,e){if(1e4==n){g=setTimeout(function(){C(n)},11e3);var r=u();r.val1=n,r.val2=e,o(30,r,v,function(n,e){t.reportCache.set("step30",e)})}else clearTimeout(g),C(n)};return o(3,u(),v),t.on("_save",function(){var n=u();n.val1=p?Date.now()-p:0,n.val2=w?2:0,o(5,n,v,function(n,e){t.reportCache.set("step5",e)})}),t.on("_restore",function(){r.forEach(function(n){t.reportCache.del("step"+n)})}),{setPlayFlow:e(function(n){n.on("adplaying",function(n){m=!0,y(n.url)}),n.on("videoplay",function(n){!p&&(p=Date.now()),c=Date.now()}),n.on("videoplaying",function(n){w=!0,D(n.url),q(p?Date.now()-p:0,0)}),n.on("videopause",function(){s+=Date.now()-c,c=0}),n.on("videotimeout",function(n){q(n,1)}),n.on("terminate",function(){h("incomplete")}),n.on("end",function(){h("complete")}),n.on("error",function(n){h("error","1 "+(n.code||"")+" "+n.message)})}),setVideoInfo:e(function(n){d=n}),error:function(n){h("error","2 "+(n.code||"")+" "+n.message)}}}; 
 			}); 
		define("src/lib/algorithm/fillTimeStamp.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";module.exports=function(r){r=r||10;var t=parseInt(+new Date)+"";if(t.length===r)return t;if(t.length>r)return t.substring(0,r);for(var e=r-t.length;e>0;)t="0"+t,e--;return t}; 
 			}); 
		define("src/lib/algorithm/qvsec.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";var r={};r.ha=function(r){function t(r,t){return((r>>1)+(t>>1)<<1)+(1&r)+(1&t)}for(var e=[],n=0;n<64;)e[n]=0|4294967296*Math.abs(Math.sin(++n));return function(r){for(var n,a,o,u,c=[],h=decodeURIComponent(encodeURI(r)),f=h.length,i=[n=1732584193,a=-271733879,~n,~a],d=0;d<=f;)c[d>>2]|=(h.charCodeAt(d)||128)<<d++%4*8;for(c[r=16*(f+8>>6)+14]=8*f,d=0;d<r;d+=16){for(f=i,u=0;u<64;)f=[o=f[3],t(n=f[1],(o=t(t(f[0],[n&(a=f[2])|~n&o,o&n|~o&a,n^a^o,a^(n|~o)][f=u>>4]),t(e[u],c[[u,5*u+1,3*u+5,7*u][f]%16+d])))<<(f=[7,12,17,22,5,9,14,20,4,11,16,23,6,10,15,21][4*f+u++%4])|o>>>32-f),n,a];for(u=4;u;)i[--u]=t(i[u],f[u])}for(r="";u<32;)r+=(i[u>>3]>>4*(1^7&u++)&15).toString(16);return r}}(),r.stringToHex=function(r){for(var t="",e=new Array("0","1","2","3","4","5","6","7","8","9","a","b","c","d","e","f"),n=0;n<r.length;n++)t+=e[r.charCodeAt(n)>>4]+e[15&r.charCodeAt(n)];return t},r.hexToString=function(r){for(var t="",e="0x"==r.substr(0,2)?2:0;e<r.length;e+=2)t+=String.fromCharCode(parseInt(r.substr(e,2),16));return t},r._Seed="#$#@#*ad",r.tempcalc=function(r,t){for(var e="",n=0;n<r.length;n++)e+=String.fromCharCode(r.charCodeAt(n)^t.charCodeAt(n%4));return e},r.u1=function(r,t){for(var e="",n=t;n<r.length;n+=2)e+=r.charAt(n);return e},r._urlStr="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",r.urlenc=function(t,e,n){for(var a,o,u,c,h,f,i,d="",s=0;s<t.length;)a=t.charCodeAt(s++),o=t.charCodeAt(s++),u=t.charCodeAt(s++),15==s&&(d+="A",d+=e,d+=n),c=a>>2,h=(3&a)<<4|o>>4,f=(15&o)<<2|u>>6,i=63&u,isNaN(o)?f=i=64:isNaN(u)&&(i=64),d=d+r._urlStr.charAt(c)+r._urlStr.charAt(h)+r._urlStr.charAt(f)+r._urlStr.charAt(i);return d},r.$xx=function(t,e,n,a,o){var o=o||parseInt(+new Date/1e3);return r.ha(t+e+o+r._Seed+n+"heherand")},r.$xxzb=function(t,e,n,a,o){var o=o||parseInt(+new Date/1e3);return r.ha(e+"tmp123"+t+"#$$&c2*KA"+o)},r.$xxf=function(t,e,n,a,o){var o=o||parseInt(+new Date/1e3);return r.ha(t+"ques"+o+"*&%$(SD!L}"+e+n)},r.$xxzbf=function(t,e,n,a,o){var o=o||parseInt(+new Date/1e3);return r.ha(e+o+"*#016"+t+"zput")},module.exports=r; 
 			}); 
		define("src/lib/es6-promise.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";var t="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(t){return typeof t}:function(t){return t&&"function"==typeof Symbol&&t.constructor===Symbol&&t!==Symbol.prototype?"symbol":typeof t};!function(e,n){"object"===("undefined"==typeof exports?"undefined":t(exports))&&"undefined"!=typeof module?module.exports=n():"function"==typeof define&&define.amd?define(n):e.ES6Promise=n()}(void 0,function(){function e(e){return"function"==typeof e||"object"===(void 0===e?"undefined":t(e))&&null!==e}function n(t){return"function"==typeof t}function r(){return void 0!==D?function(){D(i)}:o()}function o(){var t=setTimeout;return function(){return t(i,1)}}function i(){for(var t=0;t<F;t+=2)(0,G[t])(G[t+1]),G[t]=void 0,G[t+1]=void 0;F=0}function s(t,e){var n=arguments,r=this,o=new this.constructor(c);void 0===o[I]&&x(o);var i=r._state;return i?function(){var t=n[i-1];L(function(){return j(i,o,t,r._result)})}():w(r,o,t,e),o}function u(e){var n=this;if(e&&"object"===(void 0===e?"undefined":t(e))&&e.constructor===n)return e;var r=new n(c);return _(r,e),r}function c(){}function f(){return new TypeError("You cannot resolve a promise with itself")}function a(){return new TypeError("A promises callback cannot return that same promise.")}function l(t){try{return t.then}catch(t){return V.error=t,V}}function h(t,e,n,r){try{t.call(e,n,r)}catch(t){return t}}function p(t,e,n){L(function(t){var r=!1,o=h(n,e,function(n){r||(r=!0,e!==n?_(t,n):m(t,n))},function(e){r||(r=!0,b(t,e))},"Settle: "+(t._label||" unknown promise"));!r&&o&&(r=!0,b(t,o))},t)}function d(t,e){e._state===Q?m(t,e._result):e._state===R?b(t,e._result):w(e,void 0,function(e){return _(t,e)},function(e){return b(t,e)})}function v(t,e,r){e.constructor===t.constructor&&r===s&&e.constructor.resolve===u?d(t,e):r===V?b(t,V.error):void 0===r?m(t,e):n(r)?p(t,e,r):m(t,e)}function _(t,n){t===n?b(t,f()):e(n)?v(t,n,l(n)):m(t,n)}function y(t){t._onerror&&t._onerror(t._result),g(t)}function m(t,e){t._state===J&&(t._result=e,t._state=Q,0!==t._subscribers.length&&L(g,t))}function b(t,e){t._state===J&&(t._state=R,t._result=e,L(y,t))}function w(t,e,n,r){var o=t._subscribers,i=o.length;t._onerror=null,o[i]=e,o[i+Q]=n,o[i+R]=r,0===i&&t._state&&L(g,t)}function g(t){var e=t._subscribers,n=t._state;if(0!==e.length){for(var r=void 0,o=void 0,i=t._result,s=0;s<e.length;s+=3)r=e[s],o=e[s+n],r?j(n,r,o,i):o(i);t._subscribers.length=0}}function A(){this.error=null}function S(t,e){try{return t(e)}catch(t){return X.error=t,X}}function j(t,e,r,o){var i=n(r),s=void 0,u=void 0,c=void 0,f=void 0;if(i){if((s=S(r,o))===X?(f=!0,u=s.error,s=null):c=!0,e===s)return void b(e,a())}else s=o,c=!0;e._state!==J||(i&&c?_(e,s):f?b(e,u):t===Q?m(e,s):t===R&&b(e,s))}function E(t,e){try{e(function(e){_(t,e)},function(e){b(t,e)})}catch(e){b(t,e)}}function T(){return Z++}function x(t){t[I]=Z++,t._state=void 0,t._result=void 0,t._subscribers=[]}function M(t,e){this._instanceConstructor=t,this.promise=new t(c),this.promise[I]||x(this.promise),q(e)?(this._input=e,this.length=e.length,this._remaining=e.length,this._result=new Array(this.length),0===this.length?m(this.promise,this._result):(this.length=this.length||0,this._enumerate(),0===this._remaining&&m(this.promise,this._result))):b(this.promise,P())}function P(){return new Error("Array Methods must be provided an Array")}function C(){throw new TypeError("You must pass a resolver function as the first argument to the promise constructor")}function O(){throw new TypeError("Failed to construct 'Promise': Please use the 'new' operator, this object constructor cannot be called as a function.")}function k(t){this[I]=T(),this._result=this._state=void 0,this._subscribers=[],c!==t&&("function"!=typeof t&&C(),this instanceof k?E(this,t):O())}var Y=void 0,q=Y=Array.isArray?Array.isArray:function(t){return"[object Array]"===Object.prototype.toString.call(t)},F=0,D=void 0,K=void 0,L=function(t,e){G[F]=t,G[F+1]=e,2===(F+=2)&&(K?K(i):H())},N="undefined"!=typeof window?window:void 0,U=N||{},W=U.MutationObserver||U.WebKitMutationObserver,z="undefined"==typeof self&&"undefined"!=typeof process&&"[object process]"==={}.toString.call(process),B="undefined"!=typeof Uint8ClampedArray&&"undefined"!=typeof importScripts&&"undefined"!=typeof MessageChannel,G=new Array(1e3),H=void 0;H=z?function(){return process.nextTick(i)}:W?function(){var t=0,e=new W(i),n=document.createTextNode("");return e.observe(n,{characterData:!0}),function(){n.data=t=++t%2}}():B?function(){var t=new MessageChannel;return t.port1.onmessage=i,function(){return t.port2.postMessage(0)}}():void 0===N&&"function"==typeof require?function(){try{var t=require("vertx");return D=t.runOnLoop||t.runOnContext,r()}catch(t){return o()}}():o();var I=Math.random().toString(36).substring(16),J=void 0,Q=1,R=2,V=new A,X=new A,Z=0;return M.prototype._enumerate=function(){for(var t=this.length,e=this._input,n=0;this._state===J&&n<t;n++)this._eachEntry(e[n],n)},M.prototype._eachEntry=function(t,e){var n=this._instanceConstructor,r=n.resolve;if(r===u){var o=l(t);if(o===s&&t._state!==J)this._settledAt(t._state,e,t._result);else if("function"!=typeof o)this._remaining--,this._result[e]=t;else if(n===k){var i=new n(c);v(i,t,o),this._willSettleAt(i,e)}else this._willSettleAt(new n(function(e){return e(t)}),e)}else this._willSettleAt(r(t),e)},M.prototype._settledAt=function(t,e,n){var r=this.promise;r._state===J&&(this._remaining--,t===R?b(r,n):this._result[e]=n),0===this._remaining&&m(r,this._result)},M.prototype._willSettleAt=function(t,e){var n=this;w(t,void 0,function(t){return n._settledAt(Q,e,t)},function(t){return n._settledAt(R,e,t)})},k.all=function(t){return new M(this,t).promise},k.race=function(t){var e=this;return new e(q(t)?function(n,r){for(var o=t.length,i=0;i<o;i++)e.resolve(t[i]).then(n,r)}:function(t,e){return e(new TypeError("You must pass an array to race."))})},k.resolve=u,k.reject=function(t){var e=new this(c);return b(e,t),e},k._setScheduler=function(t){K=t},k._setAsap=function(t){L=t},k._asap=L,k.prototype={constructor:k,then:s,catch:function(t){return this.then(null,t)}},k.polyfill=function(){var t=void 0;if("undefined"!=typeof global)t=global;else if("undefined"!=typeof self)t=self;else try{t=Function("return this")()}catch(t){throw new Error("polyfill failed because global object is unavailable in this environment")}var e=t.Promise;if(e){var n=null;try{n=Object.prototype.toString.call(e.resolve())}catch(t){}if("[object Promise]"===n&&!e.cast)return}t.Promise=k},k.Promise=k,k.defer=function(){var t={};return t.promise=new k(function(e,n){t.resolve=e,t.reject=n}),t},k}); 
 			}); 
		define("src/lib/message.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";function t(){this._evtObjs={},this._outdatedMsgs={}}function e(){}t.prototype.on=function(t,e,s){this._evtObjs[t]||(this._evtObjs[t]=[]),this._evtObjs[t].push({handler:e,once:s});var n=this;return function(){n.off(t,e)}},t.prototype.wait=function(t,s){return this._outdatedMsgs[t]?(s.apply(null,this._outdatedMsgs[t]),e):this.on(t,s,!0)},t.prototype.off=function(t,e){var s=this;return(t?[t]:Object.keys(this._evtObjs)).forEach(function(t){if(e){var n=[];(s._evtObjs[t]||[]).forEach(function(t){t.handler!==e&&n.push(t)}),s._evtObjs[t]=n}else s._evtObjs[t]=[]}),this},t.prototype.emit=function(t){var e=Array.prototype.slice.call(arguments,1);this._outdatedMsgs[t]=e,(this._evtObjs[t]||[]).forEach(function(t){if(!t.once||!t.called){t.called=!0;try{t.handler&&t.handler.apply(null,e)}catch(t){console.error(t.stack||t.message||t)}}})},t.prototype.emitAsync=function(){var t=arguments,e=this;setTimeout(function(){e.emit.apply(e,t)},0)},t.prototype.assign=function(t){var e=this;["on","off","wait","emit","emitAsync"].forEach(function(s){var n=e[s];t[s]=function(){return n.apply(e,arguments)}})},(new t).assign(t),module.exports=t; 
 			}); 
		define("src/lib/parse-body.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";module.exports=function(t){if("string"!=typeof t)return t;t&&(t=t.trim()),t&&/^(data|QZOutputJson)=/.test(t)&&(t=t.replace(/^(data|QZOutputJson)=/,"").replace(/;?$/,""));try{return JSON.parse(t)}catch(t){throw new Error("parse jsonp body failed")}}; 
 			}); 
		define("src/lib/request.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";var e=require("./parse-body"),t=require("./es6-promise"),s=module.exports={request:function(t){return t.success=function(t){return t=t||function(){},function(s){if(console.log("wx.request success"),s&&200==s.statusCode)try{s.data=e(s.data)}catch(e){}t(s)}}(t.success),console.log("wx.request",t.url),wx.request(t)},get:function(e,u){return u=u||{},new t(function(t,n){s.request({url:e,data:u.data||{},header:u.header||{},method:"GET",success:function(e){t(e)},fail:function(e){n(e)},needlogin:u.needlogin})})}}; 
 			}); 
		define("src/module/cache.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";module.exports={set:function(e,t,a){wx.setStorageSync("_cache_"+e,{expr:a||0,date:+new Date,data:t})},get:function(e){e="_cache_"+e;var t=wx.getStorageSync(e);return t?t.expr&&t.expr?new Date-(t.date+t.expr)<0?t.data:(wx.removeStorageSync(e),null):t.data:null},del:function(e){e="_cache_"+e,wx.removeStorageSync(e)}}; 
 			}); 
		define("src/module/log.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";var o="devtools"==wx.getSystemInfoSync().platform;module.exports=function(a){var n=[Math.floor(50*Math.random()+200),Math.floor(50*Math.random()+150),Math.floor(50*Math.random()+100)].sort(function(){return Math.random()-.5});return n="rgb("+n[0]+", "+n[1]+", "+n[2]+")",o?function(){var o=["%c【%s】%c "+a+" %c %s ","background: #ddd",new Date,"background: "+n,"background: #333;color: white"];console.log.apply(console,o.concat([].slice.call(arguments,0)))}:function(){var o=["【%s】 "+a+" %s ",new Date];console.log.apply(console,o.concat([].slice.call(arguments,0)))}}; 
 			}); 
		define("src/module/reporter/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";var e=new(require("../../lib/message")),r=require("./report-queue");r.onReport=function(e){o.emit("report",e)};var t=require("./report-cache"),o={};o.any=function(e){r.push(e)},o.saveState=function(){console.log("reporter.js","saveState"),o.emit("_save")},o.restoreState=function(){console.log("reporter.js","restoreState"),o.emit("_restore")},o.checkState=function(){console.log("reporter.js","checkState"),t.getAll().forEach(r.push),t.del()},o.reportCache=t,e.assign(o),module.exports=o; 
 			}); 
		define("src/module/reporter/report-cache.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";var t=require("../cache"),e=t.get("tvp_report")||{};exports.get=function(t){return e[t]},exports.set=function(r,n){e[r]=n,t.set("tvp_report",e)},exports.del=function(r){r?delete e[r]:e={},t.set("tvp_report",e)},exports.getAll=function(){return Object.keys(e).map(function(t){return e[t]})}; 
 			}); 
		define("src/module/reporter/report-queue.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";var e=require("../../../lib-inject").request;module.exports=function(t){function n(t){~t.reportUrl.indexOf("btrace.qq.com")?e(t.reportUrl).then(function(){r.release()}).catch(function(){r.onReport&&r.onReport(t)}):r.onReport&&r.onReport(t),c=setTimeout(function(){r.release()},o)}var r,o=3e3,u=!1,i=[],c=null;return r={release:function(e){u&&e&&e!=u||(u=!1,clearTimeout(c),i.length&&n(i.shift()))},push:function(e){u?i.push(e):(u=e,n(e))}}}(); 
 			}); 
		define("src/util/platform-config.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";module.exports={APP_NAME:{v4169:"plugin",v4160:"sport.qq.com",v4144:"pvp.qq.com"},APP_PLATFORM:{v4169:"4210801",v4160:"40801",v4144:"3100801"}}; 
 			}); 
		define("src/video.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";var e=require("./module/reporter/index"),t=require("./controller-video/index"),o=require("./controller-live/index"),n=require("./util/platform-config").APP_NAME,r=module.exports=function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{},r=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{},i=r.from,a=void 0===r.autoplay||r.autoplay,d=r.defn||"",p=void 0!==r.noad&&!!r.noad,f="function"==typeof r.getReportParam?r.getReportParam:"function"==typeof r.getLoginData?function(e){r.getLoginData(function(t,o){o.hc_openid=o.openid,delete o.openid,e(t,o)})}:function(e){return e()},u=e.vid;"string"==typeof e&&(u=e);var c,l=e.cid||"",s=e.sid,v=e.pid;return c=u?t({vid:u,cid:l,from:i,defn:d,noad:p},{getReportParam:function(e){f(function(t,o){o&&(o.appname=n[i]),e(t,o)})}}):o({sid:s,pid:v,from:i,defn:d,noad:p},{getReportParam:function(e){f(function(t,o){o&&(o.appname=n[i]),e(t,o)})}}),a&&c.start(),c};r.on=function(t){"report"==t&&(e.off("report"),e.on.apply(e,arguments))},r.release=e.release,r.saveState=e.saveState,r.restoreState=e.restoreState,r.checkState=e.checkState; 
 			}); 
		global.__wxAppCurrentFile__ = 'plugin-private://wxa75efa648b60994b/component/live/live.js';	define("component/live/live.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";var t=require("../../index"),e=require("../txv-context"),i=require("../../src/module/log")("txv-live-component");Component({properties:{pid:{type:String,value:"",observer:"onVideoChange"},sid:{type:String,value:"",observer:"onVideoChange"},playerid:{type:String,value:""},autoplay:{type:Boolean,value:!1}},data:{tvpUrl:"",tvpIsAd:!1,tvpState:"",tvpVideoError:""},attached:function(){var t=this;if(this.videoContext=wx.createVideoContext("tvp",this),i("attached",this.data),!this.data.playerid)throw new Error("需要为txv-live组件指定一个playerid");if(!this.data.sid||!this.data.pid)throw new Error("需要为txv-live组件传入sid和pid，否则怎么播放视频呢");var o={};["play","pause","seek","playbackRate","requestFullScreen","exitFullScreen"].forEach(function(e){o[e]=function(){for(var i=arguments.length,o=Array(i),n=0;n<i;n++)o[n]=arguments[n];t.videoContext[e].apply(t.videoContext,o)}}),e.txvAttached(this.data.playerid,o)},detached:function(){i("detached",this.data),e.txvDetached(this.data.playerid)},methods:{onVideoChange:function(){var e=this;this.data.sid&&this.data.pid&&(i("onVideoChange",this.data.sid,this.data.pid),this.video=t({sid:this.data.sid,pid:this.data.pid},{from:"v4169"}),this.video.on("contentchange",function(t){t.currentContent&&e.setData({tvpUrl:t.currentContent.url})}),this.video.on("error",function(t){e.triggerEvent("error",t)}))},__onTvpPlay:function(){this.video&&this.video.onContentPlay()},__onTvpPause:function(){this.video&&this.video.onContentPause()},__onTvpEnded:function(){this.video&&this.video.onContentEnd()},__onTvpTimeupdate:function(t){this.triggerEvent("timeupdate",t.detail),this.video&&this.video.onContentTimeupdate(null,t)},__onTvpError:function(){this.video&&this.video.onContentError()}}}); 
 			}); 	require("component/live/live.js");
 		global.__wxAppCurrentFile__ = 'plugin-private://wxa75efa648b60994b/component/noad-video/noad-video.js';	define("component/noad-video/noad-video.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";var e=require("../../index"),t=require("../txv-context"),o=require("../../src/module/log")("txv-video-component"),a=wx.getStorageSync("tvp_openid");a||(a=["_",Math.random().toString(16).slice(2),Math.random().toString(16).slice(2),Math.random().toString(16).slice(2)].join("").slice(0,28),wx.setStorageSync("tvp_openid",a)),Component({properties:{vid:{type:String,value:"",observer:"onVideoChange"},playerid:{type:String,value:""},autoplay:{type:Boolean,value:!1},objectFit:{type:String,value:"contain"},poster:{type:String,value:""},showProgress:{type:Boolean,value:!0},controls:{type:Boolean,value:!0},initialTime:{type:Number,value:0},showFullscreenBtn:{type:Boolean,value:!0},showPlayBtn:{type:Boolean,value:!0},showCenterPlayBtn:{type:Boolean,value:!0},enableProgressGesture:{type:Boolean,value:!0},pageGesture:{type:Boolean,value:!1},muted:{type:Boolean,value:!1},loop:{type:Boolean,value:!1}},data:{progressBaseTime:0,progressSkipTime:0,progressTime:0,progressDuration:0,tvpUrl:"",tvpIsAd:!1,tvpState:"",tvpVideoError:"",reportUrl:""},attached:function(){var a=this;if(this.videoContext=wx.createVideoContext("tvp",this),o("attached",this.data),!this.data.playerid)throw new Error("需要为txv-video组件指定一个playerid");if(!this.data.vid)throw new Error("需要为txv-video组件传入一个vid，否则怎么播放视频呢");var n={};["play","pause","seek","playbackRate","requestFullScreen","exitFullScreen"].forEach(function(e){n[e]=function(){for(var t=arguments.length,o=Array(t),n=0;n<t;n++)o[n]=arguments[n];a.videoContext[e].apply(a.videoContext,o)}}),t.txvAttached(this.data.playerid,n),e.on("report",function(e){a.setData({reportUrl:e.reportUrl.replace("https","http")})})},moved:function(){},detached:function(){o("detached",this.data),t.txvDetached(this.data.playerid)},methods:{skipAd:function(){this.video.onContentSkip(0)},onVideoChange:function(){var t=this;if(this.data.vid){o("onVideoChange",this.data.vid);var n=this.video=e(this.data.vid,{from:"v4169",noad:!0,getReportParam:function(e){e(null,{hc_openid:a,hc_vuserid:a})}});n.on("error",function(e){t.triggerEvent("error",e)}),n.on("statechange",function(e,a,n){if(o("onstatechange",e,a),t.triggerEvent("statechange",{newstate:e,oldstate:a}),e!=t.data.tvpState){switch(console.info("playerstatechange "+t.data.tvpState+" => "+e),t.data.tvpState){case"stop":break;case"error":return}switch(t.setData({tvpState:e}),e){case"playing":t.videoContext.play();break;case"error":t.setData({tvpVideoError:n||""});case"pause":case"stop":break;case"ended":t.videoContext.pause()}}}),n.on("contentchange",function(e){if(o("contentchange",e),e.currentContent){var a={};a.progressTime=0,e.progress?(a.progressDuration=e.progress.duration,a.progressBaseTime=e.progress.time,a.progressSkipTime=e.progress.skipable):(a.progressDuration=0,a.progressBaseTime=0,a.progressSkipTime=0),console.log("contentchange",e),a.tvpUrl=e.currentContent.url,a.tvpIsAd=!!e.currentContent.isad,t.setData(a)}else o("first content change",e)})}},__onTvpPlay:function(){this.video&&this.video.onContentPlay()},__onTvpPause:function(){this.video&&this.video.onContentPause()},__onTvpEnded:function(){this.video&&this.video.onContentEnd()},__onTvpTimeupdate:function(e){this.triggerEvent("timeupdate",e.detail);try{this.setData({progressTime:Math.floor(e.detail.currentTime)}),this.video&&this.video.onContentTimeupdate(null,e)}catch(e){}},__onTvpError:function(){this.video&&this.video.onContentError()}}}); 
 			}); 	require("component/noad-video/noad-video.js");
 		global.__wxAppCurrentFile__ = 'plugin-private://wxa75efa648b60994b/component/video/video.js';	define("component/video/video.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";var e=require("../../index"),t=require("../txv-context"),o=require("../../src/module/log")("txv-video-component"),a=wx.getStorageSync("tvp_openid");a||(a=["_",Math.random().toString(16).slice(2),Math.random().toString(16).slice(2),Math.random().toString(16).slice(2)].join("").slice(0,28),wx.setStorageSync("tvp_openid",a)),Component({properties:{vid:{type:String,value:"",observer:"onVideoChange"},playerid:{type:String,value:""},autoplay:{type:Boolean,value:!1},objectFit:{type:String,value:"contain"},poster:{type:String,value:""},showProgress:{type:Boolean,value:!0},controls:{type:Boolean,value:!0},initialTime:{type:Number,value:0},showFullscreenBtn:{type:Boolean,value:!0},showPlayBtn:{type:Boolean,value:!0},showCenterPlayBtn:{type:Boolean,value:!0},enableProgressGesture:{type:Boolean,value:!0},pageGesture:{type:Boolean,value:!1},muted:{type:Boolean,value:!1},loop:{type:Boolean,value:!1}},data:{progressBaseTime:0,progressSkipTime:0,progressTime:0,progressDuration:0,tvpUrl:"",tvpIsAd:!1,tvpState:"",tvpVideoError:"",reportUrl:""},attached:function(){var a=this;if(this.videoContext=wx.createVideoContext("tvp",this),o("attached",this.data),!this.data.playerid)throw new Error("需要为txv-video组件指定一个playerid");if(!this.data.vid)throw new Error("需要为txv-video组件传入一个vid，否则怎么播放视频呢");var n={};["play","pause","seek","playbackRate","requestFullScreen","exitFullScreen"].forEach(function(e){n[e]=function(){for(var t=arguments.length,o=Array(t),n=0;n<t;n++)o[n]=arguments[n];a.videoContext[e].apply(a.videoContext,o)}}),t.txvAttached(this.data.playerid,n),e.on("report",function(e){a.setData({reportUrl:e.reportUrl.replace("https","http")})})},moved:function(){},detached:function(){o("detached",this.data),t.txvDetached(this.data.playerid)},methods:{skipAd:function(){this.video.onContentSkip(0)},onVideoChange:function(){var t=this;if(this.data.vid){o("onVideoChange",this.data.vid);var n=this.video=e(this.data.vid,{from:"v4169",getReportParam:function(e){e(null,{hc_openid:a,hc_vuserid:a})}});n.on("error",function(e){t.triggerEvent("error",e)}),n.on("statechange",function(e,a,n){if(o("onstatechange",e,a),t.triggerEvent("statechange",{newstate:e,oldstate:a}),e!=t.data.tvpState){switch(console.info("playerstatechange "+t.data.tvpState+" => "+e),t.data.tvpState){case"stop":break;case"error":return}switch(t.setData({tvpState:e}),e){case"playing":t.videoContext.play();break;case"error":t.setData({tvpVideoError:n||""});case"pause":case"stop":break;case"ended":t.videoContext.pause()}}}),n.on("contentchange",function(e){if(o("contentchange",e),e.currentContent){var a={};a.progressTime=0,e.progress?(a.progressDuration=e.progress.duration,a.progressBaseTime=e.progress.time,a.progressSkipTime=e.progress.skipable):(a.progressDuration=0,a.progressBaseTime=0,a.progressSkipTime=0),console.log("contentchange",e),a.tvpUrl=e.currentContent.url,a.tvpIsAd=!!e.currentContent.isad,t.setData(a)}else o("first content change",e)})}},__onTvpPlay:function(){this.video&&this.video.onContentPlay()},__onTvpPause:function(){this.video&&this.video.onContentPause()},__onTvpEnded:function(){this.video&&this.video.onContentEnd()},__onTvpTimeupdate:function(e){this.triggerEvent("timeupdate",e.detail);try{this.setData({progressTime:Math.floor(e.detail.currentTime)}),this.video&&this.video.onContentTimeupdate(null,e)}catch(e){}},__onTvpError:function(){this.video&&this.video.onContentError()}}}); 
 			}); 	require("component/video/video.js");
 	
				global.publishDomainComponents({
			"plugin://wxa75efa648b60994b/video":"plugin-private://wxa75efa648b60994b/component/video/video","plugin://wxa75efa648b60994b/noad-video":"plugin-private://wxa75efa648b60994b/component/noad-video/noad-video","plugin://wxa75efa648b60994b/live":"plugin-private://wxa75efa648b60994b/component/live/live"
	})
				module.exports = function() {
		return require('component/txv-context.js')
	}
			});
	requirePlugin("plugin://wxa75efa648b60994b");
/*v0.5vv_20200413_syb_scopedata*/global.__wcc_version__='v0.5vv_20200413_syb_scopedata';global.__wcc_version_info__={"customComponents":true,"fixZeroRpx":true,"propValueDeepCopy":false};
var $gwxc
var $gaic={}
$gwx=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx || [];
__WXML_GLOBAL__.ops_set.$gwx=z;
__WXML_GLOBAL__.ops_init.$gwx=true;
var nv_require=function(){var nnm={};var nom={};return function(n){if(n[0]==='p'&&n[1]==='_'&&f_[n.slice(2)])return f_[n.slice(2)];return function(){if(!nnm[n]) return undefined;try{if(!nom[n])nom[n]=nnm[n]();return nom[n];}catch(e){e.message=e.message.replace(/nv_/g,'');var tmp = e.stack.substring(0,e.stack.lastIndexOf(n));e.stack = tmp.substring(0,tmp.lastIndexOf('\n'));e.stack = e.stack.replace(/\snv_/g,' ');e.stack = $gstack(e.stack);e.stack += '\n    at ' + n.substring(2);console.error(e);}
}}}()
var x=[];if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||true)$gwx();;__wxRoute = undefined;__wxRouteBegin = undefined;__wxAppCurrentFile__=undefined;define("@babel/runtime/helpers/arrayLikeToArray.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
function _arrayLikeToArray(r,a){(null==a||a>r.length)&&(a=r.length);for(var e=0,n=new Array(a);e<a;e++)n[e]=r[e];return n}module.exports=_arrayLikeToArray;
},{isPage:false,isComponent:false,currentFile:'@babel/runtime/helpers/arrayLikeToArray.js'});;__wxRoute = undefined;__wxRouteBegin = undefined;__wxAppCurrentFile__=undefined;define("@babel/runtime/helpers/arrayWithHoles.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
function _arrayWithHoles(r){if(Array.isArray(r))return r}module.exports=_arrayWithHoles;
},{isPage:false,isComponent:false,currentFile:'@babel/runtime/helpers/arrayWithHoles.js'});;__wxRoute = undefined;__wxRouteBegin = undefined;__wxAppCurrentFile__=undefined;define("@babel/runtime/helpers/defineProperty.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
function _defineProperty(e,r,n){return r in e?Object.defineProperty(e,r,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[r]=n,e}module.exports=_defineProperty;
},{isPage:false,isComponent:false,currentFile:'@babel/runtime/helpers/defineProperty.js'});;__wxRoute = undefined;__wxRouteBegin = undefined;__wxAppCurrentFile__=undefined;define("@babel/runtime/helpers/iterableToArray.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
function _iterableToArray(r){if("undefined"!=typeof Symbol&&Symbol.iterator in Object(r))return Array.from(r)}module.exports=_iterableToArray;
},{isPage:false,isComponent:false,currentFile:'@babel/runtime/helpers/iterableToArray.js'});;__wxRoute = undefined;__wxRouteBegin = undefined;__wxAppCurrentFile__=undefined;define("@babel/runtime/helpers/nonIterableRest.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
function _nonIterableRest(){throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}module.exports=_nonIterableRest;
},{isPage:false,isComponent:false,currentFile:'@babel/runtime/helpers/nonIterableRest.js'});;__wxRoute = undefined;__wxRouteBegin = undefined;__wxAppCurrentFile__=undefined;define("@babel/runtime/helpers/toArray.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
var arrayWithHoles=require("./arrayWithHoles"),iterableToArray=require("./iterableToArray"),unsupportedIterableToArray=require("./unsupportedIterableToArray"),nonIterableRest=require("./nonIterableRest");function _toArray(r){return arrayWithHoles(r)||iterableToArray(r)||unsupportedIterableToArray(r)||nonIterableRest()}module.exports=_toArray;
},{isPage:false,isComponent:false,currentFile:'@babel/runtime/helpers/toArray.js'});;__wxRoute = undefined;__wxRouteBegin = undefined;__wxAppCurrentFile__=undefined;define("@babel/runtime/helpers/unsupportedIterableToArray.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
var arrayLikeToArray=require("./arrayLikeToArray");function _unsupportedIterableToArray(r,e){if(r){if("string"==typeof r)return arrayLikeToArray(r,e);var t=Object.prototype.toString.call(r).slice(8,-1);return"Object"===t&&r.constructor&&(t=r.constructor.name),"Map"===t||"Set"===t?Array.from(r):"Arguments"===t||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t)?arrayLikeToArray(r,e):void 0}}module.exports=_unsupportedIterableToArray;
},{isPage:false,isComponent:false,currentFile:'@babel/runtime/helpers/unsupportedIterableToArray.js'});;__wxRoute = undefined;__wxRouteBegin = undefined;__wxAppCurrentFile__=undefined;define("config.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var a="https://mini.kaililaw.com/eae/api/",t={appid:"wxed767ccdc8b08ef6",login:"".concat(a,"user/login"),tel:"".concat(a,"user/tel"),wxdl:"".concat(a,"user/wxdl"),reg:"".concat(a,"user/reg"),vcode:"".concat(a,"user/vcode"),verify:"".concat(a,"user/verify"),user:"".concat(a,"user/user"),logout:"".concat(a,"user/logout"),getExamListIndex:"".concat(a,"nntli/exam/getExamList"),getExamList:"".concat(a,"exam/getExamList"),beginExam:"".concat(a,"exam/beginExam"),addRecord:"".concat(a,"exam/addRecord"),getReport:"".concat(a,"exam/getReport"),allRecords:"".concat(a,"exam/allRecords"),recordReport:"".concat(a,"exam/recordReport"),examReview:"".concat(a,"exam/examReview"),restartExam:"".concat(a,"exam/restartExam"),banner:"".concat(a,"banner/banners"),allRank:"".concat(a,"statistics/allRank"),myRank:"".concat(a,"statistics/myRank"),zzjg:"".concat(a,"info/zzjg_zhiji"),getComp:"".concat(a,"voting/campaign/campaigns"),getCompDetail:"".concat(a,"voting/campaign/campaign"),getGroups:"".concat(a,"voting/campaign/groups"),getCalist:"".concat(a,"voting/candidate/candidates"),getCaDetail:"".concat(a,"voting/candidate/candidate"),getRank:"".concat(a,"voting/candidate/rank"),vote:"".concat(a,"voting/vote")};module.exports=t;
},{isPage:false,isComponent:false,currentFile:'config.js'});;__wxRoute = undefined;__wxRouteBegin = undefined;__wxAppCurrentFile__=undefined;define("http.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var t=require("config.js");module.exports={request:function(e,a,s,o,d,n){n&&wx.showLoading({title:"正在加载中..."}),wx.request({url:e,data:s,method:a,header:{Cookie:"sessionid="+wx.getStorageSync("sessionId")+";appid="+wx.getStorageSync("appid")},success:function(e){n&&wx.hideLoading(),200==e.statusCode||201==e.statusCode?o(e.data):401==e.statusCode?wx.navigateTo({url:"../login-default/login-default"}):402==e.statusCode?wx.login({success:function(e){wx.request({url:t.login,data:{code:e.code},method:"POST",success:function(t){null!=t.data.data&&(wx.setStorageSync("sessionId",t.data.data),wx.reLaunch({url:"../index/index"}))},fail:function(t){}})}}):444==e.statusCode?wx.showToast({title:"您的账号存在风险，已加入系统黑名单，请联系管理员处理",icon:"none",duration:3e3}):409==e.statusCode?d(e.data.msg):421==e.statusCode?d(e.data.data):500==e.statusCode&&wx.showToast({title:e.data.msg,icon:"none",duration:3e3})},fail:function(t){n&&wx.hideLoading(),d("连接服务器失败，请稍后重试")}})}};
},{isPage:false,isComponent:false,currentFile:'http.js'});;__wxRoute = undefined;__wxRouteBegin = undefined;__wxAppCurrentFile__=undefined;define("utils/util.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var e=function(e){return(e=e.toString())[1]?e:"0"+e};module.exports={formatTime:function(t){var g=t.getFullYear(),n=t.getMonth()+1,o=t.getDate(),r=t.getHours(),s=t.getMinutes(),u=t.getSeconds();return[g,n,o].map(e).join("/")+" "+[r,s,u].map(e).join(":")},dateFormat:function(e,t){(e=new Date(e)).setHours(e.getHours()-14);var g={"M+":e.getMonth()+1,"d+":e.getDate(),"H+":e.getHours(),"m+":e.getMinutes(),"s+":e.getSeconds(),"q+":Math.floor((e.getMonth()+3)/3),S:e.getMilliseconds()};for(var n in/(y+)/.test(t)&&(t=t.replace(RegExp.$1,(e.getFullYear()+"").substr(4-RegExp.$1.length))),g)new RegExp("("+n+")").test(t)&&(t=t.replace(RegExp.$1,1==RegExp.$1.length?g[n]:("00"+g[n]).substr((""+g[n]).length)));return t},formatDate:function(e){return(e=new Date(e)).getFullYear()+"-"+(e.getMonth()+1<10?"0"+(e.getMonth()+1):e.getMonth()+1)+"-"+(e.getDate()<10?"0"+e.getDate():e.getDate())+" "+(e.getHours()<10?"0"+e.getHours():e.getHours())+":"+(e.getMinutes()<10?"0"+e.getMinutes():e.getMinutes())+":"+(e.getSeconds()<10?"0"+e.getSeconds():e.getSeconds())}};
},{isPage:false,isComponent:false,currentFile:'utils/util.js'});;__wxRoute = undefined;__wxRouteBegin = undefined;__wxAppCurrentFile__=undefined;define("app.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var t=require("config.js"),e=(require("http.js"),wx.getUpdateManager());App({onLaunch:function(){var o=this;wx.setStorageSync("appid",t.appid),this.login(),wx.getSetting({success:function(t){wx.getUserProfile({success:function(t){wx.setStorageSync("userInfo",t.userInfo),o.globalData.userInfo=t.userInfo,o.userInfoReadyCallback&&o.userInfoReadyCallback(t)}})}}),wx.getSystemInfo({success:function(t){o.globalData.StatusBar=t.statusBarHeight;var e=wx.getMenuButtonBoundingClientRect();o.globalData.Custom=e;var a=e.bottom+e.top-t.statusBarHeight;o.globalData.CustomBar=a,a>75&&(o.globalData.tabbar_bottom="y")}}),e.onCheckForUpdate((function(t){})),e.onUpdateReady((function(){wx.showModal({title:"更新提示",content:"新版本已经准备好，是否重启应用？",success:function(t){t.confirm&&e.applyUpdate()}})})),e.onUpdateFailed((function(){}))},login:function(){wx.login({success:function(e){wx.showLoading({title:"正在加载中..."}),wx.request({url:t.login,data:{code:e.code},header:{Cookie:"sessionid="+wx.getStorageSync("sessionId")+";appid="+wx.getStorageSync("appid")},method:"POST",success:function(t){wx.hideLoading(),null!=t.data.data&&wx.setStorageSync("sessionId",t.data.data)},fail:function(t){wx.hideLoading()}})}})},globalData:{userInfo:null,userMsg:null,haslogin:!1,examMsg:null,question:{zero:!1,one:!1,two:!1,three:!1,four:!1},score:{zero:0,one:0,two:0,three:0,four:0,total:0},examTitle:null}});
},{isPage:false,isComponent:false,currentFile:'app.js'});require("app.js");$gwx_XC_0=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_0 || [];
function gz$gwx_XC_0_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_0_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_0_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_0_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'contentview'])
Z([[2,'=='],[[7],[3,'formType']],[1,0]])
Z([[2,'=='],[[7],[3,'formType']],[1,1]])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_0_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_0_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_0=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_0=true;
var x=['./pages/amend/amend.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_0_1()
var oB=_n('view')
_rz(z,oB,'class',0,e,s,gg)
var xC=_v()
_(oB,xC)
if(_oz(z,1,e,s,gg)){xC.wxVkey=1
}
var oD=_v()
_(oB,oD)
if(_oz(z,2,e,s,gg)){oD.wxVkey=1
}
xC.wxXCkey=1
oD.wxXCkey=1
_(r,oB)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_0";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_0();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/amend/amend.wxml'] = [$gwx_XC_0, './pages/amend/amend.wxml'];else __wxAppCode__['pages/amend/amend.wxml'] = $gwx_XC_0( './pages/amend/amend.wxml' );
	;__wxRoute = "pages/amend/amend";__wxRouteBegin = true;__wxAppCurrentFile__="pages/amend/amend.js";define("pages/amend/amend.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var a=require("../../@babel/runtime/helpers/toArray"),t=require("../../config.js"),e=require("../../http.js"),n=getApp();Page({data:{array:[],index:0,default:" 请选择",multidefault:"请选择",formType:"",typedefault:"请选择",name:"",area:"请选择",unit:"",zhiwu:"",type:"",rawData:[],multiObjArray:[[],[],[]],multiIndex:[0,0,0],reason:"请选择",reasonArray:["缺考","不合格","其他"],reasonIndex:0},onLoad:function(a){var t=a.type;this.setData({formType:t}),this.getzzjg()},getzzjg:function(){var a=this;e.request(t.zzjg,"get",null,(function(t){if(t.rows){var e=t.rows;a.setData({array:JSON.parse(e.zhiji),rawData:JSON.parse(e.zzjg)});var n=function a(){for(var t=arguments.length>0&&void 0!==arguments[0]?arguments[0]:[],e=[],n=function(n){var i=t[n];"string"==typeof i?e.push({name:i}):Object.keys(i).forEach((function(t){var n={};n.name=t;var o=i[t];Array.isArray(o)&&o.length>0&&(n.list=a(o)),e.push(n)}))},i=0;i<t.length;i++)n(i);return e}(a.data.rawData);a.setData({rawData:n,"multiObjArray[0]":n,"multiObjArray[1]":n[0].list,"multiObjArray[2]":n[0].list[0].list})}}),(function(a){wx.showToast({title:a,icon:"none"})}),!0)},onReady:function(){},onShow:function(){var a=wx.getStorageSync("userMsg");console.log("msg===>",a),this.setData({userMsg:a,phone:a.phone,name:a.name,area:a.area,unit:a.unit,zhiwu:a.zhiwu})},onHide:function(){},onUnload:function(){},bindMultiPickerChange:function(a){var t=a.detail.value;this.setData({multiIndex:t,multidefault:this.data.multiObjArray[0][t[0]].name+" "+this.data.multiObjArray[1][t[1]].name+" "+this.data.multiObjArray[2][t[2]].name});var e=this.data.multidefault;this.setData({area:e})},bindMultiPickerColumnChange:function(t){var e=a(this.data.multiIndex).slice(0);e[t.detail.column]=t.detail.value,0===t.detail.column&&(e[1]=0,e[2]=0,e[3]=0),1===t.detail.column&&(e[2]=0,e[3]=0),2===t.detail.column&&(e[3]=0);var n=this.data.rawData[e[0]].list;this.setData({"multiObjArray[1]":n,"multiObjArray[2]":n[e[1]].list,multiIndex:e})},nameInput:function(a){var t=a.detail.value;this.setData({name:t})},unitInput:function(a){var t=a.detail.value;this.setData({unit:t})},bindPickerChange:function(a){var t=a.detail.value,e=this.data.array;this.setData({index:t,default:e[t]});var n=this.data.array[this.data.index];this.setData({zhiwu:n})},bindPickerChanges:function(a){var t=a.detail.value,e=this.data.reasonArray;this.setData({reasonIndex:t,defaults:e[t]});var n=this.data.reasonArray[this.data.reasonIndex];this.setData({reason:n})},bindTypeChange:function(a){var t=a.detail.value,e=this.data.typeArray;this.setData({typeIndex:t,typedefault:e[t]});var n=this.data.typeArray[this.data.typeIndex];this.setData({type:n})},amend:function(){var a=this;""!=a.data.name?""!=a.data.area?""!=a.data.zhiwu?e.request(t.user,"POST",{name:this.data.name,unit:this.data.unit,zhiwu:this.data.zhiwu,area:this.data.area},(function(t){if(null!=t.data)return wx.setStorageSync("userMsg",t.data),wx.showToast({title:"个人信息修改成功",icon:"none"}),void(1==a.data.formType&&a.toway())}),(function(a){wx.showToast({title:a,icon:"none"})})):wx.showToast({title:"职务不能为空",icon:"none"}):wx.showToast({title:"所在地不能为空",icon:"none"}):wx.showToast({title:"姓名不能为空",icon:"none"})},toway:function(){n.globalData.question.zero?wx.navigateTo({url:"../loading/loading?type=0&questionType=0"}):n.globalData.question.one?wx.navigateTo({url:"../loading/loading?type=0&questionType=1"}):n.globalData.question.two?wx.navigateTo({url:"../loading/loading?type=0&questionType=2"}):n.globalData.question.three?wx.navigateTo({url:"../loading/loading?type=0&questionType=3"}):n.globalData.question.four&&wx.navigateTo({url:"../loading/loading?type=0&questionType=4"})},cancle:function(){wx.navigateBack({delta:1})},logout:function(){e.request(t.logout,"POST",null,(function(a){wx.setStorageSync("haslogin",!1),wx.reLaunch({url:"../index/index"})}),(function(a){wx.showToast({title:a,icon:"none"})}))}});
},{isPage:true,isComponent:true,currentFile:'pages/amend/amend.js'});require("pages/amend/amend.js");$gwx_XC_1=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_1 || [];
function gz$gwx_XC_1_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_1_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_1_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_1_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'noData']])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_1_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_1_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_1=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_1=true;
var x=['./pages/area-rank/area-rank.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_1_1()
var cF=_v()
_(r,cF)
if(_oz(z,0,e,s,gg)){cF.wxVkey=1
}
cF.wxXCkey=1
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_1";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_1();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/area-rank/area-rank.wxml'] = [$gwx_XC_1, './pages/area-rank/area-rank.wxml'];else __wxAppCode__['pages/area-rank/area-rank.wxml'] = $gwx_XC_1( './pages/area-rank/area-rank.wxml' );
	;__wxRoute = "pages/area-rank/area-rank";__wxRouteBegin = true;__wxAppCurrentFile__="pages/area-rank/area-rank.js";define("pages/area-rank/area-rank.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var a=require("../../config.js"),t=require("../../http.js"),i=1;Page({data:{multiArray:[["区（中）直单位","地（市）"],["党政机关","事业单位","人民团体","中直单位","国有企业"],["自治区纪委","自治区党委办公厅","自治区人大办公厅","自治区政府办公厅","自治区政协办公厅","自治区高级人民法院","自治区人民检察院","自治区党委组织部","自治区党委宣传部","自治区党委统战部","自治区党委政法委","自治区党委政研室","自治区党委网信办","区直机关工委","自治区党委老干部局","自治区发改委","自治区教育厅","自治区科技厅","自治区经信厅","自治区民族事务委员会","自治区公安厅","自治区民政厅","自治区司法厅","自治区财政厅","自治区人社厅","自治区自然资源厅","自治区生态环境厅","自治区住建厅","自治区交通厅","自治区水利厅","自治区农业农村厅","自治区商务厅","自治区文化厅","自治区卫健委","自治区旅游发展厅","自治区退役军人事务厅","自治区应急管理厅","自治区审计厅","自治区外事办","自治区政府国资委","自治区市场监督管理局","自治区广电局","自治区体育局","自治区统计局","自治区扶贫办","自治区林业和草原局","自治区宗教事务局","自治区医疗保障局","自治区人防办","自治区政府研究室","自治区信访局","自治区粮食和物资储备局","自治区能源局","自治区文物局","自治区药监局","北京办事处","成都办事处","上海办事处","格尔木办事处","西安办事处","其他单位（自行填写）"]],multiIndex:[0,0,0],userRank:{rank:"无",total:"无"},noData:!0},onLoad:function(a){var t=this.data.multiArray[0][this.data.multiIndex[0]]+this.data.multiArray[1][this.data.multiIndex[1]]+this.data.multiArray[2][this.data.multiIndex[2]];this.setData({area:t}),i=1,this.getAllRank(i),this.getMyRank()},onReady:function(){},onShow:function(){},onHide:function(){},onUnload:function(){},bindMultiPickerChange:function(a){this.setData({multiIndex:a.detail.value});var t=this.data.multiArray[0][this.data.multiIndex[0]]+this.data.multiArray[1][this.data.multiIndex[1]]+this.data.multiArray[2][this.data.multiIndex[2]];this.setData({area:t,userRank:{rank:"无",total:"无"},noData:!0}),i=1,this.getAllRank(i),this.getMyRank()},bindMultiPickerColumnChange:function(a){var t={multiArray:this.data.multiArray,multiIndex:this.data.multiIndex};switch(t.multiIndex[a.detail.column]=a.detail.value,a.detail.column){case 0:switch(t.multiIndex[0]){case 0:t.multiArray[1]=["党政机关","事业单位","人民团体","中直单位","国有企业"],t.multiArray[2]=["自治区纪委","自治区党委办公厅","自治区人大办公厅","自治区政府办公厅","自治区政协办公厅","自治区高级人民法院","自治区人民检察院","自治区党委组织部","自治区党委宣传部","自治区党委统战部","自治区党委政法委","自治区党委政研室","自治区党委网信办","区直机关工委","自治区党委老干部局","自治区发改委","自治区教育厅","自治区科技厅","自治区经信厅","自治区民族事务委员会","自治区公安厅","自治区民政厅","自治区司法厅","自治区财政厅","自治区人社厅","自治区自然资源厅","自治区生态环境厅","自治区住建厅","自治区交通厅","自治区水利厅","自治区农业农村厅","自治区商务厅","自治区文化厅","自治区卫健委","自治区旅游发展厅","自治区退役军人事务厅","自治区应急管理厅","自治区审计厅","自治区外事办","自治区政府国资委","自治区市场监督管理局","自治区广电局","自治区体育局","自治区统计局","自治区扶贫办","自治区林业和草原局","自治区宗教事务局","自治区医疗保障局","自治区人防办","自治区政府研究室","自治区信访局","自治区粮食和物资储备局","自治区能源局","自治区文物局","自治区药监局","北京办事处","成都办事处","上海办事处","格尔木办事处","西安办事处","其他单位（自行填写）"];break;case 1:t.multiArray[1]=["拉萨市","日喀则市","昌都市","山南市","那曲市","阿里地区","林芝市"],t.multiArray[2]=["市直单位","其他单位（自行填写）","城关区","林周县","当雄县","尼木县","曲水县","堆龙德庆区","达孜区","墨竹工卡县"]}t.multiIndex[1]=0,t.multiIndex[2]=0;break;case 1:switch(t.multiIndex[0]){case 0:switch(t.multiIndex[1]){case 0:t.multiArray[2]=["自治区纪委","自治区党委办公厅","自治区人大办公厅","自治区政府办公厅","自治区政协办公厅","自治区高级人民法院","自治区人民检察院","自治区党委组织部","自治区党委宣传部","自治区党委统战部","自治区党委政法委","自治区党委政研室","自治区党委网信办","区直机关工委","自治区党委老干部局","自治区发改委","自治区教育厅","自治区科技厅","自治区经信厅","自治区民族事务委员会","自治区公安厅","自治区民政厅","自治区司法厅","自治区财政厅","自治区人社厅","自治区自然资源厅","自治区生态环境厅","自治区住建厅","自治区交通厅","自治区水利厅","自治区农业农村厅","自治区商务厅","自治区文化厅","自治区卫健委","自治区旅游发展厅","自治区退役军人事务厅","自治区应急管理厅","自治区审计厅","自治区外事办","自治区政府国资委","自治区市场监督管理局","自治区广电局","自治区体育局","自治区统计局","自治区扶贫办","自治区林业和草原局","自治区宗教事务局","自治区医疗保障局","自治区人防办","自治区政府研究室","自治区信访局","自治区粮食和物资储备局","自治区能源局","自治区文物局","自治区药监局","北京办事处","成都办事处","上海办事处","格尔木办事处","西安办事处","其他单位（自行填写）"];break;case 1:t.multiArray[2]=["自治区党校（自治区行政学院）","西藏日报社","自治区社科院","西藏大学","西藏农牧学院","西藏民族大学","西藏藏医药大学","自治区藏语工作委员会办公室（编译局）","自治区农科院","自治区地质矿产勘查开发局","西藏广播电视台","其他单位（自行填写）"];break;case 2:t.multiArray[2]=["自治区总工会","团区委","自治区妇联","自治区文联","自治区工商联","自治区科协","佛协西藏分会","自治区残联","自治区红十字会","其他单位（自行填写）"];break;case 3:t.multiArray[2]=["国家税务总局西藏税务局","拉萨海关","西藏自治区通信管理局","西藏自治区邮政管理局","西藏自治区地震局","西藏自治区气象局","民航西藏自治区管理局","其他单位（自行填写）"];break;case 4:t.multiArray[2]=["全部"]}break;case 1:switch(t.multiIndex[1]){case 0:t.multiArray[2]=["市直单位","其他单位（自行填写）","城关区","林周县","当雄县","尼木县","曲水县","堆龙德庆区","达孜区","墨竹工卡县"];break;case 1:t.multiArray[2]=["市直单位","其他单位（自行填写）","桑珠孜区","南木林县","江孜县","定日县","萨迦县","拉孜县","昂仁县","谢通门县","白朗县","仁布县","康马县","定结县","仲巴县","亚东县","吉隆县","聂拉木县","萨嘎县","岗巴县"];break;case 2:t.multiArray[2]=["市直单位","其他单位（自行填写）","卡若区","江达县","贡觉县","类乌齐县","丁青县","察雅县","八宿县","左贡县","芒康县","洛隆县","边坝县"];break;case 3:t.multiArray[2]=["市直单位","其他单位（自行填写）","乃东区","扎囊县","贡嘎县","桑日县","琼结县","曲松县","措美县","洛扎县","加查县","隆子县","错那县","浪卡子县"];break;case 4:t.multiArray[2]=["市直单位","其他单位（自行填写）","色尼区","嘉黎县","比如县","聂荣县","安多县","申扎县","索县","班戈县","巴青县","尼玛县","双湖县"];break;case 5:t.multiArray[2]=["地直单位","其他单位（自行填写）","普兰县","札达县","噶尔县","日土县","革吉县","改则县","措勤县"];break;case 6:t.multiArray[2]=["市直单位","其他单位（自行填写）","巴宜区","工布江达县","米林县","墨脱县","波密县","察隅县","朗县"]}}t.multiIndex[2]=0}this.setData(t)},historyRank:function(){wx.navigateBack({delta:1})},loadMoreData:function(){i++,this.getAllRank(i)},getAllRank:function(i){var e=this;t.request(a.allRank,"GET",{page:i,pageSize:20,area:this.data.area},(function(a){null!=a&&(i>1?e.setData({rankData:e.data.rankData.concat(a)}):(e.setData({rankData:a}),a.length>0&&e.setData({noData:!1})))}),(function(a){wx.showToast({title:a,icon:"none"})}))},getMyRank:function(){var i=this;t.request(a.myRank,"GET",{area:this.data.area},(function(a){null!=a&&""!=a&&i.setData({userRank:a})}),(function(a){wx.showToast({title:a,icon:"none"})}))}});
},{isPage:true,isComponent:true,currentFile:'pages/area-rank/area-rank.js'});require("pages/area-rank/area-rank.js");$gwx_XC_2=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_2 || [];
function gz$gwx_XC_2_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_2_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_2_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_2_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container4'])
Z([3,'content'])
Z([[7],[3,'single']])
Z([[7],[3,'multiple']])
Z([[7],[3,'check']])
Z([[7],[3,'completion']])
Z([[7],[3,'unsureness']])
Z([[2,'=='],[[7],[3,'type']],[1,1]])
Z(z[7])
Z(z[7])
Z([[2,'>'],[[6],[[7],[3,'exam']],[3,'tryAgain']],[1,0]])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_2_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_2_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_2=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_2=true;
var x=['./pages/exam-result/exam-result.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_2_1()
var oH=_n('view')
_rz(z,oH,'class',0,e,s,gg)
var aL=_n('view')
_rz(z,aL,'class',1,e,s,gg)
var tM=_v()
_(aL,tM)
if(_oz(z,2,e,s,gg)){tM.wxVkey=1
}
var eN=_v()
_(aL,eN)
if(_oz(z,3,e,s,gg)){eN.wxVkey=1
}
var bO=_v()
_(aL,bO)
if(_oz(z,4,e,s,gg)){bO.wxVkey=1
}
var oP=_v()
_(aL,oP)
if(_oz(z,5,e,s,gg)){oP.wxVkey=1
}
var xQ=_v()
_(aL,xQ)
if(_oz(z,6,e,s,gg)){xQ.wxVkey=1
}
tM.wxXCkey=1
eN.wxXCkey=1
bO.wxXCkey=1
oP.wxXCkey=1
xQ.wxXCkey=1
_(oH,aL)
var cI=_v()
_(oH,cI)
if(_oz(z,7,e,s,gg)){cI.wxVkey=1
}
var oJ=_v()
_(oH,oJ)
if(_oz(z,8,e,s,gg)){oJ.wxVkey=1
}
var lK=_v()
_(oH,lK)
if(_oz(z,9,e,s,gg)){lK.wxVkey=1
var oR=_v()
_(lK,oR)
if(_oz(z,10,e,s,gg)){oR.wxVkey=1
}
oR.wxXCkey=1
}
else{lK.wxVkey=2
}
cI.wxXCkey=1
oJ.wxXCkey=1
lK.wxXCkey=1
_(r,oH)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_2";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_2();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/exam-result/exam-result.wxml'] = [$gwx_XC_2, './pages/exam-result/exam-result.wxml'];else __wxAppCode__['pages/exam-result/exam-result.wxml'] = $gwx_XC_2( './pages/exam-result/exam-result.wxml' );
	;__wxRoute = "pages/exam-result/exam-result";__wxRouteBegin = true;__wxAppCurrentFile__="pages/exam-result/exam-result.js";define("pages/exam-result/exam-result.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var e=require("../../config.js"),t=require("../../http.js"),a=getApp();Page({data:{type:-1,examPaper:null,userScore:null},onLoad:function(e){var t=e.type;this.setData({type:t});var o=wx.getStorageSync("userInfo");if(o&&this.setData({userAvatarUrl:o.avatarUrl,userNickName:o.nickName}),1==t){var n=a.globalData.question;this.setData({unsureness:n.zero,single:n.one,multiple:n.two,check:n.three,completion:n.four});var i=wx.getStorageSync("examMsg");i&&this.setData({exam:i,examName:i.theme});var s=wx.getStorageSync("examPaper");s&&this.setData({examData:s}),this.setData({userScore:a.globalData.score});var r=wx.getStorageSync("examRecord");r&&this.setData({examRecord:r})}else{var l=wx.getStorageSync("testRecord");if(l){a.globalData.examTitle={name:l.examName,start:l.startTime,end:l.endTime};var c=(new Date).getTime(),u=l.startTime.replace(/-/g,"/"),d=new Date(u).getTime(),m=l.endTime.replace(/-/g,"/"),h=new Date(m).getTime();c>d&&c<h?this.setData({showDetail:!1}):this.setData({showDetail:!0}),this.setData({examName:l.examName}),this.setData({examData:{unsurenessTotalPoint:l.unsurenessPoint,singleTotalPoint:l.singlePoint,multipleTotalPoint:l.mulitplePoint,checkTotalPoint:l.checkPoint,completionTotalPoint:l.completionPoint,totalPoint:l.totalPoint}}),null!=l.unsurenessPoint&&0!=l.unsurenessPoint&&this.setData({unsureness:!0}),null!=l.singlePoint&&0!=l.singlePoint&&this.setData({single:!0}),null!=l.mulitplePoint&&0!=l.mulitplePoint&&this.setData({multiple:!0}),null!=l.checkPoint&&0!=l.checkPoint&&this.setData({check:!0}),null!=l.completionPoint&&0!=l.completionPoint&&this.setData({completion:!0}),null!=l.eaeExamRecordVO&&this.setData({userScore:{zero:l.eaeExamRecordVO.unsurenessPoint,one:l.eaeExamRecordVO.singlePoint,two:l.eaeExamRecordVO.multiplePoint,three:l.eaeExamRecordVO.checkPoint,four:l.eaeExamRecordVO.completionPoint,total:l.eaeExamRecordVO.totalPoint},recordId:l.eaeExamRecordVO.id,examId:l.examId})}}},onReady:function(){},onShow:function(){},onHide:function(){},onUnload:function(){},backIndex:function(){wx.reLaunch({url:"../index/index"})},again:function(){a.globalData.question.zero?wx.navigateTo({url:"../loading/loading?type=0&questionType=0"}):a.globalData.question.one?wx.navigateTo({url:"../loading/loading?type=0&questionType=1"}):a.globalData.question.two?wx.navigateTo({url:"../loading/loading?type=0&questionType=2"}):a.globalData.question.three?wx.navigateTo({url:"../loading/loading?type=0&questionType=3"}):a.globalData.question.four&&wx.navigateTo({url:"../loading/loading?type=0&questionType=4"})},submit:function(){t.request(e.addRecord,"POST",{examId:this.data.exam.id,single_point:this.data.userScore.one,multiple_point:this.data.userScore.two,check_point:this.data.userScore.three,completion_point:this.data.userScore.four,unsureness_point:this.data.userScore.zero,unsurenessRecord:this.data.examRecord.unsurenessArray,singleRecord:this.data.examRecord.singleArray,multipleRecord:this.data.examRecord.multipleArray,checkRecord:this.data.examRecord.checkArray,completionRecord:this.data.examRecord.completionArray},(function(e){wx.showToast({title:"成绩提交成功"}),setTimeout((function(){wx.reLaunch({url:"../index/index"})}),1500)}),(function(e){wx.showToast({title:e,icon:"none"})}),!0)},examPaper:function(){this.data.showDetail?wx.navigateTo({url:"../test-paper/test-paper?type=2&examId="+this.data.examId+"&recordId="+this.data.recordId}):wx.showToast({title:"考试还未结束，不能查看试卷",icon:"none"})}});
},{isPage:true,isComponent:true,currentFile:'pages/exam-result/exam-result.js'});require("pages/exam-result/exam-result.js");$gwx_XC_3=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_3 || [];
function gz$gwx_XC_3_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_3_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_3_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_3_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[2,'!='],[[7],[3,'position']],[1,1]])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_3_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_3_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_3=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_3=true;
var x=['./pages/exam/exam.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_3_1()
var cT=_v()
_(r,cT)
if(_oz(z,0,e,s,gg)){cT.wxVkey=1
}
cT.wxXCkey=1
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_3";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_3();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/exam/exam.wxml'] = [$gwx_XC_3, './pages/exam/exam.wxml'];else __wxAppCode__['pages/exam/exam.wxml'] = $gwx_XC_3( './pages/exam/exam.wxml' );
	;__wxRoute = "pages/exam/exam";__wxRouteBegin = true;__wxAppCurrentFile__="pages/exam/exam.js";define("pages/exam/exam.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var e=null,t=null,s=[],a=getApp();Page({data:{position:1,typeValue:"单选题",typeCode:0,topic:"",answers:[],currentPos:0,timer:"",countDownNum:0,countDownValue:"00:00"},onLoad:function(e){this.setData({examName:a.globalData.examTitle.name}),s=[];var n=e.questionType;this.setData({typeCode:n});try{switch(n){case"0":t=wx.getStorageSync("unsurenessQuestions"),this.setData({typeValue:"不定项选择题"});break;case"1":t=wx.getStorageSync("singleQuestions"),this.setData({typeValue:"单选题"});break;case"2":t=wx.getStorageSync("multipleQuestions"),this.setData({typeValue:"多选题"});break;case"3":t=wx.getStorageSync("checkQuestions"),this.setData({typeValue:"判断题"});break;case"4":t=wx.getStorageSync("completionQuestions"),this.setData({typeValue:"填空题"})}t&&this.updatePageData(0)}catch(e){}var o=wx.getStorageSync("countDownNum");o&&this.setData({countDownNum:o})},onReady:function(){this.countDown()},onShow:function(){},onHide:function(){},onUnload:function(){wx.setStorageSync("countDownNum",this.data.countDownNum),clearInterval(this.data.timer)},last:function(){this.data.currentPos>0?(s.pop(),this.data.currentPos--,this.updatePageData(this.data.currentPos),this.data.position--,this.setData({position:this.data.position})):wx.showToast({title:"已经是该题型的第一题",icon:"none"})},next:function(){if(e.selectItems.length>0||""!=e.inputAnswer)if("2"==this.data.typeCode&&e.selectItems.length<2)wx.showToast({title:"多选题，请至少选择两个答案",icon:"none"});else if(this.data.currentPos<=t.length-1&&s.push(e),this.data.currentPos++,this.data.currentPos<t.length)this.updatePageData(this.data.currentPos),this.data.position++,this.setData({position:this.data.position});else{switch(this.data.typeCode){case"0":wx.setStorageSync("unsurenessRecord",s);break;case"1":wx.setStorageSync("singleRecord",s);break;case"2":wx.setStorageSync("multipleRecord",s);break;case"3":wx.setStorageSync("checkRecord",s);break;case"4":wx.setStorageSync("completionRecord",s)}var a=getCurrentPages();a[a.length-2].setData({lastQuestionType:this.data.typeCode}),wx.navigateBack({delta:1})}else wx.showToast({title:"请先作答",icon:"none"})},updatePageData:function(s){e={id:t[s].id,correctCount:t[s].correctCount,content:t[s].content,answers:t[s].answers,selectItems:[],inputAnswer:""};for(var a=0;a<e.answers.length;a++)e.answers[a].isSelect=!1;this.setData({topic:e.content,answers:e.answers,currentPos:s}),4==this.data.typeCode&&this.setData({answerValue:""})},itemClick:function(t){var s=t.currentTarget.dataset.pos,a=e.answers[s].id,n=e.selectItems.indexOf(a);switch(this.data.typeCode){case"0":-1==n?(e.selectItems.push(a),e.answers[s].isSelect=!0):(e.answers[s].isSelect=!1,e.selectItems.splice(n,1));break;case"1":if(-1==n){e.selectItems=[],e.selectItems.push(a),e.answers[s].isSelect=!0;for(var o=0;o<e.answers.length;o++)s!=o&&(e.answers[o].isSelect=!1)}else e.answers[s].isSelect=!1,e.selectItems=[];break;case"2":-1==n?(e.selectItems.push(a),e.answers[s].isSelect=!0):(e.answers[s].isSelect=!1,e.selectItems.splice(n,1));break;case"3":if(-1==n){e.selectItems=[],e.selectItems.push(a),e.answers[s].isSelect=!0;for(o=0;o<e.answers.length;o++)s!=o&&(e.answers[o].isSelect=!1)}else e.answers[s].isSelect=!1,e.selectItems=[]}this.setData({answers:e.answers})},answerInput:function(t){e.inputAnswer=t.detail.value},countDown:function(){var e=this,t=e.data.countDownNum;e.data.timer=setInterval((function(){if(600==t)wx.showToast({title:"考试时间还剩10分钟，请尽快答题",icon:"none"}),t--,e.setData({countDownNum:t});else if(0==t)e.examStop(),clearInterval(e.data.timer);else{t--;var s=Math.floor(t/60),a=t%60;s=1==(s+="").length?"0"+s:s,a=1==(a+="").length?"0"+a:a,e.setData({countDownNum:t,countDownValue:s+":"+a})}}),1e3)},examStop:function(){switch(this.data.typeCode){case"0":wx.setStorageSync("unsurenessRecord",s);break;case"1":wx.setStorageSync("singleRecord",s);break;case"2":wx.setStorageSync("multipleRecord",s);break;case"3":wx.setStorageSync("checkRecord",s);break;case"4":wx.setStorageSync("completionRecord",s)}var e=getCurrentPages();e[e.length-2].setData({lastQuestionType:4}),wx.navigateBack({delta:1})}});
},{isPage:true,isComponent:true,currentFile:'pages/exam/exam.js'});require("pages/exam/exam.js");$gwx_XC_4=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_4 || [];
function gz$gwx_XC_4_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_4_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_4_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_4_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_4_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_4_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_4=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_4=true;
var x=['./pages/index/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_4_1()
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_4";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_4();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/index/index.wxml'] = [$gwx_XC_4, './pages/index/index.wxml'];else __wxAppCode__['pages/index/index.wxml'] = $gwx_XC_4( './pages/index/index.wxml' );
	;__wxRoute = "pages/index/index";__wxRouteBegin = true;__wxAppCurrentFile__="pages/index/index.js";define("pages/index/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var t,a=require("../../@babel/runtime/helpers/defineProperty"),n=require("../../config.js"),o=require("../../http.js"),e=getApp();Page((a(t={data:{hasUserInfo:!1,canIUse:wx.canIUse("button.open-type.getUserInfo"),avatarUrl:"../../images/logo.jpg",nickName:"未登录",bannerData:["../../images/home_img_banner.png"],bannerData2:["../../images/img_nothing.png"],noExam:!0,showModal:!1,examList:[],swiperCurrent:0,second:5,check:!1,isCheck:!1,noCheck:!0,compList:[{imgUrl:"https://cdn2.pluslegal.cn/zzb%2Fhome_footer_img_1.png"}]},showHint:function(){this.timer(),this.setData({showModal:!0})},hideModal:function(){this.setData({showModal:!1})},radiocon:function(t){var a=this.data.check;a=!a,this.setData({check:a})},timer:function(){var t=this;new Promise((function(a,n){var o=setInterval((function(){t.setData({second:t.data.second-1}),t.data.second<=0&&(t.setData({second:5,isCheck:!0,noCheck:!1}),a(o))}),800)})).then((function(t){clearInterval(t)}))},confirm:function(){this.data.check?(this.hideModal(),this.setData({isCheck:!1,noCheck:!0}),wx.navigateTo({url:"../notice/notice?type=1"})):wx.showToast({title:"请先阅读知情书并勾选",icon:"none",duration:2e3})},toLogin:function(){e.globalData.haslogin?wx.navigateTo({url:"../amend/amend?type=0"}):e.globalData.userInfo?wx.navigateTo({url:"/pages/login-default/login-default"}):wx.navigateTo({url:"../login/login"})},examRecord:function(){e.globalData.haslogin?wx.navigateTo({url:"../record/record"}):this.toLogin()},toRanking:function(){e.globalData.haslogin?wx.navigateTo({url:"../ranking/ranking"}):this.toLogin()},toRule:function(){e.globalData.haslogin?wx.navigateTo({url:"../rule/rule"}):this.toLogin()},toReview:function(){e.globalData.haslogin?wx.navigateTo({url:"../review/review"}):this.toLogin()},toExam:function(){e.globalData.haslogin?wx.navigateTo({url:"../notice/notice"}):this.toLogin()},swiperChange:function(t){this.setData({swiperCurrent:t.detail.current})},swipclick:function(){this.data.noExam||(e.globalData.haslogin?(wx.setStorageSync("examMsg",this.data.examList[this.data.swiperCurrent]),wx.navigateTo({url:"../notice/notice?type=1"})):this.toLogin())},toVote:function(t){var a=this.data.compList[0].code;wx.setStorageSync("compId",a),e.globalData.haslogin?wx.switchTab({url:"../vote/home/home?code="+a}):this.toLogin()}},"showHint",(function(){this.setData({showModal:!0})})),a(t,"preventTouchMove",(function(){})),a(t,"hideModal",(function(){this.setData({showModal:!1})})),a(t,"clickButton",(function(){this.hideModal()})),a(t,"onLoad",(function(){e.globalData.userInfo||(this.data.canIUse?e.userInfoReadyCallback=function(t){e.globalData.userInfo=t.userInfo,wx.setStorageSync("userInfo",t.userInfo)}:wx.getUserInfo({success:function(t){e.globalData.userInfo=t.userInfo,wx.setStorageSync("userInfo",t.userInfo)}}));var t=wx.getStorageSync("firstLaunch");console.log("firstLaunch",t),t?this.setData({showModal:!1}):(this.setData({showModal:!1}),wx.setStorageSync("firstLaunch",!0)),this.getBanners(),this.getExamList(),this.getComp();var a=wx.getStorageSync("haslogin");e.globalData.haslogin=a;var n=wx.getStorageSync("userInfo");a&&this.setData({avatarUrl:n.avatarUrl,nickName:n.nickName})})),a(t,"onShow",(function(){})),a(t,"onShareAppMessage",(function(){})),a(t,"getBanners",(function(){var t=this;o.request(n.banner,"GET",null,(function(a){if(null!=a.data){for(var n=[],o=0;o<a.data.length;o++)n.push(a.data[o].imgUrl);t.setData({bannerData:n})}}),(function(t){wx.showToast({title:t,icon:"none"})}))})),a(t,"getExamList",(function(){var t=this;o.request(n.getExamListIndex,"POST",{examTypes:[4],type:1},(function(a){if(null!=a.data&&a.data.length>0){t.setData({examList:a.data});for(var n=[],o=0;o<a.data.length;o++)n.push(a.data[o].themeUrl);t.setData({bannerData2:n,noExam:!1})}}),(function(t){wx.showToast({title:t,icon:"none"})}))})),a(t,"getComp",(function(){var t=this;o.request(n.getComp,"POST",{type:0},(function(a){null!=a.rows&&a.rows.length>0&&t.setData({compList:a.rows})}),(function(t){wx.showToast({title:t,icon:"none"})}))})),t));
},{isPage:true,isComponent:true,currentFile:'pages/index/index.js'});require("pages/index/index.js");$gwx_XC_5=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_5 || [];
function gz$gwx_XC_5_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_5_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_5_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_5_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_5_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_5_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_5=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_5=true;
var x=['./pages/loading/loading.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_5_1()
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_5";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_5();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/loading/loading.wxml'] = [$gwx_XC_5, './pages/loading/loading.wxml'];else __wxAppCode__['pages/loading/loading.wxml'] = $gwx_XC_5( './pages/loading/loading.wxml' );
	;__wxRoute = "pages/loading/loading";__wxRouteBegin = true;__wxAppCurrentFile__="pages/loading/loading.js";define("pages/loading/loading.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";require("../../config.js"),require("../../http.js");var e=getApp();Page({data:{typeStr:"加载题库",questionType:0},onLoad:function(e){var t=e.type,a=e.questionType,o="加载题库";if(0==t){switch(a){case"0":o="不定项选择题";break;case"1":o="单项选择题";break;case"2":o="多项选择题";break;case"3":o="判断题";break;case"4":o="填空题"}this.setData({typeStr:o}),wx.navigateTo({url:"../exam/exam?questionType="+a})}},onReady:function(){},onShow:function(){console.log("onShow lastQuestionType=",this.data.lastQuestionType);var t=this.data.lastQuestionType,a=parseInt(t)+1;console.log("curQuestionType",a);try{if(1==a){if(e.globalData.question.one)return this.setData({questionType:1,typeStr:"单项选择"}),void setTimeout((function(){wx.navigateTo({url:"../exam/exam?questionType=1"})}),500);a++}if(2==a){if(e.globalData.question.two)return this.setData({questionType:2,typeStr:"多项选择"}),void setTimeout((function(){wx.navigateTo({url:"../exam/exam?questionType=2"})}),500);a++}if(3==a){if(e.globalData.question.three)return this.setData({questionType:3,typeStr:"判断题"}),void setTimeout((function(){wx.navigateTo({url:"../exam/exam?questionType=3"})}),500);a++}if(4==a){if(e.globalData.question.four)return this.setData({questionType:4,typeStr:"填空题"}),void setTimeout((function(){wx.navigateTo({url:"../exam/exam?questionType=4"})}),500);a++}return void(a>4&&(this.setData({typeStr:"正在计算成绩..."}),this.calculateGrade(),setTimeout((function(){wx.redirectTo({url:"../exam-result/exam-result?type=1"})}),2e3)))}catch(e){}},onHide:function(){},onUnload:function(){},calculateGrade:function(){var t=0,a=0,o=0,r=0,n=0,s=[],i=[],c=[],l=[],u=[],g=wx.getStorageSync("examPaper");if(e.globalData.question.zero){var f=wx.getStorageSync("unsurenessRecord");if(f)for(var p=0;p<f.length;p++){var v=f[p];if(v.correctCount==v.selectItems.length){for(var y=0,h=0;h<v.answers.length;h++){var m=v.answers[h];1==m.correct&&m.isSelect&&y++}y==v.correctCount&&(t+=g.unsurenessPoint)}var w={},x=v.id,d=v.selectItems;w[x]=d,s.push(w)}}if(e.globalData.question.one){var S=wx.getStorageSync("singleRecord");if(S)for(var T=0;T<S.length;T++){for(var q=S[T],b=0;b<q.answers.length;b++){var D=q.answers[b];if(1==D.correct){D.isSelect&&(a+=g.singlePoint);break}}w={},x=q.id,d=q.selectItems;w[x]=d,i.push(w)}}if(e.globalData.question.two){var k=wx.getStorageSync("multipleRecord");if(k)for(var I=0;I<k.length;I++){var A=k[I];if(A.correctCount==A.selectItems.length){for(var R=0,P=0;P<A.answers.length;P++){var C=A.answers[P];1==C.correct&&C.isSelect&&R++}R==A.correctCount&&(o+=g.multiplePoint)}w={},x=A.id,d=A.selectItems;w[x]=d,c.push(w)}}if(e.globalData.question.three){var Q=wx.getStorageSync("checkRecord");if(Q)for(var j=0;j<Q.length;j++){for(var z=Q[j],G=0;G<z.answers.length;G++){var H=z.answers[G];if(1==H.correct){H.isSelect&&(r+=g.checkPoint);break}}w={},x=z.id,d=z.selectItems;w[x]=d,l.push(w)}}if(e.globalData.question.four){var L=wx.getStorageSync("completionRecord");if(L)for(var U=0;U<L.length;U++){var _=L[U];_.inputAnswer==_.answers[0].correct_content&&(n+=g.completionPoint);w={},x=_.id;_.selectItems.push(_.inputAnswer);d=_.selectItems;w[x]=d,u.push(w)}}var B=t+a+o+r+n;e.globalData.score={zero:t,one:a,two:o,three:r,four:n,total:B};var E={unsurenessArray:s,singleArray:i,multipleArray:c,checkArray:l,completionArray:u};wx.setStorageSync("examRecord",E),console.log("examRecord",E),console.log("app.globalData.score",e.globalData.score)}});
},{isPage:true,isComponent:true,currentFile:'pages/loading/loading.js'});require("pages/loading/loading.js");$gwx_XC_6=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_6 || [];
function gz$gwx_XC_6_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_6_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_6_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_6_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_6_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_6_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_6=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_6=true;
var x=['./pages/login-default/login-default.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_6_1()
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_6";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_6();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/login-default/login-default.wxml'] = [$gwx_XC_6, './pages/login-default/login-default.wxml'];else __wxAppCode__['pages/login-default/login-default.wxml'] = $gwx_XC_6( './pages/login-default/login-default.wxml' );
	;__wxRoute = "pages/login-default/login-default";__wxRouteBegin = true;__wxAppCurrentFile__="pages/login-default/login-default.js";define("pages/login-default/login-default.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var t=require("../../config.js"),n=require("../../http.js"),e=getApp();Page({data:{tel:""},onLoad:function(t){},onReady:function(){},onShow:function(){},onHide:function(){},onUnload:function(){},cancel:function(){wx.navigateBack({delta:3})},tellogin:function(){wx.redirectTo({url:"../tellogin/tellogin"})},getPhoneNumber:function(e){var a=this;e.detail.encryptedData&&n.request(t.tel,"POST",{encryptedData:e.detail.encryptedData,iv:e.detail.iv},(function(t){null!=t.data&&(a.setData({tel:t.data}),a.wxdl())}),(function(t){wx.showToast({title:t,icon:"none"})}))},wxdl:function(){var a=this;n.request(t.wxdl,"POST",null,(function(t){null!=t.data?(e.globalData.userMsg=t.data,e.globalData.haslogin=!0,wx.setStorageSync("userMsg",t.data),wx.setStorageSync("haslogin",!0),wx.reLaunch({url:"../index/index"})):wx.redirectTo({url:"../usermsg/usermsg?phone="+a.data.tel})}),(function(t){wx.showToast({title:t,icon:"none"})}))}});
},{isPage:true,isComponent:true,currentFile:'pages/login-default/login-default.js'});require("pages/login-default/login-default.js");$gwx_XC_7=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_7 || [];
function gz$gwx_XC_7_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_7_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_7_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_7_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[2,'!'],[[7],[3,'hasUserInfo']]])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_7_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_7_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_7=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_7=true;
var x=['./pages/login/login.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_7_1()
var lY=_v()
_(r,lY)
if(_oz(z,0,e,s,gg)){lY.wxVkey=1
}
lY.wxXCkey=1
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_7";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_7();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/login/login.wxml'] = [$gwx_XC_7, './pages/login/login.wxml'];else __wxAppCode__['pages/login/login.wxml'] = $gwx_XC_7( './pages/login/login.wxml' );
	;__wxRoute = "pages/login/login";__wxRouteBegin = true;__wxAppCurrentFile__="pages/login/login.js";define("pages/login/login.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var e=getApp();Page({data:{userInfo:{},hasUserInfo:!1,canIUseGetUserProfile:!1},getUserProfile:function(n){var o=this;wx.getSetting({success:function(n){wx.getUserProfile({desc:"用于完善资料",success:function(n){n.userInfo?(o.setData({userInfo:n.userInfo,hasUserInfo:!0}),wx.setStorageSync("userInfo",n.userInfo),e.globalData.userInfo=n.userInfo,wx.navigateTo({url:"../login-default/login-default"})):wx.navigateBack({delta:1})}})}})},getUserInfo:function(n){console.log("getUserInfo",n),n.detail.userInfo?(wx.setStorageSync("userInfo",n.detail.userInfo),e.globalData.userInfo=n.detail.userInfo,wx.navigateTo({url:"../login-default/login-default"})):wx.navigateBack({delta:1})},noAllow:function(){wx.navigateBack({delta:1})},onLoad:function(e){wx.getUserProfile&&this.setData({canIUseGetUserProfile:!0})},onReady:function(){},onShow:function(){},onHide:function(){},onUnload:function(){}});
},{isPage:true,isComponent:true,currentFile:'pages/login/login.js'});require("pages/login/login.js");$gwx_XC_8=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_8 || [];
function gz$gwx_XC_8_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_8_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_8_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_8_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_8_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_8_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_8=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_8=true;
var x=['./pages/logs/logs.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_8_1()
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_8";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_8();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/logs/logs.wxml'] = [$gwx_XC_8, './pages/logs/logs.wxml'];else __wxAppCode__['pages/logs/logs.wxml'] = $gwx_XC_8( './pages/logs/logs.wxml' );
	;__wxRoute = "pages/logs/logs";__wxRouteBegin = true;__wxAppCurrentFile__="pages/logs/logs.js";define("pages/logs/logs.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var t=require("../../utils/util.js");Page({data:{logs:[]},onLoad:function(){this.setData({logs:(wx.getStorageSync("logs")||[]).map((function(a){return t.formatTime(new Date(a))}))})}});
},{isPage:true,isComponent:true,currentFile:'pages/logs/logs.js'});require("pages/logs/logs.js");$gwx_XC_9=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_9 || [];
function gz$gwx_XC_9_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_9_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_9_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_9_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container4'])
Z([[2,'=='],[[7],[3,'type']],[1,1]])
Z([[2,'=='],[[7],[3,'type']],[1,2]])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_9_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_9_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_9=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_9=true;
var x=['./pages/notice/notice.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_9_1()
var e2=_n('view')
_rz(z,e2,'class',0,e,s,gg)
var b3=_v()
_(e2,b3)
if(_oz(z,1,e,s,gg)){b3.wxVkey=1
}
var o4=_v()
_(e2,o4)
if(_oz(z,2,e,s,gg)){o4.wxVkey=1
}
b3.wxXCkey=1
o4.wxXCkey=1
_(r,e2)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_9";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_9();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/notice/notice.wxml'] = [$gwx_XC_9, './pages/notice/notice.wxml'];else __wxAppCode__['pages/notice/notice.wxml'] = $gwx_XC_9( './pages/notice/notice.wxml' );
	;__wxRoute = "pages/notice/notice";__wxRouteBegin = true;__wxAppCurrentFile__="pages/notice/notice.js";define("pages/notice/notice.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var e=require("../../config.js"),t=require("../../http.js"),a=getApp();Page({data:{type:0,stCode:-1,can:!1},onLoad:function(e){var t=e.type;if(this.setData({type:t}),1==t){var n=wx.getStorageSync("examMsg"),o=(new Date).getTime(),s=n.startTime.replace(/-/g,"/"),i=new Date(s).getTime(),l=n.endTime.replace(/-/g,"/"),u=new Date(l).getTime();o>i&&o<u?this.setData({can:!0}):this.setData({can:!1}),this.setData({examMsg:n}),a.globalData.examTitle={name:n.theme,start:n.startTime,end:n.endTime}}else{var c=wx.getStorageSync("examMsgReview");this.setData({examMsg:c}),a.globalData.examTitle={name:c.theme,start:c.startTime,end:c.endTime}}},onReady:function(){},onShow:function(){wx.removeStorageSync("unsurenessRecord"),wx.removeStorageSync("singleRecord"),wx.removeStorageSync("multipleRecord"),wx.removeStorageSync("checkRecord"),wx.removeStorageSync("completionRecord"),wx.removeStorageSync("examRecord")},onHide:function(){},onUnload:function(){},beginExam:function(){if(wx.setStorageSync("countDownNum",60*this.data.examMsg.duration),this.data.can){t.request(e.beginExam,"POST",{examId:this.data.examMsg.id},(function(e){if(null!=e.data){null!=e.data.unsurenessQuestions&&e.data.unsurenessQuestions.length>0?(a.globalData.question.zero=!0,wx.setStorageSync("unsurenessQuestions",e.data.unsurenessQuestions)):(a.globalData.question.zero=!1,wx.removeStorageSync("unsurenessQuestions")),null!=e.data.singleQuestions&&e.data.singleQuestions.length>0?(a.globalData.question.one=!0,wx.setStorageSync("singleQuestions",e.data.singleQuestions)):(a.globalData.question.one=!1,wx.removeStorageSync("singleQuestions")),null!=e.data.multipleQuestions&&e.data.multipleQuestions.length>0?(a.globalData.question.two=!0,wx.setStorageSync("multipleQuestions",e.data.multipleQuestions)):(a.globalData.question.two=!1,wx.removeStorageSync("multipleQuestions")),null!=e.data.checkQuestions&&e.data.checkQuestions.length>0?(a.globalData.question.three=!0,wx.setStorageSync("checkQuestions",e.data.checkQuestions)):(a.globalData.question.three=!1,wx.removeStorageSync("checkQuestions")),null!=e.data.completionQuestions&&e.data.completionQuestions.length>0?(a.globalData.question.four=!0,wx.setStorageSync("completionQuestions",e.data.completionQuestions)):(a.globalData.question.four=!1,wx.removeStorageSync("completionQuestions"));var t={checkCount:e.data.checkCount,checkPoint:e.data.checkPoint,checkTotalPoint:e.data.checkTotalPoint,completionCount:e.data.completionCount,completionPoint:e.data.completionPoint,completionTotalPoint:e.data.completionTotalPoint,multipleCount:e.data.multipleCount,multiplePoint:e.data.multiplePoint,multipleTotalPoint:e.data.multipleTotalPoint,unsurenessCount:e.data.unsurenessCount,unsurenessPoint:e.data.unsurenessPoint,unsurenessTotalPoint:e.data.unsurenessTotalPoint,singleCount:e.data.singleCount,singlePoint:e.data.singlePoint,singleTotalPoint:e.data.singleTotalPoint,qualifiedPoint:e.data.qualifiedPoint,totalPoint:e.data.totalPoint};wx.setStorageSync("examPaper",t),wx.navigateTo({url:"../amend/amend?type=1"})}}),(function(e){wx.showToast({title:e,icon:"none"})}),!0)}else wx.showToast({title:"未在考试规定时间范围内，不能参加考试",icon:"none"})},lookExam:function(){wx.navigateTo({url:"../test-paper/test-paper?type=1&examId="+this.data.examMsg.id})}});
},{isPage:true,isComponent:true,currentFile:'pages/notice/notice.js'});require("pages/notice/notice.js");$gwx_XC_10=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_10 || [];
function gz$gwx_XC_10_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_10_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_10_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_10_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'noData']])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_10_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_10_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_10=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_10=true;
var x=['./pages/ranking/ranking.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_10_1()
var o6=_v()
_(r,o6)
if(_oz(z,0,e,s,gg)){o6.wxVkey=1
}
o6.wxXCkey=1
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_10";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_10();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/ranking/ranking.wxml'] = [$gwx_XC_10, './pages/ranking/ranking.wxml'];else __wxAppCode__['pages/ranking/ranking.wxml'] = $gwx_XC_10( './pages/ranking/ranking.wxml' );
	;__wxRoute = "pages/ranking/ranking";__wxRouteBegin = true;__wxAppCurrentFile__="pages/ranking/ranking.js";define("pages/ranking/ranking.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var a=require("../../config.js"),n=require("../../http.js"),t=1;Page({data:{userRank:{rank:"无",total:"无"},noData:!0},areaRank:function(){wx.navigateTo({url:"../area-rank/area-rank"})},loadMoreData:function(){t++,this.getAllRank(t)},onLoad:function(a){t=1,this.getAllRank(t),this.getMyRank()},onReady:function(){},onShow:function(){},onHide:function(){},onUnload:function(){},getAllRank:function(t){var o=this;n.request(a.allRank,"GET",{page:t,pageSize:20},(function(a){null!=a&&(t>1?o.setData({rankData:o.data.rankData.concat(a)}):(o.setData({rankData:a}),a.length>0?o.setData({noData:!1}):o.setData({noData:!0})))}),(function(a){wx.showToast({title:a,icon:"none"})}))},getMyRank:function(){var t=this;n.request(a.myRank,"GET",null,(function(a){null!=a&&""!=a&&t.setData({userRank:a})}),(function(a){wx.showToast({title:a,icon:"none"})}))}});
},{isPage:true,isComponent:true,currentFile:'pages/ranking/ranking.js'});require("pages/ranking/ranking.js");$gwx_XC_11=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_11 || [];
function gz$gwx_XC_11_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_11_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_11_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_11_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_11_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_11_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_11=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_11=true;
var x=['./pages/record/record.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_11_1()
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_11";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_11();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/record/record.wxml'] = [$gwx_XC_11, './pages/record/record.wxml'];else __wxAppCode__['pages/record/record.wxml'] = $gwx_XC_11( './pages/record/record.wxml' );
	;__wxRoute = "pages/record/record";__wxRouteBegin = true;__wxAppCurrentFile__="pages/record/record.js";define("pages/record/record.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var t=require("../../config.js"),e=require("../../http.js");Page({data:{recordData:null,recordList:[]},lookDetail:function(t){var e=t.currentTarget.dataset.pos;wx.setStorageSync("testRecord",this.data.recordList[e]),wx.navigateTo({url:"../exam-result/exam-result?type=2"})},onLoad:function(t){this.getAllRecords()},onReady:function(){},onShow:function(){},onHide:function(){},onUnload:function(){},getAllRecords:function(){var o=this;e.request(t.allRecords,"POST",null,(function(t){null!=t.data&&o.setData({recordData:t.data,recordList:t.data.records})}),(function(t){wx.showToast({title:t,icon:"none"})}))}});
},{isPage:true,isComponent:true,currentFile:'pages/record/record.js'});require("pages/record/record.js");$gwx_XC_12=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_12 || [];
function gz$gwx_XC_12_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_12_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_12_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_12_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[2,'!'],[[7],[3,'haveData']]])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_12_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_12_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_12=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_12=true;
var x=['./pages/review/review.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_12_1()
var h9=_v()
_(r,h9)
if(_oz(z,0,e,s,gg)){h9.wxVkey=1
}
h9.wxXCkey=1
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_12";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_12();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/review/review.wxml'] = [$gwx_XC_12, './pages/review/review.wxml'];else __wxAppCode__['pages/review/review.wxml'] = $gwx_XC_12( './pages/review/review.wxml' );
	;__wxRoute = "pages/review/review";__wxRouteBegin = true;__wxAppCurrentFile__="pages/review/review.js";define("pages/review/review.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var t=require("../../config.js"),a=require("../../http.js");Page({data:{year:2020,reviewList:[1],haveData:!1},itemClick:function(t){if(this.data.haveData){var a=t.currentTarget.dataset.pos;wx.setStorageSync("examMsgReview",this.data.reviewList[a]),wx.navigateTo({url:"../notice/notice?type=2"})}},onLoad:function(t){var a=(new Date).getFullYear();this.setData({year:a}),this.getExamList()},onReady:function(){},onShow:function(){},onHide:function(){},onUnload:function(){},getExamList:function(){var e=this;a.request(t.getExamList,"POST",{type:2},(function(t){null!=t.data&&t.data.length>0&&e.setData({reviewList:t.data,haveData:!0})}),(function(t){wx.showToast({title:t,icon:"none"})}))}});
},{isPage:true,isComponent:true,currentFile:'pages/review/review.js'});require("pages/review/review.js");$gwx_XC_13=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_13 || [];
function gz$gwx_XC_13_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_13_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_13_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_13_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_13_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_13_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_13=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_13=true;
var x=['./pages/rule/rule.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_13_1()
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_13";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_13();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/rule/rule.wxml'] = [$gwx_XC_13, './pages/rule/rule.wxml'];else __wxAppCode__['pages/rule/rule.wxml'] = $gwx_XC_13( './pages/rule/rule.wxml' );
	;__wxRoute = "pages/rule/rule";__wxRouteBegin = true;__wxAppCurrentFile__="pages/rule/rule.js";define("pages/rule/rule.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";Page({data:{},onLoad:function(n){},onReady:function(){},onShow:function(){},onHide:function(){},onUnload:function(){}});
},{isPage:true,isComponent:true,currentFile:'pages/rule/rule.js'});require("pages/rule/rule.js");$gwx_XC_14=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_14 || [];
function gz$gwx_XC_14_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_14_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_14_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_14_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'isSend']])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_14_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_14_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_14=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_14=true;
var x=['./pages/tellogin/tellogin.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_14_1()
var oBB=_v()
_(r,oBB)
if(_oz(z,0,e,s,gg)){oBB.wxVkey=1
}
oBB.wxXCkey=1
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_14";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_14();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/tellogin/tellogin.wxml'] = [$gwx_XC_14, './pages/tellogin/tellogin.wxml'];else __wxAppCode__['pages/tellogin/tellogin.wxml'] = $gwx_XC_14( './pages/tellogin/tellogin.wxml' );
	;__wxRoute = "pages/tellogin/tellogin";__wxRouteBegin = true;__wxAppCurrentFile__="pages/tellogin/tellogin.js";define("pages/tellogin/tellogin.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var t=require("../../config.js"),e=require("../../http.js"),n=getApp(),o=/^[1][3,4,5,6,7,8][0-9]{9}$/;Page({data:{isSend:!1,isFocus:!1,tel:"",msgCode:[]},onLoad:function(t){},onReady:function(){},onShow:function(){},onHide:function(){},onUnload:function(){},sendCode:function(){this.data.canSend&&this.sendCodeMsg()},telInput:function(t){this.setData({tel:t.detail.value}),o.test(t.detail.value)?this.setData({canSend:!0}):this.setData({canSend:!1})},numberClick:function(){this.setData({isFocus:!0})},numberInput:function(t){this.setData({tmpValue:t.detail.value,msgCode:t.detail.value.split("")}),4==this.data.msgCode.length&&this.verifyCode()},sendAgain:function(){this.setData({msgCode:[],tmpValue:""}),this.sendCodeMsg()},sendCodeMsg:function(){var n=this;e.request(t.vcode,"POST",{phoneNumber:this.data.tel},(function(t){200==t.stCode||401==t.stCode?(n.setData({isSend:!0}),wx.showToast({title:"验证码已发送",icon:"none"})):wx.showToast({title:"验证码发送失败",icon:"none"})}),(function(t){wx.showToast({title:"验证码发送失败",icon:"none"})}))},verifyCode:function(){var o=this;e.request(t.verify,"POST",{vcode:this.data.tmpValue},(function(t){0==t.stCode&&(null!=t.data?(n.globalData.userMsg=t.data,n.globalData.haslogin=!0,wx.setStorageSync("userMsg",t.data),wx.setStorageSync("haslogin",!0),wx.reLaunch({url:"../index/index"})):wx.redirectTo({url:"../usermsg/usermsg?phone="+o.data.tel})),402==t.stCode&&wx.showToast({title:"验证码已过期，请重新发送",icon:"none"}),403==t.stCode&&wx.showToast({title:"验证码错误",icon:"none"})}),(function(t){wx.showToast({title:"验证失败",icon:"none"})}),!0)}});
},{isPage:true,isComponent:true,currentFile:'pages/tellogin/tellogin.js'});require("pages/tellogin/tellogin.js");$gwx_XC_15=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_15 || [];
function gz$gwx_XC_15_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_15_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_15_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_15_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_15_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_15_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_15=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_15=true;
var x=['./pages/test-paper/test-paper.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_15_1()
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_15";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_15();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/test-paper/test-paper.wxml'] = [$gwx_XC_15, './pages/test-paper/test-paper.wxml'];else __wxAppCode__['pages/test-paper/test-paper.wxml'] = $gwx_XC_15( './pages/test-paper/test-paper.wxml' );
	;__wxRoute = "pages/test-paper/test-paper";__wxRouteBegin = true;__wxAppCurrentFile__="pages/test-paper/test-paper.js";define("pages/test-paper/test-paper.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var t=require("../../config.js"),e=require("../../http.js"),a=getApp();Page({data:{examList:[]},onLoad:function(t){var e=t.type;this.setData({titleMsg:a.globalData.examTitle}),1==e?this.getReportWithExamId(t.examId):this.getReportWithRecordId(t.examId,t.recordId)},onReady:function(){},onShow:function(){},onHide:function(){},onUnload:function(){},getReportWithExamId:function(a){var n=this;e.request(t.examReview,"POST",{examId:a},(function(t){null!=t.data&&t.data.length>0?n.setData({size:t.data.length,examList:t.data}):wx.showToast({title:"没有记录",icon:"none"})}),(function(t){wx.showToast({title:t,icon:"none"})}))},getReportWithRecordId:function(a,n){var o=this;e.request(t.recordReport,"POST",{examId:a,recordId:n},(function(t){null!=t.data&&t.data.length>0?o.setData({size:t.data.length,examList:t.data}):wx.showToast({title:"没有记录",icon:"none"})}),(function(t){wx.showToast({title:t,icon:"none"})}))}});
},{isPage:true,isComponent:true,currentFile:'pages/test-paper/test-paper.js'});require("pages/test-paper/test-paper.js");$gwx_XC_16=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_16 || [];
function gz$gwx_XC_16_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_16_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_16_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_16_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_16_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_16_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_16=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_16=true;
var x=['./pages/usermsg/usermsg.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_16_1()
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_16";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_16();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/usermsg/usermsg.wxml'] = [$gwx_XC_16, './pages/usermsg/usermsg.wxml'];else __wxAppCode__['pages/usermsg/usermsg.wxml'] = $gwx_XC_16( './pages/usermsg/usermsg.wxml' );
	;__wxRoute = "pages/usermsg/usermsg";__wxRouteBegin = true;__wxAppCurrentFile__="pages/usermsg/usermsg.js";define("pages/usermsg/usermsg.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var t=require("../../@babel/runtime/helpers/toArray"),a=require("../../config.js"),i=require("../../http.js"),e=getApp();Page({data:{array:[],index:0,default:" 请选择",multidefault:"请选择",formType:"",typedefault:"请选择",name:"",area:"",unit:"",zhiwu:"请选择",type:"",phone:"",rawData:[],multiObjArray:[[],[],[]],multiIndex:[0,0,0]},onLoad:function(t){this.setData({phone:t.phone}),wx.setStorageSync("phone",this.data.phone),this.getzzjg()},onReady:function(){},onShow:function(){var t=wx.getStorageSync("userMsg");t&&this.setData({userMsg:t})},getzzjg:function(){var t=this;i.request(a.zzjg,"get",null,(function(a){if(a.rows){var i=a.rows;t.setData({array:JSON.parse(i.zhiji),rawData:JSON.parse(i.zzjg)});var e=function t(){for(var a=arguments.length>0&&void 0!==arguments[0]?arguments[0]:[],i=[],e=function(e){var n=a[e];"string"==typeof n?i.push({name:n}):Object.keys(n).forEach((function(a){var e={};e.name=a;var s=n[a];Array.isArray(s)&&s.length>0&&(e.list=t(s)),i.push(e)}))},n=0;n<a.length;n++)e(n);return i}(t.data.rawData);t.setData({rawData:e,"multiObjArray[0]":e,"multiObjArray[1]":e[0].list,"multiObjArray[2]":e[0].list[0].list})}}),(function(t){wx.showToast({title:t,icon:"none"})}),!0)},onHide:function(){},onUnload:function(){},nameInput:function(t){this.setData({name:t.detail.value})},unitInput:function(t){this.setData({unit:t.detail.value})},bindPickerChange:function(t){var a=t.detail.value,i=this.data.array;this.setData({index:a,default:i[a]});var e=this.data.array[this.data.index];this.setData({zhiwu:e})},bindTypeChange:function(t){this.setData({typeIndex:t.detail.value})},bindMultiPickerChange:function(t){var a=t.detail.value;this.setData({multiIndex:a,multidefault:this.data.multiObjArray[0][a[0]].name+" "+this.data.multiObjArray[1][a[1]].name+" "+this.data.multiObjArray[2][a[2]].name}),console.log("====>",this.data.multidefault)},bindMultiPickerColumnChange:function(a){var i=t(this.data.multiIndex).slice(0);i[a.detail.column]=a.detail.value,0===a.detail.column&&(i[2]=0);var e=this.data.rawData[i[0]].list;this.setData({"multiObjArray[1]":e,"multiObjArray[2]":e[i[1]].list,multiIndex:i})},makeSure:function(){""!=this.data.name?""!=this.data.multidefault&&"请选择"!=this.data.multidefault?""!=this.data.zhiwu&&"请选择"!=this.data.zhiwu?this.submitUserInfo():wx.showToast({title:"职务不能为空",icon:"none"}):wx.showToast({title:"所在地不能为空",icon:"none"}):wx.showToast({title:"姓名不能为空",icon:"none"})},submitUserInfo:function(){i.request(a.reg,"POST",{name:this.data.name,area:this.data.multidefault,unit:this.data.unit,zhiwu:this.data.zhiwu,phone:this.data.phone},(function(t){null!=t.data&&(e.globalData.userMsg=t.data,e.globalData.haslogin=!0,wx.setStorageSync("userMsg",t.data),wx.setStorageSync("haslogin",!0),wx.reLaunch({url:"../index/index"}))}),(function(t){wx.showToast({title:t,icon:"none"})}))}});
},{isPage:true,isComponent:true,currentFile:'pages/usermsg/usermsg.js'});require("pages/usermsg/usermsg.js");$gwx_XC_17=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_17 || [];
function gz$gwx_XC_17_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_17_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_17_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_17_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'playArea'])
Z([[6],[[7],[3,'comp']],[3,'videoUrl']])
Z([1,false])
Z([3,'videoBox'])
Z(z[1])
Z(z[1])
Z([[6],[[7],[3,'comp']],[3,'audioUrl']])
Z([[6],[[7],[3,'comp']],[3,'imgUrl']])
Z([[7],[3,'ArticleList']])
Z([3,'index'])
Z([3,'infoContentStyle'])
Z([[2,'?:'],[[2,'=='],[[6],[[7],[3,'item']],[3,'type']],[1,'rich-text']],[1,true],[1,false]])
Z([[2,'?:'],[[2,'&&'],[[2,'=='],[[6],[[7],[3,'item']],[3,'type']],[1,'video']],[[2,'!='],[[6],[[7],[3,'item']],[3,'value']],[1,'']]],[1,true],[1,false]])
Z([3,'btn'])
Z([[2,'=='],[[7],[3,'stu']],[1,2]])
Z([[2,'=='],[[7],[3,'stu']],[1,1]])
Z([[2,'=='],[[7],[3,'stu']],[1,0]])
Z([[7],[3,'showModal']])
Z([3,'preventTouchMove'])
Z([3,'modal-mask'])
Z(z[17])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_17_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_17_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_17=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_17=true;
var x=['./pages/vote/details/details.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_17_1()
var bGB=_n('view')
var oHB=_n('view')
_rz(z,oHB,'class',0,e,s,gg)
var xIB=_v()
_(oHB,xIB)
if(_oz(z,1,e,s,gg)){xIB.wxVkey=1
var cLB=_mz(z,'txv-video',['autoplay',2,'class',1,'playerid',2,'vid',3],[],e,s,gg)
_(xIB,cLB)
}
var oJB=_v()
_(oHB,oJB)
if(_oz(z,6,e,s,gg)){oJB.wxVkey=1
}
var fKB=_v()
_(oHB,fKB)
if(_oz(z,7,e,s,gg)){fKB.wxVkey=1
}
xIB.wxXCkey=1
xIB.wxXCkey=3
oJB.wxXCkey=1
fKB.wxXCkey=1
_(bGB,oHB)
var hMB=_v()
_(bGB,hMB)
var oNB=function(oPB,cOB,lQB,gg){
var tSB=_n('view')
_rz(z,tSB,'class',10,oPB,cOB,gg)
var eTB=_v()
_(tSB,eTB)
if(_oz(z,11,oPB,cOB,gg)){eTB.wxVkey=1
}
var bUB=_v()
_(tSB,bUB)
if(_oz(z,12,oPB,cOB,gg)){bUB.wxVkey=1
}
eTB.wxXCkey=1
bUB.wxXCkey=1
_(lQB,tSB)
return lQB
}
hMB.wxXCkey=2
_2z(z,8,oNB,e,s,gg,hMB,'item','index','index')
var oVB=_n('view')
_rz(z,oVB,'class',13,e,s,gg)
var xWB=_v()
_(oVB,xWB)
if(_oz(z,14,e,s,gg)){xWB.wxVkey=1
}
var oXB=_v()
_(oVB,oXB)
if(_oz(z,15,e,s,gg)){oXB.wxVkey=1
}
var fYB=_v()
_(oVB,fYB)
if(_oz(z,16,e,s,gg)){fYB.wxVkey=1
}
xWB.wxXCkey=1
oXB.wxXCkey=1
fYB.wxXCkey=1
_(bGB,oVB)
_(r,bGB)
var eFB=_v()
_(r,eFB)
if(_oz(z,17,e,s,gg)){eFB.wxVkey=1
var cZB=_mz(z,'view',['catchtouchmove',18,'class',1],[],e,s,gg)
var h1B=_v()
_(cZB,h1B)
if(_oz(z,20,e,s,gg)){h1B.wxVkey=1
}
h1B.wxXCkey=1
_(eFB,cZB)
}
eFB.wxXCkey=1
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_17";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_17();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/vote/details/details.wxml'] = [$gwx_XC_17, './pages/vote/details/details.wxml'];else __wxAppCode__['pages/vote/details/details.wxml'] = $gwx_XC_17( './pages/vote/details/details.wxml' );
	;__wxRoute = "pages/vote/details/details";__wxRouteBegin = true;__wxAppCurrentFile__="pages/vote/details/details.js";define("pages/vote/details/details.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var t=require("../../../config.js"),e=require("../../../http.js");Page({data:{item:["https://cdn.pluslegal.cn/xxzzb%2Fhome_img_banner%402x.png"],showModal:!1,compId:"",code:"",vcode:"",vcodes:"",content:"",imgUrl:"http://eae.mini.kaililaw.com",ArticleList:[]},onLoad:function(t){var e=t.compId,o=t.code;this.setData({compId:e,code:o}),this.getDetail(),this.getCompDetail()},getDetail:function(){var o=this;e.request(t.getCaDetail,"POST",{code:o.data.compId},(function(t){if(null!=t.rows){o.setData({comp:t.rows,content:t.rows.content,poll:t.rows.poll});var e=o.data.content.replace(/(\<img|\<p)/gi,(function(t,e){return{"<img":'<img style="width:100%;height:auto;display:block;"margin:30rpx 0; ',"<p":'<p class="txt" style="color:#333;text-align:justify" padding:20rpx;line-height ',"<article":"<div","</article":"</div","<header":"<div","</header":"</div"}[e]})),a=[],i=/src=[\'\"]?([^\'\"]*)[\'\"]?/i,n=e.match(/<video.*?(?:>|\/>)/gi)||[],s=e.split("</video>");n.forEach((function(t,e){var o=t.match(i);a.push(o[1])}));var c=[];s.forEach((function(t,e){""!=t&&null!=t&&c.push({type:"rich-text",value:t+"</video>"}),e<s.length&&null!=a[e]&&c.push({type:"video",value:a[e]})})),o.setData({ArticleList:c})}}),(function(t){wx.showToast({title:t,icon:"none"})}))},getCompDetail:function(){var o=this;e.request(t.getCompDetail,"POST",{code:o.data.code},(function(t){if(null!=t.rows){o.setData({comps:t.rows,startTime:t.rows.startTime,endTime:t.rows.endTime});var e=o.getFormatDate();e<o.data.startTime&&o.setData({stu:1}),e>o.data.endTime&&o.setData({stu:0}),e>o.data.startTime&&e<o.data.endTime&&o.setData({stu:2})}}),(function(t){wx.showToast({title:t,icon:"none"})}))},getFormatDate:function(){var t=new Date;return t.getFullYear()+"-"+(t.getMonth()+1<10?"0"+(t.getMonth()+1):t.getMonth()+1)+"-"+(t.getDate()<10?"0"+t.getDate():t.getDate())+" "+(t.getHours()<10?"0"+t.getHours():t.getHours())+":"+(t.getMinutes()<10?"0"+t.getMinutes():t.getMinutes())+":"+(t.getSeconds()<10?"0"+t.getSeconds():t.getSeconds())},showHint:function(){this.setData({showModal:!0})},hideModal:function(){this.setData({showModal:!1})},toVote:function(){this.vote()},confirm:function(t){this.data.vcode.toLowerCase()==this.data.vcodes.toLowerCase()?(this.hideModal(),this.vote()):wx.showToast({title:"验证码输入有误！",icon:"none"})},codeInput:function(t){var e=t.detail.value;this.setData({vcode:e})},vote:function(){var o=this;e.request(t.vote,"POST",{campcode:o.data.code,candicode:o.data.compId,vcode:o.data.vcode},(function(t){0==t.success&&(wx.showToast({title:"投票成功！",icon:"success"}),o.setData({poll:t.rows.poll}))}),(function(t){"活动已结束"==t?(wx.showToast({title:t,icon:"none"}),o.hideModal()):(o.setData({vcodes:t}),o.showHint())}))},onReady:function(){},onShow:function(){},onHide:function(){},onUnload:function(){},onPullDownRefresh:function(){},onReachBottom:function(){},onShareAppMessage:function(){return{title:"2022年护航二十大，普法新征程 投票活动开始啦",desc:"2022年护航二十大，普法新征程 投票活动开始啦!",url:"../details/details?compId="+this.data.compId+"&code="+this.data.code}}});
},{isPage:true,isComponent:true,currentFile:'pages/vote/details/details.js'});require("pages/vote/details/details.js");$gwx_XC_18=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_18 || [];
function gz$gwx_XC_18_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_18_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_18_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_18_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'contents'])
Z([3,'info'])
Z([3,'status'])
Z([[2,'=='],[[7],[3,'stu']],[1,2]])
Z([[2,'=='],[[7],[3,'stu']],[1,1]])
Z([[2,'=='],[[7],[3,'stu']],[1,0]])
Z(z[3])
Z([[2,'>'],[[7],[3,'length']],[1,0]])
Z([3,'loadMore'])
Z([3,'videolist scrollview '])
Z([3,'true'])
Z([[7],[3,'complist']])
Z([3,'index'])
Z([[2,'>'],[[7],[3,'listLen']],[1,0]])
Z([3,'v-item'])
Z([3,'playArea'])
Z([[6],[[7],[3,'item']],[3,'videoUrl']])
Z(z[16])
Z([1,false])
Z([3,'bindplay'])
Z([3,'videoBox'])
Z(z[16])
Z([[2,'-'],[[7],[3,'data']],[[7],[3,'index']]])
Z([a,[3,'myVideo'],[[7],[3,'index']]])
Z([1,true])
Z(z[24])
Z(z[16])
Z(z[24])
Z(z[16])
Z([[6],[[7],[3,'item']],[3,'audioUrl']])
Z([[6],[[7],[3,'item']],[3,'imgUrl']])
Z([3,'btn'])
Z(z[3])
Z(z[4])
Z(z[5])
Z([[2,'<='],[[7],[3,'listLen']],[1,0]])
Z([[7],[3,'showModal']])
Z([3,'preventTouchMove'])
Z([3,'modal-mask'])
Z(z[36])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_18_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_18_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_18=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_18=true;
var x=['./pages/vote/home/home.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_18_1()
var o4B=_n('view')
_rz(z,o4B,'class',0,e,s,gg)
var a6B=_n('view')
_rz(z,a6B,'class',1,e,s,gg)
var e8B=_n('view')
_rz(z,e8B,'class',2,e,s,gg)
var b9B=_v()
_(e8B,b9B)
if(_oz(z,3,e,s,gg)){b9B.wxVkey=1
}
var o0B=_v()
_(e8B,o0B)
if(_oz(z,4,e,s,gg)){o0B.wxVkey=1
}
var xAC=_v()
_(e8B,xAC)
if(_oz(z,5,e,s,gg)){xAC.wxVkey=1
}
b9B.wxXCkey=1
o0B.wxXCkey=1
xAC.wxXCkey=1
_(a6B,e8B)
var t7B=_v()
_(a6B,t7B)
if(_oz(z,6,e,s,gg)){t7B.wxVkey=1
}
t7B.wxXCkey=1
_(o4B,a6B)
var l5B=_v()
_(o4B,l5B)
if(_oz(z,7,e,s,gg)){l5B.wxVkey=1
}
var oBC=_mz(z,'scroll-view',['bindscrolltolower',8,'class',1,'scrollY',2],[],e,s,gg)
var cDC=_v()
_(oBC,cDC)
var hEC=function(cGC,oFC,oHC,gg){
var aJC=_v()
_(oHC,aJC)
if(_oz(z,13,cGC,oFC,gg)){aJC.wxVkey=1
var tKC=_n('view')
_rz(z,tKC,'class',14,cGC,oFC,gg)
var eLC=_n('view')
_rz(z,eLC,'class',15,cGC,oFC,gg)
var bMC=_v()
_(eLC,bMC)
if(_oz(z,16,cGC,oFC,gg)){bMC.wxVkey=1
var oPC=_v()
_(bMC,oPC)
if(_oz(z,17,cGC,oFC,gg)){oPC.wxVkey=1
var fQC=_mz(z,'txv-video',['autoplay',18,'bindtap',1,'class',2,'data-id',3,'data-index',4,'id',5,'isHiddenStop',6,'isNeedMutex',7,'playerid',8,'showCenterPlayBtn',9,'vid',10],[],cGC,oFC,gg)
_(oPC,fQC)
}
oPC.wxXCkey=1
oPC.wxXCkey=3
}
var oNC=_v()
_(eLC,oNC)
if(_oz(z,29,cGC,oFC,gg)){oNC.wxVkey=1
}
var xOC=_v()
_(eLC,xOC)
if(_oz(z,30,cGC,oFC,gg)){xOC.wxVkey=1
}
bMC.wxXCkey=1
bMC.wxXCkey=3
oNC.wxXCkey=1
xOC.wxXCkey=1
_(tKC,eLC)
var cRC=_n('view')
_rz(z,cRC,'class',31,cGC,oFC,gg)
var hSC=_v()
_(cRC,hSC)
if(_oz(z,32,cGC,oFC,gg)){hSC.wxVkey=1
}
var oTC=_v()
_(cRC,oTC)
if(_oz(z,33,cGC,oFC,gg)){oTC.wxVkey=1
}
var cUC=_v()
_(cRC,cUC)
if(_oz(z,34,cGC,oFC,gg)){cUC.wxVkey=1
}
hSC.wxXCkey=1
oTC.wxXCkey=1
cUC.wxXCkey=1
_(tKC,cRC)
_(aJC,tKC)
}
aJC.wxXCkey=1
aJC.wxXCkey=3
return oHC
}
cDC.wxXCkey=4
_2z(z,11,hEC,e,s,gg,cDC,'item','index','index')
var fCC=_v()
_(oBC,fCC)
if(_oz(z,35,e,s,gg)){fCC.wxVkey=1
}
fCC.wxXCkey=1
_(o4B,oBC)
l5B.wxXCkey=1
_(r,o4B)
var c3B=_v()
_(r,c3B)
if(_oz(z,36,e,s,gg)){c3B.wxVkey=1
var oVC=_mz(z,'view',['catchtouchmove',37,'class',1],[],e,s,gg)
var lWC=_v()
_(oVC,lWC)
if(_oz(z,39,e,s,gg)){lWC.wxVkey=1
}
lWC.wxXCkey=1
_(c3B,oVC)
}
c3B.wxXCkey=1
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_18";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_18();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/vote/home/home.wxml'] = [$gwx_XC_18, './pages/vote/home/home.wxml'];else __wxAppCode__['pages/vote/home/home.wxml'] = $gwx_XC_18( './pages/vote/home/home.wxml' );
	;__wxRoute = "pages/vote/home/home";__wxRouteBegin = true;__wxAppCurrentFile__="pages/vote/home/home.js";define("pages/vote/home/home.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var t=require("../../../@babel/runtime/helpers/defineProperty"),e=require("../../../config.js"),a=require("../../../http.js"),i=requirePlugin("tencentvideo"),o=getApp(),n=1;Page({data:{item:["https://cdn.pluslegal.cn/xxzzb%2Fhome_img_banner%402x.png"],txtHidden:!0,showModal:!1,code:"",comp:{},pageSize:10,groupid:"",caContent:{},vcode:"",vcodes:"",title:"",startTime:"",endTime:"",beg:"",end:"",StatusBar:o.globalData.StatusBar,CustomBar:o.globalData.CustomBar,index:"",indexCurrent:null,noData:!1,listLen:""},onLoad:function(){var t=wx.getStorageSync("compId");this.setData({code:t}),t&&(n=1,this.getCompDetail(),this.getGroups(),this.getCalist(n))},bindplay:function(t){var e=t.currentTarget.dataset.id;(console.log("indexCurrent===>",this.data.indexCurrent),console.log(t),console.log(this.data.indexCurrent,!!this.data.indexCurrent),this.data.indexCurrent)&&i.getTxvContext(this.data.indexCurrent).pause();this.setData({indexCurrent:e})},videoPlay:function(t){var e=t.currentTarget.dataset.index,a=t.currentTarget.dataset.id;if(null!=this.data.indexCurrent){var o=i.getTxvContext();this.data.indexCurrent!=e&&o.pause(),this.setData({indexCurrent:e}),i.getTxvContext(a).play()}else{this.setData({indexCurrent:e}),i.getTxvContext(e).play()}},navigateBack:function(){wx.redirectTo({url:"/pages/index/index"})},showHint:function(){this.setData({showModal:!0})},hideModal:function(){this.setData({showModal:!1})},txtToggle:function(){var t=!this.data.txtHidden;this.setData({txtHidden:t})},toDetails:function(t){var e=t.currentTarget.dataset.code;wx.navigateTo({url:"../details/details?compId="+e+"&code="+this.data.code})},toVote:function(t){var e=t.currentTarget.dataset.code,a=t.currentTarget.dataset.index;this.setData({compId:e,index:a}),this.vote()},confirm:function(t){this.data.vcode.toLowerCase()==this.data.vcodes.toLowerCase()?(this.hideModal(),this.vote()):wx.showToast({title:"验证码输入有误！",icon:"none"})},codeInput:function(t){var e=t.detail.value;this.setData({vcode:e})},keywordInput:function(t){var e=t.detail.value;this.setData({title:e})},search:function(){n=1,this.setData({complist:[],isFromSearch:!0,searchLoading:!0,searchLoadingComplete:!1}),this.getCalist(n)},changeType:function(t){var e=t.currentTarget.dataset.id;n=1,"-1"==e?this.setData({groupid:""}):this.setData({groupid:e}),this.getCalist(n)},changeTypeAll:function(){this.setData({groupid:""})},getCompDetail:function(){var t=this;a.request(e.getCompDetail,"POST",{code:t.data.code},(function(e){if(null!=e.rows){t.setData({comp:e.rows,startTime:e.rows.startTime,endTime:e.rows.endTime,pollTotal:e.rows.pollTotal,visit:e.rows.visit});var a=t.getFormatDate();a<t.data.startTime&&t.setData({stu:1}),a>t.data.endTime&&t.setData({stu:0}),a>t.data.startTime&&a<t.data.endTime&&t.setData({stu:2});var i=new Date(t.data.endTime).getTime();t.setData({end:i}),t.startCountTime()}}),(function(t){wx.showToast({title:t,icon:"none"})}))},getGroups:function(){var t=this;a.request(e.getGroups,"POST",{code:t.data.code},(function(e){null!=e.rows&&t.setData({grouplist:e.rows,length:e.rows.length})}),(function(t){wx.showToast({title:t,icon:"none"})}))},getCalist:function(t){var i=this;a.request(e.getCalist,"POST",{code:i.data.code,groupid:i.data.groupid,page:t,pageSize:i.data.pageSize,title:i.data.title},(function(e){null!=e.rows&&(t>1?i.setData({complist:i.data.complist.concat(e.rows),listLen:i.data.complist.concat(e.rows).length}):i.setData({complist:e.rows,listLen:e.rows.length}),console.log("complist===>",i.data.complist))}),(function(t){wx.showToast({title:t,icon:"none"})}))},loadMore:function(t){console.log("加载更多"),n++,this.getCalist(n)},vote:function(){var i=this;a.request(e.vote,"POST",{campcode:i.data.code,candicode:i.data.compId,vcode:i.data.vcode},(function(e){0==e.success&&(wx.showToast({title:"投票成功！",icon:"success"}),i.data.complist[i.data.index].poll=e.rows.poll,i.setData(t({pollTotal:e.rows.campPoll,visit:e.rows.campVisit},"complist["+i.data.index+"]",i.data.complist[i.data.index])))}),(function(t){if("活动已结束"==t)wx.showToast({title:t,icon:"none"}),i.hideModal();else{if("投票已达上限"==t)return void wx.showToast({title:t,icon:"none"});i.setData({vcodes:t}),i.showHint()}}))},startCountTime:function(){var t=this,e=setTimeout((function(){t.countTime(t.data.end),t.startCountTime()}),1e3);t.setData({timer:e})},countTime:function(t){var e=this.data.endTime.split(/[- :]/),a=new Date(e[0],e[1]-1,e[2],e[3],e[4],e[5]),i=((a=Date.parse(a))-new Date)/1e3;if(i>=0){var o=parseInt(i/86400),n=parseInt(i%86400/3600),s=parseInt(i%86400%3600/60),r=parseInt(i%86400%3600%60);o=this.timeFormin(o),n=this.timeFormin(n),s=this.timeFormin(s),r=this.timeFormin(r),this.setData({day:this.timeFormat(o),hou:this.timeFormat(n),min:this.timeFormat(s),sec:this.timeFormat(r)})}},timeFormat:function(t){return t<10?"0"+t:t},timeFormin:function(t){return t<0?0:t},getFormatDate:function(){var t=new Date;return t.getFullYear()+"-"+(t.getMonth()+1<10?"0"+(t.getMonth()+1):t.getMonth()+1)+"-"+(t.getDate()<10?"0"+t.getDate():t.getDate())+" "+(t.getHours()<10?"0"+t.getHours():t.getHours())+":"+(t.getMinutes()<10?"0"+t.getMinutes():t.getMinutes())+":"+(t.getSeconds()<10?"0"+t.getSeconds():t.getSeconds())},onReady:function(){},onShow:function(){n=1,this.getCompDetail(),this.getCalist(n)},onHide:function(){},onUnload:function(){this.data.timer=null},onPullDownRefresh:function(){},onReachBottom:function(){},onShareAppMessage:function(){return{title:"2022年护航二十大，普法新征程 投票活动开始啦",desc:"2022年护航二十大，普法新征程 投票活动开始啦!",url:"../vote/home/home?code="+this.data.code}}});
},{isPage:true,isComponent:true,currentFile:'pages/vote/home/home.js'});require("pages/vote/home/home.js");$gwx_XC_19=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_19 || [];
function gz$gwx_XC_19_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_19_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_19_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_19_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'contents'])
Z([3,'info'])
Z([3,'status'])
Z([[2,'=='],[[7],[3,'stu']],[1,2]])
Z([[2,'=='],[[7],[3,'stu']],[1,1]])
Z([[2,'=='],[[7],[3,'stu']],[1,0]])
Z(z[3])
Z([3,'loadMoreData'])
Z([3,'content'])
Z([3,'true'])
Z([[7],[3,'rankData']])
Z([3,'*this'])
Z([[2,'>'],[[7],[3,'listLen']],[1,0]])
Z([[2,'<='],[[7],[3,'listLen']],[1,0]])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_19_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_19_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_19=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_19=true;
var x=['./pages/vote/rank/rank.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_19_1()
var tYC=_n('view')
_rz(z,tYC,'class',0,e,s,gg)
var eZC=_n('view')
_rz(z,eZC,'class',1,e,s,gg)
var o2C=_n('view')
_rz(z,o2C,'class',2,e,s,gg)
var x3C=_v()
_(o2C,x3C)
if(_oz(z,3,e,s,gg)){x3C.wxVkey=1
}
var o4C=_v()
_(o2C,o4C)
if(_oz(z,4,e,s,gg)){o4C.wxVkey=1
}
var f5C=_v()
_(o2C,f5C)
if(_oz(z,5,e,s,gg)){f5C.wxVkey=1
}
x3C.wxXCkey=1
o4C.wxXCkey=1
f5C.wxXCkey=1
_(eZC,o2C)
var b1C=_v()
_(eZC,b1C)
if(_oz(z,6,e,s,gg)){b1C.wxVkey=1
}
b1C.wxXCkey=1
_(tYC,eZC)
var c6C=_mz(z,'scroll-view',['bindscrolltolower',7,'class',1,'scrollY',2],[],e,s,gg)
var o8C=_v()
_(c6C,o8C)
var c9C=function(lAD,o0C,aBD,gg){
var eDD=_v()
_(aBD,eDD)
if(_oz(z,12,lAD,o0C,gg)){eDD.wxVkey=1
}
eDD.wxXCkey=1
return aBD
}
o8C.wxXCkey=2
_2z(z,10,c9C,e,s,gg,o8C,'item','index','*this')
var h7C=_v()
_(c6C,h7C)
if(_oz(z,13,e,s,gg)){h7C.wxVkey=1
}
h7C.wxXCkey=1
_(tYC,c6C)
_(r,tYC)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_19";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_19();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/vote/rank/rank.wxml'] = [$gwx_XC_19, './pages/vote/rank/rank.wxml'];else __wxAppCode__['pages/vote/rank/rank.wxml'] = $gwx_XC_19( './pages/vote/rank/rank.wxml' );
	;__wxRoute = "pages/vote/rank/rank";__wxRouteBegin = true;__wxAppCurrentFile__="pages/vote/rank/rank.js";define("pages/vote/rank/rank.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var t=require("../../../config.js"),e=require("../../../http.js"),a=getApp(),n=1;Page({data:{code:"",StatusBar:a.globalData.StatusBar,CustomBar:a.globalData.CustomBar,listLen:""},loadMoreData:function(){n++,this.getAllRank(n)},onLoad:function(t){var e=wx.getStorageSync("compId");console.log(e),this.setData({code:e}),n=1,this.getAllRank(n),this.getCompDetail()},onReady:function(){this.getCompDetail()},onShow:function(){},onHide:function(){},onUnload:function(){this.data.timer=null},getAllRank:function(a){var n=this;e.request(t.getRank,"POST",{code:n.data.code,page:a,pageSize:10},(function(t){null!=t.rows&&(a>1?n.setData({rankData:n.data.rankData.concat(t.rows),listLen:n.data.complist.concat(t.rows).length}):(n.setData({rankData:t.rows,listLen:t.rows.length}),console.log("listLen===>",n.data.listLen)))}),(function(t){wx.showToast({title:t,icon:"none"})}))},getCompDetail:function(){var a=this;e.request(t.getCompDetail,"POST",{code:a.data.code},(function(t){if(null!=t.rows){a.setData({comp:t.rows,startTime:t.rows.startTime,endTime:t.rows.endTime});var e=a.getFormatDate();e<a.data.startTime&&a.setData({stu:1}),e>a.data.endTime&&a.setData({stu:0}),e>a.data.startTime&&e<a.data.endTime&&a.setData({stu:2});var n=new Date(a.data.endTime).getTime();console.log(n),a.setData({end:n}),a.startCountTime()}}),(function(t){wx.showToast({title:t,icon:"none"})}))},startCountTime:function(){var t=this,e=setTimeout((function(){t.countTime(t.data.end),t.startCountTime()}),1e3);t.setData({timer:e})},countTime:function(t){var e=this.data.endTime.split(/[- :]/),a=new Date(e[0],e[1]-1,e[2],e[3],e[4],e[5]),n=((a=Date.parse(a))-new Date)/1e3;if(n>=0){var o=parseInt(n/86400),i=parseInt(n%86400/3600),s=parseInt(n%86400%3600/60),r=parseInt(n%86400%3600%60);o=this.timeFormin(o),i=this.timeFormin(i),s=this.timeFormin(s),r=this.timeFormin(r),this.setData({day:this.timeFormat(o),hou:this.timeFormat(i),min:this.timeFormat(s),sec:this.timeFormat(r)})}},timeFormat:function(t){return t<10?"0"+t:t},timeFormin:function(t){return t<0?0:t},getFormatDate:function(){var t=new Date;return t.getFullYear()+"-"+(t.getMonth()+1<10?"0"+(t.getMonth()+1):t.getMonth()+1)+"-"+(t.getDate()<10?"0"+t.getDate():t.getDate())+" "+(t.getHours()<10?"0"+t.getHours():t.getHours())+":"+(t.getMinutes()<10?"0"+t.getMinutes():t.getMinutes())+":"+(t.getSeconds()<10?"0"+t.getSeconds():t.getSeconds())},navigateBack:function(){wx.redirectTo({url:"/pages/index/index"})}});
},{isPage:true,isComponent:true,currentFile:'pages/vote/rank/rank.js'});require("pages/vote/rank/rank.js");