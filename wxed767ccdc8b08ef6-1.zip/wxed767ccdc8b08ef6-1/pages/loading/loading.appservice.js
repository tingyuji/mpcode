$gwx_XC_5=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_5 || [];
function gz$gwx_XC_5_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_5_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_5_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_5_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_5_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_5_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_5=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_5=true;
var x=['./pages/loading/loading.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_5_1()
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_5";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_5();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/loading/loading.wxml'] = [$gwx_XC_5, './pages/loading/loading.wxml'];else __wxAppCode__['pages/loading/loading.wxml'] = $gwx_XC_5( './pages/loading/loading.wxml' );
	;__wxRoute = "pages/loading/loading";__wxRouteBegin = true;__wxAppCurrentFile__="pages/loading/loading.js";define("pages/loading/loading.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";require("../../config.js"),require("../../http.js");var e=getApp();Page({data:{typeStr:"加载题库",questionType:0},onLoad:function(e){var t=e.type,a=e.questionType,o="加载题库";if(0==t){switch(a){case"0":o="不定项选择题";break;case"1":o="单项选择题";break;case"2":o="多项选择题";break;case"3":o="判断题";break;case"4":o="填空题"}this.setData({typeStr:o}),wx.navigateTo({url:"../exam/exam?questionType="+a})}},onReady:function(){},onShow:function(){console.log("onShow lastQuestionType=",this.data.lastQuestionType);var t=this.data.lastQuestionType,a=parseInt(t)+1;console.log("curQuestionType",a);try{if(1==a){if(e.globalData.question.one)return this.setData({questionType:1,typeStr:"单项选择"}),void setTimeout((function(){wx.navigateTo({url:"../exam/exam?questionType=1"})}),500);a++}if(2==a){if(e.globalData.question.two)return this.setData({questionType:2,typeStr:"多项选择"}),void setTimeout((function(){wx.navigateTo({url:"../exam/exam?questionType=2"})}),500);a++}if(3==a){if(e.globalData.question.three)return this.setData({questionType:3,typeStr:"判断题"}),void setTimeout((function(){wx.navigateTo({url:"../exam/exam?questionType=3"})}),500);a++}if(4==a){if(e.globalData.question.four)return this.setData({questionType:4,typeStr:"填空题"}),void setTimeout((function(){wx.navigateTo({url:"../exam/exam?questionType=4"})}),500);a++}return void(a>4&&(this.setData({typeStr:"正在计算成绩..."}),this.calculateGrade(),setTimeout((function(){wx.redirectTo({url:"../exam-result/exam-result?type=1"})}),2e3)))}catch(e){}},onHide:function(){},onUnload:function(){},calculateGrade:function(){var t=0,a=0,o=0,r=0,n=0,s=[],i=[],c=[],l=[],u=[],g=wx.getStorageSync("examPaper");if(e.globalData.question.zero){var f=wx.getStorageSync("unsurenessRecord");if(f)for(var p=0;p<f.length;p++){var v=f[p];if(v.correctCount==v.selectItems.length){for(var y=0,h=0;h<v.answers.length;h++){var m=v.answers[h];1==m.correct&&m.isSelect&&y++}y==v.correctCount&&(t+=g.unsurenessPoint)}var w={},x=v.id,d=v.selectItems;w[x]=d,s.push(w)}}if(e.globalData.question.one){var S=wx.getStorageSync("singleRecord");if(S)for(var T=0;T<S.length;T++){for(var q=S[T],b=0;b<q.answers.length;b++){var D=q.answers[b];if(1==D.correct){D.isSelect&&(a+=g.singlePoint);break}}w={},x=q.id,d=q.selectItems;w[x]=d,i.push(w)}}if(e.globalData.question.two){var k=wx.getStorageSync("multipleRecord");if(k)for(var I=0;I<k.length;I++){var A=k[I];if(A.correctCount==A.selectItems.length){for(var R=0,P=0;P<A.answers.length;P++){var C=A.answers[P];1==C.correct&&C.isSelect&&R++}R==A.correctCount&&(o+=g.multiplePoint)}w={},x=A.id,d=A.selectItems;w[x]=d,c.push(w)}}if(e.globalData.question.three){var Q=wx.getStorageSync("checkRecord");if(Q)for(var j=0;j<Q.length;j++){for(var z=Q[j],G=0;G<z.answers.length;G++){var H=z.answers[G];if(1==H.correct){H.isSelect&&(r+=g.checkPoint);break}}w={},x=z.id,d=z.selectItems;w[x]=d,l.push(w)}}if(e.globalData.question.four){var L=wx.getStorageSync("completionRecord");if(L)for(var U=0;U<L.length;U++){var _=L[U];_.inputAnswer==_.answers[0].correct_content&&(n+=g.completionPoint);w={},x=_.id;_.selectItems.push(_.inputAnswer);d=_.selectItems;w[x]=d,u.push(w)}}var B=t+a+o+r+n;e.globalData.score={zero:t,one:a,two:o,three:r,four:n,total:B};var E={unsurenessArray:s,singleArray:i,multipleArray:c,checkArray:l,completionArray:u};wx.setStorageSync("examRecord",E),console.log("examRecord",E),console.log("app.globalData.score",e.globalData.score)}});
},{isPage:true,isComponent:true,currentFile:'pages/loading/loading.js'});require("pages/loading/loading.js");