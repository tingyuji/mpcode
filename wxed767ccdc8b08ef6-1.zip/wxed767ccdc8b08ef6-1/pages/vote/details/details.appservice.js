$gwx_XC_17=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_17 || [];
function gz$gwx_XC_17_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_17_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_17_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_17_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'playArea'])
Z([[6],[[7],[3,'comp']],[3,'videoUrl']])
Z([1,false])
Z([3,'videoBox'])
Z(z[1])
Z(z[1])
Z([[6],[[7],[3,'comp']],[3,'audioUrl']])
Z([[6],[[7],[3,'comp']],[3,'imgUrl']])
Z([[7],[3,'ArticleList']])
Z([3,'index'])
Z([3,'infoContentStyle'])
Z([[2,'?:'],[[2,'=='],[[6],[[7],[3,'item']],[3,'type']],[1,'rich-text']],[1,true],[1,false]])
Z([[2,'?:'],[[2,'&&'],[[2,'=='],[[6],[[7],[3,'item']],[3,'type']],[1,'video']],[[2,'!='],[[6],[[7],[3,'item']],[3,'value']],[1,'']]],[1,true],[1,false]])
Z([3,'btn'])
Z([[2,'=='],[[7],[3,'stu']],[1,2]])
Z([[2,'=='],[[7],[3,'stu']],[1,1]])
Z([[2,'=='],[[7],[3,'stu']],[1,0]])
Z([[7],[3,'showModal']])
Z([3,'preventTouchMove'])
Z([3,'modal-mask'])
Z(z[17])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_17_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_17_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_17=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_17=true;
var x=['./pages/vote/details/details.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_17_1()
var bGB=_n('view')
var oHB=_n('view')
_rz(z,oHB,'class',0,e,s,gg)
var xIB=_v()
_(oHB,xIB)
if(_oz(z,1,e,s,gg)){xIB.wxVkey=1
var cLB=_mz(z,'txv-video',['autoplay',2,'class',1,'playerid',2,'vid',3],[],e,s,gg)
_(xIB,cLB)
}
var oJB=_v()
_(oHB,oJB)
if(_oz(z,6,e,s,gg)){oJB.wxVkey=1
}
var fKB=_v()
_(oHB,fKB)
if(_oz(z,7,e,s,gg)){fKB.wxVkey=1
}
xIB.wxXCkey=1
xIB.wxXCkey=3
oJB.wxXCkey=1
fKB.wxXCkey=1
_(bGB,oHB)
var hMB=_v()
_(bGB,hMB)
var oNB=function(oPB,cOB,lQB,gg){
var tSB=_n('view')
_rz(z,tSB,'class',10,oPB,cOB,gg)
var eTB=_v()
_(tSB,eTB)
if(_oz(z,11,oPB,cOB,gg)){eTB.wxVkey=1
}
var bUB=_v()
_(tSB,bUB)
if(_oz(z,12,oPB,cOB,gg)){bUB.wxVkey=1
}
eTB.wxXCkey=1
bUB.wxXCkey=1
_(lQB,tSB)
return lQB
}
hMB.wxXCkey=2
_2z(z,8,oNB,e,s,gg,hMB,'item','index','index')
var oVB=_n('view')
_rz(z,oVB,'class',13,e,s,gg)
var xWB=_v()
_(oVB,xWB)
if(_oz(z,14,e,s,gg)){xWB.wxVkey=1
}
var oXB=_v()
_(oVB,oXB)
if(_oz(z,15,e,s,gg)){oXB.wxVkey=1
}
var fYB=_v()
_(oVB,fYB)
if(_oz(z,16,e,s,gg)){fYB.wxVkey=1
}
xWB.wxXCkey=1
oXB.wxXCkey=1
fYB.wxXCkey=1
_(bGB,oVB)
_(r,bGB)
var eFB=_v()
_(r,eFB)
if(_oz(z,17,e,s,gg)){eFB.wxVkey=1
var cZB=_mz(z,'view',['catchtouchmove',18,'class',1],[],e,s,gg)
var h1B=_v()
_(cZB,h1B)
if(_oz(z,20,e,s,gg)){h1B.wxVkey=1
}
h1B.wxXCkey=1
_(eFB,cZB)
}
eFB.wxXCkey=1
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_17";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_17();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/vote/details/details.wxml'] = [$gwx_XC_17, './pages/vote/details/details.wxml'];else __wxAppCode__['pages/vote/details/details.wxml'] = $gwx_XC_17( './pages/vote/details/details.wxml' );
	;__wxRoute = "pages/vote/details/details";__wxRouteBegin = true;__wxAppCurrentFile__="pages/vote/details/details.js";define("pages/vote/details/details.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var t=require("../../../config.js"),e=require("../../../http.js");Page({data:{item:["https://cdn.pluslegal.cn/xxzzb%2Fhome_img_banner%402x.png"],showModal:!1,compId:"",code:"",vcode:"",vcodes:"",content:"",imgUrl:"http://eae.mini.kaililaw.com",ArticleList:[]},onLoad:function(t){var e=t.compId,o=t.code;this.setData({compId:e,code:o}),this.getDetail(),this.getCompDetail()},getDetail:function(){var o=this;e.request(t.getCaDetail,"POST",{code:o.data.compId},(function(t){if(null!=t.rows){o.setData({comp:t.rows,content:t.rows.content,poll:t.rows.poll});var e=o.data.content.replace(/(\<img|\<p)/gi,(function(t,e){return{"<img":'<img style="width:100%;height:auto;display:block;"margin:30rpx 0; ',"<p":'<p class="txt" style="color:#333;text-align:justify" padding:20rpx;line-height ',"<article":"<div","</article":"</div","<header":"<div","</header":"</div"}[e]})),a=[],i=/src=[\'\"]?([^\'\"]*)[\'\"]?/i,n=e.match(/<video.*?(?:>|\/>)/gi)||[],s=e.split("</video>");n.forEach((function(t,e){var o=t.match(i);a.push(o[1])}));var c=[];s.forEach((function(t,e){""!=t&&null!=t&&c.push({type:"rich-text",value:t+"</video>"}),e<s.length&&null!=a[e]&&c.push({type:"video",value:a[e]})})),o.setData({ArticleList:c})}}),(function(t){wx.showToast({title:t,icon:"none"})}))},getCompDetail:function(){var o=this;e.request(t.getCompDetail,"POST",{code:o.data.code},(function(t){if(null!=t.rows){o.setData({comps:t.rows,startTime:t.rows.startTime,endTime:t.rows.endTime});var e=o.getFormatDate();e<o.data.startTime&&o.setData({stu:1}),e>o.data.endTime&&o.setData({stu:0}),e>o.data.startTime&&e<o.data.endTime&&o.setData({stu:2})}}),(function(t){wx.showToast({title:t,icon:"none"})}))},getFormatDate:function(){var t=new Date;return t.getFullYear()+"-"+(t.getMonth()+1<10?"0"+(t.getMonth()+1):t.getMonth()+1)+"-"+(t.getDate()<10?"0"+t.getDate():t.getDate())+" "+(t.getHours()<10?"0"+t.getHours():t.getHours())+":"+(t.getMinutes()<10?"0"+t.getMinutes():t.getMinutes())+":"+(t.getSeconds()<10?"0"+t.getSeconds():t.getSeconds())},showHint:function(){this.setData({showModal:!0})},hideModal:function(){this.setData({showModal:!1})},toVote:function(){this.vote()},confirm:function(t){this.data.vcode.toLowerCase()==this.data.vcodes.toLowerCase()?(this.hideModal(),this.vote()):wx.showToast({title:"验证码输入有误！",icon:"none"})},codeInput:function(t){var e=t.detail.value;this.setData({vcode:e})},vote:function(){var o=this;e.request(t.vote,"POST",{campcode:o.data.code,candicode:o.data.compId,vcode:o.data.vcode},(function(t){0==t.success&&(wx.showToast({title:"投票成功！",icon:"success"}),o.setData({poll:t.rows.poll}))}),(function(t){"活动已结束"==t?(wx.showToast({title:t,icon:"none"}),o.hideModal()):(o.setData({vcodes:t}),o.showHint())}))},onReady:function(){},onShow:function(){},onHide:function(){},onUnload:function(){},onPullDownRefresh:function(){},onReachBottom:function(){},onShareAppMessage:function(){return{title:"2022年护航二十大，普法新征程 投票活动开始啦",desc:"2022年护航二十大，普法新征程 投票活动开始啦!",url:"../details/details?compId="+this.data.compId+"&code="+this.data.code}}});
},{isPage:true,isComponent:true,currentFile:'pages/vote/details/details.js'});require("pages/vote/details/details.js");