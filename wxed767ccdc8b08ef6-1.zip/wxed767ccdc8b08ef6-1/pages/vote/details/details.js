var t = require("../../../config.js"), e = require("../../../http.js");

Page({
    data: {
        item: [ "https://cdn.pluslegal.cn/xxzzb%2Fhome_img_banner%402x.png" ],
        showModal: !1,
        compId: "",
        code: "",
        vcode: "",
        vcodes: "",
        content: "",
        imgUrl: "http://eae.mini.kaililaw.com",
        ArticleList: []
    },
    onLoad: function(t) {
        var e = t.compId, o = t.code;
        this.setData({
            compId: e,
            code: o
        }), this.getDetail(), this.getCompDetail();
    },
    getDetail: function() {
        var o = this;
        e.request(t.getCaDetail, "POST", {
            code: o.data.compId
        }, function(t) {
            if (null != t.rows) {
                o.setData({
                    comp: t.rows,
                    content: t.rows.content,
                    poll: t.rows.poll
                });
                var e = o.data.content.replace(/(\<img|\<p)/gi, function(t, e) {
                    return {
                        "<img": '<img style="width:100%;height:auto;display:block;"margin:30rpx 0; ',
                        "<p": '<p class="txt" style="color:#333;text-align:justify" padding:20rpx;line-height ',
                        "<article": "<div",
                        "</article": "</div",
                        "<header": "<div",
                        "</header": "</div"
                    }[e];
                }), a = [], i = /src=[\'\"]?([^\'\"]*)[\'\"]?/i, n = e.match(/<video.*?(?:>|\/>)/gi) || [], s = e.split("</video>");
                n.forEach(function(t, e) {
                    var o = t.match(i);
                    a.push(o[1]);
                });
                var c = [];
                s.forEach(function(t, e) {
                    "" != t && null != t && c.push({
                        type: "rich-text",
                        value: t + "</video>"
                    }), e < s.length && null != a[e] && c.push({
                        type: "video",
                        value: a[e]
                    });
                }), o.setData({
                    ArticleList: c
                });
            }
        }, function(t) {
            wx.showToast({
                title: t,
                icon: "none"
            });
        });
    },
    getCompDetail: function() {
        var o = this;
        e.request(t.getCompDetail, "POST", {
            code: o.data.code
        }, function(t) {
            if (null != t.rows) {
                o.setData({
                    comps: t.rows,
                    startTime: t.rows.startTime,
                    endTime: t.rows.endTime
                });
                var e = o.getFormatDate();
                e < o.data.startTime && o.setData({
                    stu: 1
                }), e > o.data.endTime && o.setData({
                    stu: 0
                }), e > o.data.startTime && e < o.data.endTime && o.setData({
                    stu: 2
                });
            }
        }, function(t) {
            wx.showToast({
                title: t,
                icon: "none"
            });
        });
    },
    getFormatDate: function() {
        var t = new Date();
        return t.getFullYear() + "-" + (t.getMonth() + 1 < 10 ? "0" + (t.getMonth() + 1) : t.getMonth() + 1) + "-" + (t.getDate() < 10 ? "0" + t.getDate() : t.getDate()) + " " + (t.getHours() < 10 ? "0" + t.getHours() : t.getHours()) + ":" + (t.getMinutes() < 10 ? "0" + t.getMinutes() : t.getMinutes()) + ":" + (t.getSeconds() < 10 ? "0" + t.getSeconds() : t.getSeconds());
    },
    showHint: function() {
        this.setData({
            showModal: !0
        });
    },
    hideModal: function() {
        this.setData({
            showModal: !1
        });
    },
    toVote: function() {
        this.vote();
    },
    confirm: function(t) {
        this.data.vcode.toLowerCase() == this.data.vcodes.toLowerCase() ? (this.hideModal(), 
        this.vote()) : wx.showToast({
            title: "验证码输入有误！",
            icon: "none"
        });
    },
    codeInput: function(t) {
        var e = t.detail.value;
        this.setData({
            vcode: e
        });
    },
    vote: function() {
        var o = this;
        e.request(t.vote, "POST", {
            campcode: o.data.code,
            candicode: o.data.compId,
            vcode: o.data.vcode
        }, function(t) {
            0 == t.success && (wx.showToast({
                title: "投票成功！",
                icon: "success"
            }), o.setData({
                poll: t.rows.poll
            }));
        }, function(t) {
            "活动已结束" == t ? (wx.showToast({
                title: t,
                icon: "none"
            }), o.hideModal()) : (o.setData({
                vcodes: t
            }), o.showHint());
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: "2022年护航二十大，普法新征程 投票活动开始啦",
            desc: "2022年护航二十大，普法新征程 投票活动开始啦!",
            url: "../details/details?compId=" + this.data.compId + "&code=" + this.data.code
        };
    }
});