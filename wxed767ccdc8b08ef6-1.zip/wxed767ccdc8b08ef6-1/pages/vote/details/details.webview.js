$gwx_XC_17=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_17 || [];
function gz$gwx_XC_17_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_17_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_17_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_17_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'autoplay']])
Z([3,'swiperChange'])
Z([3,'swiper'])
Z([[7],[3,'duration']])
Z([[7],[3,'indicatorDots']])
Z([[7],[3,'interval']])
Z([3,'showDialogBtn'])
Z([3,'swiper-item'])
Z([3,'toExam'])
Z([3,'slide-image'])
Z([[6],[[7],[3,'comps']],[3,'imgUrl']])
Z([3,'contents'])
Z([3,'info'])
Z([3,'detail'])
Z([3,'bl'])
Z([a,[[6],[[7],[3,'comp']],[3,'title']]])
Z([3,'text-2 bl'])
Z([a,[[6],[[7],[3,'comp']],[3,'intro']]])
Z([3,'total'])
Z(z[14])
Z([a,[[6],[[7],[3,'comp']],[3,'rank']]])
Z(z[14])
Z([3,'排名'])
Z(z[14])
Z([a,[[7],[3,'poll']]])
Z(z[14])
Z([3,'票数'])
Z(z[14])
Z([a,[[6],[[7],[3,'comp']],[3,'visit']]])
Z(z[14])
Z([3,'访问量'])
Z([3,'video-list'])
Z([3,'playArea'])
Z([[6],[[7],[3,'comp']],[3,'videoUrl']])
Z([1,false])
Z([3,'videoBox'])
Z(z[33])
Z(z[33])
Z([[6],[[7],[3,'comp']],[3,'audioUrl']])
Z(z[34])
Z(z[38])
Z([[6],[[7],[3,'comp']],[3,'imgUrl']])
Z(z[41])
Z([[7],[3,'ArticleList']])
Z([3,'index'])
Z([3,'infoContentStyle'])
Z([[2,'?:'],[[2,'=='],[[6],[[7],[3,'item']],[3,'type']],[1,'rich-text']],[1,true],[1,false]])
Z([3,'content'])
Z([[6],[[7],[3,'item']],[3,'value']])
Z([[2,'?:'],[[2,'&&'],[[2,'=='],[[6],[[7],[3,'item']],[3,'type']],[1,'video']],[[2,'!='],[[6],[[7],[3,'item']],[3,'value']],[1,'']]],[1,true],[1,false]])
Z([3,'0'])
Z(z[48])
Z([3,'width:100%;height: 150px'])
Z([3,'btn'])
Z([[2,'=='],[[7],[3,'stu']],[1,2]])
Z([3,'toVote'])
Z([[6],[[7],[3,'comp']],[3,'code']])
Z([3,'投票'])
Z([[2,'=='],[[7],[3,'stu']],[1,1]])
Z([3,'novote'])
Z([3,'投票未开始'])
Z([[2,'=='],[[7],[3,'stu']],[1,0]])
Z(z[59])
Z([3,'投票已结束'])
Z([3,'share'])
Z([3,'确认分享'])
Z([[7],[3,'showModal']])
Z([3,'preventTouchMove'])
Z([3,'modal-mask'])
Z(z[66])
Z([3,'modal-dialog'])
Z([3,'hideModal'])
Z([3,'close'])
Z([3,'30'])
Z([3,'cancel'])
Z([3,'modal-titles'])
Z([3,'投票验证'])
Z([3,'modal-contents'])
Z([3,'vcode'])
Z([a,[3,' '],[[7],[3,'vcodes']],[3,' ']])
Z([3,'weui-cell weui-cell_input verify'])
Z([3,'codeInput'])
Z([3,'weui-input'])
Z([3,'请输入上述字符'])
Z([3,'confirm'])
Z([3,'modal-btn'])
Z([3,'确定 '])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_17_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_17_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_17=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_17=true;
var x=['./pages/vote/details/details.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_17_1()
var c5N=_mz(z,'swiper',['autoplay',0,'bindchange',1,'class',1,'duration',2,'indicatorDots',3,'interval',4],[],e,s,gg)
var o6N=_mz(z,'swiper-item',['bindtap',6,'class',1],[],e,s,gg)
var l7N=_mz(z,'image',['bindtap',8,'class',1,'src',2],[],e,s,gg)
_(o6N,l7N)
_(c5N,o6N)
_(r,c5N)
var a8N=_n('view')
_rz(z,a8N,'class',11,e,s,gg)
var t9N=_n('view')
_rz(z,t9N,'class',12,e,s,gg)
var e0N=_n('view')
_rz(z,e0N,'class',13,e,s,gg)
var bAO=_n('text')
_rz(z,bAO,'class',14,e,s,gg)
var oBO=_oz(z,15,e,s,gg)
_(bAO,oBO)
_(e0N,bAO)
var xCO=_n('view')
_rz(z,xCO,'class',16,e,s,gg)
var oDO=_oz(z,17,e,s,gg)
_(xCO,oDO)
_(e0N,xCO)
_(t9N,e0N)
var fEO=_n('view')
_rz(z,fEO,'class',18,e,s,gg)
var cFO=_n('view')
var hGO=_n('text')
_rz(z,hGO,'class',19,e,s,gg)
var oHO=_oz(z,20,e,s,gg)
_(hGO,oHO)
_(cFO,hGO)
var cIO=_n('text')
_rz(z,cIO,'class',21,e,s,gg)
var oJO=_oz(z,22,e,s,gg)
_(cIO,oJO)
_(cFO,cIO)
_(fEO,cFO)
var lKO=_n('view')
var aLO=_n('text')
_rz(z,aLO,'class',23,e,s,gg)
var tMO=_oz(z,24,e,s,gg)
_(aLO,tMO)
_(lKO,aLO)
var eNO=_n('text')
_rz(z,eNO,'class',25,e,s,gg)
var bOO=_oz(z,26,e,s,gg)
_(eNO,bOO)
_(lKO,eNO)
_(fEO,lKO)
var oPO=_n('view')
var xQO=_n('text')
_rz(z,xQO,'class',27,e,s,gg)
var oRO=_oz(z,28,e,s,gg)
_(xQO,oRO)
_(oPO,xQO)
var fSO=_n('text')
_rz(z,fSO,'class',29,e,s,gg)
var cTO=_oz(z,30,e,s,gg)
_(fSO,cTO)
_(oPO,fSO)
_(fEO,oPO)
_(t9N,fEO)
_(a8N,t9N)
var hUO=_n('view')
_rz(z,hUO,'class',31,e,s,gg)
var oVO=_n('view')
var cWO=_n('view')
_rz(z,cWO,'class',32,e,s,gg)
var oXO=_v()
_(cWO,oXO)
if(_oz(z,33,e,s,gg)){oXO.wxVkey=1
var t1O=_mz(z,'txv-video',['autoplay',34,'class',1,'playerid',2,'vid',3],[],e,s,gg)
_(oXO,t1O)
}
var lYO=_v()
_(cWO,lYO)
if(_oz(z,38,e,s,gg)){lYO.wxVkey=1
var e2O=_mz(z,'video',['autoplay',39,'src',1],[],e,s,gg)
_(lYO,e2O)
}
var aZO=_v()
_(cWO,aZO)
if(_oz(z,41,e,s,gg)){aZO.wxVkey=1
var b3O=_n('image')
_rz(z,b3O,'src',42,e,s,gg)
_(aZO,b3O)
}
oXO.wxXCkey=1
oXO.wxXCkey=3
lYO.wxXCkey=1
aZO.wxXCkey=1
_(oVO,cWO)
var o4O=_v()
_(oVO,o4O)
var x5O=function(f7O,o6O,c8O,gg){
var o0O=_n('view')
_rz(z,o0O,'class',45,f7O,o6O,gg)
var cAP=_v()
_(o0O,cAP)
if(_oz(z,46,f7O,o6O,gg)){cAP.wxVkey=1
var lCP=_mz(z,'rich-text',['class',47,'nodes',1],[],f7O,o6O,gg)
_(cAP,lCP)
}
var oBP=_v()
_(o0O,oBP)
if(_oz(z,49,f7O,o6O,gg)){oBP.wxVkey=1
var aDP=_mz(z,'video',['frameborder',50,'src',1,'style',2],[],f7O,o6O,gg)
_(oBP,aDP)
}
cAP.wxXCkey=1
oBP.wxXCkey=1
_(c8O,o0O)
return c8O
}
o4O.wxXCkey=2
_2z(z,43,x5O,e,s,gg,o4O,'item','index','index')
var tEP=_n('view')
_rz(z,tEP,'class',53,e,s,gg)
var eFP=_v()
_(tEP,eFP)
if(_oz(z,54,e,s,gg)){eFP.wxVkey=1
var xIP=_mz(z,'button',['bindtap',55,'data-code',1],[],e,s,gg)
var oJP=_oz(z,57,e,s,gg)
_(xIP,oJP)
_(eFP,xIP)
}
var bGP=_v()
_(tEP,bGP)
if(_oz(z,58,e,s,gg)){bGP.wxVkey=1
var fKP=_n('button')
_rz(z,fKP,'class',59,e,s,gg)
var cLP=_oz(z,60,e,s,gg)
_(fKP,cLP)
_(bGP,fKP)
}
var oHP=_v()
_(tEP,oHP)
if(_oz(z,61,e,s,gg)){oHP.wxVkey=1
var hMP=_n('button')
_rz(z,hMP,'class',62,e,s,gg)
var oNP=_oz(z,63,e,s,gg)
_(hMP,oNP)
_(oHP,hMP)
}
var cOP=_n('button')
_rz(z,cOP,'openType',64,e,s,gg)
var oPP=_oz(z,65,e,s,gg)
_(cOP,oPP)
_(tEP,cOP)
eFP.wxXCkey=1
bGP.wxXCkey=1
oHP.wxXCkey=1
_(oVO,tEP)
_(hUO,oVO)
var lQP=_n('view')
_(hUO,lQP)
_(a8N,hUO)
_(r,a8N)
var o4N=_v()
_(r,o4N)
if(_oz(z,66,e,s,gg)){o4N.wxVkey=1
var aRP=_mz(z,'view',['catchtouchmove',67,'class',1],[],e,s,gg)
var tSP=_v()
_(aRP,tSP)
if(_oz(z,69,e,s,gg)){tSP.wxVkey=1
var eTP=_n('view')
_rz(z,eTP,'class',70,e,s,gg)
var bUP=_mz(z,'icon',['bindtap',71,'class',1,'size',2,'type',3],[],e,s,gg)
_(eTP,bUP)
var oVP=_n('view')
_rz(z,oVP,'class',75,e,s,gg)
var xWP=_oz(z,76,e,s,gg)
_(oVP,xWP)
_(eTP,oVP)
var oXP=_n('view')
_rz(z,oXP,'class',77,e,s,gg)
var fYP=_n('view')
_rz(z,fYP,'class',78,e,s,gg)
var cZP=_oz(z,79,e,s,gg)
_(fYP,cZP)
_(oXP,fYP)
var h1P=_n('view')
_rz(z,h1P,'class',80,e,s,gg)
var o2P=_mz(z,'input',['bindinput',81,'class',1,'placeholder',2],[],e,s,gg)
_(h1P,o2P)
_(oXP,h1P)
_(eTP,oXP)
var c3P=_mz(z,'view',['bindtap',84,'class',1],[],e,s,gg)
var o4P=_oz(z,86,e,s,gg)
_(c3P,o4P)
_(eTP,c3P)
_(tSP,eTP)
}
tSP.wxXCkey=1
_(o4N,aRP)
}
o4N.wxXCkey=1
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_17";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_17();
	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/vote/details/details.wxml'] = [$gwx_XC_17, './pages/vote/details/details.wxml'];else __wxAppCode__['pages/vote/details/details.wxml'] = $gwx_XC_17( './pages/vote/details/details.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['pages/vote/details/details.wxss'] = setCssToHead(["body{background-color:#ac1212}\n.",[1],"video-list{background:url(\x22https://cdn.pluslegal.cn/xxzzb%2Fhome_rules_img_bg%402x.png\x22)no-repeat;background-color:inherit!important;background-size:100% 100%;padding:0!important;width:100%}\n.",[1],"video-list\x3ewx-view{border-radius:",[0,10],";margin:3%;position:relative;width:94%}\n.",[1],"video-list\x3ewx-view wx-video{border-radius:",[0,10],";height:",[0,500],";margin:",[0,30]," 0;width:100%}\n.",[1],"video-list .",[1],"num{background-color:#f9ede1;border-radius:0 ",[0,50]," ",[0,50]," 0;color:#732824;font-size:",[0,26],";left:0;padding:",[0,8]," ",[0,20],";position:absolute;top:",[0,20],";z-index:1}\n.",[1],"video-list .",[1],"info\x3ewx-text{display:inherit;margin:",[0,16]," 0}\n.",[1],"video-list .",[1],"info\x3ewx-text:first-child{color:#732824;font-size:",[0,34],";font-weight:700}\n.",[1],"video-list .",[1],"info wx-text:nth-child(2){color:#222;font-size:",[0,32],";font-weight:700}\n.",[1],"video-list .",[1],"info wx-text:last-child{color:#999;font-size:",[0,28],";font-weight:700}\n.",[1],"detail{padding-top:",[0,20],"}\n.",[1],"detail\x3ewx-text{color:#222;margin:",[0,16]," 0;text-align:center}\n.",[1],"detail\x3ewx-text:first-child{font-size:",[0,36],";font-weight:700}\n.",[1],"detail\x3ewx-text:nth-child(2){color:#999}\n.",[1],"des{line-height:1.8!important;margin:5%!important;text-align:justify!important;width:90%!important}\n.",[1],"modal-dialog{border-radius:",[0,10],";height:",[0,530],";position:relative}\n.",[1],"btn wx-button{width:100%!important}\n.",[1],"des wx-img{display:block;display:table;height:auto;margin:",[0,10]," auto;max-width:100%;text-align:center}\n.",[1],"infoContentStyle{padding:0 ",[0,20],"}\n.",[1],"infoContentStyle .",[1],"txt{word-wrap:break-word;word-break:break-all}\n.",[1],"detail .",[1],"text-2{margin:0 auto;padding:0 ",[0,26],";text-align:center;width:80%}\n.",[1],"playArea{margin:",[0,20]," 0;overflow:hidden;padding:",[0,20],"}\n.",[1],"playArea .",[1],"videoBox{height:100%;width:100%}\n",],"Some selectors are not allowed in component wxss, including tag name selectors, ID selectors, and attribute selectors.(./pages/vote/details/details.wxss:1:1218)",{path:"./pages/vote/details/details.wxss"});
}