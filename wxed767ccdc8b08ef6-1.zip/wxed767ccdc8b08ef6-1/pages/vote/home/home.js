var t = require("../../../@babel/runtime/helpers/defineProperty"), e = require("../../../config.js"), a = require("../../../http.js"), i = requirePlugin("tencentvideo"), o = getApp(), n = 1;

Page({
    data: {
        item: [ "https://cdn.pluslegal.cn/xxzzb%2Fhome_img_banner%402x.png" ],
        txtHidden: !0,
        showModal: !1,
        code: "",
        comp: {},
        pageSize: 10,
        groupid: "",
        caContent: {},
        vcode: "",
        vcodes: "",
        title: "",
        startTime: "",
        endTime: "",
        beg: "",
        end: "",
        StatusBar: o.globalData.StatusBar,
        CustomBar: o.globalData.CustomBar,
        index: "",
        indexCurrent: null,
        noData: !1,
        listLen: ""
    },
    onLoad: function() {
        var t = wx.getStorageSync("compId");
        this.setData({
            code: t
        }), t && (n = 1, this.getCompDetail(), this.getGroups(), this.getCalist(n));
    },
    bindplay: function(t) {
        var e = t.currentTarget.dataset.id;
        (console.log("indexCurrent===>", this.data.indexCurrent), console.log(t), console.log(this.data.indexCurrent, !!this.data.indexCurrent), 
        this.data.indexCurrent) && i.getTxvContext(this.data.indexCurrent).pause();
        this.setData({
            indexCurrent: e
        });
    },
    videoPlay: function(t) {
        var e = t.currentTarget.dataset.index, a = t.currentTarget.dataset.id;
        if (null != this.data.indexCurrent) {
            var o = i.getTxvContext();
            this.data.indexCurrent != e && o.pause(), this.setData({
                indexCurrent: e
            }), i.getTxvContext(a).play();
        } else {
            this.setData({
                indexCurrent: e
            }), i.getTxvContext(e).play();
        }
    },
    navigateBack: function() {
        wx.redirectTo({
            url: "/pages/index/index"
        });
    },
    showHint: function() {
        this.setData({
            showModal: !0
        });
    },
    hideModal: function() {
        this.setData({
            showModal: !1
        });
    },
    txtToggle: function() {
        var t = !this.data.txtHidden;
        this.setData({
            txtHidden: t
        });
    },
    toDetails: function(t) {
        var e = t.currentTarget.dataset.code;
        wx.navigateTo({
            url: "../details/details?compId=" + e + "&code=" + this.data.code
        });
    },
    toVote: function(t) {
        var e = t.currentTarget.dataset.code, a = t.currentTarget.dataset.index;
        this.setData({
            compId: e,
            index: a
        }), this.vote();
    },
    confirm: function(t) {
        this.data.vcode.toLowerCase() == this.data.vcodes.toLowerCase() ? (this.hideModal(), 
        this.vote()) : wx.showToast({
            title: "验证码输入有误！",
            icon: "none"
        });
    },
    codeInput: function(t) {
        var e = t.detail.value;
        this.setData({
            vcode: e
        });
    },
    keywordInput: function(t) {
        var e = t.detail.value;
        this.setData({
            title: e
        });
    },
    search: function() {
        n = 1, this.setData({
            complist: [],
            isFromSearch: !0,
            searchLoading: !0,
            searchLoadingComplete: !1
        }), this.getCalist(n);
    },
    changeType: function(t) {
        var e = t.currentTarget.dataset.id;
        n = 1, "-1" == e ? this.setData({
            groupid: ""
        }) : this.setData({
            groupid: e
        }), this.getCalist(n);
    },
    changeTypeAll: function() {
        this.setData({
            groupid: ""
        });
    },
    getCompDetail: function() {
        var t = this;
        a.request(e.getCompDetail, "POST", {
            code: t.data.code
        }, function(e) {
            if (null != e.rows) {
                t.setData({
                    comp: e.rows,
                    startTime: e.rows.startTime,
                    endTime: e.rows.endTime,
                    pollTotal: e.rows.pollTotal,
                    visit: e.rows.visit
                });
                var a = t.getFormatDate();
                a < t.data.startTime && t.setData({
                    stu: 1
                }), a > t.data.endTime && t.setData({
                    stu: 0
                }), a > t.data.startTime && a < t.data.endTime && t.setData({
                    stu: 2
                });
                var i = new Date(t.data.endTime).getTime();
                t.setData({
                    end: i
                }), t.startCountTime();
            }
        }, function(t) {
            wx.showToast({
                title: t,
                icon: "none"
            });
        });
    },
    getGroups: function() {
        var t = this;
        a.request(e.getGroups, "POST", {
            code: t.data.code
        }, function(e) {
            null != e.rows && t.setData({
                grouplist: e.rows,
                length: e.rows.length
            });
        }, function(t) {
            wx.showToast({
                title: t,
                icon: "none"
            });
        });
    },
    getCalist: function(t) {
        var i = this;
        a.request(e.getCalist, "POST", {
            code: i.data.code,
            groupid: i.data.groupid,
            page: t,
            pageSize: i.data.pageSize,
            title: i.data.title
        }, function(e) {
            null != e.rows && (t > 1 ? i.setData({
                complist: i.data.complist.concat(e.rows),
                listLen: i.data.complist.concat(e.rows).length
            }) : i.setData({
                complist: e.rows,
                listLen: e.rows.length
            }), console.log("complist===>", i.data.complist));
        }, function(t) {
            wx.showToast({
                title: t,
                icon: "none"
            });
        });
    },
    loadMore: function(t) {
        console.log("加载更多"), n++, this.getCalist(n);
    },
    vote: function() {
        var i = this;
        a.request(e.vote, "POST", {
            campcode: i.data.code,
            candicode: i.data.compId,
            vcode: i.data.vcode
        }, function(e) {
            0 == e.success && (wx.showToast({
                title: "投票成功！",
                icon: "success"
            }), i.data.complist[i.data.index].poll = e.rows.poll, i.setData(t({
                pollTotal: e.rows.campPoll,
                visit: e.rows.campVisit
            }, "complist[" + i.data.index + "]", i.data.complist[i.data.index])));
        }, function(t) {
            if ("活动已结束" == t) wx.showToast({
                title: t,
                icon: "none"
            }), i.hideModal(); else {
                if ("投票已达上限" == t) return void wx.showToast({
                    title: t,
                    icon: "none"
                });
                i.setData({
                    vcodes: t
                }), i.showHint();
            }
        });
    },
    startCountTime: function() {
        var t = this, e = setTimeout(function() {
            t.countTime(t.data.end), t.startCountTime();
        }, 1e3);
        t.setData({
            timer: e
        });
    },
    countTime: function(t) {
        var e = this.data.endTime.split(/[- :]/), a = new Date(e[0], e[1] - 1, e[2], e[3], e[4], e[5]), i = ((a = Date.parse(a)) - new Date()) / 1e3;
        if (i >= 0) {
            var o = parseInt(i / 86400), n = parseInt(i % 86400 / 3600), s = parseInt(i % 86400 % 3600 / 60), r = parseInt(i % 86400 % 3600 % 60);
            o = this.timeFormin(o), n = this.timeFormin(n), s = this.timeFormin(s), r = this.timeFormin(r), 
            this.setData({
                day: this.timeFormat(o),
                hou: this.timeFormat(n),
                min: this.timeFormat(s),
                sec: this.timeFormat(r)
            });
        }
    },
    timeFormat: function(t) {
        return t < 10 ? "0" + t : t;
    },
    timeFormin: function(t) {
        return t < 0 ? 0 : t;
    },
    getFormatDate: function() {
        var t = new Date();
        return t.getFullYear() + "-" + (t.getMonth() + 1 < 10 ? "0" + (t.getMonth() + 1) : t.getMonth() + 1) + "-" + (t.getDate() < 10 ? "0" + t.getDate() : t.getDate()) + " " + (t.getHours() < 10 ? "0" + t.getHours() : t.getHours()) + ":" + (t.getMinutes() < 10 ? "0" + t.getMinutes() : t.getMinutes()) + ":" + (t.getSeconds() < 10 ? "0" + t.getSeconds() : t.getSeconds());
    },
    onReady: function() {},
    onShow: function() {
        n = 1, this.getCompDetail(), this.getCalist(n);
    },
    onHide: function() {},
    onUnload: function() {
        this.data.timer = null;
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: "2022年护航二十大，普法新征程 投票活动开始啦",
            desc: "2022年护航二十大，普法新征程 投票活动开始啦!",
            url: "../vote/home/home?code=" + this.data.code
        };
    }
});