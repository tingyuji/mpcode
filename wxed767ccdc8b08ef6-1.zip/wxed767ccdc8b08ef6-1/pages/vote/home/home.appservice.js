$gwx_XC_18=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_18 || [];
function gz$gwx_XC_18_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_18_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_18_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_18_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'contents'])
Z([3,'info'])
Z([3,'status'])
Z([[2,'=='],[[7],[3,'stu']],[1,2]])
Z([[2,'=='],[[7],[3,'stu']],[1,1]])
Z([[2,'=='],[[7],[3,'stu']],[1,0]])
Z(z[3])
Z([[2,'>'],[[7],[3,'length']],[1,0]])
Z([3,'loadMore'])
Z([3,'videolist scrollview '])
Z([3,'true'])
Z([[7],[3,'complist']])
Z([3,'index'])
Z([[2,'>'],[[7],[3,'listLen']],[1,0]])
Z([3,'v-item'])
Z([3,'playArea'])
Z([[6],[[7],[3,'item']],[3,'videoUrl']])
Z(z[16])
Z([1,false])
Z([3,'bindplay'])
Z([3,'videoBox'])
Z(z[16])
Z([[2,'-'],[[7],[3,'data']],[[7],[3,'index']]])
Z([a,[3,'myVideo'],[[7],[3,'index']]])
Z([1,true])
Z(z[24])
Z(z[16])
Z(z[24])
Z(z[16])
Z([[6],[[7],[3,'item']],[3,'audioUrl']])
Z([[6],[[7],[3,'item']],[3,'imgUrl']])
Z([3,'btn'])
Z(z[3])
Z(z[4])
Z(z[5])
Z([[2,'<='],[[7],[3,'listLen']],[1,0]])
Z([[7],[3,'showModal']])
Z([3,'preventTouchMove'])
Z([3,'modal-mask'])
Z(z[36])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_18_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_18_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_18=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_18=true;
var x=['./pages/vote/home/home.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_18_1()
var o4B=_n('view')
_rz(z,o4B,'class',0,e,s,gg)
var a6B=_n('view')
_rz(z,a6B,'class',1,e,s,gg)
var e8B=_n('view')
_rz(z,e8B,'class',2,e,s,gg)
var b9B=_v()
_(e8B,b9B)
if(_oz(z,3,e,s,gg)){b9B.wxVkey=1
}
var o0B=_v()
_(e8B,o0B)
if(_oz(z,4,e,s,gg)){o0B.wxVkey=1
}
var xAC=_v()
_(e8B,xAC)
if(_oz(z,5,e,s,gg)){xAC.wxVkey=1
}
b9B.wxXCkey=1
o0B.wxXCkey=1
xAC.wxXCkey=1
_(a6B,e8B)
var t7B=_v()
_(a6B,t7B)
if(_oz(z,6,e,s,gg)){t7B.wxVkey=1
}
t7B.wxXCkey=1
_(o4B,a6B)
var l5B=_v()
_(o4B,l5B)
if(_oz(z,7,e,s,gg)){l5B.wxVkey=1
}
var oBC=_mz(z,'scroll-view',['bindscrolltolower',8,'class',1,'scrollY',2],[],e,s,gg)
var cDC=_v()
_(oBC,cDC)
var hEC=function(cGC,oFC,oHC,gg){
var aJC=_v()
_(oHC,aJC)
if(_oz(z,13,cGC,oFC,gg)){aJC.wxVkey=1
var tKC=_n('view')
_rz(z,tKC,'class',14,cGC,oFC,gg)
var eLC=_n('view')
_rz(z,eLC,'class',15,cGC,oFC,gg)
var bMC=_v()
_(eLC,bMC)
if(_oz(z,16,cGC,oFC,gg)){bMC.wxVkey=1
var oPC=_v()
_(bMC,oPC)
if(_oz(z,17,cGC,oFC,gg)){oPC.wxVkey=1
var fQC=_mz(z,'txv-video',['autoplay',18,'bindtap',1,'class',2,'data-id',3,'data-index',4,'id',5,'isHiddenStop',6,'isNeedMutex',7,'playerid',8,'showCenterPlayBtn',9,'vid',10],[],cGC,oFC,gg)
_(oPC,fQC)
}
oPC.wxXCkey=1
oPC.wxXCkey=3
}
var oNC=_v()
_(eLC,oNC)
if(_oz(z,29,cGC,oFC,gg)){oNC.wxVkey=1
}
var xOC=_v()
_(eLC,xOC)
if(_oz(z,30,cGC,oFC,gg)){xOC.wxVkey=1
}
bMC.wxXCkey=1
bMC.wxXCkey=3
oNC.wxXCkey=1
xOC.wxXCkey=1
_(tKC,eLC)
var cRC=_n('view')
_rz(z,cRC,'class',31,cGC,oFC,gg)
var hSC=_v()
_(cRC,hSC)
if(_oz(z,32,cGC,oFC,gg)){hSC.wxVkey=1
}
var oTC=_v()
_(cRC,oTC)
if(_oz(z,33,cGC,oFC,gg)){oTC.wxVkey=1
}
var cUC=_v()
_(cRC,cUC)
if(_oz(z,34,cGC,oFC,gg)){cUC.wxVkey=1
}
hSC.wxXCkey=1
oTC.wxXCkey=1
cUC.wxXCkey=1
_(tKC,cRC)
_(aJC,tKC)
}
aJC.wxXCkey=1
aJC.wxXCkey=3
return oHC
}
cDC.wxXCkey=4
_2z(z,11,hEC,e,s,gg,cDC,'item','index','index')
var fCC=_v()
_(oBC,fCC)
if(_oz(z,35,e,s,gg)){fCC.wxVkey=1
}
fCC.wxXCkey=1
_(o4B,oBC)
l5B.wxXCkey=1
_(r,o4B)
var c3B=_v()
_(r,c3B)
if(_oz(z,36,e,s,gg)){c3B.wxVkey=1
var oVC=_mz(z,'view',['catchtouchmove',37,'class',1],[],e,s,gg)
var lWC=_v()
_(oVC,lWC)
if(_oz(z,39,e,s,gg)){lWC.wxVkey=1
}
lWC.wxXCkey=1
_(c3B,oVC)
}
c3B.wxXCkey=1
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_18";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_18();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/vote/home/home.wxml'] = [$gwx_XC_18, './pages/vote/home/home.wxml'];else __wxAppCode__['pages/vote/home/home.wxml'] = $gwx_XC_18( './pages/vote/home/home.wxml' );
	;__wxRoute = "pages/vote/home/home";__wxRouteBegin = true;__wxAppCurrentFile__="pages/vote/home/home.js";define("pages/vote/home/home.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var t=require("../../../@babel/runtime/helpers/defineProperty"),e=require("../../../config.js"),a=require("../../../http.js"),i=requirePlugin("tencentvideo"),o=getApp(),n=1;Page({data:{item:["https://cdn.pluslegal.cn/xxzzb%2Fhome_img_banner%402x.png"],txtHidden:!0,showModal:!1,code:"",comp:{},pageSize:10,groupid:"",caContent:{},vcode:"",vcodes:"",title:"",startTime:"",endTime:"",beg:"",end:"",StatusBar:o.globalData.StatusBar,CustomBar:o.globalData.CustomBar,index:"",indexCurrent:null,noData:!1,listLen:""},onLoad:function(){var t=wx.getStorageSync("compId");this.setData({code:t}),t&&(n=1,this.getCompDetail(),this.getGroups(),this.getCalist(n))},bindplay:function(t){var e=t.currentTarget.dataset.id;(console.log("indexCurrent===>",this.data.indexCurrent),console.log(t),console.log(this.data.indexCurrent,!!this.data.indexCurrent),this.data.indexCurrent)&&i.getTxvContext(this.data.indexCurrent).pause();this.setData({indexCurrent:e})},videoPlay:function(t){var e=t.currentTarget.dataset.index,a=t.currentTarget.dataset.id;if(null!=this.data.indexCurrent){var o=i.getTxvContext();this.data.indexCurrent!=e&&o.pause(),this.setData({indexCurrent:e}),i.getTxvContext(a).play()}else{this.setData({indexCurrent:e}),i.getTxvContext(e).play()}},navigateBack:function(){wx.redirectTo({url:"/pages/index/index"})},showHint:function(){this.setData({showModal:!0})},hideModal:function(){this.setData({showModal:!1})},txtToggle:function(){var t=!this.data.txtHidden;this.setData({txtHidden:t})},toDetails:function(t){var e=t.currentTarget.dataset.code;wx.navigateTo({url:"../details/details?compId="+e+"&code="+this.data.code})},toVote:function(t){var e=t.currentTarget.dataset.code,a=t.currentTarget.dataset.index;this.setData({compId:e,index:a}),this.vote()},confirm:function(t){this.data.vcode.toLowerCase()==this.data.vcodes.toLowerCase()?(this.hideModal(),this.vote()):wx.showToast({title:"验证码输入有误！",icon:"none"})},codeInput:function(t){var e=t.detail.value;this.setData({vcode:e})},keywordInput:function(t){var e=t.detail.value;this.setData({title:e})},search:function(){n=1,this.setData({complist:[],isFromSearch:!0,searchLoading:!0,searchLoadingComplete:!1}),this.getCalist(n)},changeType:function(t){var e=t.currentTarget.dataset.id;n=1,"-1"==e?this.setData({groupid:""}):this.setData({groupid:e}),this.getCalist(n)},changeTypeAll:function(){this.setData({groupid:""})},getCompDetail:function(){var t=this;a.request(e.getCompDetail,"POST",{code:t.data.code},(function(e){if(null!=e.rows){t.setData({comp:e.rows,startTime:e.rows.startTime,endTime:e.rows.endTime,pollTotal:e.rows.pollTotal,visit:e.rows.visit});var a=t.getFormatDate();a<t.data.startTime&&t.setData({stu:1}),a>t.data.endTime&&t.setData({stu:0}),a>t.data.startTime&&a<t.data.endTime&&t.setData({stu:2});var i=new Date(t.data.endTime).getTime();t.setData({end:i}),t.startCountTime()}}),(function(t){wx.showToast({title:t,icon:"none"})}))},getGroups:function(){var t=this;a.request(e.getGroups,"POST",{code:t.data.code},(function(e){null!=e.rows&&t.setData({grouplist:e.rows,length:e.rows.length})}),(function(t){wx.showToast({title:t,icon:"none"})}))},getCalist:function(t){var i=this;a.request(e.getCalist,"POST",{code:i.data.code,groupid:i.data.groupid,page:t,pageSize:i.data.pageSize,title:i.data.title},(function(e){null!=e.rows&&(t>1?i.setData({complist:i.data.complist.concat(e.rows),listLen:i.data.complist.concat(e.rows).length}):i.setData({complist:e.rows,listLen:e.rows.length}),console.log("complist===>",i.data.complist))}),(function(t){wx.showToast({title:t,icon:"none"})}))},loadMore:function(t){console.log("加载更多"),n++,this.getCalist(n)},vote:function(){var i=this;a.request(e.vote,"POST",{campcode:i.data.code,candicode:i.data.compId,vcode:i.data.vcode},(function(e){0==e.success&&(wx.showToast({title:"投票成功！",icon:"success"}),i.data.complist[i.data.index].poll=e.rows.poll,i.setData(t({pollTotal:e.rows.campPoll,visit:e.rows.campVisit},"complist["+i.data.index+"]",i.data.complist[i.data.index])))}),(function(t){if("活动已结束"==t)wx.showToast({title:t,icon:"none"}),i.hideModal();else{if("投票已达上限"==t)return void wx.showToast({title:t,icon:"none"});i.setData({vcodes:t}),i.showHint()}}))},startCountTime:function(){var t=this,e=setTimeout((function(){t.countTime(t.data.end),t.startCountTime()}),1e3);t.setData({timer:e})},countTime:function(t){var e=this.data.endTime.split(/[- :]/),a=new Date(e[0],e[1]-1,e[2],e[3],e[4],e[5]),i=((a=Date.parse(a))-new Date)/1e3;if(i>=0){var o=parseInt(i/86400),n=parseInt(i%86400/3600),s=parseInt(i%86400%3600/60),r=parseInt(i%86400%3600%60);o=this.timeFormin(o),n=this.timeFormin(n),s=this.timeFormin(s),r=this.timeFormin(r),this.setData({day:this.timeFormat(o),hou:this.timeFormat(n),min:this.timeFormat(s),sec:this.timeFormat(r)})}},timeFormat:function(t){return t<10?"0"+t:t},timeFormin:function(t){return t<0?0:t},getFormatDate:function(){var t=new Date;return t.getFullYear()+"-"+(t.getMonth()+1<10?"0"+(t.getMonth()+1):t.getMonth()+1)+"-"+(t.getDate()<10?"0"+t.getDate():t.getDate())+" "+(t.getHours()<10?"0"+t.getHours():t.getHours())+":"+(t.getMinutes()<10?"0"+t.getMinutes():t.getMinutes())+":"+(t.getSeconds()<10?"0"+t.getSeconds():t.getSeconds())},onReady:function(){},onShow:function(){n=1,this.getCompDetail(),this.getCalist(n)},onHide:function(){},onUnload:function(){this.data.timer=null},onPullDownRefresh:function(){},onReachBottom:function(){},onShareAppMessage:function(){return{title:"2022年护航二十大，普法新征程 投票活动开始啦",desc:"2022年护航二十大，普法新征程 投票活动开始啦!",url:"../vote/home/home?code="+this.data.code}}});
},{isPage:true,isComponent:true,currentFile:'pages/vote/home/home.js'});require("pages/vote/home/home.js");