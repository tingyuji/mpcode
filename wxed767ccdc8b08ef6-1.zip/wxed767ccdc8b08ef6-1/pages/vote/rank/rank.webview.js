$gwx_XC_19=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_19 || [];
function gz$gwx_XC_19_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_19_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_19_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_19_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'cu-custom'])
Z([a,[3,'height:'],[[7],[3,'CustomBar']],[3,'px;']])
Z([3,'cu-bar fixed none-bg text-white bg-img'])
Z([a,z[1][1],z[1][2],[3,'px;padding-top:'],[[7],[3,'StatusBar']],z[1][3]])
Z([3,'navigateBack'])
Z([3,'canui-head-title action'])
Z([3,'none'])
Z([3,'icon-back'])
Z([3,'/images/home.png'])
Z([[7],[3,'autoplay']])
Z([3,'swiperChange'])
Z([3,'swiper'])
Z([[7],[3,'duration']])
Z([[7],[3,'indicatorDots']])
Z([[7],[3,'interval']])
Z([3,'showDialogBtn'])
Z([3,'swiper-item'])
Z([3,'toExam'])
Z([3,'slide-image'])
Z([[6],[[7],[3,'comp']],[3,'imgUrl']])
Z([3,'contents'])
Z([3,'info'])
Z([3,'title'])
Z([a,[3,' '],[[6],[[7],[3,'comp']],[3,'title']],[3,' ']])
Z([3,'total'])
Z([3,'bl'])
Z([a,[[6],[[7],[3,'comp']],[3,'pollTotal']]])
Z(z[25])
Z([3,'总票数'])
Z(z[25])
Z([a,[[6],[[7],[3,'comp']],[3,'candiAmount']]])
Z(z[25])
Z([3,'选手数'])
Z(z[25])
Z([a,[[6],[[7],[3,'comp']],[3,'visit']]])
Z(z[25])
Z([3,'访问量'])
Z([3,'status'])
Z([[2,'=='],[[7],[3,'stu']],[1,2]])
Z([3,'ing'])
Z([3,'活动进行中~'])
Z([[2,'=='],[[7],[3,'stu']],[1,1]])
Z([3,'noting'])
Z([3,'活动未开始!'])
Z([[2,'=='],[[7],[3,'stu']],[1,0]])
Z(z[42])
Z([3,'活动已结束!'])
Z(z[38])
Z([3,'time'])
Z([3,' 距投票结束还有 '])
Z([3,'textColor'])
Z([a,[[7],[3,'day']]])
Z([3,'天'])
Z(z[50])
Z([a,[[7],[3,'hou']]])
Z([3,'时'])
Z(z[50])
Z([a,[[7],[3,'min']]])
Z([3,'分'])
Z(z[50])
Z([a,[[7],[3,'sec']]])
Z([3,'秒 '])
Z([3,'voteList'])
Z([3,'toplist'])
Z(z[22])
Z([3,'—'])
Z([3,' 排行榜 '])
Z(z[65])
Z([3,'item thead'])
Z([3,'排名'])
Z([3,'姓名'])
Z([3,'票数'])
Z([3,'loadMoreData'])
Z([3,'content'])
Z([3,'true'])
Z([[7],[3,'rankData']])
Z([3,'*this'])
Z([[2,'>'],[[7],[3,'listLen']],[1,0]])
Z([3,'item'])
Z([3,'item-no'])
Z([a,[[6],[[7],[3,'item']],[3,'rank']]])
Z([3,'item-name'])
Z([a,[[6],[[7],[3,'item']],[3,'title']]])
Z([3,'item-value'])
Z([a,[[6],[[7],[3,'item']],[3,'poll']]])
Z([[2,'<='],[[7],[3,'listLen']],[1,0]])
Z([3,'noData'])
Z([3,' 暂无数据~ '])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_19_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_19_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_19=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_19=true;
var x=['./pages/vote/rank/rank.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_19_1()
var oDU=_mz(z,'view',['class',0,'style',1],[],e,s,gg)
var lEU=_mz(z,'view',['class',2,'style',1],[],e,s,gg)
var aFU=_mz(z,'view',['bindtap',4,'class',1,'hoverClass',2],[],e,s,gg)
var tGU=_mz(z,'image',['class',7,'src',1],[],e,s,gg)
_(aFU,tGU)
_(lEU,aFU)
_(oDU,lEU)
_(r,oDU)
var eHU=_mz(z,'swiper',['autoplay',9,'bindchange',1,'class',2,'duration',3,'indicatorDots',4,'interval',5],[],e,s,gg)
var bIU=_mz(z,'swiper-item',['bindtap',15,'class',1],[],e,s,gg)
var oJU=_mz(z,'image',['bindtap',17,'class',1,'src',2],[],e,s,gg)
_(bIU,oJU)
_(eHU,bIU)
_(r,eHU)
var xKU=_n('view')
_rz(z,xKU,'class',20,e,s,gg)
var oLU=_n('view')
_rz(z,oLU,'class',21,e,s,gg)
var cNU=_n('view')
_rz(z,cNU,'class',22,e,s,gg)
var hOU=_oz(z,23,e,s,gg)
_(cNU,hOU)
_(oLU,cNU)
var oPU=_n('view')
_rz(z,oPU,'class',24,e,s,gg)
var cQU=_n('view')
var oRU=_n('text')
_rz(z,oRU,'class',25,e,s,gg)
var lSU=_oz(z,26,e,s,gg)
_(oRU,lSU)
_(cQU,oRU)
var aTU=_n('text')
_rz(z,aTU,'class',27,e,s,gg)
var tUU=_oz(z,28,e,s,gg)
_(aTU,tUU)
_(cQU,aTU)
_(oPU,cQU)
var eVU=_n('view')
var bWU=_n('text')
_rz(z,bWU,'class',29,e,s,gg)
var oXU=_oz(z,30,e,s,gg)
_(bWU,oXU)
_(eVU,bWU)
var xYU=_n('text')
_rz(z,xYU,'class',31,e,s,gg)
var oZU=_oz(z,32,e,s,gg)
_(xYU,oZU)
_(eVU,xYU)
_(oPU,eVU)
var f1U=_n('view')
var c2U=_n('text')
_rz(z,c2U,'class',33,e,s,gg)
var h3U=_oz(z,34,e,s,gg)
_(c2U,h3U)
_(f1U,c2U)
var o4U=_n('text')
_rz(z,o4U,'class',35,e,s,gg)
var c5U=_oz(z,36,e,s,gg)
_(o4U,c5U)
_(f1U,o4U)
_(oPU,f1U)
_(oLU,oPU)
var o6U=_n('view')
_rz(z,o6U,'class',37,e,s,gg)
var l7U=_v()
_(o6U,l7U)
if(_oz(z,38,e,s,gg)){l7U.wxVkey=1
var e0U=_n('view')
_rz(z,e0U,'class',39,e,s,gg)
var bAV=_oz(z,40,e,s,gg)
_(e0U,bAV)
_(l7U,e0U)
}
var a8U=_v()
_(o6U,a8U)
if(_oz(z,41,e,s,gg)){a8U.wxVkey=1
var oBV=_n('view')
_rz(z,oBV,'class',42,e,s,gg)
var xCV=_oz(z,43,e,s,gg)
_(oBV,xCV)
_(a8U,oBV)
}
var t9U=_v()
_(o6U,t9U)
if(_oz(z,44,e,s,gg)){t9U.wxVkey=1
var oDV=_n('view')
_rz(z,oDV,'class',45,e,s,gg)
var fEV=_oz(z,46,e,s,gg)
_(oDV,fEV)
_(t9U,oDV)
}
l7U.wxXCkey=1
a8U.wxXCkey=1
t9U.wxXCkey=1
_(oLU,o6U)
var fMU=_v()
_(oLU,fMU)
if(_oz(z,47,e,s,gg)){fMU.wxVkey=1
var cFV=_n('view')
_rz(z,cFV,'class',48,e,s,gg)
var hGV=_oz(z,49,e,s,gg)
_(cFV,hGV)
var oHV=_n('text')
_rz(z,oHV,'class',50,e,s,gg)
var cIV=_oz(z,51,e,s,gg)
_(oHV,cIV)
_(cFV,oHV)
var oJV=_oz(z,52,e,s,gg)
_(cFV,oJV)
var lKV=_n('text')
_rz(z,lKV,'class',53,e,s,gg)
var aLV=_oz(z,54,e,s,gg)
_(lKV,aLV)
_(cFV,lKV)
var tMV=_oz(z,55,e,s,gg)
_(cFV,tMV)
var eNV=_n('text')
_rz(z,eNV,'class',56,e,s,gg)
var bOV=_oz(z,57,e,s,gg)
_(eNV,bOV)
_(cFV,eNV)
var oPV=_oz(z,58,e,s,gg)
_(cFV,oPV)
var xQV=_n('text')
_rz(z,xQV,'class',59,e,s,gg)
var oRV=_oz(z,60,e,s,gg)
_(xQV,oRV)
_(cFV,xQV)
var fSV=_oz(z,61,e,s,gg)
_(cFV,fSV)
_(fMU,cFV)
}
fMU.wxXCkey=1
_(xKU,oLU)
var cTV=_n('view')
_rz(z,cTV,'class',62,e,s,gg)
var hUV=_n('view')
_rz(z,hUV,'class',63,e,s,gg)
var oVV=_n('view')
_rz(z,oVV,'class',64,e,s,gg)
var cWV=_n('em')
var oXV=_oz(z,65,e,s,gg)
_(cWV,oXV)
_(oVV,cWV)
var lYV=_oz(z,66,e,s,gg)
_(oVV,lYV)
var aZV=_n('em')
var t1V=_oz(z,67,e,s,gg)
_(aZV,t1V)
_(oVV,aZV)
_(hUV,oVV)
_(cTV,hUV)
var e2V=_n('view')
_rz(z,e2V,'class',68,e,s,gg)
var b3V=_n('text')
var o4V=_oz(z,69,e,s,gg)
_(b3V,o4V)
_(e2V,b3V)
var x5V=_n('text')
var o6V=_oz(z,70,e,s,gg)
_(x5V,o6V)
_(e2V,x5V)
var f7V=_n('text')
var c8V=_oz(z,71,e,s,gg)
_(f7V,c8V)
_(e2V,f7V)
_(cTV,e2V)
var h9V=_mz(z,'scroll-view',['bindscrolltolower',72,'class',1,'scrollY',2],[],e,s,gg)
var cAW=_v()
_(h9V,cAW)
var oBW=function(aDW,lCW,tEW,gg){
var bGW=_v()
_(tEW,bGW)
if(_oz(z,77,aDW,lCW,gg)){bGW.wxVkey=1
var oHW=_n('view')
_rz(z,oHW,'class',78,aDW,lCW,gg)
var xIW=_n('text')
_rz(z,xIW,'class',79,aDW,lCW,gg)
var oJW=_oz(z,80,aDW,lCW,gg)
_(xIW,oJW)
_(oHW,xIW)
var fKW=_n('text')
_rz(z,fKW,'class',81,aDW,lCW,gg)
var cLW=_oz(z,82,aDW,lCW,gg)
_(fKW,cLW)
_(oHW,fKW)
var hMW=_n('text')
_rz(z,hMW,'class',83,aDW,lCW,gg)
var oNW=_oz(z,84,aDW,lCW,gg)
_(hMW,oNW)
_(oHW,hMW)
_(bGW,oHW)
}
bGW.wxXCkey=1
return tEW
}
cAW.wxXCkey=2
_2z(z,75,oBW,e,s,gg,cAW,'item','index','*this')
var o0V=_v()
_(h9V,o0V)
if(_oz(z,85,e,s,gg)){o0V.wxVkey=1
var cOW=_n('view')
_rz(z,cOW,'class',86,e,s,gg)
var oPW=_oz(z,87,e,s,gg)
_(cOW,oPW)
_(o0V,cOW)
}
o0V.wxXCkey=1
_(cTV,h9V)
_(xKU,cTV)
_(r,xKU)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_19";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_19();
	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/vote/rank/rank.wxml'] = [$gwx_XC_19, './pages/vote/rank/rank.wxml'];else __wxAppCode__['pages/vote/rank/rank.wxml'] = $gwx_XC_19( './pages/vote/rank/rank.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['pages/vote/rank/rank.wxss'] = setCssToHead(["body{background-color:#ac1212}\n.",[1],"item{-webkit-align-items:center;align-items:center;border-bottom:",[0,1]," solid #eda256;display:-webkit-flex;display:flex;-webkit-flex-direction:row;flex-direction:row;height:",[0,96],";-webkit-justify-content:space-between;justify-content:space-between;padding:0 ",[0,20],"}\n.",[1],"item:last-child{border-bottom:none}\n.",[1],"item\x3ewx-text{-webkit-flex:1;flex:1}\n.",[1],"item-no{color:#ea3323;font-size:",[0,34],"}\n.",[1],"item-no2{color:#cd003f;font-size:",[0,34],"}\n.",[1],"item-no3{color:#451b8b;font-size:",[0,34],"}\n.",[1],"item-no4{color:#222;font-size:",[0,34],"}\n.",[1],"item-img{background-color:#8b1b23;border-radius:50%;height:",[0,56],";margin-left:",[0,20],";width:",[0,56],"}\n.",[1],"item-num{color:#666}\n.",[1],"item-name{margin-left:",[0,25],"}\n.",[1],"item-name,.",[1],"item-value{color:#000;font-size:",[0,28],"}\n.",[1],"item-value{margin-right:",[0,30],"}\n.",[1],"thead{background-color:#700c0a;color:#fff}\n.",[1],"voteList{background-color:none!important;padding:0}\n.",[1],"voteList .",[1],"toplist{background:url(\x22https://cdn.pluslegal.cn/xxzzb%2Fhome_rules_img_bg%402x.png\x22)no-repeat;background-color:none!important;background-size:100% auto;height:100%;padding:",[0,10]," 0;width:100%}\n.",[1],"voteList .",[1],"title{background:linear-gradient(90deg,#a40f0f,#e82828 51%,#a40f0f);border-radius:0 0 ",[0,30]," ",[0,30],";color:#f9dca7;font-size:",[0,36],";font-weight:600;height:",[0,90],";line-height:",[0,90],";margin:",[0,30]," auto;text-align:center!important;width:50%}\n.",[1],"content{background-color:#fff;border-radius:0 0 ",[0,10]," ",[0,10],";height:",[0,600],";min-height:",[0,300],"}\n",],"Some selectors are not allowed in component wxss, including tag name selectors, ID selectors, and attribute selectors.(./pages/vote/rank/rank.wxss:1:335)",{path:"./pages/vote/rank/rank.wxss"});
}