$gwx_XC_19=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_19 || [];
function gz$gwx_XC_19_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_19_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_19_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_19_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'contents'])
Z([3,'info'])
Z([3,'status'])
Z([[2,'=='],[[7],[3,'stu']],[1,2]])
Z([[2,'=='],[[7],[3,'stu']],[1,1]])
Z([[2,'=='],[[7],[3,'stu']],[1,0]])
Z(z[3])
Z([3,'loadMoreData'])
Z([3,'content'])
Z([3,'true'])
Z([[7],[3,'rankData']])
Z([3,'*this'])
Z([[2,'>'],[[7],[3,'listLen']],[1,0]])
Z([[2,'<='],[[7],[3,'listLen']],[1,0]])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_19_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_19_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_19=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_19=true;
var x=['./pages/vote/rank/rank.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_19_1()
var tYC=_n('view')
_rz(z,tYC,'class',0,e,s,gg)
var eZC=_n('view')
_rz(z,eZC,'class',1,e,s,gg)
var o2C=_n('view')
_rz(z,o2C,'class',2,e,s,gg)
var x3C=_v()
_(o2C,x3C)
if(_oz(z,3,e,s,gg)){x3C.wxVkey=1
}
var o4C=_v()
_(o2C,o4C)
if(_oz(z,4,e,s,gg)){o4C.wxVkey=1
}
var f5C=_v()
_(o2C,f5C)
if(_oz(z,5,e,s,gg)){f5C.wxVkey=1
}
x3C.wxXCkey=1
o4C.wxXCkey=1
f5C.wxXCkey=1
_(eZC,o2C)
var b1C=_v()
_(eZC,b1C)
if(_oz(z,6,e,s,gg)){b1C.wxVkey=1
}
b1C.wxXCkey=1
_(tYC,eZC)
var c6C=_mz(z,'scroll-view',['bindscrolltolower',7,'class',1,'scrollY',2],[],e,s,gg)
var o8C=_v()
_(c6C,o8C)
var c9C=function(lAD,o0C,aBD,gg){
var eDD=_v()
_(aBD,eDD)
if(_oz(z,12,lAD,o0C,gg)){eDD.wxVkey=1
}
eDD.wxXCkey=1
return aBD
}
o8C.wxXCkey=2
_2z(z,10,c9C,e,s,gg,o8C,'item','index','*this')
var h7C=_v()
_(c6C,h7C)
if(_oz(z,13,e,s,gg)){h7C.wxVkey=1
}
h7C.wxXCkey=1
_(tYC,c6C)
_(r,tYC)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_19";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_19();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/vote/rank/rank.wxml'] = [$gwx_XC_19, './pages/vote/rank/rank.wxml'];else __wxAppCode__['pages/vote/rank/rank.wxml'] = $gwx_XC_19( './pages/vote/rank/rank.wxml' );
	;__wxRoute = "pages/vote/rank/rank";__wxRouteBegin = true;__wxAppCurrentFile__="pages/vote/rank/rank.js";define("pages/vote/rank/rank.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var t=require("../../../config.js"),e=require("../../../http.js"),a=getApp(),n=1;Page({data:{code:"",StatusBar:a.globalData.StatusBar,CustomBar:a.globalData.CustomBar,listLen:""},loadMoreData:function(){n++,this.getAllRank(n)},onLoad:function(t){var e=wx.getStorageSync("compId");console.log(e),this.setData({code:e}),n=1,this.getAllRank(n),this.getCompDetail()},onReady:function(){this.getCompDetail()},onShow:function(){},onHide:function(){},onUnload:function(){this.data.timer=null},getAllRank:function(a){var n=this;e.request(t.getRank,"POST",{code:n.data.code,page:a,pageSize:10},(function(t){null!=t.rows&&(a>1?n.setData({rankData:n.data.rankData.concat(t.rows),listLen:n.data.complist.concat(t.rows).length}):(n.setData({rankData:t.rows,listLen:t.rows.length}),console.log("listLen===>",n.data.listLen)))}),(function(t){wx.showToast({title:t,icon:"none"})}))},getCompDetail:function(){var a=this;e.request(t.getCompDetail,"POST",{code:a.data.code},(function(t){if(null!=t.rows){a.setData({comp:t.rows,startTime:t.rows.startTime,endTime:t.rows.endTime});var e=a.getFormatDate();e<a.data.startTime&&a.setData({stu:1}),e>a.data.endTime&&a.setData({stu:0}),e>a.data.startTime&&e<a.data.endTime&&a.setData({stu:2});var n=new Date(a.data.endTime).getTime();console.log(n),a.setData({end:n}),a.startCountTime()}}),(function(t){wx.showToast({title:t,icon:"none"})}))},startCountTime:function(){var t=this,e=setTimeout((function(){t.countTime(t.data.end),t.startCountTime()}),1e3);t.setData({timer:e})},countTime:function(t){var e=this.data.endTime.split(/[- :]/),a=new Date(e[0],e[1]-1,e[2],e[3],e[4],e[5]),n=((a=Date.parse(a))-new Date)/1e3;if(n>=0){var o=parseInt(n/86400),i=parseInt(n%86400/3600),s=parseInt(n%86400%3600/60),r=parseInt(n%86400%3600%60);o=this.timeFormin(o),i=this.timeFormin(i),s=this.timeFormin(s),r=this.timeFormin(r),this.setData({day:this.timeFormat(o),hou:this.timeFormat(i),min:this.timeFormat(s),sec:this.timeFormat(r)})}},timeFormat:function(t){return t<10?"0"+t:t},timeFormin:function(t){return t<0?0:t},getFormatDate:function(){var t=new Date;return t.getFullYear()+"-"+(t.getMonth()+1<10?"0"+(t.getMonth()+1):t.getMonth()+1)+"-"+(t.getDate()<10?"0"+t.getDate():t.getDate())+" "+(t.getHours()<10?"0"+t.getHours():t.getHours())+":"+(t.getMinutes()<10?"0"+t.getMinutes():t.getMinutes())+":"+(t.getSeconds()<10?"0"+t.getSeconds():t.getSeconds())},navigateBack:function(){wx.redirectTo({url:"/pages/index/index"})}});
},{isPage:true,isComponent:true,currentFile:'pages/vote/rank/rank.js'});require("pages/vote/rank/rank.js");