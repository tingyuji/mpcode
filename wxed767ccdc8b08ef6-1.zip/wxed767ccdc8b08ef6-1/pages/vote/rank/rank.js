var t = require("../../../config.js"), e = require("../../../http.js"), a = getApp(), n = 1;

Page({
    data: {
        code: "",
        StatusBar: a.globalData.StatusBar,
        CustomBar: a.globalData.CustomBar,
        listLen: ""
    },
    loadMoreData: function() {
        n++, this.getAllRank(n);
    },
    onLoad: function(t) {
        var e = wx.getStorageSync("compId");
        console.log(e), this.setData({
            code: e
        }), n = 1, this.getAllRank(n), this.getCompDetail();
    },
    onReady: function() {
        this.getCompDetail();
    },
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {
        this.data.timer = null;
    },
    getAllRank: function(a) {
        var n = this;
        e.request(t.getRank, "POST", {
            code: n.data.code,
            page: a,
            pageSize: 10
        }, function(t) {
            null != t.rows && (a > 1 ? n.setData({
                rankData: n.data.rankData.concat(t.rows),
                listLen: n.data.complist.concat(t.rows).length
            }) : (n.setData({
                rankData: t.rows,
                listLen: t.rows.length
            }), console.log("listLen===>", n.data.listLen)));
        }, function(t) {
            wx.showToast({
                title: t,
                icon: "none"
            });
        });
    },
    getCompDetail: function() {
        var a = this;
        e.request(t.getCompDetail, "POST", {
            code: a.data.code
        }, function(t) {
            if (null != t.rows) {
                a.setData({
                    comp: t.rows,
                    startTime: t.rows.startTime,
                    endTime: t.rows.endTime
                });
                var e = a.getFormatDate();
                e < a.data.startTime && a.setData({
                    stu: 1
                }), e > a.data.endTime && a.setData({
                    stu: 0
                }), e > a.data.startTime && e < a.data.endTime && a.setData({
                    stu: 2
                });
                var n = new Date(a.data.endTime).getTime();
                console.log(n), a.setData({
                    end: n
                }), a.startCountTime();
            }
        }, function(t) {
            wx.showToast({
                title: t,
                icon: "none"
            });
        });
    },
    startCountTime: function() {
        var t = this, e = setTimeout(function() {
            t.countTime(t.data.end), t.startCountTime();
        }, 1e3);
        t.setData({
            timer: e
        });
    },
    countTime: function(t) {
        var e = this.data.endTime.split(/[- :]/), a = new Date(e[0], e[1] - 1, e[2], e[3], e[4], e[5]), n = ((a = Date.parse(a)) - new Date()) / 1e3;
        if (n >= 0) {
            var o = parseInt(n / 86400), i = parseInt(n % 86400 / 3600), s = parseInt(n % 86400 % 3600 / 60), r = parseInt(n % 86400 % 3600 % 60);
            o = this.timeFormin(o), i = this.timeFormin(i), s = this.timeFormin(s), r = this.timeFormin(r), 
            this.setData({
                day: this.timeFormat(o),
                hou: this.timeFormat(i),
                min: this.timeFormat(s),
                sec: this.timeFormat(r)
            });
        }
    },
    timeFormat: function(t) {
        return t < 10 ? "0" + t : t;
    },
    timeFormin: function(t) {
        return t < 0 ? 0 : t;
    },
    getFormatDate: function() {
        var t = new Date();
        return t.getFullYear() + "-" + (t.getMonth() + 1 < 10 ? "0" + (t.getMonth() + 1) : t.getMonth() + 1) + "-" + (t.getDate() < 10 ? "0" + t.getDate() : t.getDate()) + " " + (t.getHours() < 10 ? "0" + t.getHours() : t.getHours()) + ":" + (t.getMinutes() < 10 ? "0" + t.getMinutes() : t.getMinutes()) + ":" + (t.getSeconds() < 10 ? "0" + t.getSeconds() : t.getSeconds());
    },
    navigateBack: function() {
        wx.redirectTo({
            url: "/pages/index/index"
        });
    }
});