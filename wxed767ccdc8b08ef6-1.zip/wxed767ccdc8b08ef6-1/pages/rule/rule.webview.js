$gwx_XC_13=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_13 || [];
function gz$gwx_XC_13_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_13_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_13_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_13_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container'])
Z([3,'title'])
Z([3,'考试规则介绍'])
Z([3,'content'])
Z([3,'1.进入答题小程序，请连接较为畅通的网络以确保顺利打开和加载程序。\n2.答题需要的时间较长，请注意保持手机电量。\n3.答题最终成绩仅有一次提交机会，一经提交，成绩无法改变且不能再次答题。\n4.答题人员务必严格按照提示要求如实填写个人信息，同一手机号码和同一微信号仅记录一个人信息。\n5.如遇网络故障或程序故障无法作答的情况，请留下实时屏幕截图并及时向本单位反馈。\n6.答题满分为100分，60分以下为不及格，成绩不合格者应进行补考，补考时间将在“西藏组工”微信公众号上另行通知。\n  '])
Z([3,'line'])
Z(z[1])
Z([3,'考试流程说明'])
Z(z[3])
Z([3,'首页点击“未登陆”—\x3e西藏党员干部考试系统“获取您的公开信息（昵称、头像）”点击【允许】—\x3e理论知识测试申请“获取您的昵称、头像、地区及性别”点击【允许】—\x3e点击【微信手机号登录】—\x3e“理论知识测试”申请使用“您的手机号码”点击【允许】—\x3e录入个人基本信息，点击【确定】—\x3e点击主题考试图片，如“《习近平谈治国理政》第三卷知识测试”—\x3e点击【开始考试】进行考试答题。\n注：\n1.请在通知规定时间内参加考试。\n2.考试时间过后，只能在真题回顾中查看考试真题，不能再次参加考试。\n3.基于安全机制约束，长时间未登录小程序用户需要重新进行微信授权。授权后方可再次使用理论知识测试小程序。'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_13_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_13_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_13=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_13=true;
var x=['./pages/rule/rule.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_13_1()
var x9K=_n('view')
_rz(z,x9K,'class',0,e,s,gg)
var o0K=_n('text')
_rz(z,o0K,'class',1,e,s,gg)
var fAL=_oz(z,2,e,s,gg)
_(o0K,fAL)
_(x9K,o0K)
var cBL=_n('text')
_rz(z,cBL,'class',3,e,s,gg)
var hCL=_oz(z,4,e,s,gg)
_(cBL,hCL)
_(x9K,cBL)
var oDL=_n('view')
_rz(z,oDL,'class',5,e,s,gg)
_(x9K,oDL)
var cEL=_n('text')
_rz(z,cEL,'class',6,e,s,gg)
var oFL=_oz(z,7,e,s,gg)
_(cEL,oFL)
_(x9K,cEL)
var lGL=_n('text')
_rz(z,lGL,'class',8,e,s,gg)
var aHL=_oz(z,9,e,s,gg)
_(lGL,aHL)
_(x9K,lGL)
_(r,x9K)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_13";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_13();
	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/rule/rule.wxml'] = [$gwx_XC_13, './pages/rule/rule.wxml'];else __wxAppCode__['pages/rule/rule.wxml'] = $gwx_XC_13( './pages/rule/rule.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['pages/rule/rule.wxss'] = setCssToHead([".",[1],"title{border-left:",[0,5]," solid #8b1b23;color:#8b1b23;font-size:",[0,32],";font-weight:700;margin-top:",[0,30],";padding-left:",[0,20],";width:90%}\n.",[1],"content{color:#222;font-size:",[0,30],";line-height:",[0,55],";margin-top:",[0,20],";width:90%}\n.",[1],"line{background-color:#8b1b23;height:",[0,2],";margin-top:",[0,30],";width:94%}\n",],undefined,{path:"./pages/rule/rule.wxss"});
}