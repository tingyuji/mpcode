var t = require("../../config.js"), e = require("../../http.js");

Page({
    data: {
        recordData: null,
        recordList: []
    },
    lookDetail: function(t) {
        var e = t.currentTarget.dataset.pos;
        wx.setStorageSync("testRecord", this.data.recordList[e]), wx.navigateTo({
            url: "../exam-result/exam-result?type=2"
        });
    },
    onLoad: function(t) {
        this.getAllRecords();
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    getAllRecords: function() {
        var o = this;
        e.request(t.allRecords, "POST", null, function(t) {
            null != t.data && o.setData({
                recordData: t.data,
                recordList: t.data.records
            });
        }, function(t) {
            wx.showToast({
                title: t,
                icon: "none"
            });
        });
    }
});