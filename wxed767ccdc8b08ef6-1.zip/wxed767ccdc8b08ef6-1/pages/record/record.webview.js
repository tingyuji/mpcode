$gwx_XC_11=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_11 || [];
function gz$gwx_XC_11_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_11_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_11_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_11_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container'])
Z([3,'head-bg'])
Z([3,'user-view'])
Z([3,'user-item'])
Z([3,'user-title'])
Z([3,'累计考试'])
Z([3,'user-value'])
Z([a,[[6],[[7],[3,'recordData']],[3,'total']],[3,'次']])
Z([3,'user-line'])
Z(z[3])
Z(z[4])
Z([3,'合格次数'])
Z(z[6])
Z([a,[[6],[[7],[3,'recordData']],[3,'passed']],z[7][2]])
Z([3,'scrollview'])
Z([3,'true'])
Z([[7],[3,'recordList']])
Z([3,'*this'])
Z([3,'item'])
Z([3,'item-img'])
Z([3,'item-text'])
Z([a,[[6],[[6],[[7],[3,'item']],[3,'eaeExamRecordVO']],[3,'addTime']],[3,'参加'],[[6],[[7],[3,'item']],[3,'examName']],[3,'考试，考试'],[[2,'?:'],[[2,'=='],[[6],[[6],[[7],[3,'item']],[3,'eaeExamRecordVO']],[3,'isPass']],[1,0]],[1,'不合格'],[1,'合格']]])
Z([3,'lookDetail'])
Z([3,'item-look'])
Z([[7],[3,'index']])
Z([3,'查看详情'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_11_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_11_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_11=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_11=true;
var x=['./pages/record/record.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_11_1()
var eZJ=_n('view')
_rz(z,eZJ,'class',0,e,s,gg)
var b1J=_n('view')
_rz(z,b1J,'class',1,e,s,gg)
_(eZJ,b1J)
var o2J=_n('view')
_rz(z,o2J,'class',2,e,s,gg)
var x3J=_n('view')
_rz(z,x3J,'class',3,e,s,gg)
var o4J=_n('text')
_rz(z,o4J,'class',4,e,s,gg)
var f5J=_oz(z,5,e,s,gg)
_(o4J,f5J)
_(x3J,o4J)
var c6J=_n('text')
_rz(z,c6J,'class',6,e,s,gg)
var h7J=_oz(z,7,e,s,gg)
_(c6J,h7J)
_(x3J,c6J)
_(o2J,x3J)
var o8J=_n('view')
_rz(z,o8J,'class',8,e,s,gg)
_(o2J,o8J)
var c9J=_n('view')
_rz(z,c9J,'class',9,e,s,gg)
var o0J=_n('text')
_rz(z,o0J,'class',10,e,s,gg)
var lAK=_oz(z,11,e,s,gg)
_(o0J,lAK)
_(c9J,o0J)
var aBK=_n('text')
_rz(z,aBK,'class',12,e,s,gg)
var tCK=_oz(z,13,e,s,gg)
_(aBK,tCK)
_(c9J,aBK)
_(o2J,c9J)
_(eZJ,o2J)
var eDK=_mz(z,'scroll-view',['class',14,'scrollY',1],[],e,s,gg)
var bEK=_v()
_(eDK,bEK)
var oFK=function(oHK,xGK,fIK,gg){
var hKK=_n('view')
_rz(z,hKK,'class',18,oHK,xGK,gg)
var oLK=_n('image')
_rz(z,oLK,'class',19,oHK,xGK,gg)
_(hKK,oLK)
var cMK=_n('view')
_rz(z,cMK,'class',20,oHK,xGK,gg)
var oNK=_oz(z,21,oHK,xGK,gg)
_(cMK,oNK)
_(hKK,cMK)
var lOK=_mz(z,'text',['bindtap',22,'class',1,'data-pos',2],[],oHK,xGK,gg)
var aPK=_oz(z,25,oHK,xGK,gg)
_(lOK,aPK)
_(hKK,lOK)
_(fIK,hKK)
return fIK
}
bEK.wxXCkey=2
_2z(z,16,oFK,e,s,gg,bEK,'item','index','*this')
_(eZJ,eDK)
_(r,eZJ)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_11";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_11();
	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/record/record.wxml'] = [$gwx_XC_11, './pages/record/record.wxml'];else __wxAppCode__['pages/record/record.wxml'] = $gwx_XC_11( './pages/record/record.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['pages/record/record.wxss'] = setCssToHead([".",[1],"head-bg{background-color:#8b1b23;height:",[0,120],";width:100%}\n.",[1],"user-view{background-color:#ffd1a9;-webkit-flex-direction:row;flex-direction:row;position:absolute;top:",[0,30],";width:92%}\n.",[1],"user-item,.",[1],"user-view{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;height:",[0,160],";-webkit-justify-content:center;justify-content:center}\n.",[1],"user-item{-webkit-flex-direction:column;flex-direction:column;width:46%}\n.",[1],"user-line{background-color:#828282;height:",[0,80],";width:",[0,2],"}\n.",[1],"user-title{color:#212121;font-size:",[0,26],";font-weight:700}\n.",[1],"user-value{color:#8b1b23;font-size:",[0,32],";margin-top:",[0,20],"}\n.",[1],"scrollview{bottom:",[0,0],";position:absolute;top:",[0,200],";width:92%}\n.",[1],"item{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;-webkit-flex-direction:row;flex-direction:row;-webkit-justify-content:space-between;justify-content:space-between;margin-top:",[0,70],";width:100%}\n.",[1],"item-img{background:#8b1b23;border-radius:50%;height:",[0,19],";margin-left:",[0,20],";width:",[0,19],"}\n.",[1],"item-text{color:#212121;line-height:",[0,45],";width:50%}\n.",[1],"item-look,.",[1],"item-text{font-size:",[0,26],";font-weight:700}\n.",[1],"item-look{border:",[0,1]," solid #8b1b23;border-radius:",[0,32],";color:#8b1b23;height:",[0,64],";line-height:",[0,64],";margin-right:",[0,20],";text-align:center;width:",[0,224],"}\n",],undefined,{path:"./pages/record/record.wxss"});
}