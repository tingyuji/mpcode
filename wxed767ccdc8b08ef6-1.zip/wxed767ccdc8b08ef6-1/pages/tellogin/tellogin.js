var t = require("../../config.js"), e = require("../../http.js"), n = getApp(), o = /^[1][3,4,5,6,7,8][0-9]{9}$/;

Page({
    data: {
        isSend: !1,
        isFocus: !1,
        tel: "",
        msgCode: []
    },
    onLoad: function(t) {},
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    sendCode: function() {
        this.data.canSend && this.sendCodeMsg();
    },
    telInput: function(t) {
        this.setData({
            tel: t.detail.value
        }), o.test(t.detail.value) ? this.setData({
            canSend: !0
        }) : this.setData({
            canSend: !1
        });
    },
    numberClick: function() {
        this.setData({
            isFocus: !0
        });
    },
    numberInput: function(t) {
        this.setData({
            tmpValue: t.detail.value,
            msgCode: t.detail.value.split("")
        }), 4 == this.data.msgCode.length && this.verifyCode();
    },
    sendAgain: function() {
        this.setData({
            msgCode: [],
            tmpValue: ""
        }), this.sendCodeMsg();
    },
    sendCodeMsg: function() {
        var n = this;
        e.request(t.vcode, "POST", {
            phoneNumber: this.data.tel
        }, function(t) {
            200 == t.stCode || 401 == t.stCode ? (n.setData({
                isSend: !0
            }), wx.showToast({
                title: "验证码已发送",
                icon: "none"
            })) : wx.showToast({
                title: "验证码发送失败",
                icon: "none"
            });
        }, function(t) {
            wx.showToast({
                title: "验证码发送失败",
                icon: "none"
            });
        });
    },
    verifyCode: function() {
        var o = this;
        e.request(t.verify, "POST", {
            vcode: this.data.tmpValue
        }, function(t) {
            0 == t.stCode && (null != t.data ? (n.globalData.userMsg = t.data, n.globalData.haslogin = !0, 
            wx.setStorageSync("userMsg", t.data), wx.setStorageSync("haslogin", !0), wx.reLaunch({
                url: "../index/index"
            })) : wx.redirectTo({
                url: "../usermsg/usermsg?phone=" + o.data.tel
            })), 402 == t.stCode && wx.showToast({
                title: "验证码已过期，请重新发送",
                icon: "none"
            }), 403 == t.stCode && wx.showToast({
                title: "验证码错误",
                icon: "none"
            });
        }, function(t) {
            wx.showToast({
                title: "验证失败",
                icon: "none"
            });
        }, !0);
    }
});