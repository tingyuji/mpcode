$gwx_XC_14=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_14 || [];
function gz$gwx_XC_14_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_14_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_14_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_14_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'isSend']])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_14_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_14_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_14=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_14=true;
var x=['./pages/tellogin/tellogin.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_14_1()
var oBB=_v()
_(r,oBB)
if(_oz(z,0,e,s,gg)){oBB.wxVkey=1
}
oBB.wxXCkey=1
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_14";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_14();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/tellogin/tellogin.wxml'] = [$gwx_XC_14, './pages/tellogin/tellogin.wxml'];else __wxAppCode__['pages/tellogin/tellogin.wxml'] = $gwx_XC_14( './pages/tellogin/tellogin.wxml' );
	;__wxRoute = "pages/tellogin/tellogin";__wxRouteBegin = true;__wxAppCurrentFile__="pages/tellogin/tellogin.js";define("pages/tellogin/tellogin.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var t=require("../../config.js"),e=require("../../http.js"),n=getApp(),o=/^[1][3,4,5,6,7,8][0-9]{9}$/;Page({data:{isSend:!1,isFocus:!1,tel:"",msgCode:[]},onLoad:function(t){},onReady:function(){},onShow:function(){},onHide:function(){},onUnload:function(){},sendCode:function(){this.data.canSend&&this.sendCodeMsg()},telInput:function(t){this.setData({tel:t.detail.value}),o.test(t.detail.value)?this.setData({canSend:!0}):this.setData({canSend:!1})},numberClick:function(){this.setData({isFocus:!0})},numberInput:function(t){this.setData({tmpValue:t.detail.value,msgCode:t.detail.value.split("")}),4==this.data.msgCode.length&&this.verifyCode()},sendAgain:function(){this.setData({msgCode:[],tmpValue:""}),this.sendCodeMsg()},sendCodeMsg:function(){var n=this;e.request(t.vcode,"POST",{phoneNumber:this.data.tel},(function(t){200==t.stCode||401==t.stCode?(n.setData({isSend:!0}),wx.showToast({title:"验证码已发送",icon:"none"})):wx.showToast({title:"验证码发送失败",icon:"none"})}),(function(t){wx.showToast({title:"验证码发送失败",icon:"none"})}))},verifyCode:function(){var o=this;e.request(t.verify,"POST",{vcode:this.data.tmpValue},(function(t){0==t.stCode&&(null!=t.data?(n.globalData.userMsg=t.data,n.globalData.haslogin=!0,wx.setStorageSync("userMsg",t.data),wx.setStorageSync("haslogin",!0),wx.reLaunch({url:"../index/index"})):wx.redirectTo({url:"../usermsg/usermsg?phone="+o.data.tel})),402==t.stCode&&wx.showToast({title:"验证码已过期，请重新发送",icon:"none"}),403==t.stCode&&wx.showToast({title:"验证码错误",icon:"none"})}),(function(t){wx.showToast({title:"验证失败",icon:"none"})}),!0)}});
},{isPage:true,isComponent:true,currentFile:'pages/tellogin/tellogin.js'});require("pages/tellogin/tellogin.js");