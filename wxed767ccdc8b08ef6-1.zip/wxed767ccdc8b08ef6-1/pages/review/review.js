var t = require("../../config.js"), a = require("../../http.js");

Page({
    data: {
        year: 2020,
        reviewList: [ 1 ],
        haveData: !1
    },
    itemClick: function(t) {
        if (this.data.haveData) {
            var a = t.currentTarget.dataset.pos;
            wx.setStorageSync("examMsgReview", this.data.reviewList[a]), wx.navigateTo({
                url: "../notice/notice?type=2"
            });
        }
    },
    onLoad: function(t) {
        var a = new Date().getFullYear();
        this.setData({
            year: a
        }), this.getExamList();
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    getExamList: function() {
        var e = this;
        a.request(t.getExamList, "POST", {
            type: 2
        }, function(t) {
            null != t.data && t.data.length > 0 && e.setData({
                reviewList: t.data,
                haveData: !0
            });
        }, function(t) {
            wx.showToast({
                title: t,
                icon: "none"
            });
        });
    }
});