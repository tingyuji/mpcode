$gwx_XC_3=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_3 || [];
function gz$gwx_XC_3_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_3_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_3_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_3_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container4'])
Z([3,'title'])
Z([a,[[7],[3,'examName']]])
Z([3,'time'])
Z([a,[3,'考试倒计时'],[[7],[3,'countDownValue']]])
Z([3,'head-img'])
Z([3,'../../images/ques_img_1.png'])
Z([3,'content'])
Z([3,'topic'])
Z([3,'emsp'])
Z([a,[3,'【'],[[7],[3,'typeValue']],[3,'-第'],[[7],[3,'position']],[3,'题-】'],[[7],[3,'topic']]])
Z([[2,'=='],[[7],[3,'typeCode']],[1,4]])
Z([3,'fill-title'])
Z([3,'请在下方横线处填写答案：'])
Z([3,'answerInput'])
Z([3,'input'])
Z([3,'{true}'])
Z([3,'-webkit-user-select:text !important'])
Z([3,'-1'])
Z([[7],[3,'answerValue']])
Z([[7],[3,'answers']])
Z([3,'id'])
Z([3,'itemClick'])
Z([[2,'?:'],[[6],[[7],[3,'item']],[3,'isSelect']],[1,'answer'],[1,'answer-default']])
Z([[7],[3,'index']])
Z([a,[[6],[[7],[3,'item']],[3,'content']]])
Z([3,'btnview'])
Z([[2,'!='],[[7],[3,'position']],[1,1]])
Z([3,'last'])
Z(z[28])
Z([3,'上一题'])
Z([3,'next'])
Z(z[31])
Z([3,'下一题'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_3_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_3_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_3=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_3=true;
var x=['./pages/exam/exam.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_3_1()
var aVE=_n('view')
_rz(z,aVE,'class',0,e,s,gg)
var tWE=_n('text')
_rz(z,tWE,'class',1,e,s,gg)
var eXE=_oz(z,2,e,s,gg)
_(tWE,eXE)
_(aVE,tWE)
var bYE=_n('text')
_rz(z,bYE,'class',3,e,s,gg)
var oZE=_oz(z,4,e,s,gg)
_(bYE,oZE)
_(aVE,bYE)
var x1E=_mz(z,'image',['class',5,'src',1],[],e,s,gg)
_(aVE,x1E)
var o2E=_n('view')
_rz(z,o2E,'class',7,e,s,gg)
var c4E=_mz(z,'text',['class',8,'space',1],[],e,s,gg)
var h5E=_oz(z,10,e,s,gg)
_(c4E,h5E)
_(o2E,c4E)
var f3E=_v()
_(o2E,f3E)
if(_oz(z,11,e,s,gg)){f3E.wxVkey=1
var o6E=_n('view')
_rz(z,o6E,'class',12,e,s,gg)
var c7E=_oz(z,13,e,s,gg)
_(o6E,c7E)
_(f3E,o6E)
var o8E=_mz(z,'input',['bindinput',14,'class',1,'focus',2,'style',3,'tabindex',4,'value',5],[],e,s,gg)
_(f3E,o8E)
}
else{f3E.wxVkey=2
var l9E=_v()
_(f3E,l9E)
var a0E=function(eBF,tAF,bCF,gg){
var xEF=_mz(z,'view',['bindtap',22,'class',1,'data-pos',2],[],eBF,tAF,gg)
var oFF=_oz(z,25,eBF,tAF,gg)
_(xEF,oFF)
_(bCF,xEF)
return bCF
}
l9E.wxXCkey=2
_2z(z,20,a0E,e,s,gg,l9E,'item','index','id')
}
f3E.wxXCkey=1
_(aVE,o2E)
var fGF=_n('view')
_rz(z,fGF,'class',26,e,s,gg)
var cHF=_v()
_(fGF,cHF)
if(_oz(z,27,e,s,gg)){cHF.wxVkey=1
var hIF=_mz(z,'text',['bindtap',28,'class',1],[],e,s,gg)
var oJF=_oz(z,30,e,s,gg)
_(hIF,oJF)
_(cHF,hIF)
}
var cKF=_mz(z,'text',['bindtap',31,'class',1],[],e,s,gg)
var oLF=_oz(z,33,e,s,gg)
_(cKF,oLF)
_(fGF,cKF)
cHF.wxXCkey=1
_(aVE,fGF)
_(r,aVE)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_3";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_3();
	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/exam/exam.wxml'] = [$gwx_XC_3, './pages/exam/exam.wxml'];else __wxAppCode__['pages/exam/exam.wxml'] = $gwx_XC_3( './pages/exam/exam.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['pages/exam/exam.wxss'] = setCssToHead([".",[1],"title{font-family:Source Han Sans CN;font-size:",[0,34],";font-weight:700;margin-top:",[0,30],"}\n.",[1],"time,.",[1],"title{color:#8b1b23}\n.",[1],"time{font-size:",[0,28],";margin-top:",[0,20],"}\n.",[1],"head-img{height:",[0,50],";margin-top:",[0,30],";width:94%}\n.",[1],"content{background-color:#fff;border:",[0,2]," solid #000;min-height:",[0,600],";overflow-y:scroll;padding:",[0,50]," ",[0,20],";width:85%}\n.",[1],"topic{color:#222;font-size:",[0,32],";font-weight:blod;width:100%}\n.",[1],"answer{background:#8b1b23;color:#fff;text-align:left}\n.",[1],"answer,.",[1],"answer-default{border:",[0,4]," solid #000;border-radius:",[0,43],";font-size:",[0,34],";margin-top:",[0,50],";padding:",[0,25]," ",[0,25]," ",[0,25]," ",[0,30],";width:90%}\n.",[1],"answer-default{background:#ffd2aa;color:#000}\n.",[1],"fill-title{color:#333;font-size:",[0,30],";margin-top:",[0,180],";width:100%}\n.",[1],"line{background:#333;height:",[0,2],";margin-top:",[0,10],";width:100%}\n.",[1],"input{border-bottom:",[0,2]," solid #999;color:#333;font-size:",[0,34],";height:",[0,70],";margin-top:",[0,45],";text-align:center;width:100%}\n.",[1],"btnview{display:-webkit-flex;display:flex;-webkit-flex-direction:row;flex-direction:row;height:",[0,86],";-webkit-justify-content:space-around;justify-content:space-around;margin-bottom:",[0,50],";margin-top:",[0,40],";width:100%}\n.",[1],"last{border:",[0,4]," solid #8b1b23;color:#8b1b23}\n.",[1],"last,.",[1],"next{border-radius:",[0,43],";font-weight:700;height:",[0,86],";line-height:",[0,86],";text-align:center;width:40%}\n.",[1],"next{background:#8b1b23;border:",[0,4]," solid #8b1b23;color:#fff;font-size:",[0,30],"}\n",],undefined,{path:"./pages/exam/exam.wxss"});
}