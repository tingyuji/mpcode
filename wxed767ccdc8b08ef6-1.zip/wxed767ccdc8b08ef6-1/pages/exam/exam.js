var e = null, t = null, s = [], a = getApp();

Page({
    data: {
        position: 1,
        typeValue: "单选题",
        typeCode: 0,
        topic: "",
        answers: [],
        currentPos: 0,
        timer: "",
        countDownNum: 0,
        countDownValue: "00:00"
    },
    onLoad: function(e) {
        this.setData({
            examName: a.globalData.examTitle.name
        }), s = [];
        var n = e.questionType;
        this.setData({
            typeCode: n
        });
        try {
            switch (n) {
              case "0":
                t = wx.getStorageSync("unsurenessQuestions"), this.setData({
                    typeValue: "不定项选择题"
                });
                break;

              case "1":
                t = wx.getStorageSync("singleQuestions"), this.setData({
                    typeValue: "单选题"
                });
                break;

              case "2":
                t = wx.getStorageSync("multipleQuestions"), this.setData({
                    typeValue: "多选题"
                });
                break;

              case "3":
                t = wx.getStorageSync("checkQuestions"), this.setData({
                    typeValue: "判断题"
                });
                break;

              case "4":
                t = wx.getStorageSync("completionQuestions"), this.setData({
                    typeValue: "填空题"
                });
            }
            t && this.updatePageData(0);
        } catch (e) {}
        var o = wx.getStorageSync("countDownNum");
        o && this.setData({
            countDownNum: o
        });
    },
    onReady: function() {
        this.countDown();
    },
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {
        wx.setStorageSync("countDownNum", this.data.countDownNum), clearInterval(this.data.timer);
    },
    last: function() {
        this.data.currentPos > 0 ? (s.pop(), this.data.currentPos--, this.updatePageData(this.data.currentPos), 
        this.data.position--, this.setData({
            position: this.data.position
        })) : wx.showToast({
            title: "已经是该题型的第一题",
            icon: "none"
        });
    },
    next: function() {
        if (e.selectItems.length > 0 || "" != e.inputAnswer) if ("2" == this.data.typeCode && e.selectItems.length < 2) wx.showToast({
            title: "多选题，请至少选择两个答案",
            icon: "none"
        }); else if (this.data.currentPos <= t.length - 1 && s.push(e), this.data.currentPos++, 
        this.data.currentPos < t.length) this.updatePageData(this.data.currentPos), this.data.position++, 
        this.setData({
            position: this.data.position
        }); else {
            switch (this.data.typeCode) {
              case "0":
                wx.setStorageSync("unsurenessRecord", s);
                break;

              case "1":
                wx.setStorageSync("singleRecord", s);
                break;

              case "2":
                wx.setStorageSync("multipleRecord", s);
                break;

              case "3":
                wx.setStorageSync("checkRecord", s);
                break;

              case "4":
                wx.setStorageSync("completionRecord", s);
            }
            var a = getCurrentPages();
            a[a.length - 2].setData({
                lastQuestionType: this.data.typeCode
            }), wx.navigateBack({
                delta: 1
            });
        } else wx.showToast({
            title: "请先作答",
            icon: "none"
        });
    },
    updatePageData: function(s) {
        e = {
            id: t[s].id,
            correctCount: t[s].correctCount,
            content: t[s].content,
            answers: t[s].answers,
            selectItems: [],
            inputAnswer: ""
        };
        for (var a = 0; a < e.answers.length; a++) e.answers[a].isSelect = !1;
        this.setData({
            topic: e.content,
            answers: e.answers,
            currentPos: s
        }), 4 == this.data.typeCode && this.setData({
            answerValue: ""
        });
    },
    itemClick: function(t) {
        var s = t.currentTarget.dataset.pos, a = e.answers[s].id, n = e.selectItems.indexOf(a);
        switch (this.data.typeCode) {
          case "0":
            -1 == n ? (e.selectItems.push(a), e.answers[s].isSelect = !0) : (e.answers[s].isSelect = !1, 
            e.selectItems.splice(n, 1));
            break;

          case "1":
            if (-1 == n) {
                e.selectItems = [], e.selectItems.push(a), e.answers[s].isSelect = !0;
                for (var o = 0; o < e.answers.length; o++) s != o && (e.answers[o].isSelect = !1);
            } else e.answers[s].isSelect = !1, e.selectItems = [];
            break;

          case "2":
            -1 == n ? (e.selectItems.push(a), e.answers[s].isSelect = !0) : (e.answers[s].isSelect = !1, 
            e.selectItems.splice(n, 1));
            break;

          case "3":
            if (-1 == n) {
                e.selectItems = [], e.selectItems.push(a), e.answers[s].isSelect = !0;
                for (o = 0; o < e.answers.length; o++) s != o && (e.answers[o].isSelect = !1);
            } else e.answers[s].isSelect = !1, e.selectItems = [];
        }
        this.setData({
            answers: e.answers
        });
    },
    answerInput: function(t) {
        e.inputAnswer = t.detail.value;
    },
    countDown: function() {
        var e = this, t = e.data.countDownNum;
        e.data.timer = setInterval(function() {
            if (600 == t) wx.showToast({
                title: "考试时间还剩10分钟，请尽快答题",
                icon: "none"
            }), t--, e.setData({
                countDownNum: t
            }); else if (0 == t) e.examStop(), clearInterval(e.data.timer); else {
                t--;
                var s = Math.floor(t / 60), a = t % 60;
                s = 1 == (s += "").length ? "0" + s : s, a = 1 == (a += "").length ? "0" + a : a, 
                e.setData({
                    countDownNum: t,
                    countDownValue: s + ":" + a
                });
            }
        }, 1e3);
    },
    examStop: function() {
        switch (this.data.typeCode) {
          case "0":
            wx.setStorageSync("unsurenessRecord", s);
            break;

          case "1":
            wx.setStorageSync("singleRecord", s);
            break;

          case "2":
            wx.setStorageSync("multipleRecord", s);
            break;

          case "3":
            wx.setStorageSync("checkRecord", s);
            break;

          case "4":
            wx.setStorageSync("completionRecord", s);
        }
        var e = getCurrentPages();
        e[e.length - 2].setData({
            lastQuestionType: 4
        }), wx.navigateBack({
            delta: 1
        });
    }
});