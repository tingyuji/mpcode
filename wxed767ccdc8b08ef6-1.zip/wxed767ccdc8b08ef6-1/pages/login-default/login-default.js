var t = require("../../config.js"), n = require("../../http.js"), e = getApp();

Page({
    data: {
        tel: ""
    },
    onLoad: function(t) {},
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    cancel: function() {
        wx.navigateBack({
            delta: 3
        });
    },
    tellogin: function() {
        wx.redirectTo({
            url: "../tellogin/tellogin"
        });
    },
    getPhoneNumber: function(e) {
        var a = this;
        e.detail.encryptedData && n.request(t.tel, "POST", {
            encryptedData: e.detail.encryptedData,
            iv: e.detail.iv
        }, function(t) {
            null != t.data && (a.setData({
                tel: t.data
            }), a.wxdl());
        }, function(t) {
            wx.showToast({
                title: t,
                icon: "none"
            });
        });
    },
    wxdl: function() {
        var a = this;
        n.request(t.wxdl, "POST", null, function(t) {
            null != t.data ? (e.globalData.userMsg = t.data, e.globalData.haslogin = !0, wx.setStorageSync("userMsg", t.data), 
            wx.setStorageSync("haslogin", !0), wx.reLaunch({
                url: "../index/index"
            })) : wx.redirectTo({
                url: "../usermsg/usermsg?phone=" + a.data.tel
            });
        }, function(t) {
            wx.showToast({
                title: t,
                icon: "none"
            });
        });
    }
});