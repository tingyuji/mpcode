$gwx_XC_16=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_16 || [];
function gz$gwx_XC_16_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_16_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_16_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_16_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container3'])
Z([3,'contentview'])
Z([3,'title'])
Z([3,'您的姓名：'])
Z([3,'nameInput'])
Z([3,'value'])
Z([3,'请填写您的姓名'])
Z([3,'line'])
Z(z[2])
Z([3,'您的手机号：'])
Z(z[5])
Z([a,[[7],[3,'phone']]])
Z(z[7])
Z(z[2])
Z([3,'所在地：'])
Z([3,'bindMultiPickerChange'])
Z([3,'bindMultiPickerColumnChange'])
Z(z[5])
Z([3,'multiSelector'])
Z([[7],[3,'multiObjArray']])
Z([1,'name'])
Z([[7],[3,'multiIndex']])
Z([3,'picker'])
Z([a,[3,' '],[[7],[3,'multidefault']],[3,' ']])
Z(z[7])
Z(z[2])
Z([3,'您的单位：'])
Z([3,'unitInput'])
Z(z[5])
Z([3,'请输入您的单位'])
Z(z[7])
Z(z[2])
Z([3,'您的职务：'])
Z([3,'bindPickerChange'])
Z(z[5])
Z([[7],[3,'array']])
Z([[7],[3,'index']])
Z([a,[[7],[3,'zhiwu']]])
Z(z[7])
Z([3,'makeSure'])
Z([3,'sure'])
Z([3,'确定'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_16_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_16_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_16=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_16=true;
var x=['./pages/usermsg/usermsg.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_16_1()
var c0M=_n('view')
_rz(z,c0M,'class',0,e,s,gg)
var hAN=_n('view')
_rz(z,hAN,'class',1,e,s,gg)
var oBN=_n('text')
_rz(z,oBN,'class',2,e,s,gg)
var cCN=_oz(z,3,e,s,gg)
_(oBN,cCN)
_(hAN,oBN)
var oDN=_mz(z,'input',['bindinput',4,'class',1,'placeholder',2],[],e,s,gg)
_(hAN,oDN)
var lEN=_n('view')
_rz(z,lEN,'class',7,e,s,gg)
_(hAN,lEN)
var aFN=_n('text')
_rz(z,aFN,'class',8,e,s,gg)
var tGN=_oz(z,9,e,s,gg)
_(aFN,tGN)
_(hAN,aFN)
var eHN=_n('text')
_rz(z,eHN,'class',10,e,s,gg)
var bIN=_oz(z,11,e,s,gg)
_(eHN,bIN)
_(hAN,eHN)
var oJN=_n('view')
_rz(z,oJN,'class',12,e,s,gg)
_(hAN,oJN)
var xKN=_n('text')
_rz(z,xKN,'class',13,e,s,gg)
var oLN=_oz(z,14,e,s,gg)
_(xKN,oLN)
_(hAN,xKN)
var fMN=_mz(z,'picker',['bindchange',15,'bindcolumnchange',1,'class',2,'mode',3,'range',4,'rangeKey',5,'value',6],[],e,s,gg)
var cNN=_n('view')
_rz(z,cNN,'class',22,e,s,gg)
var hON=_oz(z,23,e,s,gg)
_(cNN,hON)
_(fMN,cNN)
_(hAN,fMN)
var oPN=_n('view')
_rz(z,oPN,'class',24,e,s,gg)
_(hAN,oPN)
var cQN=_n('text')
_rz(z,cQN,'class',25,e,s,gg)
var oRN=_oz(z,26,e,s,gg)
_(cQN,oRN)
_(hAN,cQN)
var lSN=_mz(z,'input',['bindinput',27,'class',1,'placeholder',2],[],e,s,gg)
_(hAN,lSN)
var aTN=_n('view')
_rz(z,aTN,'class',30,e,s,gg)
_(hAN,aTN)
var tUN=_n('text')
_rz(z,tUN,'class',31,e,s,gg)
var eVN=_oz(z,32,e,s,gg)
_(tUN,eVN)
_(hAN,tUN)
var bWN=_mz(z,'picker',['bindchange',33,'class',1,'range',2,'value',3],[],e,s,gg)
var oXN=_n('view')
var xYN=_oz(z,37,e,s,gg)
_(oXN,xYN)
_(bWN,oXN)
_(hAN,bWN)
var oZN=_n('view')
_rz(z,oZN,'class',38,e,s,gg)
_(hAN,oZN)
var f1N=_mz(z,'text',['bindtap',39,'class',1],[],e,s,gg)
var c2N=_oz(z,41,e,s,gg)
_(f1N,c2N)
_(hAN,f1N)
_(c0M,hAN)
_(r,c0M)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_16";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_16();
	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/usermsg/usermsg.wxml'] = [$gwx_XC_16, './pages/usermsg/usermsg.wxml'];else __wxAppCode__['pages/usermsg/usermsg.wxml'] = $gwx_XC_16( './pages/usermsg/usermsg.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['pages/usermsg/usermsg.wxss'] = setCssToHead([".",[1],"title{color:#666;font-size:",[0,26],";margin-top:",[0,40],";width:90%}\n.",[1],"value{color:#222;font-size:",[0,30],";margin-top:",[0,30],";width:90%}\n.",[1],"line{background:#8b1b23;height:",[0,2],";margin-top:",[0,15],";width:90%}\n.",[1],"sure{background-color:#8b1b23;border-radius:",[0,43],";color:#fff;font-size:",[0,30],";height:",[0,86],";line-height:",[0,86],";margin-top:",[0,100],";text-align:center;width:50%}\n",],undefined,{path:"./pages/usermsg/usermsg.wxss"});
}