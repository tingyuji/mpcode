var t, a = require("../../@babel/runtime/helpers/defineProperty"), n = require("../../config.js"), o = require("../../http.js"), e = getApp();

Page((a(t = {
    data: {
        hasUserInfo: !1,
        canIUse: wx.canIUse("button.open-type.getUserInfo"),
        avatarUrl: "../../images/logo.jpg",
        nickName: "未登录",
        bannerData: [ "../../images/home_img_banner.png" ],
        bannerData2: [ "../../images/img_nothing.png" ],
        noExam: !0,
        showModal: !1,
        examList: [],
        swiperCurrent: 0,
        second: 5,
        check: !1,
        isCheck: !1,
        noCheck: !0,
        compList: [ {
            imgUrl: "https://cdn2.pluslegal.cn/zzb%2Fhome_footer_img_1.png"
        } ]
    },
    showHint: function() {
        this.timer(), this.setData({
            showModal: !0
        });
    },
    hideModal: function() {
        this.setData({
            showModal: !1
        });
    },
    radiocon: function(t) {
        var a = this.data.check;
        a = !a, this.setData({
            check: a
        });
    },
    timer: function() {
        var t = this;
        new Promise(function(a, n) {
            var o = setInterval(function() {
                t.setData({
                    second: t.data.second - 1
                }), t.data.second <= 0 && (t.setData({
                    second: 5,
                    isCheck: !0,
                    noCheck: !1
                }), a(o));
            }, 800);
        }).then(function(t) {
            clearInterval(t);
        });
    },
    confirm: function() {
        this.data.check ? (this.hideModal(), this.setData({
            isCheck: !1,
            noCheck: !0
        }), wx.navigateTo({
            url: "../notice/notice?type=1"
        })) : wx.showToast({
            title: "请先阅读知情书并勾选",
            icon: "none",
            duration: 2e3
        });
    },
    toLogin: function() {
        e.globalData.haslogin ? wx.navigateTo({
            url: "../amend/amend?type=0"
        }) : e.globalData.userInfo ? wx.navigateTo({
            url: "/pages/login-default/login-default"
        }) : wx.navigateTo({
            url: "../login/login"
        });
    },
    examRecord: function() {
        e.globalData.haslogin ? wx.navigateTo({
            url: "../record/record"
        }) : this.toLogin();
    },
    toRanking: function() {
        e.globalData.haslogin ? wx.navigateTo({
            url: "../ranking/ranking"
        }) : this.toLogin();
    },
    toRule: function() {
        e.globalData.haslogin ? wx.navigateTo({
            url: "../rule/rule"
        }) : this.toLogin();
    },
    toReview: function() {
        e.globalData.haslogin ? wx.navigateTo({
            url: "../review/review"
        }) : this.toLogin();
    },
    toExam: function() {
        e.globalData.haslogin ? wx.navigateTo({
            url: "../notice/notice"
        }) : this.toLogin();
    },
    swiperChange: function(t) {
        this.setData({
            swiperCurrent: t.detail.current
        });
    },
    swipclick: function() {
        this.data.noExam || (e.globalData.haslogin ? (wx.setStorageSync("examMsg", this.data.examList[this.data.swiperCurrent]), 
        wx.navigateTo({
            url: "../notice/notice?type=1"
        })) : this.toLogin());
    },
    toVote: function(t) {
        var a = this.data.compList[0].code;
        wx.setStorageSync("compId", a), e.globalData.haslogin ? wx.switchTab({
            url: "../vote/home/home?code=" + a
        }) : this.toLogin();
    }
}, "showHint", function() {
    this.setData({
        showModal: !0
    });
}), a(t, "preventTouchMove", function() {}), a(t, "hideModal", function() {
    this.setData({
        showModal: !1
    });
}), a(t, "clickButton", function() {
    this.hideModal();
}), a(t, "onLoad", function() {
    e.globalData.userInfo || (this.data.canIUse ? e.userInfoReadyCallback = function(t) {
        e.globalData.userInfo = t.userInfo, wx.setStorageSync("userInfo", t.userInfo);
    } : wx.getUserInfo({
        success: function(t) {
            e.globalData.userInfo = t.userInfo, wx.setStorageSync("userInfo", t.userInfo);
        }
    }));
    var t = wx.getStorageSync("firstLaunch");
    console.log("firstLaunch", t), t ? this.setData({
        showModal: !1
    }) : (this.setData({
        showModal: !1
    }), wx.setStorageSync("firstLaunch", !0)), this.getBanners(), this.getExamList(), 
    this.getComp();
    var a = wx.getStorageSync("haslogin");
    e.globalData.haslogin = a;
    var n = wx.getStorageSync("userInfo");
    a && this.setData({
        avatarUrl: n.avatarUrl,
        nickName: n.nickName
    });
}), a(t, "onShow", function() {}), a(t, "onShareAppMessage", function() {}), a(t, "getBanners", function() {
    var t = this;
    o.request(n.banner, "GET", null, function(a) {
        if (null != a.data) {
            for (var n = [], o = 0; o < a.data.length; o++) n.push(a.data[o].imgUrl);
            t.setData({
                bannerData: n
            });
        }
    }, function(t) {
        wx.showToast({
            title: t,
            icon: "none"
        });
    });
}), a(t, "getExamList", function() {
    var t = this;
    o.request(n.getExamListIndex, "POST", {
        examTypes: [ 4 ],
        type: 1
    }, function(a) {
        if (null != a.data && a.data.length > 0) {
            t.setData({
                examList: a.data
            });
            for (var n = [], o = 0; o < a.data.length; o++) n.push(a.data[o].themeUrl);
            t.setData({
                bannerData2: n,
                noExam: !1
            });
        }
    }, function(t) {
        wx.showToast({
            title: t,
            icon: "none"
        });
    });
}), a(t, "getComp", function() {
    var t = this;
    o.request(n.getComp, "POST", {
        type: 0
    }, function(a) {
        null != a.rows && a.rows.length > 0 && t.setData({
            compList: a.rows
        });
    }, function(t) {
        wx.showToast({
            title: t,
            icon: "none"
        });
    });
}), t));