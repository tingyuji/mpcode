$gwx_XC_4=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_4 || [];
function gz$gwx_XC_4_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_4_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_4_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_4_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container'])
Z([3,'head-bg'])
Z([3,'../../images/home_img_bg.png'])
Z([3,'content'])
Z([3,'true'])
Z([3,'swiper-banner'])
Z([3,'500'])
Z([3,'#FFFFFF'])
Z([3,'#999999'])
Z(z[4])
Z([3,'3500'])
Z([[7],[3,'bannerData']])
Z([3,'id'])
Z([3,'bannertap'])
Z([3,'banner-img'])
Z([[7],[3,'item']])
Z([3,'user-view'])
Z([3,'toLogin'])
Z([3,'user-view2'])
Z([3,'user-img'])
Z([[7],[3,'avatarUrl']])
Z([3,'user-name'])
Z([a,[[7],[3,'nickName']]])
Z([3,'examRecord'])
Z([3,'exam-record'])
Z([3,'考试记录'])
Z(z[4])
Z([3,'swiperChange'])
Z([3,'swiper-banner2'])
Z(z[6])
Z(z[7])
Z(z[8])
Z(z[4])
Z(z[10])
Z([[7],[3,'bannerData2']])
Z(z[12])
Z([3,'swipclick'])
Z([3,'banner-img2'])
Z(z[15])
Z([3,'course-view'])
Z([3,'toReview'])
Z([3,'review'])
Z([3,'review-bg'])
Z([3,'../../images/home_img_bg_2.png'])
Z([3,'review-title'])
Z([3,'真题回顾'])
Z([3,'review-hint'])
Z([3,'学而时习之，逢考必过'])
Z([3,'review-look'])
Z([3,'去看看\x3e'])
Z([3,'review-img'])
Z([3,'../../images/home_icon_2.png'])
Z([3,'course-item'])
Z([3,'toRanking'])
Z([3,'ranking'])
Z([3,'ranking-bg'])
Z([3,'../../images/home_img_bg_3.png'])
Z([3,'ranking-title'])
Z([3,'排行榜'])
Z([3,'ranking-line'])
Z([3,'ranking-img'])
Z([3,'../../images/home_icon_3.png'])
Z([3,'toRule'])
Z([3,'rule'])
Z([3,'rule-bg'])
Z([3,'../../images/home_img_bg_4.png'])
Z([3,'rule-title'])
Z([3,'规则介绍'])
Z([3,'rule-line'])
Z([3,'rule-img'])
Z([3,'../../images/home_icon_4.png'])
Z([3,'toVote'])
Z([3,'bottom-bg'])
Z([3,'../../images/home_bg.png'])
Z([3,'bottom-tv'])
Z([3,'技术支持：北京法和科技有限公司'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_4_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_4_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_4=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_4=true;
var x=['./pages/index/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_4_1()
var aNF=_n('view')
_rz(z,aNF,'class',0,e,s,gg)
var tOF=_mz(z,'image',['class',1,'src',1],[],e,s,gg)
_(aNF,tOF)
var ePF=_n('view')
_rz(z,ePF,'class',3,e,s,gg)
var bQF=_mz(z,'swiper',['autoplay',4,'class',1,'duration',2,'indicatorActiveColor',3,'indicatorColor',4,'indicatorDots',5,'interval',6],[],e,s,gg)
var oRF=_v()
_(bQF,oRF)
var xSF=function(fUF,oTF,cVF,gg){
var oXF=_n('swiper-item')
var cYF=_mz(z,'image',['bindtap',13,'class',1,'src',2],[],fUF,oTF,gg)
_(oXF,cYF)
_(cVF,oXF)
return cVF
}
oRF.wxXCkey=2
_2z(z,11,xSF,e,s,gg,oRF,'item','index','id')
_(ePF,bQF)
var oZF=_n('view')
_rz(z,oZF,'class',16,e,s,gg)
var l1F=_mz(z,'view',['bindtap',17,'class',1],[],e,s,gg)
var a2F=_mz(z,'image',['class',19,'src',1],[],e,s,gg)
_(l1F,a2F)
var t3F=_n('text')
_rz(z,t3F,'class',21,e,s,gg)
var e4F=_oz(z,22,e,s,gg)
_(t3F,e4F)
_(l1F,t3F)
_(oZF,l1F)
var b5F=_mz(z,'text',['catchtap',23,'class',1],[],e,s,gg)
var o6F=_oz(z,25,e,s,gg)
_(b5F,o6F)
_(oZF,b5F)
_(ePF,oZF)
var x7F=_mz(z,'swiper',['autoplay',26,'bindchange',1,'class',2,'duration',3,'indicatorActiveColor',4,'indicatorColor',5,'indicatorDots',6,'interval',7],[],e,s,gg)
var o8F=_v()
_(x7F,o8F)
var f9F=function(hAG,c0F,oBG,gg){
var oDG=_n('swiper-item')
var lEG=_mz(z,'image',['bindtap',36,'class',1,'src',2],[],hAG,c0F,gg)
_(oDG,lEG)
_(oBG,oDG)
return oBG
}
o8F.wxXCkey=2
_2z(z,34,f9F,e,s,gg,o8F,'item','index','id')
_(ePF,x7F)
var aFG=_n('view')
_rz(z,aFG,'class',39,e,s,gg)
var tGG=_mz(z,'view',['bindtap',40,'class',1],[],e,s,gg)
var eHG=_mz(z,'image',['class',42,'src',1],[],e,s,gg)
_(tGG,eHG)
var bIG=_n('text')
_rz(z,bIG,'class',44,e,s,gg)
var oJG=_oz(z,45,e,s,gg)
_(bIG,oJG)
_(tGG,bIG)
var xKG=_n('text')
_rz(z,xKG,'class',46,e,s,gg)
var oLG=_oz(z,47,e,s,gg)
_(xKG,oLG)
_(tGG,xKG)
var fMG=_n('text')
_rz(z,fMG,'class',48,e,s,gg)
var cNG=_oz(z,49,e,s,gg)
_(fMG,cNG)
_(tGG,fMG)
var hOG=_mz(z,'image',['class',50,'src',1],[],e,s,gg)
_(tGG,hOG)
_(aFG,tGG)
var oPG=_n('view')
_rz(z,oPG,'class',52,e,s,gg)
var cQG=_mz(z,'view',['bindtap',53,'class',1],[],e,s,gg)
var oRG=_mz(z,'image',['class',55,'src',1],[],e,s,gg)
_(cQG,oRG)
var lSG=_n('text')
_rz(z,lSG,'class',57,e,s,gg)
var aTG=_oz(z,58,e,s,gg)
_(lSG,aTG)
_(cQG,lSG)
var tUG=_n('view')
_rz(z,tUG,'class',59,e,s,gg)
_(cQG,tUG)
var eVG=_mz(z,'image',['class',60,'src',1],[],e,s,gg)
_(cQG,eVG)
_(oPG,cQG)
var bWG=_mz(z,'view',['bindtap',62,'class',1],[],e,s,gg)
var oXG=_mz(z,'image',['class',64,'src',1],[],e,s,gg)
_(bWG,oXG)
var xYG=_n('text')
_rz(z,xYG,'class',66,e,s,gg)
var oZG=_oz(z,67,e,s,gg)
_(xYG,oZG)
_(bWG,xYG)
var f1G=_n('view')
_rz(z,f1G,'class',68,e,s,gg)
_(bWG,f1G)
var c2G=_mz(z,'image',['class',69,'src',1],[],e,s,gg)
_(bWG,c2G)
_(oPG,bWG)
_(aFG,oPG)
_(ePF,aFG)
_(aNF,ePF)
var h3G=_mz(z,'image',['bindtap',71,'class',1,'src',2],[],e,s,gg)
_(aNF,h3G)
var o4G=_n('text')
_rz(z,o4G,'class',74,e,s,gg)
var c5G=_oz(z,75,e,s,gg)
_(o4G,c5G)
_(aNF,o4G)
_(r,aNF)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_4";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_4();
	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/index/index.wxml'] = [$gwx_XC_4, './pages/index/index.wxml'];else __wxAppCode__['pages/index/index.wxml'] = $gwx_XC_4( './pages/index/index.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['pages/index/index.wxss'] = setCssToHead([".",[1],"head-bg{height:",[0,446],";position:absolute;width:100%}\n.",[1],"content{-webkit-align-items:center;align-items:center;box-sizing:border-box;display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column;height:100%;padding:",[0,0]," ",[0,30],";width:100%}\n.",[1],"swiper-banner{margin-top:",[0,55],"}\n.",[1],"banner-img,.",[1],"swiper-banner{height:",[0,300],";width:100%}\n.",[1],"swiper-banner2{margin-top:",[0,31],"}\n.",[1],"banner-img2,.",[1],"swiper-banner2,.",[1],"swiper-item{height:",[0,280],";width:100%}\n.",[1],"user-view{background:#fbfbfb;border:",[0,1]," solid #ededed;border-radius:",[0,10],";box-shadow:",[0,0]," ",[0,7]," ",[0,10]," ",[0,0]," rgba(4,0,0,.1);-webkit-justify-content:space-between;justify-content:space-between;margin-top:",[0,21],";position:relative;width:100%}\n.",[1],"user-view,.",[1],"user-view2{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;-webkit-flex-direction:row;flex-direction:row;height:",[0,120],"}\n.",[1],"user-view2{width:60%}\n.",[1],"user-img{border-radius:50%;height:",[0,92],";margin-left:",[0,46],";width:",[0,92],"}\n.",[1],"user-name{color:#222;font-size:",[0,28],";margin-left:",[0,20],"}\n.",[1],"exam-record{border:",[0,1]," solid #f33114;border-radius:",[0,20],";color:#ed1515;font-size:",[0,26],";height:",[0,55],";line-height:",[0,55],";margin-right:",[0,40],";text-align:center;width:",[0,150],"}\n.",[1],"course-view{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;-webkit-flex-direction:row;flex-direction:row;-webkit-justify-content:space-between;justify-content:space-between;margin-top:",[0,24],";width:100%}\n.",[1],"review{height:",[0,424],";position:relative;width:48%}\n.",[1],"review-bg{height:100%;position:absolute;width:100%}\n.",[1],"review-title{color:#000002;font-size:",[0,32],";font-weight:700;left:",[0,44],";position:absolute;top:",[0,42],"}\n.",[1],"review-hint{color:#666;font-size:",[0,28],";left:",[0,45],";position:absolute;top:",[0,92],"}\n.",[1],"review-look{background:#ed1515;border:",[0,1]," solid #f33114;border-radius:",[0,20],";color:#fff;font-size:",[0,26],";left:",[0,46],";padding:",[0,5]," ",[0,20],";position:absolute;top:",[0,160],"}\n.",[1],"review-img{bottom:",[0,25],";height:",[0,140],";position:absolute;right:",[0,41],";width:",[0,150],"}\n.",[1],"course-item{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column;height:",[0,424],";-webkit-justify-content:space-between;justify-content:space-between;width:48%}\n.",[1],"ranking{position:relative}\n.",[1],"ranking,.",[1],"ranking-bg{height:",[0,200],";width:100%}\n.",[1],"ranking-bg,.",[1],"ranking-title{position:absolute}\n.",[1],"ranking-title{color:#000002;font-size:",[0,32],";font-weight:700;left:",[0,38],";top:",[0,42],"}\n.",[1],"ranking-line{background:#222;height:",[0,5],";left:",[0,41],";position:absolute;top:",[0,88],";width:",[0,62],"}\n.",[1],"ranking-img{height:",[0,140],";position:absolute;right:",[0,31],";top:",[0,34],";width:",[0,150],"}\n.",[1],"rule{position:relative}\n.",[1],"rule,.",[1],"rule-bg{height:",[0,200],";width:100%}\n.",[1],"rule-bg,.",[1],"rule-title{position:absolute}\n.",[1],"rule-title{color:#000002;font-size:",[0,32],";font-weight:700;left:",[0,38],";top:",[0,36],"}\n.",[1],"rule-line{background:#222;height:",[0,5],";left:",[0,41],";position:absolute;top:",[0,82],";width:",[0,62],"}\n.",[1],"rule-img{height:",[0,140],";position:absolute;right:",[0,16],";top:",[0,34],";width:",[0,150],"}\n.",[1],"bottom-bg{height:",[0,300],";width:100%}\n.",[1],"bottom-tv{color:#656565;font-size:",[0,26],";margin-bottom:",[0,5],";margin-top:",[0,5],"}\n.",[1],"modal-mask{background-color:rgba(0,0,0,.6);height:100%;-webkit-justify-content:center;justify-content:center;left:0;top:0;width:100%;z-index:9000}\n.",[1],"modal-dialog,.",[1],"modal-mask{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column;overflow:hidden;position:fixed}\n.",[1],"modal-dialog{background-color:#fff;height:86%;width:90%;z-index:9999}\n.",[1],"modal-title{color:#000;font-size:",[0,36],";margin:",[0,60]," 0 ",[0,45],";text-align:center;width:80%}\n.",[1],"modal-scroll{background:#fff;width:90%}\n.",[1],"modal-content{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column;height:100%;-webkit-justify-content:center;justify-content:center;width:100%}\n.",[1],"modal-text{color:#333;font-size:",[0,28],";line-height:1.9;text-align:justify;text-indent:2em}\n.",[1],"modal-btn{background:#e32516;border-radius:",[0,40],";bottom:30px;color:#fff;font-size:",[0,28],";height:",[0,80],";line-height:",[0,80],";margin-top:",[0,60],";position:absolute;text-align:center;width:90%}\n.",[1],"checkboxType{font-weight:700;margin:",[0,30]," 0;width:90%}\n.",[1],"checkboxType wx-label{font-size:",[0,28],"}\n.",[1],"hide-btn{opacity:.6}\n.",[1],"swiper-banner3{height:",[0,280],";margin:4%;width:92%}\n.",[1],"swiper-banner3 wx-image{border-radius:",[0,10],";height:100%;width:100%}\n",],"Some selectors are not allowed in component wxss, including tag name selectors, ID selectors, and attribute selectors.(./pages/index/index.wxss:1:4203)",{path:"./pages/index/index.wxss"});
}