$gwx_XC_4=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_4 || [];
function gz$gwx_XC_4_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_4_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_4_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_4_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_4_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_4_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_4=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_4=true;
var x=['./pages/index/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_4_1()
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_4";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_4();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/index/index.wxml'] = [$gwx_XC_4, './pages/index/index.wxml'];else __wxAppCode__['pages/index/index.wxml'] = $gwx_XC_4( './pages/index/index.wxml' );
	;__wxRoute = "pages/index/index";__wxRouteBegin = true;__wxAppCurrentFile__="pages/index/index.js";define("pages/index/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var t,a=require("../../@babel/runtime/helpers/defineProperty"),n=require("../../config.js"),o=require("../../http.js"),e=getApp();Page((a(t={data:{hasUserInfo:!1,canIUse:wx.canIUse("button.open-type.getUserInfo"),avatarUrl:"../../images/logo.jpg",nickName:"未登录",bannerData:["../../images/home_img_banner.png"],bannerData2:["../../images/img_nothing.png"],noExam:!0,showModal:!1,examList:[],swiperCurrent:0,second:5,check:!1,isCheck:!1,noCheck:!0,compList:[{imgUrl:"https://cdn2.pluslegal.cn/zzb%2Fhome_footer_img_1.png"}]},showHint:function(){this.timer(),this.setData({showModal:!0})},hideModal:function(){this.setData({showModal:!1})},radiocon:function(t){var a=this.data.check;a=!a,this.setData({check:a})},timer:function(){var t=this;new Promise((function(a,n){var o=setInterval((function(){t.setData({second:t.data.second-1}),t.data.second<=0&&(t.setData({second:5,isCheck:!0,noCheck:!1}),a(o))}),800)})).then((function(t){clearInterval(t)}))},confirm:function(){this.data.check?(this.hideModal(),this.setData({isCheck:!1,noCheck:!0}),wx.navigateTo({url:"../notice/notice?type=1"})):wx.showToast({title:"请先阅读知情书并勾选",icon:"none",duration:2e3})},toLogin:function(){e.globalData.haslogin?wx.navigateTo({url:"../amend/amend?type=0"}):e.globalData.userInfo?wx.navigateTo({url:"/pages/login-default/login-default"}):wx.navigateTo({url:"../login/login"})},examRecord:function(){e.globalData.haslogin?wx.navigateTo({url:"../record/record"}):this.toLogin()},toRanking:function(){e.globalData.haslogin?wx.navigateTo({url:"../ranking/ranking"}):this.toLogin()},toRule:function(){e.globalData.haslogin?wx.navigateTo({url:"../rule/rule"}):this.toLogin()},toReview:function(){e.globalData.haslogin?wx.navigateTo({url:"../review/review"}):this.toLogin()},toExam:function(){e.globalData.haslogin?wx.navigateTo({url:"../notice/notice"}):this.toLogin()},swiperChange:function(t){this.setData({swiperCurrent:t.detail.current})},swipclick:function(){this.data.noExam||(e.globalData.haslogin?(wx.setStorageSync("examMsg",this.data.examList[this.data.swiperCurrent]),wx.navigateTo({url:"../notice/notice?type=1"})):this.toLogin())},toVote:function(t){var a=this.data.compList[0].code;wx.setStorageSync("compId",a),e.globalData.haslogin?wx.switchTab({url:"../vote/home/home?code="+a}):this.toLogin()}},"showHint",(function(){this.setData({showModal:!0})})),a(t,"preventTouchMove",(function(){})),a(t,"hideModal",(function(){this.setData({showModal:!1})})),a(t,"clickButton",(function(){this.hideModal()})),a(t,"onLoad",(function(){e.globalData.userInfo||(this.data.canIUse?e.userInfoReadyCallback=function(t){e.globalData.userInfo=t.userInfo,wx.setStorageSync("userInfo",t.userInfo)}:wx.getUserInfo({success:function(t){e.globalData.userInfo=t.userInfo,wx.setStorageSync("userInfo",t.userInfo)}}));var t=wx.getStorageSync("firstLaunch");console.log("firstLaunch",t),t?this.setData({showModal:!1}):(this.setData({showModal:!1}),wx.setStorageSync("firstLaunch",!0)),this.getBanners(),this.getExamList(),this.getComp();var a=wx.getStorageSync("haslogin");e.globalData.haslogin=a;var n=wx.getStorageSync("userInfo");a&&this.setData({avatarUrl:n.avatarUrl,nickName:n.nickName})})),a(t,"onShow",(function(){})),a(t,"onShareAppMessage",(function(){})),a(t,"getBanners",(function(){var t=this;o.request(n.banner,"GET",null,(function(a){if(null!=a.data){for(var n=[],o=0;o<a.data.length;o++)n.push(a.data[o].imgUrl);t.setData({bannerData:n})}}),(function(t){wx.showToast({title:t,icon:"none"})}))})),a(t,"getExamList",(function(){var t=this;o.request(n.getExamListIndex,"POST",{examTypes:[4],type:1},(function(a){if(null!=a.data&&a.data.length>0){t.setData({examList:a.data});for(var n=[],o=0;o<a.data.length;o++)n.push(a.data[o].themeUrl);t.setData({bannerData2:n,noExam:!1})}}),(function(t){wx.showToast({title:t,icon:"none"})}))})),a(t,"getComp",(function(){var t=this;o.request(n.getComp,"POST",{type:0},(function(a){null!=a.rows&&a.rows.length>0&&t.setData({compList:a.rows})}),(function(t){wx.showToast({title:t,icon:"none"})}))})),t));
},{isPage:true,isComponent:true,currentFile:'pages/index/index.js'});require("pages/index/index.js");