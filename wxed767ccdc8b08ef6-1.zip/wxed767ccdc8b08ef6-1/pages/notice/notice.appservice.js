$gwx_XC_9=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_9 || [];
function gz$gwx_XC_9_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_9_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_9_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_9_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container4'])
Z([[2,'=='],[[7],[3,'type']],[1,1]])
Z([[2,'=='],[[7],[3,'type']],[1,2]])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_9_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_9_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_9=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_9=true;
var x=['./pages/notice/notice.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_9_1()
var e2=_n('view')
_rz(z,e2,'class',0,e,s,gg)
var b3=_v()
_(e2,b3)
if(_oz(z,1,e,s,gg)){b3.wxVkey=1
}
var o4=_v()
_(e2,o4)
if(_oz(z,2,e,s,gg)){o4.wxVkey=1
}
b3.wxXCkey=1
o4.wxXCkey=1
_(r,e2)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_9";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_9();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/notice/notice.wxml'] = [$gwx_XC_9, './pages/notice/notice.wxml'];else __wxAppCode__['pages/notice/notice.wxml'] = $gwx_XC_9( './pages/notice/notice.wxml' );
	;__wxRoute = "pages/notice/notice";__wxRouteBegin = true;__wxAppCurrentFile__="pages/notice/notice.js";define("pages/notice/notice.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var e=require("../../config.js"),t=require("../../http.js"),a=getApp();Page({data:{type:0,stCode:-1,can:!1},onLoad:function(e){var t=e.type;if(this.setData({type:t}),1==t){var n=wx.getStorageSync("examMsg"),o=(new Date).getTime(),s=n.startTime.replace(/-/g,"/"),i=new Date(s).getTime(),l=n.endTime.replace(/-/g,"/"),u=new Date(l).getTime();o>i&&o<u?this.setData({can:!0}):this.setData({can:!1}),this.setData({examMsg:n}),a.globalData.examTitle={name:n.theme,start:n.startTime,end:n.endTime}}else{var c=wx.getStorageSync("examMsgReview");this.setData({examMsg:c}),a.globalData.examTitle={name:c.theme,start:c.startTime,end:c.endTime}}},onReady:function(){},onShow:function(){wx.removeStorageSync("unsurenessRecord"),wx.removeStorageSync("singleRecord"),wx.removeStorageSync("multipleRecord"),wx.removeStorageSync("checkRecord"),wx.removeStorageSync("completionRecord"),wx.removeStorageSync("examRecord")},onHide:function(){},onUnload:function(){},beginExam:function(){if(wx.setStorageSync("countDownNum",60*this.data.examMsg.duration),this.data.can){t.request(e.beginExam,"POST",{examId:this.data.examMsg.id},(function(e){if(null!=e.data){null!=e.data.unsurenessQuestions&&e.data.unsurenessQuestions.length>0?(a.globalData.question.zero=!0,wx.setStorageSync("unsurenessQuestions",e.data.unsurenessQuestions)):(a.globalData.question.zero=!1,wx.removeStorageSync("unsurenessQuestions")),null!=e.data.singleQuestions&&e.data.singleQuestions.length>0?(a.globalData.question.one=!0,wx.setStorageSync("singleQuestions",e.data.singleQuestions)):(a.globalData.question.one=!1,wx.removeStorageSync("singleQuestions")),null!=e.data.multipleQuestions&&e.data.multipleQuestions.length>0?(a.globalData.question.two=!0,wx.setStorageSync("multipleQuestions",e.data.multipleQuestions)):(a.globalData.question.two=!1,wx.removeStorageSync("multipleQuestions")),null!=e.data.checkQuestions&&e.data.checkQuestions.length>0?(a.globalData.question.three=!0,wx.setStorageSync("checkQuestions",e.data.checkQuestions)):(a.globalData.question.three=!1,wx.removeStorageSync("checkQuestions")),null!=e.data.completionQuestions&&e.data.completionQuestions.length>0?(a.globalData.question.four=!0,wx.setStorageSync("completionQuestions",e.data.completionQuestions)):(a.globalData.question.four=!1,wx.removeStorageSync("completionQuestions"));var t={checkCount:e.data.checkCount,checkPoint:e.data.checkPoint,checkTotalPoint:e.data.checkTotalPoint,completionCount:e.data.completionCount,completionPoint:e.data.completionPoint,completionTotalPoint:e.data.completionTotalPoint,multipleCount:e.data.multipleCount,multiplePoint:e.data.multiplePoint,multipleTotalPoint:e.data.multipleTotalPoint,unsurenessCount:e.data.unsurenessCount,unsurenessPoint:e.data.unsurenessPoint,unsurenessTotalPoint:e.data.unsurenessTotalPoint,singleCount:e.data.singleCount,singlePoint:e.data.singlePoint,singleTotalPoint:e.data.singleTotalPoint,qualifiedPoint:e.data.qualifiedPoint,totalPoint:e.data.totalPoint};wx.setStorageSync("examPaper",t),wx.navigateTo({url:"../amend/amend?type=1"})}}),(function(e){wx.showToast({title:e,icon:"none"})}),!0)}else wx.showToast({title:"未在考试规定时间范围内，不能参加考试",icon:"none"})},lookExam:function(){wx.navigateTo({url:"../test-paper/test-paper?type=1&examId="+this.data.examMsg.id})}});
},{isPage:true,isComponent:true,currentFile:'pages/notice/notice.js'});require("pages/notice/notice.js");