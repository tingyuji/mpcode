$gwx_XC_9=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_9 || [];
function gz$gwx_XC_9_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_9_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_9_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_9_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container4'])
Z([3,'title'])
Z([a,[[6],[[7],[3,'examMsg']],[3,'theme']]])
Z([3,'title2'])
Z([3,'考试须知'])
Z([3,'head-img'])
Z([3,'../../images/ques_img_1.png'])
Z([3,'content'])
Z([a,[[6],[[7],[3,'examMsg']],[3,'introduce']]])
Z([[2,'=='],[[7],[3,'type']],[1,1]])
Z([3,'beginExam'])
Z([[2,'?:'],[[7],[3,'can']],[1,'start'],[1,'default']])
Z([3,'开始考试'])
Z([[2,'=='],[[7],[3,'type']],[1,2]])
Z([3,'lookExam'])
Z([3,'examine'])
Z([3,'查看真题'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_9_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_9_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_9=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_9=true;
var x=['./pages/notice/notice.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_9_1()
var lCI=_n('view')
_rz(z,lCI,'class',0,e,s,gg)
var eFI=_n('text')
_rz(z,eFI,'class',1,e,s,gg)
var bGI=_oz(z,2,e,s,gg)
_(eFI,bGI)
_(lCI,eFI)
var oHI=_n('text')
_rz(z,oHI,'class',3,e,s,gg)
var xII=_oz(z,4,e,s,gg)
_(oHI,xII)
_(lCI,oHI)
var oJI=_mz(z,'image',['class',5,'src',1],[],e,s,gg)
_(lCI,oJI)
var fKI=_n('text')
_rz(z,fKI,'class',7,e,s,gg)
var cLI=_oz(z,8,e,s,gg)
_(fKI,cLI)
_(lCI,fKI)
var aDI=_v()
_(lCI,aDI)
if(_oz(z,9,e,s,gg)){aDI.wxVkey=1
var hMI=_mz(z,'text',['bindtap',10,'class',1],[],e,s,gg)
var oNI=_oz(z,12,e,s,gg)
_(hMI,oNI)
_(aDI,hMI)
}
var tEI=_v()
_(lCI,tEI)
if(_oz(z,13,e,s,gg)){tEI.wxVkey=1
var cOI=_mz(z,'text',['bindtap',14,'class',1],[],e,s,gg)
var oPI=_oz(z,16,e,s,gg)
_(cOI,oPI)
_(tEI,cOI)
}
aDI.wxXCkey=1
tEI.wxXCkey=1
_(r,lCI)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_9";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_9();
	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/notice/notice.wxml'] = [$gwx_XC_9, './pages/notice/notice.wxml'];else __wxAppCode__['pages/notice/notice.wxml'] = $gwx_XC_9( './pages/notice/notice.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['pages/notice/notice.wxss'] = setCssToHead([".",[1],"title{font-size:",[0,34],";margin-top:",[0,30],";text-align:center;width:80%}\n.",[1],"title,.",[1],"title2{color:#8b1b23;font-family:Source Han Sans CN;font-weight:700}\n.",[1],"title2{font-size:",[0,28],";margin-top:",[0,20],"}\n.",[1],"head-img{height:",[0,50],";margin-top:",[0,30],";width:94%}\n.",[1],"content{background-color:#fff;border:",[0,2]," solid #000;color:#212121;font-size:",[0,28],";line-height:",[0,50],";min-height:",[0,600],";overflow-y:scroll;padding:",[0,20],";text-align:justify;text-justify:inter-ideograph;width:85%}\n.",[1],"exambtn{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;-webkit-flex-direction:row;flex-direction:row;height:",[0,88],";-webkit-justify-content:space-around;justify-content:space-around;margin-bottom:",[0,50],";margin-top:",[0,50],";width:90%}\n.",[1],"examine,.",[1],"start{background:#8b1b23;color:#fff}\n.",[1],"default,.",[1],"examine,.",[1],"start{border-radius:",[0,43],";font-size:",[0,30],";height:",[0,86],";line-height:",[0,86],";margin-bottom:",[0,50],";margin-top:",[0,50],";text-align:center;width:40%}\n.",[1],"default{background:#f3f3f3;color:#999}\n",],undefined,{path:"./pages/notice/notice.wxss"});
}