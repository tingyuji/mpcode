var a = require("../../config.js"), n = require("../../http.js"), t = 1;

Page({
    data: {
        userRank: {
            rank: "无",
            total: "无"
        },
        noData: !0
    },
    areaRank: function() {
        wx.navigateTo({
            url: "../area-rank/area-rank"
        });
    },
    loadMoreData: function() {
        t++, this.getAllRank(t);
    },
    onLoad: function(a) {
        t = 1, this.getAllRank(t), this.getMyRank();
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    getAllRank: function(t) {
        var o = this;
        n.request(a.allRank, "GET", {
            page: t,
            pageSize: 20
        }, function(a) {
            null != a && (t > 1 ? o.setData({
                rankData: o.data.rankData.concat(a)
            }) : (o.setData({
                rankData: a
            }), a.length > 0 ? o.setData({
                noData: !1
            }) : o.setData({
                noData: !0
            })));
        }, function(a) {
            wx.showToast({
                title: a,
                icon: "none"
            });
        });
    },
    getMyRank: function() {
        var t = this;
        n.request(a.myRank, "GET", null, function(a) {
            null != a && "" != a && t.setData({
                userRank: a
            });
        }, function(a) {
            wx.showToast({
                title: a,
                icon: "none"
            });
        });
    }
});