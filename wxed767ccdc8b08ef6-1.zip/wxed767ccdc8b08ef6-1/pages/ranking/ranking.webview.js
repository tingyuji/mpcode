$gwx_XC_10=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_10 || [];
function gz$gwx_XC_10_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_10_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_10_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_10_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container3'])
Z([3,'head-img'])
Z([3,'../../images/list_img_2.png'])
Z([3,'head-text'])
Z([3,'历史排名'])
Z([3,'head-hint'])
Z([3,'历史总排名，我有一席之地'])
Z([3,'areaRank'])
Z([3,'area'])
Z([3,'地区排名 》'])
Z([3,'loadMoreData'])
Z([3,'content'])
Z([3,'true'])
Z([[7],[3,'rankData']])
Z([3,'name'])
Z([3,'item'])
Z([3,'item2'])
Z([[2,'=='],[[7],[3,'index']],[1,0]])
Z([3,'item-no'])
Z([a,[3,'NO.'],[[2,'+'],[[7],[3,'index']],[1,1]]])
Z([[2,'=='],[[7],[3,'index']],[1,1]])
Z([3,'item-no2'])
Z([a,z[19][1],z[19][2]])
Z([[2,'=='],[[7],[3,'index']],[1,2]])
Z([3,'item-no3'])
Z([a,z[19][1],z[19][2]])
Z([3,'item-no4'])
Z([a,z[19][1],z[19][2]])
Z([3,'item-name'])
Z([a,[[6],[[7],[3,'item']],[3,'name']]])
Z([3,'item-value'])
Z([a,[[6],[[7],[3,'item']],[3,'total']]])
Z([3,'user'])
Z([3,'user-img'])
Z([3,'userAvatarUrl'])
Z([3,'user-rank'])
Z([3,'我的排名：'])
Z([3,'rank-value'])
Z([a,[[6],[[7],[3,'userRank']],[3,'rank']]])
Z([3,'user-score'])
Z([3,'我的分数：'])
Z([3,'score-value'])
Z([a,[[6],[[7],[3,'userRank']],[3,'total']]])
Z([[7],[3,'noData']])
Z([3,'default'])
Z([3,'暂无排名记录'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_10_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_10_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_10=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_10=true;
var x=['./pages/ranking/ranking.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_10_1()
var aRI=_n('view')
_rz(z,aRI,'class',0,e,s,gg)
var eTI=_mz(z,'image',['class',1,'src',1],[],e,s,gg)
_(aRI,eTI)
var bUI=_n('text')
_rz(z,bUI,'class',3,e,s,gg)
var oVI=_oz(z,4,e,s,gg)
_(bUI,oVI)
_(aRI,bUI)
var xWI=_n('text')
_rz(z,xWI,'class',5,e,s,gg)
var oXI=_oz(z,6,e,s,gg)
_(xWI,oXI)
_(aRI,xWI)
var fYI=_mz(z,'text',['bindtap',7,'class',1],[],e,s,gg)
var cZI=_oz(z,9,e,s,gg)
_(fYI,cZI)
_(aRI,fYI)
var h1I=_mz(z,'scroll-view',['bindscrolltolower',10,'class',1,'scrollY',2],[],e,s,gg)
var o2I=_v()
_(h1I,o2I)
var c3I=function(l5I,o4I,a6I,gg){
var e8I=_n('view')
_rz(z,e8I,'class',15,l5I,o4I,gg)
var b9I=_n('view')
_rz(z,b9I,'class',16,l5I,o4I,gg)
var o0I=_v()
_(b9I,o0I)
if(_oz(z,17,l5I,o4I,gg)){o0I.wxVkey=1
var xAJ=_n('text')
_rz(z,xAJ,'class',18,l5I,o4I,gg)
var oBJ=_oz(z,19,l5I,o4I,gg)
_(xAJ,oBJ)
_(o0I,xAJ)
}
else if(_oz(z,20,l5I,o4I,gg)){o0I.wxVkey=2
var fCJ=_n('text')
_rz(z,fCJ,'class',21,l5I,o4I,gg)
var cDJ=_oz(z,22,l5I,o4I,gg)
_(fCJ,cDJ)
_(o0I,fCJ)
}
else if(_oz(z,23,l5I,o4I,gg)){o0I.wxVkey=3
var hEJ=_n('text')
_rz(z,hEJ,'class',24,l5I,o4I,gg)
var oFJ=_oz(z,25,l5I,o4I,gg)
_(hEJ,oFJ)
_(o0I,hEJ)
}
else{o0I.wxVkey=4
var cGJ=_n('text')
_rz(z,cGJ,'class',26,l5I,o4I,gg)
var oHJ=_oz(z,27,l5I,o4I,gg)
_(cGJ,oHJ)
_(o0I,cGJ)
}
var lIJ=_n('text')
_rz(z,lIJ,'class',28,l5I,o4I,gg)
var aJJ=_oz(z,29,l5I,o4I,gg)
_(lIJ,aJJ)
_(b9I,lIJ)
o0I.wxXCkey=1
_(e8I,b9I)
var tKJ=_n('text')
_rz(z,tKJ,'class',30,l5I,o4I,gg)
var eLJ=_oz(z,31,l5I,o4I,gg)
_(tKJ,eLJ)
_(e8I,tKJ)
_(a6I,e8I)
return a6I
}
o2I.wxXCkey=2
_2z(z,13,c3I,e,s,gg,o2I,'item','index','name')
_(aRI,h1I)
var bMJ=_n('view')
_rz(z,bMJ,'class',32,e,s,gg)
var oNJ=_mz(z,'open-data',['class',33,'type',1],[],e,s,gg)
_(bMJ,oNJ)
var xOJ=_n('text')
_rz(z,xOJ,'class',35,e,s,gg)
var oPJ=_oz(z,36,e,s,gg)
_(xOJ,oPJ)
_(bMJ,xOJ)
var fQJ=_n('text')
_rz(z,fQJ,'class',37,e,s,gg)
var cRJ=_oz(z,38,e,s,gg)
_(fQJ,cRJ)
_(bMJ,fQJ)
var hSJ=_n('text')
_rz(z,hSJ,'class',39,e,s,gg)
var oTJ=_oz(z,40,e,s,gg)
_(hSJ,oTJ)
_(bMJ,hSJ)
var cUJ=_n('text')
_rz(z,cUJ,'class',41,e,s,gg)
var oVJ=_oz(z,42,e,s,gg)
_(cUJ,oVJ)
_(bMJ,cUJ)
_(aRI,bMJ)
var tSI=_v()
_(aRI,tSI)
if(_oz(z,43,e,s,gg)){tSI.wxVkey=1
var lWJ=_n('text')
_rz(z,lWJ,'class',44,e,s,gg)
var aXJ=_oz(z,45,e,s,gg)
_(lWJ,aXJ)
_(tSI,lWJ)
}
tSI.wxXCkey=1
_(r,aRI)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_10";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_10();
	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/ranking/ranking.wxml'] = [$gwx_XC_10, './pages/ranking/ranking.wxml'];else __wxAppCode__['pages/ranking/ranking.wxml'] = $gwx_XC_10( './pages/ranking/ranking.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['pages/ranking/ranking.wxss'] = setCssToHead([".",[1],"head-img{height:",[0,110],";margin-top:",[0,34],";width:",[0,144],"}\n.",[1],"head-text{color:#fff;font-size:",[0,30],";margin-top:",[0,21],"}\n.",[1],"head-hint{color:#fff;font-size:",[0,26],";margin-top:",[0,28],"}\n.",[1],"area{background-color:#fff;border-radius:",[0,35]," ",[0,0]," ",[0,0]," ",[0,35],";color:#8b1b23;height:",[0,70],";line-height:",[0,70],";position:absolute;right:",[0,0],";text-align:center;top:",[0,74],";width:",[0,221],"}\n.",[1],"default{color:#666;font-size:",[0,28],";margin-top:",[0,200],";z-index:2}\n.",[1],"content{background-color:#fff9f3;bottom:",[0,114],";box-shadow:inset ",[0,0]," ",[0,12]," ",[0,15]," ",[0,0]," rgba(62,62,62,.28);position:absolute;top:",[0,284],";width:92%}\n.",[1],"item{border-bottom:",[0,1]," solid #909090;-webkit-justify-content:space-between;justify-content:space-between}\n.",[1],"item,.",[1],"item2{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;-webkit-flex-direction:row;flex-direction:row;height:",[0,96],"}\n.",[1],"item2{margin-left:",[0,30],"}\n.",[1],"item-no{color:#8b1b23}\n.",[1],"item-no,.",[1],"item-no2{font-size:",[0,34],";width:",[0,200],"}\n.",[1],"item-no2{color:#cd003f}\n.",[1],"item-no3{color:#451b8b}\n.",[1],"item-no3,.",[1],"item-no4{font-size:",[0,34],";width:",[0,200],"}\n.",[1],"item-no4{color:#222}\n.",[1],"item-img{background-color:#8b1b23;border-radius:50%;height:",[0,56],";margin-left:",[0,20],";width:",[0,56],"}\n.",[1],"item-name{color:#222;font-size:",[0,28],";margin-left:",[0,25],"}\n.",[1],"item-value{color:#8b1b23;font-size:",[0,28],";margin-right:",[0,30],"}\n.",[1],"user{background:#ffd2aa;border-radius:",[0,45],";bottom:",[0,0],";height:",[0,115],";width:100%}\n.",[1],"user,.",[1],"user-img{position:absolute}\n.",[1],"user-img{background-color:#8b1b23;border-radius:50%;height:",[0,56],";left:",[0,68],";overflow:hidden;top:",[0,32],";width:",[0,56],"}\n.",[1],"user-name{font-size:",[0,32],";left:",[0,70],"}\n.",[1],"user-name,.",[1],"user-rank{color:#222;position:absolute;top:",[0,44],"}\n.",[1],"user-rank{font-size:",[0,30],";left:",[0,200],"}\n.",[1],"rank-value{color:#8b1b23;font-size:",[0,32],";left:",[0,350],";position:absolute;top:",[0,42],";width:",[0,60],"}\n.",[1],"user-score{color:#222;font-size:",[0,30],";position:absolute;right:",[0,147],";top:",[0,44],"}\n.",[1],"score-value{color:#8b1b23;font-size:",[0,32],";position:absolute;right:",[0,80],";top:",[0,42],";width:",[0,62],"}\n",],undefined,{path:"./pages/ranking/ranking.wxss"});
}