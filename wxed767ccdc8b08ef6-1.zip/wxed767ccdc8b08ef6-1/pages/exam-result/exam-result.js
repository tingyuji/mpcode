var e = require("../../config.js"), t = require("../../http.js"), a = getApp();

Page({
    data: {
        type: -1,
        examPaper: null,
        userScore: null
    },
    onLoad: function(e) {
        var t = e.type;
        this.setData({
            type: t
        });
        var o = wx.getStorageSync("userInfo");
        if (o && this.setData({
            userAvatarUrl: o.avatarUrl,
            userNickName: o.nickName
        }), 1 == t) {
            var n = a.globalData.question;
            this.setData({
                unsureness: n.zero,
                single: n.one,
                multiple: n.two,
                check: n.three,
                completion: n.four
            });
            var i = wx.getStorageSync("examMsg");
            i && this.setData({
                exam: i,
                examName: i.theme
            });
            var s = wx.getStorageSync("examPaper");
            s && this.setData({
                examData: s
            }), this.setData({
                userScore: a.globalData.score
            });
            var r = wx.getStorageSync("examRecord");
            r && this.setData({
                examRecord: r
            });
        } else {
            var l = wx.getStorageSync("testRecord");
            if (l) {
                a.globalData.examTitle = {
                    name: l.examName,
                    start: l.startTime,
                    end: l.endTime
                };
                var c = new Date().getTime(), u = l.startTime.replace(/-/g, "/"), d = new Date(u).getTime(), m = l.endTime.replace(/-/g, "/"), h = new Date(m).getTime();
                c > d && c < h ? this.setData({
                    showDetail: !1
                }) : this.setData({
                    showDetail: !0
                }), this.setData({
                    examName: l.examName
                }), this.setData({
                    examData: {
                        unsurenessTotalPoint: l.unsurenessPoint,
                        singleTotalPoint: l.singlePoint,
                        multipleTotalPoint: l.mulitplePoint,
                        checkTotalPoint: l.checkPoint,
                        completionTotalPoint: l.completionPoint,
                        totalPoint: l.totalPoint
                    }
                }), null != l.unsurenessPoint && 0 != l.unsurenessPoint && this.setData({
                    unsureness: !0
                }), null != l.singlePoint && 0 != l.singlePoint && this.setData({
                    single: !0
                }), null != l.mulitplePoint && 0 != l.mulitplePoint && this.setData({
                    multiple: !0
                }), null != l.checkPoint && 0 != l.checkPoint && this.setData({
                    check: !0
                }), null != l.completionPoint && 0 != l.completionPoint && this.setData({
                    completion: !0
                }), null != l.eaeExamRecordVO && this.setData({
                    userScore: {
                        zero: l.eaeExamRecordVO.unsurenessPoint,
                        one: l.eaeExamRecordVO.singlePoint,
                        two: l.eaeExamRecordVO.multiplePoint,
                        three: l.eaeExamRecordVO.checkPoint,
                        four: l.eaeExamRecordVO.completionPoint,
                        total: l.eaeExamRecordVO.totalPoint
                    },
                    recordId: l.eaeExamRecordVO.id,
                    examId: l.examId
                });
            }
        }
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    backIndex: function() {
        wx.reLaunch({
            url: "../index/index"
        });
    },
    again: function() {
        a.globalData.question.zero ? wx.navigateTo({
            url: "../loading/loading?type=0&questionType=0"
        }) : a.globalData.question.one ? wx.navigateTo({
            url: "../loading/loading?type=0&questionType=1"
        }) : a.globalData.question.two ? wx.navigateTo({
            url: "../loading/loading?type=0&questionType=2"
        }) : a.globalData.question.three ? wx.navigateTo({
            url: "../loading/loading?type=0&questionType=3"
        }) : a.globalData.question.four && wx.navigateTo({
            url: "../loading/loading?type=0&questionType=4"
        });
    },
    submit: function() {
        t.request(e.addRecord, "POST", {
            examId: this.data.exam.id,
            single_point: this.data.userScore.one,
            multiple_point: this.data.userScore.two,
            check_point: this.data.userScore.three,
            completion_point: this.data.userScore.four,
            unsureness_point: this.data.userScore.zero,
            unsurenessRecord: this.data.examRecord.unsurenessArray,
            singleRecord: this.data.examRecord.singleArray,
            multipleRecord: this.data.examRecord.multipleArray,
            checkRecord: this.data.examRecord.checkArray,
            completionRecord: this.data.examRecord.completionArray
        }, function(e) {
            wx.showToast({
                title: "成绩提交成功"
            }), setTimeout(function() {
                wx.reLaunch({
                    url: "../index/index"
                });
            }, 1500);
        }, function(e) {
            wx.showToast({
                title: e,
                icon: "none"
            });
        }, !0);
    },
    examPaper: function() {
        this.data.showDetail ? wx.navigateTo({
            url: "../test-paper/test-paper?type=2&examId=" + this.data.examId + "&recordId=" + this.data.recordId
        }) : wx.showToast({
            title: "考试还未结束，不能查看试卷",
            icon: "none"
        });
    }
});