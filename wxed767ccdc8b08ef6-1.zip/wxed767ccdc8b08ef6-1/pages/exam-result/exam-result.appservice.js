$gwx_XC_2=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_2 || [];
function gz$gwx_XC_2_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_2_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_2_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_2_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container4'])
Z([3,'content'])
Z([[7],[3,'single']])
Z([[7],[3,'multiple']])
Z([[7],[3,'check']])
Z([[7],[3,'completion']])
Z([[7],[3,'unsureness']])
Z([[2,'=='],[[7],[3,'type']],[1,1]])
Z(z[7])
Z(z[7])
Z([[2,'>'],[[6],[[7],[3,'exam']],[3,'tryAgain']],[1,0]])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_2_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_2_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_2=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_2=true;
var x=['./pages/exam-result/exam-result.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_2_1()
var oH=_n('view')
_rz(z,oH,'class',0,e,s,gg)
var aL=_n('view')
_rz(z,aL,'class',1,e,s,gg)
var tM=_v()
_(aL,tM)
if(_oz(z,2,e,s,gg)){tM.wxVkey=1
}
var eN=_v()
_(aL,eN)
if(_oz(z,3,e,s,gg)){eN.wxVkey=1
}
var bO=_v()
_(aL,bO)
if(_oz(z,4,e,s,gg)){bO.wxVkey=1
}
var oP=_v()
_(aL,oP)
if(_oz(z,5,e,s,gg)){oP.wxVkey=1
}
var xQ=_v()
_(aL,xQ)
if(_oz(z,6,e,s,gg)){xQ.wxVkey=1
}
tM.wxXCkey=1
eN.wxXCkey=1
bO.wxXCkey=1
oP.wxXCkey=1
xQ.wxXCkey=1
_(oH,aL)
var cI=_v()
_(oH,cI)
if(_oz(z,7,e,s,gg)){cI.wxVkey=1
}
var oJ=_v()
_(oH,oJ)
if(_oz(z,8,e,s,gg)){oJ.wxVkey=1
}
var lK=_v()
_(oH,lK)
if(_oz(z,9,e,s,gg)){lK.wxVkey=1
var oR=_v()
_(lK,oR)
if(_oz(z,10,e,s,gg)){oR.wxVkey=1
}
oR.wxXCkey=1
}
else{lK.wxVkey=2
}
cI.wxXCkey=1
oJ.wxXCkey=1
lK.wxXCkey=1
_(r,oH)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_2";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_2();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/exam-result/exam-result.wxml'] = [$gwx_XC_2, './pages/exam-result/exam-result.wxml'];else __wxAppCode__['pages/exam-result/exam-result.wxml'] = $gwx_XC_2( './pages/exam-result/exam-result.wxml' );
	;__wxRoute = "pages/exam-result/exam-result";__wxRouteBegin = true;__wxAppCurrentFile__="pages/exam-result/exam-result.js";define("pages/exam-result/exam-result.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var e=require("../../config.js"),t=require("../../http.js"),a=getApp();Page({data:{type:-1,examPaper:null,userScore:null},onLoad:function(e){var t=e.type;this.setData({type:t});var o=wx.getStorageSync("userInfo");if(o&&this.setData({userAvatarUrl:o.avatarUrl,userNickName:o.nickName}),1==t){var n=a.globalData.question;this.setData({unsureness:n.zero,single:n.one,multiple:n.two,check:n.three,completion:n.four});var i=wx.getStorageSync("examMsg");i&&this.setData({exam:i,examName:i.theme});var s=wx.getStorageSync("examPaper");s&&this.setData({examData:s}),this.setData({userScore:a.globalData.score});var r=wx.getStorageSync("examRecord");r&&this.setData({examRecord:r})}else{var l=wx.getStorageSync("testRecord");if(l){a.globalData.examTitle={name:l.examName,start:l.startTime,end:l.endTime};var c=(new Date).getTime(),u=l.startTime.replace(/-/g,"/"),d=new Date(u).getTime(),m=l.endTime.replace(/-/g,"/"),h=new Date(m).getTime();c>d&&c<h?this.setData({showDetail:!1}):this.setData({showDetail:!0}),this.setData({examName:l.examName}),this.setData({examData:{unsurenessTotalPoint:l.unsurenessPoint,singleTotalPoint:l.singlePoint,multipleTotalPoint:l.mulitplePoint,checkTotalPoint:l.checkPoint,completionTotalPoint:l.completionPoint,totalPoint:l.totalPoint}}),null!=l.unsurenessPoint&&0!=l.unsurenessPoint&&this.setData({unsureness:!0}),null!=l.singlePoint&&0!=l.singlePoint&&this.setData({single:!0}),null!=l.mulitplePoint&&0!=l.mulitplePoint&&this.setData({multiple:!0}),null!=l.checkPoint&&0!=l.checkPoint&&this.setData({check:!0}),null!=l.completionPoint&&0!=l.completionPoint&&this.setData({completion:!0}),null!=l.eaeExamRecordVO&&this.setData({userScore:{zero:l.eaeExamRecordVO.unsurenessPoint,one:l.eaeExamRecordVO.singlePoint,two:l.eaeExamRecordVO.multiplePoint,three:l.eaeExamRecordVO.checkPoint,four:l.eaeExamRecordVO.completionPoint,total:l.eaeExamRecordVO.totalPoint},recordId:l.eaeExamRecordVO.id,examId:l.examId})}}},onReady:function(){},onShow:function(){},onHide:function(){},onUnload:function(){},backIndex:function(){wx.reLaunch({url:"../index/index"})},again:function(){a.globalData.question.zero?wx.navigateTo({url:"../loading/loading?type=0&questionType=0"}):a.globalData.question.one?wx.navigateTo({url:"../loading/loading?type=0&questionType=1"}):a.globalData.question.two?wx.navigateTo({url:"../loading/loading?type=0&questionType=2"}):a.globalData.question.three?wx.navigateTo({url:"../loading/loading?type=0&questionType=3"}):a.globalData.question.four&&wx.navigateTo({url:"../loading/loading?type=0&questionType=4"})},submit:function(){t.request(e.addRecord,"POST",{examId:this.data.exam.id,single_point:this.data.userScore.one,multiple_point:this.data.userScore.two,check_point:this.data.userScore.three,completion_point:this.data.userScore.four,unsureness_point:this.data.userScore.zero,unsurenessRecord:this.data.examRecord.unsurenessArray,singleRecord:this.data.examRecord.singleArray,multipleRecord:this.data.examRecord.multipleArray,checkRecord:this.data.examRecord.checkArray,completionRecord:this.data.examRecord.completionArray},(function(e){wx.showToast({title:"成绩提交成功"}),setTimeout((function(){wx.reLaunch({url:"../index/index"})}),1500)}),(function(e){wx.showToast({title:e,icon:"none"})}),!0)},examPaper:function(){this.data.showDetail?wx.navigateTo({url:"../test-paper/test-paper?type=2&examId="+this.data.examId+"&recordId="+this.data.recordId}):wx.showToast({title:"考试还未结束，不能查看试卷",icon:"none"})}});
},{isPage:true,isComponent:true,currentFile:'pages/exam-result/exam-result.js'});require("pages/exam-result/exam-result.js");