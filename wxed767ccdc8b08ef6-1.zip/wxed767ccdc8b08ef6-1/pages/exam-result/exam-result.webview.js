$gwx_XC_2=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_2 || [];
function gz$gwx_XC_2_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_2_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_2_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_2_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container4'])
Z([3,'head-img'])
Z([3,'../../images/ques_img_1.png'])
Z([3,'content'])
Z([3,'user-img'])
Z([[7],[3,'userAvatarUrl']])
Z([3,'user-bg'])
Z([3,'../../images/results_img_1.png'])
Z([3,'user-name'])
Z([a,[[7],[3,'userNickName']]])
Z([3,'user-hint'])
Z([a,[3,'您在'],[[7],[3,'examName']],[3,'考试中获得'],[[6],[[7],[3,'userScore']],[3,'total']],[3,'分的成绩。成绩单如下所示。考试结束后，您可以通过个人中心查看详细答题记录。']])
Z([3,'tab-head'])
Z([3,'title'])
Z([3,'题型'])
Z(z[13])
Z([3,'总分'])
Z(z[13])
Z([3,'得分'])
Z([[7],[3,'single']])
Z([3,'tab-head2'])
Z([3,'title2'])
Z([3,'单选题'])
Z(z[21])
Z([a,[[6],[[7],[3,'examData']],[3,'singleTotalPoint']]])
Z([3,'title3'])
Z([a,[[6],[[7],[3,'userScore']],[3,'one']]])
Z([[7],[3,'multiple']])
Z(z[20])
Z(z[21])
Z([3,'多选题'])
Z(z[21])
Z([a,[[6],[[7],[3,'examData']],[3,'multipleTotalPoint']]])
Z(z[25])
Z([a,[[6],[[7],[3,'userScore']],[3,'two']]])
Z([[7],[3,'check']])
Z(z[20])
Z(z[21])
Z([3,'判断题'])
Z(z[21])
Z([a,[[6],[[7],[3,'examData']],[3,'checkTotalPoint']]])
Z(z[25])
Z([a,[[6],[[7],[3,'userScore']],[3,'three']]])
Z([[7],[3,'completion']])
Z(z[20])
Z(z[21])
Z([3,'填空题'])
Z(z[21])
Z([a,[[6],[[7],[3,'examData']],[3,'completionTotalPoint']]])
Z(z[25])
Z([a,[[6],[[7],[3,'userScore']],[3,'four']]])
Z([[7],[3,'unsureness']])
Z(z[20])
Z(z[21])
Z([3,'不定项选择题'])
Z(z[21])
Z([a,[[6],[[7],[3,'examData']],[3,'unsurenessTotalPoint']]])
Z(z[25])
Z([a,[[6],[[7],[3,'userScore']],[3,'zero']]])
Z([3,'tab-head3'])
Z(z[21])
Z(z[16])
Z(z[21])
Z([a,[[6],[[7],[3,'examData']],[3,'totalPoint']]])
Z(z[25])
Z([a,z[11][4]])
Z([[2,'=='],[[7],[3,'type']],[1,1]])
Z([3,'exam-hint'])
Z([3,'注：1.如您对本次答题成绩不满意，可点击【重答一次】按钮重新进行答题。'])
Z(z[66])
Z(z[67])
Z([3,'emsp'])
Z([3,'  2.如对本次答题成绩满意，请您点击【提交成绩】按钮主动提交成绩；如不提交，我们将无法记录您本次考试成绩。'])
Z(z[66])
Z([3,'btnview'])
Z([[2,'>'],[[6],[[7],[3,'exam']],[3,'tryAgain']],[1,0]])
Z([3,'again'])
Z([3,'left-btn'])
Z([3,'重答一次'])
Z([3,'submit'])
Z([3,'right-btn'])
Z([3,'提交成绩'])
Z([3,'examPaper'])
Z([3,'center-btn'])
Z([3,'查看试卷'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_2_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_2_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_2=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_2=true;
var x=['./pages/exam-result/exam-result.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_2_1()
var xOC=_n('view')
_rz(z,xOC,'class',0,e,s,gg)
var hSC=_mz(z,'image',['class',1,'src',1],[],e,s,gg)
_(xOC,hSC)
var oTC=_n('view')
_rz(z,oTC,'class',3,e,s,gg)
var eZC=_mz(z,'image',['class',4,'src',1],[],e,s,gg)
_(oTC,eZC)
var b1C=_mz(z,'image',['class',6,'src',1],[],e,s,gg)
_(oTC,b1C)
var o2C=_n('text')
_rz(z,o2C,'class',8,e,s,gg)
var x3C=_oz(z,9,e,s,gg)
_(o2C,x3C)
_(oTC,o2C)
var o4C=_n('text')
_rz(z,o4C,'class',10,e,s,gg)
var f5C=_oz(z,11,e,s,gg)
_(o4C,f5C)
_(oTC,o4C)
var c6C=_n('view')
_rz(z,c6C,'class',12,e,s,gg)
var h7C=_n('view')
_rz(z,h7C,'class',13,e,s,gg)
var o8C=_oz(z,14,e,s,gg)
_(h7C,o8C)
_(c6C,h7C)
var c9C=_n('view')
_rz(z,c9C,'class',15,e,s,gg)
var o0C=_oz(z,16,e,s,gg)
_(c9C,o0C)
_(c6C,c9C)
var lAD=_n('view')
_rz(z,lAD,'class',17,e,s,gg)
var aBD=_oz(z,18,e,s,gg)
_(lAD,aBD)
_(c6C,lAD)
_(oTC,c6C)
var cUC=_v()
_(oTC,cUC)
if(_oz(z,19,e,s,gg)){cUC.wxVkey=1
var tCD=_n('view')
_rz(z,tCD,'class',20,e,s,gg)
var eDD=_n('view')
_rz(z,eDD,'class',21,e,s,gg)
var bED=_oz(z,22,e,s,gg)
_(eDD,bED)
_(tCD,eDD)
var oFD=_n('view')
_rz(z,oFD,'class',23,e,s,gg)
var xGD=_oz(z,24,e,s,gg)
_(oFD,xGD)
_(tCD,oFD)
var oHD=_n('view')
_rz(z,oHD,'class',25,e,s,gg)
var fID=_oz(z,26,e,s,gg)
_(oHD,fID)
_(tCD,oHD)
_(cUC,tCD)
}
var oVC=_v()
_(oTC,oVC)
if(_oz(z,27,e,s,gg)){oVC.wxVkey=1
var cJD=_n('view')
_rz(z,cJD,'class',28,e,s,gg)
var hKD=_n('view')
_rz(z,hKD,'class',29,e,s,gg)
var oLD=_oz(z,30,e,s,gg)
_(hKD,oLD)
_(cJD,hKD)
var cMD=_n('view')
_rz(z,cMD,'class',31,e,s,gg)
var oND=_oz(z,32,e,s,gg)
_(cMD,oND)
_(cJD,cMD)
var lOD=_n('view')
_rz(z,lOD,'class',33,e,s,gg)
var aPD=_oz(z,34,e,s,gg)
_(lOD,aPD)
_(cJD,lOD)
_(oVC,cJD)
}
var lWC=_v()
_(oTC,lWC)
if(_oz(z,35,e,s,gg)){lWC.wxVkey=1
var tQD=_n('view')
_rz(z,tQD,'class',36,e,s,gg)
var eRD=_n('view')
_rz(z,eRD,'class',37,e,s,gg)
var bSD=_oz(z,38,e,s,gg)
_(eRD,bSD)
_(tQD,eRD)
var oTD=_n('view')
_rz(z,oTD,'class',39,e,s,gg)
var xUD=_oz(z,40,e,s,gg)
_(oTD,xUD)
_(tQD,oTD)
var oVD=_n('view')
_rz(z,oVD,'class',41,e,s,gg)
var fWD=_oz(z,42,e,s,gg)
_(oVD,fWD)
_(tQD,oVD)
_(lWC,tQD)
}
var aXC=_v()
_(oTC,aXC)
if(_oz(z,43,e,s,gg)){aXC.wxVkey=1
var cXD=_n('view')
_rz(z,cXD,'class',44,e,s,gg)
var hYD=_n('view')
_rz(z,hYD,'class',45,e,s,gg)
var oZD=_oz(z,46,e,s,gg)
_(hYD,oZD)
_(cXD,hYD)
var c1D=_n('view')
_rz(z,c1D,'class',47,e,s,gg)
var o2D=_oz(z,48,e,s,gg)
_(c1D,o2D)
_(cXD,c1D)
var l3D=_n('view')
_rz(z,l3D,'class',49,e,s,gg)
var a4D=_oz(z,50,e,s,gg)
_(l3D,a4D)
_(cXD,l3D)
_(aXC,cXD)
}
var tYC=_v()
_(oTC,tYC)
if(_oz(z,51,e,s,gg)){tYC.wxVkey=1
var t5D=_n('view')
_rz(z,t5D,'class',52,e,s,gg)
var e6D=_n('view')
_rz(z,e6D,'class',53,e,s,gg)
var b7D=_oz(z,54,e,s,gg)
_(e6D,b7D)
_(t5D,e6D)
var o8D=_n('view')
_rz(z,o8D,'class',55,e,s,gg)
var x9D=_oz(z,56,e,s,gg)
_(o8D,x9D)
_(t5D,o8D)
var o0D=_n('view')
_rz(z,o0D,'class',57,e,s,gg)
var fAE=_oz(z,58,e,s,gg)
_(o0D,fAE)
_(t5D,o0D)
_(tYC,t5D)
}
var cBE=_n('view')
_rz(z,cBE,'class',59,e,s,gg)
var hCE=_n('view')
_rz(z,hCE,'class',60,e,s,gg)
var oDE=_oz(z,61,e,s,gg)
_(hCE,oDE)
_(cBE,hCE)
var cEE=_n('view')
_rz(z,cEE,'class',62,e,s,gg)
var oFE=_oz(z,63,e,s,gg)
_(cEE,oFE)
_(cBE,cEE)
var lGE=_n('view')
_rz(z,lGE,'class',64,e,s,gg)
var aHE=_oz(z,65,e,s,gg)
_(lGE,aHE)
_(cBE,lGE)
_(oTC,cBE)
cUC.wxXCkey=1
oVC.wxXCkey=1
lWC.wxXCkey=1
aXC.wxXCkey=1
tYC.wxXCkey=1
_(xOC,oTC)
var oPC=_v()
_(xOC,oPC)
if(_oz(z,66,e,s,gg)){oPC.wxVkey=1
var tIE=_n('text')
_rz(z,tIE,'class',67,e,s,gg)
var eJE=_oz(z,68,e,s,gg)
_(tIE,eJE)
_(oPC,tIE)
}
var fQC=_v()
_(xOC,fQC)
if(_oz(z,69,e,s,gg)){fQC.wxVkey=1
var bKE=_mz(z,'text',['class',70,'space',1],[],e,s,gg)
var oLE=_oz(z,72,e,s,gg)
_(bKE,oLE)
_(fQC,bKE)
}
var cRC=_v()
_(xOC,cRC)
if(_oz(z,73,e,s,gg)){cRC.wxVkey=1
var xME=_n('view')
_rz(z,xME,'class',74,e,s,gg)
var oNE=_v()
_(xME,oNE)
if(_oz(z,75,e,s,gg)){oNE.wxVkey=1
var fOE=_mz(z,'text',['bindtap',76,'class',1],[],e,s,gg)
var cPE=_oz(z,78,e,s,gg)
_(fOE,cPE)
_(oNE,fOE)
}
var hQE=_mz(z,'text',['bindtap',79,'class',1],[],e,s,gg)
var oRE=_oz(z,81,e,s,gg)
_(hQE,oRE)
_(xME,hQE)
oNE.wxXCkey=1
_(cRC,xME)
}
else{cRC.wxVkey=2
var cSE=_mz(z,'text',['bindtap',82,'class',1],[],e,s,gg)
var oTE=_oz(z,84,e,s,gg)
_(cSE,oTE)
_(cRC,cSE)
}
oPC.wxXCkey=1
fQC.wxXCkey=1
cRC.wxXCkey=1
_(r,xOC)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_2";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_2();
	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/exam-result/exam-result.wxml'] = [$gwx_XC_2, './pages/exam-result/exam-result.wxml'];else __wxAppCode__['pages/exam-result/exam-result.wxml'] = $gwx_XC_2( './pages/exam-result/exam-result.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['pages/exam-result/exam-result.wxss'] = setCssToHead([".",[1],"head-img{height:",[0,50],";margin-top:",[0,30],";width:94%}\n.",[1],"content{-webkit-align-items:center;align-items:center;background-color:#fff;border:",[0,2]," solid #000;display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column;min-height:",[0,800],";overflow-y:scroll;width:90%}\n.",[1],"user-img{background-color:#8b1b23;border-radius:50%;height:",[0,164],";margin-top:",[0,30],";overflow:hidden;width:",[0,164],"}\n.",[1],"user-bg{height:",[0,180],";position:absolute;top:",[0,109],";width:",[0,199],"}\n.",[1],"user-name{color:#8b1b23;font-size:",[0,34],";margin-top:",[0,30],"}\n.",[1],"user-hint{color:#212121;font-size:",[0,28],";line-height:",[0,40],";margin-top:",[0,20],";width:90%}\n.",[1],"tab-head{-webkit-align-items:center;align-items:center;border:",[0,1]," solid #e0e0e0;display:-webkit-flex;display:flex;-webkit-flex-direction:row;flex-direction:row;height:",[0,68],";-webkit-justify-content:space-around;justify-content:space-around;margin-top:",[0,20],";width:96%}\n.",[1],"title{color:#8b1b23}\n.",[1],"title,.",[1],"title2{font-size:",[0,26],";font-weight:700;height:",[0,68],";line-height:",[0,68],";text-align:center;width:33%}\n.",[1],"title2{color:#656565}\n.",[1],"title3{color:#333;font-size:",[0,26],";font-weight:700;height:",[0,68],";line-height:",[0,68],";text-align:center;width:33%}\n.",[1],"tab-head2,.",[1],"tab-head3{-webkit-align-items:center;align-items:center;border-bottom:",[0,1]," solid #b2b2b2;border-left:",[0,1]," solid #b2b2b2;border-right:",[0,1]," solid #b2b2b2;display:-webkit-flex;display:flex;-webkit-flex-direction:row;flex-direction:row;height:",[0,68],";-webkit-justify-content:space-around;justify-content:space-around;width:96%}\n.",[1],"tab-head3{background-color:#ffd1a9;margin-bottom:",[0,50],"}\n.",[1],"exam-hint{color:#333;font-size:",[0,24],";margin-left:",[0,20],";width:96%}\n.",[1],"btnview{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;-webkit-flex-direction:row;flex-direction:row;-webkit-justify-content:space-around;justify-content:space-around;margin-bottom:",[0,25],";margin-top:",[0,20],";width:100%}\n.",[1],"left-btn{border:",[0,4]," solid #8b1b23;color:#8b1b23}\n.",[1],"left-btn,.",[1],"right-btn{border-radius:",[0,43],";font-size:",[0,30],";height:",[0,86],";line-height:",[0,86],";text-align:center;width:40%}\n.",[1],"right-btn{border:",[0,4]," solid #8b1b23}\n.",[1],"center-btn,.",[1],"right-btn{background:#8b1b23;color:#fff}\n.",[1],"center-btn{border-radius:",[0,43],";font-size:",[0,30],";height:",[0,86],";line-height:",[0,86],";margin-bottom:",[0,25],";margin-top:",[0,35],";text-align:center;width:50%}\n",],undefined,{path:"./pages/exam-result/exam-result.wxss"});
}