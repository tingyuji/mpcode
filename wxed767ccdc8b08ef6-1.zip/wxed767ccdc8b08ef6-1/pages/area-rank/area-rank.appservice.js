$gwx_XC_1=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_1 || [];
function gz$gwx_XC_1_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_1_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_1_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_1_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'noData']])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_1_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_1_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_1=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_1=true;
var x=['./pages/area-rank/area-rank.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_1_1()
var cF=_v()
_(r,cF)
if(_oz(z,0,e,s,gg)){cF.wxVkey=1
}
cF.wxXCkey=1
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_1";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_1();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/area-rank/area-rank.wxml'] = [$gwx_XC_1, './pages/area-rank/area-rank.wxml'];else __wxAppCode__['pages/area-rank/area-rank.wxml'] = $gwx_XC_1( './pages/area-rank/area-rank.wxml' );
	;__wxRoute = "pages/area-rank/area-rank";__wxRouteBegin = true;__wxAppCurrentFile__="pages/area-rank/area-rank.js";define("pages/area-rank/area-rank.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var a=require("../../config.js"),t=require("../../http.js"),i=1;Page({data:{multiArray:[["区（中）直单位","地（市）"],["党政机关","事业单位","人民团体","中直单位","国有企业"],["自治区纪委","自治区党委办公厅","自治区人大办公厅","自治区政府办公厅","自治区政协办公厅","自治区高级人民法院","自治区人民检察院","自治区党委组织部","自治区党委宣传部","自治区党委统战部","自治区党委政法委","自治区党委政研室","自治区党委网信办","区直机关工委","自治区党委老干部局","自治区发改委","自治区教育厅","自治区科技厅","自治区经信厅","自治区民族事务委员会","自治区公安厅","自治区民政厅","自治区司法厅","自治区财政厅","自治区人社厅","自治区自然资源厅","自治区生态环境厅","自治区住建厅","自治区交通厅","自治区水利厅","自治区农业农村厅","自治区商务厅","自治区文化厅","自治区卫健委","自治区旅游发展厅","自治区退役军人事务厅","自治区应急管理厅","自治区审计厅","自治区外事办","自治区政府国资委","自治区市场监督管理局","自治区广电局","自治区体育局","自治区统计局","自治区扶贫办","自治区林业和草原局","自治区宗教事务局","自治区医疗保障局","自治区人防办","自治区政府研究室","自治区信访局","自治区粮食和物资储备局","自治区能源局","自治区文物局","自治区药监局","北京办事处","成都办事处","上海办事处","格尔木办事处","西安办事处","其他单位（自行填写）"]],multiIndex:[0,0,0],userRank:{rank:"无",total:"无"},noData:!0},onLoad:function(a){var t=this.data.multiArray[0][this.data.multiIndex[0]]+this.data.multiArray[1][this.data.multiIndex[1]]+this.data.multiArray[2][this.data.multiIndex[2]];this.setData({area:t}),i=1,this.getAllRank(i),this.getMyRank()},onReady:function(){},onShow:function(){},onHide:function(){},onUnload:function(){},bindMultiPickerChange:function(a){this.setData({multiIndex:a.detail.value});var t=this.data.multiArray[0][this.data.multiIndex[0]]+this.data.multiArray[1][this.data.multiIndex[1]]+this.data.multiArray[2][this.data.multiIndex[2]];this.setData({area:t,userRank:{rank:"无",total:"无"},noData:!0}),i=1,this.getAllRank(i),this.getMyRank()},bindMultiPickerColumnChange:function(a){var t={multiArray:this.data.multiArray,multiIndex:this.data.multiIndex};switch(t.multiIndex[a.detail.column]=a.detail.value,a.detail.column){case 0:switch(t.multiIndex[0]){case 0:t.multiArray[1]=["党政机关","事业单位","人民团体","中直单位","国有企业"],t.multiArray[2]=["自治区纪委","自治区党委办公厅","自治区人大办公厅","自治区政府办公厅","自治区政协办公厅","自治区高级人民法院","自治区人民检察院","自治区党委组织部","自治区党委宣传部","自治区党委统战部","自治区党委政法委","自治区党委政研室","自治区党委网信办","区直机关工委","自治区党委老干部局","自治区发改委","自治区教育厅","自治区科技厅","自治区经信厅","自治区民族事务委员会","自治区公安厅","自治区民政厅","自治区司法厅","自治区财政厅","自治区人社厅","自治区自然资源厅","自治区生态环境厅","自治区住建厅","自治区交通厅","自治区水利厅","自治区农业农村厅","自治区商务厅","自治区文化厅","自治区卫健委","自治区旅游发展厅","自治区退役军人事务厅","自治区应急管理厅","自治区审计厅","自治区外事办","自治区政府国资委","自治区市场监督管理局","自治区广电局","自治区体育局","自治区统计局","自治区扶贫办","自治区林业和草原局","自治区宗教事务局","自治区医疗保障局","自治区人防办","自治区政府研究室","自治区信访局","自治区粮食和物资储备局","自治区能源局","自治区文物局","自治区药监局","北京办事处","成都办事处","上海办事处","格尔木办事处","西安办事处","其他单位（自行填写）"];break;case 1:t.multiArray[1]=["拉萨市","日喀则市","昌都市","山南市","那曲市","阿里地区","林芝市"],t.multiArray[2]=["市直单位","其他单位（自行填写）","城关区","林周县","当雄县","尼木县","曲水县","堆龙德庆区","达孜区","墨竹工卡县"]}t.multiIndex[1]=0,t.multiIndex[2]=0;break;case 1:switch(t.multiIndex[0]){case 0:switch(t.multiIndex[1]){case 0:t.multiArray[2]=["自治区纪委","自治区党委办公厅","自治区人大办公厅","自治区政府办公厅","自治区政协办公厅","自治区高级人民法院","自治区人民检察院","自治区党委组织部","自治区党委宣传部","自治区党委统战部","自治区党委政法委","自治区党委政研室","自治区党委网信办","区直机关工委","自治区党委老干部局","自治区发改委","自治区教育厅","自治区科技厅","自治区经信厅","自治区民族事务委员会","自治区公安厅","自治区民政厅","自治区司法厅","自治区财政厅","自治区人社厅","自治区自然资源厅","自治区生态环境厅","自治区住建厅","自治区交通厅","自治区水利厅","自治区农业农村厅","自治区商务厅","自治区文化厅","自治区卫健委","自治区旅游发展厅","自治区退役军人事务厅","自治区应急管理厅","自治区审计厅","自治区外事办","自治区政府国资委","自治区市场监督管理局","自治区广电局","自治区体育局","自治区统计局","自治区扶贫办","自治区林业和草原局","自治区宗教事务局","自治区医疗保障局","自治区人防办","自治区政府研究室","自治区信访局","自治区粮食和物资储备局","自治区能源局","自治区文物局","自治区药监局","北京办事处","成都办事处","上海办事处","格尔木办事处","西安办事处","其他单位（自行填写）"];break;case 1:t.multiArray[2]=["自治区党校（自治区行政学院）","西藏日报社","自治区社科院","西藏大学","西藏农牧学院","西藏民族大学","西藏藏医药大学","自治区藏语工作委员会办公室（编译局）","自治区农科院","自治区地质矿产勘查开发局","西藏广播电视台","其他单位（自行填写）"];break;case 2:t.multiArray[2]=["自治区总工会","团区委","自治区妇联","自治区文联","自治区工商联","自治区科协","佛协西藏分会","自治区残联","自治区红十字会","其他单位（自行填写）"];break;case 3:t.multiArray[2]=["国家税务总局西藏税务局","拉萨海关","西藏自治区通信管理局","西藏自治区邮政管理局","西藏自治区地震局","西藏自治区气象局","民航西藏自治区管理局","其他单位（自行填写）"];break;case 4:t.multiArray[2]=["全部"]}break;case 1:switch(t.multiIndex[1]){case 0:t.multiArray[2]=["市直单位","其他单位（自行填写）","城关区","林周县","当雄县","尼木县","曲水县","堆龙德庆区","达孜区","墨竹工卡县"];break;case 1:t.multiArray[2]=["市直单位","其他单位（自行填写）","桑珠孜区","南木林县","江孜县","定日县","萨迦县","拉孜县","昂仁县","谢通门县","白朗县","仁布县","康马县","定结县","仲巴县","亚东县","吉隆县","聂拉木县","萨嘎县","岗巴县"];break;case 2:t.multiArray[2]=["市直单位","其他单位（自行填写）","卡若区","江达县","贡觉县","类乌齐县","丁青县","察雅县","八宿县","左贡县","芒康县","洛隆县","边坝县"];break;case 3:t.multiArray[2]=["市直单位","其他单位（自行填写）","乃东区","扎囊县","贡嘎县","桑日县","琼结县","曲松县","措美县","洛扎县","加查县","隆子县","错那县","浪卡子县"];break;case 4:t.multiArray[2]=["市直单位","其他单位（自行填写）","色尼区","嘉黎县","比如县","聂荣县","安多县","申扎县","索县","班戈县","巴青县","尼玛县","双湖县"];break;case 5:t.multiArray[2]=["地直单位","其他单位（自行填写）","普兰县","札达县","噶尔县","日土县","革吉县","改则县","措勤县"];break;case 6:t.multiArray[2]=["市直单位","其他单位（自行填写）","巴宜区","工布江达县","米林县","墨脱县","波密县","察隅县","朗县"]}}t.multiIndex[2]=0}this.setData(t)},historyRank:function(){wx.navigateBack({delta:1})},loadMoreData:function(){i++,this.getAllRank(i)},getAllRank:function(i){var e=this;t.request(a.allRank,"GET",{page:i,pageSize:20,area:this.data.area},(function(a){null!=a&&(i>1?e.setData({rankData:e.data.rankData.concat(a)}):(e.setData({rankData:a}),a.length>0&&e.setData({noData:!1})))}),(function(a){wx.showToast({title:a,icon:"none"})}))},getMyRank:function(){var i=this;t.request(a.myRank,"GET",{area:this.data.area},(function(a){null!=a&&""!=a&&i.setData({userRank:a})}),(function(a){wx.showToast({title:a,icon:"none"})}))}});
},{isPage:true,isComponent:true,currentFile:'pages/area-rank/area-rank.js'});require("pages/area-rank/area-rank.js");