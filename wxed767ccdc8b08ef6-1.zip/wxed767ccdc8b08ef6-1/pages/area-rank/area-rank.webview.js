$gwx_XC_1=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_1 || [];
function gz$gwx_XC_1_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_1_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_1_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_1_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container3'])
Z([3,'head-img'])
Z([3,'../../images/list_img_1.png'])
Z([3,'head-text'])
Z([3,'本地排名'])
Z([3,'bindMultiPickerChange'])
Z([3,'bindMultiPickerColumnChange'])
Z([3,'multiSelector'])
Z([[7],[3,'multiArray']])
Z([[7],[3,'multiIndex']])
Z([3,'head-hint'])
Z([a,[3,' '],[[6],[[6],[[7],[3,'multiArray']],[1,0]],[[6],[[7],[3,'multiIndex']],[1,0]]],[3,'-'],[[6],[[6],[[7],[3,'multiArray']],[1,1]],[[6],[[7],[3,'multiIndex']],[1,1]]],[3,'-'],[[6],[[6],[[7],[3,'multiArray']],[1,2]],[[6],[[7],[3,'multiIndex']],[1,2]]],[3,' ']])
Z([3,'historyRank'])
Z([3,'area'])
Z([3,'《 历史排名'])
Z([3,'loadMoreData'])
Z([3,'content'])
Z([3,'true'])
Z([[7],[3,'rankData']])
Z([3,'name'])
Z([3,'item'])
Z([3,'item2'])
Z([[2,'=='],[[7],[3,'index']],[1,0]])
Z([3,'item-no'])
Z([a,[3,'NO.'],[[2,'+'],[[7],[3,'index']],[1,1]]])
Z([[2,'=='],[[7],[3,'index']],[1,1]])
Z([3,'item-no2'])
Z([a,z[24][1],z[24][2]])
Z([[2,'=='],[[7],[3,'index']],[1,2]])
Z([3,'item-no3'])
Z([a,z[24][1],z[24][2]])
Z([3,'item-no4'])
Z([a,z[24][1],z[24][2]])
Z([3,'item-name'])
Z([a,[[6],[[7],[3,'item']],[3,'name']]])
Z([3,'item-value'])
Z([a,[[6],[[7],[3,'item']],[3,'total']]])
Z([3,'user'])
Z([3,'user-img'])
Z([3,'userAvatarUrl'])
Z([3,'user-rank'])
Z([3,'我的排名：'])
Z([3,'rank-value'])
Z([a,[[6],[[7],[3,'userRank']],[3,'rank']]])
Z([3,'user-score'])
Z([3,'我的分数：'])
Z([3,'score-value'])
Z([a,[[6],[[7],[3,'userRank']],[3,'total']]])
Z([[7],[3,'noData']])
Z([3,'default'])
Z([3,'暂无排名记录'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_1_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_1_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_1=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_1=true;
var x=['./pages/area-rank/area-rank.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_1_1()
var eFB=_n('view')
_rz(z,eFB,'class',0,e,s,gg)
var oHB=_mz(z,'image',['class',1,'src',1],[],e,s,gg)
_(eFB,oHB)
var xIB=_n('text')
_rz(z,xIB,'class',3,e,s,gg)
var oJB=_oz(z,4,e,s,gg)
_(xIB,oJB)
_(eFB,xIB)
var fKB=_mz(z,'picker',['bindchange',5,'bindcolumnchange',1,'mode',2,'range',3,'value',4],[],e,s,gg)
var cLB=_n('view')
_rz(z,cLB,'class',10,e,s,gg)
var hMB=_oz(z,11,e,s,gg)
_(cLB,hMB)
_(fKB,cLB)
_(eFB,fKB)
var oNB=_mz(z,'text',['bindtap',12,'class',1],[],e,s,gg)
var cOB=_oz(z,14,e,s,gg)
_(oNB,cOB)
_(eFB,oNB)
var oPB=_mz(z,'scroll-view',['bindscrolltolower',15,'class',1,'scrollY',2],[],e,s,gg)
var lQB=_v()
_(oPB,lQB)
var aRB=function(eTB,tSB,bUB,gg){
var xWB=_n('view')
_rz(z,xWB,'class',20,eTB,tSB,gg)
var oXB=_n('view')
_rz(z,oXB,'class',21,eTB,tSB,gg)
var fYB=_v()
_(oXB,fYB)
if(_oz(z,22,eTB,tSB,gg)){fYB.wxVkey=1
var cZB=_n('text')
_rz(z,cZB,'class',23,eTB,tSB,gg)
var h1B=_oz(z,24,eTB,tSB,gg)
_(cZB,h1B)
_(fYB,cZB)
}
else if(_oz(z,25,eTB,tSB,gg)){fYB.wxVkey=2
var o2B=_n('text')
_rz(z,o2B,'class',26,eTB,tSB,gg)
var c3B=_oz(z,27,eTB,tSB,gg)
_(o2B,c3B)
_(fYB,o2B)
}
else if(_oz(z,28,eTB,tSB,gg)){fYB.wxVkey=3
var o4B=_n('text')
_rz(z,o4B,'class',29,eTB,tSB,gg)
var l5B=_oz(z,30,eTB,tSB,gg)
_(o4B,l5B)
_(fYB,o4B)
}
else{fYB.wxVkey=4
var a6B=_n('text')
_rz(z,a6B,'class',31,eTB,tSB,gg)
var t7B=_oz(z,32,eTB,tSB,gg)
_(a6B,t7B)
_(fYB,a6B)
}
var e8B=_n('text')
_rz(z,e8B,'class',33,eTB,tSB,gg)
var b9B=_oz(z,34,eTB,tSB,gg)
_(e8B,b9B)
_(oXB,e8B)
fYB.wxXCkey=1
_(xWB,oXB)
var o0B=_n('text')
_rz(z,o0B,'class',35,eTB,tSB,gg)
var xAC=_oz(z,36,eTB,tSB,gg)
_(o0B,xAC)
_(xWB,o0B)
_(bUB,xWB)
return bUB
}
lQB.wxXCkey=2
_2z(z,18,aRB,e,s,gg,lQB,'item','index','name')
_(eFB,oPB)
var oBC=_n('view')
_rz(z,oBC,'class',37,e,s,gg)
var fCC=_mz(z,'open-data',['class',38,'type',1],[],e,s,gg)
_(oBC,fCC)
var cDC=_n('text')
_rz(z,cDC,'class',40,e,s,gg)
var hEC=_oz(z,41,e,s,gg)
_(cDC,hEC)
_(oBC,cDC)
var oFC=_n('text')
_rz(z,oFC,'class',42,e,s,gg)
var cGC=_oz(z,43,e,s,gg)
_(oFC,cGC)
_(oBC,oFC)
var oHC=_n('text')
_rz(z,oHC,'class',44,e,s,gg)
var lIC=_oz(z,45,e,s,gg)
_(oHC,lIC)
_(oBC,oHC)
var aJC=_n('text')
_rz(z,aJC,'class',46,e,s,gg)
var tKC=_oz(z,47,e,s,gg)
_(aJC,tKC)
_(oBC,aJC)
_(eFB,oBC)
var bGB=_v()
_(eFB,bGB)
if(_oz(z,48,e,s,gg)){bGB.wxVkey=1
var eLC=_n('text')
_rz(z,eLC,'class',49,e,s,gg)
var bMC=_oz(z,50,e,s,gg)
_(eLC,bMC)
_(bGB,eLC)
}
bGB.wxXCkey=1
_(r,eFB)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_1";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_1();
	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/area-rank/area-rank.wxml'] = [$gwx_XC_1, './pages/area-rank/area-rank.wxml'];else __wxAppCode__['pages/area-rank/area-rank.wxml'] = $gwx_XC_1( './pages/area-rank/area-rank.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['pages/area-rank/area-rank.wxss'] = setCssToHead([".",[1],"head-img{height:",[0,110],";margin-top:",[0,34],";width:",[0,144],"}\n.",[1],"head-text{color:#fff;font-size:",[0,30],";margin-top:",[0,21],"}\n.",[1],"head-hint{border:",[0,1]," solid #fff;border-radius:",[0,30],";color:#fff;font-size:",[0,26],";height:",[0,60],";line-height:",[0,60],";margin-top:",[0,10],";padding-left:",[0,10],";padding-right:",[0,10],"}\n.",[1],"area,.",[1],"head-hint{text-align:center}\n.",[1],"area{background-color:#fff;border-radius:",[0,0]," ",[0,35]," ",[0,35]," ",[0,0],";color:#8b1b23;height:",[0,70],";left:",[0,0],";line-height:",[0,70],";position:absolute;top:",[0,74],";width:",[0,221],"}\n.",[1],"default{color:#666;font-size:",[0,28],";margin-top:",[0,200],";z-index:2}\n.",[1],"content{background-color:#fff9f3;bottom:",[0,114],";box-shadow:inset ",[0,0]," ",[0,12]," ",[0,15]," ",[0,0]," rgba(62,62,62,.28);position:absolute;top:",[0,284],";width:92%}\n.",[1],"item{border-bottom:",[0,1]," solid #909090;-webkit-justify-content:space-between;justify-content:space-between}\n.",[1],"item,.",[1],"item2{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;-webkit-flex-direction:row;flex-direction:row;height:",[0,96],"}\n.",[1],"item2{margin-left:",[0,30],"}\n.",[1],"item-no{color:#8b1b23}\n.",[1],"item-no,.",[1],"item-no2{font-size:",[0,34],";width:",[0,200],"}\n.",[1],"item-no2{color:#cd003f}\n.",[1],"item-no3{color:#451b8b}\n.",[1],"item-no3,.",[1],"item-no4{font-size:",[0,34],";width:",[0,200],"}\n.",[1],"item-no4{color:#222}\n.",[1],"item-img{background-color:#8b1b23;border-radius:50%;height:",[0,56],";margin-left:",[0,20],";width:",[0,56],"}\n.",[1],"item-name{color:#222;font-size:",[0,28],";margin-left:",[0,25],"}\n.",[1],"item-value{color:#8b1b23;font-size:",[0,28],";margin-right:",[0,30],"}\n.",[1],"user{background:#ffd2aa;border-radius:",[0,45],";bottom:",[0,0],";height:",[0,115],";width:100%}\n.",[1],"user,.",[1],"user-img{position:absolute}\n.",[1],"user-img{background-color:#8b1b23;border-radius:50%;height:",[0,56],";left:",[0,68],";overflow:hidden;top:",[0,32],";width:",[0,56],"}\n.",[1],"user-name{font-size:",[0,32],";left:",[0,70],"}\n.",[1],"user-name,.",[1],"user-rank{color:#222;position:absolute;top:",[0,44],"}\n.",[1],"user-rank{font-size:",[0,30],";left:",[0,200],"}\n.",[1],"rank-value{color:#8b1b23;font-size:",[0,32],";left:",[0,350],";position:absolute;top:",[0,42],";width:",[0,60],"}\n.",[1],"user-score{color:#222;font-size:",[0,30],";position:absolute;right:",[0,147],";top:",[0,44],"}\n.",[1],"score-value{color:#8b1b23;font-size:",[0,32],";position:absolute;right:",[0,80],";top:",[0,42],";width:",[0,62],"}\n",],undefined,{path:"./pages/area-rank/area-rank.wxss"});
}