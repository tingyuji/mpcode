$gwx_XC_15=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_15 || [];
function gz$gwx_XC_15_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_15_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_15_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_15_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container'])
Z([3,'title'])
Z([a,[[6],[[7],[3,'titleMsg']],[3,'name']]])
Z([3,'time'])
Z([a,[[6],[[7],[3,'titleMsg']],[3,'start']],[3,'至'],[[6],[[7],[3,'titleMsg']],[3,'end']]])
Z([3,'scrollview'])
Z([3,'true'])
Z([3,'outItem'])
Z([[7],[3,'examList']])
Z([3,'*this'])
Z([3,'item'])
Z([3,'item-topic'])
Z([a,[3,'题目'],[[2,'+'],[[7],[3,'index']],[1,1]],[3,'：'],[[6],[[7],[3,'outItem']],[3,'qcontent']],[3,' ']])
Z([3,'item-content'])
Z([[6],[[7],[3,'outItem']],[3,'correctAnswers']])
Z([3,'correct-answer'])
Z([a,[3,'正确答案：'],[[7],[3,'item']]])
Z([[6],[[7],[3,'outItem']],[3,'userAnswers']])
Z([3,'mine-answer'])
Z([a,[3,'我的答案：'],z[16][2]])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_15_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_15_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_15=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_15=true;
var x=['./pages/test-paper/test-paper.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_15_1()
var bCM=_n('view')
_rz(z,bCM,'class',0,e,s,gg)
var oDM=_n('text')
_rz(z,oDM,'class',1,e,s,gg)
var xEM=_oz(z,2,e,s,gg)
_(oDM,xEM)
_(bCM,oDM)
var oFM=_n('text')
_rz(z,oFM,'class',3,e,s,gg)
var fGM=_oz(z,4,e,s,gg)
_(oFM,fGM)
_(bCM,oFM)
var cHM=_mz(z,'scroll-view',['class',5,'scrollY',1],[],e,s,gg)
var hIM=_v()
_(cHM,hIM)
var oJM=function(oLM,cKM,lMM,gg){
var tOM=_n('view')
_rz(z,tOM,'class',10,oLM,cKM,gg)
var ePM=_n('view')
_rz(z,ePM,'class',11,oLM,cKM,gg)
var bQM=_oz(z,12,oLM,cKM,gg)
_(ePM,bQM)
_(tOM,ePM)
var oRM=_n('view')
_rz(z,oRM,'class',13,oLM,cKM,gg)
var xSM=_v()
_(oRM,xSM)
var oTM=function(cVM,fUM,hWM,gg){
var cYM=_n('text')
_rz(z,cYM,'class',15,cVM,fUM,gg)
var oZM=_oz(z,16,cVM,fUM,gg)
_(cYM,oZM)
_(hWM,cYM)
return hWM
}
xSM.wxXCkey=2
_2z(z,14,oTM,oLM,cKM,gg,xSM,'item','index','')
var l1M=_v()
_(oRM,l1M)
var a2M=function(e4M,t3M,b5M,gg){
var x7M=_n('text')
_rz(z,x7M,'class',18,e4M,t3M,gg)
var o8M=_oz(z,19,e4M,t3M,gg)
_(x7M,o8M)
_(b5M,x7M)
return b5M
}
l1M.wxXCkey=2
_2z(z,17,a2M,oLM,cKM,gg,l1M,'item','index','')
_(tOM,oRM)
_(lMM,tOM)
return lMM
}
hIM.wxXCkey=2
_2z(z,8,oJM,e,s,gg,hIM,'outItem','index','*this')
_(bCM,cHM)
_(r,bCM)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_15";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_15();
	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/test-paper/test-paper.wxml'] = [$gwx_XC_15, './pages/test-paper/test-paper.wxml'];else __wxAppCode__['pages/test-paper/test-paper.wxml'] = $gwx_XC_15( './pages/test-paper/test-paper.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['pages/test-paper/test-paper.wxss'] = setCssToHead([".",[1],"title{color:#8b1b23;font-family:Source Han Sans CN;font-size:",[0,32],";font-weight:700;margin-top:",[0,40],"}\n.",[1],"time{color:#656565;font-size:",[0,28],";margin-top:",[0,22],"}\n.",[1],"scrollview{bottom:",[0,10],";position:absolute;top:",[0,160],";width:88%}\n.",[1],"item{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column;position:relative;width:100%}\n.",[1],"item-topic{color:#212121;font-size:",[0,28],"}\n.",[1],"item-content,.",[1],"item-topic{margin-top:",[0,30],";width:100%}\n.",[1],"item-content{-webkit-align-items:center;align-items:center;background:#f5f5f5;border-radius:",[0,3],";display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column}\n.",[1],"mine-answer{color:#333}\n.",[1],"correct-answer,.",[1],"mine-answer{font-size:",[0,24],";margin-top:",[0,30],";width:100%}\n.",[1],"correct-answer{color:#8b1b23}\n",],undefined,{path:"./pages/test-paper/test-paper.wxss"});
}