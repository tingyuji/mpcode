var t = require("../../config.js"), e = require("../../http.js"), a = getApp();

Page({
    data: {
        examList: []
    },
    onLoad: function(t) {
        var e = t.type;
        this.setData({
            titleMsg: a.globalData.examTitle
        }), 1 == e ? this.getReportWithExamId(t.examId) : this.getReportWithRecordId(t.examId, t.recordId);
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    getReportWithExamId: function(a) {
        var n = this;
        e.request(t.examReview, "POST", {
            examId: a
        }, function(t) {
            null != t.data && t.data.length > 0 ? n.setData({
                size: t.data.length,
                examList: t.data
            }) : wx.showToast({
                title: "没有记录",
                icon: "none"
            });
        }, function(t) {
            wx.showToast({
                title: t,
                icon: "none"
            });
        });
    },
    getReportWithRecordId: function(a, n) {
        var o = this;
        e.request(t.recordReport, "POST", {
            examId: a,
            recordId: n
        }, function(t) {
            null != t.data && t.data.length > 0 ? o.setData({
                size: t.data.length,
                examList: t.data
            }) : wx.showToast({
                title: "没有记录",
                icon: "none"
            });
        }, function(t) {
            wx.showToast({
                title: t,
                icon: "none"
            });
        });
    }
});