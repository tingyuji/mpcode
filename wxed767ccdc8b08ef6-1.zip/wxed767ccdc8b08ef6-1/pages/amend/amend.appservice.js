$gwx_XC_0=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_0 || [];
function gz$gwx_XC_0_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_0_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_0_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_0_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'contentview'])
Z([[2,'=='],[[7],[3,'formType']],[1,0]])
Z([[2,'=='],[[7],[3,'formType']],[1,1]])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_0_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_0_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_0=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_0=true;
var x=['./pages/amend/amend.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_0_1()
var oB=_n('view')
_rz(z,oB,'class',0,e,s,gg)
var xC=_v()
_(oB,xC)
if(_oz(z,1,e,s,gg)){xC.wxVkey=1
}
var oD=_v()
_(oB,oD)
if(_oz(z,2,e,s,gg)){oD.wxVkey=1
}
xC.wxXCkey=1
oD.wxXCkey=1
_(r,oB)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_0";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_0();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/amend/amend.wxml'] = [$gwx_XC_0, './pages/amend/amend.wxml'];else __wxAppCode__['pages/amend/amend.wxml'] = $gwx_XC_0( './pages/amend/amend.wxml' );
	;__wxRoute = "pages/amend/amend";__wxRouteBegin = true;__wxAppCurrentFile__="pages/amend/amend.js";define("pages/amend/amend.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var a=require("../../@babel/runtime/helpers/toArray"),t=require("../../config.js"),e=require("../../http.js"),n=getApp();Page({data:{array:[],index:0,default:" 请选择",multidefault:"请选择",formType:"",typedefault:"请选择",name:"",area:"请选择",unit:"",zhiwu:"",type:"",rawData:[],multiObjArray:[[],[],[]],multiIndex:[0,0,0],reason:"请选择",reasonArray:["缺考","不合格","其他"],reasonIndex:0},onLoad:function(a){var t=a.type;this.setData({formType:t}),this.getzzjg()},getzzjg:function(){var a=this;e.request(t.zzjg,"get",null,(function(t){if(t.rows){var e=t.rows;a.setData({array:JSON.parse(e.zhiji),rawData:JSON.parse(e.zzjg)});var n=function a(){for(var t=arguments.length>0&&void 0!==arguments[0]?arguments[0]:[],e=[],n=function(n){var i=t[n];"string"==typeof i?e.push({name:i}):Object.keys(i).forEach((function(t){var n={};n.name=t;var o=i[t];Array.isArray(o)&&o.length>0&&(n.list=a(o)),e.push(n)}))},i=0;i<t.length;i++)n(i);return e}(a.data.rawData);a.setData({rawData:n,"multiObjArray[0]":n,"multiObjArray[1]":n[0].list,"multiObjArray[2]":n[0].list[0].list})}}),(function(a){wx.showToast({title:a,icon:"none"})}),!0)},onReady:function(){},onShow:function(){var a=wx.getStorageSync("userMsg");console.log("msg===>",a),this.setData({userMsg:a,phone:a.phone,name:a.name,area:a.area,unit:a.unit,zhiwu:a.zhiwu})},onHide:function(){},onUnload:function(){},bindMultiPickerChange:function(a){var t=a.detail.value;this.setData({multiIndex:t,multidefault:this.data.multiObjArray[0][t[0]].name+" "+this.data.multiObjArray[1][t[1]].name+" "+this.data.multiObjArray[2][t[2]].name});var e=this.data.multidefault;this.setData({area:e})},bindMultiPickerColumnChange:function(t){var e=a(this.data.multiIndex).slice(0);e[t.detail.column]=t.detail.value,0===t.detail.column&&(e[1]=0,e[2]=0,e[3]=0),1===t.detail.column&&(e[2]=0,e[3]=0),2===t.detail.column&&(e[3]=0);var n=this.data.rawData[e[0]].list;this.setData({"multiObjArray[1]":n,"multiObjArray[2]":n[e[1]].list,multiIndex:e})},nameInput:function(a){var t=a.detail.value;this.setData({name:t})},unitInput:function(a){var t=a.detail.value;this.setData({unit:t})},bindPickerChange:function(a){var t=a.detail.value,e=this.data.array;this.setData({index:t,default:e[t]});var n=this.data.array[this.data.index];this.setData({zhiwu:n})},bindPickerChanges:function(a){var t=a.detail.value,e=this.data.reasonArray;this.setData({reasonIndex:t,defaults:e[t]});var n=this.data.reasonArray[this.data.reasonIndex];this.setData({reason:n})},bindTypeChange:function(a){var t=a.detail.value,e=this.data.typeArray;this.setData({typeIndex:t,typedefault:e[t]});var n=this.data.typeArray[this.data.typeIndex];this.setData({type:n})},amend:function(){var a=this;""!=a.data.name?""!=a.data.area?""!=a.data.zhiwu?e.request(t.user,"POST",{name:this.data.name,unit:this.data.unit,zhiwu:this.data.zhiwu,area:this.data.area},(function(t){if(null!=t.data)return wx.setStorageSync("userMsg",t.data),wx.showToast({title:"个人信息修改成功",icon:"none"}),void(1==a.data.formType&&a.toway())}),(function(a){wx.showToast({title:a,icon:"none"})})):wx.showToast({title:"职务不能为空",icon:"none"}):wx.showToast({title:"所在地不能为空",icon:"none"}):wx.showToast({title:"姓名不能为空",icon:"none"})},toway:function(){n.globalData.question.zero?wx.navigateTo({url:"../loading/loading?type=0&questionType=0"}):n.globalData.question.one?wx.navigateTo({url:"../loading/loading?type=0&questionType=1"}):n.globalData.question.two?wx.navigateTo({url:"../loading/loading?type=0&questionType=2"}):n.globalData.question.three?wx.navigateTo({url:"../loading/loading?type=0&questionType=3"}):n.globalData.question.four&&wx.navigateTo({url:"../loading/loading?type=0&questionType=4"})},cancle:function(){wx.navigateBack({delta:1})},logout:function(){e.request(t.logout,"POST",null,(function(a){wx.setStorageSync("haslogin",!1),wx.reLaunch({url:"../index/index"})}),(function(a){wx.showToast({title:a,icon:"none"})}))}});
},{isPage:true,isComponent:true,currentFile:'pages/amend/amend.js'});require("pages/amend/amend.js");