$gwx_XC_0=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_0 || [];
function gz$gwx_XC_0_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_0_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_0_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_0_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container3'])
Z([3,'contentview'])
Z([3,'title'])
Z([3,'您的姓名：'])
Z([3,'nameInput'])
Z([3,'value'])
Z([3,'请输入您的姓名'])
Z([[7],[3,'name']])
Z([3,'line'])
Z(z[2])
Z([3,'您的手机号：'])
Z([3,'value2'])
Z([a,[[7],[3,'phone']]])
Z(z[8])
Z(z[2])
Z([3,'所在地：'])
Z([3,'bindMultiPickerChange'])
Z([3,'bindMultiPickerColumnChange'])
Z(z[5])
Z([3,'multiSelector'])
Z([[7],[3,'multiObjArray']])
Z([1,'name'])
Z([[7],[3,'multiIndex']])
Z([3,'picker'])
Z([a,[3,' '],[[7],[3,'area']],[3,' ']])
Z(z[8])
Z(z[2])
Z([3,'您的单位：'])
Z([3,'unitInput'])
Z(z[5])
Z([3,'请输入您的单位'])
Z([[7],[3,'unit']])
Z(z[8])
Z(z[2])
Z([3,'您的职务：'])
Z([3,'bindPickerChange'])
Z(z[5])
Z([3,'请选择'])
Z([[7],[3,'array']])
Z([[7],[3,'index']])
Z(z[23])
Z([a,z[24][1],[[7],[3,'zhiwu']],z[24][1]])
Z(z[8])
Z([[2,'=='],[[7],[3,'formType']],[1,0]])
Z([3,'btnview'])
Z([3,'logout'])
Z(z[45])
Z([3,'退出'])
Z([3,'amend'])
Z(z[45])
Z([3,'修改'])
Z([[2,'=='],[[7],[3,'formType']],[1,1]])
Z(z[44])
Z([3,'cancle'])
Z(z[45])
Z([3,'取消'])
Z(z[48])
Z(z[45])
Z([3,'确定'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_0_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_0_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_0=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_0=true;
var x=['./pages/amend/amend.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_0_1()
var oB=_n('view')
_rz(z,oB,'class',0,e,s,gg)
var xC=_n('view')
_rz(z,xC,'class',1,e,s,gg)
var cF=_n('text')
_rz(z,cF,'class',2,e,s,gg)
var hG=_oz(z,3,e,s,gg)
_(cF,hG)
_(xC,cF)
var oH=_mz(z,'input',['bindinput',4,'class',1,'placeholder',2,'value',3],[],e,s,gg)
_(xC,oH)
var cI=_n('view')
_rz(z,cI,'class',8,e,s,gg)
_(xC,cI)
var oJ=_n('text')
_rz(z,oJ,'class',9,e,s,gg)
var lK=_oz(z,10,e,s,gg)
_(oJ,lK)
_(xC,oJ)
var aL=_n('text')
_rz(z,aL,'class',11,e,s,gg)
var tM=_oz(z,12,e,s,gg)
_(aL,tM)
_(xC,aL)
var eN=_n('view')
_rz(z,eN,'class',13,e,s,gg)
_(xC,eN)
var bO=_n('text')
_rz(z,bO,'class',14,e,s,gg)
var oP=_oz(z,15,e,s,gg)
_(bO,oP)
_(xC,bO)
var xQ=_mz(z,'picker',['bindchange',16,'bindcolumnchange',1,'class',2,'mode',3,'range',4,'rangeKey',5,'value',6],[],e,s,gg)
var oR=_n('view')
_rz(z,oR,'class',23,e,s,gg)
var fS=_oz(z,24,e,s,gg)
_(oR,fS)
_(xQ,oR)
_(xC,xQ)
var cT=_n('view')
_rz(z,cT,'class',25,e,s,gg)
_(xC,cT)
var hU=_n('text')
_rz(z,hU,'class',26,e,s,gg)
var oV=_oz(z,27,e,s,gg)
_(hU,oV)
_(xC,hU)
var cW=_mz(z,'input',['bindinput',28,'class',1,'placeholder',2,'value',3],[],e,s,gg)
_(xC,cW)
var oX=_n('view')
_rz(z,oX,'class',32,e,s,gg)
_(xC,oX)
var lY=_n('text')
_rz(z,lY,'class',33,e,s,gg)
var aZ=_oz(z,34,e,s,gg)
_(lY,aZ)
_(xC,lY)
var t1=_mz(z,'picker',['bindchange',35,'class',1,'placeholder',2,'range',3,'value',4],[],e,s,gg)
var e2=_n('view')
_rz(z,e2,'class',40,e,s,gg)
var b3=_oz(z,41,e,s,gg)
_(e2,b3)
_(t1,e2)
_(xC,t1)
var o4=_n('view')
_rz(z,o4,'class',42,e,s,gg)
_(xC,o4)
var oD=_v()
_(xC,oD)
if(_oz(z,43,e,s,gg)){oD.wxVkey=1
var x5=_n('view')
_rz(z,x5,'class',44,e,s,gg)
var o6=_mz(z,'text',['bindtap',45,'class',1],[],e,s,gg)
var f7=_oz(z,47,e,s,gg)
_(o6,f7)
_(x5,o6)
var c8=_mz(z,'text',['bindtap',48,'class',1],[],e,s,gg)
var h9=_oz(z,50,e,s,gg)
_(c8,h9)
_(x5,c8)
_(oD,x5)
}
var fE=_v()
_(xC,fE)
if(_oz(z,51,e,s,gg)){fE.wxVkey=1
var o0=_n('view')
_rz(z,o0,'class',52,e,s,gg)
var cAB=_mz(z,'text',['bindtap',53,'class',1],[],e,s,gg)
var oBB=_oz(z,55,e,s,gg)
_(cAB,oBB)
_(o0,cAB)
var lCB=_mz(z,'text',['bindtap',56,'class',1],[],e,s,gg)
var aDB=_oz(z,58,e,s,gg)
_(lCB,aDB)
_(o0,lCB)
_(fE,o0)
}
oD.wxXCkey=1
fE.wxXCkey=1
_(oB,xC)
_(r,oB)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_0";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_0();
	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/amend/amend.wxml'] = [$gwx_XC_0, './pages/amend/amend.wxml'];else __wxAppCode__['pages/amend/amend.wxml'] = $gwx_XC_0( './pages/amend/amend.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['pages/amend/amend.wxss'] = setCssToHead([".",[1],"title{color:#666;font-size:",[0,26],";margin-top:",[0,40],";width:90%}\n.",[1],"value{color:#222}\n.",[1],"value,.",[1],"value2{font-size:",[0,30],";margin-top:",[0,30],";width:90%}\n.",[1],"value2{color:#999}\n.",[1],"line{background:#8b1b23;height:",[0,2],";margin-top:",[0,15],";width:90%}\n.",[1],"btnview{-webkit-align-items:center;align-items:center;bottom:",[0,20],";display:-webkit-flex;display:flex;-webkit-flex-direction:row;flex-direction:row;-webkit-justify-content:space-around;justify-content:space-around;margin-top:",[0,50],";position:fixed;width:100%}\n.",[1],"amend{border:",[0,2]," solid #8b1b23;color:#8b1b23}\n.",[1],"amend,.",[1],"logout{border-radius:",[0,43],";font-size:",[0,30],";height:",[0,80],";line-height:",[0,80],";text-align:center;width:40%}\n.",[1],"logout{background:#8b1b23;border:",[0,2]," solid #8b1b23;color:#fff}\n.",[1],"remaind{border-bottom:1px solid #8b1b23;color:#8b1b23;font-size:",[0,28],";font-weight:700;margin:",[0,40]," ",[0,20]," ",[0,20],"}\n",],undefined,{path:"./pages/amend/amend.wxss"});
}