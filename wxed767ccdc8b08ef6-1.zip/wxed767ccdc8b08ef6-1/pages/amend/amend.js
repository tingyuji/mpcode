var a = require("../../@babel/runtime/helpers/toArray"), t = require("../../config.js"), e = require("../../http.js"), n = getApp();

Page({
    data: {
        array: [],
        index: 0,
        default: " 请选择",
        multidefault: "请选择",
        formType: "",
        typedefault: "请选择",
        name: "",
        area: "请选择",
        unit: "",
        zhiwu: "",
        type: "",
        rawData: [],
        multiObjArray: [ [], [], [] ],
        multiIndex: [ 0, 0, 0 ],
        reason: "请选择",
        reasonArray: [ "缺考", "不合格", "其他" ],
        reasonIndex: 0
    },
    onLoad: function(a) {
        var t = a.type;
        this.setData({
            formType: t
        }), this.getzzjg();
    },
    getzzjg: function() {
        var a = this;
        e.request(t.zzjg, "get", null, function(t) {
            if (t.rows) {
                var e = t.rows;
                a.setData({
                    array: JSON.parse(e.zhiji),
                    rawData: JSON.parse(e.zzjg)
                });
                var n = function a() {
                    for (var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [], e = [], n = function(n) {
                        var i = t[n];
                        "string" == typeof i ? e.push({
                            name: i
                        }) : Object.keys(i).forEach(function(t) {
                            var n = {};
                            n.name = t;
                            var o = i[t];
                            Array.isArray(o) && o.length > 0 && (n.list = a(o)), e.push(n);
                        });
                    }, i = 0; i < t.length; i++) n(i);
                    return e;
                }(a.data.rawData);
                a.setData({
                    rawData: n,
                    "multiObjArray[0]": n,
                    "multiObjArray[1]": n[0].list,
                    "multiObjArray[2]": n[0].list[0].list
                });
            }
        }, function(a) {
            wx.showToast({
                title: a,
                icon: "none"
            });
        }, !0);
    },
    onReady: function() {},
    onShow: function() {
        var a = wx.getStorageSync("userMsg");
        console.log("msg===>", a), this.setData({
            userMsg: a,
            phone: a.phone,
            name: a.name,
            area: a.area,
            unit: a.unit,
            zhiwu: a.zhiwu
        });
    },
    onHide: function() {},
    onUnload: function() {},
    bindMultiPickerChange: function(a) {
        var t = a.detail.value;
        this.setData({
            multiIndex: t,
            multidefault: this.data.multiObjArray[0][t[0]].name + " " + this.data.multiObjArray[1][t[1]].name + " " + this.data.multiObjArray[2][t[2]].name
        });
        var e = this.data.multidefault;
        this.setData({
            area: e
        });
    },
    bindMultiPickerColumnChange: function(t) {
        var e = a(this.data.multiIndex).slice(0);
        e[t.detail.column] = t.detail.value, 0 === t.detail.column && (e[1] = 0, e[2] = 0, 
        e[3] = 0), 1 === t.detail.column && (e[2] = 0, e[3] = 0), 2 === t.detail.column && (e[3] = 0);
        var n = this.data.rawData[e[0]].list;
        this.setData({
            "multiObjArray[1]": n,
            "multiObjArray[2]": n[e[1]].list,
            multiIndex: e
        });
    },
    nameInput: function(a) {
        var t = a.detail.value;
        this.setData({
            name: t
        });
    },
    unitInput: function(a) {
        var t = a.detail.value;
        this.setData({
            unit: t
        });
    },
    bindPickerChange: function(a) {
        var t = a.detail.value, e = this.data.array;
        this.setData({
            index: t,
            default: e[t]
        });
        var n = this.data.array[this.data.index];
        this.setData({
            zhiwu: n
        });
    },
    bindPickerChanges: function(a) {
        var t = a.detail.value, e = this.data.reasonArray;
        this.setData({
            reasonIndex: t,
            defaults: e[t]
        });
        var n = this.data.reasonArray[this.data.reasonIndex];
        this.setData({
            reason: n
        });
    },
    bindTypeChange: function(a) {
        var t = a.detail.value, e = this.data.typeArray;
        this.setData({
            typeIndex: t,
            typedefault: e[t]
        });
        var n = this.data.typeArray[this.data.typeIndex];
        this.setData({
            type: n
        });
    },
    amend: function() {
        var a = this;
        "" != a.data.name ? "" != a.data.area ? "" != a.data.zhiwu ? e.request(t.user, "POST", {
            name: this.data.name,
            unit: this.data.unit,
            zhiwu: this.data.zhiwu,
            area: this.data.area
        }, function(t) {
            if (null != t.data) return wx.setStorageSync("userMsg", t.data), wx.showToast({
                title: "个人信息修改成功",
                icon: "none"
            }), void (1 == a.data.formType && a.toway());
        }, function(a) {
            wx.showToast({
                title: a,
                icon: "none"
            });
        }) : wx.showToast({
            title: "职务不能为空",
            icon: "none"
        }) : wx.showToast({
            title: "所在地不能为空",
            icon: "none"
        }) : wx.showToast({
            title: "姓名不能为空",
            icon: "none"
        });
    },
    toway: function() {
        n.globalData.question.zero ? wx.navigateTo({
            url: "../loading/loading?type=0&questionType=0"
        }) : n.globalData.question.one ? wx.navigateTo({
            url: "../loading/loading?type=0&questionType=1"
        }) : n.globalData.question.two ? wx.navigateTo({
            url: "../loading/loading?type=0&questionType=2"
        }) : n.globalData.question.three ? wx.navigateTo({
            url: "../loading/loading?type=0&questionType=3"
        }) : n.globalData.question.four && wx.navigateTo({
            url: "../loading/loading?type=0&questionType=4"
        });
    },
    cancle: function() {
        wx.navigateBack({
            delta: 1
        });
    },
    logout: function() {
        e.request(t.logout, "POST", null, function(a) {
            wx.setStorageSync("haslogin", !1), wx.reLaunch({
                url: "../index/index"
            });
        }, function(a) {
            wx.showToast({
                title: a,
                icon: "none"
            });
        });
    }
});