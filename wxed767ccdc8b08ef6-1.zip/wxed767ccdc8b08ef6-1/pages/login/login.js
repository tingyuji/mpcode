var e = getApp();

Page({
    data: {
        userInfo: {},
        hasUserInfo: !1,
        canIUseGetUserProfile: !1
    },
    getUserProfile: function(n) {
        var o = this;
        wx.getSetting({
            success: function(n) {
                wx.getUserProfile({
                    desc: "用于完善资料",
                    success: function(n) {
                        n.userInfo ? (o.setData({
                            userInfo: n.userInfo,
                            hasUserInfo: !0
                        }), wx.setStorageSync("userInfo", n.userInfo), e.globalData.userInfo = n.userInfo, 
                        wx.navigateTo({
                            url: "../login-default/login-default"
                        })) : wx.navigateBack({
                            delta: 1
                        });
                    }
                });
            }
        });
    },
    getUserInfo: function(n) {
        console.log("getUserInfo", n), n.detail.userInfo ? (wx.setStorageSync("userInfo", n.detail.userInfo), 
        e.globalData.userInfo = n.detail.userInfo, wx.navigateTo({
            url: "../login-default/login-default"
        })) : wx.navigateBack({
            delta: 1
        });
    },
    noAllow: function() {
        wx.navigateBack({
            delta: 1
        });
    },
    onLoad: function(e) {
        wx.getUserProfile && this.setData({
            canIUseGetUserProfile: !0
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {}
});