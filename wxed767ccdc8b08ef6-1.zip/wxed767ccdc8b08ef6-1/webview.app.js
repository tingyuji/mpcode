var __globalThis=(typeof __vd_version_info__!=='undefined'&&typeof __vd_version_info__.globalThis!=='undefined')?__vd_version_info__.globalThis:window;var __mainPageFrameReady__=__globalThis.__mainPageFrameReady__||function(){};var __pageFrameStartTime__=Date.now();var __webviewId__;var __wxAppCode__=__wxAppCode__||{};var __WXML_GLOBAL__=__WXML_GLOBAL__||{entrys:{},defines:{},modules:{},ops:[],wxs_nf_init:undefined,total_ops:0};var __GWX_GLOBAL__=__GWX_GLOBAL__||{};	(function(){
	 /*v0.6vv_20180522_fbi*/window.__wcc_version__='v0.6vv_20180522_fbi';window.__wcc_version_info__={"customComponents":true,"fixZeroRpx":true,"propValueDeepCopy":false};
var $gwxc
var $gaic={}
$gwx_wxa75efa648b60994b=function(path,global){
if(typeof global === 'undefined') global={};
if(typeof __WXML_GLOBAL__ === 'undefined') __WXML_GLOBAL__={};
function _(a,b){if(typeof(b)!='undefined')a.children.push(b);}
function _v(k){if(typeof(k)!='undefined')return {tag:'virtual','wxKey':k,children:[]};return {tag:'virtual',children:[]};}
function _n(tag){$gwxc++;if($gwxc>=16000){throw 'Dom limit exceeded, please check if there\'s any mistake you\'ve made.'};return {tag:'wx-'+tag,attr:{},children:[],n:[],raw:{},generics:{}}}
function _p(a,b){b&&a.properities.push(b);}
function _s(scope,env,key){return typeof(scope[key])!='undefined'?scope[key]:env[key]}
function _wp(m){console.warn("WXMLRT_$gwx_wxa75efa648b60994b:"+m)}
function _wl(tname,prefix){_wp(prefix+':-1:-1:-1: Template `' + tname + '` is being called recursively, will be stop.')}
$gwn=console.warn;
$gwl=console.log;
function $gwh()
{
function x()
{
}
x.prototype = 
{
hn: function( obj, all )
{
if( typeof(obj) == 'object' )
{
var cnt=0;
var any1=false,any2=false;
for(var x in obj)
{
any1=any1|x==='__value__';
any2=any2|x==='__wxspec__';
cnt++;
if(cnt>2)break;
}
return cnt == 2 && any1 && any2 && ( all || obj.__wxspec__ !== 'm' || this.hn(obj.__value__) === 'h' ) ? "h" : "n";
}
return "n";
},
nh: function( obj, special )
{
return { __value__: obj, __wxspec__: special ? special : true }
},
rv: function( obj )
{
return this.hn(obj,true)==='n'?obj:this.rv(obj.__value__);
},
hm: function( obj )
{
if( typeof(obj) == 'object' )
{
var cnt=0;
var any1=false,any2=false;
for(var x in obj)
{
any1=any1|x==='__value__';
any2=any2|x==='__wxspec__';
cnt++;
if(cnt>2)break;
}
return cnt == 2 && any1 && any2 && (obj.__wxspec__ === 'm' || this.hm(obj.__value__) );
}
return false;
}
}
return new x;
}
wh=$gwh();
function $gstack(s){
var tmp=s.split('\n '+' '+' '+' ');
for(var i=0;i<tmp.length;++i){
if(0==i) continue;
if(")"===tmp[i][tmp[i].length-1])
tmp[i]=tmp[i].replace(/\s\(.*\)$/,"");
else
tmp[i]="at anonymous function";
}
return tmp.join('\n '+' '+' '+' ');
}
function $gwrt( should_pass_type_info )
{
function ArithmeticEv( ops, e, s, g, o )
{
var _f = false;
var rop = ops[0][1];
var _a,_b,_c,_d, _aa, _bb;
switch( rop )
{
case '?:':
_a = rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && ( wh.hn(_a) === 'h' );
_d = wh.rv( _a ) ? rev( ops[2], e, s, g, o, _f ) : rev( ops[3], e, s, g, o, _f );
_d = _c && wh.hn( _d ) === 'n' ? wh.nh( _d, 'c' ) : _d;
return _d;
break;
case '&&':
_a = rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && ( wh.hn(_a) === 'h' );
_d = wh.rv( _a ) ? rev( ops[2], e, s, g, o, _f ) : wh.rv( _a );
_d = _c && wh.hn( _d ) === 'n' ? wh.nh( _d, 'c' ) : _d;
return _d;
break;
case '||':
_a = rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && ( wh.hn(_a) === 'h' );
_d = wh.rv( _a ) ? wh.rv(_a) : rev( ops[2], e, s, g, o, _f );
_d = _c && wh.hn( _d ) === 'n' ? wh.nh( _d, 'c' ) : _d;
return _d;
break;
case '+':
case '*':
case '/':
case '%':
case '|':
case '^':
case '&':
case '===':
case '==':
case '!=':
case '!==':
case '>=':
case '<=':
case '>':
case '<':
case '<<':
case '>>':
_a = rev( ops[1], e, s, g, o, _f );
_b = rev( ops[2], e, s, g, o, _f );
_c = should_pass_type_info && (wh.hn( _a ) === 'h' || wh.hn( _b ) === 'h');
switch( rop )
{
case '+':
_d = wh.rv( _a ) + wh.rv( _b );
break;
case '*':
_d = wh.rv( _a ) * wh.rv( _b );
break;
case '/':
_d = wh.rv( _a ) / wh.rv( _b );
break;
case '%':
_d = wh.rv( _a ) % wh.rv( _b );
break;
case '|':
_d = wh.rv( _a ) | wh.rv( _b );
break;
case '^':
_d = wh.rv( _a ) ^ wh.rv( _b );
break;
case '&':
_d = wh.rv( _a ) & wh.rv( _b );
break;
case '===':
_d = wh.rv( _a ) === wh.rv( _b );
break;
case '==':
_d = wh.rv( _a ) == wh.rv( _b );
break;
case '!=':
_d = wh.rv( _a ) != wh.rv( _b );
break;
case '!==':
_d = wh.rv( _a ) !== wh.rv( _b );
break;
case '>=':
_d = wh.rv( _a ) >= wh.rv( _b );
break;
case '<=':
_d = wh.rv( _a ) <= wh.rv( _b );
break;
case '>':
_d = wh.rv( _a ) > wh.rv( _b );
break;
case '<':
_d = wh.rv( _a ) < wh.rv( _b );
break;
case '<<':
_d = wh.rv( _a ) << wh.rv( _b );
break;
case '>>':
_d = wh.rv( _a ) >> wh.rv( _b );
break;
default:
break;
}
return _c ? wh.nh( _d, "c" ) : _d;
break;
case '-':
_a = ops.length === 3 ? rev( ops[1], e, s, g, o, _f ) : 0;
_b = ops.length === 3 ? rev( ops[2], e, s, g, o, _f ) : rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && (wh.hn( _a ) === 'h' || wh.hn( _b ) === 'h');
_d = _c ? wh.rv( _a ) - wh.rv( _b ) : _a - _b;
return _c ? wh.nh( _d, "c" ) : _d;
break;
case '!':
_a = rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && (wh.hn( _a ) == 'h');
_d = !wh.rv(_a);
return _c ? wh.nh( _d, "c" ) : _d;
case '~':
_a = rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && (wh.hn( _a ) == 'h');
_d = ~wh.rv(_a);
return _c ? wh.nh( _d, "c" ) : _d;
default:
$gwn('unrecognized op' + rop );
}
}
function rev( ops, e, s, g, o, newap )
{
var op = ops[0];
var _f = false;
if ( typeof newap !== "undefined" ) o.ap = newap;
if( typeof(op)==='object' )
{
var vop=op[0];
var _a, _aa, _b, _bb, _c, _d, _s, _e, _ta, _tb, _td;
switch(vop)
{
case 2:
return ArithmeticEv(ops,e,s,g,o);
break;
case 4: 
return rev( ops[1], e, s, g, o, _f );
break;
case 5: 
switch( ops.length )
{
case 2: 
_a = rev( ops[1],e,s,g,o,_f );
return should_pass_type_info?[_a]:[wh.rv(_a)];
return [_a];
break;
case 1: 
return [];
break;
default:
_a = rev( ops[1],e,s,g,o,_f );
_b = rev( ops[2],e,s,g,o,_f );
_a.push( 
should_pass_type_info ?
_b :
wh.rv( _b )
);
return _a;
break;
}
break;
case 6:
_a = rev(ops[1],e,s,g,o);
var ap = o.ap;
_ta = wh.hn(_a)==='h';
_aa = _ta ? wh.rv(_a) : _a;
o.is_affected |= _ta;
if( should_pass_type_info )
{
if( _aa===null || typeof(_aa) === 'undefined' )
{
return _ta ? wh.nh(undefined, 'e') : undefined;
}
_b = rev(ops[2],e,s,g,o,_f);
_tb = wh.hn(_b) === 'h';
_bb = _tb ? wh.rv(_b) : _b;
o.ap = ap;
o.is_affected |= _tb;
if( _bb===null || typeof(_bb) === 'undefined' || 
_bb === "__proto__" || _bb === "prototype" || _bb === "caller" ) 
{
return (_ta || _tb) ? wh.nh(undefined, 'e') : undefined;
}
_d = _aa[_bb];
if ( typeof _d === 'function' && !ap ) _d = undefined;
_td = wh.hn(_d)==='h';
o.is_affected |= _td;
return (_ta || _tb) ? (_td ? _d : wh.nh(_d, 'e')) : _d;
}
else
{
if( _aa===null || typeof(_aa) === 'undefined' )
{
return undefined;
}
_b = rev(ops[2],e,s,g,o,_f);
_tb = wh.hn(_b) === 'h';
_bb = _tb ? wh.rv(_b) : _b;
o.ap = ap;
o.is_affected |= _tb;
if( _bb===null || typeof(_bb) === 'undefined' || 
_bb === "__proto__" || _bb === "prototype" || _bb === "caller" ) 
{
return undefined;
}
_d = _aa[_bb];
if ( typeof _d === 'function' && !ap ) _d = undefined;
_td = wh.hn(_d)==='h';
o.is_affected |= _td;
return _td ? wh.rv(_d) : _d;
}
case 7: 
switch(ops[1][0])
{
case 11:
o.is_affected |= wh.hn(g)==='h';
return g;
case 3:
_s = wh.rv( s );
_e = wh.rv( e );
_b = ops[1][1];
if (g && g.f && g.f.hasOwnProperty(_b) )
{
_a = g.f;
o.ap = true;
}
else
{
_a = _s && _s.hasOwnProperty(_b) ? 
s : (_e && _e.hasOwnProperty(_b) ? e : undefined );
}
if( should_pass_type_info )
{
if( _a )
{
_ta = wh.hn(_a) === 'h';
_aa = _ta ? wh.rv( _a ) : _a;
_d = _aa[_b];
_td = wh.hn(_d) === 'h';
o.is_affected |= _ta || _td;
_d = _ta && !_td ? wh.nh(_d,'e') : _d;
return _d;
}
}
else
{
if( _a )
{
_ta = wh.hn(_a) === 'h';
_aa = _ta ? wh.rv( _a ) : _a;
_d = _aa[_b];
_td = wh.hn(_d) === 'h';
o.is_affected |= _ta || _td;
return wh.rv(_d);
}
}
return undefined;
}
break;
case 8: 
_a = {};
_a[ops[1]] = rev(ops[2],e,s,g,o,_f);
return _a;
break;
case 9: 
_a = rev(ops[1],e,s,g,o,_f);
_b = rev(ops[2],e,s,g,o,_f);
function merge( _a, _b, _ow )
{
var ka, _bbk;
_ta = wh.hn(_a)==='h';
_tb = wh.hn(_b)==='h';
_aa = wh.rv(_a);
_bb = wh.rv(_b);
for(var k in _bb)
{
if ( _ow || !_aa.hasOwnProperty(k) )
{
_aa[k] = should_pass_type_info ? (_tb ? wh.nh(_bb[k],'e') : _bb[k]) : wh.rv(_bb[k]);
}
}
return _a;
}
var _c = _a
var _ow = true
if ( typeof(ops[1][0]) === "object" && ops[1][0][0] === 10 ) {
_a = _b
_b = _c
_ow = false
}
if ( typeof(ops[1][0]) === "object" && ops[1][0][0] === 10 ) {
var _r = {}
return merge( merge( _r, _a, _ow ), _b, _ow );
}
else
return merge( _a, _b, _ow );
break;
case 10:
_a = rev(ops[1],e,s,g,o,_f);
_a = should_pass_type_info ? _a : wh.rv( _a );
return _a ;
break;
case 12:
var _r;
_a = rev(ops[1],e,s,g,o);
if ( !o.ap )
{
return should_pass_type_info && wh.hn(_a)==='h' ? wh.nh( _r, 'f' ) : _r;
}
var ap = o.ap;
_b = rev(ops[2],e,s,g,o,_f);
o.ap = ap;
_ta = wh.hn(_a)==='h';
_tb = _ca(_b);
_aa = wh.rv(_a);	
_bb = wh.rv(_b); snap_bb=$gdc(_bb,"nv_");
try{
_r = typeof _aa === "function" ? $gdc(_aa.apply(null, snap_bb)) : undefined;
} catch (e){
e.message = e.message.replace(/nv_/g,"");
e.stack = e.stack.substring(0,e.stack.indexOf("\n", e.stack.lastIndexOf("at nv_")));
e.stack = e.stack.replace(/\snv_/g," "); 
e.stack = $gstack(e.stack);	
if("undefined"!==typeof debugInfo)
e.stack += "\n "+" "+" "+" at "+debugInfo[g.opindex][0]+":"+debugInfo[g.opindex][1]+":"+debugInfo[g.opindex][2];
throw e;
}
return should_pass_type_info && (_tb || _ta) ? wh.nh( _r, 'f' ) : _r;
}
}
else
{
if( op === 3 || op === 1) return ops[1];
else if( op === 11 ) 
{
var _a='';
for( var i = 1 ; i < ops.length ; i++ )
{
var xp = wh.rv(rev(ops[i],e,s,g,o,_f));
_a += typeof(xp) === 'undefined' ? '' : xp;
}
return _a;
}
}
}
return rev;
}
gra=$gwrt(true); 
grb=$gwrt(false); 
function TestTest( expr, ops, e,s,g, expect_a, expect_b, expect_affected )
{
{
var o = {is_affected:false};
var a = gra( ops, e,s,g, o );
if( JSON.stringify(a) != JSON.stringify( expect_a )
|| o.is_affected != expect_affected )
{
console.warn( "A. " + expr + " get result " + JSON.stringify(a) + ", " + o.is_affected + ", but " + JSON.stringify( expect_a ) + ", " + expect_affected + " is expected" );
}
}
{
var o = {is_affected:false};
var a = grb( ops, e,s,g, o );
if( JSON.stringify(a) != JSON.stringify( expect_b )
|| o.is_affected != expect_affected )
{
console.warn( "B. " + expr + " get result " + JSON.stringify(a) + ", " + o.is_affected + ", but " + JSON.stringify( expect_b ) + ", " + expect_affected + " is expected" );
}
}
}

function wfor( to_iter, func, env, _s, global, father, itemname, indexname, keyname )
{
var _n = wh.hn( to_iter ) === 'n'; 
var scope = wh.rv( _s ); 
var has_old_item = scope.hasOwnProperty(itemname);
var has_old_index = scope.hasOwnProperty(indexname);
var old_item = scope[itemname];
var old_index = scope[indexname];
var full = Object.prototype.toString.call(wh.rv(to_iter));
var type = full[8]; 
if( type === 'N' && full[10] === 'l' ) type = 'X'; 
var _y;
if( _n )
{
if( type === 'A' ) 
{
var r_iter_item;
for( var i = 0 ; i < to_iter.length ; i++ )
{
scope[itemname] = to_iter[i];
scope[indexname] = _n ? i : wh.nh(i, 'h');
r_iter_item = wh.rv(to_iter[i]);
var key = keyname && r_iter_item ? (keyname==="*this" ? r_iter_item : wh.rv(r_iter_item[keyname])) : undefined;
_y = _v(key);
_(father,_y);
func( env, scope, _y, global );
}
}
else if( type === 'O' ) 
{
var i = 0;
var r_iter_item;
for( var k in to_iter )
{
scope[itemname] = to_iter[k];
scope[indexname] = _n ? k : wh.nh(k, 'h');
r_iter_item = wh.rv(to_iter[k]);
var key = keyname && r_iter_item ? (keyname==="*this" ? r_iter_item : wh.rv(r_iter_item[keyname])) : undefined;
_y = _v(key);
_(father,_y);
func( env,scope,_y,global );
i++;
}
}
else if( type === 'S' ) 
{
for( var i = 0 ; i < to_iter.length ; i++ )
{
scope[itemname] = to_iter[i];
scope[indexname] = _n ? i : wh.nh(i, 'h');
_y = _v( to_iter[i] + i );
_(father,_y);
func( env,scope,_y,global );
}
}
else if( type === 'N' ) 
{
for( var i = 0 ; i < to_iter ; i++ )
{
scope[itemname] = i;
scope[indexname] = _n ? i : wh.nh(i, 'h');
_y = _v( i );
_(father,_y);
func(env,scope,_y,global);
}
}
else
{
}
}
else
{
var r_to_iter = wh.rv(to_iter);
var r_iter_item, iter_item;
if( type === 'A' ) 
{
for( var i = 0 ; i < r_to_iter.length ; i++ )
{
iter_item = r_to_iter[i];
iter_item = wh.hn(iter_item)==='n' ? wh.nh(iter_item,'h') : iter_item;
r_iter_item = wh.rv( iter_item );
scope[itemname] = iter_item
scope[indexname] = _n ? i : wh.nh(i, 'h');
var key = keyname && r_iter_item ? (keyname==="*this" ? r_iter_item : wh.rv(r_iter_item[keyname])) : undefined;
_y = _v(key);
_(father,_y);
func( env, scope, _y, global );
}
}
else if( type === 'O' ) 
{
var i=0;
for( var k in r_to_iter )
{
iter_item = r_to_iter[k];
iter_item = wh.hn(iter_item)==='n'? wh.nh(iter_item,'h') : iter_item;
r_iter_item = wh.rv( iter_item );
scope[itemname] = iter_item;
scope[indexname] = _n ? k : wh.nh(k, 'h');
var key = keyname && r_iter_item ? (keyname==="*this" ? r_iter_item : wh.rv(r_iter_item[keyname])) : undefined;
_y=_v(key);
_(father,_y);
func( env, scope, _y, global );
i++
}
}
else if( type === 'S' ) 
{
for( var i = 0 ; i < r_to_iter.length ; i++ )
{
iter_item = wh.nh(r_to_iter[i],'h');
scope[itemname] = iter_item;
scope[indexname] = _n ? i : wh.nh(i, 'h');
_y = _v( to_iter[i] + i );
_(father,_y);
func( env, scope, _y, global );
}
}
else if( type === 'N' ) 
{
for( var i = 0 ; i < r_to_iter ; i++ )
{
iter_item = wh.nh(i,'h');
scope[itemname] = iter_item;
scope[indexname]= _n ? i : wh.nh(i,'h');
_y = _v( i );
_(father,_y);
func(env,scope,_y,global);
}
}
else
{
}
}
if(has_old_item)
{
scope[itemname]=old_item;
}
else
{
delete scope[itemname];
}
if(has_old_index)
{
scope[indexname]=old_index;
}
else
{
delete scope[indexname];
}
}

function _ca(o)
{ 
if ( wh.hn(o) == 'h' ) return true;
if ( typeof o !== "object" ) return false;
for(var i in o){ 
if ( o.hasOwnProperty(i) ){
if (_ca(o[i])) return true;
}
}
return false;
}
function _da( node, attrname, opindex, raw, o )
{
var isaffected = false;
if ( o.is_affected || _ca(raw) ) 
{
node.n.push( attrname );
node.raw[attrname] = raw;
var value = $gdc( raw, "", 2 );
return value;
}
else
{
var value = $gdc( raw, "", 2 );
return value;
}
}
function _r( node, attrname, opindex, env, scope, global ) 
{
global.opindex=opindex;
var o = {}, _env;
var a = grb( z[opindex], env, scope, global, o );
a = _da( node, attrname, opindex, a, o );
node.attr[attrname] = a;
}
function _o( opindex, env, scope, global )
{
global.opindex=opindex;
var nothing = {};
var r = grb( z[opindex], env, scope, global, nothing );
return (r&&r.constructor===Function) ? undefined : r;
}
function _1( opindex, env, scope, global, o )
{
var o = o || {};
global.opindex=opindex;
return gra( z[opindex], env, scope, global, o );
}
function _2( opindex, func, env, scope, global, father, itemname, indexname, keyname )
{
var o = {};
var to_iter = _1( opindex, env, scope, global );
wfor( to_iter, func, env, scope, global, father, itemname, indexname, keyname );
}


function _m(tag,attrs,generics,env,scope,global)
{
var tmp=_n(tag);
var base=0;
for(var i = 0 ; i < attrs.length ; i+=2 )
{
if(base+attrs[i+1]<0)
{
tmp.attr[attrs[i]]=true;
}
else
{
_r(tmp,attrs[i],base+attrs[i+1],env,scope,global);
if(base===0)base=attrs[i+1];
}
}
for(var i=0;i<generics.length;i+=2)
{
if(base+generics[i+1]<0)
{
tmp.generics[generics[i]]="";
}
else
{
var $t=grb(z[base+generics[i+1]],env,scope,global);
if ($t!="") $t="wx-"+$t;
tmp.generics[generics[i]]=$t;
if(base===0)base=generics[i+1];
}
}
return tmp;
}

var nf_init=function(){
if(typeof __WXML_GLOBAL__==="undefined"||undefined===__WXML_GLOBAL__.wxs_nf_init){
nf_init_Object();nf_init_Function();nf_init_Array();nf_init_String();nf_init_Boolean();nf_init_Number();nf_init_Math();nf_init_Date();nf_init_RegExp();
}
if(typeof __WXML_GLOBAL__!=="undefined") __WXML_GLOBAL__.wxs_nf_init=true;
};
var nf_init_Object=function(){
Object.defineProperty(Object.prototype,"nv_constructor",{writable:true,value:"Object"})
Object.defineProperty(Object.prototype,"nv_toString",{writable:true,value:function(){return "[object Object]"}})
}
var nf_init_Function=function(){
Object.defineProperty(Function.prototype,"nv_constructor",{writable:true,value:"Function"})
Object.defineProperty(Function.prototype,"nv_length",{get:function(){return this.length;},set:function(){}});
Object.defineProperty(Function.prototype,"nv_toString",{writable:true,value:function(){return "[function Function]"}})
}
var nf_init_Array=function(){
Object.defineProperty(Array.prototype,"nv_toString",{writable:true,value:function(){return this.nv_join();}})
Object.defineProperty(Array.prototype,"nv_join",{writable:true,value:function(s){
s=undefined==s?',':s;
var r="";
for(var i=0;i<this.length;++i){
if(0!=i) r+=s;
if(null==this[i]||undefined==this[i]) r+='';	
else if(typeof this[i]=='function') r+=this[i].nv_toString();
else if(typeof this[i]=='object'&&this[i].nv_constructor==="Array") r+=this[i].nv_join();
else r+=this[i].toString();
}
return r;
}})
Object.defineProperty(Array.prototype,"nv_constructor",{writable:true,value:"Array"})
Object.defineProperty(Array.prototype,"nv_concat",{writable:true,value:Array.prototype.concat})
Object.defineProperty(Array.prototype,"nv_pop",{writable:true,value:Array.prototype.pop})
Object.defineProperty(Array.prototype,"nv_push",{writable:true,value:Array.prototype.push})
Object.defineProperty(Array.prototype,"nv_reverse",{writable:true,value:Array.prototype.reverse})
Object.defineProperty(Array.prototype,"nv_shift",{writable:true,value:Array.prototype.shift})
Object.defineProperty(Array.prototype,"nv_slice",{writable:true,value:Array.prototype.slice})
Object.defineProperty(Array.prototype,"nv_sort",{writable:true,value:Array.prototype.sort})
Object.defineProperty(Array.prototype,"nv_splice",{writable:true,value:Array.prototype.splice})
Object.defineProperty(Array.prototype,"nv_unshift",{writable:true,value:Array.prototype.unshift})
Object.defineProperty(Array.prototype,"nv_indexOf",{writable:true,value:Array.prototype.indexOf})
Object.defineProperty(Array.prototype,"nv_lastIndexOf",{writable:true,value:Array.prototype.lastIndexOf})
Object.defineProperty(Array.prototype,"nv_every",{writable:true,value:Array.prototype.every})
Object.defineProperty(Array.prototype,"nv_some",{writable:true,value:Array.prototype.some})
Object.defineProperty(Array.prototype,"nv_forEach",{writable:true,value:Array.prototype.forEach})
Object.defineProperty(Array.prototype,"nv_map",{writable:true,value:Array.prototype.map})
Object.defineProperty(Array.prototype,"nv_filter",{writable:true,value:Array.prototype.filter})
Object.defineProperty(Array.prototype,"nv_reduce",{writable:true,value:Array.prototype.reduce})
Object.defineProperty(Array.prototype,"nv_reduceRight",{writable:true,value:Array.prototype.reduceRight})
Object.defineProperty(Array.prototype,"nv_length",{get:function(){return this.length;},set:function(value){this.length=value;}});
}
var nf_init_String=function(){
Object.defineProperty(String.prototype,"nv_constructor",{writable:true,value:"String"})
Object.defineProperty(String.prototype,"nv_toString",{writable:true,value:String.prototype.toString})
Object.defineProperty(String.prototype,"nv_valueOf",{writable:true,value:String.prototype.valueOf})
Object.defineProperty(String.prototype,"nv_charAt",{writable:true,value:String.prototype.charAt})
Object.defineProperty(String.prototype,"nv_charCodeAt",{writable:true,value:String.prototype.charCodeAt})
Object.defineProperty(String.prototype,"nv_concat",{writable:true,value:String.prototype.concat})
Object.defineProperty(String.prototype,"nv_indexOf",{writable:true,value:String.prototype.indexOf})
Object.defineProperty(String.prototype,"nv_lastIndexOf",{writable:true,value:String.prototype.lastIndexOf})
Object.defineProperty(String.prototype,"nv_localeCompare",{writable:true,value:String.prototype.localeCompare})
Object.defineProperty(String.prototype,"nv_match",{writable:true,value:String.prototype.match})
Object.defineProperty(String.prototype,"nv_replace",{writable:true,value:String.prototype.replace})
Object.defineProperty(String.prototype,"nv_search",{writable:true,value:String.prototype.search})
Object.defineProperty(String.prototype,"nv_slice",{writable:true,value:String.prototype.slice})
Object.defineProperty(String.prototype,"nv_split",{writable:true,value:String.prototype.split})
Object.defineProperty(String.prototype,"nv_substring",{writable:true,value:String.prototype.substring})
Object.defineProperty(String.prototype,"nv_toLowerCase",{writable:true,value:String.prototype.toLowerCase})
Object.defineProperty(String.prototype,"nv_toLocaleLowerCase",{writable:true,value:String.prototype.toLocaleLowerCase})
Object.defineProperty(String.prototype,"nv_toUpperCase",{writable:true,value:String.prototype.toUpperCase})
Object.defineProperty(String.prototype,"nv_toLocaleUpperCase",{writable:true,value:String.prototype.toLocaleUpperCase})
Object.defineProperty(String.prototype,"nv_trim",{writable:true,value:String.prototype.trim})
Object.defineProperty(String.prototype,"nv_length",{get:function(){return this.length;},set:function(value){this.length=value;}});
}
var nf_init_Boolean=function(){
Object.defineProperty(Boolean.prototype,"nv_constructor",{writable:true,value:"Boolean"})
Object.defineProperty(Boolean.prototype,"nv_toString",{writable:true,value:Boolean.prototype.toString})
Object.defineProperty(Boolean.prototype,"nv_valueOf",{writable:true,value:Boolean.prototype.valueOf})
}
var nf_init_Number=function(){
Object.defineProperty(Number,"nv_MAX_VALUE",{writable:false,value:Number.MAX_VALUE})
Object.defineProperty(Number,"nv_MIN_VALUE",{writable:false,value:Number.MIN_VALUE})
Object.defineProperty(Number,"nv_NEGATIVE_INFINITY",{writable:false,value:Number.NEGATIVE_INFINITY})
Object.defineProperty(Number,"nv_POSITIVE_INFINITY",{writable:false,value:Number.POSITIVE_INFINITY})
Object.defineProperty(Number.prototype,"nv_constructor",{writable:true,value:"Number"})
Object.defineProperty(Number.prototype,"nv_toString",{writable:true,value:Number.prototype.toString})
Object.defineProperty(Number.prototype,"nv_toLocaleString",{writable:true,value:Number.prototype.toLocaleString})
Object.defineProperty(Number.prototype,"nv_valueOf",{writable:true,value:Number.prototype.valueOf})
Object.defineProperty(Number.prototype,"nv_toFixed",{writable:true,value:Number.prototype.toFixed})
Object.defineProperty(Number.prototype,"nv_toExponential",{writable:true,value:Number.prototype.toExponential})
Object.defineProperty(Number.prototype,"nv_toPrecision",{writable:true,value:Number.prototype.toPrecision})
}
var nf_init_Math=function(){
Object.defineProperty(Math,"nv_E",{writable:false,value:Math.E})
Object.defineProperty(Math,"nv_LN10",{writable:false,value:Math.LN10})
Object.defineProperty(Math,"nv_LN2",{writable:false,value:Math.LN2})
Object.defineProperty(Math,"nv_LOG2E",{writable:false,value:Math.LOG2E})
Object.defineProperty(Math,"nv_LOG10E",{writable:false,value:Math.LOG10E})
Object.defineProperty(Math,"nv_PI",{writable:false,value:Math.PI})
Object.defineProperty(Math,"nv_SQRT1_2",{writable:false,value:Math.SQRT1_2})
Object.defineProperty(Math,"nv_SQRT2",{writable:false,value:Math.SQRT2})
Object.defineProperty(Math,"nv_abs",{writable:false,value:Math.abs})
Object.defineProperty(Math,"nv_acos",{writable:false,value:Math.acos})
Object.defineProperty(Math,"nv_asin",{writable:false,value:Math.asin})
Object.defineProperty(Math,"nv_atan",{writable:false,value:Math.atan})
Object.defineProperty(Math,"nv_atan2",{writable:false,value:Math.atan2})
Object.defineProperty(Math,"nv_ceil",{writable:false,value:Math.ceil})
Object.defineProperty(Math,"nv_cos",{writable:false,value:Math.cos})
Object.defineProperty(Math,"nv_exp",{writable:false,value:Math.exp})
Object.defineProperty(Math,"nv_floor",{writable:false,value:Math.floor})
Object.defineProperty(Math,"nv_log",{writable:false,value:Math.log})
Object.defineProperty(Math,"nv_max",{writable:false,value:Math.max})
Object.defineProperty(Math,"nv_min",{writable:false,value:Math.min})
Object.defineProperty(Math,"nv_pow",{writable:false,value:Math.pow})
Object.defineProperty(Math,"nv_random",{writable:false,value:Math.random})
Object.defineProperty(Math,"nv_round",{writable:false,value:Math.round})
Object.defineProperty(Math,"nv_sin",{writable:false,value:Math.sin})
Object.defineProperty(Math,"nv_sqrt",{writable:false,value:Math.sqrt})
Object.defineProperty(Math,"nv_tan",{writable:false,value:Math.tan})
}
var nf_init_Date=function(){
Object.defineProperty(Date.prototype,"nv_constructor",{writable:true,value:"Date"})
Object.defineProperty(Date,"nv_parse",{writable:true,value:Date.parse})
Object.defineProperty(Date,"nv_UTC",{writable:true,value:Date.UTC})
Object.defineProperty(Date,"nv_now",{writable:true,value:Date.now})
Object.defineProperty(Date.prototype,"nv_toString",{writable:true,value:Date.prototype.toString})
Object.defineProperty(Date.prototype,"nv_toDateString",{writable:true,value:Date.prototype.toDateString})
Object.defineProperty(Date.prototype,"nv_toTimeString",{writable:true,value:Date.prototype.toTimeString})
Object.defineProperty(Date.prototype,"nv_toLocaleString",{writable:true,value:Date.prototype.toLocaleString})
Object.defineProperty(Date.prototype,"nv_toLocaleDateString",{writable:true,value:Date.prototype.toLocaleDateString})
Object.defineProperty(Date.prototype,"nv_toLocaleTimeString",{writable:true,value:Date.prototype.toLocaleTimeString})
Object.defineProperty(Date.prototype,"nv_valueOf",{writable:true,value:Date.prototype.valueOf})
Object.defineProperty(Date.prototype,"nv_getTime",{writable:true,value:Date.prototype.getTime})
Object.defineProperty(Date.prototype,"nv_getFullYear",{writable:true,value:Date.prototype.getFullYear})
Object.defineProperty(Date.prototype,"nv_getUTCFullYear",{writable:true,value:Date.prototype.getUTCFullYear})
Object.defineProperty(Date.prototype,"nv_getMonth",{writable:true,value:Date.prototype.getMonth})
Object.defineProperty(Date.prototype,"nv_getUTCMonth",{writable:true,value:Date.prototype.getUTCMonth})
Object.defineProperty(Date.prototype,"nv_getDate",{writable:true,value:Date.prototype.getDate})
Object.defineProperty(Date.prototype,"nv_getUTCDate",{writable:true,value:Date.prototype.getUTCDate})
Object.defineProperty(Date.prototype,"nv_getDay",{writable:true,value:Date.prototype.getDay})
Object.defineProperty(Date.prototype,"nv_getUTCDay",{writable:true,value:Date.prototype.getUTCDay})
Object.defineProperty(Date.prototype,"nv_getHours",{writable:true,value:Date.prototype.getHours})
Object.defineProperty(Date.prototype,"nv_getUTCHours",{writable:true,value:Date.prototype.getUTCHours})
Object.defineProperty(Date.prototype,"nv_getMinutes",{writable:true,value:Date.prototype.getMinutes})
Object.defineProperty(Date.prototype,"nv_getUTCMinutes",{writable:true,value:Date.prototype.getUTCMinutes})
Object.defineProperty(Date.prototype,"nv_getSeconds",{writable:true,value:Date.prototype.getSeconds})
Object.defineProperty(Date.prototype,"nv_getUTCSeconds",{writable:true,value:Date.prototype.getUTCSeconds})
Object.defineProperty(Date.prototype,"nv_getMilliseconds",{writable:true,value:Date.prototype.getMilliseconds})
Object.defineProperty(Date.prototype,"nv_getUTCMilliseconds",{writable:true,value:Date.prototype.getUTCMilliseconds})
Object.defineProperty(Date.prototype,"nv_getTimezoneOffset",{writable:true,value:Date.prototype.getTimezoneOffset})
Object.defineProperty(Date.prototype,"nv_setTime",{writable:true,value:Date.prototype.setTime})
Object.defineProperty(Date.prototype,"nv_setMilliseconds",{writable:true,value:Date.prototype.setMilliseconds})
Object.defineProperty(Date.prototype,"nv_setUTCMilliseconds",{writable:true,value:Date.prototype.setUTCMilliseconds})
Object.defineProperty(Date.prototype,"nv_setSeconds",{writable:true,value:Date.prototype.setSeconds})
Object.defineProperty(Date.prototype,"nv_setUTCSeconds",{writable:true,value:Date.prototype.setUTCSeconds})
Object.defineProperty(Date.prototype,"nv_setMinutes",{writable:true,value:Date.prototype.setMinutes})
Object.defineProperty(Date.prototype,"nv_setUTCMinutes",{writable:true,value:Date.prototype.setUTCMinutes})
Object.defineProperty(Date.prototype,"nv_setHours",{writable:true,value:Date.prototype.setHours})
Object.defineProperty(Date.prototype,"nv_setUTCHours",{writable:true,value:Date.prototype.setUTCHours})
Object.defineProperty(Date.prototype,"nv_setDate",{writable:true,value:Date.prototype.setDate})
Object.defineProperty(Date.prototype,"nv_setUTCDate",{writable:true,value:Date.prototype.setUTCDate})
Object.defineProperty(Date.prototype,"nv_setMonth",{writable:true,value:Date.prototype.setMonth})
Object.defineProperty(Date.prototype,"nv_setUTCMonth",{writable:true,value:Date.prototype.setUTCMonth})
Object.defineProperty(Date.prototype,"nv_setFullYear",{writable:true,value:Date.prototype.setFullYear})
Object.defineProperty(Date.prototype,"nv_setUTCFullYear",{writable:true,value:Date.prototype.setUTCFullYear})
Object.defineProperty(Date.prototype,"nv_toUTCString",{writable:true,value:Date.prototype.toUTCString})
Object.defineProperty(Date.prototype,"nv_toISOString",{writable:true,value:Date.prototype.toISOString})
Object.defineProperty(Date.prototype,"nv_toJSON",{writable:true,value:Date.prototype.toJSON})
}
var nf_init_RegExp=function(){
Object.defineProperty(RegExp.prototype,"nv_constructor",{writable:true,value:"RegExp"})
Object.defineProperty(RegExp.prototype,"nv_exec",{writable:true,value:RegExp.prototype.exec})
Object.defineProperty(RegExp.prototype,"nv_test",{writable:true,value:RegExp.prototype.test})
Object.defineProperty(RegExp.prototype,"nv_toString",{writable:true,value:RegExp.prototype.toString})
Object.defineProperty(RegExp.prototype,"nv_source",{get:function(){return this.source;},set:function(){}});
Object.defineProperty(RegExp.prototype,"nv_global",{get:function(){return this.global;},set:function(){}});
Object.defineProperty(RegExp.prototype,"nv_ignoreCase",{get:function(){return this.ignoreCase;},set:function(){}});
Object.defineProperty(RegExp.prototype,"nv_multiline",{get:function(){return this.multiline;},set:function(){}});
Object.defineProperty(RegExp.prototype,"nv_lastIndex",{get:function(){return this.lastIndex;},set:function(v){this.lastIndex=v;}});
}
nf_init();
var nv_getDate=function(){var args=Array.prototype.slice.call(arguments);args.unshift(Date);return new(Function.prototype.bind.apply(Date, args));}
var nv_getRegExp=function(){var args=Array.prototype.slice.call(arguments);args.unshift(RegExp);return new(Function.prototype.bind.apply(RegExp, args));}
var nv_console={}
nv_console.nv_log=function(){var res="WXSRT:";for(var i=0;i<arguments.length;++i)res+=arguments[i]+" ";console.log(res);}
var nv_parseInt = parseInt, nv_parseFloat = parseFloat, nv_isNaN = isNaN, nv_isFinite = isFinite, nv_decodeURI = decodeURI, nv_decodeURIComponent = decodeURIComponent, nv_encodeURI = encodeURI, nv_encodeURIComponent = encodeURIComponent;
function $gdc(o,p,r) {
o=wh.rv(o);
if(o===null||o===undefined) return o;
if(o.constructor===String||o.constructor===Boolean||o.constructor===Number) return o;
if(o.constructor===Object){
var copy={};
for(var k in o)
if(o.hasOwnProperty(k))
if(undefined===p) copy[k.substring(3)]=$gdc(o[k],p,r);
else copy[p+k]=$gdc(o[k],p,r);
return copy;
}
if(o.constructor===Array){
var copy=[];
for(var i=0;i<o.length;i++) copy.push($gdc(o[i],p,r));
return copy;
}
if(o.constructor===Date){
var copy=new Date();
copy.setTime(o.getTime());
return copy;
}
if(o.constructor===RegExp){
var f="";
if(o.global) f+="g";
if(o.ignoreCase) f+="i";
if(o.multiline) f+="m";
return (new RegExp(o.source,f));
}
if(r&&o.constructor===Function){
if ( r == 1 ) return $gdc(o(),undefined, 2);
if ( r == 2 ) return o;
}
return null;
}
var nv_JSON={}
nv_JSON.nv_stringify=function(o){
JSON.stringify(o);
return JSON.stringify($gdc(o));
}
nv_JSON.nv_parse=function(o){
if(o===undefined) return undefined;
var t=JSON.parse(o);
return $gdc(t,'nv_');
}

function _af(p, a, c){
p.extraAttr = {"t_action": a, "t_cid": c};
}

function _gv( )
{if( typeof( window.__webview_engine_version__) == 'undefined' ) return 0.0;
return window.__webview_engine_version__;}
function _ai(i,p,e,me,r,c){var x=_grp(p,e,me);if(x)i.push(x);else{i.push('');_wp(me+':import:'+r+':'+c+': Path `'+p+'` not found from `'+me+'`.')}}
function _grp(p,e,me){if(p[0]!='/'){var mepart=me.split('/');mepart.pop();var ppart=p.split('/');for(var i=0;i<ppart.length;i++){if( ppart[i]=='..')mepart.pop();else if(!ppart[i]||ppart[i]=='.')continue;else mepart.push(ppart[i]);}p=mepart.join('/');}if(me[0]=='.'&&p[0]=='/')p='.'+p;if(e[p])return p;if(e[p+'.wxml'])return p+'.wxml';}
function _gd(p,c,e,d){if(!c)return;if(d[p][c])return d[p][c];for(var x=e[p].i.length-1;x>=0;x--){if(e[p].i[x]&&d[e[p].i[x]][c])return d[e[p].i[x]][c]};for(var x=e[p].ti.length-1;x>=0;x--){var q=_grp(e[p].ti[x],e,p);if(q&&d[q][c])return d[q][c]}var ii=_gapi(e,p);for(var x=0;x<ii.length;x++){if(ii[x]&&d[ii[x]][c])return d[ii[x]][c]}for(var k=e[p].j.length-1;k>=0;k--)if(e[p].j[k]){for(var q=e[e[p].j[k]].ti.length-1;q>=0;q--){var pp=_grp(e[e[p].j[k]].ti[q],e,p);if(pp&&d[pp][c]){return d[pp][c]}}}}
function _gapi(e,p){if(!p)return [];if($gaic[p]){return $gaic[p]};var ret=[],q=[],h=0,t=0,put={},visited={};q.push(p);visited[p]=true;t++;while(h<t){var a=q[h++];for(var i=0;i<e[a].ic.length;i++){var nd=e[a].ic[i];var np=_grp(nd,e,a);if(np&&!visited[np]){visited[np]=true;q.push(np);t++;}}for(var i=0;a!=p&&i<e[a].ti.length;i++){var ni=e[a].ti[i];var nm=_grp(ni,e,a);if(nm&&!put[nm]){put[nm]=true;ret.push(nm);}}}$gaic[p]=ret;return ret;}
var $ixc={};function _ic(p,ent,me,e,s,r,gg){var x=_grp(p,ent,me);ent[me].j.push(x);if(x){if($ixc[x]){_wp('-1:include:-1:-1: `'+p+'` is being included in a loop, will be stop.');return;}$ixc[x]=true;try{ent[x].f(e,s,r,gg)}catch(e){}$ixc[x]=false;}else{_wp(me+':include:-1:-1: Included path `'+p+'` not found from `'+me+'`.')}}
function _w(tn,f,line,c){_wp(f+':template:'+line+':'+c+': Template `'+tn+'` not found.');}function _ev(dom){var changed=false;delete dom.properities;delete dom.n;if(dom.children){do{changed=false;var newch = [];for(var i=0;i<dom.children.length;i++){var ch=dom.children[i];if( ch.tag=='virtual'){changed=true;for(var j=0;ch.children&&j<ch.children.length;j++){newch.push(ch.children[j]);}}else { newch.push(ch); } } dom.children = newch; }while(changed);for(var i=0;i<dom.children.length;i++){_ev(dom.children[i]);}} return dom; }
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules;
var p_={}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_wxa75efa648b60994b || [];
if ( !__WXML_GLOBAL__.ops_init.$gwx_wxa75efa648b60994b){
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'mod_player']);Z([[7],[3,'autoplay']]);Z([3,'__onTvpEnded']);Z([3,'__onTvpError']);Z([3,'__onTvpPause']);Z([3,'__onTvpPlay']);Z([3,'__onTvpTimeupdate']);Z([3,'player_video']);Z([[2,'!'],[[7],[3,'tvpIsAd']]]);Z([1,false]);Z([1,true]);Z([[2,'=='],[[7],[3,'tvpState']],[1,'error']]);Z([3,'tvp']);Z([[7],[3,'tvpUrl']]);Z(z[0]);Z(z[1]);Z(z[2]);Z(z[3]);Z(z[4]);Z(z[5]);Z(z[6]);Z(z[7]);Z(z[9]);Z([[2,'?:'],[[7],[3,'tvpIsAd']],[1,false],[[7],[3,'enableProgressGesture']]]);Z(z[10]);Z(z[11]);Z(z[12]);Z([[2,'?:'],[[7],[3,'tvpIsAd']],[1,0],[[7],[3,'initialTime']]]);Z([[7],[3,'loop']]);Z([[7],[3,'muted']]);Z([[7],[3,'objectFit']]);Z([[7],[3,'pageGesture']]);Z([[7],[3,'poster']]);Z([[7],[3,'showCenterPlayBtn']]);Z([[7],[3,'showFullscreenBtn']]);Z([[7],[3,'showPlayBtn']]);Z(z[8]);Z(z[13]);Z([[2,'&&'],[[7],[3,'tvpIsAd']],[[7],[3,'progressSkipTime']]]);Z([3,'mod_skipad']);Z([[2,'!'],[[2,'&&'],[[2,'!='],[[7],[3,'progressSkipTime']],[[2,'-'],[1,1]]],[[2,'<='],[[7],[3,'progressSkipTime']],[[2,'+'],[[7],[3,'progressTime']],[[7],[3,'progressBaseTime']]]]]]);Z([3,'progress']);Z([a,[[2,'-'],[[2,'-'],[[7],[3,'progressSkipTime']],[[7],[3,'progressBaseTime']]],[[7],[3,'progressTime']]]]);Z(z[40]);Z([3,'skipbtn disabled']);Z([3,' 秒后可跳过']);Z([[2,'&&'],[[2,'!='],[[7],[3,'progressSkipTime']],[[2,'-'],[1,1]]],[[2,'<='],[[7],[3,'progressSkipTime']],[[2,'+'],[[7],[3,'progressTime']],[[7],[3,'progressBaseTime']]]]]);Z([3,'skipAd']);Z([3,'skipbtn']);Z([3,'跳过广告']);Z([[7],[3,'reportUrl']]);Z(z[0]);Z(z[1]);Z(z[2]);Z(z[3]);Z(z[4]);Z(z[5]);Z(z[6]);Z(z[7]);Z([[2,'!'],[[2,'&&'],[[7],[3,'autoplay']],[[7],[3,'tvpIsAd']]]]);Z(z[9]);Z(z[23]);Z(z[10]);Z(z[11]);Z(z[12]);Z(z[27]);Z(z[28]);Z(z[29]);Z(z[30]);Z(z[31]);Z(z[32]);Z(z[33]);Z(z[34]);Z(z[35]);Z([[2,'!'],[[2,'&&'],[[2,'!'],[[7],[3,'autoplay']]],[[7],[3,'tvpIsAd']]]]);Z(z[13]);Z(z[38]);Z(z[39]);Z(z[40]);Z(z[41]);Z([a,z[42][1]]);Z(z[40]);Z(z[44]);Z([3,'秒后可跳过']);Z(z[46]);Z(z[47]);Z(z[48]);Z(z[49]);Z(z[50]);})(z);__WXML_GLOBAL__.ops_set.$gwx_wxa75efa648b60994b=z;
__WXML_GLOBAL__.ops_init.$gwx_wxa75efa648b60994b=true;
}
var nv_require=function(){var nnm={};var nom={};return function(n){return function(){if(!nnm[n]) return undefined;try{if(!nom[n])nom[n]=nnm[n]();return nom[n];}catch(e){e.message=e.message.replace(/nv_/g,'');var tmp = e.stack.substring(0,e.stack.lastIndexOf(n));e.stack = tmp.substring(0,tmp.lastIndexOf('\n'));e.stack = e.stack.replace(/\snv_/g,' ');e.stack = $gstack(e.stack);e.stack += '\n    at ' + n.substring(2);throw e;}
}}}()
var x=['./component/live/live.wxml','./component/noad-video/noad-video.wxml','./component/video/video.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var oB=_n('view')
_r(oB,'class',0,e,s,gg)
var xC=_m('video',['autoplay',1,'bindended',1,'binderror',2,'bindpause',3,'bindplay',4,'bindtimeupdate',5,'class',6,'controls',7,'danmuBtn',8,'enableDanmu',9,'hidden',10,'id',11,'src',12],[],e,s,gg)
_(oB,xC)
_(r,oB)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
d_[x[1]]={}
var m1=function(e,s,r,gg){
var fE=_n('view')
_r(fE,'class',14,e,s,gg)
var cF=_m('video',['autoplay',15,'bindended',1,'binderror',2,'bindpause',3,'bindplay',4,'bindtimeupdate',5,'class',6,'danmuBtn',7,'enableProgressGesture',8,'enableDanmu',9,'hidden',10,'id',11,'initialTime',12,'loop',13,'muted',14,'objectFit',15,'pageGesture',16,'poster',17,'showCenterPlayBtn',18,'showFullscreenBtn',19,'showPlayBtn',20,'showProgress',21,'src',22],[],e,s,gg)
var hG=_v()
_(cF,hG)
if(_o(38,e,s,gg)){hG.wxVkey=1
var oH=_n('cover-view')
_r(oH,'class',39,e,s,gg)
var cI=_v()
_(oH,cI)
if(_o(40,e,s,gg)){cI.wxVkey=1
var aL=_n('cover-view')
_r(aL,'class',41,e,s,gg)
var tM=_o(42,e,s,gg)
_(aL,tM)
_(cI,aL)
}
var oJ=_v()
_(oH,oJ)
if(_o(43,e,s,gg)){oJ.wxVkey=1
var eN=_n('cover-view')
_r(eN,'class',44,e,s,gg)
var bO=_o(45,e,s,gg)
_(eN,bO)
_(oJ,eN)
}
var lK=_v()
_(oH,lK)
if(_o(46,e,s,gg)){lK.wxVkey=1
var oP=_m('cover-view',['bindtap',47,'class',1],[],e,s,gg)
var xQ=_o(49,e,s,gg)
_(oP,xQ)
_(lK,oP)
}
cI.wxXCkey=1
oJ.wxXCkey=1
lK.wxXCkey=1
_(hG,oH)
}
hG.wxXCkey=1
_(fE,cF)
var oR=_m('image',['hidden',-1,'src',50],[],e,s,gg)
_(fE,oR)
_(r,fE)
return r
}
e_[x[1]]={f:m1,j:[],i:[],ti:[],ic:[]}
d_[x[2]]={}
var m2=function(e,s,r,gg){
var cT=_n('view')
_r(cT,'class',51,e,s,gg)
var hU=_m('video',['autoplay',52,'bindended',1,'binderror',2,'bindpause',3,'bindplay',4,'bindtimeupdate',5,'class',6,'controls',7,'danmuBtn',8,'enableProgressGesture',9,'enableDanmu',10,'hidden',11,'id',12,'initialTime',13,'loop',14,'muted',15,'objectFit',16,'pageGesture',17,'poster',18,'showCenterPlayBtn',19,'showFullscreenBtn',20,'showPlayBtn',21,'showProgress',22,'src',23],[],e,s,gg)
var oV=_v()
_(hU,oV)
if(_o(76,e,s,gg)){oV.wxVkey=1
var cW=_n('cover-view')
_r(cW,'class',77,e,s,gg)
var oX=_v()
_(cW,oX)
if(_o(78,e,s,gg)){oX.wxVkey=1
var t1=_n('cover-view')
_r(t1,'class',79,e,s,gg)
var e2=_o(80,e,s,gg)
_(t1,e2)
_(oX,t1)
}
var lY=_v()
_(cW,lY)
if(_o(81,e,s,gg)){lY.wxVkey=1
var b3=_n('cover-view')
_r(b3,'class',82,e,s,gg)
var o4=_o(83,e,s,gg)
_(b3,o4)
_(lY,b3)
}
var aZ=_v()
_(cW,aZ)
if(_o(84,e,s,gg)){aZ.wxVkey=1
var x5=_m('cover-view',['bindtap',85,'class',1],[],e,s,gg)
var o6=_o(87,e,s,gg)
_(x5,o6)
_(aZ,x5)
}
oX.wxXCkey=1
lY.wxXCkey=1
aZ.wxXCkey=1
_(oV,cW)
}
oV.wxXCkey=1
_(cT,hU)
var f7=_m('image',['hidden',-1,'src',88],[],e,s,gg)
_(cT,f7)
_(r,cT)
return r
}
e_[x[2]]={f:m2,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
window.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(window.__webview_engine_version__)!='undefined'&&window.__webview_engine_version__+1e-6>=0.02+1e-6&&window.__mergeData__)
{
env=window.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
if(typeof(window.__webview_engine_version__)=='undefined'|| window.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
return root;
}
}
}

	 var BASE_DEVICE_WIDTH = 750;
var isIOS=navigator.userAgent.match("iPhone");
var deviceWidth = window.screen.width || 375;
var deviceDPR = window.devicePixelRatio || 2;
function checkDeviceWidth() {
var newDeviceWidth = window.screen.width || 375
var newDeviceDPR = window.devicePixelRatio || 2
const newDeviceHeight = window.screen.height || 375
if (window.screen.orientation && /^landscape/.test(window.screen.orientation.type || '')) newDeviceWidth = newDeviceHeight
if (newDeviceWidth !== deviceWidth || newDeviceDPR !== deviceDPR) {
deviceWidth = newDeviceWidth
deviceDPR = newDeviceDPR
}
}
checkDeviceWidth()
var eps = 1e-4;
function transformRPX(number, newDeviceWidth) {
if ( number === 0 ) return 0;
number = number / BASE_DEVICE_WIDTH * ( newDeviceWidth || deviceWidth );
number = Math.floor(number + eps);
if (number === 0) {
if (deviceDPR === 1 || !isIOS) {
return 1;
} else {
return 0.5;
}
}
return number;
}
var setCssToHead = function(file, _xcInvalid, info) {
var Ca = {};
var css_id;
var info = info || {};
var _C= [];
function makeup(file, opt) {
var _n = typeof(file) === "number";
if ( _n && Ca.hasOwnProperty(file)) return "";
if ( _n ) Ca[file] = 1;
var ex = _n ? _C[file] : file;
var res="";
for (var i = ex.length - 1; i >= 0; i--) {
var content = ex[i];
if (typeof(content) === "object")
{
var op = content[0];
if ( op == 0 )
res = transformRPX(content[1], opt.deviceWidth) + "px" + res;
else if ( op == 1)
res = opt.suffix + res;
else if ( op == 2 ) 
res = makeup(content[1], opt) + res;
}
else
res = content + res
}
return res;
}
var rewritor = function(suffix, opt, style){
opt = opt || {};
suffix = suffix || "";
opt.suffix = suffix;
if ( opt.allowIllegalSelector != undefined && _xcInvalid != undefined )
{
if ( opt.allowIllegalSelector )
console.warn( "For developer:" + _xcInvalid );
else
{
console.error( _xcInvalid + "This wxss file is ignored." );
return;
}
}
Ca={};
css = makeup(file, opt);
if ( !style ) 
{
var head = document.head || document.getElementsByTagName('head')[0];
window.__rpxRecalculatingFuncs__ = window.__rpxRecalculatingFuncs__ || [];
style = document.createElement('style');
style.type = 'text/css';
style.setAttribute( "wxss:path", info.path );
head.appendChild(style);
window.__rpxRecalculatingFuncs__.push(function(size){
opt.deviceWidth = size.width;
rewritor(suffix, opt, style);
});
}
if (style.styleSheet) {
style.styleSheet.cssText = css;
} else {
if ( style.childNodes.length == 0 )
style.appendChild(document.createTextNode(css));
else 
style.childNodes[0].nodeValue = css;
}
}
return rewritor;
}
setCssToHead([])();setCssToHead([])();
	 		__wxAppCode__['plugin-private://wxa75efa648b60994b/component/live/live.wxss'] = setCssToHead([".",[1],"mod_player{ position: relative; z-index: 11; left: 0; top: 0; width: 100%; }\n.",[1],"mod_player:before{ content: \x27\x27; display: block; width: 100%; padding-bottom: 56.25%; }\n.",[1],"mod_player .",[1],"player_video{ position: absolute; top: 0; left: 0; width: 100%; height: 100%; }\n",],undefined,{path:"./component/live/live.wxss"})
		__wxAppCode__['plugin-private://wxa75efa648b60994b/component/live/live.wxml'] = $gwx_wxa75efa648b60994b( './component/live/live.wxml' )
			__wxAppCode__['plugin-private://wxa75efa648b60994b/component/noad-video/noad-video.wxss'] = setCssToHead([".",[1],"mod_player{ position: relative; z-index: 11; left: 0; top: 0; width: 100%; }\n.",[1],"mod_player:before{ content: \x27\x27; display: block; width: 100%; padding-bottom: 56.25%; }\n.",[1],"mod_player .",[1],"player_video{ position: absolute; top: 0; left: 0; width: 100%; height: 100%; }\n.",[1],"mod_player .",[1],"player_video .",[1],"mod_skipad { background: rgba(0, 0, 0, 0.6); position: absolute; top: ",[0,15],"; right: ",[0,15],"; color: white; font-size: 12px; padding: 7px 12px; border-radius: 80px; overflow: hidden; white-space: nowrap; }\n.",[1],"mod_player .",[1],"player_video .",[1],"mod_skipad wx-cover-view { display: inline; }\n.",[1],"mod_player .",[1],"player_video .",[1],"mod_skipad .",[1],"progress { color: #ff7000; }\n.",[1],"mod_player .",[1],"player_video .",[1],"mod_skipad .",[1],"skipbtn { color: #ff7000; }\n.",[1],"mod_player .",[1],"player_video .",[1],"mod_skipad .",[1],"skipbtn.",[1],"disabled { color: white; }\n",],undefined,{path:"./component/noad-video/noad-video.wxss"})
		__wxAppCode__['plugin-private://wxa75efa648b60994b/component/noad-video/noad-video.wxml'] = $gwx_wxa75efa648b60994b( './component/noad-video/noad-video.wxml' )
			__wxAppCode__['plugin-private://wxa75efa648b60994b/component/video/video.wxss'] = setCssToHead([".",[1],"mod_player{ position: relative; z-index: 11; left: 0; top: 0; width: 100%; }\n.",[1],"mod_player:before{ content: \x27\x27; display: block; width: 100%; padding-bottom: 56.25%; }\n.",[1],"mod_player .",[1],"player_video{ position: absolute; top: 0; left: 0; width: 100%; height: 100%; }\n.",[1],"mod_player .",[1],"player_video .",[1],"mod_skipad { background: rgba(0, 0, 0, 0.6); position: absolute; top: ",[0,15],"; right: ",[0,15],"; height: ",[0,28],"; color: white; font-size: 12px; padding: 7px 12px; border-radius: 80px; overflow: hidden; white-space: nowrap; }\n.",[1],"mod_player .",[1],"player_video .",[1],"mod_skipad wx-cover-view { display: inline; }\n.",[1],"mod_player .",[1],"player_video .",[1],"mod_skipad .",[1],"progress { color: #ff7000; margin-right: 3px; }\n.",[1],"mod_player .",[1],"player_video .",[1],"mod_skipad .",[1],"skipbtn { color: #ff7000; }\n.",[1],"mod_player .",[1],"player_video .",[1],"mod_skipad .",[1],"skipbtn.",[1],"disabled { color: white; }\n",],undefined,{path:"./component/video/video.wxss"})
		__wxAppCode__['plugin-private://wxa75efa648b60994b/component/video/video.wxml'] = $gwx_wxa75efa648b60994b( './component/video/video.wxml' )
	
	 })();;/*v0.5vv_20200413_syb_scopedata*/__globalThis.__wcc_version__='v0.5vv_20200413_syb_scopedata';__globalThis.__wcc_version_info__={"customComponents":true,"fixZeroRpx":true,"propValueDeepCopy":false};
var $gwxc
var $gaic={}
var outerGlobal=typeof __globalThis==='undefined'?window:__globalThis;$gwx=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx || [];
__WXML_GLOBAL__.ops_set.$gwx=z;
__WXML_GLOBAL__.ops_init.$gwx=true;
var nv_require=function(){var nnm={};var nom={};return function(n){if(n[0]==='p'&&n[1]==='_'&&f_[n.slice(2)])return f_[n.slice(2)];return function(){if(!nnm[n]) return undefined;try{if(!nom[n])nom[n]=nnm[n]();return nom[n];}catch(e){e.message=e.message.replace(/nv_/g,'');var tmp = e.stack.substring(0,e.stack.lastIndexOf(n));e.stack = tmp.substring(0,tmp.lastIndexOf('\n'));e.stack = e.stack.replace(/\snv_/g,' ');e.stack = $gstack(e.stack);e.stack += '\n    at ' + n.substring(2);console.error(e);}
}}}()
var x=[];if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||true)$gwx();;;var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){var BASE_DEVICE_WIDTH = 750;
var isIOS=navigator.userAgent.match("iPhone");
var deviceWidth = window.screen.width || 375;
var deviceDPR = window.devicePixelRatio || 2;
var checkDeviceWidth = window.__checkDeviceWidth__ || function() {
var newDeviceWidth = window.screen.width || 375
var newDeviceDPR = window.devicePixelRatio || 2
var newDeviceHeight = window.screen.height || 375
if (window.screen.orientation && /^landscape/.test(window.screen.orientation.type || '')) newDeviceWidth = newDeviceHeight
if (newDeviceWidth !== deviceWidth || newDeviceDPR !== deviceDPR) {
deviceWidth = newDeviceWidth
deviceDPR = newDeviceDPR
}
}
checkDeviceWidth()
var eps = 1e-4;
var transformRPX = window.__transformRpx__ || function(number, newDeviceWidth) {
if ( number === 0 ) return 0;
number = number / BASE_DEVICE_WIDTH * ( newDeviceWidth || deviceWidth );
number = Math.floor(number + eps);
if (number === 0) {
if (deviceDPR === 1 || !isIOS) {
return 1;
} else {
return 0.5;
}
}
return number;
}
window.__rpxRecalculatingFuncs__ = window.__rpxRecalculatingFuncs__ || [];
var __COMMON_STYLESHEETS__ = __COMMON_STYLESHEETS__||{}

var setCssToHead = function(file, _xcInvalid, info) {
var Ca = {};
var css_id;
var info = info || {};
var _C = __COMMON_STYLESHEETS__
function makeup(file, opt) {
var _n = typeof(file) === "string";
if ( _n && Ca.hasOwnProperty(file)) return "";
if ( _n ) Ca[file] = 1;
var ex = _n ? _C[file] : file;
var res="";
for (var i = ex.length - 1; i >= 0; i--) {
var content = ex[i];
if (typeof(content) === "object")
{
var op = content[0];
if ( op == 0 )
res = transformRPX(content[1], opt.deviceWidth) + "px" + res;
else if ( op == 1)
res = opt.suffix + res;
else if ( op == 2 )
res = makeup(content[1], opt) + res;
}
else
res = content + res
}
return res;
}
var styleSheetManager = window.__styleSheetManager2__
var rewritor = function(suffix, opt, style){
opt = opt || {};
suffix = suffix || "";
opt.suffix = suffix;
if ( opt.allowIllegalSelector != undefined && _xcInvalid != undefined )
{
if ( opt.allowIllegalSelector )
console.warn( "For developer:" + _xcInvalid );
else
{
console.error( _xcInvalid );
}
}
Ca={};
css = makeup(file, opt);
if (styleSheetManager) {
var key = (info.path || Math.random()) + ':' + suffix
if (!style) {
styleSheetManager.addItem(key, info.path);
window.__rpxRecalculatingFuncs__.push(function(size){
opt.deviceWidth = size.width;
rewritor(suffix, opt, true);
});
}
styleSheetManager.setCss(key, css);
return;
}
if ( !style )
{
var head = document.head || document.getElementsByTagName('head')[0];
style = document.createElement('style');
style.type = 'text/css';
style.setAttribute( "wxss:path", info.path );
head.appendChild(style);
window.__rpxRecalculatingFuncs__.push(function(size){
opt.deviceWidth = size.width;
rewritor(suffix, opt, style);
});
}
if (style.styleSheet) {
style.styleSheet.cssText = css;
} else {
if ( style.childNodes.length == 0 )
style.appendChild(document.createTextNode(css));
else
style.childNodes[0].nodeValue = css;
}
}
return rewritor;
}
setCssToHead([])();setCssToHead([".",[1],"clearfix:after{clear:both;content:\x22.\x22;display:block;height:0;visibility:hidden}\n.",[1],"noData{color:#fff;font-family:PingFangSC-Regular,PingFang SC;font-size:",[0,34],";font-weight:400;padding:",[0,30],";text-align:center}\n.",[1],"container{height:100%;-webkit-justify-content:space-between;justify-content:space-between}\n.",[1],"container,.",[1],"container2{-webkit-align-items:center;align-items:center;box-sizing:border-box;display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column;width:100%}\n.",[1],"container2{height:100vh;-webkit-justify-content:center;justify-content:center;padding:",[0,10]," ",[0,30],"}\n.",[1],"container3{background-color:#8b1b23}\n.",[1],"container3,.",[1],"container4{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column;height:100vh;width:100%}\n.",[1],"container4{background-image:url(\x22data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAu4AAATnCAYAAAC1wvc4AAAgAElEQVR4Xuy9ibbjuI4tKMs+Q0Tkzdf3vh/sVcOndFfVT1a+b+i6mXHiDHYvgAQFURzAQbJsw6tf1804nARS1ObmBnD44z/+5XI4PQ3+7zIMw8H+o/+/qSz9fV73MAwX+P/Ow3CBmvpTC9y3BQ7jcRjGcRgO4Tfiuk9/wPf4Ai+l+5l/MX/B1xV/5l/n/5ePHctdzsPl85PVuu7TPXrvh+PJrD03m9N88n2azyvNNZ/7yY5mNcDamK+ZXpa+DMP5PFy+vno1qO10sMAB1hCuo06/zT/95R1ezopROs22NrOtBf44EHDn4Lx8DGHAcrnAixH+PJT3oTXUAvu1wASgthojB+QEwQm0TeBr/vbN/53+xgE7/zdedypzQdB1OSvw2mqmU/3AukPQhUB7OnQROPePa/6c++Xmh7fl4W55tIsBJmrJGz2QOQDcdf3sYfmYMRwOZg01EQ+x+b7WY2aA/PkyID7Rn1rg9iwwAffU2EOgnrN09u0PN6Hs++0tCx1xuQUO43A4His/fpGPnvmqsv+/GZZhQn2wPr2F/vvqM+ocrPksOz04v21b/Buy7h/lNtIa3S3gA3feQWpV+QPxD29mnYVvX5Z3N9PtLG/XlPMAFAJ3OPgpaOq+GCob7M62L8YBt/DljHjl49hqif4Ak+D623pMbU+ktdUC1gJy4D5BiNCWnzeoYd/1RclbSkvcqgVqJDN5SQIx6wSiwqCdg7QYYPOlb74Ezr83899WB+4ul+Fy/lTwtYOFiofF8WilLdPhLQCZF9JHf/75gY7v9z6Tn3vs0GHQrUlYO1+fKLnS3w4sgGw7EQ69v8+BXal3F0kThjtTicwO1p0OocUCcamMz7aEpTRlml6VzrTMlda9BQtIJTME2LnOnL9NMdBMNogB9RyAL+3Dt7nbF5R138VyBNAF/+9iZQ6hm5IQ1ZKS0PDyqduaWLv+GGb/rcB9F+vG7SPknxMc1RooO7NC1+iSPxvItPTQuKs1qIMptkBa4768Ki0D6rG9QB1XiydKK9yKBRaSmbmkJQRqYuCIWFOfQfeZczJNqB2fRQ0xqaF+YhIa1x5KHpR1v/qyHMfhMJ6MTtm7/I/JX/iaSNVZyiHN04akMvxAGbLJdOC7WJnV2gjt6jOz/wHM2PbYcNecJ7b61uzGbZBwU6gSmf0vTB1hxgJLqUyIiTGNdADtfDTA2GFnW7yxuhDUAttZwEhmjsPhYBwGQ2BZ8u+hMiHQlZK4pPitHPvuLGa/r4uDweXLRpjZzrbak2cBOCieTmat2QmSsO4pO8akLrPtO6B/D0lvFv3oTc1ulrCT9olGVCqYkqwwVmZ1GGBBu8p1RbOthXZtgbTGfc64dwbuFrMr+77rBaKDq7SAkcwcZ7VTGnMqiN8vRkT5jKg/nBww98FUjGENtevqslcfvnsUfOICsgcIDalXz5WrpEM1Btxdax774mMVyRrIrSu7fbtDqX+o89l+NyQF7h0mvUMTIrY9108t2hbsap0BttG1q19Fbkb17zdhgTDjPn2nVwDrAbuo4+pNLBYdZIkFnGRmXMRHT4HkGGsZk8dwAEWYn/7NZ9QnwG3vzwKvNwfmksfF0JDgbKi/61ggBNyFI1kAem/B5MB4aO2FZDSzZjGGu0YkEk7RasXK2PbYMGqBe+qxUqCe7YIlXcNhUaMYrbaWtOHNLTDXuJsPf0gZucLAfNCAcVXhbSx5I1cYlzapFuhkAXIcJIq6Rh7DhxIC9Yu3lUVeA6BeCsRLH92w7h8aMarUcL3KA3N6ekKpTPEPQ/XmI5i6NWTL43eCry27sP2deynFouRLetArnquuFQ4NoWtTAxGJpTJPwoF7SLRlq9PCzTHzGAFLde1dl482dm0LhJxTKz4ApY/huvB4RHjJNGxkqTW1/I4tYOJszyUz/PMGQ/fVo/7navZG2j+6Q8AGr2vavBDeD1hUBWNXWYYtwL33gP2DwALQK3DvbfKa9vqw7X7PMY8c6Qhz8hk8LgbyPKe5PpXISO2v5W7IAga4D8DY4KhXRAHICMUgimcyZd9vaA3pUJMWAGAFevfDlE48BcwXrCV7Jddmz2tnUln3Wsv1qGcZ93HFvbthmL5PBCZf+tKsuw0mbay6FtvOh1Vya54D7KG/CwG8hn5sXCtafacW+OPw3//xL5fx9Lz++NxVbuyl9uAMsDfKvq8/L9rD6hYwmQltyL6ATHOmPfcuoVYfXI8O7HW0su49jFneBkplYI3t+IcAfrgMZ7iZUb3x1WYK2fbjeCVFagmgz5koQQSi4hYkMnpAzFlR/36LFrhsBNwXZFDuFM2Miafmni/8LU6UjvnWLYCSGfhgerdac0Yyrzfe3g6xdxVGMr2XF7glA627+qhsPkUGuJMca797pUYh2nxpeB1ath0OeVf/pvquzynbSFl50hFq6MdrrzTtfz0LXD4/QCrzrxfY+Ff7IWjnp2PqKce8c/CujqurzY82vI0FMMoM6N33JGngY0m5FgpMZDNiKsslsFXnInPgzvdXyVpLAf0cYCp7EAXuZfbqXdqx7Zw8uBqAl2riQ8x62jKoa9dbnd7LR9vbgQWQxD6fVwLuTs/ug/aSU7ZnJZXO7GDZ6BCaLABZLgG810QAiXacA1dce0ON+IDO/4jWPSV8MC+f73WVtVa1BTABEzLuEqAu6SYFqkLrSdImkLwagUhmqTVKgS+Eketlf5uDed/3LTtCW8Df+w4I2JU8kNpPy92aBeBW+/jb/+oM3IMOqBws+MA9BzoCZlXH1VtbazpeZoGYZKbMSDGm3P93wUe6rONkaQRmEKNb2a6OVs035SIXSUBZvrmKEqGD35LJV+BeYdpOVVwkmZI1sjmAh4ctuIl3trH7HIJ2Df3YacloMzu0AAD30+//uxNwXwD2FCtToG+PGU7Z9x0uKR2SyAJVkpnb8VgFtsto3fW3lQUOx+NwsM7PW/Up62cOwsyNjK4Nme16lipg2/1uCbxzD/qeQ4u2VeKrYZIKaOjHTSZGO7miBSAAxOn3fzQAd8rAAQ/hiL1SPVoF4+46A62Pjft+RUNq12qBUgtABBATIlLCiEvKlI5gvfITq6rpxdez8rxlTPQlXk9bjWrZjx7qrmP7KrY9N1QO6Ddh5jO+GEAY6E1fbtb07zdrgQPibMO4NwF33wIhVjDk8NaiZ1vQAeakDRvHJpvHzc66DnxnFpgkMxTGz0/LtLMBS4ZDQR2UdZdYq1sZPAhigAF2yKvhRLqNKNyQAveVDRxsvoFtTw3XD4e1yaNFwDsQeBr6cZMZ0E6uYAFG8HUA7r4cxgfutQA9diBIGMyBd2X5rrCstMsaC2Biph3F3+5I7BvW/R1vxPS3gQUscEenZ37+i50Fe23NJY9m42prrP8So7WXXYVt58O6GmFm9xbg7AC0X20c7XOkLagFwhYwLPvsdatm3BeJlLg8Brro+VUoQRMkncHsC7oS1AL7twBKZp46R5nJPDZnYkterxJrEkj7/CyppWVrLTACq/pcv474dhlbE61bKq6JT82aWjvHVfVWYttDY/G18AgFWhdN7qGtrl0lMjlD6d9vzQIRGW0d446besxRLhTqUeKkGnNWrbQ0su/nDTaNyvFpNbUAs4CRzHQI5eefn6kP/xy9Flj3ZhUdET80IdMmix1ub54agLtkkKEIkSUuTRrnX2LlrmVWZ9v90XL5jA/cuU9cr6fU0I+9LKnt7MYCS5adD60MuC/Qf0i7jm9q5PFDNF/uNN6CMNRxdTfrUAeStkCNZCbFira8Nj3nCuUy4DCmrHtPsy7bugwDRCpaG7iXPERoa7ehQtWBsMSQLWU3ZNtTw1zLifVyHi5fGvqxZYVo3Z1ZAHF2iuyWOqfOGHafwiOgzpGCL6qMxW1PeU71Qh4gfgP9m77cO1ueOhzfAiSZgayqMX9uqtPr9eg2C/F3eWLd4R3c3cC7WeC6DcGCscB9V1l551ZRv4dtV8nmbHvp47XIaDT0Y6m1tfyuLUAse16nKGPcZ3r2lDNqzioSoO7fxebazPydxg7XaRh1Rh1XGy2q1Ve0gJPMiEJErjiQaNMxiRyv4B3U4bX7/NCID6tPF0hlwNEZJFecYOGnvdwN57qDROD+8a4SxnXNbFvfCdueetYWJl5DP26yirSTDSwwY9mTLwz+sQC4c5GsRNTof+BTzqodWTieIMIHPxa4XzDKxXU/YBssBe3iJi0AH9un4XCk8JBbPkT6es6MRPquzm/dMAQgADb9rWiBEHDHbT7gkxSTOVL5dYYJe69ZB3r7so6FWatwgweHuN2SAJ4FSth3lMh8rW5C7UAtsK4Fciw79T7Hz3Hg7uQxMZkLNRhj0SUgoAQICM2X26RsrHd1XBXaU4ttbwEe1q9776H3MgTGYzEEKwdkQ0OqtrnSfqJqMeCeqpya59jtZz3poc7KoonsUuhwOg2Hw9FSVPVz1mUwJY3kALyNVrV+tJqSQWtZtUChBcQs+7JdA9z/zjKnYmM+Q+NXlDDuuYeQMne5doBMsm353uzJ75WNOqMhpAQG1iJbW6C/ZCbkGL7tUwFDhnHd9beaBSapTMf9dTbaENBP3abOH9XcvECUIf2tagFk2+dZmedHdg7kpSTbqiMOoJOgd/MwYBQZlbxuPBvaXTcLSFn2eIcT4/6f/3YxWfdCv1wMMKiTOtH7rHznj0qOZY89v7Lv3ZaiNtTbAhLJTOi2q/O71fGxJsdE/eh2NOusKZRZXUUeEQKCNLTpbwrc15r5ebvAtg+HyddhKVyd36QfhsNw2at8lDPwGvpxmwWkvaxjgQaWfRoQRGoDxv1//3H4IwjcU4CdmvGZPH8DT23oHWxTC9p51+qd3mEitInuFnAJdUDvHjoY7xekR8/KX5+46ehvHQugPMJjWtfpyW81FVTAMvKUfEkTcq07JZZthwy6MU+GOWyfl9otiAfQjrr2G5L9rDvT2votWaALaDckeSFw95n1EJMee6k6goweYH3x3TERZ0zkGd0Ybul9uOexGsnM/Mr7pp7X2yLAt0Sjiqw3g7teL5R86Utj+q+3AoaB2PaYOC4E5s2/mf+/Ae7028m3ENfOl0aFW3PhaNsrWaBdGrOAq8i4/4Mz7iVOaTltY0ewjjtK5/YW00Qx32GD2MmGtdJS0mZvxQJcMrP2+q+0SW5Ys23CJmT6Uta90trJapB993B8Cu+VsTgCawwk1CYlX9JoIOtZHJJw2YN+7C58KZuZhuP/bYLvuW/9eo+EB4ov0LVrFJk1raxtr2CBbiz7fGyexv0UCBvGK0jBbO5L3mCg1cE7EA+WfdewkQ0TpVW7WWAmmenWar6hkA967Mueb23i8ODKW2N5F1hMXhT07eCg6sJ2+lvxFfGX+jjI57G2JN64jBRJZg7IU3fhOYHrtGyusIBQIqO3NLVrQutdwwL9WfYZEl8y7vDnGOueer15sysB9y1Au6MYjGRGw0ZeY9Frn74FkkxqjblS7OtKr++E3IF1/9SPcc285eoA4/r8PIC+WfQrdWMSNRoupMC9wXiSqjD34ONgcy3wr7j0yw3d+Of1cMwZKYknGXiijEpkGg2o1Te3wEosewK4c8adADwVj1E3fjl69TuYS/rx6dBVtAl1XF3Tutq22AIdJDMpLFeikBOPOV4Q43m/ayKeDqacN3E4DIfnFzlwlw4g5Hs693DMtmSypv5SGWLWUnUFXAhZW52iI7vkpAm3zhBYD0Hz0CXcas6iMHCNIlO3GLTWFSywLsueAO4UDjL0FfevyDYIRbcH4I7nEnVcvcJboF36FshJZjrIWDYzOoK4D9Wt9jQ4bNGwRtYA7qXjDFC8E3DXrKml5syWJ7Y98M2cpTex8xITvHBgHqLkOC03l89kR1heAGL+qz9Eud20xvYW2IBlTwB3n3EPPX/uikx4RRtqGh6+JInSptOjjqubmls7C1oAJTOQb2Evh1rxPPF9wXzyMSETMLBRaZ64cS1IBAOEAtwDcKcZYQjRZE3VW5Y1FqvPtqf68IF8SC0Vqx9m3GMQv+FJbQQiDRLRYEOtuoEFtmPZE8AdGPfYa5zzUe9go10Dd/t8lLQJM7flDjEdbKJNqAU8C5jsmBAickvTLIH3cq/gaA3+t8/feeO10gnNgthrHi/DAMzr08twGDddHKIHMAc1iCak+6bIYNJCCbZd0oQfQM2/S499+f22l3fwlfOM8tQvlMnoTy2wWwtYlp1g65bjjGRODcli/I8y/XenD8TeGUQ+PgfeNWzklotV+7IWAB3z0/NwGCEx0xq/0Kd7jX4GdFA1LKz+2i1AwB3WxpQ1M9xuSKAedkOc6qc8mvOjN3OtYUDzliorAeE/D8fGvSAhoYntBj4sj6+eEgCvoR/LZl9Lb28Bw7JTgjN8P0qWeIcBM+D+r5fD6TlwbR3ySurQ8+K43ukA0HtoqQMFOs6cNSlEb5tre1kL1ElmQqw5dLWxZyp7OkzIBE6qF2XXspOeLYAid3OoO+aAe7YxPkssTDD9c0wlHWvXJNBR4F5id0FZOMSfIIqQoGxBkRAQSXm1pe/pC1CNhn4smCUturkF4H0DmScpZLwBbAXgA4w735Bjvuaddok9S2OkOyF5vgPw2GrWNl+t2uEeLWAkM0eh3r3TO9vdEADolIntZ1a4jQEGFvyVev0kB7sYOLPfEMqa+qnxuHvNCrRj2HY4pAW8gbGjtlsSPNbbpmP69lgP078vYf2UnZWNW0M/9lwa2lZXC1ikjsA9ETC94IzaMrxEAiZ8ZfM61drepcC4tv2WeqVjU+lMi7W1bq0FFpKZnYFzofjPsO6/hgESnu3sEWqn5pr1JuB+DWP6ANJ+RwCUfX5olJCeC8Ox7bl5bkMTMfadIwQfLfAjgy+h8e/9EGdo6MeeK0Pb6mkBrmVn7YbW9VbcbUTjzp9awrYUWqkUGBc231S8ZWxu81HH1aY50MpiC7hMmYdGjau4RzjL2y2L71L+v/k+IfglZ59sR+OZSFII6j5V/1wyDbGyDrjjwalHix3aQEfkdw3/2cGU1MQUSSYH3AlWt3XuvbKuMSmnn9TAa+jHtsnR2itY4GA+WR4mTInHQ2h5DTAfYNz58/NXTbI5JGy3V1kMBxwtoJ0eXdn3FV4gbTJlgSnKTOM7mjOz9F2pCOkKUSSUdc9NgOzvEC4UMmjOPzgevNoY0GMMd7hVUV8G2STmSiHb/jQcqg7s7ZMfAyO+jCB1Z+/+BjduX58qNc3Nuf59OwvktOxsJHxnnR1O4QI5wFX1eAjPOZUSMIXAe2N3PUBx4xCC1dcal+r11pgtbTNkAZTMQAjAQtbd31X8d4FTbKta3lyVY0Im+IDrr8kCyMQ+NcT657RRO8bDZzHA/U3lUE0zO1UuY9tjnfaa3LmoFnpLsfBzcAOhHz819GOndaHNtFogEDFGsJ5DB1TOX/Vm3TNSmU4ymbXAccscbXEDoI6rLTOkdUssAIl3IJqIlIHb/J2M7SXTv7uETMjKrnx7UGLbGyuLEYeenoVOy5mH64XtnB/Duc+4bmxOug63iW0PjaQ0QpDXhslN6H6he/qQ6+xhAMd0iMymh/Wu60Mbq7OAZdnp0xNa00hCRL5OXELjA3kC8b0AfCAcZN0zB2ttAY5rhrslaFHpTM0MaZ0KC0QlMzlmvaKvVapQQiZNc95kXvR7eO4A3FNiTn+EGexnsqaSVEYPZS0T7Nj2Jh+G2OQ2ntQCIN5fGo6Nv3wNl88vTcjVshi0bgcLLLXsQa267SklB4Misd2tF2jHw8Pnx3D6/R9/HP74T4jjTlKZThvrlgBZOn3XGpM6rkpnSMvVWoAkM11jeNcOpqaejfUNWugrxpavGfmu6sDty/MLJgjZ9JfAguY2BRJt6W1K25zYcJ8xWVwT7u6nkUKGkT3oYlg2PKj6PLStBq3daAFk2UdcrBd2bxRau778S3KzhCDbi83YA8ALospUGGbrD4ZkiNceE/SPyZpsOucesyd5bi3zWBZAyczrlVPep1zSaDpMmWkzNJ9258So6c7r1y18jF5etwfusREDC+ti9Tchy3qb3EnNw3gaDqdM7oZmEzc3MLe2z8LbbyA4pOtPLXAdCxDLDn5hc8YBAHwOlMOYfVpkAdAzgk/stfJV6wvcrw2OYytgD5Idd61pHfFADqARFq7zzt55ryYcYINzotA+0jBwoeZC7IXZ+C7D+RMSMgE7q79iC4ARx70Bd02yVTyPwQoZtp3XqQQEy27bG1o46WHoR9W191kT2kqxBRjLbuougTu1GfrGSe8xw34d895q+ds+wH0PwDiIDqQmLp76bAXkEk2I6inTFoVVhhl1jqsA4Ns3x+yAtMCDWAAWHLDuL53T3svMFwPzqQ1wIY8+n4ezhg6UGdwvBXsJ3Log405RhoBBQlfAWWlz3zG/Iq7rNFML4/R/apz+RuOK2PZQHxyXVH1qqioFn/ZyNoc4Ja0aF4NWr7AAZ9lz1fNrfvHdYgx7SCO/OFfnu4gOsh2475llz81N978beILaUk8uODvTEYqBDxp61msM2+5T8egNomRGFiIyF7rN/+5LmHbuwOO9Cm5mQmXM9SExtMq6Fy9jAu7Pr8M4jhaqzz8j/jWwFSn5Skw2TwD66VfxtdFQn8XTOK+A1ygY4rM45GsKyDeNqnwdoAwOvnUqg2uyvFausMCCZU+3weUy/s7nO6fyv/Nvo0QTv6grfK0McP87OKf+G3NOLTCMAveZscghbEGiAwFvtX4LwOI0f5pxtWDladGMBUwinrxkJgagOcDjXfmbkwTSSTSD1A6UPUMUEmDd4SN/vYuzG1xj043LaJ2UQ1e2sQcLfZSW35Lw18Ww+njy8nAnxHDXrKktiwkjBeG7DK3wF0L4peedx07SVQMU9o/fOJtoqaofraQWqLFACcu+bJ9uKVOA3H8ja0ZJuyb2I3il7pNxv8JhYrqKtgH87QSk9tn5/FwQpKDDjmTmaleH1nsQC8wlMxKWPAUJfEDnf/tj7MJsQ7KWD7U19W0lHcjOfWBSJv2VWIDm/XkYj6dZRANJKyFI6B/g5gc9s4tNoH0J3JFp/aVZUyX2D0EHw7Y/R9h2wVc+1XFjddN0vhHMjKyhH+uWgNaqs0Ahyx7uZE5FxAio1L5J7cbkMz6xgm9U5pUqB+7StOd1pm6rdQ3AbmUxF8uom7BChl23X7RpEgymd/sc1Zkm9GKiaqjjats60NqTBUDvDqEBQTqzcMOZf3bDEoq0MWMHApKL0ZUjl9vgW4D+HxPomxxBbH94jv2y2TY1aY98SZOs4nk4nE7iDJYxRikqZ5q2Nze0GDNvgLtmTZXP4bzkxLaHrp5CcCAPpBdjqagSPmQE/tX6OKiuvXYFaL1SC+D3R5qMMNG4+X4t757prfPfvti/p8a/aEPwLpZLZa4AjrOTdqUxweJwNvacUOEPM2BuHVURs9hK7u8E6AmzuJjvyr5n514LZC1Akhm+XmMgPQXeuYMjOV8bdsBubjEqHQpZoO42QR8R2jL4MPR+gP/Hxy90bNRfiQVs9JHjCf1t3KGJgghEONKYNIp6DoH7UB3/3y6QNRWBux7ASmbRvAgptj0HB8p6S5zAhA0FEIclojT0o9CEWqzNAi776Tr6ypB0xv90RckswneRUJKLT2ACwJcB9ysB5OhMXnE8vgOqS2nrexZz5t0y8QjYc8sTNjyXpEJwBMu1p39/UAvko8z4EUccpvacrGcAPWRNTjfwXYjKzml386+cbgjUP0P8b6d1z741DzrHy8cGacWICfW80xQ62tgNiLMOoa8PRZ0J3NumD3jzkGfm5oT8FXQOSxZpmm2XAPfccSwzmupPj6mIibc09GPJlGvZWgsAaIfEZNVrVtKxge6hm0heO8S8x+7GfJnN7I2NPItcKnNFkDwz57WlOrA4fDZ9cVSaH6lcHFvHJJq/O9lM4luGcgLY/NATf9UVKVm1WuZWLXAYh9FKZia8PAE4vBKMveN82cVwQEiHE9rhQvYLURS2H5OQ6c3Ix/QntgDcsoynZyBs6bqDOTbyjDg+i0Ae9Dx27Rz8c9bJDCgUanLarUzWVNK4K3CXTWIL205vOH2YGr8bldWNM+pHXrArM4iWUguELUAs+0gfjTUN5X8Mly9HDqCX/D2mdU8z7nsB63werjgmd+0MJKb//fGILE5skWwG/m9VyHv0yKeMqwDg9acWKLeAA3Oo//PYbmouxIr7VILfdUj2MntnI2PlfSXYeEzIBIztAGtfgZ9k5kHfPj49o9Ri7tzgXQFiY5SfPsCjAzs/w3/2s+NNg7uN8eLKQLEpoZbOn2TuqAyy7U90a1JSM1Q29LIVtFkI3lEepaEfCwysRWssgGQTsOypJV/TsLiOvVmKxHoKfWZDl8yhz6/jvQLvXppxvyJIXtjtCmNBoG7pcjcBxJpTeEdOWHGyypbDYYeOWOKFYQtiwlVNXlFqNi3PtgRMzPQ8HKz22dlGQgFw8BbDzj74Du1QFe8CHFrP76CRVtZdup4PxyPesBimwN+sGOOOc8nYdccs0L5lNzCcN3LUsXXwTx4DRf+G/9fUPX9CdCCNyS+du5m2/RgAJYUget6v/wJWNJarQuGNVSIjn3ItWWYBn2WP1c6t1bJeo6VDcd85GE9dSEO50KeTPrmuHfYsS+B+BYCctd2VxuQiY1ir07eIJC4LYxORSQSWb/nsg/ICPvtl/oYHCdCMatjIImtqYWsBAO8vL8M4HsP6cr6LkNFKSO4KYJ6dmwuAv08L/pS1zdoLMPZ4HMaXV3s1aCdlgdnYDubmmJgJC9TxupDWDgfu/ihCGipT/vz1rmE9JZPGyji2PfTt6wpGHK9XOEJbfDEWG68dHcq7DrRufFrr/ixAWnbpk626DOeNp7grDuRTn1behkeLOJ5EgXt08m3gfu/YhAQTVxrwUxBPslQCdmZjEFD06LgKV5EQdUalM9L3V8sZC3fTc6oAACAASURBVBgZxYu3kAMf4po1vAZwBwhwPg9njAWurLtoHR+Ow/j6Gvdb8Bvxb0dwoVj93wyAsbBYoWCTuB+ya0i4LfnUyECiOXOFKCrQMV5tNTDS0DDeCp8HABXZQNRlBtHSagEkIUyYx8IPU8OSlprdjzYToTGCsRigjwVA94Oc0OeZeBWXOfW//v0CV+jFRpE+WW250kmq7WdRzwJ3IpzYTLhlY/8H3RY7Rr4JvMgXpXFc/TTsu/7UAiILTAl6MM431zB7h1RRc1sVcqw7aN31l7UAOCMjcI/oP7MNeMy72+RYogoO0onRwHZtXSubOb//UufirL2nAkm2nbcT+s50AymFDUFxK+XU71HBZGtRmQVKWfZYq4XLWja46cPpN++jOf9+i0tooJVQeWqdl4XEhKff//7H4Q8A7hg+bAe/Kg/OtnGTnt3Fp/aPQPZ7RN8qbuRF0WrgLgft09Map1XDvq+6KtsMrLX3ZQEumdnXyKKjMaw7xQO/kUFfY5iwD4zjML58i2Tb7DQoHgM3otIEcsH4J+jNoNTqxg8lwbaHGordr0s7XZQr/JYgaLdRZKr71IpqAd8ClmWniDGtBgrdLLa2Gf9iJVv2X1mutfABvg/eUSrzt3/sELivZsxlwy4m++RPZS6BmbadjkL4rWKonRu/fsg1gJ2OZ8CAnY3jKugKVTpTPw0PVhNu2FAy02tT7Ga/hF4aZBcfH916usuGtgLuMQDJpu8ynIfz25vuS8KFhhmO4Z10N82FABr64V99n9ITjmMqFoMQ84YcaFfyqNjCWiFiAZTG2KhYvYy0KXCHVxGSE3rvSkAG4w8rJph2b+Pnx3DcDXDfUBbjIsagD5bJLogZTUn+Qv+T7Zv4Z+9YFFIalK2xQtA+u42YU/sX0P8C64GOq+rEVzYPj1Ya1o6NMgOSmQ3fvXgsyvwcnM+fmoUzZyYL3A8vr8YJ+Yo/c0vyU7OmCueAoj4tP/XCBmKHqYbqpmr8AGFIow+9VWm2sTZgLNCZZY+ZteJMXD5D6U58tYYv1ghdpCEEReB+banMpqDBN71xpELQzn6z7KYszCNtYa58Ie6e91JR2dH9Pq1iRwZj1cQX5e/Xo9ZoksyEmHFuSP/yj/5Wse5tVQQJH2/mdkl/YQsQcH9+HcZSyUVnm2LWVCdvqp/3zsPaZ3PwLkKStOT3sAPaaG6Cs1kgkdHsqPtcUDc4Ksey574tHZ+t+X1Ij4UcV82RJB7MjVoJSWj8HqYETNfUuF8DuFM6dxae2MfEaECGjxeOBMXfodgFiGARBm3kX2Pa9vGgcRkGCKGnjqsC4z52EZTMUMzvoCmKF/qqBlXWPWdeckB+Gcag31LsYjbXbvnfz+A8D8mzQON+jX2+fMhXqxFm21PDaUAcDVX5iBC0A9uuoR+vtm7uo2POsvPvTaeFKjHSil2l4ryHADtBTx/sz6QyV3dO3WhDn+QxU8QYNBpH5BSq2Dvw9RliBQBaZHBKXaZ4q9MlwtCwkZL39jHLTJKZ8URRpRZH1OuaxhsOsu7vbyYzo/4CFuDA/VSYbTbH95R83Vj8fZXupVcqse3gb1JiYtdqVaXKvkynJvTj+zCcK/vWd1ctgPhrzIR53Gh9rdwNB+8+iiOgHmLkaZHwv0FSu+tFlemDhkWL3+nYbWli0x0uts6oMwxvJ5ISD9ZlWy8A67PMhCSolzIuETYfY75bDaI6rorWysMVQux+wIQ9hxGA3pV/qYsp+06evz6GC8Z1VyY3Nlvg5IiMe9U+G/q0UE/+F84/6NEmS8BdQ3jm3ijHtkdMmatvobSsmF+qBrDYb4re6NaZXGshYjeAHYMj5HBSzSKtsPKq3UyNh3ZQAu981L5gyP03AvetospUfUAqjM+qEGB3pxb2PXL/00sO6KqzGO65ZRUeZUWthY1CcpjY+Sxuq1nMd/X8b1tUd1p7kszUxv7OGKYjkT+FhtQcBnHg/jyMp+dK4J4jDAR7G8beh6yp73f6xnR6LM62x85G4q4qkUdJNfSj+rQSGfHAtKBaYLJAlmWPGatkoTYafLWulg2naBJ/S8DPKDinbiKVuUJsdgfWBxs1hmXsJok7fn6s1WZhie2/z3C0xLru5CgqPF9ZSdAe+lAW9oHSGRtrV8F741t9n9WR+Ts9xx3kcowgpwhi2K5w2QYtTQmZIEb4LB/dfc5LzVMdnp6G8cRDC0a8o2oal9SBOfqArKkavjNlrhnbzgvy96QKRFRUElQxoR/fNW+I5B3QMp4FSlj2K4N3wbvQNr1zBj530TxT/m8mlbkG2w6A3UaMoZjsLoIMJQAk4M7jtgvIpPCEVVc0zUWBOxtk9kops5QAvKvjatv7dq+1rWTGhBEMSGb85R2779vIPlOoQWDdG9+9jca8ZTeQGXd8fs0z7s0AMfJUNvmS+iIkZh3Z9ud8oqwmECGsLChmdO0a+nHL9/hu+qpm2VMWECzaWgOu2LRBdKYDDthDn1T6N/6FmzTu//lvFzj5r/K7AmgHEDw7oXADMfUJxWEHG/Jh1pGCFeAhapvQCOpGFT23QsQHcPBT9n2VZX+rjYLOfXwBptZKZlLMOe0813jYyzCcP0CKoRrqkPlR+vQiAO7S76K/oebm/GIy3aoOOm4ouBWBeRL7IVSDicKK7BvpRo83tiCRUafw3NLXv3MLHIYD6NgxmRKTPXQzUuHaLul3xabNMEwHIXCeGqYD7v/9//7LZQTgDobtDbR7t5cxPED2GCBf3Kp7IL4CetezfRvbxZmN+iXpDDAo6rha8jrffVlkAVOSmW4W8LU1kgMru2L8ogQ/X/33rW7PeJ2G8AD22gjcJaA+AuiBnT2//RwGSAynNyJLSwK5BHHbxwqfkiZAUVjZFjfx2uFbUVj/Ostfe92DBTjLPmNGe64hDnt7tssMuFKzBN5DwN3/EvL/RuAOmVP/Gxh3BO0sNA9uyHVQtjv4l4B1T23CNesOHgCzThFkrCXQaB7jLl/zhfbZGqwL+gPJwQDsu2ZclU/7PZeEF2I8DCiZATaw+RfySg1tSxX7Deqo34bLh+qoF9M0Hofx5Zthu2Yxb5snVNTA5XwZzm9/agz3iLWi2naRdb1CxcCirAL6RoGTsYL2mtl5wDoeyx6zwCrrqWxtF03OCk2HEjTFvoSOZ+Ya99kDYAYrut4o+KBu7YRqJTEE0kN3Du5hmdEdeC+aNb9wAWjf2i40VAFwx6IU8x3Z9xVWZ5OdtfI1LOAkM8WMIAfqBe9I5UOC3Ov866cCRG4/zJ56HMbX7wy4U4Ft3m9gaHVeYqgd2HYIvwpsO5+PnPd34iWpnlZ27RxqHrMVf6jkqXJ/erhqMZZ9M/Be/SLkp6p70wa2p+6dfTYe/nuWOTU46lIALwWKeROJSqCSnWEDx7Iza8zE//bfXRWf+BP16lCxvPTGdsGBlfZpY74Pn7pJyyf2vksCK+gkdO5RQ+DCB+uhy7+VbEVOkBq9ZDIwAvdxGF9/1Ekx6rIAzSYYs6b+etMDVWDZG237FGN//kY1oAMfBVS9crz/y4ASGb3RqrLkY1USsuwpo3QjDRveodykrdK0aVQCRwm4P1E4yOR4pQC+FCzmjBTa9A42vCNxFUzm4h4cYs1aTI//xkmFahKwumI5iK6wSxVYjzEs6rhaOwP3U4/AHyRmmklmGt6DlaxjQKKy7s68DrgD434UWt1nfnk1/2vFOaJA8+A4DEmy3m2SrFrJpXDkN1MMzAgyNMu2x47A5iPeASFUN2GBhEpkbmZpXXWgiA+t82krBuwC3qsXft6MXQ7HydPLtI17YnUHYyGOO2jc//ivf5c9aQjAc0/h1knLm20eY5onSWKJlFzYR9ve7CRTjTsKKu5dGpOzM7LvGvorZ6aH+DtqpeFaXwoAN7YKBCoAgAERTCBKkv6M3A0Yd9C4d/FTiIH4qGfqcP78NMB9ONf7St3hXBLbzpMDpu6rJi6uwhicsCqsPunaYf70pxYIWaADyx5qdu/g3Zys5xqX7gskDsmncJBS4E6DmwF4u3mvDtoNhY6bnHUyhf/w7YejsYw7/E/6b/znubKmwNQFoJ3ZSN6B5JJE0FrnOUDHVQwBBpEh9AMsmIG7LHJ4eglIZjZ81JneLSQKhCydH8Pll2V4O78HGz5pn64scDcOxk992hS3YhgUTL6kWVMnq3lsexgGzUPDTZ9uGa+WnKKSJoC4gRsTDf0oXvUPV7Any36L4J3epwa3lPCameveg6ahqDJixt1vxZ+8NT+Y0BcB8kAUGJLEoD2tMVnkQwf6y16wQsCeff5OAJ0/RLbPsicOLhSQIqjjarshb7GFNUCgZLPz1RiZVxETMkH4QYiO9Og/mrPn12E8bQ3cDbNyfn/TrKneOjycngaMJuO5pM62c0bmLbFBCfoOvASS6vCNRbJGAxU8+jYSfv6VWHbeWRfGnRqULPrKmV6FdSfgbj548F8L59VoVJnS59gAwLurRQvaHVAnkE4bHntKZ1fO2ImerRCwU5sbgGg3/C364jHfIda7RhcQrZ67LOTCCxbGnY69ezFJde3ZFsAisu5vQjefu5wl+1CwSY4D3pQAcN9ir/A+vJh8CeJ+68/Q6FbbPo7jLPiZBFYsgb6kltDwXlNGIgM3Vx37EA5Fi+3cAmuz7KuA943W8SrdLBvFfwGNu8g5Vbye4DQ2or4Sf50+GBiakjmcmpPI9H1GJp7foIMkhpcvAgPFKL/rs4pM3cmu0b5iGn3Y1NVxVTRF91jIRJmBrKrewTYmZdnYCIZ1/8uy7pWH743HvE53iBQxwc/4ZIF7bA9c44Njky9p1tRpdpFth6RmGFfffLxI8lk3BXW1FuuNNwN+TUrOrPNK3nSrG7DsIft0Pzx2emeCY11rgs2YafteCbjT4DsCeC6RIRUMl8rYJ+IJl/DMUATWfaMLP/prA+jQWlizT0nbFPMdQoRpxtW13tb9teskMy9WN02+LQ6HVOdr6/awpK1Gp0j94UHrmR20NgLvmHzpFyRf0qyp5Ch8eHkZRnLwRmcrYpuYoxbsrYF0WWllWQcwYlkwJGU09KNuHNwCW7LsKct3AfEd3pXkGNdZOiSXcXtDf8Z9CYBrGXhk2QM/Mr2v+1kcS4TY23QRbC09CxKQ23se1+5T2j7FfEcHJnVc7T3Nu26Poswc9xllBhP/kNZdup53bfD6wUEEk/H5dbohyQH32J5Z+L0zNx+aNdXRWKcTypZwOboPGAB2btjpIHyx/+67eUy0WCxtU+FEUYOoa4d47ZAdVYMQ1L9x91UTsRuFedzDozWD98r3o/TZO3ezyK6Kzql/LwgHWfoArjwx8LAVAduQRtU8VBZsdL6TKd/AaCMEEoOXLR9qEdLPPkN5/4kaawOQ2vYx+gB3ZGq65uhqMm1sPQssAGF1V6F3LrTr+eUCgMeBEOsYqRFNBpBnQCjP3H5bNH2cOYl8oAAEGsnSuW/fRQPdQWF+SzWezIAsuz3xRZZxd8OdGzhnbp+Nn/5bjh5Q1/5OoH0HdtMhXNcCe2HZuRWaQTs7pW5hXfnrVzAaA+HzmVMLmhQXHcdEsH7MhTpPnsRJCrvx0U0juee7MI/VuHGnoL0WUEsno0f7Nua7Oq5KjX7j5WaSmecCeQx/x6pfVGu8dH0IY3f+pcARsnOOrwDcyaF4ha9JYCowhrsmxDLY3LHtjGF3HznmnOUyBrLoCywRk+9Ggm0HotPMWXrBfMP+DU7dGvrxxjfmPsOfsezk69an6b6tNAF5wXvRY7SrdGPe11Nf51T50y4WCAORpE/n3wT83z79UOlHakY5u7eUDxyrFgL9stan0mv107FdZwmM6vFpIkmcKdB+7YNrvd1bgKLMHKVRZjZ6Z/Bwfx4wqgmEtHvgHyRfGl+/ZYB7WkFdbD7wMwAg+P722Iy7C8kJPiGWbSdjctBBIN7PlGoDMlAOVUtpuekIMfH+51CSfRUAu9G1r4IyipePVriSBYhlR3kM26ubAPKKz9I8rg3W+ypdWOC+jVQmPoEcwKOunS0aB9ytAVAOE0uqVEziFaL+jmA3u5zX6Iufnju1v/AMAPCO4cTAcVXjaWfn+cYLTFIMAO/+LrUhUF/YETY3YN0hrvsDyzXgcPX63UYy8W88yGi9gTtLhvXgSdvg4ASRfcL+WuyDRf9zFmaGaT9JXuOm6oDxnfkvRUPFALyRyPxSouXG9+Hm4adUEM0AuXl04QZcNJJWdNxaP/F87r3uawPDuP9fW2jcBQOHuMPWGQJx5QE2p3h0GLeeqrKhFoKKTkA3aYVYCEaB6URFuKNA5fP4QD24LjEywsXEfP9Sx1XR3NxiIT/JT+Wa6v3o7nxKIQm/Pnt3cRvt4fwch/HbD7OvFv0aPmZweIesqaCZftRfim1P2YQ+aoszFtt5reLG/MsSwPvHsfmxjM3r+YLOqBqy81EXqcFYB5DR+Sx7zCR7BPHdxtSw50mWUMfmryqViT4rAXj7saEY7lCeGHfcsrghinB4UeHtZDH4UIVjkyyYxnb9EfErWup+8W8WPeGVucvAV3wlIn06LXc1C1hw+PJtAHax+eeTvykymBGSuDf4+wElZHp7M5Ey1nq3mh96pQYseDTAvTUCUEiYYYDj4qaFsqY+eFjBw/E4HJ5fI2x7Er1PTl48OCT/+NEH8DIBd59xj80Y9oxBBT409ONKr95NNAssO+0L0r2xG0juaKHmMXVE1JnXutdT7xO4O8rAMvCwwBy7YP6I/12NcQsqShd0y4yszbQ3AvfQo3Hm3f98z66FrXRmUGanZYXsvu5cMlMw3BBQD1X3ToZBPB84F2JYwp+UkKlgXPdQtCtw9w3Cje39b3jnH9m/oJZtJxOTBMCdRu2VMgIUOq3awha4O9Gn50zog3cqBzehJjuqhn68h1e96BlKWfbFq78R0C15qGbwji9bSY/lZTs2v2/gngDwE3qX2s8XeQjqbQHa3TMWHCYEQ0d2kX8AJHUiZUIgnZb5jOWJ2gu81SAXi2Xf1XG1YTZ2WJUDlRNEmWFr2V88fPg+HvEezVcLLNQDrLzPNrptmBIy/YKETA8GUgi4g8a9x22IdOk9ukQJ4HU12+4Z2SFvmwY8MgekYTe302mXVKdr1+R50hV9P+VAzUD5N1rwTReg3Nms3cbUEWHzR+zYLAD34+//+D+HP/7r3zs223lCYgC+eOEJwXFxuw3Pu1ZfDe2GrlxDIMqXxyAflOoXmDhketRxtWHF7LTqXDKD+MGOdLGeGEEbu94PPWSqrGMcA7zJ5YuSAT1YFk8C7iBjOj0Zk5YYvHKlTcmXHszeeFqEaFrjgFlSex2WZo5E9q1yV872v10SE/MCBPdmHB44bb9r6MfKtX2z1VpZ9tSDdwPMnazbPJ4VoXCnpm8LuHMADyHoYIPEj1EKkAvB+owJrKhTsuY6suHRbhuAuzNzgPyJffeTgH126rwMl4uJOqOOqyWL5jbKOskMc4YMyVpiQDtVdvaKRi42g8ob1Fz/wv/3UD+6CXl5HcYnAO5+QEFrDV/10mgkTL7083Gzph7G03B48bXtvb7YFOPdb48iNDDUzuaRSpvQj+A0/GC3T41r+qar92LZbwG8N4N2esikh0if5dCwJdwmcOcAHgACaeCDYLUChHcAvWsC6uSqaRh7jGkPfCLcYQkYHDFo9wC8cVz9tDrLgEC5z+uhrWxlAS6ZeXrGdeHPam6vCgJvLwEbbyME9EOPe/mkTJ5fD+SkCpay7O+TJ2HKrYkZy5srPP/74wJ3a+/nl2GkG46F6XJvgNDW2Axj32fN2rfCk81MoR/BUVvYjxa7XQusybIHN9lOa7vF4t2A+wystIwoXbfSZLcN3KMAvjT0mW1oCyYcumoA12uBdhyWx2LGNMZZSYx0mVPM98/3YcCwkQrepabbbTnYOI/HYUR5Rj7KjBR4u1c9Ei3ex5mGWzY/VPyiw+TPB4uiYYDk+Pw8jM8vLryueO3ETl3km8CwozM3mPrrczi/PWbWWsO2Q9x2ymsQQ8iVX+wZnmBJ7qIEoYk6cwAnbQ0QIF76N19wC5bdN9IqoLlhJprH0+EdDR5wCG8yyFPYFcjdjtfKnNowJeGqcMKE8EaOgS8A8GuBaX+ka/VTeOgIgXSfyeTfZQL2axw6UDoDV7gQNvKRk+V0fyGu12BOMjNJZbhoZgLaqfVJgg8O1jlQDz+1yer7iIDy8PQ8jC+vScJgOQvzGAtBiZwHFo1fA8Rw/xguvx4ta6qEbY99xUuPr147PPY7ad1xw7aHBgDtGvrxepvhlj07lv1o578QEfYYazNg7jEIYm16Pn/PttgzlqhysCwcwj+G49/2koCp13zNAPw8E+uii7WAdAiwd4ryEjRTxXP4H+uQJMaRbhXtF00nsu/guPpuwLv+btgCDMQ8zyUaS0BuGcHA3b2LlGH/5v+3OVherHI7by44IAJwR3nWA/0IuJN0iR69ES4ut1Lr/IjM7iNG8YFkV6Bt58mugt96/qX26ZGahWl17Y68oYQnZvc+f4GuXUM/1lj2puoA7oFMvZCUC/737HZyJdAZPItu2FduglY5RHR+Pglwx1f8bNkU8BO8QDbsnWROzU1C6d8RwIMG/mg+7j74XBuM8vGu0VdlmzE2ky51Zzfkto9qLbt4zoCuO5uoB/Dh14yrYsvtsiDq3Y/D+GokMz4jXgK4+z2fYYPPbz8fKiET3n68fpvtfzEnc7C1BNBHy6Aj8PtwQUfgR3GA5Gz7afmdEX3nRYXirwJn3ZluCSP8wCFKQz/220b21tKCZZ/e4ek9bVxfNc+8CmiuGEj3caxgy1iTlIUe/+4XutwpcHfUUgDAF0pLKpbLulr2BvY+pbqcgffKg0G5rTw1PcTeppBl+MGZHSXKm9caV7MAgHbUuzdn7uzzCCZU4V+ow36UH84BxHJH3bXV/LsYM3RrYayR+iRJAL3xJXizkUsexcLgShBg2+nxeeIksVdoB3AAa11DP973IrQsO0aMssEAlg/cYS2VWrE7WC4dACvfbSwr25FrPx1gT/Z558DdB/CHo2HitwCma/RR2WZMxzoD8iwSQVW0GPH7lXKFNfGQzyCZ+fxl2Xdxw1pwNxYwTCQ4RpJzZPehpa6PInve+ePXcH57exzW/Xgcjq+/wdVq1Pw8ZQ/3P5jkSWFQzw/6BvnDwejN+Ks8xC/Dtods4IC8Q/aJNOB1YMHEa9fQj3e7BD2W3aO+uK+4u0Gbv6t166rYnt1Ac3HPgfNLz2fu2RYb6hl2XBNMQfB7EODuLMEYeNQjUgxcgamkRSrBdbD5xtuBkJZ98cGlT0fPcWdtFQcSrioAAQwbqY6rWXPusQCTzMRD5AUGnqJ3c8vG1wx65YF1//rrTxPJKNfWHm1aMiYb5ef4DYC73FnfSJl4Ip+5oaK5OSlr6iP5EaTY9tRcRb/NvgYeT0Qls278hdBBmEWeKWpBC+/WAh7LTqtDKn/bVD4jA6DbmZqUCk3jKnsXsw+HON369ZWN69GAO5nSA/CtoLW1fmyGO7W7H7Ae+jAlljey75Y9AhZelTPZvWBvBcBpCuUaBeCxGlTn1gdIsd7fjPb33nXYNrb+8cffnFRmrbWBXBHIMyD50tcjxAo3C+3w/DqMEPq0Zp+eAYnQnSjNFr9Hz8wgzMH7rwHi6evvjixgffYOhyM6n/KfRP46P/51Bp/JA+qGfeXGQXYrA8heq52ehwB7UL8uWrePCtwn4yCggBTVmI21koGv2bhF89Me+90H7e4TseaYRVuL1AAGFKjjqtReeyoXkMzMnCki++KKbDg4PyPrDuBms3fgCnNigfv4/bdh3MDP4Hz5Gs5//vNBwrpaB+yFD0fhhz2IyVOnz0T7QHLADSVmR9Xf3VjARsoDnEJxtGIXi3w5hS4uzb8VrtEehmwCyz0GwNpoHkvBQdofOsjYoP96wE4tPjpwZ5skxIAfT5lsrJFFtAYAqGwzJv2FkW8P2qnXgpcvJoF3H6YPzbhaYM6rFyUA+fJ9GJ8q2cmeDwHr6O1tAL37Xf/I7t9+GFaYfit9tyH0IDLuD5KP4YBZUlNZaQsMLS4aKQg3SXAzCRF9HsT+d/3u4sMxVQB8EwN4AC9trCFCoD36KX1E8M6DejSD98LNtEy/Llnajw7c+QTYVwABPCRzglCSAsa7EmAnZ6eyzfiL6kl6K9uXrKh5ULkK6jRVhTKuAujCsJH6uw0LXIbD0YQmPByPVxyyeUMwIdO9g0wC7q9wYHoK25yTu2LwGG4K2N7HSHIVY9tzyzrFltu6Kf+OoE7QtIkypXeb+Co3DP37/i3AWPbcrSDHoCGtewzY47rZGsB3A8wdprB5LIINsz9gpwdX4D5fAj4DnwHwawHghnZjjPtMRdnQvvyVEYL2lLwz1JnVh4HTqjquymdjDyUxykwmk2f9OP315vtTTJyUScj0c7h83HEEFHfT8c0Ad8k7L/gWxU4AGCf/18+HYHzzbHtk44otbl/7YOC4F3EmIqGBtfzx6+GSi9XvE3uumWfZ/dET6x46g/uf1tCOaNqrfvHrjNkMmuu6XdRqHkfAbvBPkJcGzbqaXRW4Z5eAY+BJA5/JyJptMFJA8mEVtM3hi3uZNwv1yAcoAO4hAX7yGdmxBNh3zAxoM65GvmsCk2mRLSwwk8wAkOzdaXDlRzoxeuDzz7/uF2g6e78O41NC0uF/zcliJd8clLG9Yxz3u5ZqsEhJ8vwEQVSeX/wz+4c3NxP6kXTtj5L0Km+6myxRwLIHj4VeEKHY6xvaJe29zbpmW0Wq0mHITeCavduoX58ynHYYWaoJBe5iA3MJDQDhTkDb9d+pvejVWKf28/aqQGQVVRD5wcsC4c8+PmxiHf145efnmiUuw3B8Go4QZcZJZiTAJgbK609rAHrOb3/eL+vugPvLMD69hPcrqfliU0TnaMya+gv/371H6zk8PZvcBNUnz5ITkU+GzicM9dyThwAAIABJREFUde0QIQl17dd8r7XvFgtQgAyRNDfVkV1aoRXm76DQzESDFa7Jloddl4muG1k1eDdx17G6+f/V9V9eS4F7sc3WAPAVoDp+cp6eyF2VVbRfZpdSvYttvepjE6hEMd9B+qAZV8um7gqlD08vw/j6asMUhtCjjxSrFkrmyS4DyjuAdYc1s/o7srWhwYbjML6smASLgAJmTQXp0R1HNOFsOxw6m7/RhQ0gMGD7rAv9+DiZgLd+g1bvz7HsR2//KVwbdqDcWZXGzlvyL7ipjFlVdX1W26gaLFf3GK5YNQ4C7OKESZ0HPShwr7YohI+EDRycWFsY+E5JluYnaEvAQCrky8WMb9VfRfuiKkwak6OUbMz34eNdM66uOteNjS8kMyFtumhxNA7EOPV9/fznXTs6r+pX4Bi+B/AZANhMbDvu2S3Lr6GyZfdAmnTXB6UW895AXWTZx1MGO5Svk5Czaoht9/HC9N/lfVaZuwowV/WUrlQ0DgjfVJThdIUBY5MK3Jst2wrgVwbVuwPtYkxWLIA311VWb6uOq80re70G4NtwPA3Hb1wys1530ZYvl+ELHPve3u6UdQewCdF8vtvDu38zxm876j/Yl/MFo/Rcvu6U/SW2HeK2n1hUpGqT+TxoQUPk26OhH6+wYXToMsqyh9ouWBe2OuHQ2B14TEYz3eeU91ltlSLQXN2LrGJqLBZX4K3EPsaswF02q4JSNQC+A2iPatrxCC1GyYIH9Is0tC2qKioUHjd+3KzTFug/NeVqxfyuX2UumVm/v+Cn8WwTMkF40YYld53R53s1wP1H4tatAUQ6sHAZviD50p3aELdSzrbHzF6FecoqgU+PcwLOT7+W2JEFJi27xEeu4VDNVVVMeR06tpN5+N1243VSmcX3AYTnY6YxEWDfVr8usZ8Cd4mVispIAXwhqJ6/WGZEsRdxfW17gaa9QO0yfyp6wiLrs4wUNuMqpAAHJpB7tRc2qcVXsICTzEC4wlQimxX6njUJ+uxfBgwN9+fcfDidhvH1t+EwlpxKvC9/ZgpQcvTn/9xnRBkm7Zqx7cFTYOtazYB49CV4u9+bjVbz7bU+sOzHo8kPUyWzKjvcgRlCeDgkmQljiPL+mky/J/BOkWEoy2mbJq7JLInKCtzXsiy8oIcjZGKNaOALgbsP1Pl5fPEMFW3L7VACAAKni2xH/h1CtsJUICSXxjjHEPMdwkZCzKyk5Qo606LNFkDJzHEYv30fRnhXrvS7fAHr/s9hOAPrXri+rzRmcbfjcTh+B+A+iqvMC+Y/4uevr+GM9rtHJ18h205Gy5srMQ+JygDaYR9DB+D7O2BWLs79VwMi78S07FVEevmiIkdVqpm6medlpp7K+6yeDCLVrgbgQQJjTjsmpOOGz15nNAXudXaT1LJvqNW0gaYX9ebVH9DlTb6/B+DLuTrwKAA2BUWXyZslNvbKRIV9F3RYhZTgcNWsv31ZYNJh14LLxufB0JA/MZHNXf2sNvv4428NwJ0j0vC9n4mJ/+f9AfcStt0H7iFTZRdXHNVhzgoN/Zi14G4KWJbdEXehgRXhw6LCCERjq4l/JkMYYn7fVthvywRsDpgJsJ8xiMcNAHayrgL3lnUmq8sB/IhxrJH9Mig72wQ/KVNh/8VzLa0K2iuZ8PwjyjIEZi1lC8T6g/fyfEbG6vL1YUAG2F80PmnnWq7YAr0kM74kq/B7c/78HM4QYeaeWGNr2+OP3zsAdz6z3LiH4fzxPpzf7jOZ1eH0NIwv3ywhUriowGQVVebvkJH8GV27kg7F+8s1Kvgsewy0hz7uyfHWLSZi3/3lmGfh6/qrMvmWoN1p2G8OsCtwr1pcTZV8AH+ymrc8gBcpylcH7UKJSTEQLq4wnwWRcZiNKeb7u824Cl/WVW3XtGgeozJspC7KTIVkphG04wcN1sXbX/eVkIkORT/+Noygr13jhxIO6yNwh4ee8eU7Sh2mX1hYEDVtNfax+621r4Z+XGPxdm4TeCAuj5U2X7RGigovl639l/nRe2Ln56u7si/pc8+4APYdXgvEc8AOstn2U3XNk/aoo4x7DyuWtUEA+GBYMNC/0Uc1ACBDuDT0Oq0X9rECWBdVKSq8NLW4OitIGVfVcbVs6a5cOimZCas05HtvVrpwGYzk446YYwLu338M4/FpndnDrKlv6OB7b9rrOds+QxmzvJNZw861B9nipoCphPHaNfSj0GZXLIZBKeBbLokY442zCB8XFXZLiS9Bfyv0P6E+RbdJciYePKI3cCcZDGnYr7hMOnWtwL2TIcubcQvVAng4qR/H4YDyDfz/s+17fiLmLxq+ZKsyxgJkLCgSN1BT5WVonWBHgT5w/wPHVZvIBB1Xy6dRa3SygJPMvA7j08vyFiQLvAXjyLSB8cjf/hwwB8A9/Mim334M42kd4A7aUHNTcUdZU5l8C8D78lcBngiLF6yry/lTQz8W2OsqRZ0P23E4DCCBXXNttLUduyvy8US39d4yIc3gnTucok62ZTR7q6vA/eozwgD8MEIkmqfhcAQnvQnApwibdUB7IYIVFxfrWmTTku1X0B+cwsHxSx1XZTZfsxRKZiDKDDDEGclMDyDvPwsm77KsO2z0qx6I1zQknfov6AwPCZjGJwCg2RemeFB3KTECS6G2/dUEE4jipQogJa0C0q1fEMr2Tg6RxStrzxWY7NX5rIXeLelk0/ta8syFbbMtgXrhX0e/teXf6voreaJF2SrwfrMOpyWmUuBeYq11y04XVJSoATzSx8NhuAQYeCJw+gL3yg+7qJqoUNjEHKSJmxEXNGGg0HHVxnxXx9V1l3qm9ahkphSsz9YNpKm3Hx8C5IEPAwBRDA0JyYRu/dfL8TdhB5M19Z/3E1t8xrbD4bFgHynRzKZwEOra7U2ghn7c31sInBrIW0EaYwm2+CALAG9BUdNfYQWLaVPAPQzmC/vpNWMlwP32HU5LrKbAvcRa25RlCrPR6uaO4FjGJDSrMoElH6qS71phu76xi8F7RX/kuArX/l824+qqtt5mRd1UL1wy8/wSX2ApEM/njGsnQ4bwPw6Xy/AFB7i3n7eftMvZ8mUYn15XuUHAg86dZU2FW8/xFexVGp60EOAEi5sbQPQZQGffm3p773iwUpY9uMnI7FK0fIoKz/tnAD62vHjr01bb0KfMAt44Bf3dj8NpiYUUuJdYa9uyHoAfTyb7GjHw3QGlQFYSAtNZoxQj7mWLVU0UfvFsZEjQ7EKsd4iZrBlXs5O7TgEEnJA46IeJ0uBTRIt1KJzrFIhnf3MJmSDjbvf3bB2ThVs1ewhIPsbnlYC7y5p6B8mrPLYd91oyrABDmKLigsHisPdo6Mct3xFhX0UsO28zJXT1+i5cOsVrja1lf1R8Bw39DRxU4XZhE0dVN86EQWaA/a7065IFqcBdYqXrlokAeIwFLwQs4gfItFeB7eeoSzyQecGixywqvAjl7jYtiJ2sjquVE9ahGvgKPwHz+d3mPaB5Ze+Dv8H3eh9sankEUHcgVRifX1gs8g5zw5oAoPn15//cTfx7CP04vkLcdggUwKCRGH8VoC+/KEpk3u4rJGnf5Xad1jCZEvM9qxpFw7qI9lfQpkkM6tLH0P9OLevQjrspcMdzMH/Gu3Y4LVlVCtxLrHXdsrSATfZVZCKPJ9TA9wHwAsBbxHwL2pMatKgpYWFbLLw52WA15LgK7LsmP5HOVp9yxH4+vxonwV6gXDg6uG1BCQjM+8Z9C4coLnZ4eh7Gb9+NHrfz726yptr1doDbCevIu1BjFeEkIdJnxTT0Y+fF2dpcNcvuGIWyERStr8o+bDUO3FOD9D/5mwN3BO9nc4K+3GzCpLJ1kC+twD1vo72VYIyjzdDWB8ALPuqCIpO1igovjVxcPV0BsJc7vAcSpkY/s+S4SjHf1XF1uxeCosy8QjjD06YAGqOl/PyJDsu3/ps5+/r6/6aHA4b4426ypmIc7tdvLsssv2BETCUGVoxkEVYyunbIjvpw1/5NK3C1ysCyU44V/HjYnhanudwIKioWr7PcGKa/SwF7qEXz6OLByQcVKwmDxf+ngN0zkQL39tV1xRYIbTYD+AKULCoqKpQ2XFETBYVZ0Zj4IrjVApD7+DDxqtVxddNFj6H5QDKDTtpb/SA05OdwhggzN54R1Mg/fpuSw5REa0iZ+16ypiLbfhgOL99MvPvYDYsYs4gLGuuCLE9DP271Ymf7wYgxANr922zhJcqyg8L1IC5edyjgzfNvIIybf0nDj7uB1t0BdhPtreDEnJ3bOymgwP0uJpIDeAA3AHREEhrOKWUsIcbG4oLhDguGVBJyIUWa+MyaD+jdRqeOq1d4XcD6o3Gw3Fgy4xIy3XJyIby1OA3HH3/rn6jtjrKmouM/+VPkyFUxsKLXJVGBQj++QwIrACmN++cV3tC76RK17CYIRFIeJ55/ccG5CYurFVcw/VnJuA/e+WAWt05UcY1Jd4D9a4C9V39RCyhwv6vFsQDwoIEPObEWoWNjIvH3RFxwbvoY/R2coBRP4FVgj+rfcvpWYCKk2c0oPPzsinDmuEoh2yqf+64W4EoPY6PMYGIm1B9v9HMJmf68XdadIvQAcAeH9p4/dOL9OZzfb1hOZNn28eXbcDg9y/a5YkwRrwBZejX0Y89FWddWlGXnZ69imYxFx3VDKiCaixfklNKCjS30/aNP/9RD9bVD2AouOoxl1+8rw2ntzOfqKXDPWegm/+4APDAIxMBzAF8AMguKyr56CYuK+xIWtBstZ9up99geHPr3yanPwHcMi4WOq/TRvYNkPTew0FHy8e2HSX6y0Q+uajHB0OfnRj127sY6XR5//D6PztNBLnM3WVOPx+H4+t1kSQ38FntCOU4KXvfj2oJ8Aer43nnRFzQnZdl5k8XzX1zB9CaqJiq0NAirxgU31G3oC2vKVfbnj4D2H0h8iM6nndotmPobLqrA/YYnLz90ik2NmxNkensaRgwjCR8ofr7uAaahDSGg9rsLUeH5p5P1xxxRfa4g1q2/hZinCjwbMI6w8aDj6od1LAt4voqeRQulLWBmz0hmIFxf5VorNTPpuBFgwe3KRv2WjjNW3gH3v00x8ekjOfPYLu/QSYk+P8or76GG3R8Pr6/DiGw7P6LHB4j7hghnxDhM08D5XUM/XnUZQHS20xPTsqdEI2ykorlPPVlBA6KiokJR8O4jgTynXtkf4n5bVwF7y9JX4N5ivZupywE8Ot4QgIeNKgNERKqaIp3L3Gyi9mOWFoIoD0tLt52p9XQ/wBhcILoGRCABx9WD8FB0MwtoJwOlEJEgmUk5EXYeLjCjX3/9zzBAQqbc+9K57+bmyGbffwzjsa/MyNjFhsxsHugVGoDX9HjEUJnjeMxGzHAHfekGEmMnrQQLDvw3eRi8wlR17dKy7DD36IBa8xOvAWq8uEIhuV3efirCDLfKEsjnof3CpOpwWrPKYnUUuPe05u7bigF4ACP+Bla8nxVXWJpL1ITwoMFbZ1X8c0KIXZ9g91SRMsfF5thkXP3UjKurvwQXTIaCkpkNo8x8/fo5XN7eTEzh2o/96rYJdOAfdqAIjV9GG0dHjcAdky/dYqx7eMvH4fDyMoxPLy4RWwqS8L0D9w0RVloWwtCPtJausSYeuU/Hsod8v0QTOlmvsLipSJViYk02OU3t5yfZXbx59+98hH4ryzukzCAtYEc5jIY6zU+KrIQCd5md7qzUDMCPVkJjPenpoy4C0YgC6o3D9y5xM+KCZlyB4rH7gdDFdlnSGuNgc35/Hy6f78qm1a+MRE0zSyMkZsIMl4XroXJMl68vy7rfGEgl4P76fRifjBwkjsS9jzBJaSKSmpvOmjpj28eZcDDHJ84glwhcsUIY+vFtAPCuvw0tMGPZY07aosm8G+A+O0d459DQRbj/fTRlAjabOZx+SXVlGy6Gm+9KgfvNT2HTAzBumSQ0yGIyBj6Li7IF0iOsksoU9unp3AnP8y3HvxqkQZcBd+JULoOJFkEJVfiW1zRhWhks4MAoRJkRRgJptRxFUIE5lfqHtPbZoz7ZCnwDnr0MtJxxD7HwHLiT3dmYbjdrqmHbR8a2x27eslMgxnommcz54324aOjHrFm7Fkiy7Lwn8WRWgnf/i1PQX0FR4VWQwe2Bdv27gJBsBuv6oF31612XbaIxBe5bWXrX/RADD5DdJp8YjzZTpZjRLATTOfScNZhAMsMId8mWWQPSZ8Oc7XCX4fwFjquWXbtFx8bsHFyzAMQnfxqOG0pmgCU10pAbksukgLt0+rgzK9WxCcnOb3/dlj0MXBmG8TiMkJGXya1IDhfLDhkUN0gBFeD2r3cb+vHGbm2k62Rv5UQsewy4C6QsdimVP7Z00bCWxVXEBefDtjHd6R9TktI5kLfZTaGiOpyWL4W6Ggrc6+x2p7UCAB4TUiySOfkal0ZGWYz5C+h5y7KHAHtsU2oG7nQY4fstbGbguAqOaBijttFWd7r0ah9rfH7BrKqbSGYArL79hVKo2/lVSItCQN1/4DOwx78wjvtNHWTw/eNs+3zzKQLtBcANpFbGVho6dpN3B7KJPz1NIVBFeFZUaAF4y59n7X4q2rfse/zmefpymdYJ6YN2XTOclq+BphoK3JvMd6+VGYAHZgrB+yIFtBhtp61U1EwBcA+AaH8g4eNH0YDCz+Y1gY6rn582bCRoWxW8d3l1Zvpt42C47u8ynD8/hzNGUrkh1h2g6tMzRk8xoWAFvxR4tw5n5483ljxodeMLBi0pEmbbqWYMuPOW+S4k8u+FAx/o2m81bKbErLsoYw5lhxOEPgbCCRxQ7cCKsGxR4RJlSs1gTJ2iIRUVXmRQnd6F+aQaU16MvAZjr5/Rp0t/m1tAgfvmJr+lDpMAnmLBCxBy6pmLvvdFhWdALnTxGdrTm1j31LkCCAp0XP2ljqs93wFYo8fTcPz+2yZRZlzs8o9bYt2H4YDA/Yc8/F1I/+6+6FavfXNZUy3bDrc0z3DQ8/cTCWyfFi++7oSRYsoKDP0IunYN/djztQ+2BSw7xGU/ehFjCnGsGClXtUsoXCjFiaHoqDGJFCobHIWG9Jt1rTiHUwvWNcPp6ss50YEC92ta/3b6ZgwxOPogAw+JK0IhtQqfqpBEj9KqDIXHMqWGiAvMgsrojCrg7lP3CRMg+47SGeu4yg9HhabT4tPlBYT0G79BlBkho1xrPBuD+/zzz5ti3eF9Hb/9NhzGwsNvxE4m6+efuJZv5oc3NBC3fa5tX45/CeBDr7iEbcfsyhD6EW9obsZSNzRQy7JjhvCArLMMv9rnFlYSFgsbU1hZWGzeR1kl+gTx8JDTGf2Cyxbe98tFI8Ts5MVQ4L6TibiRYTB6CQH8E5PQCAFTMVAH03BuPPD1Y22Gmg9tY/NWGr+ohdURvJPj6uenjQ3On/NGlsNehlkS8rDDmBG0/vwnyp9u5QeH7fHHb+aw3fKzX3m8eUAb3BBwByEFsu1edB0WIYMO7gTds7xoCiNh6MefGvqxZb3l6oIDKrLsNpxxrHwZlpVrU9Zq13+ODfqZAXf4RgGhpQ6nuRV4jb8rcL+G1W+/Twbg8XqygIEvBLnGVgWVmFMqr+Xve9cE7o7NQMfVd+PsCGxG6bPe/kLq9wQwwcfjcPwOiZlO/doNtYTp6m/IMZPkRD/+Zpz1Wn72635zWVMd2/59wIhZ2Z+B7jM9ewoU+ggfQz/+MhIZ/XW2QIZlD76zNUMQoOWcVGrRbZ2URaZxZzfjsgqz0eGZnAN21K8LbFBjWq3TYgEF7i3W07qgdbVIWQrgC2Qlc/smwLv3J591z21nVfIYGlzBmSKMAclxFcJGAnjno9UVVmoB1HK/fm8HqJmOXdZQSKQjDpla+jSdylvQevzt9zq7BDQht5g1FdfGyzeRzt8Xy/i4fAboF9jGy+Ow9/XRaZmt34zdG6UsOw2oEitnQWsTphVWXmvsfLIQrFuHjfOXOpyuv5Bbe1Dg3mpBrY9vfB2AFxkvra1xSR0ZgA6xZNkrb2TXKlF4ZTX3+M5x1UaeuLGIJaJp3KKQi1n+DZPrFN3UlI7vMgxfIIOAhEzgqLVncGbtcvzxe5kDL48s44H3m8qa6qRUP4bxlGbbJe6pi73Ew2Bgm/Obhn4sfaXS5Q2CRUkM+lexJIG5joQYed6MsJKwWHiIgsqCIuFxC754BNjh5he+OepwmltJe/m7Ave9zMR9jIMDeNhkrYQGrudJW1sFcoWVbDHBljUz9wT0hf2EJqu66lTxAuG11HG17VVwUWbWl8zADYlJyLTzhDoEXH/8NozHJ5l9fadpz4PtDE6Xf92Og66EbacETIaKsE55nrWCewsHVxD6EZKu3ZLTrmxFXKkUY9nRpyqjZY+NshoAZx67uN0Z1V1m0+K+IhUAsMOfKJyjAvayebh+aQXu15+DexyBTc5gWREE8JAMg6LQUNgXMdgVFGQ0u4Rx91u0fE77ZAiGOu9krh0yjqtfJuMqOP65OF3FDbc/y822cBkOEGVmbckM6JghJCKw7nuWOBFw//7bMJ6EwD0KgAwYOMMB8+0GgHsF206RpuiNC8GfoFRGQz923jF8ln1Ept3MRyGKLSwubr+4XTJRRcXiKv5VEAB2vN61DHtxg53nV5urtIAC90rDaTWpBYipo/TTp5NNMw6fPquPT7YlAKwBmQw0KWXeJ4kMOaQJ+uQd8C+8sGr8kU0DcN2ujqvSReaV45KZYLzuynYD1S5fn5Z137FchoPX5+fyh/fjxQFwvyHn3MMJ/B5eRRF1JFIZbkC3xwAe0tCP5WsrVQO/GSZyWSjmflFnYq14BZitqCI+GPCHLO7HHnEQrNsIMepwWrRsdlpYgftOJ+b+hsUB/HgahicG4KP6YM5rZUwiAO8xJp6Hm6xi3pvAus/rcemMcXJD9h0dV/UntgBJZiDpUEbXLG4zBNxBGvHzLzxk7fZXe5Dx5TJ4orTJl24hayo99zeKJJN+Uef5HMLQakEGEJjS0I9dl/9hPA4Dv6V1rRejV1OzuJqwgrBY2DiFlUuKU3QY+L8g5dMMp13X55UbU+B+5Ql4vO5nAN5sziNs0kFno3LgHrreDjHv8094JfIuGF56ohOUPW68VjcL0hncgCU3FY+3tJZPDJIZYFt/1EVTEZkQMmN+Due//rnfhEwOuL8GY5hHHzMF3G8kayomnnqFSDL5MJip2O2p2zsIoYc3EBr6UfTGxEGscTgl3yhi2fnuPBHnBSi2oOg0NmElYbG4YYQNCIvBwdrFX1eH04b1uOuqCtx3PT33PDgO4A8WwFMSDcfAFwBqD0TPleNz0mX5t4J+QnPSWD2bYAqJTor5/msYvmx83T1HMtnD2q0FrIVj338yIvjqj8P48or/rzUCjsmaeiO3DK/fbSSZvJ4tJZOJAfcDKBA+342fg0aDKnxzvOLj0flCTVr2peTRzIUAyQqKbAaok5YRDjRVbAbYNcNp20LcfW0F7rufonsfoGP1DoO5Hj0ZxgUdWeHhy1Ex4dmcrHGO9cv7mU1NY/X5NIcbmxxXf5qsneq4mn87ELwfh/E7hAJsdMyM9YbJdt5RMrPn0JCYNfT1ez1wt+8qrEO4Ydh71tQ82047BB3sIZKMefdEwBDKfWnox/xLmClhtezD6TiMuHmTA6qp5x+5pHPjehXi4vkohZWExaa2+ZorrBwqjhFi0MFCHU6bF+LNNKDA/Wam6t4Hyq/lgXmBWL2QkZUi0eSenzKm0ubmYV+fZfdBfXUMdz6uKvDuc3n5RmaOqxiKsO6AkzPp3fwdMgKCJAv07q2ZQyNGQRYawCwkZNrpD2VD376LZCOpR4Dbn69/QhhMeNb8et3cHM4Z12fbDSSfj3n6bwkgnL2tqGu30Z82f8j76JBr2Q/jwaQEsY/mKxG3k8nQOsnY2AfSKT3VrKlCwM7rUlUC7C5hUkOb97GUHukpFLg/0mzfxLM6FnkchnEsAvCpZEy5Z68C7iHxZa6jxd85nyQH4Mi+g+MqAAcA7/qLW2ATyQyEhvyF4SH3KpmY9P6VYJsY9zMA9/9v1/HrHdsOBzWHaXzQPl8yRVIZ1LW/DxfUtVu/E30HZRZA5RZp2SlizLQm0/i3EKAWFjcPIKwkLBY2SmFlKO4ynJ7x3cOkSfp7RAsocH/EWb+JZ8YMEUCOcQCfyZjHWfcMNgkz8BWAJi+dTZibc0ppUBFsRB1X5Ut5A8kMfEgxIROw7jv0P4AbrPHbb823DrsOgcnZ9qeTyejswFj6/Z4SMOW5d0yU5nTt8mWoJWFPN1r2ERPzzWUx3D7+7lgEqn1DF+JkMXgvwPn+MVG8FihhEoF1TZgkNt2dFlTgfqcTez+P5QD8wTLwz4aFj6W89u9XrSVC/7yEyvARMRkTiyQAFXh/rtzk/ZUDeHVcFS73tSUzmJDpzSZk2hsLexmG42k4/vhbnVSGxXLfe9ZUPKBA8i2rl5YC95CyPcj+onPuz13LooRvxHbFGMs+wPzM5kYYetMdwAqG7etuxFUzSL/4IFBxknD69fNwgYAECtjFs3fnBRW43/kE38/jcUdMktAcnwfURXJ204LoEKPuw+Pwf1ehcGPnhqqtDajjqmSpI3roFl0l1CM4KyLrjr4HzQtC8lCyMhjX/jgcf/xex7jTAXrPWVNxjxgx/OP49GTsL5TJgBFFUhl7ONt13H7Ziti2lMeyU3a8HK5e7uMViLmiyjaMe+BYiGO1DqeOYa96gG3nV3vb0gIK3Le0tvbVwwJsqz+QBt4CeOvcFALQvpI8NpIqrTtvrAmrNVU2fNT5jLrb88cvq7XucqLoMXH7aIMkM99+GHDX+wfA7u2v/cX0thISBO4QdlXy47dd9L8pgs5OtfwQkQrZdueEHPIgpIfnsDEH3U0diB4EfiV79WOQTOtmZTjLDvMCBynYo42ppx+cr+DMxVyHY7OWFzFFnk6Mfb2BpfTu4jZDY/IqE2A/Q3yIVUo7AAAgAElEQVRR0q83dbDZNGtHm1tAgfvmJtcOO1nAhh9AyQwB+CfzwaaPw/zb4OJJpLbDZuBOfVZh8KpKC3sax1UAGL+M42q5+qbTHO23GQR43yHKjBDEFjzK+fNjfwmZHHD/G4ZbLfoxmQwgrPP7mzmY7CluOXdAfnphwb/9xU//HXop0rAQtP3nNwDt6gwuWj8+yw6VYlehAtAuO1r1BO6Zp2zG1SYLMTYD75I6nIqWlRYaFLjrIrh1C/gA/mSSeFA2Vi8OMH076Kn9q9pm4F6NvasrhifQproGgAWOdEYfqRlXjbEMaDMJib51l7RgnPOffw67klMQcP/+G/qIVP0wXrTV8b+/BUIrVrXarRIexiDc5SKSDH/rw6dYDtmjunYN/ZifK7vO8FYHstbinpPf20LHK58DMXt1BVoWVxEXnOxQUcU8hhd/XSPE5NeWliALKHDXtXAvFgBQYYEpJPTAOPBMQuPpZ4IfZ2uKJvAecY7NW5l/3GIsYb4VvwRKZyA5EEhnNOMq++BCYibQQ38fRmJoy80bqQEJmT4QvO+GlSZGGiVCz/InZdp2gzeMFGh/hxI4iIG23Wfbffg3HdxC6CuIwzT0o3y9wO0nRIyBWx0/oA/f1qyh8Z88HaNPplSB9dCIxSA7UzB1yshZigN2dTjNWUv/HraAAnddGfdmAc7A21jBwMAfjxhlYsqNuPwczL8zeZYoaLkq4O4r8Cv7jsFI+Fh8fZqY7xCqkCe7urfpL3oeG2kFQiRKdd/C9jEhE7Dunx/CGisXm4VJfBaxoLhOvN/lDMB9R89F4wPHW9C20zy6occPwVP4R+OYGlNxaOjH3NoEG4/G9gDaKWme85Gw9fly8pgTX8C0LCpG3fHBipoQFZrLD3NV8O/AsDM5TODdyllZ/64WsBZQ4K5L4V4t4AF4yMIKLDxkZQUAD6w8u3hdQudK8FxcLUVL9Z0b47j6hg52hgmG9osH3HdQO2htfH5B5l1ypS8eLjlxvv21D9bdacC/DfC8yWdNgAoE7pAhFrOm7uBnD6Emkow9kFigNHd3XBxBmOuHCQMb/Gnox8QkW7gNUb6OT8N4sr4TLhMe0em0FzMA72173Dm1EXmHq+fANdYSFTLtB24PFh0H9esFfezg9dIh7NICCtx3OS06qL4WIIYZwPqRNPDmKtew8OEfl8xwdm5R2tfdhE4EoidaH0RjzHfMuKqOq+YDvJ5kBhMy/WUTMl37gMSdN59fG4C7TTK1l3CX8PIC207a9uB7Fr4Gy0Yo0dCPCQwNYWBgPwWW/TnMsicY9uUxapnZgspM22kF6K2oMiHzzKYdaxsBO0SHOZvgAKpfF339tJDYAgrcxabSgrdvAQ7gwXnVaTGNA1VIsGKIFZ8VLzBFlXSGf7J8JqgDuOcZV9Vx1YB3SE4EjptdJTOX4QvkSRCJBK7JBU56BSursKhZyVmH3MwVPgARE6f+2s9jD10H+0yobecvm48aSQ4zfyEJvC99XoyfgoZ+jEBs60c0gqMzv7njIUQBvHINTGLFyvC1rNSsm+IqwgqhYlGHU1+uVfjqanG1wNwCCtx1RTygBZzGmxgjcqaKR0Coclhtlq6HQHq/j4A6rtq1Tzf+Ty/D+A2izIzdXgpMyISs+z4SMiVlQQLd7a6yplq2HSLJjE7bzpFiCMjzd8qgryAG+/wczhirHkI/djgsd1tR12zI0hg+y05D4utneRJaDFwIkdlL2vDs4s6EBXmxmcMphN8VttHwOFr1oS2gwP2hp//RH94D8CYSDUhoDkEJzaSKL/yQF7PuKYa/A3BnH1UT8/0Tte/ouPqoQd9rnDcl7w/KLX4OZ0jaswPbHkDW8O0Hru85MykDGxgt520P0XJgvJAF92XS7OMjhCjeMMsOpYP4EnTtGvqRLQ9r0xjLzheSL1ZPAHgJGW+qy9Zm8HWUdFJzpIB2EbCrw6lkG9QyXS2gwL2rObWx27QAA/DDkSVzsgCewwH41E/X64UAnqwjqhb74okqF87DBTOuQmIdjPm+BxlE4RN0KY4MLkhmIDpJYZKixADgQPT15z8Ne3tVucxgQvW9WuBOY5nJG6wEJfQ8e8qaivKmIx5CRszZQNS5D/L8U3MGBmrox+BKNnHZn4cRYuRL1rDM23Th4xnH+ZXgXVyNEyKJSuRwCqEcNcNpl21XGym2gAL3YpNphfu1AH1sBsi+yrOxThr4JSwoANLN0hmfI+SfuYJxRGYQHVeBUYXkOgDeHzRs5MFKZg6dJDNg1/PPfcQ+NxljfzNJivxf7op/N1lTDcgybDtztMXxh26rQrdUcwBPzO7lAyQydv23v1I3vFcSyw774GlYaNlTT5ZbR17dEEz2t8qiiC+zGwDpFGQQPslh1OFUalAtt54FFLivZ1tt+WYt4BjIMIDnz1WsfQ9RSkUAYckgmvEUNRKfGgBnwCQR++4OM53a3/ui4JKZZ0hU1OO5L8P582M4/3VliQneKByH44/fhqpDCcl+3n9ddxZxjizbfqQDSOrF8vUS4fCP4Hh7fvtp/BEe+mftBaFzQVolYdkLwHrsTiRwkmyfhSLGPdCdA+xfw2WWMKmDZLH96bSFx7SAAvfHnHd9apEFuIQAGfhnGwveaODhx78L5l8agF5V1S40/sIcxnH113B+fx+GCwGZqgGKTL2rQi7KzI9ukhmXuAhi6F/rZwHv8cffwox7Zlz7yJpq2XaIvY9s+/wYPX+EiVX3Yb1/V4XPBrr2a87PtdaF3y9lnobQuSNYSvDeS4C7NXoMS4dlMmLk7U+9+e+49sZ7aq8fAuxfXygjxKhQ+lML7MMCCtz3MQ86il1bgLPOHoAnvef0aRN85FIP21hdLhXIW3xyXP05QHSUPThX5kfdo4T5iKNkBrJxhmQlpd1AWOfPd8ymejUfAnubcPzxe9UzGeD+p/GDuNZvwbbHITlBsRwXD+taQz/aCUWW/cn6DZRsRoyBdoRHgNmQR4hMA+vY+lsyKQmVjbdC8D+Nv4/Tr0sOJNd6F7TfR7WAAvdHnXl97goLcAB/sBr4p2fDSlkGfhKyhD96yUROoSGFcEnF0KcqhQ3ymO+fD+S4SpKZF5aRE9F8AsyEfALYrQ06AEPWUYzec4UfPdOP34ZxlDrfToAMbw1+XnH8hC1nbDu/cUpkQI2YG2qfHz30I0zxeEAtO2RAFbPsZNMQuPW2mZiOffnvqeNW5p0pIudZ4ZnD6acB7vpTC+zXAgrc9zs3OrLdWoBLaByAhw/e6MJIhgQs0yepgMlaRwnDTCsby0M6rtrIJUcInwiJZmLOuj5w4dFaZv97GM6/fhkd9TUSMhFwh0gs8DzRX1i/i5lgMfnSlaLjOLadxW33niGH3fzXCW4/zm8QCvWKtwjX3uiqWXY78AQrXSaLgfZyMxgxVnE1Q/1fhvMwfPkZTlW/fu0lqf0nLaDAXReIWqDeAnTva6POQBx4x8DHk/jkWPnkeKbK9cOe1ZQBd/ykAjMFmk9wXAX2/SEcVy/GQQ9CKJJkhgP4FGgHo3kMvUnI9E+bkKnTFEqb4Y63TwDc5XOP83+msJbXy5qKc/HyGj0gS02BrxFGyfk1XK7tbCsddM9yxLKDjh32LVinkjCPszHY/S80Lsa458D7dJgqRt/izKzzYVP8dQXsPZeUtrWZBRS4b2Zq7eiOLeADePgYPg8HiHgBjl4Y+336FUeiiVmuDHdl7B9qLMa8fqET30M4rjrJzOswPr1M4AZAjlT/6pX9AidICDm4Nes+k/9Aqno6XPJ59ud8+m+MjHMtjT4/dECSNOZ1WAH38I08Y+hHyI56vYPI1TbFg9WyQ3z2EsAuXfP2wVJzM2F7WmM1MynoCIvAHg2A/YKHZnU4vdrK047bLaDAvd2G2oJagCwQAvBPAyQvAUbrEmE4DWTugMJjTXDZaPNkmU6M46qN+X7vjqtWMgOs+4igse0HYQcn1r3DvEuHEzuEzOqHDmvm385wWHv762pAFw7D4yuL2z47DJv/iEJAX+ZkQz8ap+sH+dn5h1j+VSx7IWhnu2IkuMsGenbUr4NnuDqcPsgqf4THVOD+CLOsz3gFCxBQwNBq9kOJGR7nV9Lch8sw8QZ6zJ1YTVg7MVO/KhZkWh0X8/2Xkc6gUxc83xXsvUGXAHa6RJm5Wjx01EfYxEVwe8DlXHHAbk9qBrhfg6F22nzQtp/i4Dy2Buy7SPIYYF5dluAN1s1uugB/HJAaSVl258tjiYUYcA84ovou8ERNzDn1CoZdSs4TYEf9+qfdm3YzEzoQtUCLBRS4t1hP66oFshbgAB4ieTydEHz4AD7UzhzUT25bWYY+99XkwLrYD2s5qslx9Rc6euFIS67fs0bcQQECjy6iSdvp5Pz1iRFmriHTGOEZXr6xOfKvZAL/DaTl+xs61w7g0Lfx6cwcmr45bbu/IqJL3oJNvPGC/41hOT/QT+Matt98JTuW/WhZdiPfE/0qGXZoOw7JfVmWaCRyn1WeMAmcqF2EmOKNTjgwLaYW2NwCCtw3N7l2+JgWcFf1B5TODBAr2QJ4I6MxvxRYn8pYuYqtJWLi/YZpFpq/Z6bhuePq5306rjrJzHcrmRECoMCKh8MORJe5RsIf42wLIDjkQO0F2naegyZBEThzbvpj2na4ueK/EFhfjA1fmommBWkMRvW5VmScTY0HGwqw7NNeU9Q9Z9wT5LhMx843HH+nE4wqR847wP5pck64Q0fzBicYnBZRC2xqAQXum5pbO1ML+AAeIjrYDIUcwOcMNQlWfFkNwmh7CCgElj4SKqyOEAkyrr6/o6zCgCP6SOee6Hb+DgDSSGaODYO+mPjhV3D2nEt+PEQUwTnTQWP7sIlmvKBtj0dqEjkKQ+hHcAy+Vhz9htVSVBX3mHEiCMBuK7LsMUw9305yyDvyhMlqNqQjOHmjwykH7EUW08JqgVuygAL3W5otHesdWYAB+AHivz8BgLfJTzASjfn53y0Ry8jMJGLjfbPGOuGDSoB657gKsgr4mDrG8x7mzyBbCEk4PocdJfNPaWYVExr9+mvzTKTm4AHhLSOT6KsZIIAOxjv/a7h8bpg8asa2wyFpGq9boiI5h4kAdP6499CPduJsbgl0pJYCdlq0jmWPRE1ie0Md055/O2YlQp1wh1OKEIN7jLLrhdbV4rdpAQXutzlvOuq7sQACeHiacYgBeAlXFcfaVspS4twqNW6KkQegBI5hAJbuzXF1FpoQwipWXE0gcgcweQWHz+NxOH7/zcTu9uXsMwA3ORpj8qW//rQHMekCaS/H2fbZGqeDrwS441r8NCE47zX0IzngogzveRilLLvEfmwaJ9GRZG4lO1eiHb+6y3AK7Lo6nEpmQMvcpQUUuN/ltOpD3Z4FfAAPEhqIRgMf4AAzKtHCkxEMrJzr4rmBqlj5mIU9DIvSmY8PZDvvy3H1gjckKJkBsFT1uyCT/QVyma3CElqd/vEHAPeA9CQC5EAq8/WnBe61B5USG9Hh6OXbcHiycdtLwDoHm6BrR9B+j6EfiWWH6FVPJiOudH4kUWLs+0zbkxyKy0sGGXa+wanDacmbo2Xv3wIK3O9/jvUJb8oC7qraMvAI4CcJDUFwma50/uQmEVT6gxoH8RXX0Pbji5GUgfGELJUotahoa6eTaCK0hPTXnt4E/9MXQBk5whfcSrxtlJDJAuIJuFtW3VGp4fVxBmfaP7eNggO+H1lte25dYOhNm+k3V/ZG/26c3QUseyG7TuYIseyTjw2X81WCdd4RnwN1OL3RFanDXtkCCtxXNrA2rxaoswDXmoIGHjOxWgBvGfhyvXs6qhp3eK0bdLqWYd9/WcdVyFZJx5A1etugTcYKj0/PFpinxAThexKIguFYdylbWvt4NObvP4axwLn2DKz1Vo60FMIQ/AhcltSKB0YpEoR+vE4Iy4oRC6twLfvJsuyZd6kCtKf8a8J7TwNwd1WtwykmTPq0GU4b2hVaVIupBW7IAgrcb2iydKiPaAEnoQFmFAD8EyZRQcdC68SK3+SIzLoU3MdM3EtOM2VcJcfVO5hU0IxTlBl/HiSXC5gQ6Nc2MdIJuH/7YRLxCH8YAWfDrKkYaen1NRKyUjZouN0xEhk6JMrq7buUWVAY0QhY9lEYMaYAuIdgsr+PTP/NnSQKATYvrg6n+152Oro9WUCB+55mQ8eiFohbgOJrBwA8oXZfiUGN8Xtt+28xjbxfJTUjIemNCOBjxlUIG/lruHzdR8bVKTa65/DJCXg+Px7AR0abnD/XZN1njrXzuOiptQfM9QSCK51xJa83se3Plm2vtQVGwXkzToz39MNMzBCX/Qn92ZOJsIQ+ARw/x7YQY8IGkB6aA2guql+/p0nTZ1ELdLWAAveu5tTG1AKrW8AH8CergSfmbQmqXPCQ2BeaVSll6EMHgBB4D8WWNxlX34fzO8R8B1ZUQk+vbuDyDmaSGesc6Nt6pqDxAZDxPdgkIZM31pjFZ9ypjX5z2ShrKrLtL6/DAdjkmp+9wbhGcqua4YrrjEeTTAnY9tCBpoBV533KJDHTSjHvfCG7znE//m+TtA0chjH+umY4FS8DLfjwFlDg/vBLQA1woxbgAB5YOALw9FH3AHwIkXuoOwbaU+x8KdCfOEIzPgTvEIsZ2fcbdlwFHHM8DuO370a+4H5yC20iR3HAHRjtp+HCAGCUbSUHT0iqteYPx3YYDsi2F0RHmaFQCP34MeAh4x5CP8K6ApvA+00+Lr4urhNg96d2KYfpMPlniKQEe5ef4bRD29qEWuAxLKDA/THmWZ/yfi3gAXhgKyGZEzoeGh28+BdD6JkzQO5MIOofpA0YdcZKZ0rGLepgm0IomQG2uGL8wEAi6w42WO2HSHA4vLwMk0NtuDM3r5uMy44BDj8QArKSbYdD4F2FfuzIspdw5N1AO3YK7DpmHBsGiC4FB6rKw8Zqr4U2rBa4HQsocL+dudKRqgUyFiBNK+hgAcAjS2djYOeAZFrcOklpucqj04TMAOKnjQJCH/fcuDuNoUszHptddGiyA9iEdYcjHYSxfH6ZHJxTBoBQkKAX3+pAUcu288Nflwm9UiPEsuM7/GQOgbH3oBAASxxPzVNzEVUJ5Gc2QznMYOQwcJsGTLtmOL3SotJu78gCCtzvaDL1UdQC9psL2Vht1JnxNAxPp2GUAPicqiMC7lFDXwDoU8Q+Rp2BD/37uwGKdBi5pbkdj8P4+i0YtSVnJpAOGdZ9XadKuhnIHi4QfJ2H88+f6ycwsnZbsO18DfAwqRy0wq0AHPpAzgPMbizM0i2so4PVskPUHwLshQCdoDf8X/+1TjummxUqyfkQNCU5nAJABwmc6tdvYcXpGG/LAgrcb2u+dLRqgQILcAYew8dBNAqQ0IAjK7VTIKXxu2YIwDnA+mSdBxxSZ4PZ34A9hRjcDojdluMqRv54/YZsaYqv5NY35Wzs8V8AlO0BrGDKpUVpfC6kKHbN+mNAETTJJob7V5n0SjoYtJCV74TY9hhY5+TuF4R+JF27uOP9FKRoOj7LXgHYOWiXP2Alq04dEGBH/Tow7F/2ABXYEOSD0pJqAbXA0gIK3HVVqAXu3gI+gMdwcpbNy0pRGoA9N6xj6xkAJ6Qe6wLY3s9PTNqEQOBWMq4SCIMEQk9PxewvaIAxZjo+8zo/cHQ0WUnz84vjWTv5ErDtPJLM7BonYwMY369ftx36EXI0gH9EI8vOLSWXxVRAfd443pJBhBjQrwNgbzwErLPktVW1wL1YQIH7vcykPodaIGsBx6hSAhejgU9qaION5sHevFoq6CBIeizbi5UsmifgBgSeDRt5W46rECHFSGaMn0H6N7ttAAwEhxVIHrTSYQXGZIB7PuQiOnyunHwJNfc12nYKVbl2xJvcBNb83bHsx2GAg1RKy55oPweTw1IZLtrKtRDoHMYO/98iw+lt3YzVTJvWUQtc2QIK3K88Adq9WmB7CzAAP4w2Gys4slYCh/kDROlzWyz1d199S0ygEdEbDbOVQ9yI9h0lKS+vA9g5pNePSYcmsAyse+lBSbCkYnryQFVwmL2gdAdi7fceiz3gVEWSgTXxiaFE1xmbwI4tRZBlJ/ma3K5lTDofIIHqCqBOzbD460bDrg6nLUtA66oFKiygwL3CaFpFLXAfFkDwC48yIrDECBYxAM91xuKnXyq4J1e5FFAJAQwD3p3jKmRcXYmNFj9eriAxqpxN5sA3dPigf6MkQgBKe/9wXBBz/sdwGDOAkQ5MK4LjWrYd1oLL5trbRqu1Z/X8IImBQ13hYTnm3ByH4g0gfYb5bcIkAOuqX19tdWjDagGBBRS4C4ykRdQC920BB8oJwNswdIDqCdjh97/WWTISjsYxyRxc5Bh5Ew/6/PFuHVc7AZPVZpgxyugYLP8Z1t1Gc+nJdFPYSgTuGakMSVHWOEDAekJte0XcdlgDoGvHpF238LOHUUimBLIYkE9F5jQnYom9TWSF6Ranw7tBDPsCsN+CzXWMaoG7tIAC97ucVn0otUCNBRwDD4B9NJkan07DgUeh4eHpqsBkWHE7DTcVd4Y9FAAKSOYCAH5FJ84aM4bqGGdQiJue15S7+pSxtHf89FLgDomxVtKQo0Pm03OZBOfmdO0GtB8cyw5RndI3HTnwvlxjHUC6PZsb8brxLXEhHdXhtNdWoO2oBVotoMC91YJaXy1wfxZgsAEBvE3mBKATgScDCeREGgL0a+vQ0UHOsu8Q93wVDXaP2bXyCJDMQJSZggMPRNU599aXE3CPOc56YSFBjtI9+RKaZDSRZEpuIsBxF6KXgOMuhsvsMT8rtwEJ0TCS05xlT0Ht3PHWjNi20MMfFKXqF8hxat4j1K9DPHzSsN+CoVeeR21eLbAPCyhw38c86CjUAnu0AEME4EgH+vdcJkfJYxQAV0lzk+PquwEdax8YRIPyChFQfQWgmo8y42pDDHUAzqjp7/Tj4SoJTPo2o//GUIvQf39JSg3bjqEpEbSvFyqzk5WxmQPlT8BD7xz8xoB77M5pIZFxN2SVI6YBMIfTecKkyna1mlpALbCmBRS4r2ldbVstcB8WAGbbhm10AB6i0OSv/Iuf33fe5A2EYnszph8kM0Y6AyCzBw1ZPPpsBQzDSFFmsqXNY2A0nXcAq52iuvhOs4lxmEyunYEyHmIOlm2PHGJCBwl0lAXfho6HGMkcFJWx6w7ek+MRQ1xeeh1UOVBPLW//b74LSRaw7/PdKZoGLawWuF8LKHC/37nVJ1ML9LYAB/Bw/U8M/AoAvnboADQxbOTHbqUUGEUlpOuO3BQAywzSkH6sN0hMIBQhxE6PO0nCFJhkUP0dZDEM4hNo/hkLndRRA2iHg9kvm5Fzv9INzrIDaE/JXvwAqAZTB7j4EJYu+Tek/0n5YhMmXT5thJhO+vjad1brqQXUAiUWUOBeYi0tqxZQC1hggaABWHhwurMAHiKU9GIXWwwNzKxl33cnqeBsMyQc8n+evpxwnGHdITQk6I77gFZJGEaI031++7M722+07Sdxlk0T+pFAe8viWLEuvgsmpGrVexBi1Dk4p/8tIcQXWDyWMGlFe2jTagG1wBoWUOC+hlW1TbXAw1iAgKYF8MPpNIyg6702gEfd7hmZd2SqIUJGJ8DbY24PI2QulUeZWUPbLdGYY0jKzs6x6KhZEkkGWH/IJLvj6EHEskvlY8uQjWHuvWithYhzdTgtMqEWVgvcgAUUuN/AJOkQ1QL7twAH8ONpGJ4AwEMEGsPKX+2HumgTNtKAdwlduc1oJcDZjYQnQuo0PATQz55cxWv7DCE30Rm0g76eO8XC4U7ycxlz3yWlty/jbpyIZV9KY/igDDz3ELaESacquSDu1BkBdowO82XmT39qAbXAPVhAgfs9zKI+g1pgNxaYAXibHfJ4ZQCPGVeBfd+R46of2UUwgYb9JhAtqJApApKO8fk1frBCydGnkeh0urFAv4inl+EgPMy5/nscHNpNNm/hcBxAq49JrJLP46NuE3oxeAEUciwNJSCOPUs0Qsx+Dqy9p0HbUws8mAUUuD/YhOvjqgW2scAMwI8mvTuxrLlsnWuMEMNRW8dVSGi0lxjgmDn0NZ/BFGzSOfGQi3Djx+JnrO0ZpEbgENr645FshOEwUR4Eh4a9hX4kWRj4dlg/j2RMdYfbrRymBENL/UatNMzFX8eDlv7UAmqBO7SAAvc7nFR9JLXAfizgADyQkoaBhzB5KCjwFTQ83KOQkS1+0B06rpZIZkCvP7HujRIkOjT4tqb/BsdUDL/YR6aCTszPQradDim9s8YWLxivAkbjAZb9iKDdRYGRRHiJAXZOyEuBuj3IYXG4jYCkVJTDoPUZtb5aQC2wZwsocN/z7OjY1AJ3YwEXLeWAMbwxkZMD8BUAlGdqJSP5/+YDUhqDc1wF6cxXNxlI1VzNmGjIqpppBQDtO2Qy7ZAQ6TAOIySEwmy4gR+C51/tfRWy7Zi/c+aXkDNKleULKmEooOFwOg7DjGU/zCUvEiad69kLRjArutCv43XSrvw3ah9N66kF1AJZCyhwz5pIC6gF1AL9LMDDHY6QpOZk/p+THPTrClsKJW2iLpB9BykIRZ3p3HdJcweQzLzMJTORgweOGUIjtui+LZgeX77FZTp0SOgQzQUPac9wSMiAcOgT/BEw4VREB15i1x5l4aAJYR6PFC3Ji8yeYtJTj1sK4lW/3mM2tQ21wK1bQIH7rc+gjl8tcJMW2BrAx4xkgeIAkpAOALVlLjAp0el57ugYOHhgmMv3xvCIAuB+AdugM+xX/WOVsO1QFuQ5wPK39Fk/WlYzwrKHZC0hcB6TztSMzQF2TZhUYz6toxa4MwsocL+zCdXHUQvcmAUYwtmCgU8BeADvIEFpYbJrrV8CcAcb4vIdtOeV8ekFoRmn2PEQCrL2wQYjiZJEknE3IB/1nfWquWDZPUxPpDv/v1CEA3b/fxeNDRImQS6Cy2AcTkHSVSKALzWFQTUAACAASURBVOpMC6sF1AK3YwEF7rczVzpStcA9W2AHAJ7CH358WN37FewNDqPgwJmJvNMccUVwUDDA/WfDQcay1s/Pw5iJJIMKbQg96eLtN5wUqqfNjhckMSDfGgM5CELAvBlPswYwwSncPJwtYKfcAxIBffWDa0W1gFrgdiygwP125kpHqhZ4MAtABA9IH388DeNaGnjfpLOMqyARqWS0G6ZKlFnUJZaqDdUI+nGIkPI8jGDjAKV+Pn81J1/C6CuRSDJcdWJ07RQvvsF4LVUhzKN1mk5eMXgSd3mXCQreOZyeNWGS3KBaUi3wiBZQ4P6Is67PrBa4CQsQzkEADyzo06YA/vz5MVwgHOGmEoUJUGOyooRGxUlZGmJ2g4QFgfvCaZSSL1HG2VIG3EwegPYQ2z7zywTQ6pJjXWdlouMpOKCCHYBph18Tky70PJ05nEJYR4q/rgz7dVaC9qoW2L0FFLjvfop0gGqBR7cAB/BWxjBj4Dno9EF2S2x4inAC8o2tnSXhsPLyMowomSEgCaCeAWhk3SEqTn2cdWTcQcYSAu4YkhH05pUIFnwWALgfxpn0e46JKfRjQz8t74dNpoQ3O/yQxFn1YoY95MHqDZID9q/z9aRZLbbTumoBtcA1LPDH4b//898u2RBd1xia9qkWUAuoBbgFHICH8HwrMvAeiAVmG5h30GBv6biKmU2fvCgz3opwEhN0qC1fLlHg7vT+bYeCBSBmQ4T0RdP4tw/9CDKeAW41II59Lkxl0rTCgw3KYShhEjicAmAX1i2fWq2hFlAL3KcF/jj89//zf19A16c/tYBaQC1wGxawCB7YUgu+gNVtA1/2yWNx35F9/zIMNEpTtpAyHEyWTopzH5gciDqCh4rKDKOop4f93z+sNLaL+nmIS8+SO/nENR6IPmw8+i0XHrHswZuGkoEIQTcBdooO4+QwJX1pWbWAWkAtgBZQ4K4LQS2gFrhRC1AseATw4zAACAVZhgWhFQR02hAA3gG0I/veENu8xNzwbM+vVjITrogHCnDsrAhjiYeCEKuPwN2GxywZL51/np7RsRg0+nN4a/8L2/+sPnBUDMlUAWfZLMsu1KfnBqH69ZyF9O9qAbVAuQX+OPzxn/96gc2bdtfFJov/IGQWygegNdQCagG1QJsFfAAPToYA5CGan9WP5HYwPyw3DMhniN1BgCK6fG3juEpx0IkVX0iu0bmzLiGT37abiIY2kW1/frYSFNuih4Ux9OOWjr+WZR8gpjy7BVguvNxKySxV+73E+OtwoFL9etu7rbXVAmoB3wIA3P8tIZXBoLLsR2yJD+WpXOOmpxOkFlALqAWqLeBE8JaBh1jcR9Nak4bZNsEpDAC2M+lM9aBFFYEVR4Il8hwIhIF1L5XwoAPpq4mmQj/LFNeGZyR5z2Ks9PkgicxW+m54RgjziHIqbu5ir1NTOaSSOpuHg6y2cPNh9OsUIUY0xVpILaAWUAtILGAZd0izXbrhz5pPA/xJNsrLKciXzJCWUQuoBQotQAw88O3AvIMjK0gkZrHgJ/Q1g2+u7rLPINONmS1BY75izHcYKmTyBIAdScwEgNHJZUrMhew4JHyaC4tQO//rbRgAkJZojlDaYxNIcYDrGHfQtW8kNUKW3SZTcix7w3fH3T7jVY75ZDqH068JsOsNdckK1LJqAbVAmQUIuJNzKu3QnR2vQsSGx7ZYf3tL5SvAL5tHLa0WUAssLMC3MWBdgbEGqYQFwoarCKHSkv3PpqYHx8OVpR9G1gIkiwWOszCRg9GMl4SGnB0I5rHLZweBgtsKx7Y7tM80MmCqM4WYXHm92uRdRjIlPHmEpp1wvvuG2UJwUIJnhFsXCBWqDqcrT6g2rxZQC1gL+MA9ZBjhppeyaSxSw2xDnWQ4yw/wnCVBkE/sh/tTA5Oi60EtoBa4YwswRAYAHuQzqHW2Ke1DzDBYwwdt/lZIwB9JiMuAumZgk1eM+R6UoTgsCaw7JUwSTCeM18Zan8lIEGBDBJ3C5Eucbef2s0OZ2lxxryaWHW5YIrcT4e9LTDbjTTo5nF5sOEcF7IKFpkXUAmqBjhbYCLjnRixlRFw7vjSHvgz+BwE+plRJdfi5adC/qwXu2wIMoVM2VgB4wJyGsmVyj9WYYRZbzgXjvQP7vYpTPwBT1Ltb7f7scGH7xqRJgp8P3JlcEp+hMPkS6shhXLif+9IbkMhAIqsVdd85lp3LoNyHgY+T3Q6g+Xzdv9GtY0ShrfT5gmnUImoBtcBDWUAC3LlBOrDvIfsWA3fpJEUAPrJB0xd3YvAtTeS0jNJ+tJxaQC1wkxYAsIc66ACADzHsHp5zWJez9mdwXAWA97EKUIUbA2DeIXqL/5skLhJtOpQZzUEAnXjZnuiAu2BWSXLzZLXtWIWdaGAbRj8AOMys8KN4/jCHPss+A9ghVj0E3O0Y+U0KSmI0YdIKs6dNqgXUAmUWKAXuQdRd1qW09GpgPjQAGcA3nyNfprPita/UVlpOLaAWaLMAB/A+Y5yLFRlRWWCEEdCdQ8bVzj+UzIyBKDMg5aBQi6I+KcmTZfCBZbascklSpznbTh3btmzm2VVYajtvePBADM4nI3RlEtqvPfBOW7zVrq8pfRJNkRZSC6gF1AKTBXYM3N3evxLLX70MZDId1eFXG1grqgWuZwEC8IsoNJVDQiAN8bw7x3wnyQwyzHOwWqpPnxxKLfDFMRcw5LOxzO1ksqOCVr4zwQHuCeirYJI8xSPfhIA8O1j4NwMDC+e4pqyncjlpNbWAWuDRLXDpAdyJ5djImJsy8S3P5AF856Br/51FKTDfNI2k02JtrasW6GqBngAeHRrPJupMRzAIspBJMsMiglFWUiHTPwfuNsRhwU0BZiINxZjHJE4rOOs6lp0ixsQcS0MMPK0SLuWxjsUwRzA/Heeo65rUxtQCaoGHt8Dl86MXcE/ZsjNjfjPAPbO+Ut+aGTtlAL0y+A//vqoBrmEBBImjjQPvJ/DxSQs/nqAXDQtjvoN0pp9zY1iiAmoXG2EGGORMIPZFGyWAO8S2w3PSYUXqKCuZ2yjLntpMQ+y6LU8RYjRhksT6WkYtoBa4sgVMRuZujHvuaTqDd7+7WwfzxMbHYkrHbpl9gI/EPYukE/p7bqr072oBtcDSAs4BcrQZOCv3NMy4atn3HvIRGBdEc3Eabzt0ZN1liY5mjDllTRXeDgDTDvX93+XLOuf2eEY8H5lkSuY5K22P+yORIDzDaWcZj74/agG1gFpgBQuAg//xt9+3YNw542F3zqJUfBVP37KxV3TXvUrV+O3HRwryrTxHZTrdZ08bvGcLIIC3DHxJcp+ZTQC8W/YdHCBbcSNGhgHwPo8yM4V0TE/IDHwfDuZgkdWlYyiZcL/20NBHcjJlv51nvi1cZC7DKchhNGFSofW0uFpALbCqBRgZkeAlLh+fw+l//WNL4M6fWhIgucFKSQa7pt1YhpaatirrVIH5WF/SKDoq06mcLa127xYIAXiKE+6zzDwBHX+PKQJMB+kMgm8XQ90YH65VJbp6ZLJJoz4D7mmZzawezbdzxu0QSQdZ9pM5kNTufy5hkurX7/2V1OdTC1zfAjIADuOcuc3DvisgcGA/P/3+9z8Of/zHv17gqnVtEjzD+axn79oNnyUjWW9wBS3Tc3BwUP1s0n57AHyEENIOtZxa4MYs4DHCyQgngUdz0pRPDMNY/UOQCwmQfNb9y4D31A+cXEFuY/cTw7hDnfR7a+K/s/6cDKhD8ikYE4B2ym5bahh4Btx6NGFSqem0vFpALVAGwAnlYIQr+kE0XM/DKEQBl6QNWgJ3OgJcfcYa9IvSsRcDXv4BY9Eb3JlpgzHHni31LDxToNQ2VeUSAB9XNNnPZ/AJG8DfFdxXmV4r7cYCqL9GGc2YCVG4HDI6HUHYSJTOVL4LHgA3rx6w7pCxNNHmArh/WeAeNy0mgQJtO9t/uujaeTKl0N6Wsw1KYsCByzLsufK7WT06ELWAWqC/BeQAnOHt4WJ2cAO8bRMp3QX9zQfq/vO0bkdh4B4Fh/3NKWvRj8ErqyUqlWWw6UOXkvXw6dqd8cyAig8pIutVFvIBPr0cFrg7bBGS6MA8NDCSlSPWamqBYgsAELYgPh1j3GuZGGsI41i5wy8kM/AqnT/TWUtHcHB9Nuw2ls+z9D7bLpXlJG1JLHvxvmUd8jHiggXsSgQUL1utoBbYrwVkAHwqRf/rgAf55T48ERlRFpwZI5QNgtO1PnDn6JGaqdzSZ1MiB+5XJJPDi2ilAfkAF9lq/IL4X1f736Fpgz+VsGU+e7/Ba7MrIB973hCDT6+O9zdi2BiprwB/g3WkXeQtMAPwwkM0RlI8W/YdDqol+4nZr0yUGErMZENDpqQvFNJRCNwxfjzKK4mKAmdbAPuVunZi2aHdkv2JHE5RDnNukxrlZ1NLqAXUAl0sYPeNCJSbqFJeQAbcw8Ob8+AGyC9/vq7CB/R+jRgSje3Y+Fyl27mPPhcad+mExJ54JTydH9bKHUcdXUPTys9lNPLQv4WeauXn4F2WfBzzE2BL5C6JxA1FCnJ23gIUKwWIvoIz8RjFlmbDVQa/dVK0vsQCCOBtJBpcuoJ3vYV9BwYd9O6kP0e5DMhwYsD6MEWHETiXurjv+OyQZRWAc+UtASVTKtGyzyLEKGCXLEEtoxbob4E0AJ8QkL/fyer1Ge+cWeeojLfvo5eQ9EUsh2ENE1jn8QlankvOuKd6uQJhHB6O4EPYYi0323CVbBfCossW0G6AqPn5574eA8+0EYt60dx17HVobjjRwHxizKxYmy5OuyTR4XNHWRT5dNhyaw5b275/CxCAB7AqAaoNjqt+xJekwynFgifnVEoSFZgRZNv9CDRfkBG2kEqqYdldhBjD8DfTV/e/4vQJ1QICC8iAtHO8dJ9YVq/w9RcMSlSEs+chuUqOWedAPiR8jqE6Qmp++zOuUPQEZYX6APdQnxth6DiAD6mLyowjKo3PyYE8TbE/1VLGPdbrlQwqYQVFhuKFpK9WccO2QngOYMPhq2L+v6cxuZkKbkIk0WGaHCTx+aGA/a32EbTe/VvAJhMahAAeQPcAUhT4vwV3rSYxkw2lSAmZoI0QILdl8YiaSL7k2sQvl5XIQDjLkl8Ry6769RLTatlHtkABAJ/BClm9oGWvBNjNWOadxyhPHxH6Q05Rrjk6lhj1rVbdesCdH2G2eppkPyEg3XlgvAsHeC3Q64q7r8jKR88VJQ8Ygs+84ZK2es5hvt/pSOD4e7tvBG4V/Iy1DuD72v2r7no9Daht1ViAA3ion4kQBdr3S0nMdwDIoHfnYR4joSEJkBsn00hoSh6iET6bEAUHJDLSXwnLrvp1qVW13F1aIAymp+9Q6O8NALzWhlf9hE3fYh8ZiQA3e2ZO+XFT+F93+tvssTe0wfrA3cdjMQvULpjmenmwVt1FaBVVN5aruOJz5LrmYMNJiPzx+Cw7nZRDh5Bch9d61mkboOtC864uQfv8qaD0GUlS04J3IxAC+BjWQwF+biXc1d85oE0CeMM+I1iOMOe+XTBso03MhKA8UlcC3PEQANFyMDx6oa6dkinlJEKqX7+rpa0P44Np898LoOg+bd437lqfPB+90qCDyHX7WWb02axz7ws7EyDnKFxfKhMF/xsCdd+y2wJ3vlL9BfD/s/fe37Yl21lYrR1PurHjex1e671u6e9CgHFOeBgbhiO2BJYHQQIBAiRARAnJYIMjDmBwwJat4d9Ex9fx3tt9z7nh5LODR81Us2rVCnufHc+ZZ4zue87ea1X4qlatb8765qzVj/ma9eQZvrcUDNb4xOsZX7UglbJlpDdVPR3ZwpeCYH2hMRXHa0Pu17CNp4NqtQGgryAdPnQ5d40m8kmqzJT8rwEJq3JBCLQk8CDPgrSH7XTekiISCHc++wuTcknrmEpylLe9zgAoIcEnzHrvvz6sqfRG4tgSL7+xgNMFzSgrZmEI5Ak4F19+zVUR8Kr3snYCrZEZlp7LhQE4d0GsY6+SuFT5SXOIVpJxal2tO3EDhmX1xL1u2NbIMeNmLbkhVbNm7il93RuX3F9Z1aie4HpWWTbrHqXcd7P0eUX9yzQp6OpTeVDZQMFr264KU1dUnndlBH+W2bGx12qyW+Wh5sDVNtlc2Nvd6dCBTGUpDJD7TtdN/Q4RpI5MVkb2tutsN00AkhSoKEhnT9dzXIiX8ABJ9z9eBjSjhr+pevveEMgjUCTvn3AVvDGi18asBHwWzNuu+bOUOee1OUXEmprH78Kc9zwntq2jVVVe9JQZlPbO6YOo7DXhoUdUEfefnvpt0ljQsAbCs4Yq66f4mhu0kupXUknzSlLmsngPaHOX9bRo21rjsF5NVxUU/D7RaKQLWwx03Wm2ZYIPPn9fuHnwm+frqq5oQeDR+94icFU85l5qQzIX1Q/IQgPEfVom7korj7p2H4xa91wWlP4SCbto7PXc4t/twKRVzaYbWA+t25pt64+ipVx9kft8Keikq3VaybLebTN2ZkOaEVpd7cZqJNyJ3ZUj+lxPXVmwPGmKMCOky7q8RNzB6UG1xZv7KyZ3KVdbcfXNgK+4QSuujhhzMwyruiJ9eFaOR0qlV9Xx+eqpM3Xy381G8GFJhYUiIf/zNdfuaoVAIMLZNJLsBW+QzkAaRy9X4QBURb5ZCy9SmYjUq/sgOLbmBGOW+2R3CmjOwG6Bz5RjJyG3Gv4bf1EDAY/6r73l+gtdBn2+NkK6tornmylrbK6m6G15ct112pkVc1qERhP5nBklZa8Rk7pBjIi786nAKqTXsSfeF7ly5lTuxwY0ITbHVmBtpE7htQzFRgC/AbZF1dKxOfik5kbVlmH7lR5JVzP5TzT4RvDbQ9x4ZerJxkUgpCT1wac1xFoFiILWXadx5FNeOYCV20L3wJ+sq8+2M25bdImkTDU5TOMQb/0FGRlKlmvPQMDbYLI2olXl061zobTp0IKuSZvXlh0vqHpdTErSc7vHTGvS4WzDsMpcNdSeGyVN0hd1QNISYIuX0nBy6k9Pc8Q9BQH/xq5isMAaSUpKYtfYlOqBWkGjcs7gtSg9VtDXpieiyjO/cjyqsKiz9Zs6t7jvF/U6qS7HPPiLG62akvgwJ78O6zSSHLjqPdq5nO+djut0e2VJDOVWB625IvSQkcZnkkmJvm6akvSU2sKEv6o9KwHLKpkdgbwXvLy6VRFwpmAL9vWtlYjW6ScWtbLOPlKlO1IvTRUbXkBVTUXowFLtHE5fyzkSn6M3yD/jrDzpmzU3RUqQNFkGTR1b0/ficf/kZ3962lEa99hCKvvXc4YtPsxrIG9VI7smUPPVVjHKFTRSPykrqC5UsYa50NS/rTD29HO0GUS/Cda679OFOn5/GMG/DrZyryfwHPzJBB5yRlafLoonn3ZIG0+HJzFx11518bazJz+z+pOnHjxW/A7AYAk4TRWDT9fmDl0IxNtdSBUBz6zR8lHFi3XVy/pGkascG97gmbH2Rw7xyqnV63xs+h2hr0vvSRlnalKlM7gEx9rxmW/ulIg7F1PnoMw9R2ULaNVPdwUAG9KMcuvWbG2kuCzNI5171BiNDRicupWgaqLP96wt4K7cEtbmiV1A1WsvIib4sV+rJovObZPocLpFrS2XtJEJeVbyFzglFd6CHcj3rqU2SPB95pdxWY8OQacd1MynBoPp15f01LB3m1xl8E/FWjrvd9LyFTOb3HtoxU2IB22tldfPnw1oWl51gTQ9VmZgV5r2KtK3WZsuxu+CAFnJYeQlnuBYUD9tKljSU3ydYiPi7rPK5JaAKhuzjnal2xhr8cTX8cOlEdXrDEd67xqIbY7Q17wXFtfbNfR1cY1f6/TOd6NqIHkw9Yq15dgTANgLyoqTBeUWEfwoOJTemDnvO3nKhZQTmYcDmiBta+GAuOd07UDyOzFprPHwL/JxuxllJTpwcYonz2PkAc/0vI6czwzUkplMFTGvYl8zt3/eG5bc73mbpZlsbum+brnXuJ/lL22amJLo3N+4esfxUyXyHa315aMPS2Vs+LDOC39DVpl6YPSAaYAZvJTv5bYx1s54NpqzpKtZivK8w95wX24RXTlOG9GI9gC3efGsHMP2zS8vl5QSspIUqKeZ8/KXvH6bbB3XSHQqT7KllU1eBlvwVtAEng2bcXywERyIVHTwNFX/4vTad0r1CNp2v9VN3+EFPgC1G2vqPbG/tfp1YdzBiAFOnnngGz3g6Vtzlme46trUSF/hvE2XgBVWHdCo8/MuAt8FlrEWfOrbH/Kp40uOm5gj1VVv7SpCrmd7Xdd1ufxUlZ3DIdHZAkdkA4uaOiTuDz8tPv3ZEJyas6DqlgS9PFWBWU3DNoTN5DjyBg5ZaNKG4LaM90wr3HOPcqsbN+eidAVad8uih5fwzXJvv99IqWXYSq/tC32p70EGiD0mz+66u5+v/4Zo8FOynRx0BGSdDj4SqYwnnz6nu04vmXrZbxxhj2UoEPObEnBZemvW4DqCvvCJnnOJrZgBpmxO9zElCAvvf1pgTiOgF6ilN2C+ClY8ZO0bGRpWR9qrhjx9Rei/q0zKOrddyjFLZtnG4tge8fjKsvUrxJ2DU1PSzq/XuqUhfSS0JZZrau4ZLy+BG0RM10ZOZx3oDcBsA5oQx5rrGb0RjWse1E1vpn6Am3tD5LxChhutSRUdF2JPJLp02SYAVufB51cVAQeXpnnwV/S20ZlftKzFE3KvY59O4NAkT+LxbwxwlQOUvKfdN5WJ/8YGnJZlKDN7wGXdX9f8yhHQtg/ckq9b0XSdrxcb3bhK/8B8fV3eXfrkUl7BUnJeZa+1tdXqrsuR99xyI7r1LRz25tHLdyoQ95/Bk1Mlvijzni1ZNpnTqZoc17kyuPGa8ON1obTwd3NXV3bFutbzuTq4AY3dgCYE6DaqMXONaKsT3ao84WUjfn7V2ixl1TnD6lwzvrMsYUmHLq1fZ5mX79L7a8Y/uwOgKpl7hyAQ9+yAw9fAisXYWRrB55NMvUSGgkh9kOmU+C5vjsB3ROoxQDWW2cw3cWe5i8ZJe7Dn8YKv1AM+S/+qrl0TCyk9S5uUDGhNmFxnOLeuyfWnlerlO0usW6RoTHleagykrwGpc+uwvM7EyZlKobwScYevKlKyVr2fNZ6pBVXHG9ihkSs3R+bnZxbXBbDi/ty7P7fwLan6+YqtGpH5SlvaXSvh1SkW2n/QpmezXt+mzCVeU9VdfhDrOETdeFS97JfxfKRvDt3mtu3Qw9bmeU29DVVvniYjqVROFaia4CeefHlbxp/PT/C9Xh3bMZ1M0cvOmE6n9B173q97wmkLGYrMRbYgMpNy60j4rM/0GhhKWmWdK3TW7lzr+vShuVZh67l5DcPZtqM6K0wu2DRHzvXyV0Uv275qsqNb9VrdYBzb4l2+Ltep3Iskvi5P3Kt4auY9U0XmeUB1E+r4Qdv3py4j3LMSljf72OhZv6FNDJ1aBsuaHbLSHXXcZqmYVvkTeAbm3nRVK8tSG7oAkKmIdEUWAtdQRe4hb1qP0sWgaQFIF/Om63OEPveWqOqz7nvuOW5TVtXiWIVNzkCoejOWhkSR/exbs+4kWx7/qjWA4hBgzCifmlwavDwiRYkwzZTZ9D33LZ1Xi5vpKy5pgxnH2pvGk143JF1769biFQ9lWl3VOpCuP2tuZljOEOdZEK1a/qq6lNp8+nGvGm1Z5tY+H1c9UPN1eGbiLgkX1JZqup63mctV78Wm93nTwIdJ0vRGXvUAredsqtl6mXtTbjjpTFeJdALNBsAKr95wXFeIRPZNUkXa2sKWI/aa/OuFpGoOpdfkiHVqUGiiXcU/cm/ClKDn3n58Ta7cygVVvRhyiyeUSQc1ZcYcmgE54enBSpfVCGdq9BbxrvppPstLdQOsjFmau+rnW+rbikaW0al6dtaIIzYpHG6Ui+FoOvgoXYrajk7dI54zClLyHsHWttK1Yb2Miq/X6ZmIe6WFRWsWSz9zjqYqPlX1fm16P+feqU2kf+OkNgxoU2eXMW+WUuYGdmQDm1QNfdrYHNNcysBtX6F1b4em3uTubbon933ubdSGrOuycm/OSg5I8yFLIvLfyYsbvq4IoJVpl3lYxFNDlSoCD0RB31v1duZ75sF45fdc74W6kubmDMjU8Ft6Q9K1KZ3UK2/Q4nqcToFFrRcLamGVCr1qKUmXizZkXS9BVba6him37OVmAFy3BY/YgoYqU8xiOr8Q4h49smrthwGiv3P8Kees4rJyy8I8tCZnRGjLlHVdbL0ub8BalJy++LaKdOYWbn506zpSNwtaYNbmktzKw1Zeuvq0KW/t11S9SbZ2wqwd0Ws3oM3bUCqpIdBMsDNvvUjHLt9f80XAQargdKejBWURJo07f9c6g0yDlr2KyC+E4OdoSt3oXhO/a0+cind71ctuGfXNXeYGYjd3X9SNG9atOI86trM6hDTY0umbtapbqZ+gailrY7/krin5ITYM30VMmfZlLKbzCyfupQ4op0zVkpqz3HKTKfMuE61WE2VJCbwuK/C6plLaD8/SrkxN4aVVtIyCm5aIZdQ5Q5mlFUbdm5J/XWxucs1Q7eIvrfJ/pDU1LeVV11eN4xY8PwsFuy7HO60wGYgDAdfXLGZBb909zhQDJ82iVAayyqRZISSrjD8h1R+yROkhW1dUd2Ebgu/vT+ZVluCvGL+F9H+TMrY0dajOw95074Z9r9frDZ82cUrG8BzEDkfJQ1WbaKzu7ctPWRtnasMTjeb9huO6vBm5mo4vn7inM0JzoWQ9rrIQUwuwDehtjAEuB5sRM7MQbb0Cj3CbDuWuuXE8aQs6lGtibopUkfmmlXELIChPxZxVkz6B807yVdw3HwEHv5d0U5exmsV7LmQ6mK8d1jvIxe7bSnnavV6WMsnAv6U87v6EVbpvoQS+qSf0UDBhr00HqVb1ZT5LuRdMUzf0C2ctUyQ1y3IMKwUtdbfVvNDb9n+d6NpdlwAAIABJREFU1+W6s872JN7zlOvUTZO6kUpX5LSc1LWjzeOSXVNls+USP61lXq95AKPqVwPAaoh7k4mmfCptCXcVf8pZlenyVOVYzT00VeWFLi3z7TDDhKx6EnNrtS62imDOUPViL811RC8rG934xUChp1S6im7IdJu/o/qJquporvS6lYGvp2sq1848QS95wGXBWM0iPD+Wbe/0KR+JdMMtUzklFUsoXNHtuOnYp3v08hg6LRVkNP4wpnGoKCX+KyXwbfqbBNJG/nplAMhzpY2CNuVvgzexblG/KXN6G8Yhnk/aS05PHT+N2SwvTXykyl2S3pesjpUqhbplE9qrjsJo+aTcsMvamD+r6fL6ibvqZzox9N98MFQKS51js63vIJ3YmiamBnqTJVt+IDeIaaWcqc77u5r5t4RaqvDess7mVt+0CxtndLUdzibjLCXgmVdK9iN9X+b3ts27MddRjnZYPL3UhbLH+EOU1F62J+pA54GgM4lHsg6EH75TOdzl9FVKDek99xtH4JsGMSfT0feodQR+TUh/U/Er+z63CJR8pjMmAFxZ4+evaMPsD96hz2dxwbmTfle3CuZGkMGaxTmJ9eZ/6sqR7zYM5/knzCLuNOLeDsXMzJbjbRtO6ErJeJV1qh+GJj9FzhDIdQSvC43HcjeIwKeNTh2fFe+vdoO2LVdt8HjkxqfNApquxNWTc7WDJG2vI+Dh6YszodCrp66M1fZm82uTU1H9hAj72dlTT8mDzt5271bzZH06Ji+718L7vz2pj9JBsFHgPfkqpeTWEfim4cwQ/MiATgm+IvlNRTd+3+ahbyxkOy7QXU0dTCn7bLPOrbjXmrintIXf/fqAIz2Fcv4YzSCqCH6OyJfrxqvqKGcdN+JHe8Vwblh1m/ccbpTHvdVoJQ9tjsinS2fVQ5JatVVOznRiN1nD/H38QGK+1XhNyj0yrVBY/UVbxHPbg5N7Q/Dd6XLavtSbf2UVAY8/L3Nt84IvdW5ows5blJyjnbXsugHsOfeOeJbDCHEPXvnYI5/0AIi9J7f0LHF9N47AN41cnBozWtmjtZP+gH9yi2rd26WpDVv2/ebxoUYA9Umj+uK6LC9Vhebsj/SzKtI+C5mX+jPsPapvC8ejccBaXZAza3LmTqvCVnLR9hH3Bljk/dGwOdj0QDRRulnIfNrkKgsX68T/V+nhVjIrrlPJjSX4VQ/3dcCq2+O5Trlt79VEOn4N0SSUf+LnxQh4W4RXch1niPGDpDWFE84Yo2QuqkFFlyQypG3H5QeJuHjg5bMOBbNmyqozGG4dgW8a8Txxl2Uz/WUb1tOcByzlPTmW2gTVir9PE1Jgt4LDTTvkUi96G3Mr5Rx15FtzhNQRyLBUQVpZz60l5ulEyrlyVzzZrlndjSPuMqmVA0jx4WxgRht7K0fUmWan0yBda5vK19fXPVsbLbepsk6qJug2vJDmfrhyplmusEV59dsT8LgV6X22ss895Cu/Eb3ckCEmJex1XnZqJ2jX/X8Tn1lGkXGWzvjPlDQGvO6QUCb+POo2e98jTzLp6o3AzzhDNMHHW8Oqkhx8xV/OWMPCLm9D3BdW2TIKQn95cJzhOqiJuybLTd3VxDkl4Gk5s/QmLZfbyI3PEXYuX8j/rV7iUxOoznSaZWRWf+2NJe6toUzWx6qhrfOS5yziKuqWs8zrnBH6u7CwhECXrSLzelDSTueeoRtH7tv4WLQgMZlZimfHJRkBb/28b/2FTNaVPEX3aVrvZUcGiLp1WEW0t91/V0Hc5R5fvs4yk+IpxgQGtYYfI/DLmXplgh/Iof6u+rrW7dpi0pc7xAiJr5evolcdHg0CY56u5gh7jqhXOfZyxLvK6acJuQjY1RDDffN0ovVk2MYLbw4gRtwzZDL38FZRrqoHXT+cerpUWeD6AednrqqM/LWxht4vQbEeT5sMW/bQVRH4plVt3d2M2qf+EJ6dmxkpcV93J6z+jUDAE2IINK0g7P4tzdKY2je2Sg3pve3+gCX1UxRd57xUBjzr+rv6+8r83Xv0/YOboSliXNycF+lGzJHaRtQTd5xbfu3R3nw9MTabCKbS0ioo6sh1hgo0ZmTRBLru3d7EKWp5AT0mOoxk8+fbsluYvjur6ruZa4wR91nnlzp0IF0E6gh31bV1FnnOk58j7f6zOoc1T92t9tjXOasZgFnHcpbr5fmPvdu5TAFSbBVxn6Veu/Z2I5BmiMmhAUS4RsKi+Rfkc/d6dcrlnlATlMTkiLv/mOQ1pTzwFUNEeeAj3b1+OIzAb+DcrvPgpwttBclfca9mDQxtepWkvayifk1EvcIt04hO1L6byTsbMWh3we0FJyHuvbyHBFCscnu2g/imXJUGvzJZzyGkCXOVczj1g88yFXPeg9x2W9zGYPtj3fj3jfHON000TcAVWI0em5S4N9Vj3xsC10GgDWFv7WWnhohExqG2PfG2wxpWQ9xhteCDnCqIf6nLtf1gI5jlPbOsftcB1+5dDAL1xD3IOOu9/frdU5e1pUoW2oa4V+2Mt8Ghiehf93u2nUsHHDUV3KbxN/qa27teKOL+u6ZFr58Mc85PfKNnQnPn1AoQPWgKKk3uqwrMbCBH5lFuI6jusybvf+q9196CKuNDE3sO1eH+VC2wzQAu6IoKIt24iBsBX9AAWDGLRyAJOK1zlszgZceFhUg3RJhWe+jriTt73f3qUVSS/ywuUn8NauaBX/yU2ogS88S9zEuJmkenLcYretkxFfTpuqu10pMKTNJ3YnjXNYNY5UTT71Yo5fZyzWYQZ7ridgPZQNyrHgWegVVTfaYRuLkXK1mNf2CzFnVNQEzOe56brrlFg0Fta7S38UhUGwfX2I3JyEkayXe0AN7uB/jmPjy3qWe4UIAUpc2j1ErLHq/d4in3H1d424NHvSZ7jMhfsPzaLDPpEEbedyPwt2mGt+trvWc+lIEE38vxq36qHFOlKUkfpLvjdcRfV5vbSa+UuNqrqsU0SDUI+hYDUIzJ0ZXr3Xn4afHJz+Q87i1whkvavG3alnXLrtOMWe08QiY2TfwTHXvOZKpcMAjS3GJW52VImlZ/+ppPGiFtnOEByxD3WzYDrLu3FYEo4LQFCJCYpZ2WPaLtoE2np7m2DJbCeHJPXvlMs1DrrsqDdJIzPPNtvO9gFbCEBv5oAZBdcjsQaCb4+F7D66oOaWTmUkW+4eb0PVx78e1A//q9TLUD9my3wlTBNIPHva5oI+6tgM++BPFDTdT575zkpsqDnvOYp6OSehVybS7oIvwHl74mg0AWOCnQHsR554PddwsQYMLO5LdNl2f2slOhKUmuIeRBTlNP3KPrZvW6c18Tz30tBGJsGIFvM1XsGplk+EsjPQnq+ZIX315lS5hORtwrQW254bAg4t5mbBufnjaF3OprtNSmkdTTs4HEOzwojdIZ84Df6jlmnV8iAm2lIroJc3rZmbGgRIYKbCpLk/w6gg9BrL7cUPB0gnnaZ/uhnPRtDRgj8LPBa1e3REBxk1qaYhymJaA1l826Rly/xq0qIbVpKnwVKyTubeCzB6MepRkmvRHwNhPOrjEElowA69er8q/XVD+vl52KjCQt/rMGMh550iVrTEX7Sp58kvHMI2lJve91yxx5HlAyVPFWW/KIWvG3FYG2BN/jc9u4TN2+fE4PcMvmkJY7NHW9Bc3bQOKeCjrSUJCb8kC0GZ10hFvc0zQp7HtDwBBYAQLem4ynlM78Dm/yjLdpfUqs22Rs0fc0EXftdWd53Rz6e+kKyIdmxAriaozAt5kOds2qEWhL8reZz7QS0a4a+M2tb4H0bcOI+6yYb8KkbzEa2Uta3DcrHHa9IWAIrBcBko80ZohJPTD8tyfM3pU8s+xEdTsT/Nkq+wvf59vCKSPr0NSecvJ+T3275267yq4zyygagZ8FLbt2oxDYNoKvRdjGYVpNpSXAtKXEXSu1F0XeW6BrBLzVPLWLDIFbh4DOEDNP54V8tliHGspHoyHeqWxFqJmI+/LZ618rfSGNuq6r1X2NHZjd+05tds4fLCV/zDMSdo8hsIEIrJLg53Qd11+XNhDU1TRpCdBtKXH3eDeGWVYPihHw1UxYq8UQuNEIkIcYk7DP31OWscyjD09r1eSbvmubQjIi/G0J+DXqqwdsTu87Gx1eQgO/L+GtOf9I252GwJIRSNahVsuS1qDnpMn2DEWD5mOFeG1JaahPyye7pxzqkBkEcPRQrtI5ZsT2EvfKuWSTbI55YLcYAoZAawSYsM+oyU7LX6CXHYrOkGjIKdVSvpJ66tsR/ozXfYY6GyHP9ilkygqJ/PIlQR+MwDfCbBfcRgTmIfm3CCdSBaXrJ6w5nY4rvLOG/4V1Sh0aoFMAgvxRn0sxxYPr4CA8xVc561gLiNdP3I2Atxgmu8QQMATWj8CCCDus4YsOqvQvjrIh0Y58I7LzEfcKg6Gtx77NoKq4gfRUZU3c+Tv/Wel3fkGaB74N4naNIaAQuGUEH3ZAabfOL/menHe7ruh0XafXdb3dPdfb3XW9nV3XHQ5dZzh03X7fFb2e6/g0uV1P6jtCzieeoI9Gbnx55SZXF258fu5G/r/TMzc6O3WT0dhNJ2M3Hft/ydHQ4JFfDHGvdXKbB9zWAEPAENhiBJg4zpr1pKLLs5Dp1qglnmkhuC297V56mBL/9u0kqRDYNeEl3/7+lr3043AdSZL2vBuBbwm6XWYItEUgJwlpe+/6rxPPOpD1rut0e67T77vBvXtuePeeG9y943p7e0DQ/VoJ//kzKMTb3kFpnifvfKImBAspRw0F/fu6/NkX0/HIjY5P3OXxS3f5/Lm7fPHcja8uhczj6Ze0q6kgCsT9P/1d06LXr3rVrB9Va4EhYAgYAqtEQGeIWUC9S5NtVBHa1qQd/O3oJeKjk5nktiW4C2lDC5BxP7oxxWZjBJR54FuAbZcYAstAYAMIvviTg4zFe9Y7vZ7r7uy6nQcP3M7DV9zg7l0g757IF96T7km5dgDI72mcQOyw9mfQ+31Anx443g0snJuyx33iJpdX7vLlC3d++NSdHx658fmZm4xG6IlXXviEuPeWMUpWpiFgCBgCW4IAy2Gcm17Xu6t7PBOJngWq4O0u3TVLnTnifd374aXGAaKL3Hkl4r6I8TECP8tks2sNgRUjUBFd2yrotqKpnLqWSLeXwXSHAze898Dtvf66Gz544Lr9ARH1Ljq9JVMVedDB0eE96Z6MEyn3DgW1zHmCDjp4ilctyCkynZIeXsXOe5UjJ1yZeE/8aAye94ujI3f27bfu4ujQjS8vQU4DFY9Grnfv4afFJ3/k90yhEvsxBAwBQ+DWIcBe3Nib2+i5bcJp2cQwQ7ihzbOQbnhnZGQo1yxDsJu1nCZM+XtKwTmtcOBVmQqlRBCMV+pJa9sOu84QMATWjEBLgg+yFfAmuMLr1Xd23d5rr7u9N95w/f0D9K4X4BsPkTLJQqJ967rTgb7jDen6w/GqaUth/fJknu6C+3hncTIG2czVybE7efTInX37BPTxk/NzJO6f/tHfu0iXyJoH0ao3BAwBQ6ANAnnC3uZO4Y+5RXoe8jxLpVVkm8uYlSwvgbhH3Zm1Pa2xqPe+z2x4LdvQat0vu9AQMAQWiQA6MxwEmgJhf+MNt//m91x/fx+CTpFAqxrRmQ5ydfRpgw8dvO9yLXjRkXLL5/D7VK5hQ0DYvDB/EdCg+k9lkoy8815HP5268Wjkrk5O3Omjb9zJ1185N9j5xIj7ImeIlWUIGAKbjYDsLtbrpfVa3poEroL8EdHOtmkekkwBUJH3Zs5ysgGkS5HMqCnGHip4g7abelnPO29Yr2IM2zXTrjIEDIHrIMDnZBQFZIHZf/0Nd/D22+hh7/UkVWN+PSivsPhJ5nMi+UjClf8cfmUZDa2w6nb5NSky8uz7P/wa57NIjkcQxHr+/MXnRtyvMzHsXkPAENgOBIDwzsDuZu3VPGR31jr4wKcqgjpPGxKP+1xyG4C1JvPLPO2aBRtN3me6L/ayRe9kdoO1DdKdpV671hAwBJaKAEsGPUEf3n/g7rz7Awg89ZIYfM6Dxzy41vkz9a8n4kDIvSedPOwqzFTuVcVhx9gVomk4308+/GmhvP3evY/SGXxPJQX6P8EDP3HT8eTSiPtSp48VbggYAmtFQHvYmbfXiQM1KU4XY/o7cpBw8NIqCN4yyLEuU941U+cmcygoK9o3tzEw08RZlmFGOEiQ2kyNsosNAUNglQjwoUfOQc71g7fedgfffwskMj6rLxBtpY2BJT1a0Fvvr9b3ikk4EfhSPZFbXeJThfLLa6jUHDIkTOO+yllldRkChsDyEdAymMQ93WZdLjtJyhFHvMSuitA1epUh+mp2aLPlLrIs7dXG4LCl/jTidJ3aWYy65D5cp4l2ryFwSxFgL7vXsg/v33f33vsJt/PgIeRfR8KuHNqcZ11OoIi9ND49rpxNAV9hMsdwXkUQpse+dXz3hBUCxTX+B35j/XwUBMsZzUIDQVXP3neqn7PPQBlG3G/pLLduGwI3DoFleV1zQM1JbufCvOkAomu0ZZHEnaU8lX28Rjtnwm3Z88AI/EzDYRcbAktGgEm7P8l094033b0fvAfBp96dDpRb2dqiSGGezGkblUCFabpvthDvjBZd0304C4OyxKSiG939KhGNvoevp6ySmJZS6+ONuC95RlnxhoAhsGQElk3UkmV3VV52vXrXRl5egxBXeagpddrMA9fo8b5GW2dtTGNbZi0wvd4I/HURtPsNgesiwKTdy2HuvPOOO3jrLdcdDEnGTuGkwpZ9dhh0ewdyznI4n2d9Gkne2cseUs8GI0AHl8rvyqMe+kXfQh53OdsaPOpI9mPjQAwF0deQxIe+gHhVI+7XnTZ2vyFgCKwFgVS/vvRGrJB0roK013nI5yXujV73ZRzMVDPwSyfvvm4j8Et/9KwCQyCDAOZmd66/t+fuvfdDt/vG68573acSo8NBn+yxLkf2I5kO+hak9FUZADQdD2eh4qfBly4GAJ6bCj+cYrJ+IIMgB+5ji0DlnDTibo+CIWAIbB8CayHsemFeEWStSOd1jImGTDDz6tEb232dNs+D/ap2ZIzAzzM6do8hMA8CTNoHB3fcvR/+yO2+8gocriQBqJwZSktc0hinNEhUN0RIM30Y62ICUc8FmupytDYmKkPrcJjdR3qdSB4jRfrlzDzu80wZu8cQMARWi0BNwOlSG7JqksmdadK1kyExT0Bq9Aao8CzN7XEnN5EYV1WDswZcGw2KRU0kI/CLQtLKMQRyCAhpv+NJ+/tI2jsdFaAfi8JDqCmy6DgUtYBTVTG7DKZoDEKamOmrkFXVrFh0g3fweapxZXG9WETctmAt1Pn9jbjbc2EIGAIbjMCqvKUpBGsmX61I5jXJb10d1yLu6ujuupl13TrmmrWrnE9rnkNz4WM3GQKbjUDwtB+4e++/73YfeNLuyTe2G10RrGPHk0mZqtMZqCiGYek5ZYvBz6gc+I7+5gwvUU4sFtOwsEYT7iBxkVSTosRhSk90HdJXYotZSgPiGo5KBVvCZ5hRUh/zuG/2BLXWGQK3F4FVEqwcaVdpCFY9CKsg7fymqNRyXtMoaKN1B234mnAuYZzzhemBT79vuj65d9UBzaues1afIbACBDgQ1WeMefD+B27n1VfJtz2RjC7cDAkopWcPSLl8qTXnTNAD8U/VLdpFHwwBPkmVCqVXVrqiCemmy6K9AF1RsDdKIsVU7WMe9xVMNqvCEDAE2iKwbsLO3pm27V30dW0kMtTG65LeWgNhAaR6VQbI3EOgsU7foMFLh8XniDtYP8nrWDGDqF3KvTdv7MDc/bQbDYEbgID3Tk+nrrezA5r2vTfecEXHa9onoXMqArQsX2cRC4WR0iMZRC3q9FJ55vO4pVJ5fVVSC3ylPyP/upy/2lxD1EIszzTuN2BCWxcMgW1HQEhek2ezKrqnDoCMW0MuV8v7dYnwIsYgIru5djMBXICnei3EPdOntXqjtaGoMa17NecGOhf1VjNGa+3zIiaqlWEIrBaB6WTiOv2+u/uD99zB97/vOv2ec8DZSbcOj7I6/UgHp8JlzNT9NSRH4YxQ8hrIRLJGj7avhBLAy6moSs8usT0sk1PXk/wmGPuh7WHjk9vG3dIRssFXb8R9tXPPajMEDAFNmitiI9uD1ESYMgtx5CXlBXIBRLh9oyucLAxGlReXb1uANxzcNr6eqgFYZB1pd8u+sLVJZrhpjcG01x3civuNwC8JWCv2JiEAwaOdjtt/80137yd+6LqDQZDZ5SM+Mcg0HEaqszWqxI2oZceAVCT9QVOO0hpcrcLJqfCZfKFIPElx+HqltocSQjlhzUXZDdWZeS9RFnpsG1dqJ6fepKltfTEEtgUBnSFmzW3eBC87L+tZDq0/5FVeeWquA1/RicKtQlEL9OrDC6dlI9c+FjO0tWWXWl9mBL41VHbh7UKAg1GH9++7hz/5U5CzHYi8hqHFBlluPy2zuuoDSqPfmXyXNOy8XGayOwbCHhobadxVH9JlUjYIdIZ4dsibVOZ2PQTWW0NgfQiskRilnd40ojSLx3dRBLepzoXUM8OYb8qYNOGyzAdoUzBYZh+tbEOgLQKsa9/ddQ8++MDtPHwFEyiKpzr2PaT7q+LigC9Q0jJNdPCaIIPTXav56Pdau4A9+9wntaFI1UbeflHM6Ou5ESnTB9k91g6mCmWYMalM2wlk1xkChsCcCMxA3uasYabbFkJIZ6qx/uJZiOLCiF2LMVkUTjP1bwMkSzBaLfBZ4BQoFbWwcV5mI61sQ2C5CHjPeqfbdXffedcdvPWWOmCJ6i0xan5uUWMuxJmbCe5u1sHTBdku1LnRk0ol52MoSMi5kHjVLm1NwPekh6drA1GvwNakMsuddFa6IXC7EVgz+UnB30gyNCNGiyLTbYjpKuvSL9aNyboy49gs42HfyDm7jI5amYZAggDkOHdu58ED9+D9n3S93aFzE/SYF7A2BTIcy9w5tzoZ4Jnkivp6lUk9mz0qLRtbyXcFyQ5el4nfYaIuWhgm/um/3F59Q+r+x3vM425PiyFgCCwQAXEbLLDMaxa1seRnRmK40H60qHthxJ0DYVuO40L72bLO2staYLWIaurK2DhMlt1hK/+2I+CzyHSHQ3f//Q/c7sOHwXuuuKw+XIkJtRB6zhzDCV4I0ECXSTajQ/TJIIiUK5ydJhztpLTvoTF1oTw64BVouUhw0DiRQCAdg5psCITzWS0d5G1/Nqz/hsCCENgAcpPrySYTnlkkJHq1X8iItRivRRL3Nh5+3a+F1r0IwFrgtYhqmsrY5Pnc1Hb73hBoiQAEnxaF23/zDXfv3Z/A1I9AxEkunpD3XMAnL6/6O+HgwJWVL11dxPKa6Npcu8kCAMKulDXqT6T6Kvuk2BKRIx37yhsD8JXOOslNpYyWvl3mcW85kewyQ8AQqFq91Od1bod5AIz3KduXsPEEZ0YiuPD+tKh/0eR5FkNl4f1tP3XqryTccvNy3rk6T9M2Fp95OmP3GAIKAQ5I3dt1r3zwU65/5w65qNkdHa4VtTkrZ3SK9dy7SDzdlNadiopSs3spDieAZILNVWolTFq+JuOBy2NZlDaeFT6V412xhgRVvUll7FkxBAyBuRFQq1YVWW9DZKoIkF4oqxZPf42+P7ouvWnuji7hxhakOa110SS6jQd84eRwxn4vvP5FDWWLfrSZ+7M2p/JZ2eS5Pmsn7frbjgDnbD/43vfc3bffCQGpJWByevJAcXOvhvhVVaFHr9KpJ/Vj+aE+/DqnW49v9Kp4zBDP1+sXWZtnuTCP+21/SKz/hsBsCCjSkq49JbKZOd+neTUNqbP0OqjL1qtvqbw2C99sPV741W09z9y3ZRDYNm1YV70a8IUbLAsczToMV0XcuTvLGKsFQmVFGQJtEfDEvb+76x5+8IHrHxzIAUnspFHnEIW0kIpAc5IXeARZwiJxrErfooXs1Dgm4/gvvkvCoyx++ISyIxWHgFWdscZ/yu52TERJlF0HtPprlAifdDoSMJvaBUT2TSrTdjbZdYbArUagwq1e5XBYC1ZbQNrbeLojMsavjgUDui7iPkv/peubPK4ZQ1Y70iIjpGYMFyUxE6g2GbMFz2Ur7sYgIN72N990d95+G1JB8smm6N9Gkgucm9aH8OgUcOopfknzn3k6XYSfqnKYghdTN8XjU6lcPrOUskcqqQtegv/noFMoV5ztbC3E/nc2BTxRB2MgOmGJiD2ty+KzIV1/1B0v5bEDmG7MnLeOGAILRmBRbGLBzSoVty0kpUFikds95bfToiFcG3GfMcPMtpD3hY9PJjNdzoZLd/tLu//b8mwsGkArbxsR4Ewy/rClwZ07SI9ZIC4dSrZZmaMX5COnU1UDuU+18fohSaQt/pAmCCbFQFjx7md3ipU7H5LGqyhUFWkqZoSsuXqhZwMhfnA5rWRoB3v0EQQj7ts4u63NhsBSEdgWwp5jMksF5hqFV0iM0hdCKgNaVk7zdRL3Wb3u/PK+BvqrubXC+z5P5SUCnsjOqmRqlTzdCPw8w2D3rA4BziTjUz/ee+8HrtMfqGNM07Veb/Wm76vk4SjJ1sIHQRKjSLgUV+VJ0WQ/xUd85RmdKF+rn8WcEQHUnC6OST567S2P++pmpdVkCGw8AkbYlzZEmiiX12KsNn3BwHVLIlxrJe7K615nuOjBWCYWCx30BT5DmptwG3OEnt/zualiHviFjq4VtjwE8JTUHpB2yNvu1yglfYGlAp6JlOzGbcoto4Fq5yzeaitY1Otgk5NMh0h1ajpgKaH2nDmhD1nlvOzkSy8Rff5ch7Lyo24e9+XNQyvZENgSBBZINlbS4yWR2aW1XeFb8qgnzpWIaC2rnxUpDbMOphW0QRPPunfy1pB37TFb2qS6ZsHLGtdrNstuv7UIQFDq3p57+P77rruzQyR4ClpwCezMGbMJYqAhJ70cs7LgAAAgAElEQVQ6XK4OMkJNesjpIreSJgYPdGJ3CcpfOHa05BtXbWF7Ipf7XWwN9chp+4Pr1G4aHWALDdJOfsvjfmufEeu4IVCzlbep4Gwj2Wgwiqo8qOr1sfjRqGhTzqhYlscfXkZJO1Lve7bj2zQHtsEg3iY8F/8kWImbgQDKZDpu77VX3d233nJFr4f0mdaE6PBSrUbh5kfu78TnrnOoV3U3IcaBvmee4dR4yN6ryDbVKbel1+f+pkOX5OnkzQci8cUnP/u78TtKOl9aTDdjXK0VhoAhsDAEtoFQpJ3dVoIxL9bL7O8sbVpBO2qNl9ykX2abFvaQqdf1ostcRnnbhOky+m9lrhMBH5Ta6ffdvR+863buP8A4T5/9RbvLS68ExWY5LpSILV4asXnMTqM3OJNcARIDWys5w5tgB4DtCk28M68tcP5n9DsRKef7qlQ7+ntf3mc/9/u8qeM8cG4ywWhasWJ8hO0si/w6h97qNgQMgXoEtvFZ3mZCcR28l9nvWdq1zHZEb9kZH95lt2vG5jRePgvmjYUt8YJtw3WJUFjRK0PA88+ez93+/vuutzOMeGjKi1OHO6RVJBYt8veywzuQZyogPggpRBNV1afBKDv9g5GQOuT1Kqd5eXSaqg77gcJR2Z5ezzGrxYu/9/PT8cWFG52fudHpqRudnbnJ6AqI/HQ8RkIPNVOCGiPyK5vMVpEhsBgEtoU0pEvjYnq/nlKug/myydMsbduktmz7/JgF9/XM2lDrssd93f2z+jcFAckmc/++u/vOu67oY+52/ilvyJWpcbgGv2PaG1/J3+mQ//SzQNs1cc65GEiqIop4Td3jw5vwm0pHvvLcB6Ieape+Ka99Mfl/fwOc7EDUp0jWR8cn7uL4hbt6/txdvnjuxleXbjLyJH5MmiPzxG/KpLd2GALVCGwTUdh2UpaOwnWwXzZpmqVtm9SWFONlt21Za8ss+C+rDW3L3VaM2/bPrls3AphNpuv233zT7b/6qis6Vc9HStjpb/hHfUd/c0hrPjOXLgtPL609pFkur2iDBlGfnhpdXjZB0CmO7U8NhZLUR0W+FtP/7+9Ae0GD0ymw8UTgPZmfXF25yxcv3Nnhd+7i8MiNz71HfoSeePPCr3vOW/2GQILANpGCm0LEtom053xHdQ/RKojbdebsKtq3jEXmOn1eRnuaytxWnJv6Zd+vGwFP3Ls9r29/xw3v3ImbQ8Q3OJsDE1YOaLhH/mYir0XokQRcZdlNST/XDo8nCeejFgVzAD+O/8Y2sIc9JHJECY/OUEN5cshggHukr+luA5UHGW7Izz/97f8CJftMwlnAX3SkuRPvjZ+M3fjqyl0cHbqzJ0/cxdGRG19egIce6/T/27bFaN1T1uo3BBaFQJtnL13qFlX3Isq5KcSgzThsE1FexbhcB7NVtG8R87uqjOv0fZntqip72/FeB2ZWZ+2K5/Xtw6G7/6Mfur7Xt3t1tk/bCKkc+QxR/AzSPApFj083hSQ0IHfXQhXtt9YeeqbdXBoRcAg8JQ8+pI7E62TWK/IcGQvUQX7DYjMVhVenuuKJrNhGLYgJdD850oOWCPSwo5O9mPz2b4pUR/JJ6ghdholIuZfTTK5G7urkxJ08+sadffsE9PHTkSfwJqGxR9QQ2F4E0m1A3ZNlEYybRgSug9OqsJiljZvYpvQJW1Ubl/VkzzIey2rDrOVuO+az9teuXwoCFKHZ39939999B09LdcDcJR2kvJWE8Or8jpyyRbUusOzkADt6zuAfEpbLbUk5XEb0aHKb4mw2ZC2UFTl8L+eR9+RdZclBw8Q3ICmPFfppG8QqUMRdUtJThG6IuMXauT6fwJ6PY52ORu7q9NSdfPONO33yCAJb0QNvBH4pk9wKNQTWikATwZjVo3/TXv5N+NT6nVY4srO0c1VjNEubclCtqp3LHKbrYrDMtt1UzFeNmdWnEeDA1J0HD9zdN9+A/O0oIkl+wJueOUNUyCyyY04hGb2JNPMndYkI2tmbTWQ50soTp8aWaKdWMCq4oVAf7waAxp3YuiLbeK12n+uzLHD94pNaOZgV1T5I7DUmxeS3fyMOdyUXP11ef/wGeeF94OrV8bE7/uoLd/rksfNZanzD8cjabVuM7MEyBAyBdgikz3Zb4n4TSFaK0HXXuVViMktbN7VdmTd7u0m74VfNMjab1JVVzpNN6re15ToIQGBqBw9ewsBUL9GO860joUU5NpP62BlNsZlAbvF3pNaQ6TzKBy+z1MtYxAkt57JKkKs4wjOd47bodgKtho2AxE2OjL6khY/yPKq8NOqMWKyZT42lo1TZoQ5ZZYJkSG1BsHWgKiaTQIwG+Rvk8AVkn7k4PHQvP//cXTw7giBW875fZ1rbvYbAJiMwD3G/iS/465KtVWMyS3tX2bZZ2pV7LlbZ1mU/l9fFYtntqyr/Jo3BujC8PfVyRpmDN95wuw/ug7NXU18mp0G1HnTjMUrsEY//TT9Fpspu6eBHZ6KfUcRDNfw0age6Lon94Xhd7GbXOwglBzx1IvW0xx7+cquKyf/ztxEn3TKNiN4haJpPPo3PZOpG5+fu+Ouv3PFXX4J8Roo373sTgva9IbDhCGhCkb6k9TKpu3HTX+bXJVmrxmfW9q6yfbO2LX1cVtnWZT+q18Vi2e2rK/8mjcM6cbzZdQNx7/Xc3e9/zw0ODkigkZJOpQHPwRGx8+TeEn9NiK4UnalTmxCSipHuV1GrpUSOUTrIXGYa7kTGrGCZDRHybIpIv7Mw/q1fp0w15KQHkyD3clYN0FoiirJF/RH9eKvpauTOnx26F5996s6fPTPt+81+/qx3tw6BnC9DewBuC3G/LrlaNcGZtb2b3r6bTNyrnqdtWmxWPX+2CRtrK6SC7Pfcvbfecr29XUmmGJ1jqnKsk2JEjlhCBMspGkm3QrKZRKpC5FgduMoKd/SW6zhVIdLpWGmir05uVT5w8ZMn/izOlMPed19ySdbD6SH9N9AkVZ+vbvJbv64y7JB6Rz1rovWhz+KtAmqaLjOwd4igHZ2cuBeff+ZOHz9y48srk87Ys2oIGAI3CIHrEOFZtjMXCdksbV4H8ZqlfTlc1tHmRY5PlVtx0XXE1KEcgIeUgslRkqQuaYy+7raMyaLH4/aVh8S97+69/Rakggyp0ykQVZi6JsfxugmrhfpIJCSQzrFwmFCFZjET2khJH54DXHni9SNIUjI7zOCJpxzsnI+SgmslwQvIfzCLjXJvC1mXBDcq1aS0SOJck35MfuvXogOjdDugmYqpIzYs6k+6p55bMTB8hzoOglVffv2Ve/n5F3CAk+neb98Daj02BG4fAnXbr5uARlP7NsWwaCKFKZY3kbgzO5l33miSnhLy5EUPVSSSAmFG6W58ep1QpEwqvps6LvOOid3HxP3+O2+77nDA+RGDsQjTi6gzZ3Ck7DLgcaZc63LAEbFgzsSS4eFlQ5TL0HNee9rZMlCpHIMxS8Uxi6YlE8wOktfw4UqQClIU9kTm+dwl7ICo78sOclL5U6BrMf6/f43jVgNLLz2LymKBbQn9oKcPffll4I+wHV+N3NmTx+75p59ACklYGkzzbk+uIWAIbC0CVaSlqkOzXr8MYFLilRLCTSFXTe1swmZT+tHUzlm/n3c3Ikfcc2XVGUl1ZeT24nMGAvf3po7PrON5u69n4v7gnbddZ9APaRQVLJziEUkjHY4kvysezp5ymIpKPqO87CyFCbnXy95ySdsYpXRUa7ekfVRrpybuZfe/2hHgnQNVr+L+aCNoXXx+HSzG/9ffCgkio+eSCLh+vvSehDynYmIEqLPPcAGnr54dPnXPP/rYXR6/NPJ+u59Z670hsOUIyN4iL736LaI+04R9XV5shjrnSa0jWPq7VQ7XvARVt/Emk8O2+KREPH2h6++rvPKaJaX1ZuQD0TRp2i25yWO0yudlO+sS4v7uW3j4kug/knk6nUaKFG3+oUc75J8RmYi+h93SLGwnKwCd4DjvQz4bmu/8nVbDBC0PlOBjO7X2RDYIhD6jQkVT4kivnpB8VLSEg5OwCYHksy1RjP/p3+QUlKUU86XnL7NWxI+67kTcITSC8OSo86dP3bOPP3KXL428b+fjZq02BG4zAikRbyK3ObK8LsJSvUbjiKYennUaGm3JadVcXBfGq3o22uBTRdRzY522O50ruXme8wi27f917m1bh123yQhwcOr9t7/vOoOBKzzZTlI2gkBbvOg4B5kgC6dVIhOctQWURenVlQgmntP4Fz4jfJ8QcaoTv8NrsGZqIZ36GieXRNItga8s65Es9PEqG2r2BB3v06GoceZ6fF78Z0jc+YeYfoi2JT27iGmo0ZRrEwqF1O/s2lfbABwpC1ofMWqw40LeP3SXx8fYGJPNbPLzZW0zBAyBaKFkEpOS8hxMba5ZFby3ibjniOaqcF5lPXUEfpuI+zqNxFWOl9XFCEhWme9/z3WHXiqjyWj6/KbzQ62rpamjCHbk7w4UPc3insuJXkr1mB26KsdMenfV2ts073VfyHwY/dO/gYodPnuplFwH9wmkaey1lw6o9PJkiEg1bJiodxxYTj7f+3Tqzr77zh199CGcukqmROLxoUo41aSRe3viDQFDYG0IVC3QkedDta684KYHa6ynK7ofTUZF00tl2T3IkdIm+UXappvueWcy0tRvjWUVhlXSmZyMpq48fX0V/k1G5LLnlpW/bgSAuEMe9zdcbziQU0+ZEGKaRDyVNOjTg9YdZxn/Xx+DxKeh8rXpaaxh3UsPT0JHcwgGVUlpkuU7NQ5SNHPfB+c3eOYlzwwScNwkUM8LXI6kW8fGFqP/86/DVeERUg8T3wTt0Sqd0EApl6Jiw7YDetqDZiluMMhmJhN38vixe/HF55D3nRuBqXO8N5/+nUycm0zwb3lHkhYo2tpd9zS0+g0BQ+BmItCGwLa5ZpPRybV/3X0y4t5+xtSNVYpjStxz5Lpp7NsYfU2tT3cE+Po832gqzb7fLgTwAKauu/vm6643HEZyFeTrKHkRkgp/Ix8NshVksDhb2XvMKWhYvY6f6wON+C9Wt6dymDiFe/BYs9IEsiOywn3KyR9DHngm5cGsYHME26tpO/eIexIy0tC1cgAU0uRi9H/8tUi2oxJpUi3qgU+tHiiTml7akaP7ohOnsFPE6NEc8Ph6Yt7twKmrk/HETUcjNx5dusnlpRufX7jR+ZkbnZ7CKayT0QiCXKfjMd5HbYDazCO/XU+ttdYQMAQ2CIEmoraOpqbksIqA4guu/HMbvO1txmWesZ3nHm6LvjdH8KuMRKQw9nM7EADi3u26g9decYO93ShE1Ad1eq4IZJzTJgbvLqYVL2nig4e+7ETmFSLWoAfnMid0iecmEnidDYaMAqifZiv/IrdqI4Gd1mHTgIl7OaZIr2PKeJW0kUR5gbhHhyzQgyOA4UMnS6KURSRcbVRw/nmwQ2SnLGyZ+UFCbo2lsQ1UdDuu6Pdd0elhq2AwpkDk/T2eoE+nEyDro+NjyEhz+fy5u3zxwo2vLoXMY4HeE59bwG/Hg2C9NAQMAUPgZiGQI4HcwyqPbfr9dUjozUJzNb1Jx6wNGW/y4K+m5VbL6hBA4t5xew/vu+HBAfrN+TAh5qUslaHsL5poR9oVnnJ0vTDP1HkMFJQdzvqYVOKmkm89yGyizC3MhqEI5eEH7iqN0Cw9nPQabXSxBIjYsCL9SLoTaq7KLq7+97+qUr8Tm2dunaf0EZHnLYxSHUp+U7tk+i8nU1d0Oq4zGDrX7So9PWnrfSUd1P84IvCezE+uRu7yxTN3fvjUnR8eweFO6JGfIIGXAVrdRLSaDAFDwBAwBBaJQPoG0QRPO2nakMNFtsvKWj0CRu5Xj/nyagTi3um4nXt33O69u5LoxKdZhKwwlHIRuTw93z7mUjzcwQnsCWLM8dmBTElU9KFISjbP3nykzyEbDTuC2eEcNOacfhLXpci3Lo5tlUc+mrJ4MBN8xClx4J4g/cFuhpNixQ/OTN3ff/W//arw+MgQiXTvTOhZIUQt0Wxdkf300UrajXkpdRoexrfTBfLuSTyolahl4qVXJ2dJdV42M5mA5/3i6MidPnkM/44vL8FDj4Pi/2de+OU9flayIWAIGAKGgCFgCBgCMyDg2XCncIP9fbf/4C6QeAnGlLSLJGEh1igZ1zVRJ3YbyH2QTotjnEkjlRMiPgMBR15K/ycFB/ZGu8o5PWVIBCmnu1LX0REfR5TKRgK7piWdJNenvf+xQ4JbKPVc/ZNfhVbEPg26KQoGpU2JoHwJo5MktUe82ToKFoAEB0vDfd90kEEBkplOb0ByFypDsk1S88kikTuZlE+9F/7KjU5O3PGjR+7s2yegj5+OPIE3Cc0Mj5NdaggYAobAhiEwq9wld/2sZWwYBNYcQ+AGIuADUw9eve86vV45xIFc3fERSXwqUkyoEZqqXbjgG9e/MTGPP0vLxTIluJW8/vHppbpuvH+m1UbnTQ9a82ximOLqn/wVJYhJOh2R9ISIq+LSoCCVIFIl6+HZFgDB4tX2JlhfXjKz4zrdXthSYB09tUd2I6hIDFDgqF+Eyge4Xp2eupNvvnGnTx5BYCt64I3A38Dn3rpkCBgCNx6BmV6DFa9Nk1rc+GliHdwqBDiX+53XHrpurx+4t1DDcirHKCOLd/6yboQCRgPbDARaM9D49NIAF1/NKSZZZx77qyVSVvnhU5ker1VBXZKaE+UTVDlXDnFYyZST8GS/sl3+47+sJO+heSXHumqHaPdhq4K9877zgVLDUbAcv0q4aKLOR7vCAIhNQDZVt+e6wx3SqYeoYp2NhqGGO/yOARlgwVDBdnnN+9XJsTv+8kuQ0YwvLiCgANpt8pmtesCtsYaAIWAIGAKGgCFwcxDgzDL7D++7/s4gpIRkRTZkPcH+inqF86yLIgXZpU7hqBMeMhVmqyB8Rz5z4resPRHvPhHLIBInSk/6m5CHPU1QGdqiFTNsggQ6HVixUsWrPQOVCjPkg3HF1T/+S5AePfJl6JNO6WAmQU2Bp4NvBVY6rEmOoi076mXGZWRAlPrHe90HrsPWFwyIktREov5kAke6oRA9PL66cheHR+7l5z92F8+OgNCb9/3mPPzWE0PAEDAEDAFDwBDYLgQ4QHV498Dt7O+5AkIchbUHty99FjKgB797yN+OmV7iZIzo3GXHL3BdYdOUF174pcqwLtyVTydV/wrEOgs81Rtlv1H9KGVDRwdyUJbjBWA8SFVkSohFQpKdy//1V1Ifv3DwyJnO5o7/V/v84WpF+5WrvrSxmbrxq/4GyUzXdXd2MVCVraGcdj/f+vLM9ae1TqZudH7ujr/5CjzwXj4j3THv+3Y97dZaQ8AQMAQMAUPAENhuBIgH9nd23N79O5AeEn6UVEbSxUQ91YRakX19WCiy9Fgnzp+FaFGVulGlMof6E4IZn8qkAji1sUFedDIgAslU6SO5g5pkkxcfu5iQbPhTGR+X/+iXK6hvWU/IdozGTm8VhHOrtNO/3ZzKlV0Mhq7bG2CQMVgm4Syq0GiyQGiwMHUPXavE8JBeCPAoQP9+fnTonn/2qbt49sy07+2GyK4yBAwBQ8AQMAQMAUNgoQiAzr3Xc3de8QGqXco5yAccsSSbCB2ff0T8NsRUBtJdknrLmUlMfpEbi0BDZCdBCqNFLCFfO5Fv4pjYBOVZFs7NwbMxTCgNZy88E/xylKg2VGKBCXakuPyHv8yhnVQDN1zHrAYdubZBsLm0VRCJiyLjQE7DEsG/MqdImURH1WrfPXrde8PdKLc7w8DEPTUv2E5BGY4CT0l2fPohPxBXJyfu5Y8/c6ePH7nx5ZVJZxb6KFphhoAhYAgYAoaAIWAI1CPAchnvce8PfVZBlWpR5NoJcdfnFwmnDJ5q7WcH3pooXpDLMgMl37qShtcJQsIZTIHes7wFe6qz3oQULNqPLnVHDuZA4nUAbmgLlltc/MO/iNnpRRWkqS82IQoApU9C3kp1JK0KEMV7fFZInWMm9pNLJhglsg/+czQJOsOhK7zWveP/Cp70EESglTqc3J6AStJZhrGlwAFXuMnFhXv59VegfR+fnxt5txXGEDAEDAFDwBAwBAyBVSFArHqwN3S7d/ZdUXTCQZxJfqiyFoQdvgkJb9X2km9e7srVU1dk/vq4/Oq250quvre4+F/+AhF3lbBenO10o9RGxFvMBk2zmeJ7y0abLfh7OHWWKLek72HjgEX5KnTWy166XddhrbsyLgIAbEZxvvt08LDNYUMg8sm7olO48dXInT155J5/+imkkMTrS0L+VtPALjIEDAFDwBAwBAwBQ8AQaI+A5429fs/tP/A69245n3tVUddh2LPeq9OgJ9L5qublTANUhNAuQO5GVt9kstL7r4qL//nPaxEJFpFqcPg8JRLIx9RY9zzeCCgnwtdiGaw2lMWtD1550Kt3vNd9DxPzy3m2ScxAuifCBWtAYr5O/aQLvF5pMnFnh9+55x997C6PXxp5b/+82ZWGgCFgCBgChoAhYAjMjQDLZXbv7rn+cCgqkKhAoZukvkiId5X/XEurqw4u1bQxce+KqAaJITHboNzBIgN1jZqsMyymZ5WqeFPMTs7cWxWm+yT9uPiffqlM3JOI1sg6EEtAi1V09stwZCx0BqwKSuco6Xx0ovlgK6BXPgSgMvH3UpnODud1p0JFnUQ6e5bbSIYbNGcg7Q8m2FGGApYRndnqyft06s6fPnXPPv7IXb408j73E2g3GgKGgCFgCBgChoAhMCMC/WHf7dzZcx0vl0mU2xKoGYQW+vig0lGlJYc6lSfhj3EoJ54pxCkaiTyj4lqdq6oKRUqbnOkqp6pSc5SGPXVtsxGAIhUsGC4Xho68VFgsSVeKi//xz2kluDjJRdqSgB5wjFTmUR740DhKHh+U/CKZSf30hA3uHdD10o1Ox3V391yn0wvkOzlxCfJ0egB1xDGTdTigic0kGmfQ44d7MFS3A57380Mi78fHaGCZbGbGR88uNwQMAUPAEDAEDAFDoD0CEqR6d9/1Bsj3AulLy4lpecjuqNh+5GpX9ysyLZ/yqUzI+lTFfEXC2IVd8/VpoRm9S+o+F+IfHN6hlbn+oUO6OP8Hfza4o1OQUtd/SRWjUusoTMTjr0DThgArXqJB0X3XwQiQ093LZXZcpz+g01TDWOZGtpSek7REYt3k5hEBCrbTdOrOnn7njj760I1OTixgtf1zZ1caAoaAIWAIGAKGgCEwOwLEwwY7Q7ezP4ycpjEHL5HRSq2KptN8l/Z8x0TZ/6Vl3FVdSH358d9Vkh0uXRKtiJFQPlM1r70h3/v5P/gzcuiUJLbMGBwgYCH2rZzXEYMufa5sFjZOIJ+6yiIjmp8USTjS1ufvRCd8p993XZDLVEUbYwGceAdjX0sbJbKVEjY3eOdADV9RuMlk4k4fP3bPPvkYss2A190877M/iHaHIWAIGAKGgCFgCBgCLRDAnO5dt3ew57q9DkpHVCBnnNdEa19yqplMunKlD2Glh1dkBOqsPdb8OTZcaKp2vouQJZThpR/IefGOoD0J6dZBQu6/IU5c4a8v+f59icX5//CLirir/OtRYnnSqmfS8vA4sI5d0lfq6FuVQ5N6ESe/T4CErkrCfMxS409Q7e4eQJYZOQ8WrotBjqIE5CseXG2UafuNM9kosu/J+2jkjr/+2r34/DM3ubzCU1ztxxAwBAwBQ8AQMAQMAUNg8QgQgx3uDNxg13vdE+UKqZ6R+GpSTD5qkp8w1+SUKEye2QEblBlxznVJmZIoTiJin+SQZ5IuZDqkUURnMqs+FA2X1gtxh/zpiGeiq2eQ2XAozv77Px0Rd63s0U5wUoNH0bUxbIkQvzSc5a0NZZ/Q5kTGQw49njjnifvOruv4nO4S1qssLD5eNmo0RjBE2xbC14NlwBsj0B/4gyIfCufGF5dwwurJo0egfze9++KfUyvREDAEDAFDwBAwBAwB9MdOXafbcXsHu+B9D0xPWK1i6YmQPSGu+mxQQFc76cVLTGf7VGlc4HN9UFFQeGDtfGqr8ptny6LK5TJ1KhTxWmDBci/9osoCO+bsv/tTiV1BEydzEmo0pSIpSo5wZ8rJCv6VG79K3kLAdAYD0Lr7FJGcLUf6Q03gbRX22PM4JX75qCspvmH7xKttCsjt/uyf/Y47f/YMW2KSGVtdDAFDwBAwBAwBQ8AQWBoCg0HPDfeC1j1wtcjdGoh9FfFuaqHi5MovnL1Lq9HTCxIdB0m38+7wdk3V56eG2oqz//YXhNMqW4EIapCs6JQ3kS49bSn0mkCl78CTnaZ7UVIYcYnT9aFDkZDIFf2e6+zuk2QlKUAxcwl+jT6TvQplHIWUkGzHCcRcNZF0n2nm6MMP3ejszPTuTQ+BfW8IGAKGgCFgCBgChsCcCHCGmZ29oev3vdc9/6N5a5ViRPO7iOdmfM5C/RI/P5LiILcuUd+keZHjX3n5g2wmn7sGi1HpJzPtKE7/m58XT38pgbxoibio0HAI6VSpYthZjiJ/hEmDKA2JPwzXJGgJPtyGCZ6i2t1TOvcIKO1yDxohdWRr6H5ue4Q7D9/F7nv/12QydsdffuVefPG5m4zH5nWf82G02wwBQ8AQMAQMAUPAEGhEYOpcr99xw92h63ilRaJ7QbqmzuSR/O46mjXwVyTtyF1FjhIxcOR+ZT4fPokoLNNgdUPJ+asJf3J9dC2ocbAgVo7I8USKvMN3p//1z6tWki2STYZOEOsepaZJOgrKymD5CXF60qmj1xxJf6bg1KTpFK67u4+nqBK8iYJdmUNK6A8XJ8ddhYaoyN9gcJS8/kXhRufn4HU/PzpCg8MkM43PnV1gCBgChoAhYAgYAobAvAgMhn03GPbKlCs6ilQT9IR6Z66Lgh9TuQk3VDtykR4S79Pia7o45/rXHS59nyPQSJrj40FVvWRtFKd//08E4i7lKGuFignHOekATjYluBLWMooAACAASURBVOGJXiV7BiyfaEqKmhQYrg9AYq0N54TkfO46v2eqFNKHPrF9hf/y//ls1ihJj4yzxB5TS7T1Ubizw0PI7z6+uLAsM/M+hXafIWAIGAKGgCFgCBgCDQhAOvBO4XZ2+uB9z0qppQztD9fEmC8oC1wCH0RmLhkSQ/LHnGhGsXXmwWX2Lx7+Uh9Tpbw2BKo84uHz4uTv/3HJdo5ZVVRqxJy1AH2jrQb6PqhxaBtCEfacISPZaMR6CRZG7EGPM1X6qzqDoev4fO4cQZA0V3J80vgBHBnjSKT4CiO8NpB9FvsIp/cpIq9GkB4Sssz4TDbmdbeFxxAwBAwBQ8AQMAQMgaUh0O0WbrjTBxKPHBJdr+H36OROPDgzEwqZUntFaaO2py5hppKRVIbMCFTwUFtIhiOHLJVOHOUcOZzDnVzInBaSzzpShkPYMKAen/y9P6bd5MJy61Uw3PRw4BF2Ku5S2KzQ50Sl+qGY9gfkNIHGT315RX/ouru7QaaiDSgxJPJcnUaaIgJiIyUS6shgh+T7mrxfvnzpDn/ndyxQdWmPqBVsCBgChoAhYAgYAoZAQKDf7zifaaZDab4jB2wCVOS01fGagb4ir0yyPALzJA4I33NeE1Zfx3lOOOV6ZCRw3VKVKoObqeuVelIOy1Jy/pxp68l/5Yk72Ra6tcyUoQWKkOtelLKvB+V9SaPD1BsYsLZl0i0Ctmuke8plXrii10fi3gknqOZjc2Mjojz5M5r6qnSVOlTBT5jR2L348gt3/M03ltvdVhVDwBAwBAwBQ8AQMARWgMBg0HWewHsGqOQiUrN2BYc0MInmXbUTkiByGvY0Y3zO7a7v1YKOjBMZLmV6TfelApC4ZXHrpaqoHYUrTv7L/1zK0bIWlJ4X5P7H2zGTDBLvmPbGaRXlyxQr+DvIbPiY2RAorFLgBBe3Ok2qgMwynf191ym64YhatR8i2xVRjslgYsXYKjQ4ypgNDIqahRbRTeJ/97ndj48hUPWK00OuYMJaFYaAIWAIGAKGgCFgCNxGBFDv7pwn771uh6TKkuEkyb0CJDbWStOf+E/Oha7d6XQxWAfEwOVX+kUc0UldlXZC5gsk2xiQqrXekes/3iYoTv7uz4VrJYsia4OC+IX5LHzCTFYlVuHPdfHId1OZDFpJoGXXWxRRHK0/xSqk6wGCX0wxPbxPCbl/x3U6HdGYe7LO44NGQEhVKal/uCVwadhhwGt5a0S3uCwD0sR9Oh67l97r/uixed1v4wpifTYEDAFDwBAwBAyBlSLAwarDQcd1vd7dO5jj7OTI8Tj+cOq15Bx/GTg4etlVaKr2XBMPD45gTkxIXlzJUhjbCp6n6jOP0JXPtcRtQnqMRJ5bgVRWXZfT8fuvj//uzykGrcU9acgpdj5Oq4h5J7Gx/BNONcVcjzHR58YW0BkWEHGsKX2WnPAkdXhPf6fnegd30OwSws7H1XKkKtlTbBhE04qtKFYAUagsWzfBQkmsLH0fmicXL1+4ow8/sgwzK31srTJDwBAwBAwBQ8AQuM0I+CDVQa9wPmgVAlEjUXWIc+TPY581IldSmSherxht6bpUFVOtqKmW6KQicSDvwGmZzGML0n6BYXD8d/6zKBO9z6fOpBozpuSU+9Rl1r9HxJ3IvbciODpWIRfapfOsk9Sm6khW2TLw+yRdIO5FB6UyOBhqKyPqagCgeljxfgQ+hT+nv6fhLBxkmHn+2WeQInLmDDNsuNDOQ/wAqsgI6V4y7WR7xfLJ3+bFy/puCBgChoAhYAjcRgT8mUyDvifvHaGBcIiRZHYJzDfitqTwEMwSNUzqfA+qGiUfVz5q1skDM1a0UfutI5ZKnJhonIR9SsAq+e2RabOXnxzcntu//M0/KiwxZK0h8g5WDOe1jBz66NpXedYD8Q1cP8h/KGGP9K6c5hHzZ8ZecLaZRLBDAidP3DudrpgiAWTccChbMuHzMkWvtpVCps0KWj+duvPDQ/fsxz92k9GoJjUk9S2SGBUYYFt0nKPtHrQa+aCoRHQEo+T/58uaOjfx/078ka74t5iHuHVkP4aAIWAIGAKGgCFgCNxkBIC89wrX6aLyIgpIFXqX4XlAm4gblny/qS+eHNhwXYnWK3iRzYPUm33l5ODGKuhzKUc8s0ScAwcOhVJ95MD2txYvf+OPIOsjrzl7sFE3Ln9JI3T/ggtfb0bESSG5faLvV6p3bJiuA//WSRiDF5zsi07HdQ/uyuFHcc3V0xOuy+xaJPRYWqSHWbZFkjT33oIbn5+7w48+clenpzFhZo86kerCk/RuF3YK/Mmvvd1d19vbc92dXdcbDl1nOHDd/sAVPZ/qqOMcBF54HT+S84kn6KORG19eusnVpRufX0A6ytHZKfznDYepv2Y8hn+xI2wwGZG/yQuX9c0QMAQMAUPAELiNCHh+1nHkefeO96zjUjG6lqSx2qVLKGf4ZEq2G8vgG9Ky9N8q4w17pYuXv/mz6qjQsq86NCQpKaLyQm2TZDpsnaStS1Pe5OizvofK8SS423O9fS+V8UPV8KO2I1jVUyW7ZxNCIyCl64HWXYLUkCP34quv3Om33yHJhu9Ra88k3RPywd27rn/vHv67v08k3ic0oshoPlTAm48w2ux5R++6GG+elIPjfeKm5HWfjkdudHzqLo9fusvnz9zFi+dA7icjf81IyjNPfNOEse8NAUPAEDAEDAFDYFsQYHLsaVqvV7geihiSsE5ieCzr9rGZLLVO/JrssyYHt3Lg6+yJgQ8LZ5ySx588+RlxujB+cYxzhsYkz3zZ1cp1Y73Fy7/9M6Fe0XljJ4OGnA9XktjXsmJep8xRJz6xQoeqUzry3HZDYMiROIX1Sv5DIO4HrvCaprSINJMPzzztMmdNeYoM74Tok7YSu4PJf6xnmrrzZ8/c889+7MZXV67j01X2euBJ33n4wO08fNUN7951Rb8PbfZk3hsdOCmUZIgHm9qcWmryt8dZbBYcbXDqg7fdy2bGbnJ15S5fvHDnh09ByjM+PxOPvHnht2U5snYaAoaAIWAIGAKGQHsEpq5XONfvFa4AJ+gENRyRegT5rRZVs5ia5S3h2/AJs2JsS9Ce6EhLTUmRzQZXMGtL8P6QaUZrVJgncw3lOE6q/eWv/ydJOkjO0BKzXvGRq7Q78WfYLHYWq4QvRFAVUJQfPuRwlDyUAUzJIa9SQXq4un3XPTjAFEBx1hypP3Q6wBtZGooVZ7h/sAfUlyFOVx+wi2mIvFzm6JNP3WQ8djsPX3F7r7/hhg8euK4n656od4moA0ATig/AsWcDBdNpomSJA2mVmRRS44OBQd8ok4snJsubQC4zHoMxcX506M6ePHYXR0dufHnlvIfeCHz7pcCuNAQMAUPAEDAEDIHNRAA82CRL9o7Twd6O63edm1ycA9/xfJEZaCSbjvisHDOkuFksPRfqSD5mSbtOsOi0lOIbDhxfyhUUlcSDY0zlQCj5DhuJmwXEh1/82h+OT1PSrFeNkeRDp5vFcQ8ifLICdDIUDqeFRuuUkGGLIVKzExFHZb/O60Nws0e8N3DdvX3UMRGKwUpRKIhVlB4WxfZOeQIGfz/ZYn4bQ3nmq0r3+vOrs3M3uP/ADbxR0es7n6qIeHiyc6FstWTSsOGTswbTVscyLW1saWsDT5edTsZuMrpyVycn7uTRY3f27WM3Oj+DE2CBwFsw62auRtYqQ8AQMAQMAUPAECgjoOIIvYqBlQ7Dhw/drlc5jC7c5fNDN3qO0uGQINIL4RM2xx5nIGEhJSOyV+07T1i4aFPiK7V7l7mbPqGVSa5kwJFauJueqJOiQsJtKXO7//vF3/rD1IPU98xsXBFvyW3D4nHNajO0lk80ldOR2Cxhzq1AIPLIZDfoYAKd9b91BkPX2d1LyKY6sCkdXm0EXGvy1xRUFK473HXdO3ddp9f1TnXKxhM2UThfPypi9MTQ5oL/inPf09Cy9olhYOgh2DZ43sXS43xC9C/aN94AwQOr/K6AJ/Cnj752p4+IwI+NwF9ratjNhoAhYAgYAoaAIbB8BICwI4n1CT+6gyEoHPZee90NHz5wnV7fTU6P3ej4JXjbx2en7vLo0I3PTspqA6Kt2tutE6lIZ9hJnGTqbuxscjgr87HgzA4cOmR1TEpF0hjIc6fniud/8z8GmT780Kmj2qbg7IQ6NSKmbQw2BaaGDLIPPHQJK5NzqaBQfRoq6+Yl37x4psvJG/29EzctOq473HGd4S56wmnPA4kpnZiqAw7EFlGkW36NiThKTYhopzZIemxuhCui1xkO3eDufcovj32NtmSibDlcgGbhGYtDDB/9Xdg2kZ0ONawYFRtml/bMoxoHR9dP6MvjY3f85Zfu9MljOETKGxTgfTcPfOPzaBcYAoaAIWAIGAKGwOoQYElM0eu63s4ukPW9N78HCT+8x911vT5m4q6OnrrRybH4yj3fuXr5wo2eH7nJ5SWoEIDyBiKJnRAtDBFiUqnruEZ0y4b/B1KdOncjJi0gaX4b7q3AkBVA3knrMxIOBq53774n7v9RyYYoyTBEYk/fgFNYJ20MwavcXegWeY/5NCj2NiuVi8hoIkGLltnow1c7hevu7EPjUSqDhzyFE1QVIZatECW1IeuEqCtdHMBFIkwEnjX0NJp5kowGjO+n97QP77/qw5qTEdDRrnpXIx3UJNdkeqiUiKkiKq4mmmqheO2TIIAoKABd+eOrS3dxeOhefvE5aOB9WkmTz6xuIbKaDAFDwBAwBAwBQ6AaASHs3S6k0t57/U23/73vud7+nut0kXOhyMCTmpG7OHzqpuenITjU8zSfhW906UYvX7irl8+BwBcQc8gqCDzEiXzMyPxAW06Mkdi70pkQ2Q8qiRCMqOXe4XdRXkA2GYyRDFSV3OPela7P/PFJTfoD179zz/XuUKKT53/jP6yXykRYaosipvcqZ04pQb3yZQdPtPZii75Iu7qTlJHg1u647t4BWFaRakcRbqHuvvNaxyTSeVIshS2CSIMfekjyGybyPCmCoj8ckQVbNh3Xv/8QpDz6B3qkB6cST5oDKl5ZLmVOL9w+t4PQ7rEXei+zD3dHvOb9+Ouv3PFXX0J+eDZhzPveDle7yhAwBAwBQ8AQMAQWiAAfOAly5CEk/jh46x3XP0AeCORFTu5EAu1TdF88feKmF+dxQ8hj7FNp+1PvRycv3OT4pZtcXoAH3pNlYbWR6iDwLXS9sus3zkETnPWJmiPKQaMTpqDDW84qosQlqAHyGQg7wCf9gaPd/buu0+9hGnTfzud//T8QBY34gJWVUdaaa09xsETQKgmnRXHn0vvjtDu83ZDsUBC9j0wDn9an00WLwx9QVDJ7gm4eWpEaA6UtkJBvHSwrFYSAphYRaW2BpTshNC3g3k7henfuue4uBc6yLMgPjPL+40TLsXMw70LFqn/RZCEDRI70jXDgXQhsWDwG2jkfhFe8y+B3MHwA68XRoXv+2afu4tkzOMzJvO8LXISsKEPAEDAEDAFDwBBoRIC97J6wDu8/cHfe+YHbefjQdfp9JDMQTKhOJ/IE3icF8cT920duenEB8upYo0AqDV+798D7zHv+EEtP4n3CjvEIvd3wn5LDyLk6ZCtAoSQEp1NSI18w3MwKFeRbyiyg9hPJZE8+1OEP3+ziwZz7d113dxd0/EDkQ+JBVzz7a//+FIglJaQPaAZLIAg8Au1mj2ysR09PTQ2iFBbWsB89SaooXBnv0OelhjJdr+96eweYnzPaiQg552MxSt7yyfPmUCezdp8nE4+uVYlumDgDz+aBQQvJW0aQY94Hgup7Ep4ebArdkrDdomU50s/Ea5+T7sRoq+w1hJYk5EwMEJnYHtfJ1F2enrgXP/7MnT56BDnhjbw3rjF2gSFgCBgChoAhYAhcFwHOFuMPVNrddQdvv+0OvveW6+7soNOWD7pk+sX8CghQ4abjK3f++Bs3vbyCM2+QY5dJD/MhSJ3t67y6cuPzUzc6PQEvfCGn0PvYTHXmjs40Q5752DggtktMXtI4kjeY5TEoN/f55v2JUR3XGe5AxsTuzh4E2MJnXWTrKDtn565zxbO/+u9RcCpXFr5U4aOUn52sBtqa0GQczZOga4+sEQFNB1ZiVwOZZC85g0zGFNSFZXcGO2CJIDEuGwmcmFKTfy3+j9JPJnEIYdMjDjVg4sytLe9ABH1Ud28PvO4d2hEI5N0H79LAR0ZYYONgJMC8Y50T5RSl4iUYGAoNWigMKA4SoxCZHGv7g7QonsCSckg8+djD8eWlO/76S/fy888hT72R9+uuRna/IWAIGAKGgCFgCFQhoLXsw/v33d33fsLtPHiIshjyhEdiClIcADFn4j7yxP0rIOLs5GVPb7g3JfL4N9Q/meKBlRfnbnxxBqkkpxDQOsFr4F/mV+qIJeJh3qHLCV8wjbovm/Ts/m9vTHgPen8AnLazQwlXul38HA7Y1FYJl8YpIqeeuP8hv3eAOLLsQgc3qi9S9UlQ8XOedikgFnZrYbXokYgSqww0YTBVe1jI4zPK7O7hNglnPhGRT9R4KkYPTErZue5EntL6eUoGnar3gzC4/4qcjBoXlyqgEp88cHi9k6B86pziUY1nWnboYWz7BUNDi4Gq9hxY7IQnjfnJ6w9uev7pJ+7q9BRngmWcaT1L7EJDwBAwBAwBQ8AQaEYgSGP6bu+NN929H7wH2WLYIczsEthbRoEA33cKN7lE4u6lvx3gl/HF6PsklQYnQFSUkDUpXguPXHxCZP7STa8uQYXgJTb43wi+g4M1WSMPNgQSdpC5wCGcXVf0ehBI2xn04awfV/jv8LqO/907ZH0ZFJ+pM9mk7LF49qt/UFzB4reltICSFYYwh0JVskk0cijlY6TdIO87q3okuUnQI5HjGDEl0GhPQ46nZZkQ1NvpuN7+HQSCffUq7aGMTRrASdsLscKIrKtU147MFLdNohAEMeZoyyX0m0+08nd0+kM3ePiqKzoUNKE5dJW2hQ+WSr9P+XeEkdLh6NlcdY0m/KnNkbYxsnd8JPbEnT/9zj37+GN3efzSyHvz+mNXGAKGgCFgCBgChkBLBJi0eznMnXffdQfff8v1BkMizrGiAGTd6QFKKD1Ajbs/Lf7x10CyQY4SkUz2lecIGREllqVAmV7KgtdyG1HhQATbk3qVlzGiT6igRhZMuwHo+PTSGFUXk2Hx44fzf9CVqlO/kKT76K/8QYmWDJVq4UhAPpB0JfCnr+NTofBDpsdoQQjdlrwsKZ/UYyzOdO4z6Nv9wUuwz0AZIIlgC/MnmYuS5sQUPRbTsAQH24E55qt4MLSectejAcMie5pEPk5iMADi7q0qLeUJfFq1puT0znjxFYoa0XgbRaMW7zKECNt8qppgiKmcm+RRF6RI/nT+9Kl79vFH7vKlkfeWa5FdZggYAoaAIWAIGAI1CLDUt7+35+6990O3+8brkEHFc+JIuExJUwKND8xKR6BOfZKNx99AukcmzFoyrRmt5qCxSFpryjXJJyam0qEHbhZ3Mk2YTlZIJuJR3SeaZv4s7/0tjv7yvxvhwGIN/DCmsZrYZ9O6UF1VTt3qdCq1owpE3Wvb/SFH4XAnVVlqkbDm2xNtpS0PCiAfdMrp38PuAJQIHccepAHL6qZoHkBGFp/Lvd93w4evQS736ECqCEdk7OFAK11lsK0kI4zSsPNuBzYxOaZKRyqwxkqkN2TBkdUnOwoyvOT2Z90/DaDYFhCzOnXnTw/d848/hIOboAkmm7EF2RAwBAwBQ8AQMATmQIBJ++Dgjrv3ox+53Ve81LgbzuZR3Dzy+Oq6IppK2fGefO0mFxfhQEnWn0e0kYhOcoROegCojvWMDQC+PziSmRcHv2zWzCCqmU/VUq6DO6t2Ho7+0r8TlxybIFhB6J9Kr6KthJBKM818KFdpMkhAy3lAqgUlRzRsf3QhY4vrwv6CJKyXHRA9uFQhGx46Pw1F2JIUhtMlSoL3kL5HZbUpea3LaAEm0Mxezw1eeR30S3joVGLn6cOkCAMtXw9pImnqaDD0fgkpesTOIEzY5gjGl5rRqixRGHEbYrs2PB/a0PQW5tiTdy+b+dBdnZxYwOocC5XdYggYAoaAIWAI3HYEhLTfuePu/+h9t+NJO3tLtVwlYexpIhHtk/aky8fmXX77jZtc+PNoAsnRioq8cjmciBrEKprwJbkRxUGKI8mhophGMmQ6jMeZVBeR7J55mhZ0810hqTezSaByR7/yB0JOEvJQIzumxiSETzcCtTsEo+wsUJOp8aDRCe2KnNbCt1V+ypi4418++tZnbEG9Uoh75ehdaAGNiqhm2FDQ6XpY4pJmalEymRARrBqdPGHa4JA2wOmpPTd89Q3n01bytgj57oUaR7sR6o/4uvL2SHIclewMlR/++F5dX7nUvB1WtaDAzsJk4s4eP3bPPvnYjc7Pg0V721ch678hYAgYAoaAIWAINCIQPO0HQNqHr7yC2fjkECLUJWh1d0i0wiSQnLhC+pC4TsYjd/ndEzc+PVEiD9JcAw9XZFwIUsL3+HKlwAidSr2uSH4jjsZBl3K/ggQkP9yK4LXnTIygxhCyxt5fTXydKw5/5Q9gEWlflLNWqlTlccGYi5KT1ScqIcGCuqT+DtsPSQeU0YBea39aqs8mM0CRP5Hv1KOus2yCPEa0MHE++lSuw95pNJnQlZ2GpsakmU5e1eMAhsAEPO2euPvo4SCYV3Q5sjo4EJaNJBqA1KMfTSztsg8WWWgK3ZydjNpK4CxAmecrsizUYDBAnQ4ccPDyq68g17uPsIY8pPZjCBgChoAhYAgYAoZADQIc5Okzxtx//wO38+qr5GmPozyFOfHHwk344CNdSYgq9Ak1rg6/dSOIx4vznwf+p8ksslFOugilCv9Vx9brwzOTFOdRlpUSWWdelniouaJUAiGHN+mc5cob75t++Mv/NsCi7y1xt2gQVOLBII3GK4R01pwWlBvQmvuKXtd1fTYZTG5J+WSY9sfbGGX4w1lVeK/2OXOD097m/NLc6JwXHj/zxkLR77vBq14q44k77DVInLDoZmDsEDgJcJVJEnKC8km02GRl4clWSNydoN+nwFnuL7UD0xMF8CUwVQZOf8kZlIJlK3f68nzKpYtL9/yzT9zJo0eQecb07rZWGwKGgCFgCBgChkAlAt6pOp263s6Ou//DH7ndN94QTXsI5ky814rqxOXmmKpXZUzc1bNDN3p+FJ2uGuQxKpUhsl+JOsTzchJPv3Jsszwbncgc+0qJTTjmj2XSdIAntzmoSYIkR5zFlEpSS1KkDk07SVtdHP7Ffyv18SYwtRNY6EYlym5qdwBZy2FiaYwaFvJ+Q3L6wQ5tRaTkOz7NKhoYsiIqy0892SVSTwRbyYcqy+Jg1t7ADYm4c07P8qAluxKqy+kmR1pf6B+bMMEcUWohoeKMlp7sugyCOD9cpQOqknDkooDc7kf/7Hfc+bNnaCZYsKqt2IaAIWAIGAKGgCGQQcA7+Xwe87vvvufufP/7mM8cTkJFQsauzqAFVioC8TzGCpGoGpBTT9zo5Qt3dfgdHpakkpQESYviTvpUVODjGbmJ5GhP+DAx+XBEEsp3kFuxGkU5skE0QcGsUI3KP6hPR6U0jWqTgRpMCB3+hd+vkiAiSGCBQDJ4gpNkJ0Ekokl4cvRPQnQ5BJQjSrFMJdynoqJIXt9oP5bdruvt77tOpyvOfPQcs7qHhfvkqU7aGQcxxFshspshJ5ayLD14yXU2TSVKUgcC6MnmXGcwdP1XXnNFl/K4p8xYK1lCN5D0yqECagpEOquY4XNQK9zHefKpPlTkxLso5YjsMIbabk1/Tw0P/WB51H2mmaOPPnSjszPTu9tSbQgYAoaAIWAIGAIlBPg8nn1/uNJP/NB1BwNKFIIERvmhkToDX1JHulOJwaGpfM4SSIn3jM7P3OWTb9xkPMbzOoNPPcqWGBicsLBSNkWsNnWb8mea5NM1cil9F0XFMvELCghug7RRH0rE3n/pNBZePP3zv3+KJD3ZIkikPUzotUYopFRUGSspKph14jp9PF6vZB8Kd02rmdZ7b3t3MASZjAj2/RCAhp3GFKwa5vLUKeiZt2oopWOCOZ6a5S8hayeKNmXtOSNFJoWkf6FABFC78HYJ9rK7u+v6D/wBTJz9Ruev1/OQcr8H64GsKbFiyn9Lfk+23jI7IZGhkFqGNDE57Q+NtzQBMNQHG+j9Gbo3OpgAzxHwp4cdf/mle/HFF/SQZKxVW8QMAUPAEDAEDAFD4FYiwMGoO/fvuwc/+VPO52zHtNTxTr6maprOpCel5kAM9xZucnXpzh99iTF4QElyyhEqRXOryAceOFBoZ87NqTiPcngjw45TjOt2hGyNlIFQOFlwSBMRLOX9K57+0r9JrlllCZA4PgryZI10ijTptSVHI7eWrSXd+nBqEWm/6TQqItokDMc7uj3X3dt3hU8ByexSkU4EJM2vmJygpAwD5dJW8amZYIHg+o7jWJUxFWnTgwXhuvv7rn/3gQrW1IPMUy3n006nq75WT9HcNM/VodX+yhiI8OdZxZs18e5BeJw0iFxuaJM3XsbnZ+7oww/d+dERWsommbmVi7N12hAwBAwBQ8AQiBBgXfvurnvw/gdu95WHytnK5Bn5CCQkifK+KH4TEewkflFf5injaOzOnzxyk7NToeIxDU+kv0n0pBBmOkcH01SGAFGmiRxHKg5pEtpI69SFWL9Wm1CWRKWyT69Bxhcf5QSlPP2lf0ModrAbgreZ4nfjcUg3EyI+iX/o/+NAcEmJ+xu+xCwwcBeZWd2dPdcZ+EwyWJlIQyggFnk7SnrwNro/JadMuFnCQ99LKyQ6OOiSOOcktLnEsxElBM1/X7jpZOpct3C9O3dd/+AeBdKGPQe+PhoU2ZmQKVLCOKXvUT79kg2m8Y293tgPfUgAlgyYy7m5oZVs6co5VnAt2nd8KpUecv/72eGhe/bR7iqgmQAAIABJREFUh27sDz2wLDO2chsChoAhYAgYArceAe9t73S77u4777qDt9/CYFQJ+EwSmRC5lbzfOnQ0SDyQFOosfYwyERPILHN06K5eHPnTI0lvHjgOs7hA/4kzESEKfAm5D9BQIqPCfUiHjrsJOt0kNYady9EMiKl57HbVfn3ajSBFiRQBWvvCFd/90r/O7RJCqjXoKUHTbWBSG2i+OsOINduElb4mncmh8cgiferHzu4eEUCyOZQ8phQ7ICcxBTMj+IljbzYTfhgIkMqQRIRGRqwyDiLQOwr0GXYpGBk+uMKT1d69h663d0AHEwVmjeogdagS1EUoUPMiLFXqTk3BdT58bL+KK1U6d0285ZoYhhhCdXKYjJNKQhPnzg/BFzKOPr/7aORefPaZO3n8iCRKsfFw61cvA8AQMAQMAUPAELhNCJAcZufBA/fggw8gmwzLxWP3MIISO4pjFhcn4tYEihmk4hzTqRudHruLbx+76XiEXBK9rYo4KVKUCheIlMvWANyaIUXMmiWjTMrtUuLFKo9oWyHMiMhRrIJ1tajId+G7P/evaRm6ZKPhksIWQbAi4rSTVJOKruUAVB2QqrU94FlPPNmBCHdcd3ffdfo+wDNht9CEEsKxpCWYJqUgA7xTJQUlQs1bNFF8Q66u0lGt1B5P3Ls913/4musOMQMOj2fJEKswzvT12ec6Z0GlZwqo+SvGHhuSpCyKGLsuk+Y01p1J5ynPRHI+sNKOXb586Q4//B03OrVA1du0NltfDQFDwBAwBAyBFAHv+e4OhyCR2XnlIZ0oH7Kq4K4+esSFAxGnjfKqx1nWFY0JWVk0ffdUbXJ54c4ffeUml1cOeLtKRMLtjNNiKye+1oiwskI4P6kPuE1wCCn58MnLiUoQjHFkhXeQjQSU5PRTcfgjKZO0k1Q3a1aYARdP/+y/ymnFY8ypRgGDGqEZach/EkEWkdYQjBsIN/aJg0x56wBTAhWDHdcZYkAqm2Yxv8xYV0mIA3U9WBr6e2G02ghIrAhqNEtJKiyDYCL4rSCfw/2V12G3IJqBclXkOy894SmHZh4dtyw1WriYqs+r+pjrUa6M0GbOMM+jpXz9xPW9133sXn75hTv+5hvL7W5ruCFgCBgChoAhcEsRYFK8/+ab7u4P3kNnrJetEC1BtYNSvdDn2fOImMwzv2cHqHZoE2lCxUEBnvbz7x678cmxSr2XuH5ZqSDy55K/N0iiI7l3alYwp2Itd7yfoHOboDM3ML7IJytEPdBIlMSwaUD1fPdn/hUWa0R2TjkJvZ59ifu/NDEVCZQMLkxFkxFQZpY/uMhr2715VJbrkECfU/uA0z4cWKTTTnKGnAAdzoiY8mMf8P8xHdU7AkGFQxZVlKIxyGV8Bpzhw1fB845GZEgmGW1pREQ+pP5HTZU+CiDk2Yn7kURhEx5xhHbAP0yKsA0QTRS1OyCY0+08XWJDKAy2bhfc4nO7Hx9DoOoVp4e8pYuWddsQMAQMAUPAELiVCKiA1Ic/9VNucOcO59sWxzPjwr5U5hCalTHTZJ6L1ET9X6csFy8xS+inbvTyOZyiOh1jPvd5f7DGnHu1rAGJ68jfU3KdJn7T2GGbMDDP+b77RU/cVeFC2jgNYnD1xzYCiqw5zU8g2pxqsRQ9qfoTQlXFc9vpuu7OLlplRPa5XSoON6igKO0OFqoGJI1iZSuJUl7C1RQpzHeGCGBVjmzhkLYpGTgZSL/X0em47sFd179733U6/puQipJPPQ3xyGG6yuCQBRZvm9Dk5L2WSOHDif2pM2QoSMlK+y7bNEFljwaLRGhT1LLGjQVJgEGSp5/NnyTCG3HtgJX7wnvdHz02r/u8q4TdZwgYAoaAIWAIbCkCnLP94Hvfc3fffodOk/eqivqfOuXB7BS5cOPLc3fx+Gs46b3oVLijU7FBlfhArIhMHypED1W0nUvA3QHaEKAPs/coZypwre9+8V/WbmvhwMRbY7kzB/IysdMGDPvtVbCv2APUkmi7AGrnTJQd1/UnpPb7zoFEJiX92sOvvsyQR+mAVEZo6Fz1irRKmkjdWB31GQ1IutNAX3Y6kL+95wNq5eQt8uXzjoO31yTvuxKayDZIGIZQZWxIaKKPUdk+q07IcBPr15NACr5ZW53aUhCzV88i2qXg6FQxe2lAKa87UHsVWX3x8oU7+vAjyzDTtErZ94aAIWAIGAKGwA1DwPOB/u6ue/jBB65/gN52cdeKFkaxVhW7mO7kAzSSuVu7cYNchdUX0TFOPmnGZOQuv33iRscvMS6V6GXETUVrElzFeDE7bQO5DTGSgXBD85RyARhqTZigEHMuXzIjhhDOCjtAZknx7Z/+l6rtiLgGZsDZM6h0Wh0tYYkFH1iENAqIXwdOHAVdO0VyRhYH/KEyuAAq5L+GoAAeVU5ij39DcACNtqR1VGIZ7DS1moMW2GKg1Il6QCQEIpIw4fG6Rb/vhq+8iYZH7Y/uWZiecS4cPQOEbYdSGY9yah2185DqrPh2bRxQXlKW2kiWHNpmks/jDulQkCgshFN6+ofl6so9/+wzSBGZBn/csPXJumMIGAKGgCFgCBgChICckOq17W+/7TpePjxlbzsyWjwEk5ybHNjJUpcSYVapTVh5EDNJuYB0CshRyUHrSfvl0yduOho51/GxlUF2jfyceJbyasdSFe1o5cQ0rHpQWdaTjJDBoZl41bVzm+tWPuGU9QE/JCcp+loLV3z7p/5FYq+cLF3NvwhAXZy2ifj6zPep11trkNgM6A8gEwvm/tbZ3onOEgfVT0WoKVDH0Apsm1BkfdysikzWZfCosxkA0Kh88UjxA7Ji89EBUN3dPTe47/Xt/oTXWIOu260zu8d2Y9BPJYabStePJeP3fHJs8MhrbzweYoCflPPwpxssocZUYR+3nftVLlNbflzr2XeH7vnnP4Y0kRIxbkubIWAIGAKGgCFgCNxYBCSTzAcfgLYdGIYcCqNkG5o6wjXIfOHgTybmQoYT/zIRWKHUcB+xD6gwxDR6DnL55Cs3PjsLqSADdcKamGemvtUsvS2708V5rsQi2ArMZkMgpOaG8DS8LiWPynzgZDGc2OXbX/DEXbFjlpREvnoVequmG3tTg1dV1QxF6jQ52ChsIB5s5AM5O8NdV3R9Qn4kpIH2ht+jpmSme/33dVRaq6bkCKcmKVVoAenb+/ceuN7+Hdkv0XNCplvGhIs+4vRBCoe4X6p9CVZlsh8sRK0m0octpYEWuTaLcVNx1oGMGN0sapmicKOzc3f40Ufu6vTUiPuNXaKtY4aAIWAIGAKGAFM45Io7Dx+6+++95zq9vvKsB5qH3DBhfZC5kFMtav0JoxvIe1mloFUZsWPZ883Ri2fu8vCpm07GCR9JIyg1Aw16kXR8dQ1xvpf8TIhZaJ6xxWUy7WeWlUR8fvsL/wKgwQqMNJd5yjdDMTG/DR7sQL8TGwmtDfJSI2nfcUWvW8osWPkQaAOkxrM980NUmkFqRuUKo3bAiWC9vhu8+jqc8qqc8mUbJC0nZcpUJnusRbyugaUytEQMQQ1mXkT2ozLxZi3vj5qU2XCpxTGxWCOby0uN/IFMX37lTr/9DuVE14jonnk87QZDwBAwBAwBQ8AQWCkCyIl67t4PfuB2Hz6U975SgkB7qjUbVUcwoY4iFddofUOc8iSucXp16c4ff+2mF+dJdhkm7kyWUEyP8ur0dyqT3OvVWWbKvWW9hNaISEp0ReFiSk8mQUT4sJ3Fk5/3xJ2E+JqVpwGoioXHGWRCZ6DSOEdNnLqHyvRpHz1pd/7oW9riABAknjJsp0CH1UmikR2ielnmt8hEyU4IkzdnTdQEE0R+7tQ6cc519/Zd/8ErcjIXD0YqQdftgHSVnO4lYyimew2pFIVnfWkvoWyySZREdDpwukWRGoAVj7rUR8e8yvTU85QGzI/n+dGRe/7jz00us9Kl0yozBAwBQ8AQMARWjwAEpe7tuYfvvw+npGKKa/ypCtisoGTS+EBPmP4y8Y9oMJ5YL4XhtfCnL2AycVfe63701LmxP+keD4GCH504nkhskN0QeWbPNreKdgdCp5CkpinKtVdaqeED7xVpkJLfKO852QgqOpOa/ORP/vOwNyGbAqIJj13CgeulrlYqKEkhE1sjnp1iIKr3tPuTtApP2iXTospkkpJAAJa6zDYCNSEMeDmfDpP9MCYSlhwChnlQk1NwhZ8zQU0DjOGCqSs6Pdd/8NB5jTtbfpLap9TG8BBFRoaQbTI0MmKhlLjLHKL21VmwiS0Wq6Kyuioez3jTIJSTpockbRk9MWKgFB3I5X708cdudH5uHvfVr6FWoyFgCBgChoAhsBIEUALdcXuvveruvvUWpYCMPL5xOxJiQ7Sqtq2RjzFyQCKJK6kRuDQ4SfXKXTz5xk3OT8nrTqWJxzmUzgp5If7sQRbduiKF4WjUslCdA3F10GTqYBVe6x3N2hvNnFUzPCHuvy/4yFNP7KzDzcjrdIpIzzFYwHva/cmonS5ZQroHxKIliIEqF8Cod+nfnGecipJI3tjuUGHJFBXM6pK8HVLfc2qK3zUYvPKqK3p9HDBpQ1n9k4NWfwaRzjrpumpBzkFeDmRgwo1XV1mxsQEWcgHFHa6eCFGb9RCFHD2URQmzy7z44gt3/ux5dHLZrNPKrjcEDAFDwBAwBAyBzUVgOvEnyHuZzLtu5/6D+Lwj2a5PFMXJyaWaA5dIjJCPTK7F1KOf8jqSv4xe0IFMEzyQSTULgQXiFBrF8ZjMrhj9WJYTpUORARInZo6o5/gpOVJRVRxahlwulhAVT/7kPycO/sC7U3qmSDPx69A6+sDLUoLfGTVCQGYLSMHjUyUW/QF52lPCXjUZmYRWBwmUGDkUleb61AS1qixEMh7ICvoLF3Vc/9591z24k/cmZ7lvjWWkvmpHmzVmTWZB7tq2Vlo6w+qE8vE4+ujyk+++cyePHrvJOA0K2dwFyFpmCBgChoAhYAgYAu0R8MS9t7vjHrz/I9f3UmjFvJlJldhE4uyM5CSkYsGs3sRX1PWBRCtarbIB5pQKPvbu8rvHbnR6TPw847mtoUaBucbKA41SyRgo8Uq8WjBJBCNViGupUfHkT/xeUSHF1DW1KRi8uNgcRQ5024GOveMJe69HBFdSy+BgqL0NtDTo1FHdsSQpIrcgJPxJYkFVKpXQp7L0QzRQQQ3FewNgD6BqiLdEQr8hmUx/4Aavvgb/yumxPAcSnX8wCEJ/IyNMTRQcnIqZAx/HwRQySbQ2CCoMnncuLUQ/qykfvsxuEyAGoc6Q0lIdPMwWHweCqzTy5y9fuuc//sJNRlcml2m/BtqVhoAhYAgYAobAdiBA7uWd+/fc3XfewTNtSD2RcwOntAOpU6wQr0rvp2hWlJkmB1SOSY3PTtzFt0/c5OqSdgW4dtUGLTlnnqoTokT55JXhIGm4qfUkZ5Z2sOHBvvBAhwkBOtUeHN/EWROwoAgk7ikZD0ewRr5xKkBJq+VGUbBIdGrhnM8cw172DnJ0GBwiej5qNwQv0Odwv1YYMYLl/J+Bn7M1lk4RvxuCvcd+pOdrJQNFDBs2JaS6MnH3Owj9u/dcd/8eaLqiaGd9Claa7oUOhMIRCgMTAnTDXoFut0zgJHg3a9nxGEkuez6sivOj0iSVyaAitWk7CZDiHRS12YK30P/p6cFAW4rCpkkgY1p03OjiAnXuFxeUq3871iFrpSFgCBgChoAhYAg0IwDZZLpdt//mG27/tVclWUd0p9AzTb0zZZfYdo76V9F0HWyK/K7kkZxO3OWzQ3f1/JlzkzFlP1EnzWvdRXIOUHCHUv2B+CqZTexO5/NdWYUTznsK+d3LouXUDc8cF7tUPP7jvwdocnosj/ZPI8w53TRTOT5FiuixP52qN4ATRTENoPasKxND5ybUZ8ZKwnqGnYJnxcKgX6LxF8YazBRoTpL/nAeCe62jSRnZKHWhPgEK6y0GQzdkbTtAoyYHt0lIOqYVCk2nMshoiTcdQh8Cr1anfPE2gJ6zUF8waqJpqiy1cFJZYn3prSqehPqwBLJ6wjOHden88FH90Fc8Gc1fNB5duWc//txdnZyYzr15/bMrDAFDwBAwBAyBrULAE/dur+/uvfeOGx7QmTbkhQfmqI8CSpyBuqORqBlIh6LKikaqr8jrHpgPS0pyJ9+w+9YrAC6+e+K89x3bltG7RwlX2AhALlw2CDQZ1UGlfL02IjLGBDJLYdr4myJwQViD7tPHf+x3q1yQBKHidtodn6ZlDKQzCIv8YUpey+6tL0iNSJ0seYdVfsTc+Z4antIMTgvTJ4VCndoaSu5Osubo3QbcEVCBCQyljJPXyHht+wPX3T8IRgncxjCWrcl0AkmL0vHPbWVEzdc7FGqsuMc6sLeEkdKxxE8Kz5cYKC2oikBK5i11F4dTW4WUJWc0cS++eQSpIcNBXS3WJD49rbQfRGOUtinNvwnznvOgyoxoUbFdYggYAoaAIWAIGAJtEfDxbL3h0N3/0Q/hX3EFRxn7/n/27sTLtizPC/q+N4YXb8rMl5lVldVZ1TbQDLrwjwIFaUCXA4qiLgecltKMjagIgooK4iwOf4BruZSGpm2arq4pK7MyK8c3v3jxYrjhOns+597IgaK73873SajOlxE37t33s/d98d37/PY+XSVFDeFpITc+fnkqeZ/O+3KVsrCbs8H8ZkzzddTS/tn6bG7TxdPjcPLxh+Hy9FnOCjkn1FydQlR/x/sUp1tiLY/oQ9SuSohZ5Krrs2VfaLnxVA7u8fvds5T/rqfmzIJ7n4T6tN+/ZDermcop4pOnYx7jUY8H+2G9dxA3o7ao1BeSLHYUl+zZTUDabCl9s5+bLP+8HFTlHcznKbnso3t7yxhX8/NyIlSB291e10fXw8Gd1+Oxlu112pOXkN533tWybaPszpxd32CbDLT3uJydlW3V7dpI3wvz2vTU8vm9y5r2nCG3sb+57mKzRT//iK0qd0Cb/hg3qN4Nxx99FDabq2/EFPcJdCE9TgLW63TJbRqw8Va7U1vK5aVy5aYF+TSzn/4CyP+edo5vNnUPQhpQqbRn92zl8/415XEECBAgQIBAuVnOwc2b4ZWf/Ml4ssyUDaeF2xJA+8QRv95fyV/krvSfKdmXSoGU4fugmH+Hd/fDScdB5tctK9S7Do8vK9vTHVUfPwhn9z4JlxfnKc+Vxb4+TPbFNouvp7yTz6hvUaSF12XlThc9YtO7u9LXScZiSMWHlfxVKiQ++NnfXYu4yxGSaXNkSdX53336vExH6cRXLWUx00p7DEXrFArLjGoZhrtGJajtEqR58N4O8GVW0J+e2NqewlnKgOldxqlDVyofv1M7oKud74P6bNIwPd8m3hHs8M7rYe/oei4cKtG49Wabo306YV+etCsoz2ue6lDuNnC01756Qbz9XHu+7d3Q7efbBGF7wrSrI5dTpH4Dc3rWKUSf3HsQHn+wOFlmsaI+BfR4tWa9js7712+E/Rs3wv7R9bB3dC2sD6+Fvan0ajpSdArze+s41qaJwRTOp0nBtGP84uw0bE5Pw8XJs3B+8jScHx+H86fH8SZQ02MvLy7Sz5QQn//tr18CBAgQIEDgiwmUK+lHd+6El974Wju/vUaGLjssjybv4mVbUOtP95jf42eWw7uYmsLGIly2CJi+UcJmjS2rmAXO7n8Szh/er7mgL5vpFyWXKsvc1i9Lt0Nb2v1N66Lust1d1F4ugi4Xo8tS9ur9n/3d3ZHvfWlLv3bc31wqvWoNWtPK8xSkyj9drfpsPblHqw3N87DZMvsyPe+6OVMXexczoNi2MmPr95XGWvdCu4il8dLJjhr+vl3rVdi/+VLYf2nakLpLftd0o6Lsri+ZbZn9Ij+f3+VyGjYbuTuG2ezxeetBP4nZ+rwu2/RZbSxPUKaFlyFsQjh9/CQ8eO+9GJ7TByjfJXc6cWg/nTp0+NLL4drLr4TD27fD/s0b6YrGFOanKzlx9T2vtq+LfdeWy02amG3y1Ya8yj716OXFFNbPw/nj43D6+FF49uBBOH34IO4oT2H+ou6J2N2vX+wvMY8mQIAAAQIvikDcmLpehxuvfyXceP3VWCZdQ2yMAvl3dZe66ypyf+27hvpZ7K3L2Wk1PZ26l6pl8uJgX9I8y6HzBdWyNy/l+VaPMNW7n977OFw8fpSyyZQx6oryFcvI/d1W+5r3uhrdZaFuopCaPAum3TBZ1maUNJt/pq9jef9nf1fXxHbqSl+2UE89mbCmQBVDVV5d7zeVtvReg2pZgZ4X2m83pB/krWykrV/3Rz/ueBtXFG/0QXJXiL6qHR1gbkwskXn51bCebra02JzQ2tumDW28tolIOVoxp9eUYfM1gf4566wrX/ppZR2tXf3nYblRYv6cu1/j6iKkblty+bzNzuMpty6+KtSXyz9l+rSKd1C9/8474eL0LH6opxX16arF0at3wtGrr4fDl15K5/yXVfdpJT1+QLsPZvfnptz+1FqTSmhqn+SNGdMVk7LiPt0Y6vThw3By9+NwcvdeuDh5Wlfk1cW/KL9uvE8CBAgQ+HEFyokyt772tXB055W21222VDo7WyW/5HLNehHYZ4XSrZV1YXaRw+bHg+cF5lltRHeC3qJmYlrIe3b347CJm1Xnia6UFZejwetJev3No0otfzxcvS/j7TJmySX9/s76c3l+0yfZRTP6bZSrD/7Y77qMt1mNdSdl92960+lYxLzaud6LpQyxlj0ves7u5RQ1+xnOp0XSrsK4m4zVfaGLicds0tYVi6Su7MtVrrgG0R/v08XlflIxNyrf2cTZ3XQ6zsErr4a9o6P2TOU89TrDSj2QcPMAWTQnTdLadYganssJM+VawazUJ59WlOucumffqv+vfZZLg9LErt/4UOraE3Bp3lbt2I5JZv/Y+RlEua6stKa+53z6TAjh7Nmz8OCH78Wxc/Tqq+H6V74art25E/YO0ybmWMseG18OR+17owvv3cx9ustsnTPnYyxTRs+3PS7zpf48/unKUJ7xbjbT1YCLcHF2Fp7duxuOP/wgPLt3L1ycnsZyGgH+x/3r3M8TIECAwJddIAb3/f3w0k98PRzeKod2LFePFycL9qeklOy484L+PNzPs3wrg54Vi3f3Bqr29Wlqkll0yypsTp/FlffN0+PZQRr9O+lbs3Ppcnkn2O5VtqcD28unfaO6fF+/XBP2+3/sd/W3PG2bANcpUKVQlc/qzoX7dUU4P0sL8u0qQHml2RWH+sXF7KIrvO9PiKzpsp+V5FKl2Twhp9BSCbK8ihG7qtsE0Hdd3SCwmAPGyzLT19Z7+cz22+kKSr+cW0o+St6sl3HyWfQpjZb/n44cinj9ToOCUjZNpgBbB0vdDt1ds+hvrlRL9MsJKt3P1psn9Sm9w+xHSUYpk4tuzXre3trZbTi3wTy/m0CacKX3fHa2Cddffz0c3L4V1nv7aWzl8pbl1Ya6yWSxhbRNN/qK/eWb6IL+jr8xZ3+dpA6ddtDGG0SdP34Snrz/fjj+6MNYH395ngP8ztKoL/tfx94fAQIECBD4dIEY3A/2w8tvvhkOb1zPK40th5S1zdk+0l1P2Sfhug7c1tfbjyxW5VqEKuUA9YSafvl4vhyYn7eugqcoMIX3qea9hPd8k5rFjsf0gluBPi8s9mv9szlEl/rr+Trl5MUuQ5YF7LzGOJ975PnP6oM//ntSCppCzGod1rGGOD9tF1h2zzSW57+3jLeYJ3Xd1B0JlJP58gLJsvQj5+7dFdz1zPfuTp6LmvX5zKgNhOWccDaWYq3TOuzfvBX2b788r+Pvd97WGcSsV7ptxmUE9oeQLnRaSm/Docw2yggpk4D432XgdvG6c8gFYN3oqlOtNj2pTcjztq3ZV38DgH4Db/7Bfldxnly0Cd10zns6ZWjvxq2wf/N22niaV9fnd1TLH608oWkr5vnZuqanTcbdCv/WBuhcO5/HVZwA1clm9xHOV4bKpCI2Pz/XVPd+9uQ4PHn/vXD8wfvh/OSkrcAL8H6HESBAgACBKhDPcD84CC9/882wf3St3vGzHgzSrxt2VQV9ui7Xz2sxS15ILFUrpa69XDFvk4GuBKe/RVA+laasWpeqktmBJjFYtpxTItZ01f3s/t18xntZne5WjGtqz/ezKZksP0E/1WjHYpZjL/vA300l+rMwSy1BPZlnWcS/CquP/szvb6fj53rgVjy/K653MbrfdDBPvbMZSlpa7QJsfIrFFKM/KqbbLpue9qppwGKK1k9VrprqzNqZR0d/2SavkE8Tmb2jG+Hg5VfiHWDTyvz2BtZlbu93RtfBMpWr5MnE7KW6AyVLmC2r1K18a3nnghKcy+k5afDMjs3Jo7XcCCmWlfRhvztbtQjUwpl4MWA+pYlTrVJjngd6O7M9PcPltAs1D+DV/l485/7g1svxTP+0yTSdMDPrz9LuOUp3f9tu7tH129WTwvLsqTwo3YE3bWgpLzGfxM2bk4ZamoJvLqYA/yQ8/uE7sYzm4tmzfOOpdCylfwgQIECAwIsuUIL7K998M5YTr6bDIWZ13ssl0nKkc78GPi+1LvlwVwVGCdh1o2q/2bOuabb9mq10OUfqEj37XNpXEqxWYXM2rbzfDxfHj9PdVWM26A5h+bROrxUVX3RkLDyu+vGJ76Of+5lc457LXEoSXbyRWZl4KffodrmWvJsnOrk0pd01dBmxa5v6MzDzF/si/LqmXOuYu9XfMqvqdgjP25khup5OIbbMBcru5PLCeRvCVNZ/7Xo4eOlOWE2bUfNGybSo3W3gXVwDaNOANkBKZU2ZfuSUm8Lk1gWYrhhkCp3TRKHP7TnoJ/7U9npCS/e9vr8/beoVc3bNrt3dXRdfba3KP1HHV64nj42crlDsxU2nBy+9HKbNvKvVfts7kcfKduhefnjzaTe5v9OPLYNyaVG5Y2+HuTUJu+IvidmHoq3u178o8uk100bWk7t3w6NI1ByqAAAgAElEQVR3fhCe3bsfS2rqufJf9HPp8QQIECBA4EskUIL7nW++GdbXrsXS05puunuzzH+N9wuQfd1Jv5ia81lfM1K/XX6vlwy0OGeynChZFqPLQm7JE32wqsvyOd/kx0yn0Z09uB/OnzxMZbMxu89OvmhbSXN5c79w2xZf50fnpAXVxQAoi+AllM0ZUmysC5Fxxf1netocJufxakehxaJNux9fmracRyzWXft155Jru3c1f+5lEF2O/3pp5e/jg1FWhOMJMi+9Eo8pXJ4g0562L/npg2X/bvOllEUn9We4b5+20/fc/DT3qx/bpgCfvhq9nD71Pbtci16+p12g7U6u0wbeqaRo/9ZLcbLTTwPqT24td396a2ev2F3S2l0ztX0aztb4W5T0LC/kdPOR2ZNN4+Li5CQ8fu+98Pjdd8L506f5c5JX6P8+xpofIUCAAAECowvMgvvhwWyPXvuVn/7UDufI+aKs0nahMFYqxF+tXZ18/n65qVN8tlIfPg8KrbqhmymUsFxW6WNbSk16KnPo9iLm1L9exTLZ8yePw9l0zvvZaW5XuldRn8da6pun3U/7r1TZkicCVae8mZa/2pEi7dyc1Yd/6veldFg2VtYTLuf3n911Q6C6ul5OLsmZs+bU3GsFebZjoG5c3I7xqcntrMtWUt7XI6U/9z89C2rLk1rKpK7LinV1NX4t3QF27/BaPKt9fXCtu7do/0b6UXJFEO7LgOpMr3TQrmlQCev9CngL4/2gKi5pxraVhNsdx7ryljzaZqf+zP+y6Pcnb+/+TqcL1etL6UdrpdMq3iRp/5U7YX39RliXy0mzyUrqy1S/3urUu+OJ8sp8e09pdpnKdvLHeLEdJM9Aa98Vu/zoPEuvV0nKlYvZ5Zy20l6vxOS/EEpL6gd0unx2fh5O7t0ND9/6fnh2/77a99F/42g/AQIECPxYAim474dXvvFmWMfgXq6Rt+MX+7SyfLFWpT5flt1VAxBrHsp57luJIL1Kf/fU+W0qy2Qhl2pv1U/Ml1RTO9Pi5ObZSQzvm5On8YaPsaXd6nvJY/Ed97X2NbLm0/1K5K8TkRZ9ZpFpGcMyWlmpX334p3/f5Spe2pieuESkkvFL03MoijmnnIhS6vpz+Jmt/XcnapaTV3KJSX8Y4iwBdpsIUxnI/ODERc1IIZ2f8lJifJ5B1TlLKbuI/VC+WuTye1ytwvroKOzfmkL7YTchyI9LKXJr1jiXWsThuJGy24yQy3TqTDEfD5kibcrh6fJHdyOsvgNL5832B7QebT/bnqsW9syKxfrZXMn/3dywtLNvR0nrObTHNu9Ntey30/n2hwf1BJld6+jtFZvRcgrTf7iLR50gLApmyiR5+f3uHg9bfxktp4gtnC/nz90Eqt91ng3PnzwJD99+Kzz54P2wOVU682P9re+HCRAgQGBYgRLcX3rz62H/8HBxDvqnXdVf/sbf9djdW1z7fY8pb+xKHcvpQp9vP20qsUwG6b+nMtnpJk3njx+Fy4uzErzyLGVZgTG/+2t/AEtbbl3eQirtRSw3l5rfArW845QNV3f/0h++vJjuJHlxUY+CLDFmtsy/yLufa5RtLwhv/9iW96LzrkqBy6X22XTlc7WuLRuv17Em++D2VOaxn1NbfsOfssm1nJFerprUoyXrMYy9YLuCEDd21qsFXUiP46MU/eeh2G/ULcftlzlEqXVf1nXPNobkDp+dldnVfefJSJtQzS/uzDYRT88R53hTaN8Phy+/Gq9OTJt323WmYp87rtsUu/hO3Wuw7Lp+qKUF9fzR7I70LJOoVkFTbrxUVtG7yVDdE9DOfo8z47gK3/VFvvTWdqKXeV670pOeYRUuTp+Fx++9Gx69/YN48oy698/7mfM4AgQIEPiyCNRz3L/+tXBwNAX3fHW9vsEW1kqxzPxwkvLAXaEu/16PNzbKz5sz2SKpdJwtJu862CT93CLQ1hywvM9OvuqfF1SnmzhuTk/C2aMHcRU+XGzyknm+51HZY1sqAeoJjYvW7go9fZ33cg4zvbuyRj61//hv/InL07sfh9P79+osIoWZMqHoEfLP1jZ0gaarrNm5CWE2SnNY6vYXtNXsVrazVcG/yMHz0z2689LrhGne9vre6yr4ZVhNGypv3IzHPk5htN01q7uSsDyWpO0Jbe+qr7vZdWDprO39jGbHinc+CSUOre7CwOxiQTfu2lPn5+37b/bhKZOR8ryLM93rKUFd/Vg3DsrJMtMViYNXXgv7t26HMB3xONslcdXH6YoPZbrWs2ObbxvZ849Sf/ktz0l3TO7mX7r6I741mcjXVNqG2OXPJrPp/00z8OMPPwwPvv+9cHZ8HJ8qnbbjHwIECBAg8OUXqMH9a18J+9eP0u/zbrEt/XLvbwSZqt3TV9Oqc6s4aHXf7US4q1bTF7F8R3VC/Z2cT8vr71NTw3s+BKQ9tpQOt5A1u3PMFF8vzsPF8ZNw8eRRmA6wmMpncgDYWb7dj4KtNPJp8aQ75rt/2Orp//lzl1Pt7vmjB+H07kdh8+xZPZ9kOou7y45lvrO4iWwJXu1SQasrarVO6VHz80HSf/ddOH972zOj+W1z26ypDITlmS+tw1sXTOrTLGkVg/oUPqdjH6cjC1MDcyvr8YdtcJVV5RLO0qptHnp9LVN+X2WwxgFRL4Gk1J/Hcl5gTz/czhVvA2f6UJQLPG2SmO/SGjunHAdZJmRlhppXxjNp3fCRGtMmBN1u5tjGftiVE3jKZajpRgvXrofDV18P6xs341nt9bl2XV3ZWjrvBkCZkMwmbzv+klvm4OXkrf+RZRv6n+1nsOlvjPRPf0WgnwVf9X5mM+FVmGbgJ598HO5/97vh9PGj/NkV3r/8v668QwIECBCIwX1vL9z6ymvxBkx1oW1R0ltPySu/elNS7mqJF/kgr1rXlfacRlN2WpwuWDd69ivIbWPj7F5B3SJrS4hbq8KLDai50fEH2lWAy/PzsDk+jsdGTgt5l5ebtt48W8QrC8E7njY3okWR9tj4XuNb6r42/ffT/+NPx2g4veDUgCm8T42It32f0k0uwC/tTZknvVJZ2a/7SMuCb9cxFaYLcbM8Vco/lo3vyyJ6s2W2Xvx8Sk71lMSWzXLITX2+CuvDo3jW+OrwWno/yxKVAjZtcu2XvfNdZNNUIb+Tbmd0DdllIHUbKOqmijI3qK+RGp1y47yyqQza8tdDnc3GFypTm3ZsZJnH1rr5cnUgT2lbiUh/OStPoeqNidrgam/tMuzF0P6VHNrzGJhNxtK7j5ONshm1Ttc+KxWXeVNXDzQbR9thuJveVIk2+Vr+hdq3tw3GNjksM4ncF/kh7VXnVwVqP8exNoX3u+H+d78TTh8J736VESBAgMCLIZCC+zrcePVOuHZzWtCb/9acZaJKsvx9nn//zo5FzHG7y47tPI4WudvZ2t1q4Nav/26zYX2+nFdyZpzyWV3DL0+/3BNZMkkps53yzuYyrcCfPAkXx8fh8uw8XF5ezGr966mUXS3+ci0xN6O1YSv/lAy1Cqvj//1PtSnKVMJ8nu4adfbgXrg8O8uBKJ240q3ppjBbr2p0iN3lj7aKXI/0mO/jrZOc7eXQ5dp6V7tT3049y3xx2aVuVYhnoadgVZZY44bK6zfC3o0bYbV3sHtWtTW4+uXhZQBtVxxanXft9fnwqYG2xfB60k7+UpMsVw92jtpuOlA4lueVt06eXUnI/dbKmWbTqB1L4un5p/NZD1/7aiwrKqVUsddmJ+jkUvd8Ekw9d3R2QSxfLSgTyO7uYLHPZzPpfkG8v6FC2YaQr3iUSV83kenviNbqcEp4z3+VxP/sP6zdkVB5EpXefZpMlFNx5teN0ux/s7kMz+59Eu5/59vh9PHj9FPKZl6M31zeJQECBF5QgRjc1+tw9PLtcPTS7bxXsjsoLi9HxlwWF0LbKnJZPY+huVu8rSUtJUuUfNQf6NFHo/I7uu7ZawuT9VTCssJcUs4sIpU7srff923RNJ27Xg++iN9oK3vlaeKC5cVF3P92cXJca+BjVt50p83kbJDecl6uLVmh5pGElPZRZrA8WYiJ5fh/+5Pzcx+nB24uYv3O2b274fzpkzibSHW9+RJFfp7ZOJ0hbqXQmn921ss0q/Tt2SbE/qzL/o3Ms2s687M7zaY0LkJMz7EX1oeHYf9GXmW/qmB864jFcpGl3AyglLmkE2PaP/16ed1HkE7HSaNz67HLIqM5UvmZdopn+kqL9vF0mjzgy/GJfde04qR5OVJ/Es7i7J5utlc2bV6G9WEK7VNZUd3MWSdd+W0t/7t/x4uTJGspfT+/KRPu7jOx/fdg9yKL10tjO5/N2n2vvUSuu+vv21D/Ammfw/iay+OsugDe3xRt3vzk9fSTj8O973w7TCfP2LD6gv4m87YJECDwoghMGWS9Coc3boabd14O6722kj0/RXp7cTH9Pu1ualSu+ufAWvNNyT6LEwLrK9UbUubFxDJZyCdN9KdylwXWeu5HzYolt7aUVZb6WuFAeg8lW6WosThbcMohl5uYmzenz8Lm5CRcnp6mBeQpwIdN3RY4yxCzhb7toykjU/z5acX9b/yJNtWpGT8Fz8vzs3D+6GE4e3A3bM5OY/lM3UywtVC7vXJb3tSOtza7HNDtF95eSS5r4p9yzt9WZqybJVOpz1TLHlfZp7t5rtcp4McNCY1tvkbeuiOGr1iTvqioz+fedxF9Vu6Sfq7fhJEGRWbvVnCv+nSX1+zaUq9mlOXqFFb7YTabFdYymbZxt+T+/p3PN4rUAqB0MWB/L4X22y/HmvY6kGOz2ySifxdpQprr9ksQn01y5j+5+1k+5W+9ZX1bWTmvM+HFi8Wm9ufo91OgHY8tn9+do7H/5qLl02rCZhOOP/gg3P/ed+NNm+JEx8r7i/IrzPskQIDACymwf+1auPX6nbDenw6sKGlnKxnk5FBW3ls1Rn1kH+jKSm5Xctt+6y5Xi+cpriWuHW2oz9u1swtPy0yStj7Olzznndz/RLe4GnP6lL+mEH8WNmfP4o2cNtOdWKcgX+64Gv+dq1hKIUC3iJnqXUpWmYL7//rHt+6c2rZjrsJmmjmUAP/ofpo5TPXvJTzFMFfwu6TTTaJie7odvyVfzVesS216d2+t3C/17rT5MkLkmzm1B5Y3MwX0KXROmymnwD6dflKid9mtXJ8iltRklu4SSCmjqGG1O3Ulvf0dnZW/tJwS9PFwNpfaOuu9T4vp0lIcWn1Jx9ZVgRKE82yw947uOfxn8LoJNXdE7cr4nspZopsQ1vvh8M5r4eCVO3nz7vLNFfeS4fs54MImPrTetWk+UFotS/os7BogM8BuE0P5kNcxvQzo+Qlnx2Euknn/+Z+F/+79lo0TpX3Lv5rrXzarsLk4D4/ffS88/MFbccd53PjsHwIECBAg8CUUKGe53/7Kq2HvIN2EKf3Gz8uypTqg/IK/8pjt5dEwXY7IN9VsexLTL+N+gbgsjbaIvVwPL7/sSyfMk9n85/o6iRaalxOCedXCIkzkPBGfN67ExyXxeArNlBMuzy/iyvzl5jxcXmziwt90X6X6uLJGG0uMppy6DmHKtk/+l5+dn11fneYNiJtXpwD/+FG4mM6wnAL8JhXgl4bX+qW2r3irMqab33TFI8uzZRpm37jl/KruQi017tNG2lgScy2usMfANAX2vixm62jH7g47sXH5VbZuclQESyrOHV9KVcp7jk1fBNz6QS1f78Nlf6xKec6+CGtXOM7Ps3wv9eigvnY7iy93OPePzR+x5Jl/dr0KB7dfCYevfSXtBVjlfQL1zqPzBNvn57KBtk2Qlsm4XkbpLjSV91SOouw/+HnqlPcstA9O96FcXGqoozJfkag7tpezxW52X6+q5Nl1t5e7/VU7e//938D9XwjTOe+n4cFb3wtP3n8/fRitun8Jf115SwQIECBQTpa5+eor4eD64aw8OC20tvrntNjdL+KVgN9nr7xg2WWTbt00Z8eWOtrZeyk7tl/rpYo8rZjH0J+/WUP6FTUzqRR5O4eUReuUKdI+ynYkdptoxDYt5iHxXdWH5ANeSpjvVtWnxdW4wp+zSFrs7WorYnCfrbn3K6WLAZk34YXNdIblcTh/8jBsnj5NNfB1NpF+Jj1LWclu4bM2vM+90bJbae9W1uPqf5et40ykPH5CmxYzp/8Ty2Guh4NbL4X10Y347BdTfX6cXJT6/HzaTH/qTM3A805td2otJTXd++pyaMpjrQ49gXdudbW7fLmLuHnAtMxZBl1fltNlxkWeLzPNWN9eR1h+/V1H/pSu3bEfoFby50s30ybUo6+8EdbXjtrlnMVwmIf1Pk73H5z51/unSB/g7XqUrUX0HSUry3lz+bD2n4vldKHL6N1Fp+22zj/48zc9n5/Pf3Z+UWAVz3a/+6vfCs/u30+fCeHdbzgCBAgQ+JIJlA2q1166FY5upSMhW2oth4R0v6VLEIy/NMuiaPtF39bRy31T+tLm8ls+/2wN0OWcubYA20f78ju4hOH5oRWLfFcX6ErJc/l+2ePYLfLmipM+sqfnXqaU+dHdXUrumtLXY7TsWx4QK0Om08wf/8//wbR/sv5TwvaseqFeosgPKwF+WtI/OwsXT4/TJtbpTlLTkn+s6bkMm3wG+da5njnA1HBfZxr1ke1IwX4XcZKPQX0KQau9dVhdOwp712/G/60PDuLu5ukxUxsunj6O7auXbXYueLeuba+eBlCaMPRxbz7GSglQfYFFR+2aAs06t242LYebpI6YtWPxAc/zhLTpte5J7iYFcZNGanNep07POdu80VrcP32q5b8Mq4Nr4eirb4S9G7e6qwet1j9Oyfpz6/PseTbB6q469BtD4iw02uYjLHMDZlVHV1bPtw9XXA3P5S/zE4jmk4EytGdl8WUY589emjB35/GnyfkVV4taD+a/L9Kz5RdqX0vP9/STu2mz6tOn6t2/ZL+svB0CBAgQaLno4Ogo3LwzHWIx7SXsrln3N6XMKadPnXnH5/xmjnVVr66u5mCWQ3F3ZbzW1PcbXbvfy/VYmBSGugBUFjq73/fdAmd/n5d0qtx8slCeq67O5+y1rP6dHUtTzoHvckjC6qo5ysJrCXzdlYKYnx7/T/9+LUxOtc/5CUpNb7/JsB7mmN/ZVJoyVVBMZTTTnaMuLuIROJtnT8PFs2dxQ+tUrxNDfDwOJx+L04/0vNqfVl/bDCUFoDRrW8USmFTfszo8TKUw166n1eD9vVgSU24WleqoU/umtlw8e5qP4tlx4kxKbF3I/eIfwXkQ37UO3J5zO8hvn+nyeVuwtZN59oOLycanPOmsTXF3+Doc3nk9HNx5rd2Uqhzj1M1CZ7OhGty7E3jqAF++63b5ZH61rF8f78zKRKQvYSofyPojZUa2/Ub7U2BKGVSZNGwd9DPrvv4/yoQq72vIH6b6+a65fXEDgSm6n1+Ex+/9MDx8552wmTZ3W3X/vEPc4wgQIEBgEIFY576/H26/9nJY7093oW/JdH4AxvyoyLLGl/Js22vY/6qsexdzZo/P3OfcLrbWUpjl5fHymH6Vbavoplsnrz8/nVaXXrhPM2VhtFZZxFPt8uNm5QgNos01ZtOaeir1LILkMvRccdNODp+cHv+PU3Cf1xul97JjI+F8STXNp0plyPS96SD6GNSn/38RC/Cnw+inAB/vKjXtpL04izW/cYNrXJjftK2WZTV9WkmfVs7392N99TQI1geHYXVwkEJ8yAX6yxBUgmUpQdmch/Mnj/LtaD89VC8/G92Yu/pjsyOT9qv7W5tvv+gHcDvpz5/hs77flZh81rsvVxam4zKn1fbpxlRpNJXvlGFaBvYitqaZV33Feub5Vi1MH9CXYX3XG5o/Zj7NWrxe1VleJ2lt7TefzOaPuePmB0G1Iqj6cc4fyPk5Q/1omb/2NPmcTpe59+1vh5N799JHS3j/op8EjydAgACB51iglMvcePl2ODg6rGe290mhrLkt8nd8V8uFsHacdYmj7RCUXdGrPHd9nrKG25nF75Ur/l1Jd3pIW6CL2Tb/ru+Tz67EUl+3HEe96KOt7bE54M8qJrq2tqyWyoNK7O4nQqtH/8O/1853L2e1l6rtuAJfagBy3XV8gXwgfVmBj+E9N68EuGVd+lRWE2c8OdjEmvj5KX3T9+P5G/mQ/ql0/TKsw3r677joPn2hhKQuOuUnSt9pN+WZJgVTLX5c+Z/eSTnBJfds6/x6yGXbHlBv4Nmxd6OlvM125aRtJmgDsPta/mI/Eds1WNtmhq5b8wk26fSelsbrMMs3KShzrWVI70/SXOTr+nxTWdNUanT01a+H/Zu3a5lI6uu+4qyUlMxvVjSbYM53LMw3Y3THau7+mTLq5zPS8qGaf7RSf6f313/M+8lG+xS1Z4zFPvUvi2TaxlMfvevWlvzpKW1e/gU0D/Il8LeeeHo3lcxMV6KcMvMc//bRNAIECBD44gI5hx3euBau355u1JhOU1uG3c//xP1v21Z20y+k78xQ+QWuWtdsQby0pLWwz4Szds4u3X/2O9iehPRTg/n72vVsV7W9tvjRf//v5ure+aphAinBvauX7s517DYKd1R9pGkwaaUxBaYaA+OdRLtdv7XMp50lPqWyFKTy+TL1PXfPU1+9racWpunMzPPj43RmZi69KdccYpu2jk7MEbHK5/PIYztzuxYlUrOzLmf12d2QzX+clXr1+0jLe+gCfvpSmUF056LHL5d2pceUTbvxR2oizuG0nFnf1aLXkJ8P9Z+uZOy/fCccvv7VsF7vtcnd7L0uBtwixfYf0NmfyyE65T329eP5gXV2u6P8rF78Wda+lwlYMbtitPf17bMPVPfzs/3Z5XXKjvD+h7JvG8/dZY3+b5HZ3wmrsDk7Dw/ffiudMpPH/Wd//D2CAAECBAiMIVCOhZzq3PfWe7OFxvIOdsbWz0yqi9+zu37XXpWAd0fS3Rv98nP0abjEsPg0W7cr3fGin/VernqNPjMsG9Dl1PjWH/13/05ZUp9dKrjijMgrWnmVTJ8i+27r1XekorqxsU988/XZ9GzL9evyvO21poF08eRxOvkmP75u1OyXqGchdHHo/FV9sxyBO5tYl+5nzzKfwM3XyLvrHNuv3C+f1+8ua6t3jIC61N73VZ57bjZhPW1I/fo34sk8sxny7D1++ojcnlkv552f/ZdP/Il6duOOx8fRWhJ39/0rJ7HpsZ85YS6fguUko3wqak1YN7Poum2nTH9FabUKp48ehbvf+paNqp89DDyCAAECBAYTKOUy12/faOUyi5hWc0Ifs7oFy+Xv0lRt238155ZsUxbR8gbN+X1My8Jgjj3LBcXKu2MZv4X0dBBGyibpJ9rhHK2D+qeYJbqu/bM8viM0dOviXVnt4qSMKVc8+uv/dhfc+5reXSOmvdLyIkY/fUnfy+Utu44lrKE7hbC6kl3yZzzFZsfJI7OOSg/e3t7ZVxSllejN6Um4OHmabkQ01cgvjzBJXVELPK6aiiWoq858mfdCf2XhU6d23Q7J5fWCErHnsf7T+2XmeUWureeVp00GcRROm1EPX/1KWE2z5Lrenp7gsy/s7G7TrvezfGQbyJ9nmto+sO0DuOyPz/M87X2lHi3/d/np7R+3PMOnPXZ7vrZj6/A0ps/Pw8Mf/jA8/tGPnO0+2C8kzSVAgACBzydwcO0gTOG93m09l1PHzLZrwWvXomcOH7Eqo0/MOy7Bl21jy6Xc+FL9mejdVryyFld/k/eLgotIMJs2dLfhKZOG+Lr9mt5yzblk11y5kaqe8xJt9igH0tTNtYsKg9qGGNz/238rH9o4P+KvRvhSXpFfeHe0mXdmLaypM6r2tkugr5X/3ar5MqDOO2Ee0PoD9+cLtNvr1dNZ7mnVfboRTu6RXD6SXnO+3NpXO6fv5nPSdy221pni/D228JvqYUopy6xevJbK9DG0jZgWmJeBtQXDOkmqVdv5Bkb9aT2LaxOzgyKn2vbDo3D0E2/Gk3rKLXhnW0Vmdx0tNxVIrzwP9a06vF2xmQfp1sd9b6fJQ5rhzkfYVWOgfj3PZks/1n0MZSqW69/bJtsyVku78mw6D6L084vNrbWP+3q97ujSut+8fXrTmCmX1sr1tVU4e/w43P32t8NZOR7y8/096FEECBAgQOC5F0g3Y1qHG7dvhv2D/e6YluUqYJeZFifEpDf5+Rfhth/dfr/H3+ctYnXtaY9pS3Tll/2iUqKE+k+5geO8Dd157OXKe/x3l08XK6K1iTu+3lJRXmZ89Nf+aK1MKFi7SjVms4N+xbqmk3JnrBaMZ3spl0bluMn48HZXrdkB2l06q+vh8eZBJWsvOrbWJHelI/nBm2fPwsWzkxbK6o+WqJjXyOvZ4GUTbg6nOXynH2tTpNmRoPncnvS1jjq/v9b3+TXj08xP9Jmv1c43o84Gcw6ssTX989cBXz7fXRCu09L8telf61U4fPnVWNseN03mzcftDrJl6pKH9qzvU/PTXCiPmjpI+wLxFGhruUo/0+oHdT33KK/yl3P0u09d3iLdTbcWzl0dWuyD2lXdB7G78VU/Z0urAf3YyVOcsvm3v1SWndNZ8uWvmMXfDmVjb/2wr+JpStPRkE8++MCq+3P/K0gDCRAgQOALCeTcdnj9MBzduF4PUVvk0fqUX/xQ7HlVxbxkuv8d3KJ0X/o9XzxcVm3kYDi7d1EfXpcLi/2C7Wcp7Z6IlMXX3aXfu55zFVYP/+q/mVrShb8UxPIPbE1Vdl6MmG8dzmv+cRPe7Lnyc5YTZ2Yhs+vWetxMQVrAlbaWU3ByON9Z/p1ffwpM042i4pGU/YyiHs3XV/931zlaLzfBxWk47fnaYf5bBVF1slHuBLYsLkoNLau9LXG2cJ8ONslTh/5887rjdfn6fT/2H5uyWj7Vth+Ga2+8Gfav32hpuaTZfC2pTuTyHVrnxyT146Sl8Hp5qx4HuZzy5mFXa8i7azr6uEAAACAASURBVFjlvNT+eM/+PebYXicss+HRFc61z223ybcMiDy26uc0/aEcY1kDfL85eHZ9od0voA7jfIfeekzTcnznLjh9+Cjc/c53nDDzWX/P+T4BAgQIDCeQznTfCzdu3Qjr/VR+u1x0q7miXOUuv4tzmfW0kHZF/Gq/crvi5bbgXJZX57mxTBDas87zZVkLTVGjhey2Vplas1zY7tu4nVjTd9v0YHv3aJ+/a0wsJ+XFZvRn4OXcNAX3Uk9eTnCJwHllu2GXYxxLyO/GUrdy3MpKtnce1LtT9tmpng3fZf8S3HPlQem9MhGoM5TYxtLC9IbqanweDGVhf2ridCzkxdOn8YSZWBKx4+MwmxVeMUW8auZYXn8ZUWcv07238vUSoxezn3ayS73C1E9uSlnGYiV5NilqrxylupXmWO+/WoW9Wy+Fa1/9evpwNbwdle3Lo2AWCnXylO8ulgdcf7Z7as0u9SbRZp9l6Xw5g84fndz+xfWSfO7p4uNTPohlnM6OLi3z3Hmv9X0yP/t9/r7rZ2f2vvpZeT/LThOr6YSZ+2+9FU7u3q17DIb7m1mDCRAgQIDALoH8a/LwaFp1v5ZzcB+kcwCeXZif3529331WcnQK0SX15RKYnGvq0ltZLOzuIp9LCWYt7e/evlhGjC+9tR7aF+fHGNL91KzSIL/d3M5IUcqlu4M1SrVG2XxbEmyrbsl/qpGjFdevHvw3/0ZN5PUOUFvntbQgMj+EsR1SX0s+6ip4O0s75aYSyVoxUz0Wrx5c3xU67fw45HYUiW4FtJ8FlflWiYl1AX9zGS6ePgmX56c76rPnJVV99IrPs6y+ye27KqRvz7z6EN0i7FWPa/GwDMft+urymNrWOmNdTKq6zF1fbzoec+8gXPvqG2H/9ss1UvcXjloFe9PYPv88vdZVB8G0ADwPyMv3nZ+lHRY6G+jl3k7tzPb0mq1MpZ8Q9C7Li2r9sFpMPdL7KCcPLbYqV4tytGYdQW0y0t5Ta8FsIlsnlpfh6Sd3w4O3fxA25+fupupXHwECBAh8qQRqrfvN62HvYDrTPQeUvopjVibdFutSXfqnLfKVkLr4Ld4vjMZvzdNAfxBhe+mSI/Lq+KyOvayELk92ydUNpcdyGUJahy6PXa6iLnevthtKtVXa3N7a9rK5Nr9QDhmrB//1v15btL22uXjTy1KBLu7Nz+YoAbs7qDw/eX82fHnPbdW0NXLHuRxtE+nW6/YTi3ZRpq8zTztEQ7yD6+bkSbjclNlSv7O3nJXeXSapuSz9fJs5teReh1etnug2JsRvdtuQZ20vC9BdicziJMoaBsuY76tf+s0b/cJue9p67ujssxI/H5dh7+goHH39m2F9eC2dLd4LL2e2pd2lH/vz1stHsptQz0z676d0PFfoXnh25notuZptle12D/Txf/dWlji28sbXq/5WrOO+m/j022zT9HtxESJvpC2jqH/u+nZmz1c/4SGs1vFuqlO5zNnxseD+pfp15c0QIECAQBE4PNwP125ca7/nlll7VlmxzJzNcbnQdtXC27yWYtejrn7OEk9mv+7rU7Scma4XLPbd1hzeBfduGJRFzPTvZaDYrtSfL6J2wX2KIw/+q3+tTSVmh10v10QXl/xrnfjy6/1bL+Ucu2JNP5uaB7D06PS1zz5WcUe7+iMmZ3lrukKwCdNG1c3ps3woZ0rKqTXp2KG+Pnt+fsvOeNYC75VjpD9nfR7SyzPOJjS1tjt/t176Kf+d2tqucnSd2p6wMS6pp/e43gv7L72SN6XmIyCvCOU1t/afqQVF7YX8mJz7277jrsmZuo3UxadlFnzbUGivuD3DTN/bEa77ZpbHzDcUz5+2fjTra+TLcoV712v3vl17SxXY4qCcNJG4mI6GfDccf/yxTapbneQLBAgQIDC6QDnXfSqX2T/YawWl3S/5kvTKr/A+DvTvf5kS+7g1i9Q1B5Q8t1jz7Z50667yC/BaSTBb1WwPim3oolj/Hq7qu13vo5TmLBdYU6l3O9Wwxrv7f+VfzVvqOq4YRC7TD+RHNqSW3lqlUZl/tHKIBtIH8PRk8znVkr8v0Mhzk1qe0LonN3G2+lpB8skoqaZ7vi0ghqmLy3Axrbqfn+X2LM/oLjzLycuurlj26FUTmb5U5OrnbRq7UuiyN5rHfILTpcd+k0XZDzAF9739cPS1nwh7t2+l+d+ySik/9SYdPFPL3/uSoU13tWhqWXxsfgPxX/1zlq+XE1iWNWT5sf2dyfp9w22fQyrLiTdTzm3sP1yxDbO9Duk/uq0Us06sV9a6LpndemBxtSs+rJtQz3q/nfpYx2XvsK4TwzRnPLl3L9z/wQ/C5uys3h569L+otZ8AAQIECPTxdu9gLxxdvxb29qZ8l35rzs+byGvQy1uY16S64/d4+f0fw3O3Ah5j0o6DOvJzzRbU+vPly/dLfugmAKV0Yefadt/VJRMtypPzO66hZZYSa77KObSs89Z/53Psu9XR1YP/8l9JF/27Z5qtMsevp8BY/zg7wq/futcVp9SM2Z54tpKdj0xczlYKeNfGlACnRFbf9iZutIwbTMv/1qXgJn0tBb30ztPjutvVri7jBsHNs6chbLaPA4rjITZgsZs3v6d6L4Cm0i2Aty5ql1Nm88F6VGRZZa8Hr8w+61mgG2VlQ20qaynfzz80m6QkqTztqX+u5UzTzx8ehKM33oynypTz03dd3SjPUXq2n04sj1hq5WXlQzRN/tKHql1BWSyMd4f5zPZ+dOVfPUsJzn3523IaNFtRz69d211nRnlSt+N16vvaEfjL65fxNdthviO4Lz7TbdK6WofzZ8/Cg+9/P54uE2dH/iFAgAABAl8mgen34nTs9OF+2D/Mq+79yXx9jlq8767ouPvOFOY2eQGt1OxexivXcVFtyjfTASQlMK7XYT3loVU67rrWvc/+3I6OLmF4Vn7fHyJXM0Xe41l+q/f19IsjDvv3kfaSpmxU33r5Q13V7lc4W+1/foNhdf+/+JfznZeW8agLhstE1a/D14CclZa7OOtS52x61O4dO6uszuElh+b4jPHd5SMUV+u0Mrk3BfF1WB0cxOC5PjwI6/39EPb3w2pvL55Hvt7bSyUJ0+N2haIp0F81u/syfWiuei+rVTJqF69ehHf9XL3HaTI0TSDrRoTnqnUaQ4AAAQIE/kEJpAXUH+ufGM5TdpvuRD6VnG7OL2L1xOb0NP3v5CSWQ6cgv4n7GdOfcwYtB6jUtuRFvBye65pzd1PL/miQRdrOb2dr+XCrtmS+mFoUWo3F3GX59ZKf80L0/f/8j1yWM6vTMZCL18sL7vXNlN2z06vUGUbX9vzz9die3FPpZdORhKlJ3RutG3fLzZXS9+INgdarWI+9OjwM+9evh/XRUdi7dhRW1w7T9/Nlkjgi8up7BfisUfJZ3/+xRthz/sNTP/aXDvqLAl+k6bNrPjtqyfrv73reHeMtf35qKczWjy2fc9d/95+L8uf2iWxP+Wnt2/X4OOCuqJm76vHLN9D/fB7DX4TcYwkQIECAwAslUJfQ+1rYvLib80xcjN1swmZzEQP8dPz3xZMn8X9xb+PFRbi8mEL8RV4wmwpYc6H6fCvi1npaya05nS6WPHPQzqfKpJw7v7XU7jlLO9J8dl/KPorXNe98+s20QH3vL/+RXBnQagZmuWTHueN9A+rKfs0zbabQH4jfgv+siqWd0pJvSxtD+rRifnAQ9q5fD3u3bsabA60OpqA+FTen1fatqduLvHr+Qn16vVkCBAgQIECAQLcqt0zGU6bcTCvumxTmz87C+aNH4fzRg3D26FFcnZ9uzJmC/HRgR1r8nR0ZmZ++lU+38vn+0IlaGZPb0Ofi/hS9XL2d1ia7Re7a9FKS03VsKv1ti9l7t18Kq/t/+V+aldosF153H8u4e7i0Cw7z2zb1Wz/ramV+1ViPtF7HEpcY1m/dCge3b4e9GzdCyGUvqWa9iPz9Lg0b4gQIECBAgAABAi+MQFdZkYL8Rbg8Ow/nTx6Hs3v3wtnDB3F1PlxchM1mk/YPlhLwxWSgLxCY/Po0+lnFBdW73IF+cRDesuS9Pne50rBeh/3rN8P61u2wuvuX/sXl/aCu7s+tli2+0GXr+n4XpRD1cPpcCrPa3w/7U1h/+eWwf+tmCHv7KciXEgIr6S/M58sbJUCAAAECBAj8mgmU8u28Gn95dhbOHjwIZ3c/if+eVuYvN+d5aX2K8csa2B31wVdl47yCPzvEYnlO9KeW/rYAvb5+PRzceimVjt/9z/5wvQrQoLqz+vKG1ri0v5Cclc93N5gqD+svL8SG5xNe9nLN+hTWD155Jdatl02l8WeF9V+zMeuJCRAgQIAAAQIvvEAf4i8uwsXxcTj9+KNw+snH4eLZSdz4OuXeeCLitIeyXwaf7ZFc3BW1LMd3C9cxL5fS81l4nm9EjVXvi7vLTjfJ3L/1clgd7KWzWu7+xX9hVnvSH4Gz80apsafTgfDlvOv52Zb5e6XhuXY9vtjeOt6t89qdV8P+K3fCumwwrS/6wg8jAAQIECBAgAABAr+eAjmHThtYN89OwrOPPw6nH34QN7hOtfD5bOt6ZnxZzN6VwfuvzWN5ekOf9f20fp1uBrqeDmaZVtr3D2pxzeruX/zn84HfOyp04rPvuCywaMlVtT3pJMdNvNnPtKp+7c6dcPDqq7Eh0wp7egdq1n89x6bXIkCAAAECBAgQ2CFQVuGnFfiTk/Dsww/Ds48+iKvxYXMRb/E4bWQtZd8t/5a76/R3uJnf/6i8Wrm3Tb/43W9cLTeNXB0ehb1bt8Pewf6soH519y/8oZyc2/E18znBsvy+ny+Um/ws3vy0yh6nI2m2cPjqa+Ha66+H9bVrrXbdiCFAgAABAgQIECDwvAn0Af74OJy8/3549uEH6Yz4y01Y5/KZGLLbfUpbfI4ZuC2vp1LzdsPSdDOl7vbzuZSmHBA5hfb9aSPqwbTSno+CLMezf/Kf/qEdJ6uXlsyX9Ivr7HTKesOldAjmJt9tdLoh0v5LL4drX/ta2L95M0ybUK2uP28jU3sIECBAgAABAgR2CuQAvzk/C+cPH4aTd98Np/fuxuMkt+4d9GMR5jr56Tj0KbTfvJVycw78KeSn1fzV3T//z12Wg9/LDZXKDth0fmS3JbXeS74c8FhuppTmEXGmsFqFves3wtFXv5bKYuJswT8ECBAgQIAAAQIEBhSYVtinapLT01g+8/S9H4aLx09yLXq7AVN9ZzmH92vbs+L2tABfV+XjH9fTPtDrYe/6dMLi3uxej2XFPu4x/eTP/7OpFibudp3+0B1AP2tBWdKf3w0qreCnu3Cu9w/Cwat3wtEbX4/nsMcjHdWwDzhCNZkAAQIECBAgQGAmMAX4zSacP34Unr7zTjj96KOwOTttJ8/k2yW1QyTnB0rOT0ifTpDJxTH7++Hgxs2wunYUwnQkerntUozmaZE8J/Sw+uQ/+Wfyf6fon46sWeb3Xfti861m85NNp8VMgf3w9ddjTc7y6EhdT4AAAQIECBAgQGBogVw+c/HsWXj2/vvh6Q/fCZvjJyk/x9r3/O6m0J2qyNt56uXPm1zPMi1wHxyG/Rs3wt7BYcrh9ajGPq7nRfNpDf2T/3gK7nnRvaulL6h9AO9W9dMsYapn39uLBfTXv/GNsP/SS+m0GKvsQ49JjSdAgAABAgQIEPgUgSmkX1yEs/v3wvH3vx9OH9yP/z2F9Rjg8xJ2OfolPlM6bjGtnu/thfW1qTRmqlDZm4f7PoTXTJ0qX1Yf/0f/9LRWX4+amS3jx1r49JVZ7s+hfX2wH669+lo4evMbYT2VxuhhAgQIECBAgAABAi+CQK59v3jyOBy/9VY8eWa6G2tYx22kSaCE401O0lMpzMFB2D+6kSpU8mNTxfqOevnuNJr4rB//uX8qHzrZ3S21/7mubKbVs4ewd3gQrr3xRjh64yfiMY9W2V+EEeo9EiBAgAABAgQIzARWq3ju+1Q2c/LDt8NURlNOnYnVKXGpfJVW2acNqIfXQljvpVKavDYfw3i+8VJcnM8vsFX58vGf+yfLrtT5Ftc6TWhlNPFZLi/j3U+vv/mNcO2rX01nTCqNMYIJECBAgAABAgReVIH1Oh4TefLeu3H1/eLp8XS/pqkmJqynwH54Lf4vnhiT6+TLgnw5v/3z3JJ09dF/+Acv+z2vl9OMoFXO5J2tubp+Cu03rocbP/lT4fD11+IdUYX2F3WEet8ECBAgQIAAAQJVYLUKm/PzcPrhB+HJ974bNs9O4kkxe4dHIexNp8WUgx1XYRVPgumW1suTtNux7oRdffRn/+Ds/qz1zMn+TlC5pn26kdLNf+inwsFrrzvq0TglQIAAAQIECBAg0AvkTaund++Gk/d/FDYnJ9Mh7Tm0d2vqXQ1MOZG9HgKz6xZK8TVWYfXRn/0Du1fmS2379O/NJuzfuhlu/qbfHA5efU1oN0QJECBAgAABAgQI7BLIm1bP798PT999N1wcH6ezIbv9qv3x62kPaXpI/PPytJc+73/0c7+/bU6tpfC5FfFg+BCPqplCezyj3U2VDFICBAgQIECAAAECVwvkmzVNx0We/PDdVPOezopsPzMl9L5kpn7r6nqZ1Yd/5mcuy5OUOzilZ8x3Qz06Cjd/028J177yFWe0G6AECBAgQIAAAQIEPo9ACe9374anP/xhPHkm5vbVuhz8uChy3w7sqQCmHhQZVh/9mZ/pj3ZPkT3XtO8dHobrP/lT4fpP/ERY7duI+nn6yGMIECBAgAABAgQIRIFc8/7sww/jiTPTyTOrKbhPh8FUonnV+uyGp/kxaXF+qnH/01Nwb/d3SsF9E4P69W98M1z/5jfDeroNqyMfjUACBAgQIECAAAECX0xgOm3m7Cw8+9GPwskH74fL84t446Ua1+Mf2lkx8bjI7oTHdqp7CKsP/9Q/kc9xn/6Vj31crcLRV98IN376p8PetaMQLjdfrIEeTYAAAQIECBAgQIBAEpjC++lpePr22+HZRx+lEplZvXu6y2osW+/y+Gz76epyCu6/t96AKd3dKYSDO3fCrd/2O8L+rVtW2g04AgQIECBAgAABAj+uwHSH1ePj8OR73wvnDx/UQL982nLr0762PT2mBvfpyMfpPzdh/+atcOu3//ZwcOe1rvbmx22pnydAgAABAgQIECDwYgtMofz8wf0Y3i+ePs2L8a1sZnmwTKl3n5bjY2n7B3/y917GP24uYy37jd/8m8P1N7/hBJkXe1x59wQIECBAgAABAv+gBcpm1Q/eD8fvvB02Z+dhPX0tVtOkcD6roulq3eOBNB/8id9zGTeeTnXtb3w93Pqtvy2sr11TIvMPuqM8HwECBAgQIECAAIFc73781vdTvXvcS9rOeE917hNT2Xuayaa4/sEf/8djlt+/dTvc/kd+Zzh4+WWh3ZAiQIAAAQIECBAg8GslsFqF80ePwuNv/2o4f/w4LqCnvarz26amUply/swqrD742d99OZXI3Pzp3xqOphIZd0b9teoiz0uAAAECBAgQIEAgCkyHwjx7/0fh+K23wub8LJbKlOA+O9k9nzYTb8X0wc/+Y5fXvvZGuPU7/uGwp0TGUCJAgAABAgQIECDway8wnTLz7DQ8+e53wunHH6bj2tdpxT3eQ7Wc+5iOdU+17x/93B+4fOl3/qPh4NXpFJn5nZt+7VvsFQgQIECAAAECBAi8mALTQezn9++FR9/6Vrg4eZpW3efVMjOY1cO//kcvb/6Wnw7r/X217S/mmPGuCRAgQIAAAQIEfiMEppNkzs/D8Q/eCifvvhs2m00umWl17bM7pz77v/7C5eFLLwntvxGd5TUJECBAgAABAgRebIFpo+rjx+HRL//dcP6kbFTNJ8rkeph8YGRYnf/8X7ncOzwU3F/sIePdEyBAgAABAgQI/EYI5LPdn77zdnjy9g/iCvx6vU5nu+f2lD+vNn/nr16mXaz+IUCAAAECBAgQIEDg111gWnV/8iQ8+ru/FM4fP8o3Y5pasWp7UOPpMr/41+xI/XXvHS9IgAABAgQIECBAIAt0q+5Tvfvl+UU82z0tubeoLrgbMQQIECBAgAABAgR+owVyrfvDX/rFWPO+Wq23TpgR3H+jO8nrEyBAgAABAgQIECgnzLz1/XD8ztvh8mI6YSaEy7jwng5zF9wNEwIECBAgQIAAAQLPhcAqnD24Hx780i+GzdOnYZU3qZamCe7PRSdpBAECBAgQIECAwAsvsFqFzelpePQrvxyeffRhCJvLsFqv4l1Up38E9xd+hAAgQIAAAQIECBB4XgQuLy/Ds/d/FB796q/EED+tuufYLrg/L52kHQQIECBAgAABAgSmwvaLJ0/Cw1/82+Hs0aN0mvuU3S9XgrvhQYAAAQIECBAgQOC5EZjKZc7Ow5Pv/Gp4+u4Pw+XFRV11Vyrz3PSShhAgQIAAAQIECBCYDpC5DKcffhge/vIvtXIZp8oYGgQIECBAgAABAgSeM4GpXObpcbj/t38+nD98GEKuc7fi/pz1k+YQIECAAAECBAi84AKxXOYsPPrW3wsn770XLi+nM93VuL/go8LbJ0CAAAECBAgQeB4FLjebcPLeu+Hht34lXJ6dhvV6bXPq89hR2kSAAAECBAgQIPCCC6xW4ezhg3D/5/9muDg5DquV4P6CjwhvnwABAgQIECBA4LkUWK/DxdOn4f4v/K1wevdeWK9WZ2rcn8ue0igCBAgQIECAAIEXWiDXud/71q+Gx++8F8Lm4m3B/YUeEd48AQIECBAgQIDAcymwWsUz3B+98264961vT5tVvye4P5c9pVEECBAgQIAAAQIEQjj5+G748Bd+MVycPPu+4G5EECBAgAABAgQIEHgeBaYNqo+fhPf/358P54+PBffnsY+0iQABAgQIECBAgMB046Xzpyfho7/9d8LJ3XuCuyFBgAABAgQIECBA4LkUmO6genoa7v7yr4QnP3pfcH8uO0mjCBAgQIAAAQIECMSTZc7D/e98Nzz6wTuCuxFBgAABAgQIECBA4LkUmE6WOb8ID99+Jzz49vcE9+eykzSKAAECBAgQIECAQAjh8vIyPHnv/XD3731LcDciCBAgQIAAAQIECDyvApchhKcffhQ++aVfFtyf107SLgIECBAgQIAAAQJhtQond++Gj37h/xPcDQcCBAgQIECAAAECz63AahVOHzwMH/z8Lwjuz20naRgBAgQIECBAgACB6SZMjx6HD/7m3xLcjQYCBAgQIECAAAECz63AOt099YP/5+cF9+e2kzSMAAECBAgQIECAwHodzo6Pwwf/998U3I0GAgQIECBAgAABAs+twHodzo+Pw/uC+3PbRRpGgAABAgQIECBAIATB3SggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQI5O1+MgAAIABJREFUECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIAAAQIECBAgMICA4D5AJ2kiAQIECBAgQIAAAcHdGCBAgAABAgQIECAwgIDgPkAnaSIBAgQIECBAgAABwd0YIECAAAECBAgQIDCAgOA+QCdpIgECBAgQIECAAAHB3RggQIDA/99uHdxSGIVRFH10JnpQpEYMRCIKIDGSKMATiV/CQA07Z3Xw3XXuYBMgQIAAAQIBAeEeGMmJBAgQIECAAAECBIS7P0CAAAECBAgQIEAgICDcAyM5kQABAgQIECBAgIBw9wcIECBAgAABAgQIBASEe2AkJxIgQIAAAQIECBAQ7v4AAQIECBAgQIAAgYCAcA+M5EQCBAgQIECAAAECwt0fIECAAAGB4IJEAAAJCklEQVQCBAgQIBAQEO6BkZxIgAABAgQIECBAQLj7AwQIECBAgAABAgQCAsI9MJITCRAgQIAAAQIECAh3f4AAAQIECBAgQIBAQEC4B0ZyIgECBAgQIECAAAHh7g8QIECAAAECBAgQCAgI98BITiRAgAABAgQIECAg3P0BAgQIECBAgAABAgEB4R4YyYkECBAgQIAAAQIEhLs/QIAAAQIECBAgQCAgINwDIzmRAAECBAgQIECAgHD3BwgQIECAAAECBAgEBIR7YCQnEiBAgAABAgQIEBDu/gABAgQIECBAgACBgIBwD4zkRAIECBAgQIAAAQLC3R8gQIAAAQIECBAgEBAQ7oGRnEiAAAECBAgQIEBAuPsDBAgQIECAAAECBAICwj0wkhMJECBAgAABAgQICHd/gAABAgQIECBAgEBAQLgHRnIiAQIECBAgQIAAAeHuDxAgQIAAAQIECBAICAj3wEhOJECAAAECBAgQICDc/QECBAgQIECAAAECAQHhHhjJiQQIECBAgAABAgSEuz9AgAABAgQIECBAICAg3AMjOZEAAQIECBAgQICAcPcHCBAgQIAAAQIECAQEhHtgJCcSIECAAAECBAgQEO7+AAECBAgQIECAAIGAgHAPjOREAgQIECBAgAABAsLdHyBAgAABAgQIECAQEBDugZGcSIAAAQIECBAgQEC4+wMECBAgQIAAAQIEAgLCPTCSEwkQIECAAAECBAgId3+AAAECBAgQIECAQEBAuAdGciIBAgQIECBAgAAB4e4PECBAgAABAgQIEAgICPfASE4kQIAAAQIECBAgINz9AQIECBAgQIAAAQIBAeEeGMmJBAgQIECAAAECBIS7P0CAAAECBAgQIEAgICDcAyM5kQABAgQIECBAgIBw9wcIECBAgAABAgQIBASEe2AkJxIgQIAAAQIECBAQ7v4AAQIECBAgQIAAgYCAcA+M5EQCBAgQIECAAAECwt0fIECAAAECBAgQIBAQEO6BkZxIgAABAgQIECBAQLj7AwQIECBAgAABAgQCAsI9MJITCRAgQIAAAQIECAh3f4AAAQIECBAgQIBAQEC4B0ZyIgECBAgQIECAAAHh7g8QIECAAAECBAgQCAgI98BITiRAgAABAgQIECAg3P0BAgQIECBAgAABAgEB4R4YyYkECBAgQIAAAQIEhLs/QIAAAQIECBAgQCAgINwDIzmRAAECBAgQIECAgHD3BwgQIECAAAECBAgEBIR7YCQnEiBAgAABAgQIEBDu/gABAgQIECBAgACBgIBwD4zkRAIECBAgQIAAAQLC3R8gQIAAAQIECBAgEBAQ7oGRnEiAAAECBAgQIEBAuPsDBAgQIECAAAECBAICwj0wkhMJECBAgAABAgQICHd/gAABAgQIECBAgEBAQLgHRnIiAQIECBAgQIAAAeHuDxAgQIAAAQIECBAICAj3wEhOJECAAAECBAgQICDc/QECBAgQIECAAAECAQHhHhjJiQQIECBAgAABAgSEuz9AgAABAgQIECBAICAg3AMjOZEAAQIECBAgQICAcPcHCBAgQIAAAQIECAQEhHtgJCcSIECAAAECBAgQEO7+AAECBAgQIECAAIGAgHAPjOREAgQIECBAgAABAsLdHyBAgAABAgQIECAQEBDugZGcSIAAAQIECBAgQEC4+wMECBAgQIAAAQIEAgLCPTCSEwkQIECAAAECBAgId3+AAAECBAgQIECAQEBAuAdGciIBAgQIECBAgAAB4e4PECBAgAABAgQIEAgICPfASE4kQIAAAQIECBAgINz9AQIECBAgQIAAAQIBAeEeGMmJBAgQIECAAAECBIS7P0CAAAECBAgQIEAgICDcAyM5kQABAgQIECBAgIBw9wcIECBAgAABAgQIBASEe2AkJxIgQIAAAQIECBAQ7v4AAQIECBAgQIAAgYCAcA+M5EQCBAgQIECAAAECwt0fIECAAAECBAgQIBAQEO6BkZxIgAABAgQIECBAQLj7AwQIECBAgAABAgQCAv/h/npxPN0egZOdSIAAAQIECBAgQGBP4C/cv97u7h+E+978XkyAAAECBAgQIFARuLw4fZ8/X98fHm+Ee2U0dxIgQIAAAQIECEwKHMfp+fz1cSXcJ+f3aAIECBAgQIAAgZDAy+k4XQv30GJOJUCAAAECBAgQmBQQ7pOzezQBAgQIECBAgEBNQLjXFnMvAQIECBAgQIDApIBwn5zdowkQIECAAAECBGoCwr22mHsJECBAgAABAgQmBYT75OweTYAAAQIECBAgUBMQ7rXF3EuAAAECBAgQIDApINwnZ/doAgQIECBAgACBmoBwry3mXgIECBAgQIAAgUkB4T45u0cTIECAAAECBAjUBIR7bTH3EiBAgAABAgQITAoI98nZPZoAAQIECBAgQKAmINxri7mXAAECBAgQIEBgUkC4T87u0QQIECBAgAABAjUB4V5bzL0ECBAgQIAAAQKTAsJ9cnaPJkCAAAECBAgQqAkI99pi7iVAgAABAgQIEJgUEO6Ts3s0AQIECBAgQIBATUC41xZzLwECBAgQIECAwKSAcJ+c3aMJECBAgAABAgRqAsK9tph7CRAgQIAAAQIEJgWE++TsHk2AAAECBAgQIFATEO61xdxLgAABAgQIECAwKSDcJ2f3aAIECBAgQIAAgZqAcK8t5l4CBAgQIECAAIFJAeE+ObtHEyBAgAABAgQI1ASEe20x9xIgQIAAAQIECEwKCPfJ2T2aAAECBAgQIECgJiDca4u5lwABAgQIECBAYFJAuE/O7tEECBAgQIAAAQI1AeFeW8y9BAgQIECAAAECkwLCfXJ2jyZAgAABAgQIEKgJCPfaYu4lQIAAAQIECBCYFBDuk7N7NAECBAgQIECAQE1AuNcWcy8BAgQIECBAgMCkgHCfnN2jCRAgQIAAAQIEagLCvbaYewkQIECAAAECBCYFhPvk7B5NgAABAgQIECBQExDutcXcS4AAAQIECBAgMCkg3Cdn92gCBAgQIECAAIGagHCvLeZeAgQIECBAgACBSQHhPjm7RxMgQIAAAQIECNQEhHttMfcSIECAAAECBAhMCvyG+w9r88MAD6jYBwAAAABJRU5ErkJggg\x3d\x3d\x22);box-sizing:border-box}\n.",[1],"contentview{-webkit-align-items:center;align-items:center;background-color:#fff9f3;bottom:",[0,0],";box-shadow:inset ",[0,0]," ",[0,12]," ",[0,15]," ",[0,0]," rgba(62,62,62,.28);display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column;left:",[0,30],";position:absolute;right:",[0,30],";top:",[0,30],"}\n.",[1],"swiper{height:",[0,500],"}\n.",[1],"textColor{color:#732824;font-weight:700;margin:0 ",[0,10],"}\n.",[1],"slide-item{background-color:#ccc;height:",[0,900],";width:100%}\n.",[1],"contents,.",[1],"slide-image{height:100%;width:100%}\n.",[1],"contents{-webkit-align-items:center;align-items:center;box-sizing:border-box;display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column;padding:0}\n.",[1],"contents\x3ewx-view{border-radius:",[0,10],";margin:1%;padding:",[0,20]," 0;text-align:center;width:94%}\n.",[1],"contents .",[1],"info{background:url(\x22https://cdn.pluslegal.cn/xxzzb%2Fhome_votes_img_bg%402x.png\x22)no-repeat;background-size:100% 100%;padding:5% 3%;width:100%}\n.",[1],"contents .",[1],"tips{background:url(\x22https://cdn.pluslegal.cn/xxzzb%2Fhome_rules_img_bg%402x.png\x22)no-repeat;background-color:inherit!important;background-size:100% 100%}\n.",[1],"contents .",[1],"bl{display:block;vertical-align:middle}\n.",[1],"info .",[1],"title{color:#222;font-family:Source Han Serif CN;font-size:",[0,34],";font-weight:600;margin-top:",[0,80],";width:80%}\n.",[1],"info .",[1],"time{font-size:",[0,30],"}\n.",[1],"info .",[1],"total .",[1],"bl{margin:",[0,10]," 0}\n.",[1],"info .",[1],"total{background:#ac1212;border-radius:",[0,20],";color:#fff;display:-webkit-flex;display:flex;margin:",[0,10]," 7%;padding:",[0,16]," 0;width:86%}\n.",[1],"info .",[1],"total\x3ewx-view{-webkit-flex:1;flex:1;font-size:",[0,32],";margin:0}\n.",[1],"info\x3ewx-view{margin:",[0,20]," auto ",[0,15],"}\n.",[1],"tips\x3ewx-view{margin:",[0,16]," auto}\n.",[1],"info .",[1],"status\x3ewx-view{font-size:",[0,32],";font-weight:600;margin:",[0,20]," 0 ",[0,6],"!important}\n.",[1],"info .",[1],"status\x3ewx-view.",[1],"noting{margin:",[0,40]," 0 ",[0,6],"!important}\n.",[1],"btn{padding:",[0,10]," 0}\n.",[1],"btn wx-button{background:#7d2120;border-radius:10px;color:#fff;font-size:",[0,28],";height:",[0,100],";line-height:",[0,100],";margin:",[0,20]," auto;padding:0;width:80%!important}\n.",[1],"btn wx-button:last-child{background:#ac1212}\n.",[1],"btn wx-button.",[1],"novote{background:rgba(173,23,23,.6)}\n.",[1],"modal-mask{background-color:rgba(0,0,0,.7);height:100%;-webkit-justify-content:center;justify-content:center;left:0;top:0;width:100%;z-index:1000000}\n.",[1],"modal-dialog,.",[1],"modal-mask{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column;overflow:hidden;position:fixed}\n.",[1],"modal-dialog{background-color:#fff;height:86%;width:90%;z-index:999999}\n.",[1],"modal-contents{width:86%}\n.",[1],"modal-titles{color:#000;font-size:",[0,38],";margin:",[0,40]," 0 ",[0,16],";text-align:center}\n.",[1],"modal-contents .",[1],"vcode,.",[1],"modal-contents .",[1],"verify{height:",[0,100],";line-height:",[0,100],";margin:",[0,20]," auto;padding:0 ",[0,20],";text-align:center;width:80%}\n.",[1],"modal-contents .",[1],"vcode{background-color:#ccc;border-radius:",[0,10],";font-size:",[0,43],";font-style:italic;font-weight:700;letter-spacing:.5rem;padding:0}\n.",[1],"modal-contents .",[1],"verify wx-input{background-color:#ccc;border-radius:",[0,10],";font-size:",[0,30],";height:100%!important;padding:0;width:100%!important}\n.",[1],"modal-title{color:#000;font-size:",[0,36],";margin:",[0,60]," 0 ",[0,45],";text-align:center;width:80%}\n.",[1],"modal-scroll{background:#fff;width:90%}\n.",[1],"modal-content{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column;height:100%;-webkit-justify-content:center;justify-content:center;width:100%}\n.",[1],"modal-text{color:#333;line-height:1.9;text-align:justify;text-indent:2em}\n.",[1],"modal-btn,.",[1],"modal-text{font-size:",[0,28],"}\n.",[1],"modal-btn{background:#e32516;border-radius:",[0,40],";bottom:30px;font-size:",[0,30],";height:",[0,80],";line-height:",[0,80],";margin-top:",[0,60],";text-align:center;width:90%}\n.",[1],"close,.",[1],"modal-btn{color:#fff;position:absolute}\n.",[1],"close{height:",[0,50],";right:",[0,15],";top:",[0,15],";width:",[0,50],"}\n.",[1],"text-3{-webkit-line-clamp:3;text-align:justify}\n.",[1],"text-2,.",[1],"text-3{-webkit-box-orient:vertical;display:-webkit-box;overflow:hidden;padding:0 ",[0,26],";text-overflow:ellipsis}\n.",[1],"text-2{-webkit-line-clamp:2}\n.",[1],"cu-custom{display:block;position:relative}\n.",[1],"cu-bar .",[1],"action{-webkit-align-items:left;align-items:left;color:#fff;display:-webkit-flex;display:flex;height:50%;-webkit-justify-content:left;justify-content:left;max-width:100%}\n.",[1],"icon-back{-webkit-align-self:center;align-self:center;height:",[0,46],";padding:",[0,16],";width:",[0,46],"}\n",],"Some selectors are not allowed in component wxss, including tag name selectors, ID selectors, and attribute selectors.(./app.wxss:1:138095)",{path:"./app.wxss"})();;;}__mainPageFrameReady__();var __pageFrameEndTime__=Date.now();