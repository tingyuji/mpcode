var __wxAppData=__wxAppData||{};var __wxRoute=__wxRoute||"";var __wxRouteBegin=__wxRouteBegin||"";var __wxAppCode__=__wxAppCode__||{};var global=global||{};var __WXML_GLOBAL__=__WXML_GLOBAL__||{entrys:{},defines:{},modules:{},ops:[],wxs_nf_init:undefined,total_ops:0};var __wxAppCurrentFile__=__wxAppCurrentFile__||"";var Component=Component||function(){};var definePlugin=definePlugin||function(){};var requirePlugin=requirePlugin||function(){};var Behavior=Behavior||function(){};var __vd_version_info__=__vd_version_info__||{};var __GWX_GLOBAL__=__GWX_GLOBAL__||{};
	definePlugin("plugin://wxa75efa648b60994b", function(define, require, module, exports, global, wx, App, Page, Component, Behavior, getApp, getCurrentPages) {			/*v0.6vv_20180522_fbi*/global.__wcc_version__='v0.6vv_20180522_fbi';global.__wcc_version_info__={"customComponents":true,"fixZeroRpx":true,"propValueDeepCopy":false};
var $gwxc
var $gaic={}
$gwx_wxa75efa648b60994b=function(path,global){
if(typeof global === 'undefined') global={};
if(typeof __WXML_GLOBAL__ === 'undefined') __WXML_GLOBAL__={};
function _(a,b){if(typeof(b)!='undefined')a.children.push(b);}
function _v(k){if(typeof(k)!='undefined')return {tag:'virtual','wxKey':k,children:[]};return {tag:'virtual',children:[]};}
function _n(tag){$gwxc++;if($gwxc>=16000){throw 'Dom limit exceeded, please check if there\'s any mistake you\'ve made.'};return {tag:'wx-'+tag,attr:{},children:[],n:[],raw:{},generics:{}}}
function _p(a,b){b&&a.properities.push(b);}
function _s(scope,env,key){return typeof(scope[key])!='undefined'?scope[key]:env[key]}
function _wp(m){console.warn("WXMLRT_$gwx_wxa75efa648b60994b:"+m)}
function _wl(tname,prefix){_wp(prefix+':-1:-1:-1: Template `' + tname + '` is being called recursively, will be stop.')}
$gwn=console.warn;
$gwl=console.log;
function $gwh()
{
function x()
{
}
x.prototype = 
{
hn: function( obj, all )
{
if( typeof(obj) == 'object' )
{
var cnt=0;
var any1=false,any2=false;
for(var x in obj)
{
any1=any1|x==='__value__';
any2=any2|x==='__wxspec__';
cnt++;
if(cnt>2)break;
}
return cnt == 2 && any1 && any2 && ( all || obj.__wxspec__ !== 'm' || this.hn(obj.__value__) === 'h' ) ? "h" : "n";
}
return "n";
},
nh: function( obj, special )
{
return { __value__: obj, __wxspec__: special ? special : true }
},
rv: function( obj )
{
return this.hn(obj,true)==='n'?obj:this.rv(obj.__value__);
},
hm: function( obj )
{
if( typeof(obj) == 'object' )
{
var cnt=0;
var any1=false,any2=false;
for(var x in obj)
{
any1=any1|x==='__value__';
any2=any2|x==='__wxspec__';
cnt++;
if(cnt>2)break;
}
return cnt == 2 && any1 && any2 && (obj.__wxspec__ === 'm' || this.hm(obj.__value__) );
}
return false;
}
}
return new x;
}
wh=$gwh();
function $gstack(s){
var tmp=s.split('\n '+' '+' '+' ');
for(var i=0;i<tmp.length;++i){
if(0==i) continue;
if(")"===tmp[i][tmp[i].length-1])
tmp[i]=tmp[i].replace(/\s\(.*\)$/,"");
else
tmp[i]="at anonymous function";
}
return tmp.join('\n '+' '+' '+' ');
}
function $gwrt( should_pass_type_info )
{
function ArithmeticEv( ops, e, s, g, o )
{
var _f = false;
var rop = ops[0][1];
var _a,_b,_c,_d, _aa, _bb;
switch( rop )
{
case '?:':
_a = rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && ( wh.hn(_a) === 'h' );
_d = wh.rv( _a ) ? rev( ops[2], e, s, g, o, _f ) : rev( ops[3], e, s, g, o, _f );
_d = _c && wh.hn( _d ) === 'n' ? wh.nh( _d, 'c' ) : _d;
return _d;
break;
case '&&':
_a = rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && ( wh.hn(_a) === 'h' );
_d = wh.rv( _a ) ? rev( ops[2], e, s, g, o, _f ) : wh.rv( _a );
_d = _c && wh.hn( _d ) === 'n' ? wh.nh( _d, 'c' ) : _d;
return _d;
break;
case '||':
_a = rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && ( wh.hn(_a) === 'h' );
_d = wh.rv( _a ) ? wh.rv(_a) : rev( ops[2], e, s, g, o, _f );
_d = _c && wh.hn( _d ) === 'n' ? wh.nh( _d, 'c' ) : _d;
return _d;
break;
case '+':
case '*':
case '/':
case '%':
case '|':
case '^':
case '&':
case '===':
case '==':
case '!=':
case '!==':
case '>=':
case '<=':
case '>':
case '<':
case '<<':
case '>>':
_a = rev( ops[1], e, s, g, o, _f );
_b = rev( ops[2], e, s, g, o, _f );
_c = should_pass_type_info && (wh.hn( _a ) === 'h' || wh.hn( _b ) === 'h');
switch( rop )
{
case '+':
_d = wh.rv( _a ) + wh.rv( _b );
break;
case '*':
_d = wh.rv( _a ) * wh.rv( _b );
break;
case '/':
_d = wh.rv( _a ) / wh.rv( _b );
break;
case '%':
_d = wh.rv( _a ) % wh.rv( _b );
break;
case '|':
_d = wh.rv( _a ) | wh.rv( _b );
break;
case '^':
_d = wh.rv( _a ) ^ wh.rv( _b );
break;
case '&':
_d = wh.rv( _a ) & wh.rv( _b );
break;
case '===':
_d = wh.rv( _a ) === wh.rv( _b );
break;
case '==':
_d = wh.rv( _a ) == wh.rv( _b );
break;
case '!=':
_d = wh.rv( _a ) != wh.rv( _b );
break;
case '!==':
_d = wh.rv( _a ) !== wh.rv( _b );
break;
case '>=':
_d = wh.rv( _a ) >= wh.rv( _b );
break;
case '<=':
_d = wh.rv( _a ) <= wh.rv( _b );
break;
case '>':
_d = wh.rv( _a ) > wh.rv( _b );
break;
case '<':
_d = wh.rv( _a ) < wh.rv( _b );
break;
case '<<':
_d = wh.rv( _a ) << wh.rv( _b );
break;
case '>>':
_d = wh.rv( _a ) >> wh.rv( _b );
break;
default:
break;
}
return _c ? wh.nh( _d, "c" ) : _d;
break;
case '-':
_a = ops.length === 3 ? rev( ops[1], e, s, g, o, _f ) : 0;
_b = ops.length === 3 ? rev( ops[2], e, s, g, o, _f ) : rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && (wh.hn( _a ) === 'h' || wh.hn( _b ) === 'h');
_d = _c ? wh.rv( _a ) - wh.rv( _b ) : _a - _b;
return _c ? wh.nh( _d, "c" ) : _d;
break;
case '!':
_a = rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && (wh.hn( _a ) == 'h');
_d = !wh.rv(_a);
return _c ? wh.nh( _d, "c" ) : _d;
case '~':
_a = rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && (wh.hn( _a ) == 'h');
_d = ~wh.rv(_a);
return _c ? wh.nh( _d, "c" ) : _d;
default:
$gwn('unrecognized op' + rop );
}
}
function rev( ops, e, s, g, o, newap )
{
var op = ops[0];
var _f = false;
if ( typeof newap !== "undefined" ) o.ap = newap;
if( typeof(op)==='object' )
{
var vop=op[0];
var _a, _aa, _b, _bb, _c, _d, _s, _e, _ta, _tb, _td;
switch(vop)
{
case 2:
return ArithmeticEv(ops,e,s,g,o);
break;
case 4: 
return rev( ops[1], e, s, g, o, _f );
break;
case 5: 
switch( ops.length )
{
case 2: 
_a = rev( ops[1],e,s,g,o,_f );
return should_pass_type_info?[_a]:[wh.rv(_a)];
return [_a];
break;
case 1: 
return [];
break;
default:
_a = rev( ops[1],e,s,g,o,_f );
_b = rev( ops[2],e,s,g,o,_f );
_a.push( 
should_pass_type_info ?
_b :
wh.rv( _b )
);
return _a;
break;
}
break;
case 6:
_a = rev(ops[1],e,s,g,o);
var ap = o.ap;
_ta = wh.hn(_a)==='h';
_aa = _ta ? wh.rv(_a) : _a;
o.is_affected |= _ta;
if( should_pass_type_info )
{
if( _aa===null || typeof(_aa) === 'undefined' )
{
return _ta ? wh.nh(undefined, 'e') : undefined;
}
_b = rev(ops[2],e,s,g,o,_f);
_tb = wh.hn(_b) === 'h';
_bb = _tb ? wh.rv(_b) : _b;
o.ap = ap;
o.is_affected |= _tb;
if( _bb===null || typeof(_bb) === 'undefined' || 
_bb === "__proto__" || _bb === "prototype" || _bb === "caller" ) 
{
return (_ta || _tb) ? wh.nh(undefined, 'e') : undefined;
}
_d = _aa[_bb];
if ( typeof _d === 'function' && !ap ) _d = undefined;
_td = wh.hn(_d)==='h';
o.is_affected |= _td;
return (_ta || _tb) ? (_td ? _d : wh.nh(_d, 'e')) : _d;
}
else
{
if( _aa===null || typeof(_aa) === 'undefined' )
{
return undefined;
}
_b = rev(ops[2],e,s,g,o,_f);
_tb = wh.hn(_b) === 'h';
_bb = _tb ? wh.rv(_b) : _b;
o.ap = ap;
o.is_affected |= _tb;
if( _bb===null || typeof(_bb) === 'undefined' || 
_bb === "__proto__" || _bb === "prototype" || _bb === "caller" ) 
{
return undefined;
}
_d = _aa[_bb];
if ( typeof _d === 'function' && !ap ) _d = undefined;
_td = wh.hn(_d)==='h';
o.is_affected |= _td;
return _td ? wh.rv(_d) : _d;
}
case 7: 
switch(ops[1][0])
{
case 11:
o.is_affected |= wh.hn(g)==='h';
return g;
case 3:
_s = wh.rv( s );
_e = wh.rv( e );
_b = ops[1][1];
if (g && g.f && g.f.hasOwnProperty(_b) )
{
_a = g.f;
o.ap = true;
}
else
{
_a = _s && _s.hasOwnProperty(_b) ? 
s : (_e && _e.hasOwnProperty(_b) ? e : undefined );
}
if( should_pass_type_info )
{
if( _a )
{
_ta = wh.hn(_a) === 'h';
_aa = _ta ? wh.rv( _a ) : _a;
_d = _aa[_b];
_td = wh.hn(_d) === 'h';
o.is_affected |= _ta || _td;
_d = _ta && !_td ? wh.nh(_d,'e') : _d;
return _d;
}
}
else
{
if( _a )
{
_ta = wh.hn(_a) === 'h';
_aa = _ta ? wh.rv( _a ) : _a;
_d = _aa[_b];
_td = wh.hn(_d) === 'h';
o.is_affected |= _ta || _td;
return wh.rv(_d);
}
}
return undefined;
}
break;
case 8: 
_a = {};
_a[ops[1]] = rev(ops[2],e,s,g,o,_f);
return _a;
break;
case 9: 
_a = rev(ops[1],e,s,g,o,_f);
_b = rev(ops[2],e,s,g,o,_f);
function merge( _a, _b, _ow )
{
var ka, _bbk;
_ta = wh.hn(_a)==='h';
_tb = wh.hn(_b)==='h';
_aa = wh.rv(_a);
_bb = wh.rv(_b);
for(var k in _bb)
{
if ( _ow || !_aa.hasOwnProperty(k) )
{
_aa[k] = should_pass_type_info ? (_tb ? wh.nh(_bb[k],'e') : _bb[k]) : wh.rv(_bb[k]);
}
}
return _a;
}
var _c = _a
var _ow = true
if ( typeof(ops[1][0]) === "object" && ops[1][0][0] === 10 ) {
_a = _b
_b = _c
_ow = false
}
if ( typeof(ops[1][0]) === "object" && ops[1][0][0] === 10 ) {
var _r = {}
return merge( merge( _r, _a, _ow ), _b, _ow );
}
else
return merge( _a, _b, _ow );
break;
case 10:
_a = rev(ops[1],e,s,g,o,_f);
_a = should_pass_type_info ? _a : wh.rv( _a );
return _a ;
break;
case 12:
var _r;
_a = rev(ops[1],e,s,g,o);
if ( !o.ap )
{
return should_pass_type_info && wh.hn(_a)==='h' ? wh.nh( _r, 'f' ) : _r;
}
var ap = o.ap;
_b = rev(ops[2],e,s,g,o,_f);
o.ap = ap;
_ta = wh.hn(_a)==='h';
_tb = _ca(_b);
_aa = wh.rv(_a);	
_bb = wh.rv(_b); snap_bb=$gdc(_bb,"nv_");
try{
_r = typeof _aa === "function" ? $gdc(_aa.apply(null, snap_bb)) : undefined;
} catch (e){
e.message = e.message.replace(/nv_/g,"");
e.stack = e.stack.substring(0,e.stack.indexOf("\n", e.stack.lastIndexOf("at nv_")));
e.stack = e.stack.replace(/\snv_/g," "); 
e.stack = $gstack(e.stack);	
if("undefined"!==typeof debugInfo)
e.stack += "\n "+" "+" "+" at "+debugInfo[g.opindex][0]+":"+debugInfo[g.opindex][1]+":"+debugInfo[g.opindex][2];
throw e;
}
return should_pass_type_info && (_tb || _ta) ? wh.nh( _r, 'f' ) : _r;
}
}
else
{
if( op === 3 || op === 1) return ops[1];
else if( op === 11 ) 
{
var _a='';
for( var i = 1 ; i < ops.length ; i++ )
{
var xp = wh.rv(rev(ops[i],e,s,g,o,_f));
_a += typeof(xp) === 'undefined' ? '' : xp;
}
return _a;
}
}
}
return rev;
}
gra=$gwrt(true); 
grb=$gwrt(false); 
function TestTest( expr, ops, e,s,g, expect_a, expect_b, expect_affected )
{
{
var o = {is_affected:false};
var a = gra( ops, e,s,g, o );
if( JSON.stringify(a) != JSON.stringify( expect_a )
|| o.is_affected != expect_affected )
{
console.warn( "A. " + expr + " get result " + JSON.stringify(a) + ", " + o.is_affected + ", but " + JSON.stringify( expect_a ) + ", " + expect_affected + " is expected" );
}
}
{
var o = {is_affected:false};
var a = grb( ops, e,s,g, o );
if( JSON.stringify(a) != JSON.stringify( expect_b )
|| o.is_affected != expect_affected )
{
console.warn( "B. " + expr + " get result " + JSON.stringify(a) + ", " + o.is_affected + ", but " + JSON.stringify( expect_b ) + ", " + expect_affected + " is expected" );
}
}
}

function wfor( to_iter, func, env, _s, global, father, itemname, indexname, keyname )
{
var _n = wh.hn( to_iter ) === 'n'; 
var scope = wh.rv( _s ); 
var has_old_item = scope.hasOwnProperty(itemname);
var has_old_index = scope.hasOwnProperty(indexname);
var old_item = scope[itemname];
var old_index = scope[indexname];
var full = Object.prototype.toString.call(wh.rv(to_iter));
var type = full[8]; 
if( type === 'N' && full[10] === 'l' ) type = 'X'; 
var _y;
if( _n )
{
if( type === 'A' ) 
{
var r_iter_item;
for( var i = 0 ; i < to_iter.length ; i++ )
{
scope[itemname] = to_iter[i];
scope[indexname] = _n ? i : wh.nh(i, 'h');
r_iter_item = wh.rv(to_iter[i]);
var key = keyname && r_iter_item ? (keyname==="*this" ? r_iter_item : wh.rv(r_iter_item[keyname])) : undefined;
_y = _v(key);
_(father,_y);
func( env, scope, _y, global );
}
}
else if( type === 'O' ) 
{
var i = 0;
var r_iter_item;
for( var k in to_iter )
{
scope[itemname] = to_iter[k];
scope[indexname] = _n ? k : wh.nh(k, 'h');
r_iter_item = wh.rv(to_iter[k]);
var key = keyname && r_iter_item ? (keyname==="*this" ? r_iter_item : wh.rv(r_iter_item[keyname])) : undefined;
_y = _v(key);
_(father,_y);
func( env,scope,_y,global );
i++;
}
}
else if( type === 'S' ) 
{
for( var i = 0 ; i < to_iter.length ; i++ )
{
scope[itemname] = to_iter[i];
scope[indexname] = _n ? i : wh.nh(i, 'h');
_y = _v( to_iter[i] + i );
_(father,_y);
func( env,scope,_y,global );
}
}
else if( type === 'N' ) 
{
for( var i = 0 ; i < to_iter ; i++ )
{
scope[itemname] = i;
scope[indexname] = _n ? i : wh.nh(i, 'h');
_y = _v( i );
_(father,_y);
func(env,scope,_y,global);
}
}
else
{
}
}
else
{
var r_to_iter = wh.rv(to_iter);
var r_iter_item, iter_item;
if( type === 'A' ) 
{
for( var i = 0 ; i < r_to_iter.length ; i++ )
{
iter_item = r_to_iter[i];
iter_item = wh.hn(iter_item)==='n' ? wh.nh(iter_item,'h') : iter_item;
r_iter_item = wh.rv( iter_item );
scope[itemname] = iter_item
scope[indexname] = _n ? i : wh.nh(i, 'h');
var key = keyname && r_iter_item ? (keyname==="*this" ? r_iter_item : wh.rv(r_iter_item[keyname])) : undefined;
_y = _v(key);
_(father,_y);
func( env, scope, _y, global );
}
}
else if( type === 'O' ) 
{
var i=0;
for( var k in r_to_iter )
{
iter_item = r_to_iter[k];
iter_item = wh.hn(iter_item)==='n'? wh.nh(iter_item,'h') : iter_item;
r_iter_item = wh.rv( iter_item );
scope[itemname] = iter_item;
scope[indexname] = _n ? k : wh.nh(k, 'h');
var key = keyname && r_iter_item ? (keyname==="*this" ? r_iter_item : wh.rv(r_iter_item[keyname])) : undefined;
_y=_v(key);
_(father,_y);
func( env, scope, _y, global );
i++
}
}
else if( type === 'S' ) 
{
for( var i = 0 ; i < r_to_iter.length ; i++ )
{
iter_item = wh.nh(r_to_iter[i],'h');
scope[itemname] = iter_item;
scope[indexname] = _n ? i : wh.nh(i, 'h');
_y = _v( to_iter[i] + i );
_(father,_y);
func( env, scope, _y, global );
}
}
else if( type === 'N' ) 
{
for( var i = 0 ; i < r_to_iter ; i++ )
{
iter_item = wh.nh(i,'h');
scope[itemname] = iter_item;
scope[indexname]= _n ? i : wh.nh(i,'h');
_y = _v( i );
_(father,_y);
func(env,scope,_y,global);
}
}
else
{
}
}
if(has_old_item)
{
scope[itemname]=old_item;
}
else
{
delete scope[itemname];
}
if(has_old_index)
{
scope[indexname]=old_index;
}
else
{
delete scope[indexname];
}
}

function _ca(o)
{ 
if ( wh.hn(o) == 'h' ) return true;
if ( typeof o !== "object" ) return false;
for(var i in o){ 
if ( o.hasOwnProperty(i) ){
if (_ca(o[i])) return true;
}
}
return false;
}
function _da( node, attrname, opindex, raw, o )
{
var isaffected = false;
if ( o.is_affected || _ca(raw) ) 
{
node.n.push( attrname );
node.raw[attrname] = raw;
var value = $gdc( raw, "", 2 );
return value;
}
else
{
var value = $gdc( raw, "", 2 );
return value;
}
}
function _r( node, attrname, opindex, env, scope, global ) 
{
global.opindex=opindex;
var o = {}, _env;
var a = grb( z[opindex], env, scope, global, o );
a = _da( node, attrname, opindex, a, o );
node.attr[attrname] = a;
}
function _o( opindex, env, scope, global )
{
global.opindex=opindex;
var nothing = {};
var r = grb( z[opindex], env, scope, global, nothing );
return (r&&r.constructor===Function) ? undefined : r;
}
function _1( opindex, env, scope, global, o )
{
var o = o || {};
global.opindex=opindex;
return gra( z[opindex], env, scope, global, o );
}
function _2( opindex, func, env, scope, global, father, itemname, indexname, keyname )
{
var o = {};
var to_iter = _1( opindex, env, scope, global );
wfor( to_iter, func, env, scope, global, father, itemname, indexname, keyname );
}


function _m(tag,attrs,generics,env,scope,global)
{
var tmp=_n(tag);
var base=0;
for(var i = 0 ; i < attrs.length ; i+=2 )
{
if(base+attrs[i+1]<0)
{
tmp.attr[attrs[i]]=true;
}
else
{
_r(tmp,attrs[i],base+attrs[i+1],env,scope,global);
if(base===0)base=attrs[i+1];
}
}
for(var i=0;i<generics.length;i+=2)
{
if(base+generics[i+1]<0)
{
tmp.generics[generics[i]]="";
}
else
{
var $t=grb(z[base+generics[i+1]],env,scope,global);
if ($t!="") $t="wx-"+$t;
tmp.generics[generics[i]]=$t;
if(base===0)base=generics[i+1];
}
}
return tmp;
}

var nf_init=function(){
if(typeof __WXML_GLOBAL__==="undefined"||undefined===__WXML_GLOBAL__.wxs_nf_init){
nf_init_Object();nf_init_Function();nf_init_Array();nf_init_String();nf_init_Boolean();nf_init_Number();nf_init_Math();nf_init_Date();nf_init_RegExp();
}
if(typeof __WXML_GLOBAL__!=="undefined") __WXML_GLOBAL__.wxs_nf_init=true;
};
var nf_init_Object=function(){
Object.defineProperty(Object.prototype,"nv_constructor",{writable:true,value:"Object"})
Object.defineProperty(Object.prototype,"nv_toString",{writable:true,value:function(){return "[object Object]"}})
}
var nf_init_Function=function(){
Object.defineProperty(Function.prototype,"nv_constructor",{writable:true,value:"Function"})
Object.defineProperty(Function.prototype,"nv_length",{get:function(){return this.length;},set:function(){}});
Object.defineProperty(Function.prototype,"nv_toString",{writable:true,value:function(){return "[function Function]"}})
}
var nf_init_Array=function(){
Object.defineProperty(Array.prototype,"nv_toString",{writable:true,value:function(){return this.nv_join();}})
Object.defineProperty(Array.prototype,"nv_join",{writable:true,value:function(s){
s=undefined==s?',':s;
var r="";
for(var i=0;i<this.length;++i){
if(0!=i) r+=s;
if(null==this[i]||undefined==this[i]) r+='';	
else if(typeof this[i]=='function') r+=this[i].nv_toString();
else if(typeof this[i]=='object'&&this[i].nv_constructor==="Array") r+=this[i].nv_join();
else r+=this[i].toString();
}
return r;
}})
Object.defineProperty(Array.prototype,"nv_constructor",{writable:true,value:"Array"})
Object.defineProperty(Array.prototype,"nv_concat",{writable:true,value:Array.prototype.concat})
Object.defineProperty(Array.prototype,"nv_pop",{writable:true,value:Array.prototype.pop})
Object.defineProperty(Array.prototype,"nv_push",{writable:true,value:Array.prototype.push})
Object.defineProperty(Array.prototype,"nv_reverse",{writable:true,value:Array.prototype.reverse})
Object.defineProperty(Array.prototype,"nv_shift",{writable:true,value:Array.prototype.shift})
Object.defineProperty(Array.prototype,"nv_slice",{writable:true,value:Array.prototype.slice})
Object.defineProperty(Array.prototype,"nv_sort",{writable:true,value:Array.prototype.sort})
Object.defineProperty(Array.prototype,"nv_splice",{writable:true,value:Array.prototype.splice})
Object.defineProperty(Array.prototype,"nv_unshift",{writable:true,value:Array.prototype.unshift})
Object.defineProperty(Array.prototype,"nv_indexOf",{writable:true,value:Array.prototype.indexOf})
Object.defineProperty(Array.prototype,"nv_lastIndexOf",{writable:true,value:Array.prototype.lastIndexOf})
Object.defineProperty(Array.prototype,"nv_every",{writable:true,value:Array.prototype.every})
Object.defineProperty(Array.prototype,"nv_some",{writable:true,value:Array.prototype.some})
Object.defineProperty(Array.prototype,"nv_forEach",{writable:true,value:Array.prototype.forEach})
Object.defineProperty(Array.prototype,"nv_map",{writable:true,value:Array.prototype.map})
Object.defineProperty(Array.prototype,"nv_filter",{writable:true,value:Array.prototype.filter})
Object.defineProperty(Array.prototype,"nv_reduce",{writable:true,value:Array.prototype.reduce})
Object.defineProperty(Array.prototype,"nv_reduceRight",{writable:true,value:Array.prototype.reduceRight})
Object.defineProperty(Array.prototype,"nv_length",{get:function(){return this.length;},set:function(value){this.length=value;}});
}
var nf_init_String=function(){
Object.defineProperty(String.prototype,"nv_constructor",{writable:true,value:"String"})
Object.defineProperty(String.prototype,"nv_toString",{writable:true,value:String.prototype.toString})
Object.defineProperty(String.prototype,"nv_valueOf",{writable:true,value:String.prototype.valueOf})
Object.defineProperty(String.prototype,"nv_charAt",{writable:true,value:String.prototype.charAt})
Object.defineProperty(String.prototype,"nv_charCodeAt",{writable:true,value:String.prototype.charCodeAt})
Object.defineProperty(String.prototype,"nv_concat",{writable:true,value:String.prototype.concat})
Object.defineProperty(String.prototype,"nv_indexOf",{writable:true,value:String.prototype.indexOf})
Object.defineProperty(String.prototype,"nv_lastIndexOf",{writable:true,value:String.prototype.lastIndexOf})
Object.defineProperty(String.prototype,"nv_localeCompare",{writable:true,value:String.prototype.localeCompare})
Object.defineProperty(String.prototype,"nv_match",{writable:true,value:String.prototype.match})
Object.defineProperty(String.prototype,"nv_replace",{writable:true,value:String.prototype.replace})
Object.defineProperty(String.prototype,"nv_search",{writable:true,value:String.prototype.search})
Object.defineProperty(String.prototype,"nv_slice",{writable:true,value:String.prototype.slice})
Object.defineProperty(String.prototype,"nv_split",{writable:true,value:String.prototype.split})
Object.defineProperty(String.prototype,"nv_substring",{writable:true,value:String.prototype.substring})
Object.defineProperty(String.prototype,"nv_toLowerCase",{writable:true,value:String.prototype.toLowerCase})
Object.defineProperty(String.prototype,"nv_toLocaleLowerCase",{writable:true,value:String.prototype.toLocaleLowerCase})
Object.defineProperty(String.prototype,"nv_toUpperCase",{writable:true,value:String.prototype.toUpperCase})
Object.defineProperty(String.prototype,"nv_toLocaleUpperCase",{writable:true,value:String.prototype.toLocaleUpperCase})
Object.defineProperty(String.prototype,"nv_trim",{writable:true,value:String.prototype.trim})
Object.defineProperty(String.prototype,"nv_length",{get:function(){return this.length;},set:function(value){this.length=value;}});
}
var nf_init_Boolean=function(){
Object.defineProperty(Boolean.prototype,"nv_constructor",{writable:true,value:"Boolean"})
Object.defineProperty(Boolean.prototype,"nv_toString",{writable:true,value:Boolean.prototype.toString})
Object.defineProperty(Boolean.prototype,"nv_valueOf",{writable:true,value:Boolean.prototype.valueOf})
}
var nf_init_Number=function(){
Object.defineProperty(Number,"nv_MAX_VALUE",{writable:false,value:Number.MAX_VALUE})
Object.defineProperty(Number,"nv_MIN_VALUE",{writable:false,value:Number.MIN_VALUE})
Object.defineProperty(Number,"nv_NEGATIVE_INFINITY",{writable:false,value:Number.NEGATIVE_INFINITY})
Object.defineProperty(Number,"nv_POSITIVE_INFINITY",{writable:false,value:Number.POSITIVE_INFINITY})
Object.defineProperty(Number.prototype,"nv_constructor",{writable:true,value:"Number"})
Object.defineProperty(Number.prototype,"nv_toString",{writable:true,value:Number.prototype.toString})
Object.defineProperty(Number.prototype,"nv_toLocaleString",{writable:true,value:Number.prototype.toLocaleString})
Object.defineProperty(Number.prototype,"nv_valueOf",{writable:true,value:Number.prototype.valueOf})
Object.defineProperty(Number.prototype,"nv_toFixed",{writable:true,value:Number.prototype.toFixed})
Object.defineProperty(Number.prototype,"nv_toExponential",{writable:true,value:Number.prototype.toExponential})
Object.defineProperty(Number.prototype,"nv_toPrecision",{writable:true,value:Number.prototype.toPrecision})
}
var nf_init_Math=function(){
Object.defineProperty(Math,"nv_E",{writable:false,value:Math.E})
Object.defineProperty(Math,"nv_LN10",{writable:false,value:Math.LN10})
Object.defineProperty(Math,"nv_LN2",{writable:false,value:Math.LN2})
Object.defineProperty(Math,"nv_LOG2E",{writable:false,value:Math.LOG2E})
Object.defineProperty(Math,"nv_LOG10E",{writable:false,value:Math.LOG10E})
Object.defineProperty(Math,"nv_PI",{writable:false,value:Math.PI})
Object.defineProperty(Math,"nv_SQRT1_2",{writable:false,value:Math.SQRT1_2})
Object.defineProperty(Math,"nv_SQRT2",{writable:false,value:Math.SQRT2})
Object.defineProperty(Math,"nv_abs",{writable:false,value:Math.abs})
Object.defineProperty(Math,"nv_acos",{writable:false,value:Math.acos})
Object.defineProperty(Math,"nv_asin",{writable:false,value:Math.asin})
Object.defineProperty(Math,"nv_atan",{writable:false,value:Math.atan})
Object.defineProperty(Math,"nv_atan2",{writable:false,value:Math.atan2})
Object.defineProperty(Math,"nv_ceil",{writable:false,value:Math.ceil})
Object.defineProperty(Math,"nv_cos",{writable:false,value:Math.cos})
Object.defineProperty(Math,"nv_exp",{writable:false,value:Math.exp})
Object.defineProperty(Math,"nv_floor",{writable:false,value:Math.floor})
Object.defineProperty(Math,"nv_log",{writable:false,value:Math.log})
Object.defineProperty(Math,"nv_max",{writable:false,value:Math.max})
Object.defineProperty(Math,"nv_min",{writable:false,value:Math.min})
Object.defineProperty(Math,"nv_pow",{writable:false,value:Math.pow})
Object.defineProperty(Math,"nv_random",{writable:false,value:Math.random})
Object.defineProperty(Math,"nv_round",{writable:false,value:Math.round})
Object.defineProperty(Math,"nv_sin",{writable:false,value:Math.sin})
Object.defineProperty(Math,"nv_sqrt",{writable:false,value:Math.sqrt})
Object.defineProperty(Math,"nv_tan",{writable:false,value:Math.tan})
}
var nf_init_Date=function(){
Object.defineProperty(Date.prototype,"nv_constructor",{writable:true,value:"Date"})
Object.defineProperty(Date,"nv_parse",{writable:true,value:Date.parse})
Object.defineProperty(Date,"nv_UTC",{writable:true,value:Date.UTC})
Object.defineProperty(Date,"nv_now",{writable:true,value:Date.now})
Object.defineProperty(Date.prototype,"nv_toString",{writable:true,value:Date.prototype.toString})
Object.defineProperty(Date.prototype,"nv_toDateString",{writable:true,value:Date.prototype.toDateString})
Object.defineProperty(Date.prototype,"nv_toTimeString",{writable:true,value:Date.prototype.toTimeString})
Object.defineProperty(Date.prototype,"nv_toLocaleString",{writable:true,value:Date.prototype.toLocaleString})
Object.defineProperty(Date.prototype,"nv_toLocaleDateString",{writable:true,value:Date.prototype.toLocaleDateString})
Object.defineProperty(Date.prototype,"nv_toLocaleTimeString",{writable:true,value:Date.prototype.toLocaleTimeString})
Object.defineProperty(Date.prototype,"nv_valueOf",{writable:true,value:Date.prototype.valueOf})
Object.defineProperty(Date.prototype,"nv_getTime",{writable:true,value:Date.prototype.getTime})
Object.defineProperty(Date.prototype,"nv_getFullYear",{writable:true,value:Date.prototype.getFullYear})
Object.defineProperty(Date.prototype,"nv_getUTCFullYear",{writable:true,value:Date.prototype.getUTCFullYear})
Object.defineProperty(Date.prototype,"nv_getMonth",{writable:true,value:Date.prototype.getMonth})
Object.defineProperty(Date.prototype,"nv_getUTCMonth",{writable:true,value:Date.prototype.getUTCMonth})
Object.defineProperty(Date.prototype,"nv_getDate",{writable:true,value:Date.prototype.getDate})
Object.defineProperty(Date.prototype,"nv_getUTCDate",{writable:true,value:Date.prototype.getUTCDate})
Object.defineProperty(Date.prototype,"nv_getDay",{writable:true,value:Date.prototype.getDay})
Object.defineProperty(Date.prototype,"nv_getUTCDay",{writable:true,value:Date.prototype.getUTCDay})
Object.defineProperty(Date.prototype,"nv_getHours",{writable:true,value:Date.prototype.getHours})
Object.defineProperty(Date.prototype,"nv_getUTCHours",{writable:true,value:Date.prototype.getUTCHours})
Object.defineProperty(Date.prototype,"nv_getMinutes",{writable:true,value:Date.prototype.getMinutes})
Object.defineProperty(Date.prototype,"nv_getUTCMinutes",{writable:true,value:Date.prototype.getUTCMinutes})
Object.defineProperty(Date.prototype,"nv_getSeconds",{writable:true,value:Date.prototype.getSeconds})
Object.defineProperty(Date.prototype,"nv_getUTCSeconds",{writable:true,value:Date.prototype.getUTCSeconds})
Object.defineProperty(Date.prototype,"nv_getMilliseconds",{writable:true,value:Date.prototype.getMilliseconds})
Object.defineProperty(Date.prototype,"nv_getUTCMilliseconds",{writable:true,value:Date.prototype.getUTCMilliseconds})
Object.defineProperty(Date.prototype,"nv_getTimezoneOffset",{writable:true,value:Date.prototype.getTimezoneOffset})
Object.defineProperty(Date.prototype,"nv_setTime",{writable:true,value:Date.prototype.setTime})
Object.defineProperty(Date.prototype,"nv_setMilliseconds",{writable:true,value:Date.prototype.setMilliseconds})
Object.defineProperty(Date.prototype,"nv_setUTCMilliseconds",{writable:true,value:Date.prototype.setUTCMilliseconds})
Object.defineProperty(Date.prototype,"nv_setSeconds",{writable:true,value:Date.prototype.setSeconds})
Object.defineProperty(Date.prototype,"nv_setUTCSeconds",{writable:true,value:Date.prototype.setUTCSeconds})
Object.defineProperty(Date.prototype,"nv_setMinutes",{writable:true,value:Date.prototype.setMinutes})
Object.defineProperty(Date.prototype,"nv_setUTCMinutes",{writable:true,value:Date.prototype.setUTCMinutes})
Object.defineProperty(Date.prototype,"nv_setHours",{writable:true,value:Date.prototype.setHours})
Object.defineProperty(Date.prototype,"nv_setUTCHours",{writable:true,value:Date.prototype.setUTCHours})
Object.defineProperty(Date.prototype,"nv_setDate",{writable:true,value:Date.prototype.setDate})
Object.defineProperty(Date.prototype,"nv_setUTCDate",{writable:true,value:Date.prototype.setUTCDate})
Object.defineProperty(Date.prototype,"nv_setMonth",{writable:true,value:Date.prototype.setMonth})
Object.defineProperty(Date.prototype,"nv_setUTCMonth",{writable:true,value:Date.prototype.setUTCMonth})
Object.defineProperty(Date.prototype,"nv_setFullYear",{writable:true,value:Date.prototype.setFullYear})
Object.defineProperty(Date.prototype,"nv_setUTCFullYear",{writable:true,value:Date.prototype.setUTCFullYear})
Object.defineProperty(Date.prototype,"nv_toUTCString",{writable:true,value:Date.prototype.toUTCString})
Object.defineProperty(Date.prototype,"nv_toISOString",{writable:true,value:Date.prototype.toISOString})
Object.defineProperty(Date.prototype,"nv_toJSON",{writable:true,value:Date.prototype.toJSON})
}
var nf_init_RegExp=function(){
Object.defineProperty(RegExp.prototype,"nv_constructor",{writable:true,value:"RegExp"})
Object.defineProperty(RegExp.prototype,"nv_exec",{writable:true,value:RegExp.prototype.exec})
Object.defineProperty(RegExp.prototype,"nv_test",{writable:true,value:RegExp.prototype.test})
Object.defineProperty(RegExp.prototype,"nv_toString",{writable:true,value:RegExp.prototype.toString})
Object.defineProperty(RegExp.prototype,"nv_source",{get:function(){return this.source;},set:function(){}});
Object.defineProperty(RegExp.prototype,"nv_global",{get:function(){return this.global;},set:function(){}});
Object.defineProperty(RegExp.prototype,"nv_ignoreCase",{get:function(){return this.ignoreCase;},set:function(){}});
Object.defineProperty(RegExp.prototype,"nv_multiline",{get:function(){return this.multiline;},set:function(){}});
Object.defineProperty(RegExp.prototype,"nv_lastIndex",{get:function(){return this.lastIndex;},set:function(v){this.lastIndex=v;}});
}
nf_init();
var nv_getDate=function(){var args=Array.prototype.slice.call(arguments);args.unshift(Date);return new(Function.prototype.bind.apply(Date, args));}
var nv_getRegExp=function(){var args=Array.prototype.slice.call(arguments);args.unshift(RegExp);return new(Function.prototype.bind.apply(RegExp, args));}
var nv_console={}
nv_console.nv_log=function(){var res="WXSRT:";for(var i=0;i<arguments.length;++i)res+=arguments[i]+" ";console.log(res);}
var nv_parseInt = parseInt, nv_parseFloat = parseFloat, nv_isNaN = isNaN, nv_isFinite = isFinite, nv_decodeURI = decodeURI, nv_decodeURIComponent = decodeURIComponent, nv_encodeURI = encodeURI, nv_encodeURIComponent = encodeURIComponent;
function $gdc(o,p,r) {
o=wh.rv(o);
if(o===null||o===undefined) return o;
if(o.constructor===String||o.constructor===Boolean||o.constructor===Number) return o;
if(o.constructor===Object){
var copy={};
for(var k in o)
if(o.hasOwnProperty(k))
if(undefined===p) copy[k.substring(3)]=$gdc(o[k],p,r);
else copy[p+k]=$gdc(o[k],p,r);
return copy;
}
if(o.constructor===Array){
var copy=[];
for(var i=0;i<o.length;i++) copy.push($gdc(o[i],p,r));
return copy;
}
if(o.constructor===Date){
var copy=new Date();
copy.setTime(o.getTime());
return copy;
}
if(o.constructor===RegExp){
var f="";
if(o.global) f+="g";
if(o.ignoreCase) f+="i";
if(o.multiline) f+="m";
return (new RegExp(o.source,f));
}
if(r&&o.constructor===Function){
if ( r == 1 ) return $gdc(o(),undefined, 2);
if ( r == 2 ) return o;
}
return null;
}
var nv_JSON={}
nv_JSON.nv_stringify=function(o){
JSON.stringify(o);
return JSON.stringify($gdc(o));
}
nv_JSON.nv_parse=function(o){
if(o===undefined) return undefined;
var t=JSON.parse(o);
return $gdc(t,'nv_');
}

function _af(p, a, c){
p.extraAttr = {"t_action": a, "t_cid": c};
}

function _ai(i,p,e,me,r,c){var x=_grp(p,e,me);if(x)i.push(x);else{i.push('');_wp(me+':import:'+r+':'+c+': Path `'+p+'` not found from `'+me+'`.')}}
function _grp(p,e,me){if(p[0]!='/'){var mepart=me.split('/');mepart.pop();var ppart=p.split('/');for(var i=0;i<ppart.length;i++){if( ppart[i]=='..')mepart.pop();else if(!ppart[i]||ppart[i]=='.')continue;else mepart.push(ppart[i]);}p=mepart.join('/');}if(me[0]=='.'&&p[0]=='/')p='.'+p;if(e[p])return p;if(e[p+'.wxml'])return p+'.wxml';}
function _gd(p,c,e,d){if(!c)return;if(d[p][c])return d[p][c];for(var x=e[p].i.length-1;x>=0;x--){if(e[p].i[x]&&d[e[p].i[x]][c])return d[e[p].i[x]][c]};for(var x=e[p].ti.length-1;x>=0;x--){var q=_grp(e[p].ti[x],e,p);if(q&&d[q][c])return d[q][c]}var ii=_gapi(e,p);for(var x=0;x<ii.length;x++){if(ii[x]&&d[ii[x]][c])return d[ii[x]][c]}for(var k=e[p].j.length-1;k>=0;k--)if(e[p].j[k]){for(var q=e[e[p].j[k]].ti.length-1;q>=0;q--){var pp=_grp(e[e[p].j[k]].ti[q],e,p);if(pp&&d[pp][c]){return d[pp][c]}}}}
function _gapi(e,p){if(!p)return [];if($gaic[p]){return $gaic[p]};var ret=[],q=[],h=0,t=0,put={},visited={};q.push(p);visited[p]=true;t++;while(h<t){var a=q[h++];for(var i=0;i<e[a].ic.length;i++){var nd=e[a].ic[i];var np=_grp(nd,e,a);if(np&&!visited[np]){visited[np]=true;q.push(np);t++;}}for(var i=0;a!=p&&i<e[a].ti.length;i++){var ni=e[a].ti[i];var nm=_grp(ni,e,a);if(nm&&!put[nm]){put[nm]=true;ret.push(nm);}}}$gaic[p]=ret;return ret;}
var $ixc={};function _ic(p,ent,me,e,s,r,gg){var x=_grp(p,ent,me);ent[me].j.push(x);if(x){if($ixc[x]){_wp('-1:include:-1:-1: `'+p+'` is being included in a loop, will be stop.');return;}$ixc[x]=true;try{ent[x].f(e,s,r,gg)}catch(e){}$ixc[x]=false;}else{_wp(me+':include:-1:-1: Included path `'+p+'` not found from `'+me+'`.')}}
function _w(tn,f,line,c){_wp(f+':template:'+line+':'+c+': Template `'+tn+'` not found.');}function _ev(dom){var changed=false;delete dom.properities;delete dom.n;if(dom.children){do{changed=false;var newch = [];for(var i=0;i<dom.children.length;i++){var ch=dom.children[i];if( ch.tag=='virtual'){changed=true;for(var j=0;ch.children&&j<ch.children.length;j++){newch.push(ch.children[j]);}}else { newch.push(ch); } } dom.children = newch; }while(changed);for(var i=0;i<dom.children.length;i++){_ev(dom.children[i]);}} return dom; }
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules;
var p_={}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_wxa75efa648b60994b || [];
if ( !__WXML_GLOBAL__.ops_init.$gwx_wxa75efa648b60994b){
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'autoplay']]);Z([3,'__onTvpEnded']);Z([3,'__onTvpError']);Z([3,'__onTvpPause']);Z([3,'__onTvpPlay']);Z([3,'__onTvpTimeupdate']);Z([3,'player_video']);Z([1,false]);Z([[2,'?:'],[[7],[3,'tvpIsAd']],[1,false],[[7],[3,'enableProgressGesture']]]);Z([1,true]);Z([[2,'=='],[[7],[3,'tvpState']],[1,'error']]);Z([3,'tvp']);Z([[2,'?:'],[[7],[3,'tvpIsAd']],[1,0],[[7],[3,'initialTime']]]);Z([[7],[3,'loop']]);Z([[7],[3,'muted']]);Z([[7],[3,'objectFit']]);Z([[7],[3,'pageGesture']]);Z([[7],[3,'poster']]);Z([[7],[3,'showCenterPlayBtn']]);Z([[7],[3,'showFullscreenBtn']]);Z([[7],[3,'showPlayBtn']]);Z([[2,'!'],[[7],[3,'tvpIsAd']]]);Z([[7],[3,'tvpUrl']]);Z([[2,'&&'],[[7],[3,'tvpIsAd']],[[7],[3,'progressSkipTime']]]);Z([3,'mod_skipad']);Z([[2,'!'],[[2,'&&'],[[2,'!='],[[7],[3,'progressSkipTime']],[[2,'-'],[1,1]]],[[2,'<='],[[7],[3,'progressSkipTime']],[[2,'+'],[[7],[3,'progressTime']],[[7],[3,'progressBaseTime']]]]]]);Z(z[25]);Z([[2,'&&'],[[2,'!='],[[7],[3,'progressSkipTime']],[[2,'-'],[1,1]]],[[2,'<='],[[7],[3,'progressSkipTime']],[[2,'+'],[[7],[3,'progressTime']],[[7],[3,'progressBaseTime']]]]]);Z(z[0]);Z(z[1]);Z(z[2]);Z(z[3]);Z(z[4]);Z(z[5]);Z(z[6]);Z([[2,'!'],[[2,'&&'],[[7],[3,'autoplay']],[[7],[3,'tvpIsAd']]]]);Z(z[7]);Z(z[8]);Z(z[9]);Z(z[10]);Z(z[11]);Z(z[12]);Z(z[13]);Z(z[14]);Z(z[15]);Z(z[16]);Z(z[17]);Z(z[18]);Z(z[19]);Z(z[20]);Z([[2,'!'],[[2,'&&'],[[2,'!'],[[7],[3,'autoplay']]],[[7],[3,'tvpIsAd']]]]);Z(z[22]);Z(z[23]);Z(z[24]);Z(z[25]);Z(z[25]);Z(z[27]);})(z);__WXML_GLOBAL__.ops_set.$gwx_wxa75efa648b60994b=z;
__WXML_GLOBAL__.ops_init.$gwx_wxa75efa648b60994b=true;
}
var nv_require=function(){var nnm={};var nom={};return function(n){return function(){if(!nnm[n]) return undefined;try{if(!nom[n])nom[n]=nnm[n]();return nom[n];}catch(e){e.message=e.message.replace(/nv_/g,'');var tmp = e.stack.substring(0,e.stack.lastIndexOf(n));e.stack = tmp.substring(0,tmp.lastIndexOf('\n'));e.stack = e.stack.replace(/\snv_/g,' ');e.stack = $gstack(e.stack);e.stack += '\n    at ' + n.substring(2);throw e;}
}}}()
var x=['./component/live/live.wxml','./component/noad-video/noad-video.wxml','./component/video/video.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
d_[x[1]]={}
var m1=function(e,s,r,gg){
var xC=_m('video',['autoplay',0,'bindended',1,'binderror',1,'bindpause',2,'bindplay',3,'bindtimeupdate',4,'class',5,'danmuBtn',6,'enableProgressGesture',7,'enableDanmu',8,'hidden',9,'id',10,'initialTime',11,'loop',12,'muted',13,'objectFit',14,'pageGesture',15,'poster',16,'showCenterPlayBtn',17,'showFullscreenBtn',18,'showPlayBtn',19,'showProgress',20,'src',21],[],e,s,gg)
var oD=_v()
_(xC,oD)
if(_o(23,e,s,gg)){oD.wxVkey=1
var fE=_n('cover-view')
_r(fE,'class',24,e,s,gg)
var cF=_v()
_(fE,cF)
if(_o(25,e,s,gg)){cF.wxVkey=1
}
var hG=_v()
_(fE,hG)
if(_o(26,e,s,gg)){hG.wxVkey=1
}
var oH=_v()
_(fE,oH)
if(_o(27,e,s,gg)){oH.wxVkey=1
}
cF.wxXCkey=1
hG.wxXCkey=1
oH.wxXCkey=1
_(oD,fE)
}
oD.wxXCkey=1
_(r,xC)
return r
}
e_[x[1]]={f:m1,j:[],i:[],ti:[],ic:[]}
d_[x[2]]={}
var m2=function(e,s,r,gg){
var oJ=_m('video',['autoplay',28,'bindended',1,'binderror',2,'bindpause',3,'bindplay',4,'bindtimeupdate',5,'class',6,'controls',7,'danmuBtn',8,'enableProgressGesture',9,'enableDanmu',10,'hidden',11,'id',12,'initialTime',13,'loop',14,'muted',15,'objectFit',16,'pageGesture',17,'poster',18,'showCenterPlayBtn',19,'showFullscreenBtn',20,'showPlayBtn',21,'showProgress',22,'src',23],[],e,s,gg)
var lK=_v()
_(oJ,lK)
if(_o(52,e,s,gg)){lK.wxVkey=1
var aL=_n('cover-view')
_r(aL,'class',53,e,s,gg)
var tM=_v()
_(aL,tM)
if(_o(54,e,s,gg)){tM.wxVkey=1
}
var eN=_v()
_(aL,eN)
if(_o(55,e,s,gg)){eN.wxVkey=1
}
var bO=_v()
_(aL,bO)
if(_o(56,e,s,gg)){bO.wxVkey=1
}
tM.wxXCkey=1
eN.wxXCkey=1
bO.wxXCkey=1
_(lK,aL)
}
lK.wxXCkey=1
_(r,oJ)
return r
}
e_[x[2]]={f:m2,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
}catch(err){
console.log(err)
}
return root;
}
}
}

				global.__wxAppCode__['plugin-private://wxa75efa648b60994b/component/live/live.json'] = {
  "component": true
};
		global.__wxAppCode__['plugin-private://wxa75efa648b60994b/component/live/live.wxml'] = $gwx_wxa75efa648b60994b( './component/live/live.wxml' );
		global.__wxAppCode__['plugin-private://wxa75efa648b60994b/component/noad-video/noad-video.json'] = {
  "component": true
};
		global.__wxAppCode__['plugin-private://wxa75efa648b60994b/component/noad-video/noad-video.wxml'] = $gwx_wxa75efa648b60994b( './component/noad-video/noad-video.wxml' );
		global.__wxAppCode__['plugin-private://wxa75efa648b60994b/component/video/video.json'] = {
  "component": true
};
		global.__wxAppCode__['plugin-private://wxa75efa648b60994b/component/video/video.wxml'] = $gwx_wxa75efa648b60994b( './component/video/video.wxml' );
		global.__wxAppCode__['plugin-private://wxa75efa648b60994b/plugin.json'] = {
  "publicComponents": {
    "video": "component/video/video",
    "noad-video": "component/noad-video/noad-video",
    "live": "component/live/live"
  },
  "main": "component/txv-context.js"
}
;
		global.__wxAppCode__['plugin-private://wxa75efa648b60994b/plugin.wxml'] = $gwx_wxa75efa648b60994b( './plugin.wxml' );
	
				define("component/txv-context.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";var t={};module.exports={getTxvContext:function(e){if(!t[e])throw new Error("找不到playerid为"+e+"的txv-video组件");return t[e]},txvAttached:function(e,r){t[e]=r},txvDetached:function(e){delete t[e]}}; 
 			}); 
		define("index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";var e=require("./src/video");module.exports=e; 
 			}); 
		define("lib-inject.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";var e="./src/lib/es6-promise",r="./src/lib/request";try{var s=require("../tvp.js");e=s.Promise||e,r=s.request||r}catch(e){}module.exports={Promise:require(e),request:require(r).get}; 
 			}); 
		define("src/classes/Content.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";function t(t,e){if(!(t instanceof e))throw new TypeError("Cannot call a class as a function")}var e="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(t){return typeof t}:function(t){return t&&"function"==typeof Symbol&&t.constructor===Symbol&&t!==Symbol.prototype?"symbol":typeof t},i=function(){function t(t,e){for(var i=0;i<e.length;i++){var n=e[i];n.enumerable=n.enumerable||!1,n.configurable=!0,"value"in n&&(n.writable=!0),Object.defineProperty(t,n.key,n)}}return function(e,i,n){return i&&t(e.prototype,i),n&&t(e,n),e}}(),n=require("../lib/message"),r=1;module.exports=function(){function o(e){var i=this;t(this,o),this.mockUpdate=0,this._urlIndex=0,Object.defineProperties(this,{_url:{value:e.url instanceof Array?e.url:[e.url]},_id:{value:r++},_duration:{value:e.duration},_filesize:{value:e.filesize},_charged:{value:e.charged},_preview:{value:e.preview},isad:{value:e.isad}}),(new n).assign(this);var u=null,a=null;this.on("play",function(){u=setTimeout(function(){i.emit("timeout",1e4)},1e4),a=setTimeout(function(){i.emit("timeout",2e4)},2e4)},!0),this.on("start",function(){clearTimeout(u),clearTimeout(a)},!0)}return i(o,[{key:"url",get:function(){return this._url[this._urlIndex]}},{key:"id",get:function(){return this._id}},{key:"duration",get:function(){return this._duration}},{key:"filesize",get:function(){return this._filesize}},{key:"preview",get:function(){return this._preview}},{key:"charged",get:function(){return this._charged}}]),i(o,[{key:"onContentEnd",value:function(){this.emit("end")}},{key:"onContentPlay",value:function(){this.emittedPlay=!0,this.emit("play")}},{key:"onContentPause",value:function(){}},{key:"onContentTimeupdate",value:function(t){this.emittedPlay&&(t&&t.target&&(t=t.detail.currentTime),!this.emittedStart&&((void 0===t?"undefined":e(t))==e(void 0)?this.mockUpdate++>5:t>0)&&(this.emit("start"),this.emittedStart=!0),this.emit.apply(this,["timeupdate",t]))}},{key:"onContentError",value:function(){if(this._url.length>this._urlIndex+1)return this._urlIndex++,void this.emit("change",this.url);this.emit.apply(this,["error"].concat([].slice.call(arguments,0)))}},{key:"onContentSkip",value:function(){this.isad&&this.emit("skip")}}]),o}(); 
 			}); 
		define("src/classes/Controller.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";function t(t,e){if(!(t instanceof e))throw new TypeError("Cannot call a class as a function")}function e(t){var e={};return(t instanceof Array?t:[].slice.call(arguments,0)).forEach(function(t){var n=t.initialize;Object.defineProperty(e,t.name,{get:function(){return n},set:function(e){var r=n;n=e,t.onChange&&t.onChange(e,r)}})}),e}var n=function(){function t(t,e){for(var n=0;n<e.length;n++){var r=e[n];r.enumerable=r.enumerable||!1,r.configurable=!0,"value"in r&&(r.writable=!0),Object.defineProperty(t,r.key,r)}}return function(e,n,r){return n&&t(e.prototype,n),r&&t(e,r),e}}(),r=require("../lib/message"),i=require("../../lib-inject").Promise;module.exports=function(){function o(){for(var n=this,a=arguments.length,s=Array(a),c=0;c<a;c++)s[c]=arguments[c];t(this,o),this.started=i.defer(),(new r).assign(this);var u=this.model=new e([{name:"state",onChange:function(t,e){n.emit("statechange",t,e)},initialize:"loading"},{name:"currentContent",initialize:null}]);Object.defineProperties(this,{currentContent:{get:function(){return u.currentContent}},state:{get:function(){return u.state}}}),this.flow=this.createFlow.apply(this,s),this.flow.catch(function(t){n.emit("error",t)}),["End","Play","Pause","Timeupdate","Error","Skip"].forEach(function(t){n["onContent"+t]=function(){for(var e=arguments.length,r=Array(e),i=0;i<e;i++)r[i]=arguments[i];n.emit.apply(n,["content"+t.toLowerCase()].concat(r))},n["on"+t]=function(){console.warn("不建议再使用video.on"+t+"，请使用onContent"+t),this["onContent"+t].apply(this,arguments)}})}return n(o,[{key:"createFlow",value:function(){}},{key:"start",value:function(){return this.started.resolve(),this}},{key:"stop",value:function(){return this.started.reject(),this.flow&&this.flow.stop(),this.off(),this}}]),o}(); 
 			}); 
		define("src/classes/State.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";function e(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}function t(){}var n=function(){function e(e,t){for(var n=0;n<t.length;n++){var r=t[n];r.enumerable=r.enumerable||!1,r.configurable=!0,"value"in r&&(r.writable=!0),Object.defineProperty(e,r.key,r)}}return function(t,n,r){return n&&e(t.prototype,n),r&&e(t,r),t}}(),r=require("../lib/message"),s=require("../../lib-inject").Promise;module.exports=function(){function a(n,s){e(this,a),this.destroyed=!1;var i=Object.keys(n);i.forEach(function(e){!(n[e].to instanceof Array)&&(n[e].to=[]),!("function"==typeof n[e].beforeLeave)&&(n[e].beforeLeave=t),!("function"==typeof n[e].beforeEnter)&&(n[e].beforeEnter=t),!("function"==typeof n[e].afterLeave)&&(n[e].afterLeave=t),!("function"==typeof n[e].afterEnter)&&(n[e].afterEnter=t)}),this.message=new r,this.states=n,this._state=i[0],this._laststate="",Object.defineProperties(this,{state:{get:function(){return this._state}},lastState:{get:function(){return this._laststate}}})}return n(a,null,[{key:"create",value:function(e,t){return new a(e,t)}}]),n(a,[{key:"setState",value:function(e,t){var n=(t=t||{}).force||!1,r=t.silent||!1,s=this.states;if(n||~s[this._state].to.indexOf(e)){var a=this._state;if(r)this._laststate=this._state,this._state=e;else{var i=!1;if(n||(i=!1===s[a].beforeLeave(e),i=!1===s[e].beforeEnter(a)||!0===i),i)return;this._laststate=this._state,this._state=e,this.message.emit("change",e,a),s[a].afterLeave(e),s[e].afterEnter(a)}return 0==s[e].to.length&&(this.message.emit("end",e),this.message.off()),this}}},{key:"getStatePromise",value:function(e){var t=this;if("function"!=typeof e){var n=e;e=function(e){return e==n}}return new s(function(n,r){var s=t.message.on("change",function(t){e(t)&&(s(),n())});t.message.on("end",function(e){s(),r(new Error("state ended:"+e))},!0)})}},{key:"onChange",value:function(e){return this.message.on("change",e),this}}]),a}(); 
 			}); 
		define("src/controller-live/flow-getinfo/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";var e=require("../../util/platform-config").APP_PLATFORM,i=require("../../../lib-inject").request,r=require("../../module/cache"),t=require("../../lib/algorithm/qvsec"),o=require("../../lib/algorithm/fillTimeStamp"),u=r.get("tvp_guid");u||(u=Math.random().toString(16).substring(2),r.set("tvp_guid",u)),module.exports=function(r,m,l,n){var q=o(),s=t["v4138"==l?"$xxzb":"$xxzbf"](e[l],r,1,1,q),d="";return s&&(d="encver="+("v4138"==l?"201":"301")+"&_qv_rmtv2="+s),i("https://info.zb.video.qq.com/?host=qq.com&cmd=2&qq=0&guid="+u+"&appVer=7&stream=2&ip=&system=1&sdtfrom="+e[l]+"&livepid="+m+"&cnlid="+r+"&_rnd="+q+"&"+d,{needlogin:!0})}; 
 			}); 
		define("src/controller-live/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";function t(t,e){if(!(t instanceof e))throw new TypeError("Cannot call a class as a function")}function e(t,e){if(!t)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return!e||"object"!=typeof e&&"function"!=typeof e?t:e}function n(t,e){if("function"!=typeof e&&null!==e)throw new TypeError("Super expression must either be null or a function, not "+typeof e);t.prototype=Object.create(e&&e.prototype,{constructor:{value:t,enumerable:!1,writable:!0,configurable:!0}}),e&&(Object.setPrototypeOf?Object.setPrototypeOf(t,e):t.__proto__=e)}var r=function(){function t(t,e){for(var n=0;n<e.length;n++){var r=e[n];r.enumerable=r.enumerable||!1,r.configurable=!0,"value"in r&&(r.writable=!0),Object.defineProperty(t,r.key,r)}}return function(e,n,r){return n&&t(e.prototype,n),r&&t(e,r),e}}(),o=function t(e,n,r){null===e&&(e=Function.prototype);var o=Object.getOwnPropertyDescriptor(e,n);if(void 0===o){var i=Object.getPrototypeOf(e);return null===i?void 0:t(i,n,r)}if("value"in o)return o.value;var u=o.get;if(void 0!==u)return u.call(r)},i=require("./flow-getinfo/index"),u=require("../classes/Controller"),a=require("../classes/Content"),l=function(l){function c(){return t(this,c),e(this,(c.__proto__||Object.getPrototypeOf(c)).apply(this,arguments))}return n(c,u),r(c,[{key:"createFlow",value:function(t,e){var n=this,r=t.sid,o=t.from,u=t.pid;t.defn,t.noad;"v4138"!=o&&"";var l=null,c=i(r,u,o).then(function(t){l=new a({url:t.data.playurl}),n.emit("contentchange",{currentContent:l})});return["End","Play","Pause","Timeupdate","Error","Skip"].forEach(function(t){n.on("content"+t.toLowerCase(),function(e){for(var n=arguments.length,r=Array(n>1?n-1:0),o=1;o<n;o++)r[o-1]=arguments[o];l&&l["onContent"+t].apply(l,r)})}),c}},{key:"stop",value:function(){o(c.prototype.__proto__||Object.getPrototypeOf(c.prototype),"stop",this).call(this),this.playflow&&this.playflow.stop()}}]),c}();module.exports=function(t,e){return new l(t,e)}; 
 			}); 
		define("src/controller-video/flow-getinfo/data/ad.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";function r(r){u(r,{header:{Cookie:"appuser="+d+"; Lturn="+a}}).then(function(r){console.log("上报成功"),console.log(r)},function(e){console.log("上报失败"),console.log(e),r=r+"&appuesr="+d,y.emit("report",{reportUrl:r}),console.log("用message抛出上报事件")})}function e(){a=h.get("Lturn"),console.log("Lturn:"+a),a?(a+=1,console.log("Lturn+1:"+a)):(a=Math.floor(1e3*Math.random()),console.log("create Lturn:"+a)),a>999&&(a=0),h.set("Lturn",a,72e5)}function t(r){var e=[];return r.item.forEach(function(r,t){e.push(r)}),e}function o(r){console.log("开始检查trueview贴片状态");for(var e=r.length,t=[],o=0,l=0;l<e;l++)r[l].trueviewTurn=!1,1==r[l].order_id||"FT"==r[l].type?t[l]=0:(i(r[l])&&(r[l].trueviewTurn=!0),t[l]=1,o+=1);n=1==o,console.log("trueviewCheckArr内容是："+t+",trueviewCount值是："+o)}function i(r){if(console.log("开始检查trueview开关"),r.params&&void 0!=r.params&&""!=r.params){var e=r.params;if(-1!=e.indexOf("richdata=")){var t=e.substr(e.indexOf("richdata=")+9);-1!=t.indexOf("&")&&(t=t.substr(0,t.indexOf("&"))),t=decodeURIComponent(t.replace(/\+/g," ")),console.log("转换出来的richdata参数是："+t);try{var o=JSON.parse(t);if(console.log("转换成json后的对象是："+o),o.plugins&&void 0!=o.plugins&&o.plugins.trueview&&void 0!=o.plugins.trueview&&"Y"==o.plugins.trueview)return console.log("trueview开关是打开的Y！"),!0}catch(r){console.log("richdata解析出错！")}}}return!1}function l(r){O=0;for(var e=0;e<r.length;e++)1!=r[e].order_id&&(O+=r[e].duration/1e3);console.log("广告总时长为："+O)}var n,p,a,d,s,u=require("../../../../lib-inject").request,c=require("../../../lib/message"),h=require("../../../module/cache"),g=require("./adReport"),v=require("./md5"),m="",U=0,f="",D=0,w=-1,L=1,T=-1,O=0,S="",K="",y=new c;(module.exports=function(i){console.log("ad video onLoad"),console.log(i),console.log("当前rfid:"+S),i.vid&&(m=i.vid),i.live&&(U=i.live),i.chid&&(D=i.chid),i.coverid&&(f=i.coverid),i.pu&&(w=i.pu),i.openid&&(K=i.openid),console.log("openid:"+K),d=String(v(K).substr(0,16)).toUpperCase(),console.log("appuesr:"+d),e();var c={};return p=(new Date).getTime(),u("https://livew.l.qq.com/livemsg?ty=web&ad_type=WL&pf=H5&lt=wx&pt=0&live="+U+"&pu="+w+"&rfid="+S+"&openid="+K+"&v=TencentPlayerV3.2.19.358&plugin=1.0.0&speed=0&adaptor=2&musictxt=&chid="+D+"&st=0&resp_type=json&_t=1478361546359&rfid=&vid="+m+"&vptag=&url=&refer=&pid=&mbid=&oid=&guid=&coverid="+f,{needlogin:!0,header:{Cookie:"appuser="+d+"; Lturn="+a}}).then(function(r){s=r,r.data.adLoc&&r.data.adLoc.tpid&&(L=r.data.adLoc.tpid),c={t:"0",url:"",vid:m,coverid:f,pf:"H5",vptag:"",pid:"",chid:D,tpid:L};var e=(new Date).getTime()-p;console.log("livew请求完成，进行dp3上报,时间为:"+e),g.reportDp3(2,"WL",e,1,100,0,K,c),p=(new Date).getTime();var i=t(r.data.adList);return console.log("最终adList:"+i),o(i),l(i),i},function(r){console.log("livew error，再试一次");var e=(new Date).getTime()-p;return console.log("livew请求失败，进行dp3上报,时间为:"+e),g.reportDp3(2,"WL",e,1,202,0,K,c),p=(new Date).getTime(),u("https://livew.l.qq.com/livemsg?ty=web&ad_type=WL&pf=H5&lt=wx&pt=0&live="+U+"&pu="+w+"&rfid="+S+"&v=TencentPlayerV3.2.19.358&plugin=1.0.0&speed=0&adaptor=2&musictxt=&chid="+D+"&openid="+K+"&st=0&resp_type=json&_t=1478361546359&rfid=&vid="+m+"&vptag=&url=&refer=&pid=&mbid=&oid=&guid=&coverid="+f,{needlogin:!0,header:{Cookie:"appuser="+d+"; Lturn="+a}}).then(function(r){s=r,r.data.adLoc&&r.data.adLoc.tpid&&(L=r.data.adLoc.tpid),c={t:"0",url:"",vid:m,coverid:f,pf:"H5",vptag:"",pid:"",chid:D,tpid:L};var e=(new Date).getTime()-p;console.log("livew重试请求完成，进行dp3上报,时间为:"+e),g.reportDp3(2,"WL",e,1,100,0,K,c),p=(new Date).getTime();var i=t(r.data.adList);return console.log("最终adList:"+i),o(i),l(i),i},function(r){var e=(new Date).getTime()-p;return console.log("livew error，订单获取失败，返回空数组，进行dp3上报,时间为:"+e),g.reportDp3(2,"WL",e,1,202,0,K,c),p=(new Date).getTime(),[]})}).then(function(e){return e=e.map(function(e,t){return function(){var t=[];if(e.reportUrlOther.reportitem)for(i=0;i<e.reportUrlOther.reportitem.length;i++)t[i]={url:e.reportUrlOther.reportitem[i].url,time:e.reportUrlOther.reportitem[i].reporttime,isReported:!1};var o=[];if(e.reportUrlSDK.reportitem)for(var i=0;i<e.reportUrlSDK.reportitem.length;i++)o[i]={url:e.reportUrlSDK.reportitem[i].url,time:e.reportUrlSDK.reportitem[i].reporttime,isReported:!1};return console.log("当前广告的trueview开关是否打开："+e.trueviewTurn),console.log("当前广告是否符合trueview条件："+n),n?(console.log("allAdDuration:"+O),T=O<=5?0:5):T=-1,console.log("skipable:"+T),{oid:e.order_id,url:e.image[0].url,reportUrl:{url:e.reportUrl,time:e.ReportTime,isReported:!1},reportUrlOther:t,reportUrlSDK:o,skipable:T,duration:e.duration/1e3,allDuration:O,onSkip:function(){console.log("当前广告被跳过了，上报智慧点10237"),g.reportWisdomPoint(10237,e.order_id,e.order_id,"");var r=(new Date).getTime()-p;console.log("当前广告被跳过，进行dp3上报,时间为:"+r),g.reportDp3(4,"WL",r,1,"",0,K,c),p=(new Date).getTime()},onTimeupdate:function(r){},onEnd:function(){var r=(new Date).getTime()-p;console.log("当前广告播放结束，进行dp3上报,时间为:"+r),g.reportDp3(5,"WL",r,1,"",0,K,c),p=(new Date).getTime(),s.data.adLoc&&s.data.adLoc.rfid&&(S=s.data.adLoc.rfid,console.log("rfid赋值成功："+S))},onStart:function(){console.log("当前广告开始播放"+e),console.log("当前广告的oid是："+this.oid);var t=(new Date).getTime()-p;if(console.log("素材加载完成，开始播放，进行dp3上报,时间为:"+t),g.reportDp3(3,"WL",t,1,"",0,K,c),p=(new Date).getTime(),this.reportUrl.url=g.updateUrlParam(this.reportUrl.url,c),this.reportUrl.time>=0&&!this.reportUrl.isReported){this.reportUrl.isReported=!0;try{r(this.reportUrl.url)}catch(r){}}for(o=0;o<this.reportUrlOther.length;o++)if(this.reportUrlOther[o].url=g.updateUrlParam(this.reportUrlOther[o].url,c),this.reportUrlOther[o].time>=0&&!this.reportUrlOther[o].isReported){this.reportUrlOther[o].isReported=!0;try{g.pingUrl(this.reportUrlOther[o].url)}catch(r){}}for(var o=0;o<this.reportUrlSDK.length;o++)if(this.reportUrlSDK[o].url=g.updateUrlParam(this.reportUrlSDK[o].url,c),this.reportUrlSDK[o].time>=0&&!this.reportUrlSDK[o].isReported){this.reportUrlSDK[o].isReported=!0;try{g.pingUrl(this.reportUrlSDK[o].url)}catch(r){}}},onError:function(){var r=(new Date).getTime()-p;console.log("当前广告播放出错，进行dp3上报,时间为:"+r),g.reportDp3(4,"WL",r,1,"",0,K,c),p=(new Date).getTime()},onReportEmpty:function(){console.log("我是空单上报，当前广告的上报地址是："+this.reportUrl.url),this.reportUrl.url=g.updateUrlParam(this.reportUrl.url,c);try{r(this.reportUrl.url)}catch(r){}for(e=0;e<this.reportUrlOther.length;e++)if(this.reportUrlOther[e].url=g.updateUrlParam(this.reportUrlOther[e].url,c),this.reportUrlOther[e].time>=0&&!this.reportUrlOther[e].isReported){this.reportUrlOther[e].isReported=!0;try{g.pingUrl(this.reportUrlOther[e].url)}catch(r){}}for(var e=0;e<this.reportUrlSDK.length;e++)if(this.reportUrlSDK[e].url=g.updateUrlParam(this.reportUrlSDK[e].url,c),this.reportUrlSDK[e].time>=0&&!this.reportUrlSDK[e].isReported){this.reportUrlSDK[e].isReported=!0;try{g.pingUrl(this.reportUrlSDK[e].url)}catch(r){}}}}}}),{adList:e}}).catch(function(r){return{}})}).reporter=g.reporter; 
 			}); 
		define("src/controller-video/flow-getinfo/data/adReport.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";function r(r){var e=r.indexOf("?"),t=new Object,o=r;if(e>=0)for(var i,n=(o=o.substr(e+1)).split("&"),l=0;l<n.length;l++)(i=n[l].split("=")).length>1?t[i[0]]=i[1]:t[i[0]]="null";return t}var e=require("../../../lib/message"),t=(require("../../../module/cache"),new e);(module.exports={updateUrlParam:function(e,t){try{var o=r(e),i=e,n=!0;if(-1!=e.indexOf("?")){i=e.substring(0,e.indexOf("?"));var l;for(l in t)o[l]=t[l];for(l in o)n?(n=!1,i+="?"+l+"="+o[l]):i+="&"+l+"="+o[l]}}catch(r){i=""}return i},reportDp3:function(r,e,t,o,i,n,l,s){console.log("开始dp3上报");var c="https://dp3.qq.com/stdlog/?bid=weixin&step="+r+"&merged="+o+"&errorcode="+i+"&trycount="+n+"&openid="+l;c=this.updateUrlParam(c,s);try{this.pingUrl(c)}catch(r){console.log("dp3上报失败")}},reportWisdomPoint:function(r,e,t,o){console.log("开始智慧点上报");var i="https://t.l.qq.com?t=s&actid="+r;i+="&oid="+e+"&mid="+t+"&locid="+o;try{this.pingUrl(i)}catch(r){}},pingUrl:function(r,e,o,i){console.log("ping上报地址："+r);var n=(new Date).getTime();r=this.updateUrlParam(r,{reportTime:n}),t.emit("report",{reportUrl:r}),console.log("用message抛出上报事件")}}).reporter=t; 
 			}); 
		define("src/controller-video/flow-getinfo/data/getinfo-status.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";var e={};e[10001]=e[50]=e[68]=e[71]=e[73]=e[74]=e[76]=e[77]=e[445]=e[444]="啊哦，没能找到你要的节目信息~",e[51]=e[52]=e[64]=e[61]=e[62]=e[63]=e[65]=e[66]=e[69]=e[81]=e[82]=e[84]=e[86]=e[94]="啊哦，本来在这儿的视频不见了~",e[80]=e[83]="啊哦，版权原因，该视频暂时无法播放~",module.exports=e; 
 			}); 
		define("src/controller-video/flow-getinfo/data/getinfo.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";function e(e,c,p){t=c,p=p||"auto";var a=o(),s=i["v4138"==c?"$xx":"$xxf"](f[c],e,t,1,a),m="";s&&(m="encver="+("v4138"==c?2:300)+"&_qv_rmtv2="+s),console.log("getinfo waiting");return new l(function(e,t){e()}).then(function(){return console.log("request start"),n("https://h5vv.video.qq.com/getinfo?"+m+"&defn="+p+"&platform="+f[c]+"&otype=json&sdtfrom="+c+"&_rnd="+a+"&appVer=7&"+(u?"dtype=3&":"")+"vid="+e+"&newnettype=0",{needlogin:!0})}).catch(function(){return n("https://bkvv.video.qq.com/getinfo?"+m+"&defn="+p+"&platform="+f[c]+"&otype=json&sdtfrom="+c+"&_rnd="+a+"&appVer=7&"+(u?"dtype=3&":"")+"vid="+e+"&newnettype=0",{needlogin:!0})}).catch(function(){var e=new Error(r[444]);throw e.em=444,e.code="G.444",e}).then(function(e){return e=e.data,console.log("getinfo result:",e),e})}var t,r=require("./getinfo-status"),n=require("../../../../lib-inject").request,i=require("../../../lib/algorithm/qvsec"),o=require("../../../lib/algorithm/fillTimeStamp"),l=require("../../../../lib-inject").Promise,u="devtools"!=wx.getSystemInfoSync().platform,f=require("../../../util/platform-config").APP_PLATFORM;module.exports=function(){return e.apply(this,arguments).then(function(e){if(e.em){var t=new Error(r[e.em]);throw t.em=e.em,t.code="G."+e.em,t}return e}).then(function(e){var r=e.vl.vi[0],n={duration:+r.td,dltype:e.dltype,fmid:e.fl.fi.filter(function(e){return+e.sl})[0].id,filesize:e.fl.fi.filter(function(e){return+e.sl})[0].fs,preview:e.preview,charge:r.ch,raw:e};return r.ch<1&&(n.preview=e.preview,n.charged=r.ch),3==e.dltype?(n.url=r.ul.ui.map(function(e){return e.hls.pt?e.url+e.hls.pt+"?platform="+f[t]+"&sdtfrom="+t:""}),n.url=n.url.filter(function(e){return e})):n.url=r.ul.ui.map(function(e){return e.url+r.fn+"?vkey="+r.fvkey+"&br="+r.br+"&fmt=auto&level="+r.level+"&platform="+f[t]+"&sdtfrom="+t}),n})}; 
 			}); 
		define("src/controller-video/flow-getinfo/data/md5.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";var n="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(n){return typeof n}:function(n){return n&&"function"==typeof Symbol&&n.constructor===Symbol&&n!==Symbol.prototype?"symbol":typeof n};!function(t){function r(n,t){var r=(65535&n)+(65535&t);return(n>>16)+(t>>16)+(r>>16)<<16|65535&r}function o(n,t){return n<<t|n>>>32-t}function e(n,t,e,u,f,c){return r(o(r(r(t,n),r(u,c)),f),e)}function u(n,t,r,o,u,f,c){return e(t&r|~t&o,n,t,u,f,c)}function f(n,t,r,o,u,f,c){return e(t&o|r&~o,n,t,u,f,c)}function c(n,t,r,o,u,f,c){return e(t^r^o,n,t,u,f,c)}function i(n,t,r,o,u,f,c){return e(r^(t|~o),n,t,u,f,c)}function d(n,t){n[t>>5]|=128<<t%32,n[14+(t+64>>>9<<4)]=t;var o,e,d,l,a,h=1732584193,m=-271733879,y=-1732584194,p=271733878;for(o=0;o<n.length;o+=16)e=h,d=m,l=y,a=p,m=i(m=i(m=i(m=i(m=c(m=c(m=c(m=c(m=f(m=f(m=f(m=f(m=u(m=u(m=u(m=u(m,y=u(y,p=u(p,h=u(h,m,y,p,n[o],7,-680876936),m,y,n[o+1],12,-389564586),h,m,n[o+2],17,606105819),p,h,n[o+3],22,-1044525330),y=u(y,p=u(p,h=u(h,m,y,p,n[o+4],7,-176418897),m,y,n[o+5],12,1200080426),h,m,n[o+6],17,-1473231341),p,h,n[o+7],22,-45705983),y=u(y,p=u(p,h=u(h,m,y,p,n[o+8],7,1770035416),m,y,n[o+9],12,-1958414417),h,m,n[o+10],17,-42063),p,h,n[o+11],22,-1990404162),y=u(y,p=u(p,h=u(h,m,y,p,n[o+12],7,1804603682),m,y,n[o+13],12,-40341101),h,m,n[o+14],17,-1502002290),p,h,n[o+15],22,1236535329),y=f(y,p=f(p,h=f(h,m,y,p,n[o+1],5,-165796510),m,y,n[o+6],9,-1069501632),h,m,n[o+11],14,643717713),p,h,n[o],20,-373897302),y=f(y,p=f(p,h=f(h,m,y,p,n[o+5],5,-701558691),m,y,n[o+10],9,38016083),h,m,n[o+15],14,-660478335),p,h,n[o+4],20,-405537848),y=f(y,p=f(p,h=f(h,m,y,p,n[o+9],5,568446438),m,y,n[o+14],9,-1019803690),h,m,n[o+3],14,-187363961),p,h,n[o+8],20,1163531501),y=f(y,p=f(p,h=f(h,m,y,p,n[o+13],5,-1444681467),m,y,n[o+2],9,-51403784),h,m,n[o+7],14,1735328473),p,h,n[o+12],20,-1926607734),y=c(y,p=c(p,h=c(h,m,y,p,n[o+5],4,-378558),m,y,n[o+8],11,-2022574463),h,m,n[o+11],16,1839030562),p,h,n[o+14],23,-35309556),y=c(y,p=c(p,h=c(h,m,y,p,n[o+1],4,-1530992060),m,y,n[o+4],11,1272893353),h,m,n[o+7],16,-155497632),p,h,n[o+10],23,-1094730640),y=c(y,p=c(p,h=c(h,m,y,p,n[o+13],4,681279174),m,y,n[o],11,-358537222),h,m,n[o+3],16,-722521979),p,h,n[o+6],23,76029189),y=c(y,p=c(p,h=c(h,m,y,p,n[o+9],4,-640364487),m,y,n[o+12],11,-421815835),h,m,n[o+15],16,530742520),p,h,n[o+2],23,-995338651),y=i(y,p=i(p,h=i(h,m,y,p,n[o],6,-198630844),m,y,n[o+7],10,1126891415),h,m,n[o+14],15,-1416354905),p,h,n[o+5],21,-57434055),y=i(y,p=i(p,h=i(h,m,y,p,n[o+12],6,1700485571),m,y,n[o+3],10,-1894986606),h,m,n[o+10],15,-1051523),p,h,n[o+1],21,-2054922799),y=i(y,p=i(p,h=i(h,m,y,p,n[o+8],6,1873313359),m,y,n[o+15],10,-30611744),h,m,n[o+6],15,-1560198380),p,h,n[o+13],21,1309151649),y=i(y,p=i(p,h=i(h,m,y,p,n[o+4],6,-145523070),m,y,n[o+11],10,-1120210379),h,m,n[o+2],15,718787259),p,h,n[o+9],21,-343485551),h=r(h,e),m=r(m,d),y=r(y,l),p=r(p,a);return[h,m,y,p]}function l(n){var t,r="",o=32*n.length;for(t=0;t<o;t+=8)r+=String.fromCharCode(n[t>>5]>>>t%32&255);return r}function a(n){var t,r=[];for(r[(n.length>>2)-1]=void 0,t=0;t<r.length;t+=1)r[t]=0;var o=8*n.length;for(t=0;t<o;t+=8)r[t>>5]|=(255&n.charCodeAt(t/8))<<t%32;return r}function h(n){return l(d(a(n),8*n.length))}function m(n,t){var r,o,e=a(n),u=[],f=[];for(u[15]=f[15]=void 0,e.length>16&&(e=d(e,8*n.length)),r=0;r<16;r+=1)u[r]=909522486^e[r],f[r]=1549556828^e[r];return o=d(u.concat(a(t)),512+8*t.length),l(d(f.concat(o),640))}function y(n){var t,r,o="";for(r=0;r<n.length;r+=1)t=n.charCodeAt(r),o+="0123456789abcdef".charAt(t>>>4&15)+"0123456789abcdef".charAt(15&t);return o}function p(n){return unescape(encodeURIComponent(n))}function g(n){return h(p(n))}function v(n){return y(g(n))}function b(n,t){return m(p(n),p(t))}function s(n,t){return y(b(n,t))}function S(n,t,r){return t?r?b(t,n):s(t,n):r?g(n):v(n)}"function"==typeof define&&define.amd?define(function(){return S}):"object"===("undefined"==typeof module?"undefined":n(module))&&module.exports?module.exports=S:t.md5=S}(void 0); 
 			}); 
		define("src/controller-video/flow-getinfo/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";var e=require("../../../lib-inject").Promise,i=require("./data/ad"),r=require("./data/getinfo");module.exports=function(d){var n=(d=d||{}).vid,o=d.cid,t=d.from,a=d.openid,u=d.defn,v=d.noad;return e.all([v?e.resolve({}):i({coverid:o,vid:n,live:0,chid:41,pu:1,openid:a||""}),r(n,t,u)]).then(function(e){return{ad:e[0],videoinfo:e[1]}})}; 
 			}); 
		define("src/controller-video/flow-play/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";var n=require("../../../lib-inject").Promise,e=require("../../lib/message"),o=require("../../classes/Content");module.exports=function(t,i,r){var u={time:0,duration:0,skipable:!1},a={},c={},f=[],d=n.defer(),s=d.promise,l=new e,p=null,m=function(n){console.log("contentchange:",n,c);var e={currentContent:n=n||p,preloadContents:f.filter(function(e){return!c[e.id]&&e!=n}),getinforaw:h.raw};n&&n.isad&&(e.progress=u),p=n,r(e)},v=t.ad,h=t.videoinfo,g=!1;(v.adList||[]).forEach(function(e){var t=e(),i=new o({url:t.url,duration:t.duration,isad:!0}),r=new n(function(n){g||(i.on("end",function(){n(),t.onEnd()},!0),i.on("error",function(){n(),t.onError()},!0),i.on("timeout",function(){n(),t.onError()},!0),i.on("skip",function(){g=!0,n(),t.onSkip()},!0),i.on("start",function(){l.emit("adplaying",i),t.onStart()},!0),i.on("timeupdate",function(n){t.onTimeupdate(n)},!0),l.on("_terminate",function(){n()}))}).then(function(n){return c[i.id]=!0,n});a[i.id]=i,f.push(i),u.duration+=t.duration,u.skipable=t.skipable,s=s.then(function(){return console.info("playflow: ad."+t.url),"1"==t.oid?(console.log("这是一个空单，往下走"),void t.onReportEmpty()):(m(i),r.then(function(n){u.time+=i.duration}))})});var w=new o({url:h.url,duration:h.duration,filesize:h.filesize,isad:!1,preview:h.preview,charged:h.charged});a[w.id]=w,f.unshift(w);var y=new n(function(n,e){function o(o){!t&&o.on("start",function(){l.emit("videoplaying",o),t=!0},!0),o.on("play",function(){l.emit("videoplay",o)}),o.on("pause",function(){l.emit("videopause",o)}),o.on("timeupdate",function(n){l.emit("videotimeupdate",n,h.duration)}),o.on("error",function(n){var o=new Error(n?n.detail&&n.detail.errMsg||n.message:"播放出错");o.code="P.0",e(o)},!0),o.on("end",n,!0),o.on("timeout",function(n){l.emit("videotimeout",n)})}var t=!1;o(w),l.on("_terminate",function(){n()}),l.on("_changevideocontent",function(n){w.off(),c[w.id]=!0,f.every(function(e,o){return e!=w||(f.splice(o,1,n),!1)}),o(n),m(p==w?n:null),a[n.id]=n,w=n})}).then(function(n){return c[w.id]=!0,n});s=s.then(function(){return w.off("change"),w.on("change",function(){m(w)}),l.on("_changevideocontent",function(n){w.off("change"),n.on("change",function(){m(n)})}),m(w),y}).then(function(){l.emit("end")}).catch(function(n){throw l.emit("error",n),n}),m(null);var E={progress:s,stop:function(){return l.emit("_terminate"),l.emit("terminate"),Object.keys(a).forEach(function(n){a[n].off()}),l.off(),this},start:function(){return d.resolve(),s},on:function(){return l.on.apply(l,arguments)},switchVideo:function(n){var e=n.videoinfo;h=e;var t=new o({url:e.url,duration:e.duration,filesize:e.filesize,isad:!1,preview:e.preview,charged:e.charged});l.emit("_changevideocontent",t)}};return["End","Play","Pause","Timeupdate","Error","Skip"].forEach(function(n){i.on("content"+n.toLowerCase(),function(e){for(var o=e&&a[e]?a[e]:p,t=arguments.length,i=Array(t>1?t-1:0),r=1;r<t;r++)i[r-1]=arguments[r];o&&o["onContent"+n].apply(o,i)})}),E}; 
 			}); 
		define("src/controller-video/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";function e(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}function t(e,t){if(!e)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return!t||"object"!=typeof t&&"function"!=typeof t?e:t}function n(e,t){if("function"!=typeof t&&null!==t)throw new TypeError("Super expression must either be null or a function, not "+typeof t);e.prototype=Object.create(t&&t.prototype,{constructor:{value:e,enumerable:!1,writable:!0,configurable:!0}}),t&&(Object.setPrototypeOf?Object.setPrototypeOf(e,t):e.__proto__=t)}var r=function(){function e(e,t){for(var n=0;n<t.length;n++){var r=t[n];r.enumerable=r.enumerable||!1,r.configurable=!0,"value"in r&&(r.writable=!0),Object.defineProperty(e,r.key,r)}}return function(t,n,r){return n&&e(t.prototype,n),r&&e(t,r),t}}(),o=function e(t,n,r){null===t&&(t=Function.prototype);var o=Object.getOwnPropertyDescriptor(t,n);if(void 0===o){var i=Object.getPrototypeOf(t);return null===i?void 0:e(i,n,r)}if("value"in o)return o.value;var a=o.get;if(void 0!==a)return a.call(r)},i=require("../../lib-inject").Promise,a=require("./flow-getinfo/index"),u=require("./flow-play/index"),f=require("./reporter"),c=require("../module/reporter/index"),l=require("../classes/Controller");require("./flow-getinfo/data/ad").reporter.on("report",function(e){c.any(e)});var p=function(c){function p(){return e(this,p),t(this,(p.__proto__||Object.getPrototypeOf(p)).apply(this,arguments))}return n(p,l),r(p,[{key:"createFlow",value:function(e,t){var n=this;e=e||{},t=t||{};var r=e,o=r.vid,c=r.from,l=r.cid,p=r.defn,s=r.noad,d=t.getReportParam,y=new i(function(e){d?d(function(t,n){e(n&&n.hc_openid||"")}):e("")}),h=f({cid:l,vid:o},{getReportParam:d}),v=this.model,w=y.then(function(e){return a({vid:o,from:c,cid:l,openid:e,defn:p,noad:s})}).then(function(e){v.state="ready";var t=n.playflow=u(e,n,function(e){v.currentContent=e.currentContent,n.emit("contentchange",e)});return h.setPlayFlow(t),h.setVideoInfo(e.videoinfo),t.on("videotimeupdate",function(){for(var e=arguments.length,t=Array(e),r=0;r<e;r++)t[r]=arguments[r];n.emit.apply(n,["videotimeupdate"].concat(t))}),n.started.promise}).then(function(){return v.state="playing",n.playflow.start()}).then(function(e){v.state="ended"}).catch(function(e){throw v.state="error",n.playflow&&n.playflow.stop(),h.error(e),e});return this.switchDefn=function(e){return y.then(function(t){return a({vid:o,from:c,cid:l,openid:t,defn:e,noad:!0})}).then(function(e){n.playflow.switchVideo(e)})},w}},{key:"stop",value:function(){this.model.state="ended",o(p.prototype.__proto__||Object.getPrototypeOf(p.prototype),"stop",this).call(this),this.playflow&&this.playflow.stop()}}]),p}();module.exports=function(e,t){return new p(e,t)}; 
 			}); 
		define("src/controller-video/report-play.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";var e="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(e){return typeof e}:function(e){return e&&"function"==typeof Symbol&&e.constructor===Symbol&&e!==Symbol.prototype?"symbol":typeof e},o=require("./../module/reporter/report-queue"),t=wx.getSystemInfoSync();module.exports=function(n){var r=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{},p=arguments[2],i=arguments[3];p(function(p,l){p&&(l={}),delete l.val1,delete l.val2,delete l.val3,"object"==e(l[n])&&(["val1","val2","val3"].forEach(function(e){l[e]=l[n][e]}),delete l[n]);var a=[],c=a.pop(),u=a.pop(),f={},d={BossId:4327,Pwd:944465292,app_version:"1.1.1",platform:t.platform,client_model:t.model,wx_version:t.version,network:f&&f.networkType?f.networkType:"",step:n,page_url:c&&c.$name||"",page_query:c&&c.$query||"",page_ref:u&&u.$name||""};["hc_vuserid","hc_openid","hc_appid","ptag","iformat","duration","defn","tpay","adid","playtime","page_url","page_query","page_ref","cid","vid","isvip","val1","val2","val3","appname","nick","rmd","scene","additional"].forEach(function(e){e in r&&(d[e]=r[e]),e in l&&(d[e]=l[e]),void 0==d[e]&&(d[e]="")}),i&&"function"==typeof i?i(null,{reportUrl:"https://btrace.qq.com/kvcollect?"+Object.keys(d).map(function(e){return e in d?e+"="+encodeURIComponent(d[e]):""}).filter(function(e){return e}).join("&")}):o.push({reportUrl:"https://btrace.qq.com/kvcollect?"+Object.keys(d).map(function(e){return e in d?e+"="+encodeURIComponent(d[e]):""}).filter(function(e){return e}).join("&")})})}; 
 			}); 
		define("src/controller-video/reporter.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";function n(n){return{1:1,2:1,10001:4,10002:3,10003:2,10201:4,10202:3,10203:2,100001:2,320089:2,320091:3,320092:4,320093:5}[n]}function e(n){var e=!1,o=function(){e||(e=!0,n.done=e,n.apply(this,arguments))};return o.done=e,o}var o=require("./report-play"),t=require("../module/reporter/index"),r=[5,30];module.exports=function(a,i){function u(){return{iformat:d?d.dltype:0,duration:d?Math.floor(d.duration):"",defn:d?n(d.fmid):"",playtime:s+(c?Date.now()-c:0),vid:l||"",cid:f||""}}var c,l=a.vid,f=a.cid,v=i.getReportParam||function(n){return n({})},d=null,p=0,s=0,m=!1,w=!1,y=e(function(n){var e=u();e.val1=0,e.val2=0,e.val3=n,o(7,e,v)}),D=e(function(n){var e=u();e.val1=p?Date.now()-p:0,e.val2=m?0:1,e.val3=n,o(6,e,v)}),h=e(function(n,e){var t=u();t.val1=p?Date.now()-p:0,t.val2={error:3,complete:1,incomplete:w?2:0}[n],void 0==t.val2&&(t.val2=2),t.val3=e,o(5,t,v)}),g=null,C=e(function(n,e){t.reportCache.del("step30");var r=u();r.val1=n,r.val2=e,o(30,r,v)}),q=function(n,e){if(1e4==n){g=setTimeout(function(){C(n)},11e3);var r=u();r.val1=n,r.val2=e,o(30,r,v,function(n,e){t.reportCache.set("step30",e)})}else clearTimeout(g),C(n)};return o(3,u(),v),t.on("_save",function(){var n=u();n.val1=p?Date.now()-p:0,n.val2=w?2:0,o(5,n,v,function(n,e){t.reportCache.set("step5",e)})}),t.on("_restore",function(){r.forEach(function(n){t.reportCache.del("step"+n)})}),{setPlayFlow:e(function(n){n.on("adplaying",function(n){m=!0,y(n.url)}),n.on("videoplay",function(n){!p&&(p=Date.now()),c=Date.now()}),n.on("videoplaying",function(n){w=!0,D(n.url),q(p?Date.now()-p:0,0)}),n.on("videopause",function(){s+=Date.now()-c,c=0}),n.on("videotimeout",function(n){q(n,1)}),n.on("terminate",function(){h("incomplete")}),n.on("end",function(){h("complete")}),n.on("error",function(n){h("error","1 "+(n.code||"")+" "+n.message)})}),setVideoInfo:e(function(n){d=n}),error:function(n){h("error","2 "+(n.code||"")+" "+n.message)}}}; 
 			}); 
		define("src/lib/algorithm/fillTimeStamp.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";module.exports=function(r){r=r||10;var t=parseInt(+new Date)+"";if(t.length===r)return t;if(t.length>r)return t.substring(0,r);for(var e=r-t.length;e>0;)t="0"+t,e--;return t}; 
 			}); 
		define("src/lib/algorithm/qvsec.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";var r={};r.ha=function(r){function t(r,t){return((r>>1)+(t>>1)<<1)+(1&r)+(1&t)}for(var e=[],n=0;n<64;)e[n]=0|4294967296*Math.abs(Math.sin(++n));return function(r){for(var n,a,o,u,c=[],h=decodeURIComponent(encodeURI(r)),f=h.length,i=[n=1732584193,a=-271733879,~n,~a],d=0;d<=f;)c[d>>2]|=(h.charCodeAt(d)||128)<<d++%4*8;for(c[r=16*(f+8>>6)+14]=8*f,d=0;d<r;d+=16){for(f=i,u=0;u<64;)f=[o=f[3],t(n=f[1],(o=t(t(f[0],[n&(a=f[2])|~n&o,o&n|~o&a,n^a^o,a^(n|~o)][f=u>>4]),t(e[u],c[[u,5*u+1,3*u+5,7*u][f]%16+d])))<<(f=[7,12,17,22,5,9,14,20,4,11,16,23,6,10,15,21][4*f+u++%4])|o>>>32-f),n,a];for(u=4;u;)i[--u]=t(i[u],f[u])}for(r="";u<32;)r+=(i[u>>3]>>4*(1^7&u++)&15).toString(16);return r}}(),r.stringToHex=function(r){for(var t="",e=new Array("0","1","2","3","4","5","6","7","8","9","a","b","c","d","e","f"),n=0;n<r.length;n++)t+=e[r.charCodeAt(n)>>4]+e[15&r.charCodeAt(n)];return t},r.hexToString=function(r){for(var t="",e="0x"==r.substr(0,2)?2:0;e<r.length;e+=2)t+=String.fromCharCode(parseInt(r.substr(e,2),16));return t},r._Seed="#$#@#*ad",r.tempcalc=function(r,t){for(var e="",n=0;n<r.length;n++)e+=String.fromCharCode(r.charCodeAt(n)^t.charCodeAt(n%4));return e},r.u1=function(r,t){for(var e="",n=t;n<r.length;n+=2)e+=r.charAt(n);return e},r._urlStr="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",r.urlenc=function(t,e,n){for(var a,o,u,c,h,f,i,d="",s=0;s<t.length;)a=t.charCodeAt(s++),o=t.charCodeAt(s++),u=t.charCodeAt(s++),15==s&&(d+="A",d+=e,d+=n),c=a>>2,h=(3&a)<<4|o>>4,f=(15&o)<<2|u>>6,i=63&u,isNaN(o)?f=i=64:isNaN(u)&&(i=64),d=d+r._urlStr.charAt(c)+r._urlStr.charAt(h)+r._urlStr.charAt(f)+r._urlStr.charAt(i);return d},r.$xx=function(t,e,n,a,o){var o=o||parseInt(+new Date/1e3);return r.ha(t+e+o+r._Seed+n+"heherand")},r.$xxzb=function(t,e,n,a,o){var o=o||parseInt(+new Date/1e3);return r.ha(e+"tmp123"+t+"#$$&c2*KA"+o)},r.$xxf=function(t,e,n,a,o){var o=o||parseInt(+new Date/1e3);return r.ha(t+"ques"+o+"*&%$(SD!L}"+e+n)},r.$xxzbf=function(t,e,n,a,o){var o=o||parseInt(+new Date/1e3);return r.ha(e+o+"*#016"+t+"zput")},module.exports=r; 
 			}); 
		define("src/lib/es6-promise.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";var t="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(t){return typeof t}:function(t){return t&&"function"==typeof Symbol&&t.constructor===Symbol&&t!==Symbol.prototype?"symbol":typeof t};!function(e,n){"object"===("undefined"==typeof exports?"undefined":t(exports))&&"undefined"!=typeof module?module.exports=n():"function"==typeof define&&define.amd?define(n):e.ES6Promise=n()}(void 0,function(){function e(e){return"function"==typeof e||"object"===(void 0===e?"undefined":t(e))&&null!==e}function n(t){return"function"==typeof t}function r(){return void 0!==D?function(){D(i)}:o()}function o(){var t=setTimeout;return function(){return t(i,1)}}function i(){for(var t=0;t<F;t+=2)(0,G[t])(G[t+1]),G[t]=void 0,G[t+1]=void 0;F=0}function s(t,e){var n=arguments,r=this,o=new this.constructor(c);void 0===o[I]&&x(o);var i=r._state;return i?function(){var t=n[i-1];L(function(){return j(i,o,t,r._result)})}():w(r,o,t,e),o}function u(e){var n=this;if(e&&"object"===(void 0===e?"undefined":t(e))&&e.constructor===n)return e;var r=new n(c);return _(r,e),r}function c(){}function f(){return new TypeError("You cannot resolve a promise with itself")}function a(){return new TypeError("A promises callback cannot return that same promise.")}function l(t){try{return t.then}catch(t){return V.error=t,V}}function h(t,e,n,r){try{t.call(e,n,r)}catch(t){return t}}function p(t,e,n){L(function(t){var r=!1,o=h(n,e,function(n){r||(r=!0,e!==n?_(t,n):m(t,n))},function(e){r||(r=!0,b(t,e))},"Settle: "+(t._label||" unknown promise"));!r&&o&&(r=!0,b(t,o))},t)}function d(t,e){e._state===Q?m(t,e._result):e._state===R?b(t,e._result):w(e,void 0,function(e){return _(t,e)},function(e){return b(t,e)})}function v(t,e,r){e.constructor===t.constructor&&r===s&&e.constructor.resolve===u?d(t,e):r===V?b(t,V.error):void 0===r?m(t,e):n(r)?p(t,e,r):m(t,e)}function _(t,n){t===n?b(t,f()):e(n)?v(t,n,l(n)):m(t,n)}function y(t){t._onerror&&t._onerror(t._result),g(t)}function m(t,e){t._state===J&&(t._result=e,t._state=Q,0!==t._subscribers.length&&L(g,t))}function b(t,e){t._state===J&&(t._state=R,t._result=e,L(y,t))}function w(t,e,n,r){var o=t._subscribers,i=o.length;t._onerror=null,o[i]=e,o[i+Q]=n,o[i+R]=r,0===i&&t._state&&L(g,t)}function g(t){var e=t._subscribers,n=t._state;if(0!==e.length){for(var r=void 0,o=void 0,i=t._result,s=0;s<e.length;s+=3)r=e[s],o=e[s+n],r?j(n,r,o,i):o(i);t._subscribers.length=0}}function A(){this.error=null}function S(t,e){try{return t(e)}catch(t){return X.error=t,X}}function j(t,e,r,o){var i=n(r),s=void 0,u=void 0,c=void 0,f=void 0;if(i){if((s=S(r,o))===X?(f=!0,u=s.error,s=null):c=!0,e===s)return void b(e,a())}else s=o,c=!0;e._state!==J||(i&&c?_(e,s):f?b(e,u):t===Q?m(e,s):t===R&&b(e,s))}function E(t,e){try{e(function(e){_(t,e)},function(e){b(t,e)})}catch(e){b(t,e)}}function T(){return Z++}function x(t){t[I]=Z++,t._state=void 0,t._result=void 0,t._subscribers=[]}function M(t,e){this._instanceConstructor=t,this.promise=new t(c),this.promise[I]||x(this.promise),q(e)?(this._input=e,this.length=e.length,this._remaining=e.length,this._result=new Array(this.length),0===this.length?m(this.promise,this._result):(this.length=this.length||0,this._enumerate(),0===this._remaining&&m(this.promise,this._result))):b(this.promise,P())}function P(){return new Error("Array Methods must be provided an Array")}function C(){throw new TypeError("You must pass a resolver function as the first argument to the promise constructor")}function O(){throw new TypeError("Failed to construct 'Promise': Please use the 'new' operator, this object constructor cannot be called as a function.")}function k(t){this[I]=T(),this._result=this._state=void 0,this._subscribers=[],c!==t&&("function"!=typeof t&&C(),this instanceof k?E(this,t):O())}var Y=void 0,q=Y=Array.isArray?Array.isArray:function(t){return"[object Array]"===Object.prototype.toString.call(t)},F=0,D=void 0,K=void 0,L=function(t,e){G[F]=t,G[F+1]=e,2===(F+=2)&&(K?K(i):H())},N="undefined"!=typeof window?window:void 0,U=N||{},W=U.MutationObserver||U.WebKitMutationObserver,z="undefined"==typeof self&&"undefined"!=typeof process&&"[object process]"==={}.toString.call(process),B="undefined"!=typeof Uint8ClampedArray&&"undefined"!=typeof importScripts&&"undefined"!=typeof MessageChannel,G=new Array(1e3),H=void 0;H=z?function(){return process.nextTick(i)}:W?function(){var t=0,e=new W(i),n=document.createTextNode("");return e.observe(n,{characterData:!0}),function(){n.data=t=++t%2}}():B?function(){var t=new MessageChannel;return t.port1.onmessage=i,function(){return t.port2.postMessage(0)}}():void 0===N&&"function"==typeof require?function(){try{var t=require("vertx");return D=t.runOnLoop||t.runOnContext,r()}catch(t){return o()}}():o();var I=Math.random().toString(36).substring(16),J=void 0,Q=1,R=2,V=new A,X=new A,Z=0;return M.prototype._enumerate=function(){for(var t=this.length,e=this._input,n=0;this._state===J&&n<t;n++)this._eachEntry(e[n],n)},M.prototype._eachEntry=function(t,e){var n=this._instanceConstructor,r=n.resolve;if(r===u){var o=l(t);if(o===s&&t._state!==J)this._settledAt(t._state,e,t._result);else if("function"!=typeof o)this._remaining--,this._result[e]=t;else if(n===k){var i=new n(c);v(i,t,o),this._willSettleAt(i,e)}else this._willSettleAt(new n(function(e){return e(t)}),e)}else this._willSettleAt(r(t),e)},M.prototype._settledAt=function(t,e,n){var r=this.promise;r._state===J&&(this._remaining--,t===R?b(r,n):this._result[e]=n),0===this._remaining&&m(r,this._result)},M.prototype._willSettleAt=function(t,e){var n=this;w(t,void 0,function(t){return n._settledAt(Q,e,t)},function(t){return n._settledAt(R,e,t)})},k.all=function(t){return new M(this,t).promise},k.race=function(t){var e=this;return new e(q(t)?function(n,r){for(var o=t.length,i=0;i<o;i++)e.resolve(t[i]).then(n,r)}:function(t,e){return e(new TypeError("You must pass an array to race."))})},k.resolve=u,k.reject=function(t){var e=new this(c);return b(e,t),e},k._setScheduler=function(t){K=t},k._setAsap=function(t){L=t},k._asap=L,k.prototype={constructor:k,then:s,catch:function(t){return this.then(null,t)}},k.polyfill=function(){var t=void 0;if("undefined"!=typeof global)t=global;else if("undefined"!=typeof self)t=self;else try{t=Function("return this")()}catch(t){throw new Error("polyfill failed because global object is unavailable in this environment")}var e=t.Promise;if(e){var n=null;try{n=Object.prototype.toString.call(e.resolve())}catch(t){}if("[object Promise]"===n&&!e.cast)return}t.Promise=k},k.Promise=k,k.defer=function(){var t={};return t.promise=new k(function(e,n){t.resolve=e,t.reject=n}),t},k}); 
 			}); 
		define("src/lib/message.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";function t(){this._evtObjs={},this._outdatedMsgs={}}function e(){}t.prototype.on=function(t,e,s){this._evtObjs[t]||(this._evtObjs[t]=[]),this._evtObjs[t].push({handler:e,once:s});var n=this;return function(){n.off(t,e)}},t.prototype.wait=function(t,s){return this._outdatedMsgs[t]?(s.apply(null,this._outdatedMsgs[t]),e):this.on(t,s,!0)},t.prototype.off=function(t,e){var s=this;return(t?[t]:Object.keys(this._evtObjs)).forEach(function(t){if(e){var n=[];(s._evtObjs[t]||[]).forEach(function(t){t.handler!==e&&n.push(t)}),s._evtObjs[t]=n}else s._evtObjs[t]=[]}),this},t.prototype.emit=function(t){var e=Array.prototype.slice.call(arguments,1);this._outdatedMsgs[t]=e,(this._evtObjs[t]||[]).forEach(function(t){if(!t.once||!t.called){t.called=!0;try{t.handler&&t.handler.apply(null,e)}catch(t){console.error(t.stack||t.message||t)}}})},t.prototype.emitAsync=function(){var t=arguments,e=this;setTimeout(function(){e.emit.apply(e,t)},0)},t.prototype.assign=function(t){var e=this;["on","off","wait","emit","emitAsync"].forEach(function(s){var n=e[s];t[s]=function(){return n.apply(e,arguments)}})},(new t).assign(t),module.exports=t; 
 			}); 
		define("src/lib/parse-body.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";module.exports=function(t){if("string"!=typeof t)return t;t&&(t=t.trim()),t&&/^(data|QZOutputJson)=/.test(t)&&(t=t.replace(/^(data|QZOutputJson)=/,"").replace(/;?$/,""));try{return JSON.parse(t)}catch(t){throw new Error("parse jsonp body failed")}}; 
 			}); 
		define("src/lib/request.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";var e=require("./parse-body"),t=require("./es6-promise"),s=module.exports={request:function(t){return t.success=function(t){return t=t||function(){},function(s){if(console.log("wx.request success"),s&&200==s.statusCode)try{s.data=e(s.data)}catch(e){}t(s)}}(t.success),console.log("wx.request",t.url),wx.request(t)},get:function(e,u){return u=u||{},new t(function(t,n){s.request({url:e,data:u.data||{},header:u.header||{},method:"GET",success:function(e){t(e)},fail:function(e){n(e)},needlogin:u.needlogin})})}}; 
 			}); 
		define("src/module/cache.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";module.exports={set:function(e,t,a){wx.setStorageSync("_cache_"+e,{expr:a||0,date:+new Date,data:t})},get:function(e){e="_cache_"+e;var t=wx.getStorageSync(e);return t?t.expr&&t.expr?new Date-(t.date+t.expr)<0?t.data:(wx.removeStorageSync(e),null):t.data:null},del:function(e){e="_cache_"+e,wx.removeStorageSync(e)}}; 
 			}); 
		define("src/module/log.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";var o="devtools"==wx.getSystemInfoSync().platform;module.exports=function(a){var n=[Math.floor(50*Math.random()+200),Math.floor(50*Math.random()+150),Math.floor(50*Math.random()+100)].sort(function(){return Math.random()-.5});return n="rgb("+n[0]+", "+n[1]+", "+n[2]+")",o?function(){var o=["%c【%s】%c "+a+" %c %s ","background: #ddd",new Date,"background: "+n,"background: #333;color: white"];console.log.apply(console,o.concat([].slice.call(arguments,0)))}:function(){var o=["【%s】 "+a+" %s ",new Date];console.log.apply(console,o.concat([].slice.call(arguments,0)))}}; 
 			}); 
		define("src/module/reporter/index.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";var e=new(require("../../lib/message")),r=require("./report-queue");r.onReport=function(e){o.emit("report",e)};var t=require("./report-cache"),o={};o.any=function(e){r.push(e)},o.saveState=function(){console.log("reporter.js","saveState"),o.emit("_save")},o.restoreState=function(){console.log("reporter.js","restoreState"),o.emit("_restore")},o.checkState=function(){console.log("reporter.js","checkState"),t.getAll().forEach(r.push),t.del()},o.reportCache=t,e.assign(o),module.exports=o; 
 			}); 
		define("src/module/reporter/report-cache.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";var t=require("../cache"),e=t.get("tvp_report")||{};exports.get=function(t){return e[t]},exports.set=function(r,n){e[r]=n,t.set("tvp_report",e)},exports.del=function(r){r?delete e[r]:e={},t.set("tvp_report",e)},exports.getAll=function(){return Object.keys(e).map(function(t){return e[t]})}; 
 			}); 
		define("src/module/reporter/report-queue.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";var e=require("../../../lib-inject").request;module.exports=function(t){function n(t){~t.reportUrl.indexOf("btrace.qq.com")?e(t.reportUrl).then(function(){r.release()}).catch(function(){r.onReport&&r.onReport(t)}):r.onReport&&r.onReport(t),c=setTimeout(function(){r.release()},o)}var r,o=3e3,u=!1,i=[],c=null;return r={release:function(e){u&&e&&e!=u||(u=!1,clearTimeout(c),i.length&&n(i.shift()))},push:function(e){u?i.push(e):(u=e,n(e))}}}(); 
 			}); 
		define("src/util/platform-config.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";module.exports={APP_NAME:{v4169:"plugin",v4160:"sport.qq.com",v4144:"pvp.qq.com"},APP_PLATFORM:{v4169:"4210801",v4160:"40801",v4144:"3100801"}}; 
 			}); 
		define("src/video.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";var e=require("./module/reporter/index"),t=require("./controller-video/index"),o=require("./controller-live/index"),n=require("./util/platform-config").APP_NAME,r=module.exports=function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{},r=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{},i=r.from,a=void 0===r.autoplay||r.autoplay,d=r.defn||"",p=void 0!==r.noad&&!!r.noad,f="function"==typeof r.getReportParam?r.getReportParam:"function"==typeof r.getLoginData?function(e){r.getLoginData(function(t,o){o.hc_openid=o.openid,delete o.openid,e(t,o)})}:function(e){return e()},u=e.vid;"string"==typeof e&&(u=e);var c,l=e.cid||"",s=e.sid,v=e.pid;return c=u?t({vid:u,cid:l,from:i,defn:d,noad:p},{getReportParam:function(e){f(function(t,o){o&&(o.appname=n[i]),e(t,o)})}}):o({sid:s,pid:v,from:i,defn:d,noad:p},{getReportParam:function(e){f(function(t,o){o&&(o.appname=n[i]),e(t,o)})}}),a&&c.start(),c};r.on=function(t){"report"==t&&(e.off("report"),e.on.apply(e,arguments))},r.release=e.release,r.saveState=e.saveState,r.restoreState=e.restoreState,r.checkState=e.checkState; 
 			}); 
		global.__wxAppCurrentFile__ = 'plugin-private://wxa75efa648b60994b/component/live/live.js';	define("component/live/live.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";var t=require("../../index"),e=require("../txv-context"),i=require("../../src/module/log")("txv-live-component");Component({properties:{pid:{type:String,value:"",observer:"onVideoChange"},sid:{type:String,value:"",observer:"onVideoChange"},playerid:{type:String,value:""},autoplay:{type:Boolean,value:!1}},data:{tvpUrl:"",tvpIsAd:!1,tvpState:"",tvpVideoError:""},attached:function(){var t=this;if(this.videoContext=wx.createVideoContext("tvp",this),i("attached",this.data),!this.data.playerid)throw new Error("需要为txv-live组件指定一个playerid");if(!this.data.sid||!this.data.pid)throw new Error("需要为txv-live组件传入sid和pid，否则怎么播放视频呢");var o={};["play","pause","seek","playbackRate","requestFullScreen","exitFullScreen"].forEach(function(e){o[e]=function(){for(var i=arguments.length,o=Array(i),n=0;n<i;n++)o[n]=arguments[n];t.videoContext[e].apply(t.videoContext,o)}}),e.txvAttached(this.data.playerid,o)},detached:function(){i("detached",this.data),e.txvDetached(this.data.playerid)},methods:{onVideoChange:function(){var e=this;this.data.sid&&this.data.pid&&(i("onVideoChange",this.data.sid,this.data.pid),this.video=t({sid:this.data.sid,pid:this.data.pid},{from:"v4169"}),this.video.on("contentchange",function(t){t.currentContent&&e.setData({tvpUrl:t.currentContent.url})}),this.video.on("error",function(t){e.triggerEvent("error",t)}))},__onTvpPlay:function(){this.video&&this.video.onContentPlay()},__onTvpPause:function(){this.video&&this.video.onContentPause()},__onTvpEnded:function(){this.video&&this.video.onContentEnd()},__onTvpTimeupdate:function(t){this.triggerEvent("timeupdate",t.detail),this.video&&this.video.onContentTimeupdate(null,t)},__onTvpError:function(){this.video&&this.video.onContentError()}}}); 
 			}); 	require("component/live/live.js");
 		global.__wxAppCurrentFile__ = 'plugin-private://wxa75efa648b60994b/component/noad-video/noad-video.js';	define("component/noad-video/noad-video.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";var e=require("../../index"),t=require("../txv-context"),o=require("../../src/module/log")("txv-video-component"),a=wx.getStorageSync("tvp_openid");a||(a=["_",Math.random().toString(16).slice(2),Math.random().toString(16).slice(2),Math.random().toString(16).slice(2)].join("").slice(0,28),wx.setStorageSync("tvp_openid",a)),Component({properties:{vid:{type:String,value:"",observer:"onVideoChange"},playerid:{type:String,value:""},autoplay:{type:Boolean,value:!1},objectFit:{type:String,value:"contain"},poster:{type:String,value:""},showProgress:{type:Boolean,value:!0},controls:{type:Boolean,value:!0},initialTime:{type:Number,value:0},showFullscreenBtn:{type:Boolean,value:!0},showPlayBtn:{type:Boolean,value:!0},showCenterPlayBtn:{type:Boolean,value:!0},enableProgressGesture:{type:Boolean,value:!0},pageGesture:{type:Boolean,value:!1},muted:{type:Boolean,value:!1},loop:{type:Boolean,value:!1}},data:{progressBaseTime:0,progressSkipTime:0,progressTime:0,progressDuration:0,tvpUrl:"",tvpIsAd:!1,tvpState:"",tvpVideoError:"",reportUrl:""},attached:function(){var a=this;if(this.videoContext=wx.createVideoContext("tvp",this),o("attached",this.data),!this.data.playerid)throw new Error("需要为txv-video组件指定一个playerid");if(!this.data.vid)throw new Error("需要为txv-video组件传入一个vid，否则怎么播放视频呢");var n={};["play","pause","seek","playbackRate","requestFullScreen","exitFullScreen"].forEach(function(e){n[e]=function(){for(var t=arguments.length,o=Array(t),n=0;n<t;n++)o[n]=arguments[n];a.videoContext[e].apply(a.videoContext,o)}}),t.txvAttached(this.data.playerid,n),e.on("report",function(e){a.setData({reportUrl:e.reportUrl.replace("https","http")})})},moved:function(){},detached:function(){o("detached",this.data),t.txvDetached(this.data.playerid)},methods:{skipAd:function(){this.video.onContentSkip(0)},onVideoChange:function(){var t=this;if(this.data.vid){o("onVideoChange",this.data.vid);var n=this.video=e(this.data.vid,{from:"v4169",noad:!0,getReportParam:function(e){e(null,{hc_openid:a,hc_vuserid:a})}});n.on("error",function(e){t.triggerEvent("error",e)}),n.on("statechange",function(e,a,n){if(o("onstatechange",e,a),t.triggerEvent("statechange",{newstate:e,oldstate:a}),e!=t.data.tvpState){switch(console.info("playerstatechange "+t.data.tvpState+" => "+e),t.data.tvpState){case"stop":break;case"error":return}switch(t.setData({tvpState:e}),e){case"playing":t.videoContext.play();break;case"error":t.setData({tvpVideoError:n||""});case"pause":case"stop":break;case"ended":t.videoContext.pause()}}}),n.on("contentchange",function(e){if(o("contentchange",e),e.currentContent){var a={};a.progressTime=0,e.progress?(a.progressDuration=e.progress.duration,a.progressBaseTime=e.progress.time,a.progressSkipTime=e.progress.skipable):(a.progressDuration=0,a.progressBaseTime=0,a.progressSkipTime=0),console.log("contentchange",e),a.tvpUrl=e.currentContent.url,a.tvpIsAd=!!e.currentContent.isad,t.setData(a)}else o("first content change",e)})}},__onTvpPlay:function(){this.video&&this.video.onContentPlay()},__onTvpPause:function(){this.video&&this.video.onContentPause()},__onTvpEnded:function(){this.video&&this.video.onContentEnd()},__onTvpTimeupdate:function(e){this.triggerEvent("timeupdate",e.detail);try{this.setData({progressTime:Math.floor(e.detail.currentTime)}),this.video&&this.video.onContentTimeupdate(null,e)}catch(e){}},__onTvpError:function(){this.video&&this.video.onContentError()}}}); 
 			}); 	require("component/noad-video/noad-video.js");
 		global.__wxAppCurrentFile__ = 'plugin-private://wxa75efa648b60994b/component/video/video.js';	define("component/video/video.js", function(require, module, exports, window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){ 			"use strict";			
"use strict";var e=require("../../index"),t=require("../txv-context"),o=require("../../src/module/log")("txv-video-component"),a=wx.getStorageSync("tvp_openid");a||(a=["_",Math.random().toString(16).slice(2),Math.random().toString(16).slice(2),Math.random().toString(16).slice(2)].join("").slice(0,28),wx.setStorageSync("tvp_openid",a)),Component({properties:{vid:{type:String,value:"",observer:"onVideoChange"},playerid:{type:String,value:""},autoplay:{type:Boolean,value:!1},objectFit:{type:String,value:"contain"},poster:{type:String,value:""},showProgress:{type:Boolean,value:!0},controls:{type:Boolean,value:!0},initialTime:{type:Number,value:0},showFullscreenBtn:{type:Boolean,value:!0},showPlayBtn:{type:Boolean,value:!0},showCenterPlayBtn:{type:Boolean,value:!0},enableProgressGesture:{type:Boolean,value:!0},pageGesture:{type:Boolean,value:!1},muted:{type:Boolean,value:!1},loop:{type:Boolean,value:!1}},data:{progressBaseTime:0,progressSkipTime:0,progressTime:0,progressDuration:0,tvpUrl:"",tvpIsAd:!1,tvpState:"",tvpVideoError:"",reportUrl:""},attached:function(){var a=this;if(this.videoContext=wx.createVideoContext("tvp",this),o("attached",this.data),!this.data.playerid)throw new Error("需要为txv-video组件指定一个playerid");if(!this.data.vid)throw new Error("需要为txv-video组件传入一个vid，否则怎么播放视频呢");var n={};["play","pause","seek","playbackRate","requestFullScreen","exitFullScreen"].forEach(function(e){n[e]=function(){for(var t=arguments.length,o=Array(t),n=0;n<t;n++)o[n]=arguments[n];a.videoContext[e].apply(a.videoContext,o)}}),t.txvAttached(this.data.playerid,n),e.on("report",function(e){a.setData({reportUrl:e.reportUrl.replace("https","http")})})},moved:function(){},detached:function(){o("detached",this.data),t.txvDetached(this.data.playerid)},methods:{skipAd:function(){this.video.onContentSkip(0)},onVideoChange:function(){var t=this;if(this.data.vid){o("onVideoChange",this.data.vid);var n=this.video=e(this.data.vid,{from:"v4169",getReportParam:function(e){e(null,{hc_openid:a,hc_vuserid:a})}});n.on("error",function(e){t.triggerEvent("error",e)}),n.on("statechange",function(e,a,n){if(o("onstatechange",e,a),t.triggerEvent("statechange",{newstate:e,oldstate:a}),e!=t.data.tvpState){switch(console.info("playerstatechange "+t.data.tvpState+" => "+e),t.data.tvpState){case"stop":break;case"error":return}switch(t.setData({tvpState:e}),e){case"playing":t.videoContext.play();break;case"error":t.setData({tvpVideoError:n||""});case"pause":case"stop":break;case"ended":t.videoContext.pause()}}}),n.on("contentchange",function(e){if(o("contentchange",e),e.currentContent){var a={};a.progressTime=0,e.progress?(a.progressDuration=e.progress.duration,a.progressBaseTime=e.progress.time,a.progressSkipTime=e.progress.skipable):(a.progressDuration=0,a.progressBaseTime=0,a.progressSkipTime=0),console.log("contentchange",e),a.tvpUrl=e.currentContent.url,a.tvpIsAd=!!e.currentContent.isad,t.setData(a)}else o("first content change",e)})}},__onTvpPlay:function(){this.video&&this.video.onContentPlay()},__onTvpPause:function(){this.video&&this.video.onContentPause()},__onTvpEnded:function(){this.video&&this.video.onContentEnd()},__onTvpTimeupdate:function(e){this.triggerEvent("timeupdate",e.detail);try{this.setData({progressTime:Math.floor(e.detail.currentTime)}),this.video&&this.video.onContentTimeupdate(null,e)}catch(e){}},__onTvpError:function(){this.video&&this.video.onContentError()}}}); 
 			}); 	require("component/video/video.js");
 	
				global.publishDomainComponents({
			"plugin://wxa75efa648b60994b/video":"plugin-private://wxa75efa648b60994b/component/video/video","plugin://wxa75efa648b60994b/noad-video":"plugin-private://wxa75efa648b60994b/component/noad-video/noad-video","plugin://wxa75efa648b60994b/live":"plugin-private://wxa75efa648b60994b/component/live/live"
	})
				module.exports = function() {
		return require('component/txv-context.js')
	}
			});
	requirePlugin("plugin://wxa75efa648b60994b");
/*v0.5vv_20200413_syb_scopedata*/global.__wcc_version__='v0.5vv_20200413_syb_scopedata';global.__wcc_version_info__={"customComponents":true,"fixZeroRpx":true,"propValueDeepCopy":false};
var $gwxc
var $gaic={}
$gwx=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx || [];
__WXML_GLOBAL__.ops_set.$gwx=z;
__WXML_GLOBAL__.ops_init.$gwx=true;
var nv_require=function(){var nnm={};var nom={};return function(n){if(n[0]==='p'&&n[1]==='_'&&f_[n.slice(2)])return f_[n.slice(2)];return function(){if(!nnm[n]) return undefined;try{if(!nom[n])nom[n]=nnm[n]();return nom[n];}catch(e){e.message=e.message.replace(/nv_/g,'');var tmp = e.stack.substring(0,e.stack.lastIndexOf(n));e.stack = tmp.substring(0,tmp.lastIndexOf('\n'));e.stack = e.stack.replace(/\snv_/g,' ');e.stack = $gstack(e.stack);e.stack += '\n    at ' + n.substring(2);console.error(e);}
}}}()
var x=[];if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||true)$gwx();;__wxRoute = undefined;__wxRouteBegin = undefined;__wxAppCurrentFile__=undefined;define("@babel/runtime/helpers/arrayLikeToArray.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
function _arrayLikeToArray(r,a){(null==a||a>r.length)&&(a=r.length);for(var e=0,n=new Array(a);e<a;e++)n[e]=r[e];return n}module.exports=_arrayLikeToArray;
},{isPage:false,isComponent:false,currentFile:'@babel/runtime/helpers/arrayLikeToArray.js'});;__wxRoute = undefined;__wxRouteBegin = undefined;__wxAppCurrentFile__=undefined;define("@babel/runtime/helpers/arrayWithHoles.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
function _arrayWithHoles(r){if(Array.isArray(r))return r}module.exports=_arrayWithHoles;
},{isPage:false,isComponent:false,currentFile:'@babel/runtime/helpers/arrayWithHoles.js'});;__wxRoute = undefined;__wxRouteBegin = undefined;__wxAppCurrentFile__=undefined;define("@babel/runtime/helpers/defineProperty.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
function _defineProperty(e,r,n){return r in e?Object.defineProperty(e,r,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[r]=n,e}module.exports=_defineProperty;
},{isPage:false,isComponent:false,currentFile:'@babel/runtime/helpers/defineProperty.js'});;__wxRoute = undefined;__wxRouteBegin = undefined;__wxAppCurrentFile__=undefined;define("@babel/runtime/helpers/iterableToArray.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
function _iterableToArray(r){if("undefined"!=typeof Symbol&&Symbol.iterator in Object(r))return Array.from(r)}module.exports=_iterableToArray;
},{isPage:false,isComponent:false,currentFile:'@babel/runtime/helpers/iterableToArray.js'});;__wxRoute = undefined;__wxRouteBegin = undefined;__wxAppCurrentFile__=undefined;define("@babel/runtime/helpers/nonIterableRest.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
function _nonIterableRest(){throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}module.exports=_nonIterableRest;
},{isPage:false,isComponent:false,currentFile:'@babel/runtime/helpers/nonIterableRest.js'});;__wxRoute = undefined;__wxRouteBegin = undefined;__wxAppCurrentFile__=undefined;define("@babel/runtime/helpers/toArray.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
var arrayWithHoles=require("./arrayWithHoles"),iterableToArray=require("./iterableToArray"),unsupportedIterableToArray=require("./unsupportedIterableToArray"),nonIterableRest=require("./nonIterableRest");function _toArray(r){return arrayWithHoles(r)||iterableToArray(r)||unsupportedIterableToArray(r)||nonIterableRest()}module.exports=_toArray;
},{isPage:false,isComponent:false,currentFile:'@babel/runtime/helpers/toArray.js'});;__wxRoute = undefined;__wxRouteBegin = undefined;__wxAppCurrentFile__=undefined;define("@babel/runtime/helpers/unsupportedIterableToArray.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
var arrayLikeToArray=require("./arrayLikeToArray");function _unsupportedIterableToArray(r,e){if(r){if("string"==typeof r)return arrayLikeToArray(r,e);var t=Object.prototype.toString.call(r).slice(8,-1);return"Object"===t&&r.constructor&&(t=r.constructor.name),"Map"===t||"Set"===t?Array.from(r):"Arguments"===t||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t)?arrayLikeToArray(r,e):void 0}}module.exports=_unsupportedIterableToArray;
},{isPage:false,isComponent:false,currentFile:'@babel/runtime/helpers/unsupportedIterableToArray.js'});;__wxRoute = undefined;__wxRouteBegin = undefined;__wxAppCurrentFile__=undefined;define("config.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var a="https://mini.kaililaw.com/eae/api/",t={appid:"wxed767ccdc8b08ef6",login:"".concat(a,"user/login"),tel:"".concat(a,"user/tel"),wxdl:"".concat(a,"user/wxdl"),reg:"".concat(a,"user/reg"),vcode:"".concat(a,"user/vcode"),verify:"".concat(a,"user/verify"),user:"".concat(a,"user/user"),logout:"".concat(a,"user/logout"),getExamListIndex:"".concat(a,"nntli/exam/getExamList"),getExamList:"".concat(a,"exam/getExamList"),beginExam:"".concat(a,"exam/beginExam"),addRecord:"".concat(a,"exam/addRecord"),getReport:"".concat(a,"exam/getReport"),allRecords:"".concat(a,"exam/allRecords"),recordReport:"".concat(a,"exam/recordReport"),examReview:"".concat(a,"exam/examReview"),restartExam:"".concat(a,"exam/restartExam"),banner:"".concat(a,"banner/banners"),allRank:"".concat(a,"statistics/allRank"),myRank:"".concat(a,"statistics/myRank"),zzjg:"".concat(a,"info/zzjg_zhiji"),getComp:"".concat(a,"voting/campaign/campaigns"),getCompDetail:"".concat(a,"voting/campaign/campaign"),getGroups:"".concat(a,"voting/campaign/groups"),getCalist:"".concat(a,"voting/candidate/candidates"),getCaDetail:"".concat(a,"voting/candidate/candidate"),getRank:"".concat(a,"voting/candidate/rank"),vote:"".concat(a,"voting/vote")};module.exports=t;
},{isPage:false,isComponent:false,currentFile:'config.js'});;__wxRoute = undefined;__wxRouteBegin = undefined;__wxAppCurrentFile__=undefined;define("http.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var t=require("config.js");module.exports={request:function(e,a,s,o,d,n){n&&wx.showLoading({title:"正在加载中..."}),wx.request({url:e,data:s,method:a,header:{Cookie:"sessionid="+wx.getStorageSync("sessionId")+";appid="+wx.getStorageSync("appid")},success:function(e){n&&wx.hideLoading(),200==e.statusCode||201==e.statusCode?o(e.data):401==e.statusCode?wx.navigateTo({url:"../login-default/login-default"}):402==e.statusCode?wx.login({success:function(e){wx.request({url:t.login,data:{code:e.code},method:"POST",success:function(t){null!=t.data.data&&(wx.setStorageSync("sessionId",t.data.data),wx.reLaunch({url:"../index/index"}))},fail:function(t){}})}}):444==e.statusCode?wx.showToast({title:"您的账号存在风险，已加入系统黑名单，请联系管理员处理",icon:"none",duration:3e3}):409==e.statusCode?d(e.data.msg):421==e.statusCode?d(e.data.data):500==e.statusCode&&wx.showToast({title:e.data.msg,icon:"none",duration:3e3})},fail:function(t){n&&wx.hideLoading(),d("连接服务器失败，请稍后重试")}})}};
},{isPage:false,isComponent:false,currentFile:'http.js'});;__wxRoute = undefined;__wxRouteBegin = undefined;__wxAppCurrentFile__=undefined;define("utils/util.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var e=function(e){return(e=e.toString())[1]?e:"0"+e};module.exports={formatTime:function(t){var g=t.getFullYear(),n=t.getMonth()+1,o=t.getDate(),r=t.getHours(),s=t.getMinutes(),u=t.getSeconds();return[g,n,o].map(e).join("/")+" "+[r,s,u].map(e).join(":")},dateFormat:function(e,t){(e=new Date(e)).setHours(e.getHours()-14);var g={"M+":e.getMonth()+1,"d+":e.getDate(),"H+":e.getHours(),"m+":e.getMinutes(),"s+":e.getSeconds(),"q+":Math.floor((e.getMonth()+3)/3),S:e.getMilliseconds()};for(var n in/(y+)/.test(t)&&(t=t.replace(RegExp.$1,(e.getFullYear()+"").substr(4-RegExp.$1.length))),g)new RegExp("("+n+")").test(t)&&(t=t.replace(RegExp.$1,1==RegExp.$1.length?g[n]:("00"+g[n]).substr((""+g[n]).length)));return t},formatDate:function(e){return(e=new Date(e)).getFullYear()+"-"+(e.getMonth()+1<10?"0"+(e.getMonth()+1):e.getMonth()+1)+"-"+(e.getDate()<10?"0"+e.getDate():e.getDate())+" "+(e.getHours()<10?"0"+e.getHours():e.getHours())+":"+(e.getMinutes()<10?"0"+e.getMinutes():e.getMinutes())+":"+(e.getSeconds()<10?"0"+e.getSeconds():e.getSeconds())}};
},{isPage:false,isComponent:false,currentFile:'utils/util.js'});;__wxRoute = undefined;__wxRouteBegin = undefined;__wxAppCurrentFile__=undefined;define("app.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var t=require("config.js"),e=(require("http.js"),wx.getUpdateManager());App({onLaunch:function(){var o=this;wx.setStorageSync("appid",t.appid),this.login(),wx.getSetting({success:function(t){wx.getUserProfile({success:function(t){wx.setStorageSync("userInfo",t.userInfo),o.globalData.userInfo=t.userInfo,o.userInfoReadyCallback&&o.userInfoReadyCallback(t)}})}}),wx.getSystemInfo({success:function(t){o.globalData.StatusBar=t.statusBarHeight;var e=wx.getMenuButtonBoundingClientRect();o.globalData.Custom=e;var a=e.bottom+e.top-t.statusBarHeight;o.globalData.CustomBar=a,a>75&&(o.globalData.tabbar_bottom="y")}}),e.onCheckForUpdate((function(t){})),e.onUpdateReady((function(){wx.showModal({title:"更新提示",content:"新版本已经准备好，是否重启应用？",success:function(t){t.confirm&&e.applyUpdate()}})})),e.onUpdateFailed((function(){}))},login:function(){wx.login({success:function(e){wx.showLoading({title:"正在加载中..."}),wx.request({url:t.login,data:{code:e.code},header:{Cookie:"sessionid="+wx.getStorageSync("sessionId")+";appid="+wx.getStorageSync("appid")},method:"POST",success:function(t){wx.hideLoading(),null!=t.data.data&&wx.setStorageSync("sessionId",t.data.data)},fail:function(t){wx.hideLoading()}})}})},globalData:{userInfo:null,userMsg:null,haslogin:!1,examMsg:null,question:{zero:!1,one:!1,two:!1,three:!1,four:!1},score:{zero:0,one:0,two:0,three:0,four:0,total:0},examTitle:null}});
},{isPage:false,isComponent:false,currentFile:'app.js'});require("app.js");