var t = require("config.js");

module.exports = {
    request: function(e, a, s, o, d, n) {
        n && wx.showLoading({
            title: "正在加载中..."
        }), wx.request({
            url: e,
            data: s,
            method: a,
            header: {
                Cookie: "sessionid=" + wx.getStorageSync("sessionId") + ";appid=" + wx.getStorageSync("appid")
            },
            success: function(e) {
                n && wx.hideLoading(), 200 == e.statusCode || 201 == e.statusCode ? o(e.data) : 401 == e.statusCode ? wx.navigateTo({
                    url: "../login-default/login-default"
                }) : 402 == e.statusCode ? wx.login({
                    success: function(e) {
                        wx.request({
                            url: t.login,
                            data: {
                                code: e.code
                            },
                            method: "POST",
                            success: function(t) {
                                null != t.data.data && (wx.setStorageSync("sessionId", t.data.data), wx.reLaunch({
                                    url: "../index/index"
                                }));
                            },
                            fail: function(t) {}
                        });
                    }
                }) : 444 == e.statusCode ? wx.showToast({
                    title: "您的账号存在风险，已加入系统黑名单，请联系管理员处理",
                    icon: "none",
                    duration: 3e3
                }) : 409 == e.statusCode ? d(e.data.msg) : 421 == e.statusCode ? d(e.data.data) : 500 == e.statusCode && wx.showToast({
                    title: e.data.msg,
                    icon: "none",
                    duration: 3e3
                });
            },
            fail: function(t) {
                n && wx.hideLoading(), d("连接服务器失败，请稍后重试");
            }
        });
    }
};