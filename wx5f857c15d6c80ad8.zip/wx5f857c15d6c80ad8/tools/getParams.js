!function() {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: !0
    });
    var r = exports.getParams = {
        get: function(r) {
            var t = r.indexOf("?");
            if (-1 != t) {
                var e = r.substring(t + 1, r.length);
                return this.params(e);
            }
        },
        params: function(r) {
            var t = {};
            return r.split("&").forEach(function(r) {
                var e = r.split("=");
                t[e[0]] = e[1];
            }), t;
        },
        jumpUrl: function(r) {
            var t = r.indexOf("?");
            return -1 != t ? r.substring(0, t) : r;
        },
        paramsStr: function(r) {
            var t = r.indexOf("?"), e = "";
            return -1 != t && (e = r.substring(t, r.length)), e;
        }
    };
    exports.getParams = r, exports.default = {
        getParams: r
    };
}();