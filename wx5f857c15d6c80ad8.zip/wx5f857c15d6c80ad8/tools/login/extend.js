!function() {
    "use strict";
    var e = require("./config.js").api;
    exports.getSystemConfig = function() {
        var r = null;
        return function(e) {
            return function() {
                var r = e.apply(this, arguments);
                return new Promise(function(e, t) {
                    return function n(u, o) {
                        try {
                            var a = r[u](o), i = a.value;
                        } catch (e) {
                            return void t(e);
                        }
                        if (!a.done) return Promise.resolve(i).then(function(e) {
                            n("next", e);
                        }, function(e) {
                            n("throw", e);
                        });
                        e(i);
                    }("next");
                });
            };
        }(regeneratorRuntime.mark(function t() {
            var n = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {
                reload: !1
            };
            return regeneratorRuntime.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (!r || n.reload) {
                        t.next = 2;
                        break;
                    }
                    return t.abrupt("return", r);

                  case 2:
                    return t.prev = 2, t.next = 5, e.getSystemConfig();

                  case 5:
                    r = t.sent, t.next = 12;
                    break;

                  case 8:
                    return t.prev = 8, t.t0 = t.catch(2), r = null, t.abrupt("return", Promise.reject(t.t0));

                  case 12:
                    return t.abrupt("return", r);

                  case 13:
                  case "end":
                    return t.stop();
                }
            }, t, void 0, [ [ 2, 8 ] ]);
        }));
    }();
}();