!function() {
    "use strict";
    function e(e) {
        var i = e.type, n = e.response;
        if (i && i in s) return s[i] = n, n;
    }
    var s = {
        isLoged: !1,
        isLogining: !1,
        needAuthorization: !1,
        needReload: !1,
        logedFail: !1,
        logedResult: null,
        handUp: !1,
        status: {
            success: "app/login/success",
            error: "app/login/error"
        },
        dispatch: e
    };
    module.exports = {
        data: s,
        dispatch: e
    };
}();