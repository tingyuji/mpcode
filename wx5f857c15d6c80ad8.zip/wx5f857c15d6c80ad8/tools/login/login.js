!function() {
    "use strict";
    function e(e) {
        return function() {
            var r = e.apply(this, arguments);
            return new Promise(function(e, t) {
                return function n(o, s) {
                    try {
                        var a = r[o](s), i = a.value;
                    } catch (e) {
                        return void t(e);
                    }
                    if (!a.done) return Promise.resolve(i).then(function(e) {
                        n("next", e);
                    }, function(e) {
                        n("throw", e);
                    });
                    e(i);
                }("next");
            });
        };
    }
    var r = function() {
        var r = e(regeneratorRuntime.mark(function e(r) {
            var t, o, i, c = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "";
            return regeneratorRuntime.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return t = {
                        fromKey: s.fromKey(),
                        scene: n.getLaunchOptionsSync().scene,
                        js_code: r,
                        clientVersion: s.getVersion(),
                        clientInfo: JSON.stringify(n.getClientInfo()),
                        launchInfo: JSON.stringify(n.getLaunchOptionsSync()),
                        from: c
                    }, o = null, e.prev = 2, e.next = 5, a.loginByCode(t, {
                        noTry: !0,
                        noToken: !0
                    });

                  case 5:
                    o = e.sent, e.next = 18;
                    break;

                  case 8:
                    if (e.prev = 8, e.t0 = e.catch(2), i = function(r) {
                        return Object.assign({
                            rcode: 1,
                            scode: 1
                        }, e.t0, r);
                    }, 3 !== e.t0.scode) {
                        e.next = 13;
                        break;
                    }
                    return e.abrupt("return", Promise.reject(i({
                        errMsg: "升级提示"
                    })));

                  case 13:
                    if (-2 !== e.t0.scode) {
                        e.next = 15;
                        break;
                    }
                    return e.abrupt("return", Promise.reject(i({
                        errMsg: "网络连接错误,请检查手机网络是否正常后重试！"
                    })));

                  case 15:
                    if (e.t0.data && e.t0.data.sessionKey) {
                        e.next = 17;
                        break;
                    }
                    return e.abrupt("return", Promise.reject(i({
                        errMsg: "登录超时,无key"
                    })));

                  case 17:
                    return e.abrupt("return", Promise.reject(e.t0));

                  case 18:
                    if (o.data.sessionKey) {
                        e.next = 20;
                        break;
                    }
                    return e.abrupt("return", Promise.reject({
                        errMsg: "登陆成功无sessionKey",
                        rcode: 1,
                        scode: 1
                    }));

                  case 20:
                    return e.abrupt("return", o);

                  case 21:
                  case "end":
                    return e.stop();
                }
            }, e, this, [ [ 2, 8 ] ]);
        }));
        return function(e) {
            return r.apply(this, arguments);
        };
    }(), t = function() {
        var r = e(regeneratorRuntime.mark(function e() {
            var r, t, n = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
            return regeneratorRuntime.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (n) {
                        e.next = 2;
                        break;
                    }
                    return e.abrupt("return", Promise.reject({
                        errMsg: "api.login.缺少sessionKey"
                    }));

                  case 2:
                    if (o && o.iv && o.encryptedData && o.userInfo) {
                        e.next = 4;
                        break;
                    }
                    return e.abrupt("return", Promise.reject({
                        errMsg: "api.login.用户信息缺失",
                        rcode: 1,
                        scode: 1
                    }));

                  case 4:
                    return r = {
                        sessionKey: n,
                        iv: o.iv,
                        encryptedData: o.encryptedData
                    }, t = null, e.prev = 6, e.next = 9, a.createUserInfo(r, {
                        noTry: !0,
                        noToken: !0
                    });

                  case 9:
                    t = e.sent, e.next = 17;
                    break;

                  case 12:
                    if (e.prev = 12, e.t0 = e.catch(6), -2 !== e.t0.scode) {
                        e.next = 16;
                        break;
                    }
                    return e.abrupt("return", Promise.reject({
                        errMsg: "网络连接错误,请检查手机网络是否正常后重试！",
                        rcode: 1,
                        scode: -2
                    }));

                  case 16:
                    return e.abrupt("return", Promise.reject({
                        errMsg: "api.login.登录失败",
                        rcode: 1,
                        scode: 1
                    }));

                  case 17:
                    if (t.data && t.data.token) {
                        e.next = 19;
                        break;
                    }
                    return e.abrupt("return", Promise.reject({
                        errMsg: "api.login.登录成功没有返回有效信息",
                        rcode: 1,
                        scode: 1
                    }));

                  case 19:
                    return e.abrupt("return", t);

                  case 20:
                  case "end":
                    return e.stop();
                }
            }, e, this, [ [ 6, 12 ] ]);
        }));
        return function() {
            return r.apply(this, arguments);
        };
    }(), n = require("./lib/wx.js"), o = require("./config.js"), s = o.config, a = o.api;
    module.exports = {
        createUserInfo: t,
        apiLoginByCode: r
    };
}();