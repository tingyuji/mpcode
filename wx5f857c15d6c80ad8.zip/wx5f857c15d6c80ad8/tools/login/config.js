!function() {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: !0
    });
    var e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
        return typeof e;
    } : function(e) {
        return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
    }, n = require("./../../fhd.config.js");
    if (!n.plugins || !n.plugins.login) throw new Error("fhdConfig.plugins.login 无配置");
    var t = n.plugins.login, o = require("./lib/fromKey.js"), r = t.event ? t.event : new (require("./lib/event.js"))(), i = {
        checkRequire: function(e, n, o) {
            return t[e] ? t[e](n, o) : Promise.reject({
                errMsg: "缺少配置" + e,
                rcode: 1,
                scode: 1
            });
        },
        loginByCode: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
            return this.checkRequire("loginByCode", e, n);
        },
        createUserInfo: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
            return this.checkRequire("createUserInfo", e, n);
        },
        getSystemConfig: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
            return this.checkRequire("getSystemConfig", e, n);
        }
    }, u = {
        getApp: function() {
            var e = null;
            return function() {
                if (e) return e;
                var n = null;
                try {
                    n = require("./../../npm/wepy/lib/wepy.js");
                } catch (n) {
                    return e = getApp();
                }
                if (!n.default || !n.default.$instance) throw new Error("wepy app 对象调整,请修改 login.config.getApp对象");
                return e = n.default.$instance;
            };
        }(),
        getLaunchOptionsSync: function() {
            return "function" == typeof wx.getLaunchOptionsSync ? wx.getLaunchOptionsSync() || {} : this.getLaunchInfo();
        },
        getToken: function() {
            return t.getToken ? t.getToken() || null : this.getApp().globalData.token || null;
        },
        getLaunchInfo: function() {
            return t.getLaunchInfo ? t.getLaunchInfo() || {} : this.getApp().globalData.launchInfo || {};
        },
        getVersion: function() {
            return t.getVersion ? t.getVersion() || "v1.0.0" : this.getApp().globalData.version || "v1.0.0";
        },
        getSessionKey: function() {
            if (t.getSessionKey) return t.getSessionKey();
            throw new Error("请配置getSessionKey");
        },
        isLoged: function() {
            if (!t.isLoged) throw new Error("plugins.login 缺少配置 isLoged");
            return t.isLoged() || !1;
        },
        authorizePhone: function() {
            if (!t.authorizePhone) throw new Error("plugins.login 缺少配置 authorizePhone");
            return t.authorizePhone() || !1;
        },
        reload: !0,
        fromKey: function() {
            var e = null;
            return function() {
                if (e) return e;
                var n = u.getLaunchOptionsSync();
                try {
                    n = o(n);
                } catch (n) {
                    return e = "", "";
                }
                return n && n.fromKey ? e = n.fromKey + "" + n.fromValue : (e = "", "");
            };
        }(),
        set: function(n) {
            var t = this;
            "object" === (void 0 === n ? "undefined" : e(n)) && Object.keys(n).forEach(function(e) {
                t[e] = n[e];
            });
        }
    };
    module.exports = {
        api: i,
        event: r,
        config: u
    }, exports.default = {
        api: i,
        event: r,
        config: u
    };
}();