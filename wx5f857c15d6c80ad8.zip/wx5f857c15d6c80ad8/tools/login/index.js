!function() {
    "use strict";
    function e(e) {
        return function() {
            var t = e.apply(this, arguments);
            return new Promise(function(e, r) {
                return function n(s, a) {
                    try {
                        var o = t[s](a), i = o.value;
                    } catch (e) {
                        return void r(e);
                    }
                    if (!o.done) return Promise.resolve(i).then(function(e) {
                        n("next", e);
                    }, function(e) {
                        n("throw", e);
                    });
                    e(i);
                }("next");
            });
        };
    }
    Object.defineProperty(exports, "__esModule", {
        value: !0
    });
    var t = function() {
        var n = e(regeneratorRuntime.mark(function e() {
            var n, c, u, p = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {
                reload: !1,
                quiet: !1,
                visitor: !1,
                hideLoading: !1,
                query: ""
            }, l = arguments[1];
            return regeneratorRuntime.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (p = Object.assign({
                        reload: !1,
                        quiet: !1,
                        visitor: !1,
                        hideLoading: !1,
                        query: ""
                    }, p), d.quiet = p.hideLoading, !o.data.isLogining || p.reload === s.reload) {
                        e.next = 4;
                        break;
                    }
                    return e.abrupt("return", h(p));

                  case 4:
                    if (!o.data.isLoged || p.reload === s.reload) {
                        e.next = 17;
                        break;
                    }
                    return n = null, e.prev = 6, e.next = 9, i.checkSession();

                  case 9:
                    n = e.sent, e.next = 15;
                    break;

                  case 12:
                    e.prev = 12, e.t0 = e.catch(6), n = e.t0;

                  case 15:
                    if (!n || 0 !== n.rcode) {
                        e.next = 17;
                        break;
                    }
                    return e.abrupt("return", o.data.logedResult);

                  case 17:
                    return o.dispatch({
                        type: "isLogining",
                        response: !0
                    }), o.dispatch({
                        type: "isLoged",
                        response: !1
                    }), o.dispatch({
                        type: "logedFail",
                        response: !1
                    }), o.dispatch({
                        type: "needReload",
                        response: !1
                    }), c = null, e.prev = 22, e.next = 25, r(p);

                  case 25:
                    c = e.sent, e.next = 35;
                    break;

                  case 28:
                    return e.prev = 28, e.t1 = e.catch(22), o.dispatch({
                        type: "isLogining",
                        response: !1
                    }), o.dispatch({
                        type: "handUp",
                        response: !1
                    }), u = h(Object.assign({
                        router: "app/login/loginPromise"
                    }, p)), e.t1 && 3 === e.t1.scode ? (o.dispatch({
                        type: "logedFail",
                        response: e.t1
                    }), a.emitAll(o.data.status.error, e.t1)) : (o.dispatch({
                        type: "needReload",
                        response: !0
                    }), a.emitAll("login/error/show")), e.abrupt("return", u);

                  case 35:
                    if (o.dispatch({
                        type: "isLogining",
                        response: !1
                    }), o.dispatch({
                        type: "logedFail",
                        response: !1
                    }), o.dispatch({
                        type: "isLoged",
                        response: !0
                    }), o.dispatch({
                        type: "needReload",
                        response: !1
                    }), o.dispatch({
                        type: "logedResult",
                        response: c
                    }), o.dispatch({
                        type: "handUp",
                        response: !1
                    }), !l || "function" != typeof l) {
                        e.next = 50;
                        break;
                    }
                    return e.prev = 42, e.next = 45, l(c);

                  case 45:
                    e.next = 50;
                    break;

                  case 47:
                    e.prev = 47, e.t2 = e.catch(42), console.error("extendLoginSuccessAfter 执行异常", e.t2);

                  case 50:
                    if ("function" != typeof t.extendLoginSuccessAfter) {
                        e.next = 61;
                        break;
                    }
                    return e.prev = 51, e.next = 54, t.extendLoginSuccessAfter(c);

                  case 54:
                    e.next = 59;
                    break;

                  case 56:
                    e.prev = 56, e.t3 = e.catch(51), console.error("login.extendLoginSuccessAfter 执行异常", e.t3);

                  case 59:
                    e.next = 62;
                    break;

                  case 61:
                    console.error("login.extendLoginSuccessAfter不是可执行的方法");

                  case 62:
                    return a.emitAllByReverse(o.data.status.success, c), e.abrupt("return", c);

                  case 64:
                  case "end":
                    return e.stop();
                }
            }, e, this, [ [ 6, 12 ], [ 22, 28 ], [ 42, 47 ], [ 51, 56 ] ]);
        }));
        return function() {
            return n.apply(this, arguments);
        };
    }(), r = function() {
        var t = e(regeneratorRuntime.mark(function e() {
            var t, r, n = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
            return regeneratorRuntime.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return d.show("正在登录"), t = null, e.prev = 2, e.next = 5, i.login();

                  case 5:
                    t = e.sent, e.next = 13;
                    break;

                  case 8:
                    return e.prev = 8, e.t0 = e.catch(2), e.next = 12, u.alert(e.t0.errMsg || "微信登陆故障:code");

                  case 12:
                    return e.abrupt("return", Promise.reject(e.t0));

                  case 13:
                    return r = null, e.prev = 14, e.next = 17, p.apiLoginByCode(t.code, n.query);

                  case 17:
                    r = e.sent, e.next = 28;
                    break;

                  case 20:
                    if (e.prev = 20, e.t1 = e.catch(14), 3 !== e.t1.scode) {
                        e.next = 24;
                        break;
                    }
                    return e.abrupt("return", Promise.reject(e.t1));

                  case 24:
                    if (e.t1.data && e.t1.data.sessionKey) {
                        e.next = 27;
                        break;
                    }
                    return e.next = 27, u.alert(e.t1.errMsg || "登陆失败,sessionKey");

                  case 27:
                    return e.abrupt("return", Promise.reject(e.t1));

                  case 28:
                    return e.abrupt("return", r);

                  case 29:
                  case "end":
                    return e.stop();
                }
            }, e, this, [ [ 2, 8 ], [ 14, 20 ] ]);
        }));
        return function() {
            return t.apply(this, arguments);
        };
    }(), n = require("./config.js"), s = n.config, a = n.event, o = require("./store.js"), i = require("./lib/wx.js"), c = require("./lib/actions.js"), u = c.model, d = c.load, p = require("./login.js"), l = require("./extend.js"), g = new (require("./lib/event.js"))(), f = 0, h = function(e) {
        var t = e.router, r = void 0 === t ? "" : t;
        return f++, r = (r || "app/login/waitPromise/" + f) + "/" + i.getRouter(), new Promise(function(e, t) {
            a.onoldest(o.data.status.success, function(t) {
                d.hide(), e(t), a.remove(o.data.status.success, r), a.remove(o.data.status.error, r);
            }, r), a.onoldest(o.data.status.error, function(e) {
                d.hide(), t(e), a.remove(o.data.status.success, r), a.remove(o.data.status.error, r);
            }, r);
        });
    };
    t.wait = function() {
        return o.data.isLogining ? h({}) : o.data.isLoged ? o.data.logedResult : o.data.logedFail ? Promise.reject(o.data.logedFail) : h({});
    }, t.handUp = function(e) {
        if (o.data.handUp) return e && e();
        f++, g.onoldest("handUp", function() {
            e && e();
        }, "handUpSelf/" + f);
    }, t.isLoged = function() {
        return o.data.isLoged;
    }, t.config = s, t.extendLoginSuccessAfter = e(regeneratorRuntime.mark(function e() {
        return regeneratorRuntime.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
              case "end":
                return e.stop();
            }
        }, e, this);
    })), t.getSystemConfig = l.getSystemConfig, wx.$login = t, module.exports = t, exports.default = t;
}();