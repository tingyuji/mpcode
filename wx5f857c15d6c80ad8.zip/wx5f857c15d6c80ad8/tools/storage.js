!function() {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: !0
    });
    var e = function(e) {
        return e && e.__esModule ? e : {
            default: e
        };
    }(require("./../npm/wepy/lib/wepy.js")), t = function() {
        function t(t, n) {
            return e.default.setStorage({
                key: t,
                data: n
            });
        }
        function n(t) {
            return new Promise(function(n, r) {
                e.default.getStorage({
                    key: t
                }).then(function(e) {
                    console.log("getStorage", e), n(e);
                }).catch(function(e) {
                    r(e);
                });
            });
        }
        return {
            set: function(e, n) {
                return t(e, n);
            },
            setSync: function(t, n) {
                return function(t, n) {
                    try {
                        e.default.setStorageSync(t, n);
                    } catch (t) {}
                }(t, n);
            },
            get: function(e) {
                var t = this;
                return new Promise(function() {
                    var r = function(e) {
                        return function() {
                            var t = e.apply(this, arguments);
                            return new Promise(function(e, n) {
                                return function r(o, u) {
                                    try {
                                        var c = t[o](u), a = c.value;
                                    } catch (e) {
                                        return void n(e);
                                    }
                                    if (!c.done) return Promise.resolve(a).then(function(e) {
                                        r("next", e);
                                    }, function(e) {
                                        r("throw", e);
                                    });
                                    e(a);
                                }("next");
                            });
                        };
                    }(regeneratorRuntime.mark(function r(o, u) {
                        var c;
                        return regeneratorRuntime.wrap(function(t) {
                            for (;;) switch (t.prev = t.next) {
                              case 0:
                                return t.prev = 0, t.next = 3, n(e);

                              case 3:
                                c = t.sent, o(c), t.next = 10;
                                break;

                              case 7:
                                t.prev = 7, t.t0 = t.catch(0), u(t.t0);

                              case 10:
                              case "end":
                                return t.stop();
                            }
                        }, r, t, [ [ 0, 7 ] ]);
                    }));
                    return function(e, t) {
                        return r.apply(this, arguments);
                    };
                }());
            },
            getSync: function(t) {
                return function(t) {
                    try {
                        return e.default.getStorageSync(t);
                    } catch (t) {
                        return console.error("getStorageSync", t), "";
                    }
                }(t);
            },
            getAll: function() {
                return e.default.getStorageInfo();
            },
            getAllSync: function() {
                return function() {
                    try {
                        return e.default.getStorageInfoSync();
                    } catch (e) {
                        return e;
                    }
                }();
            },
            remove: function(t) {
                return function(t) {
                    e.default.removeStorage({
                        key: t
                    }).then(function(e) {
                        console.log("remove storage", e);
                    });
                }(t);
            },
            removeSync: function(t) {
                return function(t) {
                    try {
                        e.default.removeStorageSync(t);
                    } catch (t) {
                        console.log("remove storage error", t);
                    }
                }(t);
            }
        };
    }();
    exports.default = t;
}();