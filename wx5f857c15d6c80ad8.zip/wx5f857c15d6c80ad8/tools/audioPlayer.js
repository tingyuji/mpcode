!function() {
    "use strict";
    function a(a) {
        return a && a.__esModule ? a : {
            default: a
        };
    }
    function t(a) {
        return function() {
            var t = a.apply(this, arguments);
            return new Promise(function(a, e) {
                return function n(i, u) {
                    try {
                        var l = t[i](u), o = l.value;
                    } catch (a) {
                        return void e(a);
                    }
                    if (!l.done) return Promise.resolve(o).then(function(a) {
                        n("next", a);
                    }, function(a) {
                        n("throw", a);
                    });
                    a(o);
                }("next");
            });
        };
    }
    Object.defineProperty(exports, "__esModule", {
        value: !0
    });
    var e = (a(require("./../api/index.js")), require("./../npm/wepy/lib/wepy.js")), n = a(e), i = a(require("./event.js")), u = a(require("./DataStatistics.js")), l = {
        bgAuMg: {},
        getBgAuMg: function() {
            this.bgAuMg = n.default.$instance.globalData.bgAudioData.bgAuMg;
        },
        initData: function(a) {
            n.default.$instance.globalData.bgAudioData.list = a.list, n.default.$instance.globalData.bgAudioData.currentIndex = a.index, 
            n.default.$instance.globalData.bgAudioData.productId = a.productId, n.default.$instance.globalData.bgAudioData.contentId = a.contentId, 
            n.default.$instance.globalData.bgAudioData.type = a.productType;
        },
        init: function(a) {
            this.bgAuMg.src && this.bgAuMg.src != a.list[a.index].location && n.default.$instance.globalData.bgAudioData.contentId && this.pause(), 
            this.initData(a), this.bgAuMg.src || this.getBgAuMg(), this.onPlay(), this.onSeekIng(), 
            this.onPause(), this.onPlayIngTime(), this.onEnded(), this.onStop(), this.bgAuMg.title = n.default.$instance.globalData.bgAudioData.list[n.default.$instance.globalData.bgAudioData.currentIndex].desc || n.default.$instance.globalData.bgAudioData.list[n.default.$instance.globalData.bgAudioData.currentIndex].title, 
            this.bgAuMg.src = n.default.$instance.globalData.bgAudioData.list[n.default.$instance.globalData.bgAudioData.currentIndex].location, 
            n.default.$instance.globalData.bgAudioData.list[n.default.$instance.globalData.bgAudioData.currentIndex].playProgress >= 0 && (this.bgAuMg.startTime = n.default.$instance.globalData.bgAudioData.list[n.default.$instance.globalData.bgAudioData.currentIndex].playProgress, 
            this.bgAuMg.play()), this.changeSpeed(1);
        },
        onPlay: function() {
            this.bgAuMg.onPlay(function() {
                console.log("---音乐开始播放---", n.default.$instance.globalData.bgAudioData.currentTime), 
                n.default.$instance.globalData.bgAudioData.contentId = n.default.$instance.globalData.bgAudioData.list[n.default.$instance.globalData.bgAudioData.currentIndex].id, 
                i.default.emitAll("onPlay");
            });
        },
        onPause: function() {
            this.bgAuMg.onPause(function() {
                console.log("---音乐暂停播放---", n.default.$instance.globalData.bgAudioData.currentTime), 
                n.default.$instance.globalData.bgAudioData.contentId = "", i.default.emitAll("onPause");
            });
        },
        onEnded: function() {
            var a = this;
            this.bgAuMg.onEnded(function() {
                console.log("---音乐播放结束---", n.default.$instance.globalData.bgAudioData.currentTime), 
                n.default.$instance.globalData.bgAudioData.list[n.default.$instance.globalData.bgAudioData.currentIndex].playProgress = 0, 
                26 != n.default.$instance.globalData.bgAudioData.type && a.saveTime(), n.default.$instance.globalData.bgAudioData.contentId = "", 
                i.default.emitAll("onEnded");
            });
        },
        onSeekIng: function() {
            this.bgAuMg.onSeeking(function(a) {
                console.log("----是否有跳转操作------", a);
            });
        },
        onPlayIngTime: function() {
            var a = this;
            this.bgAuMg.onTimeUpdate(function() {
                n.default.$instance.globalData.bgAudioData.currentTime = a.bgAuMg.currentTime, i.default.emitAll("onPlayIngTime");
            });
        },
        onStop: function() {
            var a = this;
            this.bgAuMg.onStop(t(regeneratorRuntime.mark(function t() {
                return regeneratorRuntime.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        n.default.$instance.globalData.bgAudioData.list[n.default.$instance.globalData.bgAudioData.currentIndex].playProgress = n.default.$instance.globalData.bgAudioData.currentTime, 
                        n.default.$instance.globalData.bgAudioData.list[n.default.$instance.globalData.bgAudioData.currentIndex].learningProgress < n.default.$instance.globalData.bgAudioData.list[n.default.$instance.globalData.bgAudioData.currentIndex].duration && (n.default.$instance.globalData.bgAudioData.list[n.default.$instance.globalData.bgAudioData.currentIndex].learningProgress = n.default.$instance.globalData.bgAudioData.currentTime), 
                        26 != n.default.$instance.globalData.bgAudioData.type && a.saveTime(), n.default.$instance.globalData.bgAudioData.contentId = "", 
                        i.default.emitAll("onShop");

                      case 5:
                      case "end":
                        return t.stop();
                    }
                }, t, a);
            })));
        },
        pause: function() {
            n.default.$instance.globalData.bgAudioData.list[n.default.$instance.globalData.bgAudioData.currentIndex].playProgress = n.default.$instance.globalData.bgAudioData.currentTime, 
            n.default.$instance.globalData.bgAudioData.list[n.default.$instance.globalData.bgAudioData.currentIndex].learningProgress < n.default.$instance.globalData.bgAudioData.list[n.default.$instance.globalData.bgAudioData.currentIndex].duration && (n.default.$instance.globalData.bgAudioData.list[n.default.$instance.globalData.bgAudioData.currentIndex].learningProgress = n.default.$instance.globalData.bgAudioData.currentTime), 
            26 != n.default.$instance.globalData.bgAudioData.type && this.saveTime(), this.bgAuMg.pause(), 
            n.default.$instance.globalData.bgAudioData.contentId = "";
        },
        seekPlay: function(a) {
            this.bgAuMg.seek(a), this.bgAuMg.play(), n.default.$instance.globalData.bgAudioData.contentId = n.default.$instance.globalData.bgAudioData.list[n.default.$instance.globalData.bgAudioData.currentIndex].id;
        },
        next: function() {
            var a = {
                list: n.default.$instance.globalData.bgAudioData.list,
                index: parseInt(n.default.$instance.globalData.bgAudioData.currentIndex) + 1,
                productId: n.default.$instance.globalData.bgAudioData.productId,
                contentId: n.default.$instance.globalData.bgAudioData.list[parseInt(n.default.$instance.globalData.bgAudioData.currentIndex) + 1].id
            };
            this.init(a);
        },
        pre: function() {
            var a = {
                list: n.default.$instance.globalData.bgAudioData.list,
                index: parseInt(n.default.$instance.globalData.bgAudioData.currentIndex) - 1,
                productId: n.default.$instance.globalData.bgAudioData.productId,
                contentId: n.default.$instance.globalData.bgAudioData.list[parseInt(n.default.$instance.globalData.bgAudioData.currentIndex) - 1].id
            };
            this.init(a);
        },
        changeSpeed: function(a) {
            this.bgAuMg.playbackRate = a, n.default.$instance.globalData.bgAudioData.speed = a;
        },
        stop: function() {
            this.bgAuMg.stop();
        },
        saveTime: function() {
            var a = t(regeneratorRuntime.mark(function a() {
                return regeneratorRuntime.wrap(function(a) {
                    for (;;) switch (a.prev = a.next) {
                      case 0:
                        if (console.log("---保存进度---"), n.default.$instance.globalData.friendJoin) {
                            a.next = 6;
                            break;
                        }
                        return a.abrupt("return");

                      case 6:
                      case "end":
                        return a.stop();
                    }
                }, a, this);
            }));
            return function() {
                return a.apply(this, arguments);
            };
        }(),
        getSpeed: function() {
            return n.default.$instance.globalData.bgAudioData.speed;
        },
        getCurrentTime: function() {
            return n.default.$instance.globalData.bgAudioData.currentTime;
        },
        getGlobalAudioId: function() {
            return n.default.$instance.globalData.bgAudioData.productId + "-" + n.default.$instance.globalData.bgAudioData.contentId;
        },
        getPId: function() {
            return n.default.$instance.globalData.bgAudioData.productId;
        },
        getCId: function() {
            return n.default.$instance.globalData.bgAudioData.contentId;
        },
        dataStatistics: function() {
            var a = t(regeneratorRuntime.mark(function a(t, e, n) {
                return regeneratorRuntime.wrap(function(a) {
                    for (;;) switch (a.prev = a.next) {
                      case 0:
                        return console.log("----播放统计----"), a.next = 3, u.default.init(t, e, n, "", !1, "");

                      case 3:
                        return a.next = 5, u.default.addPlayStatisticsByPerson();

                      case 5:
                        return a.next = 7, u.default.addPlayStatistics();

                      case 7:
                        return a.next = 9, u.default.addPlayStatisticsNum();

                      case 9:
                        return a.next = 11, u.default.setStaticStroageContent();

                      case 11:
                      case "end":
                        return a.stop();
                    }
                }, a, this);
            }));
            return function(t, e, n) {
                return a.apply(this, arguments);
            };
        }()
    };
    exports.default = l;
}();