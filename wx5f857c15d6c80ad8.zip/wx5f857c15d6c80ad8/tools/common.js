!function() {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: !0
    });
    var e = require("./../npm/js-base64/base64.js").Base64;
    exports.decodeLocation = function(r) {
        var o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "20220105";
        r = e.decode(r);
        for (var t = "", a = 0; a < r.length; a++) {
            var n = r.charCodeAt(a) ^ o;
            t += String.fromCharCode(n);
        }
        return t;
    };
}();