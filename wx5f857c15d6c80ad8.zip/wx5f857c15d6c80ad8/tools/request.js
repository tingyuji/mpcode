!function() {
    "use strict";
    function e(e) {
        return e && e.__esModule ? e : {
            default: e
        };
    }
    function r(e) {
        return function() {
            var r = e.apply(this, arguments);
            return new Promise(function(e, t) {
                return function n(a, o) {
                    try {
                        var s = r[a](o), u = s.value;
                    } catch (e) {
                        return void t(e);
                    }
                    if (!s.done) return Promise.resolve(u).then(function(e) {
                        n("next", e);
                    }, function(e) {
                        n("throw", e);
                    });
                    e(u);
                }("next");
            });
        };
    }
    Object.defineProperty(exports, "__esModule", {
        value: !0
    });
    var t = e(require("./../npm/wepy/lib/wepy.js")), n = e(require("./login/index.js")), a = e((require("./../fhd.config.js"), 
    require("./wx-request/index.js"))), o = require("./actions.js"), s = require("./config.js"), u = wx.getStorageSync("BaseRequestUrl"), i = wx.getAccountInfoSync().miniProgram.envVersion;
    a.default.config.set({
        baseUrl: u && "release" != i ? u : "https://" + s.DomainName.PROD,
        subUrl: {}
    }), a.default.interceptors.request.use(function() {
        var e = r(regeneratorRuntime.mark(function e(r, n) {
            var o, s;
            return regeneratorRuntime.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return o = r.options, s = r.data, o.extends = {
                        startTime: Date.now()
                    }, "string" == typeof o.baseUrl ? 0 !== o.baseUrl.indexOf("http") && (o.baseUrl = a.default.config.subUrl[o.baseUrl] ? a.default.config.subUrl[o.baseUrl] : a.default.config.baseUrl) : o.baseUrl = a.default.config.baseUrl, 
                    s.needHeader && (o.header[s.needHeader[0]] = s.needHeader[1]), s.contentType ? o.header["content-type"] = s.contentType : o.header["content-type"] = "application/x-www-form-urlencoded", 
                    o.noBaseUrl && (o.baseUrl = ""), o.noToken || (s.token = t.default.$instance.globalData.token), 
                    !s.shopId && t.default.$instance.globalData.userInfo && t.default.$instance.globalData.userInfo.shop && (s.targetShopId = t.default.$instance.globalData.userInfo.shop.shopId), 
                    e.abrupt("return", n());

                  case 9:
                  case "end":
                    return e.stop();
                }
            }, e, void 0);
        }));
        return function(r, t) {
            return e.apply(this, arguments);
        };
    }(), function() {
        var e = r(regeneratorRuntime.mark(function e(r) {
            var n;
            return regeneratorRuntime.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    r.options, n = r.data, r.url, n.referer || (n.referer = t.default.$instance.globalData.appConfig.source || "wendao");

                  case 2:
                  case "end":
                    return e.stop();
                }
            }, e, void 0);
        }));
        return function(r) {
            return e.apply(this, arguments);
        };
    }());
    var c = function(e, r) {
        var t = e.source, n = e.data;
        if (!t || !t.options || !t.options.extends) return r();
        var a, o, s = new Date(), u = s.getTime() - t.options.extends.startTime, i = [ "请求：", t.url, ", 响应耗时：", u, ", 回调时间：", s.format("hh:mm:ss"), ", 请求参数：", t.data, ", 响应参数: ", n ];
        n && 0 === n.scode && 0 === n.rcode ? (a = console).log.apply(a, i) : (o = console).error.apply(o, i);
        return r();
    };
    a.default.interceptors.response.success.use(c, function() {
        var e = r(regeneratorRuntime.mark(function e(r) {
            var t, a, s = r.data, u = r.source;
            return regeneratorRuntime.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (s) {
                        e.next = 2;
                        break;
                    }
                    return e.abrupt("return", s);

                  case 2:
                    if (3 === s.scode && -1 === u.url.indexOf("/system/getTime.do") && wx.reLaunch({
                        url: "/pages/other/updating"
                    }), !(-1 !== (t = u.options.baseUrl.indexOf("fhdowx.xyy001.com")) && 103 === s.scode || -1 === t && 6 === s.scode)) {
                        e.next = 18;
                        break;
                    }
                    return e.prev = 5, e.next = 8, o.Model.select("登录超时请重试", "登录");

                  case 8:
                    e.next = 13;
                    break;

                  case 10:
                    return e.prev = 10, e.t0 = e.catch(5), e.abrupt("return", Promise.reject(s));

                  case 13:
                    a = "/pages/index/index", "subCommonPage/pages/orderCenter/orderCenter" === getCurrentPages().pop().route && (a = "/subCommonPage/pages/orderCenter/orderCenter"), 
                    wx.reLaunch({
                        url: a
                    }), (0, n.default)({
                        reload: !0
                    });

                  case 18:
                    if (0 === s.rcode && 0 === s.scode) {
                        e.next = 20;
                        break;
                    }
                    return e.abrupt("return", Promise.reject(s));

                  case 20:
                    return e.abrupt("return", s);

                  case 21:
                  case "end":
                    return e.stop();
                }
            }, e, void 0, [ [ 5, 10 ] ]);
        }));
        return function(r) {
            return e.apply(this, arguments);
        };
    }()), a.default.interceptors.response.fail.use(c, function() {
        var e = r(regeneratorRuntime.mark(function e(r) {
            var t;
            return regeneratorRuntime.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return t = function(e) {
                        return e ? 404 === r.statusCode ? "接口不存在 404!" : "网络超时: " + r.statusCode : "网络连接错误";
                    }(r.statusCode), wx.showToast({
                        title: t,
                        icon: "none",
                        duration: 2e3
                    }), e.abrupt("return", Promise.reject({
                        rcode: -1,
                        scode: -1,
                        errMsg: t + " " + r.errMsg,
                        statusCode: r.statusCode || 0
                    }));

                  case 3:
                  case "end":
                    return e.stop();
                }
            }, e, void 0);
        }));
        return function(r) {
            return e.apply(this, arguments);
        };
    }()), exports.default = a.default;
}();