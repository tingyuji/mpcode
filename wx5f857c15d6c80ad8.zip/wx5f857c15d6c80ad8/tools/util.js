!function() {
    "use strict";
    Date.prototype.format = function(t) {
        var e = {
            "M+": this.getMonth() + 1,
            "d+": this.getDate(),
            "h+": this.getHours(),
            "m+": this.getMinutes(),
            "s+": this.getSeconds(),
            "q+": Math.floor((this.getMonth() + 3) / 3),
            S: this.getMilliseconds()
        };
        for (var r in /(y+)/.test(t) && (t = t.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length))), 
        e) new RegExp("(" + r + ")").test(t) && (t = t.replace(RegExp.$1, 1 == RegExp.$1.length ? e[r] : ("00" + e[r]).substr(("" + e[r]).length)));
        return t;
    }, Number.prototype.format = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "yyyy-MM-dd hh:mm:ss", e = t, r = new Date(1e3 * this), n = {
            "M+": r.getMonth() + 1,
            "d+": r.getDate(),
            "h+": r.getHours(),
            "m+": r.getMinutes(),
            "s+": r.getSeconds(),
            "q+": Math.floor((r.getMonth() + 3) / 3),
            S: r.getMilliseconds()
        };
        for (var i in /(y+)/.test(e) && (e = e.replace(RegExp.$1, (r.getFullYear() + "").substr(4 - RegExp.$1.length))), 
        n) new RegExp("(" + i + ")").test(e) && (e = e.replace(RegExp.$1, 1 == RegExp.$1.length ? n[i] : ("00" + n[i]).substr(("" + n[i]).length)));
        return e;
    }, String.prototype.replaceAll = function(t, e, r) {
        return RegExp.prototype.isPrototypeOf(t) ? this.replace(t, e) : this.replace(new RegExp(t, r ? "gi" : "g"), e);
    }, String.prototype.trim = function() {
        return this.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, "");
    }, String.prototype.startWith = function(t) {
        return new RegExp("^" + t).test(this);
    }, String.prototype.endWith = function(t) {
        return new RegExp(t + "$").test(this);
    }, String.prototype.parseQueryString = function() {
        var t = this, e = {}, r = [];
        if (!t || -1 == t.indexOf("?")) return e;
        for (var n = t.substring(t.indexOf("?") + 1, t.length).split("&"), i = 0; i < n.length; i++) n[i] && (e[(r = n[i].split("="))[0]] = r[1]);
        return e;
    }, Object.defineProperty(Object, "parseQueryObject", {
        value: function(t) {
            var e = [];
            for (var r in t) e.push(r + "=" + t[r]);
            return e.join("&");
        },
        writable: !0,
        configurable: !0
    });
}();