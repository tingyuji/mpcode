!function() {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: !0
    });
    var t = Object.assign || function(t) {
        for (var n = 1; n < arguments.length; n++) {
            var e = arguments[n];
            for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
        }
        return t;
    }, n = exports.Model = {
        _show: function(t) {
            var n = Object.assign({}, {
                title: "提示",
                content: "",
                confirmText: "确定",
                cancelText: "取消",
                showCancel: !0,
                cancelColor: "#000000",
                confirmColor: "#1C83E4"
            }, t);
            if ("string" != typeof n.content) if (n.content instanceof Error) n.content = n.content.toString(); else try {
                n.content = JSON.stringify(n.content);
            } catch (t) {
                try {
                    n.content = n.content.toString();
                } catch (t) {
                    n.content = "该错误提示无法正常显示";
                }
            }
            e.hide(), wx.showModal(n);
        },
        select: function() {
            var n = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", e = this, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "确定", r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
            return new Promise(function(i, c) {
                e._show(t({
                    content: n,
                    confirmText: o
                }, r, {
                    success: function(t) {
                        return t.confirm ? i(n) : c(n);
                    },
                    fail: function() {
                        return c(n);
                    }
                }));
            });
        },
        alert: function() {
            var n = this, e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
            return new Promise(function(r, i) {
                n._show(t({
                    content: e,
                    showCancel: !1
                }, o, {
                    success: function() {
                        return r(e);
                    },
                    fail: function() {
                        return r(e);
                    }
                }));
            });
        },
        fail: function() {
            var n = this, e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
            return new Promise(function(r, i) {
                n._show(t({
                    content: e,
                    showCancel: !1
                }, o, {
                    success: function() {
                        return i(e);
                    },
                    fail: function() {
                        return i(e);
                    }
                }));
            });
        }
    }, e = exports.Load = {
        show: function() {
            var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "加载中...", n = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
            wx.showLoading({
                title: t,
                mask: n
            });
        },
        hide: function() {
            wx.hideLoading();
        }
    }, o = exports.Toast = {
        success: function() {
            var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "成功", n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 900;
            wx.showToast({
                title: t,
                icon: "success",
                duration: n
            });
        },
        alert: function() {
            var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "失败", n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 2e3;
            wx.showToast({
                title: t,
                icon: "none",
                duration: n
            });
        },
        fail: function() {
            var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "失败", n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 2e3;
            wx.showToast({
                title: t,
                icon: "none",
                duration: n
            });
        }
    }, r = exports.showActionSheet = function(t) {
        function n(t, n) {
            var o = function() {
                var e = [].concat(n);
                return 0 === t ? e : e.slice(5 + 4 * (t - 1));
            }(), r = o.length;
            if (0 === t) {
                if (r > e) {
                    var i = o.slice(0, 5);
                    return i.push("下一页"), i;
                }
                return o;
            }
            if (r > e - 1) {
                var c = o.slice(0, 4);
                return c.push("下一页"), c.unshift("上一页"), c;
            }
            var s = o.slice(0, 5);
            return s.unshift("上一页"), s;
        }
        var e = 6, o = 0;
        return new Promise(function(e, r) {
            !function i(c) {
                var s = n(c, t);
                wx.showActionSheet({
                    itemList: s,
                    success: function(t) {
                        return "上一页" === s[t.tapIndex] ? i(--o) : "下一页" === s[t.tapIndex] ? i(++o) : void e({
                            index: t.tapIndex,
                            value: s[t.tapIndex]
                        });
                    },
                    fail: function(t) {
                        r(t);
                    }
                });
            }(o);
        });
    }, i = exports.Request = function() {
        var t = function(t) {
            return function() {
                var n = t.apply(this, arguments);
                return new Promise(function(t, e) {
                    return function o(r, i) {
                        try {
                            var c = n[r](i), s = c.value;
                        } catch (t) {
                            return void e(t);
                        }
                        if (!c.done) return Promise.resolve(s).then(function(t) {
                            o("next", t);
                        }, function(t) {
                            o("throw", t);
                        });
                        t(s);
                    }("next");
                });
            };
        }(regeneratorRuntime.mark(function t(o) {
            var r, i, c = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
            return regeneratorRuntime.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return c = Object.assign({
                        loadText: "加载中...",
                        showModal: !0,
                        modelText: ""
                    }, c), r = null, e.show(c.loadText), t.prev = 3, t.next = 6, o;

                  case 6:
                    r = t.sent, t.next = 18;
                    break;

                  case 9:
                    if (t.prev = 9, t.t0 = t.catch(3), i = null, e.hide(), !c.showModal) {
                        t.next = 17;
                        break;
                    }
                    return i = c.modelText ? "function" == typeof c.modelText ? c.modelText(t.t0) : c.modelText : JSON.stringify(t.t0), 
                    t.next = 17, n.alert(i);

                  case 17:
                    return t.abrupt("return", Promise.reject(t.t0));

                  case 18:
                    return e.hide(), t.abrupt("return", r);

                  case 20:
                  case "end":
                    return t.stop();
                }
            }, t, this, [ [ 3, 9 ] ]);
        }));
        return function(n) {
            return t.apply(this, arguments);
        };
    }();
    exports.Model = n, exports.Load = e, exports.Toast = o, exports.Request = i, exports.showActionSheet = r, 
    exports.default = {
        Model: n,
        Load: e,
        Toast: o,
        Request: i,
        showActionSheet: r
    };
}();