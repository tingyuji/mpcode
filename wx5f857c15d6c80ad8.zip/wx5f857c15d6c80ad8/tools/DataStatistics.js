!function() {
    "use strict";
    function e(e) {
        return e && e.__esModule ? e : {
            default: e
        };
    }
    function t(e) {
        return function() {
            var t = e.apply(this, arguments);
            return new Promise(function(e, i) {
                return function s(n, a) {
                    try {
                        var r = t[n](a), u = r.value;
                    } catch (e) {
                        return void i(e);
                    }
                    if (!r.done) return Promise.resolve(u).then(function(e) {
                        s("next", e);
                    }, function(e) {
                        s("throw", e);
                    });
                    e(u);
                }("next");
            });
        };
    }
    Object.defineProperty(exports, "__esModule", {
        value: !0
    });
    var i = (e(require("./../npm/wepy/lib/wepy.js")), require("./../api/index.js")), s = e(i), n = e(require("./storage.js")), a = {
        productId: 0,
        contentId: 0,
        pageUrl: "pages/index/index",
        type: 1,
        isShare: !1,
        shareType: "",
        note: "",
        sourceType: {
            "pages/index/index": "shouye",
            "pages/indexNew": "shouye",
            "pages/qandaDetail2": "wendatuijian",
            "pages/bkwzDetail": "",
            "pages/askResult": "tiwenchenggongtuijian",
            "pages/myOrder": "yigou",
            "pages/myOrder2": "yigou",
            "pages/user/user": "gerenzhongxin",
            "/subPsychologyTheme/pages/psychologyTheme/psychologyTheme": "xinlizhuanti",
            "pages/qanda": "wendazhuye",
            "pages/qandaList": "wendaliebiao",
            "pages/qandaTwo": "wendaerjiye",
            "pages/qaSearch": "wendasousuo",
            "pages/myCollection": "shoucang",
            "pages/myQuestion": "wodetiwen",
            "pages/myAnswered": "wodehuida",
            "pages/sentencePicture": "zhiyutu",
            "pages/healings": "xinlitiaojiezhuye",
            "pages/healingsTwo": "xinlitiaojieerjiye",
            "pages/xltjSearch": "xinlitiaojiesousuo",
            "subHypnosis/pages/theme/theme": "cuimianliaoyuzhutiliebiao",
            "subHypnosis/pages/vip/vip": "huiyuanshouye",
            "subHypnosis/pages/courseList/courseList": "huiyuanerjiye",
            "subHypnosis/pages/index/index": "cuimianliaoyushouye",
            "subHypnosis/pages/receive/receive": "zengsonglingqu",
            "subHypnosis/pages/problemAnswer/problemAnswer": "cuimianliaoyudayiliebiao",
            "subHypnosis/pages/answerDetail/answerDetail": "cuimianliaoyudayixiangqing",
            "pages/xltjDetail": "cuimianliaoyuxiangqing",
            "pages/coursesList": "jingpinkeerjiye",
            "pages/courseSearch": "jingpinkesousuo",
            "pages/buyResult": "yigou",
            "pages/indexMoreJump": "wenzhangbaikeliebiao",
            "pages/audioListPage": "yinpinliebiao",
            "pages/ypSearch": "yinpinsousuo",
            "pages/courseDetail2": "kechengxiangqing",
            wxShare: "wxShare",
            qrCodeShare: "qrCodeShare",
            gzhwzShare: "gzhwzShare",
            mbxxShare: "mbxxShare",
            pyqShare: "pyqShare",
            "subPsychologicalTest/pages/testResult/testResult": "xingliceshijieguotuijian",
            "subPsychologicalTest/pages/index/index": "xinliceshierjiye",
            "subPsychologicalTest/pages/testListPage/testListPage": "xinliceshiliebiao",
            "pages/testIndex": "xinliceshizhuye",
            "subPsychologicalTest/pages/testDetail/testDetail": "xinliceshiliebiao",
            "subPsychologicalTest/pages/searchListPage/searchListPage": "xinliceshisousuo",
            "subWiki/pages/index/index": "baiketuijian",
            wikeDetailPage: "baiketuijian",
            "subWiki/pages/detail/detail": "baiketuijian",
            "subWiki/pages/home/home": "baikeerjiye",
            "pages/wiki/home": "baikezhuye",
            "subAudioFrequency/pages/index/index": "yinpinliebiao",
            "subAudioFrequency/pages/rankingList/rankingList": "yinpinliebiao",
            "pages/themeDetail": "zhutituijian",
            "subSearch/pages/search/search": "sousuo",
            "subPlan/pages/index/index": "fanganshouye",
            "subPlan/pages/squeeze/squeeze": "fanganluodiye",
            "subPlan/pages/myPlansSet/myPlansSet": "wodefangan"
        },
        addAccessStatistics: function() {
            var e = t(regeneratorRuntime.mark(function e() {
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return e.next = 2, s.default.statistics.addAccessStatistics({
                            courseId: this.productId,
                            sourceType: this.isShare ? this.sourceType[this.shareType] : this.sourceType[this.pageUrl],
                            type: this.type
                        });

                      case 2:
                        e.sent;

                      case 3:
                      case "end":
                        return e.stop();
                    }
                }, e, this);
            }));
            return function() {
                return e.apply(this, arguments);
            };
        }(),
        addAccessStatisticsByPerson: function() {
            var e = t(regeneratorRuntime.mark(function e() {
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (!this.isVisitedProduct()) {
                            e.next = 2;
                            break;
                        }
                        return e.abrupt("return");

                      case 2:
                        return e.next = 4, s.default.statistics.addAccessStatisticsByPerson({
                            courseId: this.productId,
                            sourceType: this.isShare ? this.sourceType[this.shareType] : this.sourceType[this.pageUrl],
                            type: this.type
                        });

                      case 4:
                        e.sent;

                      case 5:
                      case "end":
                        return e.stop();
                    }
                }, e, this);
            }));
            return function() {
                return e.apply(this, arguments);
            };
        }(),
        addPlayStatisticsNum: function() {
            var e = t(regeneratorRuntime.mark(function e() {
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return e.next = 2, s.default.statistics.addPlayStatisticsNum({
                            concatId: this.productId,
                            contentId: this.contentId,
                            type: this.type
                        });

                      case 2:
                        e.sent;

                      case 3:
                      case "end":
                        return e.stop();
                    }
                }, e, this);
            }));
            return function() {
                return e.apply(this, arguments);
            };
        }(),
        addPlayStatistics: function() {
            var e = t(regeneratorRuntime.mark(function e() {
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return e.next = 2, s.default.statistics.addPlayStatistics({
                            courseId: this.productId,
                            contentId: this.contentId,
                            type: this.type
                        });

                      case 2:
                        e.sent;

                      case 3:
                      case "end":
                        return e.stop();
                    }
                }, e, this);
            }));
            return function() {
                return e.apply(this, arguments);
            };
        }(),
        addPlayStatisticsByPerson: function() {
            var e = t(regeneratorRuntime.mark(function e() {
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (!this.isVisitedContent()) {
                            e.next = 2;
                            break;
                        }
                        return e.abrupt("return");

                      case 2:
                        return e.next = 4, s.default.statistics.addPlayStatisticsByPerson({
                            courseId: this.productId,
                            contentId: this.contentId,
                            type: this.type
                        });

                      case 4:
                        e.sent;

                      case 5:
                      case "end":
                        return e.stop();
                    }
                }, e, this);
            }));
            return function() {
                return e.apply(this, arguments);
            };
        }(),
        addAccessFullStatistics: function() {
            var e = t(regeneratorRuntime.mark(function e() {
                var t;
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return t = n.default.getSync("tuijianProductMainName"), console.log("---tuijianProductMainName---", t, (this.isShare ? this.sourceType[this.shareType] : this.sourceType[this.pageUrl]).indexOf("tuijian")), 
                        t && -1 != (this.isShare ? this.sourceType[this.shareType] : this.sourceType[this.pageUrl]).indexOf("tuijian") && (this.note = t), 
                        e.next = 5, s.default.statistics.addAccessFullStatistics({
                            courseId: this.productId,
                            sourceType: this.isShare ? this.sourceType[this.shareType] : this.sourceType[this.pageUrl],
                            type: this.type,
                            note: this.note ? this.note : ""
                        });

                      case 5:
                        e.sent, this.note = "";

                      case 7:
                      case "end":
                        return e.stop();
                    }
                }, e, this);
            }));
            return function() {
                return e.apply(this, arguments);
            };
        }(),
        init: function() {
            var e = t(regeneratorRuntime.mark(function e(t, i, s, a, r, u) {
                var o, c, p, h, d = this;
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        this.productId = t || "", this.contentId = i || "", this.type = s || "", this.pageUrl = a || "pyqShare", 
                        this.isShare = r || !1, this.shareType = u, "pages/bkwzDetail" == a && (o = n.default.getSync("wenzhangORbaike"), 
                        this.sourceType[this.pageUrl] = o && 1 == o ? "baiketuijian" : "wenzhangtuijian"), 
                        "pages/indexMoreJump" == a && (c = n.default.getSync("wenzhangORbaike"), this.sourceType[this.pageUrl] = c && 1 == c ? "baikeliebiao" : "wenzhangliebiao"), 
                        "pages/coursesList" != a && "pages/index" != a && "pages/audioListPage" != a && "pages/qandaTwo" != a && "pages/qanda" != a && "pages/healings" != a && "pages/healingsTwo" != a || (p = this.sourceType[this.pageUrl], 
                        (h = n.default.getSync("lunbotuJump")) && (this.sourceType[this.pageUrl] = h), n.default.removeSync("lunbotuJump"), 
                        setTimeout(function() {
                            d.sourceType[d.pageUrl] = p;
                        }, 1e3));

                      case 9:
                      case "end":
                        return e.stop();
                    }
                }, e, this);
            }));
            return function(t, i, s, n, a, r) {
                return e.apply(this, arguments);
            };
        }(),
        setStaticStroageProduct: function() {
            var e = t(regeneratorRuntime.mark(function e() {
                var t;
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        (t = n.default.getSync("myVisitProductIds")) && "" != t ? -1 == t.indexOf(this.productId + "_" + this.type) && n.default.setSync("myVisitProductIds", t + "" + this.productId + "_" + this.type + ",") : n.default.setSync("myVisitProductIds", this.productId + "_" + this.type + ",");

                      case 2:
                      case "end":
                        return e.stop();
                    }
                }, e, this);
            }));
            return function() {
                return e.apply(this, arguments);
            };
        }(),
        isVisitedProduct: function() {
            var e = n.default.getSync("myVisitProductIds");
            return !(!e || -1 == e.indexOf(this.productId + "_" + this.type));
        },
        setStaticStroageContent: function() {
            var e = n.default.getSync("myVisitContentIds");
            e && "" != e ? -1 == e.indexOf(this.productId + "_" + this.type + "_" + this.contentId) && n.default.setSync("myVisitContentIds", e + "" + this.productId + "_" + this.type + "_" + this.contentId + ",") : n.default.setSync("myVisitContentIds", this.productId + "_" + this.type + "_" + this.contentId + ",");
        },
        isVisitedContent: function() {
            var e = n.default.getSync("myVisitContentIds");
            return !(!e || -1 == e.indexOf(this.productId + "_" + this.type + "_" + this.contentId));
        }
    };
    exports.default = a;
}();