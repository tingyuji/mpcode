!function() {
    "use strict";
    function e(e) {
        return e && e.__esModule ? e : {
            default: e
        };
    }
    Object.defineProperty(exports, "__esModule", {
        value: !0
    }), exports.getHtmlValTxt = exports.throttle = exports.debounce = exports.PROD_Collect = exports.getPhoneType = exports.sleepSync = exports.getElementSync = void 0;
    var t = e(require("./../npm/wepy/lib/wepy.js")), n = e(require("./../npm/@clevok/collect-util/lib/index.js"));
    exports.getElementSync = function(e) {
        return new Promise(function(t) {
            wx.createSelectorQuery().select(e).boundingClientRect(function(e) {
                t(e);
            }).exec();
        });
    }, exports.sleepSync = function(e) {
        return new Promise(function(t) {
            setTimeout(function() {
                return t();
            }, e);
        });
    }, exports.getPhoneType = function() {
        var e = t.default.$instance.globalData.system.system, n = void 0;
        if (e) {
            var r = e.indexOf(" ");
            n = e.substring(0, r);
        } else {
            var o = wx.getSystemInfoSync(), i = o.system.indexOf(" ");
            n = o.system.substring(0, i);
        }
        return n;
    }, exports.PROD_Collect = function() {
        var e = function(e) {
            return function() {
                var t = e.apply(this, arguments);
                return new Promise(function(e, n) {
                    return function r(o, i) {
                        try {
                            var s = t[o](i), u = s.value;
                        } catch (e) {
                            return void n(e);
                        }
                        if (!s.done) return Promise.resolve(u).then(function(e) {
                            r("next", e);
                        }, function(e) {
                            r("throw", e);
                        });
                        e(u);
                    }("next");
                });
            };
        }(regeneratorRuntime.mark(function e(r, o) {
            var i, s, u, c;
            return regeneratorRuntime.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.next = 2, wx.$login.wait();

                  case 2:
                    0 === r.fid.indexOf("yiyuzycs_") ? (i = wx.getAccountInfoSync().miniProgram.envVersion, 
                    console.log(i, "release" == i, "------这个点的信息为------", r), "release" === i && n.default.uba(r, o)) : (s = r.fid, 
                    u = r.params, (c = void 0 === u ? {} : u).time = (new Date().getTime() / 1e3).format("yyyy-MM-dd hh:mm:ss"), 
                    c.uid = t.default.$instance.globalData.userInfo.userId, console.log({
                        fid: s,
                        params: c
                    }), wx.reportEvent(s, c));

                  case 3:
                  case "end":
                    return e.stop();
                }
            }, e, this);
        }));
        return function(t, n) {
            return e.apply(this, arguments);
        };
    }(), exports.debounce = function(e, t) {
        var n = void 0, r = t || 500;
        return function() {
            clearTimeout(n);
            var t = this, o = arguments;
            n = setTimeout(function() {
                e.call(t, o);
            }, r);
        };
    }, exports.throttle = function(e, t) {
        var n = 0, r = t || 2e3;
        return function() {
            var t = this, o = new Date();
            o - n > r && (e.call(t, arguments), n = o);
        };
    }, exports.getHtmlValTxt = function(e) {
        var t = new RegExp("<[^>]*?>", "gi"), n = new RegExp("&nbsp;", "g"), r = new RegExp(" &nbsp;", "g");
        return e.replace(t, "").replace(n, "").replace(r, "");
    };
}();