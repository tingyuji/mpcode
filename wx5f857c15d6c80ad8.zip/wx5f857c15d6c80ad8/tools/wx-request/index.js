!function() {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: !0
    });
    var e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
        return typeof e;
    } : function(e) {
        return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
    }, t = require("./lib/request.js"), r = require("./config.js"), n = require("./lib/interceptors.js");
    n.request.use(function() {
        var e = function(e) {
            return function() {
                var t = e.apply(this, arguments);
                return new Promise(function(e, r) {
                    return function n(o, i) {
                        try {
                            var u = t[o](i), s = u.value;
                        } catch (e) {
                            return void r(e);
                        }
                        if (!u.done) return Promise.resolve(s).then(function(e) {
                            n("next", e);
                        }, function(e) {
                            n("throw", e);
                        });
                        e(s);
                    }("next");
                });
            };
        }(regeneratorRuntime.mark(function e(t, n) {
            return regeneratorRuntime.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return t.options = Object.assign({
                        baseUrl: t.options.baseUrl || r.baseUrl,
                        method: t.options.method || r.method || "POST",
                        header: t.options.header || r.header || {},
                        dataType: t.options.dataType || r.dataType || "json"
                    }, t.options), e.abrupt("return", n());

                  case 2:
                  case "end":
                    return e.stop();
                }
            }, e, void 0);
        }));
        return function(t, r) {
            return e.apply(this, arguments);
        };
    }()), t.interceptors = n, t.config = r, t.config.set = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        "object" === (void 0 === t ? "undefined" : e(t)) && Object.keys(t).forEach(function(e) {
            r[e] = t[e];
        });
    }, module.exports = t, exports.default = t;
}();