!function() {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: !0
    });
    var e = exports.DomainName = Object.freeze({
        UAT: "dev-zhishi.fhd001.com",
        PROD: "zhishi.fhd001.com"
    });
    exports.ScanTag = Object.freeze({
        M: "http://" + e.PROD,
        Co: "http://" + e.PROD + "/coourse/"
    });
}();