!function() {
    "use strict";
    function e(e) {
        if (Array.isArray(e)) {
            for (var t = 0, r = Array(e.length); t < e.length; t++) r[t] = e[t];
            return r;
        }
        return Array.from(e);
    }
    Object.defineProperty(exports, "__esModule", {
        value: !0
    });
    var t = function() {
        function e(e, t) {
            for (var r = 0; r < t.length; r++) {
                var n = t[r];
                n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), 
                Object.defineProperty(e, n.key, n);
            }
        }
        return function(t, r, n) {
            return r && e(t.prototype, r), n && e(t, n), t;
        };
    }(), r = function() {
        function r() {
            (function(e, t) {
                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
            })(this, r), this._events = {};
        }
        return t(r, [ {
            key: "getEmitBeforeRoute",
            value: function() {
                var e = getCurrentPages(), t = e.length;
                return 1 !== t && t ? e[t - 2].route || e[t - 2].__route__ : null;
            }
        }, {
            key: "beforeOn",
            value: function(e, t, r) {
                return e ? t ? r ? (this._events[e] || (this._events[e] = []), !0) : (console.warn("缺少this参数" + e), 
                !1) : (console.warn("空回调函数" + e), !1) : (console.warn("缺失监听事件名称"), !1);
            }
        }, {
            key: "on",
            value: function(e, t, r) {
                if (this.beforeOn(e, t, r)) {
                    var n = [ r, t ], o = this._events[e];
                    o.unshift(n);
                    for (var i = 0, l = o.length, s = 0; s < l; s++) o[s][0] === r && (i += 1);
                    i > 1 && console.warn("发现重复绑定" + e), 0 === i && console.warn("绑定失败" + e);
                }
            }
        }, {
            key: "onnewest",
            value: function(e, t, r) {
                if (this.beforeOn(e, t, r)) {
                    for (var n = this._events[e], o = n.length, i = 0; i < o; i++) {
                        var l = n[i];
                        l && l[0] === r && (console.error("移除重复绑定" + e), n.splice(i, 1), i -= 1, o -= 1);
                    }
                    n.unshift([ r, t ]);
                }
            }
        }, {
            key: "onoldest",
            value: function(e, t, r) {
                if (this.beforeOn(e, t, r)) {
                    for (var n = this._events[e], o = n.length, i = 0; i < o; i++) {
                        var l = n[i];
                        if (l && l[0] === r) return void console.error(e + "下注册失败,原因:" + r + "标识已被注册");
                    }
                    n.unshift([ r, t ]);
                }
            }
        }, {
            key: "remove",
            value: function(e, t) {
                var r = this._events[e];
                if (!r || r.length <= 0) return console.error("移除空监听" + e);
                for (var n = !1, o = r.length, i = 0; i < o; i++) r[i][0] === t && (n = !0, r.splice(i, 1), 
                i -= 1, o -= 1);
                return n ? void 0 : console.error("移除空监听" + e);
            }
        }, {
            key: "getEmitEvent",
            value: function(t) {
                var r = [], n = this._events[t];
                if (!n || n.length <= 0) return console.error("空响应" + t), r;
                for (var o = n.length, i = 0; i < o; i++) {
                    var l = n[i], s = [];
                    if (!l) return console.error("进入循环无响应"), r;
                    try {
                        (s = [].slice.apply(arguments)).shift();
                    } catch (e) {
                        console.error("emitAll解析数据失败", e);
                    }
                    try {
                        r.push({
                            fun: l[1],
                            self: l[0],
                            argus: [].concat(e(s), [ {
                                index: i,
                                beforeRoute: this.getEmitBeforeRoute()
                            } ])
                        });
                    } catch (e) {
                        console.error("响应失败emitAll", e);
                    }
                }
                return r;
            }
        }, {
            key: "emitAll",
            value: function() {
                this.getEmitEvent.apply(this, arguments).forEach(function(e) {
                    e.fun.apply(e.self, e.argus);
                });
            }
        }, {
            key: "emitAllByReverse",
            value: function() {
                this.getEmitEvent.apply(this, arguments).reverse().forEach(function(e) {
                    e.fun.apply(e.self, e.argus);
                });
            }
        }, {
            key: "emit",
            value: function(t) {
                var r = this._events[t];
                if (!r || r.length <= 0) return console.error("空响应" + t);
                var n = r[0], o = [];
                try {
                    (o = [].slice.apply(arguments)).shift();
                } catch (e) {
                    console.error("emit解析数据失败", e);
                }
                n[1].apply(n[0], [].concat(e(o), [ {
                    index: 0,
                    beforeRoute: this.getEmitBeforeRoute()
                } ]));
            }
        } ]), r;
    }();
    !function() {
        var e = new r();
        [ "on", "onnewest", "onoldest", "remove", "emitAll", "emitAllByReverse", "emit" ].forEach(function(t) {
            r[t] = function() {
                return e[t].apply(e, arguments);
            };
        });
    }(), module.exports = r, exports.default = r;
}();