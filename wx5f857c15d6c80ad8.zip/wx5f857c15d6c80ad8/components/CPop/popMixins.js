!function() {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: !0
    }), exports.default = Behavior({
        options: {
            multipleSlots: !0
        },
        properties: {
            sync: String,
            show: {
                type: Boolean,
                value: !1,
                observer: function(t) {
                    "boolean" == typeof t && this.data._show !== t && (t ? this.show() : this.hide());
                }
            },
            maskClosable: {
                type: Boolean,
                value: !0
            }
        },
        data: {
            _show: !1,
            modalOpen: !1
        },
        ready: function() {
            this.handleCallback = null;
        },
        methods: {
            changeModalStatus: function() {
                var t = this, e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
                this.handleCallback && clearTimeout(this.handleCallback), e || (this.handleCallback = setTimeout(function() {
                    t.handleCallback = null, t.setData({
                        modalOpen: !1
                    });
                }, 600));
            },
            changeSync: function() {
                var t = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
                this.properties.sync && this.triggerEvent("ing", {
                    type: "sync",
                    value: t,
                    sync: this.properties.sync
                });
            },
            show: function() {
                this.setData({
                    _show: !0,
                    modalOpen: !0
                }), this.changeModalStatus(!0), this.changeSync(!0), this.triggerEvent("show");
            },
            hide: function() {
                this.setData({
                    _show: !1
                }), this.changeModalStatus(!1), this.changeSync(!1), this.triggerEvent("hide");
            },
            $tapMask: function() {
                this.triggerEvent("tapMask"), this.properties.maskClosable && this.hide();
            },
            $catch: function() {}
        }
    });
}();