!function() {
    "use strict";
    var e = function(e) {
        return e && e.__esModule ? e : {
            default: e
        };
    }(require("./../popMixins.js"));
    Component.C({
        behaviors: [ e.default ],
        options: {
            multipleSlots: !0
        },
        properties: {
            loading: {
                type: Boolean,
                value: !1
            }
        },
        methods: {}
    });
}();