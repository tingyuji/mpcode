!function() {
    "use strict";
    function e(e) {
        return function() {
            var n = e.apply(this, arguments);
            return new Promise(function(e, t) {
                return function r(o, i) {
                    try {
                        var s = n[o](i), a = s.value;
                    } catch (e) {
                        return void t(e);
                    }
                    if (!s.done) return Promise.resolve(a).then(function(e) {
                        r("next", e);
                    }, function(e) {
                        r("throw", e);
                    });
                    e(a);
                }("next");
            });
        };
    }
    var n = require("./../../fhd.config.js"), t = require("./../../tools/login/config.js").event, r = require("./../../tools/login/store.js"), o = require("./../../tools/login/index.js"), i = require("./../../tools/login/login.js");
    Component.C({
        data: {
            reload: !1,
            project: n.project
        },
        ready: function() {
            var e = this, n = function() {
                e.showLogin(), wx.hideLoading(), e.setData({
                    reload: !0
                });
            };
            r.data.needReload && n(), t.on("login/error/show", n, this), t.on("app/login/success", function() {
                e.hideLogin(), e.setData({
                    reload: !1,
                    show: !1
                });
            }, this);
        },
        detached: function() {
            t.remove("login/error/show", this), t.remove("app/login/success", this);
        },
        methods: {
            showLogin: function() {
                this.$refs.pop.show();
            },
            hideLogin: function() {
                this.$refs.pop.hide();
            },
            login: function() {
                var n = e(regeneratorRuntime.mark(function n(t) {
                    var r = this, s = t.detail;
                    return regeneratorRuntime.wrap(function(n) {
                        for (;;) switch (n.prev = n.next) {
                          case 0:
                            if (!s || "getUserInfo:fail auth deny" !== s.errMsg) {
                                n.next = 2;
                                break;
                            }
                            return n.abrupt("return");

                          case 2:
                            if (s && s.iv && s.encryptedData && s.userInfo) {
                                n.next = 4;
                                break;
                            }
                            return n.abrupt("return", wx.showModal({
                                title: "提示",
                                content: "微信授权获取用户信息缺失"
                            }));

                          case 4:
                            return n.next = 6, o({
                                reload: !0
                            }, function() {
                                var n = e(regeneratorRuntime.mark(function e(n) {
                                    var t, o, a = n.data;
                                    return regeneratorRuntime.wrap(function(e) {
                                        for (;;) switch (e.prev = e.next) {
                                          case 0:
                                            if (1 !== a.createStatus) {
                                                e.next = 6;
                                                break;
                                            }
                                            return e.next = 3, i.createUserInfo(a.sessionKey, s);

                                          case 3:
                                            t = e.sent, o = t.data, a = Object.assign(a, o);

                                          case 6:
                                          case "end":
                                            return e.stop();
                                        }
                                    }, e, r);
                                }));
                                return function(e) {
                                    return n.apply(this, arguments);
                                };
                            }());

                          case 6:
                          case "end":
                            return n.stop();
                        }
                    }, n, this);
                }));
                return function(e) {
                    return n.apply(this, arguments);
                };
            }()
        }
    });
}();