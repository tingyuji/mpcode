!function() {
    "use strict";
    function e(e) {
        return e && e.__esModule ? e : {
            default: e
        };
    }
    function t(e, t) {
        if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
    }
    function r(e, t) {
        if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
        return !t || "object" != typeof t && "function" != typeof t ? e : t;
    }
    Object.defineProperty(exports, "__esModule", {
        value: !0
    }), exports.default = void 0;
    var o = e(require("./../npm/wepy/lib/wepy.js")), n = e(require("./../tools/wxpage/lib/component.js")), i = function(e) {
        function o() {
            var e, i, a;
            t(this, o);
            for (var s = arguments.length, f = Array(s), c = 0; c < s; c++) f[c] = arguments[c];
            return i = a = r(this, (e = o.__proto__ || Object.getPrototypeOf(o)).call.apply(e, [ this ].concat(f))), 
            a.methods = {
                $: function(e) {
                    var t = e.detail;
                    switch (t.type) {
                      case "attached":
                        var r = n.default.getRef && n.default.getRef(t.id);
                        if (!r) return;
                        this.$refs || (this.$refs = {});
                        var o = r._$ref;
                        o && this.$refs && (this.$refs[o] = r), r._$attached(this);
                        break;

                      case "event:call":
                        var i = this[t.method];
                        i && i.apply(this, t.args);
                    }
                }
            }, r(a, i);
        }
        return function(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
            e.prototype = Object.create(t && t.prototype, {
                constructor: {
                    value: e,
                    enumerable: !1,
                    writable: !0,
                    configurable: !0
                }
            }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
        }(o, e), o;
    }(o.default.mixin);
    exports.default = i;
}();