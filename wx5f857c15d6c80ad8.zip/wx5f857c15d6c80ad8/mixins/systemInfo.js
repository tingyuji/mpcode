!function() {
    "use strict";
    function e(e) {
        return e && e.__esModule ? e : {
            default: e
        };
    }
    function t(e, t) {
        if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
    }
    function n(e, t) {
        if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
        return !t || "object" != typeof t && "function" != typeof t ? e : t;
    }
    Object.defineProperty(exports, "__esModule", {
        value: !0
    }), exports.default = void 0;
    var o = function() {
        function e(e, t) {
            for (var n = 0; n < t.length; n++) {
                var o = t[n];
                o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), 
                Object.defineProperty(e, o.key, o);
            }
        }
        return function(t, n, o) {
            return n && e(t.prototype, n), o && e(t, o), t;
        };
    }(), r = e(require("./../npm/wepy/lib/wepy.js")), a = e(require("./../tools/event.js")), i = {
        dataVersion: 1,
        currentRoute: "",
        preRoute: "",
        userInfo: {},
        isLoged: !1,
        authorizePhone: !1,
        phoneType: "Android",
        followGZH: !1,
        gzhMessageSend: !1
    }, s = function(e) {
        function s() {
            var e, o, r;
            t(this, s);
            for (var a = arguments.length, u = Array(a), l = 0; l < a; l++) u[l] = arguments[l];
            return o = r = n(this, (e = s.__proto__ || Object.getPrototypeOf(s)).call.apply(e, [ this ].concat(u))), 
            r.computed = {
                setDataVersion: function() {
                    this.dataVersion++;
                }
            }, r.data = JSON.parse(JSON.stringify(i)), n(r, o);
        }
        return function(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
            e.prototype = Object.create(t && t.prototype, {
                constructor: {
                    value: e,
                    enumerable: !1,
                    writable: !0,
                    configurable: !0
                }
            }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
        }(s, e), o(s, [ {
            key: "updateData",
            value: function(e) {
                for (var t in e) this[t] = e[t];
                this.$apply();
            }
        }, {
            key: "analysisSystemInfo",
            value: function() {
                var e = function(e) {
                    return function() {
                        var t = e.apply(this, arguments);
                        return new Promise(function(e, n) {
                            return function o(r, a) {
                                try {
                                    var i = t[r](a), s = i.value;
                                } catch (e) {
                                    return void n(e);
                                }
                                if (!i.done) return Promise.resolve(s).then(function(e) {
                                    o("next", e);
                                }, function(e) {
                                    o("throw", e);
                                });
                                e(s);
                            }("next");
                        });
                    };
                }(regeneratorRuntime.mark(function e() {
                    var t, n, o, a, i, s;
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            if (t = getCurrentPages(), n = t[t.length - 1], this.currentRoute = n.route, t && t.length > 1 && (o = t[t.length - 2], 
                            this.preRoute = o.route), r.default.$instance.globalData.token) {
                                e.next = 7;
                                break;
                            }
                            return e.next = 7, wx.$login.wait();

                          case 7:
                            this.userInfo = r.default.$instance.globalData.userInfo, this.isLoged = r.default.$instance.globalData.isLoged, 
                            a = r.default.$instance.globalData.system.system, i = a.indexOf(" "), s = a.substring(0, i), 
                            this.phoneType = s, this.followGZH = r.default.$instance.globalData.followGZH, this.gzhMessageSend = r.default.$instance.globalData.gzhMessageSend, 
                            this.$apply();

                          case 16:
                          case "end":
                            return e.stop();
                        }
                    }, e, this);
                }));
                return function() {
                    return e.apply(this, arguments);
                };
            }()
        }, {
            key: "onLoad",
            value: function() {
                var e = this;
                a.default.on("loginSuccessEvent", function(t) {
                    e.userInfo = t.userInfo, e.isLoged = t.isLoged, e.$apply();
                }, this), a.default.on("updatePhoneSuccess", function(t) {
                    e.userInfo.phone = t.phone, e.$apply();
                }, this), a.default.on("updateUserInfoSuccess", function(t) {
                    e.userInfo.userNick = t.userNick, e.userInfo.avatar = t.avatar, e.$apply();
                }, this), a.default.on("isFollowGZH", function(t) {
                    e.followGZH = !0, e.$apply();
                }, this), a.default.on("isSendGZHmsg", function(t) {
                    e.gzhMessageSend = t.data, e.$apply();
                }, this), this.analysisSystemInfo();
            }
        } ]), s;
    }(r.default.mixin);
    exports.default = s;
}();