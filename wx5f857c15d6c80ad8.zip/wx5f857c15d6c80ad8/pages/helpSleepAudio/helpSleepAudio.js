!function() {
    "use strict";
    function t(t) {
        return t && t.__esModule ? t : {
            default: t
        };
    }
    function e(t) {
        return function() {
            var e = t.apply(this, arguments);
            return new Promise(function(t, n) {
                return function r(o, a) {
                    try {
                        var i = e[o](a), u = i.value;
                    } catch (t) {
                        return void n(t);
                    }
                    if (!i.done) return Promise.resolve(u).then(function(t) {
                        r("next", t);
                    }, function(t) {
                        r("throw", t);
                    });
                    t(u);
                }("next");
            });
        };
    }
    var n = Object.assign || function(t) {
        for (var e = 1; e < arguments.length; e++) {
            var n = arguments[e];
            for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (t[r] = n[r]);
        }
        return t;
    }, r = t(require("./../../npm/wepy/lib/wepy.js")), o = t(require("./../../api/index.js")), a = t(require("./../../tools/audioPlayer.js")), i = t(require("./../../tools/event.js")), u = require("./../../tools/common.js"), s = require("./../../tools/utility.js");
    Page({
        data: {
            userInfo: {},
            audioList: [],
            curAudioIndex: -1,
            currentProgress: 0,
            isNotBad: !0
        },
        getUserInfo: function() {
            this.setData({
                userInfo: r.default.$instance.globalData.userInfo
            });
        },
        getAudioList: function() {
            var t = e(regeneratorRuntime.mark(function t() {
                var e;
                return regeneratorRuntime.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return t.next = 2, o.default.newIndex.queryMusicContent({
                            userId: this.data.userInfo.userId
                        });

                      case 2:
                        e = t.sent, this.setData({
                            audioList: e.data.list.map(function(t) {
                                return n({}, t, {
                                    location: (0, u.decodeLocation)(t.location),
                                    selected: !1
                                });
                            })
                        });

                      case 4:
                      case "end":
                        return t.stop();
                    }
                }, t, this);
            }));
            return function() {
                return t.apply(this, arguments);
            };
        }(),
        handlePlay: function(t, e, r) {
            var o = void 0, a = void 0;
            if (e ? (o = e, a = t) : (o = t.currentTarget.dataset.id, a = t.currentTarget.dataset.index), 
            a !== this.data.curAudioIndex) {
                (0, s.PROD_Collect)({
                    fid: "yiyuzycs_handlePlayHelpSleep",
                    params: {
                        audioId: o
                    }
                });
                var i = this.data.audioList.map(function(t) {
                    return n({}, t, {
                        selected: t.id === o
                    });
                });
                this.setData({
                    audioList: i,
                    curAudioTitle: this.data.audioList[a].title,
                    curAudioIndex: a
                }), this.startPlay(a);
            }
        },
        startPlay: function() {
            var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0;
            console.log(this.data.audioList);
            var e = this.data.audioList.map(function(t) {
                return {
                    location: t.location,
                    title: t.title,
                    desc: t.title,
                    playProgress: 0
                };
            }), n = {
                list: e,
                index: t,
                productId: 0,
                contentId: 0,
                productType: 30
            };
            a.default.init(n);
        },
        eventOn: function() {
            var t = this;
            i.default.on("onPlay", function() {
                t.setData({
                    currentProgress: 0,
                    isNotBad: !0
                });
            }, this), i.default.on("onPlayIngTime", function() {
                t.setData({
                    currentProgress: Math.ceil(a.default.getCurrentTime() ? a.default.getCurrentTime() : t.data.currentProgress)
                });
            }, this), i.default.on("onShop", function() {
                t.setData({
                    isNotBad: !1
                });
            }, this), i.default.on("onEnded", e(regeneratorRuntime.mark(function e() {
                var n;
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        n = t.data, n.audioList, n.curAudioIndex, t.setData({
                            curAudioIndex: -1
                        });

                      case 2:
                      case "end":
                        return e.stop();
                    }
                }, e, t);
            })), this);
        },
        eventRemove: function() {
            console.log("移除"), a.default.getCurrentTime() && a.default.stop(), i.default.remove("onPlay", this), 
            i.default.remove("onPlayIngTime", this), i.default.remove("onEnded", this);
        },
        onLoad: function() {
            var t = e(regeneratorRuntime.mark(function t(e) {
                var n = e.progressId, r = e.planScheduleId;
                return regeneratorRuntime.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return this.setData({
                            progressId: n,
                            planScheduleId: r
                        }), t.next = 3, wx.$login.wait();

                      case 3:
                        this.getUserInfo(), this.getAudioList(), this.eventOn();

                      case 6:
                      case "end":
                        return t.stop();
                    }
                }, t, this);
            }));
            return function(e) {
                return t.apply(this, arguments);
            };
        }(),
        onReady: function() {},
        onShow: function() {
            this.getTabBar().setData({
                selected: 1
            });
        },
        onHide: function() {},
        onUnload: function() {
            this.eventRemove();
        },
        onPullDownRefresh: function() {},
        onReachBottom: function() {},
        onShareAppMessage: function() {
            return {
                title: "【减压助眠】10分钟快速入睡",
                path: "/pages/helpSleepAudio/helpSleepAudio"
            };
        },
        onPageScroll: function() {},
        onTabItemTap: function(t) {}
    });
}();