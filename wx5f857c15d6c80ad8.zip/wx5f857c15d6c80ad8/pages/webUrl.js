!function() {
    "use strict";
    function e(e) {
        return e && e.__esModule ? e : {
            default: e
        };
    }
    function t(e) {
        return function() {
            var t = e.apply(this, arguments);
            return new Promise(function(e, n) {
                return function r(o, i) {
                    try {
                        var a = t[o](i), u = a.value;
                    } catch (e) {
                        return void n(e);
                    }
                    if (!a.done) return Promise.resolve(u).then(function(e) {
                        r("next", e);
                    }, function(e) {
                        r("throw", e);
                    });
                    e(u);
                }("next");
            });
        };
    }
    function n(e, t) {
        if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
    }
    function r(e, t) {
        if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
        return !t || "object" != typeof t && "function" != typeof t ? e : t;
    }
    Object.defineProperty(exports, "__esModule", {
        value: !0
    });
    var o = function() {
        function e(e, t) {
            for (var n = 0; n < t.length; n++) {
                var r = t[n];
                r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), 
                Object.defineProperty(e, r.key, r);
            }
        }
        return function(t, n, r) {
            return n && e(t.prototype, n), r && e(t, r), t;
        };
    }(), i = e(require("./../npm/wepy/lib/wepy.js")), a = e(require("./../mixins/systemInfo.js")), u = e(require("./../mixins/componentsExtend.js")), f = e(require("./../tools/event.js")), c = function(e) {
        function i() {
            var e, t, o;
            n(this, i);
            for (var f = arguments.length, c = Array(f), s = 0; s < f; s++) c[s] = arguments[s];
            return t = o = r(this, (e = i.__proto__ || Object.getPrototypeOf(i)).call.apply(e, [ this ].concat(c))), 
            o.config = {
                navigationBarTitleText: "公众号",
                usingComponents: {
                    "c-login": "/components/CLogin/CLogin"
                }
            }, o.mixins = [ a.default, u.default ], o.data = {
                url: "https://mp.weixin.qq.com/s?__biz=MzIzNDY1MDY0Nw==&mid=2247484243&idx=5&sn=7813263830c64d4f39b662761e94bf5c&chksm=e8f26e2bdf85e73d5aef509c3f67d8248bf0050275640f1f2d0a553518533e5484b4acfc5f5c&token=1432586088&lang=zh_CN#rd",
                fromPay: !1
            }, o.methods = {}, r(o, t);
        }
        return function(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
            e.prototype = Object.create(t && t.prototype, {
                constructor: {
                    value: e,
                    enumerable: !1,
                    writable: !0,
                    configurable: !0
                }
            }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
        }(i, e), o(i, [ {
            key: "message",
            value: function(e) {
                console.log("----msg----", e);
            }
        }, {
            key: "renderConfig",
            value: function() {}
        }, {
            key: "renderData",
            value: function() {
                var e = t(regeneratorRuntime.mark(function e() {
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                          case "end":
                            return e.stop();
                        }
                    }, e, this);
                }));
                return function() {
                    return e.apply(this, arguments);
                };
            }()
        }, {
            key: "onLoad",
            value: function() {
                var e = t(regeneratorRuntime.mark(function e(t) {
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            return console.log(t), t.url && (this.url = t.url, this.$apply()), t.fromPay && (this.fromPay = JSON.parse(t.fromPay), 
                            this.$apply()), e.next = 5, wx.$login.wait();

                          case 5:
                            this.renderConfig(), this.renderData(), f.default.emitAll("isFollowGZH");

                          case 8:
                          case "end":
                            return e.stop();
                        }
                    }, e, this);
                }));
                return function(t) {
                    return e.apply(this, arguments);
                };
            }()
        }, {
            key: "onUnload",
            value: function() {
                !this.fromPay && f.default.emit("backFromGZH");
            }
        } ]), i;
    }(i.default.page);
    Page(require("./../npm/wepy/lib/wepy.js").default.$createPage(c, "pages/webUrl"));
}();