!function() {
    "use strict";
    function t(t) {
        return t && t.__esModule ? t : {
            default: t
        };
    }
    function e(t) {
        return function() {
            var e = t.apply(this, arguments);
            return new Promise(function(t, n) {
                return function a(o, i) {
                    try {
                        var r = e[o](i), s = r.value;
                    } catch (t) {
                        return void n(t);
                    }
                    if (!r.done) return Promise.resolve(s).then(function(t) {
                        a("next", t);
                    }, function(t) {
                        a("throw", t);
                    });
                    t(s);
                }("next");
            });
        };
    }
    var n = Object.assign || function(t) {
        for (var e = 1; e < arguments.length; e++) {
            var n = arguments[e];
            for (var a in n) Object.prototype.hasOwnProperty.call(n, a) && (t[a] = n[a]);
        }
        return t;
    }, a = t(require("./../../npm/wepy/lib/wepy.js")), o = t(require("./../../api/index.js")), i = t(require("./../../tools/actions.js")), r = t(require("./../../constant/appConfig.js")), s = t(require("./../../tools/audioPlayer.js")), u = t(require("./../../tools/event.js")), c = require("./../../tools/common.js"), l = require("./../../tools/utility.js"), d = r.default.subscribeTmplIds;
    Page({
        data: {
            population: 0,
            audioList: [],
            curAudioIndex: 0,
            isNowPlaying: !1,
            countDownList: [ {
                key: "20分钟",
                value: 1200
            }, {
                key: "30分钟",
                value: 1800
            }, {
                key: "45分钟",
                value: 2700
            }, {
                key: "60分钟",
                value: 3600
            }, {
                key: "90分钟",
                value: 4500
            } ],
            countDown: 1200,
            useSetCountDown: 1200,
            mark: 0,
            newMark: 0,
            direction: 0,
            showModal: !1
        },
        hadnlePauseOrPlay: function() {
            var t = this.data, e = t.isNowPlaying;
            t.audioList.length && (e ? s.default.stop() : this.startPlay());
        },
        startPlay: function() {
            var t = this.data.curAudioIndex, e = {
                list: this.data.audioList.map(function(t) {
                    return {
                        location: t.location,
                        title: t.title,
                        desc: t.title,
                        playProgress: 0,
                        id: t.id
                    };
                }),
                index: t,
                productId: 0,
                contentId: 0,
                productType: 30
            };
            s.default.init(e);
        },
        touchStart: function(t) {
            this.data.mark = this.data.newMark = t.touches[0].pageX;
        },
        touchMove: function(t) {
            this.data.newMark = t.touches[0].pageX;
            var e = this.data.newMark - this.data.mark;
            Math.abs(e) < 100 ? this.data.direction = 0 : (e > 0 && (this.data.direction = 1), 
            e < 0 && (this.data.direction = -1));
        },
        touchEnd: function() {
            var t = this.data, e = t.curAudioIndex, n = t.audioList;
            if (1 === this.data.direction) {
                var a = e - 1 < 0 ? n.length - 1 : e - 1;
                this.setData({
                    curAudioIndex: a
                }), this.startPlay();
            } else if (-1 === this.data.direction) {
                var o = e + 1 < n.length ? e + 1 : 0;
                this.setData({
                    curAudioIndex: o
                }), this.startPlay();
            }
            this.data.mark = this.data.newMark = this.data.direction = 0;
        },
        checktheEnd: function() {
            var t = this.data, e = t.countDown, n = t.useSetCountDown;
            e <= 0 && (s.default.stop(), this.setData({
                countDown: n
            }));
        },
        handleSetCountDown: function() {
            var t = this, e = this.data.countDownList;
            wx.showActionSheet({
                itemList: e.map(function(t) {
                    return t.key;
                }),
                success: function(n) {
                    var a = n.tapIndex;
                    t.setData({
                        useSetCountDown: e[a].value,
                        countDown: e[a].value
                    }), (0, l.PROD_Collect)({
                        fid: "set_count_down",
                        params: {
                            count_down: e[a].key
                        }
                    });
                },
                fail: function(t) {
                    console.log(t.errMsg);
                }
            });
        },
        openModal: function() {
            (0, l.PROD_Collect)({
                fid: "elastic_layer"
            }), this.setData({
                showModal: !0
            });
        },
        handleCloseModal: function() {
            this.setData({
                showModal: !1
            });
        },
        handleSubscribe: function() {
            var t = this;
            this.handleCloseModal(), wx.requestSubscribeMessage({
                tmplIds: [ d.daily_sleep_remind, d.night_sleep_remind, d.sleep_plan_notify ],
                success: function() {
                    var n = e(regeneratorRuntime.mark(function e(n) {
                        var a, r;
                        return regeneratorRuntime.wrap(function(e) {
                            for (;;) switch (e.prev = e.next) {
                              case 0:
                                for (r in a = [], n) "accept" === n[r] && a.push(r), "errMsg" !== r && (0, l.PROD_Collect)({
                                    fid: "message_push",
                                    params: {
                                        temid: r,
                                        type: n[r]
                                    }
                                });
                                if (!(a.length > 0)) {
                                    e.next = 6;
                                    break;
                                }
                                return e.next = 5, o.default.common.addMessageSubscribe({
                                    templateList: a,
                                    userId: t.data.userInfo.userId
                                });

                              case 5:
                                i.default.Toast.alert("订阅成功");

                              case 6:
                              case "end":
                                return e.stop();
                            }
                        }, e, t);
                    }));
                    return function(t) {
                        return n.apply(this, arguments);
                    };
                }(),
                fail: function(t) {
                    i.default.Toast.alert("订阅失败"), console.log(t);
                }
            });
        },
        jumpMainMiniprogram: function() {
            wx.navigateToMiniProgram({
                appId: "wx09148366103e6411",
                path: "/pages/index/index?origin=" + a.default.$instance.globalData.appConfig.source + "&goUrl=" + encodeURIComponent("/subPsychologicalTest/pages/testListPage/testListPage?id=43"),
                success: function(t) {
                    (0, l.PROD_Collect)({
                        fid: "jump_applet",
                        params: {
                            type: "success"
                        }
                    });
                },
                fail: function() {
                    (0, l.PROD_Collect)({
                        fid: "jump_applet",
                        params: {
                            type: "fail"
                        }
                    });
                }
            });
        },
        getShareStr: function() {
            var t = e(regeneratorRuntime.mark(function t() {
                var e;
                return regeneratorRuntime.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return t.next = 2, o.default.common.queryContextCommonConfig({
                            subType: "sleep-message-context-list"
                        });

                      case 2:
                        e = t.sent, this.setData({
                            shareStrArr: JSON.parse(e.data.context)
                        });

                      case 4:
                      case "end":
                        return t.stop();
                    }
                }, t, this);
            }));
            return function() {
                return t.apply(this, arguments);
            };
        }(),
        selectLoginUserCount: function() {
            var t = e(regeneratorRuntime.mark(function t() {
                var e;
                return regeneratorRuntime.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return t.next = 2, o.default.helpSleep.selectLoginUserCount();

                      case 2:
                        e = t.sent, this.setData({
                            population: e.data
                        });

                      case 4:
                      case "end":
                        return t.stop();
                    }
                }, t, this);
            }));
            return function() {
                return t.apply(this, arguments);
            };
        }(),
        queryContentInfoList: function() {
            var t = e(regeneratorRuntime.mark(function t() {
                var e;
                return regeneratorRuntime.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return t.next = 2, o.default.helpSleep.queryContentInfoList();

                      case 2:
                        e = t.sent, this.setData({
                            audioList: e.data.list.map(function(t) {
                                return n({}, t, {
                                    location: (0, c.decodeLocation)(t.location)
                                });
                            }),
                            curAudioIndex: e.data.list.length >> 1
                        });

                      case 4:
                      case "end":
                        return t.stop();
                    }
                }, t, this);
            }));
            return function() {
                return t.apply(this, arguments);
            };
        }(),
        onLoad: function() {
            var t = e(regeneratorRuntime.mark(function t(e) {
                return regeneratorRuntime.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return t.next = 2, wx.$login.wait();

                      case 2:
                        this.setData({
                            userInfo: a.default.$instance.globalData.userInfo
                        }), this.eventOn(), this.selectLoginUserCount(), this.queryContentInfoList(), this.getShareStr();

                      case 7:
                      case "end":
                        return t.stop();
                    }
                }, t, this);
            }));
            return function(e) {
                return t.apply(this, arguments);
            };
        }(),
        onReady: function() {},
        onShow: function() {},
        onHide: function() {},
        onUnload: function() {
            this.eventRemove();
        },
        onPullDownRefresh: function() {},
        onReachBottom: function() {},
        onShareAppMessage: function() {
            (0, l.PROD_Collect)({
                fid: "share_friends"
            });
            var t = this.data.shareStrArr;
            return {
                title: t[Math.floor(Math.random() * t.length)],
                path: "/pages/index/index",
                imageUrl: "https://mmbiz.qpic.cn/sz_mmbiz_png/UONHPDzL4Bnx2NJ5zSrjb4qNMMefOEHXTUSlf2a8p6NATgpiaFVMT1X2JsFv8icDr7Y2KjicMPLibQWIqdC37s8DxQ/0?wx_fmt=png"
            };
        },
        onPageScroll: function() {},
        onTabItemTap: function(t) {},
        eventOn: function() {
            var t = this;
            u.default.on("onPlay", function() {
                t.setData({
                    isNowPlaying: !0
                });
            }, this), u.default.on("onPlayIngTime", (0, l.throttle)(function() {
                t.setData({
                    countDown: --t.data.countDown
                }), t.checktheEnd();
            }, 1e3), this), u.default.on("onShop", function() {
                t.setData({
                    isNowPlaying: !1
                });
            }, this), u.default.on("onEnded", e(regeneratorRuntime.mark(function e() {
                var n, a, o, i;
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        n = t.data, a = n.audioList, o = n.curAudioIndex, i = o + 1 < a.length ? o + 1 : 0, 
                        t.setData({
                            curAudioIndex: i
                        }), t.startPlay(), (0, l.PROD_Collect)({
                            fid: "switch_function_trigger",
                            params: {
                                id: a[o].id
                            }
                        });

                      case 5:
                      case "end":
                        return e.stop();
                    }
                }, e, t);
            })), this);
        },
        eventRemove: function() {
            u.default.remove("onPlay", this), u.default.remove("onPlayIngTime", this), u.default.remove("onShop", this), 
            u.default.remove("onEnded", this);
        }
    });
}();