!function() {
    "use strict";
    function e(e) {
        return e && e.__esModule ? e : {
            default: e
        };
    }
    function t(e) {
        return function() {
            var t = e.apply(this, arguments);
            return new o.default(function(e, n) {
                return function a(r, i) {
                    try {
                        var s = t[r](i), u = s.value;
                    } catch (e) {
                        return void n(e);
                    }
                    if (!s.done) return o.default.resolve(u).then(function(e) {
                        a("next", e);
                    }, function(e) {
                        a("throw", e);
                    });
                    e(u);
                }("next");
            });
        };
    }
    Object.defineProperty(exports, "__esModule", {
        value: !0
    });
    var n = Object.assign || function(e) {
        for (var t = 1; t < arguments.length; t++) {
            var n = arguments[t];
            for (var a in n) Object.prototype.hasOwnProperty.call(n, a) && (e[a] = n[a]);
        }
        return e;
    }, a = function() {
        function e(e, t) {
            for (var n = 0; n < t.length; n++) {
                var a = t[n];
                a.enumerable = a.enumerable || !1, a.configurable = !0, "value" in a && (a.writable = !0), 
                Object.defineProperty(e, a.key, a);
            }
        }
        return function(t, n, a) {
            return n && e(t.prototype, n), a && e(t, a), t;
        };
    }(), r = e(require("./npm/wepy/lib/wepy.js"));
    require("./npm/wepy-async-function/index.js");
    var o = e(require("./npm/promise-polyfill/promise.js")), i = e(require("./tools/actions.js")), s = e(require("./tools/storage.js")), u = e((require("./tools/getParams.js"), 
    require("./tools/login/index.js"))), l = e(require("./tools/event.js"));
    require("./tools/util.js");
    var c = e(require("./constant/appConfig.js")), f = e(require("./api/index.js"));
    require("./tools/wxpage/lib/component.js"), require("./collectConfig.js");
    var p = (e(require("./pagesComponents/xltjSearch/constInitData.js")), require("./tools/utility.js")), d = function(e) {
        function r() {
            !function(e, t) {
                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
            }(this, r);
            var e = function(e, t) {
                if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                return !t || "object" != typeof t && "function" != typeof t ? e : t;
            }(this, (r.__proto__ || Object.getPrototypeOf(r)).call(this));
            return e.config = {
                pages: [ "pages/index/index", "pages/helpSleepAudio/helpSleepAudio", "pages/webUrl" ],
                tabBar: {
                    custom: !0,
                    selectedColor: "#ff4f4f",
                    color: "#666666",
                    list: [ {
                        pagePath: "pages/index/index",
                        text: "测试",
                        iconPath: "images/tab/index.png",
                        selectedIconPath: "images/tab/indexA.png"
                    }, {
                        pagePath: "pages/helpSleepAudio/helpSleepAudio",
                        text: "减压助眠",
                        iconPath: "images/tab/index.png",
                        selectedIconPath: "images/tab/indexA.png"
                    } ]
                },
                window: {
                    backgroundColor: "#F2F3F6",
                    backgroundTextStyle: "dark",
                    navigationBarBackgroundColor: "#FFFFFF",
                    navigationBarTitleText: "WeChat",
                    navigationBarTextStyle: "black"
                },
                networkTimeout: {
                    request: 3e4,
                    downloadFile: 2e4
                },
                requiredBackgroundModes: [ "audio" ]
            }, e.globalData = {
                project: "wendaoclient",
                clientInfo: null,
                token: "",
                sessionKey: "",
                userInfo: {},
                isLoged: !1,
                authorizePhone: !1,
                system: {},
                bgAudioData: {
                    bgAuMg: {},
                    list: [],
                    currentIndex: 0,
                    productId: 0,
                    contentId: 0,
                    currentTime: 0,
                    speed: 1,
                    type: 0
                },
                friendJoin: !1,
                followGZH: !1,
                gzhMessageSend: !1
            }, e.use("requestfix"), e.use("promisify"), e;
        }
        return function(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
            e.prototype = Object.create(t && t.prototype, {
                constructor: {
                    value: e,
                    enumerable: !1,
                    writable: !0,
                    configurable: !0
                }
            }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
        }(r, e), a(r, [ {
            key: "onLaunch",
            value: function() {
                var e = t(regeneratorRuntime.mark(function e(a) {
                    var r, o = this;
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            if (wx.onAppRoute(function(e) {
                                var t = e.path, n = e.query, a = e.page.window.navigationBarTitleText;
                                (0, p.PROD_Collect)({
                                    fid: "yiyuzycs_browsePage",
                                    m: "p",
                                    params: {
                                        path: t,
                                        query: n,
                                        navigationBarTitleText: a
                                    }
                                });
                            }), console.log("----app.js-----", a), l.default.on("updateUserInfoSuccess", function(e) {
                                o.globalData.userInfo = n({}, o.globalData.userInfo, e);
                            }, this), l.default.on("updatePhoneSuccess", function(e) {
                                o.globalData.userInfo = n({}, o.globalData.userInfo, e);
                            }, this), (!a.mode || "singlePage" == a.mode) && a.mode) {
                                e.next = 21;
                                break;
                            }
                            return this.setNowTimeStorage(), this.globalData.appConfig = c.default, wx.getSystemInfo({
                                success: function(e) {
                                    o.globalData.system = e;
                                }
                            }), this.globalData.launchInfo = a, this.globalData.scene = a.scene, u.default.extendLoginSuccessAfter = function() {
                                var e = t(regeneratorRuntime.mark(function e(t) {
                                    return regeneratorRuntime.wrap(function(e) {
                                        for (;;) switch (e.prev = e.next) {
                                          case 0:
                                            o.globalData.token = t.data.token, o.globalData.sessionKey = t.data.sessionKey, 
                                            o.globalData.userInfo = t.data.userInfo || {}, o.globalData.isLoged = 0 == t.data.createStatus, 
                                            o.globalData.authorizePhone = !(!t.data.userInfo || !t.data.userInfo.phone), i.default.Load.hide(), 
                                            t.data.userInfo ? s.default.setSync("showToLoginTip", !1) : s.default.setSync("showToLoginTip", !0);

                                          case 7:
                                          case "end":
                                            return e.stop();
                                        }
                                    }, e, o);
                                }));
                                return function(t) {
                                    return e.apply(this, arguments);
                                };
                            }(), e.next = 13, (0, u.default)({
                                hideLoading: !0
                            });

                          case 13:
                            this.getMessageCount(), this.getPublicSubscribeInfo(), this.getSubTemp(), (r = s.default.getSync("messageCount")) > 0 && wx.setTabBarBadge({
                                index: 4,
                                text: "" + r
                            }), this.createBgAudio(), e.next = 22;
                            break;

                          case 21:
                            this.globalData.friendJoin = !0;

                          case 22:
                          case "end":
                            return e.stop();
                        }
                    }, e, this);
                }));
                return function(t) {
                    return e.apply(this, arguments);
                };
            }()
        }, {
            key: "getMessageCount",
            value: function() {
                var e = t(regeneratorRuntime.mark(function e() {
                    var t;
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            return e.next = 2, f.default.message.count();

                          case 2:
                            (t = e.sent) && 0 == t.rcode ? s.default.setSync("messageCount", t.data) : i.default.Toast.alert("数据获取失败，请稍后重试");

                          case 4:
                          case "end":
                            return e.stop();
                        }
                    }, e, this);
                }));
                return function() {
                    return e.apply(this, arguments);
                };
            }()
        }, {
            key: "getPublicSubscribeInfo",
            value: function() {
                var e = t(regeneratorRuntime.mark(function e() {
                    var t;
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            return e.next = 2, f.default.publicSubscribe.getPublicSubscribeInfo();

                          case 2:
                            (t = e.sent) && 0 == t.rcode ? this.globalData.followGZH = t.data : i.default.Toast.alert("数据获取失败，请稍后重试");

                          case 4:
                          case "end":
                            return e.stop();
                        }
                    }, e, this);
                }));
                return function() {
                    return e.apply(this, arguments);
                };
            }()
        }, {
            key: "getSubTemp",
            value: function() {
                var e = t(regeneratorRuntime.mark(function e() {
                    var t;
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            return e.next = 2, f.default.publicSubscribe.getSubTemp();

                          case 2:
                            (t = e.sent) && 0 == t.rcode ? (console.log("----是否开启了公众号消息通知----", t), this.globalData.gzhMessageSend = t.data, 
                            "" === s.default.getSync("showGZHmsgTip_mine") && (t.data ? (s.default.setSync("showGZHmsgTip_mine", !1), 
                            s.default.setSync("showGZHmsgTip_topTip", !1)) : (s.default.setSync("showGZHmsgTip_mine", !0), 
                            s.default.setSync("showGZHmsgTip_topTip", !0)))) : i.default.Toast.alert("数据获取失败，请稍后重试");

                          case 4:
                          case "end":
                            return e.stop();
                        }
                    }, e, this);
                }));
                return function() {
                    return e.apply(this, arguments);
                };
            }()
        }, {
            key: "setNowTimeStorage",
            value: function() {
                var e = s.default.getSync("lastDay");
                if (e) {
                    var t = new Date().getDate();
                    t != e && (s.default.setSync("lastDay", t), s.default.removeSync("myVisitProductIds"), 
                    s.default.removeSync("myVisitContentIds"));
                } else {
                    var n = new Date().getDate();
                    s.default.setSync("lastDay", n);
                }
            }
        }, {
            key: "createBgAudio",
            value: function() {
                this.globalData.bgAudioData.bgAuMg = wx.getBackgroundAudioManager();
            }
        } ]), r;
    }(r.default.app);
    App(require("./npm/wepy/lib/wepy.js").default.$createApp(d, {
        noPromiseAPI: [ "createSelectorQuery" ]
    }));
}();