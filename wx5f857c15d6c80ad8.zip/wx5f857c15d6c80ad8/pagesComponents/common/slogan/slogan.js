!function() {
    "use strict";
    function e(e) {
        return e && e.__esModule ? e : {
            default: e
        };
    }
    var a = e(require("./../../../npm/wepy/lib/wepy.js")), t = e(require("./../../../tools/actions.js")), s = e(require("./../../../tools/storage.js")), n = require("./../../../tools/config.js");
    Component.C({
        properties: {
            haveSlogan: {
                type: Boolean,
                value: !1
            },
            isTransparent: {
                type: Boolean,
                value: !1
            }
        },
        data: {
            envVersion: "release",
            versionType: {
                develop: {
                    key: "开发版",
                    value: "https://" + n.DomainName.UAT
                },
                trial: {
                    key: "体验版",
                    value: "https://" + n.DomainName.UAT
                },
                release: {
                    key: "正式版",
                    value: "https://" + n.DomainName.PROD
                }
            },
            showMask: !1,
            url: ""
        },
        ready: function() {
            var e = wx.getAccountInfoSync();
            this.setData({
                envVersion: e.miniProgram.envVersion
            });
        },
        methods: {
            handleToHGTX: function() {
                wx.navigateToMiniProgram({
                    appId: "wx5b7002ba3a006769",
                    path: "/pages/index/index?origin=" + a.default.$instance.globalData.appConfig.source
                });
            },
            changeUrl: function() {
                var e = s.default.getSync("BaseRequestUrl");
                "正式版" != this.data.versionType[this.data.envVersion].key && (e ? (s.default.removeSync("BaseRequestUrl"), 
                t.default.Model.alert("当前环境已切换为正式环境，重新进入小程序生效（可关闭调试模式）。")) : this.setData({
                    showMask: !0
                }));
            },
            handleInput: function(e) {
                this.setData({
                    url: e.detail.value
                });
            },
            handleConfirm: function() {
                "" == this.data.url ? (s.default.setSync("BaseRequestUrl", this.data.versionType[this.data.envVersion].value), 
                t.default.Model.alert("当前环境已切换为测试环境，请打开调试模式并重新进入小程序生效。"), this.setData({
                    url: "",
                    showMask: !1
                })) : /(25[0-5]|2[0-4]\d|[0-1]\d{2}|[1-9]?\d)\.(25[0-5]|2[0-4]\d|[0-1]\d{2}|[1-9]?\d)\.(25[0-5]|2[0-4]\d|[0-1]\d{2}|[1-9]?\d)\.(25[0-5]|2[0-4]\d|[0-1]\d{2}|[1-9]?\d)/g.test(this.data.url) ? (s.default.setSync("BaseRequestUrl", "https://" + this.data.url + ":443"), 
                t.default.Model.alert("当前环境已切换为开发环境，请打开调试模式并重新进入小程序生效。"), this.setData({
                    url: "",
                    showMask: !1
                })) : t.default.Toast.alert("检查Ip地址");
            },
            handleCancel: function() {
                this.setData({
                    url: "",
                    showMask: !1
                });
            }
        }
    });
}();