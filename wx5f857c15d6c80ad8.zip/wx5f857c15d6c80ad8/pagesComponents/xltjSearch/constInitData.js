!function() {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: !0
    });
    exports.default = {
        keyword: "",
        historyLabel: [],
        findLabel: [ "压力", "放松", "疲劳", "情绪", "焦虑", "担心", "亲人离世", "过度悲伤", "孤独", "寂寞", "考前焦虑", "后悔", "遗憾", "错误的爱", "失恋离婚", "婆媳矛盾", "自信", "自卑", "拖延症", "迷茫", "选择困难", "敏感脆弱", "社交恐惧", "怕老板、怕领导、怕权威" ],
        choseQuestionInfo: {},
        choseQuestionIndex: 0
    };
}();