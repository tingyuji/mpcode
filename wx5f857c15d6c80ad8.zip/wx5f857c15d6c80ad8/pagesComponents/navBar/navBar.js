!function() {
    "use strict";
    Component({
        properties: {
            navigationBarTitleText: {
                type: String,
                value: "自定义导航名字"
            },
            navigateBack: {
                type: Boolean,
                value: !1
            }
        },
        data: {
            navHeight: 0,
            statusBarHeight: 0
        },
        methods: {
            getNavigationHeight: function() {
                var t = wx.getSystemInfoSync(), a = wx.getMenuButtonBoundingClientRect(), e = 2 * (a.top - t.statusBarHeight) + a.height + t.statusBarHeight;
                this.setData({
                    navHeight: e,
                    statusBarHeight: t.statusBarHeight
                });
            },
            handleNavigateBack: function() {
                wx.navigateBack();
            }
        },
        created: function() {},
        ready: function() {
            this.getNavigationHeight();
        }
    });
}();