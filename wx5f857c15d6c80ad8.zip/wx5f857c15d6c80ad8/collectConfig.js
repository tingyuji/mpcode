!function() {
    "use strict";
    function e(e) {
        return e && e.__esModule ? e : {
            default: e
        };
    }
    var n = e(require("./npm/wepy/lib/wepy.js")), t = require("./npm/@clevok/collect-util/lib/index.js"), u = e(require("./tools/request.js"));
    (0, t.SetConfig)({
        appKey: "yiyuzycs",
        getUserInfo: function() {
            return n.default.$instance.globalData.userInfo;
        },
        getVersion: function() {
            return n.default.$instance.globalData.version;
        },
        getRequest: function(e, n) {
            var t = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
            return t = Object.assign(t, {
                noToken: !0
            }), (0, u.default)(e, n, t);
        }
    });
}();