!function() {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: !0
    }), exports.queryPlanFiveDiaryLineChart = exports.refreshNewPlanTask = exports.queryPlanFiveDiaryList = exports.queryNewPlanTaskData = exports.updateMessageScribeRead = exports.queryUserHasMessage = exports.queryUserIsReadMessage = exports.queryUserIsDoPaper = exports.queryMusicContent = exports.queryOneMusicContent = exports.queryUserPlanInfo = exports.queryTaskInfos = exports.getOpenAndUseCount = exports.getPlanInfo = exports.getList = exports.getIndexTheme = exports.getIndexWiki = exports.getIndexQuestion = exports.getIndexPaper = exports.getIndexCureQuatations = exports.getIndexHypnosis = void 0;
    var e = function(e) {
        return e && e.__esModule ? e : {
            default: e
        };
    }(require("./../tools/request.js"));
    exports.getIndexHypnosis = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/course/getIndexHypnosis.do", t, n);
    }, exports.getIndexCureQuatations = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/cureQuatations/getIndexCureQuatations.do", t, n);
    }, exports.getIndexPaper = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/paper/getIndexPaper.do", t, n);
    }, exports.getIndexQuestion = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/question/getIndexQuestion.do", t, n);
    }, exports.getIndexWiki = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/wiki/getIndexWiki.do", t, n);
    }, exports.getIndexTheme = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/theme/getIndexTheme.do", t, n);
    }, exports.getList = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/banner/getList.do", t, n);
    }, exports.getPlanInfo = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/firstPageCourse/getPlanInfoNew.do", t, n);
    }, exports.getOpenAndUseCount = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/api/planOrder/getOpenAndUseCount.do", t, n);
    }, exports.queryTaskInfos = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/api/task/queryTaskInfos.do", t, n);
    }, exports.queryUserPlanInfo = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return t.source = "wendao", (0, e.default)("/api/planCommon/queryUserPlanInfo.do", t, n);
    }, exports.queryOneMusicContent = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return t.source = "wendao", (0, e.default)("/api/queryOneMusicContent.do", t, n);
    }, exports.queryMusicContent = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return t.source = "wendao", (0, e.default)("/api/queryMusicContent.do", t, n);
    }, exports.queryUserIsDoPaper = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return t.source = "wendao", (0, e.default)("/api/paper/queryUserIsDoPaper.do", t, n);
    }, exports.queryUserIsReadMessage = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return t.source = "wendao", (0, e.default)("/api/messageSubscribe/queryUserIsReadMessage.do", t, n);
    }, exports.queryUserHasMessage = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/api/messageSubscribe/queryUserHasMessage.do", t, n);
    }, exports.updateMessageScribeRead = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return t.source = "wendao", (0, e.default)("/api/messageSubscribe/updateMessageScribeRead.do", t, n);
    }, exports.queryNewPlanTaskData = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return t.source = "wendao", (0, e.default)("/api/planTask/queryNewPlanTaskData.do", t, n);
    }, exports.queryPlanFiveDiaryList = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/api/planTask/queryPlanFiveDiaryList.do", t, n);
    }, exports.refreshNewPlanTask = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/api/planTask/refreshNewPlanTask.do", t, n);
    }, exports.queryPlanFiveDiaryLineChart = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return t.source = "wendao", (0, e.default)("/api/planTask/queryPlanFiveDiaryLineChart.do", t, n);
    };
}();