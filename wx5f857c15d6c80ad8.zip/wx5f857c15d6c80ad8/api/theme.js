!function() {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: !0
    }), exports.getCourseByType = exports.getEAByType = exports.getWiki = exports.getQuestions = exports.getPaper = exports.getDetail = void 0;
    var e = function(e) {
        return e && e.__esModule ? e : {
            default: e
        };
    }(require("./../tools/request.js"));
    exports.getDetail = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return t.source = "wendao", (0, e.default)("/theme/getDetail.do", t, o);
    }, exports.getPaper = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/theme/getPaper.do", t, o);
    }, exports.getQuestions = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/theme/getQuestions.do", t, o);
    }, exports.getWiki = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/theme/getWiki.do", t, o);
    }, exports.getEAByType = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/theme/getEAByType.do", t, o);
    }, exports.getCourseByType = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/theme/getCourseByType.do", t, o);
    };
}();