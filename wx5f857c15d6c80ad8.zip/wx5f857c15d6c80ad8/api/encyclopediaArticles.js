!function() {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: !0
    }), exports.getNewArticles = exports.getRandom = exports.getShareImage = exports.getEncyclopediaArticles = exports.getArticles = exports.getEncyclopedia = void 0;
    var e = function(e) {
        return e && e.__esModule ? e : {
            default: e
        };
    }(require("./../tools/request.js"));
    exports.getEncyclopedia = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/encyclopediaArticles/getEncyclopedia.do", t, o);
    }, exports.getArticles = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/encyclopediaArticles/getArticles.do", t, o);
    }, exports.getEncyclopediaArticles = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/encyclopediaArticles/getEncyclopediaArticles.do", t, o);
    }, exports.getShareImage = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/api/encyclopediaArticles/getShareImage.do", t, o);
    }, exports.getRandom = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/encyclopediaArticles/getRandom.do", t, o);
    }, exports.getNewArticles = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/encyclopediaArticles/getNewArticles.do", t, o);
    };
}();