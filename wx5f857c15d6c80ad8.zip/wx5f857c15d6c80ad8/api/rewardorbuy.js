!function() {
    "use strict";
    function e(e) {
        return e && e.__esModule ? e : {
            default: e
        };
    }
    Object.defineProperty(exports, "__esModule", {
        value: !0
    }), exports.getUserAvatarListByCourseId = exports.onlineFormBack = exports.onlineFormComplate = exports.prePayOnlineForm = exports.orderCourse = exports.rewardCourse = void 0;
    var r = e(require("./../npm/wepy/lib/wepy.js")), o = e(require("./../tools/request.js"));
    exports.rewardCourse = function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, o.default)("/api/pay/rewardCourse.do", e, r);
    }, exports.orderCourse = function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, o.default)("/api/pay/orderCourse.do", e, r);
    }, exports.prePayOnlineForm = function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return e = Object.assign(e, {
            source: r.default.$instance.globalData.appConfig.source
        }), (0, o.default)("/api/pay/prePayOnlineForm.do", e, t);
    }, exports.onlineFormComplate = function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, o.default)("/api/pay/onlineFormComplate.do", e, r);
    }, exports.onlineFormBack = function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, o.default)("/api/payBack/onlineFormBack.do", e, r);
    }, exports.getUserAvatarListByCourseId = function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, o.default)("/api/courseInfo/getUserAvatarListByCourseId.do", e, r);
    };
}();