!function() {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: !0
    }), exports.updateTodayProverbsLikes = exports.getOneTodayProverbs = exports.getOrderStatus = exports.queryPlanStatus = exports.uploadToken = exports.addMessageSubscribe = exports.queryContextCommonConfig = void 0;
    var e = function(e) {
        return e && e.__esModule ? e : {
            default: e
        };
    }(require("./../tools/request.js"));
    exports.queryContextCommonConfig = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/api/contextCommonConfig/queryContextCommonConfig.do", t, o);
    }, exports.addMessageSubscribe = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/api/messageSubscribe/addMessageSubscribe.do", t, o);
    }, exports.uploadToken = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/uploadToken.do", t, o);
    }, exports.queryPlanStatus = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return t.channelId = 1, (0, e.default)("/api/planCommon/queryPlanStatus.do", t, o);
    }, exports.getOrderStatus = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/api/planOrder/getOrderStatus.do", t, o);
    }, exports.getOneTodayProverbs = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/api/planTask/getOneTodayProverbs.do", t, o);
    }, exports.updateTodayProverbsLikes = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/api/planTask/updateTodayProverbsLikes.do", t, o);
    };
}();