!function() {
    "use strict";
    function e(e) {
        return e && e.__esModule ? e : {
            default: e
        };
    }
    Object.defineProperty(exports, "__esModule", {
        value: !0
    }), exports.getMemberInfo = exports.subscribeMsg = exports.publicSubscribe = exports.updateUserInfo = exports.updatePhone = void 0;
    var t = e(require("./../npm/wepy/lib/wepy.js")), o = e(require("./../tools/request.js"));
    exports.updatePhone = function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return e = Object.assign(e, {
            source: t.default.$instance.globalData.appConfig.source
        }), (0, o.default)("/commonUpdatePhone.do", e, r);
    }, exports.updateUserInfo = function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return e = Object.assign(e, {
            origin: t.default.$instance.globalData.appConfig.source
        }), (0, o.default)("/api/updateUserInfo.do", e, r);
    }, exports.publicSubscribe = function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, o.default)("/api/publicSubscribe/getSubscribeInfo.do", e, t);
    }, exports.subscribeMsg = function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, o.default)("/api/publicSubscribe/subscribeMsg.do", e, t);
    }, exports.getMemberInfo = function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, o.default)("/api/getMemberInfo.do", e, t);
    };
}();