!function() {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: !0
    }), exports.getGiveBuyId = exports.orderGive = exports.orderPaper = exports.rewardQuestionAnswer = exports.rewardAnswer = void 0;
    var e = function(e) {
        return e && e.__esModule ? e : {
            default: e
        };
    }(require("./../tools/request.js"));
    exports.rewardAnswer = function() {
        var r = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/api/pay/rewardAnswer.do", r, t);
    }, exports.rewardQuestionAnswer = function() {
        var r = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/api/pay/rewardQuestionAnswer.do", r, t);
    }, exports.orderPaper = function() {
        var r = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/api/pay/orderPaper.do", r, t);
    }, exports.orderGive = function() {
        var r = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/api/pay/orderGive.do", r, t);
    }, exports.getGiveBuyId = function() {
        var r = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/api/giveBuy/getGiveBuyId.do", r, t);
    };
}();