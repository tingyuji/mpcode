!function() {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: !0
    }), exports.addInfo = exports.getDraft = exports.testText = exports.getMyConsults = exports.addPointTime = void 0;
    var t = function(t) {
        return t && t.__esModule ? t : {
            default: t
        };
    }(require("./../tools/request.js"));
    exports.addPointTime = function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, t.default)("/api/consult/addPointTime.do", e, o);
    }, exports.getMyConsults = function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, t.default)("/api/consult/getMyConsults.do", e, o);
    }, exports.testText = function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, t.default)("/api/consult/testText.do", e, o);
    }, exports.getDraft = function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, t.default)("/api/consult/getDraft.do", e, o);
    }, exports.addInfo = function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, t.default)("/api/consult/addInfo.do", e, o);
    };
}();