!function() {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: !0
    }), exports.paperIndexList = exports.getMyPapers = exports.submitSubjects = exports.getRecommendPapersPage = exports.getSubjects = exports.getDetail = exports.getClassify = exports.getRecommendPapers = exports.getPageByClassifyId = void 0;
    var e = function(e) {
        return e && e.__esModule ? e : {
            default: e
        };
    }(require("./../tools/request.js"));
    exports.getPageByClassifyId = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/paper/getPageByClassifyId.do", t, r);
    }, exports.getRecommendPapers = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/paper/getRecommendPapers.do", t, r);
    }, exports.getClassify = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/paper/getClassify.do", t, r);
    }, exports.getDetail = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/paper/getDetail.do", t, r);
    }, exports.getSubjects = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/api/paper/getSubjects.do", t, r);
    }, exports.getRecommendPapersPage = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/paper/getRecommendPapersPage.do", t, r);
    }, exports.submitSubjects = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/api/paper/submitSubjects.do", t, r);
    }, exports.getMyPapers = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/api/paper/getMyPapers.do", t, r);
    }, exports.paperIndexList = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/paper/paperIndexList.do", t, r);
    };
}();