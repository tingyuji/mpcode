!function() {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: !0
    }), exports.increaseDownloadNum = exports.goodSentenceLike = exports.getNewGoodSentenceList = exports.getGoodSentenceById = exports.getGoodSentenceList = void 0;
    var e = function(e) {
        return e && e.__esModule ? e : {
            default: e
        };
    }(require("./../tools/request.js"));
    exports.getGoodSentenceList = function() {
        var o = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/api/goodSentence/getGoodSentenceList.do", o, t);
    }, exports.getGoodSentenceById = function() {
        var o = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/api/goodSentence/getGoodSentenceById.do", o, t);
    }, exports.getNewGoodSentenceList = function() {
        var o = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/goodSentence/getNewGoodSentenceList.do", o, t);
    }, exports.goodSentenceLike = function() {
        var o = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/api/goodSentence/goodSentenceLike.do", o, t);
    }, exports.increaseDownloadNum = function() {
        var o = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/api/goodSentence/increaseDownloadNum.do", o, t);
    };
}();