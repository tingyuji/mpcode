!function() {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: !0
    }), exports.add = exports.use = exports.getQCoupons = void 0;
    var e = function(e) {
        return e && e.__esModule ? e : {
            default: e
        };
    }(require("./../tools/request.js"));
    exports.getQCoupons = function() {
        var o = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/qCoupon/getQCoupons.do", o, t);
    }, exports.use = function() {
        var o = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/api/qCoupon/use.do", o, t);
    }, exports.add = function() {
        var o = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/api/qCoupon/add.do", o, t);
    };
}();