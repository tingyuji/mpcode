!function() {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: !0
    }), exports.getUserCourseByCourseId = exports.getUserCourseDTO = void 0;
    var e = function(e) {
        return e && e.__esModule ? e : {
            default: e
        };
    }(require("./../tools/request.js"));
    exports.getUserCourseDTO = function() {
        var r = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/api/userCourse/getUserCourseDTO.do", r, o);
    }, exports.getUserCourseByCourseId = function() {
        var r = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/userCourse/getUserCourseByCourseId.do", r, o);
    };
}();