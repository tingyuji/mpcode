!function() {
    "use strict";
    function e(e) {
        return e && e.__esModule ? e : {
            default: e
        };
    }
    Object.defineProperty(exports, "__esModule", {
        value: !0
    }), exports.createUserInfo = exports.updateUserInfo = exports.login = exports.loginByCode = void 0;
    var o = e(require("./../npm/wepy/lib/wepy.js")), t = e(require("./../tools/request.js"));
    exports.loginByCode = function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return e = Object.assign(e, {
            source: o.default.$instance.globalData.appConfig.source
        }), (0, t.default)("/commonLoginByCode.do", e, n);
    }, exports.login = function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, t.default)("/login.do", e, o);
    }, exports.updateUserInfo = function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, t.default)("/updateUserInfo.do", e, o);
    }, exports.createUserInfo = function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return e = Object.assign(e, {
            source: o.default.$instance.globalData.appConfig.source
        }), (0, t.default)("/commonCreateUserInfo.do", e, n);
    };
}();