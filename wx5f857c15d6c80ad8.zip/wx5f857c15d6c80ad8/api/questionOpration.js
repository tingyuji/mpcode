!function() {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: !0
    }), exports.userAnswerLikeOpration = exports.questionAnswerLikeOpration = exports.questionShareOpration = exports.questionCollectedOpration = exports.questionLikeOpration = void 0;
    var e = function(e) {
        return e && e.__esModule ? e : {
            default: e
        };
    }(require("./../tools/request.js"));
    exports.questionLikeOpration = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/api/questionOpration/questionLikeOpration.do", t, o);
    }, exports.questionCollectedOpration = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/api/questionOpration/questionCollectedOpration.do", t, o);
    }, exports.questionShareOpration = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/api/questionOpration/questionShareOpration.do", t, o);
    }, exports.questionAnswerLikeOpration = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/api/questionOpration/questionAnswerLikeOpration.do", t, o);
    }, exports.userAnswerLikeOpration = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/api/questionOpration/userAnswerLikeOpration.do", t, o);
    };
}();