!function() {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: !0
    }), exports.addPlayStatisticsNum = exports.addAccessFullStatistics = exports.addQuestionDetailStatistics = exports.addQuestionAccessStatisticsByPerson = exports.addQuestionAccessStatistics = exports.addAccessStatistics = exports.addAccessStatisticsByPerson = exports.addPlayStatistics = exports.addPlayStatisticsByPerson = exports.addAccessDetailStatistics = void 0;
    var t = function(t) {
        return t && t.__esModule ? t : {
            default: t
        };
    }(require("./../tools/request.js"));
    exports.addAccessDetailStatistics = function() {
        var s = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, t.default)("/api/statistics/addAccessDetailStatistics.do", s, i);
    }, exports.addPlayStatisticsByPerson = function() {
        var s = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, t.default)("/api/statistics/addPlayStatisticsByPerson.do", s, i);
    }, exports.addPlayStatistics = function() {
        var s = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, t.default)("/api/statistics/addPlayStatistics.do", s, i);
    }, exports.addAccessStatisticsByPerson = function() {
        var s = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, t.default)("/api/statistics/addAccessStatisticsByPerson.do", s, i);
    }, exports.addAccessStatistics = function() {
        var s = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, t.default)("/api/statistics/addAccessStatistics.do", s, i);
    }, exports.addQuestionAccessStatistics = function() {
        var s = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, t.default)("/api/statistics/addQuestionAccessStatistics.do", s, i);
    }, exports.addQuestionAccessStatisticsByPerson = function() {
        var s = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, t.default)("/api/statistics/addQuestionAccessStatisticsByPerson.do", s, i);
    }, exports.addQuestionDetailStatistics = function() {
        var s = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, t.default)("/api/statistics/addQuestionDetailStatistics.do", s, i);
    }, exports.addAccessFullStatistics = function() {
        var s = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, t.default)("/api/statistics/addAccessFullStatistics.do", s, i);
    }, exports.addPlayStatisticsNum = function() {
        var s = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, t.default)("/api/statistics/addPlayStatisticsNum.do", s, i);
    };
}();