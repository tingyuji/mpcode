!function() {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: !0
    }), exports.changeStatusByType = exports.changePtStatus = exports.getSubTemp = exports.getSubTempList = exports.getPublicSubscribeInfo = void 0;
    var e = function(e) {
        return e && e.__esModule ? e : {
            default: e
        };
    }(require("./../tools/request.js"));
    exports.getPublicSubscribeInfo = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, u = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return t.source = "wendao", (0, e.default)("/api/publicSubscribe/getPublicSubscribeInfo.do", t, u);
    }, exports.getSubTempList = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, u = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return t.source = "wendao", (0, e.default)("/api/publicSubscribe/getSubTempList.do", t, u);
    }, exports.getSubTemp = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, u = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return t.source = "wendao", (0, e.default)("/api/publicSubscribe/getSubTemp.do", t, u);
    }, exports.changePtStatus = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, u = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return t.source = "wendao", (0, e.default)("/api/publicSubscribe/changePtStatus.do", t, u);
    }, exports.changeStatusByType = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, u = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return t.source = "wendao", (0, e.default)("/api/publicSubscribe/changeStatusByType.do", t, u);
    };
}();