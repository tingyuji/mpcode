!function() {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: !0
    }), exports.getRandom = exports.getCoursePageByCatsId = exports.getShareImage = exports.getCourseByTypeAndTitle = exports.getAudioCourseByIds = exports.getCourseCatsByCourseId = exports.getMyCoursePageBy = exports.getCoursePageByCodition = exports.getCourseCasts = exports.saveUserCourseContent = exports.getUserCourseContentByCourseIds = exports.getCourseById = exports.getCoursePageByCats = void 0;
    var e = function(e) {
        return e && e.__esModule ? e : {
            default: e
        };
    }(require("./../tools/request.js"));
    exports.getCoursePageByCats = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/api/course/getCoursePageByCats.do", t, o);
    }, exports.getCourseById = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/course/getCourseById.do", t, o);
    }, exports.getUserCourseContentByCourseIds = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/userCourseContent/getUserCourseContentByCourseIds.do", t, o);
    }, exports.saveUserCourseContent = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/api/userCourseContent/saveUserCourseContent.do", t, o);
    }, exports.getCourseCasts = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/course/getCourseCasts.do", t, o);
    }, exports.getCoursePageByCodition = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/api/course/getCoursePageByCodition.do", t, o);
    }, exports.getMyCoursePageBy = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/api/course/getMyCoursePageBy.do", t, o);
    }, exports.getCourseCatsByCourseId = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/api/course/getCourseCatsByCourseId.do", t, o);
    }, exports.getAudioCourseByIds = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/course/getAudioCourseByIds.do", t, o);
    }, exports.getCourseByTypeAndTitle = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/api/course/getCourseByTypeAndTitle.do", t, o);
    }, exports.getShareImage = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/api/course/getShareImage.do", t, o);
    }, exports.getCoursePageByCatsId = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/course/getCoursePageByCatsId.do", t, o);
    }, exports.getRandom = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/course/getRandom.do", t, o);
    };
}();