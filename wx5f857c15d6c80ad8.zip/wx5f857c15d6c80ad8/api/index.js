!function() {
    "use strict";
    function e(e) {
        if (e && e.__esModule) return e;
        var r = {};
        if (null != e) for (var i in e) Object.prototype.hasOwnProperty.call(e, i) && (r[i] = e[i]);
        return r.default = e, r;
    }
    Object.defineProperty(exports, "__esModule", {
        value: !0
    });
    var r = e(require("./classifyQ.js")), i = e(require("./login.js")), s = e(require("./firstPageCourse.js")), u = e(require("./consult.js")), n = e(require("./content.js")), o = e(require("./question.js")), t = e(require("./questionOpration.js")), q = e(require("./mySubscribe.js")), c = e(require("./sentence.js")), a = e(require("./course.js")), j = e(require("./rewardorbuy.js")), p = e(require("./statistics.js")), l = e(require("./live.js")), d = e(require("./user.js")), m = e(require("./pay.js")), b = e(require("./comment.js")), f = e(require("./message.js")), y = e(require("./evaluation.js")), w = e(require("./banner.js")), g = e(require("./encyclopediaArticles.js")), v = e(require("./residenceApplication.js")), x = e(require("./indexConfig.js")), A = e(require("./userAnswer.js")), C = e(require("./qCoupon.js")), S = e(require("./qaRecommend.js")), h = e(require("./publicSubscribe.js")), O = e(require("./paper.js")), P = e(require("./report.js")), _ = e(require("./wiki.js")), k = e(require("./theme.js")), E = e(require("./orderExperts.js")), I = e(require("./newIndwx.js")), M = e(require("./common.js")), Q = e(require("./helpSleep.js"));
    exports.default = {
        classifyQ: r,
        login: i,
        firstPageCourse: s,
        consult: u,
        content: n,
        question: o,
        questionOpration: t,
        indexConfig: x,
        mySubscribe: q,
        sentence: c,
        course: a,
        rewardorbuy: j,
        statistics: p,
        live: l,
        user: d,
        pay: m,
        comment: b,
        message: f,
        evaluation: y,
        banner: w,
        encyclopediaArticles: g,
        residenceApplication: v,
        userAnswer: A,
        qCoupon: C,
        qaRecommend: S,
        publicSubscribe: h,
        paper: O,
        report: P,
        wiki: _,
        orderExperts: E,
        theme: k,
        newIndex: I,
        common: M,
        helpSleep: Q
    };
}();