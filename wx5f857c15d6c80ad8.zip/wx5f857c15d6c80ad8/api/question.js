!function() {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: !0
    }), exports.voiceMp3 = exports.getAIToken = exports.uploadFileMp3 = exports.getListUserQuestionIdentity = exports.deCode = exports.edit = exports.getSaveQuestionPrefix = exports.getSaveQuestionDetail = exports.addQuestionPrefix = exports.getTeacherAnswer = exports.getDetail = exports.getRandom = exports.getQuestionImage = exports.getQuestionAnswerWait = exports.updateStatus = exports.answerQuetion = exports.getFirstPageQuestions = exports.queryQuestionByKeyword = exports.getRewardInfo = exports.getSaveQuestionAnswer = exports.getSaveQuestionTheme = exports.questionShareOpration = exports.getMyClloctedTotal = exports.getMyClloctedPage = exports.editQuestionAnswer = exports.addQuestionAnswer = exports.editQuestionTheme = exports.getDetailInfo = exports.addQuestionTheme = void 0;
    var e = function(e) {
        return e && e.__esModule ? e : {
            default: e
        };
    }(require("./../tools/request.js"));
    exports.addQuestionTheme = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return t.source = "wendao", (0, e.default)("/api/question/addQuestionTheme.do", t, o);
    }, exports.getDetailInfo = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/api/question/getDetailInfo.do", t, o);
    }, exports.editQuestionTheme = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return t.source = "wendao", (0, e.default)("/api/question/editQuestionTheme.do", t, o);
    }, exports.addQuestionAnswer = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return t.source = "wendao", (0, e.default)("/api/question/addQuestionAnswer.do", t, o);
    }, exports.editQuestionAnswer = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return t.source = "wendao", (0, e.default)("/api/question/editQuestionAnswer.do", t, o);
    }, exports.getMyClloctedPage = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/api/question/getMyClloctedPage.do ", t, o);
    }, exports.getMyClloctedTotal = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/api/question/getMyClloctedTotal.do ", t, o);
    }, exports.questionShareOpration = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/api/questionOpration/questionShareOpration.do", t, o);
    }, exports.getSaveQuestionTheme = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/api/question/getSaveQuestionTheme.do", t, o);
    }, exports.getSaveQuestionAnswer = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/api/question/getSaveQuestionAnswer.do", t, o);
    }, exports.getRewardInfo = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/api/question/getRewardInfo.do", t, o);
    }, exports.queryQuestionByKeyword = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/api/question/queryQuestionByKeyword.do", t, o);
    }, exports.getFirstPageQuestions = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/api/question/getFpq.do", t, o);
    }, exports.answerQuetion = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return t.source = "wendao", (0, e.default)("/api/question/answerQuetion.do", t, o);
    }, exports.updateStatus = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/api/question/updateStatus.do", t, o);
    }, exports.getQuestionAnswerWait = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/api/question/getQuestionAnswerWait.do", t, o);
    }, exports.getQuestionImage = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/api/question/getQuestionImage.do", t, o);
    }, exports.getRandom = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/question/getRandom.do", t, o);
    }, exports.getDetail = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/question/getDetail.do", t, o);
    }, exports.getTeacherAnswer = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/question/getTeacherAnswer.do", t, o);
    }, exports.addQuestionPrefix = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/api/question/addQuestionPrefix.do", t, o);
    }, exports.getSaveQuestionDetail = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/api/question/getSaveQuestionDetail.do", t, o);
    }, exports.getSaveQuestionPrefix = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/api/question/getSaveQuestionPrefix.do", t, o);
    }, exports.edit = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/api/question/edit.do", t, o);
    }, exports.deCode = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/api/ai/deCode.do", t, o);
    }, exports.getListUserQuestionIdentity = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/api/userQuestionIdentity/getListUserQuestionIdentity.do", t, o);
    }, exports.uploadFileMp3 = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/uploadFileMp3.do", t, o);
    }, exports.getAIToken = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return t.appKey = "wendao", (0, e.default)("/api/ai/getAIToken.do", t, o);
    }, exports.voiceMp3 = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("https://aiapi.fhd001.com/voice/mp3", t, o);
    };
}();