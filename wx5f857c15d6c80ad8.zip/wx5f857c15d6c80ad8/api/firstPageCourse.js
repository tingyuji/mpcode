!function() {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: !0
    }), exports.getMyAnswerTotal = exports.getMyQCouponTotal = exports.getMyTest = exports.getMyClloctedQuestionTotal = exports.getMyClloctedQuestionPage = exports.getFirstPageCourseCats = exports.getQuestions = void 0;
    var e = function(e) {
        return e && e.__esModule ? e : {
            default: e
        };
    }(require("./../tools/request.js"));
    exports.getQuestions = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/firstPageCourse/getQuestions.do", t, o);
    }, exports.getFirstPageCourseCats = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/api/firstPageCourse/getFirstPageCourseCats.do", t, o);
    }, exports.getMyClloctedQuestionPage = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/api/firstPageCourse/getMyClloctedQuestionPage.do", t, o);
    }, exports.getMyClloctedQuestionTotal = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/api/firstPageCourse/getMyClloctedQuestionTotal.do", t, o);
    }, exports.getMyTest = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/api/firstPageCourse/getMyTest.do", t, o);
    }, exports.getMyQCouponTotal = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/api/firstPageCourse/getMyQCouponTotal.do", t, o);
    }, exports.getMyAnswerTotal = function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/api/firstPageCourse/getMyAnswerTotal.do", t, o);
    };
}();