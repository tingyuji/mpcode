!function() {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: !0
    }), exports.getIndexWikiList = exports.getHotData = exports.getHotOrNewData = exports.getDetail = exports.getInfoWithContents = exports.getWikis = void 0;
    var t = function(t) {
        return t && t.__esModule ? t : {
            default: t
        };
    }(require("./../tools/request.js"));
    exports.getWikis = function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return e.source = "wendao", (0, t.default)("/wiki/getWikis.do", e, o);
    }, exports.getInfoWithContents = function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return e.source = "wendao", (0, t.default)("/wiki/getInfoWithContents.do", e, o);
    }, exports.getDetail = function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return e.source = "wendao", (0, t.default)("/wiki/getDetail.do", e, o);
    }, exports.getHotOrNewData = function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return e.source = "wendao", (0, t.default)("/wiki/getHotOrNewData.do", e, o);
    }, exports.getHotData = function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return e.source = "wendao", (0, t.default)("/wiki/getHotData.do", e, o);
    }, exports.getIndexWikiList = function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return e.source = "wendao", (0, t.default)("/wiki/getIndexWikiList.do", e, o);
    };
}();