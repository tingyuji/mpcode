!function() {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: !0
    }), exports.getQuestionsByClassifyIdAndOrder = exports.getQuestionsBuClassifyId = void 0;
    var e = function(e) {
        return e && e.__esModule ? e : {
            default: e
        };
    }(require("./../tools/request.js"));
    exports.getQuestionsBuClassifyId = function() {
        var s = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/api/classifyQ/getQuestionsBuClassifyId.do", s, t);
    }, exports.getQuestionsByClassifyIdAndOrder = function() {
        var s = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return (0, e.default)("/classifyQ/getQuestionsByClassifyIdAndOrder.do", s, t);
    };
}();