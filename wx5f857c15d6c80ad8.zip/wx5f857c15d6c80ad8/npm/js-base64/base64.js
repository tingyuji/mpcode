!function() {
    !function(t, n) {
        var r, e;
        "object" == typeof exports && "undefined" != typeof module ? module.exports = n() : "function" == typeof define && define.amd ? define(n) : (r = t.Base64, 
        (e = n()).noConflict = function() {
            return t.Base64 = r, e;
        }, t.Meteor && (Base64 = e), t.Base64 = e);
    }("undefined" != typeof self ? self : "undefined" != typeof window ? window : "undefined" != typeof global ? global : this, function() {
        "use strict";
        var t = "function" == typeof atob, n = "function" == typeof btoa, r = "function" == typeof Buffer, e = "function" == typeof TextDecoder ? new TextDecoder() : void 0, o = "function" == typeof TextEncoder ? new TextEncoder() : void 0, u = Array.prototype.slice.call("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/="), i = function(t) {
            var n = {};
            return t.forEach(function(t, r) {
                return n[t] = r;
            }), n;
        }(u), f = /^(?:[A-Za-z\d+\/]{4})*?(?:[A-Za-z\d+\/]{2}(?:==)?|[A-Za-z\d+\/]{3}=?)?$/, c = String.fromCharCode.bind(String), a = "function" == typeof Uint8Array.from ? Uint8Array.from.bind(Uint8Array) : function(t, n) {
            return void 0 === n && (n = function(t) {
                return t;
            }), new Uint8Array(Array.prototype.slice.call(t, 0).map(n));
        }, d = function(t) {
            return t.replace(/=/g, "").replace(/[+\/]/g, function(t) {
                return "+" == t ? "-" : "_";
            });
        }, s = function(t) {
            return t.replace(/[^A-Za-z0-9\+\/]/g, "");
        }, l = function(t) {
            for (var n, r, e, o, i = "", f = t.length % 3, c = 0; c < t.length; ) {
                if ((r = t.charCodeAt(c++)) > 255 || (e = t.charCodeAt(c++)) > 255 || (o = t.charCodeAt(c++)) > 255) throw new TypeError("invalid character found");
                i += u[(n = r << 16 | e << 8 | o) >> 18 & 63] + u[n >> 12 & 63] + u[n >> 6 & 63] + u[63 & n];
            }
            return f ? i.slice(0, f - 3) + "===".substring(f) : i;
        }, h = n ? function(t) {
            return btoa(t);
        } : r ? function(t) {
            return Buffer.from(t, "binary").toString("base64");
        } : l, p = r ? function(t) {
            return Buffer.from(t).toString("base64");
        } : function(t) {
            for (var n = [], r = 0, e = t.length; r < e; r += 4096) n.push(c.apply(null, t.subarray(r, r + 4096)));
            return h(n.join(""));
        }, y = function(t, n) {
            return void 0 === n && (n = !1), n ? d(p(t)) : p(t);
        }, A = function(t) {
            if (t.length < 2) return (n = t.charCodeAt(0)) < 128 ? t : n < 2048 ? c(192 | n >>> 6) + c(128 | 63 & n) : c(224 | n >>> 12 & 15) + c(128 | n >>> 6 & 63) + c(128 | 63 & n);
            var n = 65536 + 1024 * (t.charCodeAt(0) - 55296) + (t.charCodeAt(1) - 56320);
            return c(240 | n >>> 18 & 7) + c(128 | n >>> 12 & 63) + c(128 | n >>> 6 & 63) + c(128 | 63 & n);
        }, b = /[\uD800-\uDBFF][\uDC00-\uDFFFF]|[^\x00-\x7F]/g, g = function(t) {
            return t.replace(b, A);
        }, B = r ? function(t) {
            return Buffer.from(t, "utf8").toString("base64");
        } : o ? function(t) {
            return p(o.encode(t));
        } : function(t) {
            return h(g(t));
        }, x = function(t, n) {
            return void 0 === n && (n = !1), n ? d(B(t)) : B(t);
        }, C = function(t) {
            return x(t, !0);
        }, m = /[\xC0-\xDF][\x80-\xBF]|[\xE0-\xEF][\x80-\xBF]{2}|[\xF0-\xF7][\x80-\xBF]{3}/g, v = function(t) {
            switch (t.length) {
              case 4:
                var n = ((7 & t.charCodeAt(0)) << 18 | (63 & t.charCodeAt(1)) << 12 | (63 & t.charCodeAt(2)) << 6 | 63 & t.charCodeAt(3)) - 65536;
                return c(55296 + (n >>> 10)) + c(56320 + (1023 & n));

              case 3:
                return c((15 & t.charCodeAt(0)) << 12 | (63 & t.charCodeAt(1)) << 6 | 63 & t.charCodeAt(2));

              default:
                return c((31 & t.charCodeAt(0)) << 6 | 63 & t.charCodeAt(1));
            }
        }, U = function(t) {
            return t.replace(m, v);
        }, F = function(t) {
            if (t = t.replace(/\s+/g, ""), !f.test(t)) throw new TypeError("malformed base64.");
            t += "==".slice(2 - (3 & t.length));
            for (var n, r, e, o = "", u = 0; u < t.length; ) n = i[t.charAt(u++)] << 18 | i[t.charAt(u++)] << 12 | (r = i[t.charAt(u++)]) << 6 | (e = i[t.charAt(u++)]), 
            o += 64 === r ? c(n >> 16 & 255) : 64 === e ? c(n >> 16 & 255, n >> 8 & 255) : c(n >> 16 & 255, n >> 8 & 255, 255 & n);
            return o;
        }, w = t ? function(t) {
            return atob(s(t));
        } : r ? function(t) {
            return Buffer.from(t, "base64").toString("binary");
        } : F, S = r ? function(t) {
            return a(Buffer.from(t, "base64"));
        } : function(t) {
            return a(w(t), function(t) {
                return t.charCodeAt(0);
            });
        }, E = function(t) {
            return S(R(t));
        }, D = r ? function(t) {
            return Buffer.from(t, "base64").toString("utf8");
        } : e ? function(t) {
            return e.decode(S(t));
        } : function(t) {
            return U(w(t));
        }, R = function(t) {
            return s(t.replace(/[-_]/g, function(t) {
                return "-" == t ? "+" : "/";
            }));
        }, z = function(t) {
            return D(R(t));
        }, T = function(t) {
            return {
                value: t,
                enumerable: !1,
                writable: !0,
                configurable: !0
            };
        }, Z = function() {
            var t = function(t, n) {
                return Object.defineProperty(String.prototype, t, T(n));
            };
            t("fromBase64", function() {
                return z(this);
            }), t("toBase64", function(t) {
                return x(this, t);
            }), t("toBase64URI", function() {
                return x(this, !0);
            }), t("toBase64URL", function() {
                return x(this, !0);
            }), t("toUint8Array", function() {
                return E(this);
            });
        }, j = function() {
            var t = function(t, n) {
                return Object.defineProperty(Uint8Array.prototype, t, T(n));
            };
            t("toBase64", function(t) {
                return y(this, t);
            }), t("toBase64URI", function() {
                return y(this, !0);
            }), t("toBase64URL", function() {
                return y(this, !0);
            });
        }, I = {
            version: "3.7.2",
            VERSION: "3.7.2",
            atob: w,
            atobPolyfill: F,
            btoa: h,
            btoaPolyfill: l,
            fromBase64: z,
            toBase64: x,
            encode: x,
            encodeURI: C,
            encodeURL: C,
            utob: g,
            btou: U,
            decode: z,
            isValid: function(t) {
                if ("string" != typeof t) return !1;
                var n = t.replace(/\s+/g, "").replace(/={0,2}$/, "");
                return !/[^\s0-9a-zA-Z\+/]/.test(n) || !/[^\s0-9a-zA-Z\-_]/.test(n);
            },
            fromUint8Array: y,
            toUint8Array: E,
            extendString: Z,
            extendUint8Array: j,
            extendBuiltins: function() {
                Z(), j();
            },
            Base64: {}
        };
        return Object.keys(I).forEach(function(t) {
            return I.Base64[t] = I[t];
        }), I;
    });
}();