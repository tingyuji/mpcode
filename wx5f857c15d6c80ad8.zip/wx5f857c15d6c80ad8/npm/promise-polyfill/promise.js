!function() {
    !function(e) {
        function n() {}
        function t(e) {
            if (!(this instanceof t)) throw new TypeError("Promises must be constructed via new");
            if ("function" != typeof e) throw new TypeError("not a function");
            this._state = 0, this._handled = !1, this._value = void 0, this._deferreds = [], 
            c(e, this);
        }
        function o(e, n) {
            for (;3 === e._state; ) e = e._value;
            0 !== e._state ? (e._handled = !0, t._immediateFn(function() {
                var t = 1 === e._state ? n.onFulfilled : n.onRejected;
                if (null !== t) {
                    var o;
                    try {
                        o = t(e._value);
                    } catch (e) {
                        return void r(n.promise, e);
                    }
                    i(n.promise, o);
                } else (1 === e._state ? i : r)(n.promise, e._value);
            })) : e._deferreds.push(n);
        }
        function i(e, n) {
            try {
                if (n === e) throw new TypeError("A promise cannot be resolved with itself.");
                if (n && ("object" == typeof n || "function" == typeof n)) {
                    var o = n.then;
                    if (n instanceof t) return e._state = 3, e._value = n, void f(e);
                    if ("function" == typeof o) return void c(function(e, n) {
                        return function() {
                            e.apply(n, arguments);
                        };
                    }(o, n), e);
                }
                e._state = 1, e._value = n, f(e);
            } catch (n) {
                r(e, n);
            }
        }
        function r(e, n) {
            e._state = 2, e._value = n, f(e);
        }
        function f(e) {
            2 === e._state && 0 === e._deferreds.length && t._immediateFn(function() {
                e._handled || t._unhandledRejectionFn(e._value);
            });
            for (var n = 0, i = e._deferreds.length; n < i; n++) o(e, e._deferreds[n]);
            e._deferreds = null;
        }
        function u(e, n, t) {
            this.onFulfilled = "function" == typeof e ? e : null, this.onRejected = "function" == typeof n ? n : null, 
            this.promise = t;
        }
        function c(e, n) {
            var t = !1;
            try {
                e(function(e) {
                    t || (t = !0, i(n, e));
                }, function(e) {
                    t || (t = !0, r(n, e));
                });
            } catch (e) {
                if (t) return;
                t = !0, r(n, e);
            }
        }
        var a = setTimeout;
        t.prototype.catch = function(e) {
            return this.then(null, e);
        }, t.prototype.then = function(e, t) {
            var i = new this.constructor(n);
            return o(this, new u(e, t, i)), i;
        }, t.all = function(e) {
            return new t(function(n, t) {
                function o(e, f) {
                    try {
                        if (f && ("object" == typeof f || "function" == typeof f)) {
                            var u = f.then;
                            if ("function" == typeof u) return void u.call(f, function(n) {
                                o(e, n);
                            }, t);
                        }
                        i[e] = f, 0 == --r && n(i);
                    } catch (e) {
                        t(e);
                    }
                }
                if (!e || void 0 === e.length) throw new TypeError("Promise.all accepts an array");
                var i = Array.prototype.slice.call(e);
                if (0 === i.length) return n([]);
                for (var r = i.length, f = 0; f < i.length; f++) o(f, i[f]);
            });
        }, t.resolve = function(e) {
            return e && "object" == typeof e && e.constructor === t ? e : new t(function(n) {
                n(e);
            });
        }, t.reject = function(e) {
            return new t(function(n, t) {
                t(e);
            });
        }, t.race = function(e) {
            return new t(function(n, t) {
                for (var o = 0, i = e.length; o < i; o++) e[o].then(n, t);
            });
        }, t._immediateFn = "function" == typeof setImmediate && function(e) {
            setImmediate(e);
        } || function(e) {
            a(e, 0);
        }, t._unhandledRejectionFn = function(e) {
            "undefined" != typeof console && console && console.warn("Possible Unhandled Promise Rejection:", e);
        }, t._setImmediateFn = function(e) {
            t._immediateFn = e;
        }, t._setUnhandledRejectionFn = function(e) {
            t._unhandledRejectionFn = e;
        }, "undefined" != typeof module && module.exports ? module.exports = t : e.Promise || (e.Promise = t);
    }(this);
}();