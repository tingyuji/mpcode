!function() {
    "use strict";
    function e(e) {
        return e && e.__esModule ? e : {
            default: e
        };
    }
    Object.defineProperty(exports, "__esModule", {
        value: !0
    }), exports.plugins = exports.project = void 0;
    var n = e(require("./npm/wepy/lib/wepy.js")), t = e(require("./api/index.js")), o = exports.project = {
        appName: "起源心理理",
        appId: ""
    }, a = exports.plugins = {
        login: {
            createUserInfo: function(e, n) {
                return t.default.login.createUserInfo(e, n);
            },
            loginByCode: function(e, n) {
                return t.default.login.loginByCode(e, n);
            },
            isLoged: function() {
                return n.default.$instance.globalData.isLoged;
            },
            getSessionKey: function() {
                return n.default.$instance.globalData.sessionKey;
            },
            getLaunchInfo: function() {
                return n.default.$instance.globalData.launchInfo;
            },
            getVersion: function() {
                return n.default.$instance.globalData.version;
            },
            getToken: function() {
                return n.default.$instance.globalData.token;
            },
            authorizePhone: function() {
                return n.default.$instance.globalData.authorizePhone;
            }
        }
    };
    exports.default = {
        project: o,
        plugins: a
    };
}();