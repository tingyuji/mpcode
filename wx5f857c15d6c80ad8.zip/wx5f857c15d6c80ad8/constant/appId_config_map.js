!function() {
    "use strict";
    module.exports = {
        wx5f857c15d6c80ad8: {
            source: "youyu",
            name: "忧郁症自测试题症状分析专业版",
            subscribeTmplIds: {
                daily_sleep_remind: "fkPu7Zkxuny2ltylEYmXdmXi_dRjjkZ2Pe2KrP8n0XM",
                night_sleep_remind: "bk-h2R35qB4Bcu1d-TFpTX5j0NOAIlk8Ifp5vMPy1fc",
                sleep_plan_notify: "Zzrw2oH9nbSt89rE3aUgcv9pxGMjBQaDhlPPUu2YCws"
            }
        }
    };
}();