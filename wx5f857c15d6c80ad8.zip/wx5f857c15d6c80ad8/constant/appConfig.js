!function() {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: !0
    });
    var e = Object.assign || function(e) {
        for (var t = 1; t < arguments.length; t++) {
            var r = arguments[t];
            for (var o in r) Object.prototype.hasOwnProperty.call(r, o) && (e[o] = r[o]);
        }
        return e;
    }, t = function(e) {
        return e && e.__esModule ? e : {
            default: e
        };
    }(require("./appId_config_map.js")), r = "wx09148366103e6411";
    try {
        r = wx.getAccountInfoSync().miniProgram.appId;
    } catch (e) {}
    console.log(t.default[r], r, t.default), exports.default = e({}, t.default[r]);
}();