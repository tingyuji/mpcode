function _interopRequireDefault(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

function _classCallCheck(t, e) {
    if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(t, e) {
    if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !e || "object" != typeof e && "function" != typeof e ? t : e;
}

function _inherits(t, e) {
    if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
    t.prototype = Object.create(e && e.prototype, {
        constructor: {
            value: t,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e);
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var _wepy = require("./../npm/wepy/lib/wepy.js"), _wepy2 = _interopRequireDefault(_wepy), _storage = require("./../common/storage.js"), _storage2 = _interopRequireDefault(_storage), kcUpdateModle = function(t) {
    function e() {
        var t, o, n, r;
        _classCallCheck(this, e);
        for (var s = arguments.length, i = Array(s), a = 0; a < s; a++) i[a] = arguments[a];
        return o = n = _possibleConstructorReturn(this, (t = e.__proto__ || Object.getPrototypeOf(e)).call.apply(t, [ this ].concat(i))), 
        n.props = {
            hasVip: {
                default: !1,
                type: Boolean
            },
            status: {
                default: !1,
                type: Boolean
            }
        }, n.data = {
            cb: null,
            show: !1,
            tips: [ "同学，你目前的网络状况不好", "建议切换至稳定的网络环境", "" ],
            btnMsg: ""
        }, n.methods = {
            showModal: function(t) {
                var e = t.cb;
                this.show = !0, this.cb = e, this.$apply();
            },
            closeModal: function() {
                this.show = !1;
            },
            close: function() {
                this.show = !1, wx.reportAnalytics("index_20_click_vipclose", {});
            },
            handleContact: function(t) {
                wx.reportAnalytics("index_20_click_vipcontact", {}), this.show = !1, _storage2.default.set("contactBack", !0);
            }
        }, n.computed = {
            bgSrc: function() {
                return this.status ? "../images/activate/vip_success.png" : "../images/activate/vip_fail.png";
            }
        }, r = o, _possibleConstructorReturn(n, r);
    }
    return _inherits(e, t), e;
}(_wepy2.default.component);

exports.default = kcUpdateModle;