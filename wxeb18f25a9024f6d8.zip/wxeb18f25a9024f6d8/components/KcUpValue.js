function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function _asyncToGenerator(e) {
    return function() {
        var t = e.apply(this, arguments);
        return new Promise(function(e, n) {
            function r(o, i) {
                try {
                    var a = t[o](i), u = a.value;
                } catch (e) {
                    return void n(e);
                }
                if (!a.done) return Promise.resolve(u).then(function(e) {
                    r("next", e);
                }, function(e) {
                    r("throw", e);
                });
                e(u);
            }
            return r("next");
        });
    };
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t;
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var _createClass = function() {
    function e(e, t) {
        for (var n = 0; n < t.length; n++) {
            var r = t[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), 
            Object.defineProperty(e, r.key, r);
        }
    }
    return function(t, n, r) {
        return n && e(t.prototype, n), r && e(t, r), t;
    };
}(), _wepy = require("./../npm/wepy/lib/wepy.js"), _wepy2 = _interopRequireDefault(_wepy), _api = require("./../common/api.js"), _api2 = _interopRequireDefault(_api), _storage = require("./../common/storage.js"), _storage2 = _interopRequireDefault(_storage), log = require("./../common/log.js"), KcUpValue = function(e) {
    function t() {
        var e, n, r, o;
        _classCallCheck(this, t);
        for (var i = arguments.length, a = Array(i), u = 0; u < i; u++) a[u] = arguments[u];
        return n = r = _possibleConstructorReturn(this, (e = t.__proto__ || Object.getPrototypeOf(t)).call.apply(e, [ this ].concat(a))), 
        r.props = {}, r.data = {
            cb: null,
            show: !1,
            imgSrc: "",
            title: "",
            text1: "",
            text2: "",
            text3: "",
            leftBtnText: "",
            rightBtnText: "",
            leftCb: null,
            rightCb: null,
            rightBtnTips: ""
        }, r.methods = {
            showModal: function(e) {
                var t = e.cb;
                this.show = !0, this.cb = t, this.$apply();
            },
            close: function() {
                this.show = !1;
            },
            leftBtn: function() {
                this.leftCb();
            },
            rightBtn: function() {
                this.rightCb();
            }
        }, o = n, _possibleConstructorReturn(r, o);
    }
    return _inherits(t, e), _createClass(t, [ {
        key: "unlockVideo",
        value: function() {
            function e(e) {
                return t.apply(this, arguments);
            }
            var t = _asyncToGenerator(regeneratorRuntime.mark(function e(t) {
                var n;
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return e.prev = 0, e.next = 3, _storage2.default.get("token");

                      case 3:
                        if (e.t0 = e.sent, e.t0) {
                            e.next = 6;
                            break;
                        }
                        e.t0 = 0;

                      case 6:
                        return n = e.t0, e.next = 9, _api2.default.unlockVideo({
                            questionId: t,
                            token: n
                        });

                      case 9:
                        this.show = !1, this.$apply(), this.$emit("unlockVideoSuccess"), e.next = 18;
                        break;

                      case 14:
                        e.prev = 14, e.t1 = e.catch(0), console.log(e.t1), wx.showToast({
                            title: "解锁失败,请重试",
                            icon: "none",
                            duration: 3e3
                        });

                      case 18:
                      case "end":
                        return e.stop();
                    }
                }, e, this, [ [ 0, 14 ] ]);
            }));
            return e;
        }()
    }, {
        key: "close",
        value: function() {
            this.$apply(), this.show = !1;
        }
    }, {
        key: "modalCloseCb",
        value: function() {
            this.$emit("modalCloseCb");
        }
    }, {
        key: "unlockCourse",
        value: function() {
            function e(e, n) {
                return t.apply(this, arguments);
            }
            var t = _asyncToGenerator(regeneratorRuntime.mark(function e(t, n) {
                var r;
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return e.next = 2, _storage2.default.get("token");

                      case 2:
                        if (e.t0 = e.sent, e.t0) {
                            e.next = 5;
                            break;
                        }
                        e.t0 = 0;

                      case 5:
                        return r = e.t0, e.prev = 6, e.next = 9, _api2.default.unlockCourse({
                            subjectId: t,
                            stage: n,
                            token: r
                        });

                      case 9:
                        log.info("解锁弹窗去列表页", "learnIndex?sid=" + t + "&day=" + n), wx.redirectTo({
                            url: "learnIndex?sid=" + t + "&day=" + n
                        }), e.next = 17;
                        break;

                      case 13:
                        e.prev = 13, e.t1 = e.catch(6), console.log(e.t1), wx.showToast({
                            title: "解锁失败,请重试",
                            icon: "none",
                            duration: 3e3
                        });

                      case 17:
                      case "end":
                        return e.stop();
                    }
                }, e, this, [ [ 6, 13 ] ]);
            }));
            return e;
        }()
    } ]), t;
}(_wepy2.default.component);

exports.default = KcUpValue;