function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function _asyncToGenerator(e) {
    return function() {
        var r = e.apply(this, arguments);
        return new Promise(function(e, t) {
            function n(o, i) {
                try {
                    var a = r[o](i), c = a.value;
                } catch (e) {
                    return void t(e);
                }
                if (!a.done) return Promise.resolve(c).then(function(e) {
                    n("next", e);
                }, function(e) {
                    n("throw", e);
                });
                e(c);
            }
            return n("next");
        });
    };
}

function _classCallCheck(e, r) {
    if (!(e instanceof r)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(e, r) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !r || "object" != typeof r && "function" != typeof r ? e : r;
}

function _inherits(e, r) {
    if ("function" != typeof r && null !== r) throw new TypeError("Super expression must either be null or a function, not " + typeof r);
    e.prototype = Object.create(r && r.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), r && (Object.setPrototypeOf ? Object.setPrototypeOf(e, r) : e.__proto__ = r);
}

function _applyDecoratedDescriptor(e, r, t, n, o) {
    var i = {};
    return Object.keys(n).forEach(function(e) {
        i[e] = n[e];
    }), i.enumerable = !!i.enumerable, i.configurable = !!i.configurable, ("value" in i || i.initializer) && (i.writable = !0), 
    i = t.slice().reverse().reduce(function(t, n) {
        return n(e, r, t) || t;
    }, i), o && void 0 !== i.initializer && (i.value = i.initializer ? i.initializer.call(o) : void 0, 
    i.initializer = void 0), void 0 === i.initializer && (Object.defineProperty(e, r, i), 
    i = null), i;
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var _createClass = function() {
    function e(e, r) {
        for (var t = 0; t < r.length; t++) {
            var n = r[t];
            n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), 
            Object.defineProperty(e, n.key, n);
        }
    }
    return function(r, t, n) {
        return t && e(r.prototype, t), n && e(r, n), r;
    };
}(), _dec, _desc, _value, _class, _wepy = require("./../npm/wepy/lib/wepy.js"), _wepy2 = _interopRequireDefault(_wepy), _api = require("./../common/api.js"), _api2 = _interopRequireDefault(_api), _decorator = require("./../common/decorator.js"), _KcLoading = require("./KcLoading.js"), _KcLoading2 = _interopRequireDefault(_KcLoading), _KcErrorModal = require("./KcErrorModal.js"), _KcErrorModal2 = _interopRequireDefault(_KcErrorModal), kcUpdateModle = (_dec = (0, 
_decorator.trycatch)(), _class = function(e) {
    function r() {
        var e, t, n, o, i = this;
        _classCallCheck(this, r);
        for (var a = arguments.length, c = Array(a), s = 0; s < a; s++) c[s] = arguments[s];
        return t = n = _possibleConstructorReturn(this, (e = r.__proto__ || Object.getPrototypeOf(r)).call.apply(e, [ this ].concat(c))), 
        n.props = {
            isAuth: {
                default: !1,
                type: Boolean
            }
        }, n.$repeat = {}, n.$props = {
            KcLoading: {
                "xmlns:v-bind": "",
                "v-bind:loadingHide.sync": "loadingHide"
            }
        }, n.$events = {}, n.components = {
            KcErrorModal: _KcErrorModal2.default,
            KcLoading: _KcLoading2.default
        }, n.data = {
            cb: null,
            show: !1,
            loadingHide: !0
        }, n.methods = {
            startAuth: function() {
                function e(e) {
                    return r.apply(this, arguments);
                }
                var r = _asyncToGenerator(regeneratorRuntime.mark(function e(r) {
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            n.isAuth ? console.log("ok") : r.detail.errMsg.indexOf("ok") > -1 && n.loginTo();

                          case 1:
                          case "end":
                            return e.stop();
                        }
                    }, e, i);
                }));
                return e;
            }(),
            showModal: function(e) {
                var r = e.cb;
                this.show = !0, this.cb = r, this.$apply();
            },
            close: function() {
                this.show = !1, (0, this.cb)();
            }
        }, o = t, _possibleConstructorReturn(n, o);
    }
    return _inherits(r, e), _createClass(r, [ {
        key: "loginTo",
        value: function() {
            function e() {
                return r.apply(this, arguments);
            }
            var r = _asyncToGenerator(regeneratorRuntime.mark(function e() {
                var r, t, n;
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return e.next = 2, _wepy2.default.getUserInfo();

                      case 2:
                        return r = e.sent, t = r.encryptedData, n = r.iv, e.next = 7, _api2.default.login({
                            encryptedData: t,
                            iv: n
                        });

                      case 7:
                        this.show = !1, this.$apply(), wx.showToast({
                            title: "领取成功！快把这个活动分享给你的研友吧！",
                            icon: "none",
                            duration: 3e3
                        });

                      case 10:
                      case "end":
                        return e.stop();
                    }
                }, e, this);
            }));
            return e;
        }()
    }, {
        key: "handleError",
        value: function() {
            function e(e) {
                return r.apply(this, arguments);
            }
            var r = _asyncToGenerator(regeneratorRuntime.mark(function e(r) {
                var t = this;
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        this.loadingHide = !0, this.$apply(), this.$invoke("KcErrorModal", "showModal", {
                            err: r,
                            btnMsg: "重新加载",
                            cb: function() {
                                t.loginTo();
                            }
                        });

                      case 3:
                      case "end":
                        return e.stop();
                    }
                }, e, this);
            }));
            return e;
        }()
    } ]), r;
}(_wepy2.default.component), _applyDecoratedDescriptor(_class.prototype, "loginTo", [ _dec ], Object.getOwnPropertyDescriptor(_class.prototype, "loginTo"), _class.prototype), 
_class);

exports.default = kcUpdateModle;