function _interopRequireDefault(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

function getOpenId(t) {
    return _http2.default.get("/wx/authNew", t);
}

function login(t) {
    return _http2.default.Login(t, !0);
}

function register(t) {
    return _http2.default.register(t, !0);
}

function indexInfo(t) {
    return _http2.default.get("/indexInfo", t);
}

function indexBanner(t) {
    return _http2.default.get("/banner", t);
}

function learnInfo(t) {
    return _http2.default.get("/getLearnInfoNew", t);
}

function getReviewDays(t) {
    return _http2.default.get("/getReviewDaysNew", t);
}

function unlockCourse(t) {
    return _http2.default.get("/unlockCourse", t);
}

function upValue(t) {
    return _http2.default.get("/userShareTask", t);
}

function saveScore(t) {
    return _http2.default.get("/saveScore", t);
}

function activityInfo(t) {
    return _http2.default.get("/edge/acceding", t);
}

function activityHelp(t) {
    return _http2.default.post("/edge/acceding", t);
}

function getDayInfo(t) {
    return _http2.default.get("/getDayInfo", t);
}

function submitAnswers(t) {
    return _http2.default.post("/submitAnswers", t);
}

function submitAnswersBehaviour(t) {
    return _http2.default.post("/submitAnswersBehaviour", t);
}

function submitFormId(t) {
    return _http2.default.post("/collect", t);
}

function pay(t) {
    return _http2.default.get("/pay", t);
}

function getPointDetail(t) {
    return _http2.default.get("/getPointDetail", t);
}

function submitShareStats(t) {
    return _http2.default.post("/shareStats", t);
}

function updateAppUserStatus(t) {
    return _http2.default.post("/updateAppUserStatus", t);
}

function getQRCodeForUpValue(t) {
    return _http2.default.get("/getQRCodeForUpValue", t);
}

function getRankingDetail(t) {
    return _http2.default.get("/userRankingDetail", t);
}

function subscribeMessage(t) {
    return _http2.default.post("/subscribeMessage", t);
}

function getUserIndex(t) {
    return _http2.default.get("/userTaskList", t);
}

function getMyUpValue(t) {
    return _http2.default.get("/myUpValue", t);
}

function posterHelp(t) {
    return _http2.default.get("/posterHelp", t);
}

function unlockVideo(t) {
    return _http2.default.get("/unlockVideo", t);
}

function userLearnData(t) {
    return _http2.default.get("/userLearnData", t);
}

function clickPublicCourse(t) {
    return _http2.default.get("/clickPublicCourse", t);
}

function wrongSection(t) {
    return _http2.default.get("/wrongSection", t);
}

function getUserInfo(t) {
    return _http2.default.get("/user", t);
}

function setPhoneNumber(t) {
    return _http2.default.post("/wx/phoneNumber", t);
}

function shareHelp() {
    return _http2.default.get("/shareHelp");
}

function postShareHelp() {
    return _http2.default.post("/shareHelp");
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _http = require("./http.js"), _http2 = _interopRequireDefault(_http);

exports.default = {
    getOpenId: getOpenId,
    login: login,
    indexInfo: indexInfo,
    learnInfo: learnInfo,
    getReviewDays: getReviewDays,
    unlockCourse: unlockCourse,
    saveScore: saveScore,
    upValue: upValue,
    activityInfo: activityInfo,
    activityHelp: activityHelp,
    getDayInfo: getDayInfo,
    submitAnswers: submitAnswers,
    submitAnswersBehaviour: submitAnswersBehaviour,
    submitFormId: submitFormId,
    pay: pay,
    getPointDetail: getPointDetail,
    submitShareStats: submitShareStats,
    updateAppUserStatus: updateAppUserStatus,
    getQRCodeForUpValue: getQRCodeForUpValue,
    getRankingDetail: getRankingDetail,
    subscribeMessage: subscribeMessage,
    getUserIndex: getUserIndex,
    getMyUpValue: getMyUpValue,
    posterHelp: posterHelp,
    unlockVideo: unlockVideo,
    userLearnData: userLearnData,
    clickPublicCourse: clickPublicCourse,
    wrongSection: wrongSection,
    getUserInfo: getUserInfo,
    register: register,
    indexBanner: indexBanner,
    setPhoneNumber: setPhoneNumber,
    shareHelp: shareHelp,
    postShareHelp: postShareHelp
};