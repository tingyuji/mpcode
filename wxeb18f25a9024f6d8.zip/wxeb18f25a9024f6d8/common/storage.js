function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function set(e, t) {
    return new Promise(function(n, r) {
        _wepy2.default.setStorage({
            key: e,
            data: t
        }).then(function(e) {
            n();
        }).catch(function(e) {
            n();
        });
    });
}

function get(e) {
    return new Promise(function(t, n) {
        _wepy2.default.getStorage({
            key: e
        }).then(function(e) {
            t(e.data);
        }).catch(function(e) {
            t();
        });
    });
}

function remove(e) {
    return new Promise(function(t, n) {
        _wepy2.default.removeStorage({
            key: e
        }).then(function(e) {
            t();
        }).catch(function(e) {
            t();
        });
    });
}

function clear() {
    return new Promise(function(e, t) {
        _wepy2.default.clearStorage().then(function(t) {
            e();
        }).catch(function(t) {
            e();
        });
    });
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _wepy = require("./../npm/wepy/lib/wepy.js"), _wepy2 = _interopRequireDefault(_wepy);

exports.default = {
    set: set,
    get: get,
    remove: remove,
    clear: clear
};