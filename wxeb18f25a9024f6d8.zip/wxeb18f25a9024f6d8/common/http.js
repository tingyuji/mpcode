function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function HttpRequest(e) {
    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, o = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "GET", n = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : "form";
    return new Promise(function(a, s) {
        e = _wepy2.default.$appConfig.rootURL + e, t = Object.assign(t, {
            version: _constant2.default.KEY_VERSION
        }), _wepy2.default.request({
            url: e,
            method: o,
            header: sessionType[n],
            data: t,
            dataType: "json"
        }).then(function(e) {
            200 === e.statusCode && 0 === e.data.errorCode ? a(e.data.results) : (console.log("HttpRequest status !== 1, detail:", e), 
            s(e.data));
        }).catch(function(e) {
            console.log("HttpRequest error:", e), s(e);
        });
    });
}

function Login(e) {
    var t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
    return new Promise(function(o, n) {
        _wepy2.default.login().then(function(a) {
            HttpRequest("/wx/authNew", {
                code: a.code,
                appKey: "politicalExamServer"
            }, "GET").then(function(a) {
                e.openId = a.openId;
                var s = _wepy2.default.$instance.globalData.scene || "";
                if (a.isAuth || t) _kcLog2.default.send({
                    pagename: "HomePage",
                    name: "loginSuccess",
                    category: "login",
                    pt: "mini"
                }), e.scene = s, HttpRequest("/wx/loginNew", e, "POST", "json").then(function(e) {
                    var t = _storage2.default.set(_constant2.default.KEY_IS_AUTH, !0), r = _storage2.default.set(_constant2.default.KEY_TOKEN, e.token), u = _storage2.default.set(_constant2.default.KEY_OPENID, a.openId), c = _storage2.default.set(_constant2.default.KEY_UNIONID, e.unionId);
                    Promise.all([ t, r, u, c ]).then(function(e) {
                        reportNewUser(a.isNew, s, a.openId), o();
                    }).catch(function(e) {
                        console.log("Login storage-token error:", e), n(e);
                    });
                }).catch(function(e) {
                    console.log("Login request-login error:", e), n(e);
                }); else {
                    var r = _storage2.default.set(_constant2.default.KEY_TOKEN, a.token), u = _storage2.default.set(_constant2.default.KEY_IS_AUTH, !1), c = _storage2.default.set(_constant2.default.KEY_IS_NEW, a.isNew), i = _storage2.default.set(_constant2.default.KEY_OPENID, a.openId);
                    _kcLog2.default.send({
                        pagename: "HomePage",
                        name: "signupSuccess",
                        category: "signUp",
                        pt: "mini"
                    }), Promise.all([ r, u, c, i ]).then(function(e) {
                        reportNewUser(a.isNew, s, a.openId), o();
                    }).catch(function(e) {
                        console.log("Login storage-all error:", e), n(e);
                    });
                }
            }).catch(function(e) {
                console.log("Login request-auth error:", e), n(e);
            });
        }).catch(function(e) {
            console.log("Login wx-login error:", e), n(e);
        });
    });
}

function register(e) {
    var t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
    return new Promise(function(o, n) {
        HttpRequest("/wx/authNew", {
            code: e.code,
            appKey: "politicalExamServer"
        }, "GET").then(function(a) {
            e.openId = a.openId;
            var s = _wepy2.default.$instance.globalData.scene || "";
            if (a.isAuth || t) e.scene = s, HttpRequest("/wx/loginNew", e, "POST", "json").then(function(e) {
                var t = _storage2.default.set(_constant2.default.KEY_IS_AUTH, !0), r = _storage2.default.set(_constant2.default.KEY_TOKEN, e.token), u = _storage2.default.set(_constant2.default.KEY_OPENID, a.openId), c = _storage2.default.set(_constant2.default.KEY_UNIONID, e.unionId);
                Promise.all([ t, r, u, c ]).then(function(e) {
                    reportNewUser(a.isNew, s, a.openId), o();
                }).catch(function(e) {
                    console.log("Login storage-token error:", e), n(e);
                });
            }).catch(function(e) {
                console.log("Login request-login error:", e), n(e);
            }); else {
                var r = _storage2.default.set(_constant2.default.KEY_TOKEN, a.token), u = _storage2.default.set(_constant2.default.KEY_IS_AUTH, !1), c = _storage2.default.set(_constant2.default.KEY_IS_NEW, a.isNew), i = _storage2.default.set(_constant2.default.KEY_OPENID, a.openId);
                Promise.all([ r, u, c, i ]).then(function(e) {
                    reportNewUser(a.isNew, s, a.openId), o();
                }).catch(function(e) {
                    console.log("Login storage-all error:", e), n(e);
                });
            }
        }).catch(function(e) {
            console.log("Login request-auth error:", e), n(e);
        });
    });
}

function reportNewUser(e, t, o) {
    var n = getCurrentPages(), a = n[n.length - 1].options, s = {
        BSceneCode: "auth",
        BDescribe: "授权成功",
        BIsNew: e ? 1 : 0,
        ext: {
            scene: t
        }
    }, r = "share" === a.from && a.openId;
    r && r !== o && (s.ext = Object.assign(s.ext, {
        shareUser: r
    })), _common2.default.business(s);
}

function HttpRequestV2(e) {
    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, o = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "GET", n = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : "form";
    return new Promise(function(a, s) {
        -1 === e.indexOf("http") && (e = _wepy2.default.$appConfig.rootURL + e), t = Object.assign(t, {
            version: _constant2.default.KEY_VERSION
        });
        var r = wx.getStorageSync(_constant2.default.KEY_TOKEN) || "", u = sessionType[n];
        u.token = r, _wepy2.default.request({
            url: e,
            method: o,
            header: u,
            data: t,
            dataType: "json"
        }).then(function(n) {
            200 === n.statusCode && 0 === n.data.errorCode ? a(n.data.results) : 200 === n.statusCode && 4 === n.data.errorCode ? (_wepy2.default.removeStorage({
                key: _constant2.default.KEY_TOKEN
            }), Login({}).then(function() {
                var n = wx.getStorageSync(_constant2.default.KEY_TOKEN) || "";
                u.token = n, _wepy2.default.request({
                    url: e,
                    method: o,
                    header: u,
                    data: t,
                    dataType: "json"
                }).then(function(e) {
                    200 === e.statusCode && 0 === e.data.errorCode ? a(e.data.results) : (console.log("HttpRequestV2 retry status !== 1, detail:", e), 
                    s(e.data));
                }).catch(function(e) {
                    console.log("HttpRequestV2 retry error:", e), s(e);
                });
            }).catch(function(e) {
                console.log("HttpRequestV2 Login, error:", e), s(e);
            })) : 200 === n.statusCode && 5022 === n.data.errorCode ? wx.reLaunch({
                url: "login"
            }) : (console.log("HttpRequestV2 status !== 1, detail:", n), s(n.data));
        }).catch(function(e) {
            s(e);
        });
    });
}

function get(e, t) {
    return HttpRequestV2(e, t);
}

function post(e, t, o) {
    return HttpRequestV2(e, t, "POST", o);
}

var _wepy = require("./../npm/wepy/lib/wepy.js"), _wepy2 = _interopRequireDefault(_wepy), _storage = require("./storage.js"), _storage2 = _interopRequireDefault(_storage), _constant = require("./constant.js"), _constant2 = _interopRequireDefault(_constant), _common = require("./common.js"), _common2 = _interopRequireDefault(_common), _kcLog = require("./../npm/@kc-base/kc-log/dist/kc-log.js"), _kcLog2 = _interopRequireDefault(_kcLog), sessionType = {
    json: {
        "content-type": "application/json"
    },
    form: {
        "content-type": "application/x-www-form-urlencoded"
    }
};

module.exports = {
    get: get,
    post: post,
    Login: Login,
    register: register
};