var log = wx.getRealtimeLogManager ? wx.getRealtimeLogManager() : null;

module.exports = {
    info: function() {
        log && log.info.apply(log, arguments);
    },
    warn: function() {
        log && log.warn.apply(log, arguments);
    },
    error: function() {
        log && log.error.apply(log, arguments);
    },
    setFilterMsg: function(o) {
        log && log.setFilterMsg && "string" == typeof o && log.setFilterMsg(o);
    },
    addFilterMsg: function(o) {
        log && log.addFilterMsg && "string" == typeof o && log.addFilterMsg(o);
    }
};