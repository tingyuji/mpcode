function _toConsumableArray(r) {
    if (Array.isArray(r)) {
        for (var e = 0, t = Array(r.length); e < r.length; e++) t[e] = r[e];
        return t;
    }
    return Array.from(r);
}

function _asyncToGenerator(r) {
    return function() {
        var e = r.apply(this, arguments);
        return new Promise(function(r, t) {
            function n(a, o) {
                try {
                    var c = e[a](o), u = c.value;
                } catch (r) {
                    return void t(r);
                }
                if (!c.done) return Promise.resolve(u).then(function(r) {
                    n("next", r);
                }, function(r) {
                    n("throw", r);
                });
                r(u);
            }
            return n("next");
        });
    };
}

function trycatch() {
    var r = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "handleError", e = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
    return function(t, n, a) {
        var o = a.value;
        return a.value = _asyncToGenerator(regeneratorRuntime.mark(function a() {
            var c, u, i, s = arguments;
            return regeneratorRuntime.wrap(function(a) {
                for (;;) switch (a.prev = a.next) {
                  case 0:
                    for (a.prev = 0, c = s.length, u = Array(c), i = 0; i < c; i++) u[i] = s[i];
                    if (!e) {
                        a.next = 7;
                        break;
                    }
                    return a.next = 5, o.call.apply(o, [ this ].concat(_toConsumableArray(u)));

                  case 5:
                    a.next = 8;
                    break;

                  case 7:
                    o.call.apply(o, [ this ].concat(_toConsumableArray(u)));

                  case 8:
                    a.next = 19;
                    break;

                  case 10:
                    if (a.prev = 10, a.t0 = a.catch(0), console.log("错误监控 捕获错误信息 err=", a.t0), !e) {
                        a.next = 18;
                        break;
                    }
                    return a.next = 16, t[r].call(this, a.t0, n);

                  case 16:
                    a.next = 19;
                    break;

                  case 18:
                    t[r].call(this, a.t0, n);

                  case 19:
                  case "end":
                    return a.stop();
                }
            }, a, this, [ [ 0, 10 ] ]);
        })), a;
    };
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.trycatch = trycatch;