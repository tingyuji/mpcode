function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function _classCallCheck(e, n) {
    if (!(e instanceof n)) throw new TypeError("Cannot call a class as a function");
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _createClass = function() {
    function e(e, n) {
        for (var t = 0; t < n.length; t++) {
            var r = n[t];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), 
            Object.defineProperty(e, r.key, r);
        }
    }
    return function(n, t, r) {
        return t && e(n.prototype, t), r && e(n, r), n;
    };
}(), _wepy = require("./../npm/wepy/lib/wepy.js"), _wepy2 = _interopRequireDefault(_wepy), reportURL = "https://analyze.kaochong.com/business", Report = function() {
    function e(n, t, r) {
        _classCallCheck(this, e), this.instance = null, this.BSource = n, this.BVersion = t, 
        this.idObj = r;
    }
    return _createClass(e, [ {
        key: "send",
        value: function(e) {
            var n = getCurrentPages(), t = n[n.length - 1].route;
            e = Object.assign({
                BSource: this.BSource,
                BVersion: this.BVersion,
                BClientSource: "FE",
                BCreateTime: +new Date().getTime(),
                BPage: t
            }, this.idObj, e), _wepy2.default.request({
                data: e,
                url: reportURL,
                method: "POST",
                header: {
                    "content-type": "application/json"
                },
                dataType: "json"
            }), console.log("【send】complete data... \n " + JSON.stringify(e, null, 2));
        }
    } ], [ {
        key: "init",
        value: function(n, t, r, i, o) {
            if (!this.instance || this.instance && r && "noAuth" === this.instance.idObj.BUserId) {
                if (!n) throw Error("Report.init需传入项目标识 【BSource】");
                if (!t) throw Error("Report.init需传入项目版本号【BVersion】");
                if (!r && (r = "noAuth", console.warn("------------------------------------ \n*\n* Report.init需传入用户unionId【BUserId】\n*\n* 您目前没有传入 \n*\n* 如果存在unionID请补充 \n*\n* 如果不存在请务必传入openID \n*\n ------------------------------------"), 
                !i)) throw Error("Report.init需传入用户标识【BOpenId】");
                console.log("【init】" + n + "_" + t + " reportor...[" + r + "]");
                var s = {
                    BUserId: r
                };
                i && Object.assign(s, {
                    BOpenId: i
                }), o && Object.assign(s, {
                    BUID: o
                }), this.instance = new e(n, t, s);
            }
            return this.instance;
        }
    } ]), e;
}();

exports.default = Report;