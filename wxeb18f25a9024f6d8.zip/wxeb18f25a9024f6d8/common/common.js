function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function business(e) {
    try {
        var r = wx.getStorageSync(_constant2.default.KEY_UNIONID), t = wx.getStorageSync(_constant2.default.KEY_OPENID);
        _report2.default.init("zhengzhiyiqianti", _constant2.default.KEY_VERSION, r, t).send(e);
    } catch (e) {
        console.log(e);
    }
}

function getErrorWarnMsg(e) {
    if (!e) return null;
    var r = [ {
        code: 1001,
        msg: "downloadFile",
        warnMsg: "网络加载失败(1001)"
    }, {
        code: 1002,
        msg: "connect to",
        warnMsg: "网络加载失败(1002)"
    }, {
        code: 1003,
        msg: "timed out",
        warnMsg: "网络加载失败(1003)"
    }, {
        code: 1004,
        msg: "timeout",
        warnMsg: "网络加载失败(1004)"
    }, {
        code: 1005,
        msg: "服务器",
        warnMsg: "网络加载失败(1005)"
    }, {
        code: 1006,
        msg: "互联网",
        warnMsg: "网络加载失败(1006)"
    }, {
        code: 1007,
        msg: "saveFile",
        warnMsg: "网络加载失败(1007)"
    }, {
        code: 1008,
        msg: "request",
        warnMsg: "网络加载失败(1008)"
    }, {
        code: 1009,
        msg: "getImageInfo",
        warnMsg: "网络加载失败(1008)"
    } ], t = r.find(function(r) {
        return e.includes(r.msg);
    });
    return t ? t.warnMsg : null;
}

function showModal(e) {
    var r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "提示", t = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2];
    return new Promise(function(o, n) {
        wx.showModal({
            title: r,
            content: e,
            showCancel: t,
            success: function(e) {
                o(e.confirm ? 1 : 0);
            }
        });
    });
}

function shareTxt(e) {
    var r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "安利一个政治刷题小程序给你，290万考研人都用过！", t = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "../images/img_share@2x.png";
    e || (e = {}), e.from = "share";
    try {
        if (!e.openId) {
            var o = wx.getStorageSync(_constant2.default.KEY_OPENID) || "";
            o && (e.openId = o);
        }
    } catch (e) {}
    var n = "/pages/index";
    return Object.keys(e).forEach(function(r, t) {
        n += (0 === t ? "?" : "&") + r + "=" + e[r];
    }), console.log(n), {
        title: r,
        imageUrl: t,
        path: n
    };
}

function collectFormID(e) {
    var r = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
    if (e && allFormIds.push({
        formId: e
    }), console.log("收集 formId ---- ", allFormIds), Array.isArray(allFormIds) && (allFormIds.length >= 5 || r)) {
        if (flagFormId) return;
        flagFormId = !0;
        var t = allFormIds;
        allFormIds = [], t.length > 0 && _api2.default.submitFormId({
            formIds: JSON.stringify(t)
        }).then(function(e) {
            flagFormId = !1, console.log("submitFormId success");
        }).catch(function(e) {
            flagFormId = !1, console.log(e, "submitFormId failed");
        });
    }
}

function getQueryParam(e, r) {
    var t = new RegExp("(\\?|^|&)" + r + "=([^&]*)(&|$)", "i"), o = e.match(t);
    return null != o ? unescape(o[2]) : null;
}

function obj2url(e) {
    var r = "?";
    return Object.keys(e).forEach(function(t) {
        r += t + "=" + e[t] + "&";
    }), r.substring(0, r.length - 1);
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _api = require("./api.js"), _api2 = _interopRequireDefault(_api), _constant = require("./constant.js"), _constant2 = _interopRequireDefault(_constant), _report = require("./report.js"), _report2 = _interopRequireDefault(_report), allFormIds = [], flagFormId = !1;

exports.default = {
    getErrorWarnMsg: getErrorWarnMsg,
    showModal: showModal,
    shareTxt: shareTxt,
    collectFormID: collectFormID,
    getQueryParam: getQueryParam,
    obj2url: obj2url,
    business: business
};