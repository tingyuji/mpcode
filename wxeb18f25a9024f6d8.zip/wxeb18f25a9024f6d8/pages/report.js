function _interopRequireDefault(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

function _asyncToGenerator(t) {
    return function() {
        var e = t.apply(this, arguments);
        return new Promise(function(t, n) {
            function i(r, o) {
                try {
                    var a = e[r](o), s = a.value;
                } catch (t) {
                    return void n(t);
                }
                if (!a.done) return Promise.resolve(s).then(function(t) {
                    i("next", t);
                }, function(t) {
                    i("throw", t);
                });
                t(s);
            }
            return i("next");
        });
    };
}

function _classCallCheck(t, e) {
    if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(t, e) {
    if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !e || "object" != typeof e && "function" != typeof e ? t : e;
}

function _inherits(t, e) {
    if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
    t.prototype = Object.create(e && e.prototype, {
        constructor: {
            value: t,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e);
}

function _applyDecoratedDescriptor(t, e, n, i, r) {
    var o = {};
    return Object.keys(i).forEach(function(t) {
        o[t] = i[t];
    }), o.enumerable = !!o.enumerable, o.configurable = !!o.configurable, ("value" in o || o.initializer) && (o.writable = !0), 
    o = n.slice().reverse().reduce(function(n, i) {
        return i(t, e, n) || n;
    }, o), r && void 0 !== o.initializer && (o.value = o.initializer ? o.initializer.call(r) : void 0, 
    o.initializer = void 0), void 0 === o.initializer && (Object.defineProperty(t, e, o), 
    o = null), o;
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _createClass = function() {
    function t(t, e) {
        for (var n = 0; n < e.length; n++) {
            var i = e[n];
            i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), 
            Object.defineProperty(t, i.key, i);
        }
    }
    return function(e, n, i) {
        return n && t(e.prototype, n), i && t(e, i), e;
    };
}(), _dec, _dec2, _dec3, _desc, _value, _class, _wepy = require("./../npm/wepy/lib/wepy.js"), _wepy2 = _interopRequireDefault(_wepy), _api = require("./../common/api.js"), _api2 = _interopRequireDefault(_api), _common = require("./../common/common.js"), _common2 = _interopRequireDefault(_common), _PointTips = require("./../components/PointTips.js"), _PointTips2 = _interopRequireDefault(_PointTips), _decorator = require("./../common/decorator.js"), _KcLoading = require("./../components/KcLoading.js"), _KcLoading2 = _interopRequireDefault(_KcLoading), _KcErrorModal = require("./../components/KcErrorModal.js"), _KcErrorModal2 = _interopRequireDefault(_KcErrorModal), _eChart = require("./../common/e-chart.js"), _eChart2 = _interopRequireDefault(_eChart), _storage = require("./../common/storage.js"), _storage2 = _interopRequireDefault(_storage), _KcUpValue = require("./../components/KcUpValue.js"), _KcUpValue2 = _interopRequireDefault(_KcUpValue), _kcLog = require("./../npm/@kc-base/kc-log/dist/kc-log.js"), _kcLog2 = _interopRequireDefault(_kcLog), log = require("./../common/log.js"), touchStartX = 0, touchMoveX = 0, touchStartY = 0, touchMoveY = 0, Report = (_dec = (0, 
_decorator.trycatch)(), _dec2 = (0, _decorator.trycatch)(), _dec3 = (0, _decorator.trycatch)(), 
_class = function(t) {
    function e() {
        var t, n, i, r;
        _classCallCheck(this, e);
        for (var o = arguments.length, a = Array(o), s = 0; s < o; s++) a[s] = arguments[s];
        return n = i = _possibleConstructorReturn(this, (t = e.__proto__ || Object.getPrototypeOf(e)).call.apply(t, [ this ].concat(a))), 
        i.config = {
            navigationBarTitleText: "刷题报告"
        }, i.data = {
            loadingHide: !0,
            tipsTitle: "题目对应的考点掌握情况出炉啦，复习更高效",
            tipsIcon: "../images/report/icon_tips.png",
            tipsShow: !1,
            suggest: !1,
            onlyFalse: !1,
            sid: "",
            day: 0,
            days: [],
            daysText: "",
            type: "",
            name: "",
            allTopic: "",
            rnum: "",
            fnum: "",
            fTopicNum: "",
            rTopicNum: "",
            overPercentage: 0,
            proposal: [],
            content: [],
            hasPointDetail: 0,
            showCanvas: !1,
            width: 0,
            accNum: 0,
            moved: !1,
            isSubscribeRead: !0,
            pointToggleState: [],
            learnDay: 0,
            unlockDay: 0,
            allDay: 0,
            upValue: 0,
            title: "",
            text1: "",
            text2: "",
            text3: "",
            leftBtnText: "",
            rightBtnText: "",
            rightBtnTips: "",
            leftCb: null,
            rightCb: null,
            imgSrc: "",
            wrongSectionShow: !1,
            wrongSectionNum: 0,
            isAuth: !1,
            subjectList: [],
            addWrongSectionNum: 0,
            link: {},
            hasVip: !1
        }, i.$repeat = {}, i.$props = {
            KcLoading: {
                "xmlns:v-bind": "",
                "v-bind:loadingHide.sync": "loadingHide"
            },
            PointTips: {
                "xmlns:v-bind": "",
                "v-bind:title.sync": "tipsTitle",
                "v-bind:icon.sync": "tipsIcon"
            },
            KcUpValue: {
                "xmlns:v-bind": "",
                "v-bind:title.sync": "title",
                "v-bind:text1.sync": "text1",
                "v-bind:text2.sync": "text2",
                "v-bind:text3.sync": "text3",
                "v-bind:leftBtnText.sync": "leftBtnText",
                "v-bind:rightBtnText.sync": "rightBtnText",
                "v-bind:leftCb.sync": "leftCb",
                "v-bind:rightCb.sync": "rightCb",
                "v-bind:imgSrc.sync": "imgSrc",
                "v-bind:rightBtnTips.sync": "rightBtnTips"
            }
        }, i.$events = {}, i.components = {
            KcLoading: _KcLoading2.default,
            KcErrorModal: _KcErrorModal2.default,
            PointTips: _PointTips2.default,
            KcUpValue: _KcUpValue2.default
        }, i.mixins = [], i.events = {
            modalCloseCb: function() {
                this.showCanvas = !0, this.setEchart();
            }
        }, i.methods = {
            tapSuggest: function() {
                this.suggest = !0, wx.createSelectorQuery().select(".container").boundingClientRect(function(t) {
                    setTimeout(function() {
                        wx.pageScrollTo({
                            scrollTop: t.bottom
                        });
                    }, 100);
                }).exec();
            },
            back: function() {
                wx.navigateBack({
                    delta: 1
                });
            },
            formSubmit: function(t) {
                var e = t.detail.formId;
                _common2.default.collectFormID(e);
            },
            touchStart: function(t) {
                touchStartX = t.touches[0].pageX, touchStartY = t.touches[0].pageY;
            },
            touchMove: function(t) {
                touchMoveX = t.touches[0].pageX, touchMoveY = t.touches[0].pageY, this.moved = !0;
            },
            touchEnd: function(t) {
                var e = touchMoveX - touchStartX, n = touchMoveY - touchStartY;
                e > 0 && n > -2 && n < 2 && (this.moved = !1, this.$navigate("index"));
            },
            pointDetailToggle: function(t) {
                1 === this.type && wx.reportAnalytics("report_20_click_toggle", {
                    pointId: t
                });
                for (var e = 0; e < this.content.length; e++) for (var n = 0; n < this.content[e].points.length; n++) {
                    var i = this.content[e].points[n];
                    if (i.pointId === t) return void (this.pointToggleState[i.index] = !this.pointToggleState[i.index]);
                }
            },
            goReview: function() {
                _kcLog2.default.send({
                    pagename: "reportPage",
                    name: "reviewClick",
                    category: "webClick",
                    pt: "mini"
                }), wx.redirectTo({
                    url: "reviewIndex?sid=" + this.sid
                });
            },
            wrongTopic: function() {
                log.info("报告页回顾错题去学习", "study?sid=" + this.sid + "&days=" + JSON.stringify(this.days)), 
                wx.redirectTo({
                    url: "study?sid=" + this.sid + "&days=" + JSON.stringify(this.days) + "&type=3&onlyFalse=" + this.onlyFalse
                });
            },
            goNext: function() {
                if (_kcLog2.default.send({
                    pagename: "reportPage",
                    name: "nextClick",
                    category: "webClick",
                    pt: "mini"
                }), this.hasVip) wx.redirectTo({
                    url: "learnIndex?sid=" + this.sid + "&day=" + (this.learnDay + 1)
                }); else if (this.learnDay < this.unlockDay && this.unlockDay <= this.allDay) wx.redirectTo({
                    url: "learnIndex?sid=" + this.sid + "&day=" + (this.learnDay + 1)
                }); else if (this.upValue >= 20) {
                    this.imgSrc = "../images/components/icon_lock@2x.png", this.title = "解锁下一天题目", this.text1 = "需消耗", 
                    this.text2 = "20点UP值", this.text3 = "你目前拥有" + this.upValue + "点UP值", this.leftBtnText = "消耗UP值解锁", 
                    this.rightBtnText = "获取无限UP值", this.rightBtnTips = "限时活动";
                    var t = this.day + 1, e = this.sid;
                    this.leftCb = function() {
                        this.unlockCourse(e, t);
                    }, this.rightCb = function() {
                        _wepy2.default.navigateTo({
                            url: "web?url=" + encodeURIComponent("https://mp.weixin.qq.com/s?__biz=MzU2ODcxNTYxNQ==&mid=2247709644&idx=1&sn=3c4d5f76282c25f9f002ec736bd29f51&chksm=fc8443fccbf3caea2eacaebff39971de1e76aa63c6a4d984c933830e6d9991137062adf7ae07#rd")
                        }), this.close(), this.modalCloseCb();
                    }, this.showCanvas = !1, this.$invoke("KcUpValue", "showModal");
                } else this.imgSrc = "../images/components/icon_face@2x.png", this.title = "UP值不够无法解锁", 
                this.text1 = "解锁题目需消耗", this.text2 = "20点UP值", this.text3 = "你目前拥有" + this.upValue + "点UP值", 
                this.leftBtnText = "收集UP值", this.rightBtnText = "获取无限UP值", this.rightBtnTips = "限时活动", 
                this.leftCb = function() {
                    wx.navigateTo({
                        url: "upValue"
                    }), this.close(), this.modalCloseCb();
                }, this.rightCb = function() {
                    _wepy2.default.navigateTo({
                        url: "web?url=" + encodeURIComponent("https://mp.weixin.qq.com/s?__biz=MzU2ODcxNTYxNQ==&mid=2247709644&idx=1&sn=3c4d5f76282c25f9f002ec736bd29f51&chksm=fc8443fccbf3caea2eacaebff39971de1e76aa63c6a4d984c933830e6d9991137062adf7ae07#rd")
                    }), this.close(), this.modalCloseCb();
                }, this.showCanvas = !1, this.$invoke("KcUpValue", "showModal");
            },
            goStudyData: function() {
                wx.redirectTo({
                    url: "studyData"
                });
            }
        }, r = n, _possibleConstructorReturn(i, r);
    }
    return _inherits(e, t), _createClass(e, [ {
        key: "onLoad",
        value: function() {
            function t(t) {
                return e.apply(this, arguments);
            }
            var e = _asyncToGenerator(regeneratorRuntime.mark(function t(e) {
                return regeneratorRuntime.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return _kcLog2.default.send({
                            pagename: "reportPage",
                            name: "reportPageView",
                            category: "webPageView",
                            pt: "mini"
                        }), this.link = e, this.sid = e.sid, this.days = e.days ? JSON.parse(e.days) : [], 
                        this.day = parseInt(this.days[0]), this.daysText = this.days.reduce(function(t, e, n) {
                            return t + (0 === n ? "" : "/") + e;
                        }, "DAY"), this.type = Number(e.type), this.onlyFalse = JSON.parse(e.onlyFalse), 
                        this.width = 750 / wx.getSystemInfoSync().windowWidth, "2" === this.type && wx.setNavigationBarTitle({
                            title: "复习报告"
                        }), this.getData(), this.wrongSection(), this.getUserInfo(), t.next = 15, _storage2.default.get("is_auth");

                      case 15:
                        if (t.t0 = t.sent, t.t0) {
                            t.next = 18;
                            break;
                        }
                        t.t0 = !1;

                      case 18:
                        return this.isAuth = t.t0, t.next = 21, _storage2.default.get("hasVip");

                      case 21:
                        this.hasVip = t.sent;

                      case 22:
                      case "end":
                        return t.stop();
                    }
                }, t, this);
            }));
            return t;
        }()
    }, {
        key: "getData",
        value: function() {
            function t() {
                return e.apply(this, arguments);
            }
            var e = _asyncToGenerator(regeneratorRuntime.mark(function t() {
                var e, n, i = this;
                return regeneratorRuntime.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return this.loadingHide = !1, t.next = 3, _storage2.default.get("token");

                      case 3:
                        if (t.t0 = t.sent, t.t0) {
                            t.next = 6;
                            break;
                        }
                        t.t0 = 0;

                      case 6:
                        return e = t.t0, t.next = 9, _api2.default.learnInfo({
                            subjectId: this.sid,
                            stage: this.days.join(","),
                            type: this.type,
                            needProposal: !0,
                            token: e
                        });

                      case 9:
                        n = t.sent, this.name = n.abbreviationName, this.rnum = n.rnum, this.fnum = n.fnum, 
                        this.fTopicNum = n.fTopicNum, this.rTopicNum = n.rTopicNum, this.proposal = n.proposal, 
                        this.content = n.content, this.allTopic = n.allTopic, this.overPercentage = n.overPercentage, 
                        this.hasPointDetail = n.hasPointDetail, this.loadingHide = !0, this.showCanvas = !0, 
                        this.accNum = parseInt(n.rnum / n.allQuestion * 100), this.$apply(), this.setEchart(), 
                        this.content.forEach(function(t) {
                            t.points.forEach(function(t, e) {
                                t.index = e, i.pointToggleState.push(!1);
                            });
                        }), this.fnum ? wx.reportAnalytics("report_20_show_wrongtopic", {}) : wx.reportAnalytics("report_20_show_gore", {}), 
                        this.allDay !== this.day && wx.reportAnalytics("report_20_show_next", {}), setTimeout(function() {
                            i.tipsShow = !0, i.$apply();
                        }, 500);

                      case 29:
                      case "end":
                        return t.stop();
                    }
                }, t, this);
            }));
            return t;
        }()
    }, {
        key: "wrongSection",
        value: function() {
            function t() {
                return e.apply(this, arguments);
            }
            var e = _asyncToGenerator(regeneratorRuntime.mark(function t() {
                var e, n;
                return regeneratorRuntime.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return t.next = 2, _storage2.default.get("wrongSectionNum");

                      case 2:
                        if (t.t0 = t.sent, t.t0) {
                            t.next = 5;
                            break;
                        }
                        t.t0 = 0;

                      case 5:
                        return e = t.t0, t.next = 8, _api2.default.wrongSection();

                      case 8:
                        n = t.sent, this.wrongSectionNum = n.length, this.wrongSectionNum - e > 0 && (this.addWrongSectionNum = this.wrongSectionNum - e, 
                        this.wrongSectionShow = !0, wx.reportAnalytics("report_20_show_wrongsection", {})), 
                        _storage2.default.set("wrongSectionNum", this.wrongSectionNum);

                      case 12:
                      case "end":
                        return t.stop();
                    }
                }, t, this);
            }));
            return t;
        }()
    }, {
        key: "getUserInfo",
        value: function() {
            function t() {
                return e.apply(this, arguments);
            }
            var e = _asyncToGenerator(regeneratorRuntime.mark(function t() {
                var e, n = this;
                return regeneratorRuntime.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return t.next = 2, _api2.default.getUserInfo();

                      case 2:
                        e = t.sent, this.subjectList = e.subjectList, this.subjectList.forEach(function(t) {
                            t.subjectId === parseInt(n.sid) && (n.learnDay = t.stage, n.unlockDay = t.unlockDays, 
                            n.allDay = t.totalDays);
                        }), this.upValue = e.user.upValue;

                      case 6:
                      case "end":
                        return t.stop();
                    }
                }, t, this);
            }));
            return t;
        }()
    }, {
        key: "handleError",
        value: function() {
            function t(t, n) {
                return e.apply(this, arguments);
            }
            var e = _asyncToGenerator(regeneratorRuntime.mark(function t(e, n) {
                var i = this;
                return regeneratorRuntime.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        this.loadingHide = !0, this.$apply(), this.$invoke("KcErrorModal", "showModal", {
                            err: e,
                            btnMsg: "重新加载",
                            cb: function() {
                                i.getData();
                            }
                        });

                      case 3:
                      case "end":
                        return t.stop();
                    }
                }, t, this);
            }));
            return t;
        }()
    }, {
        key: "onShareAppMessage",
        value: function(t) {
            return _common2.default.shareTxt();
        }
    }, {
        key: "setEchart",
        value: function() {
            var t = this;
            new _eChart2.default({
                canvasId: "ringCanvas",
                type: "ring",
                extra: {
                    ringWidth: 15 / t.width,
                    pie: {
                        offsetAngle: -90
                    }
                },
                series: [ {
                    name: "错误",
                    data: t.fnum,
                    color: "#FF9C79"
                }, {
                    name: "正确",
                    data: t.rnum,
                    color: "#D2F5E2"
                } ],
                width: 310 / t.width,
                height: 310 / t.width,
                dataLabel: !1,
                legend: !1
            });
        }
    } ]), e;
}(_wepy2.default.page), _applyDecoratedDescriptor(_class.prototype, "getData", [ _dec ], Object.getOwnPropertyDescriptor(_class.prototype, "getData"), _class.prototype), 
_applyDecoratedDescriptor(_class.prototype, "wrongSection", [ _dec2 ], Object.getOwnPropertyDescriptor(_class.prototype, "wrongSection"), _class.prototype), 
_applyDecoratedDescriptor(_class.prototype, "getUserInfo", [ _dec3 ], Object.getOwnPropertyDescriptor(_class.prototype, "getUserInfo"), _class.prototype), 
_class);

Page(require("./../npm/wepy/lib/wepy.js").default.$createPage(Report, "pages/report"));