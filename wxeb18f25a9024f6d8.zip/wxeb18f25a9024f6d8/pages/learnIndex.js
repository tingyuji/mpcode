function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function _asyncToGenerator(e) {
    return function() {
        var t = e.apply(this, arguments);
        return new Promise(function(e, n) {
            function r(o, i) {
                try {
                    var a = t[o](i), s = a.value;
                } catch (e) {
                    return void n(e);
                }
                if (!a.done) return Promise.resolve(s).then(function(e) {
                    r("next", e);
                }, function(e) {
                    r("throw", e);
                });
                e(s);
            }
            return r("next");
        });
    };
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t;
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

function _applyDecoratedDescriptor(e, t, n, r, o) {
    var i = {};
    return Object.keys(r).forEach(function(e) {
        i[e] = r[e];
    }), i.enumerable = !!i.enumerable, i.configurable = !!i.configurable, ("value" in i || i.initializer) && (i.writable = !0), 
    i = n.slice().reverse().reduce(function(n, r) {
        return r(e, t, n) || n;
    }, i), o && void 0 !== i.initializer && (i.value = i.initializer ? i.initializer.call(o) : void 0, 
    i.initializer = void 0), void 0 === i.initializer && (Object.defineProperty(e, t, i), 
    i = null), i;
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _createClass = function() {
    function e(e, t) {
        for (var n = 0; n < t.length; n++) {
            var r = t[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), 
            Object.defineProperty(e, r.key, r);
        }
    }
    return function(t, n, r) {
        return n && e(t.prototype, n), r && e(t, r), t;
    };
}(), _dec, _desc, _value, _class, _wepy = require("./../npm/wepy/lib/wepy.js"), _wepy2 = _interopRequireDefault(_wepy), _api = require("./../common/api.js"), _api2 = _interopRequireDefault(_api), _common = require("./../common/common.js"), _common2 = _interopRequireDefault(_common), _PointTips = require("./../components/PointTips.js"), _PointTips2 = _interopRequireDefault(_PointTips), _decorator = require("./../common/decorator.js"), _KcLoading = require("./../components/KcLoading.js"), _KcLoading2 = _interopRequireDefault(_KcLoading), _KcErrorModal = require("./../components/KcErrorModal.js"), _KcErrorModal2 = _interopRequireDefault(_KcErrorModal), _storage = require("./../common/storage.js"), _storage2 = _interopRequireDefault(_storage), log = require("./../common/log.js"), LearnIndex = (_dec = (0, 
_decorator.trycatch)(), _class = function(e) {
    function t() {
        var e, n, r, o;
        _classCallCheck(this, t);
        for (var i = arguments.length, a = Array(i), s = 0; s < i; s++) a[s] = arguments[s];
        return n = r = _possibleConstructorReturn(this, (e = t.__proto__ || Object.getPrototypeOf(t)).call.apply(e, [ this ].concat(a))), 
        r.config = {
            navigationBarTitleText: "考点预览",
            navigationBarTextStyle: "white",
            navigationBarBackgroundColor: "#7B99FF"
        }, r.$repeat = {}, r.$props = {
            KcLoading: {
                "xmlns:v-bind": "",
                "v-bind:loadingHide.sync": "loadingHide"
            },
            PointTips: {
                "xmlns:v-bind": "",
                "v-bind:title.sync": "tipsTitle",
                "v-bind:icon.sync": "tipsIcon",
                "xmlns:wx": ""
            }
        }, r.$events = {}, r.components = {
            KcLoading: _KcLoading2.default,
            KcErrorModal: _KcErrorModal2.default,
            PointTips: _PointTips2.default
        }, r.mixins = [], r.data = {
            loadingHide: !0,
            tipsTitle: "先看下题目对应的每章考点哦，做到心里有数~",
            tipsIcon: "../images/learn/icon_tips.png",
            tipsShow: !1,
            sid: "",
            day: "",
            name: "",
            allQuestion: "",
            content: []
        }, r.methods = {
            goLearn: function() {
                function e() {
                    return t.apply(this, arguments);
                }
                var t = _asyncToGenerator(regeneratorRuntime.mark(function e() {
                    var t, n;
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            return e.next = 2, _storage2.default.get("isnewuser");

                          case 2:
                            if (e.t0 = e.sent, e.t0) {
                                e.next = 5;
                                break;
                            }
                            e.t0 = 0;

                          case 5:
                            return t = e.t0, wx.reportAnalytics("learnindex_20_click_golearn", {
                                isnewuser: t
                            }), log.info("课程列表去学习页", "sid=" + this.sid + "&days=" + JSON.stringify([ this.day ])), 
                            wx.redirectTo({
                                url: "study?sid=" + this.sid + "&days=" + JSON.stringify([ this.day ]) + "&type=1&onlyFalse=false"
                            }), _common2.default.business({
                                BSceneCode: "startLearn",
                                BDescribe: "点击学习按钮",
                                BType: 0,
                                ext: {
                                    subjectId: parseInt(this.sid),
                                    stageIndex: parseInt(this.day)
                                }
                            }), e.next = 12, _storage2.default.get("studyTime");

                          case 12:
                            if (e.t1 = e.sent, e.t1) {
                                e.next = 15;
                                break;
                            }
                            e.t1 = 0;

                          case 15:
                            n = e.t1, _storage2.default.set("studyTime", ++n);

                          case 17:
                          case "end":
                            return e.stop();
                        }
                    }, e, this);
                }));
                return e;
            }(),
            formSubmit: function(e) {
                var t = e.detail.formId;
                _common2.default.collectFormID(t);
            }
        }, o = n, _possibleConstructorReturn(r, o);
    }
    return _inherits(t, e), _createClass(t, [ {
        key: "onLoad",
        value: function(e) {
            this.sid = e.sid, this.day = e.day, this.getLearnInfo();
        }
    }, {
        key: "getLearnInfo",
        value: function() {
            function e() {
                return t.apply(this, arguments);
            }
            var t = _asyncToGenerator(regeneratorRuntime.mark(function e() {
                var t, n, r = this;
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return this.loadingHide = !1, e.next = 3, _storage2.default.get("token");

                      case 3:
                        if (e.t0 = e.sent, e.t0) {
                            e.next = 6;
                            break;
                        }
                        e.t0 = 0;

                      case 6:
                        return t = e.t0, e.next = 9, _api2.default.learnInfo({
                            subjectId: this.sid,
                            stage: this.day,
                            type: 1,
                            needProposal: !1,
                            token: t
                        });

                      case 9:
                        n = e.sent, this.name = n.abbreviationName, this.content = n.content, this.allQuestion = n.allQuestion, 
                        this.content.forEach(function(e, t) {
                            e.index = r.numToChinese(t + 1);
                        }), this.loadingHide = !0, this.$apply(), setTimeout(function() {
                            r.tipsShow = !0, r.$apply();
                        }, 500);

                      case 17:
                      case "end":
                        return e.stop();
                    }
                }, e, this);
            }));
            return e;
        }()
    }, {
        key: "handleError",
        value: function() {
            function e(e, n) {
                return t.apply(this, arguments);
            }
            var t = _asyncToGenerator(regeneratorRuntime.mark(function e(t, n) {
                var r = this;
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        this.loadingHide = !0, this.$apply(), this.$invoke("KcErrorModal", "showModal", {
                            err: t,
                            btnMsg: "重新加载",
                            cb: function() {
                                r.getLearnInfo();
                            }
                        });

                      case 3:
                      case "end":
                        return e.stop();
                    }
                }, e, this);
            }));
            return e;
        }()
    }, {
        key: "onShareAppMessage",
        value: function() {
            return _common2.default.shareTxt();
        }
    }, {
        key: "numToChinese",
        value: function(e) {
            for (var t = new Array("零", "一", "二", "三", "四", "五", "六", "七", "八", "九"), n = new Array("", "十", "百", "千", "万", "亿", "点", ""), r = ("" + e).replace(/(^0*)/g, "").split("."), o = 0, i = "", a = r[0].length - 1; a >= 0; a--) {
                switch (o) {
                  case 0:
                    i = n[7] + i;
                    break;

                  case 4:
                    new RegExp("0{4}\\d{" + (r[0].length - a - 1) + "}$").test(r[0]) || (i = n[4] + i);
                    break;

                  case 8:
                    i = n[5] + i, n[7] = n[5], o = 0;
                }
                o % 4 == 2 && 0 != r[0].charAt(a + 2) && 0 == r[0].charAt(a + 1) && (i = t[0] + i), 
                0 != r[0].charAt(a) && (i = t[r[0].charAt(a)] + n[o % 4] + i), o++;
            }
            if (r.length > 1) {
                i += n[6];
                for (var s = 0; s < r[1].length; s++) i += t[r[1].charAt(s)];
            }
            return i;
        }
    } ]), t;
}(_wepy2.default.page), _applyDecoratedDescriptor(_class.prototype, "getLearnInfo", [ _dec ], Object.getOwnPropertyDescriptor(_class.prototype, "getLearnInfo"), _class.prototype), 
_class);

Page(require("./../npm/wepy/lib/wepy.js").default.$createPage(LearnIndex, "pages/learnIndex"));