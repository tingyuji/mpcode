function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function _asyncToGenerator(e) {
    return function() {
        var t = e.apply(this, arguments);
        return new Promise(function(e, a) {
            function n(r, o) {
                try {
                    var i = t[r](o), s = i.value;
                } catch (e) {
                    return void a(e);
                }
                if (!i.done) return Promise.resolve(s).then(function(e) {
                    n("next", e);
                }, function(e) {
                    n("throw", e);
                });
                e(s);
            }
            return n("next");
        });
    };
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t;
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

function _applyDecoratedDescriptor(e, t, a, n, r) {
    var o = {};
    return Object.keys(n).forEach(function(e) {
        o[e] = n[e];
    }), o.enumerable = !!o.enumerable, o.configurable = !!o.configurable, ("value" in o || o.initializer) && (o.writable = !0), 
    o = a.slice().reverse().reduce(function(a, n) {
        return n(e, t, a) || a;
    }, o), r && void 0 !== o.initializer && (o.value = o.initializer ? o.initializer.call(r) : void 0, 
    o.initializer = void 0), void 0 === o.initializer && (Object.defineProperty(e, t, o), 
    o = null), o;
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _createClass = function() {
    function e(e, t) {
        for (var a = 0; a < t.length; a++) {
            var n = t[a];
            n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), 
            Object.defineProperty(e, n.key, n);
        }
    }
    return function(t, a, n) {
        return a && e(t.prototype, a), n && e(t, n), t;
    };
}(), _dec, _desc, _value, _class, _wepy = require("./../npm/wepy/lib/wepy.js"), _wepy2 = _interopRequireDefault(_wepy), _decorator = require("./../common/decorator.js"), _api = require("./../common/api.js"), _api2 = _interopRequireDefault(_api), _eChart = require("./../common/e-chart.js"), _eChart2 = _interopRequireDefault(_eChart), studyData = (_dec = (0, 
_decorator.trycatch)(), _class = function(e) {
    function t() {
        var e, a, n, r;
        _classCallCheck(this, t);
        for (var o = arguments.length, i = Array(o), s = 0; s < o; s++) i[s] = arguments[s];
        return a = n = _possibleConstructorReturn(this, (e = t.__proto__ || Object.getPrototypeOf(t)).call.apply(e, [ this ].concat(i))), 
        n.config = {
            navigationBarTitleText: "",
            navigationBarBackgroundColor: "#7B99FF",
            navigationBarTextStyle: "white"
        }, n.config = {}, n.data = {
            subjectIndex: 0,
            subjectData: [],
            pointData: [],
            beyondRate: 0,
            heads: [],
            couresData: [],
            noData: !1
        }, n.methods = {
            selectCourse: function(e) {
                wx.reportAnalytics("studydata_20_click_subject", {
                    id: e
                }), this.subjectIndex = parseInt(e), this.couresData[this.subjectIndex] ? this.noData = !1 : this.noData = !0;
            },
            toggleLesson: function(e, t) {
                var a = this.couresData[this.subjectIndex].chapters, n = a[t].sections;
                n[e].toggle = !n[e].toggle, this.couresData[this.subjectIndex].chapters[t].sections[e].toggle = n[e].toggle, 
                this.$apply();
            },
            gotoRanking: function(e) {
                var t = {
                    rankType: e
                };
                this.$navigate("ranking", t);
            }
        }, n.computed = {}, r = a, _possibleConstructorReturn(n, r);
    }
    return _inherits(t, e), _createClass(t, [ {
        key: "onLoad",
        value: function(e) {
            this.getData();
        }
    }, {
        key: "getData",
        value: function() {
            function e() {
                return t.apply(this, arguments);
            }
            var t = _asyncToGenerator(regeneratorRuntime.mark(function e() {
                var t, a = this;
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return e.next = 2, _api2.default.userLearnData();

                      case 2:
                        t = e.sent, this.beyondRate = t.beyondRate, this.heads = t.heads, t.subjectList && t.subjectList.forEach(function(e) {
                            a.subjectData.push(e.name), a.pointData.push(parseInt(e.rightRate));
                        }), t.content && t.content.forEach(function(e) {
                            a.couresData[e.subjectId - 1] = e;
                        }), this.couresData && this.couresData.forEach(function(e) {
                            e.chapters && e.chapters.forEach(function(e) {
                                e.sections.forEach(function(e) {
                                    e.toggle = !1;
                                });
                            });
                        }), this.couresData[this.subjectIndex] ? this.noData = !1 : this.noData = !0, this.$apply(), 
                        this.setChart();

                      case 11:
                      case "end":
                        return e.stop();
                    }
                }, e, this);
            }));
            return e;
        }()
    }, {
        key: "setChart",
        value: function() {
            console.log(wx.getSystemInfoSync().windowWidth);
            var e = wx.getSystemInfoSync().windowWidth * (670 / 750), t = wx.getSystemInfoSync().windowWidth * (325 / 750), a = {
                main: {
                    data: this.pointData,
                    categories: this.subjectData
                }
            };
            new _eChart2.default({
                canvasId: "columnCanvas",
                type: "column",
                categories: a.main.categories,
                series: [ {
                    name: "成交量",
                    data: a.main.data,
                    format: function(e, t) {
                        return e + "%";
                    },
                    color: "#6787FF"
                } ],
                yAxis: {
                    format: function(e) {
                        return e + "%";
                    },
                    min: 0,
                    max: 100,
                    disabled: !0
                },
                xAxis: {
                    disableGrid: !1,
                    type: "calibration"
                },
                extra: {
                    column: {
                        width: 30
                    }
                },
                width: e,
                height: t,
                legend: !1
            });
        }
    } ]), t;
}(_wepy2.default.page), _applyDecoratedDescriptor(_class.prototype, "getData", [ _dec ], Object.getOwnPropertyDescriptor(_class.prototype, "getData"), _class.prototype), 
_class);

Page(require("./../npm/wepy/lib/wepy.js").default.$createPage(studyData, "pages/studyData"));