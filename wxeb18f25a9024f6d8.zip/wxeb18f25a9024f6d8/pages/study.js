function _interopRequireDefault(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

function _asyncToGenerator(t) {
    return function() {
        var e = t.apply(this, arguments);
        return new Promise(function(t, i) {
            function s(n, r) {
                try {
                    var a = e[n](r), o = a.value;
                } catch (t) {
                    return void i(t);
                }
                if (!a.done) return Promise.resolve(o).then(function(t) {
                    s("next", t);
                }, function(t) {
                    s("throw", t);
                });
                t(o);
            }
            return s("next");
        });
    };
}

function _classCallCheck(t, e) {
    if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(t, e) {
    if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !e || "object" != typeof e && "function" != typeof e ? t : e;
}

function _inherits(t, e) {
    if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
    t.prototype = Object.create(e && e.prototype, {
        constructor: {
            value: t,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e);
}

function _applyDecoratedDescriptor(t, e, i, s, n) {
    var r = {};
    return Object.keys(s).forEach(function(t) {
        r[t] = s[t];
    }), r.enumerable = !!r.enumerable, r.configurable = !!r.configurable, ("value" in r || r.initializer) && (r.writable = !0), 
    r = i.slice().reverse().reduce(function(i, s) {
        return s(t, e, i) || i;
    }, r), n && void 0 !== r.initializer && (r.value = r.initializer ? r.initializer.call(n) : void 0, 
    r.initializer = void 0), void 0 === r.initializer && (Object.defineProperty(t, e, r), 
    r = null), r;
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _createClass = function() {
    function t(t, e) {
        for (var i = 0; i < e.length; i++) {
            var s = e[i];
            s.enumerable = s.enumerable || !1, s.configurable = !0, "value" in s && (s.writable = !0), 
            Object.defineProperty(t, s.key, s);
        }
    }
    return function(e, i, s) {
        return i && t(e.prototype, i), s && t(e, s), e;
    };
}(), _dec, _desc, _value, _class, _wepy = require("./../npm/wepy/lib/wepy.js"), _wepy2 = _interopRequireDefault(_wepy), _api = require("./../common/api.js"), _api2 = _interopRequireDefault(_api), _common = require("./../common/common.js"), _common2 = _interopRequireDefault(_common), _storage = require("./../common/storage.js"), _storage2 = _interopRequireDefault(_storage), _constant = require("./../common/constant.js"), _constant2 = _interopRequireDefault(_constant), _decorator = require("./../common/decorator.js"), _KcLoading = require("./../components/KcLoading.js"), _KcLoading2 = _interopRequireDefault(_KcLoading), _KcErrorModal = require("./../components/KcErrorModal.js"), _KcErrorModal2 = _interopRequireDefault(_KcErrorModal), _KcUpValue = require("./../components/KcUpValue.js"), _KcUpValue2 = _interopRequireDefault(_KcUpValue), _kcLog = require("./../npm/@kc-base/kc-log/dist/kc-log.js"), _kcLog2 = _interopRequireDefault(_kcLog), log = require("./../common/log.js"), Study = (_dec = (0, 
_decorator.trycatch)(), _class = function(t) {
    function e() {
        var t, i, s, n;
        _classCallCheck(this, e);
        for (var r = arguments.length, a = Array(r), o = 0; o < r; o++) a[o] = arguments[o];
        return i = s = _possibleConstructorReturn(this, (t = e.__proto__ || Object.getPrototypeOf(e)).call.apply(t, [ this ].concat(a))), 
        s.config = {
            navigationBarTitleText: "正在答题",
            navigationBarTextStyle: "black",
            navigationBarBackgroundColor: "#F9FAFC"
        }, s.data = {
            loadingHide: !0,
            tipsShow: !1,
            index: 0,
            btn: "对答案",
            sid: "",
            days: [],
            type: "",
            topicNum: "",
            status: 0,
            handTipShowTime: 0,
            onlyFalse: !1,
            handTips: !0,
            optionStatus: [ 0, 0, 0, 0 ],
            currentAnswerStatus: 0,
            hasPointDetail: 0,
            topicList: [],
            answerList: [],
            endAlertShow: !1,
            accuracyRate: 0,
            changeValue: 0,
            eggShow: !1,
            markTips: !1,
            longtips: !1,
            needMarkTips: !0,
            needLongTips: !0,
            maskShow: !1,
            submitStatus: 0,
            wrongTopic: [],
            hasVip: !1,
            firstVideoPlay: !1,
            videoContext: null,
            imgSrc: "",
            title: "",
            text1: "",
            text2: "",
            text3: "",
            leftBtnText: "",
            rightBtnText: "",
            leftCb: null,
            rightCb: null,
            firstVideoClick: !1,
            upValue: 0,
            videoMaskShow: !0,
            lock: !1,
            isnewuser: 0,
            isAuth: !1,
            isAuthPhone: !1,
            isLast: !1,
            loginLock: !1,
            code: ""
        }, s.$repeat = {}, s.$props = {
            KcLoading: {
                "xmlns:v-bind": "",
                "v-bind:loadingHide.sync": "loadingHide"
            },
            KcUpValue: {
                "xmlns:v-bind": "",
                "v-bind:title.sync": "title",
                "v-bind:text1.sync": "text1",
                "v-bind:text2.sync": "text2",
                "v-bind:text3.sync": "text3",
                "v-bind:leftBtnText.sync": "leftBtnText",
                "v-bind:rightBtnText.sync": "rightBtnText",
                "v-bind:leftCb.sync": "leftCb",
                "v-bind:rightCb.sync": "rightCb",
                "v-bind:imgSrc.sync": "imgSrc"
            }
        }, s.$events = {}, s.components = {
            KcLoading: _KcLoading2.default,
            KcErrorModal: _KcErrorModal2.default,
            KcUpValue: _KcUpValue2.default
        }, s.mixins = [], s.computed = {
            percent: function() {
                return parseInt((this.index + 1) / this.topicNum * 100);
            },
            nowTopic: function() {
                return this.topicList[this.index];
            },
            canClick: function() {
                if (1 === this.status) {
                    for (var t = 0, e = 0, i = this.optionStatus.length; e < i; e++) 0 !== this.optionStatus[e] && t++;
                    return 0 !== t && (1 !== t || !this.nowTopic.isCheckbox);
                }
                return !0;
            },
            yourAnswer: function() {
                for (var t = "", e = this.optionStatus, i = 0; i < 4; i++) if (1 === e[i] || 2 === e[i] || 3 === e[i]) switch (i) {
                  case 0:
                    t += "A";
                    break;

                  case 1:
                    t += "B";
                    break;

                  case 2:
                    t += "C";
                    break;

                  case 3:
                    t += "D";
                }
                return t;
            },
            rightAnswer: function() {
                var t = "";
                if (this.nowTopic) for (var e = this.nowTopic.rightOption, i = 0; i < e.length; i++) switch (e[i] - 1) {
                  case 0:
                    t += "A";
                    break;

                  case 1:
                    t += "B";
                    break;

                  case 2:
                    t += "C";
                    break;

                  case 3:
                    t += "D";
                }
                return t;
            }
        }, s.methods = {
            getPhoneNumber: function() {
                function t(t) {
                    return e.apply(this, arguments);
                }
                var e = _asyncToGenerator(regeneratorRuntime.mark(function t(e) {
                    var i, s, n;
                    return regeneratorRuntime.wrap(function(t) {
                        for (;;) switch (t.prev = t.next) {
                          case 0:
                            if (_kcLog2.default.send({
                                pagename: "studyPage",
                                name: "phoneWindowShow",
                                category: "webShow",
                                pt: "mini",
                                bundleid: "zhengzhi1000"
                            }), "getPhoneNumber:ok" !== e.detail.errMsg) {
                                t.next = 13;
                                break;
                            }
                            return _kcLog2.default.send({
                                pagename: "studyPage",
                                name: "phoneAgreeClick",
                                category: "webClick",
                                pt: "mini",
                                bundleid: "zhengzhi1000"
                            }), i = {
                                code: this.code
                            }, t.next = 6, _api2.default.getOpenId(i);

                          case 6:
                            return s = t.sent, n = s.openId, t.next = 10, _api2.default.setPhoneNumber({
                                iv: e.detail.iv,
                                encryptedData: e.detail.encryptedData,
                                openId: n
                            });

                          case 10:
                            _storage2.default.set("isAuthPhone", !0), t.next = 15;
                            break;

                          case 13:
                            _kcLog2.default.send({
                                pagename: "studyPage",
                                name: "phoneRefuseClick",
                                category: "webClick",
                                pt: "mini",
                                bundleid: "zhengzhi1000"
                            }), wx.showToast({
                                title: "授权手机号失败请稍后再试"
                            });

                          case 15:
                            return t.next = 17, this.submitAnswers();

                          case 17:
                          case "end":
                            return t.stop();
                        }
                    }, t, this);
                }));
                return t;
            }(),
            wxLogin: function() {
                function t(t) {
                    return e.apply(this, arguments);
                }
                var e = _asyncToGenerator(regeneratorRuntime.mark(function t(e) {
                    var i, s, n = this;
                    return regeneratorRuntime.wrap(function(t) {
                        for (;;) switch (t.prev = t.next) {
                          case 0:
                            if (!this.loginLock) {
                                t.next = 2;
                                break;
                            }
                            return t.abrupt("return", !1);

                          case 2:
                            _kcLog2.default.send({
                                pagename: "studyPage",
                                name: "signupWindowShow",
                                category: "webShow",
                                pt: "mini",
                                bundleid: "zhengzhi1000"
                            }), this.loginLock = !0, i = this.wxSilentLogin(), s = this.wxGetUserProfile(), 
                            Promise.all([ i, s ]).then(function() {
                                var t = _asyncToGenerator(regeneratorRuntime.mark(function t(e) {
                                    var i, s, r, a;
                                    return regeneratorRuntime.wrap(function(t) {
                                        for (;;) switch (t.prev = t.next) {
                                          case 0:
                                            return _kcLog2.default.send({
                                                pagename: "studyPage",
                                                name: "loginClick",
                                                category: "login",
                                                pt: "mini",
                                                bundleid: "zhengzhi1000"
                                            }), i = e[0], s = e[1].iv, r = e[1].encryptedData, a = {
                                                code: i,
                                                encryptedData: r,
                                                iv: s
                                            }, t.next = 7, _api2.default.register(a);

                                          case 7:
                                            return t.next = 9, n.submitAnswers();

                                          case 9:
                                            n.$apply();

                                          case 10:
                                          case "end":
                                            return t.stop();
                                        }
                                    }, t, n);
                                }));
                                return function(e) {
                                    return t.apply(this, arguments);
                                };
                            }()).catch(function() {
                                _kcLog2.default.send({
                                    pagename: "studyPage",
                                    name: "refuseClick",
                                    category: "webClick",
                                    pt: "mini",
                                    bundleid: "zhengzhi1000"
                                }), n.loginLock = !1, n.$apply();
                            });

                          case 7:
                          case "end":
                            return t.stop();
                        }
                    }, t, this);
                }));
                return t;
            }(),
            hideMask: function() {
                this.maskShow = !1, this.longtips = !1, this.markTips = !1;
            },
            formSubmit: function(t) {
                var e = t.detail.formId;
                _common2.default.collectFormID(e);
            },
            markCancel: function() {
                this.markTips = !1, this.maskShow = !1, this.$apply();
            },
            longCancel: function() {
                this.longtips = !1, this.maskShow = !1, this.$apply();
            },
            goReport: function() {
                wx.redirectTo({
                    url: "report?sid=" + this.sid + "&days=" + JSON.stringify(this.days) + "&type=" + this.type + "&onlyFalse=" + this.onlyFalse
                });
            },
            removeWrong: function() {
                this.answerList[this.index] = 3;
            },
            unremoveWrong: function() {
                this.answerList[this.index] = this.currentAnswerStatus;
            },
            mark: function() {
                1 === this.type && wx.reportAnalytics("study_20_click_mark", {}), this.needMarkTips && (this.markTips = !0, 
                this.maskShow = !0, _storage2.default.set("needMarkTips", !1), this.needMarkTips = !1), 
                this.answerList[this.index] = 2;
            },
            unmark: function() {
                this.answerList[this.index] = 1;
            },
            mainTap: function() {
                function t() {
                    return e.apply(this, arguments);
                }
                var e = _asyncToGenerator(regeneratorRuntime.mark(function t() {
                    return regeneratorRuntime.wrap(function(t) {
                        for (;;) switch (t.prev = t.next) {
                          case 0:
                            if (3 !== this.type) {
                                t.next = 12;
                                break;
                            }
                            if (this.index !== this.topicList.length - 1) {
                                t.next = 4;
                                break;
                            }
                            return wx.redirectTo({
                                url: "report?sid=" + this.sid + "&days=" + JSON.stringify(this.days) + "&type=" + this.type + "&onlyFalse=" + this.onlyFalse
                            }), t.abrupt("return");

                          case 4:
                            return this.videoContext && this.videoContext.stop(), this.index = this.index + 1, 
                            this.optionStatus = this.wrongTopic[this.index].optionStatus, log.info("index", this.index), 
                            log.info("optionStatus", this.optionStatus), this.index === this.topicList.length - 1 ? this.btn = "回报告页" : this.btn = "下一题", 
                            this.$apply(), t.abrupt("return");

                          case 12:
                            this.firstVideoClick = !1, this.videoMaskShow = !0, this.nextTapEvent();

                          case 15:
                          case "end":
                            return t.stop();
                        }
                    }, t, this);
                }));
                return t;
            }(),
            tapOption: function(t) {
                1 === this.status && (this.nowTopic.isCheckbox ? 1 === this.optionStatus[t] ? this.optionStatus[t] = 0 : this.optionStatus[t] = 1 : (this.optionStatus = [ 0, 0, 0, 0 ], 
                this.optionStatus[t] = 1));
            },
            touchEnd: function() {
                function t(t) {
                    return e.apply(this, arguments);
                }
                var e = _asyncToGenerator(regeneratorRuntime.mark(function t(e) {
                    return regeneratorRuntime.wrap(function(t) {
                        for (;;) switch (t.prev = t.next) {
                          case 0:
                            this.status = 1, this.handTips = !1, this.handTipShowTime < 10 && this.handTipShowTime++, 
                            _storage2.default.set("handTipShowTime", this.handTipShowTime), wx.reportAnalytics("study_20_click_main", {
                                isnewuser: this.isnewuser
                            });

                          case 5:
                          case "end":
                            return t.stop();
                        }
                    }, t, this);
                }));
                return t;
            }(),
            longpress: function() {
                this.eggShow = !0, this.needLongTips && (this.maskShow = !0, this.longtips = !0, 
                _storage2.default.set("needLongTips", !1), this.needLongTips = !1), wx.reportAnalytics("study_19_longpress", {});
            },
            videoPlay: function() {
                function t() {
                    return e.apply(this, arguments);
                }
                var e = _asyncToGenerator(regeneratorRuntime.mark(function t() {
                    var e;
                    return regeneratorRuntime.wrap(function(t) {
                        for (;;) switch (t.prev = t.next) {
                          case 0:
                            if (!this.hasVip && this.firstVideoPlay && wx.reportAnalytics("study_20_click_novipfirst", {}), 
                            this.hasVip || this.firstVideoPlay || wx.reportAnalytics("study_20_click_novipnofirst", {}), 
                            1 !== this.nowTopic.videoState) {
                                t.next = 4;
                                break;
                            }
                            return t.abrupt("return");

                          case 4:
                            this.hasVip || (this.firstVideoPlay ? (this.firstVideoPlay = !1, this.firstVideoClick = !0, 
                            this.topicList[this.index].videoState = 1, this.unlockVideo(this.nowTopic.id), log.info("firstfree unlock")) : (e = this, 
                            this.upValue >= 10 ? (this.imgSrc = "../images/components/icon_lock@2x.png", this.title = "解锁当前视频", 
                            this.text1 = "需消耗", this.text2 = "10点UP值", this.text3 = "你目前拥有" + this.upValue + "点UP值", 
                            this.leftBtnText = "取消", this.rightBtnText = "确定", this.leftCb = function() {
                                this.close();
                            }, this.rightCb = function() {
                                this.unlockVideo(e.nowTopic.id), log.info("rightbtn unlock"), wx.reportAnalytics("study_20_show_unlockok", {});
                            }, this.$invoke("KcUpValue", "showModal"), wx.reportAnalytics("study_20_show_unlock", {})) : (this.imgSrc = "../images/components/icon_face@2x.png", 
                            this.title = "解锁当前视频", this.text1 = "需消耗", this.text2 = "10点UP值", this.text3 = "你的up值不够", 
                            this.leftBtnText = "", this.rightBtnText = "知道了", this.rightCb = function() {
                                this.close();
                            }, this.$invoke("KcUpValue", "showModal"), wx.reportAnalytics("study_20_show_nounlockok", {}))));

                          case 5:
                          case "end":
                            return t.stop();
                        }
                    }, t, this);
                }));
                return t;
            }(),
            loadedmetadata: function() {
                !this.hasVip && this.firstVideoPlay && wx.reportAnalytics("study_20_show_novipfirst", {}), 
                this.hasVip || this.firstVideoPlay || wx.reportAnalytics("study_20_show_novipnofirst", {}), 
                this.hasVip && wx.reportAnalytics("study_20_show_vipvideo", {});
            },
            videoErrorCallback: function(t) {
                log.info("视频错误信息:", t.detail.errMsg);
            },
            onVideoPlay: function() {
                this.hasVip && !this.lock && (wx.reportAnalytics("study_20_click_vipvideo", {}), 
                this.lock = !0);
            }
        }, s.events = {
            unlockVideoSuccess: function() {
                s.getUserInfo(), s.topicList[s.index].videoState = 1, s.videoMaskShow = !1, s.$apply(), 
                s.videoContext.play();
            }
        }, n = i, _possibleConstructorReturn(s, n);
    }
    return _inherits(e, t), _createClass(e, [ {
        key: "checkAnswer",
        value: function() {
            for (var t = 1, e = 0; e < 4; e++) {
                var i = this.nowTopic.rightOption.indexOf(e + 1) >= 0;
                1 === this.optionStatus[e] ? i ? this.optionStatus[e] = 3 : (this.optionStatus[e] = 2, 
                t = 0) : i && (this.nowTopic.isCheckbox ? this.optionStatus[e] = 4 : this.optionStatus[e] = 5, 
                t = 0);
            }
            this.currentAnswerStatus = t, this.answerList[this.index] = t;
        }
    }, {
        key: "nextTapEvent",
        value: function() {
            function t() {
                return e.apply(this, arguments);
            }
            var e = _asyncToGenerator(regeneratorRuntime.mark(function t() {
                var e, i, s, n, r;
                return regeneratorRuntime.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        if (t.prev = 0, 1 !== this.status || !this.canClick) {
                            t.next = 31;
                            break;
                        }
                        return wx.reportAnalytics("study_20_click_maintap", {
                            isnewuser: this.isnewuser
                        }), t.next = 5, _storage2.default.get("learnStorage");

                      case 5:
                        if (e = t.sent, i = new Date(), i.setTime(i.getTime() - 36e5), s = "" + i.getFullYear() + i.getMonth() + i.getDay(), 
                        e.nowDay = s, this.checkAnswer(), wx.setNavigationBarTitle({
                            title: "答案解析"
                        }), this.index !== this.topicList.length - 1) {
                            t.next = 22;
                            break;
                        }
                        return this.isLast = !0, t.next = 16, _wepy2.default.login();

                      case 16:
                        n = t.sent, r = n.code, this.code = r, this.btn = "提交本次答题数据", t.next = 23;
                        break;

                      case 22:
                        this.btn = "下一题";

                      case 23:
                        this.status = 2, 1 === this.type ? this.index === this.topicList.length - 1 ? (e.learn.index = 0, 
                        e.learn.sid = -1, e.learn.answerList = []) : (e.learn.index = this.index + 1, e.learn.sid = this.sid, 
                        e.learn.answerList = this.answerList) : this.index === this.topicList.length - 1 ? (e.review["sid" + this.sid].days = [], 
                        e.review["sid" + this.sid].index = 0, e.review["sid" + this.sid].onlyFalse = this.onlyFalse, 
                        e.review["sid" + this.sid].answerList = []) : (e.review["sid" + this.sid].days = this.days, 
                        e.review["sid" + this.sid].onlyFalse = this.onlyFalse, e.review["sid" + this.sid].index = this.index + 1, 
                        e.review["sid" + this.sid].answerList = this.answerList), 0 === this.answerList[this.index] && this.wrongTopic.push({
                            index: this.index,
                            optionStatus: this.optionStatus
                        }), _storage2.default.set("learnStorage", e), _storage2.default.set("wrongTopic", this.wrongTopic), 
                        log.info("setwrongTopic", this.wrongTopic), t.next = 49;
                        break;

                      case 31:
                        if (2 !== this.status) {
                            t.next = 49;
                            break;
                        }
                        if (wx.reportAnalytics("study_20_click_next", {
                            isnewuser: this.isnewuser
                        }), this.index !== this.topicList.length - 1) {
                            t.next = 39;
                            break;
                        }
                        return 1 === this.type && wx.reportAnalytics("study_20_click_submit", {}), t.next = 37, 
                        this.submitAnswers();

                      case 37:
                        t.next = 49;
                        break;

                      case 39:
                        this.status = 0, this.btn = "对答案", this.eggShow = !1, this.handTips = !0, _wepy2.default.setNavigationBarTitle({
                            title: 2 === this.type ? this.onlyFalse ? "正在复习错过的题" : "正在复习当天所有题目" : "正在答题"
                        }), this.lock = !1, this.videoContext.stop(), this.index = this.index + 1, this.eggAlertShow = !1, 
                        this.optionStatus = [ 0, 0, 0, 0 ];

                      case 49:
                        this.$apply(), t.next = 54;
                        break;

                      case 52:
                        t.prev = 52, t.t0 = t.catch(0);

                      case 54:
                      case "end":
                        return t.stop();
                    }
                }, t, this, [ [ 0, 52 ] ]);
            }));
            return t;
        }()
    }, {
        key: "submitAnswers",
        value: function() {
            function t() {
                return e.apply(this, arguments);
            }
            var e = _asyncToGenerator(regeneratorRuntime.mark(function t() {
                var e, i, s;
                return regeneratorRuntime.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        if (1 !== this.submitStatus) {
                            t.next = 2;
                            break;
                        }
                        return t.abrupt("return");

                      case 2:
                        return t.prev = 2, this.submitStatus = 1, this.$apply(), t.next = 7, _storage2.default.get("token");

                      case 7:
                        if (t.t0 = t.sent, t.t0) {
                            t.next = 10;
                            break;
                        }
                        t.t0 = 0;

                      case 10:
                        return e = t.t0, log.info("学习页提交答案", "subjectId", this.sid, "stage", this.days.join(","), "type", this.type, "answers", this.getFormatAnswerList(this.answerList)), 
                        t.next = 14, _api2.default.submitAnswers({
                            subjectId: this.sid,
                            stage: this.days.join(","),
                            type: this.type,
                            answers: this.getFormatAnswerList(this.answerList),
                            onlyFalse: this.onlyFalse,
                            token: e
                        });

                      case 14:
                        i = t.sent, this.accuracyRate = i.accuracyRate, this.changeValue = i.changeValue, 
                        this.submitStatus = 0, 2 === this.type && _storage2.default.remove(_constant2.default.KEY_REVIEW_LAST_STUDY), 
                        1 === this.type && _common2.default.business({
                            BSceneCode: "finish",
                            BDescribe: "完成一个阶段的学习",
                            ext: {
                                subjectId: parseInt(this.sid),
                                stageIndex: parseInt(this.days.join(","))
                            }
                        }), wx.redirectTo({
                            url: "report?sid=" + this.sid + "&days=" + JSON.stringify(this.days) + "&type=" + this.type + "&onlyFalse=" + this.onlyFalse
                        }), t.next = 29;
                        break;

                      case 23:
                        t.prev = 23, t.t1 = t.catch(2), this.submitStatus = 0, s = "提交答案失败，请稍后再试", t.t1 && 5010 === t.t1.code && (s = "重复提交，请稍后再试"), 
                        wx.showToast({
                            title: s,
                            icon: "none",
                            duration: 3e3
                        });

                      case 29:
                        this.$apply();

                      case 30:
                      case "end":
                        return t.stop();
                    }
                }, t, this, [ [ 2, 23 ] ]);
            }));
            return t;
        }()
    }, {
        key: "getFormatAnswerList",
        value: function(t) {
            var e = this, i = [], s = {};
            return t.forEach(function(t, i) {
                var n = e.topicList[i].stage;
                s.hasOwnProperty(n) ? s[n].push(t) : s[n] = [ t ];
            }), Object.keys(s).forEach(function(t) {
                i.push({
                    stage: t,
                    answerList: s[t]
                });
            }), JSON.stringify(i);
        }
    }, {
        key: "onLoad",
        value: function() {
            function t(t) {
                return e.apply(this, arguments);
            }
            var e = _asyncToGenerator(regeneratorRuntime.mark(function t(e) {
                var i, s;
                return regeneratorRuntime.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return this.sid = Number(e.sid), this.days = e.days ? JSON.parse(e.days) : [], this.type = Number(e.type), 
                        this.onlyFalse = JSON.parse(e.onlyFalse), this.isLast = !1, _wepy2.default.setNavigationBarTitle({
                            title: 2 === this.type ? this.onlyFalse ? "正在复习错过的题" : "正在复习当天所有题目" : "正在答题"
                        }), 3 === this.type && (this.status = 2, this.btn = "下一题"), t.next = 9, this.getStorageData();

                      case 9:
                        return t.next = 11, this.getStudyData();

                      case 11:
                        return t.next = 13, this.getUserInfo();

                      case 13:
                        return this.videoContext = wx.createVideoContext("myVideo"), t.next = 16, _storage2.default.get("preSubject");

                      case 16:
                        if (t.t0 = t.sent, t.t0) {
                            t.next = 19;
                            break;
                        }
                        t.t0 = 0;

                      case 19:
                        return i = t.t0, t.next = 22, _storage2.default.get("preDay");

                      case 22:
                        if (t.t1 = t.sent, t.t1) {
                            t.next = 25;
                            break;
                        }
                        t.t1 = 0;

                      case 25:
                        if (s = t.t1, this.sid !== parseInt(i) || parseInt(this.days[0]) !== parseInt(s)) {
                            t.next = 33;
                            break;
                        }
                        return t.next = 29, _storage2.default.get("wrongTopic");

                      case 29:
                        if (t.t2 = t.sent, t.t2) {
                            t.next = 32;
                            break;
                        }
                        t.t2 = [];

                      case 32:
                        this.wrongTopic = t.t2;

                      case 33:
                        return _storage2.default.set("preSubject", this.sid), _storage2.default.set("preDay", this.days[0]), 
                        t.next = 37, _storage2.default.get("is_auth");

                      case 37:
                        if (t.t3 = t.sent, t.t3) {
                            t.next = 40;
                            break;
                        }
                        t.t3 = !1;

                      case 40:
                        return this.isAuth = t.t3, t.next = 43, _storage2.default.get("isAuthPhone");

                      case 43:
                        if (t.t4 = t.sent, t.t4) {
                            t.next = 46;
                            break;
                        }
                        t.t4 = !1;

                      case 46:
                        this.isAuthPhone = t.t4, this.$apply();

                      case 48:
                      case "end":
                        return t.stop();
                    }
                }, t, this);
            }));
            return t;
        }()
    }, {
        key: "getStorageData",
        value: function() {
            function t() {
                return e.apply(this, arguments);
            }
            var e = _asyncToGenerator(regeneratorRuntime.mark(function t() {
                var e, i, s;
                return regeneratorRuntime.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return t.prev = 0, t.next = 3, _storage2.default.get("handTipShowTime");

                      case 3:
                        if (t.t0 = t.sent, t.t0) {
                            t.next = 6;
                            break;
                        }
                        t.t0 = 0;

                      case 6:
                        return this.handTipShowTime = t.t0, t.next = 9, _storage2.default.get("needMarkTips");

                      case 9:
                        return this.needMarkTips = t.sent, void 0 === this.needMarkTips && (this.needMarkTips = !0), 
                        t.next = 13, _storage2.default.get("needLongTips");

                      case 13:
                        return this.needLongTips = t.sent, void 0 === this.needLongTips && (this.needLongTips = !0), 
                        t.next = 17, _storage2.default.get("learnStorage");

                      case 17:
                        return e = t.sent, i = new Date(), i.setTime(i.getTime() - 36e5), s = "" + i.getFullYear() + i.getMonth() + i.getDay(), 
                        e && e.nowDay === s ? 1 === this.type && this.sid === e.learn.sid ? (this.index = e.learn.index, 
                        this.answerList = e.learn.answerList) : 2 === this.type && e.review["sid" + this.sid].days.sort().toString() === this.days.sort().toString() && e.review["sid" + this.sid].onlyFalse === this.onlyFalse && (this.index = e.review["sid" + this.sid].index, 
                        this.answerList = e.review["sid" + this.sid].answerList) : (e = {
                            nowDay: s,
                            learn: {
                                sid: -1,
                                index: 0,
                                answerList: []
                            },
                            review: {
                                sid1: {
                                    days: [],
                                    index: 0,
                                    onlyFalse: !1,
                                    answerList: []
                                },
                                sid2: {
                                    days: [],
                                    index: 0,
                                    onlyFalse: !1,
                                    answerList: []
                                },
                                sid3: {
                                    days: [],
                                    index: 0,
                                    onlyFalse: !1,
                                    answerList: []
                                },
                                sid4: {
                                    days: [],
                                    index: 0,
                                    onlyFalse: !1,
                                    answerList: []
                                }
                            }
                        }, _storage2.default.set("learnStorage", e)), t.next = 24, _storage2.default.get("hasVip");

                      case 24:
                        return this.hasVip = t.sent, t.next = 27, _storage2.default.get("isnewuser");

                      case 27:
                        if (t.t1 = t.sent, t.t1) {
                            t.next = 30;
                            break;
                        }
                        t.t1 = 0;

                      case 30:
                        this.isnewuser = t.t1, this.$apply(), t.next = 36;
                        break;

                      case 34:
                        t.prev = 34, t.t2 = t.catch(0);

                      case 36:
                      case "end":
                        return t.stop();
                    }
                }, t, this, [ [ 0, 34 ] ]);
            }));
            return t;
        }()
    }, {
        key: "getStudyData",
        value: function() {
            function t() {
                return e.apply(this, arguments);
            }
            var e = _asyncToGenerator(regeneratorRuntime.mark(function t() {
                var e, i = this;
                return regeneratorRuntime.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return this.loadingHide = !1, this.$apply(), t.next = 4, _api2.default.getDayInfo({
                            subjectId: this.sid,
                            stage: this.days.join(","),
                            type: this.type,
                            onlyFalse: this.onlyFalse
                        });

                      case 4:
                        if (e = t.sent, this.topicNum = e.questionNum, this.topicList = e.questions, log.info("学习页请求参数", "subjectId:", this.sid, "stage", this.days.join(","), "type", this.type, "onlyFalse", this.onlyFalse), 
                        3 !== this.type) {
                            t.next = 24;
                            break;
                        }
                        return this.topicList = [], t.prev = 10, t.next = 13, _storage2.default.get("wrongTopic");

                      case 13:
                        this.wrongTopic = t.sent, t.next = 19;
                        break;

                      case 16:
                        t.prev = 16, t.t0 = t.catch(10), log.info("wrongTopicError", t.t0);

                      case 19:
                        log.info("wrongTopic", this.wrongTopic), this.wrongTopic.forEach(function(t) {
                            i.topicList.push(e.questions[t.index]), log.info("错题", e.questions[t.index]);
                        }), this.topicNum = this.wrongTopic.length, this.optionStatus = this.wrongTopic[0].optionStatus, 
                        log.info("第一题optionStatus状态", this.optionStatus);

                      case 24:
                        this.firstVideoPlay = e.firstFree, this.hasPointDetail = e.hasPointDetail, this.loadingHide = !0, 
                        this.$apply();

                      case 28:
                      case "end":
                        return t.stop();
                    }
                }, t, this, [ [ 10, 16 ] ]);
            }));
            return t;
        }()
    }, {
        key: "unlockVideo",
        value: function() {
            function t(t) {
                return e.apply(this, arguments);
            }
            var e = _asyncToGenerator(regeneratorRuntime.mark(function t(e) {
                var i;
                return regeneratorRuntime.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return t.next = 2, _storage2.default.get("token");

                      case 2:
                        if (t.t0 = t.sent, t.t0) {
                            t.next = 5;
                            break;
                        }
                        t.t0 = 0;

                      case 5:
                        i = t.t0, _api2.default.unlockVideo({
                            questionId: e,
                            token: i
                        }), this.videoMaskShow = !1, this.$apply(), this.videoContext.play();

                      case 10:
                      case "end":
                        return t.stop();
                    }
                }, t, this);
            }));
            return t;
        }()
    }, {
        key: "reportLearnTime",
        value: function(t) {
            1 === this.type && _common2.default.business({
                BSceneCode: "timeTrack",
                BDescribe: "记录页面开始学习和结束学习",
                ext: {
                    trackType: t,
                    subjectId: parseInt(this.sid),
                    stageIndex: parseInt(this.days.join(","))
                }
            });
        }
    }, {
        key: "onShow",
        value: function() {
            this.reportLearnTime(0);
        }
    }, {
        key: "onHide",
        value: function() {
            this.submitAnswersBehaviour(), this.reportLearnTime(1);
        }
    }, {
        key: "onUnload",
        value: function() {
            this.submitAnswersBehaviour(), this.reportLearnTime(1);
        }
    }, {
        key: "submitAnswersBehaviour",
        value: function() {
            function t() {
                return e.apply(this, arguments);
            }
            var e = _asyncToGenerator(regeneratorRuntime.mark(function t() {
                return regeneratorRuntime.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        if (1 !== this.type) {
                            t.next = 8;
                            break;
                        }
                        return t.prev = 1, t.next = 4, _api2.default.submitAnswersBehaviour({
                            subjectId: this.sid,
                            stage: this.days.join(","),
                            answerNum: 2 === this.status ? this.index + 1 : this.index
                        });

                      case 4:
                        t.next = 8;
                        break;

                      case 6:
                        t.prev = 6, t.t0 = t.catch(1);

                      case 8:
                      case "end":
                        return t.stop();
                    }
                }, t, this, [ [ 1, 6 ] ]);
            }));
            return t;
        }()
    }, {
        key: "getUserInfo",
        value: function() {
            function t() {
                return e.apply(this, arguments);
            }
            var e = _asyncToGenerator(regeneratorRuntime.mark(function t() {
                var e;
                return regeneratorRuntime.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return t.next = 2, _api2.default.getUserInfo();

                      case 2:
                        e = t.sent, this.upValue = e.user.upValue, this.$apply();

                      case 5:
                      case "end":
                        return t.stop();
                    }
                }, t, this);
            }));
            return t;
        }()
    }, {
        key: "onPageScroll",
        value: function(t) {
            1 === this.type && 1 === this.sid && 1 === this.days[0] && 3 === this.index && 2 === this.status && t.scrollTop > 0 ? this.tipsShow || (this.tipsShow = !0, 
            this.$apply()) : this.tipsShow && (this.tipsShow = !1, this.$apply());
        }
    }, {
        key: "handleError",
        value: function() {
            function t(t, i) {
                return e.apply(this, arguments);
            }
            var e = _asyncToGenerator(regeneratorRuntime.mark(function t(e, i) {
                var s = this;
                return regeneratorRuntime.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        this.loadingHide = !0, this.$apply(), this.$invoke("KcErrorModal", "showModal", {
                            err: e,
                            btnMsg: "重新加载",
                            cb: function() {
                                s.getStudyData();
                            }
                        });

                      case 3:
                      case "end":
                        return t.stop();
                    }
                }, t, this);
            }));
            return t;
        }()
    }, {
        key: "wxSilentLogin",
        value: function() {
            return new Promise(function(t, e) {
                wx.login({
                    success: function(e) {
                        t(e.code);
                    },
                    fail: function(t) {
                        e(t);
                    }
                });
            });
        }
    }, {
        key: "wxGetUserProfile",
        value: function() {
            return new Promise(function(t, e) {
                wx.getUserProfile({
                    desc: "小程序需要您的授权才能正常使用",
                    success: function(e) {
                        t(e);
                    },
                    fail: function(t) {
                        e(t);
                    }
                });
            });
        }
    } ]), e;
}(_wepy2.default.page), _applyDecoratedDescriptor(_class.prototype, "getStudyData", [ _dec ], Object.getOwnPropertyDescriptor(_class.prototype, "getStudyData"), _class.prototype), 
_class);

Page(require("./../npm/wepy/lib/wepy.js").default.$createPage(Study, "pages/study"));