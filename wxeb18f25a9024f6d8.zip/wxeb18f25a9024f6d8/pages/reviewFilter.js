function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function _asyncToGenerator(e) {
    return function() {
        var t = e.apply(this, arguments);
        return new Promise(function(e, r) {
            function n(i, s) {
                try {
                    var a = t[i](s), o = a.value;
                } catch (e) {
                    return void r(e);
                }
                if (!a.done) return Promise.resolve(o).then(function(e) {
                    n("next", e);
                }, function(e) {
                    n("throw", e);
                });
                e(o);
            }
            return n("next");
        });
    };
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t;
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _createClass = function() {
    function e(e, t) {
        for (var r = 0; r < t.length; r++) {
            var n = t[r];
            n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), 
            Object.defineProperty(e, n.key, n);
        }
    }
    return function(t, r, n) {
        return r && e(t.prototype, r), n && e(t, n), t;
    };
}(), _wepy = require("./../npm/wepy/lib/wepy.js"), _wepy2 = _interopRequireDefault(_wepy), _storage = require("./../common/storage.js"), _storage2 = _interopRequireDefault(_storage), _constant = require("./../common/constant.js"), _constant2 = _interopRequireDefault(_constant), Points = function(e) {
    function t() {
        var e, r, n, i;
        _classCallCheck(this, t);
        for (var s = arguments.length, a = Array(s), o = 0; o < s; o++) a[o] = arguments[o];
        return r = n = _possibleConstructorReturn(this, (e = t.__proto__ || Object.getPrototypeOf(t)).call.apply(e, [ this ].concat(a))), 
        n.config = {
            navigationBarTitleText: "选择复习题目",
            navigationBarBackgroundColor: "#fff"
        }, n.components = {}, n.mixins = [], n.data = {
            subjectList: [],
            current: -1,
            reviewMode: 1,
            showChangeMode: !1
        }, n.computed = {
            selectNum: function() {
                var e = this, t = 0, r = !0, n = !1, i = void 0;
                try {
                    for (var s, a = this.subjectList[Symbol.iterator](); !(r = (s = a.next()).done); r = !0) {
                        var o = s.value;
                        if (o.active && Array.isArray(o.dayList) && o.dayList.length > 0) {
                            t += o.dayList.reduce(function(t, r) {
                                return t + (r.select ? 1 === e.reviewMode ? r.cumulativeWrongNum || 0 : r.allQuestion || 0 : 0);
                            }, 0);
                        }
                    }
                } catch (e) {
                    n = !0, i = e;
                } finally {
                    try {
                        !r && a.return && a.return();
                    } finally {
                        if (n) throw i;
                    }
                }
                return t;
            }
        }, n.methods = {
            filterConfirm: function() {
                function e() {
                    return t.apply(this, arguments);
                }
                var t = _asyncToGenerator(regeneratorRuntime.mark(function e() {
                    var t, r, n, i, s, a, o, u, c, l, f, h, p;
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            if (wx.reportAnalytics("reviewfilter_20_click_confirm", {}), !(this.selectNum > 0)) {
                                e.next = 56;
                                break;
                            }
                            t = {}, r = !0, n = !1, i = void 0, e.prev = 6, s = this.subjectList[Symbol.iterator]();

                          case 8:
                            if (r = (a = s.next()).done) {
                                e.next = 39;
                                break;
                            }
                            if (o = a.value, !o.active) {
                                e.next = 36;
                                break;
                            }
                            for (t.name = o.name, t.sid = o.sid, t.dayList = [], t.filterMode = this.reviewMode, 
                            t.last = !1, u = !0, c = !1, l = void 0, e.prev = 19, f = o.dayList[Symbol.iterator](); !(u = (h = f.next()).done); u = !0) p = h.value, 
                            p.select && t.dayList.push(p.day);
                            e.next = 27;
                            break;

                          case 23:
                            e.prev = 23, e.t0 = e.catch(19), c = !0, l = e.t0;

                          case 27:
                            e.prev = 27, e.prev = 28, !u && f.return && f.return();

                          case 30:
                            if (e.prev = 30, !c) {
                                e.next = 33;
                                break;
                            }
                            throw l;

                          case 33:
                            return e.finish(30);

                          case 34:
                            return e.finish(27);

                          case 35:
                            return e.abrupt("break", 39);

                          case 36:
                            r = !0, e.next = 8;
                            break;

                          case 39:
                            e.next = 45;
                            break;

                          case 41:
                            e.prev = 41, e.t1 = e.catch(6), n = !0, i = e.t1;

                          case 45:
                            e.prev = 45, e.prev = 46, !r && s.return && s.return();

                          case 48:
                            if (e.prev = 48, !n) {
                                e.next = 51;
                                break;
                            }
                            throw i;

                          case 51:
                            return e.finish(48);

                          case 52:
                            return e.finish(45);

                          case 53:
                            return e.next = 55, _storage2.default.set(_constant2.default.KEY_REVIEW_LAST_STUDY, t);

                          case 55:
                            _wepy2.default.navigateBack({
                                delta: 1
                            });

                          case 56:
                          case "end":
                            return e.stop();
                        }
                    }, e, this, [ [ 6, 41, 45, 53 ], [ 19, 23, 27, 35 ], [ 28, , 30, 34 ], [ 46, , 48, 52 ] ]);
                }));
                return e;
            }(),
            itemDayTap: function(e) {
                var t = this, r = Number(e);
                if (this.subjectList[this.current].active) {
                    if (1 === this.reviewMode && this.subjectList[this.current].dayList[r].cumulativeWrongNum <= 0) return;
                    var n = !this.subjectList[this.current].dayList[r].select, i = this.subjectList[this.current].dayList.filter(function(e) {
                        return e.select;
                    });
                    if (n) i.length > 7 ? wx.showToast({
                        title: "最多只能选8天哦",
                        icon: "none",
                        duration: 3e3
                    }) : this.subjectList[this.current].dayList[r].select = n, this.subjectList = this.subjectList.map(function(e, r) {
                        return t.current === r ? e.active = !0 : e.active = !1, e;
                    }); else {
                        this.subjectList[this.current].dayList[r].select = n;
                        0 === this.subjectList[this.current].dayList.filter(function(e) {
                            return e.select;
                        }).length && (this.subjectList = this.subjectList.map(function(e, t) {
                            return e.active = !0, e;
                        }));
                    }
                } else wx.showToast({
                    title: "你已经选了一个科目的题目\n暂不支持多科目同时复习哦",
                    icon: "none",
                    duration: 3e3
                });
            },
            changeModeCtnTap: function() {
                this.showChangeMode = !1;
            },
            changeModeMainTap: function() {},
            changeModeTap: function(e) {
                var t = Number(e);
                t !== this.reviewMode && (this.reviewMode = t, 1 === this.reviewMode && (this.subjectList = this.subjectList.map(function(e, t) {
                    return e.active && (e.dayList = e.dayList.map(function(e) {
                        return e.select && e.cumulativeWrongNum <= 0 && (e.select = !1), e;
                    })), e;
                })), this.showChangeMode = !1);
            },
            modeMainTap: function() {
                this.showChangeMode = !this.showChangeMode;
            },
            filterTabTap: function(e) {
                this.current = Number(e), this.showChangeMode = !1;
            }
        }, i = r, _possibleConstructorReturn(n, i);
    }
    return _inherits(t, e), _createClass(t, [ {
        key: "onLoad",
        value: function() {
            function e(e) {
                return t.apply(this, arguments);
            }
            var t = _asyncToGenerator(regeneratorRuntime.mark(function e(t) {
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        this.current = Number(t.current || -1), this.reviewMode = Number(t.reviewMode) || 1, 
                        this.getFilterData();

                      case 3:
                      case "end":
                        return e.stop();
                    }
                }, e, this);
            }));
            return e;
        }()
    }, {
        key: "getFilterData",
        value: function() {
            var e = this.getCurrentPages();
            if (Array.isArray(e) && e.length > 1) {
                var t = e.reverse()[1], r = t.data && Array.isArray(t.data.subjectList) ? t.data.subjectList : [];
                this.subjectList = JSON.parse(JSON.stringify(r));
            }
        }
    } ]), t;
}(_wepy2.default.page);

Page(require("./../npm/wepy/lib/wepy.js").default.$createPage(Points, "pages/reviewFilter"));