function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function _asyncToGenerator(e) {
    return function() {
        var t = e.apply(this, arguments);
        return new Promise(function(e, r) {
            function n(a, o) {
                try {
                    var i = t[a](o), s = i.value;
                } catch (e) {
                    return void r(e);
                }
                if (!i.done) return Promise.resolve(s).then(function(e) {
                    n("next", e);
                }, function(e) {
                    n("throw", e);
                });
                e(s);
            }
            return n("next");
        });
    };
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t;
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

function _applyDecoratedDescriptor(e, t, r, n, a) {
    var o = {};
    return Object.keys(n).forEach(function(e) {
        o[e] = n[e];
    }), o.enumerable = !!o.enumerable, o.configurable = !!o.configurable, ("value" in o || o.initializer) && (o.writable = !0), 
    o = r.slice().reverse().reduce(function(r, n) {
        return n(e, t, r) || r;
    }, o), a && void 0 !== o.initializer && (o.value = o.initializer ? o.initializer.call(a) : void 0, 
    o.initializer = void 0), void 0 === o.initializer && (Object.defineProperty(e, t, o), 
    o = null), o;
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _createClass = function() {
    function e(e, t) {
        for (var r = 0; r < t.length; r++) {
            var n = t[r];
            n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), 
            Object.defineProperty(e, n.key, n);
        }
    }
    return function(t, r, n) {
        return r && e(t.prototype, r), n && e(t, n), t;
    };
}(), _dec, _dec2, _desc, _value, _class, _wepy = require("./../npm/wepy/lib/wepy.js"), _wepy2 = _interopRequireDefault(_wepy), _api = require("./../common/api.js"), _api2 = _interopRequireDefault(_api), _storage = require("./../common/storage.js"), _storage2 = _interopRequireDefault(_storage), _common = require("./../common/common.js"), _common2 = _interopRequireDefault(_common), _decorator = require("./../common/decorator.js"), _KcModulForHelp = require("./../components/KcModulForHelp.js"), _KcModulForHelp2 = _interopRequireDefault(_KcModulForHelp), _KcLoading = require("./../components/KcLoading.js"), _KcLoading2 = _interopRequireDefault(_KcLoading), _KcErrorModal = require("./../components/KcErrorModal.js"), _KcErrorModal2 = _interopRequireDefault(_KcErrorModal), _kcLog = require("./../npm/@kc-base/kc-log/dist/kc-log.js"), _kcLog2 = _interopRequireDefault(_kcLog), UpValue = (_dec = (0, 
_decorator.trycatch)(), _dec2 = (0, _decorator.trycatch)(), _class = function(e) {
    function t() {
        var e, r, n, a;
        _classCallCheck(this, t);
        for (var o = arguments.length, i = Array(o), s = 0; s < o; s++) i[s] = arguments[s];
        return r = n = _possibleConstructorReturn(this, (e = t.__proto__ || Object.getPrototypeOf(t)).call.apply(e, [ this ].concat(i))), 
        n.config = {
            navigationBarTitleText: "我的UP值",
            navigationBarBackgroundColor: "#7B99FF",
            navigationBarTextStyle: "white"
        }, n.$repeat = {}, n.$props = {
            KcModulForHelp: {
                "xmlns:v-bind": "",
                "v-bind:show.sync": "showModulForHelp"
            },
            KcLoading: {
                "v-bind:loadingHide.sync": "loadingHide"
            }
        }, n.$events = {}, n.components = {
            KcModulForHelp: _KcModulForHelp2.default,
            KcLoading: _KcLoading2.default,
            KcErrorModal: _KcErrorModal2.default
        }, n.mixins = [], n.data = {
            loadingHide: !0,
            openId: "",
            up: 0,
            reduce: 0,
            add: 0,
            chosed: 1,
            upValue: 50,
            noFirst: !1,
            hasToday: !0,
            hasThreeDays: !1,
            hasFinishOnce: !1,
            fromUp: "",
            showModulForHelp: !1,
            successMsg: null,
            showShare: !1,
            closeBanner: !1,
            avatar: "",
            taskList: [],
            qrCodeUrl: ""
        }, n.methods = {
            choseNav: function(e) {
                this.chosed = e;
            },
            showModul: function() {
                _kcLog2.default.send({
                    pagename: "myUpPage",
                    name: "shareClick",
                    category: "webClick",
                    pt: "mini"
                }), this.noFirst || (this.showModulForHelp = !0, this.noFirst = !0, wx.setStorageSync("noFirst", !0));
            },
            goIndex: function() {
                _wepy2.default.reLaunch({
                    url: "index"
                });
            },
            goPay: function() {
                wx.navigateTo({
                    url: "subPages/pay"
                });
            },
            goValueList: function() {
                _kcLog2.default.send({
                    pagename: "myUpPage",
                    name: "detailClick",
                    category: "webClick",
                    pt: "mini"
                }), wx.navigateTo({
                    url: "upValueList"
                });
            },
            closeBannerTap: function() {
                this.closeBanner = !0, _storage2.default.set("upCloseBanner", !0);
            },
            goVip: function() {
                _kcLog2.default.send({
                    pagename: "myUpPage",
                    name: "vipClick",
                    category: "webClick",
                    pt: "mini"
                });
                _wepy2.default.navigateTo({
                    url: "web?url=" + encodeURIComponent("https://mp.weixin.qq.com/s?__biz=MzU2ODcxNTYxNQ==&mid=2247709644&idx=1&sn=3c4d5f76282c25f9f002ec736bd29f51&chksm=fc8443fccbf3caea2eacaebff39971de1e76aa63c6a4d984c933830e6d9991137062adf7ae07#rd")
                });
            }
        }, a = r, _possibleConstructorReturn(n, a);
    }
    return _inherits(t, e), _createClass(t, [ {
        key: "onLoad",
        value: function() {
            function e(e) {
                return t.apply(this, arguments);
            }
            var t = _asyncToGenerator(regeneratorRuntime.mark(function e(t) {
                var r;
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return _kcLog2.default.send({
                            pagename: "myUpPage",
                            name: "myUpPageView",
                            category: "webPageView",
                            pt: "mini"
                        }), this.fromUp = t.openId || "", this.noFirst = wx.getStorageSync("noFirst") || !1, 
                        e.next = 5, _api2.default.getUserInfo();

                      case 5:
                        return r = e.sent, this.up = r.user.upValue, e.next = 9, _storage2.default.get("upCloseBanner");

                      case 9:
                        if (e.t0 = e.sent, e.t0) {
                            e.next = 12;
                            break;
                        }
                        e.t0 = !1;

                      case 12:
                        return this.closeBanner = e.t0, e.next = 15, this.getUserIndex();

                      case 15:
                        this.successMsg && wx.showToast({
                            title: this.successMsg,
                            icon: "none",
                            duration: 3e3
                        }), this.$apply();

                      case 17:
                      case "end":
                        return e.stop();
                    }
                }, e, this);
            }));
            return e;
        }()
    }, {
        key: "getQRCodeUrl",
        value: function() {
            function e() {
                return t.apply(this, arguments);
            }
            var t = _asyncToGenerator(regeneratorRuntime.mark(function e() {
                var t, r;
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return e.prev = 0, e.next = 3, _api2.default.getQRCodeForUpValue();

                      case 3:
                        t = e.sent, r = t.qrCodeUrl, this.qrCodeUrl = r, this.$apply(), e.next = 11;
                        break;

                      case 9:
                        e.prev = 9, e.t0 = e.catch(0);

                      case 11:
                      case "end":
                        return e.stop();
                    }
                }, e, this, [ [ 0, 9 ] ]);
            }));
            return e;
        }()
    }, {
        key: "initData",
        value: function() {
            function e() {
                return t.apply(this, arguments);
            }
            var t = _asyncToGenerator(regeneratorRuntime.mark(function e() {
                var t, r, n, a, o, i, s, c, u, l, p;
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return this.loadingHide = !1, e.next = 3, _api2.default.upValue({
                            sharerOpenId: this.fromUp
                        });

                      case 3:
                        t = e.sent, r = t.showShare, n = t.openId, a = t.consume, o = t.gain, i = t.score, 
                        s = t.hasToday, c = t.hasThreeDays, u = t.hasFinishOnce, l = t.successMsg, this.showShare = r || !1, 
                        this.openId = n, this.up = i, this.add = o, this.reduce = a, this.hasToday = s || !1, 
                        this.hasThreeDays = c || !1, this.hasFinishOnce = u || !1, this.successMsg = l || !1, 
                        p = this.$parent.globalData.userInfo, this.avatar = p ? p.head : "", this.loadingHide = !0, 
                        this.$apply();

                      case 26:
                      case "end":
                        return e.stop();
                    }
                }, e, this);
            }));
            return e;
        }()
    }, {
        key: "addScore",
        value: function() {
            function e(e, r) {
                return t.apply(this, arguments);
            }
            var t = _asyncToGenerator(regeneratorRuntime.mark(function e(t, r) {
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return e.next = 2, _api2.default.saveScore({
                            type: t,
                            score: r
                        });

                      case 2:
                      case "end":
                        return e.stop();
                    }
                }, e, this);
            }));
            return e;
        }()
    }, {
        key: "onShareAppMessage",
        value: function(e) {
            return this.noFirst && "button" === e.from ? _common2.default.shareTxt({
                up: 1,
                openId: this.openId
            }, "@我的研友，推荐一个刷政治1000题的小程序给你", "../images/activate/img_share.png") : _common2.default.shareTxt();
        }
    }, {
        key: "handleError",
        value: function() {
            function e(e, r) {
                return t.apply(this, arguments);
            }
            var t = _asyncToGenerator(regeneratorRuntime.mark(function e(t, r) {
                var n = this;
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        this.loadingHide = !0, this.$apply(), this.$invoke("KcErrorModal", "showModal", {
                            err: t,
                            btnMsg: "重新加载",
                            cb: function() {
                                n.initData();
                            }
                        });

                      case 3:
                      case "end":
                        return e.stop();
                    }
                }, e, this);
            }));
            return e;
        }()
    }, {
        key: "getUserIndex",
        value: function() {
            function e() {
                return t.apply(this, arguments);
            }
            var t = _asyncToGenerator(regeneratorRuntime.mark(function e() {
                var t;
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return e.next = 2, _api2.default.getUserIndex();

                      case 2:
                        t = e.sent, this.taskList = t.tasks;

                      case 4:
                      case "end":
                        return e.stop();
                    }
                }, e, this);
            }));
            return e;
        }()
    } ]), t;
}(_wepy2.default.page), _applyDecoratedDescriptor(_class.prototype, "initData", [ _dec ], Object.getOwnPropertyDescriptor(_class.prototype, "initData"), _class.prototype), 
_applyDecoratedDescriptor(_class.prototype, "getUserIndex", [ _dec2 ], Object.getOwnPropertyDescriptor(_class.prototype, "getUserIndex"), _class.prototype), 
_class);

Page(require("./../npm/wepy/lib/wepy.js").default.$createPage(UpValue, "pages/upValue"));