function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function _asyncToGenerator(e) {
    return function() {
        var t = e.apply(this, arguments);
        return new Promise(function(e, n) {
            function a(r, o) {
                try {
                    var i = t[r](o), s = i.value;
                } catch (e) {
                    return void n(e);
                }
                if (!i.done) return Promise.resolve(s).then(function(e) {
                    a("next", e);
                }, function(e) {
                    a("throw", e);
                });
                e(s);
            }
            return a("next");
        });
    };
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t;
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

function _applyDecoratedDescriptor(e, t, n, a, r) {
    var o = {};
    return Object.keys(a).forEach(function(e) {
        o[e] = a[e];
    }), o.enumerable = !!o.enumerable, o.configurable = !!o.configurable, ("value" in o || o.initializer) && (o.writable = !0), 
    o = n.slice().reverse().reduce(function(n, a) {
        return a(e, t, n) || n;
    }, o), r && void 0 !== o.initializer && (o.value = o.initializer ? o.initializer.call(r) : void 0, 
    o.initializer = void 0), void 0 === o.initializer && (Object.defineProperty(e, t, o), 
    o = null), o;
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _extends = Object.assign || function(e) {
    for (var t = 1; t < arguments.length; t++) {
        var n = arguments[t];
        for (var a in n) Object.prototype.hasOwnProperty.call(n, a) && (e[a] = n[a]);
    }
    return e;
}, _createClass = function() {
    function e(e, t) {
        for (var n = 0; n < t.length; n++) {
            var a = t[n];
            a.enumerable = a.enumerable || !1, a.configurable = !0, "value" in a && (a.writable = !0), 
            Object.defineProperty(e, a.key, a);
        }
    }
    return function(t, n, a) {
        return n && e(t.prototype, n), a && e(t, a), t;
    };
}(), _dec, _dec2, _dec3, _desc, _value, _class, _wepy = require("./../npm/wepy/lib/wepy.js"), _wepy2 = _interopRequireDefault(_wepy), _api = require("./../common/api.js"), _api2 = _interopRequireDefault(_api), _common = require("./../common/common.js"), _common2 = _interopRequireDefault(_common), _storage = require("./../common/storage.js"), _storage2 = _interopRequireDefault(_storage), _constant = require("./../common/constant.js"), _constant2 = _interopRequireDefault(_constant), _KcShowGuide = require("./../components/KcShowGuide.js"), _KcShowGuide2 = _interopRequireDefault(_KcShowGuide), _OnlineModal = require("./../components/OnlineModal.js"), _OnlineModal2 = _interopRequireDefault(_OnlineModal), _decorator = require("./../common/decorator.js"), _KcLoading = require("./../components/KcLoading.js"), _KcLoading2 = _interopRequireDefault(_KcLoading), _KcErrorModal = require("./../components/KcErrorModal.js"), _KcErrorModal2 = _interopRequireDefault(_KcErrorModal), _kcUpdateModle = require("./../components/kcUpdateModle.js"), _kcUpdateModle2 = _interopRequireDefault(_kcUpdateModle), _KcVipModal = require("./../components/KcVipModal.js"), _KcVipModal2 = _interopRequireDefault(_KcVipModal), _receiveVipModal = require("./../components/receiveVipModal.js"), _receiveVipModal2 = _interopRequireDefault(_receiveVipModal), _KcUpValue = require("./../components/KcUpValue.js"), _KcUpValue2 = _interopRequireDefault(_KcUpValue), _eChart = require("./../common/e-chart.js"), _eChart2 = _interopRequireDefault(_eChart), _kcLog = require("./../npm/@kc-base/kc-log/dist/kc-log.js"), _kcLog2 = _interopRequireDefault(_kcLog), _hasChangeRoute = !1, Home = (_dec = (0, 
_decorator.trycatch)(), _dec2 = (0, _decorator.trycatch)(), _dec3 = (0, _decorator.trycatch)(), 
_class = function(e) {
    function t() {
        var e, n, a, r;
        _classCallCheck(this, t);
        for (var o = arguments.length, i = Array(o), s = 0; s < o; s++) i[s] = arguments[s];
        return n = a = _possibleConstructorReturn(this, (e = t.__proto__ || Object.getPrototypeOf(t)).call.apply(e, [ this ].concat(i))), 
        a.config = {
            navigationBarTitleText: "",
            navigationBarTextStyle: "black",
            navigationBarBackgroundColor: "#6787FF"
        }, a.$repeat = {}, a.$props = {
            KcShowGuide: {
                "xmlns:v-bind": "",
                "v-bind:show.sync": "showGuide"
            },
            KcLoading: {
                "xmlns:v-bind": "",
                "v-bind:loadingHide.sync": "loadingHide"
            },
            vipModle: {
                "xmlns:v-bind": "",
                "v-bind:hasVip.sync": "hasVip",
                "v-bind:status.sync": "helpStatus"
            },
            receiveVipModal: {
                "xmlns:v-bind": "",
                "v-bind:isAuth.sync": "isAuth"
            },
            KcUpValue: {
                "xmlns:v-bind": "",
                "v-bind:title.sync": "title",
                "v-bind:text1.sync": "text1",
                "v-bind:text2.sync": "text2",
                "v-bind:text3.sync": "text3",
                "v-bind:leftBtnText.sync": "leftBtnText",
                "v-bind:rightBtnText.sync": "rightBtnText",
                "v-bind:leftCb.sync": "leftCb",
                "v-bind:rightCb.sync": "rightCb",
                "v-bind:imgSrc.sync": "imgSrc"
            }
        }, a.$events = {}, a.components = {
            KcShowGuide: _KcShowGuide2.default,
            OnlineModal: _OnlineModal2.default,
            KcLoading: _KcLoading2.default,
            KcErrorModal: _KcErrorModal2.default,
            kcUpdateModle: _kcUpdateModle2.default,
            vipModle: _KcVipModal2.default,
            receiveVipModal: _receiveVipModal2.default,
            KcUpValue: _KcUpValue2.default
        }, a.mixins = [], a.data = {
            lock: !1,
            selectSubjectShow: !1,
            loadingHide: !0,
            options: {},
            unlockInfo: {},
            showMask: !1,
            unlockModle: !1,
            noUpModle: !1,
            userInfo: {
                head: "",
                upValue: "",
                points: "",
                pointsRank: "",
                pointsChange: "",
                subject: "",
                subjectRank: "",
                subjectChange: ""
            },
            learned: !1,
            canFree: !1,
            subjectList: [],
            online: "",
            isComplete: !1,
            firstAnswer: !1,
            isStart: !1,
            completeNum: 0,
            banner: "",
            hasVip: !1,
            showGuide: !1,
            isFirstOnShow: !0,
            isAuth: !1,
            isNew: !0,
            subjectUnlearn: !1,
            welcomeShow: !1,
            payloadFromApp: {},
            payloadFromWeb: {},
            handleAPPWebSuccess: !1,
            helpStatus: !1,
            isSubscribeShow: !1,
            publicCourseCount: 0,
            noPointsData: !1,
            swiperList: [],
            createTime: 0,
            imgSrc: "",
            title: "",
            text1: "",
            text2: "",
            text3: "",
            leftBtnText: "",
            rightBtnText: "",
            leftCb: null,
            rightCb: null,
            isnewuser: 0,
            animation: null,
            indexCourse: {},
            subjectData: [],
            pointData: [],
            bannerBtn: {},
            bannerPic: {},
            bannerMiniprogram: {},
            checkStatus: !1,
            showShare: !1
        }, a.computed = {}, a.methods = {
            goShare: function() {
                _kcLog2.default.send({
                    pagename: "HomePage",
                    name: "freeUnlockClick",
                    category: "webClick",
                    pt: "mini"
                });
                _wepy2.default.navigateTo({
                    url: "web?url=" + encodeURIComponent("https://mp.weixin.qq.com/s?__biz=MzU2ODcxNTYxNQ==&mid=2247740302&idx=1&sn=c6fd89beba752422044d374527ebe459&chksm=fc84dbbecbf352a8e58c6e892570d58e420ceb7847177645657e8205f189a4b2d18707db7e1e&token=373004341&lang=zh_CN#rd")
                });
            },
            handleContact: function(e) {
                _kcLog2.default.send({
                    pagename: "HomePage",
                    name: "messageCardClick",
                    category: "webClick",
                    pt: "mini"
                }), _kcLog2.default.send({
                    pagename: "HomePage",
                    name: "joinGroupClick",
                    category: "webClick",
                    pt: "mini"
                });
            },
            goVip: function() {
                _kcLog2.default.send({
                    pagename: "HomePage",
                    name: "vipClick",
                    category: "webClick",
                    pt: "mini"
                });
                _wepy2.default.navigateTo({
                    url: "web?url=" + encodeURIComponent("https://mp.weixin.qq.com/s?__biz=MzU2ODcxNTYxNQ==&mid=2247709644&idx=1&sn=3c4d5f76282c25f9f002ec736bd29f51&chksm=fc8443fccbf3caea2eacaebff39971de1e76aa63c6a4d984c933830e6d9991137062adf7ae07#rd")
                });
            },
            LearnWxLogin: function() {
                function e(e) {
                    return t.apply(this, arguments);
                }
                var t = _asyncToGenerator(regeneratorRuntime.mark(function e(t) {
                    var n, a, r = this;
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            if (!this.lock) {
                                e.next = 2;
                                break;
                            }
                            return e.abrupt("return", !1);

                          case 2:
                            _kcLog2.default.send({
                                pagename: "HomePage",
                                name: "signupWindowShow",
                                category: "webShow",
                                pt: "mini",
                                bundleid: "zhengzhi1000"
                            }), this.lock = !0, n = this.wxSilentLogin(), a = this.wxGetUserProfile(), Promise.all([ n, a ]).then(function() {
                                var e = _asyncToGenerator(regeneratorRuntime.mark(function e(t) {
                                    var n, a, o, i;
                                    return regeneratorRuntime.wrap(function(e) {
                                        for (;;) switch (e.prev = e.next) {
                                          case 0:
                                            return _kcLog2.default.send({
                                                pagename: "HomePage",
                                                name: "loginClick",
                                                category: "login",
                                                pt: "mini",
                                                bundleid: "zhengzhi1000"
                                            }), n = t[0], a = t[1].iv, o = t[1].encryptedData, i = {
                                                code: n,
                                                encryptedData: o,
                                                iv: a
                                            }, console.log(i), e.next = 8, _api2.default.register(i);

                                          case 8:
                                            r.lock = !1, wx.reLaunch({
                                                url: "index"
                                            });

                                          case 10:
                                          case "end":
                                            return e.stop();
                                        }
                                    }, e, r);
                                }));
                                return function(t) {
                                    return e.apply(this, arguments);
                                };
                            }()).catch(function() {
                                r.showMask = !0, r.selectSubjectShow = !0, r.lock = !1, _kcLog2.default.send({
                                    pagename: "HomePage",
                                    name: "refuseClick",
                                    category: "webClick",
                                    pt: "mini",
                                    bundleid: "zhengzhi1000"
                                }), r.$apply();
                            });

                          case 7:
                          case "end":
                            return e.stop();
                        }
                    }, e, this);
                }));
                return e;
            }(),
            wxLogin: function() {
                function e(e) {
                    return t.apply(this, arguments);
                }
                var t = _asyncToGenerator(regeneratorRuntime.mark(function e(t) {
                    var n, a, r = this;
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            if (!this.lock) {
                                e.next = 2;
                                break;
                            }
                            return e.abrupt("return", !1);

                          case 2:
                            _kcLog2.default.send({
                                pagename: "HomePage",
                                name: "signupWindowShow",
                                category: "webShow",
                                pt: "mini",
                                bundleid: "zhengzhi1000"
                            }), this.lock = !0, n = this.wxSilentLogin(), a = this.wxGetUserProfile(), Promise.all([ n, a ]).then(function() {
                                var e = _asyncToGenerator(regeneratorRuntime.mark(function e(t) {
                                    var n, a, o, i;
                                    return regeneratorRuntime.wrap(function(e) {
                                        for (;;) switch (e.prev = e.next) {
                                          case 0:
                                            return _kcLog2.default.send({
                                                pagename: "HomePage",
                                                name: "loginClick",
                                                category: "login",
                                                pt: "mini",
                                                bundleid: "zhengzhi1000"
                                            }), n = t[0], a = t[1].iv, o = t[1].encryptedData, i = {
                                                code: n,
                                                encryptedData: o,
                                                iv: a
                                            }, console.log(i), e.next = 8, _api2.default.register(i);

                                          case 8:
                                            r.lock = !1, r.$apply(), wx.reLaunch({
                                                url: "index"
                                            });

                                          case 11:
                                          case "end":
                                            return e.stop();
                                        }
                                    }, e, r);
                                }));
                                return function(t) {
                                    return e.apply(this, arguments);
                                };
                            }()).catch(function() {
                                _kcLog2.default.send({
                                    pagename: "HomePage",
                                    name: "refuseClick",
                                    category: "webClick",
                                    pt: "mini",
                                    bundleid: "zhengzhi1000"
                                }), r.lock = !1, r.$apply();
                            });

                          case 7:
                          case "end":
                            return e.stop();
                        }
                    }, e, this);
                }));
                return e;
            }(),
            gotoRanking: function(e) {
                _kcLog2.default.send({
                    pagename: "HomePage",
                    name: "rankClick",
                    category: "webClick",
                    pt: "mini",
                    bundleid: "zhengzhi1000"
                });
                var t = {
                    rankType: e
                };
                this.$navigate("ranking", t), this.hasChangeRoute();
            },
            welcomeAnimationstart: function() {
                console.log("welcomeAnimationstart");
            },
            welcomeAnimationend: function() {
                console.log("welcomeAnimationend"), this.welcomeShow = !1;
            },
            startReview: function() {
                function e() {
                    return t.apply(this, arguments);
                }
                var t = _asyncToGenerator(regeneratorRuntime.mark(function e() {
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            return e.next = 2, _storage2.default.set("isStart", !0);

                          case 2:
                            this.isStart = !0, this.$apply();

                          case 4:
                          case "end":
                            return e.stop();
                        }
                    }, e, this);
                }));
                return e;
            }(),
            gotoReview: function(e) {
                _kcLog2.default.send({
                    pagename: "HomePage",
                    name: "reviewClick",
                    category: "webClick",
                    pt: "mini"
                }), this.learned && this.isAuth && (wx.navigateTo({
                    url: "reviewIndex?sid=" + e
                }), this.hasChangeRoute());
            },
            gotoUnlock: function() {
                function e() {
                    return t.apply(this, arguments);
                }
                var t = _asyncToGenerator(regeneratorRuntime.mark(function e() {
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            return e.next = 2, this.unlockCourse();

                          case 2:
                            _common2.default.business({
                                BSceneCode: "startLearn",
                                BDescribe: "点击学习按钮",
                                BType: 2,
                                ext: {
                                    subjectId: this.unlockInfo.sid,
                                    stageIndex: this.unlockInfo.day
                                }
                            });

                          case 3:
                          case "end":
                            return e.stop();
                        }
                    }, e, this);
                }));
                return e;
            }(),
            hideModle: function() {
                this.showMask = !1, this.unlockModle = !1, this.noUpModle = !1, this.selectSubjectShow = !1, 
                this.setChart();
            },
            goSentenceApp: function() {
                wx.reportAnalytics("index_20_click_gosentenceapp", {}), _wepy2.default.navigateToMiniProgram({
                    appId: "wxfa0c84e2ddfb8989",
                    envVersion: "release"
                });
            },
            goCourse: function(e) {
                _kcLog2.default.send({
                    pagename: "HomePage",
                    name: "courseAdClick",
                    category: "webClick",
                    pt: "mini"
                }), _api2.default.clickPublicCourse(), _wepy2.default.navigateToMiniProgram({
                    appId: e.appId,
                    envVersion: "release",
                    path: e.page
                });
            },
            goWeb: function(e) {
                _kcLog2.default.send({
                    pagename: "HomePage",
                    name: "bannerClick",
                    category: "webClick",
                    pt: "mini",
                    bundleid: "zhengzhi1000"
                }), _wepy2.default.navigateTo({
                    url: "web?url=" + encodeURIComponent(e)
                });
            },
            goAdvice: function() {
                wx.reportAnalytics("index_20_cttlick_goadvice", {});
                _wepy2.default.navigateTo({
                    url: "web?url=" + encodeURIComponent("https://mp.weixin.qq.com/s/1L1D1oqE3AFv-sUjnGc8aQ")
                });
            },
            selectSubject: function() {
                _kcLog2.default.send({
                    pagename: "HomePage",
                    name: "startClick",
                    category: "webClick",
                    pt: "mini",
                    bundleid: "zhengzhi1000"
                }), this.showMask = !0, this.selectSubjectShow = !0;
            },
            goLearn: function(e, t, n, a) {
                var r = [ "", "马原", "毛中特", "史纲", "思法" ];
                if (console.log(e, t, n, a), _kcLog2.default.send({
                    pagename: "HomePage",
                    name: "subjectClick",
                    category: "webClick",
                    content: r[e],
                    pt: "mini"
                }), !this.isAuth) return void (3 === e && 0 === t ? (wx.navigateTo({
                    url: "learnIndex?sid=" + e + "&day=1"
                }), this.hasChangeRoute()) : wx.showToast({
                    title: "请授权登录",
                    icon: "none",
                    duration: 3e3
                }));
                t < n && n <= a ? (console.log("已解锁首页去课程列表", "learnIndex?sid=" + e + "&day=" + (t + 1)), 
                wx.navigateTo({
                    url: "learnIndex?sid=" + e + "&day=" + (t + 1)
                }), this.hasChangeRoute()) : t === a ? wx.showToast({
                    title: "已全部学完",
                    icon: "success",
                    duration: 3e3
                }) : this.userInfo.upValue < 20 ? wx.showToast({
                    title: "剩余up值不够，去收集更多吧",
                    icon: "none",
                    duration: 3e3
                }) : this.unlockCourse(e, n + 1);
            },
            tapAvatar: function() {
                !this.hasVip && this.isAuth && (_kcLog2.default.send({
                    pagename: "HomePage",
                    name: "myUpClick",
                    category: "webClick",
                    pt: "mini"
                }), this.gotoUpvalue());
            },
            imgError: function(e) {
                console.log("图片错误", e);
            },
            subscribe: function() {
                _kcLog2.default.send({
                    pagename: "HomePage",
                    name: "remindClick",
                    category: "webClick",
                    pt: "mini"
                }), wx.requestSubscribeMessage({
                    tmplIds: [ "CYWPM2zY4_XAQitSdB8a9vKNtH4rdIf08skg-LTKVH4" ],
                    success: function(e) {
                        _kcLog2.default.send({
                            pagename: "HomePage",
                            name: "remindAgreeClick",
                            category: "webClick",
                            pt: "mini"
                        }), _api2.default.subscribeMessage(e);
                    },
                    fail: function() {
                        _kcLog2.default.send({
                            pagename: "HomePage",
                            name: "remindRefuseClick",
                            category: "webClick",
                            pt: "mini"
                        });
                    }
                }), this.isSubscribeShow = !1, _storage2.default.set("subscribeClose", Math.round(new Date() / 1e3));
            },
            goStudyData: function() {
                _kcLog2.default.send({
                    pagename: "HomePage",
                    name: "wrongChapterClick",
                    category: "webClick",
                    pt: "mini"
                }), this.$navigate("studyData");
            }
        }, r = n, _possibleConstructorReturn(a, r);
    }
    return _inherits(t, e), _createClass(t, [ {
        key: "translate",
        value: function() {
            var e = this;
            setTimeout(function() {
                e.animation.translateY(-20).step(), e.setData({
                    animation: e.animation.export()
                });
            }, 1e3), this.$apply();
        }
    }, {
        key: "onLoad",
        value: function() {
            function e(e) {
                return t.apply(this, arguments);
            }
            var t = _asyncToGenerator(regeneratorRuntime.mark(function e(t) {
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return _kcLog2.default.send({
                            pagename: "HomePage",
                            name: "homePageView",
                            category: "webPageView",
                            pt: "mini"
                        }), this.width = 750 / wx.getSystemInfoSync().windowWidth, this.animation = wx.createAnimation(), 
                        this.options = t, _storage2.default.set("contactBack", !1), e.next = 7, this.posterHelp();

                      case 7:
                      case "end":
                        return e.stop();
                    }
                }, e, this);
            }));
            return e;
        }()
    }, {
        key: "onShow",
        value: function() {
            function e() {
                return t.apply(this, arguments);
            }
            var t = _asyncToGenerator(regeneratorRuntime.mark(function e() {
                var t, n, a, r, o = this;
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return this.handleShowGuide(), e.next = 3, this.handleFromAPPWeb();

                      case 3:
                        return e.next = 5, this.loadIndexData();

                      case 5:
                        return e.next = 7, this.getIndexBanner();

                      case 7:
                        return e.next = 9, _storage2.default.get(_constant2.default.KEY_IS_NEW);

                      case 9:
                        if (e.t0 = e.sent, e.t0) {
                            e.next = 12;
                            break;
                        }
                        e.t0 = !1;

                      case 12:
                        if (this.isNew = e.t0, this.$apply(), !this.isFirstOnShow) {
                            e.next = 18;
                            break;
                        }
                        return this.isFirstOnShow = !1, e.next = 18, this.handleOptions();

                      case 18:
                        return e.next = 20, _storage2.default.get(_constant2.default.KEY_INDEX_PAID_WELCOME);

                      case 20:
                        if (e.t1 = e.sent, e.t1) {
                            e.next = 23;
                            break;
                        }
                        e.t1 = !1;

                      case 23:
                        return t = e.t1, !t && this.hasVip && this.isAuth && setTimeout(function() {
                            o.welcomeShow = !0, o.$apply(), _storage2.default.set(_constant2.default.KEY_INDEX_PAID_WELCOME, !0);
                        }, 1e3), e.next = 27, _storage2.default.get("subscribeClose");

                      case 27:
                        if (e.t2 = e.sent, e.t2) {
                            e.next = 30;
                            break;
                        }
                        e.t2 = 0;

                      case 30:
                        return n = e.t2, e.next = 33, _storage2.default.get("studyTime");

                      case 33:
                        if (e.t3 = e.sent, e.t3) {
                            e.next = 36;
                            break;
                        }
                        e.t3 = 0;

                      case 36:
                        a = e.t3, r = Math.round(new Date() / 1e3), r - n > 86400 && a < 6 && a > 0 ? (this.isSubscribeShow = !0, 
                        this.translate(), _kcLog2.default.send({
                            pagename: "HomePage",
                            name: "remindWindowShow",
                            category: "webShow",
                            pt: "mini"
                        })) : this.isSubscribeShow = !1, wx.reportAnalytics("index_20_show", {
                            isnewuser: this.isnewuser
                        });

                      case 40:
                      case "end":
                        return e.stop();
                    }
                }, e, this);
            }));
            return e;
        }()
    }, {
        key: "posterHelp",
        value: function() {
            function e() {
                return t.apply(this, arguments);
            }
            var t = _asyncToGenerator(regeneratorRuntime.mark(function e() {
                var t, n, a;
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (this.handleAPPWebSuccess) {
                            e.next = 19;
                            break;
                        }
                        return t = decodeURIComponent(this.options.scene), this.payloadFromWeb.id = _common2.default.getQueryParam(t, "id"), 
                        e.next = 5, _storage2.default.get("contactBack");

                      case 5:
                        if (e.t0 = e.sent, e.t0) {
                            e.next = 8;
                            break;
                        }
                        e.t0 = !1;

                      case 8:
                        if (n = e.t0, this.$apply(), !this.payloadFromWeb.id || n) {
                            e.next = 19;
                            break;
                        }
                        return e.next = 13, _api2.default.posterHelp({
                            mpOpenId: this.payloadFromWeb.id
                        });

                      case 13:
                        return a = e.sent, 5025 === a.helpStatus ? wx.showToast({
                            title: "助力成功",
                            icon: "none",
                            duration: 3e3
                        }) : wx.showToast({
                            title: "助力失败",
                            icon: "none",
                            duration: 3e3
                        }), this.$apply(), this.handleAPPWebSuccess = !0, this.$apply(), e.abrupt("return", !1);

                      case 19:
                      case "end":
                        return e.stop();
                    }
                }, e, this);
            }));
            return e;
        }()
    }, {
        key: "handleFromAPPWeb",
        value: function() {
            function e() {
                return t.apply(this, arguments);
            }
            var t = _asyncToGenerator(regeneratorRuntime.mark(function e() {
                var t;
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (this.handleAPPWebSuccess) {
                            e.next = 22;
                            break;
                        }
                        if (this.loadingHide = !1, this.payloadFromApp.uid = this.options.uid, this.payloadFromApp.security = this.options.security, 
                        this.payloadFromApp.source = this.options.source, this.payloadFromApp.timeStamp = this.options.timeStamp, 
                        this.payloadFromApp.teachingCourseId = this.options.teachingCourseId, this.payloadFromApp.tag = this.options.tag, 
                        t = decodeURIComponent(this.options.scene), this.payloadFromWeb.key = _common2.default.getQueryParam(t, "key"), 
                        this.payloadFromWeb.name = _common2.default.getQueryParam(t, "miniprogram"), this.$apply(), 
                        "2" !== this.payloadFromWeb.name || !this.payloadFromWeb.key) {
                            e.next = 17;
                            break;
                        }
                        return e.next = 15, _api2.default.updateAppUserStatus({
                            key: this.payloadFromWeb.key
                        });

                      case 15:
                        e.next = 20;
                        break;

                      case 17:
                        if (!this.payloadFromApp.uid) {
                            e.next = 20;
                            break;
                        }
                        return e.next = 20, _api2.default.updateAppUserStatus(_extends({}, this.payloadFromApp));

                      case 20:
                        this.handleAPPWebSuccess = !0, this.$apply();

                      case 22:
                      case "end":
                        return e.stop();
                    }
                }, e, this);
            }));
            return e;
        }()
    }, {
        key: "getIndexBanner",
        value: function() {
            function e() {
                return t.apply(this, arguments);
            }
            var t = _asyncToGenerator(regeneratorRuntime.mark(function e() {
                var t;
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return e.next = 2, _api2.default.indexBanner();

                      case 2:
                        t = e.sent, this.bannerBtn = t.banners[0], this.bannerPic = t.banners[1], this.bannerMiniprogram = t.banners[2];

                      case 6:
                      case "end":
                        return e.stop();
                    }
                }, e, this);
            }));
            return e;
        }()
    }, {
        key: "unlockCourse",
        value: function() {
            function e(e, n) {
                return t.apply(this, arguments);
            }
            var t = _asyncToGenerator(regeneratorRuntime.mark(function e(t, n) {
                var a;
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return e.prev = 0, e.next = 3, _storage2.default.get("token");

                      case 3:
                        if (e.t0 = e.sent, e.t0) {
                            e.next = 6;
                            break;
                        }
                        e.t0 = 0;

                      case 6:
                        return a = e.t0, e.next = 9, _api2.default.unlockCourse({
                            subjectId: t,
                            stage: n,
                            token: a
                        });

                      case 9:
                        wx.showToast({
                            title: "-20up值，解锁成功",
                            icon: "none",
                            duration: 3e3
                        }), setTimeout(function() {
                            wx.navigateTo({
                                url: "learnIndex?sid=" + t + "&day=" + n
                            });
                        }, 2e3), this.hasChangeRoute(), e.next = 17;
                        break;

                      case 14:
                        e.prev = 14, e.t1 = e.catch(0), wx.showToast({
                            title: "解锁失败,请重试",
                            icon: "none",
                            duration: 3e3
                        });

                      case 17:
                      case "end":
                        return e.stop();
                    }
                }, e, this, [ [ 0, 14 ] ]);
            }));
            return e;
        }()
    }, {
        key: "handleShowGuide",
        value: function() {
            function e() {
                return t.apply(this, arguments);
            }
            var t = _asyncToGenerator(regeneratorRuntime.mark(function e() {
                var t;
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return e.next = 2, _storage2.default.get("hasShowGuide");

                      case 2:
                        if (e.t0 = e.sent, e.t0) {
                            e.next = 5;
                            break;
                        }
                        e.t0 = !1;

                      case 5:
                        t = e.t0, _hasChangeRoute && !t && (this.showGuide = !0);

                      case 7:
                      case "end":
                        return e.stop();
                    }
                }, e, this);
            }));
            return e;
        }()
    }, {
        key: "hasChangeRoute",
        value: function() {
            _hasChangeRoute = !0;
        }
    }, {
        key: "gotoLogin",
        value: function() {
            this.$navigate("login");
        }
    }, {
        key: "goUpvalue",
        value: function() {
            _kcLog2.default.send({
                pagename: "HomePage",
                name: "guideClick",
                category: "webClick",
                pt: "mini"
            }), this.gotoUpvalue();
        }
    }, {
        key: "gotoUpvalue",
        value: function() {
            wx.navigateTo({
                url: "upValue"
            }), this.hasChangeRoute();
        }
    }, {
        key: "handleOptions",
        value: function() {
            function e() {
                return t.apply(this, arguments);
            }
            var t = _asyncToGenerator(regeneratorRuntime.mark(function e() {
                var t, n, a, r, o, i, s, c, u, l, p;
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (e.prev = 0, t = decodeURIComponent(this.options.scene), "1" !== (n = _common2.default.getQueryParam(t, "fr")) && "share" !== this.options.from) {
                            e.next = 26;
                            break;
                        }
                        return a = _common2.default.getQueryParam(t, "uid"), r = _common2.default.getQueryParam(t, "date"), 
                        o = this.options.openId, i = this.options.up, e.next = 10, _storage2.default.get(_constant2.default.KEY_IS_NEW);

                      case 10:
                        if (e.t0 = e.sent, e.t0) {
                            e.next = 13;
                            break;
                        }
                        e.t0 = !1;

                      case 13:
                        if (s = e.t0, s && _storage2.default.set(_constant2.default.KEY_IS_NEW, !1), c = {
                            shareType: "1" === n ? 3 : i ? 2 : 1,
                            isNew: s
                        }, "1" === n ? c.shareUserId = a : c.shareOpenId = o, _api2.default.submitShareStats(c), 
                        "1" !== n && !i) {
                            e.next = 25;
                            break;
                        }
                        return u = {
                            helpType: i ? 1 : 2
                        }, "1" === n ? (u.shareUserId = a, u.qrCodeTime = r) : u.sharerOpenId = o, e.next = 23, 
                        _api2.default.upValue(u);

                      case 23:
                        l = e.sent, l.successMsg && wx.showToast({
                            title: l.successMsg,
                            icon: "none",
                            duration: 3e3
                        });

                      case 25:
                        this.options.link && (p = decodeURIComponent(this.options.link), wx.navigateTo({
                            url: decodeURIComponent(p)
                        }), this.hasChangeRoute());

                      case 26:
                        e.next = 30;
                        break;

                      case 28:
                        e.prev = 28, e.t1 = e.catch(0);

                      case 30:
                      case "end":
                        return e.stop();
                    }
                }, e, this, [ [ 0, 28 ] ]);
            }));
            return e;
        }()
    }, {
        key: "loadIndexData",
        value: function() {
            function e() {
                return t.apply(this, arguments);
            }
            var t = _asyncToGenerator(regeneratorRuntime.mark(function e() {
                var t, n, a, r = this;
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return this.loadingHide = !1, this.$apply(), this.unlockInfo = {}, this.showMask = !1, 
                        this.selectSubjectShow = !1, this.unlockModle = !1, this.noUpModle = !1, this.pointData = [], 
                        this.subjectData = [], e.next = 11, _api2.default.indexInfo();

                      case 11:
                        return t = e.sent, e.next = 14, _storage2.default.get("isStart");

                      case 14:
                        if (this.isStart = e.sent, !this.isFirstOnShow) {
                            e.next = 24;
                            break;
                        }
                        if (!t.isAuth) {
                            e.next = 23;
                            break;
                        }
                        return e.next = 19, _storage2.default.get(_constant2.default.KEY_UNIONID);

                      case 19:
                        if (n = e.sent) {
                            e.next = 23;
                            break;
                        }
                        return e.next = 23, _storage2.default.set(_constant2.default.KEY_UNIONID, t.unionId);

                      case 23:
                        _common2.default.business({
                            BSceneCode: "pageLoad",
                            BDescribe: "首页打开成功"
                        });

                      case 24:
                        this.showShare = t.showShare, this.userInfo = t.userInfo, this.$parent.globalData.userInfo = t.userInfo, 
                        this.online = t.online, this.learned = t.userInfo.learned, this.isComplete = t.isComplete, 
                        this.firstAnswer = t.userInfo.firstAnswer, this.indexCourse = t.indexCourse, this.checkStatus = t.checkStatus, 
                        this.subjectList = t.subjectList, this.subjectList.forEach(function(e) {
                            r.subjectData.push(e.subjectName), r.pointData.push(parseInt(e.pointGraspRate));
                        }), a = Array.isArray(t.subjectList) ? t.subjectList.filter(function(e) {
                            return 0 === e.learnDay && 0 === e.unlockDay;
                        }) : [], this.subjectUnlearn = 4 === a.length, this.completeNum = t.completeNum, 
                        this.banner = t.banner, this.isAuth = t.userInfo.isAuth, this.isAuthPhone = t.userInfo.isAuthPhone, 
                        _storage2.default.set("isAuthPhone", this.isAuthPhone), this.canFree = t.canFree, 
                        this.hasVip = t.userInfo.payFlag || !1, this.$parent.globalData.hasPay = t.payFlag || !1, 
                        this.publicCourseCount = t.publicCourseCount, this.createTime = t.userInfo.createTime, 
                        this.getTimeStamp() === this.createTime ? this.isnewuser = 1 : this.isnewuser = 0, 
                        this.loadingHide = !0, this.$apply(), this.setChart(), _storage2.default.set("upValue", this.userInfo.upValue), 
                        _storage2.default.set("hasVip", this.hasVip), _storage2.default.set("subjectList", this.subjectList), 
                        _storage2.default.set("isnewuser", this.isnewuser);

                      case 55:
                      case "end":
                        return e.stop();
                    }
                }, e, this);
            }));
            return e;
        }()
    }, {
        key: "handleError",
        value: function() {
            function e(e, n) {
                return t.apply(this, arguments);
            }
            var t = _asyncToGenerator(regeneratorRuntime.mark(function e(t, n) {
                var a, r = this;
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (this.loadingHide = !0, this.$apply(), "handleFromAPPWeb" !== n) {
                            e.next = 5;
                            break;
                        }
                        return t && 5022 === t.code ? (a = encodeURIComponent("index" + _common2.default.obj2url(this.options)), 
                        this.$redirect("login", {
                            link: a,
                            hideCancel: 1
                        })) : this.$invoke("KcErrorModal", "showModal", {
                            err: t,
                            btnMsg: "重新加载",
                            cb: function() {
                                function e() {
                                    return t.apply(this, arguments);
                                }
                                var t = _asyncToGenerator(regeneratorRuntime.mark(function e() {
                                    return regeneratorRuntime.wrap(function(e) {
                                        for (;;) switch (e.prev = e.next) {
                                          case 0:
                                            return e.next = 2, r.handleFromAPPWeb();

                                          case 2:
                                            r.loadIndexData();

                                          case 3:
                                          case "end":
                                            return e.stop();
                                        }
                                    }, e, r);
                                }));
                                return e;
                            }()
                        }), e.abrupt("return");

                      case 5:
                        this.$invoke("KcErrorModal", "showModal", {
                            err: t,
                            btnMsg: "重新加载",
                            cb: function() {
                                r.loadIndexData();
                            }
                        });

                      case 6:
                      case "end":
                        return e.stop();
                    }
                }, e, this);
            }));
            return e;
        }()
    }, {
        key: "onHide",
        value: function() {
            this.clearIsNew();
        }
    }, {
        key: "onUnload",
        value: function() {
            this.clearIsNew();
        }
    }, {
        key: "clearIsNew",
        value: function() {
            _storage2.default.get(_constant2.default.KEY_IS_NEW).then(function(e) {
                e && _storage2.default.set(_constant2.default.KEY_IS_NEW, !1);
            });
        }
    }, {
        key: "onShareAppMessage",
        value: function(e) {
            return _common2.default.shareTxt();
        }
    }, {
        key: "setPointsData",
        value: function() {
            for (var e = 0; e < this.subjectList.length; e++) {
                if (this.subjectList[e].learnDay > 0) return void (this.noPointsData = !1);
            }
            this.noPointsData = !0;
        }
    }, {
        key: "getTimeStamp",
        value: function() {
            var e = new Date(), t = "" + e.getFullYear(), n = "" + (e.getMonth() + 1), a = "" + e.getDate();
            return parseInt(t, 10) < 10 && (t = "0" + t), parseInt(n, 10) < 10 && (n = "0" + n), 
            parseInt(a, 10) < 10 && (a = "0" + a), t + "-" + n + "-" + a;
        }
    }, {
        key: "setChart",
        value: function() {
            console.log(wx.getSystemInfoSync().windowWidth);
            var e = wx.getSystemInfoSync().windowWidth * (650 / 750), t = .44 * wx.getSystemInfoSync().windowWidth, n = {
                main: {
                    data: this.pointData,
                    categories: this.subjectData
                }
            };
            new _eChart2.default({
                canvasId: "columnCanvas",
                type: "column",
                categories: n.main.categories,
                series: [ {
                    name: "成交量",
                    data: n.main.data,
                    format: function(e, t) {
                        return e + "%";
                    },
                    color: "#6787FF"
                } ],
                yAxis: {
                    format: function(e) {
                        return e + "%";
                    },
                    min: 0,
                    max: 100,
                    disabled: !0
                },
                xAxis: {
                    disableGrid: !1,
                    type: "calibration"
                },
                extra: {
                    column: {
                        width: 30
                    }
                },
                width: e,
                height: t,
                legend: !1
            });
        }
    }, {
        key: "wxSilentLogin",
        value: function() {
            return new Promise(function(e, t) {
                wx.login({
                    success: function(t) {
                        e(t.code);
                    },
                    fail: function(e) {
                        t(e);
                    }
                });
            });
        }
    }, {
        key: "wxGetUserProfile",
        value: function() {
            return new Promise(function(e, t) {
                wx.getUserProfile({
                    desc: "小程序需要您的授权才能正常使用",
                    success: function(t) {
                        e(t);
                    },
                    fail: function(e) {
                        t(e);
                    }
                });
            });
        }
    } ]), t;
}(_wepy2.default.page), _applyDecoratedDescriptor(_class.prototype, "posterHelp", [ _dec ], Object.getOwnPropertyDescriptor(_class.prototype, "posterHelp"), _class.prototype), 
_applyDecoratedDescriptor(_class.prototype, "handleFromAPPWeb", [ _dec2 ], Object.getOwnPropertyDescriptor(_class.prototype, "handleFromAPPWeb"), _class.prototype), 
_applyDecoratedDescriptor(_class.prototype, "loadIndexData", [ _dec3 ], Object.getOwnPropertyDescriptor(_class.prototype, "loadIndexData"), _class.prototype), 
_class);

Page(require("./../npm/wepy/lib/wepy.js").default.$createPage(Home, "pages/index"));