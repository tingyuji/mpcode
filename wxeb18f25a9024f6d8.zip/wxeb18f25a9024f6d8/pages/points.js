function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function _asyncToGenerator(e) {
    return function() {
        var t = e.apply(this, arguments);
        return new Promise(function(e, r) {
            function n(o, i) {
                try {
                    var s = t[o](i), a = s.value;
                } catch (e) {
                    return void r(e);
                }
                if (!s.done) return Promise.resolve(a).then(function(e) {
                    n("next", e);
                }, function(e) {
                    n("throw", e);
                });
                e(a);
            }
            return n("next");
        });
    };
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t;
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _createClass = function() {
    function e(e, t) {
        for (var r = 0; r < t.length; r++) {
            var n = t[r];
            n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), 
            Object.defineProperty(e, n.key, n);
        }
    }
    return function(t, r, n) {
        return r && e(t.prototype, r), n && e(t, n), t;
    };
}(), _wepy = require("./../npm/wepy/lib/wepy.js"), _wepy2 = _interopRequireDefault(_wepy), _common = require("./../common/common.js"), _common2 = _interopRequireDefault(_common), _api = require("./../common/api.js"), _api2 = _interopRequireDefault(_api), _KcShowError = require("./../components/KcShowError.js"), _KcShowError2 = _interopRequireDefault(_KcShowError), _error = require("./../mixins/error.js"), _error2 = _interopRequireDefault(_error), Points = function(e) {
    function t() {
        var e, r, n, o;
        _classCallCheck(this, t);
        for (var i = arguments.length, s = Array(i), a = 0; a < i; a++) s[a] = arguments[a];
        return r = n = _possibleConstructorReturn(this, (e = t.__proto__ || Object.getPrototypeOf(t)).call.apply(e, [ this ].concat(s))), 
        n.config = {
            navigationBarTitleText: "回顾本题考察的考点",
            navigationBarBackgroundColor: "#F9FAFC"
        }, n.$repeat = {}, n.$props = {
            KcShowError: {
                "xmlns:v-bind": "",
                "v-bind:show.sync": "showErrorModul",
                "v-bind:type.sync": "errorType"
            }
        }, n.$events = {}, n.components = {
            KcShowError: _KcShowError2.default
        }, n.mixins = [ _error2.default ], n.data = {
            source: "",
            points: [],
            current: 0,
            success: !1,
            sectionId: "",
            subjectId: "",
            stage: "",
            pointId: ""
        }, n.methods = {
            gotoNextQues: function() {
                var e = this.getCurrentPages();
                if (Array.isArray(e) && e.length > 1) {
                    var t = e[e.length - 2];
                    t.nextTapEvent && t.nextTapEvent();
                }
                _wepy2.default.navigateBack({
                    delta: 1
                });
            },
            backToPrePage: function() {
                _wepy2.default.navigateBack({
                    delta: 1
                });
            },
            gotoNextPoit: function() {
                this.current < 0 || this.current >= this.points.length - 1 ? this.current = 0 : this.current++;
            }
        }, o = r, _possibleConstructorReturn(n, o);
    }
    return _inherits(t, e), _createClass(t, [ {
        key: "onLoad",
        value: function() {
            function e(e) {
                return t.apply(this, arguments);
            }
            var t = _asyncToGenerator(regeneratorRuntime.mark(function e(t) {
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        this.source = t.source || "", this.sectionId = t.sectionId, this.subjectId = t.subjectId, 
                        this.stage = t.stage, this.pointId = t.pointId;

                      case 5:
                      case "end":
                        return e.stop();
                    }
                }, e, this);
            }));
            return e;
        }()
    }, {
        key: "getPointsData",
        value: function() {
            function e() {
                return t.apply(this, arguments);
            }
            var t = _asyncToGenerator(regeneratorRuntime.mark(function e() {
                var t, r;
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return e.prev = 0, wx.showLoading({}), t = {}, this.sectionId && (t.sectionId = this.sectionId, 
                        t.subjectId = this.subjectId, t.stage = this.stage), this.pointId && (t.pointId = this.pointId), 
                        e.next = 7, _api2.default.getPointDetail(t);

                      case 7:
                        r = e.sent, Array.isArray(r.points) && r.points.length > 0 ? (this.points = r.points, 
                        this.success = !0, this.$apply()) : this.showError({
                            errMsg: "fail data empty"
                        }), wx.hideLoading(), e.next = 16;
                        break;

                      case 12:
                        e.prev = 12, e.t0 = e.catch(0), this.showError(e.t0), wx.hideLoading();

                      case 16:
                      case "end":
                        return e.stop();
                    }
                }, e, this, [ [ 0, 12 ] ]);
            }));
            return e;
        }()
    }, {
        key: "onShareAppMessage",
        value: function(e) {
            return _common2.default.shareTxt();
        }
    } ]), t;
}(_wepy2.default.page);

Page(require("./../npm/wepy/lib/wepy.js").default.$createPage(Points, "pages/points"));