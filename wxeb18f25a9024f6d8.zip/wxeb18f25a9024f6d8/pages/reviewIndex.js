function _interopRequireDefault(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

function _asyncToGenerator(t) {
    return function() {
        var e = t.apply(this, arguments);
        return new Promise(function(t, n) {
            function r(a, i) {
                try {
                    var o = e[a](i), s = o.value;
                } catch (t) {
                    return void n(t);
                }
                if (!o.done) return Promise.resolve(s).then(function(t) {
                    r("next", t);
                }, function(t) {
                    r("throw", t);
                });
                t(s);
            }
            return r("next");
        });
    };
}

function _classCallCheck(t, e) {
    if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(t, e) {
    if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !e || "object" != typeof e && "function" != typeof e ? t : e;
}

function _inherits(t, e) {
    if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
    t.prototype = Object.create(e && e.prototype, {
        constructor: {
            value: t,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e);
}

function _applyDecoratedDescriptor(t, e, n, r, a) {
    var i = {};
    return Object.keys(r).forEach(function(t) {
        i[t] = r[t];
    }), i.enumerable = !!i.enumerable, i.configurable = !!i.configurable, ("value" in i || i.initializer) && (i.writable = !0), 
    i = n.slice().reverse().reduce(function(n, r) {
        return r(t, e, n) || n;
    }, i), a && void 0 !== i.initializer && (i.value = i.initializer ? i.initializer.call(a) : void 0, 
    i.initializer = void 0), void 0 === i.initializer && (Object.defineProperty(t, e, i), 
    i = null), i;
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _createClass = function() {
    function t(t, e) {
        for (var n = 0; n < e.length; n++) {
            var r = e[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), 
            Object.defineProperty(t, r.key, r);
        }
    }
    return function(e, n, r) {
        return n && t(e.prototype, n), r && t(e, r), e;
    };
}(), _dec, _desc, _value, _class, _wepy = require("./../npm/wepy/lib/wepy.js"), _wepy2 = _interopRequireDefault(_wepy), _api = require("./../common/api.js"), _api2 = _interopRequireDefault(_api), _common = require("./../common/common.js"), _common2 = _interopRequireDefault(_common), _storage = require("./../common/storage.js"), _storage2 = _interopRequireDefault(_storage), _constant = require("./../common/constant.js"), _constant2 = _interopRequireDefault(_constant), _eChart = require("./../common/e-chart.js"), _eChart2 = _interopRequireDefault(_eChart), _decorator = require("./../common/decorator.js"), _KcLoading = require("./../components/KcLoading.js"), _KcLoading2 = _interopRequireDefault(_KcLoading), _KcErrorModal = require("./../components/KcErrorModal.js"), _KcErrorModal2 = _interopRequireDefault(_KcErrorModal), _kcLog = require("./../npm/@kc-base/kc-log/dist/kc-log.js"), _kcLog2 = _interopRequireDefault(_kcLog), log = require("./../common/log.js"), touchStartX = 0, touchMoveX = 0, touchStartY = 0, touchMoveY = 0, Home = (_dec = (0, 
_decorator.trycatch)(), _class = function(t) {
    function e() {
        var t, n, r, a;
        _classCallCheck(this, e);
        for (var i = arguments.length, o = Array(i), s = 0; s < i; s++) o[s] = arguments[s];
        return n = r = _possibleConstructorReturn(this, (t = e.__proto__ || Object.getPrototypeOf(e)).call.apply(t, [ this ].concat(o))), 
        r.config = {
            navigationBarTitleText: "考点复习",
            navigationBarTextStyle: "black",
            navigationBarBackgroundColor: "#fff"
        }, r.data = {
            loadingHide: !0,
            width: 0,
            onlyFalse: !0,
            subjectList: [],
            current: -1,
            lastStudy: {},
            rnum: 0,
            fnum: 0,
            totalWrongNum: 0,
            allQuestion: 0,
            accNum: 0,
            content: [],
            hasPointDetail: 0,
            showCanvas: !1,
            showFilterTip: !1,
            moved: !1,
            pointToggleState: []
        }, r.$repeat = {}, r.$props = {
            KcLoading: {
                "xmlns:v-bind": "",
                "v-bind:loadingHide.sync": "loadingHide"
            }
        }, r.$events = {}, r.components = {
            KcLoading: _KcLoading2.default,
            KcErrorModal: _KcErrorModal2.default
        }, r.mixins = [], r.events = {}, r.computed = {
            lastStudyText: function() {
                var t = Array.isArray(this.lastStudy.dayList) && this.lastStudy.dayList.length > 0 ? "DAY" + this.lastStudy.dayList[0] + (this.lastStudy.dayList.length > 1 ? "等" : "") : "";
                return (this.lastStudy.name || "") + t + (this.lastStudy.last ? "(上次复习)" : "");
            }
        }, r.methods = {
            filterTap: function() {
                _kcLog2.default.send({
                    pagename: "reviewPage",
                    name: "selectRangeclick",
                    category: "webClick",
                    pt: "mini"
                }), this.showFilterTip && (this.showFilterTip = !1, _storage2.default.set(_constant2.default.KEY_REVIEW_FILTER_TIP_SHOWED, !0)), 
                Array.isArray(this.subjectList) && this.subjectList.length > 0 ? this.$navigate("reviewFilter", {
                    current: this.current,
                    reviewMode: this.lastStudy.filterMode
                }) : wx.showToast({
                    title: "暂无可选择的复习",
                    icon: "none",
                    duration: 3e3
                });
            },
            goReview: function(t) {
                if ("true" === t ? _kcLog2.default.send({
                    pagename: "reviewPage",
                    name: "reviewWrongClick",
                    category: "webClick",
                    pt: "mini"
                }) : _kcLog2.default.send({
                    pagename: "reviewPage",
                    name: "reviewAllClick",
                    category: "webClick",
                    pt: "mini"
                }), !("true" === t && this.totalWrongNum <= 0)) {
                    var e = {
                        sid: this.lastStudy.sid,
                        days: JSON.stringify(this.lastStudy.dayList),
                        onlyFalse: t,
                        type: 2
                    };
                    log.info("复习页去学习页参数", e), this.$navigate("study", e);
                }
            },
            formSubmit: function(t) {
                var e = t.detail.formId;
                _common2.default.collectFormID(e);
            },
            touchStart: function(t) {
                touchStartX = t.touches[0].pageX, touchStartY = t.touches[0].pageY;
            },
            touchMove: function(t) {
                touchMoveX = t.touches[0].pageX, touchMoveY = t.touches[0].pageY, this.moved = !0;
            },
            touchEnd: function(t) {
                var e = touchMoveX - touchStartX, n = touchMoveY - touchStartY;
                e > 0 && n > -2 && n < 2 && (this.moved = !1, this.$navigate("index"));
            },
            pointDetailToggle: function(t) {
                wx.reportAnalytics("reviewindex_20_click_toggle", {
                    pointid: t
                });
                for (var e = 0; e < this.content.length; e++) for (var n = 0; n < this.content[e].points.length; n++) {
                    var r = this.content[e].points[n];
                    if (r.pointId === t) return void (this.pointToggleState[r.index] = !this.pointToggleState[r.index]);
                }
            }
        }, a = n, _possibleConstructorReturn(r, a);
    }
    return _inherits(e, t), _createClass(e, [ {
        key: "onLoad",
        value: function() {
            function t(t) {
                return e.apply(this, arguments);
            }
            var e = _asyncToGenerator(regeneratorRuntime.mark(function t(e) {
                return regeneratorRuntime.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        _kcLog2.default.send({
                            pagename: "reviewPage",
                            name: "reviewPageView",
                            category: "webPageView",
                            pt: "mini"
                        }), this.sid = parseInt(e.sid), this.day = parseInt(e.day), this.width = 750 / wx.getSystemInfoSync().windowWidth;

                      case 4:
                      case "end":
                        return t.stop();
                    }
                }, t, this);
            }));
            return t;
        }()
    }, {
        key: "onShow",
        value: function() {
            function t() {
                return e.apply(this, arguments);
            }
            var e = _asyncToGenerator(regeneratorRuntime.mark(function t() {
                return regeneratorRuntime.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        this.loadReviewData();

                      case 1:
                      case "end":
                        return t.stop();
                    }
                }, t, this);
            }));
            return t;
        }()
    }, {
        key: "loadReviewData",
        value: function() {
            function t() {
                return e.apply(this, arguments);
            }
            var e = _asyncToGenerator(regeneratorRuntime.mark(function t() {
                return regeneratorRuntime.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return this.loadingHide = !1, this.$apply(), t.next = 4, this.getReviewDays();

                      case 4:
                        return t.next = 6, this.getLearnInfo();

                      case 6:
                        return t.next = 8, _storage2.default.get(_constant2.default.KEY_REVIEW_FILTER_TIP_SHOWED);

                      case 8:
                        if (t.t0 = t.sent, t.t0) {
                            t.next = 11;
                            break;
                        }
                        t.t0 = !1;

                      case 11:
                        this.showFilterTip = !t.t0, this.$apply();

                      case 13:
                      case "end":
                        return t.stop();
                    }
                }, t, this);
            }));
            return t;
        }()
    }, {
        key: "getReviewDays",
        value: function() {
            function t() {
                return e.apply(this, arguments);
            }
            var e = _asyncToGenerator(regeneratorRuntime.mark(function t() {
                var e, n, r, a, i, o, s, u, c;
                return regeneratorRuntime.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return t.next = 2, _storage2.default.get(_constant2.default.KEY_REVIEW_LAST_STUDY);

                      case 2:
                        if (t.t0 = t.sent, t.t0) {
                            t.next = 5;
                            break;
                        }
                        t.t0 = {
                            name: "暂无可复习考点",
                            dayList: []
                        };

                      case 5:
                        return e = t.t0, n = Array.isArray(e.dayList) ? e.dayList : [], t.next = 9, _storage2.default.get("token");

                      case 9:
                        if (t.t1 = t.sent, t.t1) {
                            t.next = 12;
                            break;
                        }
                        t.t1 = 0;

                      case 12:
                        return r = t.t1, t.next = 15, _api2.default.getReviewDays({
                            token: r
                        });

                      case 15:
                        a = t.sent, i = -1, o = {}, Array.isArray(a.subjectList) && a.subjectList.length > 0 ? (s = -1, 
                        log.info("data.subjectList", a.subjectList), u = a.subjectList.map(function(t, r) {
                            return Array.isArray(t.dayList) && t.dayList.length > 0 ? (t.sid === e.sid && (i = r), 
                            t.did = !0, s = s >= 0 ? s : r, t.dayList = t.dayList.map(function(a) {
                                return t.sid === e.sid && n.indexOf(a.day) > -1 ? (a.select = !0, t.active = !0) : a.select = !1, 
                                a.accuracy = parseInt((a.allQuestion - a.fnum) / a.allQuestion * 100), a.lastStudy && (0 === Object.keys(o).length && 0 !== a.cumulativeWrongNum ? o = {
                                    name: t.name,
                                    sid: t.sid,
                                    dayList: [ a.day ],
                                    current: r
                                } : o.sid === t.sid && Array.isArray(o.dayList) && 0 !== a.cumulativeWrongNum && o.dayList.push(a.day)), 
                                a;
                            })) : t.did = !1, t;
                        }), c = u.every(function(t) {
                            return !t.active;
                        }), this.subjectList = c ? u.map(function(t) {
                            return t.active = !0, t;
                        }) : u, n.length > 0 ? (e.last = !1, this.lastStudy = e, console.log("localLastStudy", this.lastStudy), 
                        this.current = i >= 0 ? i : s >= 0 ? s : -1) : Object.keys(o).length > 0 ? (o.last = !0, 
                        this.lastStudy = o, this.current = o.current, console.log("remoteLastStudy", this.lastStudy)) : (this.current = s >= 0 ? s : 0, 
                        s > -1 ? (this.lastStudy = {
                            name: a.subjectList[s].name,
                            sid: a.subjectList[s].sid,
                            dayList: [ a.subjectList[s].dayList[0].day ],
                            last: !1
                        }, console.log("otherLastStudy", this.lastStudy)) : (this.lastStudy = {
                            name: "暂无可复习考点",
                            dayList: []
                        }, console.log("暂无可复习考点", this.lastStudy)))) : (this.subjectList = [], this.current = -1, 
                        this.lastStudy = e, console.log("localLastStudy2", this.lastStudy)), this.$apply();

                      case 20:
                      case "end":
                        return t.stop();
                    }
                }, t, this);
            }));
            return t;
        }()
    }, {
        key: "getLearnInfo",
        value: function() {
            function t() {
                return e.apply(this, arguments);
            }
            var e = _asyncToGenerator(regeneratorRuntime.mark(function t() {
                var e, n, r, a = this;
                return regeneratorRuntime.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return this.loadingHide = !1, this.$apply(), t.next = 4, _storage2.default.get("token");

                      case 4:
                        if (t.t0 = t.sent, t.t0) {
                            t.next = 7;
                            break;
                        }
                        t.t0 = 0;

                      case 7:
                        return e = t.t0, n = {
                            subjectId: this.lastStudy.sid,
                            stage: this.lastStudy.dayList.join(","),
                            type: 2,
                            needProposal: !1,
                            token: e
                        }, t.next = 11, _api2.default.learnInfo(n);

                      case 11:
                        r = t.sent, this.rnum = r.rnum || 0, this.fnum = r.fnum || 0, console.log(r.rnum, r.fnum), 
                        this.totalWrongNum = r.cumulativeWrongNum, this.allQuestion = r.allQuestion, this.accNum = parseInt(r.rnum / r.allQuestion * 100), 
                        this.content = r.content, this.hasPointDetail = r.hasPointDetail, this.showCanvas = !0, 
                        this.loadingHide = !0, this.$apply(), this.setEchart(), this.content.forEach(function(t) {
                            t.points.forEach(function(t, e) {
                                t.index = e, a.pointToggleState.push(!1);
                            });
                        });

                      case 25:
                      case "end":
                        return t.stop();
                    }
                }, t, this);
            }));
            return t;
        }()
    }, {
        key: "setEchart",
        value: function() {
            var t = this;
            new _eChart2.default({
                canvasId: "ringCanvas",
                type: "ring",
                extra: {
                    ringWidth: 15 / t.width,
                    pie: {
                        offsetAngle: -90
                    }
                },
                series: [ {
                    name: "错误",
                    data: t.fnum,
                    color: "#FF9C79"
                }, {
                    name: "正确",
                    data: t.rnum,
                    color: "#D2F5E2"
                } ],
                width: 310 / t.width,
                height: 310 / t.width,
                dataLabel: !1,
                legend: !1
            });
        }
    }, {
        key: "handleError",
        value: function() {
            function t(t, n) {
                return e.apply(this, arguments);
            }
            var e = _asyncToGenerator(regeneratorRuntime.mark(function t(e, n) {
                var r = this;
                return regeneratorRuntime.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        console.log(e), this.loadingHide = !0, this.$apply(), this.$invoke("KcErrorModal", "showModal", {
                            err: e,
                            btnMsg: "重新加载",
                            cb: function() {
                                r.loadReviewData();
                            }
                        });

                      case 4:
                      case "end":
                        return t.stop();
                    }
                }, t, this);
            }));
            return t;
        }()
    }, {
        key: "onShareAppMessage",
        value: function() {
            return _common2.default.shareTxt();
        }
    } ]), e;
}(_wepy2.default.page), _applyDecoratedDescriptor(_class.prototype, "loadReviewData", [ _dec ], Object.getOwnPropertyDescriptor(_class.prototype, "loadReviewData"), _class.prototype), 
_class);

Page(require("./../npm/wepy/lib/wepy.js").default.$createPage(Home, "pages/reviewIndex"));