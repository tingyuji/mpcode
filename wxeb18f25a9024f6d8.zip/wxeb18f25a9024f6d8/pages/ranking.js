function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function _asyncToGenerator(e) {
    return function() {
        var r = e.apply(this, arguments);
        return new Promise(function(e, n) {
            function t(a, o) {
                try {
                    var i = r[a](o), c = i.value;
                } catch (e) {
                    return void n(e);
                }
                if (!i.done) return Promise.resolve(c).then(function(e) {
                    t("next", e);
                }, function(e) {
                    t("throw", e);
                });
                e(c);
            }
            return t("next");
        });
    };
}

function _classCallCheck(e, r) {
    if (!(e instanceof r)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(e, r) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !r || "object" != typeof r && "function" != typeof r ? e : r;
}

function _inherits(e, r) {
    if ("function" != typeof r && null !== r) throw new TypeError("Super expression must either be null or a function, not " + typeof r);
    e.prototype = Object.create(r && r.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), r && (Object.setPrototypeOf ? Object.setPrototypeOf(e, r) : e.__proto__ = r);
}

function _applyDecoratedDescriptor(e, r, n, t, a) {
    var o = {};
    return Object.keys(t).forEach(function(e) {
        o[e] = t[e];
    }), o.enumerable = !!o.enumerable, o.configurable = !!o.configurable, ("value" in o || o.initializer) && (o.writable = !0), 
    o = n.slice().reverse().reduce(function(n, t) {
        return t(e, r, n) || n;
    }, o), a && void 0 !== o.initializer && (o.value = o.initializer ? o.initializer.call(a) : void 0, 
    o.initializer = void 0), void 0 === o.initializer && (Object.defineProperty(e, r, o), 
    o = null), o;
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _createClass = function() {
    function e(e, r) {
        for (var n = 0; n < r.length; n++) {
            var t = r[n];
            t.enumerable = t.enumerable || !1, t.configurable = !0, "value" in t && (t.writable = !0), 
            Object.defineProperty(e, t.key, t);
        }
    }
    return function(r, n, t) {
        return n && e(r.prototype, n), t && e(r, t), r;
    };
}(), _dec, _desc, _value, _class, _wepy = require("./../npm/wepy/lib/wepy.js"), _wepy2 = _interopRequireDefault(_wepy), _common = require("./../common/common.js"), _common2 = _interopRequireDefault(_common), _api = require("./../common/api.js"), _api2 = _interopRequireDefault(_api), _decorator = require("./../common/decorator.js"), _KcLoading = require("./../components/KcLoading.js"), _KcLoading2 = _interopRequireDefault(_KcLoading), _KcErrorModal = require("./../components/KcErrorModal.js"), _KcErrorModal2 = _interopRequireDefault(_KcErrorModal), TITLE_RANK = [ "为100%", "为90%-100%", "为80%-90%", "为70%-80%", "为60%-70%", "为60%以下" ], Ranking = (_dec = (0, 
_decorator.trycatch)(), _class = function(e) {
    function r() {
        var e, n, t, a;
        _classCallCheck(this, r);
        for (var o = arguments.length, i = Array(o), c = 0; c < o; c++) i[c] = arguments[c];
        return n = t = _possibleConstructorReturn(this, (e = r.__proto__ || Object.getPrototypeOf(r)).call.apply(e, [ this ].concat(i))), 
        t.config = {
            navigationBarTitleText: "看看排名情况"
        }, t.$repeat = {}, t.$props = {
            KcLoading: {
                "xmlns:v-bind": "",
                "v-bind:loadingHide.sync": "loadingHide"
            }
        }, t.$events = {}, t.components = {
            KcLoading: _KcLoading2.default,
            KcErrorModal: _KcErrorModal2.default
        }, t.mixins = [], t.data = {
            loadingHide: !0,
            rankType: 1,
            avatar: "",
            percent: 0,
            rank: 0,
            sameRankingNum: 0,
            beyondRate: 0,
            ranking: []
        }, t.methods = {}, a = n, _possibleConstructorReturn(t, a);
    }
    return _inherits(r, e), _createClass(r, [ {
        key: "onLoad",
        value: function(e) {
            this.rankType = parseInt(e.rankType) || 1;
            var r = this.$parent.globalData.userInfo;
            this.avatar = r ? r.head : "", this.loadRankData();
        }
    }, {
        key: "loadRankData",
        value: function() {
            function e() {
                return r.apply(this, arguments);
            }
            var r = _asyncToGenerator(regeneratorRuntime.mark(function e() {
                var r, n, t, a, o, i;
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return this.loadingHide = !1, e.next = 3, _api2.default.getRankingDetail({
                            rankingType: this.rankType,
                            graspRate: this.percent
                        });

                      case 3:
                        r = e.sent, n = r.sameRankingNum, t = r.beyondRate, a = r.ranking, o = r.graspRate, 
                        i = r.rank, this.percent = o, this.rank = i, this.sameRankingNum = n, this.beyondRate = t, 
                        this.ranking = this.formatDataRanking(a), this.loadingHide = !0, this.$apply();

                      case 16:
                      case "end":
                        return e.stop();
                    }
                }, e, this);
            }));
            return e;
        }()
    }, {
        key: "formatDataRanking",
        value: function(e) {
            var r = this;
            return Array.isArray(e) ? (e.length > 6 && (e = e.slice(0, 6)), e = e.map(function(e, n) {
                return e.title = (1 === r.rankType ? "掌握率" : "准确率") + TITLE_RANK[n > 5 ? 5 : n], 
                Array.isArray(e.heads) && e.heads.length > 5 && (e.heads = e.heads.slice(0, 5)), 
                e;
            })) : [];
        }
    }, {
        key: "handleError",
        value: function() {
            function e(e, n) {
                return r.apply(this, arguments);
            }
            var r = _asyncToGenerator(regeneratorRuntime.mark(function e(r, n) {
                var t = this;
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        this.loadingHide = !0, this.$apply(), this.$invoke("KcErrorModal", "showModal", {
                            err: r,
                            btnMsg: "重新加载",
                            cb: function() {
                                t.loadRankData();
                            }
                        });

                      case 3:
                      case "end":
                        return e.stop();
                    }
                }, e, this);
            }));
            return e;
        }()
    }, {
        key: "onShareAppMessage",
        value: function(e) {
            return _common2.default.shareTxt();
        }
    } ]), r;
}(_wepy2.default.page), _applyDecoratedDescriptor(_class.prototype, "loadRankData", [ _dec ], Object.getOwnPropertyDescriptor(_class.prototype, "loadRankData"), _class.prototype), 
_class);

Page(require("./../npm/wepy/lib/wepy.js").default.$createPage(Ranking, "pages/ranking"));