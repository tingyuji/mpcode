function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function _asyncToGenerator(e) {
    return function() {
        var t = e.apply(this, arguments);
        return new Promise(function(e, r) {
            function n(o, a) {
                try {
                    var i = t[o](a), s = i.value;
                } catch (e) {
                    return void r(e);
                }
                if (!i.done) return Promise.resolve(s).then(function(e) {
                    n("next", e);
                }, function(e) {
                    n("throw", e);
                });
                e(s);
            }
            return n("next");
        });
    };
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t;
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _createClass = function() {
    function e(e, t) {
        for (var r = 0; r < t.length; r++) {
            var n = t[r];
            n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), 
            Object.defineProperty(e, n.key, n);
        }
    }
    return function(t, r, n) {
        return r && e(t.prototype, r), n && e(t, n), t;
    };
}(), _wepy = require("./../npm/wepy/lib/wepy.js"), _wepy2 = _interopRequireDefault(_wepy), _api = require("./../common/api.js"), _api2 = _interopRequireDefault(_api), _kcLog = require("./../npm/@kc-base/kc-log/dist/kc-log.js"), _kcLog2 = _interopRequireDefault(_kcLog), _storage = require("./../common/storage.js"), _storage2 = _interopRequireDefault(_storage), _common = require("./../common/common.js"), _common2 = _interopRequireDefault(_common), Share = function(e) {
    function t() {
        var e, r, n, o;
        _classCallCheck(this, t);
        for (var a = arguments.length, i = Array(a), s = 0; s < a; s++) i[s] = arguments[s];
        return r = n = _possibleConstructorReturn(this, (e = t.__proto__ || Object.getPrototypeOf(t)).call.apply(e, [ this ].concat(i))), 
        n.config = {
            navigationBarTitleText: "活动详情"
        }, n.data = {
            num: 0,
            done: 3,
            shareNum: 0,
            successShow: !1,
            maskShow: !1,
            errorShow: !1,
            isFirstShare: !0
        }, n.methods = {
            goBack: function() {
                _kcLog2.default.send({
                    pagename: "sharePage",
                    name: "backBtnClick",
                    category: "webClick",
                    pt: "mini"
                }), wx.reLaunch({
                    url: "index"
                });
            }
        }, o = r, _possibleConstructorReturn(n, o);
    }
    return _inherits(t, e), _createClass(t, [ {
        key: "onLoad",
        value: function() {
            function e(e) {
                return t.apply(this, arguments);
            }
            var t = _asyncToGenerator(regeneratorRuntime.mark(function e(t) {
                var r;
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return e.next = 2, _storage2.default.get("isFirstShare");

                      case 2:
                        return this.isFirstShare = e.sent, void 0 === this.isFirstShare && (this.isFirstShare = !0), 
                        e.next = 6, _api2.default.shareHelp();

                      case 6:
                        r = e.sent, this.num = r.num, this.done = r.done, this.$apply();

                      case 10:
                      case "end":
                        return e.stop();
                    }
                }, e, this);
            }));
            return e;
        }()
    }, {
        key: "onShareAppMessage",
        value: function() {
            var e = this;
            return this.shareNum++, _kcLog2.default.send({
                pagename: "sharePage",
                name: "shareBtnClick",
                category: "webClick",
                pt: "mini",
                count: this.shareNum
            }), this.isFirstShare && (setTimeout(function() {
                wx.showToast({
                    title: "请发送至同学群哦~",
                    icon: "none",
                    duration: 3e3
                });
            }, 2e3), this.isFirstShare = !1, _storage2.default.set("isFirstShare", !1)), setTimeout(function() {
                e.postShareHelp();
            }, 2e3), _common2.default.shareTxt();
        }
    }, {
        key: "postShareHelp",
        value: function() {
            function e() {
                return t.apply(this, arguments);
            }
            var t = _asyncToGenerator(regeneratorRuntime.mark(function e() {
                var t;
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return e.prev = 0, e.next = 3, _api2.default.postShareHelp();

                      case 3:
                        t = e.sent, this.num = t.num, this.done = t.done, this.done > 0 && t.num !== t.done && wx.showToast({
                            title: "发送成功",
                            icon: "success",
                            duration: 3e3
                        }), t.num === t.done && (this.successShow = !0, this.maskShow = !0), this.$apply(), 
                        e.next = 16;
                        break;

                      case 11:
                        e.prev = 11, e.t0 = e.catch(0), console.log(e.t0), this.errorShow = !0, this.maskShow = !0;

                      case 16:
                      case "end":
                        return e.stop();
                    }
                }, e, this, [ [ 0, 11 ] ]);
            }));
            return e;
        }()
    }, {
        key: "close",
        value: function() {
            this.errorShow = !1, this.maskShow = !1;
        }
    } ]), t;
}(_wepy2.default.page);

Page(require("./../npm/wepy/lib/wepy.js").default.$createPage(Share, "pages/share"));