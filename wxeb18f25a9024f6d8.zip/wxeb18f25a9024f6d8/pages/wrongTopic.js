function _interopRequireDefault(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

function _asyncToGenerator(t) {
    return function() {
        var e = t.apply(this, arguments);
        return new Promise(function(t, i) {
            function n(r, o) {
                try {
                    var s = e[r](o), a = s.value;
                } catch (t) {
                    return void i(t);
                }
                if (!s.done) return Promise.resolve(a).then(function(t) {
                    n("next", t);
                }, function(t) {
                    n("throw", t);
                });
                t(a);
            }
            return n("next");
        });
    };
}

function _classCallCheck(t, e) {
    if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(t, e) {
    if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !e || "object" != typeof e && "function" != typeof e ? t : e;
}

function _inherits(t, e) {
    if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
    t.prototype = Object.create(e && e.prototype, {
        constructor: {
            value: t,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e);
}

function _applyDecoratedDescriptor(t, e, i, n, r) {
    var o = {};
    return Object.keys(n).forEach(function(t) {
        o[t] = n[t];
    }), o.enumerable = !!o.enumerable, o.configurable = !!o.configurable, ("value" in o || o.initializer) && (o.writable = !0), 
    o = i.slice().reverse().reduce(function(i, n) {
        return n(t, e, i) || i;
    }, o), r && void 0 !== o.initializer && (o.value = o.initializer ? o.initializer.call(r) : void 0, 
    o.initializer = void 0), void 0 === o.initializer && (Object.defineProperty(t, e, o), 
    o = null), o;
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _createClass = function() {
    function t(t, e) {
        for (var i = 0; i < e.length; i++) {
            var n = e[i];
            n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), 
            Object.defineProperty(t, n.key, n);
        }
    }
    return function(e, i, n) {
        return i && t(e.prototype, i), n && t(e, n), e;
    };
}(), _dec, _desc, _value, _class, _wepy = require("./../npm/wepy/lib/wepy.js"), _wepy2 = _interopRequireDefault(_wepy), _api = require("./../common/api.js"), _api2 = _interopRequireDefault(_api), _common = require("./../common/common.js"), _common2 = _interopRequireDefault(_common), _storage = require("./../common/storage.js"), _storage2 = _interopRequireDefault(_storage), _decorator = require("./../common/decorator.js"), _KcLoading = require("./../components/KcLoading.js"), _KcLoading2 = _interopRequireDefault(_KcLoading), _KcErrorModal = require("./../components/KcErrorModal.js"), _KcErrorModal2 = _interopRequireDefault(_KcErrorModal), wrongTopic = (_dec = (0, 
_decorator.trycatch)(), _class = function(t) {
    function e() {
        var t, i, n, r;
        _classCallCheck(this, e);
        for (var o = arguments.length, s = Array(o), a = 0; a < o; a++) s[a] = arguments[a];
        return i = n = _possibleConstructorReturn(this, (t = e.__proto__ || Object.getPrototypeOf(e)).call.apply(t, [ this ].concat(s))), 
        n.config = {
            navigationBarTitleText: "正在复习错过的题",
            navigationBarTextStyle: "black",
            navigationBarBackgroundColor: "#F9FAFC"
        }, n.data = {
            loadingHide: !0,
            tipsShow: !1,
            index: 0,
            btn: "下一题",
            sid: "",
            days: [],
            type: "",
            topicNum: "",
            status: 0,
            handTipShowTime: 0,
            onlyFalse: !1,
            handTips: !0,
            optionStatus: [ 0, 0, 0, 0 ],
            currentAnswerStatus: 0,
            hasPointDetail: 0,
            topicList: [],
            answerList: [],
            endAlertShow: !1,
            accuracyRate: 0,
            changeValue: 0,
            eggShow: !1,
            markTips: !1,
            longtips: !1,
            needMarkTips: !0,
            needLongTips: !0,
            maskShow: !1,
            submitStatus: 0,
            wrongTopic: []
        }, n.$repeat = {}, n.$props = {
            KcLoading: {
                "xmlns:v-bind": "",
                "v-bind:loadingHide.sync": "loadingHide"
            }
        }, n.$events = {}, n.components = {
            KcLoading: _KcLoading2.default,
            KcErrorModal: _KcErrorModal2.default
        }, n.mixins = [], n.computed = {
            percent: function() {
                return parseInt((this.index + 1) / this.topicNum * 100);
            },
            nowTopic: function() {
                return this.topicList[this.index];
            },
            canClick: function() {
                if (1 === this.status) {
                    for (var t = 0, e = 0, i = this.optionStatus.length; e < i; e++) 0 !== this.optionStatus[e] && t++;
                    return 0 !== t && (1 !== t || !this.nowTopic.isCheckbox);
                }
                return !0;
            },
            yourAnswer: function() {
                for (var t = "", e = this.optionStatus, i = 0; i < 4; i++) if (1 === e[i] || 2 === e[i] || 3 === e[i]) switch (i) {
                  case 0:
                    t += "A";
                    break;

                  case 1:
                    t += "B";
                    break;

                  case 2:
                    t += "C";
                    break;

                  case 3:
                    t += "D";
                }
                return t;
            },
            rightAnswer: function() {
                var t = "";
                if (this.nowTopic) for (var e = this.nowTopic.rightOption, i = 0; i < e.length; i++) switch (e[i] - 1) {
                  case 0:
                    t += "A";
                    break;

                  case 1:
                    t += "B";
                    break;

                  case 2:
                    t += "C";
                    break;

                  case 3:
                    t += "D";
                }
                return t;
            }
        }, n.methods = {
            hideMask: function() {
                this.maskShow = !1, this.longtips = !1, this.markTips = !1;
            },
            formSubmit: function(t) {
                var e = t.detail.formId;
                _common2.default.collectFormID(e);
            },
            markCancel: function() {
                this.markTips = !1, this.maskShow = !1, this.$apply();
            },
            longCancel: function() {
                this.longtips = !1, this.maskShow = !1, this.$apply();
            },
            goReport: function() {
                wx.redirectTo({
                    url: "report?sid=" + this.sid + "&days=" + JSON.stringify(this.days) + "&type=" + this.type + "&onlyFalse=" + this.onlyFalse
                });
            },
            removeWrong: function() {
                this.answerList[this.index] = 3;
            },
            unremoveWrong: function() {
                this.answerList[this.index] = this.currentAnswerStatus;
            },
            mark: function() {
                1 === this.type && wx.reportAnalytics("study_20_click_mark", {}), this.needMarkTips && (this.markTips = !0, 
                this.maskShow = !0, _storage2.default.set("needMarkTips", !1), this.needMarkTips = !1), 
                this.answerList[this.index] = 2;
            },
            unmark: function() {
                this.answerList[this.index] = 1;
            },
            mainTap: function() {
                function t() {
                    return e.apply(this, arguments);
                }
                var e = _asyncToGenerator(regeneratorRuntime.mark(function t() {
                    return regeneratorRuntime.wrap(function(t) {
                        for (;;) switch (t.prev = t.next) {
                          case 0:
                            this.index === this.topicList.length - 1 && wx.redirectTo({
                                url: "report?sid=" + this.sid + "&days=" + JSON.stringify(this.days) + "&type=" + this.type + "&onlyFalse=" + this.onlyFalse
                            }), this.index++, this.optionStatus = this.wrongTopic[this.index].optionStatus, 
                            this.index === this.topicList.length - 1 ? this.btn = "回报告页" : this.btn = "下一题";

                          case 4:
                          case "end":
                            return t.stop();
                        }
                    }, t, this);
                }));
                return t;
            }(),
            tapOption: function(t) {
                1 === this.status && (this.nowTopic.isCheckbox ? 1 === this.optionStatus[t] ? this.optionStatus[t] = 0 : this.optionStatus[t] = 1 : (this.optionStatus = [ 0, 0, 0, 0 ], 
                this.optionStatus[t] = 1));
            },
            touchEnd: function(t) {
                this.status = 1, this.handTips = !1, this.handTipShowTime < 10 && this.handTipShowTime++, 
                _storage2.default.set("handTipShowTime", this.handTipShowTime);
            },
            longpress: function() {
                this.eggShow = !0, this.needLongTips && (this.maskShow = !0, this.longtips = !0, 
                _storage2.default.set("needLongTips", !1), this.needLongTips = !1), wx.reportAnalytics("study_19_longpress", {});
            }
        }, r = i, _possibleConstructorReturn(n, r);
    }
    return _inherits(e, t), _createClass(e, [ {
        key: "checkAnswer",
        value: function() {
            for (var t = 1, e = 0; e < 4; e++) {
                var i = this.nowTopic.rightOption.indexOf(e + 1) >= 0;
                1 === this.optionStatus[e] ? i ? this.optionStatus[e] = 3 : (this.optionStatus[e] = 2, 
                t = 0) : i && (this.nowTopic.isCheckbox ? this.optionStatus[e] = 4 : this.optionStatus[e] = 5, 
                t = 0);
            }
            this.currentAnswerStatus = t, this.answerList[this.index] = t;
        }
    }, {
        key: "onLoad",
        value: function() {
            function t(t) {
                return e.apply(this, arguments);
            }
            var e = _asyncToGenerator(regeneratorRuntime.mark(function t(e) {
                return regeneratorRuntime.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return this.status = 2, this.sid = Number(e.sid), this.days = e.days ? JSON.parse(e.days) : [], 
                        this.type = Number(e.type), this.onlyFalse = JSON.parse(e.onlyFalse), t.next = 7, 
                        this.getStudyData();

                      case 7:
                        this.$apply();

                      case 8:
                      case "end":
                        return t.stop();
                    }
                }, t, this);
            }));
            return t;
        }()
    }, {
        key: "getStudyData",
        value: function() {
            function t() {
                return e.apply(this, arguments);
            }
            var e = _asyncToGenerator(regeneratorRuntime.mark(function t() {
                var e, i = this;
                return regeneratorRuntime.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return this.loadingHide = !1, this.$apply(), t.next = 4, _api2.default.getDayInfo({
                            subjectId: this.sid,
                            stage: this.days.join(","),
                            type: this.type,
                            onlyFalse: this.onlyFalse
                        });

                      case 4:
                        return e = t.sent, t.next = 7, _storage2.default.get("wrongTopic");

                      case 7:
                        this.wrongTopic = t.sent, this.wrongTopic.forEach(function(t) {
                            i.topicList.push(e.questions[t.index]);
                        }), this.topicNum = this.wrongTopic.length, this.optionStatus = this.wrongTopic[0].optionStatus, 
                        this.hasPointDetail = e.hasPointDetail, this.loadingHide = !0, this.$apply();

                      case 14:
                      case "end":
                        return t.stop();
                    }
                }, t, this);
            }));
            return t;
        }()
    }, {
        key: "handleError",
        value: function() {
            function t(t, i) {
                return e.apply(this, arguments);
            }
            var e = _asyncToGenerator(regeneratorRuntime.mark(function t(e, i) {
                var n = this;
                return regeneratorRuntime.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        this.loadingHide = !0, this.$apply(), this.$invoke("KcErrorModal", "showModal", {
                            err: e,
                            btnMsg: "重新加载",
                            cb: function() {
                                n.getStudyData();
                            }
                        });

                      case 3:
                      case "end":
                        return t.stop();
                    }
                }, t, this);
            }));
            return t;
        }()
    } ]), e;
}(_wepy2.default.page), _applyDecoratedDescriptor(_class.prototype, "getStudyData", [ _dec ], Object.getOwnPropertyDescriptor(_class.prototype, "getStudyData"), _class.prototype), 
_class);

Page(require("./../npm/wepy/lib/wepy.js").default.$createPage(wrongTopic, "pages/wrongTopic"));