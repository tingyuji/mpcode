function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function _asyncToGenerator(e) {
    return function() {
        var t = e.apply(this, arguments);
        return new Promise(function(e, n) {
            function r(o, a) {
                try {
                    var i = t[o](a), s = i.value;
                } catch (e) {
                    return void n(e);
                }
                if (!i.done) return Promise.resolve(s).then(function(e) {
                    r("next", e);
                }, function(e) {
                    r("throw", e);
                });
                e(s);
            }
            return r("next");
        });
    };
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t;
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _createClass = function() {
    function e(e, t) {
        for (var n = 0; n < t.length; n++) {
            var r = t[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), 
            Object.defineProperty(e, r.key, r);
        }
    }
    return function(t, n, r) {
        return n && e(t.prototype, n), r && e(t, r), t;
    };
}(), _wepy = require("./npm/wepy/lib/wepy.js"), _wepy2 = _interopRequireDefault(_wepy);

require("./npm/wepy-async-function/index.js");

var _default = function(e) {
    function t() {
        _classCallCheck(this, t);
        var e = _possibleConstructorReturn(this, (t.__proto__ || Object.getPrototypeOf(t)).call(this));
        return e.config = {
            pages: [ "pages/index", "pages/activate", "pages/upValue", "pages/learnIndex", "pages/report", "pages/reviewIndex", "pages/reviewFilter", "pages/points", "pages/web", "pages/ranking", "pages/study", "pages/upValueList", "pages/studyData", "pages/wrongTopic", "pages/share" ],
            subPackages: [ {
                root: "pages/subPages",
                pages: [ "vip" ]
            } ],
            window: {
                backgroundTextStyle: "light",
                navigationBarBackgroundColor: "#fff",
                navigationBarTitleText: "WeChat",
                navigationBarTextStyle: "black",
                backgroundColor: "#FFFFFF",
                backgroundColorTop: "#FFFFFF",
                backgroundColorBottom: "#FFFFFF"
            },
            navigateToMiniProgramAppIdList: [ "wxfa0c84e2ddfb8989", "wx8abaf00ee8c3202e" ]
        }, e.globalData = {
            sence: null,
            userInfo: null,
            appid: "",
            appSecret: "",
            openId: "",
            hasPay: !1
        }, e.use("promisify"), e;
    }
    return _inherits(t, e), _createClass(t, [ {
        key: "onShow",
        value: function(e) {
            this.globalData.scene = e.scene;
        }
    } ]), _createClass(t, [ {
        key: "onLaunch",
        value: function() {
            if (wx.setStorageSync("__KC_LOG_H", JSON.parse(_wepy2.default.$appConfig.__KC_LOG_H)), 
            wx.setStorageSync("bdId", "zhengzhi1000"), wx.canIUse("getUpdateManager")) {
                var e = wx.getUpdateManager();
                e.onUpdateReady(function() {
                    wx.showModal({
                        title: "更新提示",
                        content: "新版本已经准备好，是否重启应用",
                        showCancel: !1,
                        confirmText: "确定",
                        success: function() {
                            function t(e) {
                                return n.apply(this, arguments);
                            }
                            var n = _asyncToGenerator(regeneratorRuntime.mark(function t(n) {
                                return regeneratorRuntime.wrap(function(t) {
                                    for (;;) switch (t.prev = t.next) {
                                      case 0:
                                        n.confirm && e.applyUpdate();

                                      case 1:
                                      case "end":
                                        return t.stop();
                                    }
                                }, t, this);
                            }));
                            return t;
                        }()
                    });
                });
            }
            console.log("=========app onLaunch========");
        }
    } ]), t;
}(_wepy2.default.app);

App(require("./npm/wepy/lib/wepy.js").default.$createApp(_default, {
    __KC_LOG_H: '"https://dotlog.kaochong.com"',
    noPromiseAPI: [ "createSelectorQuery" ],
    rootURL: "https://politics1000.kaochong.com/politics1000"
}));