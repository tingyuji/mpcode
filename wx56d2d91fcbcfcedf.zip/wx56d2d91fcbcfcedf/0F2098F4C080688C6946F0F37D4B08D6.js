var e = function(e) {
    return (e = e.toString())[1] ? e : "0".concat(e);
};

module.exports = {
    formatTime: function(t) {
        var o = t.getFullYear(), n = t.getMonth() + 1, r = t.getDate(), a = t.getHours(), g = t.getMinutes(), c = t.getSeconds();
        return "".concat([ o, n, r ].map(e).join("/"), " ").concat([ a, g, c ].map(e).join(":"));
    },
    getNowDate: function() {
        var e = new Date(), t = e.getFullYear(), o = e.getMonth() + 1, n = e.getDate(), r = e.getHours(), a = e.getMinutes(), g = e.getSeconds();
        e.getDay();
        return o >= 1 && o <= 9 && (o = "0" + o), n >= 0 && n <= 9 && (n = "0" + n), r >= 0 && r <= 9 && (r = "0" + r), 
        a >= 0 && a <= 9 && (a = "0" + a), g >= 0 && g <= 9 && (g = "0" + g), t + "-" + o + "-" + n;
    },
    judgeDate: function(e, t) {
        var o = new Date(e.replace(/-/g, "/")), n = new Date(t.replace(/-/g, "/")), r = new Date(), a = r.getTime() - o.getTime(), g = Math.floor(a / 864e5), c = n.getTime() - r.getTime();
        return Math.floor(c / 864e5) < 0 ? 2 : g < 0 ? 3 : 1;
    },
    playAudio: function(e) {
        if (wx.getStorageSync("music")) {
            var t = wx.createInnerAudioContext();
            t.autoplay = !0, t.src = e, t.onError(function(e) {
                console.log(e.errMsg), console.log(e.errCode);
            });
        }
    }
};