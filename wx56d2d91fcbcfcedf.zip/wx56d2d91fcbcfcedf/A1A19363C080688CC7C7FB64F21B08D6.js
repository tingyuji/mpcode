var t, i, e = require("@babel/runtime/helpers/typeof.js"), o = require("F55DF603C080688C933B9E04DE1B08D6.js"), n = "https://treasure.mambaxin.com/routine/", a = {};

function u(e, o, a, u) {
    a || (a = {}), i && !a.openId && (a.openId = i), a.timeStamp || (a.timeStamp = new Date().getTime()), 
    a.sign = s(a), t(n + e, o, a, function(t, i) {
        r(u) && (t ? u(1101, t) : u(i.code, i.data || i.msg));
    });
}

function s(t) {
    var i = [];
    return Object.keys(t).sort().forEach(function(o) {
        "object" != e(t[o]) && i.push(o + "=" + t[o]);
    }), i.push("key=prFrhNpQRNbcwO3xtAviM3ebZQe46z0V"), (0, o.utf8MD5)(i.join("&")).toUpperCase();
}

function r(t) {
    return t && "function" == typeof t;
}

function p(t, i) {
    if (!t) return i;
    var e = a[t];
    if (null == e || null == e || "" === e) {
        try {
            e = wx.getStorageSync(t);
        } catch (t) {}
        if (null == e || null == e || "" === e) return i;
        a[t] = e;
    }
    return e;
}

module.exports.login = {
    login: function(t, i) {
        u("login/login", "post", {
            code: t
        }, i);
    },
    save: function(t, i) {
        u("login/save", "post", {
            userInfo: t
        }, i);
    },
    index: function(t) {
        u("login/index", "post", {}, t);
    }
}, module.exports.api = {
    bannerList: function(t) {
        u("auth_api/banner_list", "post", {}, t);
    },
    getConfigValue: function(t, i) {
        u("auth_api/get_config_value", "post", {
            key: t
        }, i);
    },
    getActivityList: function(t, i, e) {
        u("auth_api/activity_list", "post", {
            page: t,
            limit: i
        }, e);
    },
    firstShowCategory: function(t) {
        u("auth_api/first_show_category", "post", {}, t);
    },
    firstCategoryList: function(t) {
        u("auth_api/first_category_list", "post", {}, t);
    },
    thirdCategoryList: function(t, i, e) {
        u("auth_api/third_category_list", "post", {
            second_category_id: t,
            keyword: i
        }, e);
    },
    categoryList: function(t, i) {
        u("auth_api/category_list", "post", {
            third_category_id: t
        }, i);
    },
    getQuestionList: function(t, i) {
        u("auth_api/get_question_list", "post", {
            id: t
        }, i);
    },
    getQuestionId: function(t, i) {
        u("auth_api/get_question_id", "post", {
            id: t
        }, i);
    },
    getCategoryDetail: function(t, i) {
        u("auth_api/category_detail", "post", {
            id: t
        }, i);
    },
    getEarmarkList: function(t, i) {
        u("auth_api/get_earmark_list", "post", {
            cid: t
        }, i);
    },
    getTypeList: function(t, i) {
        u("auth_api/get_type_list", "post", {
            cid: t
        }, i);
    },
    getEarmarkQuestionId: function(t, i, e, o) {
        u("auth_api/get_earmark_question_id", "post", {
            id: t,
            type: i,
            category: e
        }, o);
    },
    getSearchQuestion: function(t, i, e, o, n) {
        u("auth_api/search_question", "post", {
            id: t,
            keyword: i,
            page: e,
            limit: o
        }, n);
    },
    getSignConfig: function(t) {
        u("auth_api/get_sign_config", "post", {}, t);
    },
    getUserSign: function(t, i) {
        u("auth_api/get_user_sign", "post", {
            uid: t
        }, i);
    },
    userSign: function(t, i) {
        u("auth_api/user_sign", "post", {
            uid: t
        }, i);
    },
    getSignList: function(t, i) {
        u("auth_api/get_sign_list", "post", {
            params: t
        }, i);
    },
    getSignMonthList: function(t, i) {
        u("auth_api/get_sign_month_list", "post", {
            params: t
        }, i);
    },
    saveExamRecord: function(t, i) {
        u("auth_api/save_exam_record", "post", {
            params: t
        }, i);
    },
    getRecordDetail: function(t, i) {
        u("auth_api/get_record_detail", "post", {
            id: t
        }, i);
    },
    getUserRecord: function(t, i, e, o) {
        u("auth_api/get_user_record", "post", {
            page: t,
            limit: i,
            uid: e
        }, o);
    },
    getArticleCategory: function(t) {
        u("auth_api/get_article_category", "get", {}, t);
    },
    getArticleList: function(t, i, e, o, n) {
        u("auth_api/get_article_list", "get", {
            category: t,
            sort: i,
            page: e,
            limit: o
        }, n);
    },
    getArticleDetail: function(t, i) {
        u("auth_api/get_article_detail", "get", {
            id: t
        }, i);
    },
    addArticleRead: function(t, i) {
        u("auth_api/add_article_read", "get", {
            id: t
        }, i);
    },
    getUserIntegral: function(t, i, e, o) {
        u("auth_api/get_user_integral_list", "post", {
            page: t,
            limit: i,
            uid: e
        }, o);
    },
    oftenWrongQuestionId: function(t, i) {
        u("auth_api/often_wrong_question_id", "post", {
            category: t
        }, i);
    },
    saveFeedback: function(t, i) {
        u("auth_api/save_feedback", "post", {
            params: t
        }, i);
    },
    saveUserInfo: function(t, i) {
        u("auth_api/save_userinfo", "post", {
            params: t
        }, i);
    },
    saveAgainUserInfo: function(t, i) {
        u("auth_api/save_again_userinfo", "post", {
            params: t
        }, i);
    },
    getRankList: function(t, i) {
        u("auth_api/get_rank_list", "post", {
            params: t
        }, i);
    },
    isUseCode: function(t, i, e) {
        u("auth_api/is_use_code", "post", {
            category: t,
            uid: i
        }, e);
    },
    activate: function(t, i, e, o) {
        u("auth_api/activate", "post", {
            category: t,
            uid: i,
            code: e
        }, o);
    },
    addVideoPoints: function(t, i) {
        u("auth_api/add_video_points", "post", {
            uid: t
        }, i);
    },
    exchangeCode: function(t, i) {
        u("auth_api/exchange_code", "post", {
            uid: t
        }, i);
    },
    userCodeList: function(t, i) {
        u("auth_api/user_code_list", "post", {
            uid: t
        }, i);
    }
}, module.exports.isLogin = function() {
    return i || !1;
}, module.exports.setUid = function(t) {
    t && (i = t);
}, module.exports.getUserId = function() {
    return i;
}, module.exports.getHost = function() {
    return n;
}, module.exports.init = function(e) {
    if (r(e)) return t = e, void (i = p("openid", ""));
    throw "Wrong type of init params";
}, module.exports.set = function(t, i) {
    t && (null == i || null == i || "" === i ? (wx.removeStorageSync(t), delete a[t]) : (wx.setStorageSync(t, i), 
    a[t] = i));
}, module.exports.get = p, module.exports.getSign = s;