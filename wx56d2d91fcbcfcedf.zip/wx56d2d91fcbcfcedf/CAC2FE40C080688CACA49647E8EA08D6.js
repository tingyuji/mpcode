Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("3FC09116C080688C59A6F911112A08D6.js"), t = {
    type: "text",
    mask: !1,
    message: "",
    show: !0,
    zIndex: 1e3,
    duration: 2e3,
    position: "middle",
    forbidClick: !1,
    loadingType: "circular",
    selector: "#van-toast"
}, n = [], o = Object.assign({}, t);

function s(t) {
    return (0, e.isObj)(t) ? t : {
        message: t
    };
}

function r(e) {
    var t, r = Object.assign(Object.assign({}, o), s(e)), a = (r.context || (t = getCurrentPages())[t.length - 1]).selectComponent(r.selector);
    if (a) return delete r.context, delete r.selector, a.clear = function() {
        a.setData({
            show: !1
        }), r.onClose && r.onClose();
    }, n.push(a), a.setData(r), clearTimeout(a.timer), null != r.duration && r.duration > 0 && (a.timer = setTimeout(function() {
        a.clear(), n = n.filter(function(e) {
            return e !== a;
        });
    }, r.duration)), a;
    console.warn("未找到 van-toast 节点，请确认 selector 及 context 是否正确");
}

var a = function(e) {
    return function(t) {
        return r(Object.assign({
            type: e
        }, s(t)));
    };
};

r.loading = a("loading"), r.success = a("success"), r.fail = a("fail"), r.clear = function() {
    n.forEach(function(e) {
        e.clear();
    }), n = [];
}, r.setDefaultOptions = function(e) {
    Object.assign(o, e);
}, r.resetDefaultOptions = function() {
    o = Object.assign({}, t);
};

var i = r;

exports.default = i;