var e = require("A1A19363C080688CC7C7FB64F21B08D6.js");

App({
    onLaunch: function() {
        this.initAPI(), wx.Apis = e, wx.Apis.api.getConfigValue("notice", function(e, t) {
            wx.setStorageSync("notice", t.value);
        }), wx.Apis.api.getConfigValue("isWrite", function(e, t) {
            wx.setStorageSync("isWrite", t.value);
        }), wx.Apis.api.getConfigValue("checkUser", function(e, t) {
            wx.setStorageSync("checkUser", t.value);
        }), wx.Apis.api.getConfigValue("useLearn", function(e, t) {
            wx.setStorageSync("useLearn", t.value);
        });
        var t = wx.getStorageSync("openid");
        "" == t || null == t ? (wx.showLoading({
            title: ""
        }), wx.login({
            success: function(e) {
                e.code && (console.log(e.code), wx.Apis.login.login(e.code, function(e, t) {
                    console.log(t), wx.Apis.setUid(t.openid), wx.Apis.set("openid", t.openid), wx.setStorageSync("userInfo", t), 
                    wx.hideLoading({
                        success: function(e) {}
                    });
                }));
            },
            fail: function() {
                wx.hideLoading({
                    success: function(e) {}
                });
            }
        })) : e.login.index(function(t, n) {
            console.log(n), e.setUid(n.openid), wx.setStorageSync("userInfo", n);
        });
    },
    globalData: {
        userInfo: null,
        mainActiveIndex: 0,
        bgmUrl: "https://mamba-blog-images.oss-cn-shanghai.aliyuncs.com/5c8a08dc4956424741.mp3"
    },
    initAPI: function() {
        e.init(function(e, t, n, i) {
            wx.request({
                url: e,
                method: t,
                data: n,
                header: {
                    "Content-Type": "application/json"
                },
                success: function(e) {
                    try {
                        wx.stopPullDownRefresh();
                    } catch (e) {}
                    i(200 == e.statusCode ? null : e, e.data);
                },
                fail: function(e) {
                    try {
                        wx.stopPullDownRefresh();
                    } catch (e) {}
                    i(e);
                }
            });
        });
    },
    saveInfo: function(e, t, n) {
        wx.getStorage({
            key: e + "" + t,
            success: function(e) {
                var t = e.data;
                getApp().info = !1;
                for (var i = 0; i < t.length; i++) if (t[i][Object.keys(t[i]).toString()].indexOf(n) > -1) return console.log(t[i][Object.keys(t[i]).toString()].indexOf(n) > -1), 
                void (getApp().info = !0);
            }
        });
    },
    setIdsStroage: function(e, t, n, i) {
        wx.getStorage({
            key: e + "" + t,
            success: function(o) {
                for (var s = o.data, c = [], a = 0; a < s.length; a++) c.push(Object.keys(s[a]).toString());
                if (console.log(c), c.indexOf(n.toString()) > -1) for (a = 0; a < s.length; a++) Object.keys(s[a]).indexOf(n) > -1 && -1 == s[a][n].indexOf(i) && s[a][n].push(i); else {
                    var u = {};
                    u[n] = [], u[n].push(i), s.push(u);
                }
                wx.setStorage({
                    key: e + "" + t,
                    data: s
                });
            },
            fail: function() {
                var o = [], s = {};
                s[n] = [], s[n].push(i), o.push(s), wx.setStorage({
                    key: e + "" + t,
                    data: o
                });
            }
        });
    },
    removeids: function(e, t, n) {
        wx.getStorage({
            key: e + "" + t,
            success: function(i) {
                for (var o = i.data, s = 0; s < o.length; s++) if (o[s][Object.keys(o[s]).toString()].indexOf(n) > -1) {
                    var c = o[s][Object.keys(o[s]).toString()].indexOf(n);
                    o[s][Object.keys(o[s]).toString()].splice(c, 1), 0 == o[s][Object.keys(o[s]).toString()].length && o.splice(s, 1);
                }
                wx.setStorage({
                    key: e + "" + t,
                    data: o
                });
            }
        });
    }
});