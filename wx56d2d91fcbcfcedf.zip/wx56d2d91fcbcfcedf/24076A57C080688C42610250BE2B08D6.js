function t(t) {
    var i = wx.getStorageSync("question_" + t);
    n.questionId = wx.getStorageSync("question_id_" + t);
    for (var o = i, s = {}, r = 0; r < o.length; r++) {
        var u = o[r];
        s[u.id] = u;
    }
    e.question = s;
}

var e = {
    question: {}
}, n = {
    questionId: []
}, i = require("6D349726C080688C0B52FF216E3B08D6.js");

module.exports = {
    initQuestions: t,
    questions: e,
    questionIds: n,
    initAllQuestionFromStorage: function(e) {
        t(e);
    },
    getQuestionsByIds: function(t) {
        var n, o = e.question, s = [];
        n = i.isArray(t) ? t : t.split(",");
        for (var r = 0; r < n.length; r++) {
            var u = n[r];
            o[u] && s.push(i.clone(o[u]));
        }
        return s;
    }
};