require("../../A1A19363C080688CC7C7FB64F21B08D6.js");

Page({
    data: {
        avatarUrl: "/images/header.jpg",
        nickName: "",
        check_template_id: ""
    },
    onLoad: function(t) {
        var e = this;
        this.setData({
            isWrite: wx.getStorageSync("isWrite")
        }), "true" == this.data.isWrite && wx.Apis.api.getConfigValue("check_template_id", function(t, a) {
            e.setData({
                check_template_id: a.value
            }), wx.hideLoading({});
        });
    },
    getNickName: function(t) {
        this.setData({
            nickName: t.detail.value
        }), console.log(t);
    },
    getRealName: function(t) {
        this.setData({
            realname: t.detail.value
        });
    },
    getPhone: function(t) {
        this.setData({
            phone: t.detail.value
        });
    },
    onChooseAvatar: function(t) {
        var e = this, a = (t.detail.avatarUrl, {});
        a.openId = wx.getStorageSync("openid"), a.timeStamp = new Date().getTime(), a.sign = wx.Apis.getSign(a), 
        console.log(t.detail), wx.showLoading({
            title: "上传中"
        }), wx.uploadFile({
            url: wx.Apis.getHost() + "auth_api/upload_avatar",
            filePath: t.detail.avatarUrl,
            name: "file",
            formData: a,
            success: function(t) {
                200 == (t = JSON.parse(t.data)).code ? (e.setData({
                    avatarUrl: t.data
                }), wx.hideLoading({
                    success: function(t) {}
                })) : (wx.hideLoading({
                    success: function(t) {}
                }), wx.showToast({
                    icon: "error",
                    title: t.msg
                }));
            },
            fail: function() {
                wx.hideLoading({
                    success: function(t) {}
                }), wx.showToast({
                    icon: "error",
                    title: "上传失败"
                });
            }
        });
    },
    saveUserInfo: function() {
        if ("/images/header.jpg" == this.data.avatarUrl || "" == this.data.nickName) return wx.showToast({
            icon: "loading",
            title: "请完善信息"
        }), !1;
        if ("true" == this.data.isWrite) {
            if ("" == this.data.realname || "" == this.data.phone) return wx.showToast({
                icon: "loading",
                title: "请完善信息"
            }), !1;
            if (!/^1(3|4|5|6|7|8|9)\d{9}$/.test(this.data.phone)) return wx.showToast({
                icon: "loading",
                title: "手机号码有误"
            }), !1;
        }
        var t = {
            openid: wx.getStorageSync("openid"),
            avatarUrl: this.data.avatarUrl,
            nickName: this.data.nickName
        };
        if ("true" == this.data.isWrite) {
            t.realname = this.data.realname, t.phone = this.data.phone;
            var e = [];
            e.push(this.data.check_template_id), wx.requestSubscribeMessage({
                tmplIds: e,
                success: function(t) {
                    console.log(t);
                },
                complete: function() {
                    wx.showLoading({
                        title: "保存中"
                    });
                    var e = wx.getStorageSync("checkUser");
                    wx.Apis.api.saveUserInfo(t, function(t, a) {
                        if (wx.hideLoading({}), 200 == t) {
                            if ("true" == e) {
                                a.status = 1;
                                var i = "个人信息已提交，我们会尽快审核！";
                            } else {
                                a.status = 2;
                                i = "个人信息已通过审核！";
                            }
                            wx.setStorageSync("userInfo", a), wx.showModal({
                                title: "提交成功",
                                content: i,
                                showCancel: !1,
                                confirmText: "关闭",
                                confirmColor: "#46C6BA",
                                success: function(t) {
                                    wx.navigateBack();
                                }
                            });
                        } else setTimeout(function() {
                            wx.hideLoading({}), wx.showToast({
                                title: "提交失败",
                                icon: "none",
                                duration: 1500
                            });
                        }, 500);
                    });
                }
            });
        } else this.submitUserInfo(t);
    },
    submitUserInfo: function(t) {
        wx.Apis.login.save(t, function(t, e) {
            200 == t ? (wx.setStorageSync("userInfo", e), setTimeout(function() {
                wx.hideLoading({}), wx.showToast({
                    title: "提交成功",
                    icon: "none",
                    duration: 1500
                }), wx.navigateBack({
                    delta: 1
                });
            }, 500)) : setTimeout(function() {
                wx.hideLoading({}), wx.showToast({
                    title: "提交失败",
                    icon: "none",
                    duration: 1500
                });
            }, 500);
        });
    },
    onShareAppMessage: function() {
        return {
            title: "智慧考题宝，考试助手 ！",
            path: "pages/index/index",
            imageUrl: "/images/share.png"
        };
    }
});