Page({
    data: {
        arrCategory: [],
        arrSort: [ {
            text: "默认排序",
            value: "default"
        }, {
            text: "时间排序",
            value: "add_time"
        }, {
            text: "阅读排序",
            value: "read"
        } ],
        category: 0,
        sort: "default",
        page: 1,
        limit: 10,
        nodata: !0,
        articleList: [],
        moreData: !0
    },
    onLoad: function(t) {
        var a = this;
        wx.Apis.api.getArticleCategory(function(t, i) {
            i.unshift({
                text: "全部分类",
                value: 0
            }), a.setData({
                arrCategory: i
            });
        }), this.getArticle(this.data.category, this.data.sort, this.data.page, this.data.limit);
    },
    getArticle: function(t, a, i, e) {
        var o = this;
        wx.showLoading({
            title: "加载中",
            mask: !0,
            icon: "loading"
        }), wx.Apis.api.getArticleList(t, a, i, e, function(t, a) {
            var i = o.data.articleList, e = o.data.page;
            console.log(a), a.length ? (a.forEach(function(t) {
                i.push(t);
            }), o.setData({
                articleList: i,
                page: e + 1,
                nodata: !1
            })) : o.setData({
                articleList: i,
                moreData: !1
            }), setTimeout(function() {
                wx.hideLoading({
                    success: function(t) {}
                });
            }, 1e3);
        });
    },
    changeCategory: function(t) {
        this.setData({
            category: t.detail,
            articleList: [],
            moreData: !0,
            nodata: !0,
            page: 1
        }), this.getArticle(this.data.category, this.data.sort, this.data.page, this.data.limit);
    },
    changeSort: function(t) {
        this.setData({
            sort: t.detail,
            articleList: [],
            moreData: !0,
            nodata: !0,
            page: 1
        }), this.getArticle(this.data.category, this.data.sort, this.data.page, this.data.limit);
    },
    detail: function(t) {
        var a = t.currentTarget.dataset.id;
        wx.navigateTo({
            url: "/pages/articleDetail/articleDetail?id=" + a
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {
        this.data.moreData && this.getArticle(this.data.category, this.data.sort, this.data.page, this.data.limit);
    },
    onShareAppMessage: function() {
        return {
            title: "智慧考题宝，考试助手 ！",
            path: "pages/index/index",
            imageUrl: "/images/share.png"
        };
    }
});