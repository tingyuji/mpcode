Page({
    data: {
        thirdCategoryList: []
    },
    onLoad: function(a) {
        var t = this;
        wx.showLoading({}), this.setData({
            id: a.id,
            firstCategoryName: a.firstCategoryName,
            secondCategoryName: a.secondCategoryName
        }), wx.Apis.api.thirdCategoryList(a.id, "", function(a, e) {
            console.log(e), t.setData({
                thirdCategoryList: e
            }), wx.hideLoading({});
        });
    },
    onReady: function() {},
    onShow: function() {},
    onChange: function(a) {
        this.setData({
            value: a.detail
        });
    },
    onSearch: function() {
        var a = this;
        wx.showLoading({}), wx.Apis.api.thirdCategoryList(a.data.id, a.data.value, function(t, e) {
            console.log(e), a.setData({
                thirdCategoryList: e
            }), wx.hideLoading({});
        });
    },
    goBank: function(a) {
        wx.navigateTo({
            url: "/pages/bank/bank?id=" + a.currentTarget.dataset.id + "&name=" + a.currentTarget.dataset.name
        });
    },
    onShareAppMessage: function() {
        return {
            title: "智慧考题宝，考试助手 ！",
            path: "pages/index/index",
            imageUrl: "/images/share.png"
        };
    }
});