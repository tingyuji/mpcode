var n = require("../../24076A57C080688C42610250BE2B08D6.js");

Page({
    data: {
        options: [ "A", "B", "C", "D", "E", "F", "G", "H", "I", "J" ]
    },
    onLoad: function(e) {
        console.log(e), n.initAllQuestionFromStorage(e.category);
        var o = n.getQuestionsByIds(e.id);
        o[0].answerArr = o[0].answer.split(""), this.setData({
            questions: o,
            model: 3,
            indexInd: 0,
            length: 1,
            current: 0,
            autoplay: !1,
            xiejie: !0,
            interval: 300,
            videoctrl: !0,
            iconIndtwo: !1
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: "智慧考题宝，考试助手 ！",
            path: "pages/index/index",
            imageUrl: "/images/share.png"
        };
    }
});