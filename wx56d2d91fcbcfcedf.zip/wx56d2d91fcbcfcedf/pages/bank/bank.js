Page({
    data: {},
    onLoad: function(t) {
        var e = this;
        wx.setNavigationBarTitle({
            title: t.name
        }), wx.showLoading({
            title: ""
        }), wx.Apis.api.categoryList(t.id, function(t, a) {
            a.length && a.forEach(function(t) {
                t.start = t.start_time.substr(0, 10), t.end = t.end_time.substr(0, 10);
            }), e.setData({
                categoryList: a
            }), wx.hideLoading({});
        });
    },
    onReady: function() {},
    onShow: function() {},
    detail: function(t) {
        console.log(t), wx.navigateTo({
            url: "/pages/detail/detail?id=" + t.currentTarget.dataset.id + "&name=" + t.currentTarget.dataset.name + "&count=" + t.currentTarget.dataset.count + "&time=" + t.currentTarget.dataset.time
        });
    },
    onShareAppMessage: function() {
        return {
            title: "智慧考题宝，考试助手 ！",
            path: "pages/index/index",
            imageUrl: "/images/share.png"
        };
    }
});