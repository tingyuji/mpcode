Page({
    data: {},
    onLoad: function(e) {
        var n = this;
        wx.Apis.api.getConfigValue("exchangeCode", function(e, o) {
            n.setData({
                exchangeCode: o.value
            });
        }), wx.Apis.api.getConfigValue("code_use_days", function(e, o) {
            n.setData({
                code_use_days: o.value
            });
        });
    },
    exchange: function() {
        var e = this;
        wx.showModal({
            title: "提示",
            content: "兑换激活码将消耗" + parseInt(this.data.exchangeCode) + "积分",
            success: function(n) {
                if (n.confirm) {
                    var o = wx.getStorageSync("userInfo");
                    if (parseInt(o.integral) < parseInt(e.data.exchangeCode)) return wx.showToast({
                        icon: "error",
                        title: "积分不足"
                    }), !1;
                    wx.Apis.api.exchangeCode(o.uid, function(n, t) {
                        if (200 != n) return wx.showToast({
                            icon: "error",
                            title: "兑换失败"
                        }), !1;
                        wx.showToast({
                            title: "兑换成功"
                        }), o.integral -= parseInt(e.data.exchangeCode), wx.setStorageSync("userInfo", o);
                    });
                }
            }
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});