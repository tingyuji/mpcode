var a = require("../../@babel/runtime/helpers/interopRequireDefault"), t = a(require("../../CAC2FE40C080688CACA49647E8EA08D6.js")), e = (a(require("../../2EB83B23C080688C48DE5324825A08D6.js")), 
require("../../6D349726C080688C0B52FF216E3B08D6.js"), require("../../0F2098F4C080688C6946F0F37D4B08D6.js")), r = require("../../24076A57C080688C42610250BE2B08D6.js"), d = "random", i = getApp();

Page({
    data: {
        timer: "",
        notice: !1,
        StorageAll: {},
        indexInd: 0,
        redNum: 0,
        greenNum: 0,
        allNum: 0,
        intensify_qis: [],
        intensify_eids: [],
        intensify_okids: [],
        orderPX: {},
        idarr: [],
        textTab: "答题模式",
        selectInd: !0,
        options: [ "A", "B", "C", "D", "E", "F", "G", "H", "I", "J" ],
        moreArr: {
            A: !1,
            B: !1,
            C: !1,
            D: !1,
            E: !1,
            F: !1,
            G: !1,
            H: !1,
            I: !1,
            J: !1
        },
        iconInd: !1,
        iconcircle: [],
        recmend: !1,
        iconIndtwo: !1,
        youind: 0,
        outside: !0,
        current: 0,
        questions: [],
        xiejie: !0,
        timeshow: !0,
        times: "",
        ytimes: "",
        danxuan: 0,
        duoxuan: 0,
        panduan: 0,
        tiankong: 0,
        allfen: 0,
        passf: 0,
        interval: 300,
        training_qids: "",
        training_jl: "",
        videoctrl: !0,
        videoMedia: "",
        startTime: 0,
        startTimeind: !1,
        nums: 0,
        testMode: !1,
        timeback: !1,
        statusOptions: {
            statusType: 0,
            statusColor: "#ff4f42",
            statusBg: "#ffe3e1",
            statusPlan: 1.5,
            statusError: 11,
            statusAnswer: 39,
            statusScore: 50
        },
        fontSize: "32rpx",
        finishAutoNext: !0
    },
    onLoad: function(a) {
        console.log(a);
        var t = this;
        this.setData({
            category_id: a.id,
            model: 1,
            timeback: a.timeback,
            q_update_time: a.q_update_time
        }), a.timeback ? (t.setData({
            timeshow: !1,
            startTimeind: !1
        }), wx.setNavigationBarTitle({
            title: "错题回顾"
        }), setTimeout(function() {
            wx.hideLoading();
        }, 1e3), wx.getStorage({
            key: "examlist" + t.data.category_id,
            success: function(a) {
                t.setData({
                    orderPX: a.data,
                    allNum: a.data.all
                });
                var e = 0, r = 0;
                for (var d in t.data.orderPX) "red" == t.data.orderPX[d] ? (e++, t.setData({
                    redNum: e
                })) : "green" == t.data.orderPX[d] && (r++, t.setData({
                    greenNum: r
                }));
            }
        }), t.getMsg(a)) : wx.Apis.api.getQuestionId(a.id, function(e, r) {
            console.log(r), t.setData({
                categoryDetail: r,
                time: r.time,
                nums: r.number,
                pass: r.pass,
                question_ids: r.question_id.split(",")
            }), wx.getStorage({
                key: "examlist" + t.data.category_id,
                success: function(a) {
                    t.setData({
                        orderPX: a.data,
                        allNum: a.data.all
                    });
                    var e = 0, r = 0;
                    for (var d in t.data.orderPX) "red" == t.data.orderPX[d] ? (e++, t.setData({
                        redNum: e
                    })) : "green" == t.data.orderPX[d] && (r++, t.setData({
                        greenNum: r
                    }));
                }
            }), t.getMsg(a);
        }), this.initBgm();
    },
    changeTab: function() {
        var a = this.data.questions;
        this.setData({
            questions: a,
            textTab: "背题模式",
            selectInd: !1
        });
    },
    getMsg: function(a) {
        var t = this;
        wx.showLoading({
            title: "加载中"
        }), wx.getStorage({
            key: "exam" + t.data.category_id,
            success: function(a) {
                console.log(a.data), t.setData({
                    StorageAll: a.data
                });
            }
        }), wx.getStorage({
            key: "examall" + t.data.category_id,
            success: function(a) {
                if (t.data.timeshow || t.changeTab(), t.data.orderPX) {
                    for (var e = [], r = 0; r < a.data.length; r++) e.push(a.data[r]);
                    d = e;
                } else d = a.data;
                t.setData({
                    questions: d.slice(0, 3)
                }), wx.getStorage({
                    key: "examids" + t.data.category_id,
                    success: function(a) {
                        var e = [];
                        if (t.data.orderPX) {
                            for (var r = [], d = 0; d < a.data.length; d++) r.push(a.data[d]);
                            e = r;
                        } else e = a.data;
                        t.setData({
                            idarr: e
                        });
                    }
                }), console.log(t.data.questions);
            },
            fail: function() {
                if (a.continued) {
                    var e = wx.getStorageSync("exam_allfen" + t.data.category_id);
                    e && t.setData({
                        allfen: 1 * e
                    });
                    var r = wx.getStorageSync("examids" + t.data.category_id);
                    console.log(r), t.ind_to_data(r), setTimeout(function() {
                        wx.hideLoading();
                    }, 1e3);
                } else wx.getStorage({
                    key: d + "" + t.data.category_id,
                    success: function(a) {
                        t.setData({
                            StorageAll: a.data
                        });
                    },
                    complete: function() {
                        if (a.timeback) {
                            var e = wx.getStorageSync("examids" + t.data.category_id);
                            t.ind_to_data(e);
                        } else t.ind_to_data(t.data.question_ids);
                        setTimeout(function() {
                            wx.hideLoading();
                        }, 1e3);
                    }
                });
            }
        });
    },
    ind_to_data: function(a) {
        for (var t = r.getQuestionsByIds(a), e = 0; e < t.length; e++) if (t[e].answerArr = t[e].answer.split(""), 
        this.data.StorageAll[t[e].id]) {
            var i = this.data.StorageAll[t[e].id];
            console.log(i), "1" == i.subup || "0" == i.after ? t[e].order = i : "2" == t[e].type && (t[e].order = {}, 
            t.order.subup = 0, t[e].order.down = {
                A: !1,
                B: !1,
                C: !1,
                D: !1,
                E: !1,
                F: !1,
                G: !1,
                H: !1,
                I: !1,
                J: !1
            });
        } else "2" == t[e].type && (t[e].order = {}, t[e].order.subup = 0, t[e].order.down = {
            A: !1,
            B: !1,
            C: !1,
            D: !1,
            E: !1,
            F: !1,
            G: !1,
            H: !1,
            I: !1,
            J: !1
        });
        d = t, this.setData({
            idarr: a,
            questions: t.slice(0, 3)
        }), console.log(this.data.questions), wx.setStorage({
            key: "examids" + this.data.category_id,
            data: a
        }), this.getthree();
    },
    getthree: function() {
        var a = this;
        wx.getStorage({
            key: "examind" + a.data.category_id,
            success: function(t) {
                var e = {
                    currentTarget: {
                        dataset: {
                            index: t.data
                        }
                    }
                };
                a.jumpToQuestion(e);
            },
            fail: function() {
                a.jumpToQuestion({
                    currentTarget: {
                        dataset: {
                            index: 0
                        }
                    }
                });
            }
        }), wx.getStorage({
            key: "exam" + a.data.category_id,
            success: function(t) {
                if (t.data) {
                    var e = a.data.orderPX;
                    e[a.data.idarr[t.data]] = "blue", a.setData({
                        orderPX: e,
                        recmend: !0
                    }), a.questionStatus(), setTimeout(function() {
                        a.setData({
                            recmend: !1
                        });
                    }, 2e3);
                }
            }
        });
    },
    jumpToQuestion: function(a) {
        var t = this.data.orderPX;
        for (var e in t) "blue" == t[e] && (t[e] = "");
        this.setData({
            orderPX: t,
            iconInd: !1,
            iconIndtwo: !1,
            videoctrl: !0
        });
        var r = a.currentTarget.dataset.color;
        if ("red" != r && "green" != r) {
            var i = this.data.orderPX;
            i[a.currentTarget.dataset.id] = "blue", this.setData({
                orderPX: i
            });
        }
        var n = a.currentTarget.dataset.index;
        this.data.indexInd = n;
        var s = [];
        1 == this.data.current ? (this.data.indexInd <= 0 ? s.push(d[d.length - 1]) : s.push(d[this.data.indexInd - 1]), 
        s.push(d[this.data.indexInd]), this.data.indexInd >= d.length - 1 ? s.push(d[0]) : s.push(d[d.length - 1])) : 0 == this.data.current ? (s.push(d[this.data.indexInd]), 
        this.data.indexInd == d.length - 1 ? (s.push(d[0]), s.push(d[1])) : this.data.indexInd == d.length - 2 ? (s.push(d[this.data.indexInd + 1]), 
        s.push(d[0])) : (s.push(d[this.data.indexInd + 1]), s.push(d[this.data.indexInd + 2]))) : (0 == this.data.indexInd ? (s.push(d[d.length - 2]), 
        s.push(d[d.length - 1])) : 1 == this.data.indexInd ? (s.push(d[d.length - 1]), s.push(d[0])) : (s.push(d[this.data.indexInd - 2]), 
        s.push(d[this.data.indexInd - 1])), s.push(d[this.data.indexInd])), this.setData({
            questions: s,
            indexInd: n
        }), console.log(s);
    },
    closeNotice: function() {
        this.setData({
            notice: !this.data.notice
        }), this.timeServal(this.data.time, 0);
    },
    timeServal: function() {
        var a = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0, t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
        console.log(1);
        var e = this;
        if (!this.data.timeback) if (0 != a || 0 != t) {
            var r = a, d = (e = this, setInterval(function() {
                t < 10 ? e.setData({
                    times: r + ":0" + t,
                    ytimes: a - r + ":" + (59 - t)
                }) : e.setData({
                    times: r + ":" + t,
                    ytimes: a - r + ":" + (59 - t)
                }), --t < 0 && (r > 0 ? (t = 59, r--) : (t = 0, r = 0, e.setData({
                    startTimeind: !0
                }), clearInterval(d)));
            }, 1e3));
            e.setData({
                timer: d
            });
        } else this.setData({
            times: 0,
            startTimeind: !0
        });
    },
    selectAnswer: function(a) {
        var t = this, e = t.data.indexInd + 1, r = t.data.idarr[e];
        if (function a() {
            if (r = t.data.idarr[e], e < t.data.idarr.length - 1) {
                if ("green" != t.data.orderPX[r] && "red" != t.data.orderPX[r]) {
                    wx.setStorage({
                        key: "examind" + t.data.category_id,
                        data: e
                    });
                    var d = t.data.orderPX;
                    for (var i in d) "blue" == d[i] && (d[i] = "");
                    return d[r] = "blue", void t.setData({
                        orderPX: d
                    });
                }
                e++, a();
            } else wx.setStorage({
                key: "examind" + t.data.category_id,
                data: t.data.idarr.length - 1
            });
        }(), 1 == t.data.model && !t.data.timeback) {
            var i = d, n = t.data.questions;
            i[t.data.indexInd].order = {
                after: 0,
                downAnswer: a.currentTarget.dataset.ind,
                answer: a.currentTarget.dataset.answer,
                type: a.currentTarget.dataset.type
            }, i[t.data.current].order = {
                after: 0,
                downAnswer: a.currentTarget.dataset.ind,
                answer: a.currentTarget.dataset.answer,
                type: a.currentTarget.dataset.type
            }, d = i, t.setData({
                questions: n
            });
            var s = t.data.StorageAll;
            s[a.currentTarget.dataset.id] = {
                after: 0,
                downAnswer: a.currentTarget.dataset.ind,
                answer: a.currentTarget.dataset.answer,
                type: a.currentTarget.dataset.type
            }, wx.setStorage({
                key: "exam" + t.data.category_id,
                data: s
            }), t.setData({
                StorageAll: s
            });
            var o = t.data.allNum;
            if (o++, a.currentTarget.dataset.ind == a.currentTarget.dataset.answer) {
                var l = t.data.orderPX;
                l[a.currentTarget.dataset.id] = "green", l.all = o, wx.setStorageSync("examlist" + t.data.category_id, l);
                var u = t.data.greenNum;
                u++, t.setData({
                    greenNum: u,
                    allNum: o
                });
            } else if (a.currentTarget.dataset.ind != a.currentTarget.dataset.answer) {
                var g = t.data.orderPX;
                g[a.currentTarget.dataset.id] = "green", g.all = o, wx.setStorageSync("examlist" + t.data.category_id, g);
                var c = t.data.redNum;
                c++, t.setData({
                    redNum: c,
                    allNum: o
                });
            }
            t.questionStatus(), t.data.indexInd < d.length - 1 ? t.autoPlay() : setTimeout(function() {
                (t.data.indexInd != d.length - 1 || 1 * t.data.greenNum + 1 * t.data.redNum != d.length) && (t.data.indexInd == d.length - 1 && t.handexam());
            }, 600);
        }
    },
    selectAnswerMore: function(a) {
        var t = this;
        if (1 == this.data.model && !this.data.timeback) {
            var e = t.data.StorageAll, r = t.data.moreArr;
            r[a.currentTarget.dataset.ind] ? r[a.currentTarget.dataset.ind] = !1 : r[a.currentTarget.dataset.ind] = !0, 
            e[a.currentTarget.dataset.id] = {
                subup: 0,
                down: r
            }, t.setData({
                moreArr: r
            }), wx.setStorage({
                key: "exam" + t.data.category_id,
                data: e
            }), wx.getStorage({
                key: "exam" + t.data.category_id,
                success: function(a) {
                    t.setData({
                        StorageAll: a.data
                    });
                }
            });
            var d = t.data.questions;
            d[t.data.current].order = e[a.currentTarget.dataset.id], t.setData({
                questions: d
            });
        }
    },
    moreSelectSub: function(a) {
        var e = this, r = e.data.indexInd + 1, i = e.data.idarr[r];
        !function a() {
            if (i = e.data.idarr[r], r < e.data.idarr.length - 1) {
                if (console.log("true"), "green" != e.data.orderPX[i] && "red" != e.data.orderPX[i]) {
                    wx.setStorage({
                        key: "examind" + e.data.category_id,
                        data: r
                    });
                    var t = e.data.orderPX;
                    for (var d in t) "blue" == t[d] && (t[d] = "");
                    return t[i] = "blue", e.setData({
                        orderPX: t
                    });
                }
                r++, a();
            } else console.log("false"), wx.setStorage({
                key: "examind" + e.data.category_id,
                data: e.data.idarr.length - 1
            });
        }();
        var n = e.data.StorageAll, s = e.data.moreArr, o = 0, l = "";
        for (var u in e.data.moreArr) e.data.moreArr[u] && (o++, l += u);
        if (0 == o) return t.default.fail("请选择答案"), !1;
        n[a.currentTarget.dataset.id] = {
            subup: 1,
            down: s,
            type: a.currentTarget.dataset.type,
            answer: a.currentTarget.dataset.answer,
            downAnswer: l
        }, e.setData({
            StorageAll: n
        }), wx.setStorage({
            key: "exam" + e.data.category_id,
            data: n
        });
        var g = e.data.questions, c = d;
        c[e.data.indexInd].order = {
            subup: 1,
            down: s,
            type: a.currentTarget.dataset.type,
            answer: a.currentTarget.dataset.answer,
            downAnswer: l
        }, g[e.data.current].order = {
            subup: 1,
            down: s,
            type: a.currentTarget.dataset.type,
            answer: a.currentTarget.dataset.answer,
            downAnswer: l
        }, d = c, e.setData({
            questions: g
        });
        var h = e.data.allNum;
        if (h++, o == a.currentTarget.dataset.answer.length && l == a.currentTarget.dataset.answer) {
            (y = e.data.orderPX)[a.currentTarget.dataset.id] = "green", y.all = h, wx.setStorageSync("examlist" + e.data.category_id, y);
            var m = e.data.greenNum;
            m++, e.setData({
                greenNum: m,
                allNum: h
            }), e.questionStatus();
        } else {
            var y;
            (y = e.data.orderPX)[a.currentTarget.dataset.id] = "green", y.all = h, wx.setStorageSync("examlist" + e.data.category_id, y);
            var w = e.data.redNum;
            w++, e.setData({
                redNum: w,
                allNum: h
            }), e.questionStatus();
        }
        e.data.indexInd < d.length - 1 ? e.autoPlay() : setTimeout(function() {
            (e.data.indexInd != d.length - 1 || 1 * e.data.greenNum + 1 * e.data.redNum != d.length) && (e.data.indexInd == d.length - 1 && e.handexam());
        }, 600), e.setData({
            A: !1,
            B: !1,
            C: !1,
            D: !1,
            E: !1,
            F: !1,
            G: !1,
            H: !1,
            I: !1,
            J: !1
        }), setTimeout(function() {
            (e.data.indexInd != d.length - 1 || 1 * e.data.greenNum + 1 * e.data.redNum != d.length) && (e.data.indexInd == d.length && e.handexam());
        }, 600);
    },
    fillSub: function(a) {
        if ("" == a.detail.value.subAnswer) return t.default.fail("请输入答案"), !1;
        var e = this, r = e.data.indexInd + 1, i = e.data.idarr[r];
        if (function a() {
            if (console.log("exam"), i = e.data.idarr[r], r < e.data.idarr.length - 1) {
                if ("green" != e.data.orderPX[i] && "red" != e.data.orderPX[i]) {
                    wx.setStorage({
                        key: "examind" + e.data.category_id,
                        data: r
                    });
                    var t = e.data.orderPX;
                    for (var d in t) "blue" == t[d] && (t[d] = "");
                    return t[i] = "blue", e.setData({
                        orderPX: t
                    }), void console.log(e.data.orderPX);
                }
                r++, a();
            } else wx.setStorage({
                key: "examind" + e.data.category_id,
                data: e.data.idarr.length - 1
            });
        }(), 1 == e.data.model && !e.data.timeback) {
            var n = d, s = e.data.questions;
            n[e.data.indexInd].order = {
                type: 4,
                downAnswer: a.detail.value.subAnswer,
                answer: a.detail.value.answer,
                subup: 1
            }, s[e.data.current].order = {
                type: 4,
                downAnswer: a.detail.value.subAnswer,
                answer: a.detail.value.answer,
                subup: 1
            }, d = n, e.setData({
                questions: s
            });
            var o = e.data.StorageAll;
            o[a.detail.value.id] = {
                type: 4,
                downAnswer: a.detail.value.subAnswer,
                answer: a.detail.value.answer,
                subup: 1
            }, wx.setStorage({
                key: "exam" + e.data.category_id,
                data: o
            }), e.setData({
                StorageAll: o
            });
            var l = e.data.allNum;
            if (l++, a.detail.value.subAnswer == a.detail.value.answer) {
                (c = e.data.orderPX)[a.detail.value.id] = "green", c.all = l, wx.setStorageSync("examlist" + e.data.category_id, c);
                var u = e.data.greenNum;
                if (u++, e.setData({
                    greenNum: u
                }), e.data.indexInd < d.length - 1) {
                    e.autoPlay();
                    var g = e.data.everyDay_all;
                    g++, e.setData({
                        everyDay_all: g,
                        allNum: l
                    });
                }
            } else if (a.detail.value.subAnswer != a.detail.value.answer) {
                var c;
                console.log(s), (c = e.data.orderPX)[a.detail.value.id] = "green", c.all = l, wx.setStorageSync("examlist" + e.data.category_id, c);
                var h = e.data.redNum;
                h++, e.setData({
                    redNum: h,
                    allNum: l
                });
                var m = e.data.everyDay_error;
                g = e.data.everyDay_all;
                m++, g++, e.setData({
                    everyDay_error: m,
                    everyDay_all: g
                }), e.autoPlay();
            }
            e.questionStatus();
        }
    },
    moreFillSub: function(a) {
        for (var e = a.detail.value.answer.split(";"), r = 0, i = 0; i < e.length; i++) "" == a.detail.value["subAnswer" + i] && r++;
        if (r == e.length) return t.default.fail("请输入答案"), !1;
        var n = this, s = n.data.indexInd + 1, o = n.data.idarr[s];
        if (function a() {
            if (o = n.data.idarr[s], s < n.data.idarr.length - 1) {
                if ("green" != n.data.orderPX[o] && "red" != n.data.orderPX[o]) {
                    wx.setStorage({
                        key: d + "ind1",
                        data: s
                    });
                    var t = n.data.orderPX;
                    for (var e in t) "blue" == t[e] && (t[e] = "");
                    return t[o] = "blue", n.setData({
                        orderPX: t
                    }), void console.log(n.data.orderPX);
                }
                s++, a();
            } else wx.setStorage({
                key: d + "ind1",
                data: n.data.idarr.length - 1
            });
        }(), 1 == n.data.model && !n.data.timeback) {
            var l = d, u = n.data.questions, g = (e = a.detail.value.answer.split(";"), []);
            for (i = 0; i < e.length; i++) g.push(a.detail.value["subAnswer" + i]);
            l[n.data.indexInd].order = {
                type: 5,
                downAnswer: g.join(";"),
                answer: a.detail.value.answer,
                subup: 1,
                down: g
            }, u[n.data.current].order = {
                type: 5,
                downAnswer: g.join(";"),
                answer: a.detail.value.answer,
                subup: 1,
                down: g
            }, d = l, n.setData({
                questions: u
            });
            var c = n.data.StorageAll;
            c[a.detail.value.id] = {
                type: 5,
                downAnswer: g.join(";"),
                answer: a.detail.value.answer,
                subup: 1,
                down: g
            }, wx.setStorage({
                key: "exam" + n.data.category_id,
                data: c
            }), n.setData({
                StorageAll: c
            });
            var h = n.data.allNum, m = 0;
            for (i = 0; i < e.length; i++) a.detail.value["subAnswer" + i] == e[i] && m++;
            if (console.log("答案" + m), console.log("正确答案" + e.length), h++, m == e.length) {
                (x = n.data.orderPX)[a.detail.value.id] = "green", x.all = h, wx.setStorageSync("examlist" + n.data.category_id, x);
                var y = n.data.greenNum;
                if (y++, n.setData({
                    greenNum: y
                }), n.data.indexInd < d.length - 1) {
                    n.autoPlay();
                    var w = n.data.everyDay_all;
                    w++, n.setData({
                        everyDay_all: w,
                        allNum: h
                    });
                }
            } else if (m != e.length) {
                var x;
                (x = n.data.orderPX)[a.detail.value.id] = "green", x.all = h, wx.setStorageSync("examlist" + n.data.category_id, x);
                var f = n.data.redNum;
                f++, n.setData({
                    redNum: f,
                    allNum: h
                });
                var v = n.data.everyDay_error;
                w = n.data.everyDay_all;
                v++, w++, n.setData({
                    everyDay_error: v,
                    everyDay_all: w
                }), n.autoPlay();
            }
            n.questionStatus();
        }
    },
    storageTraining_qids: function(a) {
        var t = this.data.training_qids;
        t = t + "" + a + "," + wx.setStorage({
            key: "training_qids" + this.data.category_id,
            data: t
        }), this.setData({
            training_qids: t
        });
        var e = this.data.intensify_qis;
        e.push(a), this.setData({
            intensify_qis: e
        }), wx.setStorage({
            key: "intensify_qis" + this.data.category_id,
            data: e
        });
    },
    storageokids: function(a) {
        var t = this.data.intensify_okids;
        -1 == t.indexOf(a) && (t.push(a), this.setData({
            intensify_okids: t
        }), wx.setStorage({
            key: "intensify_okids" + this.data.category_id,
            data: t
        }));
    },
    storagenoids: function(a) {
        var t = this.data.intensify_eids;
        -1 == t.indexOf(a) && (t.push(a), this.setData({
            intensify_eids: t
        }), wx.setStorage({
            key: "intensify_noids" + this.data.category_id,
            data: t
        }));
    },
    preview: function(a) {
        var t = a.currentTarget.dataset.src, e = [];
        e.push(t), wx.previewImage({
            current: t,
            urls: e
        });
    },
    handexam: function() {},
    autoPlay: function() {
        this.data.finishAutoNext && this.setData({
            autoplay: !0
        });
    },
    pageChange: function(a) {
        "autoplay" == a.detail.source && this.setData({
            autoplay: !1
        });
        var t = this;
        2 == this.data.questions[a.detail.current].type ? t.setData({
            moreArr: this.data.questions[a.detail.current].order.down,
            xiejie: !0
        }) : t.setData({
            moreArr: {
                A: !1,
                B: !1,
                C: !1,
                D: !1,
                E: !1,
                F: !1,
                G: !1,
                H: !1,
                I: !1,
                J: !1
            },
            xiejie: !0
        });
        var e = t.data.current, r = a.detail.current, i = t.data.indexInd, n = 1 * r - 1 * e;
        if (-2 == n ? n = 1 : 2 == n && (n = -1), (i += n) >= d.length) return i = 0, wx.showToast({
            title: "已经是最后一题"
        }), void t.setData({
            xiejie: !1,
            current: 2
        });
        if (i < 0) return wx.showToast({
            title: "已经是第一题"
        }), t.setData({
            xiejie: !1,
            current: 0
        }), void (i = d.length - 1);
        var s = [];
        0 == r ? (s.push(d[i]), s.push(d[i + 1]), s.push(d[i - 1]), s[1] || (s[1] = d[0]), 
        s[2] || (s[2] = d[d.length - 1])) : 1 == r ? (s.push(d[i - 1]), s.push(d[i]), s.push(d[i + 1]), 
        s[2] || (s[2] = d[0]), s[0] || (s[0] = d[d.length - 1])) : 2 == r && (s.push(d[i + 1]), 
        s.push(d[i - 1]), s.push(d[i]), s[0] || (s[0] = d[0]), s[1] || (s[1] = d[d.length - 1])), 
        (t = this).setData({
            questions: s,
            indexInd: i,
            current: r
        });
    },
    submit: function() {
        var a = this;
        clearInterval(this.data.timer);
        var t = this.data.idarr.length, e = wx.getStorageSync("exam" + a.data.category_id), r = 0;
        e && (r = Object.keys(e).length);
        console.log(r), wx.showModal({
            title: "温馨提示",
            content: t - r > 0 ? "你还有" + (t - r) + "道题未做，确定要交卷吗？" : "你已经答完所有的题了，赶快交卷吧",
            success: function(t) {
                if (t.confirm) a.newUp_exam(); else {
                    var e = a.data.times.split(":");
                    a.timeServal(e[0], e[1]);
                }
            }
        });
    },
    newUp_exam: function() {
        console.log("new");
        var a = this;
        this.setData({
            startTimeind: !1
        });
        var e = wx.getStorageSync("examids" + a.data.category_id).join(","), r = {};
        wx.getStorage({
            key: "exam" + a.data.category_id,
            success: function(d) {
                var i = 0, n = 0;
                for (var s in d.data) {
                    var o = d.data[s];
                    switch (d.data[s].downAnswer ? r[s] = {
                        answer: d.data[s].answer,
                        downAnswer: d.data[s].downAnswer,
                        type: d.data[s].type
                    } : r[s] = {
                        answer: d.data[s].answer,
                        downAnswer: "",
                        type: d.data[s].type
                    }, o.type) {
                      case 1:
                        o.downAnswer == o.answer ? (i++, n += a.data.categoryDetail.r_score) : 0;
                        break;

                      case 2:
                        var l = "", u = 0, g = (y = o.answer.split("")).length, c = !1;
                        for (var h in o.down) o.down[h] && (l += h, y.indexOf(h) > -1 ? u++ : c = !0);
                        var m = l.length;
                        1 === a.data.categoryDetail.multiple_score_mode ? l == o.answer ? (i++, n += a.data.categoryDetail.m_score) : 0 : m == g && u == g ? (i++, 
                        n += a.data.categoryDetail.m_score) : c || (n += a.data.categoryDetail.multiple_miss);
                        break;

                      case 3:
                        o.downAnswer == o.answer ? (i++, n += a.data.categoryDetail.j_score) : 0;
                        break;

                      case 4:
                        o.answer == o.downAnswer ? (i++, n += a.data.categoryDetail.f_score) : 0;
                        break;

                      case 5:
                        for (var y = o.answer.split(";"), w = o.downAnswer.split(";"), x = 0, f = 0; f < y.length; f++) y[f] == w[f] && x++;
                        1 === a.data.categoryDetail.fill_score_mode ? x === y.length ? (i++, n += a.data.categoryDetail.more_score) : 0 : 2 === a.data.categoryDetail.fill_score_mode ? x === y.length ? (i++, 
                        n += a.data.categoryDetail.more_score) : 0 === x ? 0 : n += parseFloat((a.data.categoryDetail.more_score / y.length).toFixed(1)) : x === y.length ? (i++, 
                        n += a.data.categoryDetail.more_score) : 0 === x ? 0 : n += a.data.categoryDetail.fill_miss;
                    }
                }
                var v = a.data.times.split(":"), p = parseInt(a.data.time) - (parseInt(v[0]) + 1), _ = 60 - parseInt(v[1]), S = 60 * p + _, D = {
                    uid: wx.getStorageSync("userInfo").uid,
                    score: n,
                    category_id: a.data.category_id,
                    use_time: S,
                    record: r,
                    question_id: e
                };
                wx.Apis.api.saveExamRecord(D, function(e, r) {
                    if (200 != e) return t.default.fail("提交失败"), !1;
                    a.clear_storage();
                    var d = (p > 9 ? p.toString() : "0" + p.toString()) + ":" + (_ > 9 ? _.toString() : "0" + _.toString()), s = (i / a.data.nums * 100).toFixed(2);
                    wx.redirectTo({
                        url: "/pages/result/result?id=" + a.data.category_id + "&record=" + r.id + "&title=" + a.data.categoryDetail.name + "&score=" + n + "&time=" + d + "&green=" + i + "&right=" + s
                    });
                });
            }
        });
    },
    status_choose_btn: function(a) {
        "again" == a.detail.msg ? (this.clear_storage(), wx.redirectTo({
            url: "/pages/exam/exam?id=" + this.data.category_id
        })) : (wx.setStorage({
            key: "examall" + this.data.category_id,
            data: d
        }), wx.redirectTo({
            url: "/pages/exam/exam?id=" + this.data.category_id + "&timeback=1"
        }));
    },
    clear_storage: function() {
        wx.removeStorage({
            key: "exam" + this.data.category_id
        }), wx.removeStorage({
            key: "examlist" + this.data.category_id
        }), wx.removeStorage({
            key: "examind" + this.data.category_id
        }), wx.removeStorage({
            key: "examids" + this.data.category_id
        }), wx.removeStorage({
            key: "examall" + this.data.category_id
        }), wx.removeStorage({
            key: "examall" + this.data.category_id
        }), wx.removeStorage({
            key: "examtimes" + this.data.category_id
        });
    },
    questionStatus: function() {
        var a = this;
        wx.getStorage({
            key: "examlist" + a.data.category_id,
            success: function(t) {
                a.setData({
                    orderPX: t.data,
                    allNum: t.data.all
                });
            }
        });
    },
    _updown: function() {
        this.setData({
            iconInd: !this.data.iconInd,
            iconIndtwo: !this.data.iconIndtwo
        });
    },
    onReady: function() {},
    onShow: function() {
        var a = wx.getStorageSync("fontSize");
        a && this.setData({
            fontSize: a
        });
        var t = wx.getStorageSync("finishAutoNext");
        "" !== t && this.setData({
            finishAutoNext: t
        });
    },
    initBgm: function() {
        wx.getStorageSync("music") && (this.bgm = wx.createInnerAudioContext(), this.bgm.loop = !0, 
        this.bgm.autoplay = !1, this.bgm.src = i.globalData.bgmUrl, this.bgm.play());
    },
    onHide: function() {},
    onUnload: function() {
        wx.getStorageSync("music") && this.bgm.pause();
        var a = wx.getStorageSync("myCategory"), t = {
            id: this.data.category_id,
            name: this.data.categoryDetail.name,
            date: (0, e.getNowDate)(),
            q_update_time: this.data.q_update_time
        };
        if (a) {
            for (var r = 0; r < a.length; r++) a[r].id == this.data.category_id && a.splice(r, 1);
            a.unshift(t), wx.setStorageSync("myCategory", a);
        } else (a = []).push(t), wx.setStorageSync("myCategory", a);
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: "智慧考题宝，考试助手 ！",
            path: "pages/index/index",
            imageUrl: "/images/share.png"
        };
    }
});