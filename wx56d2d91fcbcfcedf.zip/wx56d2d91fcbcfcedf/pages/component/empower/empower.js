require("../../../@babel/runtime/helpers/interopRequireDefault")(require("../../../CAC2FE40C080688CACA49647E8EA08D6.js"));

Component({
    properties: {
        isLogin: {
            type: Boolean,
            value: !1
        },
        canIUseGetUserProfile: {
            type: Boolean,
            value: !1
        }
    },
    data: {},
    methods: {
        noLogin: function() {
            this.setData({
                isLogin: !this.data.isLogin
            });
            this.triggerEvent("myevent", {
                code: 2
            }, {});
        },
        goLogin: function() {
            this.triggerEvent("myevent", {
                code: 1,
                result: !0
            }, {}), wx.navigateTo({
                url: "/pages/login/login"
            });
        },
        getUserProfile: function(e) {
            this.noLogin();
            var t = wx.getStorageSync("openid");
            if ("" == t || null == t) return wx.showToast({
                title: "授权失败",
                icon: "none",
                duration: 1500
            }), !1;
            var o = this;
            wx.getUserProfile({
                desc: "完善用户信息",
                success: function(e) {
                    wx.showLoading({
                        title: "授权中"
                    });
                    var n = e.userInfo;
                    n.openid = t, wx.Apis.login.save(n, function(e, t) {
                        if (200 == e) {
                            wx.setStorageSync("userInfo", t);
                            var n = {
                                code: 1,
                                result: !0,
                                userInfo: t
                            };
                            o.triggerEvent("myevent", n, {}), setTimeout(function() {
                                wx.hideLoading({}), wx.showToast({
                                    title: "授权成功",
                                    icon: "none",
                                    duration: 1500
                                });
                            }, 1500);
                        } else setTimeout(function() {
                            wx.hideLoading({}), wx.showToast({
                                title: "授权失败",
                                icon: "none",
                                duration: 1500
                            });
                        }, 1500);
                    });
                }
            });
        }
    }
});