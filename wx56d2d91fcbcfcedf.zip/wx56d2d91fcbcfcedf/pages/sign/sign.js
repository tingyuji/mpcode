Page({
    data: {
        active: !1,
        signSystemList: [],
        userSign: "",
        signCount: []
    },
    onLoad: function(n) {
        var i = this;
        wx.Apis.api.getSignConfig(function(n, t) {
            console.log(t), i.setData({
                signSystemList: t,
                day: i.Rp(t.length)
            });
        });
    },
    onReady: function() {},
    onShow: function() {
        var n = this;
        this.setData({
            userInfo: wx.getStorageSync("userInfo")
        }), wx.showLoading({
            title: "加载中",
            mask: !0
        }), wx.Apis.api.getUserSign(this.data.userInfo.uid, function(i, t) {
            wx.hideLoading({}), n.setData({
                userSign: t,
                sign_index: t.sign_num,
                signCount: n.PrefixInteger(t.sum_sign_day, 4)
            });
        }), this.getSignList();
    },
    close: function() {
        this.setData({
            active: !1
        });
    },
    Rp: function(n) {
        var i = [ "零", "一", "二", "三", "四", "五", "六", "七", "八", "九" ], t = "";
        n = "" + n;
        for (var s = 0; s < n.length; s++) t += i[parseInt(n.charAt(s))];
        return t;
    },
    PrefixInteger: function(n, i) {
        return (Array(i).join("0") + n).slice(-i).split("");
    },
    goSign: function(n) {
        wx.showLoading({
            title: ""
        });
        var i = this, t = i.data.userSign.sum_sign_day;
        if (i.data.userSign.is_day_sign) return $Toast({
            content: "您今日已签到!"
        }), wx.hideLoading({}), !1;
        wx.Apis.api.userSign(this.data.userInfo.uid, function(n, s) {
            wx.hideLoading({}), i.setData({
                active: !0,
                integral: s.integral,
                sign_index: i.data.sign_index + 1 > i.data.signSystemList.length ? 1 : i.data.sign_index + 1,
                signCount: i.PrefixInteger(t + 1, 4),
                "userSign.is_day_sign": !0,
                "userInfo.integral": parseInt(i.data.userInfo.integral) + parseInt(s.integral),
                "userInfo.sign_num": parseInt(i.data.userInfo.sign_num) + 1
            }), wx.setStorageSync("userInfo", i.data.userInfo), i.getSignList();
        });
    },
    getSignList: function() {
        var n = this, i = {
            uid: n.data.userInfo.uid,
            page: 1,
            limit: 3
        };
        wx.Apis.api.getSignList(i, function(i, t) {
            n.setData({
                signList: t
            });
        });
    },
    goSignList: function(n) {
        wx.navigateTo({
            url: "/pages/signList/signList"
        });
    },
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: "智慧考题宝，考试助手 ！",
            path: "pages/index/index",
            imageUrl: "/images/share.png"
        };
    }
});