Page({
    data: {
        rightAutoNext: !0,
        finishAutoNext: !0,
        rightRemove: !1,
        music: !1,
        fontSize: "32rpx"
    },
    onLoad: function(t) {
        var e = wx.getStorageSync("rightAutoNext");
        "" !== e && this.setData({
            rightAutoNext: e
        });
        var i = wx.getStorageSync("finishAutoNext");
        "" !== i && this.setData({
            finishAutoNext: i
        });
        var a = wx.getStorageSync("rightRemove");
        "" !== a && this.setData({
            rightRemove: a
        });
        var o = wx.getStorageSync("music");
        "" !== o && this.setData({
            music: o
        });
        var n = wx.getStorageSync("fontSize");
        n && this.setData({
            fontSize: n
        });
    },
    onReady: function() {},
    onShow: function() {},
    rightAutoNextChange: function() {
        var t = wx.getStorageSync("rightAutoNext");
        t || "" === t ? (wx.setStorageSync("rightAutoNext", !1), this.setData({
            rightAutoNext: !1
        })) : (wx.setStorageSync("rightAutoNext", !0), this.setData({
            rightAutoNext: !0
        }));
    },
    finishAutoNextChange: function() {
        var t = wx.getStorageSync("finishAutoNext");
        t || "" === t ? (wx.setStorageSync("finishAutoNext", !1), this.setData({
            finishAutoNext: !1
        })) : (wx.setStorageSync("finishAutoNext", !0), this.setData({
            finishAutoNext: !0
        }));
    },
    rightRemoveChange: function() {
        wx.getStorageSync("rightRemove") ? (wx.setStorageSync("rightRemove", !1), this.setData({
            rightRemove: !1
        })) : (wx.setStorageSync("rightRemove", !0), this.setData({
            rightRemove: !0
        }));
    },
    musicChange: function() {
        wx.getStorageSync("music") ? (wx.setStorageSync("music", !1), this.setData({
            music: !1
        })) : (wx.setStorageSync("music", !0), this.setData({
            music: !0
        }));
    },
    fontSizeChange: function(t) {
        var e = t.currentTarget.dataset.size;
        wx.setStorageSync("fontSize", e), this.setData({
            fontSize: e
        });
    },
    onShareAppMessage: function() {
        return {
            title: "智慧考题宝，考试助手 ！",
            path: "pages/index/index",
            imageUrl: "/images/share.png"
        };
    }
});