var t = null;

Page({
    data: {
        page: 1,
        limit: 15,
        nodata: !0,
        integralList: [],
        moreData: !0
    },
    onLoad: function(e) {
        var n = this, o = wx.getStorageSync("userInfo");
        if (this.setData({
            userInfo: o
        }), this.getIntegral(this.data.page, this.data.limit, o.uid), wx.createRewardedVideoAd) {
            (t = wx.createRewardedVideoAd({
                adUnitId: "adunit-3199944fae31efe9"
            })).onError(function(t) {});
            try {
                t.closeHandler && (t.offClose(t.closeHandler), console.log("---videoAd.offClose 卸载成功---"));
            } catch (t) {
                console.log("---videoAd.offClose 卸载失败---"), console.error(t);
            }
            t.closeHandler = function(t) {
                (t && t.isEnded || void 0 === t) && (console.log("播放完毕"), wx.Apis.api.addVideoPoints(o.uid, function(t, e) {
                    200 == t && (o.integral += parseInt(e.point), wx.setStorageSync("userInfo", o), 
                    n.setData({
                        userInfo: o
                    }), wx.showToast({
                        title: "获取积分成功"
                    }));
                }));
            }, t.onClose(t.closeHandler);
        }
    },
    getIntegral: function(t, e, n) {
        var o = this;
        wx.showLoading({
            title: "加载中",
            mask: !0,
            icon: "loading"
        }), wx.Apis.api.getUserIntegral(t, e, n, function(t, e) {
            var n = o.data.integralList, a = o.data.page;
            console.log(e.length), e.length ? (e.forEach(function(t) {
                n.push(t);
            }), o.setData({
                integralList: n,
                page: a + 1,
                nodata: !1
            })) : o.setData({
                integralList: n,
                moreData: !1
            }), setTimeout(function() {
                wx.hideLoading({
                    success: function(t) {}
                });
            }, 1e3);
        });
    },
    goRule: function() {
        wx.navigateTo({
            url: "/pages/pointRule/pointRule"
        });
    },
    onReady: function() {},
    onShow: function() {
        this.setData({
            userInfo: wx.getStorageSync("userInfo")
        });
    },
    goList: function() {
        wx.navigateTo({
            url: "/pages/pointList/pointList"
        });
    },
    goCategory: function() {
        wx.switchTab({
            url: "/pages/category/category"
        });
    },
    seeVideo: function() {
        t && t.show().catch(function() {
            t.load().then(function() {
                return t.show();
            }).catch(function(t) {
                console.log("激励视频 广告显示失败");
            });
        });
    },
    goExchange: function() {
        wx.navigateTo({
            url: "/pages/exchange/exchange"
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {
        this.data.moreData && this.getIntegral(this.data.page, this.data.limit, this.data.userInfo.uid);
    },
    onShareAppMessage: function() {
        return {
            title: "智慧考题宝，考试助手 ！",
            path: "pages/index/index",
            imageUrl: "/images/share.png"
        };
    }
});