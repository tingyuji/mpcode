var a = require("../../@babel/runtime/helpers/interopRequireDefault"), e = require("../../0F2098F4C080688C6946F0F37D4B08D6.js"), t = a(require("../../CAC2FE40C080688CACA49647E8EA08D6.js")), r = require("../../24076A57C080688C42610250BE2B08D6.js"), d = require("../../6D349726C080688C0B52FF216E3B08D6.js"), n = "", i = 1, s = [], o = [], u = getApp();

Page({
    data: {
        StorageAll: {},
        orderPX: {},
        redNum: 0,
        greenNum: 0,
        allNum: 0,
        iconInd: !1,
        iconIndtwo: !1,
        current: 0,
        textTab: "顺序练习",
        selectInd: !0,
        xiejie: !0,
        interval: 300,
        options: [ "A", "B", "C", "D", "E", "F", "G", "H", "I", "J" ],
        moreArr: {
            A: !1,
            B: !1,
            C: !1,
            D: !1,
            E: !1,
            F: !1,
            G: !1,
            H: !1,
            I: !1,
            J: !1
        },
        everyDay_error: 0,
        everyDay_all: 0,
        mode: "",
        type: "",
        idarr: [],
        questions: [],
        recmend: !1,
        starshow: !1,
        fontSize: "32rpx",
        rightAutoNext: !0
    },
    onLoad: function(a) {
        this.setData({
            category_id: a.id,
            type: a.type,
            name: a.name,
            q_update_time: a.q_update_time
        }), "";
        var e = this;
        3 == a.type || 4 == a.type ? wx.Apis.api.getEarmarkQuestionId(a.lid, a.type, a.id, function(t, r) {
            if ("" == r.question_id) return wx.showToast({
                title: "暂无题目"
            }), setTimeout(function() {
                wx.navigateBack({
                    delta: 1
                });
            }, 1e3), !1;
            o = r.question_id.split(","), e.init_play(a);
        }) : 5 == a.type ? wx.Apis.api.oftenWrongQuestionId(a.id, function(t, r) {
            if ("" == r.question_id) return wx.showToast({
                title: "暂无题目"
            }), setTimeout(function() {
                wx.navigateBack({
                    delta: 1
                });
            }, 1e3), !1;
            o = r.question_id.split(","), e.init_play(a);
        }) : this.init_play(a), this.initBgm();
    },
    onReady: function() {},
    onShow: function() {
        var a = wx.getStorageSync("fontSize");
        a && this.setData({
            fontSize: a
        });
        var e = wx.getStorageSync("rightAutoNext");
        (e || "" !== e) && this.setData({
            rightAutoNext: e
        });
    },
    init_play: function(a) {
        var e = this, t = a.mode;
        if (i = a.id, e.setData({
            model: t,
            category_id: a.id,
            type: a.type,
            name: a.name,
            q_update_time: a.q_update_time
        }), "3" == t) var r = "背题模式"; else if ("2" == a.mode) if (1 == a.type) {
            n = "order";
            r = "顺序练习";
        } else if (2 == a.type) {
            n = "randow";
            r = "随机练习";
        } else if (3 == a.type) {
            n = a.lid + "earmark";
            r = "专项练习";
        } else if (4 == a.type) {
            n = a.lid + "type";
            r = "题型练习";
        } else if (5 == a.type) {
            n = "often";
            r = "高频错题";
        }
        wx.setNavigationBarTitle({
            title: r
        }), e.getMsg(t), wx.getStorage({
            key: n + "list" + i,
            success: function(a) {
                e.setData({
                    orderPX: a.data,
                    allNum: a.data.all
                });
                var t = 0, r = 0;
                for (var d in e.data.orderPX) "red" == e.data.orderPX[d] ? (t++, e.setData({
                    redNum: t
                })) : "green" == e.data.orderPX[d] && (r++, e.setData({
                    greenNum: r
                }));
            }
        });
    },
    getMsg: function(a) {
        var e = this;
        wx.showLoading({
            title: "加载中"
        }), wx.getStorage({
            key: n + "" + i,
            success: function(a) {
                e.setData({
                    StorageAll: a.data
                });
            },
            complete: function() {
                e.data.iconcircle;
                wx.getStorage({
                    key: "question_id_" + i,
                    success: function(a) {
                        var t = a.data;
                        if ("2" == e.data.model && 2 == e.data.type && (l = [ {
                            title: "",
                            question_ids: t = d.shuffle(t)
                        } ]), "2" == e.data.model && (3 == e.data.type || 4 == e.data.type || 5 == e.data.type) && (l = [ {
                            title: "",
                            question_ids: t = o
                        } ]), "2" != e.data.model && "3" != e.data.model || 1 != e.data.type && 2 != e.data.type) {
                            if ("2" == e.data.model && (3 == e.data.type || 4 == e.data.type || 5 == e.data.type)) {
                                r.initAllQuestionFromStorage(e.data.category_id);
                                n = r.getQuestionsByIds(o);
                                console.log(n);
                            }
                        } else for (var n = [], i = 0; i < t.length; i++) n[i] = d.clone(r.questions.question[t[i]]);
                        console.log(n);
                        for (i = 0; i < t.length; i++) if (n[i].answerArr = n[i].answer.split(""), e.data.StorageAll[n[i].id]) {
                            var u = e.data.StorageAll[n[i].id];
                            "1" == u.subup || "0" == u.after ? n[i].order = u : (console.log(), "2" == n[i].type && (n[i].order = {}, 
                            n[i].order.subup = 0, n[i].order.down = {
                                A: !1,
                                B: !1,
                                C: !1,
                                D: !1,
                                E: !1,
                                F: !1,
                                G: !1,
                                H: !1,
                                I: !1,
                                J: !1
                            }));
                        } else "2" == n[i].type && (n[i].order = {}, n[i].order.subup = 0, n[i].order.down = {
                            A: !1,
                            B: !1,
                            C: !1,
                            D: !1,
                            E: !1,
                            F: !1,
                            G: !1,
                            H: !1,
                            I: !1,
                            J: !1
                        });
                        console.log(n), console.log(n);
                        var l = [ {
                            title: "试题",
                            len: 0,
                            question_count: t.length,
                            question_ids: t
                        } ];
                        s = n, e.setData({
                            idarr: t,
                            iconcircle: l
                        }), setTimeout(function() {
                            wx.hideLoading();
                        }, 1e3), e.getthree();
                    }
                });
            }
        });
    },
    getthree: function() {
        var a = this;
        wx.getStorage({
            key: n + "ind" + i,
            success: function(e) {
                var t = {
                    currentTarget: {
                        dataset: {
                            index: e.data
                        }
                    }
                };
                a.jumpToQuestion(t);
            },
            fail: function() {
                a.jumpToQuestion({
                    currentTarget: {
                        dataset: {
                            index: 0
                        }
                    }
                });
            }
        }), wx.getStorage({
            key: n + "" + i,
            success: function(e) {
                if (e.data) {
                    var t = a.data.orderPX;
                    t[a.data.idarr[e.data]] = "blue", a.setData({
                        orderPX: t,
                        recmend: !0
                    }), a.questionStatus(), setTimeout(function() {
                        a.setData({
                            recmend: !1
                        });
                    }, 2e3);
                }
            }
        });
    },
    jumpToQuestion: function(a) {
        var e = this, t = e.data.orderPX;
        for (var r in t) "blue" == t[r] && (t[r] = "");
        this.setData({
            orderPX: t,
            iconInd: !1,
            iconIndtwo: !1,
            videoctrl: !0
        });
        var d = a.currentTarget.dataset.color;
        "red" != d && "green" != d && (t[a.currentTarget.dataset.id] = "blue", e.setData({
            orderPX: t
        }));
        var n = a.currentTarget.dataset.index;
        e.data.indexInd = n;
        var o = [];
        1 == this.data.current ? (e.data.indexInd <= 0 ? o.push(s[s.length - 1]) : o.push(s[e.data.indexInd - 1]), 
        o.push(s[e.data.indexInd]), e.data.indexInd >= s.length - 1 ? o.push(s[0]) : o.push(s[s.length - 1])) : 0 == this.data.current ? (o.push(s[e.data.indexInd]), 
        e.data.indexInd == s.length - 1 ? (o.push(s[0]), o.push(s[1])) : e.data.indexInd == s.length - 2 ? (o.push(s[e.data.indexInd + 1]), 
        o.push(s[0])) : (o.push(s[e.data.indexInd + 1]), o.push(s[e.data.indexInd + 2]))) : (0 == e.data.indexInd ? (o.push(s[s.length - 2]), 
        o.push(s[s.length - 1])) : 1 == e.data.indexInd ? (o.push(s[s.length - 1]), o.push(s[0])) : (o.push(s[e.data.indexInd - 2]), 
        o.push(s[e.data.indexInd - 1])), o.push(s[e.data.indexInd])), this.setData({
            questions: o,
            indexInd: n
        }), console.log(n), getApp().saveInfo("starids", i, s[n].id.toString()), setTimeout(function() {
            e.setData({
                starshow: getApp().info
            });
        }, 500), console.log(o);
    },
    questionStatus: function() {
        var a = this;
        wx.getStorage({
            key: n + "list" + i,
            success: function(e) {
                a.setData({
                    orderPX: e.data,
                    allNum: e.data.all
                });
            }
        });
    },
    _updown: function() {
        this.setData({
            iconInd: !this.data.iconInd
        });
    },
    starcollect: function() {
        this.setData({
            starshow: !this.data.starshow
        }), this.data.starshow ? getApp().setIdsStroage("starids", i, i, this.data.questions[this.data.current].id.toString()) : getApp().removeids("starids", i, this.data.questions[this.data.current].id.toString());
    },
    del_data: function() {
        var a = this;
        wx.showModal({
            content: "确定要清空吗？",
            success: function(e) {
                if (e.confirm) {
                    var t = n + "ind" + i, r = n + "list" + i, d = n + "" + i;
                    wx.removeStorageSync(d), wx.removeStorageSync(r), wx.removeStorageSync(t);
                    var o = {
                        id: a.data.category_id,
                        mode: a.data.model,
                        type: a.data.type
                    };
                    s = [], a.setData({
                        iconInd: !1,
                        StorageAll: {},
                        everyDay_error: 0,
                        greenNum: 0,
                        redNum: 0,
                        orderPX: {}
                    }), a.init_play(o);
                }
            }
        });
    },
    pageChange: function(a) {
        "autoplay" == a.detail.source && this.setData({
            autoplay: !1
        });
        var e = this;
        2 == this.data.questions[a.detail.current].type ? e.setData({
            moreArr: this.data.questions[a.detail.current].order.down,
            xiejie: !0
        }) : e.setData({
            moreArr: {
                A: !1,
                B: !1,
                C: !1,
                D: !1,
                E: !1,
                F: !1,
                G: !1,
                H: !1,
                I: !1,
                J: !1
            },
            xiejie: !0
        });
        var t = e.data.current, r = a.detail.current, d = e.data.indexInd, n = 1 * r - 1 * t;
        if (-2 == n ? n = 1 : 2 == n && (n = -1), (d += n) >= s.length) return d = 0, e.result(0), 
        void e.setData({
            xiejie: !1,
            current: 2
        });
        if (d < 0) return wx.showToast({
            icon: "loading",
            title: "已经是第一题"
        }), e.setData({
            xiejie: !1,
            current: 0
        }), void (d = s.length - 1);
        var o = [];
        0 == r ? (o.push(s[d]), o.push(s[d + 1]), o.push(s[d - 1]), o[1] || (o[1] = s[0]), 
        o[2] || (o[2] = s[s.length - 1])) : 1 == r ? (o.push(s[d - 1]), o.push(s[d]), o.push(s[d + 1]), 
        o[2] || (o[2] = s[0]), o[0] || (o[0] = s[s.length - 1])) : 2 == r && (o.push(s[d + 1]), 
        o.push(s[d - 1]), o.push(s[d]), o[0] || (o[0] = s[0]), o[1] || (o[1] = s[s.length - 1])), 
        console.log(o), this.setData({
            questions: o,
            indexInd: d,
            current: r
        }), getApp().saveInfo("starids", i, s[d].id.toString()), setTimeout(function() {
            e.setData({
                starshow: getApp().info
            });
        }, 300);
    },
    autoPlay: function() {
        console.log("auto"), this.data.rightAutoNext && this.setData({
            autoplay: !0
        });
    },
    selectAnswer: function(a) {
        var t = this, r = t.data.indexInd + 1, d = t.data.idarr[r];
        if (function a() {
            if (d = t.data.idarr[r], r < t.data.idarr.length - 1) {
                if ("green" != t.data.orderPX[d] && "red" != t.data.orderPX[d]) {
                    wx.setStorage({
                        key: n + "ind" + i,
                        data: r
                    });
                    var e = t.data.orderPX;
                    for (var s in e) "blue" == e[s] && (e[s] = "");
                    return e[d] = "blue", t.setData({
                        orderPX: e
                    }), void console.log(t.data.orderPX);
                }
                r++, a();
            } else wx.setStorage({
                key: n + "ind" + i,
                data: t.data.idarr.length - 1
            });
        }(), 2 == t.data.model) {
            var o = s, u = t.data.questions;
            if (t.data.StorageAll[t.data.idarr[t.data.indexInd]]) u[t.data.current].order = t.data.StorageAll[t.data.idarr[t.data.indexInd]], 
            t.setData({
                questions: u
            }); else {
                o[t.data.indexInd].order = {
                    after: 0,
                    downAnswer: a.currentTarget.dataset.ind,
                    answer: a.currentTarget.dataset.answer
                }, u[t.data.current].order = {
                    after: 0,
                    downAnswer: a.currentTarget.dataset.ind,
                    answer: a.currentTarget.dataset.answer
                }, s = o, t.setData({
                    questions: u
                });
                var l = t.data.StorageAll;
                l[a.currentTarget.dataset.id] = {
                    after: 0,
                    downAnswer: a.currentTarget.dataset.ind,
                    answer: a.currentTarget.dataset.answer
                }, wx.setStorage({
                    key: n + "" + i,
                    data: l
                }), t.setData({
                    StorageAll: l
                });
                var g = t.data.allNum;
                if (g++, a.currentTarget.dataset.ind == a.currentTarget.dataset.answer) {
                    (0, e.playAudio)("audios/correct.mp3"), (v = t.data.orderPX)[a.currentTarget.dataset.id] = "green", 
                    v.all = g, wx.setStorageSync(n + "list" + i, v);
                    var c = t.data.greenNum;
                    if (c++, t.setData({
                        greenNum: c
                    }), t.data.indexInd < s.length - 1) {
                        t.autoPlay();
                        var p = t.data.everyDay_all;
                        p++, t.setData({
                            everyDay_all: p
                        });
                    }
                } else if (a.currentTarget.dataset.ind != a.currentTarget.dataset.answer) {
                    var v;
                    (0, e.playAudio)("audios/wrong.mp3"), getApp().setIdsStroage("errorids", i, i, u[t.data.current].id.toString()), 
                    (v = t.data.orderPX)[a.currentTarget.dataset.id] = "red", v.all = g, wx.setStorageSync(n + "list" + i, v);
                    var y = t.data.redNum;
                    y++, t.setData({
                        redNum: y
                    });
                }
                t.questionStatus();
            }
        }
    },
    selectAnswerMore: function(a) {
        var e = this;
        if ("1" != e.data.questions[e.data.current].order.subup) {
            var t = e.data.StorageAll, r = e.data.moreArr;
            r[a.currentTarget.dataset.ind] ? r[a.currentTarget.dataset.ind] = !1 : r[a.currentTarget.dataset.ind] = !0, 
            t[a.currentTarget.dataset.id] = {
                subup: 0,
                down: r
            }, e.setData({
                moreArr: r
            }), wx.setStorage({
                key: n + "" + i,
                data: t
            }), wx.getStorage({
                key: n + "" + i,
                success: function(a) {
                    e.setData({
                        StorageAll: a.data
                    });
                }
            });
            var d = e.data.questions;
            d[e.data.current].order = t[a.currentTarget.dataset.id], e.setData({
                questions: d
            });
        }
    },
    moreSelectSub: function(a) {
        var r = this, d = r.data.indexInd + 1, o = r.data.idarr[d];
        !function a() {
            if (o = r.data.idarr[d], d < r.data.idarr.length - 1) {
                if ("green" != r.data.orderPX[o] && "red" != r.data.orderPX[o]) {
                    wx.setStorage({
                        key: n + "ind" + i,
                        data: d
                    });
                    var e = r.data.orderPX;
                    for (var t in e) "blue" == e[t] && (e[t] = "");
                    return e[o] = "blue", r.setData({
                        orderPX: e
                    }), void console.log(r.data.orderPX);
                }
                d++, a();
            } else wx.setStorage({
                key: n + "ind" + i,
                data: r.data.idarr.length - 1
            });
        }();
        var u = r.data.StorageAll, l = r.data.moreArr, g = 0, c = "";
        for (var p in r.data.moreArr) r.data.moreArr[p] && (g++, c += p);
        if (0 == g) return t.default.fail("请选择答案"), !1;
        console.log(c), u[a.currentTarget.dataset.id] = {
            subup: 1,
            down: l,
            downAnswer: c
        }, r.setData({
            StorageAll: u
        }), wx.setStorage({
            key: n + "" + i,
            data: u
        });
        var v = r.data.questions, y = s;
        y[r.data.indexInd].order = {
            subup: 1,
            down: l,
            downAnswer: c
        }, v[r.data.current].order = {
            subup: 1,
            down: l,
            downAnswer: c
        }, s = y, r.setData({
            questions: v
        });
        var w = r.data.allNum;
        if (w++, g == a.currentTarget.dataset.answer.length && c == a.currentTarget.dataset.answer) {
            (h = r.data.orderPX)[a.currentTarget.dataset.id] = "green", h.all = w, wx.setStorageSync(n + "list" + i, h), 
            (0, e.playAudio)("audios/correct.mp3");
            var f = r.data.greenNum;
            f++, r.setData({
                greenNum: f
            }), r.questionStatus(), r.autoPlay(), x = r.data.everyDay_all, x++, r.setData({
                everyDay_all: x
            });
        } else {
            getApp().setIdsStroage("errorids", i, i, v[r.data.current].id.toString());
            var h = r.data.orderPX;
            h[a.currentTarget.dataset.id] = "red", h.all = w, wx.setStorageSync(n + "list" + i, h), 
            (0, e.playAudio)("audios/wrong.mp3");
            var m = r.data.redNum;
            m++, r.setData({
                redNum: m
            }), r.questionStatus();
            var S = r.data.everyDay_error, x = r.data.everyDay_all;
            "," + a.currentTarget.dataset.id, S++, x++, r.setData({
                everyDay_error: S,
                everyDay_all: x
            });
        }
        r.setData({
            moreArr: {
                A: !1,
                B: !1,
                C: !1,
                D: !1,
                E: !1,
                F: !1,
                G: !1,
                H: !1,
                I: !1,
                J: !1
            }
        });
    },
    fillSub: function(a) {
        if ("" == a.detail.value.subAnswer) return t.default.fail("请输入答案"), !1;
        var r = this, d = r.data.indexInd + 1, o = r.data.idarr[d];
        if (function a() {
            if (o = r.data.idarr[d], d < r.data.idarr.length - 1) {
                if ("green" != r.data.orderPX[o] && "red" != r.data.orderPX[o]) {
                    wx.setStorage({
                        key: n + "ind" + i,
                        data: d
                    });
                    var e = r.data.orderPX;
                    for (var t in e) "blue" == e[t] && (e[t] = "");
                    return e[o] = "blue", r.setData({
                        orderPX: e
                    }), void console.log(r.data.orderPX);
                }
                d++, a();
            } else wx.setStorage({
                key: n + "ind" + i,
                data: r.data.idarr.length - 1
            });
        }(), 2 == r.data.model) {
            var u = s, l = r.data.questions;
            if (r.data.StorageAll[r.data.idarr[r.data.indexInd]]) l[r.data.current].order = r.data.StorageAll[r.data.idarr[r.data.indexInd]], 
            r.setData({
                questions: l
            }); else {
                u[r.data.indexInd].order = {
                    after: 0,
                    downAnswer: a.detail.value.subAnswer,
                    answer: a.detail.value.answer,
                    subup: 1
                }, l[r.data.current].order = {
                    after: 0,
                    downAnswer: a.detail.value.subAnswer,
                    answer: a.detail.value.answer,
                    subup: 1
                }, s = u, r.setData({
                    questions: l
                });
                var g = r.data.StorageAll;
                g[a.detail.value.id] = {
                    after: 0,
                    downAnswer: a.detail.value.subAnswer,
                    answer: a.detail.value.answer,
                    subup: 1
                }, wx.setStorage({
                    key: n + "" + i,
                    data: g
                }), r.setData({
                    StorageAll: g
                });
                var c = r.data.allNum;
                if (c++, a.detail.value.subAnswer == a.detail.value.answer) {
                    (0, e.playAudio)("audios/correct.mp3"), (y = r.data.orderPX)[a.detail.value.id] = "green", 
                    y.all = c, wx.setStorageSync(n + "list" + i, y);
                    var p = r.data.greenNum;
                    if (p++, r.setData({
                        greenNum: p
                    }), r.data.indexInd < s.length - 1) {
                        r.autoPlay();
                        var v = r.data.everyDay_all;
                        v++, r.setData({
                            everyDay_all: v
                        });
                    }
                } else if (a.detail.value.subAnswer != a.detail.value.answer) {
                    var y;
                    console.log(l), (0, e.playAudio)("audios/wrong.mp3"), getApp().setIdsStroage("errorids", i, i, l[r.data.current].id.toString()), 
                    (y = r.data.orderPX)[a.detail.value.id] = "red", y.all = c, wx.setStorageSync(n + "list" + i, y);
                    var w = r.data.redNum;
                    w++, r.setData({
                        redNum: w
                    });
                    var f = r.data.everyDay_error;
                    "," + a.detail.value.id;
                    v = r.data.everyDay_all;
                    f++, v++, r.setData({
                        everyDay_error: f,
                        everyDay_all: v
                    });
                }
                r.questionStatus();
            }
        }
    },
    moreFillSub: function(a) {
        for (var r = a.detail.value.answer.split(";"), d = 0, o = 0; o < r.length; o++) "" == a.detail.value["subAnswer" + o] && d++;
        if (d == r.length) return t.default.fail("请输入答案"), !1;
        var u = this, l = u.data.indexInd + 1, g = u.data.idarr[l];
        if (function a() {
            if (g = u.data.idarr[l], l < u.data.idarr.length - 1) {
                if ("green" != u.data.orderPX[g] && "red" != u.data.orderPX[g]) {
                    wx.setStorage({
                        key: n + "ind" + i,
                        data: l
                    });
                    var e = u.data.orderPX;
                    for (var t in e) "blue" == e[t] && (e[t] = "");
                    return e[g] = "blue", u.setData({
                        orderPX: e
                    }), void console.log(u.data.orderPX);
                }
                l++, a();
            } else wx.setStorage({
                key: n + "ind" + i,
                data: u.data.idarr.length - 1
            });
        }(), 2 == u.data.model) {
            var c = s, p = u.data.questions;
            if (u.data.StorageAll[u.data.idarr[u.data.indexInd]]) p[u.data.current].order = u.data.StorageAll[u.data.idarr[u.data.indexInd]], 
            u.setData({
                questions: p
            }); else {
                console.log(a.detail.value);
                var v = [];
                for (o = 0; o < r.length; o++) v.push(a.detail.value["subAnswer" + o]);
                c[u.data.indexInd].order = {
                    after: 0,
                    downAnswer: v.join(";"),
                    answer: a.detail.value.answer,
                    subup: 1
                }, p[u.data.current].order = {
                    after: 0,
                    downAnswer: v.join(";"),
                    answer: a.detail.value.answer,
                    subup: 1
                }, s = c, u.setData({
                    questions: p
                });
                var y = u.data.StorageAll;
                y[a.detail.value.id] = {
                    after: 0,
                    downAnswer: v.join(";"),
                    answer: a.detail.value.answer,
                    subup: 1
                }, wx.setStorage({
                    key: n + "" + i,
                    data: y
                }), u.setData({
                    StorageAll: y
                });
                var w = u.data.allNum, f = 0;
                for (o = 0; o < r.length; o++) a.detail.value["subAnswer" + o] == r[o] && f++;
                if (w++, f == r.length) {
                    (S = u.data.orderPX)[a.detail.value.id] = "green", S.all = w, wx.setStorageSync(n + "list" + i, S), 
                    (0, e.playAudio)("audios/correct.mp3");
                    var h = u.data.greenNum;
                    if (h++, u.setData({
                        greenNum: h
                    }), u.data.indexInd < s.length - 1) {
                        u.autoPlay();
                        var m = u.data.everyDay_all;
                        m++, u.setData({
                            everyDay_all: m
                        });
                    }
                } else if (f != r.length) {
                    var S;
                    console.log(p), getApp().setIdsStroage("errorids", i, i, p[u.data.current].id.toString()), 
                    (S = u.data.orderPX)[a.detail.value.id] = "red", S.all = w, wx.setStorageSync(n + "list" + i, S), 
                    (0, e.playAudio)("audios/wrong.mp3");
                    var x = u.data.redNum;
                    x++, u.setData({
                        redNum: x
                    });
                    var D = u.data.everyDay_error;
                    "," + a.detail.value.id;
                    m = u.data.everyDay_all;
                    D++, m++, u.setData({
                        everyDay_error: D,
                        everyDay_all: m
                    });
                }
                u.questionStatus();
            }
        }
    },
    showAnswer: function(a) {
        var e = this, t = e.data.indexInd + 1, r = e.data.idarr[t];
        if (function a() {
            if (r = e.data.idarr[t], t < e.data.idarr.length - 1) {
                if ("green" != e.data.orderPX[r] && "red" != e.data.orderPX[r]) {
                    wx.setStorage({
                        key: n + "ind" + i,
                        data: t
                    });
                    var d = e.data.orderPX;
                    for (var s in d) "blue" == d[s] && (d[s] = "");
                    return d[r] = "blue", e.setData({
                        orderPX: d
                    }), void console.log(e.data.orderPX);
                }
                t++, a();
            } else wx.setStorage({
                key: n + "ind" + i,
                data: e.data.idarr.length - 1
            });
        }(), 2 == e.data.model) {
            var d = s, o = e.data.questions;
            if (e.data.StorageAll[e.data.idarr[e.data.indexInd]]) o[e.data.current].order = e.data.StorageAll[e.data.idarr[e.data.indexInd]], 
            e.setData({
                questions: o
            }); else {
                d[e.data.indexInd].order = {
                    subup: 1
                }, o[e.data.current].order = {
                    subup: 1
                }, s = d, e.setData({
                    questions: o
                });
                var u = e.data.StorageAll;
                u[a.detail.value.id] = {
                    subup: 1
                }, wx.setStorage({
                    key: n + "" + i,
                    data: u
                }), e.setData({
                    StorageAll: u
                });
                var l = e.data.orderPX, g = e.data.allNum;
                l[a.detail.value.id] = "green", l.all = g, wx.setStorageSync(n + "list" + i, l), 
                e.questionStatus();
            }
        }
    },
    preview: function(a) {
        var e = a.currentTarget.dataset.src, t = [];
        t.push(e), wx.previewImage({
            current: e,
            urls: t
        });
    },
    closeNotice: function() {
        this.setData({
            notice: !this.data.notice
        });
    },
    onHide: function() {
        wx.getStorageSync("music") && this.bgm.pause();
    },
    onUnload: function() {
        wx.getStorageSync("music") && this.bgm.pause();
        var a = wx.getStorageSync("myCategory"), t = {
            id: i,
            name: this.data.name,
            date: (0, e.getNowDate)(),
            q_update_time: this.data.q_update_time
        };
        if (a) {
            for (var r = 0; r < a.length; r++) a[r].id == i && a.splice(r, 1);
            a.unshift(t), wx.setStorageSync("myCategory", a);
        } else (a = []).push(t), wx.setStorageSync("myCategory", a);
    },
    initBgm: function() {
        wx.getStorageSync("music") && (this.bgm = wx.createInnerAudioContext(), this.bgm.loop = !0, 
        this.bgm.autoplay = !1, this.bgm.src = u.globalData.bgmUrl, this.bgm.play());
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: "智慧考题宝，考试助手 ！",
            path: "pages/index/index",
            imageUrl: "/images/share.png"
        };
    }
});