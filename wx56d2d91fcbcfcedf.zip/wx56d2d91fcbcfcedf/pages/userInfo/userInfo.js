require("../../A1A19363C080688CC7C7FB64F21B08D6.js");

Page({
    data: {
        check_template_id: ""
    },
    onLoad: function(e) {
        var t = this;
        wx.Apis.api.getConfigValue("check_template_id", function(e, a) {
            t.setData({
                check_template_id: a.value
            }), wx.hideLoading({});
        });
    },
    getRealName: function(e) {
        this.setData({
            realname: e.detail.value
        });
    },
    getPhone: function(e) {
        this.setData({
            phone: e.detail.value
        });
    },
    saveUserInfo: function() {
        if ("" == this.data.realname || "" == this.data.phone) return wx.showToast({
            icon: "loading",
            title: "请完善信息"
        }), !1;
        if (!/^1(3|4|5|6|7|8|9)\d{9}$/.test(this.data.phone)) return wx.showToast({
            icon: "loading",
            title: "手机号码有误"
        }), !1;
        var e = {
            openid: wx.getStorageSync("openid")
        };
        e.realname = this.data.realname, e.phone = this.data.phone;
        var t = [];
        t.push(this.data.check_template_id), wx.requestSubscribeMessage({
            tmplIds: t,
            success: function(e) {
                console.log(e);
            },
            complete: function() {
                wx.showLoading({
                    title: "保存中"
                });
                var t = wx.getStorageSync("checkUser");
                wx.Apis.api.saveAgainUserInfo(e, function(e, a) {
                    if (wx.hideLoading({}), 200 == e) {
                        if ("true" == t) {
                            a.status = 1;
                            var i = "个人信息已提交，我们会尽快审核！";
                        } else {
                            a.status = 2;
                            i = "个人信息已通过审核！";
                        }
                        wx.setStorageSync("userInfo", a), wx.showModal({
                            title: "提交成功",
                            content: i,
                            showCancel: !1,
                            confirmText: "关闭",
                            confirmColor: "#46C6BA",
                            success: function(e) {
                                wx.navigateBack();
                            }
                        });
                    } else setTimeout(function() {
                        wx.hideLoading({}), wx.showToast({
                            title: "提交失败",
                            icon: "none",
                            duration: 1500
                        });
                    }, 500);
                });
            }
        });
    },
    onShareAppMessage: function() {
        return {
            title: "智慧考题宝，考试助手 ！",
            path: "pages/index/index",
            imageUrl: "/images/share.png"
        };
    }
});