var t = require("../../@babel/runtime/helpers/typeof");

Page({
    data: {
        loading: !1,
        loadend: !1,
        loadtitle: "加载更多",
        page: 1,
        limit: 10,
        signList: []
    },
    onLoad: function(t) {},
    onReady: function() {},
    onShow: function() {
        this.setData({
            userInfo: wx.getStorageSync("userInfo")
        }), this.getSignMoneList();
    },
    getSignMoneList: function() {
        var t = this;
        if (wx.showLoading({
            title: "加载中",
            mask: !0
        }), !t.data.loading && !t.data.loadend) {
            t.setData({
                loading: !0,
                loadtitle: ""
            });
            var i = {
                uid: t.data.userInfo.uid,
                page: 1,
                limit: 10
            };
            wx.Apis.api.getSignMonthList(i, function(i, a) {
                var n = a.data, e = n.length < t.data.limit;
                t.data.signList = t.SplitArray(n, t.data.signList), t.setData({
                    signList: t.data.signList,
                    loadend: e,
                    loading: !1,
                    loadtitle: e ? "已加载完" : "加载更多"
                });
            }, function() {
                t.setData({
                    loading: !1,
                    loadtitle: "加载更多"
                });
            }), wx.hideLoading({
                success: function(t) {}
            });
        }
    },
    SplitArray: function(i, a) {
        if ("object" != t(i)) return [];
        void 0 === a && (a = []);
        for (var n = 0; n < i.length; n++) a.push(i[n]);
        return a;
    },
    onReachBottom: function() {
        this.getSignMoneList();
    },
    onShareAppMessage: function() {
        return {
            title: "智慧考题宝，考试助手 ！",
            path: "pages/index/index",
            imageUrl: "/images/share.png"
        };
    }
});