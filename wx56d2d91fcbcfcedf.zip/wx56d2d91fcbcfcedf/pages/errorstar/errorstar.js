var a = require("../../0F2098F4C080688C6946F0F37D4B08D6.js"), t = require("../../24076A57C080688C42610250BE2B08D6.js"), e = [], r = "", d = "", n = "", s = "", i = getApp();

Page({
    data: {
        StorageAll: {},
        orderPX: {},
        redNum: 0,
        greenNum: 0,
        allNum: 0,
        iconInd: !1,
        iconIndtwo: !1,
        indexInd: 0,
        current: 0,
        textTab: "答题模式",
        selectInd: !0,
        testMode: !1,
        everyDay_all: 0,
        xiejie: !0,
        interval: 300,
        options: [ "A", "B", "C", "D", "E", "F", "G", "H", "I", "J" ],
        moreArr: {
            A: !1,
            B: !1,
            C: !1,
            D: !1,
            E: !1,
            F: !1,
            G: !1,
            H: !1,
            I: !1,
            J: !1
        },
        everyDay_error: 0,
        mode: "1",
        idarr: [],
        questions: [],
        iconcircle: [],
        collectData: [],
        starshow: !0,
        del_chapter_id: "all",
        delarr: [],
        fontSize: "32rpx",
        rightAutoNext: !0
    },
    onLoad: function(a) {
        var t = this;
        4 == a.mode ? (d = "收藏夹", s = "star") : (d = "错题集", s = "error"), wx.setNavigationBarTitle({
            title: d
        });
        var e = wx.getStorageSync(s + "ids" + a.id)[0][a.id];
        console.log(e), n = a.id, 4 == a.mode ? (r = "z全部收藏z", wx.getStorage({
            key: s + "ids" + a.id,
            success: function(a) {
                t.setData({
                    collectData: a.data
                });
            }
        }), console.log(r)) : (r = "z全部错题z", wx.getStorage({
            key: s + "ids" + a.id,
            success: function(a) {
                t.setData({
                    collectData: a.data
                });
            }
        })), t.setData({
            mode: a.mode,
            category: a.id,
            idarr: e,
            ids: e.join(","),
            iconcircle: [ {
                title: "",
                question_ids: e,
                len: 0
            } ]
        }), t.getMsg(), this.initBgm();
    },
    getMsg: function() {
        for (var a = this, r = t.getQuestionsByIds(a.data.ids), d = 0; d < r.length; d++) if (r[d].answerArr = r[d].answer.split(""), 
        a.data.StorageAll[r[d].id]) {
            var n = a.data.StorageAll[r[d].id];
            "1" == n.subup || "0" == n.after ? r[d].order = n : (r[d].order = {}, r[d].order.subup = 0, 
            r[d].order.down = {
                A: !1,
                B: !1,
                C: !1,
                D: !1,
                E: !1,
                F: !1,
                G: !1,
                H: !1,
                I: !1,
                J: !1
            });
        } else r[d].order = {}, r[d].order.subup = 0, r[d].order.down = {
            A: !1,
            B: !1,
            C: !1,
            D: !1,
            E: !1,
            F: !1,
            G: !1,
            H: !1,
            I: !1,
            J: !1
        };
        e = r, a.getthree();
    },
    getthree: function() {
        this.jumpToQuestion({
            currentTarget: {
                dataset: {
                    index: 0
                }
            }
        });
    },
    jumpToQuestion: function(a) {
        var t = this, r = t.data.orderPX;
        for (var d in r) "blue" == r[d] && (r[d] = "");
        this.setData({
            orderPX: r,
            iconInd: !1,
            iconIndtwo: !1
        });
        var n = a.currentTarget.dataset.color;
        if ("red" != n && "green" != n) {
            var s = t.data.orderPX;
            s[a.currentTarget.dataset.id] = "blue", t.setData({
                orderPX: s
            });
        }
        var i = a.currentTarget.dataset.index;
        t.data.indexInd = i;
        var o = [];
        1 == this.data.current ? (t.data.indexInd <= 0 ? o.push(e[e.length - 1]) : o.push(e[t.data.indexInd - 1]), 
        o.push(e[t.data.indexInd]), t.data.indexInd >= e.length - 1 ? o.push(e[0]) : o.push(e[e.length - 1])) : 0 == this.data.current ? (o.push(e[t.data.indexInd]), 
        t.data.indexInd == e.length - 1 ? (o.push(e[0]), o.push(e[1])) : t.data.indexInd == e.length - 2 ? (o.push(e[t.data.indexInd + 1]), 
        o.push(e[0])) : (o.push(e[t.data.indexInd + 1]), o.push(e[t.data.indexInd + 2]))) : (0 == t.data.indexInd ? (o.push(e[e.length - 2]), 
        o.push(e[e.length - 1])) : 1 == t.data.indexInd ? (o.push(e[e.length - 1]), o.push(e[0])) : (o.push(e[t.data.indexInd - 2]), 
        o.push(e[t.data.indexInd - 1])), o.push(e[t.data.indexInd])), this.setData({
            questions: o,
            indexInd: i
        }), this.infoshow(e[i].id), console.log(this.data.questions);
    },
    starcollect: function() {
        this.setData({
            starshow: !this.data.starshow
        });
        var a = this.data.delarr, t = this.data.idarr;
        this.data.starshow ? a.indexOf(t[this.data.indexInd]) > -1 && a.splice(a.indexOf(t[this.data.indexInd]), 1) : a.push(t[this.data.indexInd]), 
        this.setData({
            delarr: a
        }), wx.setStorage({
            key: "delstar" + this.data.category,
            data: a
        });
    },
    infoshow: function(a) {
        this.data.delarr.indexOf(a) > -1 ? this.setData({
            starshow: !1
        }) : this.setData({
            starshow: !0
        });
    },
    closeNotice: function() {
        this.setData({
            notice: !this.data.notice
        });
    },
    _updown: function() {
        this.setData({
            iconInd: !this.data.iconInd,
            iconIndtwo: !this.data.iconIndtwo
        });
    },
    selectAnswer: function(t) {
        var d = this, n = d.data.indexInd + 1, s = d.data.idarr[n];
        if (function a() {
            if (s = d.data.idarr[0], n < d.data.idarr.length - 1) {
                if ("green" != d.data.orderPX[s] && "red" != d.data.orderPX[s]) {
                    wx.setStorage({
                        key: r + "ind" + d.data.category,
                        data: n
                    });
                    var t = d.data.orderPX;
                    for (var e in t) "blue" == t[e] && (t[e] = "");
                    return t[s] = "blue", d.setData({
                        orderPX: t
                    }), void console.log(d.data.orderPX);
                }
                n++, a();
            } else wx.setStorage({
                key: r + "ind" + d.data.category,
                data: d.data.idarr.length - 1
            });
        }(), 4 == d.data.mode || 5 == d.data.mode) {
            var i = e, o = d.data.questions;
            if (d.data.StorageAll[d.data.idarr[d.data.indexInd]]) o[d.data.current].order = d.data.StorageAll[d.data.idarr[d.data.indexInd]], 
            d.setData({
                questions: o
            }); else {
                i[d.data.indexInd].order = {
                    after: 0,
                    downAnswer: t.currentTarget.dataset.ind,
                    answer: t.currentTarget.dataset.answer
                }, o[d.data.current].order = {
                    after: 0,
                    downAnswer: t.currentTarget.dataset.ind,
                    answer: t.currentTarget.dataset.answer
                }, e = i, d.setData({
                    questions: o
                });
                var l = d.data.StorageAll;
                l[t.currentTarget.dataset.id] = {
                    after: 0,
                    downAnswer: t.currentTarget.dataset.ind,
                    answer: t.currentTarget.dataset.answer
                }, wx.setStorage({
                    key: r + "" + d.data.category,
                    data: l
                }), d.setData({
                    StorageAll: l
                });
                var u = d.data.allNum;
                if (u++, t.currentTarget.dataset.ind == t.currentTarget.dataset.answer) {
                    (0, a.playAudio)("audios/correct.mp3"), (h = d.data.orderPX)[t.currentTarget.dataset.id] = "green", 
                    h.all = u, wx.setStorageSync(r + "list" + d.data.category, h);
                    var g = d.data.greenNum;
                    g++, d.setData({
                        greenNum: g
                    });
                    var c = wx.getStorageSync("rightRemove");
                    console.log(c), c ? (d.delCollect(), d.data.indexInd < e.length - 1 && 0 !== d.data.indexInd && d.autoPlay()) : d.data.indexInd < e.length - 1 && d.autoPlay();
                } else if (t.currentTarget.dataset.ind != t.currentTarget.dataset.answer) {
                    var h;
                    (0, a.playAudio)("audios/wrong.mp3"), (h = d.data.orderPX)[t.currentTarget.dataset.id] = "red", 
                    h.all = u, wx.setStorageSync(r + "list" + d.data.category, h);
                    var y = d.data.redNum;
                    y++, d.setData({
                        redNum: y
                    });
                }
                d.questionStatus();
            }
        }
    },
    selectAnswerMore: function(a) {
        var t = this;
        if ("1" != t.data.questions[t.data.current].order.subup) {
            var e = t.data.StorageAll, d = t.data.moreArr;
            d[a.currentTarget.dataset.ind] ? d[a.currentTarget.dataset.ind] = !1 : d[a.currentTarget.dataset.ind] = !0, 
            e[a.currentTarget.dataset.id] = {
                subup: 0,
                down: d
            }, t.setData({
                moreArr: d
            }), wx.setStorage({
                key: r + "" + this.data.category,
                data: e
            }), wx.getStorage({
                key: r + "" + this.data.category,
                success: function(a) {
                    t.setData({
                        StorageAll: a.data
                    });
                }
            });
            var n = t.data.questions;
            n[t.data.current].order = e[a.currentTarget.dataset.id], t.setData({
                questions: n
            });
        }
    },
    moreSelectSub: function(t) {
        var d = this, n = d.data.indexInd + 1, s = d.data.idarr[n];
        !function a() {
            if (s = d.data.idarr[n], n < d.data.idarr.length - 1) {
                if ("green" != d.data.orderPX[s] && "red" != d.data.orderPX[s]) {
                    wx.setStorage({
                        key: r + "ind" + d.data.category,
                        data: n
                    });
                    var t = d.data.orderPX;
                    for (var e in t) "blue" == t[e] && (t[e] = "");
                    return t[s] = "blue", d.setData({
                        orderPX: t
                    }), void console.log(d.data.orderPX);
                }
                n++, a();
            } else wx.setStorage({
                key: r + "ind" + d.data.category,
                data: d.data.idarr.length - 1
            });
        }();
        var i = d.data.StorageAll, o = d.data.moreArr, l = 0, u = "";
        for (var g in d.data.moreArr) d.data.moreArr[g] && (l++, u += g);
        i[t.currentTarget.dataset.id] = {
            subup: 1,
            down: o,
            downAnswer: u
        }, console.log(i[t.currentTarget.dataset.id]), d.setData({
            StorageAll: i
        }), wx.setStorage({
            key: r + "" + d.data.category,
            data: i
        });
        var c = d.data.questions, h = e;
        h[d.data.indexInd].order = {
            subup: 1,
            down: o,
            downAnswer: u
        }, c[d.data.current].order = {
            subup: 1,
            down: o,
            downAnswer: u
        }, e = h, d.setData({
            questions: c
        });
        var y = 0;
        for (var w in d.data.moreArr) d.data.moreArr[w] && y++;
        l = d.data.allNum;
        if (l++, y == t.currentTarget.dataset.answer.length && u == t.currentTarget.dataset.answer) {
            (v = d.data.orderPX)[t.currentTarget.dataset.id] = "green", v.all = l, wx.setStorageSync(r + "list" + d.data.category, v), 
            (0, a.playAudio)("audios/correct.mp3");
            var x = d.data.greenNum;
            x++, d.setData({
                greenNum: x
            }), d.questionStatus(), d.data.indexInd < e.length - 1 && d.autoPlay();
        } else {
            var v = d.data.orderPX;
            v[t.currentTarget.dataset.id] = "red", v.all = l, wx.setStorageSync(r + "list" + d.data.category, v), 
            (0, a.playAudio)("audios/wrong.mp3");
            var f = d.data.redNum;
            f++, d.setData({
                redNum: f
            }), d.questionStatus();
        }
        d.setData({
            moreArr: {
                A: !1,
                B: !1,
                C: !1,
                D: !1,
                E: !1,
                F: !1,
                G: !1,
                H: !1,
                I: !1,
                J: !1
            }
        });
    },
    fillSub: function(t) {
        if ("" == t.detail.value.subAnswer) return $Toast({
            content: "请输入答案"
        }), !1;
        var d = this, n = d.data.indexInd + 1, s = d.data.idarr[n];
        if (function a() {
            if (s = d.data.idarr[n], n < d.data.idarr.length - 1) {
                if ("green" != d.data.orderPX[s] && "red" != d.data.orderPX[s]) {
                    wx.setStorage({
                        key: r + "ind" + d.data.category,
                        data: n
                    });
                    var t = d.data.orderPX;
                    for (var e in t) "blue" == t[e] && (t[e] = "");
                    return t[s] = "blue", d.setData({
                        orderPX: t
                    }), void console.log(d.data.orderPX);
                }
                n++, a();
            } else wx.setStorage({
                key: r + "ind" + d.data.category,
                data: d.data.idarr.length - 1
            });
        }(), 4 == d.data.mode || 5 == d.data.mode) {
            var i = e, o = d.data.questions;
            if (d.data.StorageAll[d.data.idarr[d.data.indexInd]]) o[d.data.current].order = d.data.StorageAll[d.data.idarr[d.data.indexInd]], 
            d.setData({
                questions: o
            }); else {
                i[d.data.indexInd].order = {
                    after: 0,
                    downAnswer: t.detail.value.subAnswer,
                    answer: t.detail.value.answer,
                    subup: 1
                }, o[d.data.current].order = {
                    after: 0,
                    downAnswer: t.detail.value.subAnswer,
                    answer: t.detail.value.answer,
                    subup: 1
                }, e = i, d.setData({
                    questions: o
                });
                var l = d.data.StorageAll;
                l[t.detail.value.id] = {
                    after: 0,
                    downAnswer: t.detail.value.subAnswer,
                    answer: t.detail.value.answer,
                    subup: 1
                }, wx.setStorage({
                    key: r + "" + d.data.category,
                    data: l
                }), d.setData({
                    StorageAll: l
                });
                var u = d.data.allNum;
                if (u++, t.detail.value.subAnswer == t.detail.value.answer) {
                    (0, a.playAudio)("audios/correct.mp3"), (h = d.data.orderPX)[t.detail.value.id] = "green", 
                    h.all = u, wx.setStorageSync(r + "list" + d.data.category, h);
                    var g = d.data.greenNum;
                    if (g++, d.setData({
                        greenNum: g
                    }), d.data.indexInd < e.length - 1) {
                        d.autoPlay();
                        var c = d.data.everyDay_all;
                        c++, d.setData({
                            everyDay_all: c
                        });
                    }
                } else if (t.detail.value.subAnswer != t.detail.value.answer) {
                    var h;
                    console.log(o), (0, a.playAudio)("audios/wrong.mp3"), getApp().setIdsStroage("errorids", d.data.category, "1", o[d.data.current].id.toString()), 
                    (h = d.data.orderPX)[t.detail.value.id] = "red", h.all = u, wx.setStorageSync(r + "list" + d.data.category, h);
                    var y = d.data.redNum;
                    y++, d.setData({
                        redNum: y
                    });
                }
                d.questionStatus();
            }
        }
    },
    moreFillSub: function(t) {
        for (var r = t.detail.value.answer.split(";"), d = 0, n = 0; n < r.length; n++) "" == t.detail.value["subAnswer" + n] && d++;
        if (d == r.length) return Toast.fail("请输入答案"), !1;
        var s = this, i = s.data.indexInd + 1, o = s.data.idarr[i];
        if (function a() {
            if (o = s.data.idarr[i], i < s.data.idarr.length - 1) {
                if ("green" != s.data.orderPX[o] && "red" != s.data.orderPX[o]) {
                    wx.setStorage({
                        key: mode + "ind" + s.data.category,
                        data: i
                    });
                    var t = s.data.orderPX;
                    for (var e in t) "blue" == t[e] && (t[e] = "");
                    return t[o] = "blue", s.setData({
                        orderPX: t
                    }), void console.log(s.data.orderPX);
                }
                i++, a();
            } else wx.setStorage({
                key: mode + "ind" + s.data.category,
                data: s.data.idarr.length - 1
            });
        }(), 4 == s.data.mode || 5 == s.data.mode) {
            var l = e, u = s.data.questions;
            if (s.data.StorageAll[s.data.idarr[s.data.indexInd]]) u[s.data.current].order = s.data.StorageAll[s.data.idarr[s.data.indexInd]], 
            s.setData({
                questions: u
            }); else {
                var g = [];
                for (n = 0; n < r.length; n++) g.push(t.detail.value["subAnswer" + n]);
                l[s.data.indexInd].order = {
                    after: 0,
                    downAnswer: g.join(";"),
                    answer: t.detail.value.answer,
                    subup: 1
                }, u[s.data.current].order = {
                    after: 0,
                    downAnswer: g.join(";"),
                    answer: t.detail.value.answer,
                    subup: 1
                }, question_d = l, s.setData({
                    questions: u
                });
                var c = s.data.StorageAll;
                c[t.detail.value.id] = {
                    after: 0,
                    downAnswer: g.join(";"),
                    answer: t.detail.value.answer,
                    subup: 1
                }, wx.setStorage({
                    key: mode + "" + s.data.category,
                    data: c
                }), s.setData({
                    StorageAll: c
                });
                var h = s.data.allNum, y = 0;
                for (n = 0; n < r.length; n++) t.detail.value["subAnswer" + n] == r[n] && y++;
                if (h++, y == r.length) {
                    (v = s.data.orderPX)[t.detail.value.id] = "green", v.all = h, wx.setStorageSync(mode + "list" + s.data.category, v), 
                    (0, a.playAudio)("audios/correct.mp3");
                    var w = s.data.greenNum;
                    if (w++, s.setData({
                        greenNum: w
                    }), s.data.indexInd < question_d.length - 1) {
                        s.autoPlay();
                        var x = s.data.everyDay_all;
                        x++, s.setData({
                            everyDay_all: x
                        });
                    }
                } else if (y != r.length) {
                    var v;
                    console.log(u), getApp().setIdsStroage("errorids", s.data.category, s.data.category, u[s.data.current].id.toString()), 
                    (v = s.data.orderPX)[t.detail.value.id] = "red", v.all = h, wx.setStorageSync(mode + "list" + s.data.category, v), 
                    (0, a.playAudio)("audios/wrong.mp3");
                    var f = s.data.redNum;
                    f++, s.setData({
                        redNum: f
                    });
                    var S = s.data.everyDay_error;
                    rParam += "," + t.detail.value.id;
                    x = s.data.everyDay_all;
                    S++, x++, s.setData({
                        everyDay_error: S,
                        everyDay_all: x
                    });
                }
                s.questionStatus();
            }
        }
    },
    questionStatus: function() {
        var a = this;
        wx.getStorage({
            key: r + "list" + n,
            success: function(t) {
                a.setData({
                    orderPX: t.data,
                    allNum: t.data.all
                });
            }
        });
    },
    autoPlay: function() {
        console.log("auto"), this.data.rightAutoNext && this.setData({
            autoplay: !0
        });
    },
    pageChange: function(a) {
        "autoplay" == a.detail.source && this.setData({
            autoplay: !1
        });
        var t = this;
        t.setData({
            moreArr: {
                A: !1,
                B: !1,
                C: !1,
                D: !1,
                E: !1,
                F: !1,
                G: !1,
                H: !1,
                I: !1,
                J: !1
            }
        }), e.length < 3 ? t.setData({
            xiejie: !1
        }) : t.setData({
            xiejie: !0
        }), 1 == e.length && t.setData({
            xiejie: !1,
            current: 0
        });
        var r = this.data.current, d = a.detail.current, n = t.data.indexInd, s = 1 * d - 1 * r;
        if (-2 == s ? s = 1 : 2 == s && (s = -1), (n += s) >= e.length) return n = 0, wx.showToast({
            title: "已经是最后一题了"
        }), void t.setData({
            xiejie: !1,
            current: 2
        });
        if (n < 0) return wx.showToast({
            title: "已经是第一题了"
        }), t.setData({
            xiejie: !1,
            current: 0
        }), void (n = e.length - 1);
        var i = [];
        e.length > 3 ? 0 == d ? (i.push(e[n]), i.push(e[n + 1]), i.push(e[n - 1]), i[1] || (i[1] = e[0]), 
        i[2] || (i[2] = e[e.length - 1])) : 1 == d ? (i.push(e[n - 1]), i.push(e[n]), i.push(e[n + 1]), 
        i[2] || (i[2] = e[0]), i[0] || (i[0] = e[e.length - 1])) : 2 == d && (i.push(e[n + 1]), 
        i.push(e[n - 1]), i.push(e[n]), i[0] || (i[0] = e[0]), i[1] || (i[1] = e[e.length - 1])) : i = e, 
        this.setData({
            questions: i,
            indexInd: n,
            current: d
        }), this.infoshow(e[n].id), console.log(i);
    },
    onReady: function() {},
    onShow: function() {
        var a = wx.getStorageSync("fontSize");
        a && this.setData({
            fontSize: a
        });
        var t = wx.getStorageSync("rightAutoNext");
        "" !== t && this.setData({
            rightAutoNext: t
        });
    },
    initBgm: function() {
        wx.getStorageSync("music") && (this.bgm = wx.createInnerAudioContext(), this.bgm.loop = !0, 
        this.bgm.autoplay = !1, this.bgm.src = i.globalData.bgmUrl, this.bgm.play());
    },
    onHide: function() {
        var a = this, t = [], e = [], r = [], d = [];
        wx.getStorage({
            key: "delstar" + a.data.category,
            success: function(a) {
                d = a.data;
            }
        }), wx.getStorage({
            key: "starids" + a.data.category,
            success: function(n) {
                console.log(d);
                for (var s = n.data, i = 0; i < d.length; i++) for (u = 0; u < s.length; u++) if (s[u][Object.keys(s[u]).toString()].indexOf(d[i]) > -1) {
                    var o = s[u][Object.keys(s[u]).toString()].indexOf(d[i]);
                    s[u][Object.keys(s[u]).toString()].splice(o, 1), 0 == s[u][Object.keys(s[u]).toString()].length && s.splice(u, 1);
                }
                wx.setStorage({
                    key: "starids" + a.data.category,
                    data: s
                }), wx.removeStorage({
                    key: "delstar" + a.data.category
                });
                for (var l = "", u = 0; u < s.length; u++) for (s[u][Object.keys(s[u]).toString()].toString() && (l += s[u][Object.keys(s[u]).toString()].toString() + ","), 
                i = 0; i < t.length; i++) Object.keys(s[u]).toString() == t[i].chapter_id && r.push({
                    title: t[i].title,
                    question_ids: s[u][Object.keys(s[u]).toString()]
                });
                e = "" != l ? [ {
                    title: "全部收藏",
                    question_ids: l.slice(0, -1).split(",")
                } ] : [ {
                    title: "全部收藏",
                    question_ids: []
                } ], a.setData({
                    errorAll: e,
                    errorEach: r
                });
            },
            fail: function() {}
        });
    },
    onUnload: function() {
        wx.getStorageSync("music") && this.bgm.pause();
        var a = this, t = [], e = [], r = [], d = [];
        wx.getStorage({
            key: "delstar" + a.data.category,
            success: function(a) {
                d = a.data;
            }
        }), wx.getStorage({
            key: "starids" + a.data.category,
            success: function(n) {
                console.log(d);
                for (var s = n.data, i = 0; i < d.length; i++) for (u = 0; u < s.length; u++) if (s[u][Object.keys(s[u]).toString()].indexOf(d[i]) > -1) {
                    var o = s[u][Object.keys(s[u]).toString()].indexOf(d[i]);
                    s[u][Object.keys(s[u]).toString()].splice(o, 1), 0 == s[u][Object.keys(s[u]).toString()].length && s.splice(u, 1);
                }
                wx.setStorage({
                    key: "starids" + a.data.category,
                    data: s
                }), wx.removeStorage({
                    key: "delstar" + a.data.category
                });
                for (var l = "", u = 0; u < s.length; u++) for (s[u][Object.keys(s[u]).toString()].toString() && (l += s[u][Object.keys(s[u]).toString()].toString() + ","), 
                i = 0; i < t.length; i++) Object.keys(s[u]).toString() == t[i].chapter_id && r.push({
                    title: t[i].title,
                    question_ids: s[u][Object.keys(s[u]).toString()]
                });
                e = "" != l ? [ {
                    title: "全部收藏",
                    question_ids: l.slice(0, -1).split(",")
                } ] : [ {
                    title: "全部收藏",
                    question_ids: []
                } ], a.setData({
                    errorAll: e,
                    errorEach: r
                });
            },
            fail: function() {}
        });
    },
    delCollect: function() {
        console.log(111);
        var a = this.data.idarr, t = this.data.greenNum, r = this.data.redNum;
        console.log(this.data.orderPX[a[this.data.indexInd]]), "red" == this.data.orderPX[a[this.data.indexInd]] ? r-- : "green" == this.data.orderPX[a[this.data.indexInd]] && t--;
        for (var d = this.data.collectData, n = 0; n < d.length; n++) if (d[n][Object.keys(d[n]).toString()].indexOf(a[this.data.indexInd]) > -1) {
            var s = d[n][Object.keys(d[n]).toString()].indexOf(a[this.data.indexInd]);
            d[n][Object.keys(d[n]).toString()].splice(s, 1), 0 == d[n][Object.keys(d[n]).toString()].length && d.splice(n, 1);
        }
        4 == this.data.mode ? wx.setStorage({
            key: "starids" + this.data.category,
            data: d
        }) : wx.setStorage({
            key: "errorids" + this.data.category,
            data: d
        }), e.splice(this.data.indexInd, 1), a.splice(this.data.indexInd, 1);
        var i = this.data.questions;
        i.splice(this.data.current, 1), this.setData({
            idarr: a,
            question: i,
            iconcircle: [ {
                title: "",
                question_ids: a,
                len: 0
            } ],
            greenNum: t,
            redNum: r
        }), 0 != this.data.indexInd && this.setData({
            indexInd: this.data.indexInd - 1
        }), 2 == e.length && this.setData({
            current: 1
        }), this.pageChange({
            detail: {
                current: this.data.current
            }
        }), 0 == e.length && wx.navigateBack({
            delta: 1
        });
    },
    del_data: function() {
        var a = this;
        console.log(this.data.del_chapter_id);
        var t = wx.getStorageInfoSync("errorids" + n), e = [];
        t && (0 == t.length || "all" == this.data.del_chapter_id ? (wx.setStorage({
            key: "errorids" + n,
            data: []
        }), wx.navigateBack({
            delta: 1
        })) : (t.forEach(function(t, r) {
            Object.keys(t)[0] != a.data.del_chapter_id && e.push(t);
        }), wx.setStorage({
            key: "errorids" + n,
            data: e
        }), wx.navigateBack({
            delta: 1
        })));
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: "智慧考题宝，考试助手 ！",
            path: "pages/index/index",
            imageUrl: "/images/share.png"
        };
    }
});