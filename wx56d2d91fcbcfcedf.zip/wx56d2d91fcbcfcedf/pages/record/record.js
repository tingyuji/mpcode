var t = require("../../24076A57C080688C42610250BE2B08D6.js");

Page({
    data: {
        page: 1,
        limit: 10,
        nodata: !0,
        recordList: [],
        moreData: !0
    },
    onLoad: function(t) {
        var e = wx.getStorageSync("userInfo");
        this.setData({
            userInfo: e
        }), this.getRecord(this.data.page, this.data.limit, e.uid);
    },
    getRecord: function(t, e, a) {
        var i = this;
        wx.showLoading({
            title: "加载中",
            mask: !0,
            icon: "loading"
        }), wx.Apis.api.getUserRecord(t, e, a, function(t, e) {
            var a = i.data.recordList, o = i.data.page;
            console.log(e.length), e.length ? (e.forEach(function(t) {
                a.push(t);
            }), i.setData({
                recordList: a,
                page: o + 1,
                nodata: !1
            })) : i.setData({
                recordList: a,
                moreData: !1
            }), setTimeout(function() {
                wx.hideLoading({
                    success: function(t) {}
                });
            }, 1e3);
        });
    },
    getRecordDetail: function(e) {
        var a = this;
        wx.showLoading({
            title: "加载中"
        });
        var i = e.currentTarget.dataset.id;
        wx.Apis.api.getRecordDetail(i, function(e, i) {
            (console.log(i), wx.setStorage({
                key: "examids" + i.id,
                data: i.ids
            }), wx.setStorage({
                key: "examlist" + i.id,
                data: i.list
            }), wx.setStorage({
                key: "exam" + i.id,
                data: i.record
            }), wx.getStorageSync("question_" + i.category)) ? wx.getStorageSync("question_update_time_" + i.category) < i.q_update_time ? a.uploadQuestion(i.category, i.id, i.ids) : (t.initAllQuestionFromStorage(i.category), 
            wx.navigateTo({
                url: "/pages/exam/exam?id=" + i.id + "&timeback=1"
            })) : a.uploadQuestion(i.category, i.id, i.ids);
        });
    },
    uploadQuestion: function(e, a, i) {
        wx.Apis.api.getQuestionList(e, function(i, o) {
            wx.setStorageSync("question_id_" + e, o.question_id), wx.setStorageSync("question_" + e, o.question_list), 
            wx.setStorageSync("question_update_time_" + e, o.q_update_time), t.initAllQuestionFromStorage(e), 
            wx.navigateTo({
                url: "/pages/exam/exam?id=" + a + "&timeback=1"
            });
        });
    },
    onShow: function() {},
    onReachBottom: function() {
        this.data.moreData && this.getRecord(this.data.page, this.data.limit, this.data.userInfo.uid);
    },
    onShareAppMessage: function() {
        return {
            title: "智慧考题宝，考试助手 ！",
            path: "pages/index/index",
            imageUrl: "/images/share.png"
        };
    }
});