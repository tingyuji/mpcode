var t = getApp();

Page({
    data: {
        bannerList: [],
        firstCategory1: [],
        firstCategory2: [],
        notice: ""
    },
    onLoad: function() {
        var t = this;
        wx.Apis.api.bannerList(function(e, a) {
            t.setData({
                bannerList: a,
                notice: wx.getStorageSync("notice")
            });
        }), wx.Apis.api.firstShowCategory(function(e, a) {
            var r = [], n = [];
            if (a.length < 4) {
                for (var i = 0; i < 3; i++) r.push(a[i]);
                r.push({
                    id: 0,
                    name: "更多",
                    pic_url: ""
                });
            } else {
                for (var o = 0; o < 4; o++) r.push(a[o]);
                if (a.length >= 8) for (var s = 4; s < 7; s++) n.push(a[s]); else for (var g = 4; g < a.length; g++) n.push(a[g]);
                n.push({
                    id: 0,
                    name: "更多",
                    pic_url: "https://treasure.mambaxin.com/uploads/question/20221110/636d1b7192033.png"
                });
            }
            console.log(r), t.setData({
                firstCategory1: r,
                firstCategory2: n
            });
        });
    },
    onShow: function() {
        wx.getStorageSync("userInfo") && this.setData({
            myCategory: wx.getStorageSync("myCategory")
        });
    },
    goCategry: function(e) {
        var a = e.currentTarget.dataset.id;
        t.globalData.mainActiveIndex = a, wx.switchTab({
            url: "/pages/category/category"
        });
    },
    goDetail: function(t) {
        wx.navigateTo({
            url: "/pages/detail/detail?id=" + t.currentTarget.dataset.id + "&name=" + t.currentTarget.dataset.name + "&time=" + t.currentTarget.dataset.time
        });
    },
    onShareAppMessage: function() {
        return {
            title: "智慧考题宝，考试助手 ！",
            path: "pages/index/index",
            imageUrl: "/images/share.png"
        };
    }
});