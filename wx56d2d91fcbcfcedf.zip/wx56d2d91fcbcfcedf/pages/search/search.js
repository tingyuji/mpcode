Page({
    data: {
        page: 1,
        limit: 15,
        nodata: !1,
        moreData: !0,
        keyword: "",
        questionList: []
    },
    onLoad: function(t) {
        this.setData({
            id: t.id
        });
    },
    onReady: function() {},
    onShow: function() {},
    onChange: function(t) {
        this.setData({
            keyword: t.detail
        });
    },
    onSearch: function() {
        "" != this.data.keyword && (this.setData({
            questionList: []
        }), this.getQuestion(1, this.data.limit));
    },
    question: function(t) {
        wx.navigateTo({
            url: "/pages/question/question?id=" + t.currentTarget.dataset.id + "&category=" + this.data.id
        });
    },
    getQuestion: function(t, a) {
        var e = this, i = this;
        wx.showLoading({
            title: "加载中",
            mask: !0,
            icon: "loading"
        }), wx.Apis.api.getSearchQuestion(i.data.id, i.data.keyword, t, a, function(t, a) {
            var n = i.data.questionList, o = i.data.page;
            a.length ? a.forEach(function(t) {
                switch (t.type) {
                  case 1:
                    t.typeName = "单选题";
                    break;

                  case 2:
                    t.typeName = "多选题";
                    break;

                  case 3:
                    t.typeName = "判断题";
                    break;

                  case 4:
                    t.typeName = "单项填空题";
                    break;

                  case 5:
                    t.typeName = "多项填空题";
                    break;

                  default:
                    t.typeName = "简答题";
                }
                n.push(t), i.setData({
                    questionList: n,
                    page: o + 1,
                    nodata: !1
                });
            }) : i.setData({
                questionList: n,
                moreData: !1,
                nodata: 1 == e.data.page
            }), setTimeout(function() {
                wx.hideLoading({
                    success: function(t) {}
                });
            }, 1500);
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {
        this.data.moreData && this.getQuestion(this.data.page, this.data.limit);
    },
    onShareAppMessage: function() {
        return {
            title: "智慧考题宝，考试助手 ！",
            path: "pages/index/index",
            imageUrl: "/images/share.png"
        };
    }
});