var e = require("../../24076A57C080688C42610250BE2B08D6.js");

Page({
    data: {},
    onLoad: function(e) {
        var t = wx.getStorageSync("userInfo");
        this.setData({
            title: e.title,
            score: e.score,
            green: e.green,
            right: e.right,
            time: e.time,
            nickName: t.nickName,
            avatarUrl: t.avatarUrl,
            record: e.record,
            category_id: e.id
        });
    },
    onReady: function() {},
    onShow: function() {},
    getRecordDetail: function(t) {
        var i = this;
        wx.showLoading({
            title: "加载中"
        });
        var a = t.currentTarget.dataset.id;
        wx.Apis.api.getRecordDetail(a, function(t, a) {
            (console.log(a), wx.setStorage({
                key: "examids" + a.id,
                data: a.ids
            }), wx.setStorage({
                key: "examlist" + a.id,
                data: a.list
            }), wx.setStorage({
                key: "exam" + a.id,
                data: a.record
            }), wx.getStorageSync("question_" + a.category)) ? wx.getStorageSync("question_update_time_" + a.category) < a.q_update_time ? i.uploadQuestion(a.category, a.id, a.ids) : (e.initAllQuestionFromStorage(a.category), 
            wx.navigateTo({
                url: "/pages/exam/exam?id=" + a.id + "&timeback=1"
            })) : i.uploadQuestion(a.category, a.id, a.ids);
        });
    },
    goRank: function() {
        wx.navigateTo({
            url: "/pages/rank/rank?id=" + this.data.activity
        });
    },
    uploadQuestion: function(t, i, a) {
        wx.Apis.api.getQuestionList(t, function(a, o) {
            wx.setStorageSync("question_id_" + t, o.question_id), wx.setStorageSync("question_" + t, o.question_list), 
            wx.setStorageSync("question_update_time_" + t, o.q_update_time), e.initAllQuestionFromStorage(t), 
            wx.navigateTo({
                url: "/pages/exam/exam?id=" + i + "&timeback=1"
            });
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: "智慧考题宝，考试助手 ！",
            path: "pages/index/index",
            imageUrl: "/images/share.png"
        };
    }
});