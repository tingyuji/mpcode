require("../../24076A57C080688C42610250BE2B08D6.js");

var t = "exam";

Page({
    data: {
        detail: ""
    },
    onLoad: function(a) {
        var i = this;
        i.setData({
            id: a.id,
            action: a.action,
            q_update_time: a.q_update_time
        }), t = "activity" == a.action ? "activity" : "exam", wx.showLoading({
            title: "加载中",
            mask: !0
        }), wx.Apis.api.getCategoryDetail(a.id, function(t, a) {
            i.setData({
                detail: a
            }), setTimeout(function() {
                wx.hideLoading({
                    success: function(t) {}
                });
            }, 1e3);
        });
    },
    onReady: function() {},
    onShow: function() {},
    examGo: function(a) {
        var i = this, e = "/pages/exam/exam?id=" + i.data.id + "&q_update_time=" + i.data.q_update_time, o = t + "ind" + ("activity" == i.data.action ? i.data.activity : i.data.id), n = wx.getStorageSync(o) ? wx.getStorageSync(o) + 1 : "", c = "exam_up" + i.data.id;
        !(wx.getStorageSync(c) || "") && n ? (wx.hideLoading({}), wx.showModal({
            title: "",
            cancelText: "重新考试",
            confirmText: "继续答题",
            content: "上次考试您已经做到第" + n + "题,重新考试答题记录会丢失~",
            success: function(t) {
                t.confirm ? (e += "&continued=1", setTimeout(function() {
                    wx.redirectTo({
                        url: e
                    });
                }, 1e3)) : i.clear_storage(e);
            }
        })) : i.clear_storage(e);
    },
    clear_storage: function(a) {
        console.log(t + "list" + ("activity" == this.data.action ? this.data.activity : this.data.id)), 
        wx.removeStorage({
            key: t + ("activity" == this.data.action ? this.data.activity : this.data.id)
        }), wx.removeStorage({
            key: t + "list" + ("activity" == this.data.action ? this.data.activity : this.data.id)
        }), wx.removeStorage({
            key: t + "ind" + ("activity" == this.data.action ? this.data.activity : this.data.id)
        }), wx.removeStorage({
            key: t + "ids" + ("activity" == this.data.action ? this.data.activity : this.data.id)
        }), wx.removeStorage({
            key: t + "all" + ("activity" == this.data.action ? this.data.activity : this.data.id)
        }), wx.removeStorage({
            key: t + "times" + ("activity" == this.data.action ? this.data.activity : this.data.id)
        }), setTimeout(function() {
            wx.hideLoading({
                success: function(t) {}
            }), wx.redirectTo({
                url: a
            });
        }, 1e3);
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: "智慧考题宝，考试助手 ！",
            path: "pages/index/index",
            imageUrl: "/images/share.png"
        };
    }
});