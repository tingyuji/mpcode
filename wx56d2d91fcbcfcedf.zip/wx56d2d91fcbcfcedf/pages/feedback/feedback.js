Page({
    data: {
        feedback_template_id: "",
        title: "",
        content: ""
    },
    onLoad: function(t) {
        var e = this;
        wx.showLoading({
            title: "加载中",
            mask: !0
        }), wx.Apis.api.getConfigValue("feedback_template_id", function(t, n) {
            e.setData({
                feedback_template_id: n.value
            }), wx.hideLoading({});
        });
    },
    onReady: function() {},
    onShow: function() {},
    bindTextAreaInputTitle: function(t) {
        console.log(t.detail.value), this.setData({
            title: t.detail.value
        });
    },
    bindTextAreaInputContent: function(t) {
        console.log(t.detail.value), this.setData({
            content: t.detail.value
        });
    },
    bindsubmit: function(t) {
        console.log(t);
        var e = {
            content: this.data.content,
            title: this.data.title
        };
        if ("" == e.content || "" == e.title) return wx.showToast({
            icon: "error",
            title: "请填写完整"
        }), !1;
        var n = [];
        n.push(this.data.feedback_template_id), console.log(n), wx.requestSubscribeMessage({
            tmplIds: n,
            success: function(t) {
                console.log(t);
            },
            complete: function() {
                wx.showLoading({
                    title: "正在提交"
                });
                var t = wx.Apis.get("userInfo");
                e.uid = t.uid, wx.Apis.api.saveFeedback(e, function(t, e) {
                    wx.hideLoading({}), 200 == t ? wx.showModal({
                        title: "反馈成功",
                        content: "已经收到您的反馈，我们会尽快处理！",
                        showCancel: !1,
                        confirmText: "关闭",
                        confirmColor: "#46C6BA",
                        success: function(t) {
                            wx.navigateBack();
                        }
                    }) : wx.showToast({
                        icon: "error",
                        title: "提交失败"
                    });
                });
            }
        });
    },
    onShareAppMessage: function() {
        return {
            title: "考题星，考试助手 ！",
            path: "pages/index/index",
            imageUrl: "/images/share.png"
        };
    }
});