var t = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../CAC2FE40C080688CACA49647E8EA08D6.js")), e = require("../../24076A57C080688C42610250BE2B08D6.js");

require("../../A1A19363C080688CC7C7FB64F21B08D6.js");

Page({
    data: {
        isLogin: !1,
        canIUseGetUserProfile: !1,
        show: !1
    },
    onLoad: function(t) {
        var e = this, a = wx.getStorageSync("orderind" + t.id);
        this.setData({
            id: t.id,
            name: t.name,
            count: t.count,
            q_update_time: t.time,
            index: a || 0
        }), console.log(t);
        var i = wx.getStorageSync("openid");
        "" != i && null != i || wx.login({
            success: function(t) {
                t.code && (console.log(t.code), wx.Apis.login.login(t.code, function(t, a) {
                    console.log(a), wx.Apis.setUid(a.openid), wx.Apis.set("openid", a.openid), wx.setStorageSync("userInfo", a), 
                    e.setData({
                        userInfo: a
                    });
                }));
            }
        }), this.checkQuestion();
    },
    onReady: function() {},
    onShow: function() {
        this.setData({
            userInfo: wx.getStorageSync("userInfo")
        });
    },
    checkQuestion: function() {
        wx.showLoading({
            title: "加载中"
        });
        if (wx.getStorageSync("question_" + this.data.id)) {
            var t = wx.getStorageSync("question_update_time_" + this.data.id);
            console.log(t), console.log(this.data.q_update_time), t < parseInt(this.data.q_update_time) ? (console.log(11), 
            this.uploadQuestion()) : (e.initAllQuestionFromStorage(this.data.id), setTimeout(function() {
                wx.hideLoading({});
            }, 1e3));
        } else this.uploadQuestion();
    },
    uploadQuestion: function() {
        var t = this;
        wx.Apis.api.getQuestionList(t.data.id, function(a, i) {
            wx.setStorageSync("question_id_" + t.data.id, i.question_id), wx.setStorageSync("question_" + t.data.id, i.question_list), 
            wx.setStorageSync("question_update_time_" + t.data.id, i.q_update_time), e.initAllQuestionFromStorage(t.data.id), 
            setTimeout(function() {
                wx.hideLoading({});
            }, 1e3);
        });
    },
    goAction: function(t) {
        var e = this;
        if (console.log(t.currentTarget.dataset.action), null == this.data.userInfo.nickName || "" == this.data.userInfo.nickName) return this.login(), 
        !1;
        var a = wx.getStorageSync("checkUser");
        if ("true" == a && 1 == this.data.userInfo.status) return wx.showToast({
            icon: "none",
            title: "您的信息正在审核中"
        }), !1;
        if ("true" == a && 0 == this.data.userInfo.status) return wx.navigateTo({
            url: "/pages/userInfo/userInfo"
        }), !1;
        if (this.data.userInfo.is_del) return wx.showToast({
            icon: "none",
            title: "账号已被禁用"
        }), !1;
        var i = wx.getStorageSync("userInfo");
        wx.Apis.api.isUseCode(this.data.id, i.uid, function(a, s) {
            s.is_use_code ? s.have_code ? e.goDetail(t.currentTarget.dataset.action) : wx.showModal({
                title: "提示",
                editable: !0,
                placeholderText: "请输入激活码",
                success: function(t) {
                    if (t.confirm) {
                        var a = t.content;
                        wx.Apis.api.activate(e.data.id, i.uid, a, function(t, e) {
                            console.log(t), 200 == t ? wx.showToast({
                                title: "激活成功"
                            }) : wx.showToast({
                                icon: "error",
                                title: "激活失败"
                            });
                        });
                    } else console.log("用户点击了取消");
                }
            }) : e.goDetail(t.currentTarget.dataset.action);
        });
    },
    goDetail: function(e) {
        var a = "";
        switch (e) {
          case "learn":
            a = "/pages/learn/learn?id=" + this.data.id + "&mode=2&type=1&name=" + this.data.name + "&q_update_time=" + this.data.q_update_time;
            break;

          case "exam":
            a = "/pages/examhome/examhome?id=" + this.data.id + "&action=exam&q_update_time=" + this.data.q_update_time;
            break;

          case "high":
            a = "/pages/learn/learn?id=" + this.data.id + "&mode=2&type=5&name=" + this.data.name + "&q_update_time=" + this.data.q_update_time;
            break;

          case "random":
            a = "/pages/learn/learn?id=" + this.data.id + "&mode=2&type=2&name=" + this.data.name + "&q_update_time=" + this.data.q_update_time;
            break;

          case "type":
            a = "/pages/list/list?id=" + this.data.id + "&type=4&name=" + this.data.name + "&q_update_time=" + this.data.q_update_time;
            break;

          case "earmark":
            a = "/pages/list/list?id=" + this.data.id + "&type=3&name=" + this.data.name + "&q_update_time=" + this.data.q_update_time;
            break;

          case "error":
            var i = wx.getStorageSync("errorids" + this.data.id);
            if (!(i && i.length > 0)) return t.default.fail("暂无错题记录"), !1;
            a = "/pages/errorstar/errorstar?id=" + this.data.id + "&mode=5";
            break;

          case "star":
            var s = wx.getStorageSync("starids" + this.data.id);
            if (!(s && s.length > 0)) return t.default.fail("暂无收藏记录"), !1;
            a = "/pages/errorstar/errorstar?id=" + this.data.id + "&mode=4";
            break;

          case "show":
            a = "/pages/learn/learn?id=" + this.data.id + "&mode=3&type=1&name=" + this.data.name + "&q_update_time=" + this.data.q_update_time;
            break;

          case "rank":
            a = "/pages/rank/rank?id=" + this.data.id;
            break;

          default:
            a = "/pages/search/search?id=" + this.data.id + "&name=" + this.data.name + "&q_update_time=" + this.data.q_update_time;
        }
        wx.navigateTo({
            url: a
        });
    },
    login: function() {
        this.setData({
            isLogin: !this.data.isLogin
        });
    },
    onMyEvent: function(t) {
        this.login();
    },
    onShareAppMessage: function() {}
});