Page({
    data: {
        rankList: [],
        page: 1,
        limit: 20,
        nodata: !0,
        moreData: !0
    },
    onLoad: function(t) {
        console.log(t.id), this.setData({
            id: t.id
        }), this.getRankList(t.id, this.data.page, this.data.limit);
    },
    onReady: function() {},
    onShow: function() {},
    goBack: function() {
        wx.navigateBack({});
    },
    getRankList: function(t, a, i) {
        var n = this;
        wx.showLoading({
            title: "加载中",
            mask: !0
        });
        var e = {
            id: t,
            page: a,
            limit: i
        };
        wx.Apis.api.getRankList(e, function(t, a) {
            var i = n.data.rankList, e = n.data.page;
            console.log(a.length), a.length ? (a.forEach(function(t) {
                i.push(t);
            }), n.setData({
                rankList: i,
                page: e + 1,
                nodata: !1
            })) : n.setData({
                rankList: i,
                moreData: !1
            }), setTimeout(function() {
                wx.hideLoading({
                    success: function(t) {}
                });
            }, 1500);
        });
    },
    onReachBottom: function() {
        this.data.moreData && this.getRankList(this.data.id, this.data.page, this.data.limit);
    },
    onShareAppMessage: function() {
        return {
            title: "考题星，考试助手 ！",
            path: "pages/index/index",
            imageUrl: "/images/share.png"
        };
    }
});