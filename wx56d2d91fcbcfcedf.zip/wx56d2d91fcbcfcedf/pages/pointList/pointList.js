Page({
    data: {
        page: 1,
        limit: 15,
        nodata: !0,
        integralList: [],
        moreData: !0
    },
    onLoad: function(t) {
        var a = wx.getStorageSync("userInfo");
        this.setData({
            userInfo: a
        }), this.getIntegral(this.data.page, this.data.limit, a.uid);
    },
    getIntegral: function(t, a, n) {
        var e = this;
        wx.showLoading({
            title: "加载中",
            mask: !0,
            icon: "loading"
        }), wx.Apis.api.getUserIntegral(t, a, n, function(t, a) {
            var n = e.data.integralList, i = e.data.page;
            console.log(a.length), a.length ? (a.forEach(function(t) {
                n.push(t);
            }), e.setData({
                integralList: n,
                page: i + 1,
                nodata: !1
            })) : e.setData({
                integralList: n,
                moreData: !1
            }), setTimeout(function() {
                wx.hideLoading({
                    success: function(t) {}
                });
            }, 1e3);
        });
    },
    onReady: function() {},
    onShow: function() {
        this.setData({
            userInfo: wx.getStorageSync("userInfo")
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {
        this.data.moreData && this.getIntegral(this.data.page, this.data.limit, this.data.userInfo.uid);
    },
    onShareAppMessage: function() {
        return {
            title: "智慧考题宝，考试助手 ！",
            path: "pages/index/index",
            imageUrl: "/images/share.png"
        };
    }
});