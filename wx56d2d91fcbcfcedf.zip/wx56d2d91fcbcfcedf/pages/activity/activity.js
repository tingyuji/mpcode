var t = require("../../0F2098F4C080688C6946F0F37D4B08D6.js");

Page({
    data: {
        nodata: !1,
        activityList: []
    },
    onLoad: function(t) {
        this.getActivity(this.data.page, this.data.limit);
    },
    onReady: function() {},
    onShow: function() {},
    getActivity: function(i, a) {
        var e = this;
        wx.showLoading({
            title: "加载中",
            mask: !0,
            icon: "loading"
        }), wx.Apis.api.getActivityList(i, a, function(i, a) {
            var n = e.data.activityList, s = e.data.page;
            console.log(a.length), a.length ? (a.forEach(function(i) {
                i.status = t.judgeDate(i.start_time, i.end_time), i.start = i.start_time.substr(0, 16), 
                i.end = i.end_time.substr(0, 16), n.push(i);
            }), console.log(n), e.setData({
                activityList: n,
                page: s + 1,
                nodata: !1
            })) : e.setData({
                activityList: n,
                moreData: !1
            }), setTimeout(function() {
                wx.hideLoading({
                    success: function(t) {}
                });
            }, 1500);
        });
    },
    onShareAppMessage: function() {
        return {
            title: "智慧考题宝，考试助手 ！",
            path: "pages/index/index",
            imageUrl: "/images/share.png"
        };
    }
});