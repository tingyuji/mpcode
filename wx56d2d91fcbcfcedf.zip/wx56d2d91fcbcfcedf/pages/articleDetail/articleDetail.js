Page({
    data: {},
    onLoad: function(n) {
        var i = this;
        wx.Apis.api.getArticleDetail(n.id, function(n, t) {
            i.setData({
                detail: t
            });
        }), wx.Apis.api.addArticleRead(n.id, function(n, i) {});
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: "智慧考题宝，考试助手 ！",
            path: "pages/index/index",
            imageUrl: "/images/share.png"
        };
    }
});