Page({
    data: {
        list: [],
        nodata: !0
    },
    onLoad: function(n) {
        var t = this, o = wx.getStorageSync("userInfo");
        wx.Apis.api.userCodeList(o.uid, function(n, o) {
            o.length && t.setData({
                nodata: !1
            }), t.setData({
                list: o
            });
        });
    },
    copy: function(n) {
        wx.setClipboardData({
            data: n.currentTarget.dataset.code,
            success: function(n) {}
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});