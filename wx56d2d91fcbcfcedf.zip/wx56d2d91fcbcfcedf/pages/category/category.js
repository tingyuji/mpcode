var t = getApp();

Page({
    data: {
        items: [],
        mainActiveIndex: 0,
        activeId: null
    },
    onLoad: function(a) {
        var e = this;
        wx.showLoading({}), wx.Apis.api.firstCategoryList(function(a, i) {
            wx.hideLoading({}), e.setData({
                items: i
            }), 0 == t.globalData.mainActiveIndex ? e.setData({
                mainActiveIndex: 0,
                firstCategoryName: i[0].text
            }) : i.forEach(function(a, i) {
                a.id == t.globalData.mainActiveIndex && e.setData({
                    mainActiveIndex: i,
                    firstCategoryName: a.text
                });
            });
        });
    },
    onReady: function() {},
    onShow: function() {
        var a = this;
        a.setData({
            activeId: null
        }), a.data.items.length && (0 == t.globalData.mainActiveIndex ? a.setData({
            mainActiveIndex: 0,
            firstCategoryName: a.data.items[0].text
        }) : a.data.items.forEach(function(e, i) {
            e.id == t.globalData.mainActiveIndex && a.setData({
                mainActiveIndex: i,
                firstCategoryName: a.data.items[i].text
            });
        }));
    },
    onClickNav: function(a) {
        var e = a.detail, i = (void 0 === e ? {} : e).index || 0;
        t.globalData.mainActiveIndex = this.data.items[i].id, this.setData({
            mainActiveIndex: i,
            firstCategoryName: this.data.items[i].text
        });
    },
    goCategory: function(t) {
        var a = t.detail, e = void 0 === a ? {} : a, i = this.data.activeId === e.id ? null : e.id;
        console.log(this.data.firstCategoryName), console.log(i), this.setData({
            activeId: i
        }), wx.navigateTo({
            url: "/pages/course/course?id=" + i + "&firstCategoryName=" + this.data.firstCategoryName + "&secondCategoryName=" + e.text
        });
    },
    onShareAppMessage: function() {
        return {
            title: "智慧考题宝，考试助手 ！",
            path: "pages/index/index",
            imageUrl: "/images/share.png"
        };
    }
});