Page({
    data: {
        list: []
    },
    onLoad: function(t) {
        var n = this;
        n.setData({
            category: t.id,
            type: t.type,
            name: t.name,
            q_update_time: t.q_update_time
        }), 3 == t.type ? wx.Apis.api.getEarmarkList(t.id, function(t, e) {
            n.setData({
                list: e
            });
        }) : wx.Apis.api.getTypeList(t.id, function(t, e) {
            n.setData({
                list: e
            });
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: "智慧考题宝，考试助手 ！",
            path: "pages/index/index",
            imageUrl: "/images/share.png"
        };
    }
});