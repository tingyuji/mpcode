require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../CAC2FE40C080688CACA49647E8EA08D6.js"));

Page({
    data: {
        isLogin: !1,
        canIUseGetUserProfile: !1,
        show: !1,
        actions: [ {
            name: "复制开发者微信号"
        }, {
            name: "复制开发者QQ号"
        } ]
    },
    onLoad: function(n) {
        var e = this, i = wx.getStorageSync("openid");
        "" != i && null != i || wx.login({
            success: function(n) {
                n.code && (console.log(n.code), wx.Apis.login.login(n.code, function(n, i) {
                    console.log(i), wx.Apis.setUid(i.openid), wx.Apis.set("openid", i.openid), wx.setStorageSync("userInfo", i), 
                    e.setData({
                        userInfo: i
                    });
                }));
            }
        });
    },
    onReady: function() {},
    onShow: function() {
        this.setData({
            userInfo: wx.getStorageSync("userInfo")
        });
    },
    login: function() {
        this.setData({
            isLogin: !this.data.isLogin
        });
    },
    onMyEvent: function(n) {
        this.login();
    },
    goRecord: function() {
        if (null == this.data.userInfo.nickName || "" == this.data.userInfo.nickName) return this.login(), 
        !1;
        wx.navigateTo({
            url: "/pages/record/record"
        });
    },
    goPoint: function() {
        if (null == this.data.userInfo.nickName || "" == this.data.userInfo.nickName) return this.login(), 
        !1;
        wx.navigateTo({
            url: "/pages/point/point"
        });
    },
    goCode: function() {
        if (null == this.data.userInfo.nickName || "" == this.data.userInfo.nickName) return this.login(), 
        !1;
        wx.navigateTo({
            url: "/pages/code/code"
        });
    },
    goSetting: function() {
        if (null == this.data.userInfo.nickName || "" == this.data.userInfo.nickName) return this.login(), 
        !1;
        wx.navigateTo({
            url: "/pages/setting/setting"
        });
    },
    goSign: function() {
        if (null == this.data.userInfo.nickName || "" == this.data.userInfo.nickName) return this.login(), 
        !1;
        wx.navigateTo({
            url: "/pages/sign/sign"
        });
    },
    goFeedback: function() {
        if (null == this.data.userInfo.nickName || "" == this.data.userInfo.nickName) return this.login(), 
        !1;
        wx.navigateTo({
            url: "/pages/feedback/feedback"
        });
    },
    goAbout: function() {
        this.setData({
            show: !0
        });
    },
    clearStorage: function() {
        wx.showModal({
            content: "清空缓存会清空答题记录缓存，确定要清空吗？",
            success: function(n) {
                if (n.confirm) {
                    wx.clearStorageSync(), wx.Apis.api.getConfigValue("notice", function(n, e) {
                        wx.setStorageSync("notice", e.value);
                    });
                    var e = wx.getStorageSync("openid");
                    "" != e && null != e || (wx.showLoading({
                        title: ""
                    }), wx.login({
                        success: function(n) {
                            n.code && (console.log(n.code), wx.Apis.login.login(n.code, function(n, e) {
                                console.log(e), wx.Apis.setUid(e.openid), wx.Apis.set("openid", e.openid), wx.setStorageSync("userInfo", e), 
                                wx.hideLoading({
                                    success: function(n) {}
                                });
                            }));
                        },
                        fail: function() {
                            wx.hideLoading({
                                success: function(n) {}
                            });
                        }
                    }));
                }
            }
        });
    },
    onClose: function() {
        this.setData({
            show: !1
        });
    },
    onSelect: function(n) {
        console.log(n.detail);
        "复制开发者QQ号" === n.detail.name ? wx.setClipboardData({
            data: "903363777",
            success: function(n) {}
        }) : wx.setClipboardData({
            data: "kossfirst",
            success: function(n) {}
        });
    },
    onShareAppMessage: function() {
        return {
            title: "智慧考题宝，考试助手 ！",
            path: "pages/index/index",
            imageUrl: "/images/share.png"
        };
    }
});