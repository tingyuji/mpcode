$gwx_XC_4=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_4 || [];
function gz$gwx_XC_4_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_4_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_4_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_4_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[8],'root',[[7],[3,'root']]])
Z([3,'taro_tmpl'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_4_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_4_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_4=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_4=true;
var x=['./pages/see_details/index.wxml','../../base.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_4_1()
var f7=e_[x[0]].i
_ai(f7,x[1],e_,x[0],1,1)
var c8=_v()
_(r,c8)
var h9=_oz(z,1,e,s,gg)
var o0=_gd(x[0],h9,e_,d_)
if(o0){
var cAB=_1z(z,0,e,s,gg) || {}
var cur_globalf=gg.f
c8.wxXCkey=3
o0(cAB,cAB,c8,gg)
gg.f=cur_globalf
}
else _w(h9,x[0],2,14)
f7.pop()
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[x[1]],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_4";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_4();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/see_details/index.wxml'] = [$gwx_XC_4, './pages/see_details/index.wxml'];else __wxAppCode__['pages/see_details/index.wxml'] = $gwx_XC_4( './pages/see_details/index.wxml' );
	;__wxRoute = "pages/see_details/index";__wxRouteBegin = true;__wxAppCurrentFile__="pages/see_details/index.js";define("pages/see_details/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
(wx.webpackJsonp=wx.webpackJsonp||[]).push([[12],{102:function(e,t,a){},107:function(e,t,a){"use strict";a.r(t);var i=a(8),s=a(18),n=a.n(s),c=a(22),o=a(14),r=a(15),l=a(9),h=a(10),d=a(5),u=a(11),j=a(12),m=a(4),b=a(6),g=a.n(b),f=a(2),O=a.n(f),_=a(1),p=a(7),w=a(68),x=a.n(w),k=(a(102),a(13)),v=a(23),S=a.n(v),N=a(24),D=a.n(N),T=a(32),I=a.n(T),P=a(0),A=function(e){Object(u.a)(a,e);var t=Object(j.a)(a);function a(){var e;Object(l.a)(this,a);for(var i=arguments.length,s=new Array(i),n=0;n<i;n++)s[n]=arguments[n];return e=t.call.apply(t,[this].concat(s)),Object(m.a)(Object(d.a)(e),"state",{datalist:"",top_data:{}}),Object(m.a)(Object(d.a)(e),"BASE_URL",Object(p.a)("BASE_URL")),Object(m.a)(Object(d.a)(e),"params",Object(f.getCurrentInstance)().router.params),Object(m.a)(Object(d.a)(e),"getDate",(function(t,a){Object(k.a)("/seelog/userMainlog",{id:t},"POST").then((function(t){if(a&&O.a.stopPullDownRefresh(),0==t.code){a&&O.a.showToast({title:"刷新成功",icon:"none"});var i=e.state.top_data;(i=t.share_data).img_url=e.state.top_data.img_url?e.state.top_data.img_url:i.img_url,i.see_total=t.data.length,1===i.is_chehui&&(i.is_chehui=!0),0===i.is_chehui&&(i.is_chehui=!1),Object(p.b)("detail_data",i),e.setState({datalist:t.data,top_data:i})}else O.a.showToast({title:t.msg,icon:"none"}),-9==t.code&&e.setState({no_switch_huizhi:!0}),e.setState({datalist:t.data})})).catch((function(){a&&O.a.stopPullDownRefresh()}))})),Object(m.a)(Object(d.a)(e),"getAdInfo",(function(){Object(k.a)("/config/deatils_id_info",{},"POST").then((function(t){0==t.code&&setTimeout((function(){t.ad_id&&wx.createInterstitialAd&&(e.interstitialAd=wx.createInterstitialAd({adUnitId:t.ad_id}),e.interstitialAd.onLoad((function(){})),e.interstitialAd.onError((function(e){})),e.interstitialAd.onClose((function(){})),e.interstitialAd.show().catch((function(e){console.error(e)})))}),1e3)}))})),Object(m.a)(Object(d.a)(e),"showModalImageFill",(function(t,a){if(!a&&e.state.img_onerr)return!1;e.isSeeFillImage=!0,O.a.previewImage({showmenu:!(!e.userdata||1!==e.userdata.id),current:[t],urls:[t]})})),Object(m.a)(Object(d.a)(e),"onDeletePick",(function(t){var a=1==e.userdata.id&&1!=t.uid;O.a.showModal({title:a?"切换检测提示":"删除提示",content:a?"改变检测状态":"将从列表中移除,已发出的照片将无法查看",success:function(a){a.confirm&&e.postDelete(t)}})})),Object(m.a)(Object(d.a)(e),"onCheHuiPick",(function(t){O.a.showModal({title:"撤回提示",content:"此照片将立即撤回(好友正点开看的也会立即撤回)",success:function(a){a.confirm&&e.postCheHui(t)}})})),Object(m.a)(Object(d.a)(e),"postDelete",(function(e){Object(k.a)("/shanzhao/delete",{id:e.id},"POST").then((function(t){0==t.code?(Object(p.b)("delete_share_id",e.id),O.a.navigateBack()):O.a.showToast({title:t.msg,icon:"none"})})).catch((function(){O.a.showToast({title:"删除失败，出错",icon:"none"})}))})),Object(m.a)(Object(d.a)(e),"postCheHui",(function(e){Object(k.a)("/shanzhao/set_chehui",{id:e.id},"POST").then((function(e){0==e.code?O.a.startPullDownRefresh():O.a.showToast({title:e.msg,icon:"none"})})).catch((function(){O.a.showToast({title:"撤回失败，请重试",icon:"none"})}))})),e}return Object(h.a)(a,[{key:"componentDidMount",value:function(){var e=this;this.userdata=Object(p.a)("dbuserinfo"),console.log(this.params.data);var t=this.params.data;t&&(t=JSON.parse(decodeURIComponent(t))),console.log(t),this.setState({top_data:Object(r.a)({},t)}),t&&(this.share_id=t.id,this.getDate(t.id)),t.ctime||setTimeout((function(){e.getDate(t.id)}),3e3),t&&t.is_from_tongzhi&&this.getAdInfo()}},{key:"componentDidShow",value:function(){this.share_id&&this.DidHide&&!this.isSeeFillImage&&O.a.startPullDownRefresh(),this.isSeeFillImage=!1}},{key:"componentDidHide",value:function(){this.DidHide=!0}},{key:"onPullDownRefresh",value:function(){this.getDate(this.share_id,!0)}},{key:"render",value:function(){var e=this,t=this.state,a=t.datalist,i=t.top_data,s=t.img_onerr,n=t.no_switch_huizhi,c=this.userdata&&1===this.userdata.id,r="?token="+Object(p.a)("dbuserinfo").token;console.log("url_token",r);var l=i.img_url?"object"==Object(o.a)(i.img_url)?i.img_url[0]:this.BASE_URL+i.img_url:"";return l&&l.indexOf("wxfile://")<0&&(l+=r),console.log(l),Object(P.jsx)(_.j,{className:"see-details-page",children:Object(P.jsxs)(_.j,{className:"content",children:[Object(P.jsxs)(_.j,{className:"info-view",onClick:function(){if(!c&&!1===i.checkAllow)return!1;e.showModalImageFill(e.imgonerr&&l?l.replace(/cover_/g,""):l)},children:[Object(P.jsxs)(_.j,{className:"left",children:[Object(P.jsxs)(_.h,{className:"t-1",children:["时间 ",i.ctime?D()(i.ctime).format("YY-MM-DD HH:mm:ss"):"-"]}),Object(P.jsxs)(_.h,{className:"t-2",children:["累计查看",Object(P.jsx)(_.h,{className:"num",children:i.see_total>=0?i.see_total:"-"}),"次",Object(P.jsx)(_.h,{className:"share-text "+(i.allow_zhuanfa?"ok":"dis"),children:i.allow_zhuanfa?"允许转发":"禁止转发"})]}),!1===i.is_chehui||!0===i.is_chehui?Object(P.jsx)(_.h,{className:"t-3 "+(i.is_chehui?"dis":"ok"),children:i.is_chehui?"已撤回":"已发送"}):null]}),Object(P.jsxs)(_.j,{className:"right",children:[Object(P.jsx)(_.c,{ref:function(t){return e.img_=t},onError:function(t){console.log("图片加载失败",t),e.imgonerr=!0;var a=l?l.replace(/cover_/g,""):I.a;e.img_.setAttribute("src",a)},className:c||!1!==i.checkAllow?"":"weigui-img",src:s?I.a:l,mode:"aspectFill"},"asdf"),!c&&!1===i.checkAllow&&Object(P.jsx)(_.j,{className:"weigui-text",children:"涉嫌违规"})]})]}),Object(P.jsxs)(_.j,{className:"titles",children:[Object(P.jsx)(_.h,{children:"详细数据"}),this.userdata&&1===this.userdata.id&&Object(P.jsx)(_.j,{className:"send_user",children:Object(P.jsxs)(_.j,{children:["发送的用户id ",i.uid]})})]}),n?Object(P.jsx)(_.h,{style:{fontSize:"28rpx",color:"#444",textAlign:"center",display:"block"},children:'此照片未开启"查看回执"功能'}):Object(P.jsxs)(_.j,{className:"tables",children:[Object(P.jsxs)(_.j,{className:"head-view",children:[Object(P.jsx)(_.j,{children:"昵称"}),Object(P.jsx)(_.j,{children:"头像"}),Object(P.jsx)(_.j,{children:"截录屏"}),Object(P.jsx)(_.j,{children:"时间"})]}),Object(P.jsx)(_.j,{className:"body",children:a?a.length>0?a.map((function(t){return Object(P.jsxs)(_.j,{className:"line",children:[Object(P.jsx)(_.j,{className:"item",children:t.name}),Object(P.jsxs)(_.j,{className:"item img-view",onClick:function(){t.headimg&&e.showModalImageFill(t.headimg,!0)},children:[Object(P.jsx)(_.c,{src:t.headimg}),i.uid===t.uid&&Object(P.jsx)(_.j,{children:"自己"})]}),Object(P.jsx)(_.j,{className:"item"+(t.screenText?" redColor":""),children:t.screenText||"无"}),Object(P.jsx)(_.j,{className:"item",children:t.ctime?D()(t.ctime).format("YY-MM-DD HH:mm:ss"):"-"})]},"lin_"+t.key)})):Object(P.jsx)(_.h,{className:"end-text",children:"无数据"}):Object(P.jsxs)(_.j,{className:"end-text",children:["获取中",Object(P.jsx)(_.c,{src:x.a})]})})]}),Object(P.jsxs)(_.j,{className:"tools-view-p",children:[Object(P.jsx)(_.j,{className:"delete_btn",onClick:function(){e.onDeletePick(i)},children:"删除"}),Object(P.jsx)(_.b,{className:"share_btn",openType:"share",children:"分享"}),!1===i.is_chehui&&Object(P.jsx)(_.j,{className:"chehui_btn",onClick:function(){e.onCheHuiPick(i)},children:"撤回"})]})]})})}},{key:"onShareAppMessage",value:function(e){var t=this,a=(new Date).getTime();return console.log("上次分享成功的时间",this.share_ok_time),this.ShareRelusIng?(console.log("正在分享----------------"),new Promise((function(e,t){t(-1)}))):this.share_ok_time&&a-this.share_ok_time<=1500?(console.log("正在分享----------------手速太快，稍等一下"),O.a.showToast({title:"手速太快，稍等一下",icon:"none",mask:!0,duration:1500}),new Promise((function(e,t){t(-1)}))):new Promise(function(){var a=Object(c.a)(n.a.mark((function a(i,s){var c,o,r;return n.a.wrap((function(a){for(;;)switch(a.prev=a.next){case 0:if(O.a.showLoading({title:"获取配置中...",mask:!0}),t.ShareRelusIng=!0,"button"==e.from){a.next=6;break}return O.a.showToast({title:"请点击分享按钮~",icon:"none",duration:1500}),t.ShareRelusIng=!1,a.abrupt("return",s(-1));case 6:if(!(c=t.state.top_data).is_chehui){a.next=11;break}return O.a.showToast({title:"已经撤回，不能继续分享，请重新上传~",icon:"none",duration:2200}),t.ShareRelusIng=!1,a.abrupt("return",s(-1));case 11:console.log("await---2",c),!c.allow_zhuanfa&&c.activity_id&&wx.updateShareMenu&&(t.isHideShare=!0,wx.updateShareMenu({withShareTicket:!0,isPrivateMessage:!0,activityId:c.activity_id})),c.allow_zhuanfa&&t.isHideShare&&(t.isHideShare=!1,wx.updateShareMenu&&wx.updateShareMenu({isPrivateMessage:!1,withShareTicket:!0,activityId:""})),t.isOnShare=!0,O.a.hideLoading(),console.log("分享后的参数",c.id,"---",c),t.share_ok_time=(new Date).getTime(),t.share_data={id:c.id,img_url:c.img_url},t.ShareRelusIng=!1,Object(p.b)("isSendShanZhao",!0),console.log("分享时间",new Date(c.ctime).getTime()),o=c.ctime?new Date(c.ctime).getTime():"",r=(r=c.id+(o?"-"+o:""))+"-"+(c.allow_zhuanfa?"0":"1"),i({title:"对方发送了一张照片，点击查看",path:"/pages/share_look/index?data="+encodeURIComponent(r),imageUrl:S.a});case 26:case"end":return a.stop()}}),a)})));return function(e,t){return a.apply(this,arguments)}}())}}]),a}(g.a.PureComponent);A.enableShareAppMessage=!0,Page(Object(i.createPageConfig)(A,"pages/see_details/index",{root:{cn:[]}},{navigationBarTitleText:"详情",navigationBarBackgroundColor:"#f1f1f1",enablePullDownRefresh:!0,backgroundTextStyle:"dark",disableScroll:!1,enableShareAppMessage:!0}||{}))},68:function(e,t,a){e.exports=a.p+"resources/svg/loading.svg"}},[[107,0,1,2,3]]]);
},{isPage:true,isComponent:true,currentFile:'pages/see_details/index.js'});require("pages/see_details/index.js");