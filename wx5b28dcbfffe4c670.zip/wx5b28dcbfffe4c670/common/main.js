(global.webpackJsonp = global.webpackJsonp || []).push([ [ "common/main" ], {
    1558: function(e, t, n) {
        var r = n("c456");
        n.n(r).a;
    },
    "68da": function(e, t, n) {
        (function(e, t) {
            var r = n("4ea4"), o = r(n("9523"));
            n("a9d3");
            var a = r(n("66fd")), u = r(n("c0d5")), c = r(n("a7c4")), f = r(n("4892"));
            function d(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(e);
                    t && (r = r.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable;
                    })), n.push.apply(n, r);
                }
                return n;
            }
            e.__webpack_require_UNI_MP_PLUGIN__ = n, u.default.mpType = "20220718_gz";
            var i = "https://h5.fogln.com/" + u.default.mpType + "/";
            f.default.config.baseUrl = i, a.default.config.productionTip = !1, a.default.prototype.$http = f.default, 
            a.default.prototype.$store = c.default, a.default.prototype.$store.url = i, a.default.prototype.$store.appid = u.default.mpType;
            var l = new a.default(function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? d(Object(n), !0).forEach(function(t) {
                        (0, o.default)(e, t, n[t]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : d(Object(n)).forEach(function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
                    });
                }
                return e;
            }({}, u.default));
            t(l).$mount();
        }).call(this, n("bc2e").default, n("543d").createApp);
    },
    8335: function(e, t, n) {
        var r = n("4ea4");
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var o = r(n("2eee")), a = r(n("c973")), u = r(n("66fd")), c = r(n("fcb5")), f = r(n("a7c4")), d = n("5cc3");
        u.default.use(c.default, {
            Login: {
                name: "Login",
                watchKey: "token",
                deep: !0,
                onUpdate: function(e) {
                    return !!e;
                }
            }
        }, f.default);
        var i = {
            onLaunch: function() {
                var e = this;
                return (0, a.default)(o.default.mark(function t() {
                    return o.default.wrap(function(t) {
                        for (;;) switch (t.prev = t.next) {
                          case 0:
                            return console.log("onLaunch"), (0, d.CheckUpdate)(), t.next = 4, (0, d.wxLogin)(e);

                          case 4:
                          case "end":
                            return t.stop();
                        }
                    }, t);
                }))();
            },
            onShow: function() {},
            onHide: function() {}
        };
        t.default = i;
    },
    c0d5: function(e, t, n) {
        n.r(t);
        var r = n("fc90");
        for (var o in r) [ "default" ].indexOf(o) < 0 && function(e) {
            n.d(t, e, function() {
                return r[e];
            });
        }(o);
        n("1558");
        var a = n("f0c5"), u = Object(a.a)(r.default, void 0, void 0, !1, null, null, null, !1, void 0, void 0);
        t.default = u.exports;
    },
    c456: function(e, t, n) {},
    fc90: function(e, t, n) {
        n.r(t);
        var r = n("8335"), o = n.n(r);
        for (var a in r) [ "default" ].indexOf(a) < 0 && function(e) {
            n.d(t, e, function() {
                return r[e];
            });
        }(a);
        t.default = o.a;
    }
}, [ [ "68da", "common/runtime", "common/vendor" ] ] ]);