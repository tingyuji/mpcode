(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/feng-parse/components/wxParseAudio" ], {
    "0937": function(n, e, o) {
        o.d(e, "b", function() {
            return t;
        }), o.d(e, "c", function() {
            return c;
        }), o.d(e, "a", function() {});
        var t = function() {
            this.$createElement;
            this._self._c;
        }, c = [];
    },
    "2c72": function(n, e, o) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var t = {
            name: "wxParseAudio",
            props: {
                node: {
                    type: Object,
                    default: function() {
                        return {};
                    }
                }
            }
        };
        e.default = t;
    },
    "514c": function(n, e, o) {
        o.r(e);
        var t = o("2c72"), c = o.n(t);
        for (var a in t) [ "default" ].indexOf(a) < 0 && function(n) {
            o.d(e, n, function() {
                return t[n];
            });
        }(a);
        e.default = c.a;
    },
    "6e2c": function(n, e, o) {
        o.r(e);
        var t = o("0937"), c = o("514c");
        for (var a in c) [ "default" ].indexOf(a) < 0 && function(n) {
            o.d(e, n, function() {
                return c[n];
            });
        }(a);
        var r = o("f0c5"), u = Object(r.a)(c.default, t.b, t.c, !1, null, null, null, !1, t.a, void 0);
        e.default = u.exports;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/feng-parse/components/wxParseAudio-create-component", {
    "components/feng-parse/components/wxParseAudio-create-component": function(n, e, o) {
        o("543d").createComponent(o("6e2c"));
    }
}, [ [ "components/feng-parse/components/wxParseAudio-create-component" ] ] ]);