(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/feng-parse/components/wxParseVideo" ], {
    "3b40": function(e, n, t) {
        (function(e) {
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var t = {
                name: "wxParseVideo",
                props: {
                    node: {}
                },
                data: function() {
                    return {
                        playState: !0,
                        videoStyle: "width: 100%;",
                        w: e.upx2px(750),
                        h: "auto"
                    };
                },
                created: function() {},
                methods: {
                    loadedmetadata: function(n) {
                        this.h = e.upx2px(750 / n.detail.width * n.detail.height);
                    },
                    play: function() {
                        console.log("点击了video 播放"), this.playState = !this.playState;
                    }
                },
                mounted: function() {
                    var n = this;
                    e.$on("slideMenuShow", function(e) {
                        console.log("捕获事件：" + e), "show" == e && n.playState && (n.playState = !1);
                    });
                }
            };
            n.default = t;
        }).call(this, t("543d").default);
    },
    a102: function(e, n, t) {},
    aaae: function(e, n, t) {
        t.r(n);
        var o = t("3b40"), a = t.n(o);
        for (var c in o) [ "default" ].indexOf(c) < 0 && function(e) {
            t.d(n, e, function() {
                return o[e];
            });
        }(c);
        n.default = a.a;
    },
    d6bf: function(e, n, t) {
        var o = t("a102");
        t.n(o).a;
    },
    eb2d: function(e, n, t) {
        t.d(n, "b", function() {
            return o;
        }), t.d(n, "c", function() {
            return a;
        }), t.d(n, "a", function() {});
        var o = function() {
            this.$createElement;
            this._self._c;
        }, a = [];
    },
    f3b8: function(e, n, t) {
        t.r(n);
        var o = t("eb2d"), a = t("aaae");
        for (var c in a) [ "default" ].indexOf(c) < 0 && function(e) {
            t.d(n, e, function() {
                return a[e];
            });
        }(c);
        t("d6bf");
        var i = t("f0c5"), u = Object(i.a)(a.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        n.default = u.exports;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/feng-parse/components/wxParseVideo-create-component", {
    "components/feng-parse/components/wxParseVideo-create-component": function(e, n, t) {
        t("543d").createComponent(t("f3b8"));
    }
}, [ [ "components/feng-parse/components/wxParseVideo-create-component" ] ] ]);