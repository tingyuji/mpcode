(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/alger-simg/alger-simg" ], {
    "2d48": function(n, t, e) {
        (function(n) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var e = {
                data: function() {
                    return {
                        imgs: [],
                        currentImg: 0,
                        isPop: !1,
                        isPop1: !1
                    };
                },
                onLoad: function(n) {},
                methods: {
                    returnTo: function() {
                        this.$emit("clickColse");
                    },
                    changeSwiper: function(n) {
                        this.currentImg = n.detail.current;
                    },
                    toImg: function(n) {
                        this.currentImg = n;
                    },
                    back: function() {
                        if (this.isPop) this.isPop = !1; else try {
                            this.$Router.back(1);
                        } catch (t) {
                            n.navigateBack();
                        }
                    },
                    share: function() {
                        n.downloadFile({
                            url: this.imgs[this.currentImg],
                            success: function(t) {
                                var e = t.tempFilePath;
                                e && n.openDocument({
                                    filePath: e,
                                    success: function(n) {
                                        console.log(n), console.log("打开文档成功");
                                    }
                                });
                            }
                        });
                    },
                    saveImg: function() {
                        var t = arguments.length > 0 && void 0 !== arguments[0] && arguments[0], e = this;
                        t ? this.imgs.forEach(function(t) {
                            n.downloadFile({
                                url: t,
                                success: function(t) {
                                    200 === t.statusCode && n.saveImageToPhotosAlbum({
                                        filePath: t.tempFilePath,
                                        success: function() {
                                            n.showToast({
                                                icon: "none",
                                                title: "保存全部成功"
                                            }), e.isPop = !1;
                                        },
                                        fail: function() {}
                                    });
                                }
                            });
                        }) : n.downloadFile({
                            url: this.imgs[this.currentImg],
                            success: function(t) {
                                200 === t.statusCode && n.saveImageToPhotosAlbum({
                                    filePath: t.tempFilePath,
                                    success: function() {
                                        n.showToast({
                                            icon: "none",
                                            title: "保存成功"
                                        }), e.isPop = !1;
                                    },
                                    fail: function() {}
                                });
                            }
                        });
                    }
                }
            };
            t.default = e;
        }).call(this, e("543d").default);
    },
    "7c98": function(n, t, e) {
        e.r(t);
        var o = e("2d48"), i = e.n(o);
        for (var c in o) [ "default" ].indexOf(c) < 0 && function(n) {
            e.d(t, n, function() {
                return o[n];
            });
        }(c);
        t.default = i.a;
    },
    c04b: function(n, t, e) {
        e.d(t, "b", function() {
            return o;
        }), e.d(t, "c", function() {
            return i;
        }), e.d(t, "a", function() {});
        var o = function() {
            var n = this;
            n.$createElement;
            n._self._c, n._isMounted || (n.e0 = function(t) {
                n.isPop = !0;
            });
        }, i = [];
    },
    d51e: function(n, t, e) {
        var o = e("e755");
        e.n(o).a;
    },
    e755: function(n, t, e) {},
    fdfe: function(n, t, e) {
        e.r(t);
        var o = e("c04b"), i = e("7c98");
        for (var c in i) [ "default" ].indexOf(c) < 0 && function(n) {
            e.d(t, n, function() {
                return i[n];
            });
        }(c);
        e("d51e");
        var s = e("f0c5"), a = Object(s.a)(i.default, o.b, o.c, !1, null, "0a24b6f1", null, !1, o.a, void 0);
        t.default = a.exports;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/alger-simg/alger-simg-create-component", {
    "components/alger-simg/alger-simg-create-component": function(n, t, e) {
        e("543d").createComponent(e("fdfe"));
    }
}, [ [ "components/alger-simg/alger-simg-create-component" ] ] ]);