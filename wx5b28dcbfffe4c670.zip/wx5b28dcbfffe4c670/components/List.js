(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/List" ], {
    "919d": function(t, e, n) {
        n.r(e);
        var a = n("93f8"), r = n("d2c6");
        for (var c in r) [ "default" ].indexOf(c) < 0 && function(t) {
            n.d(e, t, function() {
                return r[t];
            });
        }(c);
        n("eae2");
        var o = n("f0c5"), u = Object(o.a)(r.default, a.b, a.c, !1, null, "5073a021", null, !1, a.a, void 0);
        e.default = u.exports;
    },
    "93f8": function(t, e, n) {
        n.d(e, "b", function() {
            return a;
        }), n.d(e, "c", function() {
            return r;
        }), n.d(e, "a", function() {});
        var a = function() {
            var t = this, e = (t.$createElement, t._self._c, t.list.length), n = t.__map(t.list, function(e, n) {
                return {
                    $orig: t.__get_orig(e),
                    m0: t.swiperCurrentIndex == n ? t.text(e.end) : null
                };
            });
            t.$mp.data = Object.assign({}, {
                $root: {
                    g0: e,
                    l0: n
                }
            });
        }, r = [];
    },
    d2c6: function(t, e, n) {
        n.r(e);
        var a = n("f4c5"), r = n.n(a);
        for (var c in a) [ "default" ].indexOf(c) < 0 && function(t) {
            n.d(e, t, function() {
                return a[t];
            });
        }(c);
        e.default = r.a;
    },
    e5cc: function(t, e, n) {},
    eae2: function(t, e, n) {
        var a = n("e5cc");
        n.n(a).a;
    },
    f4c5: function(t, e, n) {
        (function(t) {
            var a = n("4ea4");
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var r = a(n("2eee")), c = a(n("c973")), o = n("5cc3"), u = {
                name: "List",
                data: function() {
                    return {
                        swiperCurrentIndex: 0,
                        previousMargin: t.upx2px(95) + "px",
                        nextMargin: t.upx2px(95) + "px",
                        list: []
                    };
                },
                props: {
                    page: String
                },
                created: function() {
                    var t = this;
                    return (0, c.default)(r.default.mark(function e() {
                        var n, a;
                        return r.default.wrap(function(e) {
                            for (;;) switch (e.prev = e.next) {
                              case 0:
                                return e.next = 2, t.$http.get(t.page);

                              case 2:
                                n = e.sent, a = n.data, t.list = a.packet.list;

                              case 5:
                              case "end":
                                return e.stop();
                            }
                        }, e);
                    }))();
                },
                methods: {
                    change: function(t) {
                        this.swiperCurrentIndex = t.detail.current;
                    },
                    _to: function(e) {
                        t.navigateTo({
                            url: "/pages/content/cent?page=" + this.page + "&sid=" + e
                        });
                    },
                    text: function(t) {
                        return (0, o.getTimeStamp)() >= (0, o.dayjs)(t).valueOf() / 1e3 ? "活动已截止" : "了解活动详情";
                    }
                }
            };
            e.default = u;
        }).call(this, n("543d").default);
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/List-create-component", {
    "components/List-create-component": function(t, e, n) {
        n("543d").createComponent(n("919d"));
    }
}, [ [ "components/List-create-component" ] ] ]);