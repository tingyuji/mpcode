(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/TitleBar" ], {
    "4a92": function(n, t, e) {
        e.r(t);
        var a = e("4e04"), c = e.n(a);
        for (var o in a) [ "default" ].indexOf(o) < 0 && function(n) {
            e.d(t, n, function() {
                return a[n];
            });
        }(o);
        t.default = c.a;
    },
    "4e04": function(n, t, e) {
        (function(n) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var e = null, a = {
                name: "TitleBar",
                data: function() {
                    return {
                        height: null
                    };
                },
                props: {
                    page: String,
                    TitleBarType: String,
                    TitleBarbUT: String
                },
                created: function() {
                    e = this, n.getSystemInfo({
                        success: function(n) {
                            e.height = n.statusBarHeight;
                        }
                    });
                },
                methods: {
                    _back: function() {
                        n.navigateBack();
                    }
                }
            };
            t.default = a;
        }).call(this, e("543d").default);
    },
    "8a9e": function(n, t, e) {
        e.d(t, "b", function() {
            return a;
        }), e.d(t, "c", function() {
            return c;
        }), e.d(t, "a", function() {});
        var a = function() {
            this.$createElement;
            this._self._c;
        }, c = [];
    },
    "9e9c": function(n, t, e) {},
    b7b4: function(n, t, e) {
        e.r(t);
        var a = e("8a9e"), c = e("4a92");
        for (var o in c) [ "default" ].indexOf(o) < 0 && function(n) {
            e.d(t, n, function() {
                return c[n];
            });
        }(o);
        e("c38f");
        var i = e("f0c5"), r = Object(i.a)(c.default, a.b, a.c, !1, null, "ec3d77c6", null, !1, a.a, void 0);
        t.default = r.exports;
    },
    c38f: function(n, t, e) {
        var a = e("9e9c");
        e.n(a).a;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/TitleBar-create-component", {
    "components/TitleBar-create-component": function(n, t, e) {
        e("543d").createComponent(e("b7b4"));
    }
}, [ [ "components/TitleBar-create-component" ] ] ]);