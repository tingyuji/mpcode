(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/page5/setup" ], {
    "1e9a": function(n, e, t) {
        t.r(e);
        var a = t("9831"), u = t.n(a);
        for (var c in a) [ "default" ].indexOf(c) < 0 && function(n) {
            t.d(e, n, function() {
                return a[n];
            });
        }(c);
        e.default = u.a;
    },
    9608: function(n, e, t) {
        (function(n, e) {
            var a = t("4ea4");
            t("a9d3"), a(t("66fd"));
            var u = a(t("fcbb"));
            n.__webpack_require_UNI_MP_PLUGIN__ = t, e(u.default);
        }).call(this, t("bc2e").default, t("543d").createPage);
    },
    9831: function(n, e, t) {
        (function(n) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var a = {
                components: {
                    TitleBar: function() {
                        t.e("components/TitleBar").then(function() {
                            return resolve(t("b7b4"));
                        }.bind(null, t)).catch(t.oe);
                    }
                },
                data: function() {
                    return {};
                },
                methods: {
                    _to: function(e, t) {
                        n.navigateTo({
                            url: "/pages/" + e + "/" + t
                        });
                    }
                }
            };
            e.default = a;
        }).call(this, t("543d").default);
    },
    cc33: function(n, e, t) {
        t.d(e, "b", function() {
            return a;
        }), t.d(e, "c", function() {
            return u;
        }), t.d(e, "a", function() {});
        var a = function() {
            this.$createElement;
            this._self._c;
        }, u = [];
    },
    fcbb: function(n, e, t) {
        t.r(e);
        var a = t("cc33"), u = t("1e9a");
        for (var c in u) [ "default" ].indexOf(c) < 0 && function(n) {
            t.d(e, n, function() {
                return u[n];
            });
        }(c);
        var o = t("f0c5"), f = Object(o.a)(u.default, a.b, a.c, !1, null, null, null, !1, a.a, void 0);
        e.default = f.exports;
    }
}, [ [ "9608", "common/runtime", "common/vendor" ] ] ]);