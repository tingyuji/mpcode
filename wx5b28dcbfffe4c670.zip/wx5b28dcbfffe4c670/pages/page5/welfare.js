(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/page5/welfare" ], {
    "0404": function(n, e, t) {
        t.d(e, "b", function() {
            return a;
        }), t.d(e, "c", function() {
            return u;
        }), t.d(e, "a", function() {});
        var a = function() {
            this.$createElement;
            this._self._c;
        }, u = [];
    },
    "3ba8": function(n, e, t) {
        (function(n) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var a = {
                components: {
                    TitleBar: function() {
                        t.e("components/TitleBar").then(function() {
                            return resolve(t("b7b4"));
                        }.bind(null, t)).catch(t.oe);
                    }
                },
                data: function() {
                    return {};
                },
                methods: {
                    _to: function(e, t) {
                        n.navigateTo({
                            url: "/pages/" + e + "/" + t
                        });
                    }
                }
            };
            e.default = a;
        }).call(this, t("543d").default);
    },
    "4a0a": function(n, e, t) {
        t.r(e);
        var a = t("3ba8"), u = t.n(a);
        for (var o in a) [ "default" ].indexOf(o) < 0 && function(n) {
            t.d(e, n, function() {
                return a[n];
            });
        }(o);
        e.default = u.a;
    },
    bda8: function(n, e, t) {
        t.r(e);
        var a = t("0404"), u = t("4a0a");
        for (var o in u) [ "default" ].indexOf(o) < 0 && function(n) {
            t.d(e, n, function() {
                return u[n];
            });
        }(o);
        var f = t("f0c5"), c = Object(f.a)(u.default, a.b, a.c, !1, null, null, null, !1, a.a, void 0);
        e.default = c.exports;
    },
    f69f: function(n, e, t) {
        (function(n, e) {
            var a = t("4ea4");
            t("a9d3"), a(t("66fd"));
            var u = a(t("bda8"));
            n.__webpack_require_UNI_MP_PLUGIN__ = t, e(u.default);
        }).call(this, t("bc2e").default, t("543d").createPage);
    }
}, [ [ "f69f", "common/runtime", "common/vendor" ] ] ]);