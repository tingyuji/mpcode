(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/index/index" ], {
    "2cbe": function(e, n, t) {
        (function(e) {
            var a = t("4ea4");
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var o = a(t("2eee")), r = a(t("c973")), i = t("5cc3"), c = null, u = {
                components: {
                    TitleBar: function() {
                        t.e("components/TitleBar").then(function() {
                            return resolve(t("b7b4"));
                        }.bind(null, t)).catch(t.oe);
                    },
                    List: function() {
                        Promise.all([ t.e("common/vendor"), t.e("components/List") ]).then(function() {
                            return resolve(t("919d"));
                        }.bind(null, t)).catch(t.oe);
                    }
                },
                data: function() {
                    return {
                        userData: this.$store.state.userData,
                        page: "page1",
                        TitleBarType: "A",
                        videoUrl: "",
                        video: !1,
                        titleHeage: null
                    };
                },
                onShareAppMessage: function(e) {
                    return {
                        title: "观宸 | 极核地标 世界藏品",
                        path: "/pages/index/index",
                        imageUrl: "/static/image/share.jpg"
                    };
                },
                onLoadLogin: function(e) {
                    var n = this;
                    return (0, r.default)(o.default.mark(function t() {
                        var a, r;
                        return o.default.wrap(function(t) {
                            for (;;) switch (t.prev = t.next) {
                              case 0:
                                return console.log("onLoadLogin"), t.next = 3, n.$http.get("initV2");

                              case 3:
                                return a = t.sent, r = a.data, n.$store.state.app = r.packet.app, c = n, (0, i.CheckUpdate)(), 
                                t.next = 10, (0, i.wxLogin)(c);

                              case 10:
                                null != e.page && n._next("page" + e.page);

                              case 11:
                              case "end":
                                return t.stop();
                            }
                        }, t);
                    }))();
                },
                onLoad: function(e) {
                    return (0, r.default)(o.default.mark(function e() {
                        return o.default.wrap(function(e) {
                            for (;;) switch (e.prev = e.next) {
                              case 0:
                              case "end":
                                return e.stop();
                            }
                        }, e);
                    }))();
                },
                methods: {
                    ended: function() {
                        this.video = !1;
                    },
                    _to: function(n, t) {
                        "page5" != n || "info" != t && "welfare" != t ? e.navigateTo({
                            url: "/pages/" + n + "/" + t
                        }) : (0, i.dialog)("Coming Soon");
                    },
                    _next: function(e) {
                        e != this.page && (this.TitleBarType = "page3" == e || "page4" == e ? "B" : "A", 
                        this.page = e);
                    }
                }
            };
            n.default = u;
        }).call(this, t("543d").default);
    },
    "446f": function(e, n, t) {
        t.r(n);
        var a = t("2cbe"), o = t.n(a);
        for (var r in a) [ "default" ].indexOf(r) < 0 && function(e) {
            t.d(n, e, function() {
                return a[e];
            });
        }(r);
        n.default = o.a;
    },
    "7d00": function(e, n, t) {
        t.r(n);
        var a = t("ecce"), o = t("446f");
        for (var r in o) [ "default" ].indexOf(r) < 0 && function(e) {
            t.d(n, e, function() {
                return o[e];
            });
        }(r);
        t("a011");
        var i = t("f0c5"), c = Object(i.a)(o.default, a.b, a.c, !1, null, "1b33c564", null, !1, a.a, void 0);
        n.default = c.exports;
    },
    a011: function(e, n, t) {
        var a = t("d0ec");
        t.n(a).a;
    },
    b9a6: function(e, n, t) {
        (function(e, n) {
            var a = t("4ea4");
            t("a9d3"), a(t("66fd"));
            var o = a(t("7d00"));
            e.__webpack_require_UNI_MP_PLUGIN__ = t, n(o.default);
        }).call(this, t("bc2e").default, t("543d").createPage);
    },
    d0ec: function(e, n, t) {},
    ecce: function(e, n, t) {
        t.d(n, "b", function() {
            return a;
        }), t.d(n, "c", function() {
            return o;
        }), t.d(n, "a", function() {});
        var a = function() {
            this.$createElement;
            this._self._c;
        }, o = [];
    }
}, [ [ "b9a6", "common/runtime", "common/vendor" ] ] ]);