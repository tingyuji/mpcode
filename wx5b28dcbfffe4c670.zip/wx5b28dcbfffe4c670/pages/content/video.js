(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/content/video" ], {
    "4b38": function(n, e, t) {
        t.r(e);
        var o = t("842d"), u = t("e4e6");
        for (var a in u) [ "default" ].indexOf(a) < 0 && function(n) {
            t.d(e, n, function() {
                return u[n];
            });
        }(a);
        var c = t("f0c5"), r = Object(c.a)(u.default, o.b, o.c, !1, null, null, null, !1, o.a, void 0);
        e.default = r.exports;
    },
    "842d": function(n, e, t) {
        t.d(e, "b", function() {
            return o;
        }), t.d(e, "c", function() {
            return u;
        }), t.d(e, "a", function() {});
        var o = function() {
            this.$createElement;
            this._self._c;
        }, u = [];
    },
    c350: function(n, e, t) {
        (function(n, e) {
            var o = t("4ea4");
            t("a9d3"), o(t("66fd"));
            var u = o(t("4b38"));
            n.__webpack_require_UNI_MP_PLUGIN__ = t, e(u.default);
        }).call(this, t("bc2e").default, t("543d").createPage);
    },
    e4e6: function(n, e, t) {
        t.r(e);
        var o = t("f873"), u = t.n(o);
        for (var a in o) [ "default" ].indexOf(a) < 0 && function(n) {
            t.d(e, n, function() {
                return o[n];
            });
        }(a);
        e.default = u.a;
    },
    f873: function(n, e, t) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var o = {
            components: {
                TitleBar: function() {
                    t.e("components/TitleBar").then(function() {
                        return resolve(t("b7b4"));
                    }.bind(null, t)).catch(t.oe);
                }
            },
            data: function() {
                return {};
            },
            methods: {}
        };
        e.default = o;
    }
}, [ [ "c350", "common/runtime", "common/vendor" ] ] ]);