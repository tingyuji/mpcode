(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/content/audio" ], {
    "3f69": function(n, e, t) {
        (function(n, e) {
            var a = t("4ea4");
            t("a9d3"), a(t("66fd"));
            var u = a(t("b312"));
            n.__webpack_require_UNI_MP_PLUGIN__ = t, e(u.default);
        }).call(this, t("bc2e").default, t("543d").createPage);
    },
    8221: function(n, e, t) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var a = {
            components: {
                TitleBar: function() {
                    t.e("components/TitleBar").then(function() {
                        return resolve(t("b7b4"));
                    }.bind(null, t)).catch(t.oe);
                }
            },
            data: function() {
                return {};
            },
            methods: {}
        };
        e.default = a;
    },
    "8ff7": function(n, e, t) {
        t.d(e, "b", function() {
            return a;
        }), t.d(e, "c", function() {
            return u;
        }), t.d(e, "a", function() {});
        var a = function() {
            this.$createElement;
            this._self._c;
        }, u = [];
    },
    b312: function(n, e, t) {
        t.r(e);
        var a = t("8ff7"), u = t("fad2");
        for (var f in u) [ "default" ].indexOf(f) < 0 && function(n) {
            t.d(e, n, function() {
                return u[n];
            });
        }(f);
        var o = t("f0c5"), c = Object(o.a)(u.default, a.b, a.c, !1, null, null, null, !1, a.a, void 0);
        e.default = c.exports;
    },
    fad2: function(n, e, t) {
        t.r(e);
        var a = t("8221"), u = t.n(a);
        for (var f in a) [ "default" ].indexOf(f) < 0 && function(n) {
            t.d(e, n, function() {
                return a[n];
            });
        }(f);
        e.default = u.a;
    }
}, [ [ "3f69", "common/runtime", "common/vendor" ] ] ]);