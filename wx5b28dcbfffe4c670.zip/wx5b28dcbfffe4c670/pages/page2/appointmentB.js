(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/page2/appointmentB" ], {
    "0796": function(e, t, n) {
        n.d(t, "b", function() {
            return a;
        }), n.d(t, "c", function() {
            return r;
        }), n.d(t, "a", function() {});
        var a = function() {
            this.$createElement;
            this._self._c;
        }, r = [];
    },
    3726: function(e, t, n) {
        var a = n("7372");
        n.n(a).a;
    },
    7372: function(e, t, n) {},
    "90ce": function(e, t, n) {
        n.r(t);
        var a = n("0796"), r = n("cd0d");
        for (var o in r) [ "default" ].indexOf(o) < 0 && function(e) {
            n.d(t, e, function() {
                return r[e];
            });
        }(o);
        n("3726");
        var u = n("f0c5"), i = Object(u.a)(r.default, a.b, a.c, !1, null, "1783dd4b", null, !1, a.a, void 0);
        t.default = i.exports;
    },
    c4a1: function(e, t, n) {
        (function(e, t) {
            var a = n("4ea4");
            n("a9d3"), a(n("66fd"));
            var r = a(n("90ce"));
            e.__webpack_require_UNI_MP_PLUGIN__ = n, t(r.default);
        }).call(this, n("bc2e").default, n("543d").createPage);
    },
    cd0d: function(e, t, n) {
        n.r(t);
        var a = n("cd97"), r = n.n(a);
        for (var o in a) [ "default" ].indexOf(o) < 0 && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(o);
        t.default = r.a;
    },
    cd97: function(e, t, n) {
        (function(e, a) {
            var r = n("4ea4");
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var o = r(n("2eee")), u = r(n("c973")), i = n("5cc3"), c = {
                components: {
                    item: function() {
                        n.e("components/Item").then(function() {
                            return resolve(n("84f9"));
                        }.bind(null, n)).catch(n.oe);
                    },
                    TitleBar: function() {
                        n.e("components/TitleBar").then(function() {
                            return resolve(n("b7b4"));
                        }.bind(null, n)).catch(n.oe);
                    }
                },
                data: function() {
                    return {
                        type: "B",
                        page1: !0,
                        page2: !1,
                        page3: !1,
                        period: [ "" ],
                        week: [ "日", "一", "二", "三", "四", "五", "六" ],
                        form: {
                            company: "",
                            name: "",
                            call: "",
                            num: "",
                            day: "",
                            date: "",
                            period: ""
                        },
                        index: 0,
                        u_name: "",
                        u_time: "",
                        currentData: null
                    };
                },
                created: function() {
                    for (var e = this.$store.state.app.dateLimit, t = null == e ? "9" : parseInt(e[0]), n = null == e ? "18" : parseInt(e[1]), a = t; a < n + 1; a++) {
                        if (a == n && n != e[1]) {
                            this.period.push(this.dateTrun(a) + ":00");
                            break;
                        }
                        this.period.push(this.dateTrun(a) + ":00"), this.period.push(this.dateTrun(a) + ":30");
                    }
                },
                methods: {
                    dateTrun: function(e) {
                        return e >= 10 ? e : "0" + e;
                    },
                    bindPickerChange: function(e) {
                        this.index = e.detail.value;
                    },
                    returnTo: function(t) {
                        1 == t ? e.navigateBack({}) : 2 == t && (this.page1 = !0, this.page2 = !1);
                    },
                    next: function(t) {
                        if (1 == t) {
                            if (this.currentData = this.$refs.item.currentData, "可以预约" != this.currentData.state) return void e.showModal({
                                title: "温馨提示",
                                content: "当前日期不可预约",
                                showCancel: !1
                            });
                            this.page1 = !1, this.page2 = !0;
                        } else 2 == t && this.submit();
                    },
                    submit: function() {
                        var t = this;
                        return (0, u.default)(o.default.mark(function n() {
                            var a;
                            return o.default.wrap(function(n) {
                                for (;;) switch (n.prev = n.next) {
                                  case 0:
                                    if (t.form.day = t.currentData.day, t.form.date = t.currentData.date, t.form.period = t.period[t.index], 
                                    t.form.num = Number(t.form.num), "" != t.form.name) {
                                        n.next = 7;
                                        break;
                                    }
                                    return e.showModal({
                                        title: "温馨提示",
                                        content: "请输入姓名",
                                        showCancel: !1
                                    }), n.abrupt("return");

                                  case 7:
                                    if ("" != t.form.call && (0, i.re)(t.form.call)) {
                                        n.next = 10;
                                        break;
                                    }
                                    return e.showModal({
                                        title: "温馨提示",
                                        content: "请输入电话或正确的格式",
                                        showCancel: !1
                                    }), n.abrupt("return");

                                  case 10:
                                    if ("" != t.form.num && "0" != t.form.num && 0 != t.form.num && t.isInteger(t.form.num)) {
                                        n.next = 13;
                                        break;
                                    }
                                    return e.showModal({
                                        title: "温馨提示",
                                        content: "请输入到访人数",
                                        showCancel: !1
                                    }), n.abrupt("return");

                                  case 13:
                                    if (!(parseInt(t.form.num) > 10)) {
                                        n.next = 16;
                                        break;
                                    }
                                    return e.showModal({
                                        title: "温馨提示",
                                        content: "到访人数限制10人",
                                        showCancel: !1
                                    }), n.abrupt("return");

                                  case 16:
                                    if ("" != t.form.period) {
                                        n.next = 19;
                                        break;
                                    }
                                    return e.showModal({
                                        title: "温馨提示",
                                        content: "请选择到访时间",
                                        showCancel: !1
                                    }), n.abrupt("return");

                                  case 19:
                                    if ("" != t.form.day && "" != t.form.date) {
                                        n.next = 22;
                                        break;
                                    }
                                    return e.showModal({
                                        title: "温馨提示",
                                        content: "请选择到访日期",
                                        showCancel: !1
                                    }), n.abrupt("return");

                                  case 22:
                                    if ((0, i.dayjs)().format("YYYY/MM/DD") != t.form.day) {
                                        n.next = 27;
                                        break;
                                    }
                                    if (!((0, i.dayjs)(t.form.day + " " + t.form.period).unix() - Math.round(new Date().getTime() / 1e3) <= 7200)) {
                                        n.next = 27;
                                        break;
                                    }
                                    return e.showModal({
                                        title: "温馨提示",
                                        content: "当日预约需提前两小时",
                                        showCancel: !1
                                    }), n.abrupt("return");

                                  case 27:
                                    return t.form.num = parseInt(t.form.num), e.showLoading({
                                        title: "加载中",
                                        mask: !0
                                    }), n.next = 31, t.$http.post("appointment", {
                                        type: t.type,
                                        data: t.form
                                    });

                                  case 31:
                                    (a = n.sent).data.packet, e.hideLoading(), a.data.state && (t.u_name = a.data.packet.name, 
                                    t.u_time = a.data.packet.time, t.page2 = !1, t.page3 = !0);

                                  case 35:
                                  case "end":
                                    return n.stop();
                                }
                            }, n);
                        }))();
                    },
                    clickMap: function() {
                        a.openLocation({
                            latitude: 29.57544,
                            longitude: 106.53003,
                            name: "观宸销售中心",
                            address: "重庆市江北区建新北路二支路观宸销售中心",
                            scale: 28,
                            infoUrl: "",
                            success: function() {},
                            fail: function(e) {}
                        });
                    },
                    clickTel: function() {
                        e.makePhoneCall({
                            phoneNumber: "02363210888"
                        });
                    },
                    isInteger: function(e) {
                        return Math.round(e) === e;
                    }
                }
            };
            t.default = c;
        }).call(this, n("543d").default, n("bc2e").default);
    }
}, [ [ "c4a1", "common/runtime", "common/vendor" ] ] ]);