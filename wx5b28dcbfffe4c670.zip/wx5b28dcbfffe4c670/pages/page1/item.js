(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/page1/item" ], {
    "1ce2": function(e, n, t) {
        t.r(n);
        var a = t("df2b"), r = t("6837");
        for (var u in r) [ "default" ].indexOf(u) < 0 && function(e) {
            t.d(n, e, function() {
                return r[e];
            });
        }(u);
        t("422d");
        var c = t("f0c5"), o = Object(c.a)(r.default, a.b, a.c, !1, null, "1febef76", null, !1, a.a, void 0);
        n.default = o.exports;
    },
    "422d": function(e, n, t) {
        var a = t("8133");
        t.n(a).a;
    },
    "4a4d": function(e, n, t) {
        (function(e) {
            var a = t("4ea4");
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var r = a(t("2eee")), u = a(t("c973")), c = (t("5cc3"), {
                components: {
                    TitleBar: function() {
                        t.e("components/TitleBar").then(function() {
                            return resolve(t("b7b4"));
                        }.bind(null, t)).catch(t.oe);
                    }
                },
                data: function() {
                    return {
                        swiperCurrentIndex: 0,
                        url: "",
                        list: []
                    };
                },
                onLoad: function() {
                    var e = this;
                    return (0, u.default)(r.default.mark(function n() {
                        var t;
                        return r.default.wrap(function(n) {
                            for (;;) switch (n.prev = n.next) {
                              case 0:
                                return n.next = 2, e.$http.get("query", {
                                    type: "imageItem"
                                });

                              case 2:
                                t = n.sent, console.log(t), e.url = t.data.packet.url, e.list = t.data.packet.list;

                              case 6:
                              case "end":
                                return n.stop();
                            }
                        }, n);
                    }))();
                },
                methods: {
                    change: function(e) {
                        this.swiperCurrentIndex = e.detail.current;
                    },
                    _to: function(n, t) {
                        e.navigateTo({
                            url: "/pages/" + n + "/" + t
                        });
                    }
                }
            });
            n.default = c;
        }).call(this, t("543d").default);
    },
    6837: function(e, n, t) {
        t.r(n);
        var a = t("4a4d"), r = t.n(a);
        for (var u in a) [ "default" ].indexOf(u) < 0 && function(e) {
            t.d(n, e, function() {
                return a[e];
            });
        }(u);
        n.default = r.a;
    },
    8133: function(e, n, t) {},
    b19d: function(e, n, t) {
        (function(e, n) {
            var a = t("4ea4");
            t("a9d3"), a(t("66fd"));
            var r = a(t("1ce2"));
            e.__webpack_require_UNI_MP_PLUGIN__ = t, n(r.default);
        }).call(this, t("bc2e").default, t("543d").createPage);
    },
    df2b: function(e, n, t) {
        t.d(n, "b", function() {
            return a;
        }), t.d(n, "c", function() {
            return r;
        }), t.d(n, "a", function() {});
        var a = function() {
            this.$createElement;
            this._self._c;
        }, r = [];
    }
}, [ [ "b19d", "common/runtime", "common/vendor" ] ] ]);