(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/page1/content" ], {
    "077a": function(e, n, t) {
        var a = t("9f46");
        t.n(a).a;
    },
    "2a6b": function(e, n, t) {
        (function(e, n) {
            var a = t("4ea4");
            t("a9d3"), a(t("66fd"));
            var r = a(t("950e"));
            e.__webpack_require_UNI_MP_PLUGIN__ = t, n(r.default);
        }).call(this, t("bc2e").default, t("543d").createPage);
    },
    "950e": function(e, n, t) {
        t.r(n);
        var a = t("c233"), r = t("d5ed");
        for (var c in r) [ "default" ].indexOf(c) < 0 && function(e) {
            t.d(n, e, function() {
                return r[e];
            });
        }(c);
        t("077a");
        var u = t("f0c5"), o = Object(u.a)(r.default, a.b, a.c, !1, null, "21bc2148", null, !1, a.a, void 0);
        n.default = o.exports;
    },
    "9f46": function(e, n, t) {},
    c233: function(e, n, t) {
        t.d(n, "b", function() {
            return a;
        }), t.d(n, "c", function() {
            return r;
        }), t.d(n, "a", function() {});
        var a = function() {
            this.$createElement;
            this._self._c;
        }, r = [];
    },
    d5ed: function(e, n, t) {
        t.r(n);
        var a = t("ef35"), r = t.n(a);
        for (var c in a) [ "default" ].indexOf(c) < 0 && function(e) {
            t.d(n, e, function() {
                return a[e];
            });
        }(c);
        n.default = r.a;
    },
    ef35: function(e, n, t) {
        var a = t("4ea4");
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), n.default = void 0;
        var r = a(t("2eee")), c = a(t("c973")), u = {
            components: {
                TitleBar: function() {
                    t.e("components/TitleBar").then(function() {
                        return resolve(t("b7b4"));
                    }.bind(null, t)).catch(t.oe);
                }
            },
            data: function() {
                return {
                    ct: []
                };
            },
            onShareAppMessage: function(e) {
                return {
                    title: "观宸 | 极核地标 世界藏品",
                    path: "/pages/index/index",
                    imageUrl: "/static/image/share.jpg"
                };
            },
            onLoad: function() {
                var e = this;
                return (0, c.default)(r.default.mark(function n() {
                    var t, a, c;
                    return r.default.wrap(function(n) {
                        for (;;) switch (n.prev = n.next) {
                          case 0:
                            return n.next = 2, e.$http.get("ct");

                          case 2:
                            for (t = n.sent, a = t.data.packet, c = 0; c < a.arr.length; c++) e.ct.push(a.url + a.arr[c]);

                          case 5:
                          case "end":
                            return n.stop();
                        }
                    }, n);
                }))();
            }
        };
        n.default = u;
    }
}, [ [ "2a6b", "common/runtime", "common/vendor" ] ] ]);