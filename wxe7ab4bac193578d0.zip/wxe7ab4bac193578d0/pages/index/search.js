var e = require("../../server/api");

function t(t) {
    var a = t.data, i = (a.orderTypeArray, a.filterTypeArray), r = a.orderTypePickerIndex, s = a._latlon, l = a._lastTypeTagSelectedIndex, c = a._lastPriceTagSelectedIndex, n = a._searchValue, d = "distanceOrder";
    1 == r ? d = "praiseOrder" : 2 == r && (d = "timeOrder");
    var o = 0 == l ? "" : i[l], h = void 0;
    "展览" != o && "活动" != o || (1 == c ? h = 1 : 2 == c && (h = 0)), (0, e.cmsSearch)(n, s.latitude, s.longitude, d, o, h).then(function(a) {
        if (200 == a.code && a.data.records.length > 0) {
            var i = a.data.records;
            i.forEach(function(t) {
                t.img = (0, e.fullImageUrlSaaS)(t.img), "展评" == t.flag ? t.typeColor = "#DB5151" : "活动" == t.flag ? t.typeColor = "#55A662" : (t.flag, 
                t.typeColor = "#cfb053"), t.name = t.name.replace(/<span>/g, '<span style="color:#ff0000">');
            }), t.setData({
                list: i
            });
        } else t.setData({
            list: []
        }), wx.showToast({
            title: "未检索到结果",
            icon: "none"
        });
    }).catch(function(t) {
        (0, e.defaultCatch)(t, "搜索失败");
    });
}

Page({
    options: {
        pureDataPattern: /^_/
    },
    data: {
        list: [],
        orderTypeArray: [ "距离最近", "好评优先", "最近发布" ],
        filterTypeArray: [ "全部", "场馆", "活动", "特展" ],
        inputValue: "",
        orderTypePickerIndex: 0,
        _latlon: {},
        _lastTypeTagSelectedIndex: 0,
        typeTagSelectedIndex: 0,
        _lastPriceTagSelectedIndex: 0,
        priceTagSelectedIndex: 0,
        filterTagVisiable: !1,
        _searchValue: "",
        searchHistroyArray: [],
        hotSearchArray: [ "湖北" ],
        showSearchHistroy: !0
    },
    onLoad: function(e) {
        var t;
        t = this, wx.showLoading({
            title: "加载中",
            mask: !0
        }), wx.getLocation({
            success: function(e) {
                console.log("定位成功"), wx.hideLoading();
                var a = {
                    longitude: e.longitude,
                    latitude: e.latitude
                };
                t.setData({
                    _latlon: a
                });
            }
        });
        var a = wx.getStorageSync("searchHistroy"), i = null == a ? [] : JSON.parse(a);
        i.length > 6 && (i = i.slice(-6)), this.setData({
            searchHistroyArray: i
        });
    },
    orderTypePickerChange: function(e) {
        var a = e.detail.value;
        this.data.orderTypePickerIndex != a && (this.setData({
            orderTypePickerIndex: a
        }), console.log("排序方式改变了"), t(this));
    },
    typeTagClick: function(e) {
        var t = e.currentTarget.dataset.index;
        this.data.typeTagSelectedIndex != t && (2 != t && 3 != t ? this.setData({
            typeTagSelectedIndex: t,
            priceTagSelectedIndex: 0,
            _lastPriceTagSelectedIndex: 0
        }) : this.setData({
            typeTagSelectedIndex: t
        }));
    },
    priceTagClick: function(e) {
        var t = e.currentTarget.dataset.index;
        this.data.priceTagSelectedIndex != t && this.setData({
            priceTagSelectedIndex: t
        });
    },
    showFilterTag: function() {
        this.setData({
            filterTagVisiable: !0
        });
    },
    cancelClick: function() {
        this.setData({
            filterTagVisiable: !1,
            typeTagSelectedIndex: this.data._lastTypeTagSelectedIndex,
            priceTagSelectedIndex: this.data._lastPriceTagSelectedIndex
        });
    },
    confirmClick: function() {
        this.setData({
            filterTagVisiable: !1
        });
        var e = !1;
        this.data.typeTagSelectedIndex != this.data._lastTypeTagSelectedIndex && (this.setData({
            _lastTypeTagSelectedIndex: this.data.typeTagSelectedIndex
        }), e = !0), this.data.priceTagSelectedIndex != this.data._lastPriceTagSelectedIndex && (this.setData({
            _lastPriceTagSelectedIndex: this.data.priceTagSelectedIndex
        }), e = !0), e && (console.log("筛选条件改变了"), t(this));
    },
    searchClick: function(e) {
        var a = e.detail.value;
        if (this.data._searchValue != a) if (this.setData({
            _searchValue: a,
            showSearchHistroy: !1
        }), console.log("搜索值改变了" + a), "" != a) {
            t(this);
            var i = this.data.searchHistroyArray;
            -1 == i.indexOf(a) && (i.push(a), wx.setStorageSync("searchHistroy", JSON.stringify(i)), 
            this.setData({
                searchHistroyArray: i
            }));
        } else wx.showToast({
            title: "请输入想要查询的内容",
            icon: "none"
        });
    },
    deleteImgClick: function(e) {
        wx.removeStorageSync("searchHistroy"), this.setData({
            searchHistroyArray: []
        });
    },
    searchHistroyClick: function(e) {
        var a = e.currentTarget.dataset.value;
        this.setData({
            inputValue: a,
            _searchValue: a,
            showSearchHistroy: !1
        }), t(this);
    },
    itemClick: function(e) {
        var t, a = e.currentTarget.dataset.index, i = this.data.list[a], r = {
            id: i.id,
            tenantId: i.tenantId
        };
        "特展" == i.flag ? t = "../exhibition/exhibitionDetail?data=" + JSON.stringify(r) : "活动" == i.flag ? t = "../activity/activityDetail?data=" + JSON.stringify(r) : "展评" == i.flag ? t = "../exhibition/findDetail?data=" + JSON.stringify(r) : "场馆" == i.flag && (t = "../museum/museumDetail?data=" + JSON.stringify(r)), 
        wx.navigateTo({
            url: t
        });
    }
});