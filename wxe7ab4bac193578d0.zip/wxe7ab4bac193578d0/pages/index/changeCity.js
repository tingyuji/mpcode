var t = require("../../@babel/runtime/helpers/toConsumableArray"), a = require("../../server/api");

Page({
    data: {
        list: [],
        currentCityData: {}
    },
    onLoad: function(e) {
        var n = this, i = e.city;
        (0, a.queryVenueCity)().then(function(a) {
            if (200 == a.code && null != a.data && a.data.length > 0) {
                var e = a.data;
                e = [ {
                    cityName: "不限",
                    count: e[0].totalCount
                } ].concat(t(e));
                for (var r = 0, c = {}, u = 0; u < e.length; u++) if (e[u].cityName == i) {
                    r = u, c = e[u];
                    break;
                }
                e.splice(r, 1), n.setData({
                    list: e,
                    currentCityData: c
                });
            } else n.setData({
                currentCityData: {
                    cityName: i,
                    count: 0
                }
            }), wx.showToast({
                title: "未获取到城市",
                icon: "none"
            });
        });
    },
    currentCityClick: function() {
        var t = this.data.currentCityData, a = getCurrentPages(), e = a[a.length - 2];
        wx.navigateBack({
            success: function() {
                e.changeCityBack(t);
            }
        });
    },
    otherCityClick: function(t) {
        var a = t.currentTarget.dataset.index, e = this.data.list[a], n = getCurrentPages(), i = n[n.length - 2];
        wx.navigateBack({
            success: function() {
                i.changeCityBack(e);
            }
        });
    }
});