var e = require("../../server/api"), t = require("../../utils/myUtil"), a = -1;

function o(a, o) {
    if ("3" == a.type && wx.navigateTo({
        url: "../teamAppoint/TeamAppointOrderDetail?shareCode=" + a.shareCode
    }), "4" == a.type && wx.navigateTo({
        url: "../appointment/orderDetail?orderPersonalId=" + a.orderPersonalId + "&systemId=" + getApp().globalData.systemId + "&companyInfoId=" + getApp().globalData.companyInfoId
    }), null != a.q) {
        var n = decodeURIComponent(a.q);
        console.log("扫码进入，内容为--" + n);
        var i = n.indexOf("?"), l = "", r = "", s = !1;
        if (-1 != i) {
            var c = n.substring(i + 1);
            if (0 != c.indexOf("&")) {
                var p = c.split("&");
                if (console.log(p), 0 != p[0].indexOf("=") && (l = p[0].split("=")[1]), 0 != p[1].indexOf("=") && (r = p[1].split("=")[1]), 
                console.log(l + "," + r), "personalSignIn" == l) {
                    0 != p[3].indexOf("=") && (s = p[3].split("=")[1]);
                    var g = "";
                    0 != p[2].indexOf("=") && (g = p[2].split("=")[1]), "true" == s ? (0, e.teamReserveQueryListForSign)().then(function(e) {
                        if (wx.hideLoading(), 200 != e.code) showWarningToast(e, "获取预约记录失败"); else {
                            if (!0 === e.data.isBook) {
                                var a = "../appointment/signInTeam?systemId=" + getApp().globalData.systemId + "&companyInfoId=" + getApp().globalData.companyInfoId;
                                return wx.navigateTo({
                                    url: a
                                }), a;
                            }
                            (0, t.toast)("今天没有预约");
                        }
                    }) : (0, e.personalReserveQueryListForSign)(g).then(function(e) {
                        if (wx.hideLoading(), 200 != e.code) showWarningToast(e, "获取预约记录失败"); else {
                            if (!0 === e.data.isBook) {
                                var t = "../appointment/signIn?systemId=" + getApp().globalData.systemId + "&companyInfoId=" + getApp().globalData.companyInfoId;
                                return wx.navigateTo({
                                    url: t
                                }), t;
                            }
                            if (null == getApp().globalData.userInfo) return;
                            wx.navigateTo({
                                url: "../appointment/home?isTeamAppoint=false"
                            });
                        }
                    });
                } else if ("activitySignIn" == l) (0, e.queryActivityShowCheckBookById)(r).then(function(e) {
                    if (wx.hideLoading(), 200 == e.code) {
                        if (!0 === e.data.isBook) {
                            var t = "../activity/activitySignIn?activityId=" + r;
                            return wx.navigateTo({
                                url: t
                            }), t;
                        }
                        var a = {
                            id: r,
                            tenantId: r
                        }, o = JSON.stringify(a);
                        return console.log("未预约" + o), wx.navigateTo({
                            url: "../activity/activityDetail?data=" + o
                        }), t;
                    }
                    a = {
                        id: r,
                        tenantId: r
                    }, o = JSON.stringify(a);
                    return console.log("未预约" + o), wx.navigateTo({
                        url: "../activity/activityDetail?data=" + o
                    }), t;
                }); else {
                    if ("exhibitionAppoint" == l) {
                        var d = "../exhibition/exhibitionDetail?id=" + r;
                        return wx.navigateTo({
                            url: d
                        }), d;
                    }
                    if ("scanPcCode" == l) wx.navigateTo({
                        url: "../teamAppoint/ShareTeamAppoint?teamShareCode=" + r
                    }); else {
                        if ("scanPcGetCode" != l) return (0, t.toast)("请扫描正确的二维码"), "";
                        wx.navigateTo({
                            url: "../teamAppoint/shareAppointErwm?teamShareCode=" + r
                        });
                    }
                }
            }
        }
    }
}

function n(a) {
    var o = wx.getStorageSync(getApp().globalData.openId + "_realName");
    if ("" != o && null != o) {
        var n = JSON.parse(o);
        if ((0, t.strIsNotEpmty)(n.customerName) && (0, t.strIsNotEpmty)(n.showDocumentNumber) && (0, 
        t.strIsNotEpmty)(n.phoneNumber) && (0, t.strIsNotEpmty)(n.customerContactId) && (0, 
        t.strIsNotEpmty)(n.documentType)) console.log("缓存中有实名认证信息，不再请求"), a.setData({
            realNameHttpSuccess: !0
        }), getApp().globalData.userInfo = n, getApp().globalData.isHasSelf = !0; else {
            console.error("缓存中实名认证信息不完整，开始重新请求并覆盖"), console.log(o), (0, t.onlineLog)("缓存中实名认证信息不完整，开始重新请求并覆盖，" + o);
            try {
                wx.removeStorageSync(getApp().globalData.openId + "_realName");
            } catch (e) {}
            i(a);
        }
    } else console.log("缓存中没有实名认证信息，开始请求"), i(a);
    function i(t) {
        wx.showLoading({
            title: "加载中...",
            mask: !0
        }), (0, e.queryCertList)().then(function(e) {
            wx.hideLoading(), t.setData({
                realNameHttpSuccess: !0
            }), 200 === e.code && null != e.data && e.data.length > 0 ? (console.log("获取实名认证成功，并保存本地缓存，下次进入将不再获取"), 
            getApp().globalData.userInfo = e.data[0], getApp().globalData.isHasSelf = !0, wx.setStorage({
                key: getApp().globalData.openId + "_realName",
                data: JSON.stringify(e.data[0])
            }), console.log("获取个人信息失败333：" + getApp().globalData.systemId)) : 200 === e.code && (null == e.data || e.data.length <= 0) ? (getApp().globalData.isHasSelf = !1, 
            wx.showModal({
                title: "提示",
                content: "请先进行实名认证",
                cancelColor: "",
                showCancel: !0,
                success: function(e) {
                    e.confirm && wx.navigateTo({
                        url: "../contacts/realNameCertification?pageUrl=0"
                    });
                }
            })) : (t.setData({
                realNameHttpSuccess: !1
            }), console.error("获取实名认证信息失败1", e));
        }).catch(function(e) {
            wx.hideLoading(), t.setData({
                realNameHttpSuccess: !1
            }), console.error("获取实名认证信息失败2", e);
        });
    }
}

function i() {
    (0, e.queryPersonalReserveRule)(getApp().globalData.systemId, getApp().globalData.companyInfoId).then(function(e) {
        200 == e.code ? getApp().globalData.personalReserveRule = e.data : (0, t.onlineLog)("首页获取预约规则失败，" + JSON.stringify(e));
    }).catch(function(e) {
        console.error("获取预约规则失败" + e);
    });
}

Page({
    data: {
        imgModel: {},
        isHiddleFubiao: !0,
        isOpenFubiao: !1,
        fubiaoDataArr: [],
        renZrichTextNode: "",
        indicatorDots: !1,
        hiddlePop: !0,
        hiddleTongzhiPop: !0,
        hiddenGunDong: !0,
        tongzhiNotice: "",
        isFree: !1,
        isXinhai: !1,
        richTextNode: "",
        realNameHttpSuccess: !0
    },
    onLoad: function(e) {
        var t = wx.getSystemInfoSync();
        console.log(t.platform), "windows" != t.platform && "mac" != t.platform ? function(e, t) {
            "" !== getApp().globalData.authorizationc ? (n(t), o(e, t), i()) : (getApp().tokenReadyCallback = function(a) {
                if (200 == a.code) n(t), o(e, t), i(); else {
                    var l = encodeURIComponent(o(e, t));
                    console.log("跳转登录前,", l);
                }
            }, getApp().tokenFailedCallback = function() {
                console.error("登录失败");
            });
        }(e, this) : wx.showModal({
            title: "温馨提示!",
            content: "请使用手机端登录",
            showCancel: !1,
            success: function(e) {
                wx.exitMiniProgram();
            }
        });
    },
    onShow: function() {
        this.setData({
            hiddlePop: !0
        });
    },
    onUnload: function() {
        clearTimeout();
    },
    reloadContactsData: function() {},
    onShareAppMessage: function() {},
    onShareTimeline: function() {
        return {
            title: "军事博物馆票务预约",
            imageUrl: ""
        };
    },
    popViewCloseImgClick: function(e) {
        this.setData({
            hiddlePop: !0
        });
    },
    popViewSavebtnClick: function(e) {
        wx.navigateTo({
            url: "../teamAppoint/JigouCertification"
        });
    },
    tongzhiPopViewClick: function(e) {
        this.setData({
            hiddleTongzhiPop: !0
        });
    },
    btnTap: function(o) {
        var n, i;
        this.data.realNameHttpSuccess ? (a = parseInt(o.target.dataset.index), i = this, 
        1 == (n = a) || 2 == n ? (console.log(getApp().globalData.authorizationc), "" == getApp().globalData.authorizationc ? wx.navigateTo({
            url: "../login/phoneLogin"
        }) : null == getApp().globalData.userInfo ? (getApp().globalData.isHasSelf = !1, 
        wx.showModal({
            title: "提示",
            content: "请先进行实名认证",
            cancelColor: "",
            showCancel: !0,
            success: function(e) {
                e.confirm && wx.navigateTo({
                    url: "../contacts/realNameCertification?pageUrl=0"
                });
            }
        })) : 1 == n ? wx.navigateTo({
            url: "../appointment/home?isTeamAppoint=false"
        }) : ((0, t.showLoading)(), (0, e.teamReserveCheckCondition)(getApp().globalData.systemId).then(function(a) {
            wx.hideLoading(), 429 === a.code ? (i.setData({
                hiddlePop: !1
            }), function(t) {
                (0, e.queryTeamCertificationTip)(getApp().globalData.systemId, getApp().globalData.companyInfoId).then(function(e) {
                    200 == e.code ? "" == e.data.ruleValue || null == e.data.ruleValue ? t.setData({
                        renZrichTextNode: "暂无认证须知"
                    }) : t.setData({
                        renZrichTextNode: e.data.ruleValue
                    }) : wx.showToast({
                        title: e.msg,
                        icon: "none"
                    });
                });
            }(i)) : 428 === a.code ? (0, t.modal)(a.msg, function() {
                (0, t.navigateTo)("../userCenter/jigouCertification");
            }) : 430 === a.code || 431 === a.code ? ((0, t.toast)(a.msg), setTimeout(function() {
                wx.navigateTo({
                    url: "../userCenter/jigouCertification"
                });
            }, 2e3)) : 453 === a.code ? wx.navigateTo({
                url: "../contacts/realNameCertification"
            }) : 200 == a.code ? wx.navigateTo({
                url: "../appointment/home?isTeamAppoint=true"
            }) : (a.code, (0, t.modal)(a.msg, function() {}));
        }).catch(function(e) {
            (0, t.hideLoading)(), console.error(e);
        }))) : 3 == n && ("" == getApp().globalData.authorizationc ? wx.navigateTo({
            url: "../login/phoneLogin"
        }) : wx.navigateTo({
            url: "../userCenter/userCenter"
        }))) : (0, t.toast)("当前排队人数较多，请稍后重试");
    }
});