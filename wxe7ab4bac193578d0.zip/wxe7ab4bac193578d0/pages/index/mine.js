var a = require("../../server/api");

function t(t) {
    wx.showLoading({
        title: "加载中...",
        mask: !0
    }), (0, a.queryCertList)().then(function(a) {
        wx.hideLoading(), 200 === a.code && null != a.data && a.data.length > 0 ? (getApp().globalData.userInfo = a.data[0], 
        t.setData({
            userModel: a.data[0],
            useName: null == a.data[0].customerName ? "" : a.data[0].customerName
        })) : 200 === a.code && (null == a.data || a.data.length <= 0) && t.setData({
            useName: "点击实名认证"
        });
    }).catch(function(a) {
        wx.hideLoading(), wx.showToast({
            title: "获取个人信息失败",
            icon: "none"
        }), console.log("获取个人信息失败" + a);
    });
}

Page({
    data: {
        cardtypeArr: [ {
            text: "身份证",
            Id: "DAM0101"
        }, {
            text: "军官证",
            Id: "DAM0105"
        }, {
            text: "护照",
            Id: "DAM0102"
        }, {
            text: "台胞证",
            Id: "DAM0104"
        }, {
            text: "港澳证",
            Id: "DAM0103"
        } ],
        cardtypeNameArr: [ "身份证", "军官证", "护照", "台胞证", "港澳证" ],
        userModel: {},
        image_photo: "",
        loginName: "",
        currentorderTabIndex: 0,
        isHasUser: !1,
        isHiddlenFamilyCell: !0,
        isHasVip: !1,
        useName: ""
    },
    onTopTabItemTap: function(a) {
        if ("" != getApp().globalData.authorizationc) {
            var t = a.currentTarget.dataset.index;
            2 == t ? wx.navigateTo({
                url: "../contacts/contactsList"
            }) : 1 == t && wx.navigateTo({
                url: "../appointment/myOrderList"
            });
        } else wx.navigateTo({
            url: "../login/login"
        });
    },
    onLoad: function(a) {
        "" == getApp().globalData.authorizationc ? (this.setData({
            useName: "点击登录"
        }), wx.navigateTo({
            url: "../login/login"
        })) : t(this);
    },
    login: function(a) {
        "点击登录" == this.data.useName ? wx.navigateTo({
            url: "../login/login"
        }) : "点击实名认证" == this.data.useName && wx.navigateTo({
            url: "../contacts/realNameCertification"
        });
    },
    reloadContactsData: function(a) {
        t(this);
    },
    changemsgClick: function(a) {},
    cardtypepickerclick: function(a) {
        console.log(a.detail.value);
    }
});