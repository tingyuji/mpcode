var e = require("../../utils/weapp-qrcode.js"), t = 400 / (750 / wx.getSystemInfoSync().windowWidth);

Page({
    data: {
        model: {},
        qrcode_w: t
    },
    onLoad: function(o) {
        console.log(o.data);
        var n = JSON.parse(o.data);
        null != n.documentNumber && n.documentNumber.length > 15 && (n.documentNumberHide = n.documentNumber.toString(), 
        n.documentNumberHide = n.documentNumberHide.substring(0, 3) + "************" + n.documentNumberHide.substring(15)), 
        n.isHideIdcard = !0, n.documentNumberStr = n.documentNumberHide;
        var d;
        d = n.childOrderId, new e("canvas0", {
            text: d,
            width: t,
            height: t,
            colorDark: "#000000",
            colorLight: "white",
            correctLevel: e.CorrectLevel.H
        }), this.setData({
            model: n
        }), wx.setNavigationBarTitle({
            title: n.typeValue + "预约详情"
        });
    },
    onReady: function() {},
    onShow: function() {},
    eyesImgClick: function(e) {
        var t = this.data.model;
        0 == t.isHideIdcard ? (t.isHideIdcard = !0, t.documentNumberStr = t.documentNumberHide) : (t.isHideIdcard = !1, 
        t.documentNumberStr = t.documentNumber), this.setData({
            model: t
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});