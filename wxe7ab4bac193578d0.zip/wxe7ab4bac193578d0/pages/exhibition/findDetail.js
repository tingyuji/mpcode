var t = require("../../@babel/runtime/helpers/interopRequireDefault").default, a = require("../../server/api"), i = t(require("../../utils/richTextStyleUtil")), e = getApp();

Page({
    data: {
        type: 0,
        address: "",
        distance: "",
        info: {},
        bottomBarData: {}
    },
    onLoad: function(t) {
        var e, n, o = JSON.parse(t.data);
        this.setData({}), e = this, n = o.id, wx.showLoading({
            title: "加载中..."
        }), (0, a.queryExhibitionReviewById)(n).then(function(t) {
            if (200 === t.code) {
                var n = t.data, o = {
                    objectId: n.id,
                    objectTitle: n.name,
                    objectThumb: n.thumb,
                    block: "EXHIBITION_PREVIEW",
                    subBlock: "EXHIBITION_PREVIEW"
                };
                n.thumb = (0, a.fullImageUrl)(n.thumb), n.description = (0, i.default)(n.description);
                var l = new Date().getTime() - new Date(n.createTime.replace(/-/g, "/")).getTime();
                if (n.timeStr = Math.round(l / 1e3 / 3600 / 24) + "天前", e.setData({
                    info: n,
                    bottomBarData: o
                }), wx.hideLoading(), null != n.label && n.label.length > 0) {
                    var r = "";
                    n.label.forEach(function(t) {
                        r = r + t.labelId + ",";
                    }), function(t, i) {
                        (0, a.labelSearch)(i);
                    }(0, r = r.substring(0, r.length - 1));
                }
            } else (0, a.showWarningToast)(t);
        });
    },
    zhanlanDetailClick: function(t) {
        var a = {
            id: this.data.info.exhibitionId,
            type: 0,
            address: this.data.address,
            distance: this.data.distance
        }, i = JSON.stringify(a);
        wx.navigateTo({
            url: "../exhibition/exhibitionDetail?data=" + i
        });
    },
    updateLikeNum: function(t) {
        if ("cancel" == t.detail.type) (a = this.data.info).praiseCount--, this.setData({
            info: a
        }); else if ("add" == t.detail.type) {
            var a;
            (a = this.data.info).praiseCount++, this.setData({
                info: a
            });
        }
    },
    updateFavoriteNum: function(t) {
        if ("cancel" == t.detail.type) (a = this.data.info).favoriteCount--, this.setData({
            info: a
        }); else if ("add" == t.detail.type) {
            var a;
            (a = this.data.info).favoriteCount++, this.setData({
                info: a
            });
        }
    },
    likeOnTap: function() {
        "" == e.globalData.authorizationc && wx.navigateTo({
            url: "../login/login"
        });
    },
    favoritesOnTap: function() {
        "" == e.globalData.authorizationc && wx.navigateTo({
            url: "../login/login"
        });
    },
    appointmentOnTap: function() {
        console.log("111111"), "" == e.globalData.authorizationc && wx.navigateTo({
            url: "../login/login"
        });
    },
    museumClick: function() {
        var t = {
            id: this.data.info.venueId
        };
        wx.navigateTo({
            url: "../museum/museumDetail?data=" + JSON.stringify(t)
        });
    }
});