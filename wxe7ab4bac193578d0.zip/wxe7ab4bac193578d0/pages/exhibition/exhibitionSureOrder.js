var t = require("../../server/api");

Page({
    data: {
        info: {},
        actEndTimeList: [],
        orderStatusStr: "",
        orderCost: "",
        payBtnStr: "",
        hidenPayBtn: !1,
        hiddenBaozhangPop: !0
    },
    onLoad: function(t) {
        var e = JSON.parse(t.data);
        !0 === e.needPay ? this.setData({
            payBtnStr: "立即支付",
            hidenPayBtn: !1
        }) : this.setData({
            payBtnStr: "确认订单",
            hidenPayBtn: !1,
            orderStatusStr: "免费"
        }), this.setData({
            info: e,
            orderCost: e.orderCost,
            actEndTimeList: e.actEndTimeList
        }), this.countDown();
    },
    securityClick: function() {
        this.setData({
            hiddenBaozhangPop: !1
        });
    },
    baozhangCloseImgClick: function() {
        this.setData({
            hiddenBaozhangPop: !0
        });
    },
    openMuseum: function() {
        var e = {
            id: this.data.info.companyInfoId,
            tenantId: this.data.info.companyInfoId
        };
        (0, t.queryVenueById)(this.data.info.companyInfoId).then(function(t) {
            200 == t.code ? null == t.data ? wx.showModal({
                title: "提示",
                content: "场馆信息未开放",
                showCancel: !1,
                success: function(t) {
                    t.confirm;
                }
            }) : wx.navigateTo({
                url: "../museum/museumDetail?data=" + JSON.stringify(e)
            }) : wx.showModal({
                title: "提示",
                content: "场馆信息未开放",
                showCancel: !1,
                success: function(t) {
                    t.confirm;
                }
            });
        });
    },
    payBtnClick: function(e) {
        wx.showLoading({
            title: "加载中...",
            mask: !0
        });
        var n = this.data.info;
        n.price > 0 ? (0, t.queryExihibitionsureOrderPay)(this.data.orderCost, n.orderId, "EXH", n.name, n.systemId).then(function(a) {
            if (wx.hideLoading(), 200 == a.code) console.log("支付成功"), null != a.data && wx.requestPayment({
                timeStamp: a.data.timeStamp,
                nonceStr: a.data.nonceStr,
                package: a.data.package,
                signType: a.data.signType,
                paySign: a.data.paySign,
                appId: wx.getAccountInfoSync().miniProgram.appId,
                success: function(a) {
                    (0, t.queryExihibitionConfirmOrder)(n.orderId, n.systemId, "SUCCESS").then(function(t) {
                        if (200 == t.code) {
                            var a = t.data.tips;
                            wx.showToast({
                                title: "支付成功",
                                icon: "success"
                            }), n.needPay = !1;
                            var i = JSON.stringify(n);
                            wx.navigateTo({
                                url: "exhibitionAppointSuccess?data=" + i,
                                success: function(t) {
                                    t.eventChannel.emit("acceptDataFromOpenerPage", {
                                        tips: a
                                    });
                                }
                            });
                        } else wx.hideLoading(), console.debug("提交订单失败", e);
                    }).catch(function(t) {
                        wx.hideLoading(), console.debug("提交订单失败", t);
                    });
                },
                fail: function(t) {
                    wx.showToast({
                        title: "未支付成功",
                        icon: "none"
                    }), n.needPay = !0;
                    JSON.stringify(n);
                    console.error("请确保微信支付已开通320" + t);
                },
                complete: function(t) {}
            }); else {
                wx.showToast({
                    title: "支付失败",
                    icon: "none"
                });
                JSON.stringify(n);
                n.needPay = !0;
            }
        }).catch(function(t) {
            wx.hideLoading(), console.debug("提交订单失败", t);
        }) : (0, t.saveForFreeOrderSubmit)(n.displayInfoId, n.customerContactId, n.price, n.currentDateStr, n.currentTimeStr, n.seleMemberArr, "", 1).then(function(t) {
            if (wx.hideLoading(), 200 == t.code) {
                wx.showToast({
                    title: "确认成功",
                    icon: "success"
                });
                var e = t.data.tips;
                n.needPay = !1, n.orderId = t.data.orderId;
                var a = JSON.stringify(n);
                wx.navigateTo({
                    url: "exhibitionAppointSuccess?data=" + a,
                    success: function(t) {
                        t.eventChannel.emit("acceptDataFromOpenerPage", {
                            tips: e
                        });
                    }
                });
            } else wx.showToast({
                title: t.msg,
                icon: "none"
            });
        }).catch(function(t) {
            wx.hideLoading(), console.debug("提交订单失败", t);
        });
    },
    timeFormat: function(t) {
        return t < 10 ? "0" + t : t;
    },
    onUnload: function() {
        clearInterval(this.countDown);
    },
    countDown: function() {
        var t = this, e = new Date().getTime(), n = this.data.actEndTimeList, a = {}, i = this;
        n.forEach(function(n) {
            var o = new Date(n).getTime(), s = null;
            if (o - e > 0) {
                var r = (o - e) / 1e3, c = parseInt(r / 86400), d = parseInt(r % 86400 / 3600), u = parseInt(r % 86400 % 3600 / 60), h = parseInt(r % 86400 % 3600 % 60);
                s = {
                    day: t.timeFormat(c),
                    hou: t.timeFormat(d),
                    min: t.timeFormat(u),
                    sec: t.timeFormat(h)
                };
            } else i.setData({
                hidenPayBtn: !0,
                orderStatusStr: "未支付，订单已取消"
            }), s = {
                day: "00",
                hou: "00",
                min: "00",
                sec: "00"
            };
            a = s;
        }), !0 === i.data.info.needPay && 1 != i.data.hidenPayBtn && i.setData({
            orderStatusStr: "支付中（付款倒计时:" + a.hou + "时" + a.min + "分" + a.sec + "秒）"
        }), setTimeout(i.countDown, 1e3);
    }
});