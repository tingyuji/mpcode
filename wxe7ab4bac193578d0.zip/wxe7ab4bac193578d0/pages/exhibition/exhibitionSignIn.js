getApp();

var t = require("../../server/api.js"), e = t.exhibitionQueryOrderHexiaoDetail, a = t.hexiaoExihibitionOrderSubmit, i = t.queryExihibitionsureOrderPay, n = t.queryVenueById, o = t.queryExhibitionById, s = require("../../utils/weapp-qrcode.js"), r = 320 / (750 / wx.getSystemInfoSync().windowWidth);

function d(t, a) {
    console.log("特展id" + a), wx.showLoading({
        title: "加载中...",
        mask: !0
    }), e(a).then(function(e) {
        if (wx.hideLoading(), 200 == e.code) {
            var a = e.data;
            if (a.price > 0 ? a.coststr = "￥" + a.price : a.coststr = "免费", 0 === a.unsubscribeDate ? (a.popBaozhangStr = "最迟观展日期前3天可退", 
            a.popBaozhangContentStr = "最迟退订时间为参观日期三天前的晚24点整。如参观日期为1月4日，则1月1日晚24点整前均可退订。") : 1 === a.unsubscribeDate ? (a.popBaozhangStr = "最迟观展日期前1天可退", 
            a.popBaozhangContentStr = "最迟退订时间为参观日期一天前的晚24点整。如参观日期为1月4日，则1月3日晚24点整前均可退订。") : 2 === a.unsubscribeDate ? (a.popBaozhangStr = "最迟观展日期当天可退", 
            a.popBaozhangContentStr = "最迟退订时间为参观日期当天的晚24点整。如参观日期为8月4日，则8月4日晚24点整前均可退订。") : (a.popBaozhangStr = "联系后台工作人员", 
            a.popBaozhangContentStr = "联系后台工作人员"), a.tuidingState = !0, 0 === a.orderStatus) {
                a.orderStatusHiddle = !1, a.payBtnStr = "立即支付";
                var i = a.cutTime.replace(/-/g, "/"), n = [];
                [ {
                    actEndTime: i
                } ].forEach(function(t) {
                    n.push(t.actEndTime);
                }), t.setData({
                    actEndTimeList: n
                }), t.countDown();
            } else 1 === a.orderStatus || 2 === a.orderStatus ? (a.tuidingState = !1, a.tuidingStateStr = "退 订") : (a.orderStatus, 
            a.tuidingState = !0, a.orderStatusHiddle = !0);
            var o = [], d = [], c = !1;
            a.hiddenBottomBtn = !1, a.childOrderList.forEach(function(t, e) {
                t.seleted = !1, 0 != t.reserveStatus && d.push(t), t.isHideIdcard = !0, t.documentNumberStr = t.documentNumber, 
                -1 == t.reserveStatus ? (t.stateBtnStr = "支 付", t.stateBtnHiddle = !0, t.iscancle = !1) : 0 == t.reserveStatus ? "已过期" == t.reserveStatusStr ? (t.stateBtnStr = "", 
                t.stateBtnHiddle = !0, t.iscancle = !0) : (t.stateBtnHiddle = !1, t.iscancle = !1, 
                c = !0) : "待使用" == t.reserveStatusValue ? (t.stateBtnHiddle = !1, t.iscancle = !1, 
                c = !0, t.reserveStatusImg = "../../images/center/daishiyong.png") : "已预约" == t.reserveStatusValue ? (t.stateBtnHiddle = !1, 
                t.iscancle = !1, c = !0, t.reserveStatusImg = "../../images/center/yiyuyue.png") : "已使用" == t.reserveStatusValue ? (t.stateBtnStr = "", 
                t.stateBtnHiddle = !0, t.iscancle = !0, t.reserveStatusImg = "../../images/center/yishiyong.png") : "已观展" == t.reserveStatusValue ? (t.stateBtnStr = "", 
                t.stateBtnHiddle = !0, t.iscancle = !0, t.reserveStatusImg = "../../images/center/yiguanzhan.png") : "已过期" == t.reserveStatusValue ? (t.stateBtnStr = "", 
                t.stateBtnHiddle = !0, t.iscancle = !0, t.reserveStatusImg = "../../images/center/yiguoqi.png") : "已退订" == t.reserveStatusValue ? (t.stateBtnStr = "", 
                t.stateBtnHiddle = !0, t.iscancle = !0, t.reserveStatusImg = "../../images/center/yituiding.png") : (t.stateBtnStr = "", 
                t.stateBtnHiddle = !0, t.iscancle = !0), 0 == t.refund && (t.stateBtnStr = "", t.stateBtnHiddle = !0, 
                t.iscancle = !0);
                var a, i = "canvas" + e;
                a = t.childOrderId, new s(i, {
                    text: a,
                    width: r,
                    height: r,
                    colorDark: "#000000",
                    colorLight: "white",
                    correctLevel: s.CorrectLevel.H
                }), o.push(t);
            }), d.length === a.childOrderList.length && (a.hiddenBottomBtn = !0), !1 === t.data.heXiaoHiddenState && !0 === c ? (a.tuidingState = !0, 
            a.orderStatusHiddle = !0) : !1 === t.data.heXiaoHiddenState && !1 === c && (a.tuidingState = !0, 
            a.orderStatusHiddle = !0, t.setData({
                heXiaoHiddenState: !0
            })), console.log("此时可核销" + c + "dict.orderStatusHiddle" + a.orderStatusHiddle), 
            a.timeLabelStr = a.subscribeStartDate + " 至 " + a.subscribeEndDate, null !== a.subscribeEndDate && "" !== a.subscribeEndDate || (a.timeLabelStr = a.subscribeStartDate + " 开幕"), 
            a.exhibitionTime = a.displayStartTime + " 至 " + a.displayEndTime, null !== a.displayStartTime && "" !== a.displayEndTime || (a.exhibitionTime = a.displayStartTime + " 开始"), 
            a.price = 0 == a.price || null == a.price ? "免费" : "¥" + a.price + "元", t.setData({
                model: a,
                orderStatusStr: a.orderStatusStr,
                hideProgress: !0,
                memberArr: o
            });
        } else wx.showToast({
            title: e.msg
        });
    });
}

Page({
    data: {
        orderId: "",
        model: {},
        memberArr: [],
        qrcode_w: r,
        hideProgress: !1,
        actEndTimeList: [],
        actcreateTimeStr: "",
        orderStatusStr: "",
        surebtnStr: "",
        seletDataArr: [],
        isCanCommit: !1,
        heXiaoHiddenState: !0,
        hiddenBaozhangPop: !0
    },
    onLoad: function(t) {
        !0, console.log("监听页面加载" + t.heXiaoHiddenState), "false" === t.heXiaoHiddenState ? t.heXiaoHiddenState = !1 : t.heXiaoHiddenState = !0, 
        this.setData({
            hideProgress: !1,
            orderId: t.displayInfoId,
            heXiaoHiddenState: t.heXiaoHiddenState
        }), d(this, t.displayInfoId);
    },
    exhibitionTitleClick: function(t) {
        var e = {
            id: this.data.model.displayInfoId,
            tenantId: this.data.model.systemId,
            praiseCount: 0,
            favoriteCount: 0
        }, a = JSON.stringify(e);
        o(this.data.model.displayInfoId).then(function(t) {
            200 === t.code ? null == t.data ? wx.showModal({
                title: "提示",
                content: "特展已下架",
                showCancel: !1,
                success: function(t) {
                    t.confirm;
                }
            }) : wx.redirectTo({
                url: "../exhibition/exhibitionDetail?data=" + a
            }) : wx.showModal({
                title: "提示",
                content: "特展已下架",
                showCancel: !1,
                success: function(t) {
                    t.confirm;
                }
            });
        });
    },
    securityClick: function() {
        this.setData({
            hiddenBaozhangPop: !1
        });
    },
    baozhangCloseImgClick: function() {
        this.setData({
            hiddenBaozhangPop: !0
        });
    },
    openMuseum: function() {
        var t = {
            id: this.data.model.companyInfoId,
            tenantId: this.data.model.companyInfoId
        };
        n(this.data.model.companyInfoId).then(function(e) {
            200 == e.code ? null == e.data ? wx.showModal({
                title: "提示",
                content: "场馆信息未开放",
                showCancel: !1,
                success: function(t) {
                    t.confirm;
                }
            }) : wx.redirectTo({
                url: "../museum/museumDetail?data=" + JSON.stringify(t)
            }) : wx.showModal({
                title: "提示",
                content: "场馆信息未开放",
                showCancel: !1,
                success: function(t) {
                    t.confirm;
                }
            });
        });
    },
    payBtnClick: function(t) {
        !function(t) {
            wx.showLoading({
                title: "加载中...",
                mask: !0
            });
            var e = t.data.model;
            i(e.price, e.orderId, "EXH", e.name, e.systemId).then(function(e) {
                wx.hideLoading(), 200 == e.code ? (console.log("支付成功"), null != e.data && wx.requestPayment({
                    timeStamp: e.data.timeStamp,
                    nonceStr: e.data.nonceStr,
                    package: e.data.package,
                    signType: e.data.signType,
                    paySign: e.data.paySign,
                    appId: wx.getAccountInfoSync().miniProgram.appId,
                    success: function(e) {
                        d(t, t.data.orderId), wx.showToast({
                            title: "支付成功",
                            icon: "success"
                        });
                    },
                    fail: function(t) {
                        console.error("请确保微信支付已开通320" + t);
                    },
                    complete: function(t) {}
                })) : wx.showToast({
                    title: "支付失败",
                    icon: "none"
                });
            }).catch(function(t) {
                wx.hideLoading(), console.debug("提交订单失败", t);
            });
        }(this);
    },
    eyesImgClick: function(t) {
        var e = parseInt(t.currentTarget.dataset.index), a = this.data.model.childOrderList;
        console.log("证件号隐藏按钮点击" + e), a.forEach(function(t, a) {
            e == a && (0 == t.isHideIdcard ? (t.isHideIdcard = !0, t.documentNumberStr = t.documentNumberHide) : (t.isHideIdcard = !1, 
            t.documentNumberStr = t.documentNumber));
        });
        var i = this.data.model;
        i.childOrderList = a, this.setData({
            model: i
        });
    },
    orderListClick: function(t) {
        var e = parseInt(t.currentTarget.dataset.index), a = this.data.model.childOrderList, i = (this.data.seletDataArr, 
        []), n = [];
        a.forEach(function(t, a) {
            1 != t.iscancle && (e == a && (0 == t.seleted ? t.seleted = !0 : t.seleted = !1), 
            1 == t.seleted && (i.push(t.childOrderId), n.push(t)));
        });
        var o = !1;
        o = 0 != i.length;
        var s = this.data.model;
        s.childOrderList = a, this.setData({
            seletDataArr: i,
            rebookCountArr: n,
            model: s,
            isCanCommit: o
        });
    },
    heXiaoBtnClick: function(t) {
        console.log(this.data.seletDataArr);
        var e = this;
        if (0 != this.data.isCanCommit) {
            var i = this.data.seletDataArr;
            wx.showModal({
                title: "是否确定核销？",
                content: "请务必在工作人员的确认下核销订单。请勿提前自行点击核销按钮。核销界面截图不可作为参观凭证。",
                cancelText: "暂不核销",
                confirmText: "立即核销",
                cancelColor: "#525252",
                confirmColor: "#DB5151",
                success: function(t) {
                    t.confirm ? (console.log("用户点击确定"), e.setData({
                        hideProgress: !1
                    }), wx.showLoading({
                        title: "加载中...",
                        mask: !0
                    }), a(i, e.data.model.displayInfoId).then(function(t) {
                        if (wx.hideLoading(), 200 == t.code) {
                            t.data;
                            wx.showModal({
                                title: "提示",
                                content: "核销成功!",
                                showCancel: !1
                            }), e.setData({
                                seletDataArr: []
                            }), d(e, e.data.orderId);
                        } else console.debug("核销失败" + t.msg), wx.showModal({
                            title: "核销失败",
                            content: t.msg,
                            showCancel: !1
                        });
                    }).catch(function(t) {
                        wx.hideLoading(), console.debug("核销失败", t);
                    })) : t.cancel && console.log("用户点击取消");
                }
            });
        }
    },
    onShow: function() {},
    timeFormat: function(t) {
        return t < 10 ? "0" + t : t;
    },
    onUnload: function() {
        clearInterval(this.countDown);
    },
    countDown: function() {
        var t = this, e = new Date().getTime(), a = this.data.actEndTimeList, i = {}, n = this;
        a.forEach(function(a) {
            var o = new Date(a).getTime(), s = null;
            if (o - e > 0) {
                var r = (o - e) / 1e3, c = parseInt(r / 86400), l = parseInt(r % 86400 / 3600), u = parseInt(r % 86400 % 3600 / 60), h = parseInt(r % 86400 % 3600 % 60);
                s = {
                    day: t.timeFormat(c),
                    hou: t.timeFormat(l),
                    min: t.timeFormat(u),
                    sec: t.timeFormat(h)
                };
            } else 4 === n.data.model.orderStatus && d(n, n.data.orderId), s = {
                day: "00",
                hou: "00",
                min: "00",
                sec: "00"
            };
            i = s;
        }), 0 === n.data.model.orderStatus && n.setData({
            orderStatusStr: "支付中（付款倒计时:" + i.hou + "时" + i.min + "分" + i.sec + "秒）"
        }), setTimeout(n.countDown, 1e3);
    }
});