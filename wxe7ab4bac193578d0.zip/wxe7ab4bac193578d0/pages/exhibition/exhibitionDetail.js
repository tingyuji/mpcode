var a = require("../../@babel/runtime/helpers/interopRequireDefault").default, t = require("../../server/api"), o = require("../../server/http"), n = a(require("../../utils/richTextStyleUtil")), i = getApp();

Page({
    data: {
        info: {},
        bottomBarData: {},
        hiddenBaozhangPop: !0,
        hiddlePop: !0,
        baozhangInfo: {},
        praiseCount: "",
        favoriteCount: ""
    },
    onLoad: function(a) {
        console.log(a.data);
        var i, e, r = JSON.parse(a.data);
        i = this, e = r.id, (0, t.queryExhibitionById)(e).then(function(a) {
            if (200 === a.code) {
                var e = {
                    objectId: a.data.displayInfoId,
                    systemId: a.data.systemId,
                    objectTitle: a.data.name,
                    objectThumb: a.data.displayPoster,
                    block: "EXHIBITION",
                    subBlock: "3"
                };
                (0, t.customerFootprint)(e, 3).then(function(a) {}), a.data.description = (0, n.default)(a.data.description), 
                a.data.introductionStr = (0, n.default)(a.data.introduction), a.data.informationStr = (0, 
                n.default)(a.data.information), a.data.timeLabelStr = a.data.startTime + " 至 " + a.data.endTime, 
                null !== a.data.endTime && "" !== a.data.endTime || (a.data.timeLabelStr = a.data.startTime + " 开幕"), 
                a.data.thumb = null == a.data.displayPoster ? "../../images/banner.png" : o.api.fileSec + a.data.displayPoster, 
                i.setData({
                    info: a.data,
                    bottomBarData: e
                });
            } else (0, t.showWarningToast)(a);
        }), function(a, o) {
            (0, t.queryBookRuleExhBookRule)(o).then(function(t) {
                if (200 == t.code) {
                    var o = t.data;
                    0 === o.unsubscribeDate ? (o.popBaozhangStr = "最迟观展日期前3天可退", o.popBaozhangContentStr = "最迟退订时间为参观日期三天前的晚24点整。如参观日期为1月4日，则1月1日晚24点整前均可退订。") : 1 === o.unsubscribeDate ? (o.popBaozhangStr = "最迟观展日期前1天可退", 
                    o.popBaozhangContentStr = "最迟退订时间为参观日期一天前的晚24点整。如参观日期为1月4日，则1月3日晚24点整前均可退订。") : 2 === o.unsubscribeDate ? (o.popBaozhangStr = "最迟观展日期当天可退", 
                    o.popBaozhangContentStr = "最迟退订时间为参观日期当天的晚24点整。如参观日期为8月4日，则8月4日晚24点整前均可退订。") : (o.popBaozhangStr = "联系后台工作人员", 
                    o.popBaozhangContentStr = "联系后台工作人员"), 0 === o.isEndorse ? (o.popBaozhangGaiqianStr = "不支持改签", 
                    o.popGaiqianStr = "不支持改签，如需改签，请退订后重新预约。") : (o.popBaozhangGaiqianStr = "支持改签", o.popGaiqianStr = "订单可改签一次，最迟改签时间为参观日期当天晚24点整。如参观日期为1月4日，则1月4日晚24点整前均可改签。"), 
                    a.setData({
                        baozhangInfo: o
                    });
                } else wx.showToast({
                    title: t.msg,
                    icon: "none"
                });
            }).catch(function(a) {
                console.debug("获取预约须知失败" + a);
            });
        }(this, r.id);
    },
    onShow: function() {
        this.setData({
            hiddlePop: !0
        });
    },
    securityClick: function() {
        this.setData({
            hiddenBaozhangPop: !1
        });
    },
    baozhangCloseImgClick: function() {
        this.setData({
            hiddenBaozhangPop: !0
        });
    },
    appointmentOnTap: function() {
        if ("" == i.globalData.authorizationc) wx.navigateTo({
            url: "../login/login"
        }); else {
            var a = this;
            wx.requestSubscribeMessage({
                tmplIds: [ "IBbdpKSrqnfjLHjj77ITbkkZq1x8CwhGY8-rqRgIc0I", "MnecTJckce8ETWxRcM_3hBz6i_aJ3u2aW72XBAbT6xI", "b01zPzqAMlBW__OxQGT0SpROfrnjWXNG0gB5jEd5HmU" ],
                success: function(t) {
                    console.log("订阅消息授权正确：" + JSON.stringify(t));
                    var o = a.data.info;
                    o.information = "", o.informationStr = "", o.introduction = "", o.introductionStr = "", 
                    o.popBaozhangStr = a.data.baozhangInfo.popBaozhangStr, o.popBaozhangContentStr = a.data.baozhangInfo.popBaozhangContentStr, 
                    o.popBaozhangGaiqianStr = a.data.baozhangInfo.popBaozhangGaiqianStr, o.everyMaxNumber = a.data.baozhangInfo.everyMaxNumber, 
                    o.tips = "";
                    var n = JSON.stringify(o);
                    console.log("预约须知确定按钮点击" + n), wx.navigateTo({
                        url: "exhibitionNotice?data=" + n
                    });
                },
                fail: function(t) {
                    console.log("订阅消息授权错误信息" + JSON.stringify(t));
                    var o = a.data.info;
                    o.information = "", o.informationStr = "", o.introduction = "", o.introductionStr = "", 
                    o.popBaozhangStr = a.data.baozhangInfo.popBaozhangStr, o.popBaozhangContentStr = a.data.baozhangInfo.popBaozhangContentStr, 
                    o.popBaozhangGaiqianStr = a.data.baozhangInfo.popBaozhangGaiqianStr, o.everyMaxNumber = a.data.baozhangInfo.everyMaxNumber, 
                    o.tips = "";
                    var n = JSON.stringify(o);
                    console.log("预约须知确定按钮点击" + n), wx.navigateTo({
                        url: "exhibitionNotice?data=" + n
                    });
                }
            });
        }
    },
    updateLikeNum: function(a) {
        if (console.log("1111"), "cancel" == a.detail.type) {
            if ((t = this.data.info).praiseCount <= 0) return;
            t.praiseCount--, this.setData({
                info: t
            });
        } else if ("add" == a.detail.type) {
            var t;
            (t = this.data.info).praiseCount++, this.setData({
                info: t
            });
        }
    },
    updateFavoriteNum: function(a) {
        if ("cancel" == a.detail.type) {
            if ((t = this.data.info).favoriteCount <= 0) return;
            t.favoriteCount--, this.setData({
                info: t
            });
        } else if ("add" == a.detail.type) {
            var t;
            (t = this.data.info).favoriteCount++, this.setData({
                info: t
            });
        }
    },
    openMuseum: function() {
        var a = {
            id: this.data.info.companyInfoId,
            tenantId: this.data.info.companyInfoId
        };
        (0, t.queryVenueById)(this.data.info.companyInfoId).then(function(t) {
            200 == t.code ? null == t.data ? wx.showModal({
                title: "提示",
                content: "场馆信息未开放",
                showCancel: !1,
                success: function(a) {
                    a.confirm;
                }
            }) : wx.navigateTo({
                url: "../museum/museumDetail?data=" + JSON.stringify(a)
            }) : wx.showModal({
                title: "提示",
                content: "场馆信息未开放",
                showCancel: !1,
                success: function(a) {
                    a.confirm;
                }
            });
        });
    },
    openMap: function() {
        null != this.data.info.latitude && "" != this.data.info.latitude && "" != this.data.info.longitude && null != this.data.info.longitude && wx.openLocation({
            latitude: Number(this.data.info.latitude),
            longitude: Number(this.data.info.longitude),
            name: this.data.info.companyName
        });
    }
});