Page({
    data: {
        info: {},
        tips: "",
        time: "",
        visitorNum: 0,
        needPay: !1
    },
    onLoad: function(t) {
        var e = JSON.parse(t.data), i = this;
        this.getOpenerEventChannel().on("acceptDataFromOpenerPage", function(t) {
            i.setData({
                tips: t.tips
            });
        }), this.setData({
            info: e,
            time: e.currentDateStr + " " + e.currentTimeStr,
            needPay: e.needPay,
            visitorNum: e.seletDataArr.length
        });
    },
    detailbtnClick: function(t) {
        wx.redirectTo({
            url: "../exhibition/exhibitionApplintDetail?orderListId=" + this.data.info.orderId + "&heXiaoHiddenState=true"
        });
    },
    backbtnClick: function(t) {
        wx.navigateBack({
            delta: 5
        });
    },
    onShow: function() {}
});