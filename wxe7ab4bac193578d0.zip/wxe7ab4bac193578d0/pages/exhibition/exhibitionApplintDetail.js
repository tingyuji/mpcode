getApp();

var t = require("../../server/api.js"), e = t.exhibitionQueryOrderDetail, a = t.activityQueryOrderCancle, i = t.tuidingExihibitionOrderSubmit, n = t.hexiaoExihibitionOrderSubmit, s = (t.tuidingWxPayrefundSubmit, 
t.queryExihibitionsureOrderPay), o = t.tuidingNoticeToRefund, d = t.queryVenueById, r = t.queryExhibitionById, c = t.exhibitionOtherAppointQueryOrderDetail, l = require("../../utils/qrCode.js"), u = l.showLogoQRCode, h = l.showQRCode, g = wx.getSystemInfoSync().windowWidth;

function m(t, a) {
    console.log("特展id" + a), wx.showLoading({
        title: "加载中...",
        mask: !0
    }), e(a).then(function(e) {
        if (wx.hideLoading(), 200 == e.code) {
            var a = e.data;
            if (a.price > 0 ? a.coststr = "￥" + a.price : a.coststr = "免费", 0 === a.unsubscribeDate ? (a.popBaozhangStr = "最迟观展日期前3天可退", 
            a.popBaozhangContentStr = "最迟退订时间为参观日期三天前的晚24点整。如参观日期为1月4日，则1月1日晚24点整前均可退订。") : 1 === a.unsubscribeDate ? (a.popBaozhangStr = "最迟观展日期前1天可退", 
            a.popBaozhangContentStr = "最迟退订时间为参观日期一天前的晚24点整。如参观日期为1月4日，则1月3日晚24点整前均可退订。") : 2 === a.unsubscribeDate ? (a.popBaozhangStr = "最迟观展日期当天可退", 
            a.popBaozhangContentStr = "最迟退订时间为参观日期当天的晚24点整。如参观日期为8月4日，则8月4日晚24点整前均可退订。") : (a.popBaozhangStr = "联系后台工作人员", 
            a.popBaozhangContentStr = "联系后台工作人员"), a.tuidingState = !0, 0 === a.orderStatus) {
                a.orderStatusHiddle = !1, a.payBtnStr = "立即支付";
                var i = a.cutTime.replace(/-/g, "/"), n = [];
                [ {
                    actEndTime: i
                } ].forEach(function(t) {
                    n.push(t.actEndTime);
                }), t.setData({
                    actEndTimeList: n
                }), t.countDown();
            } else 1 === a.orderStatus || 2 === a.orderStatus ? (a.tuidingState = !1, a.tuidingStateStr = "退 订") : (a.orderStatus, 
            a.tuidingState = !0, a.orderStatusHiddle = !0);
            var s = [], o = [], d = !1;
            a.hiddenBottomBtn = !1, a.childOrderList.forEach(function(t, e) {
                t.seleted = !1, 0 != t.reserveStatus && o.push(t), t.isHideIdcard = !0, t.documentNumberStr = t.documentNumber, 
                -1 == t.reserveStatus ? (t.stateBtnStr = "支 付", t.stateBtnHiddle = !0, t.iscancle = !1) : 0 == t.reserveStatus ? "已过期" == t.reserveStatusStr ? (t.stateBtnStr = "", 
                t.stateBtnHiddle = !0, t.iscancle = !0) : (t.stateBtnHiddle = !1, t.iscancle = !1, 
                d = !0) : 1 == t.reserveStatus ? (t.stateBtnHiddle = !1, t.iscancle = !1, d = !0, 
                t.reserveStatusImg = "../../images/center/yiyuyue.png") : 2 == t.reserveStatus ? (t.stateBtnStr = "", 
                t.stateBtnHiddle = !0, t.iscancle = !0, t.reserveStatusImg = "../../images/center/yiquxiao.png") : 3 == t.reserveStatus ? (t.stateBtnStr = "", 
                t.stateBtnHiddle = !0, t.iscancle = !0, t.reserveStatusImg = "../../images/center/yiguanzhan.png") : 4 == t.reserveStatus ? (t.stateBtnStr = "", 
                t.stateBtnHiddle = !0, t.iscancle = !0, t.reserveStatusImg = "../../images/center/yiguoqi.png") : 5 == t.reserveStatus ? (t.stateBtnStr = "", 
                t.stateBtnHiddle = !0, t.iscancle = !0, t.reserveStatusImg = "../../images/center/yituiding.png") : (t.stateBtnStr = "", 
                t.stateBtnHiddle = !0, t.iscancle = !0), 0 == t.refund && (t.stateBtnStr = "", t.stateBtnHiddle = !0, 
                t.iscancle = !0);
                var i = "canvas" + e;
                "0c4b9fd4410c8e9d4e80607e91335151" == a.companyInfoId ? u(t.childOrderId, i) : h(t.childOrderId, i), 
                s.push(t);
            }), o.length === a.childOrderList.length && (a.hiddenBottomBtn = !0), !1 === t.data.heXiaoHiddenState && !0 === d ? (a.tuidingState = !0, 
            a.orderStatusHiddle = !0) : !1 === t.data.heXiaoHiddenState && !1 === d && (a.tuidingState = !0, 
            a.orderStatusHiddle = !0, t.setData({
                heXiaoHiddenState: !0
            })), console.log("此时可核销" + d + "dict.orderStatusHiddle" + a.orderStatusHiddle), 
            a.timeLabelStr = a.subscribeStartDate + " 至 " + a.subscribeEndDate, null !== a.subscribeEndDate && "" !== a.subscribeEndDate || (a.timeLabelStr = a.subscribeStartDate + " 开幕"), 
            a.priceStr = 0 == a.price || null == a.price ? "免费" : "¥" + a.price, t.setData({
                model: a,
                orderStatusStr: a.orderStatusStr,
                hideProgress: !0,
                memberArr: s
            });
        } else wx.showToast({
            title: e.msg
        });
    });
}

Page({
    data: {
        orderId: "",
        model: {},
        memberArr: [],
        qrcode_w: 320 / (750 / g),
        hideProgress: !1,
        actEndTimeList: [],
        actcreateTimeStr: "",
        orderStatusStr: "",
        surebtnStr: "",
        seletDataArr: [],
        isCanCommit: !1,
        heXiaoHiddenState: !0,
        isXingchengRemind: !1,
        hiddenBaozhangPop: !0
    },
    onLoad: function(t) {
        var e, a;
        !0, console.log("监听页面加载" + t.heXiaoHiddenState), "false" === t.heXiaoHiddenState ? t.heXiaoHiddenState = !1 : t.heXiaoHiddenState = !0, 
        "true" === t.isXingchengRemind ? t.isXingchengRemind = !0 : t.isXingchengRemind = !1, 
        this.setData({
            hideProgress: !1,
            orderId: t.orderListId,
            heXiaoHiddenState: t.heXiaoHiddenState,
            isXingchengRemind: t.isXingchengRemind
        }), 1 == this.data.isXingchengRemind ? (e = this, a = t.orderListId, console.log("特展id" + a), 
        wx.showLoading({
            title: "加载中...",
            mask: !0
        }), c(a).then(function(t) {
            if (wx.hideLoading(), 200 == t.code) {
                var a = t.data;
                if (a.price > 0 ? a.coststr = "￥" + a.price : a.coststr = "免费", 0 === a.unsubscribeDate ? (a.popBaozhangStr = "最迟观展日期前3天可退", 
                a.popBaozhangContentStr = "最迟退订时间为参观日期三天前的晚24点整。如参观日期为1月4日，则1月1日晚24点整前均可退订。") : 1 === a.unsubscribeDate ? (a.popBaozhangStr = "最迟观展日期前1天可退", 
                a.popBaozhangContentStr = "最迟退订时间为参观日期一天前的晚24点整。如参观日期为1月4日，则1月3日晚24点整前均可退订。") : 2 === a.unsubscribeDate ? (a.popBaozhangStr = "最迟观展日期当天可退", 
                a.popBaozhangContentStr = "最迟退订时间为参观日期当天的晚24点整。如参观日期为8月4日，则8月4日晚24点整前均可退订。") : (a.popBaozhangStr = "联系后台工作人员", 
                a.popBaozhangContentStr = "联系后台工作人员"), a.tuidingState = !0, 0 === a.orderStatus) {
                    a.orderStatusHiddle = !1, a.payBtnStr = "立即支付";
                    var i = a.cutTime.replace(/-/g, "/"), n = [];
                    [ {
                        actEndTime: i
                    } ].forEach(function(t) {
                        n.push(t.actEndTime);
                    }), e.setData({
                        actEndTimeList: n
                    }), e.countDown();
                } else 1 === a.orderStatus || 2 === a.orderStatus ? (a.tuidingState = !1, a.tuidingStateStr = "退 订") : (a.orderStatus, 
                a.tuidingState = !0, a.orderStatusHiddle = !0);
                var s = [], o = [], d = !1;
                a.hiddenBottomBtn = !1, a.childOrderList.forEach(function(t, e) {
                    t.seleted = !1, 0 != t.reserveStatus && o.push(t), t.isHideIdcard = !0, t.documentNumberStr = t.documentNumber, 
                    -1 == t.reserveStatus ? (t.stateBtnStr = "支 付", t.stateBtnHiddle = !0, t.iscancle = !1) : 0 == t.reserveStatus ? "已过期" == t.reserveStatusStr ? (t.stateBtnStr = "", 
                    t.stateBtnHiddle = !0, t.iscancle = !0) : (t.stateBtnHiddle = !1, t.iscancle = !1, 
                    d = !0) : "已预约" == t.reserveStatusValue ? (t.stateBtnHiddle = !1, t.iscancle = !1, 
                    d = !0, t.reserveStatusImg = "../../images/center/yiyuyue.png") : "待使用" == t.reserveStatusValue ? (t.stateBtnHiddle = !1, 
                    t.iscancle = !1, d = !0, t.reserveStatusImg = "../../images/center/daishiyong.png") : "已取消" == t.reserveStatusValue ? (t.stateBtnStr = "", 
                    t.stateBtnHiddle = !0, t.iscancle = !0, t.reserveStatusImg = "../../images/center/yiquxiao.png") : "已观展" == t.reserveStatusValue ? (t.stateBtnStr = "", 
                    t.stateBtnHiddle = !0, t.iscancle = !0, t.reserveStatusImg = "../../images/center/yiguanzhan.png") : "已使用" == t.reserveStatusValue ? (t.stateBtnStr = "", 
                    t.stateBtnHiddle = !0, t.iscancle = !0, t.reserveStatusImg = "../../images/center/yishiyong.png") : "已过期" == t.reserveStatusValue ? (t.stateBtnStr = "", 
                    t.stateBtnHiddle = !0, t.iscancle = !0, t.reserveStatusImg = "../../images/center/yiguoqi.png") : "已退订" == t.reserveStatusValue ? (t.stateBtnStr = "", 
                    t.stateBtnHiddle = !0, t.iscancle = !0, t.reserveStatusImg = "../../images/center/yituiding.png") : (t.stateBtnStr = "", 
                    t.stateBtnHiddle = !0, t.iscancle = !0), 0 == t.refund && (t.stateBtnStr = "", t.stateBtnHiddle = !0, 
                    t.iscancle = !0), t.stateBtnHiddle = !0, t.iscancle = !0;
                    var a = "canvas" + e;
                    h(t.childOrderId, a), s.push(t);
                }), o.length === a.childOrderList.length && (a.hiddenBottomBtn = !0), !1 === e.data.heXiaoHiddenState && !0 === d ? (a.tuidingState = !0, 
                a.orderStatusHiddle = !0) : !1 === e.data.heXiaoHiddenState && !1 === d && (a.tuidingState = !0, 
                a.orderStatusHiddle = !0, e.setData({
                    heXiaoHiddenState: !0
                })), console.log("此时可核销" + d + "dict.orderStatusHiddle" + a.orderStatusHiddle), 
                a.timeLabelStr = a.subscribeStartDate + " 至 " + a.subscribeEndDate, null !== a.subscribeEndDate && "" !== a.subscribeEndDate || (a.timeLabelStr = a.subscribeStartDate + " 开幕"), 
                a.price = 0 == a.price || null == a.price ? "免费" : "¥" + a.price, a.tuidingState = !0, 
                a.orderStatusHiddle = !0, e.setData({
                    model: a,
                    orderStatusStr: a.orderStatusStr,
                    hideProgress: !0,
                    memberArr: s
                });
            } else wx.showToast({
                title: t.msg
            });
        })) : m(this, t.orderListId);
    },
    exhibitionTitleClick: function(t) {
        var e = {
            id: this.data.model.displayInfoId,
            tenantId: this.data.model.systemId,
            praiseCount: 0,
            favoriteCount: 0
        }, a = JSON.stringify(e);
        r(this.data.model.displayInfoId).then(function(t) {
            200 === t.code ? null == t.data ? wx.showModal({
                title: "提示",
                content: "特展已下架",
                showCancel: !1,
                success: function(t) {
                    t.confirm;
                }
            }) : wx.redirectTo({
                url: "../exhibition/exhibitionDetail?data=" + a
            }) : wx.showModal({
                title: "提示",
                content: "特展已下架",
                showCancel: !1,
                success: function(t) {
                    t.confirm;
                }
            });
        });
    },
    securityClick: function() {
        this.setData({
            hiddenBaozhangPop: !1
        });
    },
    baozhangCloseImgClick: function() {
        this.setData({
            hiddenBaozhangPop: !0
        });
    },
    openMuseum: function() {
        var t = {
            id: this.data.model.companyInfoId,
            tenantId: this.data.model.companyInfoId
        };
        d(this.data.model.companyInfoId).then(function(e) {
            200 == e.code ? null == e.data ? wx.showModal({
                title: "提示",
                content: "场馆信息未开放",
                showCancel: !1,
                success: function(t) {
                    t.confirm;
                }
            }) : wx.redirectTo({
                url: "../museum/museumDetail?data=" + JSON.stringify(t)
            }) : wx.showModal({
                title: "提示",
                content: "场馆信息未开放",
                showCancel: !1,
                success: function(t) {
                    t.confirm;
                }
            });
        });
    },
    payBtnClick: function(t) {
        !function(t) {
            wx.showLoading({
                title: "加载中...",
                mask: !0
            });
            var e = t.data.model;
            s(e.price, e.orderId, "EXH", e.name, e.systemId).then(function(e) {
                wx.hideLoading(), 200 == e.code ? (console.log("支付成功"), null != e.data && wx.requestPayment({
                    timeStamp: e.data.timeStamp,
                    nonceStr: e.data.nonceStr,
                    package: e.data.package,
                    signType: e.data.signType,
                    paySign: e.data.paySign,
                    appId: wx.getAccountInfoSync().miniProgram.appId,
                    success: function(e) {
                        m(t, t.data.orderId), wx.showToast({
                            title: "支付成功",
                            icon: "success"
                        });
                    },
                    fail: function(t) {
                        console.error("请确保微信支付已开通320" + t);
                    },
                    complete: function(t) {}
                })) : wx.showToast({
                    title: "支付失败",
                    icon: "none"
                });
            }).catch(function(t) {
                wx.hideLoading(), console.debug("提交订单失败", t);
            });
        }(this);
    },
    eyesImgClick: function(t) {
        var e = parseInt(t.currentTarget.dataset.index), a = this.data.model.childOrderList;
        console.log("证件号隐藏按钮点击" + e), a.forEach(function(t, a) {
            e == a && (0 == t.isHideIdcard ? (t.isHideIdcard = !0, t.documentNumberStr = t.documentNumberHide) : (t.isHideIdcard = !1, 
            t.documentNumberStr = t.documentNumber));
        });
        var i = this.data.model;
        i.childOrderList = a, this.setData({
            model: i
        });
    },
    orderListClick: function(t) {
        var e = parseInt(t.currentTarget.dataset.index), a = this.data.model.childOrderList, i = (this.data.seletDataArr, 
        []), n = [];
        a.forEach(function(t, a) {
            1 != t.iscancle && (e == a && (0 == t.seleted ? t.seleted = !0 : t.seleted = !1), 
            1 == t.seleted && (i.push(t.childOrderId), n.push(t)));
        });
        var s = !1;
        s = 0 != i.length;
        var o = this.data.model;
        o.childOrderList = a, this.setData({
            seletDataArr: i,
            rebookCountArr: n,
            model: o,
            isCanCommit: s
        });
    },
    heXiaoBtnClick: function(t) {
        console.log(this.data.seletDataArr);
        var e = this;
        if (0 != this.data.isCanCommit) {
            var a = this.data.seletDataArr;
            wx.showModal({
                title: "是否确定核销？",
                content: "请务必在工作人员的确认下核销订单。请勿提前自行点击核销按钮。核销界面截图不可作为参观凭证。",
                cancelText: "暂不核销",
                confirmText: "立即核销",
                cancelColor: "#525252",
                confirmColor: "#DB5151",
                success: function(t) {
                    t.confirm ? (console.log("用户点击确定"), e.setData({
                        hideProgress: !1
                    }), wx.showLoading({
                        title: "加载中...",
                        mask: !0
                    }), n(a, e.data.model.displayInfoId).then(function(t) {
                        if (wx.hideLoading(), 200 == t.code) {
                            t.data;
                            wx.showModal({
                                title: "提示",
                                content: "核销成功!",
                                showCancel: !1
                            }), e.setData({
                                seletDataArr: []
                            }), m(e, e.data.orderId);
                        } else console.debug("核销失败" + t.msg), wx.showModal({
                            title: "核销失败",
                            content: t.msg,
                            showCancel: !1
                        });
                    }).catch(function(t) {
                        wx.hideLoading(), console.debug("核销失败", t);
                    })) : t.cancel && console.log("用户点击取消");
                }
            });
        }
    },
    tuidingBtnClick: function(t) {
        var e = this;
        console.log(this.data.seletDataArr);
        var a = this;
        if (0 != this.data.isCanCommit) {
            var n = this.data.seletDataArr;
            wx.showModal({
                title: "提示",
                content: "确定退订吗？",
                success: function(t) {
                    t.confirm ? (console.log("用户点击确定"), a.setData({
                        hideProgress: !1
                    }), wx.showLoading({
                        title: "加载中...",
                        mask: !0
                    }), a.data.model.price > 0 ? o(a.data.model.orderId, a.data.model.displayInfoId, a.data.model.orderTime, n).then(function(t) {
                        200 === t.code ? i(a.data.model.orderId, a.data.model.displayInfoId, a.data.model.orderTime, n).then(function(t) {
                            200 == t.code ? (t.data.status, wx.showModal({
                                title: "提示",
                                content: t.data.orderMessage,
                                showCancel: !1
                            }), m(a, a.data.orderId)) : (console.debug("退订失败" + t.msg), wx.showModal({
                                title: "退订失败",
                                content: t.msg,
                                showCancel: !1
                            }));
                        }).catch(function(t) {
                            wx.hideLoading(), wx.showToast({
                                title: "退订失败",
                                icon: "none"
                            }), console.debug("退订失败", t);
                        }) : wx.showModal({
                            title: "退订失败",
                            content: t.msg,
                            showCancel: !1
                        });
                    }).catch(function(t) {
                        wx.hideLoading(), console.debug("退订失败", t);
                    }) : i(e.data.model.orderId, e.data.model.displayInfoId, e.data.model.orderTime, n).then(function(t) {
                        200 == t.code ? (t.data.status, wx.showModal({
                            title: "提示",
                            content: t.data.orderMessage,
                            showCancel: !1
                        }), m(a, a.data.orderId)) : (console.debug("退订失败" + t.msg), wx.showModal({
                            title: "退订失败",
                            content: t.msg,
                            showCancel: !1
                        }));
                    }).catch(function(t) {
                        wx.hideLoading(), wx.showToast({
                            title: "退订失败",
                            icon: "none"
                        }), console.debug("退订失败", t);
                    })) : t.cancel && console.log("用户点击取消");
                }
            });
        }
    },
    canclebtnclick: function(t) {
        var e = this, i = [ t.currentTarget.dataset.orderactivityid ];
        wx.showModal({
            title: "提示",
            content: "确定取消预约吗？",
            success: function(t) {
                if (t.confirm) {
                    if (console.log("用户点击确定"), null != e.data.model.isAdditional && 1 === e.data.model.isAdditional) {
                        var n = [];
                        e.data.model.orderActivityList.forEach(function(t, e) {
                            console.log("亲子活动取消" + JSON.stringify(t)), n.push(t.orderActivityId);
                        }), i = n;
                    }
                    a(i).then(function(t) {
                        wx.hideLoading(), 200 == t.code ? (wx.showToast({
                            title: "取消成功！"
                        }), m(e, e.data.orderId)) : wx.showToast({
                            title: t.msg
                        });
                    }).catch(function(t) {
                        wx.hideLoading();
                    }), e.setData({
                        hideProgress: !1,
                        isCanCommit: !1
                    });
                } else t.cancel && (e.setData({
                    hideProgress: !0
                }), console.log("用户点击取消"));
            }
        });
    },
    onShow: function() {},
    timeFormat: function(t) {
        return t < 10 ? "0" + t : t;
    },
    onUnload: function() {
        clearInterval(this.countDown);
    },
    countDown: function() {
        var t = this, e = new Date().getTime(), a = this.data.actEndTimeList, i = {}, n = this;
        a.forEach(function(a) {
            var s = new Date(a).getTime(), o = null;
            if (s - e > 0) {
                var d = (s - e) / 1e3, r = parseInt(d / 86400), c = parseInt(d % 86400 / 3600), l = parseInt(d % 86400 % 3600 / 60), u = parseInt(d % 86400 % 3600 % 60);
                o = {
                    day: t.timeFormat(r),
                    hou: t.timeFormat(c),
                    min: t.timeFormat(l),
                    sec: t.timeFormat(u)
                };
            } else 4 === n.data.model.orderStatus && m(n, n.data.orderId), o = {
                day: "00",
                hou: "00",
                min: "00",
                sec: "00"
            };
            i = o;
        }), 0 === n.data.model.orderStatus && n.setData({
            orderStatusStr: "支付中（付款倒计时:" + i.hou + "时" + i.min + "分" + i.sec + "秒）"
        }), setTimeout(n.countDown, 1e3);
    }
});