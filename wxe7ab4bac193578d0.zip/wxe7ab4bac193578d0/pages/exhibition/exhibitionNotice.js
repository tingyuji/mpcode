var a = require("../../server/api");

Page({
    data: {
        richTextNode: "",
        displayInfoId: "",
        dataInfo: {}
    },
    onLoad: function(t) {
        var n, i, o = JSON.parse(t.data);
        this.setData({
            dataInfo: o,
            displayInfoId: o.displayInfoId
        }), n = this, i = this.data.displayInfoId, (0, a.queryExhibitionPersonalDescrption)(i).then(function(a) {
            200 == a.code ? n.setData({
                richTextNode: "" == a.data || null == a.data ? "暂无预约须知" : a.data
            }) : wx.showToast({
                title: a.msg,
                icon: "none"
            });
        }).catch(function(a) {
            console.debug("获取预约须知失败" + a);
        });
    },
    sureBtnClick: function(a) {
        var t = JSON.stringify(this.data.dataInfo);
        wx.navigateTo({
            url: "exhibitionAppoint?data=" + t
        });
    },
    onShow: function() {}
});