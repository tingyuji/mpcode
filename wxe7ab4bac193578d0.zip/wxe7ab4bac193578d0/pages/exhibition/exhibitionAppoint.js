var t = require("../../server/api");

require("../contacts/static");

function e(e) {
    (0, t.customerContactQueryPageList)().then(function(t) {
        if (200 == t.code) {
            var a = t.data.records, n = !1, i = "", s = [];
            a.forEach(function(t, a) {
                t.seleted = -1 != e.data.selectedContactsArr.findIndex(function(e) {
                    return e.customerContactId === t.customerContactId;
                }), 1 === t.myself && (n = !0, i = t.customerContactId, s.push(t)), "RLY0101" === t.documentType ? t.isIdcard = !0 : t.isIdcard = !1;
            }), !1 === n && wx.showModal({
                title: "提示",
                content: "请先进行实名认证",
                cancelColor: "",
                showCancel: !0,
                success: function(t) {
                    t.confirm && wx.navigateTo({
                        url: "../contacts/realNameCertification"
                    });
                }
            }), e.setData({
                isHasSelf: n,
                customerContactId: i,
                selectedContactsArr: s
            });
        } else wx.showToast({
            title: t.data.msg
        });
    }).catch(function(t) {
        console.error("获取联系人失败" + t);
    });
}

function a(e) {
    e.setData({
        codeInputStr: ""
    }), (0, t.exhibitionAppointQueryImgCode)().then(function(t) {
        if (200 == t.code) {
            var a = t.data.replace(/[\r\n]/g, "");
            e.setData({
                captchaImgBase64: a
            });
        } else wx.showToast({
            title: t.msg,
            icon: "none"
        });
    }).catch(function(t) {
        console.error("验证码失败" + t);
    });
}

Page({
    data: {
        info: {},
        picketInfoArr: [],
        surplusList: [],
        monthLabelStr: "",
        currentDateIndex: 999,
        currentDateStr: "",
        currentTimeStr: "",
        selectedContactsArr: [],
        seletimeModel: {},
        maxCount: 0,
        isHasSelf: !1,
        richTextNode: "",
        isCanCommit: !1,
        customerContactId: "",
        actEndTimeList: [],
        actcreateTimeStr: "",
        orderCost: "",
        noticeStr: "",
        hiddenBaozhangPop: !0,
        codeInputStr: ""
    },
    onLoad: function(a) {
        var n, i, s = JSON.parse(a.data);
        this.setData({
            info: s,
            maxCount: s.everyMaxNumber
        }), n = this, i = s.displayInfoId, (0, t.queryExhibitionTicketById)(i).then(function(e) {
            if (200 === e.code) {
                var a = {
                    objectId: e.data.id
                }, i = e.data;
                i.forEach(function(t, e) {
                    t.dayNum = new Date(t.subscribeDate).getDate(), 0 == t.statusValue ? t.canseleted = !0 : (1 == t.statusValue || 2 == t.statusValue) && (t.canseleted = !1), 
                    new Date(t.subscribeDate).getTime() === new Date(new Date().toDateString()).getTime() && (t.statusName = "今天"), 
                    t.subscribeTimeLineInfoList.forEach(function(e, a) {
                        e.ticketNum > 0 ? e.statusName = "可预约" + e.ticketNum + "人" : (e.statusName = "无票", 
                        t.stateStr = "停售"), "YES" == n.data.isChangeTime && e.intervalDate == n.data.changeIntervalDate && e.intervalValue == n.data.changeIntervalTime && (e.statusName = "已预约", 
                        e.ticketNum = 0);
                    });
                });
                for (var s = {}, o = 0; o < i.length && "有票" != (s = i[o]).stateStr; o++) ;
                i[0], i[1], i[2];
                for (var r = 0, c = i.length, d = {}, u = 0; u < c; u++) if ("有票" == (d = i[u]).statusName) {
                    r = u, console.log("currentModel" + d + r);
                    break;
                }
                for (var l = i[0].dayWeek, m = 0, h = 0; h < l - 1; h++) {
                    m = h + 1;
                    var f = {
                        dayWeek: h,
                        canseleted: !1
                    };
                    i.unshift(f);
                }
                var C = s.subscribeDate.substring(5, 7) + "月";
                n.setData({
                    picketInfoArr: i,
                    surplusList: d.subscribeTimeLineInfoList,
                    currentDateStr: d.subscribeDate,
                    currentDateIndex: r + m,
                    monthLabelStr: C,
                    bottomBarData: a
                });
            } else (0, t.showWarningToast)(e);
        }), e(this);
    },
    onShow: function() {
        a(this);
    },
    reloadContactsData: function() {
        e(this);
    },
    captchaClick: function(t) {
        a(this);
    },
    captchaCodeInput: function(t) {
        this.setData({
            codeInputStr: t.detail.value
        });
    },
    openMuseum: function() {
        var e = {
            id: this.data.info.companyInfoId,
            tenantId: this.data.info.companyInfoId
        };
        (0, t.queryVenueById)(this.data.info.companyInfoId).then(function(t) {
            200 == t.code ? null == t.data ? wx.showModal({
                title: "提示",
                content: "场馆信息未开放",
                showCancel: !1,
                success: function(t) {
                    t.confirm;
                }
            }) : wx.navigateTo({
                url: "../museum/museumDetail?data=" + JSON.stringify(e)
            }) : wx.showModal({
                title: "提示",
                content: "场馆信息未开放",
                showCancel: !1,
                success: function(t) {
                    t.confirm;
                }
            });
        });
    },
    securityClick: function() {
        this.setData({
            hiddenBaozhangPop: !1
        });
    },
    baozhangCloseImgClick: function() {
        this.setData({
            hiddenBaozhangPop: !0
        });
    },
    dateViewClick: function(t) {
        var e = parseInt(t.currentTarget.dataset.index), a = this.data.picketInfoArr[e], n = a.subscribeDate.substring(5, 7) + "月";
        if (0 == a.statusValue) {
            if (null != a.dateRule) if (null != a.dateRule.momentBreak && "" != a.dateRule.momentBreak) {
                var i = "本日" + a.dateRule.startMoment + "-" + a.dateRule.momentBreak + a.dateRule.remark;
                this.setData({
                    noticeStr: i
                });
            } else this.setData({
                noticeStr: ""
            }); else this.setData({
                noticeStr: ""
            });
            this.setData({
                surplusList: a.subscribeTimeLineInfoList,
                monthLabelStr: n,
                currentDateIndex: e,
                currentDateStr: a.subscribeDate,
                curtimeIndex: 999,
                isCanCommit: !1
            });
        } else 2 == a.statusValue ? wx.showToast({
            title: "不可选",
            icon: "none"
        }) : 1 == a.statusValue && wx.showToast({
            title: "已停售",
            icon: "none"
        });
        this.data.selectedContactsArr.length > 0 && this.data.currentDateStr, this.setData({
            isCanCommit: !1
        });
    },
    timeViewClick: function(t) {
        var e = parseInt(t.currentTarget.dataset.index), a = this.data.surplusList[e];
        console.log("ticketNum", a.ticketNum), a.ticketNum <= 0 || this.setData({
            curtimeIndex: e,
            seletimeModel: a,
            currentTimeStr: a.timeLine,
            isCanCommit: !0
        });
    },
    deleteBtnClick: function(t) {
        console.log("删除按钮点击" + JSON.stringify(t.target.dataset.value));
        var e = t.target.dataset.value, a = this.data.selectedContactsArr;
        a.splice(e, 1), this.setData({
            selectedContactsArr: a
        });
    },
    addContactsBtnClick: function(t) {
        if (!1 === this.data.isHasSelf) wx.showModal({
            title: "提示",
            content: "请先进行实名认证",
            cancelColor: "",
            showCancel: !0,
            success: function(t) {
                t.confirm && wx.navigateTo({
                    url: "../contacts/realNameCertification"
                });
            }
        }); else {
            var e = {
                maxCount: this.data.maxCount,
                seletDataArr: this.data.selectedContactsArr,
                isExhibitionChoose: !1
            }, a = JSON.stringify(e);
            wx.navigateTo({
                url: "../contacts/selectContacts?data=" + a
            });
        }
    },
    appointBtnClick: function(e) {
        if ("" !== this.data.currentDateStr) if ("" !== this.data.currentTimeStr) if (this.data.selectedContactsArr.length <= 0) wx.showToast({
            title: "请先选择参观者",
            icon: "none"
        }); else {
            var a = this;
            if (this.data.codeInputStr.length <= 0) wx.showToast({
                title: "请输入验证码",
                icon: "none"
            }); else {
                var n = [];
                this.data.selectedContactsArr.forEach(function(t, e) {
                    n.push(t.customerContactId);
                }), wx.showLoading({
                    title: "加载中...",
                    mask: !0
                }), this.data.info.price > 0 ? (0, t.saveForHibitionPrepareSubmit)(this.data.info.displayInfoId, this.data.customerContactId, this.data.info.price, this.data.currentDateStr, this.data.seletimeModel.timeLine, n, a.data.codeInputStr).then(function(t) {
                    if (wx.hideLoading(), 200 == t.code) {
                        var e = t.data;
                        if (e.orderCost > 0) {
                            var n = e.countdown.replace(/-/g, "/"), i = [];
                            [ {
                                actEndTime: n
                            } ].forEach(function(t) {
                                i.push(t.actEndTime);
                            }), a.setData({
                                actEndTimeList: i
                            });
                        }
                        a.setData({
                            orderCost: e.orderCost
                        });
                        var s = a.data.info;
                        s.information = "", s.introduction = "", s.tips = "", s.currentDateStr = a.data.currentDateStr, 
                        s.currentTimeStr = a.data.seletimeModel.timeLine, s.seletDataArr = a.data.selectedContactsArr, 
                        s.actEndTimeList = a.data.actEndTimeList, s.actcreateTimeStr = a.data.actcreateTimeStr, 
                        s.orderCost = e.orderCost, s.countdown = e.countdown, s.orderId = e.orderId, s.systemId = e.systemId, 
                        s.price > 0 ? s.needPay = !0 : s.needPay = !1;
                        var o = JSON.stringify(s);
                        wx.redirectTo({
                            url: "exhibitionSureOrder?data=" + o
                        });
                    } else console.debug("提交订单" + t.msg), wx.showModal({
                        title: "温馨提示",
                        content: t.msg,
                        showCancel: !1
                    });
                }).catch(function(t) {
                    wx.hideLoading(), console.debug("提交订单失败", t);
                }) : (0, t.saveForFreeOrderSubmit)(this.data.info.displayInfoId, this.data.customerContactId, this.data.info.price, this.data.currentDateStr, this.data.seletimeModel.timeLine, n, a.data.codeInputStr, 0).then(function(t) {
                    if (wx.hideLoading(), 200 == t.code) {
                        var e = t.data, i = a.data.info;
                        i.information = "", i.introduction = "", i.tips = "", i.currentDateStr = a.data.currentDateStr, 
                        i.currentTimeStr = a.data.seletimeModel.timeLine, i.seletDataArr = a.data.selectedContactsArr, 
                        i.actEndTimeList = a.data.actEndTimeList, i.actcreateTimeStr = a.data.actcreateTimeStr, 
                        i.orderCost = e.orderCost, i.countdown = e.countdown, i.orderId = e.orderId, i.systemId = e.systemId, 
                        i.customerContactId = a.data.customerContactId, i.seleMemberArr = n, i.price > 0 ? i.needPay = !0 : i.needPay = !1;
                        var s = JSON.stringify(i);
                        wx.redirectTo({
                            url: "exhibitionSureOrder?data=" + s
                        });
                    } else console.debug("提交订单" + t.msg), wx.showModal({
                        title: "温馨提示",
                        content: t.msg,
                        showCancel: !1
                    });
                }).catch(function(t) {
                    wx.hideLoading(), console.debug("提交订单失败", t);
                });
            }
        } else wx.showToast({
            title: "请先选择观展时段",
            icon: "none"
        }); else wx.showToast({
            title: "请先选择观展日期",
            icon: "none"
        });
    }
});