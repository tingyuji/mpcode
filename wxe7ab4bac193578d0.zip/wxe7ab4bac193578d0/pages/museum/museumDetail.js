var t = require("../../@babel/runtime/helpers/interopRequireDefault").default, i = require("../../server/api"), a = require("../../server/http"), e = t(require("../../utils/richTextStyleUtil")), n = getApp();

function o(t, i) {
    if ("活动" == i) t.thumb = null == t.coverImage ? "../../images/banner.png" : a.api.fileSec + t.coverImage, 
    null != t.endTime && "" != t.endTime ? t.time = t.startTime.substr(0, 16) + "至" + t.endTime.substr(0, 16) : t.time = t.startTime.substr(0, 16) + " 开始"; else if (t.thumb = null == t.displayPoster ? "../../images/banner.png" : a.api.fileSec + t.displayPoster, 
    null != t.endTime && "" != t.endTime) {
        var e = t.startTime.split(" ");
        t.startTime = e[0];
        var n = t.endTime.split(" ");
        t.endTime = n[0], t.time = t.startTime.substr(0, 16) + "至" + t.endTime.substr(0, 16);
    } else {
        e = t.startTime.split(" ");
        t.startTime = e[0], t.time = t.startTime.substr(0, 16) + " 开幕";
    }
}

Page({
    data: {
        info: {},
        basicExhibition: [],
        tempExhibition: [],
        activity: [],
        bottomBarData: {},
        activityHasMore: !1,
        tempExhibitionHasMore: !1
    },
    updateLikeNum: function(t) {
        if ("cancel" == t.detail.type) (i = this.data.info).praiseCount--, this.setData({
            info: i
        }); else if ("add" == t.detail.type) {
            var i;
            (i = this.data.info).praiseCount++, this.setData({
                info: i
            });
        }
    },
    updateFavoriteNum: function(t) {
        if ("cancel" == t.detail.type) (i = this.data.info).favoriteCount--, this.setData({
            info: i
        }); else if ("add" == t.detail.type) {
            var i;
            (i = this.data.info).favoriteCount++, this.setData({
                info: i
            });
        }
    },
    appointmentOnTap: function() {
        if ("" == n.globalData.authorizationc) wx.navigateTo({
            url: "../login/login"
        }); else {
            var t = this;
            wx.requestSubscribeMessage({
                tmplIds: [ "oIzoIcjQvO6Xl5cTKgdDUN-0amGIK5DnlNrZ3e3kvjI", "diFv_xfqC6VykrJ0NRbg0qMq25ArUDWiBy8Ip044A70", "45Wla0eXAXDYD7lBag-CK8bssUhBUIkQArDzi6g1NIQ" ],
                success: function(i) {
                    console.log("订阅消息授权正确：" + JSON.stringify(i)), n.globalData.systemId = t.data.info.systemId, 
                    n.globalData.MuseumName = t.data.info.companyName, wx.navigateTo({
                        url: "../appointment/home"
                    });
                },
                fail: function(i) {
                    console.log("订阅消息授权错误信息" + JSON.stringify(i)), n.globalData.systemId = t.data.info.systemId, 
                    n.globalData.MuseumName = t.data.info.companyName, wx.navigateTo({
                        url: "../appointment/home"
                    });
                }
            });
        }
    },
    onLoad: function(t) {
        var n = this;
        console.log(t.data);
        var s = JSON.parse(t.data);
        (0, i.queryVenueById)(s.id).then(function(t) {
            if (200 == t.code && null != t.data) {
                var d = t.data, r = null != s.tenantId && 0 != s.tenantId.length || void 0, u = {
                    objectId: d.companyInfoId,
                    objectTitle: d.companyName,
                    objectThumb: d.companyPhoto,
                    systemId: d.systemId,
                    block: "VENUE",
                    subBlock: 1,
                    fromSaas: r
                };
                d.thumb = null == d.companyPhoto ? "../../images/banner.png" : a.api.fileSec + d.companyPhoto, 
                d.companyAddress = null == d.companyAddress ? "未知" : d.companyAddress, d.distance = 0 == d.distance ? "未知" : d.distance, 
                d.description = (0, e.default)(d.description), (0, i.customerFootprint)(u, 1).then(function(t) {}), 
                n.setData({
                    info: d,
                    bottomBarData: u
                }), (0, i.queryMuseumActivity)(d.systemId, 4).then(function(t) {
                    if (200 == t.code && null != t.data) {
                        var i = t.data.records.length > 3, a = [];
                        t.data.records.forEach(function(t) {
                            a.length > 2 || (o(t, "活动"), a.push(t));
                        }), n.setData({
                            activity: a,
                            activityHasMore: i
                        });
                    }
                });
            }
        }), (0, i.queryMuseumExhibition)(2, s.id, 10).then(function(t) {
            200 == t.code && null != t.data && (t.data.records.forEach(function(t) {
                o(t, "常展");
            }), n.setData({
                basicExhibition: t.data.records
            }));
        }), (0, i.queryMuseumExhibition)(1, s.id, 4).then(function(t) {
            if (200 == t.code && null != t.data) {
                var i = t.data.records.length > 3, a = [];
                t.data.records.forEach(function(t) {
                    a.length > 2 || (o(t, "临展"), a.push(t));
                }), n.setData({
                    tempExhibition: a,
                    tempExhibitionHasMore: i
                });
            }
        });
    },
    openTempExhibition: function(t) {
        var i = t.currentTarget.dataset.index, a = {
            id: this.data.tempExhibition[i].displayInfoId
        };
        wx.navigateTo({
            url: "../../pages/exhibition/exhibitionDetail?data=" + JSON.stringify(a)
        });
    },
    openActivity: function(t) {
        var i = t.currentTarget.dataset.index, a = this.data.activity[i], e = {
            id: a.activityId,
            tenantId: a.tenantId
        };
        wx.navigateTo({
            url: "../../pages/activity/activityDetail?data=" + JSON.stringify(e)
        });
    },
    openMap: function() {
        null != this.data.info.latitude && "" != this.data.info.latitude && "" != this.data.info.longitude && null != this.data.info.longitude && wx.openLocation({
            latitude: Number(this.data.info.latitude),
            longitude: Number(this.data.info.longitude),
            name: this.data.info.companyAddress
        });
    },
    moreTempExhibitionClick: function() {
        wx.navigateTo({
            url: "../museum/museumMoreList?type=tempExhibition&venueId=" + this.data.info.companyInfoId
        });
    },
    moreActivityClick: function() {
        wx.navigateTo({
            url: "../museum/museumMoreList?type=activity&venueId=" + this.data.info.systemId
        });
    }
});