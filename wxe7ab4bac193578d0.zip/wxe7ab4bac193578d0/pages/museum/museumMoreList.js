var t = require("../../server/api"), i = require("../../server/http"), e = "";

Page({
    data: {
        list: [],
        orderNullImgState: !1
    },
    onLoad: function(a) {
        var r, s = this;
        "activity" == (e = a.type) ? (r = (0, t.queryMuseumActivity)(getApp().globalData.companyInfoId, 50), 
        wx.setNavigationBarTitle({
            title: "活动预约"
        })) : "tempExhibition" == e && (r = (0, t.queryMuseumExhibition)(1, getApp().globalData.companyInfoId, 50), 
        wx.setNavigationBarTitle({
            title: "特展预约"
        })), r.then(function(t) {
            200 == t.code && (t.data.records.forEach(function(t) {
                if ("activity" == e) t.thumb = null == t.coverImage ? "../../images/banner.png" : i.api.fileSec + t.coverImage, 
                null != t.endTime && "" != t.endTime ? t.time = t.startTime.substr(0, 16) + "至" + t.endTime.substr(0, 16) : t.time = t.startTime.substr(0, 16) + " 开始"; else if (t.thumb = null == t.displayPoster ? "../../images/banner.png" : i.api.fileSec + t.displayPoster, 
                t.cost = t.price, null != t.endTime && "" != t.endTime) {
                    var a = t.startTime.split(" ");
                    t.startTime = a[0];
                    var r = t.endTime.split(" ");
                    t.endTime = r[0], t.time = t.startTime.substr(0, 16) + "至" + t.endTime.substr(0, 16);
                } else {
                    a = t.startTime.split(" ");
                    t.startTime = a[0], t.time = t.startTime.substr(0, 16) + " 开幕";
                }
            }), t.data.records.length <= 0 ? s.setData({
                orderNullImgState: !1
            }) : s.setData({
                orderNullImgState: !0,
                list: t.data.records
            }));
        });
    },
    itemClick: function(t) {
        var i = t.currentTarget.dataset.index, a = this.data.list[i];
        if ("tempExhibition" == e) {
            var r = {
                id: a.displayInfoId
            }, s = JSON.stringify(r);
            wx.navigateTo({
                url: "../exhibition/exhibitionDetail?data=" + s
            });
        } else if ("activity" == e) {
            r = {
                id: a.activityId
            }, s = JSON.stringify(r);
            wx.navigateTo({
                url: "../activity/activityDetail?data=" + s
            });
        }
    }
});