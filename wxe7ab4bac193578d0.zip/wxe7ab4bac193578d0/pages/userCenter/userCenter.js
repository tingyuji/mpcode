var a = require("../../server/api");

function e(e) {
    var t = wx.getStorageSync(getApp().globalData.openId + "_realName");
    if ("" != t && null != t) {
        console.log("个人中心，缓存中有实名认证信息，不再请求");
        var i = JSON.parse(t);
        getApp().globalData.userInfo = i, getApp().globalData.isHasSelf = !0, e.setData({
            useName: i.customerName
        });
    } else console.log("缓存中没有实名认证信息，开始请求"), wx.showLoading({
        title: "加载中...",
        mask: !0
    }), (0, a.queryCertList)().then(function(a) {
        wx.hideLoading(), 200 === a.code && null != a.data && a.data.length > 0 ? (getApp().globalData.userInfo = a.data[0], 
        e.setData({
            useName: null == a.data[0].customerName ? "" : a.data[0].customerName
        })) : 200 === a.code && (null == a.data || a.data.length <= 0) && e.setData({
            useName: "点击实名认证"
        });
    });
}

Page({
    data: {
        isShenHe: !1,
        useName: "点击登录",
        isHiddleFubiao: !0,
        isOpenFubiao: !1,
        fubiaoDataArr: [],
        hiddenTuanduiShenhe: !0,
        hiddenJiDY: !0,
        indicatorDots: !1,
        userIcon: "../../images/center/touxiang.png",
        canIUseGetUserProfile: !1,
        hasLoadFaceUrl: !1
    },
    onLoad: function(a) {},
    onShow: function() {
        var t = this;
        "" == getApp().globalData.authorizationc ? this.setData({
            useName: "点击登录"
        }) : e(this);
        var i = wx.getStorageSync("userIcon");
        console.log(i), "" == i ? this.setData({
            canIUseGetUserProfile: !0
        }) : this.setData({
            canIUseGetUserProfile: !1,
            userIcon: i
        }), this.setData({
            fubiaoDataArr: []
        }), (0, a.teamReservecheckShow)(getApp().globalData.systemId).then(function(a) {
            wx.hideLoading(), 200 === a.code ? t.setData({
                hiddenTuanduiShenhe: !1,
                hiddenJiDY: !1
            }) : 428 === a.code || 430 === a.code || 431 === a.code ? t.setData({
                hiddenTuanduiShenhe: !1,
                hiddenJiDY: !0
            }) : 434 === a.code && t.setData({
                hiddenTuanduiShenhe: !0,
                hiddenJiDY: !0
            });
        });
    },
    getUserProfile: function(a) {
        var e = this;
        wx.getUserProfile({
            desc: "用于完善会员资料",
            success: function(a) {
                var t = a.userInfo.avatarUrl;
                e.setData({
                    userIcon: t
                }), wx.setStorageSync("userIcon", t);
            }
        });
    },
    login: function(a) {
        "点击登录" == this.data.useName ? wx.navigateTo({
            url: "../login/login"
        }) : "点击实名认证" == this.data.useName ? wx.navigateTo({
            url: "../contacts/realNameCertification"
        }) : wx.navigateTo({
            url: "userMessage"
        });
    },
    reloadContactsData: function(a) {
        e(this);
    },
    visitorsCellClick: function(a) {
        "点击登录" == this.data.useName ? wx.navigateTo({
            url: "../login/login"
        }) : "点击实名认证" == this.data.useName ? wx.navigateTo({
            url: "../contacts/realNameCertification"
        }) : wx.navigateTo({
            url: "../contacts/contactsList"
        });
    },
    teamCurrentCertificationClick: function(a) {
        "点击登录" == this.data.useName ? wx.navigateTo({
            url: "../login/login"
        }) : "点击实名认证" == this.data.useName ? wx.navigateTo({
            url: "../contacts/realNameCertification"
        }) : wx.navigateTo({
            url: "jigouCertification"
        });
    },
    orderCellClick: function(a) {
        if ("点击登录" == this.data.useName) wx.navigateTo({
            url: "../login/login"
        }); else if ("点击实名认证" == this.data.useName) wx.navigateTo({
            url: "../contacts/realNameCertification"
        }); else {
            var e = JSON.stringify({
                orderListId: [],
                isHexiaoHidden: !1
            });
            wx.navigateTo({
                url: "../appointment/myOrderList?data=" + e
            });
        }
    }
});