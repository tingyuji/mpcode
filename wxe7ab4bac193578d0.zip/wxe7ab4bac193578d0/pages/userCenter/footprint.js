var t = require("../../server/api"), a = require("../../server/http"), e = 1, i = 1, r = 1;

function n(e) {
    wx.showLoading({
        title: "加载中...",
        mask: !0
    }), (0, t.queryPersonalHistory)(i, e.data.visitorId).then(function(t) {
        if (wx.hideLoading(), 200 == t.code) {
            var r = t.data.records;
            r.forEach(function(t) {
                t.objectTitle.length > 20 && (t.objectTitle = t.objectTitle.substring(0, 20) + "..."), 
                t.objectThumb = null == t.objectThumb ? "../../images/banner.png" : a.api.fileSec + t.objectThumb;
            }), 1 == i && e.setData({
                orderArray: []
            }), i > 1 && 0 === r.length && 0 == e.data.tabIndex && e.setData({
                isHiddleTishiLab: !1
            }), r.length > 0 && 0 == e.data.tabIndex && e.setData({
                orderNullImgState: !0
            });
            var n = e.data.orderArray.concat(r);
            e.setData({
                orderArray: n
            });
        } else e.setData({}), wx.showToast({
            title: t.msg
        });
        wx.hideNavigationBarLoading(), wx.stopPullDownRefresh();
    }).catch(function(t) {
        wx.hideNavigationBarLoading(), wx.stopPullDownRefresh(), wx.hideLoading();
    });
}

function o(i) {
    wx.showLoading({
        title: "加载中...",
        mask: !0
    }), (0, t.queryActivityHistory)(e, i.data.visitorId).then(function(t) {
        if (wx.hideLoading(), 200 == t.code) {
            var r = t.data.records;
            r.forEach(function(t) {
                t.objectTitle.length > 20 && (t.objectTitle = t.objectTitle.substring(0, 20) + "..."), 
                t.objectThumb = null == t.objectThumb ? "../../images/banner.png" : a.api.fileSec + t.objectThumb;
            }), 1 == e && i.setData({
                activityOrderArray: []
            }), r.length > 0 && 1 == i.data.tabIndex && i.setData({
                orderNullImgState: !0
            }), console.log("活动去过");
            var n = i.data.activityOrderArray.concat(r);
            i.setData({
                activityOrderArray: n
            });
        } else wx.showToast({
            title: t.msg
        });
        wx.hideNavigationBarLoading(), wx.stopPullDownRefresh();
    }).catch(function(t) {
        wx.hideNavigationBarLoading(), wx.stopPullDownRefresh(), wx.hideLoading();
    });
}

function d(e) {
    wx.showLoading({
        title: "加载中...",
        mask: !0
    }), (0, t.queryExhibitionHistory)(r).then(function(t) {
        if (wx.hideLoading(), 200 == t.code) {
            var i = t.data;
            i.forEach(function(t) {
                t.name.length > 20 && (t.name = t.name.substring(0, 20) + "..."), t.objectThumb = null == t.thumb ? "../../images/banner.png" : a.api.fileSec + t.thumb;
            }), 1 == r && e.setData({
                exhibitionOrderArr: []
            }), r > 1 && 0 === i.length && 2 == e.data.tabIndex && e.setData({
                isHiddleTishiLab: !1
            }), i.length > 0 && 2 == e.data.tabIndex && e.setData({
                orderNullImgState: !0
            }), console.log(i);
            e.data.exhibitionOrderArr.concat(i);
            console.log("活动去过"), e.setData({
                exhibitionOrderArr: i
            });
        } else wx.showToast({
            title: t.msg
        });
        wx.hideNavigationBarLoading(), wx.stopPullDownRefresh();
    }).catch(function(t) {
        wx.hideNavigationBarLoading(), wx.stopPullDownRefresh(), wx.hideLoading();
    });
}

Page({
    data: {
        visitorId: "",
        tabIndex: 0,
        orderArray: [],
        activityOrderArray: [],
        exhibitionOrderArr: [],
        orderNullImgState: !1,
        isHiddleTishiLab: !0
    },
    onLoad: function(t) {
        var a = JSON.parse(t.data);
        console.log(a), this.setData({
            visitorId: a.visitorId
        }), e = 1, i = 1, r = 1, n(this), o(this), d(this);
    },
    onTopTabItemTap: function(t) {
        var a = t.currentTarget.dataset.index;
        this.data.tabIndex != a && (this.setData({
            tabIndex: a
        }), 0 == a ? this.data.orderArray.length <= 0 ? this.setData({
            orderNullImgState: !1
        }) : this.setData({
            orderNullImgState: !0
        }) : 1 == a ? this.data.activityOrderArray.length <= 0 ? this.setData({
            orderNullImgState: !1
        }) : this.setData({
            orderNullImgState: !0
        }) : 2 == a && (this.data.exhibitionOrderArr.length <= 0 ? this.setData({
            orderNullImgState: !1
        }) : this.setData({
            orderNullImgState: !0
        })));
    },
    itemClick: function(t) {
        var a = t.currentTarget.dataset.index;
        if (1 === this.data.tabIndex) {
            var e = this.data.activityOrderArray[a], i = {
                id: e.objectId,
                tenantId: e.systemId
            }, r = JSON.stringify(i);
            wx.navigateTo({
                url: "../activity/activityDetail?data=" + r
            });
        } else if (2 === this.data.tabIndex) {
            var n = this.data.exhibitionOrderArr[a];
            i = {
                id: n.displayInfoId,
                tenantId: n.displayInfoId
            }, r = JSON.stringify(i);
            wx.navigateTo({
                url: "../exhibition/exhibitionDetail?data=" + r
            });
        } else {
            var o = this.data.orderArray[a];
            i = {
                id: o.objectId,
                tenantId: o.objectId
            }, r = JSON.stringify(i);
            wx.navigateTo({
                url: "../museum/museumDetail?data=" + r
            });
        }
    },
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {
        0 == this.data.tabIndex ? (i = 1, n(this)) : 1 == this.data.tabIndex ? (e = 1, o(this)) : 2 == this.data.tabIndex && (r = 1, 
        d(this));
    },
    onReachBottom: function() {
        console.log("页面上拉触底事件的处理函数"), 0 == this.data.tabIndex ? (this.setData({
            isHiddleTishiLab: !1
        }), ++i, n(this)) : 1 == this.data.tabIndex ? (this.setData({
            isHiddleTishiLab: !1
        }), ++e, o(this)) : 2 == this.data.tabIndex && (++r, this.setData({
            isHiddleTishiLab: !1
        }), d(this));
    },
    onShareAppMessage: function() {}
});