var e = require("../../@babel/runtime/helpers/interopRequireWildcard").default, t = require("../../server/api"), a = require("../../server/http"), i = e(require("../../utils/tokenUtil"));

require("../../utils/validata.js");

Page({
    data: {
        model: {},
        jigouTypeArr: [],
        jigouTypeStr: "",
        jigouTypeIdStr: "",
        jigouTypeDict: {},
        jigouNameStr: "",
        jigouIdStr: "",
        farenNameStr: "",
        farenIdStr: "",
        qiyeNameStr: "",
        qiyeIdStr: "",
        jigouImg: "",
        yewuImg: "",
        farenCardImg1: "",
        farenCardImg2: "",
        lianxirenCardImg1: "",
        lianxirenCardImg2: "",
        renzhenImg: "",
        ziliaoType: 1,
        isHiddenCardType: !1
    },
    onLoad: function(e) {
        var a;
        a = this, (0, t.queryCurrentCertification)().then(function(e) {
            if (200 == e.code) {
                var t = e.data;
                t.hiddenShenq = !1, t.reasonTitle = "", 0 == t.status ? (t.reserveStatusStr = "待审核", 
                t.hiddenShenq = !0) : 1 == t.status ? (t.reserveStatusStr = "审核中", t.reserveStatusImg = "../../images/center/shenhezhong.png", 
                t.hiddenShenq = !0) : 2 == t.status ? (t.reserveStatusStr = "上传成功", t.reserveStatusImg = "../../images/center/shenhetongguo.png", 
                t.hiddenShenq = !0) : 3 == t.status ? (t.reserveStatusStr = "已拒绝", t.reasonTitle = "拒绝原因", 
                t.hiddenShenq = !1, t.reserveStatusImg = "../../images/center/yijujue.png") : 4 == t.status && (t.reserveStatusStr = "已解约", 
                t.reasonTitle = "解约原因", t.hiddenShenq = !1, t.reserveStatusImg = "../../images/center/yijieyue.png"), 
                "其他" != t.agencyTypeStr && a.setData({
                    isHiddenCardType: !0
                }), a.setData({
                    model: t,
                    jigouTypeIdStr: t.agencyType,
                    jigouTypeStr: t.agencyTypeStr,
                    jigouNameStr: t.agencyName,
                    jigouIdStr: t.creditCode,
                    jigouImg: t.businessLicense,
                    qiyeNameStr: t.contactName,
                    qiyeIdStr: t.contactDocumentNumber,
                    lianxirenCardImg1: t.contactFrontCard,
                    lianxirenCardImg2: t.contactReverseCard,
                    renzhenImg: t.officialLetter,
                    ziliaoType: t.dataType
                });
            } else wx.showToast({
                title: e.msg,
                icon: "none"
            });
        }), function(e) {
            wx.showLoading({
                title: "加载中...",
                mask: !0
            }), (0, t.getAgencyTypeList)().then(function(t) {
                wx.hideLoading(), 200 === t.code && e.setData({
                    jigouTypeArr: t.data
                });
            });
        }(this);
    },
    onReady: function() {},
    onShow: function() {},
    ziliaoTypeViewClick: function(e) {
        if (console.log(e), 1 != this.data.model.hiddenShenq) {
            var t = e.currentTarget.dataset.index;
            1 == t ? this.setData({
                ziliaoType: 1
            }) : 2 == t && this.setData({
                ziliaoType: 2
            });
        }
    },
    inputClick: function(e) {
        console.log(e.target.dataset.index);
        var t = e.target.dataset.index;
        1 == t ? this.setData({
            jigouNameStr: e.detail.value
        }) : 2 == t ? this.setData({
            jigouIdStr: e.detail.value
        }) : 3 == t ? this.setData({
            farenNameStr: e.detail.value
        }) : 4 == t ? this.setData({
            farenIdStr: e.detail.value
        }) : 5 == t ? this.setData({
            qiyeNameStr: e.detail.value
        }) : 6 == t && this.setData({
            qiyeIdStr: e.detail.value
        });
    },
    jigouTypePickerChange: function(e) {
        console.log(e.detail.value);
        var t = e.detail.value;
        this.setData({
            jigouTypeDict: this.data.jigouTypeArr[t],
            jigouTypeStr: this.data.jigouTypeArr[t].text,
            jigouTypeIdStr: this.data.jigouTypeArr[t].id
        }), "其他" == this.data.jigouTypeStr ? this.setData({
            isHiddenCardType: !1,
            ziliaoType: 1
        }) : this.setData({
            isHiddenCardType: !0,
            ziliaoType: 1
        });
    },
    appointBtnClick: function(e) {
        var a = this, i = this;
        if (this.data.jigouTypeStr.length <= 0) wx.showToast({
            title: "请选择机构类型",
            icon: "none"
        }); else if (this.data.jigouNameStr.length <= 0) wx.showToast({
            title: "请输入机构名称",
            icon: "none"
        }); else if (this.data.jigouIdStr.length <= 0) "机关部委" == this.data.jigouTypeStr ? wx.showToast({
            title: "请输入组织机构代码",
            icon: "none"
        }) : wx.showToast({
            title: "请输入统一社会信用代码",
            icon: "none"
        }); else if (this.data.jigouImg.length <= 0 && "旅行社" == this.data.jigouTypeStr) wx.showToast({
            title: "请上传机构营业执照",
            icon: "none"
        }); else if (this.data.renzhenImg.length <= 0 && "旅行社" != this.data.jigouTypeStr) wx.showToast({
            title: "请上传介绍信",
            icon: "none"
        }); else {
            i = this;
            wx.showModal({
                title: "提示",
                content: "修改资料后需要重新审核才允许再次预约，是否修改？",
                showCancel: !0,
                success: function(e) {
                    e.confirm && (0, t.reSubmitOrganizationCertification)(getApp().globalData.systemId, a.data.jigouTypeIdStr, a.data.jigouNameStr, a.data.jigouIdStr, a.data.jigouImg, a.data.qiyeNameStr, a.data.qiyeIdStr, a.data.lianxirenCardImg1, a.data.lianxirenCardImg2, a.data.renzhenImg, i.data.model.agencyId, a.data.ziliaoType).then(function(e) {
                        200 == e.code ? wx.showModal({
                            title: "提示",
                            content: "团队注册材料重新提交成功，所提交资料将在48小时内完成审核，审核未通过前将不能进行预约操作，请留意审核结果。",
                            showCancel: !1,
                            success: function(e) {
                                e.confirm && wx.navigateBack({});
                            }
                        }) : wx.showToast({
                            title: e.msg,
                            icon: "none"
                        });
                    });
                }
            });
        }
    },
    cellImgClick: function(e) {
        console.log(e.target.dataset.index);
        var t = e.target.dataset.index;
        if (!this.data.model.hiddenShenq) {
            var n = this;
            wx.chooseMedia({
                count: 1,
                mediaType: [ "image" ],
                sourceType: [ "album", "camera" ],
                camera: "back",
                success: function(e) {
                    console.log(e);
                    var o = e.tempFiles[0].tempFilePath;
                    console.log("件路径列表" + o), wx.uploadFile({
                        filePath: o,
                        name: "trackData",
                        header: {
                            appId: i.appId,
                            token: (0, i.default)(),
                            systemId: getApp().globalData.systemId,
                            "Content-Type": "multipart/form-data"
                        },
                        formData: {
                            code: "TRM_COMPANY_PHOTO"
                        },
                        url: a.api.file + "file/normalUploadByCode/TRM_COMPANY_PHOTO/FKYY/" + getApp().globalData.systemId,
                        success: function(e) {
                            if (413 != e.statusCode && null != e.data) {
                                var i = JSON.parse(e.data);
                                200 == i.code ? (console.log("上传成功", i.data.filePath + i.data.fileName), o = a.api.fileSec + i.data.filePath + i.data.fileName, 
                                1 == t ? n.setData({
                                    jigouImg: o
                                }) : 2 == t ? n.setData({
                                    yewuImg: o
                                }) : 3 == t ? n.setData({
                                    farenCardImg1: o
                                }) : 4 == t ? n.setData({
                                    farenCardImg2: o
                                }) : 5 == t ? n.setData({
                                    lianxirenCardImg1: o
                                }) : 6 == t ? n.setData({
                                    lianxirenCardImg2: o
                                }) : 7 == t && n.setData({
                                    renzhenImg: o
                                })) : wx.showToast({
                                    title: "请上传小于1M的图片"
                                });
                            } else wx.showToast({
                                title: "请上传小于1M的图片",
                                icon: "none"
                            });
                        },
                        fail: function(e) {
                            console.error("上传失败", e);
                        }
                    });
                }
            });
        }
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});