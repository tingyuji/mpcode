var t = require("../../server/api"), e = t.queryViewList, i = (t.fullImageUrl, t.fullImageUrlSaaS, 
require("../../server/http").api), o = 1;

function a(t) {
    wx.showLoading({
        title: "加载中..."
    }), e(o).then(function(e) {
        wx.hideLoading(), wx.hideNavigationBarLoading(), wx.stopPullDownRefresh();
        var a = [];
        if (200 == e.code) {
            var n = e.data.records;
            n.forEach(function(t) {
                t.objectTitle.length > 20 && (t.objectTitle = t.objectTitle.substring(0, 20) + "..."), 
                t.objectThumb = null == t.objectThumb ? "../../images/banner.png" : i.fileSec + t.objectThumb, 
                2 === t.objectType ? (t.typeStr = "活动", t.typeColor = "#55A662") : 3 === t.objectType ? (t.typeStr = "展览", 
                t.typeColor = "#cfb053") : 3 === t.objectType ? (t.typeStr = "展评", t.typeColor = "#DB5151") : 1 === t.objectType && (t.typeStr = "场馆", 
                t.typeColor = "#cfb053");
            }), a = 1 === o ? n : t.data.list.concat(n), t.setData({
                list: a
            });
        } else wx.showToast({
            title: e.msg,
            icon: "none"
        });
    }).catch(function(t) {
        console.error(t), wx.hideLoading(), wx.hideNavigationBarLoading(), wx.stopPullDownRefresh(), 
        wx.showToast({
            title: "获取列表数据失败",
            icon: "none"
        });
    });
}

Page({
    data: {
        list: []
    },
    onLoad: function(t) {
        a(this);
    },
    itemClick: function(t) {
        var e = t.currentTarget.dataset.index, i = this.data.list[e], o = {
            id: i.objectId,
            saas: i.saas
        }, a = JSON.stringify(o);
        if (3 === i.objectType) wx.navigateTo({
            url: "../exhibition/exhibitionDetail?data=" + a
        }); else if (2 === i.objectType) wx.navigateTo({
            url: "../activity/activityDetail?data=" + a
        }); else if (4 === i.objectType) {
            var n = {
                id: i.objectId,
                place: i.objectTitle
            }, c = JSON.stringify(n);
            wx.navigateTo({
                url: "../exhibition/findDetail?data=" + c
            });
        } else wx.navigateTo({
            url: "../museum/museumDetail?data=" + a
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {
        o = 1, a(this);
    },
    onReachBottom: function() {
        o += 1, a(this);
    },
    onShareAppMessage: function() {}
});