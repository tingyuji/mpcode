var t = require("../../server/api");

function e(e) {
    (0, t.teamReserveLeaders)(getApp().globalData.userInfo.customerId, getApp().globalData.systemId).then(function(t) {
        if (200 == t.code) {
            var a = t.data, s = !1, o = [];
            a.forEach(function(t) {
                t.myself = 0, t.guideId === getApp().globalData.userInfo.customerId && (s = !0, 
                t.myself = 1), o.push(t);
            }), e.setData({
                isHasSelf: s,
                contactsArr: o
            });
        } else wx.showToast({
            title: t.msg
        });
    });
}

Page({
    data: {
        contactsArr: [],
        maxCount: 10,
        isHasSelf: !1
    },
    onLoad: function(t) {
        e(this);
    },
    addBtnClick: function(t) {
        var e = {
            isTeamAppoint: !1
        };
        e.isHasSelf = this.data.isHasSelf, e.isAdd = !0;
        var a = JSON.stringify(e);
        wx.navigateTo({
            url: "../teamAppoint/addJidiaoyuan?data=" + a
        });
    },
    deleteClick: function(a) {
        var s = this, o = a.currentTarget.dataset.index, n = this.data.contactsArr[o], i = n.agencyId, c = n.guideId;
        wx.showModal({
            title: "提示",
            content: "确定删除吗？",
            success: function(a) {
                a.confirm ? (console.log("用户点击确定"), (0, t.deleteLeaderDeleteById)(i, c, getApp().globalData.systemId).then(function(t) {
                    200 == t.code ? (wx.showToast({
                        title: "删除成功！"
                    }), e(s)) : wx.showToast({
                        title: t.msg
                    });
                }).catch(function(t) {
                    console.error("删除联系人失败" + t);
                })) : a.cancel && console.log("用户点击取消");
            }
        });
    },
    reloadContactsData: function() {
        e(this);
    }
});