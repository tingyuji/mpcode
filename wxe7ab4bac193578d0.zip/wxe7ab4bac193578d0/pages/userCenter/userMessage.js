var e = require("../../server/api"), t = require("../../utils/tokenUtil");

require("../../utils/validata.js");

function a(a) {
    wx.showLoading({
        title: "加载中...",
        mask: !0
    }), (0, e.queryCertList)().then(function(o) {
        wx.hideLoading(), 200 === o.code && null != o.data && o.data.length > 0 && (getApp().globalData.userInfo = o.data[0], 
        o.data[0].hidePhoneNew = (0, t.hidePhoneNum)(o.data[0].phoneNumber), a.setData({
            userModel: o.data[0]
        }), (0, e.customerContactQueryPageList)().then(function(e) {
            if (200 == e.code) {
                for (var t = e.data.records, a = 0; a < t.length; a++) if (1 == t[a].myself) {
                    var o = getApp().globalData.userInfo;
                    o.customerContactId = t[a].customerContactId, getApp().globalData.userInfo = o;
                    break;
                }
            } else wx.showToast({
                title: e.data.msg,
                icon: "none"
            });
        }));
    });
}

Page({
    data: {
        userModel: {}
    },
    onLoad: function(e) {
        a(this);
    },
    onShow: function() {},
    reloadContactsData: function(e) {
        a(this);
    },
    cellviewClick: function(e) {
        var t = e.currentTarget.dataset.index;
        console.log(t);
        var a = {};
        1 == t ? a = {
            oldStr: this.data.userModel.customerName,
            titleStr: "姓名",
            showPhoneNew: "",
            hideCardNumStr: ""
        } : 2 == t && (a = {
            oldStr: this.data.userModel.hidePhoneNew,
            showPhoneNew: this.data.userModel.phoneNumber,
            titleStr: "手机号",
            hideCardNumStr: ""
        }), 3 == t && (a = {
            oldStr: this.data.userModel.documentTypeName,
            cardNumStr: this.data.userModel.documentNumber,
            hideCardNumStr: this.data.userModel.showDocumentNumber,
            cardTypeIdStr: this.data.userModel.documentType,
            titleStr: "证件号",
            showPhoneNew: ""
        }), 4 == t && (a = {
            oldStr: this.data.userModel.documentTypeName,
            cardNumStr: this.data.userModel.documentNumber,
            hideCardNumStr: this.data.userModel.showDocumentNumber,
            cardTypeIdStr: this.data.userModel.documentType,
            titleStr: "证件号",
            showPhoneNew: ""
        });
        var o = JSON.stringify(a);
        wx.navigateTo({
            url: "userMessageChange?data=" + o
        });
    }
});