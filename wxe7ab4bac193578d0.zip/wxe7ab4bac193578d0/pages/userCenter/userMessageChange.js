var t = require("../../server/api"), e = require("../../server/static"), a = require("../../utils/myUtil"), i = require("../../utils/validata.js"), n = 0;

function o(e) {
    e.setData({
        codeInputStr: ""
    }), (0, t.saasQueryVCode)().then(function(t) {
        if (200 == t.code) {
            var a = t.data.image.replace(/[\r\n]/g, "");
            e.setData({
                captchaImgBase64: a,
                vid: t.data.vid
            });
        } else n = 0, wx.showToast({
            title: t.msg,
            icon: "none"
        });
    }).catch(function(t) {
        n = 0, hideLoading(), console.error("验证码失败" + t);
    });
}

Page({
    data: {
        oldStr: "",
        newStr: "",
        titleStr: "",
        codeInputStr: "",
        captchaImgBase64: "",
        vid: "",
        codeStr: "获取验证码",
        countdown: 60,
        showCountdown: !1,
        nameStr: "",
        cardtypeArr: [],
        cardTypeStr: "",
        cardTypeIdStr: "",
        cardNumStr: "",
        hideCardNumStr: "",
        phoneStr: "",
        hidePhoneStr: "",
        showPhoneNew: "",
        vcodeStr: "",
        xianShiImg: !1
    },
    onLoad: function(t) {
        var a = JSON.parse(t.data);
        wx.setNavigationBarTitle({
            title: "更换" + a.titleStr
        }), this.setData({
            titleStr: a.titleStr,
            oldStr: a.oldStr,
            hidePhoneStr: a.oldStr,
            showPhoneNew: a.showPhoneNew,
            hideCardNumStr: a.hideCardNumStr
        }), "证件号" == a.titleStr && this.setData({
            cardNumStr: a.cardNumStr,
            cardtypeArr: e.cardTypeArr
        });
    },
    onReady: function() {},
    onShow: function() {
        n = new Date().getTime(), o(this);
    },
    tuwenCaptchaClick: function(t) {
        var e = new Date().getTime();
        e - n > 3e3 ? (n = e, o(this)) : (0, a.toast)("操作太频繁，请稍后再试");
    },
    captchaCodeInput: function(t) {
        this.setData({
            codeInputStr: t.detail.value
        });
    },
    xianShiImgClick: function(t) {
        var e = this.data.hidePhoneStr, a = this.data.showPhoneNew;
        "手机号" == this.data.titleStr ? 1 == this.data.xianShiImg ? this.setData({
            xianShiImg: !1,
            oldStr: e
        }) : this.setData({
            xianShiImg: !0,
            oldStr: a
        }) : 1 == this.data.xianShiImg ? this.setData({
            xianShiImg: !1
        }) : this.setData({
            xianShiImg: !0
        });
    },
    newStrInput: function(t) {
        this.setData({
            newStr: t.detail.value
        });
    },
    cardTypePickerChange: function(t) {
        console.log(t.detail.value);
        var e = t.detail.value;
        this.setData({
            cardTypeStr: this.data.cardtypeArr[e].text,
            cardTypeIdStr: this.data.cardtypeArr[e].id
        });
    },
    vcodeInput: function(t) {
        this.setData({
            vcodeStr: t.detail.value
        });
    },
    captchaClick: function(e) {
        var a = this;
        if (1 != this.data.showCountdown) if ("" == this.data.newStr) wx.showToast({
            title: "请输入变更" + this.data.titleStr,
            icon: "none"
        }); else if ("姓名" == this.data.titleStr && this.data.newStr == this.data.oldStr) wx.showToast({
            title: "输入内容未变更，请重新输入",
            icon: "none"
        }); else if ("手机号" == this.data.titleStr && this.data.newStr == this.data.showPhoneNew) wx.showToast({
            title: "输入内容未变更，请重新输入",
            icon: "none"
        }); else if ("证件号" == this.data.titleStr && this.data.newStr == this.data.hideCardNumStr) wx.showToast({
            title: "输入内容未变更，请重新输入",
            icon: "none"
        }); else {
            if (this.data.codeInputStr.length <= 0) return void wx.showToast({
                title: "请输入图文验证码",
                icon: "none"
            });
            this.setData({
                showCountdown: !0,
                countdown: 60
            }), clearTimeout(this.timer), this.timer = setInterval(function() {
                0 == a.data.countdown && (clearInterval(a.timer), a.setData({
                    showCountdown: !1,
                    countdown: 60
                })), a.setData({
                    countdown: a.data.countdown - 1
                });
            }, 1e3), function(e) {
                e.setData({
                    captchaInputStr: ""
                });
                var a = "";
                if ("手机号" == e.data.titleStr) {
                    if (!/^1[3456789]\d{9}$/.test(e.data.newStr)) return void wx.showToast({
                        title: "请输入正确的手机号",
                        icon: "none"
                    });
                    a = e.data.newStr;
                } else a = getApp().globalData.userInfo.phoneNumber;
                (0, t.getQuerySmsVCode)(a, e.data.codeInputStr, e.data.vid).then(function(t) {
                    200 == t.code ? wx.showToast({
                        title: "发送成功"
                    }) : (e.setData({
                        showCountdown: !1,
                        countdown: 60
                    }), wx.showToast({
                        title: t.msg,
                        icon: "none"
                    }));
                }).catch(function(t) {
                    e.setData({
                        showCountdown: !1,
                        countdown: 60
                    }), wx.showToast({
                        title: "获取验证码失败",
                        icon: "none"
                    }), console.error("获取验证码失败" + t);
                });
            }(this);
        }
    },
    sureBtnClick: function(e) {
        if ("" == this.data.newStr) wx.showToast({
            title: "请输入变更" + this.data.titleStr,
            icon: "none"
        }); else if ("手机号" !== this.data.titleStr || /^1[3456789]\d{9}$/.test(this.data.newStr)) if ("证件号" === this.data.titleStr && this.data.cardTypeIdStr.length <= 0) wx.showToast({
            title: "请选择证件类型",
            icon: "none"
        }); else if ("证件号" === this.data.titleStr && this.data.newStr.length < 5) wx.showToast({
            title: "请正确输入证件号",
            icon: "none"
        }); else if (this.data.vcodeStr.length <= 0) wx.showToast({
            title: "请正确输入验证码",
            icon: "none"
        }); else {
            if ("证件号" === this.data.titleStr && "中国居民身份证" == this.data.cardTypeStr) {
                var a = this.data.newStr;
                if (!i.checkIdCardNo(a)) return void wx.showToast({
                    title: "证件号码输入有误",
                    icon: "none"
                });
            }
            var n = "", o = "", s = "", r = "";
            "姓名" === this.data.titleStr && (n = this.data.newStr), "手机号" === this.data.titleStr && (r = this.data.newStr), 
            "证件号" === this.data.titleStr && (o = this.data.cardTypeIdStr, s = this.data.newStr), 
            (0, t.customerUpdateCert)(n, o, s, r, this.data.vcodeStr).then(function(t) {
                if (200 == t.code) {
                    var e = getCurrentPages(), a = e[e.length - 2];
                    wx.navigateBack({
                        success: function() {
                            a.reloadContactsData();
                        }
                    }), wx.showToast({
                        title: "添加成功",
                        icon: "none"
                    });
                } else wx.showToast({
                    title: t.msg,
                    icon: "none"
                });
            });
        } else wx.showToast({
            title: "请输入正确的手机号",
            icon: "none"
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});