var e = require("../../server/api.js").renlianAddFaceUrl, a = require("../../server/http.js").api, t = require("../../utils/tokenUtil.js").default, o = require("../../utils/tokenUtil.js"), i = "";

function l(e, a) {
    wx.hideLoading(), e.setData({
        isHiddleImage: !0
    }), wx.showToast({
        title: a,
        duration: 3e3,
        icon: "none"
    });
}

Page({
    data: {
        isShenHe: !1,
        isHiddleImage: !0,
        imagePathStr: "",
        visitorId: "",
        pageUrl: ""
    },
    onLoad: function(e) {
        this.setData({
            isShenHe: getApp().globalData.isShenHe
        }), function() {
            var e = wx.getSystemInfoSync().windowWidth, a = wx.getSystemInfoSync().windowHeight;
            console.log("windowHeight", a), console.log("windowWidth", e);
            var t = wx.createCanvasContext("myCanvas");
            t.beginPath();
            var o = .5 * e, i = .5 * a, l = .5 * e * .8;
            t.arc(o, i, l, 0, 2 * Math.PI), t.fill(), t.beginPath(), t.globalCompositeOperation = "source-out", 
            t.rect(0, 0, e, a), t.fillStyle = "rgba(0,0,0,0.3)", t.fill(), t.beginPath();
            o = .5 * e, i = .5 * a, l = .5 * e * .8;
            t.arc(o, i, l, 0, 2 * Math.PI), t.setStrokeStyle("#6394d6"), t.stroke(), t.draw();
        }(), function(e) {
            var a = getApp().globalData.baiDuApiUrl2;
            console.log("baiDuApiUrl2" + a);
            wx.request({
                url: a,
                method: "POST",
                success: function(e) {
                    i = e.data.access_token, console.log(i);
                },
                fail: function(e) {
                    console.debug("失败，" + e.errMsg);
                }
            });
        }();
    },
    cameraImageClick: function(n) {
        var s = this;
        console.log("刷脸拍照"), wx.createCameraContext().takePhoto({
            quality: "normal",
            success: function(n) {
                !function(n, s) {
                    wx.showLoading({
                        title: "上传识别中..."
                    }), n.setData({
                        imagePathStr: s,
                        isHiddleImage: !1
                    });
                    var c = wx.getFileSystemManager().readFileSync(s, "base64"), r = getApp().globalData.baiDuApiUrl1 + i;
                    console.log("baiDuApiUrl1" + r);
                    var u = {
                        image: c,
                        image_type: "BASE64",
                        max_face_num: 2,
                        face_field: "quality"
                    };
                    console.log("detectFace"), wx.request({
                        url: r,
                        method: "POST",
                        data: u,
                        header: {
                            "Content-Type": "application/x-www-form-urlencoded"
                        },
                        success: function(i) {
                            if ("SUCCESS" === i.data.error_msg) {
                                var c = i.data.result;
                                console.log("照片模糊度：" + c.face_list[0].quality.blur), console.log("脸部亮暗度：" + c.face_list[0].quality.illumination), 
                                c.face_num > 1 ? l(n, "多人一起拍照将导致无法刷脸入馆，请重新拍照") : c.face_list[0].quality.blur > .2 ? l(n, "照片太模糊，请重新拍照") : c.face_list[0].quality.illumination < 100 ? l(n, "脸部太暗，请重新拍照") : c.face_list[0].quality.illumination > 160 ? l(n, "脸部太亮，请重新拍照") : 0 == c.face_list[0].quality.completeness ? l(n, "脸部拍摄不完整，请重新拍照") : c.face_list[0].quality.occlusion.left_eye > .6 || c.face_list[0].quality.occlusion.right_eye > .6 ? l(n, "眼睛被遮挡，请重新拍照") : c.face_list[0].quality.occlusion.nose > .7 ? l(n, "鼻子被遮挡，请重新拍照") : c.face_list[0].quality.occlusion.mouth > .7 ? l(n, "嘴巴被遮挡，请重新拍照") : c.face_list[0].quality.occlusion.chin_contour > .6 ? l(n, "下巴被遮挡，请重新拍照") : c.face_list[0].quality.occlusion.right_cheek > .5 || c.face_list[0].quality.occlusion.left_cheek > .5 ? l(n, "脸颊被遮挡，请重新拍照") : function(i, l) {
                                    console.log("刷脸++++");
                                    var n = a.file + "file/normalUploadByCode/TRM_VISITORINFO_PHOTO/swseeker/" + getApp().globalData.systemId;
                                    wx.uploadFile({
                                        url: n,
                                        filePath: l,
                                        name: "trackData",
                                        header: {
                                            appId: o.appId,
                                            token: t(),
                                            "Content-Type": "multipart/form-data"
                                        },
                                        formData: {
                                            code: "TRM_VISITORINFO_PHOTO"
                                        },
                                        success: function(a) {
                                            console.log("url：" + n + "上传图片1：" + a.data), console.log("上传图片2：" + JSON.stringify(a.data));
                                            var t = JSON.parse(a.data);
                                            if (200 === t.code) {
                                                var o = t.data.filePath + t.data.fileName;
                                                console.log(getApp().globalData.userInfo.customerContactId + "，" + o), e(getApp().globalData.userInfo.customerContactId, o).then(function(e) {
                                                    wx.hideLoading(), 200 == e.code ? (wx.hideLoading(), getApp().globalData.hasLoadFaceUrl = !0, 
                                                    getApp().globalData.faceUrl = o, wx.showToast({
                                                        title: "识别成功"
                                                    }), setTimeout(function() {
                                                        wx.navigateBack({});
                                                    }, 1e3)) : wx.showToast({
                                                        title: e.msg,
                                                        icon: "none"
                                                    });
                                                });
                                            }
                                        }
                                    });
                                }(0, s);
                            } else l(n, "请重试");
                            console.log(i);
                        },
                        fail: function(e) {
                            l(n, "网络异常，请重试"), console.debug("失败，" + e.errMsg);
                        }
                    });
                }(s, n.tempImagePath);
            },
            error: function(e) {
                console.log("用户拒绝授权时");
            }
        });
    }
});