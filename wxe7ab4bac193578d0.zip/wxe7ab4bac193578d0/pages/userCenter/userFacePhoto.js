var n = require("../../server/http");

Page({
    data: {
        imagePathStr: ""
    },
    onLoad: function(n) {},
    onShow: function() {
        this.setData({
            imagePathStr: n.api.fileSec + getApp().globalData.faceUrl
        });
    },
    loadAgainImgClick: function(n) {
        wx.navigateTo({
            url: "PhotoExperience"
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});