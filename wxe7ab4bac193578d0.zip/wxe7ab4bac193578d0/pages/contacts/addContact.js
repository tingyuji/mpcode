var t = require("../../@babel/runtime/helpers/interopRequireWildcard").default, a = require("../../server/api"), e = require("../../server/static"), i = require("../../utils/myUtil"), s = t(require("../../utils/tokenUtil")), r = require("../../utils/validata.js");

Page({
    data: {
        cardtypeArr: [],
        model: {},
        cardTypeStr: "",
        cardTypeIdStr: "",
        countryTypeStr: "",
        countryTypeIdStr: "",
        countryTypeArr: [],
        nameStr: "",
        phoneStr: "",
        cardNumStr: "",
        visitorContactId: "",
        isMySelf: !1,
        isVip: 0,
        xieyiSeleced: !1,
        isHasSelf: !1,
        isCanChooseVip: !0
    },
    onLoad: function(t) {
        var i, s = JSON.parse(t.data);
        null != s.isHasSelf ? (this.setData({
            model: s,
            isHasSelf: s.isHasSelf
        }), 1 == s.isTeamAppoint && (wx.setNavigationBarTitle({
            title: "添加团员"
        }), 1 == s.isEdit && (this.setData({
            nameStr: s.nameStr,
            phoneStr: s.phoneStr,
            cardNumStr: s.cardNumStr,
            cardTypeStr: s.cardTypeStr,
            cardTypeIdStr: s.documentType,
            countryTypeStr: s.countryTypeStr,
            countryTypeIdStr: s.countryTypeIdStr,
            isVip: s.isVip
        }), wx.setNavigationBarTitle({
            title: "修改团员信息"
        })))) : (i = this, (0, a.customerContactQueryPageList)().then(function(t) {
            if (200 == t.code) {
                for (var a = t.data.records, e = !1, s = 0; s < a.length; s++) if (1 === a[s].myself) {
                    e = !0;
                    break;
                }
                i.setData({
                    isHasSelf: e
                });
            } else wx.showToast({
                title: t.data.msg,
                icon: "none"
            });
        }).catch(function(t) {
            console.error("获取联系人失败" + t);
        })), 1 == this.data.model.isTeamAppoint && 1 == this.data.model.isEdit ? this.setData({
            cardtypeArr: e.cardTypeArr
        }) : this.setData({
            cardTypeStr: e.cardTypeArr[0].text,
            cardTypeIdStr: e.cardTypeArr[0].id,
            cardtypeArr: e.cardTypeArr
        });
    },
    autoRefreshData: function(t) {
        this.setData({
            xieyiSeleced: !0
        });
    },
    radioLabChange: function(t) {
        var a = t.currentTarget.dataset.id;
        console.log(a), this.setData({
            isVip: a
        });
    },
    xieyiViewClick: function(t) {
        wx.navigateTo({
            url: "../contacts/yingsiAgreement"
        });
    },
    chooseTureImgClick: function(t) {
        this.setData({
            isMySelf: !0
        });
    },
    chooseFalseImgClick: function(t) {
        this.setData({
            isMySelf: !1
        });
    },
    userNameInput: function(t) {
        this.setData({
            nameStr: t.detail.value
        });
    },
    phoneNumInput: function(t) {
        this.setData({
            phoneStr: t.detail.value
        });
    },
    cardNumInput: function(t) {
        var a = this;
        if (this.setData({
            cardNumStr: t.detail.value,
            isCanChooseVip: !0
        }), console.log("证件号码输入eee"), "中国居民身份证" == this.data.cardTypeStr) {
            var e = (0, s.getAgeByCard)(this.data.cardNumStr);
            console.log("证件号码" + e), e > 18 ? this.setData({
                isCanChooseVip: !0
            }) : this.setData({
                isCanChooseVip: !1,
                isVip: 0
            }), 1 == this.data.model.isAddChild && e > 18 && wx.showModal({
                title: "提示",
                content: "您所添加的证件信息为非儿童，是否确认添加？请注意！若确认添加，所加信息将不会出现在儿童列表中。",
                cancelColor: "",
                showCancel: !0,
                success: function(t) {
                    if (t.confirm) ; else if (t.cancel) return void a.setData({
                        cardNumStr: ""
                    });
                }
            });
        } else this.setData({
            isCanChooseVip: !0
        });
    },
    cardTypePickerChange: function(t) {
        var a = t.detail.value;
        this.setData({
            cardTypeStr: this.data.cardtypeArr[a].text,
            cardTypeIdStr: this.data.cardtypeArr[a].id
        });
    },
    countryTypePickerChange: function(t) {
        var a = t.detail.value;
        this.setData({
            countryTypeStr: this.data.countryTypeArr[a].text,
            countryTypeIdStr: this.data.countryTypeArr[a].id
        });
    },
    cancleBtnClick: function(t) {
        wx.navigateBack({});
    },
    sureBtnClick: function(t) {
        var e = this, s = this.data.nameStr.replace(/\s+/g, ""), n = this.data.phoneStr.replace(/\s+/g, ""), o = this.data.cardNumStr.replace(/\s+/g, "");
        if (this.setData({
            nameStr: s,
            phoneStr: n,
            cardNumStr: o
        }), "" === this.data.nameStr) wx.showToast({
            title: "请输入与证件一致的姓名",
            icon: "none"
        }); else if ("" === this.data.phoneStr) wx.showToast({
            title: "请输入手机号码",
            icon: "none"
        }); else if (/^1[3456789]\d{9}$/.test(this.data.phoneStr)) if (this.data.cardTypeIdStr.length <= 0) wx.showToast({
            title: "请选择证件类型",
            icon: "none"
        }); else if (this.data.cardNumStr.length < 5) wx.showToast({
            title: "请填写正确的证件号码",
            icon: "none"
        }); else if (0 == this.data.xieyiSeleced) wx.showToast({
            title: "请先阅读并同意隐私协议",
            icon: "none"
        }); else {
            if ("中国居民身份证" == this.data.cardTypeStr) {
                var d = this.data.cardNumStr;
                if (!r.checkIdCardNo(d)) return void wx.showToast({
                    title: "证件号码输入有误",
                    icon: "none"
                });
            }
            "护照" != this.data.cardTypeStr && this.setData({
                countryTypeIdStr: "",
                countryTypeStr: ""
            }), 1 == this.data.model.isTeamAppoint ? 1 == this.data.model.isEdit ? (0, a.updateTeamMember)(this.data.model.teamShareCode, this.data.nameStr, this.data.phoneStr, this.data.cardTypeIdStr, this.data.countryTypeIdStr, this.data.cardNumStr, this.data.model.detailId, this.data.isVip).then(function(t) {
                if (200 == t.code) {
                    var a = getCurrentPages(), e = a[a.length - 2];
                    wx.navigateBack({
                        success: function() {
                            e.reloadContactsData();
                        }
                    }), wx.showToast({
                        title: "修改成功",
                        icon: "none"
                    });
                } else wx.showToast({
                    title: t.msg,
                    icon: "none"
                });
            }) : (0, a.addTeamMember)(this.data.model.teamShareCode, this.data.nameStr, this.data.phoneStr, this.data.cardTypeIdStr, this.data.countryTypeIdStr, this.data.cardNumStr, getApp().globalData.systemId, this.data.isVip).then(function(t) {
                if (200 == t.code) {
                    var a = getCurrentPages(), e = a[a.length - 2];
                    wx.navigateBack({
                        success: function() {
                            e.reloadContactsData();
                        }
                    }), wx.showToast({
                        title: "添加成功",
                        icon: "none"
                    });
                } else wx.showToast({
                    title: t.msg,
                    icon: "none"
                });
            }) : "中国居民身份证" != this.data.cardTypeStr && 1 == this.data.model.isAddChild ? wx.showModal({
                title: "提示",
                content: "您所添加的证件信息为非儿童，是否确认添加？请注意！若确认添加，所加信息将不会出现在儿童列表中。",
                cancelColor: "",
                showCancel: !0,
                success: function(t) {
                    if (t.confirm) (0, a.customerContactSave)(e.data.nameStr, e.data.phoneStr, e.data.cardTypeIdStr, e.data.countryTypeIdStr, e.data.cardNumStr, e.data.isVip, e.data.isMySelf ? 1 : 0).then(function(t) {
                        if (200 == t.code) {
                            var a = getCurrentPages(), e = a[a.length - 2];
                            wx.navigateBack({
                                success: function() {
                                    e.reloadContactsData();
                                }
                            }), wx.showToast({
                                title: "添加成功",
                                icon: "none"
                            });
                        } else wx.showToast({
                            title: t.msg,
                            icon: "none"
                        });
                    }); else if (t.cancel) return void e.setData({
                        cardNumStr: ""
                    });
                }
            }) : ((0, i.showLoading)(), (0, a.customerContactSave)(this.data.nameStr, this.data.phoneStr, this.data.cardTypeIdStr, this.data.countryTypeIdStr, this.data.cardNumStr, this.data.isVip, this.data.isMySelf ? 1 : 0).then(function(t) {
                if ((0, i.hideLoading)(), 200 == t.code) {
                    var a = getCurrentPages(), e = a[a.length - 2];
                    wx.navigateBack({
                        success: function() {
                            e.reloadContactsData();
                        }
                    }), wx.showToast({
                        title: "添加成功",
                        icon: "none"
                    });
                } else wx.showToast({
                    title: t.msg,
                    icon: "none"
                });
            }).catch(function(t) {
                (0, i.hideLoading)(), (0, i.toast)("保存失败"), (0, i.onlineLog)("保存联系人失败，" + JSON.stringify(t));
            }));
        } else wx.showToast({
            title: "请输入正确的手机号",
            icon: "none"
        });
    }
});