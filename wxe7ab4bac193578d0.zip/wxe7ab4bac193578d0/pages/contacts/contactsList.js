var t = require("../../server/api");

function a(a) {
    (0, t.customerContactQueryList)().then(function(t) {
        if (200 == t.code) {
            console.log("获取了最新的联系人信息，并保存本地缓存"), wx.setStorage({
                key: getApp().globalData.openId + "_contacts",
                data: JSON.stringify(t.data)
            });
            for (var e = t.data, o = !1, n = 0; n < e.length; n++) if (1 === e[n].myself) {
                o = !0;
                break;
            }
            a.setData({
                isHasSelf: o,
                contactsArr: e
            });
        } else wx.showToast({
            title: t.msg
        });
    }).catch(function(t) {
        console.error("获取联系人失败" + t);
    });
}

Page({
    data: {
        contactsArr: [],
        maxCount: 10,
        isHasSelf: !1
    },
    onLoad: function(t) {
        a(this);
    },
    addBtnClick: function(t) {
        if (this.data.contactsArr.length >= this.data.maxCount) wx.showToast({
            title: "人数已达上限",
            icon: "none"
        }); else {
            var a = {
                isTeamAppoint: !1
            };
            a.isHasSelf = this.data.isHasSelf, a.isAdd = !0;
            var e = JSON.stringify(a);
            wx.navigateTo({
                url: "addContact?data=" + e
            });
        }
    },
    editeimgClick: function(t) {
        console.log("编辑按钮点击" + JSON.stringify(t.target.dataset.value));
        var a = t.target.dataset.value, e = {
            isedite: !0,
            isHasUser: !0,
            customerContactId: a.customerContactId,
            countryTypeStr: a.nationalityName,
            countryTypeIdStr: a.nationality
        }, o = JSON.stringify(e);
        console.log(o), wx.navigateTo({
            url: "editPerple?data=" + o
        });
    },
    deleteClick: function(e) {
        var o = this;
        console.log("删除按钮点击" + e.target.dataset.value);
        var n = e.target.dataset.value;
        wx.showModal({
            title: "提示",
            content: "确定删除吗？",
            success: function(e) {
                e.confirm ? (console.log("用户点击确定"), (0, t.customerContactDeleteById)(n).then(function(t) {
                    200 == t.code ? (wx.showToast({
                        title: "删除成功！"
                    }), a(o)) : wx.showToast({
                        title: t.msg
                    });
                }).catch(function(t) {
                    console.error("删除联系人失败" + t);
                })) : e.cancel && console.log("用户点击取消");
            }
        });
    },
    reloadContactsData: function() {
        a(this);
    }
});