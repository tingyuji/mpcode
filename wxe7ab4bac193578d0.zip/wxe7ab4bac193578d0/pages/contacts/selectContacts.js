var t = require("../../server/api"), a = require("../../utils/myUtil"), e = require("./static");

function d(e, d) {
    var n = wx.getStorageSync(getApp().globalData.openId + "_contacts");
    if ("" == n || null == n || d) console.log("缓存中没有联系人，开始请求"), (0, a.showLoading)(), 
    (0, t.customerContactQueryList)().then(function(t) {
        (0, a.hideLoading)(), 200 == t.code ? (console.log("获取联系人成功，并缓存本地，下次进入将不再请求"), wx.setStorage({
            key: getApp().globalData.openId + "_contacts",
            data: JSON.stringify(t.data)
        }), i(e, t.data)) : wx.showToast({
            title: t.data.msg
        });
    }).catch(function(t) {
        console.error("获取联系人失败", t), (0, a.onlineLog)("获取联系人失败，" + JSON.stringify(t)), (0, 
        a.hideLoading)();
    }); else {
        console.log("缓存中有联系人信息，不再请求");
        var s = JSON.parse(n);
        null == s && ((0, a.onlineLog)("出错了，缓存中联系人数据存在异常，" + n), console.error("出错了，缓存中联系人数据存在异常", n)), 
        i(e, s);
    }
}

function i(t, a) {
    console.log(a);
    var e = [], d = !1;
    a.forEach(function(a, i) {
        a.seleted = -1 != t.data.seletDataArr.findIndex(function(t) {
            return t.customerContactId === a.customerContactId;
        }), t.data.allAddChildArr != [] && null != t.data.allAddChildArr && (a.childSeleted = -1 != t.data.allAddChildArr.findIndex(function(t) {
            return t.customerContactId === a.customerContactId;
        }), t.data.allAddChildArr.forEach(function(t, e) {
            a.customerContactId == t.customerContactId && (a.leaderContactId = t.leaderContactId);
        })), t.data.seletDataArr.forEach(function(t, e) {
            t.customerContactId == a.customerContactId && 0 == a.isJuveniles && (a.addChildArr = t.addChildArr);
        }), 0 === a.isJuveniles && 1 != a.seleted && (a.addChildArr = []), 1 === a.myself && (d = !0), 
        1 == a.isJuveniles && e.push(a);
    }), !0 === t.data.isAddChild && (a = e), t.setData({
        isHasSelf: d,
        allContactsArr: a
    });
}

Page({
    data: {
        allContactsArr: [],
        surebtnStr: "确认添加",
        seletDataArr: [],
        allAddChildArr: [],
        maxCount: 3,
        isAddChild: !1,
        leaderContactId: "",
        addIndex: 999,
        isHasSelf: !1,
        isExhibitionChoose: !1
    },
    onLoad: function(t) {
        var a = JSON.parse(t.data);
        this.setData({
            maxCount: a.maxCount,
            seletDataArr: a.seletDataArr,
            allAddChildArr: a.allAddChildArr,
            isAddChild: a.isAddChild,
            leaderContactId: a.leaderContactId,
            addIndex: a.addIndex,
            isExhibitionChoose: a.isExhibitionChoose
        }), d(this, !1);
    },
    addContactsBtnClick: function(t) {
        if (this.data.allContactsArr.length >= e.contactsMaxCount) wx.showToast({
            title: "联系人已达上限",
            icon: "none"
        }); else {
            var a = {
                isTeamAppoint: !1
            };
            a.isHasSelf = this.data.isHasSelf, a.isAdd = !0, a.isAddChild = this.data.isAddChild;
            var d = JSON.stringify(a);
            wx.navigateTo({
                url: "addContact?data=" + d
            });
        }
    },
    contactsClick: function(t) {
        var a = this, e = parseInt(t.currentTarget.dataset.index), d = this.data.allContactsArr, i = this.data.seletDataArr, n = d[e];
        if (1 != n.childSeleted || n.leaderContactId == this.data.leaderContactId) if (0 == n.seleted && i.length >= this.data.maxCount) {
            var s = "最多只能添加" + this.data.maxCount + "人！";
            wx.showToast({
                title: s,
                icon: "none",
                duration: 2e3
            });
        } else {
            var o = [];
            d.forEach(function(t, d) {
                e == d && (t.seleted = !t.seleted), 1 == t.seleted && ("RLY0101" != t.documentType && 1 == a.data.isExhibitionChoose ? (t.seleted = !1, 
                wx.showToast({
                    title: "仅支持使用身份证号预约",
                    icon: "none",
                    duration: 2e3
                })) : (1 == a.data.isAddChild && (t.leaderContactId = a.data.leaderContactId), o.push(t)));
            });
            var l = "确认添加";
            o.length > 0 && (l = "确认添加(" + o.length + ")人"), this.setData({
                allContactsArr: d,
                seletDataArr: o,
                surebtnStr: l
            });
        } else wx.showToast({
            title: "已被添加为携带儿童",
            icon: "none",
            duration: 2e3
        });
    },
    appointBtnClick: function(t) {
        var a = getCurrentPages(), e = a[a.length - 2];
        !0 === this.data.isAddChild ? (e.setData({
            addChildArr: this.data.seletDataArr,
            isAddChild: this.data.isAddChild,
            addIndex: this.data.addIndex
        }), wx.navigateBack({
            delta: 1,
            success: function() {
                e.addChildRefreshData();
            }
        })) : (e.setData({
            selectedContactsArr: this.data.seletDataArr
        }), wx.navigateBack({
            delta: 1
        }));
    },
    reloadContactsData: function() {
        d(this, !0);
    }
});