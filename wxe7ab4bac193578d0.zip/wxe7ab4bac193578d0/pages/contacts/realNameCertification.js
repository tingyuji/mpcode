var t = require("../../server/api"), a = require("../../server/static"), e = require("../../utils/validata.js");

Page({
    data: {
        cardtypeArr: [],
        cardTypeStr: "",
        cardTypeIdStr: "",
        nameStr: "",
        cardNumStr: "",
        pageUrl: "",
        xieyiSeleced: !1
    },
    onLoad: function(t) {
        "0" == t.pageUrl && this.setData({
            pageUrl: "../appointment/home?isTeamAppoint=false"
        }), this.setData({
            cardtypeArr: a.cardTypeArr,
            cardTypeStr: a.cardTypeArr[0].text,
            cardTypeIdStr: a.cardTypeArr[0].id
        });
    },
    autoRefreshData: function(t) {
        this.setData({
            xieyiSeleced: !0
        });
    },
    onShow: function() {},
    xieyiViewClick: function(t) {
        wx.navigateTo({
            url: "../contacts/yingsiAgreement"
        });
    },
    userNameInput: function(t) {
        this.setData({
            nameStr: t.detail.value
        });
    },
    cardNumInput: function(t) {
        this.setData({
            cardNumStr: t.detail.value
        });
    },
    cardTypePickerChange: function(t) {
        console.log(t.detail.value);
        var a = t.detail.value;
        this.setData({
            cardTypeStr: this.data.cardtypeArr[a].text,
            cardTypeIdStr: this.data.cardtypeArr[a].id
        });
    },
    surebtnClick: function(a) {
        var r = this.data.nameStr.replace(/\s+/g, ""), i = this.data.cardNumStr.replace(/\s+/g, "");
        this.setData({
            nameStr: r,
            cardNumStr: i
        });
        var n = this;
        if (this.data.nameStr.length <= 0) wx.showToast({
            title: "请输入与证件一致的姓名",
            icon: "none"
        }); else if (this.data.cardTypeIdStr.length <= 0) wx.showToast({
            title: "请选择证件类型",
            icon: "none"
        }); else if (this.data.cardNumStr.length < 5) wx.showToast({
            title: "请填写本人正确的证件号码",
            icon: "none"
        }); else if (0 == this.data.xieyiSeleced) wx.showToast({
            title: "请先阅读并同意隐私协议",
            icon: "none"
        }); else {
            if (console.log(this.data.cardTypeStr), "中国居民身份证" == this.data.cardTypeStr) {
                var s = this.data.cardNumStr;
                if (!e.checkIdCardNo(s)) return void wx.showToast({
                    title: "证件号码输入有误",
                    icon: "none"
                });
            }
            wx.showLoading({
                title: "请稍等...",
                mask: !0
            }), (0, t.saveCert)(this.data.nameStr, this.data.cardTypeIdStr, this.data.cardNumStr).then(function(t) {
                wx.hideLoading(), 200 == t.code && null != t.data ? (console.log("实名认证成功，保存本地缓存"), 
                wx.setStorage({
                    key: getApp().globalData.openId + "_realName",
                    data: JSON.stringify(t.data)
                }), getApp().globalData.userInfo = t.data, wx.showToast({
                    title: "添加成功",
                    complete: function() {
                        if ("" != n.data.pageUrl) wx.redirectTo({
                            url: n.data.pageUrl
                        }); else {
                            var t = getCurrentPages(), a = t[t.length - 2];
                            wx.navigateBack({
                                success: function() {
                                    a.reloadContactsData();
                                }
                            });
                        }
                    }
                })) : wx.showToast({
                    title: t.msg,
                    icon: "none"
                });
            }).catch(function(t) {
                wx.hideLoading(), console.error("实名认证失败" + t);
            });
        }
    }
});