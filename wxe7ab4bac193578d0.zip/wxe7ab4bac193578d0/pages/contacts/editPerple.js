var t = require("../../server/api.js"), e = t.queryContactByIdData, a = t.updateCustomerContact, i = (t.getDocumentTypeList, 
require("../../server/static.js").cardTypeArr), n = require("../../utils/validata.js");

function r(t, a) {
    e(a).then(function(e) {
        if (200 == e.code) {
            var a = t.data.cardtypeArr, i = e.data, n = "";
            a.forEach(function(t, e) {
                t.id == i.documentType && (n = t.text);
            }), t.setData({
                isEdite: !0,
                isHiddleUserBtn: !0,
                customerContactId: i.customerContactId,
                nameStr: i.contactName,
                phoneStr: i.contactPhone,
                cardNumStr: i.documentNumber,
                cardTypeStr: n,
                cardTypeIdStr: i.documentType,
                isVip: i.isPartyMember
            });
        } else wx.showToast({
            title: e.msg,
            icon: "none"
        });
    });
}

Page({
    data: {
        cardtypeArr: [],
        cardtypeNameArr: [],
        cardTypeStr: "",
        countryTypeStr: "",
        countryTypeIdStr: "",
        countryTypeArr: [],
        cardTypeIdStr: "",
        nameStr: "",
        phoneStr: "",
        cardNumStr: "",
        isEdite: !1,
        visitorContactId: "",
        isUserState: !1,
        isHiddleUserBtn: !1,
        isVip: 0,
        xieyiSeleced: !1,
        isHasSelf: !1,
        model: {}
    },
    onLoad: function(t) {
        console.log(JSON.parse(t.data));
        var e = JSON.parse(t.data);
        this.setData({
            model: e,
            countryTypeStr: e.countryTypeStr,
            countryTypeIdStr: e.countryTypeIdStr,
            cardtypeArr: i
        }), r(this, this.data.model.customerContactId);
    },
    autoRefreshData: function(t) {
        this.setData({
            xieyiSeleced: !0
        });
    },
    radioLabChange: function(t) {
        var e = t.currentTarget.dataset.id;
        console.log(e), this.setData({
            isVip: e
        });
    },
    xieyiViewClick: function(t) {
        wx.navigateTo({
            url: "../contacts/yingsiAgreement"
        });
    },
    cancleBtnClick: function(t) {
        wx.navigateBack({});
    },
    chooseTureImgClick: function(t) {
        console.log("点击了本人按钮");
        var e = this.data.isUserState;
        e = 1 != e, this.setData({
            isUserState: e
        });
    },
    chooseFalseImgClick: function(t) {
        console.log("点击了本人按钮");
        var e = this.data.isUserState;
        e = 1 != e, this.setData({
            isUserState: e
        });
    },
    userNameInput: function(t) {
        this.setData({
            nameStr: t.detail.value
        });
    },
    phoneNumInput: function(t) {
        this.setData({
            phoneStr: t.detail.value
        });
    },
    cardNumInput: function(t) {
        this.setData({
            cardNumStr: t.detail.value
        });
    },
    cardTypePickerChange: function(t) {
        console.log(t.detail.value);
        var e = this.data.cardtypeArr[t.detail.value].text, a = this.data.cardtypeArr[t.detail.value].id;
        this.setData({
            cardTypeStr: e,
            cardTypeIdStr: a
        });
    },
    countryTypePickerChange: function(t) {
        var e = t.detail.value;
        this.setData({
            countryTypeStr: this.data.countryTypeArr[e].text,
            countryTypeIdStr: this.data.countryTypeArr[e].id
        });
    },
    canclebtnClick: function(t) {
        wx.navigateBack({});
    },
    sureBtnClick: function(t) {
        var e = this.data.phoneStr.replace(/\s+/g, ""), i = "";
        for (var r in e) 8236 != e[r].charCodeAt() && 8237 != e[r].charCodeAt() && (i += e[r]);
        if (this.setData({
            phoneStr: i
        }), console.log(this.data.phoneStr.length), this.data.nameStr.length <= 0) wx.showToast({
            title: "请输入与证件一致的姓名",
            icon: "none"
        }); else if ("" == this.data.phoneStr) wx.showToast({
            title: "请先输入手机号码",
            icon: "none"
        }); else if (/^1[3456789]\d{9}$/.test(this.data.phoneStr)) if (this.data.cardTypeIdStr.length <= 0) wx.showToast({
            title: "请选择证件类型",
            icon: "none"
        }); else if (this.data.cardNumStr.length < 5) wx.showToast({
            title: "请填写正确的证件号码",
            icon: "none"
        }); else if (0 == this.data.xieyiSeleced) wx.showToast({
            title: "请先阅读并同意隐私协议",
            icon: "none"
        }); else {
            if (console.log(this.data.cardTypeStr), "中国居民身份证" == this.data.cardTypeStr) {
                var o = this.data.cardNumStr;
                if (!n.checkIdCardNo(o)) return void wx.showToast({
                    title: "证件号码输入有误",
                    icon: "none"
                });
            }
            1 == this.data.isEdite && a(this.data.customerContactId, this.data.nameStr, this.data.phoneStr, this.data.cardTypeIdStr, this.data.countryTypeIdStr, this.data.cardNumStr, this.data.isVip, 0).then(function(t) {
                if (200 == t.code) {
                    var e = getCurrentPages(), a = e[e.length - 2];
                    wx.navigateBack({
                        success: function() {
                            a.reloadContactsData();
                        }
                    }), wx.showToast({
                        title: "修改成功",
                        icon: "none"
                    });
                } else wx.showToast({
                    title: t.msg,
                    icon: "none"
                });
            }).catch(function(t) {
                console.error("添加联系人失败" + t);
            });
        } else wx.showToast({
            title: "请输入正确的手机号",
            icon: "none"
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {}
});