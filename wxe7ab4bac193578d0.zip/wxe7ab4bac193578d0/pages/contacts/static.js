Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.contactsMaxCount = void 0;

exports.contactsMaxCount = 10;