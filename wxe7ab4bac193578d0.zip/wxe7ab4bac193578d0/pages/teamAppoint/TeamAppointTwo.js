var t = require("../../server/api");

function e(e, a) {
    (0, t.queryTeamDetail)(a).then(function(t) {
        if (200 == t.code) {
            var a = t.data;
            if (-1 == e.data.model.status) {
                var o = a[0].expireTime, n = e.data.model;
                n.expireTime = o, e.setData({
                    model: n
                }), e.countDown();
            }
            e.setData({
                selectedContactsArr: a,
                maxCount: a.length
            });
        } else wx.showToast({
            title: t.msg,
            icon: "none"
        });
    }).catch(function(t) {
        console.error("获取联系人失败" + t);
    }), (0, t.queryTeamReserveRule)(getApp().globalData.systemId, getApp().globalData.companyInfoId).then(function(t) {
        200 == t.code ? (getApp().globalData.ruleData = t.data, e.setData({
            ruleData: t.data
        })) : wx.showToast({
            title: t.msg,
            icon: "none"
        });
    });
}

Page({
    data: {
        model: {},
        selectedContactsArr: [],
        maxCount: 3,
        MuseumName: "",
        ruleData: {},
        orderStatusStr: ""
    },
    onLoad: function(t) {
        this.setData({
            model: JSON.parse(t.data),
            ruleData: getApp().globalData.ruleData
        }), 0 == this.data.model.status && (this.countDown(), getApp().globalData.companyInfoId = this.data.model.companyInfoId), 
        e(this, this.data.model.teamShareCode);
    },
    onReady: function() {},
    onShow: function() {},
    reloadContactsData: function() {
        wx.showToast({
            title: "添加成功",
            icon: "success"
        }), e(this, this.data.model.teamShareCode);
    },
    deleteBtnClick: function(a) {
        console.log("删除按钮点击" + JSON.stringify(a.target.dataset.value));
        var o = a.target.dataset.value, n = this.data.selectedContactsArr[o], i = this;
        (0, t.deleteTeamMember)(this.data.model.teamShareCode, n.detailId).then(function(t) {
            200 == t.code ? (wx.showToast({
                title: "删除成功",
                icon: "none"
            }), e(i, i.data.model.teamShareCode)) : wx.showToast({
                title: t.msg,
                icon: "none"
            });
        }).catch(function(t) {
            console.error("删除人失败" + t);
        });
    },
    editBtnClick: function(t) {
        console.log("删除按钮点击" + JSON.stringify(t.target.dataset.value));
        var e = t.target.dataset.value, a = this.data.selectedContactsArr[e], o = {
            isTeamAppoint: !0,
            isHasSelf: !0,
            isAdd: !1,
            isEdit: !0
        };
        o.systemId = this.data.model.systemId, o.teamShareCode = this.data.model.teamShareCode, 
        o.nameStr = a.visitorName, o.isVip = a.isVip, o.phoneStr = a.phoneNumber, o.cardNumStr = a.documentNumber, 
        o.detailId = a.detailId, o.cardTypeStr = a.documentTypeName, o.documentType = a.documentType, 
        o.countryTypeStr = a.countryName, o.countryTypeIdStr = a.country;
        var n = JSON.stringify(o);
        wx.navigateTo({
            url: "../contacts/addContact?data=" + n
        });
    },
    addContact: function(t) {
        if (this.data.selectedContactsArr.length >= this.data.model.orderNum) wx.showToast({
            title: "团队成员已达上限",
            icon: "none"
        }); else {
            var e = {
                isTeamAppoint: !0,
                isHasSelf: !0,
                isAdd: !0,
                isEdit: !1
            };
            e.systemId = this.data.model.systemId, e.teamShareCode = this.data.model.teamShareCode;
            var a = JSON.stringify(e);
            wx.navigateTo({
                url: "../contacts/addContact?data=" + a
            });
        }
    },
    daoruBtnClick: function(t) {
        var e = this.data.model.orderNum - this.data.selectedContactsArr.length, a = {};
        a.maxCount = e, a.companyInfoId = this.data.model.companyInfoId, a.shareCode = this.data.model.teamShareCode;
        var o = JSON.stringify(a);
        wx.navigateTo({
            url: "piLiangDaoru?data=" + o
        });
    },
    appointBtnClick: function(e) {
        var a = this;
        if (this.data.selectedContactsArr.length < this.data.ruleData.minTeamCount || this.data.selectedContactsArr.length > this.data.ruleData.maxTeamCount) {
            var o = "团队成员数量需在" + this.data.ruleData.minTeamCount + "~" + this.data.ruleData.maxTeamCount + "人之间";
            wx.showToast({
                title: o,
                icon: "none"
            });
        } else wx.showLoading({
            title: "加载中"
        }), (0, t.submitTeam)(this.data.model.teamShareCode, getApp().globalData.systemId).then(function(t) {
            if (200 == t.code) {
                wx.hideLoading(), wx.showToast({
                    title: "预约成功",
                    icon: "none"
                });
                var e = {}, o = t.data;
                e.teamName = o.teamName, e.visitorName = o.visitorName, e.companyName = o.companyName, 
                e.documentNumber = o.documentNumber, e.phoneNumber = o.phoneNumber, e.visitorNum = a.data.selectedContactsArr.length, 
                e.visitTime = o.reserveDate + " " + o.reserveTime, e.shareCode = o.shareCode;
                var n = JSON.stringify(e);
                wx.navigateTo({
                    url: "teamAppointSucc?data=" + n
                });
            } else wx.hideLoading(), wx.showToast({
                title: t.msg,
                icon: "none"
            });
        });
    },
    appointEndorseBtnClick: function(e) {
        var a = this;
        wx.showModal({
            title: "提示",
            content: "确定解散团队吗？",
            showCancel: !0,
            success: function(e) {
                e.confirm && (0, t.dissolveTeam)(a.data.model.teamShareCode).then(function(t) {
                    200 == t.code ? (wx.showToast({
                        title: "解散成功",
                        icon: "none"
                    }), wx.redirectTo({
                        url: "../teamAppoint/TeamAppointOrderDetail?shareCode=" + a.data.model.teamShareCode
                    })) : wx.showToast({
                        title: t.msg,
                        icon: "none"
                    });
                });
            }
        });
    },
    onHide: function() {},
    onUnload: function() {
        clearInterval(this.countDown);
    },
    timeFormat: function(t) {
        return t < 10 ? "0" + t : t;
    },
    countDown: function() {
        var t, e = new Date().getTime(), a = this.data.model.expireTime.replace(/-/g, "/"), o = new Date(a).getTime(), n = null;
        if (o - e > 0) {
            var i = (o - e) / 1e3, s = parseInt(i / 86400), d = parseInt(i % 86400 / 3600), r = parseInt(i % 86400 % 3600 / 60), m = parseInt(i % 86400 % 3600 % 60);
            n = {
                day: this.timeFormat(s),
                hou: this.timeFormat(d),
                min: this.timeFormat(r),
                sec: this.timeFormat(m)
            };
        } else n = {
            day: "00",
            hou: "00",
            min: "00",
            sec: "00"
        };
        0 == (t = n).hou ? this.setData({
            orderStatusStr: +t.min + "分" + t.sec + "秒"
        }) : this.setData({
            orderStatusStr: +t.hou + "小时" + t.min + "分" + t.sec + "秒"
        }), setTimeout(this.countDown, 1e3);
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    shareViewBtnClick: function() {
        wx.navigateTo({
            url: "ShareTeamAppoint?teamShareCode=" + this.data.model.teamShareCode
        });
    },
    onShareAppMessage: function() {
        return {
            title: "团队预约",
            path: "pages/teamAppoint/ShareTeamAppoint?teamShareCode=" + this.data.model.teamShareCode
        };
    }
});