var e = require("../../@babel/runtime/helpers/interopRequireWildcard").default, a = require("../../server/api"), t = require("../../server/http"), i = e(require("../../utils/tokenUtil"));

require("../../utils/validata.js");

Page({
    data: {
        jigouTypeArr: [],
        jigouTypeStr: "",
        jigouTypeIdStr: "",
        jigouTypeDict: {},
        jigouNameStr: "",
        jigouIdStr: "",
        farenNameStr: "",
        farenIdStr: "",
        qiyeNameStr: "",
        qiyeIdStr: "",
        jigouImg: "../../images/sendImage.png",
        yewuImg: "../../images/sendImage.png",
        farenCardImg1: "../../images/sendImage.png",
        farenCardImg2: "../../images/sendImage.png",
        lianxirenCardImg1: "../../images/sendImage.png",
        lianxirenCardImg2: "../../images/sendImage.png",
        renzhenImg: "../../images/sendImage.png",
        ziliaoType: 1,
        isHiddenCardType: !1
    },
    onLoad: function(e) {
        var t;
        t = this, wx.showLoading({
            title: "加载中...",
            mask: !0
        }), (0, a.getAgencyTypeList)().then(function(e) {
            wx.hideLoading(), 200 === e.code && t.setData({
                jigouTypeArr: e.data
            });
        });
    },
    onReady: function() {},
    onShow: function() {},
    ziliaoTypeViewClick: function(e) {
        console.log(e);
        var a = e.currentTarget.dataset.index;
        1 == a ? this.setData({
            ziliaoType: 1
        }) : 2 == a && this.setData({
            ziliaoType: 2
        });
    },
    inputClick: function(e) {
        console.log(e.target.dataset.index);
        var a = e.target.dataset.index;
        1 == a ? this.setData({
            jigouNameStr: e.detail.value
        }) : 2 == a ? this.setData({
            jigouIdStr: e.detail.value
        }) : 3 == a ? this.setData({
            farenNameStr: e.detail.value
        }) : 4 == a ? this.setData({
            farenIdStr: e.detail.value
        }) : 5 == a ? this.setData({
            qiyeNameStr: e.detail.value
        }) : 6 == a && this.setData({
            qiyeIdStr: e.detail.value
        });
    },
    jigouTypePickerChange: function(e) {
        console.log(e.detail.value);
        var a = e.detail.value;
        this.setData({
            jigouTypeDict: this.data.jigouTypeArr[a],
            jigouTypeStr: this.data.jigouTypeArr[a].text,
            jigouTypeIdStr: this.data.jigouTypeArr[a].id
        }), "其他" == this.data.jigouTypeStr ? this.setData({
            isHiddenCardType: !1,
            ziliaoType: 1
        }) : this.setData({
            isHiddenCardType: !0,
            ziliaoType: 1
        });
    },
    xiazaiTishiViewClick: function(e) {
        wx.setClipboardData({
            data: t.api.fileSec + "18905b1ea600401c945a99734f828076/介绍信.docx",
            success: function(e) {
                wx.getClipboardData({
                    success: function(e) {
                        wx.showModal({
                            title: "提示",
                            content: "已复制下载链接",
                            showCancel: !1,
                            success: function(e) {
                                e.confirm;
                            }
                        });
                    }
                });
            }
        });
    },
    appointBtnClick: function(e) {
        if (this.data.jigouTypeStr.length <= 0) wx.showToast({
            title: "请选择机构类型",
            icon: "none"
        }); else if (this.data.jigouNameStr.length <= 0) wx.showToast({
            title: "请输入机构名称",
            icon: "none"
        }); else if (this.data.jigouIdStr.length <= 0) "机关部委" == this.data.jigouTypeStr ? wx.showToast({
            title: "请输入组织机构代码",
            icon: "none"
        }) : wx.showToast({
            title: "请输入统一社会信用代码",
            icon: "none"
        }); else if ("../../images/sendImage.png" == this.data.jigouImg && "旅行社" == this.data.jigouTypeStr) wx.showToast({
            title: "请上传机构营业执照",
            icon: "none"
        }); else if ("../../images/sendImage.png" == this.data.renzhenImg && "旅行社" != this.data.jigouTypeStr) wx.showToast({
            title: "请上传介绍信",
            icon: "none"
        }); else {
            var t = this.data.renzhenImg;
            "../../images/sendImage.png" == t && (t = "");
            var i = this.data.lianxirenCardImg1;
            "../../images/sendImage.png" == i && (i = "");
            var n = this.data.lianxirenCardImg2;
            "../../images/sendImage.png" == n && (n = ""), (0, a.submitOrganizationCertification)(getApp().globalData.systemId, this.data.jigouTypeIdStr, this.data.jigouNameStr, this.data.jigouIdStr, this.data.jigouImg, this.data.qiyeNameStr, this.data.qiyeIdStr, i, n, t, this.data.ziliaoType).then(function(e) {
                200 == e.code ? wx.showModal({
                    title: "提示",
                    content: "提交成功",
                    showCancel: !1,
                    success: function(e) {
                        e.confirm && wx.navigateBack({});
                    }
                }) : wx.showToast({
                    title: e.msg,
                    icon: "none"
                });
            });
        }
    },
    cellImgClick: function(e) {
        console.log(e.target.dataset.index);
        var n = e.target.dataset.index, o = this;
        wx.chooseMedia({
            count: 1,
            mediaType: [ "image" ],
            sourceType: [ "album", "camera" ],
            camera: "back",
            success: function(e) {
                console.log(e);
                var s = e.tempFiles[0].tempFilePath;
                console.log("件路径列表" + s), wx.uploadFile({
                    filePath: s,
                    name: "trackData",
                    header: {
                        appId: i.appId,
                        token: (0, i.default)(),
                        systemId: getApp().globalData.systemId,
                        "Content-Type": "multipart/form-data"
                    },
                    formData: {
                        code: "TRM_COMPANY_PHOTO"
                    },
                    url: t.api.file + "file/normalUploadByCode/TRM_COMPANY_PHOTO/FKYY/" + getApp().globalData.systemId,
                    success: function(e) {
                        if (413 != e.statusCode && null != e.data) {
                            var i = JSON.parse(e.data);
                            200 == i.code ? (console.log("上传成功", i.data.filePath + i.data.fileName), s = t.api.fileSec + i.data.filePath + i.data.fileName, 
                            1 == n ? o.setData({
                                jigouImg: s
                            }) : 2 == n ? o.setData({
                                yewuImg: s
                            }) : 3 == n ? o.setData({
                                farenCardImg1: s
                            }) : 4 == n ? o.setData({
                                farenCardImg2: s
                            }) : 5 == n ? o.setData({
                                lianxirenCardImg1: s
                            }) : 6 == n ? o.setData({
                                lianxirenCardImg2: s
                            }) : 7 == n && o.setData({
                                renzhenImg: s
                            })) : (0, a.showWarningToast)(e, "上传失败");
                        } else wx.showToast({
                            title: "请上传小于1M的图片",
                            icon: "none"
                        });
                    },
                    fail: function(e) {
                        console.error("上传失败", e);
                    }
                });
            }
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});