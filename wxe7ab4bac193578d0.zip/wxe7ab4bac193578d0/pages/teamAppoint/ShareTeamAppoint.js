var t = require("../../server/api"), e = require("../../server/static"), a = require("../../utils/validata.js");

Page({
    data: {
        cardtypeArr: [],
        cardTypeStr: "",
        cardTypeIdStr: "",
        countryTypeStr: "",
        countryTypeIdStr: "",
        countryTypeArr: [],
        nameStr: "",
        phoneStr: "",
        cardNumStr: "",
        visitorContactId: "",
        param: {},
        shareCode: {}
    },
    onLoad: function(a) {
        var r, n;
        this.setData({
            shareCode: a.teamShareCode
        }), r = this, n = a.teamShareCode, (0, t.queryTeamInfo)(n).then(function(t) {
            if (200 == t.code) {
                var e = t.data;
                r.setData({
                    param: e
                });
            } else wx.showToast({
                title: t.msg,
                icon: "none"
            });
        }).catch(function(t) {
            console.error("获取联系人失败" + t);
        }), this.setData({
            cardTypeStr: e.cardTypeArr[0].text,
            cardTypeIdStr: e.cardTypeArr[0].id,
            cardtypeArr: e.cardTypeArr
        });
    },
    onReady: function() {},
    onShow: function() {},
    userNameInput: function(t) {
        this.setData({
            nameStr: t.detail.value
        });
    },
    phoneNumInput: function(t) {
        this.setData({
            phoneStr: t.detail.value
        });
    },
    cardNumInput: function(t) {
        this.setData({
            cardNumStr: t.detail.value
        });
    },
    cardTypePickerChange: function(t) {
        console.log(t.detail.value);
        var e = t.detail.value;
        this.setData({
            cardTypeStr: this.data.cardtypeArr[e].text,
            cardTypeIdStr: this.data.cardtypeArr[e].id
        });
    },
    countryTypePickerChange: function(t) {
        var e = t.detail.value;
        this.setData({
            countryTypeStr: this.data.countryTypeArr[e].text,
            countryTypeIdStr: this.data.countryTypeArr[e].id
        });
    },
    sureBtnClick: function(e) {
        var r = this.data.nameStr.replace(/\s+/g, ""), n = this.data.phoneStr.replace(/\s+/g, ""), o = this.data.cardNumStr.replace(/\s+/g, "");
        if (this.setData({
            nameStr: r,
            phoneStr: n,
            cardNumStr: o
        }), "" === this.data.nameStr) wx.showToast({
            title: "请输入与证件一致的姓名",
            icon: "none"
        }); else if ("" === this.data.phoneStr) wx.showToast({
            title: "请输入手机号码",
            icon: "none"
        }); else if (/^1[3456789]\d{9}$/.test(this.data.phoneStr)) if (this.data.cardTypeIdStr.length <= 0) wx.showToast({
            title: "请选择证件类型",
            icon: "none"
        }); else if (this.data.cardNumStr.length < 5) wx.showToast({
            title: "请填写正确的证件号码",
            icon: "none"
        }); else {
            if ("中国居民身份证" == this.data.cardTypeStr) {
                var i = this.data.cardNumStr;
                if (!a.checkIdCardNo(i)) return void wx.showToast({
                    title: "证件号码输入有误",
                    icon: "none"
                });
            }
            (0, t.addTeamMember)(this.data.shareCode, this.data.nameStr, this.data.phoneStr, this.data.cardTypeIdStr, this.data.countryTypeIdStr, this.data.cardNumStr, getApp().globalData.systemId).then(function(t) {
                200 == t.code ? (wx.redirectTo({
                    url: "../index/index"
                }), wx.showToast({
                    title: "添加成功",
                    icon: "none"
                })) : wx.showToast({
                    title: t.msg,
                    icon: "none"
                });
            }).catch(function(t) {
                console.error("添加联系人失败" + t);
            });
        } else wx.showToast({
            title: "请输入正确的手机号",
            icon: "none"
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});