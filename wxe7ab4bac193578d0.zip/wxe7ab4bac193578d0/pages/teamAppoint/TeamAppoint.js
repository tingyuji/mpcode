var e = require("../../server/api"), a = require("../../utils/validata.js");

Page({
    data: {
        model: {},
        selectedContactsArr: [],
        maxCount: 3,
        isHasSelf: !1,
        teamName: "",
        userModel: {},
        userName: "",
        ruleData: {},
        teamType: 0,
        teamTypeArr: [],
        teamTypeStr: "",
        hiddenTishi: !0
    },
    onLoad: function(e) {
        this.setData({
            model: JSON.parse(e.data)
        });
    },
    teamTypePickerChange: function(e) {
        console.log(e.detail.value);
        var a = e.detail.value;
        this.setData({
            teamTypeStr: this.data.teamTypeArr[a].text,
            teamType: this.data.teamTypeArr[a].id
        }), "中小学生" == this.data.teamTypeArr[a].text ? this.setData({
            hiddenTishi: !1
        }) : this.setData({
            hiddenTishi: !0
        });
    },
    onReady: function() {},
    onShow: function() {
        var a;
        if (a = this, wx.showLoading({
            title: "加载中...",
            mask: !0
        }), (0, e.queryCertList)().then(function(e) {
            var t;
            wx.hideLoading(), 200 === e.code && null != e.data && e.data.length > 0 && (getApp().globalData.userInfo = e.data[0], 
            (t = e.data[0]).documentNumber = t.showDocumentNumber, 1 == a.data.model.isTeamReserveAgain ? ((t = {}).documentNumber = a.data.model.documentNumber, 
            t.customerName = a.data.model.customerName, t.phoneNumber = a.data.model.phoneNumber, 
            a.setData({
                userModel: t,
                userName: t.customerName
            })) : a.setData({
                userModel: e.data[0],
                userName: null == e.data[0].customerName ? "" : e.data[0].customerName
            }));
        }), (0, e.queryTeamReserveRule)(getApp().globalData.systemId, getApp().globalData.companyInfoId).then(function(e) {
            200 == e.code ? (getApp().globalData.ruleData = e.data, a.setData({
                ruleData: e.data
            })) : wx.showToast({
                title: e.msg,
                icon: "none"
            });
        }), (0, e.getTeamTypeListData)().then(function(e) {
            if (200 == e.code) {
                if (1 == a.data.model.isTeamReserveAgain) {
                    var t = a.data.model;
                    e.data.forEach(function(e) {
                        e.id == t.type && a.setData({
                            teamTypeStr: e.text
                        });
                    });
                }
                a.setData({
                    teamTypeArr: e.data
                });
            } else wx.showToast({
                title: e.msg,
                icon: "none"
            });
        }), 1 == this.data.model.isTeamReserveAgain) {
            var t = this.data.model;
            this.setData({
                teamType: t.type,
                teamTypeStr: t.typeStr
            });
        }
    },
    teamNameInput: function(e) {
        var a = this.data.model;
        a.teamName = e.detail.value, this.setData({
            model: a
        });
    },
    customerNameInput: function(e) {
        var a = this.data.userModel;
        console.log("团队姓名输入" + e.detail.value), a.customerName = e.detail.value, this.setData({
            userModel: a
        });
    },
    documentNumberInput: function(e) {
        var a = this.data.userModel;
        a.documentNumber = e.detail.value, this.setData({
            userModel: a
        });
    },
    phoneNumberInput: function(e) {
        var a = this.data.userModel;
        a.phoneNumber = e.detail.value, this.setData({
            userModel: a
        });
    },
    teamNumberInput: function(e) {
        var a;
        e.detail.value;
        if (!/(^[1-9]\d*$)/.test(e.detail.value)) return wx.showToast({
            title: "团队人数应为正整数",
            icon: "none"
        }), (a = this.data.model).teamNumber = "", void this.setData({
            model: a
        });
        (a = this.data.model).teamNumber = e.detail.value, this.setData({
            model: a
        });
    },
    appointBtnClick: function(t) {
        var o = this;
        if (null == this.data.teamTypeStr || "" == this.data.teamTypeStr) wx.showToast({
            title: "请选择团队类型",
            icon: "none"
        }); else if (null == this.data.model.teamName || "" == this.data.model.teamName) wx.showToast({
            title: "请输入团队名称",
            icon: "none"
        }); else if ("" === this.data.userModel.customerName) wx.showToast({
            title: "请填写领队姓名",
            icon: "none"
        }); else if ("" === this.data.userModel.documentNumber) wx.showToast({
            title: "请填写正确的证件号码",
            icon: "none"
        }); else if (a.checkIdCardNo(this.data.userModel.documentNumber)) if ("" === this.data.userModel.phoneNumber) wx.showToast({
            title: "请输入手机号码",
            icon: "none"
        }); else if (/^1[3456789]\d{9}$/.test(this.data.userModel.phoneNumber)) if (null == this.data.model.teamNumber || "" == this.data.model.teamNumber) wx.showToast({
            title: "请输入团队人数",
            icon: "none"
        }); else if (/(^[1-9]\d*$)/.test(this.data.model.teamNumber)) if (parseInt(this.data.model.teamNumber) < parseInt(this.data.ruleData.minTeamCount) || parseInt(this.data.model.teamNumber) > parseInt(this.data.ruleData.maxTeamCount)) console.log(this.data.model.teamNumber + "," + this.data.ruleData.minTeamCount + "," + this.data.ruleData.maxTeamCount), 
        wx.showToast({
            title: "团队人数不在规定人数范围内",
            icon: "none"
        }); else if (null == this.data.userModel.customerName || "" == this.data.userModel.customerName || null == this.data.userModel.documentNumber || "" == this.data.userModel.documentNumber || null == this.data.userModel.phoneNumber || "" == this.data.userModel.phoneNumber) wx.showToast({
            title: "请检查团队信息",
            icon: "none"
        }); else {
            var d = this;
            wx.showLoading({
                title: "加载中..."
            }), 1 == this.data.model.isTeamReserveAgain ? (0, e.teamAppointReserveAgain)(this.data.model.intervalDate, this.data.model.intervalValue, getApp().globalData.companyInfoId, this.data.model.MuseumName, getApp().globalData.systemId, this.data.model.teamShareCode, d.data.model.teamName, d.data.teamType, parseInt(d.data.model.teamNumber), d.data.userModel.customerName, d.data.userModel.phoneNumber, d.data.userModel.documentNumber).then(function(e) {
                if (200 == e.code) {
                    var a = o.data.model;
                    a.teamName = o.data.model.teamName, a.teamType = o.data.teamName, a.teamTypeStr = o.data.teamTypeStr, 
                    a.orderNum = o.data.model.teamNumber, a.customerName = o.data.userModel.customerName, 
                    a.documentNumber = o.data.userModel.documentNumber, a.phoneNumber = o.data.userModel.phoneNumber, 
                    a.teamShareCode = e.data, a.isTeamReserveAgain = !0, a.status = -1;
                    var t = JSON.stringify(a), s = "创建成功，请尽快填写团员信息，并提交预约，如未提交，系统将于" + d.data.ruleData.retainDays + "分钟后自动解散团队";
                    wx.hideLoading(), wx.showModal({
                        title: "提示",
                        content: s,
                        cancelColor: "",
                        showCancel: !1,
                        success: function(e) {
                            e.confirm && wx.redirectTo({
                                url: "TeamAppointTwo?data=" + t
                            });
                        }
                    });
                } else wx.hideLoading(), wx.showToast({
                    title: e.msg,
                    icon: "none"
                });
            }) : (0, e.createTeam)(d.data.model.intervalDate, d.data.model.intervalValue, d.data.userModel.customerId, d.data.userModel.customerName, d.data.userModel.phoneNumber, d.data.userModel.documentNumber, getApp().globalData.companyInfoId, getApp().globalData.MuseumName, d.data.model.teamName, getApp().globalData.systemId, d.data.teamType, d.data.model.teamNumber).then(function(e) {
                if (200 == e.code) {
                    var a = o.data.model;
                    a.teamName = o.data.model.teamName, a.teamType = o.data.teamName, a.teamTypeStr = o.data.teamTypeStr, 
                    a.orderNum = o.data.model.teamNumber, a.customerName = o.data.userModel.customerName, 
                    a.documentNumber = o.data.userModel.documentNumber, a.phoneNumber = o.data.userModel.phoneNumber, 
                    a.teamShareCode = e.data, a.isTeamReserveAgain = !1, a.status = -1;
                    var t = JSON.stringify(a), s = "创建成功，请尽快填写团员信息，并提交预约，如未提交，系统将于" + d.data.ruleData.retainDays + "分钟后自动解散团队";
                    wx.hideLoading(), wx.showModal({
                        title: "提示",
                        content: s,
                        cancelColor: "",
                        showCancel: !1,
                        success: function(e) {
                            e.confirm && wx.redirectTo({
                                url: "TeamAppointTwo?data=" + t
                            });
                        }
                    });
                } else wx.hideLoading(), wx.showToast({
                    title: e.msg,
                    icon: "none"
                });
            });
        } else wx.showToast({
            title: "团队人数应为正整数",
            icon: "none"
        }); else wx.showToast({
            title: "请输入正确的手机号",
            icon: "none"
        }); else wx.showToast({
            title: "证件号码输入有误",
            icon: "none"
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});