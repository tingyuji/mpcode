var t = require("../../server/api");

Page({
    options: {
        pureDataPattern: /^_/
    },
    data: {
        model: {},
        time: "",
        visitorNum: "",
        richTextNode: "",
        orderListId: "",
        systemId: "",
        isXinhai: !0
    },
    onLoad: function(e) {
        var a = this;
        console.log(JSON.parse(e.data)), this.setData({
            model: JSON.parse(e.data)
        });
        var i = this.data.model.visitTime, o = decodeURI(this.data.model.visitorNum);
        this.setData({
            time: i,
            visitorNum: o
        }), "黄埔军校旧址纪念馆" == getApp().globalData.MuseumName && this.setData({
            isXinhai: !1
        });
        var s = this;
        (0, t.queryRuleTip)(getApp().globalData.systemId, getApp().globalData.companyInfoId).then(function(e) {
            200 === e.code && (a.setData({
                richTextNode: e.data.ruleValue
            }), (0, t.querySuccessTip)(getApp().globalData.systemId, getApp().globalData.companyInfoId).then(function(t) {
                200 === t.code && (s.setData({
                    orderListId: t.data.orderListId,
                    systemId: t.data.systemId
                }), wx.showToast({
                    title: "已预约成功请按时前往参观",
                    icon: "none",
                    duration: 2e3
                }));
            }).catch(function(t) {}));
        });
    },
    shareBtnClick: function(t) {
        return {
            title: "获取检票二维码",
            path: "pages/teamAppoint/shareAppointErwm?teamShareCode=" + this.data.model.shareCode
        };
    },
    detailbtnClick: function(t) {
        wx.redirectTo({
            url: "../teamAppoint/TeamAppointOrderDetail?shareCode=" + this.data.model.shareCode
        });
    },
    onShareAppMessage: function() {
        return {
            title: "获取检票二维码",
            path: "pages/teamAppoint/shareAppointErwm?teamShareCode=" + this.data.model.shareCode
        };
    }
});