var t = require("../../server/api"), e = require("../../server/static"), a = require("../../utils/validata.js");

Page({
    data: {
        cardtypeArr: [],
        model: {},
        cardTypeStr: "",
        cardTypeIdStr: "",
        nameStr: "",
        phoneStr: "",
        cardNumStr: "",
        vcodeStr: "",
        visitorContactId: "",
        codeStr: "获取验证码",
        countdown: 60,
        showCountdown: !1
    },
    onLoad: function(t) {
        this.setData({
            cardTypeStr: e.cardTypeArr[0].text,
            cardTypeIdStr: e.cardTypeArr[0].id,
            cardtypeArr: e.cardTypeArr
        });
    },
    onReady: function() {},
    onShow: function() {},
    captchaClick: function(e) {
        var a, n = this;
        1 != this.data.showCountdown && ("" === this.data.phoneStr ? wx.showToast({
            title: "请输入手机号码",
            icon: "none"
        }) : /^1[3456789]\d{9}$/.test(this.data.phoneStr) ? (this.setData({
            showCountdown: !0,
            countdown: 60
        }), clearTimeout(this.timer), this.timer = setInterval(function() {
            0 == n.data.countdown && (clearInterval(n.timer), n.setData({
                showCountdown: !1,
                countdown: 60
            })), n.setData({
                countdown: n.data.countdown - 1
            });
        }, 1e3), (a = this).setData({
            captchaInputStr: ""
        }), (0, t.getLeaderCode)(a.data.phoneStr).then(function(t) {
            200 == t.code ? wx.showToast({
                title: "发送成功"
            }) : wx.showToast({
                title: t.msg,
                icon: "none"
            });
        }).catch(function(t) {
            wx.showToast({
                title: "获取验证码失败",
                icon: "none"
            }), console.error("获取验证码失败" + t);
        })) : wx.showToast({
            title: "请输入正确的手机号",
            icon: "none"
        }));
    },
    userNameInput: function(t) {
        this.setData({
            nameStr: t.detail.value
        });
    },
    phoneNumInput: function(t) {
        this.setData({
            phoneStr: t.detail.value
        });
    },
    cardNumInput: function(t) {
        this.setData({
            cardNumStr: t.detail.value
        });
    },
    vcodeInput: function(t) {
        this.setData({
            vcodeStr: t.detail.value
        });
    },
    cardTypePickerChange: function(t) {
        console.log(t.detail.value);
        var e = t.detail.value;
        this.setData({
            cardTypeStr: this.data.cardtypeArr[e].text,
            cardTypeIdStr: this.data.cardtypeArr[e].id
        });
    },
    sureBtnClick: function(e) {
        var n = this.data.nameStr.replace(/\s+/g, ""), o = this.data.phoneStr.replace(/\s+/g, ""), r = this.data.cardNumStr.replace(/\s+/g, "");
        if (this.setData({
            nameStr: n,
            phoneStr: o,
            cardNumStr: r
        }), "" === this.data.nameStr) wx.showToast({
            title: "请输入与证件一致的姓名",
            icon: "none"
        }); else if ("" === this.data.phoneStr) wx.showToast({
            title: "请输入手机号码",
            icon: "none"
        }); else if (/^1[3456789]\d{9}$/.test(this.data.phoneStr)) if (this.data.cardTypeIdStr.length <= 0) wx.showToast({
            title: "请选择证件类型",
            icon: "none"
        }); else if (this.data.cardNumStr.length < 5) wx.showToast({
            title: "请填写正确的证件号码",
            icon: "none"
        }); else if (this.data.vcodeStr.length < 5) wx.showToast({
            title: "请输入验证码",
            icon: "none"
        }); else {
            if ("中国居民身份证" == this.data.cardTypeStr) {
                var i = this.data.cardNumStr;
                if (!a.checkIdCardNo(i)) return void wx.showToast({
                    title: "证件号码输入有误",
                    icon: "none"
                });
            }
            (function() {
                for (var t = "", e = 0; e < 6; e++) t += String(Math.floor(10 * Math.random()));
            })();
            (0, t.teamReserveAddLeader)(this.data.nameStr, this.data.phoneStr, this.data.cardTypeIdStr, this.data.cardNumStr, getApp().globalData.systemId, this.data.vcodeStr).then(function(t) {
                if (200 == t.code) {
                    var e = getCurrentPages(), a = e[e.length - 2];
                    wx.navigateBack({
                        success: function() {
                            a.reloadContactsData();
                        }
                    }), wx.showToast({
                        title: "添加成功",
                        icon: "none"
                    });
                } else wx.showModal({
                    showCancel: !1,
                    title: "提示",
                    content: t.msg,
                    success: function(t) {
                        t.confirm;
                    }
                });
            });
        } else wx.showToast({
            title: "请输入正确的手机号",
            icon: "none"
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});