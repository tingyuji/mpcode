var t = require("../../@babel/runtime/helpers/interopRequireWildcard").default, e = require("../../server/api"), o = t(require("../../utils/qrCode"));

require("../../utils/validata.js");

Page({
    data: {
        param: {},
        shareCode: "",
        codeStr: "获取验证码",
        countdown: 60,
        showCountdown: !1,
        cardNumStr: "",
        vcodeStr: "",
        qrcode_w: (0, o.rpx2px)(320),
        reserveNoStr: ""
    },
    onLoad: function(t) {
        var o, a;
        this.setData({
            shareCode: t.teamShareCode
        }), o = this, a = t.teamShareCode, (0, e.queryTeamInfo)(a).then(function(t) {
            if (200 == t.code) {
                var e = t.data;
                o.setData({
                    param: e
                });
            } else wx.showToast({
                title: t.msg,
                icon: "none"
            });
        }).catch(function(t) {
            console.error("获取联系人失败" + t);
        });
    },
    onReady: function() {},
    onShow: function() {},
    cardNumInput: function(t) {
        this.setData({
            cardNumStr: t.detail.value
        });
    },
    vcodeInput: function(t) {
        this.setData({
            vcodeStr: t.detail.value
        });
    },
    captchaClick: function(t) {
        var o;
        1 != this.data.showCountdown && ("" === this.data.cardNumStr ? wx.showToast({
            title: "请输入证件号码",
            icon: "none"
        }) : (clearTimeout(this.timer), (o = this).setData({
            captchaInputStr: ""
        }), (0, e.getCheckInImgCode)(o.data.shareCode, o.data.cardNumStr, getApp().globalData.systemId).then(function(t) {
            200 == t.code ? (wx.showToast({
                title: "发送成功"
            }), o.setData({
                showCountdown: !0,
                countdown: 60
            }), o.timer = setInterval(function() {
                0 == o.data.countdown && (clearInterval(o.timer), o.setData({
                    showCountdown: !1,
                    countdown: 60
                })), o.setData({
                    countdown: o.data.countdown - 1
                });
            }, 1e3)) : wx.showToast({
                title: t.msg,
                icon: "none"
            });
        }).catch(function(t) {
            wx.showToast({
                title: "获取验证码失败",
                icon: "none"
            }), console.error("获取验证码失败" + t);
        })));
    },
    sureBtnClick: function(t) {
        if (this.data.cardNumStr.length < 5) wx.showToast({
            title: "请正确输入证件号码",
            icon: "none"
        }); else if (this.data.vcodeStr.length < 5) wx.showToast({
            title: "请输入验证码",
            icon: "none"
        }); else {
            var a = this;
            if ("" != this.data.reserveNoStr) return;
            (0, e.getCheckInQRCode)(this.data.cardNumStr, this.data.shareCode, getApp().globalData.systemId, this.data.vcodeStr).then(function(t) {
                200 == t.code ? (a.setData({
                    reserveNoStr: t.data.reserveNo
                }), (0, o.default)(t.data.reserveNo, "canvas0", 320), wx.showToast({
                    title: "获取成功",
                    icon: "none"
                })) : wx.showToast({
                    title: t.msg,
                    icon: "none"
                });
            });
        }
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});