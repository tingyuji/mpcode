var e = require("../../@babel/runtime/helpers/interopRequireWildcard").default, o = require("../../server/api"), a = require("../../server/http"), t = e(require("../../utils/tokenUtil"));

Page({
    data: {
        maxCount: 0,
        hiddleTongzhiPop: !0,
        model: {},
        msgDataArr: []
    },
    onLoad: function(e) {
        var o = JSON.parse(e.data);
        this.setData({
            model: o,
            maxCount: o.maxCount
        });
    },
    tongzhiPopViewClick: function(e) {
        this.setData({
            hiddleTongzhiPop: !0
        });
    },
    sendBtnClick: function(e) {
        var n = this;
        wx.chooseMessageFile({
            count: 1,
            type: "file",
            extension: [ ".xlsx", ".xls", ".XLSX", ".XLS", "xlsx", "xls", "XLSX", "XLS" ],
            success: function(e) {
                var i = e.tempFiles;
                console.log(i[0]), wx.showLoading({
                    title: "请稍等...",
                    mask: !0
                }), wx.uploadFile({
                    filePath: i[0].path,
                    name: "trackData",
                    header: {
                        appId: t.appId,
                        token: (0, t.default)(),
                        systemId: getApp().globalData.systemId,
                        "Content-Type": "multipart/form-data"
                    },
                    formData: {
                        code: "TRM_TEAM_RESERVATION_DETAIL"
                    },
                    url: a.api.file + "file/normalUploadByCode/TRM_COMPANY_PHOTO/FKYY/" + getApp().globalData.systemId,
                    success: function(e) {
                        var a = JSON.parse(e.data);
                        200 == a.code ? (console.log("上传成功", a), (0, o.getTeamContactByFileId)(n.data.model.shareCode, getApp().globalData.systemId, n.data.model.companyInfoId, a.data.fileInfoId).then(function(e) {
                            if (200 == e.code) {
                                var a = e.data;
                                (0, o.addTeamMemberBatch)(n.data.model.shareCode, getApp().globalData.systemId, a).then(function(e) {
                                    200 == e.code ? (wx.hideLoading(), wx.showToast({
                                        title: "",
                                        icon: "success",
                                        duration: 3e3,
                                        success: function() {
                                            var e = getCurrentPages(), o = e[e.length - 2];
                                            wx.navigateBack({
                                                success: function() {
                                                    o.reloadContactsData();
                                                }
                                            });
                                        }
                                    })) : (wx.hideLoading(), wx.showModal({
                                        title: "提示",
                                        content: e.msg,
                                        cancelColor: "",
                                        showCancel: !1,
                                        success: function(e) {}
                                    }));
                                });
                            } else if (455 == e.code) wx.hideLoading(), wx.showModal({
                                title: "提示",
                                content: e.msg,
                                cancelColor: "",
                                showCancel: !1,
                                success: function(e) {}
                            }); else if (499 == e.code) {
                                wx.hideLoading();
                                var t = e.data;
                                n.setData({
                                    hiddleTongzhiPop: !1,
                                    msgDataArr: t
                                });
                            } else wx.hideLoading(), wx.showModal({
                                title: "提示",
                                content: e.msg,
                                cancelColor: "",
                                showCancel: !1,
                                success: function(e) {}
                            });
                        })) : (wx.hideLoading(), (0, o.showWarningToast)(e, "上传失败"));
                    },
                    fail: function(a) {
                        wx.hideLoading(), (0, o.showWarningToast)(e, "上传失败"), console.error("上传失败", a);
                    }
                });
            },
            fail: function(e) {
                wx.hideLoading(), wx.showToast({
                    title: "请重新进入",
                    icon: "none",
                    duration: 2e3
                }), console.log(e);
            }
        });
    },
    xiazaiTishiViewClick: function(e) {
        wx.setClipboardData({
            data: a.api.fileSec + "18905b1ea600401c945a99734f828076/%E5%9B%A2%E9%98%9F%E6%88%90%E5%91%98%E4%BF%A1%E6%81%AF%E6%A8%A1%E6%9D%BF.xlsx",
            success: function(e) {
                wx.getClipboardData({
                    success: function(e) {
                        wx.showModal({
                            title: "提示",
                            content: "已复制下载链接",
                            showCancel: !1,
                            success: function(e) {
                                e.confirm;
                            }
                        });
                    }
                });
            }
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});