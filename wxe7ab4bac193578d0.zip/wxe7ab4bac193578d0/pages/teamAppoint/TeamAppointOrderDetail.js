var e = require("../../@babel/runtime/helpers/interopRequireWildcard").default, t = require("../../server/api"), a = e(require("../../utils/qrCode")), o = require("../../utils/util");

function n(e, o) {
    (0, t.queryTeamOrderDetail)(o).then(function(t) {
        if (200 == t.code) {
            var o = t.data;
            0 == o.status ? o.reserveStatusStr = "待提交" : 1 == o.status ? (o.reserveStatusStr = "预约成功", 
            o.reserveStatusImg = "../../images/center/yiyuyue.png") : 2 == o.status ? (o.reserveStatusStr = "已到馆", 
            o.reserveStatusImg = "../../images/center/yidaoguan.png") : 3 == o.status ? (o.reserveStatusStr = "已解散", 
            o.reserveStatusImg = "../../images/center/yijiesan.png") : 4 == o.status ? (o.reserveStatusStr = "已过期", 
            o.reserveStatusImg = "../../images/center/yiguoqi.png") : 5 == o.status ? (o.reserveStatusStr = "已退票", 
            o.reserveStatusImg = "../../images/center/yituipiao.png") : 6 == o.status && (o.reserveStatusStr = "已改签", 
            o.reserveStatusImg = "../../images/center/yigaiqian.png"), (0, a.default)(o.shareCode, "canvas0", 320), 
            e.setData({
                model: o
            });
        } else wx.showToast({
            title: t.msg,
            icon: "none"
        });
    });
}

Page({
    data: {
        model: {},
        timeStr: "",
        qrcode_w: (0, a.rpx2px)(320)
    },
    onLoad: function(e) {
        var t = this, a = this;
        this.setData({
            timeStr: o.formatTime(new Date())
        }), setInterval(function() {
            var e = o.formatTime(new Date());
            a.setData({
                timeStr: e
            });
        }, 1e3), "" === getApp().globalData.authorizationc ? getApp().tokenReadyCallback = function(a) {
            200 == a.data.code ? n(t, e.shareCode) : (wx.hideLoading(), console.error("模板消息界面进入时为获取到token"));
        } : n(this, e.shareCode);
    },
    onReady: function() {},
    onShow: function() {},
    appointAgainBtnClick: function(e) {
        var t = this;
        wx.showModal({
            title: "提示",
            content: "您确定要再约一次吗",
            cancelColor: "",
            showCancel: !1,
            success: function(e) {
                if (e.confirm) {
                    getApp().globalData.MuseumName = t.data.model.companyName, getApp().globalData.companyInfoId = t.data.model.companyInfoId;
                    var a = t.data.model;
                    a.documentNumber = t.data.model.documentNumberX, a.customerName = t.data.model.visitorName, 
                    a.phoneNumber = t.data.model.phoneNumberX, a.isChangeTime = "NO", a.isTeamAppoint = !0, 
                    a.isTeamReserveAgain = !0, a.typeId = t.data.model.type;
                    var o = JSON.stringify(a);
                    wx.redirectTo({
                        url: "../appointment/home?data=" + o
                    });
                }
            }
        });
    },
    shareBtnClick: function(e) {
        return {
            title: "团队预约",
            path: "pages/teamAppoint/shareAppointErwm?teamShareCode=" + this.data.model.shareCode
        };
    },
    appointEndorseBtnClick: function(e) {
        var a = this;
        wx.showModal({
            title: "提示",
            content: "确定退票吗？",
            showCancel: !0,
            success: function(e) {
                e.confirm && (0, t.teamReserve)(a.data.model.shareCode, getApp().globalData.systemId).then(function(e) {
                    200 == e.code ? wx.showModal({
                        title: "提示",
                        content: "退票成功！",
                        showCancel: !1,
                        success: function(e) {
                            e.confirm && (console.log("用户点击确定"), n(a, a.data.model.shareCode));
                        }
                    }) : wx.showToast({
                        title: e.msg,
                        icon: "none"
                    });
                }).catch(function(e) {
                    console.error("删除人失败" + e);
                });
            }
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: "获取检票二维码",
            path: "pages/teamAppoint/shareAppointErwm?teamShareCode=" + this.data.model.shareCode
        };
    }
});