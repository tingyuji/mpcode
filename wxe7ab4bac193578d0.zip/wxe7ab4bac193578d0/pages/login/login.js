var e = require("../../server/api"), a = (require("../../utils/myUtil"), getApp()), o = "", t = 5, n = "", i = "";

function s(e, o) {
    wx.showModal({
        title: "登录失败",
        content: e,
        success: function(e) {
            e.confirm && o && a.userLogin();
        }
    });
}

Page({
    data: {
        data: {},
        openType: ""
    },
    onLoad: function(e) {
        var r;
        i = null == e.pageUrl ? "" : e.pageUrl.replace(/_/g, "="), r = this, wx.showLoading({
            title: "加载中",
            mask: !0
        }), a.userLogin().then(function(e) {
            if (wx.hideLoading(), 200 == e.code) r.setData({
                openType: ""
            }), wx.showToast({
                title: "登录成功"
            }), "" != i ? wx.navigateTo({
                url: i
            }) : wx.navigateBack(); else if (100 == e.code) {
                r.setData({
                    openType: "getPhoneNumber"
                });
                var a = JSON.parse(e.msg);
                o = a.openid, t = a.openIdType, n = a.session_key, console.log("openid=", o);
            }
        }).catch(function(e) {
            console.log(e), r.setData({
                openType: ""
            }), wx.hideLoading(), s(JSON.stringify(e));
        });
    },
    onGetPhoneNumber: function(r) {
        -1 != r.detail.errMsg.indexOf("fail") ? wx.redirectTo({
            url: "phoneLogin"
        }) : function(o, t, n, r, c, l) {
            wx.showLoading({
                title: "加载中",
                mask: !0
            });
            var d = {
                encryptedData: t,
                iv: n,
                openId: r,
                openIdType: c,
                sessionKey: l
            };
            (0, e.smallProgramLoginByPhone)(d).then(function(e) {
                if (wx.hideLoading(), 200 == e.code) {
                    o.setData({
                        openType: ""
                    }), a.globalData.authorizationc = e.data.authorizationc;
                    var t = getCurrentPages(), n = t[t.length - 2];
                    "" != i ? (null != n.reloadContactsData && n.reloadContactsData(), wx.navigateTo({
                        url: i
                    })) : wx.navigateBack({
                        success: function() {}
                    });
                } else 310 == e.code ? (o.setData({
                    openType: ""
                }), a.globalData.authorizationc = e.data.authorizationc, wx.showToast({
                    title: "无法使用此微信小程序",
                    icon: "none",
                    duration: 3e3
                })) : (s("绑定手机号失败，" + e.msg), console.error("自动绑定失败" + e.msg));
            });
        }(this, r.detail.encryptedData, r.detail.iv, o, t, n);
    }
});