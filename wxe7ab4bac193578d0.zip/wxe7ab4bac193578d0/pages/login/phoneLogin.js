var t = require("../../server/api"), o = require("../../utils/myUtil");

Page({
    data: {
        phoneNum: "",
        verificationCode: "",
        codeStr: "获取验证码",
        countdown: 60,
        showCountdown: !1,
        captchaImgBase64: "",
        vid: "",
        vcode: ""
    },
    timer: "",
    onLoad: function(t) {
        this.updateImgCode();
    },
    phoneNumInput: function(t) {
        var o = this;
        this.setData({
            phoneNum: t.detail.value
        }, function() {
            console.log("手机号", o.data.phoneNum);
        });
    },
    verificationCodeInput: function(t) {
        this.setData({
            verificationCode: t.detail.value
        });
    },
    codeBtnClick: function(e) {
        var a = this;
        if (console.log("vcode", this.data.vcode), 1 != this.data.showCountdown) if (this.setData({
            phoneNum: this.data.phoneNum.replace(/\s+/g, "")
        }), "" == this.data.userName) wx.showToast({
            title: "请先输入手机号码",
            icon: "none"
        }); else if (/^1[3456789]\d{9}$/.test(this.data.phoneNum)) if (this.data.vcode) {
            var n = this.data, i = n.phoneNum, s = n.vcode, d = n.vid;
            (0, t.getQuerySmsVCode)(i, s, d).then(function(t) {
                200 === t.code ? ((0, o.toast)(t.data), a.setData({
                    showCountdown: !0,
                    countdown: 60
                }), clearTimeout(a.timer), a.timer = setInterval(function() {
                    0 == a.data.countdown && (clearInterval(a.timer), a.setData({
                        showCountdown: !1,
                        countdown: 60
                    })), a.setData({
                        countdown: a.data.countdown - 1
                    });
                }, 1e3)) : (a.setData({
                    showCountdown: !1,
                    countdown: 60
                }), (0, o.modal)(t.msg, function() {
                    a.updateImgCode();
                }));
            });
        } else wx.showToast({
            title: "请先输入图形验证码",
            icon: "none"
        }); else wx.showToast({
            title: "请输入正确的手机号",
            icon: "none"
        });
    },
    imgCodeInput: function(t) {
        this.setData({
            vcode: t.detail.value
        });
    },
    updateImgCode: function() {
        var e = this;
        (0, t.saasQueryVCode)().then(function(t) {
            if (200 == t.code) {
                var a = t.data.image.replace(/[\r\n]/g, "");
                e.setData({
                    captchaImgBase64: a,
                    vid: t.data.vid
                });
            } else (0, o.toast)("获取图形验证码失败");
        });
    },
    loginClick: function(e) {
        if ("" == this.data.phoneNum.replace(/\s+/g, "")) wx.showToast({
            title: "请先输入手机号码",
            icon: "none"
        }); else if (/^1[3456789]\d{9}$/.test(this.data.phoneNum)) if ("" == this.data.vcode) wx.showToast({
            title: "请输入图形验证码",
            icon: "none"
        }); else if ("" == this.data.verificationCode) wx.showToast({
            title: "请输入短信验证码",
            icon: "none"
        }); else {
            wx.showLoading({
                title: "登录中...",
                mask: !0
            });
            var a = this.data, n = a.phoneNum, i = a.verificationCode;
            (0, t.loginPhone)(n, i).then(function(t) {
                wx.hideLoading(), 200 === t.code ? (getApp().globalData.authorizationc = t.data.authorizationc, 
                (0, o.toast)("登录成功"), setTimeout(function() {
                    wx.navigateBack();
                }, 1e3)) : (wx.hideLoading(), wx.showToast({
                    title: t.msg,
                    icon: "none"
                }));
            });
        } else wx.showToast({
            title: "请输入正确的手机号",
            icon: "none"
        });
    },
    openLogin2: function() {
        wx.redirectTo({
            url: "login"
        });
    }
});