var e, t = require("../../server/api"), o = require("../../utils/myUtil");

Page({
    data: {
        msgStr: "订单正在处理中，请稍等...",
        msgCode: ""
    },
    onLoad: function(i) {
        var n = decodeURI(i.msgStr), a = decodeURI(i.msgCode);
        this.setData({
            msgStr: n,
            msgCode: a
        });
        var r = this;
        e = setTimeout(function() {
            !function i(n) {
                console.log("还在处理中"), (0, t.personalReserveCheckMySubmit)().then(function(t) {
                    if (200 == t.code) {
                        var a = encodeURI("appointSucc?time=" + t.data.reserveDate + " " + t.data.reserveTime + "&visitorNum=" + t.data.number + "&orderListId=" + t.data.orderListId);
                        wx.redirectTo({
                            url: a
                        }), null != t.data && null != t.data.reserveDate && null != t.data.reserveTime && null != t.data.number || (0, 
                        o.onlineLog)("即将出现undefined错误,personalReserve/checkMySubmit返回结果=" + JSON.stringify(t.data));
                    } else 201 == t.code ? e = setTimeout(function() {
                        i(n);
                    }, 3e3) : (202 == t.code || wx.showModal({
                        title: "温馨提示",
                        content: t.msg,
                        showCancel: !1
                    }), n.setData({
                        msgStr: t.msg,
                        msgCode: t.code
                    }));
                }).catch(function(t) {
                    e = setTimeout(function() {
                        i(n);
                    }, 3e3);
                });
            }(r);
        }, 2e3);
    },
    baceBtnClick: function(e) {
        wx.redirectTo({
            url: "../index/index"
        });
    },
    appointAgainClick: function(e) {
        wx.redirectTo({
            url: "home?isTeamAppoint=false"
        });
    },
    onUnload: function() {
        clearTimeout(e);
    }
});