var e = require("../../server/api"), t = require("../../utils/myUtil"), a = require("../../utils/subscribeMessage");

function n(e) {
    return e.getFullYear() + "-" + i(e.getMonth() + 1) + "-" + i(e.getDate());
}

function i(e) {
    return e <= 9 ? "0" + e : e;
}

Page({
    data: {
        isTeamAppoint: !1,
        isTeamReserveAgain: !1,
        teamReserveAgainModel: {},
        items: [],
        currentDateIndex: -1,
        currentTimeIndex: -1,
        isChangeTime: "NO",
        orderPersonalIds: [],
        changeIntervalDate: "",
        changeIntervalTime: "",
        appointbtnStr: ""
    },
    onLoad: function(e) {
        var t = e.data ? JSON.parse(e.data) : void 0;
        t && "YES" == t.isChangeTime ? this.setData({
            isChangeTime: "YES",
            orderPersonalIds: t.orderPersonalIds,
            changeIntervalDate: t.intervalDate,
            changeIntervalTime: t.intervalValue,
            appointbtnStr: "确认改签"
        }) : t && 1 == t.isTeamReserveAgain ? this.setData({
            teamReserveAgainModel: t,
            isTeamReserveAgain: t.isTeamReserveAgain,
            isTeamAppoint: t.isTeamAppoint,
            isChangeTime: "NO",
            appointbtnStr: "预约参观门票"
        }) : this.setData({
            isTeamAppoint: "true" == e.isTeamAppoint,
            isChangeTime: "NO",
            appointbtnStr: "预约参观门票"
        });
    },
    onShow: function() {
        this.data.isTeamAppoint ? wx.setNavigationBarTitle({
            title: "团队预约"
        }) : wx.setNavigationBarTitle({
            title: "个人预约"
        }), this.getData();
    },
    dateViewClick: function(e) {
        var a = parseInt(e.currentTarget.dataset.index), n = this.data.items[a];
        if (0 == n.status) {
            var i = -1, s = n.surplusList;
            i = this.data.isTeamAppoint ? null == s ? void 0 : s.findIndex(function(e) {
                return e.surplusCountTeam > 0;
            }) : null == s ? void 0 : s.findIndex(function(e) {
                return e.surplusCount > 0;
            }), this.setData({
                currentDateIndex: a,
                currentTimeIndex: i
            });
        } else (0, t.toast)("请重新选择可预约日期");
    },
    timeViewClick: function(e) {
        var a = parseInt(e.currentTarget.dataset.index), n = this.data.items[this.data.currentDateIndex].surplusList[a];
        this.data.isTeamAppoint && n.surplusCountTeam <= 0 || !this.data.isTeamAppoint && n.surplusCount <= 0 ? (0, 
        t.toast)("请重新选择可预约时段") : this.setData({
            currentTimeIndex: a
        });
    },
    appointBtnClick: function(n) {
        if ("" == getApp().globalData.authorizationc) return wx.showToast({
            title: "请先登录",
            icon: "none"
        }), void wx.navigateTo({
            url: "../login/login"
        });
        var i = this.data.items[this.data.currentDateIndex].surplusList[this.data.currentTimeIndex];
        if ("NO" == this.data.isChangeTime) {
            var s = JSON.stringify(i);
            this.data.isTeamAppoint ? (1 == this.data.isTeamReserveAgain && (i.list = this.data.teamReserveAgainModel.list, 
            i.isTeamReserveAgain = !0, i.isTeamAppoint = !0, i.teamShareCode = this.data.teamReserveAgainModel.shareCode, 
            i.teamName = this.data.teamReserveAgainModel.teamName, i.customerName = this.data.teamReserveAgainModel.visitorName, 
            i.documentNumber = this.data.teamReserveAgainModel.documentNumber, i.phoneNumber = this.data.teamReserveAgainModel.phoneNumber, 
            i.MuseumName = this.data.teamReserveAgainModel.companyName, i.companyInfoId = getApp().globalData.companyInfoId, 
            i.type = this.data.teamReserveAgainModel.type, i.typeId = this.data.teamReserveAgainModel.typeId, 
            i.typeStr = this.data.teamReserveAgainModel.typeStr, i.MuseumName = getApp().globalData.MuseumName, 
            i.companyInfoId = getApp().globalData.companyInfoId, i.status = -1, s = JSON.stringify(i)), 
            (0, a.requestTeamSubscribeMessage)("../teamAppoint/TeamAppoint?data=" + s)) : ((0, 
            t.showLoading)(), (0, e.personalReserveCheckMySubmit)().then(function(e) {
                (0, t.hideLoading)(), 201 == e.code ? wx.redirectTo({
                    url: "appointResult?msgStr=" + e.msg + "&msgCode=" + e.code
                }) : (0, a.requestPersonSubscribeMessage)("sureInfo?data=" + s);
            }).catch(function(e) {
                (0, t.hideLoading)(), console.error("个人预约时,api/personalReserve/checkMySubmit调用失败");
            }));
        } else {
            (0, t.showLoading)();
            var r = this.data.orderPersonalIds, o = i.intervalDate, d = i.intervalValue;
            (0, e.updateForChangePersonal)(r, o, d).then(function(e) {
                (0, t.hideLoading)(), 200 == e.code ? (0, t.modal)("改签成功", function() {
                    (0, t.backAndReload)();
                }) : (0, t.toast)(e.msg);
            }).catch(function(e) {
                (0, t.hideLoading)(), console.error("改签失败", e);
            });
        }
    },
    getData: function() {
        var a = this;
        wx.showLoading({
            title: "加载中...",
            mask: !0
        }), (this.data.isTeamAppoint ? (0, e.queryTeamAppointPersonal)(getApp().globalData.systemId, getApp().globalData.companyInfoId) : (0, 
        e.queryPersonal)(getApp().globalData.systemId, getApp().globalData.companyInfoId)).then(function(e) {
            if (wx.hideLoading(), 200 == e.code) {
                var s = e.data;
                new Date().getTime() >= new Date("2023/11/16 23:59:59").getTime() && s.forEach(function(e) {
                    e.status = 3;
                }), (s = function(e) {
                    var a = e[0], i = e[e.length - 1];
                    i.dayWeek - a.dayWeek + 1 != e.length && (0, t.onlineLog)("后端返回的时段有问题，" + JSON.stringify(e));
                    for (var s = 0, r = new Date(a.dayTime.replace(/-/g, "/")), o = a.dayWeek - 1; o >= 1; o--) {
                        var d = {
                            dayWeek: o,
                            canseleted: !1,
                            status: -1,
                            dayTime: n(new Date(r.getTime() - 24 * ++s * 3600 * 1e3))
                        };
                        e.unshift(d);
                    }
                    s = 0;
                    for (var u = new Date(i.dayTime.replace(/-/g, "/")), m = i.dayWeek + 1; m <= 7; m++) {
                        var l = {
                            dayWeek: m,
                            canseleted: !1,
                            status: -2,
                            dayTime: n(new Date(u.getTime() + 24 * ++s * 3600 * 1e3))
                        };
                        e.push(l);
                    }
                    if (e.length < 14) {
                        s = 0, u = new Date(e[e.length - 1].dayTime.replace(/-/g, "/"));
                        for (var c = 1; c <= 7; c++) {
                            var g = {
                                dayWeek: c,
                                canseleted: !1,
                                status: -2,
                                dayTime: n(new Date(u.getTime() + 24 * ++s * 3600 * 1e3))
                            };
                            e.push(g);
                        }
                    }
                    return e;
                }(s)).forEach(function(e) {
                    var t = new Date(e.dayTime.replace(/-/g, "/"));
                    e.dayNum = i(t.getDate()), e.month = i(t.getMonth() + 1), e.isToday = !1;
                });
                var r = s.find(function(e) {
                    return new Date(e.dayTime.replace(/-/g, "/")).getTime() == new Date(new Date().toDateString()).getTime();
                });
                null != r && (r.isToday = !0);
                var o = (0, t.findLastIndex)(s, function(e) {
                    return 0 == e.status;
                }), d = -1;
                -1 != o && (d = a.data.isTeamAppoint ? s[o].surplusList.findIndex(function(e) {
                    return e.surplusCountTeam > 0;
                }) : s[o].surplusList.findIndex(function(e) {
                    return e.surplusCount > 0;
                }));
                -1 != o && s[o].surplusList;
                a.setData({
                    currentDateIndex: o,
                    currentTimeIndex: d,
                    items: s
                });
            } else wx.hideLoading(), wx.showModal({
                content: "当前排队人数较多，是否重试？",
                showCancel: !0,
                cancelText: "回首页",
                confirmText: "重试",
                success: function(e) {
                    e.confirm ? a.getData() : e.cancel && wx.navigateBack();
                }
            });
        }).catch(function(e) {
            console.error(e), wx.hideLoading(), wx.showModal({
                content: "当前排队人数较多，是否重试？",
                showCancel: !0,
                cancelText: "回首页",
                confirmText: "重试",
                success: function(e) {
                    e.confirm ? a.getData() : e.cancel && wx.navigateBack();
                }
            });
        });
    }
});