var e = require("../../@babel/runtime/helpers/interopRequireWildcard").default, t = require("../../server/api"), a = e(require("../../utils/qrCode")), s = require("../../utils/util"), n = -1;

function i(e) {
    (0, t.teamReserveCheckBookList)().then(function(t) {
        if (wx.hideLoading(), 200 == t.code && null != t.data) if (t.data.length > 0) {
            var s = [], r = [], o = [], d = [];
            t.data.forEach(function(e, t) {
                e.seleteimgviewHidden = !0, e.isShousuo = !0;
                var n = e.list[0];
                e.hiddenList = [], e.hiddenList.push(n), e.jishilabHidden = !0, "已预约" == e.statusStr ? (e.seleteimgviewHidden = !1, 
                e.reserveStatusImg = "../../images/center/yiyuyue.png", e.jishilabHidden = !1, e.hours = "00", 
                e.second = "00", e.minute = "00") : "检票中" == e.statusStr ? (d.push(e), e.seleteimgviewHidden = !1, 
                e.reserveStatusImg = "../../images/center/jianpiaozhongguan.png") : "未开始" == e.statusStr ? (d.push(e), 
                e.seleteimgviewHidden = !0, e.jishilabHidden = !1, e.reserveStatus = -2, e.reserveStatusImg = "../../images/center/weikaishiguan.png", 
                e.hours = "00", e.second = "00", e.minute = "00", o.push(e)) : "已使用" == e.statusStr ? e.reserveStatusImg = "../../images/center/yishiyong.png" : "已过期" == e.statusStr ? (e.jishilabHidden = !0, 
                e.reserveStatusImg = "../../images/center/yiguoqi.png") : "已取消" == e.statusStr && (e.reserveStatusImg = "../../images/center/yituiding.png"), 
                "已过期" == e.statusStr && r.push(e), s.push(e), (0, a.default)(e.shareCode, "canvas".concat(t), 320);
            }), r.length == s.length && e.setData({
                isbtnhidden: !0
            });
            var c = "";
            d.length > 0 && s.forEach(function(e, t) {
                if (e.shareCode == d[0].shareCode) return e.checked = !0, void (c = e.shareCode);
            }), e.setData({
                data: s,
                systemName: t.data.systemName,
                checkedIds: c
            }), o.length > 0 && function(e) {
                -1 != n && clearInterval(n);
                n = setInterval(function() {
                    var t = e.data.data, a = [];
                    t.forEach(function(t) {
                        var s = new Date().getTime();
                        if ("未开始" == t.statusStr) {
                            var n = new Date(t.checkStartTime.replace(/-/g, "/")).getTime(), i = null;
                            if (n - s > 0) {
                                var r = (n - s) / 1e3, o = parseInt(r / 86400), d = parseInt(r % 86400 / 3600), c = parseInt(r % 86400 % 3600 / 60), u = parseInt(r % 86400 % 3600 % 60);
                                i = {
                                    day: e.timeFormat(o),
                                    hou: e.timeFormat(d),
                                    min: e.timeFormat(c),
                                    sec: e.timeFormat(u)
                                }, console.log("计时器:"), t.hours = i.hou, t.minute = i.min, t.second = i.sec, a.push(t);
                            } else console.log("计时器2:"), t.jishilabHidden = !1;
                        } else t.jishilabHidden = !0;
                    });
                    var s = t;
                    0 == a.length && (clearInterval(n), i(e)), e.setData({
                        data: s
                    });
                }, 1e3);
            }(e);
        } else wx.showModal({
            title: "提示",
            content: "订单已完成核验",
            showCancel: !1,
            success: function(e) {
                e.confirm && wx.navigateBack();
            }
        }); else wx.hideLoading();
    });
}

Page({
    data: {
        qrcode_w: (0, a.rpx2px)(320),
        data: [],
        info: {},
        checkedIds: "",
        systemName: "",
        second: "",
        minute: "",
        hours: "",
        timeStr: "",
        secondStr: ""
    },
    onLoad: function(e) {
        e.systemId, e.companyInfoId, wx.showLoading({
            title: "加载中...",
            mask: !0
        });
        var t = this, a = s.formatTime(new Date()), n = a.substr(a.length - 2);
        a = a.substring(a.length - 2, 2), t.setData({
            timeStr: a,
            secondStr: n
        }), setInterval(function() {
            var e = s.formatTime(new Date()), a = e.substr(e.length - 2);
            e = e.substring(e.length - 2, 2), t.setData({
                timeStr: e,
                secondStr: a
            });
        }, 1e3), i(this);
    },
    openMuseum: function() {
        var e = {
            id: this.data.info.companyInfoId,
            tenantId: this.data.info.companyInfoId
        };
        wx.redirectTo({
            url: "../museum/museumDetail?data=" + JSON.stringify(e)
        });
    },
    onUnload: function() {
        clearInterval(n);
    },
    timeFormat: function(e) {
        return e < 10 ? "0" + e : e;
    },
    bottomImgvImgClick: function(e) {
        var t = e.currentTarget.dataset.index, a = this.data.data;
        console.log("222"), a[t].isShousuo = !a[t].isShousuo, this.setData({
            data: a
        });
    },
    radioTap: function(e) {
        console.log("111");
        var t = e.currentTarget.dataset.index, a = this.data.data;
        if ("检票中" == a[t].statusStr) {
            var s = "";
            a.forEach(function(e, a) {
                e.checked = a == t && !e.checked, !0 === e.checked && (s = e.shareCode);
            }), this.setData({
                data: a,
                checkedIds: s
            });
        }
    },
    btnClick: function() {
        var e = this;
        (0, t.teamReserveCheckBookConfirm)(this.data.checkedIds, getApp().globalData.companyInfoId, getApp().globalData.systemId).then(function(t) {
            if (200 == t.code) {
                var a = e.data.data;
                a.forEach(function(e) {
                    e.checked = !1;
                }), e.setData({
                    data: a,
                    checkedIds: ""
                }), wx.showModal({
                    title: "提示",
                    content: "核验成功",
                    showCancel: !1,
                    success: function(t) {
                        t.confirm && (console.log("用户点击确定"), i(e));
                    }
                });
            } else wx.showToast({
                title: t.msg,
                icon: "none"
            });
        }).catch(function(e) {
            (0, t.defaultCatch)(e, "核验异常");
        });
    }
});