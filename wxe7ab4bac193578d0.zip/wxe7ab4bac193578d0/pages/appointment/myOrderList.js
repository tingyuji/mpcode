var t, e = require("../../server/api"), a = require("../../server/http"), r = 1, i = 1;

function s(t) {
    wx.showLoading({
        title: "加载中...",
        mask: !0
    }), (0, e.queryTeamAppointOrderList)(getApp().globalData.systemId, i).then(function(e) {
        wx.hideLoading();
        var a = !1;
        if (200 == e.code) {
            var r = e.data.records;
            r.forEach(function(t) {
                null != t.teamName && t.teamName.length > 15 && (t.teamName = t.teamName.substring(0, 15) + "..."), 
                0 == t.status ? (t.reserveStatusStr = "待提交", a = !0) : 1 == t.status ? t.reserveStatusStr = "预约成功" : 2 == t.status ? t.reserveStatusStr = "已到馆" : 3 == t.status ? t.reserveStatusStr = "已解散" : 4 == t.status ? t.reserveStatusStr = "已过期" : 5 == t.status ? t.reserveStatusStr = "已退票" : 6 == t.status && (t.reserveStatusStr = "已改签");
            }), 1 == i && t.setData({
                teamOrderArray: []
            }), i > 1 && 0 === r.length && 3 == t.data.tabIndex && t.setData({
                isHiddleTishiLab: !1
            }), r.length > 0 && 3 == t.data.tabIndex && t.setData({
                orderNullImgState: !0
            });
            var s = t.data.teamOrderArray.concat(r);
            t.setData({
                teamOrderArray: s
            }), 1 == a && t.startCountDown();
        } else t.setData({}), wx.showToast({
            title: e.msg
        });
        wx.hideNavigationBarLoading(), wx.stopPullDownRefresh();
    });
}

function d(t) {
    wx.showLoading({
        title: "加载中...",
        mask: !0
    }), (0, e.queryOrderPersonalList)(r).then(function(e) {
        if (wx.hideLoading(), 200 == e.code) {
            var i = e.data.records;
            i.forEach(function(t) {
                null != t.companyName && t.companyName.length > 15 && (t.companyName = t.companyName.substring(0, 15) + "..."), 
                t.photoUrl = null == t.companyImg ? "../../images/banner.png" : a.api.fileSec + t.companyImg, 
                t.photoUrl = "../../images/museum1.jpg", 0 == t.orderStatus ? t.reserveStatusStr = "待支付" : 1 == t.orderStatus ? t.reserveStatusStr = "预约成功" : 2 == t.orderStatus ? t.reserveStatusStr = "部分退票" : 3 == t.orderStatus ? t.reserveStatusStr = "已退票" : 4 == t.orderStatus && (t.reserveStatusStr = "支付中");
            }), 1 == r && t.setData({
                orderArray: []
            }), r > 1 && 0 === i.length && 0 == t.data.tabIndex && t.setData({
                isHiddleTishiLab: !1
            }), i.length > 0 && 0 == t.data.tabIndex && t.setData({
                orderNullImgState: !0
            });
            var s = t.data.orderArray.concat(i);
            t.setData({
                orderArray: s
            });
        } else t.setData({}), wx.showToast({
            title: e.msg
        });
        wx.hideNavigationBarLoading(), wx.stopPullDownRefresh();
    });
}

Page({
    data: {
        tabIndex: 0,
        orderArray: [],
        teamOrderArray: [],
        activityOrderArray: [],
        exhibitionOederArray: [],
        orderNullImgState: !1,
        isHiddleTishiLab: !0,
        isHexiaoHidden: !1,
        orderListId: []
    },
    onLoad: function(t) {
        var e = JSON.parse(t.data);
        1, r = 1, 1, i = 1, !1 === e.isHexiaoHidden ? (this.setData({
            isHexiaoHidden: !1
        }), d(this), 1, s(this)) : (this.setData({
            isHexiaoHidden: !0,
            tabIndex: e.tabIndex,
            orderNullImgState: !0,
            orderListId: e.orderListId
        }), 2 == e.tabIndex ? (0, this.data.orderListId) : e.tabIndex);
    },
    onTopTabItemTap: function(t) {
        var e = t.currentTarget.dataset.index;
        this.data.tabIndex != e && (this.setData({
            tabIndex: e
        }), 0 == e ? this.data.orderArray.length <= 0 ? this.setData({
            orderNullImgState: !1
        }) : this.setData({
            orderNullImgState: !0
        }) : 1 == e ? this.data.activityOrderArray.length <= 0 ? this.setData({
            orderNullImgState: !1
        }) : this.setData({
            orderNullImgState: !0
        }) : 2 == e ? this.data.exhibitionOederArray.length <= 0 ? this.setData({
            orderNullImgState: !1
        }) : this.setData({
            orderNullImgState: !0
        }) : 3 == e ? this.data.teamOrderArray.length <= 0 ? this.setData({
            orderNullImgState: !1
        }) : this.setData({
            orderNullImgState: !0
        }) : this.setData({
            orderNullImgState: !1
        }));
    },
    ordercellclick: function(t) {
        var e = parseInt(t.currentTarget.dataset.index), a = this.data.orderArray[e];
        wx.navigateTo({
            url: "orderDetail?orderPersonalId=" + a.orderListId + "&systemId=" + getApp().globalData.systemId + "&companyInfoId=" + getApp().globalData.companyInfoId
        });
    },
    teamOrdercellclick: function(t) {
        var e = parseInt(t.currentTarget.dataset.index), a = this.data.teamOrderArray[e];
        if (0 == a.status) {
            var r = a;
            r.teamName = a.teamName, r.customerName = a.visitorName, r.documentNumber = a.documentNumber, 
            r.phoneNumber = a.phoneNumber, r.teamShareCode = a.shareCode, r.MuseumName = a.companyName, 
            r.intervalDate = a.reserveDate, r.intervalValue = a.reserveTime, r.expireTime = a.expireTime, 
            r.companyInfoId = a.companyInfoId, r.teamTypeStr = a.typeStr, r.status = 0;
            var i = JSON.stringify(r);
            wx.navigateTo({
                url: "../teamAppoint/TeamAppointTwo?data=" + i
            });
        } else wx.navigateTo({
            url: "../teamAppoint/TeamAppointOrderDetail?shareCode=" + a.shareCode
        });
    },
    activityOrdercellclick: function(t) {
        var e = parseInt(t.currentTarget.dataset.index), a = this.data.activityOrderArray[e];
        wx.navigateTo({
            url: "../activity/activityAppointDetail?orderListId=" + a.orderListId
        });
    },
    exhibitionOrdercellclick: function(t) {
        var e = parseInt(t.currentTarget.dataset.index), a = this.data.exhibitionOederArray[e];
        !0 === this.data.isHexiaoHidden ? wx.navigateTo({
            url: "../exhibition/exhibitionSignIn?orderListId=" + a.orderId + "&heXiaoHiddenState=false&displayInfoId=" + a.orderId
        }) : wx.navigateTo({
            url: "../exhibition/exhibitionApplintDetail?orderListId=" + a.orderId + "&heXiaoHiddenState=true"
        });
    },
    onPullDownRefresh: function() {
        clearInterval(t), 0 == this.data.tabIndex ? (r = 1, d(this)) : 1 == this.data.tabIndex ? 1 : 2 == this.data.tabIndex ? (1, 
        this.data.orderListId) : 3 == this.data.tabIndex && (i = 1, s(this));
    },
    onUnload: function() {
        clearInterval(t);
    },
    timeFormat: function(t) {
        return t < 10 ? "0" + t : t;
    },
    startCountDown: function() {
        var e = this, a = this.data.teamOrderArray;
        t = setInterval(function() {
            a.forEach(function(t) {
                if (0 == t.status) {
                    var a, r = new Date().getTime(), i = t.expireTime.replace(/-/g, "/"), s = new Date(i).getTime(), d = null;
                    if (s - r > 0) {
                        var n = (s - r) / 1e3, o = parseInt(n / 86400), l = parseInt(n % 86400 / 3600), m = parseInt(n % 86400 % 3600 / 60), u = parseInt(n % 86400 % 3600 % 60);
                        d = {
                            day: e.timeFormat(o),
                            hou: e.timeFormat(l),
                            min: e.timeFormat(m),
                            sec: e.timeFormat(u)
                        };
                    } else d = {
                        day: "00",
                        hou: "00",
                        min: "00",
                        sec: "00"
                    };
                    0 == (a = d).hou ? t.expireTimeStr = +a.min + "分" + a.sec + "秒" : t.expireTimeStr = +a.hou + "小时" + a.min + "分" + a.sec + "秒";
                }
            }), e.setData({
                teamOrderArray: a
            });
        }, 1e3);
    },
    onReachBottom: function() {
        console.log("页面上拉触底事件的处理函数"), 0 == this.data.tabIndex ? (++r, d(this)) : 1 == this.data.tabIndex ? this.setData({
            isHiddleTishiLab: !1
        }) : 2 == this.data.tabIndex ? (this.setData({
            isHiddleTishiLab: !1
        }), this.data.orderListId) : 3 == this.data.tabIndex && (++i, this.setData({
            isHiddleTishiLab: !1
        }), s(this));
    }
});