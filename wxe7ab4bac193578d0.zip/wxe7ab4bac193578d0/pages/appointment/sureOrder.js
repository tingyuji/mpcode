var t = require("../../server/api");

function e(e) {
    e.setData({
        codeInputStr: ""
    }), (0, t.personalReserveQueryImgCode)().then(function(t) {
        if (200 == t.code) {
            var a = t.data.replace(/[\r\n]/g, "");
            e.setData({
                captchaImgBase64: a
            });
        } else wx.showToast({
            title: t.msg,
            icon: "none"
        });
    }).catch(function(t) {
        console.error("验证码失败" + t);
    });
}

Page({
    data: {
        param: {},
        codeInputStr: "",
        captchaImgBase64: "",
        selectIDMemberArr: [],
        MuseumName: ""
    },
    onLoad: function(t) {
        var a = JSON.parse(t.data);
        console.log(a);
        var o = [];
        a.contactIdList.forEach(function(t) {
            o.push(t.customerContactId);
        }), this.setData({
            param: a,
            MuseumName: getApp().globalData.MuseumName,
            selectIDMemberArr: o
        }), e(this);
    },
    captchaClick: function(t) {
        e(this);
    },
    captchaCodeInput: function(t) {
        this.setData({
            codeInputStr: t.detail.value
        });
    },
    verificationResult: function() {
        console.log("验证通过"), this.setData({
            codeInputStr: "验证通过"
        });
    },
    onReady: function() {},
    appointBtnClick: function(a) {
        var o = this;
        if (this.data.codeInputStr.length <= 0) wx.showToast({
            title: "请拖动滑块验证",
            icon: "none"
        }); else {
            var n = this.data.param;
            n.contactIdList = this.data.selectIDMemberArr, n.imgCode = this.data.codeInputStr, 
            wx.showLoading({
                title: "加载中...",
                mask: !0
            }), (0, t.saveForSubmitPersonal)(this.data.codeInputStr, getApp().globalData.companyInfoId).then(function(t) {
                wx.hideLoading(), 200 == t.code ? (wx.showToast({
                    title: "提交订单成功"
                }), wx.redirectTo({
                    url: "appointSucc?time=" + t.data.reserveDate + " " + t.data.reserveTime + "&visitorNum=" + o.data.param.allPeopleNum
                })) : (console.error("提交订单" + t.msg), e(o), wx.showModal({
                    title: "温馨提示",
                    content: t.msg,
                    showCancel: !1
                }));
            }).catch(function(t) {
                wx.hideLoading(), console.error("提交订单", t), e(o), wx.showModal({
                    title: "温馨提示",
                    showCancel: !1
                });
            });
        }
    }
});