var t = require("../../server/api"), e = (require("../../server/http"), require("../../utils/myUtil")), a = 0, n = {};

function o(e) {
    var a = wx.getStorageSync(getApp().globalData.openId + "_realName");
    "" != a && null != a ? (console.log("确认预约界面，缓存中有实名认证信息，不再请求"), (n = JSON.parse(a)).contactName = n.customerName, 
    n.documentNumberFull = n.showDocumentNumber, n.contactPhoneFull = n.phoneNumber, 
    n.myself = 1, e.setData({
        selectedContactsArr: [ n ],
        isHasSelf: !0,
        phoneStr: n.phoneNumber
    })) : (console.log("确认预约界面，缓存中没有实名信息，按道理来讲，这种情况不应该存在，因为没有实名认证信息，不能进到这个界面"), (0, 
    t.customerContactQueryPageList)().then(function(t) {
        if (200 == t.code) {
            for (var a = [], n = t.data.records, o = !1, s = "", i = 0; i < n.length; i++) if (1 === n[i].myself) {
                s = n[i].contactPhone, o = !0, n[i].addChildArr = [], a.push(n[i]);
                break;
            }
            !1 === o && wx.showModal({
                title: "提示",
                content: "请先进行实名认证",
                cancelColor: "",
                showCancel: !0,
                success: function(t) {
                    t.confirm && wx.navigateTo({
                        url: "../contacts/realNameCertification"
                    });
                }
            }), e.setData({
                selectedContactsArr: a,
                isHasSelf: o,
                phoneStr: s
            });
        } else wx.showToast({
            title: t.msg,
            icon: "none"
        });
    }));
}

function s(n) {
    n.setData({
        codeInputStr: ""
    }), (0, e.showLoading)(), (0, t.personalReserveQueryImgCode)().then(function(t) {
        if ((0, e.hideLoading)(), 200 == t.code) {
            var o = t.data.replace(/[\r\n]/g, "");
            n.setData({
                captchaImgBase64: o
            });
        } else a = 0, wx.showToast({
            title: t.msg,
            icon: "none"
        });
    }).catch(function(t) {
        a = 0, (0, e.hideLoading)(), console.error("验证码失败" + t);
    });
}

Page({
    data: {
        codeInputStr: "",
        captchaImgBase64: "",
        model: {},
        selectedContactsArr: [],
        maxCount: 3,
        isHasSelf: !1,
        isAddChild: !1,
        addIndex: 999,
        addChildArr: [],
        allAddChildArr: [],
        phoneStr: "",
        MuseumName: ""
    },
    onLoad: function(e) {
        var a, n;
        this.setData({
            model: JSON.parse(e.data)
        }), a = this, null != (n = getApp().globalData.personalReserveRule) && null != n.numberReserveCount ? a.setData({
            maxCount: n.numberReserveCount
        }) : (0, t.queryPersonalReserveRule)(getApp().globalData.systemId, getApp().globalData.companyInfoId).then(function(t) {
            200 == t.code ? (getApp().globalData.personalReserveRule = t.data, a.setData({
                maxCount: t.data.numberReserveCount
            })) : wx.showToast({
                title: t.msg,
                icon: "none"
            });
        }).catch(function(t) {
            console.error("获取预约规则失败" + t);
        }), o(this);
    },
    onShow: function() {
        a = new Date().getTime(), s(this);
    },
    captchaClick: function(t) {
        var n = new Date().getTime();
        n - a > 3e3 ? (a = n, s(this)) : (0, e.toast)("操作太频繁，请稍后再试");
    },
    captchaCodeInput: function(t) {
        this.setData({
            codeInputStr: t.detail.value
        });
    },
    addChildRefreshData: function() {
        if (1 == this.data.isAddChild) {
            var t = this.data.selectedContactsArr;
            console.log("用于在添加儿童中调用:" + JSON.stringify(t));
            var e = t[this.data.addIndex], a = this.data.addChildArr;
            e.addChildArr = a, t.splice(this.data.addIndex, 1, e);
            var n = this.data.allAddChildArr;
            n = n.concat(e.addChildArr);
            var o = [], s = [];
            t.forEach(function(t, e) {
                0 == t.isJuveniles && (t.addChildArr.length > 0 && (s = s.concat(t.addChildArr)), 
                1 != (-1 != n.findIndex(function(e) {
                    return e.customerContactId === t.customerContactId;
                })) && o.push(t));
            }), this.setData({
                selectedContactsArr: o,
                allAddChildArr: s,
                isAddChild: !1,
                addIndex: 999
            });
        }
    },
    reloadContactsData: function() {
        o(this);
    },
    editUserBtnClick: function(t) {
        wx.navigateTo({
            url: "../contacts/realNameCertification"
        });
    },
    addChildBtnClick: function(t) {
        if (0 == this.data.isHasSelf) wx.showModal({
            title: "提示",
            content: "请先进行实名认证",
            cancelColor: "",
            showCancel: !0,
            success: function(t) {
                t.confirm && wx.navigateTo({
                    url: "../contacts/realNameCertification"
                });
            }
        }); else {
            var e = t.target.dataset.value, a = this.data.selectedContactsArr[e], n = {
                maxCount: 2,
                isAddChild: !0,
                addIndex: e,
                allAddChildArr: this.data.allAddChildArr,
                leaderContactId: a.customerContactId,
                seletDataArr: a.addChildArr
            }, o = JSON.stringify(n);
            wx.navigateTo({
                url: "../contacts/selectContacts?data=" + o
            });
        }
    },
    selectContactsClick: function(t) {
        if (0 == this.data.isHasSelf) wx.showModal({
            title: "提示",
            content: "请先进行实名认证",
            cancelColor: "",
            showCancel: !0,
            success: function(t) {
                t.confirm && wx.navigateTo({
                    url: "../contacts/realNameCertification"
                });
            }
        }); else {
            var e = {
                maxCount: this.data.maxCount,
                allAddChildArr: this.data.allAddChildArr,
                seletDataArr: this.data.selectedContactsArr
            }, a = JSON.stringify(e);
            wx.navigateTo({
                url: "../contacts/selectContacts?data=" + a
            });
        }
    },
    deleteBtnClick: function(t) {
        console.log("删除按钮点击" + JSON.stringify(t.target.dataset.value));
        var e = t.target.dataset.value, a = this.data.selectedContactsArr, n = a[e];
        a.splice(e, 1);
        var o = this.data.allAddChildArr, s = [];
        0 == n.isJuveniles && n.addChildArr.length > 0 ? o.forEach(function(t, e) {
            1 != (-1 != n.addChildArr.findIndex(function(e) {
                return e.customerContactId === t.customerContactId;
            })) && s.push(t);
        }) : s = o, this.setData({
            selectedContactsArr: a,
            allAddChildArr: s
        });
    },
    appointBtnClick: function(a) {
        if (this.data.selectedContactsArr.length <= 0) wx.showToast({
            title: "请先添加参观者",
            icon: "none"
        }); else if (this.data.codeInputStr.length <= 0) wx.showToast({
            title: "请输入验证码",
            icon: "none"
        }); else {
            var o = this, s = [];
            this.data.selectedContactsArr.forEach(function(t, e) {
                s.push({
                    visitorName: t.contactName,
                    documentType: t.documentType,
                    documentNumber: t.documentNumberFull,
                    phoneNumber: t.contactPhoneFull,
                    customerContactId: t.customerContactId
                });
            });
            wx.showLoading({
                title: "加载中...",
                mask: !0
            });
            var i = {
                visitorName: n.contactName,
                documentNumber: n.documentNumberFull
            };
            (0, t.saveForPrepareSubmit)(this.data.model.intervalDate, this.data.model.intervalValue, getApp().globalData.companyInfoId, s, [], this.data.codeInputStr, i).then(function(a) {
                wx.hideLoading(), 200 == a.code ? (!function(e, a) {
                    (0, t.personalReserveCheckMySubmit)().then(function(t) {
                        if (wx.hideLoading(), 200 == t.code) {
                            var n = encodeURI("appointSucc?time=" + e.data.model.intervalDate + " " + e.data.model.intervalValue + "&visitorNum=" + a + "&orderListId=" + t.data.orderListId);
                            wx.redirectTo({
                                url: n
                            });
                        } else 201 == t.code ? wx.navigateTo({
                            url: "appointResult?msgStr=" + t.msg + "&msgCode=" + t.code
                        }) : wx.redirectTo({
                            url: "appointResult?msgStr=" + t.msg + "&msgCode=" + t.code
                        });
                    });
                }(o, s.length), "" != a.msg && a.msg, wx.showLoading({
                    title: "提交中..."
                })) : (console.debug("提交订单" + a.msg), null != a.msg && -1 != a.msg.indexOf("没有足够的余票") ? (0, 
                e.modal)(a.msg, function() {
                    wx.navigateBack();
                }) : null != a.msg && -1 != a.msg.indexOf("参数错误") ? ((0, e.onlineLog)("提交订单，发生了参数错误，联系人数据为，" + JSON.stringify(s)), 
                (0, e.modal)("当前排队人数较多，请稍后重试", function() {
                    wx.navigateBack();
                })) : wx.showModal({
                    title: "温馨提示",
                    content: a.msg,
                    showCancel: !1
                }));
            }).catch(function(t) {
                wx.hideLoading(), (0, e.onlineLog)("saveForPrepareSubmit进入了catch，" + JSON.stringify(t));
            });
        }
    }
});