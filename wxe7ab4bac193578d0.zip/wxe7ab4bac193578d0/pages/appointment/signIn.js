var e = require("../../@babel/runtime/helpers/interopRequireDefault").default, t = require("../../@babel/runtime/helpers/interopRequireWildcard").default, a = require("../../server/api"), r = t(require("../../utils/qrCode")), s = e(require("../../utils/weapp-qrcode")), n = require("../../utils/util"), i = "", o = -1;

function d(e) {
    (0, a.queryVenueById)(i).then(function(t) {
        if (200 == t.code && null != t.data) {
            var a = t.data;
            a.companyAddress = null == a.companyAddress ? "未知" : a.companyAddress, e.setData({
                info: a
            });
        }
    }), (0, a.personalListForSign)(getApp().globalData.systemId).then(function(t) {
        if (wx.hideLoading(), 200 == t.code) if (t.data.list.length > 0) {
            var n = [], i = [], c = [], u = [];
            t.data.list.forEach(function(e, t) {
                e.seleteimgviewHidden = !0, e.jishilabHidden = !0, "已预约" == e.reserveStatusStr ? (e.seleteimgviewHidden = !1, 
                e.reserveStatusImg = "../../images/center/yiyuyue.png", e.jishilabHidden = !1, e.hours = "00", 
                e.second = "00", e.minute = "00") : "检票中" == e.reserveStatusStr ? (u.push(e), e.seleteimgviewHidden = !1, 
                e.reserveStatusImg = "../../images/center/jianpiaozhongguan.png") : "未开始" == e.reserveStatusStr ? (u.push(e), 
                e.seleteimgviewHidden = !0, e.jishilabHidden = !1, e.reserveStatus = -2, e.reserveStatusImg = "../../images/center/weikaishiguan.png", 
                e.hours = "00", e.second = "00", e.minute = "00", c.push(e)) : "已使用" == e.reserveStatusStr ? e.reserveStatusImg = "../../images/center/yishiyong.png" : "已过期" == e.reserveStatusStr ? (e.jishilabHidden = !0, 
                e.reserveStatusImg = "../../images/center/yiguoqi.png") : "已取消" == e.reserveStatusStr && (e.reserveStatusImg = "../../images/center/yituiding.png"), 
                "已过期" == e.reserveStatusStr && i.push(e), "已使用" == e.reserveStatusStr ? (console.log("已使用" + e.visitorName + t), 
                function(e, t) {
                    var a = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 320, n = (0, 
                    r.rpx2px)(a);
                    new s.default(t, {
                        text: e,
                        width: n,
                        height: n,
                        colorDark: "#9a1e2b",
                        colorLight: "white",
                        imageSize: 50,
                        correctLevel: s.default.CorrectLevel.H
                    });
                }(e.reserveNo, "canvas".concat(e.orderPersonalId), 320)) : (console.log(e.reserveStatusStr + e.visitorName + t), 
                (0, r.default)(e.reserveNo, "canvas".concat(e.orderPersonalId), 320)), n.push(e);
            }), i.length == n.length && e.setData({
                isbtnhidden: !0
            });
            var l = [];
            u.length > 0 && n.forEach(function(e, t) {
                if (e.orderPersonalId == u[0].orderPersonalId) return e.checked = !0, void l.push(e.orderPersonalId);
            }), e.setData({
                data: n,
                systemName: t.data.systemName,
                checkedIds: l
            }), c.length > 0 && function(e) {
                -1 != o && clearInterval(o);
                o = setInterval(function() {
                    var t = e.data.data, a = [];
                    t.forEach(function(t) {
                        var r = new Date().getTime();
                        if ("未开始" == t.reserveStatusStr) {
                            var s = new Date(t.checkStartTime.replace(/-/g, "/")).getTime(), n = null;
                            if (s - r > 0) {
                                var i = (s - r) / 1e3, o = parseInt(i / 86400), d = parseInt(i % 86400 / 3600), c = parseInt(i % 86400 % 3600 / 60), u = parseInt(i % 86400 % 3600 % 60);
                                n = {
                                    day: e.timeFormat(o),
                                    hou: e.timeFormat(d),
                                    min: e.timeFormat(c),
                                    sec: e.timeFormat(u)
                                }, console.log("计时器:"), t.hours = n.hou, t.minute = n.min, t.second = n.sec, a.push(t);
                            } else console.log("计时器2:"), t.jishilabHidden = !1;
                        } else t.jishilabHidden = !0;
                    });
                    var r = t;
                    0 == a.length && (clearInterval(o), d(e)), e.setData({
                        data: r
                    });
                }, 1e3);
            }(e);
        } else wx.showModal({
            title: "提示",
            content: "订单已完成核验",
            showCancel: !1,
            success: function(e) {
                e.confirm && wx.navigateBack();
            }
        }); else (0, a.showWarningToast)(t, "获取预约记录失败");
    });
}

Page({
    data: {
        qrcode_w: (0, r.rpx2px)(320),
        data: [],
        info: {},
        checkedIds: [],
        systemName: "",
        second: "",
        minute: "",
        hours: "",
        timeStr: "",
        secondStr: ""
    },
    onLoad: function(e) {
        e.systemId, i = e.companyInfoId, wx.showLoading({
            title: "加载中...",
            mask: !0
        });
        var t = this, a = n.formatTime(new Date()), r = a.substr(a.length - 2);
        a = a.substring(a.length - 2, 2), t.setData({
            timeStr: a,
            secondStr: r
        }), setInterval(function() {
            var e = n.formatTime(new Date()), a = e.substr(e.length - 2);
            e = e.substring(e.length - 2, 2), t.setData({
                timeStr: e,
                secondStr: a
            });
        }, 1e3), d(this);
    },
    openMuseum: function() {
        var e = {
            id: this.data.info.companyInfoId,
            tenantId: this.data.info.companyInfoId
        };
        wx.redirectTo({
            url: "../museum/museumDetail?data=" + JSON.stringify(e)
        });
    },
    onUnload: function() {
        clearInterval(o);
    },
    timeFormat: function(e) {
        return e < 10 ? "0" + e : e;
    },
    radioTap: function(e) {
        var t = e.currentTarget.dataset.index, a = this.data.data;
        if (0 == a[t].reserveStatus) {
            var r = this.data.checkedIds;
            a[t].checked = !a[t].checked;
            var s = r.indexOf(a[t].orderPersonalId);
            a[t].checked && -1 == s ? r.push(a[t].orderPersonalId) : a[t].checked || -1 == s || r.splice(s, 1), 
            this.setData({
                data: a,
                checkedIds: r
            });
        }
    },
    btnClick: function() {
        var e = this;
        (0, a.personalReserveSign)(this.data.checkedIds).then(function(t) {
            if (200 == t.code) {
                var a = e.data.data;
                a.forEach(function(e) {
                    e.checked = !1;
                }), e.setData({
                    data: a,
                    checkedIds: []
                }), wx.showModal({
                    title: "提示",
                    content: "核验成功",
                    showCancel: !1,
                    success: function(t) {
                        t.confirm && (console.log("用户点击确定"), d(e));
                    }
                });
            } else wx.showToast({
                title: t.msg,
                icon: "none"
            });
        });
    }
});