var e = require("../../server/api");

Page({
    data: {
        selectTimeModel: {},
        richTextNode: ""
    },
    onLoad: function(a) {
        var t;
        console.log(JSON.parse(a.data)), this.setData({
            selectTimeModel: JSON.parse(a.data)
        }), t = this, 0 == getApp().globalData.isTeamAppoint ? (0, e.queryPersonalDescrption)(getApp().globalData.systemId, getApp().globalData.companyInfoId).then(function(e) {
            200 == e.code ? t.setData({
                richTextNode: "" == e.data || null == e.data ? "暂无预约须知" : e.data
            }) : wx.showToast({
                title: e.msg,
                icon: "none"
            });
        }).catch(function(e) {
            console.debug("获取预约须知失败" + e);
        }) : (0, e.queryTeamPersonalDescrption)(getApp().globalData.systemId, getApp().globalData.companyInfoId).then(function(e) {
            200 == e.code ? t.setData({
                richTextNode: "" == e.data || "" == e.data.ruleValue ? "暂无预约须知" : e.data.ruleValue
            }) : wx.showToast({
                title: e.msg,
                icon: "none"
            });
        }).catch(function(e) {
            console.debug("获取预约须知失败" + e);
        });
    },
    sureBtnClick: function(e) {
        wx.showLoading({
            title: "加载中..."
        });
        var a = this.data.selectTimeModel, t = JSON.stringify(this.data.selectTimeModel);
        if (0 == getApp().globalData.isTeamAppoint) wx.hideLoading(), wx.requestSubscribeMessage({
            tmplIds: [ "UpmZRKeoYzgIJQhloifP-62fUDX5DdYGLAQUAhbhAig", "CipTnZpflvHUL-ylhwLDEiLmUUHZ8sLmjf_V5rwOg_I", "YZFIIK5-6oktV2vGVaZ_1Eob4Co5_-mbEXi_TKPSsEk" ],
            success: function(e) {
                console.log("订阅消息授权正确：" + JSON.stringify(e)), wx.navigateTo({
                    url: "sureInfo?data=" + t
                });
            },
            fail: function(e) {
                wx.hideLoading(), console.log("订阅消息授权错误信息22" + JSON.stringify(e)), wx.navigateTo({
                    url: "sureInfo?data=" + t
                });
            }
        }); else if (1 == this.data.selectTimeModel.isTeamReserveAgain) {
            (a = this.data.selectTimeModel).MuseumName = getApp().globalData.MuseumName, a.companyInfoId = getApp().globalData.companyInfoId, 
            a.status = -1, wx.hideLoading();
            t = JSON.stringify(a);
            wx.requestSubscribeMessage({
                tmplIds: [ "2TmmuaUlsRoGX6MGCJWkINecP302DGXcp4kai8n9-RI", "X6NB90Fo6cP4eaLrFrgIJxQQsZ-NScpOAik2n-ZUcko", "O9F2_w1pzLoQE4coVSjudQ2VqMh3VP62d2BDO5spfRc" ],
                success: function(e) {
                    console.log("订阅消息授权正确：" + JSON.stringify(e)), wx.navigateTo({
                        url: "../teamAppoint/TeamAppoint?data=" + t
                    });
                },
                fail: function(e) {
                    wx.hideLoading(), console.log("订阅消息授权错误信息" + JSON.stringify(e)), wx.navigateTo({
                        url: "../teamAppoint/TeamAppoint?data=" + t
                    });
                }
            });
        } else wx.hideLoading(), wx.requestSubscribeMessage({
            tmplIds: [ "2TmmuaUlsRoGX6MGCJWkINecP302DGXcp4kai8n9-RI", "X6NB90Fo6cP4eaLrFrgIJxQQsZ-NScpOAik2n-ZUcko", "O9F2_w1pzLoQE4coVSjudQ2VqMh3VP62d2BDO5spfRc" ],
            success: function(e) {
                console.log("订阅消息授权正确：" + JSON.stringify(e)), wx.navigateTo({
                    url: "../teamAppoint/TeamAppoint?data=" + t
                });
            },
            fail: function(e) {
                console.log("订阅消息授权错误信息" + JSON.stringify(e)), wx.navigateTo({
                    url: "../teamAppoint/TeamAppoint?data=" + t
                });
            }
        });
    }
});