require("../../server/api");

Page({
    options: {
        pureDataPattern: /^_/
    },
    data: {
        time: "",
        visitorNum: "",
        richTextNode: "<p>1、预约成功后，系统将推送预约订单信息，请妥善保存。请在预约时段入馆参观，提前或错过预约时段谢绝入馆。</p><p>2、如需改签预约，个人可在官网或微信小程序操作。团队不可改签，可先在官网或微信公众号取消预约后，再选定您想参观的日期进行预约。</p>",
        orderListId: ""
    },
    onLoad: function(t) {
        var e = decodeURI(t.time), a = decodeURI(t.visitorNum), i = decodeURI(t.orderListId);
        this.setData({
            time: e,
            visitorNum: a,
            orderListId: i
        });
    },
    backbtnClick: function(t) {
        wx.navigateBack({
            delta: 4
        });
    },
    detailbtnClick: function(t) {
        wx.redirectTo({
            url: "orderDetail?orderPersonalId=" + this.data.orderListId + "&systemId=" + getApp().globalData.systemId + "&companyInfoId=" + getApp().globalData.companyInfoId
        });
    }
});