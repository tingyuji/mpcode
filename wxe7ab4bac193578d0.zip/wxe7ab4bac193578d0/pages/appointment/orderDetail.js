var e = require("../../@babel/runtime/helpers/interopRequireWildcard").default, t = require("../../server/api"), r = e(require("../../utils/qrCode"));

require("../../utils/util");

function a(e, a, n) {
    var s, o = (0, t.queryOrderPersonalDetail)(a);
    if ("" != n) {
        var i = (0, t.queryPersonalReserveRule)(getApp().globalData.systemId, getApp().globalData.companyInfoId);
        s = Promise.all([ o, i ]);
    } else s = Promise.all([ o ]);
    s.then(function(t) {
        if (console.log(t), wx.hideNavigationBarLoading(), wx.hideLoading(), 2 == t.length && 200 == t[0].code && 200 == t[1].code) {
            var a = t[0].data;
            "false" === t[1].data.accountRebookCount ? (a.museumCanRebook = !1, s = "不支持改签") : (a.museumCanRebook = !0, 
            s = "改签");
            var n = [];
            a.orderPersonalList.forEach(function(t, a) {
                if (t.seleted = !1, "已预约" != t.reserveStatusStr) {
                    var s = t.reserveTime.split("-"), o = t.reserveDate + " " + s[1], i = t.reserveDate + " 16:30", d = new Date(o).getDate(), c = new Date().getDate(), u = new Date(i).getTime(), l = new Date().getTime();
                    console.log(d, "现在：" + c), c == d && u > l && "已过期" === t.reserveStatusStr ? t.iscancle = !1 : (t.iscancle = !0, 
                    n.push(t));
                } else t.iscancle = !1, 1 === t.isRebook && (t.reserveStatusStr = "已改签", t.reserveStatusImg = "../../images/center/yigaiqian.png");
                1 == e.data.isXingchengRemind && (t.iscancle = !0), "已预约" == t.reserveStatusStr && (t.reserveStatusImg = "../../images/center/yiyuyue.png", 
                1 == t.isRebook && (t.reserveStatusStr = "已改签", t.reserveStatusImg = "../../images/center/yigaiqian.png")), 
                "待使用" === t.reserveStatusStr && (t.reserveStatusImg = "../../images/center/daishiyong.png"), 
                "已到馆" === t.reserveStatusStr && (t.reserveStatusImg = "../../images/center/yidaoguan.png"), 
                "已使用" === t.reserveStatusStr && (t.reserveStatusImg = "../../images/center/yishiyong.png"), 
                "已过期" === t.reserveStatusStr && (t.reserveStatusImg = "../../images/center/yiguoqi.png"), 
                "已退票" === t.reserveStatusStr && (t.reserveStatusStr = "已退票", t.reserveStatusImg = "../../images/center/yituipiao.png");
                var m = "canvas" + a;
                (0, r.default)(t.reserveNo, m);
            }), n.length === a.orderPersonalList.length && e.setData({
                isCanCommit: !1,
                isCanGaiqian: !1,
                isbtnhidden: !0,
                isEndorsebtnhidden: !0
            }), 0 == a.orderStatus ? a.reserveStatusStr = "待支付" : 1 == a.orderStatus ? a.reserveStatusStr = "预约成功" : 2 == a.orderStatus ? a.reserveStatusStr = "部分退票" : 3 == a.orderStatus ? a.reserveStatusStr = "已退票" : 4 == a.orderStatus && (a.reserveStatusStr = "支付中"), 
            1 == e.data.isXingchengRemind && e.setData({
                isCanCommit: !1,
                isCanGaiqian: !1,
                isbtnhidden: !0,
                isEndorsebtnhidden: !0
            }), 0 == a.couldRebook && e.setData({
                isEndorsebtnhidden: !0
            }), e.setData({
                model: a,
                memberArr: a.orderPersonalList,
                rebookBtnText: s
            });
        } else if (1 == t.length) {
            (a = t[0].data).museumCanRebook = !0;
            var s = "改签";
            n = [];
            a.orderPersonalList.forEach(function(e, t) {
                e.seleted = !1, "已预约" != e.reserveStatusStr ? (e.iscancle = !0, n.push(e)) : (e.iscancle = !1, 
                1 === e.isRebook && (e.reserveStatusStr = "已改签")), "已取消" === e.reserveStatusStr && (e.reserveStatusStr = "已退票");
                var a = "canvas" + t;
                (0, r.default)(e.reserveNo, a);
            }), n.length === a.orderPersonalList.length && e.setData({
                isCanCommit: !1,
                isCanGaiqian: !1,
                isbtnhidden: !0,
                isEndorsebtnhidden: !0
            }), 0 == a.orderStatus ? a.reserveStatusStr = "待支付" : 1 == a.orderStatus ? a.reserveStatusStr = "预约成功" : 2 == a.orderStatus ? a.reserveStatusStr = "部分退票" : 3 == a.orderStatus ? a.reserveStatusStr = "已退票" : 4 == a.orderStatus && (a.reserveStatusStr = "支付中"), 
            0 == a.couldRebook && e.setData({
                isEndorsebtnhidden: !0
            }), e.setData({
                model: a,
                memberArr: a.orderPersonalList,
                rebookBtnText: s
            });
        } else wx.navigateBack();
    }).catch(function(e) {
        wx.navigateBack();
    });
}

Page({
    data: {
        orderPersonalId: "",
        systemId: "",
        companyInfoId: "",
        rebookBtnText: "改签",
        model: {
            orderNo: "",
            createTime: "",
            reserveDate: "",
            reserveTime: "",
            orderNum: ""
        },
        memberArr: [],
        seletDataArr: [],
        qrcode_w: (0, r.rpx2px)(320),
        isCanCommit: !1,
        isCanGaiqian: !1,
        isbtnhidden: !1,
        isEndorsebtnhidden: !1,
        isXingchengRemind: !1,
        timeStr: "",
        currentNum: 0
    },
    onLoad: function(e) {
        var t = this, r = this;
        r.setData({
            timeStr: n(new Date())
        }), setInterval(function() {
            var e = n(new Date());
            r.setData({
                timeStr: e
            });
        }, 1e3), "true" === e.isXingchengRemind ? e.isXingchengRemind = !0 : e.isXingchengRemind = !1, 
        this.setData({
            orderPersonalId: e.orderPersonalId,
            systemId: getApp().globalData.systemId,
            companyInfoId: getApp().globalData.companyInfoId,
            isXingchengRemind: e.isXingchengRemind
        }), console.log(e), wx.showNavigationBarLoading(), wx.showLoading({
            title: "加载中...",
            mask: !0
        }), "" === getApp().globalData.authorizationc ? getApp().tokenReadyCallback = function(r) {
            200 == r.data.code ? a(t, e.orderPersonalId, e.systemId) : (wx.hideLoading(), console.error("模板消息界面进入时为获取到token"));
        } : a(this, e.orderPersonalId, e.systemId);
    },
    reloadData: function() {
        this.setData({
            isCanCommit: !1,
            isCanGaiqian: !1
        }), a(this, this.data.orderPersonalId, this.data.systemId);
    },
    backHomeBtnClick: function(e) {
        wx.reLaunch({
            url: "../index/index"
        });
    },
    zuojiantouClick: function(e) {
        var t = parseInt(e.currentTarget.dataset.index);
        0 != t && this.setData({
            currentNum: t - 1
        });
    },
    youjiantouClick: function(e) {
        var t = parseInt(e.currentTarget.dataset.index);
        t != this.data.memberArr.length - 1 && this.setData({
            currentNum: t + 1
        });
    },
    membercellClick: function(e) {
        var t = parseInt(e.currentTarget.dataset.index), r = this.data.model.orderPersonalList, a = (this.data.seletDataArr, 
        []), n = [], s = [];
        r.forEach(function(e, r) {
            1 != e.iscancle && (t == r && (0 == e.seleted ? e.seleted = !0 : e.seleted = !1), 
            1 == e.seleted && (1 == e.isRebook && s.push(e.orderPersonalId), a.push(e.orderPersonalId), 
            n.push(e)));
        });
        var o = !1;
        o = 0 != a.length;
        var i = !1;
        i = a.length > 0 && 0 == s.length, this.setData({
            seletDataArr: a,
            rebookCountArr: n,
            memberArr: r,
            isCanCommit: o,
            isCanGaiqian: i
        });
    },
    appointEndorseBtnClick: function(e) {
        var t = this;
        if (0 != this.data.isCanGaiqian) {
            var r = t.data.rebookCountArr.filter(function(e, t) {
                return 1 === e.isRebook;
            }).map(function(e) {
                return e.visitorName;
            });
            if (r.length > 0) wx.showToast({
                title: r.join("、") + "不可重复改签！",
                icon: "none"
            }); else {
                var a = this.data.seletDataArr, n = (this.data.orderListIdStr, t.data.rebookCountArr[0].reserveDate, 
                t.data.rebookCountArr[0].reserveTime, this.data.memberArr.filter(function(e) {
                    return -1 != a.indexOf(e.orderPersonalId);
                }).map(function(e) {
                    return e.visitorName;
                }).join("、"));
                wx.showModal({
                    title: "提示",
                    content: "一次改签机会哦，是否确定改签【".concat(n, "】的票？"),
                    success: function(e) {
                        if (e.confirm) {
                            console.log("用户点击确定");
                            var r = {
                                orderPersonalIds: a,
                                isChangeTime: "YES",
                                companyInfoId: t.data.companyInfoId,
                                intervalDate: t.data.model.reserveDate,
                                intervalValue: t.data.model.reserveTime
                            }, n = JSON.stringify(r);
                            console.log(n), getApp().globalData.companyInfoId = t.data.companyInfoId, wx.requestSubscribeMessage({
                                tmplIds: [ "bLlLAVEAGZdYnJ3xxePGeHzygPpwm4j3TQNNJEX3_BM" ],
                                success: function(e) {
                                    wx.navigateTo({
                                        url: "home?data=" + n
                                    });
                                },
                                fail: function(e) {
                                    wx.navigateTo({
                                        url: "home?data=" + n
                                    });
                                }
                            });
                        } else e.cancel && console.log("用户点击取消");
                    }
                });
            }
        }
    },
    appointBtnClick: function(e) {
        var r = this;
        if (0 != this.data.isCanCommit) {
            var n = this.data.seletDataArr, s = (this.data.orderListIdStr, this.data.memberArr.filter(function(e) {
                return -1 != n.indexOf(e.orderPersonalId);
            }).map(function(e) {
                return e.visitorName;
            }).join("、"));
            wx.showModal({
                title: "提示",
                content: "确定退【".concat(s, "】的票吗？"),
                success: function(e) {
                    e.confirm ? (0, t.updateForCancelPersonal)(n).then(function(e) {
                        200 == e.code ? wx.showModal({
                            title: "提示",
                            content: "退票成功！",
                            showCancel: !1,
                            success: function(e) {
                                e.confirm && (console.log("用户点击确定"), a(r, r.data.orderPersonalId, r.data.systemId));
                            }
                        }) : wx.showToast({
                            title: e.msg,
                            icon: "none"
                        });
                    }).catch(function(e) {
                        wx.showToast({
                            title: "请检查网络",
                            icon: "none"
                        }), console.error("退票失败 " + e);
                    }) : e.cancel && console.log("用户点击取消");
                }
            });
        }
    }
});

var n = function(e) {
    var t = e.getFullYear(), r = e.getMonth() + 1, a = e.getDate(), n = e.getHours(), o = e.getMinutes(), i = e.getSeconds();
    return "".concat([ t, r, a ].map(s).join("/"), " ").concat([ n, o, i ].map(s).join(":"));
}, s = function(e) {
    return (e = e.toString())[1] ? e : "0".concat(e);
};