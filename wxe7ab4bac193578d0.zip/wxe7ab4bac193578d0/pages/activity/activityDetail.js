var t = require("../../@babel/runtime/helpers/interopRequireDefault").default, e = require("../../server/api"), a = require("../../server/http"), i = t(require("../../utils/richTextStyleUtil"));

t(require("./handleActivityState.js"));

Page({
    data: {
        id: "",
        info: {},
        textAndImageArr: [],
        remarkImgAndTextArr: [],
        bottomBarData: {},
        hiddenBaozhangPop: !0
    },
    onLoad: function(t) {
        var n, o, r = JSON.parse(t.data);
        console.log(r), this.setData({
            id: r.id
        }), n = this, o = r.id, (0, e.queryActivityById)(o).then(function(t) {
            if (200 == t.code) {
                var o = t.data, r = new Date().getTime();
                if (null != o.endTime && "" != o.endTime) {
                    var s = new Date(o.startTime.replace(/-/g, "/")).getTime(), p = new Date(o.endTime.replace(/-/g, "/")).getTime();
                    o.totalNum, o.surplusNum, o.activityStatusStr = r < s ? "活动未开始" : r > p ? "活动已结束" : "活动进行中";
                } else {
                    var m = new Date(o.startTime.replace(/-/g, "/")).getTime();
                    o.totalNum, o.surplusNum, o.activityStatusStr = r < m ? "活动未开始" : "活动进行中";
                }
                if (0 == o.reserveType) o.isCanAppoint = !1, o.appointBtnStr = "无须预约"; else if (1 == o.reserveType) {
                    var u = new Date().getTime(), c = new Date(o.reserveStartTime.replace(/-/g, "/")).getTime(), l = new Date(o.reserveEndTime.replace(/-/g, "/")).getTime();
                    u < c ? (o.isCanAppoint = !1, o.appointBtnStr = "报名未开始") : u > l ? (o.isCanAppoint = !1, 
                    o.appointBtnStr = "报名已结束") : o.surplusNum <= 0 ? (o.isCanAppoint = !1, o.appointBtnStr = "预约已满") : (o.isCanAppoint = !0, 
                    o.appointBtnStr = "立即报名");
                }
                null == o.cost || 0 == o.cost ? o.costStr = "免费" : o.costStr = "￥".concat(o.cost);
                var d = {
                    objectId: o.activityId,
                    systemId: o.systemId,
                    objectTitle: o.activityName,
                    objectThumb: o.coverImage,
                    block: "ACTIVITY",
                    subBlock: "2"
                };
                o.thumb = null == o.coverImage ? "../../images/banner.png" : a.api.fileSec + o.coverImage, 
                o.remark = (0, i.default)(o.remark), null === o.endTime || "" === o.endTime ? (o.startTime = o.startTime.substring(0, 16), 
                o.timeLabelStr = o.startTime + " 开始") : (o.startTime = o.startTime.substring(0, 16), 
                o.endTime = o.endTime.substring(0, 16), o.timeLabelStr = o.startTime + "至" + o.endTime), 
                o.reserveStartTime = o.reserveStartTime.substring(0, 16), o.reserveEndTime = o.reserveEndTime.substring(0, 16), 
                1 === o.reserveCancelDeadline ? (o.popBaozhangStr = "不可退订", o.popBaozhangContentStr = "不支持退订。") : 2 === o.reserveCancelDeadline ? (o.popBaozhangStr = "最迟报名截止时间可退", 
                o.popBaozhangContentStr = "最迟退订时间为报名截止时间。如报名截止时间为1月1日18点整，则1月1日晚18点整前均可退订。") : 3 === o.reserveCancelDeadline ? (o.popBaozhangStr = "最迟报名截止时间前1天可退", 
                o.popBaozhangContentStr = "最迟退订时间为报名截止时间前1天的晚24点整。如报名截止时间为1月2日18点整，则1月1日晚24点整前均可退订。") : (o.popBaozhangStr = "联系后台工作人员", 
                o.popBaozhangContentStr = "联系后台工作人员"), o.popBaozhangGaiqianStr = "不支持改签", o.popGaiqianStr = "不支持改签", 
                (0, e.customerFootprint)(d, 2).then(function(t) {}), n.setData({
                    info: o,
                    bottomBarData: d
                });
            } else (0, e.showWarningToast)(t);
        });
    },
    updateLikeNum: function(t) {
        if ("cancel" == t.detail.type) (e = this.data.info).praiseCount--, this.setData({
            info: e
        }); else if ("add" == t.detail.type) {
            var e;
            (e = this.data.info).praiseCount++, this.setData({
                info: e
            });
        }
    },
    updateFavoriteNum: function(t) {
        if ("cancel" == t.detail.type) (e = this.data.info).favoriteCount--, this.setData({
            info: e
        }); else if ("add" == t.detail.type) {
            var e;
            (e = this.data.info).favoriteCount++, this.setData({
                info: e
            });
        }
    },
    appointmentOnTap: function(t) {
        if (this.data.info.isCanAppoint) {
            var e = this.data.info, a = {
                activityId: e.activityId,
                activityName: e.activityName,
                startTime: e.startTime,
                endTime: e.endTime,
                reserveStartTime: e.reserveStartTime,
                reserveEndTime: e.reserveEndTime,
                totalNum: e.totalNum,
                surplusNum: e.surplusNum,
                costStr: e.costStr,
                activityObject: e.activityObject,
                address: e.address,
                place: e.place,
                popBaozhangStr: e.popBaozhangStr,
                popBaozhangContentStr: e.popBaozhangContentStr,
                popBaozhangGaiqianStr: e.popBaozhangGaiqianStr,
                popGaiqianStr: e.popGaiqianStr,
                reserveType: e.reserveType,
                timeLabelStr: e.timeLabelStr,
                systemId: e.systemId,
                companyInfoId: e.companyInfoId,
                systemName: e.systemName,
                companyInfoName: e.companyInfoName,
                reserveTicketLimit: e.reserveTicketLimit
            }, i = JSON.stringify(a);
            if ("" == getApp().globalData.authorizationc) wx.showToast({
                title: "请先登录",
                icon: "none"
            }), wx.navigateTo({
                url: "../login/login?pageUrl=activityAppoint?data_" + i
            }); else {
                wx.requestSubscribeMessage({
                    tmplIds: [ "W8ZdoUIP18WxC3-XP6zSDOEi-7sBHHyCtm3B1uwXYUQ", "T2ZMc0ri_790_L0kUnTVPNE9cpOTJuVZFsRb3JsZKLw", "zintODGCp4lEN-Kfyv3P-onZtc5ebgb9Z2vK67CpC9M" ],
                    success: function(t) {
                        console.log("订阅消息授权正确：" + JSON.stringify(t)), wx.navigateTo({
                            url: "activityAppoint?data=" + i
                        });
                    },
                    fail: function(t) {
                        console.log("订阅消息授权错误信息" + JSON.stringify(t)), wx.navigateTo({
                            url: "activityAppoint?data=" + i
                        });
                    }
                });
            }
        }
    },
    securityClick: function() {
        this.setData({
            hiddenBaozhangPop: !1
        });
    },
    baozhangCloseImgClick: function() {
        this.setData({
            hiddenBaozhangPop: !0
        });
    },
    openMuseum: function() {
        var t = {
            id: this.data.info.companyInfoId
        };
        (0, e.queryVenueById)(this.data.info.companyInfoId).then(function(e) {
            200 == e.code ? null == e.data ? wx.showModal({
                title: "提示",
                content: "场馆信息未开放",
                showCancel: !1,
                success: function(t) {
                    t.confirm;
                }
            }) : wx.navigateTo({
                url: "../museum/museumDetail?data=" + JSON.stringify(t)
            }) : wx.showModal({
                title: "提示",
                content: "场馆信息未开放",
                showCancel: !1,
                success: function(t) {
                    t.confirm;
                }
            });
        });
    },
    openMap: function() {
        null != this.data.info.latitude && "" != this.data.info.latitude && "" != this.data.info.longitude && null != this.data.info.longitude && wx.openLocation({
            latitude: Number(this.data.info.latitude),
            longitude: Number(this.data.info.longitude),
            name: this.data.info.systemName
        });
    }
});