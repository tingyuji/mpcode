var t = require("../../server/api"), e = (require("../contacts/static"), require("../../utils/subscribeMessage"));

function a(e) {
    (0, t.customerContactQueryPageList)().then(function(t) {
        if (200 == t.code) if (t.data.records.length > 0) {
            var a = t.data.records, n = !1, o = [];
            a.forEach(function(t, e) {
                1 == t.myself && (n = !0, o.push(t));
            }), !1 === n && wx.showModal({
                title: "提示",
                content: "请先进行实名认证",
                cancelColor: "",
                showCancel: !0,
                success: function(t) {
                    t.confirm && wx.navigateTo({
                        url: "../contacts/realNameCertification"
                    });
                }
            }), e.setData({
                selectedContactsArr: o,
                isHasSelf: n
            });
        } else wx.showModal({
            title: "提示",
            content: "请先进行实名认证",
            cancelColor: "",
            showCancel: !0,
            success: function(t) {
                t.confirm && wx.navigateTo({
                    url: "../contacts/realNameCertification"
                });
            }
        }); else wx.showToast({
            title: t.msg,
            icon: "none"
        });
    }).catch(function(t) {
        console.error("获取联系人失败" + t);
    });
}

Page({
    data: {
        model: {},
        ticketsList: [],
        reserveDateStr: "",
        selectedContactsArr: [],
        hiddenBaozhangPop: !0,
        maxCount: 3,
        isCanCommit: !0,
        isHasSelf: !1
    },
    onLoad: function(t) {
        var e = JSON.parse(t.data);
        this.setData({
            model: e,
            maxCount: e.reserveTicketLimit
        }), a(this);
    },
    onShow: function() {},
    reloadContactsData: function() {
        a(this);
    },
    securityClick: function() {
        this.setData({
            hiddenBaozhangPop: !1
        });
    },
    baozhangCloseImgClick: function() {
        this.setData({
            hiddenBaozhangPop: !0
        });
    },
    addContactsBtnClick: function(t) {
        if (0 == this.data.isHasSelf) wx.showModal({
            title: "提示",
            content: "请先进行实名认证",
            cancelColor: "",
            showCancel: !0,
            success: function(t) {
                t.confirm && wx.navigateTo({
                    url: "../contacts/realNameCertification"
                });
            }
        }); else {
            var e = {
                maxCount: this.data.maxCount,
                seletDataArr: this.data.selectedContactsArr,
                isExhibitionChoose: !1
            }, a = JSON.stringify(e);
            wx.navigateTo({
                url: "../contacts/selectContacts?data=" + a
            });
        }
    },
    deleteBtnClick: function(t) {
        console.log("删除按钮点击" + JSON.stringify(t.target.dataset.value));
        var e = t.target.dataset.value, a = this.data.selectedContactsArr;
        a.splice(e, 1), this.setData({
            selectedContactsArr: a
        });
    },
    openMuseum: function() {
        var e = {
            id: this.data.model.companyInfoId
        };
        (0, t.queryVenueById)(this.data.model.companyInfoId).then(function(t) {
            200 == t.code ? null == t.data ? wx.showModal({
                title: "提示",
                content: "场馆信息未开放",
                showCancel: !1,
                success: function(t) {
                    t.confirm;
                }
            }) : wx.navigateTo({
                url: "../museum/museumDetail?data=" + JSON.stringify(e)
            }) : wx.showModal({
                title: "提示",
                content: "场馆信息未开放",
                showCancel: !1,
                success: function(t) {
                    t.confirm;
                }
            });
        });
    },
    detailBtnViewClick: function(t) {
        wx.navigateBack();
    },
    reserveDatePickerChange: function(t) {
        var e = t.detail.value, a = this.data.ticketsList[e].ticketDate;
        this.setData({
            reserveDateStr: a
        });
    },
    appointBtnClick: function(t) {
        var a = this, n = this;
        0 != n.data.selectedContactsArr.length ? (0, e.requestActivitySubscribeMessage)().then(function() {
            a.commit(n);
        }).catch(function() {
            a.commit(n);
        }) : wx.showToast({
            title: "请选择联系人",
            icon: "none"
        });
    },
    commit: function(e) {
        wx.showLoading({
            title: "提交中...",
            mask: !0
        }), (0, t.sureForSubmitActivity)(this.data.model.activityId).then(function(t) {
            wx.hideLoading(), 200 == t.code ? wx.showToast({
                title: "提交成功",
                icon: "success",
                duration: 2e3,
                success: function() {
                    var t = e.data.model;
                    t.seletDataArr = e.data.selectedContactsArr;
                    var a = JSON.stringify(t);
                    wx.navigateTo({
                        url: "activitySureOrder?data=" + a
                    });
                }
            }) : wx.showToast({
                title: t.msg,
                icon: "none",
                duration: 4e3
            });
        }).catch(function(t) {
            wx.hideLoading(), wx.showToast({
                title: "提交失败，服务器错误",
                icon: "none"
            }), console.error("活动预约失败" + t);
        });
    }
});