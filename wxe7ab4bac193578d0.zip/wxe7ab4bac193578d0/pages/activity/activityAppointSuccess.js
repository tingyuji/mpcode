Page({
    data: {
        info: {},
        tips: "",
        startTime: "",
        endTime: "",
        visitorNum: 0,
        needPay: !1,
        isXinhai: !0
    },
    onLoad: function(t) {
        var i = JSON.parse(t.data), n = this;
        this.getOpenerEventChannel().on("acceptDataFromOpenerPage", function(t) {
            n.setData({
                tips: t.tips
            });
        }), i.startTime = i.startTime.substring(0, 16), i.endTime = i.endTime.substring(0, 16), 
        this.setData({
            info: i,
            startTime: i.startTime,
            endTime: i.endTime,
            needPay: i.needPay,
            visitorNum: i.orderNum
        }), "黄埔军校旧址纪念馆" == getApp().globalData.MuseumName && this.setData({
            isXinhai: !1
        });
    },
    detailbtnClick: function(t) {
        wx.redirectTo({
            url: "../activity/activityAppointDetail?orderListId=" + this.data.info.orderListId
        });
    },
    backbtnClick: function(t) {
        wx.navigateBack({
            delta: 4
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});