getApp();

var t = require("../../server/api.js"), e = t.activityQueryOrderDetail, a = t.activityQueryOrderCancle, i = t.queryActivityById, n = t.queryVenueById, r = require("../../utils/qrCode.js"), o = r.showLogoQRCode, s = r.showQRCode, d = wx.getSystemInfoSync().windowWidth;

function c(t, a) {
    console.log("活动id" + a), wx.showLoading({
        title: "加载中...",
        mask: !0
    }), e(a).then(function(e) {
        if (wx.hideLoading(), 200 == e.code) {
            console.log(e);
            var a = e.data;
            if (1 === a.activity.reserveCancelDeadline ? (a.popBaozhangStr = "不可退订", a.popBaozhangContentStr = "不支持退订。") : 2 === a.activity.reserveCancelDeadline ? (a.popBaozhangStr = "最迟报名截止时间可退", 
            a.popBaozhangContentStr = "最迟退订时间为报名截止时间。如报名截止时间为1月1日18点整，则1月1日晚18点整前均可退订。") : 3 === a.activity.reserveCancelDeadline ? (a.popBaozhangStr = "最迟报名截止时间前1天可退", 
            a.popBaozhangContentStr = "最迟退订时间为报名截止时间前1天的晚24点整。如报名截止时间为1月2日18点整，则1月1日晚24点整前均可退订。") : (a.popBaozhangStr = "联系后台工作人员", 
            a.popBaozhangContentStr = "联系后台工作人员"), a.popBaozhangGaiqianStr = "不支持改签", a.popGaiqianStr = "不支持改签", 
            3 == a.activity.reserveType ? a.coststr = "￥" + a.orderCost : a.coststr = "免费", 
            null === a.activity.endTime || "" === a.activity.endTime ? (a.activity.startTime = a.activity.startTime.substring(0, 16), 
            a.activity.timeLabelStr = a.activity.startTime + " 开始") : (a.activity.startTime = a.activity.startTime.substring(0, 16), 
            a.activity.endTime = a.activity.endTime.substring(0, 16), a.activity.timeLabelStr = a.activity.startTime + "至" + a.activity.endTime), 
            a.activity.reserveStartTime = a.activity.reserveStartTime.substring(0, 16), a.activity.reserveEndTime = a.activity.reserveEndTime.substring(0, 16), 
            0 === a.orderStatus || 4 === a.orderStatus) {
                if (a.cancleBtnHiddle = !1, "支付中" === a.orderStatusStr && 4 === a.orderStatus && "预约成功" != a.orderStatusStr) {
                    var i = a.expireTime.replace(/-/g, "/"), n = a.createTime.replace(/-/g, "/"), r = [];
                    [ {
                        actEndTime: i
                    } ].forEach(function(t) {
                        r.push(t.actEndTime);
                    }), t.setData({
                        actEndTimeList: r,
                        actcreateTimeStr: n
                    }), t.countDown();
                }
            } else 1 === a.orderStatus || 2 === a.orderStatus ? a.cancleBtnHiddle = !1 : a.cancleBtnHiddle = !0;
            var d = [];
            a.orderActivityList.forEach(function(e, i) {
                console.log(e), e.seleted = !1, -1 == e.reserveStatus ? (e.stateBtnStr = "支 付", 
                e.stateBtnHiddle = !0) : "已预约" == e.reserveStatusStr ? (e.reserveStatusImg = "../../images/center/yiyuyue.png", 
                e.stateBtnStr = "取 消", e.stateBtnHiddle = !1) : "待使用" == e.reserveStatusStr ? (e.stateBtnStr = "", 
                e.stateBtnHiddle = !0, e.reserveStatusImg = "../../images/center/daishiyong.png") : "已过期" == e.reserveStatusStr ? (e.stateBtnStr = "", 
                e.stateBtnHiddle = !0, e.reserveStatusImg = "../../images/center/yiguoqi.png") : "已取消" == e.reserveStatusStr ? (e.stateBtnStr = "", 
                e.stateBtnHiddle = !0, e.reserveStatusImg = "../../images/center/yiquxiao.png") : "已签到" == e.reserveStatusStr ? (e.stateBtnStr = "", 
                e.stateBtnHiddle = !0, e.reserveStatusImg = "../../images/center/yiqiandao2.png") : "已使用" == e.reserveStatusStr && (e.stateBtnStr = "", 
                e.stateBtnHiddle = !0, e.reserveStatusImg = "../../images/center/yishiyong.png"), 
                1 == t.data.isXingchengRemind && (e.stateBtnHiddle = !0);
                var n = "canvas" + i;
                "黄埔军校旧址纪念馆" == a.systemName ? o(e.reserveNo, n) : s(e.reserveNo, n), d.push(e);
            }), 1 == t.data.isXingchengRemind && (a.cancleBtnHiddle = !0), t.setData({
                model: a,
                orderStatusStr: a.orderStatusStr,
                hideProgress: !0,
                isCanCommit: !1,
                memberArr: d
            });
        } else wx.showToast({
            title: e.msg
        });
    }).catch(function(t) {
        wx.hideLoading();
    });
}

Page({
    data: {
        orderId: "",
        model: {},
        memberArr: [],
        qrcode_w: 320 / (750 / d),
        hideProgress: !1,
        actEndTimeList: [],
        actcreateTimeStr: "",
        orderStatusStr: "",
        surebtnStr: "",
        seletDataArr: [],
        isCanCommit: !1,
        hiddenBaozhangPop: !0,
        isXingchengRemind: !1
    },
    onLoad: function(t) {
        "true" === t.isXingchengRemind ? t.isXingchengRemind = !0 : t.isXingchengRemind = !1, 
        !0, this.setData({
            hideProgress: !1,
            orderId: t.orderListId,
            isXingchengRemind: t.isXingchengRemind
        }), c(this, t.orderListId);
    },
    paybtnclick: function(t) {
        var e, a, i;
        e = this, a = getApp().globalData.serviceURL + "/activityReserve/saveForWeChatPay", 
        i = {
            orderId: e.data.orderId,
            tradeType: "JSAPI",
            payFrom: 2,
            orderTitle: e.data.model.ruleVo.title
        }, getApp().httpPost(a, i, function(t) {
            console.log("saveForWeChatPay", t), 200 == t.data.code ? "" != t.data.data.prepay_id && function(t, e) {
                var a = getApp().globalData.serviceURL + "/activityReserve/getWeChatPayPrepare", i = {
                    prepayId: e,
                    tradeType: "JSAPI",
                    payFrom: 2
                };
                getApp().httpPost(a, i, function(e) {
                    console.log("getWeChatPayPrepare", e), null != e.data.data && wx.requestPayment({
                        timeStamp: e.data.data.timeStamp,
                        nonceStr: e.data.data.nonceStr,
                        package: e.data.data.package,
                        signType: e.data.data.signType,
                        paySign: e.data.data.paySign,
                        success: function(e) {
                            c(t, t.data.orderId), wx.showToast({
                                title: "支付成功",
                                icon: "none"
                            });
                        },
                        fail: function(t) {
                            console.error("请确保微信支付已开通320" + t);
                        },
                        complete: function(t) {}
                    });
                }, function(t) {
                    console.error("请确保微信支付已开通326" + t), wx.showToast({
                        title: "请确保微信支付已开通",
                        icon: "none"
                    });
                });
            }(e, t.data.data.prepay_id) : wx.showToast({
                title: "订单已超时",
                icon: "none"
            });
        }, function(t) {
            console.error("请确保微信支付已开通284" + t), wx.showToast({
                title: "网络错误",
                icon: "none"
            });
        });
    },
    securityClick: function() {
        this.setData({
            hiddenBaozhangPop: !1
        });
    },
    baozhangCloseImgClick: function() {
        this.setData({
            hiddenBaozhangPop: !0
        });
    },
    activityTitleClick: function(t) {
        var e = {
            id: this.data.model.activityId,
            tenantId: this.data.model.systemId
        }, a = JSON.stringify(e);
        i(this.data.model.activityId).then(function(t) {
            200 == t.code ? null == t.data ? wx.showModal({
                title: "提示",
                content: "活动已下架",
                showCancel: !1,
                success: function(t) {
                    t.confirm;
                }
            }) : wx.redirectTo({
                url: "../activity/activityDetail?data=" + a
            }) : showWarningToast(t);
        });
    },
    openMuseum: function() {
        var t = {
            id: this.data.model.companyInfoId,
            tenantId: this.data.model.systemId
        };
        n(this.data.model.companyInfoId).then(function(e) {
            200 == e.code ? null == e.data ? wx.showModal({
                title: "提示",
                content: "场馆信息未开放",
                showCancel: !1,
                success: function(t) {
                    t.confirm;
                }
            }) : wx.navigateTo({
                url: "../museum/museumDetail?data=" + JSON.stringify(t)
            }) : wx.showModal({
                title: "提示",
                content: "场馆信息未开放",
                showCancel: !1,
                success: function(t) {
                    t.confirm;
                }
            });
        });
    },
    tuidingBtnClick: function(t) {
        var e = this;
        if (0 != this.data.isCanCommit) {
            var i = this.data.seletDataArr;
            wx.showModal({
                title: "提示",
                content: "确定取消预约吗？",
                success: function(t) {
                    if (t.confirm) {
                        if (console.log("用户点击确定"), null != e.data.model.isAdditional && 1 === e.data.model.isAdditional) {
                            var n = [];
                            e.data.model.orderActivityList.forEach(function(t, e) {
                                console.log("亲子活动取消" + JSON.stringify(t)), n.push(t.orderActivityId);
                            }), i = n;
                        }
                        a(i).then(function(t) {
                            wx.hideLoading(), 200 == t.code ? wx.showModal({
                                title: "提示",
                                content: "取消成功！",
                                showCancel: !1,
                                success: function(t) {
                                    t.confirm && (console.log("用户点击确定"), c(e, e.data.orderId));
                                }
                            }) : wx.showToast({
                                title: t.msg,
                                duration: 2e3,
                                icon: "none"
                            });
                        }).catch(function(t) {
                            wx.hideLoading();
                        }), e.setData({
                            hideProgress: !1
                        });
                    } else t.cancel && (e.setData({
                        hideProgress: !0
                    }), console.log("用户点击取消"));
                }
            });
        }
    },
    orderListClick: function(t) {
        var e = parseInt(t.currentTarget.dataset.index), a = this.data.model.orderActivityList, i = (this.data.seletDataArr, 
        []), n = [];
        a.forEach(function(t, a) {
            1 != t.iscancle && 2 != t.reserveStatus && (e == a && (0 == t.seleted ? t.seleted = !0 : t.seleted = !1), 
            1 == t.seleted && (i.push(t.orderActivityId), n.push(t)));
        });
        var r = !1;
        r = !(i.length <= 0);
        var o = this.data.model;
        o.orderActivityList = a, this.setData({
            seletDataArr: i,
            rebookCountArr: n,
            model: o,
            isCanCommit: r
        });
    },
    onReady: function() {},
    onShow: function() {},
    onPullDownRefresh: function() {},
    timeFormat: function(t) {
        return t < 10 ? "0" + t : t;
    },
    onUnload: function() {
        clearInterval(this.countDown);
    },
    countDown: function() {
        var t = this, e = new Date().getTime(), a = this.data.actEndTimeList, i = {}, n = this;
        a.forEach(function(a) {
            var r = new Date(a).getTime(), o = null;
            if (r - e > 0) {
                var s = (r - e) / 1e3, d = parseInt(s / 86400), l = parseInt(s % 86400 / 3600), u = parseInt(s % 86400 % 3600 / 60), m = parseInt(s % 86400 % 3600 % 60);
                o = {
                    day: t.timeFormat(d),
                    hou: t.timeFormat(l),
                    min: t.timeFormat(u),
                    sec: t.timeFormat(m)
                };
            } else 4 === n.data.model.orderStatus && c(n, n.data.orderId), o = {
                day: "00",
                hou: "00",
                min: "00",
                sec: "00"
            };
            i = o;
        }), 4 === n.data.model.orderStatus && n.setData({
            orderStatusStr: "支付中（付款倒计时:" + i.hou + "时" + i.min + "分" + i.sec + "秒）"
        }), setTimeout(n.countDown, 1e3);
    }
});