var t = require("../../server/api");

function a(a) {
    a.setData({
        captchaInputStr: ""
    }), (0, t.activityQueryImgCode)().then(function(t) {
        if (200 == t.code) {
            var n = t.data.replace(/[\r\n]/g, "");
            a.setData({
                captchaImgBase64: n
            });
        } else wx.showToast({
            title: t.msg,
            icon: "none"
        });
    }).catch(function(t) {
        wx.showToast({
            title: "获取验证码失败",
            icon: "none"
        }), console.error("获取验证码失败" + t);
    });
}

Page({
    data: {
        model: {},
        actEndTimeList: [],
        orderStatusStr: "免费",
        orderCost: "",
        payBtnStr: "",
        hidenPayBtn: !1,
        hiddenBaozhangPop: !0,
        captchaImgBase64: "",
        captchaInputStr: ""
    },
    onLoad: function(t) {
        var a = JSON.parse(t.data);
        this.setData({
            model: a
        });
    },
    securityClick: function() {
        this.setData({
            hiddenBaozhangPop: !1
        });
    },
    baozhangCloseImgClick: function() {
        this.setData({
            hiddenBaozhangPop: !0
        });
    },
    openMuseum: function() {
        var a = {
            id: this.data.model.companyInfoId
        };
        (0, t.queryVenueById)(this.data.model.companyInfoId).then(function(t) {
            200 == t.code ? null == t.data ? wx.showModal({
                title: "提示",
                content: "场馆信息未开放",
                showCancel: !1,
                success: function(t) {
                    t.confirm;
                }
            }) : wx.navigateTo({
                url: "../museum/museumDetail?data=" + JSON.stringify(a)
            }) : wx.showModal({
                title: "提示",
                content: "场馆信息未开放",
                showCancel: !1,
                success: function(t) {
                    t.confirm;
                }
            });
        });
    },
    onReady: function() {},
    onShow: function() {
        a(this);
    },
    captchaClick: function(t) {
        a(this);
    },
    captchaCodeInput: function(t) {
        var a = t.detail.value;
        this.setData({
            captchaInputStr: a
        });
    },
    payBtnClick: function(n) {
        var e = this;
        if (0 != this.data.captchaInputStr.length) {
            wx.showLoading({
                title: "加载中...",
                mask: !0
            });
            var o = this.data.model, i = [];
            this.data.model.seletDataArr.forEach(function(t, a) {
                i.push(t.customerContactId);
            }), (0, t.saveForSubmitActivity)(this.data.model.activityId, i, this.data.captchaInputStr).then(function(t) {
                if (200 == t.code) {
                    wx.showToast({
                        title: "确认成功",
                        icon: "success"
                    });
                    o.timeLabelStr;
                    var n = {
                        needPay: !1,
                        orderListId: t.data.orderListId,
                        orderNum: t.data.orderNum,
                        startTime: t.data.activity.startTime,
                        endTime: t.data.activity.endTime
                    }, i = JSON.stringify(n), c = t.data.activity.attention;
                    wx.navigateTo({
                        url: "activityAppointSuccess?data=" + i,
                        success: function(t) {
                            t.eventChannel.emit("acceptDataFromOpenerPage", {
                                tips: c
                            });
                        }
                    });
                } else a(e), wx.hideLoading({}), wx.showModal({
                    title: "确认失败",
                    content: t.msg,
                    showCancel: !1
                });
            });
        } else wx.showToast({
            title: "请先完成验证码验证",
            icon: "none"
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});