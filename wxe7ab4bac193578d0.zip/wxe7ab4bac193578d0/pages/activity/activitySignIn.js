var t = require("../../@babel/runtime/helpers/interopRequireWildcard").default, e = require("../../server/api"), i = t(require("../../utils/qrCode")), a = "";

function s(t) {
    (0, e.queryOrderActivityList)(a).then(function(a) {
        if (200 == a.code) {
            null != a.data.activity.cost && "" != a.data.activity.cost || (a.data.activity.cost = 0);
            var s = a.data.list, r = [], n = [], c = [];
            s.forEach(function(t, e) {
                t.seleteimgviewHidden = !0, "已预约" == t.reserveStatusStr ? t.reserveStatusImg = "../../images/center/yiyuyue.png" : "检票中" == t.reserveStatusStr ? (t.seleteimgviewHidden = !1, 
                t.reserveStatusImg = "../../images/center/jianpiaozhongguan.png") : "待使用" == t.reserveStatusStr ? (t.seleteimgviewHidden = !1, 
                t.reserveStatusImg = "../../images/center/daishiyong.png") : "已签到" == t.reserveStatusStr ? t.reserveStatusImg = "../../images/center/yiqiandao.png" : "已使用" == t.reserveStatusStr ? t.reserveStatusImg = "../../images/center/yishiyong.png" : "已过期" == t.reserveStatusStr ? (t.reserveStatus = -2, 
                t.reserveStatusImg = "../../images/center/yiguoqi.png") : "已取消" == t.reserveStatusStr ? t.reserveStatusImg = "../../images/center/yituiding.png" : "未开始" == t.reserveStatusStr && (t.reserveStatus = -2, 
                t.reserveStatusImg = "../../images/center/weikaishiguan.png"), "已过期" == t.reserveStatusStr && c.push(t), 
                n.push(t), 0 === t.reserveStatus && r.push(t);
            }), c.length == n.length && t.setData({
                isbtnhidden: !0
            });
            var d = a.data.activity;
            null === d.endTime || "" === d.endTime ? (d.startTime = d.startTime.substring(0, 16), 
            d.timeLabelStr = d.startTime + " 开始") : (d.startTime = d.startTime.substring(0, 16), 
            d.endTime = d.endTime.substring(0, 16), d.timeLabelStr = d.startTime + "至" + d.endTime), 
            t.setData({
                activity: a.data.activity,
                list: n
            }), a.data.list.length > 0 ? a.data.list.forEach(function(t, e) {
                (0, i.default)(t.reserveNo, "canvas".concat(e), 300);
            }) : wx.showModal({
                title: "提示",
                content: "未预约当前活动",
                showCancel: !1,
                success: function(t) {
                    t.confirm && wx.navigateBack();
                }
            });
        } else (0, e.showWarningToast)(a, "活动签到失败");
    }).catch(function(t) {
        (0, e.defaultCatch)(t, "活动签到异常");
    });
}

Page({
    data: {
        checkedIds: [],
        activity: {},
        list: [],
        qrcode_w: (0, i.rpx2px)(300)
    },
    onLoad: function(t) {
        a = t.activityId, s(this);
    },
    activityTitleClick: function(t) {
        var e = {
            id: this.data.activity.activityId,
            tenantId: this.data.activity.systemId
        }, i = JSON.stringify(e);
        wx.redirectTo({
            url: "../activity/activityDetail?data=" + i
        });
    },
    radioTap: function(t) {
        var e = t.currentTarget.dataset.index, i = this.data.list;
        if (0 == i[e].reserveStatus) {
            var a = this.data.checkedIds;
            i[e].checked = !i[e].checked;
            var s = a.indexOf(i[e].orderActivityId);
            i[e].checked && -1 == s ? a.push(i[e].orderActivityId) : i[e].checked || -1 == s || a.splice(s, 1), 
            this.setData({
                list: i,
                checkedIds: a
            });
        }
    },
    btnClick: function() {
        var t = this;
        (0, e.activitySignIn)(this.data.checkedIds).then(function(e) {
            200 == e.code && (t.setData({
                checkedIds: []
            }), wx.showModal({
                title: "提示",
                content: "签到成功",
                showCancel: !1,
                success: function(e) {
                    e.confirm && (console.log("用户点击确定"), s(t));
                }
            }));
        }).catch(function(t) {
            (0, e.defaultCatch)(t, "签到异常");
        });
    }
});