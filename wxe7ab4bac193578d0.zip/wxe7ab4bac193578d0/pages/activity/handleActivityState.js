Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = function(e) {
    if (0 == e.reserveType) e.isCanAppoint = !1, e.appointBtnStr = "无须预约"; else if (1 == e.reserveType) {
        var t = new Date().getTime(), r = new Date(e.reserveStartTime.replace(/-/g, "/")).getTime(), n = new Date(e.reserveEndTime.replace(/-/g, "/")).getTime();
        t < r ? (e.isCanAppoint = !1, e.appointBtnStr = "报名未开始") : t > n ? (e.isCanAppoint = !1, 
        e.appointBtnStr = "报名已结束") : e.surplusNum <= 0 ? (e.isCanAppoint = !1, e.appointBtnStr = "预约已满") : (e.isCanAppoint = !0, 
        e.appointBtnStr = "立即报名");
    }
    null == e.cost || 0 == e.cost ? e.costStr = "免费" : e.costStr = "￥".concat(e.cost);
    return e;
};

require("../../server/api"), require("../../server/http");