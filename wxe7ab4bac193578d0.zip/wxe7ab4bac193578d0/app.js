var e = require("@babel/runtime/helpers/regeneratorRuntime"), a = require("@babel/runtime/helpers/asyncToGenerator"), n = require("./server/api");

App({
    globalData: {
        openId: "",
        openIdType: 4,
        systemId: "18905b1ea600401c945a99734f828076",
        MuseumName: "中国人民革命军事博物馆 ",
        companyInfoId: "dd0c80d657a8920b4629e2677b783f94",
        userInfo: null,
        authorizationc: "",
        location: {},
        userIcon: "",
        homeToIndex: 999,
        ruleData: {},
        userFirstUseCamera: !0,
        userImagePath: "",
        isShenHe: !0,
        baiDuApiUrl1: "",
        baiDuApiUrl2: "",
        faceUrl: "",
        hasLoadFaceUrl: !1,
        personalReserveRule: null
    },
    tokenReadyCallback: null,
    tokenFailedCallback: null,
    onLaunch: function() {
        var e = this;
        this.userLogin().then(function(a) {
            null != e.tokenReadyCallback && e.tokenReadyCallback(a);
        }).catch(function(a) {
            null != e.tokenFailedCallback && e.tokenFailedCallback();
        });
        var a = wx.getUpdateManager();
        a.onCheckForUpdate(function(e) {
            console.log(e.hasUpdate);
        }), a.onUpdateReady(function() {
            a.applyUpdate();
        }), a.onUpdateFailed(function() {});
    },
    userLogin: function() {
        var o = this;
        return a(e().mark(function a() {
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.abrupt("return", new Promise(function(e, a) {
                        wx.login().then(function(r) {
                            r.code ? (0, n.login)(r.code).then(function(n) {
                                if (200 == n.code) o.globalData.authorizationc = n.data.authorizationc, o.globalData.openId = n.data.openid, 
                                e(n); else if (100 == n.code) {
                                    e(n);
                                    var r = JSON.parse(n.msg);
                                    o.globalData.openId = r.openid, o.globalData.openIdType = r.openIdType;
                                } else console.error("系统异常", n.msg), a("系统异常" + n.msg);
                            }).catch(function(e) {
                                console.error("登录失败，接口请求失败", e), a("网络异常，请检查网络并下拉刷新");
                            }) : (a("微信登录异常，" + r.errMsg), console.error("微信登录异常", r.errMsg));
                        });
                    }));

                  case 1:
                  case "end":
                    return e.stop();
                }
            }, a);
        }))();
    }
});