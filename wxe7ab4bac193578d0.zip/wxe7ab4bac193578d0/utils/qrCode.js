var e = require("../@babel/runtime/helpers/interopRequireDefault").default;

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = function(e, r) {
    var i = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 320, l = o(i);
    new t.default(r, {
        text: e,
        width: l,
        height: l,
        colorDark: "#000000",
        colorLight: "white",
        correctLevel: t.default.CorrectLevel.H
    });
}, exports.rpx2px = o;

var t = e(require("./weapp-qrcode")), r = 750 / wx.getSystemInfoSync().windowWidth;

function o() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 320;
    return e / r;
}