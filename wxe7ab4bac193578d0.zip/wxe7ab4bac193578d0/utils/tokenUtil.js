Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.appId = void 0, exports.default = function() {
    var e = "QV5Q22NC-O0AIEOP3-HUK132ID-7KNG1OFQ".replace(/-/g, ""), r = new Date().getTime().toString(), n = function() {
        for (var t = "", e = 0; e < 6; e++) {
            t += Math.floor(10 * Math.random());
        }
        return t;
    }() + r;
    return function(e, r) {
        return t.AES.encrypt(r, t.enc.Utf8.parse(e), {
            mode: t.mode.ECB,
            padding: t.pad.Pkcs7
        }).toString();
    }(e, n);
}, exports.getAgeByCard = function(t) {
    var e = "";
    18 == (t + "").length && (e = t.substr(6, 4) + "/" + t.substr(10, 2) + "/" + t.substr(12, 2));
    var r = new Date(e), n = new Date(), o = n.getFullYear() - r.getFullYear();
    (n.getMonth() < r.getMonth() || n.getMonth() == r.getMonth() && n.getDate() < r.getDate()) && o--;
    return o;
}, exports.hideCardNum = function(t) {
    if (idCardNoUtil.checkIdCardNo(t)) return t.substring(0, 2) + "************" + t.substring(14);
    if (t.length >= 6) {
        for (var e = "", r = 0; r < t.length - 4; r++) e += "*";
        return t.substring(0, 2) + e + t.substring(t.length - 2);
    }
    return t;
}, exports.hidePhoneNum = function(t) {
    return 11 == t.length ? t.substring(0, 3) + "****" + t.substring(7) : t;
};

var t = require("crypto-js");

exports.appId = "23c4bdfb0a724655b016cbc2267a3be7";