function e(e, o) {
    return new Promise(function(s, i) {
        wx.requestSubscribeMessage({
            tmplIds: e,
            success: function(e) {
                s(e), n(o), console.log("订阅消息授权正确，" + JSON.stringify(e));
            },
            fail: function(e) {
                i(e), n(o), console.log("订阅消息授权错误信息，" + JSON.stringify(e));
            }
        });
    });
}

function n(e) {
    null != e && wx.navigateTo({
        url: e
    });
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.requestPersonSubscribeMessage = function() {
    var n = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null;
    return e([ "UpmZRKeoYzgIJQhloifP-62fUDX5DdYGLAQUAhbhAig", "CipTnZpflvHUL-ylhwLDEiLmUUHZ8sLmjf_V5rwOg_I", "YZFIIK5-6oktV2vGVaZ_1Eob4Co5_-mbEXi_TKPSsEk" ], n);
}, exports.requestTeamSubscribeMessage = function() {
    var n = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null;
    return e([ "2TmmuaUlsRoGX6MGCJWkINecP302DGXcp4kai8n9-RI", "X6NB90Fo6cP4eaLrFrgIJxQQsZ-NScpOAik2n-ZUcko", "O9F2_w1pzLoQE4coVSjudQ2VqMh3VP62d2BDO5spfRc" ], n);
};