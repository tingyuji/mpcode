Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.back = function() {
    var n = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null;
    wx.navigateBack({
        success: function() {
            null != n && "" != n && o(n);
        }
    });
}, exports.backAndReload = function() {
    var n = getCurrentPages(), t = n[n.length - 2];
    wx.navigateBack({
        success: function() {
            null != t.reloadData && t.reloadData();
        }
    });
}, exports.findLastIndex = function(n, t) {
    var e = -1;
    return n.map(function(n, o) {
        t(n) && (e = o);
    }), e;
}, exports.formatDate = function(n) {
    var t = new Date(n.replace(/-/g, "/"));
    return "".concat(t.getFullYear(), "年").concat(t.getMonth() + 1, "月").concat(t.getDate(), "日 ").concat(e(t));
}, exports.formatTimeInterval = function(n, t) {
    if (console.log(n, t), n.length < 16 || t.length < 16) return void console.error("格式化日期区间错误");
    var e = n.substring(0, 10), o = t.substring(0, 10);
    if (e == o) return n.substring(0, 16) + "-" + t.substring(11, 16);
    if (e != o) return n.substring(0, 16) + "~" + t.substring(0, 16);
}, exports.getAgeFromIDCard = function(n) {
    if (t.checkIdCardNo(n)) {
        var e = parseInt(n.substr(6, 4));
        return new Date().getFullYear() - e;
    }
    return -1;
}, exports.getNavigationBarHeight = function() {
    var n = wx.getMenuButtonBoundingClientRect ? wx.getMenuButtonBoundingClientRect() : null;
    return 8 + (null != n ? n.bottom : 0);
}, exports.getWeekStr = e, exports.hideCardNum = function(n) {
    if (t.checkIdCardNo(n)) return n.substring(0, 2) + "************" + n.substring(14);
    if (n.length >= 6) {
        for (var e = "", o = 0; o < n.length - 4; o++) e += "*";
        return n.substring(0, 2) + e + n.substring(n.length - 2);
    }
    return n;
}, exports.hideLoading = function() {
    wx.hideLoading();
}, exports.hidePhoneNum = function(n) {
    return 11 == n.length ? n.substring(0, 3) + "****" + n.substring(7) : n;
}, exports.modal = r, exports.modalWithCancel = function(n) {
    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : void 0;
    wx.showModal({
        content: n,
        showCancel: !0,
        success: function(n) {
            n.confirm && null != t ? t() : n.cancel;
        }
    });
}, exports.navigateTo = function(n) {
    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : void 0, e = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : void 0, o = "";
    null != t && (o = "?" + Object.keys(t).map(function(n) {
        return "".concat(n, "=").concat(null != t[n] && -1 != t[n].toString().indexOf("&") ? encodeURIComponent(t[n]) : t[n]);
    }).join("&"));
    n += o, wx.navigateTo({
        url: n,
        success: function() {
            null != e && e();
        }
    });
}, exports.onlineLog = function(n) {
    wx.getRealtimeLogManager().info(n);
}, exports.px2rpx = function(n) {
    return 750 * n / wx.getSystemInfoSync().windowWidth;
}, exports.replaceObjEmpty = function(n) {
    return Object.keys(n).forEach(function(t) {
        null != n[t] && "string" == typeof n[t] && (n[t] = n[t].replace(/\s+/g, ""));
    }), n;
}, exports.saveBaseToPhotosAlbum = function(t) {
    t.startsWith("data:image/png;base64,") && (t = t.substring(22));
    var e = wx.getFileSystemManager(), o = wx.env.USER_DATA_PATH + "/base64img.png";
    e.writeFile({
        filePath: o,
        data: t,
        encoding: "base64",
        success: function(n) {
            console.log(n), wx.saveImageToPhotosAlbum({
                filePath: o,
                success: function(n) {
                    console.log(n), wx.showToast({
                        title: "保存成功",
                        icon: "success"
                    });
                },
                fail: function(n) {
                    r("保存相册失败"), console.error("保存相册失败", n);
                }
            });
        },
        fail: function(t) {
            (0, n.defaultCatch)(err, "保存文件异常"), console.error("保存文件异常", t);
        }
    });
}, exports.showLoading = function() {
    var n = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "加载中", t = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
    wx.showLoading({
        title: n,
        mask: t
    });
}, exports.strIsNotEpmty = function(n) {
    return null != n && "" != n.replace(/\s/g, "");
}, exports.toast = o;

var n = require("../server/api.js"), t = require("./validata.js");

function e(n) {
    var t = n.getDay();
    return 0 == t ? "星期天" : 1 == t ? "星期一" : 2 == t ? "星期二" : 3 == t ? "星期三" : 4 == t ? "星期四" : 5 == t ? "星期五" : 6 == t ? "星期六" : void 0;
}

function o(n) {
    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 2500;
    wx.showToast({
        title: n,
        icon: "none",
        duration: t
    });
}

function r(n) {
    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : void 0;
    wx.showModal({
        content: n,
        showCancel: !1,
        success: function(n) {
            n.confirm && null != t && t();
        }
    });
}