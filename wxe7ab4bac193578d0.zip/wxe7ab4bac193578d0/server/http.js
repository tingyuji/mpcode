var e = require("../@babel/runtime/helpers/interopRequireWildcard").default;

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = exports.api = void 0;

var t = require("../@babel/runtime/helpers/regeneratorRuntime"), n = require("../@babel/runtime/helpers/asyncToGenerator"), r = require("../@babel/runtime/helpers/classCallCheck"), a = require("../@babel/runtime/helpers/createClass"), i = e(require("../utils/tokenUtil")), o = [ "personalReserve/queryPersonal" ], s = new (function() {
    function e() {
        r(this, e);
    }
    var s, l;
    return a(e, [ {
        key: "baseOptions",
        value: function(e, t, n, r) {
            var a = getApp(), s = e.url, l = e.data, u = "application/json";
            return u = e.contentType || u, new Promise(function(e, p) {
                var c = {
                    "content-type": u,
                    Accept: "application/json"
                };
                1 === n ? "" != a.globalData.authorizationc ? (c.AuthorizationC = a.globalData.authorizationc, 
                c.token = (0, i.default)(), c.appId = i.appId) : (c.token = (0, i.default)(), c.appId = i.appId) : 2 === n && (c.token = (0, 
                i.default)(), c.appId = i.appId), wx.request({
                    url: s,
                    data: l,
                    method: t,
                    header: c,
                    timeout: r,
                    success: function(t) {
                        console.info("请求", s, c, l), 200 == t.statusCode ? (e(t.data), console.info("响应", t.data)) : (t.statusCode, 
                        -1 != o.findIndex(function(e) {
                            return -1 != s.indexOf(e);
                        }) || wx.showToast({
                            title: "当前排队人数较多，请稍后重试",
                            icon: "none",
                            duration: 2e3
                        }), p(t));
                    },
                    fail: function() {
                        console.info("请求", s, c, l), p({
                            msg: "请求失败",
                            url: s,
                            method: t,
                            data: l
                        });
                    }
                });
            });
        }
    }, {
        key: "get",
        value: (l = n(t().mark(function e(n) {
            var r, a, i, o, s = arguments;
            return t().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return r = s.length > 1 && void 0 !== s[1] ? s[1] : {}, a = s.length > 2 && void 0 !== s[2] ? s[2] : 1, 
                    i = s.length > 3 && void 0 !== s[3] ? s[3] : 6e4, o = {
                        url: n,
                        data: r
                    }, e.abrupt("return", this.baseOptions(o, "GET", a, i));

                  case 5:
                  case "end":
                    return e.stop();
                }
            }, e, this);
        })), function(e) {
            return l.apply(this, arguments);
        })
    }, {
        key: "post",
        value: (s = n(t().mark(function e(n) {
            var r, a, i, o, s, l = arguments;
            return t().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return r = l.length > 1 && void 0 !== l[1] ? l[1] : {}, a = l.length > 2 && void 0 !== l[2] ? l[2] : 1, 
                    i = l.length > 3 && void 0 !== l[3] ? l[3] : void 0, o = l.length > 4 && void 0 !== l[4] ? l[4] : 6e4, 
                    s = {
                        url: n,
                        data: r,
                        contentType: i
                    }, e.abrupt("return", this.baseOptions(s, "POST", a, o));

                  case 6:
                  case "end":
                    return e.stop();
                }
            }, e, this);
        })), function(e) {
            return s.apply(this, arguments);
        })
    } ]), e;
}())();

exports.default = s;

var l = {};

exports.api = l, l.baseUrl = "https://pw.jb.mil.cn/japi/sw-saas-cloud/", l.saas = l.baseUrl + "", 
l.trm = "https://pw.jb.mil.cn/japi/sw-trm-cloud/", l.trmSign = "https://pw.jb.mil.cn:9000/japi/sw-trm-sign/", 
l.file = "https://pw.jb.mil.cn/japi/sw-file-cloud/", l.fileSec = "https://pw.jb.mil.cn/file/", 
l.fileLoad = "https://pw.jb.mil.cn/file/";