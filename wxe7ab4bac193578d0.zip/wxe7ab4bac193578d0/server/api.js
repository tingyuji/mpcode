var e = require("../@babel/runtime/helpers/interopRequireWildcard").default;

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.activityQueryById = function(e) {
    return a.default.post(a.api.activity + "api/activity/queryById", {
        activityId: e
    });
}, exports.activityQueryImgCode = function() {
    return a.default.post(a.api.activity + "api/activityReserve/queryImgCode");
}, exports.activityQueryOrderCancle = function(e) {
    return a.default.post(a.api.activity + "api/activityReserve/updateForCancelActivity", {
        delIds: e
    });
}, exports.activityQueryOrderDetail = function(e) {
    return a.default.post(a.api.activity + "api/activityReserve/queryOrderListDetail", {
        orderListId: e
    });
}, exports.activityQueryOrderList = function(e) {
    return a.default.post(a.api.activity + "api/activityReserve/queryOrderList", {
        param: {
            pageSize: "100",
            pageNum: e
        },
        entity: {}
    });
}, exports.activityQueryTicketById = function(e) {
    return a.default.post(a.api.activity + "api/activity/queryTicketById", {
        activityId: e
    });
}, exports.activitySignIn = function(e) {
    return a.default.post(a.api.activity + "api/reserveSign/updateCheckOrderActivity", {
        ids: e,
        checkFrom: 2,
        checkType: 2
    });
}, exports.addFavorite = function(e) {
    return a.default.post(a.api.saas + "customerFavorite/saveFavorite", e);
}, exports.addPraise = function(e) {
    return a.default.post(a.api.zz + "addPraise", e);
}, exports.addTeamMember = function(e, t, r, i, o, n, s, u) {
    return a.default.post(a.api.trm + "api/teamReserve/addTeamMember", {
        shareCode: e,
        visitorName: t,
        phoneNumber: r,
        documentType: i,
        country: o,
        documentNumber: n,
        systemId: s,
        isVip: u
    }, 2);
}, exports.addTeamMemberBatch = function(e, t, r) {
    return a.default.post(a.api.trm + "api/teamReserve/addTeamMemberBatch", {
        shareCode: e,
        systemId: t,
        list: r
    });
}, exports.cancelFavorite = function(e) {
    return a.default.post(a.api.saas + "customerFavorite/cancelFavorite", e);
}, exports.cancelPraise = function(e) {
    return a.default.post(a.api.zz + "cancelPraise", e);
}, exports.checkCompanyCondition = function(e, t) {
    return a.default.post(a.api.trm + "api/teamReserve/checkCompanyCondition", {
        systemId: e,
        companyInfoId: t
    });
}, exports.cmsSearch = function(e, t, r, i, o) {
    var n = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : void 0;
    return a.default.post(a.api.es + "cmsSearch", {
        clusterName: "zhuanzhuan",
        searchValue: e,
        searchMap: {
            latitude: t,
            longitude: r,
            orderType: i,
            equalsMap: JSON.stringify({
                flag: o,
                free: n
            })
        }
    });
}, exports.companyQueryById = function(e) {
    return a.default.post(a.api.saas + "weChatCompany/queryById", {
        companyInfoId: e
    });
}, exports.createTeam = function(e, t, r, i, o, n, s, u, p, c, d, m) {
    return a.default.post(a.api.trm + "api/teamReserve/createTeam", {
        reserveDate: e,
        reserveTime: t,
        visitorId: r,
        visitorName: i,
        phoneNumber: o,
        documentNumber: n,
        companyInfoId: s,
        companyName: u,
        teamName: p,
        systemId: c,
        type: d,
        quantity: m,
        reserveFrom: "TRM0305"
    });
}, exports.customerBehavior = function(e, t, r) {
    return a.default.post(a.api.baseUrl + "customerBehavior/operate", {
        objectId: e.objectId,
        systemId: e.systemId,
        objectTitle: e.objectTitle,
        objectThumb: e.objectThumb,
        objectType: e.subBlock,
        behaviorType: t,
        status: r
    });
}, exports.customerContactDeleteById = function(e) {
    return a.default.post(a.api.saas + "customerContact/deleteById", {
        customerContactId: e
    });
}, exports.customerContactQueryById = function(e) {
    return a.default.post(a.api.saas + "customerContact/queryById", {
        customerContactId: e
    });
}, exports.customerContactQueryList = function() {
    return a.default.post(a.api.saas + "customerContact/queryList", {
        systemId: getApp().globalData.systemId,
        param: {
            pageNum: 1,
            pageSize: 50
        }
    });
}, exports.customerContactQueryPageList = function() {
    return a.default.post(a.api.saas + "customerContact/queryPageList", {
        systemId: getApp().globalData.systemId,
        param: {
            pageNum: 1,
            pageSize: 50
        }
    });
}, exports.customerContactSave = function(e, t, r, i, o, n) {
    var s = arguments.length > 6 && void 0 !== arguments[6] ? arguments[6] : 0;
    return a.default.post(a.api.saas + "customerContact/save", {
        contactName: e,
        contactPhone: t,
        documentType: r,
        nationality: i,
        documentNumber: o,
        isPartyMember: n,
        myself: s
    });
}, exports.customerFootprint = function(e, r) {
    return a.default.post(a.api.baseUrl + "customerFootprint/save", t({
        objectId: e.objectId,
        systemId: e.systemId,
        objectTitle: e.objectTitle,
        objectThumb: e.objectThumb,
        objectType: e.subBlock
    }, "objectType", r));
}, exports.customerUpdateCert = function(e, t, r, i, o) {
    return a.default.post(a.api.saas + "customerCert/updateCert", {
        customerName: e,
        documentType: t,
        documentNumber: r,
        phoneNumber: i,
        svCode: o
    });
}, exports.defaultCatch = function(e, t) {
    wx.hideNavigationBarLoading(), wx.hideLoading(), console.error(e), wx.showToast({
        title: t + "," + JSON.stringify(e),
        icon: "none"
    }), console.error(t + "," + JSON.stringify(e));
}, exports.deleteLeaderDeleteById = function(e, t, r) {
    return a.default.post(a.api.trm + "api/teamReserve/deleteLeader", {
        agencyId: e,
        guideId: t,
        systemId: r
    });
}, exports.deleteTeamMember = function(e, t) {
    return a.default.post(a.api.trm + "api/teamReserve/deleteTeamMember", {
        shareCode: e,
        detailId: t
    });
}, exports.dissolveTeam = function(e) {
    return a.default.post(a.api.trm + "api/teamReserve/dissolveTeam", {
        shareCode: e
    });
}, exports.exhibitionAppointQueryImgCode = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1;
    return a.default.post(a.api.exhibitionCS + "order/queryImgCode", {
        type: e
    });
}, exports.exhibitionOtherAppointQueryOrderDetail = function(e) {
    return a.default.get(a.api.exhibitionCS + "specialShow/getVisitFromOthers/" + e, {});
}, exports.exhibitionQueryOrderDetail = function(e) {
    return a.default.get(a.api.exhibitionCS + "order/queryOrderDetails/" + e, {});
}, exports.exhibitionQueryOrderHexiaoDetail = function(e) {
    return a.default.get(a.api.exhibitionCS + "specialShow/queryTodayVisitList/" + e, {});
}, exports.exhibitionQueryOrderList = function(e, t, r) {
    return a.default.post(a.api.exhibitionCS + "order/queryOrder", {
        param: {
            pageSize: "100",
            pageNum: e,
            ids: t
        },
        entity: {
            queryType: r
        }
    });
}, exports.fullImageUrl = function(e) {
    return null == e ? "" : a.api.file + e;
}, exports.fullImageUrlSaaS = function(e) {
    return null == e ? "" : a.api.fileSec + e;
}, exports.getAgencyTypeList = function() {
    return a.default.get(a.api.trm + "api/teamReserve/getAgencyTypeList");
}, exports.getCheckInImgCode = function(e, t, r) {
    return a.default.post(a.api.trm + "api/teamReserve/getCheckInCode", {
        shareCode: e,
        documentNumber: t,
        systemId: r
    }, 2);
}, exports.getCheckInQRCode = function(e, t, r, i) {
    return a.default.post(a.api.trm + "api/teamReserve/getCheckInQRCode", {
        documentNumber: e,
        shareCode: t,
        systemId: r,
        vcode: i
    }, 2);
}, exports.getCountryListData = function() {
    return a.default.get(a.api.trm + "api/teamReserve/getCountryList");
}, exports.getDocumentTypeList = function() {
    return a.default.get(a.api.trm + "api/teamReserve/getDocumentTypeList");
}, exports.getLeaderCode = function(e) {
    return a.default.post(a.api.trm + "api/teamReserve/getLeaderCode", {
        phoneNumber: e
    });
}, exports.getQuerySmsVCode = function(e, t, r) {
    return a.default.get(a.api.saas + "saas/querySmsVCode", {
        phone: e,
        vcode: t,
        vid: r
    });
}, exports.getTeamContactByFileId = function(e, t, r, i) {
    return a.default.post(a.api.trm + "api/teamReserve/getTeamContactByFileId", {
        shareCode: e,
        systemId: t,
        companyInfoId: r,
        fileId: i
    });
}, exports.getTeamTypeListData = function() {
    return a.default.get(a.api.trm + "api/teamReserve/getTeamTypeList", {});
}, exports.hexiaoExihibitionOrderSubmit = function(e, t) {
    return a.default.post(a.api.exhibitionCS + "order/signIn", {
        reserveNos: e,
        displayInfoId: t,
        source: "EXH0305"
    });
}, exports.labelSearch = function(e) {
    return a.default.post(a.api.es + "labelSearch", {
        pageSize: "5",
        pageNum: "1",
        searchKey: "label",
        clusterName: "zhuanzhuan",
        searchMap: {},
        searchValue: e
    });
}, exports.login = function(e) {
    var t = wx.getAccountInfoSync().miniProgram.appId;
    return a.default.post("".concat(a.api.saas, "saas/smallProgramLogin?code=").concat(e, "&appId=").concat(t));
}, exports.loginPhone = function(e, t) {
    return a.default.post("".concat(a.api.saas, "saas/svcodeLogin?phone=").concat(e, "&svCode=").concat(t, "&openId=").concat(getApp().globalData.openId, "&openIdType=").concat(getApp().globalData.openIdType));
}, exports.passCode = function(e) {
    wx.getAccountInfoSync().miniProgram.appId;
    return a.default.post("".concat(a.api.saas, "saas/passCode?code=").concat(e));
}, exports.personalListForSign = function(e) {
    return a.default.post(a.api.trmSign + "api/reserveSign/queryListForSign", {
        systemId: e
    });
}, exports.personalReserveCheckMySubmit = function() {
    return a.default.post(a.api.trm + "api/personalReserve/checkMySubmit", {});
}, exports.personalReserveQueryImgCode = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0;
    return a.default.post(a.api.trm + "api/personalReserve/queryImgCode", {
        type: e
    }, 1, void 0, 1e4);
}, exports.personalReserveQueryListForSign = function(e) {
    return a.default.get("".concat(a.api.trm, "api/personalReserve/checkBook/").concat(e));
}, exports.personalReserveSign = function(e) {
    return a.default.post(a.api.trmSign + "api/reserveSign/checkOrderPersonalForSign", {
        orderPersonalIds: e
    });
}, exports.queryActivityById = function(e) {
    return a.default.post("".concat(a.api.act, "api/activity/queryById"), r({
        activityId: e
    }, getApp().globalData.location));
}, exports.queryActivityHistory = function(e, t) {
    return a.default.post(a.api.activity + "orderActivity/personalOrderHistory", {
        param: {
            pageSize: "10",
            pageNum: e
        },
        entity: {
            visitorId: t
        }
    });
}, exports.queryActivityList = function(e) {
    return a.default.post(a.api.activity + "api/activity/queryActivityList", {
        param: {
            pageSize: "10",
            pageNum: e
        },
        entity: {}
    });
}, exports.queryActivityListByType = function(e, t, i) {
    var o = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : void 0, n = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : void 0;
    return a.default.post(a.api.act + "api/activity/queryActivityList", {
        param: {
            pageSize: "10",
            pageNum: t
        },
        entity: r(r({}, i), {}, {
            cost: o,
            cityCode: n
        })
    }, 2);
}, exports.queryActivityShowCheckBookById = function(e) {
    return a.default.get("".concat(a.api.act, "api/activity/checkBook/").concat(e));
}, exports.queryActivityTicketsById = function(e) {
    return a.default.post("".concat(a.api.activity, "actActivity/queryById"), {
        activityId: e
    });
}, exports.queryActivityTripRemind = function() {
    return a.default.get("".concat(a.api.act, "api/activity/tripRemind"));
}, exports.queryBookRuleExhBookRule = function(e) {
    return a.default.get(a.api.exhibitionCS + "exhBookRule/queryBookRule/" + e, {});
}, exports.queryCertList = function() {
    return a.default.post(a.api.saas + "customerCert/queryCertList");
}, exports.queryCompanyInfoPageList = function(e, t, r) {
    return a.default.post(a.api.baseUrl + "weChatCompany/queryDistancePageList", {
        entity: {
            latitude: t,
            longitude: r
        },
        systemId: e
    }, 2);
}, exports.queryContactByIdData = function(e) {
    return a.default.get(a.api.saas + "customerContact/queryContactById?customerContactId=" + e, {});
}, exports.queryCurrentCertification = function(e) {
    return a.default.get(a.api.trm + "api/teamReserve/queryCurrentCertification", {});
}, exports.queryDistancePageList = function(e, t) {
    return a.default.post(a.api.saas + "weChatCompany/queryDistancePageList", {
        longitude: e,
        latitude: t
    });
}, exports.queryExhibitionById = function(e) {
    return a.default.get("".concat(a.api.exhibitionCS, "specialShow/queryById/"), r({
        id: e
    }, getApp().globalData.location));
}, exports.queryExhibitionHistory = function(e) {
    return a.default.get(a.api.exhibitionCS + "order/verificationRecord", {
        param: {
            pageSize: "10",
            pageNum: e
        },
        entity: {}
    });
}, exports.queryExhibitionList = function(e, t, i, o) {
    var n = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : void 0, s = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : void 0;
    return a.default.post(a.api.exhibitionCS + "specialShow/queryByPage", {
        param: {
            pageSize: "10",
            pageNum: i
        },
        entity: r(r({}, o), {}, {
            price: n,
            cityCode: s
        })
    }, 2);
}, exports.queryExhibitionPersonalDescrption = function(e) {
    return a.default.get(a.api.exhibitionCS + "specialShow/information/" + e, {});
}, exports.queryExhibitionReviewById = function(e) {
    return a.default.get("".concat(a.api.zz, "queryExhibitionReviewById/").concat(e));
}, exports.queryExhibitionReviewList = function(e) {
    return a.default.post(a.api.zz + "queryExhibitionReviewList", {
        param: {
            pageSize: "10",
            pageNum: e
        }
    }, 2);
}, exports.queryExhibitionTicketById = function(e) {
    return a.default.get("".concat(a.api.exhibitionCS, "specialShow/ticket/") + e, {});
}, exports.queryExihibitionConfirmOrder = function(e) {
    return a.default.post(a.api.exhibitionCS + "order/confirmOrder", {
        orderId: e
    });
}, exports.queryExihibitionsureOrderPay = function(e, t, r, i, o) {
    return a.default.post(a.api.exhibitionCS + "order/payment", {
        orderId: t
    });
}, exports.queryFavoriteList = function(e, t) {
    return a.default.post(a.api.baseUrl + "customerBehavior/queryBehaviorList", {
        param: {
            pageSize: "10",
            pageNum: e
        },
        entity: {
            behaviorType: t
        }
    });
}, exports.queryIsOpenReserve = function(e, t) {
    return a.default.post(a.api.trm + "api/personalReserve/queryIsOpenReserve", {
        systemId: e,
        companyInfoId: t
    });
}, exports.queryMuseumActivity = function(e, t) {
    return a.default.post(a.api.activity + "api/activity/queryActivityList", {
        param: {
            pageSize: t,
            pageNum: 1
        },
        entity: r({
            companyInfoId: e
        }, getApp().globalData.location)
    }, 2);
}, exports.queryMuseumExhibition = function(e, t, i) {
    return a.default.post(a.api.exhibitionCS + "specialShow/queryByPage", {
        param: {
            pageSize: i,
            pageNum: 1
        },
        entity: r({
            type: e,
            companyInfoId: t
        }, getApp().globalData.location)
    }, 2);
}, exports.queryOrderActivityList = function(e) {
    return a.default.post(a.api.activity + "api/reserveSign/queryOrderActivityList", {
        activityId: e
    });
}, exports.queryOrderListDetail = function(e) {
    return a.default.post(a.api.activity + "api/activityReserve/queryOrderListDetail", {
        orderListId: e
    });
}, exports.queryOrderPersonalDetail = function(e) {
    return a.default.post(a.api.trm + "api/personalReserve/queryOrderInfo", {
        orderListId: e
    });
}, exports.queryOrderPersonalList = function(e) {
    return a.default.post(a.api.trm + "api/personalReserve/queryOrderList", {
        pageSize: "10",
        pageNum: e
    });
}, exports.queryOtherAppointOrderPersonalDetail = function(e) {
    return a.default.post(a.api.trm + "api/personalReserve/queryOrderPersonalDetail", {
        orderPersonalId: e
    });
}, exports.queryPersonal = function(e, t) {
    return a.default.post(a.api.trm + "api/personalReserve/queryPersonal", {
        systemId: e,
        companyInfoId: t
    }, 1, void 0, 1e4);
}, exports.queryPersonalDescrption = function(e, t) {
    return a.default.post(a.api.trm + "api/personalReserve/queryPersonalDescrption", {
        systemId: e,
        companyInfoId: t
    });
}, exports.queryPersonalHistory = function(e, t) {
    return a.default.post(a.api.trm + "orderPersonal/personalOrderHistory", {
        param: {
            pageSize: "10",
            pageNum: e
        },
        entity: {
            visitorId: t
        }
    });
}, exports.queryPersonalReserveRemind = function() {
    return a.default.get("".concat(a.api.trm, "api/personalReserve/queryRemindList"));
}, exports.queryPersonalReserveRule = function(e, t) {
    return a.default.post(a.api.trm + "api/personalReserve/queryPersonalReserveRule", {
        systemId: e,
        companyInfoId: t
    });
}, exports.queryPraiseList = function(e) {
    return a.default.post(a.api.baseUrl + "customerBehavior/queryOperationInfo", {
        objectId: e
    });
}, exports.queryPublishNotice = function(e, t) {
    return a.default.post(a.api.trm + "api/personalReserve/queryPublishNotice", {
        systemId: e,
        companyInfoId: t
    });
}, exports.queryReserveTipData = function(e, t, r) {
    return a.default.post(a.api.trm + "api/personalReserve/queryReserveTip", {
        systemId: e,
        companyInfoId: t,
        ruleCode: r
    });
}, exports.queryRuleTip = function(e, t) {
    return a.default.post(a.api.trm + "api/personalReserve/queryRuleTip", {
        systemId: e,
        companyInfoId: t
    });
}, exports.querySpecialShowCheckBookById = function(e) {
    return a.default.get("".concat(a.api.exhibitionCS, "specialShow/checkBook/").concat(e));
}, exports.querySuccessTip = function(e, t) {
    return a.default.post(a.api.trm + "rule/querySuccessTip", {
        systemId: e,
        companyInfoId: t
    });
}, exports.queryTeamAppointOrderList = function(e, t) {
    return a.default.post(a.api.trm + "api/teamReserve/queryOrderList", {
        param: {
            pageNum: t,
            pageSize: 10
        },
        entity: {
            systemId: e
        }
    });
}, exports.queryTeamAppointPersonal = function(e, t) {
    return a.default.post(a.api.trm + "api/teamReserve/queryTeam", {
        systemId: e,
        companyInfoId: t
    });
}, exports.queryTeamCertificationTip = function(e, t) {
    return a.default.post(a.api.trm + "api/teamReserve/queryTeamCertificationTip", {
        systemId: e,
        companyInfoId: t
    });
}, exports.queryTeamDetail = function(e) {
    return a.default.get(a.api.trm + "api/teamReserve/queryTeamDetail?code=" + e, {});
}, exports.queryTeamInfo = function(e) {
    return a.default.get(a.api.trm + "api/teamReserve/queryTeamInfo?code=" + e, {}, 2);
}, exports.queryTeamOrderDetail = function(e) {
    return a.default.post(a.api.trm + "api/teamReserve/queryOrderDetail", {
        shareCode: e
    });
}, exports.queryTeamPersonalDescrption = function(e, t) {
    return a.default.post(a.api.trm + "api/teamReserve/queryTeamReserveDesc", {
        systemId: e,
        companyInfoId: t
    });
}, exports.queryTeamReserveRule = function(e, t) {
    return a.default.post(a.api.trm + "api/teamReserve/queryTeamReserveRule", {
        systemId: e,
        companyInfoId: t
    });
}, exports.queryVenueById = function(e) {
    return a.default.post("".concat(a.api.baseUrl, "weChatCompany/queryById"), r({
        companyInfoId: e
    }, getApp().globalData.location));
}, exports.queryVenueCity = function() {
    return a.default.post(a.api.zz + "queryVenueCity", {}, 2);
}, exports.queryVenueListByType = function(e, t, i) {
    var o = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : void 0, n = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : void 0;
    return a.default.post(a.api.baseUrl + "weChatCompany/queryDistancePageList", {
        param: {
            pageSize: "10",
            pageNum: t,
            type: e
        },
        entity: r(r({}, i), {}, {
            cost: o,
            cityCode: n
        })
    }, 2);
}, exports.queryViewList = function(e) {
    return a.default.post(a.api.baseUrl + "customerFootprint/queryBehaviorList", {
        pageSize: "10",
        pageNum: e
    });
}, exports.queryspecialShowTripRemind = function() {
    return a.default.get("".concat(a.api.exhibitionCS, "specialShow/tripRemind"));
}, exports.reSubmitOrganizationCertification = function(e, t, r, i, o, n, s, u, p, c, d, m) {
    return a.default.post(a.api.trm + "api/teamReserve/reSubmitOrganizationCertification", {
        systemId: e,
        agencyType: t,
        agencyName: r,
        creditCode: i,
        businessLicense: o,
        contactName: n,
        contactDocumentNumber: s,
        contactFrontCard: u,
        contactReverseCard: p,
        officialLetter: c,
        agencyId: d,
        dataType: m
    });
}, exports.renlianAddFaceUrl = function(e, t) {
    return a.default.post(a.api.saas + "customerContact/addFaceUrl", {
        customerContactId: e,
        faceUrl: t
    });
}, exports.renlianQueryRule = function(e, t) {
    return a.default.post(a.api.saas + "saas/queryRule", {
        systemId: e
    });
}, exports.saasQueryVCode = function() {
    return a.default.get(a.api.saas + "saas/queryVCode", {});
}, exports.saasSaveCustomer = function(e, t, r) {
    return a.default.post(a.api.saas + "backend/saveCustomer", {
        customerName: e,
        customerPhone: t,
        loginPassword: r
    });
}, exports.saveCert = function(e, t, r) {
    return a.default.post(a.api.saas + "customerCert/saveCert", {
        customerName: e,
        documentType: t,
        documentNumber: r
    });
}, exports.saveForFreeOrderSubmit = function(e, t, r, i, o, n, s, u) {
    return a.default.post(a.api.exhibitionCS + "order/submitFreeOrder", {
        displayInfoId: e,
        accountId: t,
        orderCost: r,
        reserveDate: i,
        reserveTime: o,
        appContactsList: n,
        imgCode: s,
        source: "EXH0305",
        isSubmit: u
    });
}, exports.saveForHibitionPrepareSubmit = function(e, t, r, i, o, n, s) {
    return a.default.post(a.api.exhibitionCS + "order/submitOrder", {
        displayInfoId: e,
        accountId: t,
        orderCost: r,
        reserveDate: i,
        reserveTime: o,
        appContactsList: n,
        imgCode: s,
        source: "EXH0305"
    });
}, exports.saveForPrepareSubmit = function(e, t, r, i, o, n, s) {
    return a.default.post(a.api.trm + "api/personalReserve/saveForPrepareSubmit", {
        reserveDate: e,
        reserveTime: t,
        companyInfoId: r,
        orderPersonalList: i,
        childMap: o,
        imgCode: n,
        reserveFrom: "TRM0305",
        certInfo: s
    });
}, exports.saveForSubmitActivity = function(e, t, r) {
    return a.default.post(a.api.activity + "api/activityReserve/saveForSubmitActivity", {
        activityId: e,
        contactIdList: t,
        imgCode: r,
        reserveFrom: "ACT0205"
    });
}, exports.saveForSubmitPersonal = function() {
    var e = arguments.length > 1 ? arguments[1] : void 0;
    return a.default.post(a.api.trm + "api/personalReserve/saveForSubmitPersonal", {
        companyInfoId: e
    });
}, exports.showWarningToast = function(e) {
    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "";
    wx.hideNavigationBarLoading(), wx.hideLoading(), wx.showToast({
        title: "" == t ? e.msg : "".concat(t, "，").concat(e.msg),
        icon: "none"
    }), console.error(t + "," + JSON.stringify(e));
}, exports.smallProgramLoginByPhone = function(e) {
    return a.default.post(a.api.saas + "saas/smallProgramLoginByPhone", e);
}, exports.submitOrganizationCertification = function(e, t, r, i, o, n, s, u, p, c, d) {
    return a.default.post(a.api.trm + "api/teamReserve/submitOrganizationCertification", {
        systemId: e,
        agencyType: t,
        agencyName: r,
        creditCode: i,
        businessLicense: o,
        contactName: n,
        contactDocumentNumber: s,
        contactFrontCard: u,
        contactReverseCard: p,
        officialLetter: c,
        dataType: d
    });
}, exports.submitTeam = function(e, t) {
    return a.default.post(a.api.trm + "api/teamReserve/submitTeam", {
        shareCode: e,
        systemId: t
    });
}, exports.sureForSubmitActivity = function(e) {
    return a.default.post(a.api.activity + "api/activityReserve/submitActivityOrder", {
        activityId: e
    });
}, exports.teamAppointReserveAgain = function(e, t, r, i, o, n, s, u, p, c, d, m) {
    return a.default.post(a.api.trm + "api/teamReserve/reserveAgain", {
        reserveDate: e,
        reserveTime: t,
        companyInfoId: r,
        companyName: i,
        systemId: o,
        shareCode: n,
        teamName: s,
        type: u,
        quantity: p,
        visitorName: c,
        phoneNumber: d,
        documentNumber: m,
        reserveFrom: "TRM0305"
    });
}, exports.teamReserve = function(e, t) {
    return a.default.post(a.api.trm + "api/teamReserve/refund", {
        shareCode: e,
        systemId: t,
        reserveFrom: "TRM0305"
    });
}, exports.teamReserveAddLeader = function(e, t, r, i, o, n) {
    return a.default.post(a.api.trm + "api/teamReserve/addLeader", {
        username: e,
        phoneNumber: t,
        documentType: r,
        documentNumber: i,
        systemId: o,
        vcode: n
    });
}, exports.teamReserveCheckBookConfirm = function(e, t, r) {
    return a.default.post(a.api.trmSign + "api/teamReserve/checkBookConfirm", {
        reserveNo: e,
        companyInfoId: t,
        systemId: r
    });
}, exports.teamReserveCheckBookList = function() {
    return a.default.get(a.api.trmSign + "api/teamReserve/checkBookList/" + getApp().globalData.systemId + "/" + getApp().globalData.companyInfoId, {});
}, exports.teamReserveCheckCondition = function(e) {
    return a.default.post(a.api.trm + "api/teamReserve/checkCondition", {
        systemId: e
    });
}, exports.teamReserveLeaders = function(e, t) {
    return a.default.post(a.api.trm + "api/teamReserve/leaders", {
        guideId: e,
        systemId: t
    });
}, exports.teamReserveQueryListForSign = function() {
    return a.default.get(a.api.trm + "api/teamReserve/checkBook/" + getApp().globalData.systemId + "/" + getApp().globalData.companyInfoId, {});
}, exports.teamReservecheckShow = function() {
    return a.default.post(a.api.trm + "api/teamReserve/checkShow", {});
}, exports.tuidingExihibitionOrderSubmit = function(e, t, r, i) {
    return a.default.post(a.api.exhibitionCS + "order/unsubscribe", {
        orderId: e,
        displayInfoId: t,
        reserveDate: r,
        childOrderIds: i,
        remark: "",
        source: "EXH0305"
    });
}, exports.tuidingNoticeToRefund = function(e, t, r, i) {
    return a.default.post(a.api.exhibitionCS + "order/noticeToRefund", {
        orderId: e,
        displayInfoId: t,
        reserveDate: r,
        childOrderIds: i,
        remark: ""
    });
}, exports.tuidingWxPayrefundSubmit = function(e, t, r, i, o, n, s, u) {
    return a.default.post(a.api.baseUrl + "api/wxPayV3/refund", {
        outTradeNo: e,
        refundNo: t,
        totalAmount: r,
        refundAmount: i,
        refundReason: o,
        productCode: n,
        systemId: s,
        attach: u
    });
}, exports.updateCustomerContact = function(e, t, r, i, o, n, s, u) {
    return a.default.post(a.api.saas + "customerContact/updateCustomerContact", {
        customerContactId: e,
        contactName: t,
        contactPhone: r,
        documentType: i,
        nationality: o,
        documentNumber: n,
        isPartyMember: s,
        myself: u
    });
}, exports.updateForCancelActivity = function(e) {
    return a.default.post(a.api.activity + "api/activityReserve/updateForCancelActivity", {
        delIds: e
    });
}, exports.updateForCancelPersonal = function(e) {
    return a.default.post(a.api.trm + "api/personalReserve/updateForCancelPersonal", {
        delIds: e
    });
}, exports.updateForChangePersonal = function(e, t, r) {
    return a.default.post(a.api.trm + "api/personalReserve/updateForChangePersonal", {
        orderPersonalIds: e,
        reserveDate: t,
        reserveTime: r
    });
}, exports.updateTeamMember = function(e, t, r, i, o, n, s, u) {
    return a.default.post(a.api.trm + "api/teamReserve/updateTeamMember", {
        shareCode: e,
        visitorName: t,
        phoneNumber: r,
        documentType: i,
        country: o,
        documentNumber: n,
        detailId: s,
        isVip: u
    });
};

var t = require("../@babel/runtime/helpers/defineProperty"), r = require("../@babel/runtime/helpers/objectSpread2"), a = e(require("./http"));