var t = require("../../server/api");

function e() {
    return "" != getApp().globalData.authorizationc || (wx.navigateTo({
        url: "/pages/login/login"
    }), !1);
}

Component({
    options: {
        pureDataPattern: /^_/
    },
    properties: {
        _data: Object,
        _id: String,
        _type: Number,
        enable: {
            type: Boolean,
            value: !1
        },
        btnStr: {
            type: String,
            value: "不可预约"
        }
    },
    observers: {
        _data: function(e) {
            var a;
            null != e && Object.keys(e).length > 0 && (a = this, "" != getApp().globalData.authorizationc && (0, 
            t.queryPraiseList)(a.properties._data.objectId).then(function(t) {
                if (console.log(t), 200 == t.code) {
                    var e = t.data;
                    a.setData({
                        like: e.praise,
                        praiseCount: e.praiseCount,
                        favorites: e.favorite,
                        favoriteCount: e.favoriteCount,
                        _liekResult: e
                    });
                }
            }));
        }
    },
    lifetimes: {
        attached: function() {}
    },
    data: {
        like: !1,
        favorites: !1,
        praiseCount: 0,
        favoriteCount: 0,
        _liekResult: {},
        _favoritesResult: {}
    },
    methods: {
        _appointmentOnTap: function() {
            this.properties.enable && this.triggerEvent("appointmentOnTap");
        },
        _likeOnTap: function() {
            if (e()) if (this.data.like) {
                var a = this;
                (0, t.customerBehavior)(a.properties._data, 1, !1).then(function(e) {
                    if (200 == e.code) {
                        a.triggerEvent("updateLikeNum", {
                            type: "cancel"
                        }), wx.showToast({
                            title: "已取消点赞",
                            icon: "none"
                        });
                        var i = a.data.praiseCount;
                        i -= 1, a.setData({
                            like: !1,
                            praiseCount: i
                        });
                    } else (0, t.showWarningToast)(e, "取消失败");
                }).catch(function(e) {
                    (0, t.defaultCatch)(e, "取消失败");
                });
            } else {
                a = this;
                (0, t.customerBehavior)(a.properties._data, 1, !0).then(function(e) {
                    if (a.triggerEvent("updateLikeNum", {
                        type: "add"
                    }), 200 == e.code) {
                        wx.showToast({
                            title: "点赞成功",
                            icon: "none"
                        });
                        var i = a.data.praiseCount;
                        i += 1, a.setData({
                            like: !0,
                            praiseCount: i,
                            _liekResult: e.data
                        });
                    } else (0, t.showWarningToast)(e, "点赞失败");
                }).catch(function(e) {
                    (0, t.defaultCatch)(e, "点赞失败");
                });
            }
        },
        _favoritesOnTap: function() {
            if (e()) {
                var a = this;
                if (this.data.favorites) (0, t.customerBehavior)(this.properties._data, 2, !1).then(function(e) {
                    if (200 == e.code) {
                        a.triggerEvent("updateFavoriteNum", {
                            type: "cancel"
                        }), wx.showToast({
                            title: "已取消收藏",
                            icon: "none"
                        });
                        var i = a.data.favoriteCount;
                        i -= 1, a.setData({
                            favorites: !1,
                            favoriteCount: i
                        });
                    } else (0, t.showWarningToast)(e, "取消失败");
                }).catch(function(e) {
                    (0, t.defaultCatch)(e, "取消失败");
                }); else {
                    a = this;
                    (0, t.customerBehavior)(a.properties._data, 2, !0).then(function(e) {
                        if (a.triggerEvent("updateFavoriteNum", {
                            type: "add"
                        }), 200 == e.code) {
                            wx.showToast({
                                title: "收藏成功",
                                icon: "none"
                            });
                            var i = a.data.favoriteCount;
                            i += 1, a.setData({
                                favorites: !0,
                                favoriteCount: i,
                                _favoritesResult: e.data
                            });
                        } else (0, t.showWarningToast)(e, "收藏失败");
                    }).catch(function(e) {
                        (0, t.defaultCatch)(e, "收藏失败");
                    });
                }
            }
        }
    }
});