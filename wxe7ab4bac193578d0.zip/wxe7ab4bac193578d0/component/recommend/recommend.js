var t = require("../../server/api");

Component({
    options: {
        pureDataPattern: /^_/
    },
    properties: {
        _label: Object,
        _id: String
    },
    data: {
        list: []
    },
    observers: {
        _label: function(i) {
            if (null != i && i.length > 0) {
                var e = "";
                i.forEach(function(t) {
                    e = e + t.labelId + ",";
                }), function(i, e) {
                    (0, t.labelSearch)(e).then(function(e) {
                        if (200 == e.code && e.data.records.length > 0) {
                            var a = e.data.records, r = i.properties._id;
                            (a = a.filter(function(t) {
                                return t.id != r;
                            })).forEach(function(i) {
                                i.img = null != i.tenantId ? (0, t.fullImageUrlSaaS)(i.img) : (0, t.fullImageUrl)(i.img), 
                                null != i.startTime && null != i.endTime && (i.time = i.startTime.substr(0, 16) + "至" + i.endTime.substr(0, 16)), 
                                "展评" == i.flag ? i.typeColor = "#DB5151" : "活动" == i.flag ? i.typeColor = "#55A662" : i.typeColor = "#cfb053";
                            }), i.setData({
                                list: a
                            });
                        }
                    });
                }(this, e = e.substring(0, e.length - 1));
            }
        }
    },
    methods: {
        _itemClick: function(t) {
            var i, e = t.currentTarget.dataset.index, a = this.data.list[e], r = {
                id: a.id
            };
            "特展" == a.flag ? i = "../../pages/exhibition/exhibitionDetail?data=" + JSON.stringify(r) : "活动" == a.flag ? i = "../../pages/activity/activityDetail?data=" + JSON.stringify(r) : "展评" == a.flag && (i = "../../pages/exhibition/findDetail?data=" + JSON.stringify(r)), 
            wx.navigateTo({
                url: i
            });
        }
    }
});