Component({
    properties: {},
    data: {
        x: 0,
        oldx: 0,
        isOk: !1,
        size: {}
    },
    ready: function() {
        var t = this, a = function(a) {
            return new Promise(function(e, i) {
                wx.createSelectorQuery().in(t).select(a).fields({
                    size: !0
                }, function(t) {
                    e(t.width);
                }).exec();
            });
        };
        a("#pathway").then(function(e) {
            t.data.size.pathway = e, console.log(t.data.size.pathway), a("#track").then(function(a) {
                t.data.size.track = a, console.log(t.data.size.track);
            });
        });
    },
    methods: {
        onChange: function(t) {
            this.setData({
                oldx: t.detail.x
            });
        },
        onEnd: function() {
            var t = this;
            console.log(this.data.oldx), this.data.isOk || (this.data.oldx + 1 > this.data.size.pathway - this.data.size.track - 35 ? this.setData({
                isOk: !0
            }, function() {
                t.triggerEvent("result");
            }) : this.setData({
                x: 0,
                oldx: 0
            }));
        }
    }
});