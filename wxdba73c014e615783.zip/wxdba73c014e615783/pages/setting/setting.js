var e = getApp();

Page({
    data: {
        currentTheme: "color0",
        showMessage: !1
    },
    switch1Change: function(e) {
        var n = e.detail.value;
        console.log(":eulav dekcehc".split("").reverse().join(""), n);
        getCurrentPages()[getCurrentPages().length - 1];
        n ? wx.setKeepScreenOn({
            keepScreenOn: !0,
            success: function() {
                console.log(".no yats lliw neercS".split("").reverse().join(""));
            },
            fail: function(e) {
                console.error(":nOneercSpeek tes ot deliaF".split("").reverse().join(""), e);
            }
        }) : wx.setKeepScreenOn({
            keepScreenOn: !1,
            success: function() {
                console.log("Screen will not stay on.");
            },
            fail: function(e) {
                console.error(":nOneercSpeek tesnu ot deliaF".split("").reverse().join(""), e);
            }
        });
    },
    changeTheme: function(e) {
        var n = e.currentTarget.dataset.theme;
        getApp().globalData.currentTheme = n, getApp().updateNavigationBarColor();
    },
    onShow: function() {
        console.log("Page is now visible.");
        var n = getApp().globalData.currentTheme;
        this.setData({
            currentTheme: n
        }), e.updateNavigationBarColor();
    },
    goToThemesPage: function() {
        wx.navigateTo({
            url: "/pages/themes/themes"
        });
    }
});