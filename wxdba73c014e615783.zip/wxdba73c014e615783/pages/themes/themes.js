var e = getApp();

Page({
    data: {
        themeColors: getApp().globalData.themeColors,
        currentTheme: "color0",
        showMessage: !1
    },
    changeTheme: function(e) {
        var t = e.currentTarget.dataset.theme;
        getApp().globalData.currentTheme = t, getApp().updateNavigationBarColor();
    },
    onShow: function() {
        console.log("Page is now visible.");
        var t = getApp().globalData.currentTheme;
        this.setData({
            currentTheme: t
        }), e.updateNavigationBarColor();
    },
    selectColor: function(e) {
        var t = e.currentTarget.dataset.color;
        getApp().globalData.currentTheme = t, getCurrentPages().forEach(function(e) {
            e.onShow && e.onShow();
        });
    }
});