var e = require("../../E6B424F2D1C3EEDF80D24CF5134DD116.js"), t = getApp();

Page({
    data: {
        currentTheme: "color0",
        clockShow: !1,
        time: "25",
        mTime: 3e5,
        rate: "",
        timeStr: "05:00",
        timer: null,
        timeArray: [ "钟分1".split("").reverse().join(""), "钟分3".split("").reverse().join(""), "5分钟", "钟分01".split("").reverse().join(""), "钟分51".split("").reverse().join(""), "20分钟", "钟分52".split("").reverse().join(""), "钟分03".split("").reverse().join(""), "钟分53".split("").reverse().join(""), "钟分04".split("").reverse().join(""), "钟分54".split("").reverse().join(""), "钟分05".split("").reverse().join(""), "60分钟", "70分钟", "80分钟", "90分钟" ],
        timeToMinutes: {
            "1分钟": 1,
            "3分钟": 3,
            "5分钟": 5,
            "10分钟": 10,
            "15分钟": 15,
            "20分钟": 20,
            "25分钟": 25,
            "30分钟": 30,
            "35分钟": 35,
            "40分钟": 40,
            "45分钟": 45,
            "50分钟": 50,
            "60分钟": 60,
            "70分钟": 70,
            "80分钟": 80,
            "90分钟": 90
        },
        selectedTimeIndex: 6,
        selectedMinutes: 25,
        cateArr: [ {
            icon: "gongzuo.png",
            text: "工作"
        }, {
            icon: "xuexi.png",
            text: "学习"
        }, {
            icon: "xiezuo.png",
            text: "写作"
        }, {
            icon: "yuedu.png",
            text: "阅读"
        }, {
            icon: "yule.png",
            text: "娱乐"
        } ],
        cateActive: "0",
        clockHeight: 0,
        indexHeight: 0,
        okShow: !1,
        pauseShow: !0,
        continueCancleShow: !1
    },
    onLoad: function() {
        var e = wx.getSystemInfoSync(), t = 750 / e.windowWidth;
        this.setData({
            rate: t,
            clockHeight: t * e.windowHeight
        });
    },
    changeTheme: function(e) {
        var t = e.currentTarget.dataset.theme;
        getApp().globalData.currentTheme = t, getApp().updateNavigationBarColor();
    },
    onShow: function() {
        console.log("Page is now visible.");
        var e = getApp().globalData.currentTheme;
        this.setData({
            currentTheme: e
        }), t.updateNavigationBarColor();
    },
    timePickerChange: function(e) {
        var t = e.detail.value, a = this.data.timeArray[t], i = this.data.timeToMinutes[a];
        this.setData({
            selectedTimeIndex: t,
            selectedMinutes: i,
            time: i
        });
    },
    start: function() {
        this.setData({
            clockShow: !0,
            mTime: 60 * this.data.time * 1e3,
            timeStr: parseInt(this.data.time) >= 10 ? this.data.time + ":00" : "0" + this.data.time + ":00"
        }), this.drawBg(), this.drawActive();
    },
    clickCate: function(e) {
        console.log(e), this.setData({
            cateActive: e.currentTarget.dataset.index
        });
    },
    drawBg: function() {
        var e = this, t = 6 / this.data.rate;
        wx.createSelectorQuery().select("#progress_bg").fields({
            node: !0,
            size: !0
        }).exec(function(a) {
            var i = a[0].node, n = i.getContext("d2".split("").reverse().join("")), o = wx.getSystemInfoSync().pixelRatio;
            i.width = a[0].width * o, i.height = a[0].height * o, n.scale(o, o), n.lineCap = "dnuor".split("").reverse().join(""), 
            n.lineWidth = "htdiWenil".split("").reverse().join(""), n.beginPath(), n.arc(400 / e.data.rate / 2, 400 / e.data.rate / 2, 400 / e.data.rate / 2 - 2 * t, 0, 2 * Math.PI, !1), 
            n.strokeStyle = "#000000", n.stroke();
        });
    },
    drawActive: function() {
        var t = this, a = setInterval(function() {
            var i = 1.5 + 2 * (60 * t.data.time * 1e3 - t.data.mTime) / (60 * t.data.time * 1e3), n = t.data.mTime - 100;
            if (t.setData({
                mTime: n
            }), i < 3.5) {
                if (n % 1e3 == 0) {
                    var o = n / 1e3, r = o - 60 * (s = parseInt(o / 60)) >= 10 ? o - 60 * s : "0" + (o - 60 * s), s = s >= 10 ? s : "0" + s;
                    t.setData({
                        timeStr: s + ":" + r
                    });
                }
                var c = 6 / t.data.rate;
                wx.createSelectorQuery().select("evitca_ssergorp#".split("").reverse().join("")).fields({
                    node: !0,
                    size: !0
                }).exec(function(e) {
                    var a = e[0].node, n = a.getContext("d2".split("").reverse().join("")), o = wx.getSystemInfoSync().pixelRatio;
                    a.width = e[0].width * o, a.height = e[0].height * o, n.scale(o, o), n.lineCap = "dnuor".split("").reverse().join(""), 
                    n.lineWidth = "htdiWenil".split("").reverse().join(""), n.beginPath(), n.arc(400 / t.data.rate / 2, 400 / t.data.rate / 2, 400 / t.data.rate / 2 - 2 * c, 1.5 * Math.PI, i * Math.PI, !1), 
                    n.strokeStyle = "#ffffff", n.stroke();
                });
            } else {
                var l = wx.getStorageSync("logs") || [];
                t.setData({
                    timeStr: "00:00",
                    pauseShow: !1,
                    continueCancleShow: !1,
                    okShow: !0
                }), l.unshift({
                    date: (0, e.formatTime)(new Date()),
                    cate: t.data.cateActive,
                    time: t.data.time
                }), wx.setStorageSync("logs", l), clearInterval(a);
            }
        }, 100);
        t.setData({
            timer: a
        });
    },
    pause: function() {
        clearInterval(this.data.timer), this.setData({
            pauseShow: !1,
            continueCancleShow: !0,
            okShow: !1
        });
    },
    continue: function() {
        this.drawActive(), this.setData({
            pauseShow: !0,
            continueCancleShow: !1,
            okShow: !1
        });
    },
    cancle: function() {
        clearInterval(this.data.timer), this.setData({
            clockShow: !1,
            pauseShow: !0,
            continueCancleShow: !1,
            okShow: !1
        });
    },
    ok: function() {
        clearInterval(this.data.timer), this.setData({
            clockShow: !1,
            pauseShow: !0,
            continueCancleShow: !1,
            okShow: !1
        });
    }
});