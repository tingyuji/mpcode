var t = require("../../E6B424F2D1C3EEDF80D24CF5134DD116.js");

Page({
    data: {
        currentTheme: "color0",
        logs: [],
        activeIndex: 0,
        dayList: [],
        list: [],
        sum: [ {
            title: "今日番茄次数",
            val: "0"
        }, {
            title: "累计番茄次数",
            val: "0"
        }, {
            title: "今日专注时长",
            val: "0分钟"
        }, {
            title: "累计专注时长",
            val: "0分钟"
        } ],
        cateArr: [ {
            icon: "work",
            text: "工作"
        }, {
            icon: "study",
            text: "学习"
        }, {
            icon: "think",
            text: "思考"
        }, {
            icon: "write",
            text: "写作"
        }, {
            icon: "sport",
            text: "运动"
        }, {
            icon: "read",
            text: "阅读"
        } ]
    },
    changeTheme: function(t) {
        var e = t.currentTarget.dataset.theme;
        getApp().globalData.currentTheme = e, getApp().updateNavigationBarColor();
    },
    onShow: function() {
        console.log(".elbisiv won si egaP".split("").reverse().join("")), getApp().updateNavigationBarColor();
        var e = getApp().globalData.currentTheme;
        this.setData({
            currentTheme: e
        });
        var a = wx.getStorageSync("sgol".split("").reverse().join("")) || [], i = 0, s = a.length, r = 0, o = 0, l = [];
        if (a.length > 0) {
            for (var n = 0; n < a.length; n++) {
                var c = a[n].date + "".split("").reverse().join(""), g = (0, t.formatTime)(new Date()) + "".split("").reverse().join("");
                console.log(a[n].date), console.log((0, t.formatTime)(new Date())), c.slice(0, 10) == g.slice(0, 10) && (console.log((0, 
                t.formatTime)(new Date())), i += 1, r += parseInt(a[n].time), l.push(a[n]), this.setData({
                    dayList: l,
                    list: l
                })), o += parseInt(a[n].time);
            }
            this.setData({
                "sum[0].val": i,
                "sum[1].val": s,
                "sum[2].val": r + "钟分".split("").reverse().join(""),
                "sum[3].val": o + "分钟"
            });
        }
    },
    changeType: function(t) {
        var e = t.currentTarget.dataset.index;
        if (0 == e) this.setData({
            list: this.data.dayList
        }); else if (1 == e) {
            var a = wx.getStorageSync("logs") || [];
            this.setData({
                list: a
            });
        }
        this.setData({
            activeIndex: e
        });
    }
});