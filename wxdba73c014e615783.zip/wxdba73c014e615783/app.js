App({
    globalData: {
        currentTheme: "color0",
        themeColors: {
            color0: "#Ff5556",
            color1: "#00BFFF",
            color2: "#20B2AA",
            color3: "#9370DB",
            color4: "#4682B4",
            color5: "#FFA07A",
            color6: "#7B68EE",
            color7: "#FF7F50",
            color8: "#32CD32"
        }
    },
    onLaunch: function() {
        this.updateNavigationBarColor(), wx.cloud ? wx.cloud.init({
            traceUser: !0,
            keepScreenOn: !0
        }) : console.error("力能云用使以库础基的上以或 3.2.2 用使请".split("").reverse().join(""));
    },
    updateNavigationBarColor: function() {
        var o = this.globalData.currentTheme, r = this.globalData.themeColors[o];
        wx.setNavigationBarColor({
            frontColor: "#ffffff",
            backgroundColor: r
        });
    }
});