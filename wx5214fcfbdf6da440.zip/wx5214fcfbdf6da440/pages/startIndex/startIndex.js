var _typeof2 = require("../../@babel/runtime/helpers/typeof");

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "pages/startIndex/startIndex" ], {
    "0082": function _(e, n, t) {
        "use strict";
        (function(e) {
            t("6cdc");
            var n = i(t("0c4a"));
            function i(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            e(n.default);
        }).call(this, t("543d")["createPage"]);
    },
    "0c4a": function c4a(e, n, t) {
        "use strict";
        t.r(n);
        var i = t("55e5"), r = t("c9f6");
        for (var c in r) [ "default" ].indexOf(c) < 0 && function(e) {
            t.d(n, e, function() {
                return r[e];
            });
        }(c);
        var o, a = t("f0c5"), u = Object(a["a"])(r["default"], i["b"], i["c"], !1, null, null, null, !1, i["a"], o);
        n["default"] = u.exports;
    },
    "55e5": function e5(e, n, t) {
        "use strict";
        var i;
        t.d(n, "b", function() {
            return r;
        }), t.d(n, "c", function() {
            return c;
        }), t.d(n, "a", function() {
            return i;
        });
        var r = function r() {
            var e = this, n = e.$createElement;
            e._self._c;
        }, c = [];
    },
    c9f6: function c9f6(e, n, t) {
        "use strict";
        t.r(n);
        var i = t("d262"), r = t.n(i);
        for (var c in i) [ "default" ].indexOf(c) < 0 && function(e) {
            t.d(n, e, function() {
                return i[e];
            });
        }(c);
        n["default"] = r.a;
    },
    d262: function d262(e, n, t) {
        "use strict";
        (function(e) {
            function i(e) {
                return i = "function" === typeof Symbol && "symbol" === _typeof2(Symbol.iterator) ? function(e) {
                    return _typeof2(e);
                } : function(e) {
                    return e && "function" === typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : _typeof2(e);
                }, i(e);
            }
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var r = t("9ab4"), c = t("60a3"), o = u(t("4328")), a = [ "url" ];
            function u(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            function s(e, n) {
                return g(e) || p(e, n) || f(e, n) || l();
            }
            function l() {
                throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
            }
            function f(e, n) {
                if (e) {
                    if ("string" === typeof e) return d(e, n);
                    var t = Object.prototype.toString.call(e).slice(8, -1);
                    return "Object" === t && e.constructor && (t = e.constructor.name), "Map" === t || "Set" === t ? Array.from(e) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? d(e, n) : void 0;
                }
            }
            function d(e, n) {
                (null == n || n > e.length) && (n = e.length);
                for (var t = 0, i = new Array(n); t < n; t++) i[t] = e[t];
                return i;
            }
            function p(e, n) {
                var t = null == e ? null : "undefined" !== typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
                if (null != t) {
                    var i, r, c = [], o = !0, a = !1;
                    try {
                        for (t = t.call(e); !(o = (i = t.next()).done); o = !0) if (c.push(i.value), n && c.length === n) break;
                    } catch (u) {
                        a = !0, r = u;
                    } finally {
                        try {
                            o || null == t["return"] || t["return"]();
                        } finally {
                            if (a) throw r;
                        }
                    }
                    return c;
                }
            }
            function g(e) {
                if (Array.isArray(e)) return e;
            }
            function b(e, n) {
                if (null == e) return {};
                var t, i, r = y(e, n);
                if (Object.getOwnPropertySymbols) {
                    var c = Object.getOwnPropertySymbols(e);
                    for (i = 0; i < c.length; i++) t = c[i], n.indexOf(t) >= 0 || Object.prototype.propertyIsEnumerable.call(e, t) && (r[t] = e[t]);
                }
                return r;
            }
            function y(e, n) {
                if (null == e) return {};
                var t, i, r = {}, c = Object.keys(e);
                for (i = 0; i < c.length; i++) t = c[i], n.indexOf(t) >= 0 || (r[t] = e[t]);
                return r;
            }
            function _(e, n) {
                if (!(e instanceof n)) throw new TypeError("Cannot call a class as a function");
            }
            function h(e, n) {
                for (var t = 0; t < n.length; t++) {
                    var i = n[t];
                    i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), 
                    Object.defineProperty(e, i.key, i);
                }
            }
            function m(e, n, t) {
                return n && h(e.prototype, n), t && h(e, t), e;
            }
            function v(e, n) {
                if ("function" !== typeof n && null !== n) throw new TypeError("Super expression must either be null or a function");
                e.prototype = Object.create(n && n.prototype, {
                    constructor: {
                        value: e,
                        writable: !0,
                        configurable: !0
                    }
                }), n && x(e, n);
            }
            function x(e, n) {
                return x = Object.setPrototypeOf || function(e, n) {
                    return e.__proto__ = n, e;
                }, x(e, n);
            }
            function O(e) {
                var n = w();
                return function() {
                    var t, i = I(e);
                    if (n) {
                        var r = I(this).constructor;
                        t = Reflect.construct(i, arguments, r);
                    } else t = i.apply(this, arguments);
                    return k(this, t);
                };
            }
            function k(e, n) {
                if (n && ("object" === i(n) || "function" === typeof n)) return n;
                if (void 0 !== n) throw new TypeError("Derived constructors may only return object or undefined");
                return j(e);
            }
            function j(e) {
                if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                return e;
            }
            function w() {
                if ("undefined" === typeof Reflect || !Reflect.construct) return !1;
                if (Reflect.construct.sham) return !1;
                if ("function" === typeof Proxy) return !0;
                try {
                    return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
                    !0;
                } catch (e) {
                    return !1;
                }
            }
            function I(e) {
                return I = Object.setPrototypeOf ? Object.getPrototypeOf : function(e) {
                    return e.__proto__ || Object.getPrototypeOf(e);
                }, I(e);
            }
            var S = function(n) {
                v(i, n);
                var t = O(i);
                function i() {
                    return _(this, i), t.apply(this, arguments);
                }
                return m(i, [ {
                    key: "onLoad",
                    value: function value(n) {
                        if (n.q) {
                            var t = o.default.parse(decodeURIComponent(n.q).split("?")[1], {
                                ignoreQueryPrefix: !0
                            });
                            console.log(t);
                            var i = {
                                utm_tid: t.utm_tid
                            }, r = "/pages/index/index";
                            switch (t.module) {
                              case "scenic_info":
                                Object.assign(i, {
                                    id: t.scenic_id,
                                    bspot_id: t.bspot_id,
                                    inside_scenic_id: t.inside_scenic_id
                                }), r = "/package/explain/pages/guide/guide";
                                break;

                              case "scenic_introduce":
                                Object.assign(i, {
                                    id: t.scenic_id
                                }), r = "/package/explain/pages/scenic/scenic";
                                break;

                              case "museum_info":
                                Object.assign(i, {
                                    id: t.scenic_id,
                                    bspot_id: t.bspot_id,
                                    inside_scenic_id: t.inside_scenic_id
                                }), r = t.inside_scenic_id && t.bspot_id ? "/package/explain/pages/guide/guide" : "/package/explain/pages/scenic/scenic";
                                break;

                              case "scenic_details":
                                Object.assign(i, {
                                    id: t.scenic_id
                                }), r = "/package/explain/pages/scenic/scenic";
                                break;

                              case "scenic_list":
                                Object.assign(i, {
                                    id: t.country_id || t.city_id,
                                    level: t.country_id ? 0 : 2
                                }), r = "/package/explain/pages/list/list";
                                break;

                              case "personal":
                                Object.assign(i, {
                                    id: t.guider_uid
                                }), r = "/package/author/pages/scenic/scenic";
                                break;

                              case "search":
                                r = "/pages/search/search";
                                break;

                              default:
                                if (t.url) {
                                    var c = t.url.split("?");
                                    Object.assign(i, o.default.parse(decodeURIComponent(c[1]))), r = P(c[0]);
                                } else t.scenic_id && (Object.assign(i, {
                                    id: t.scenic_id,
                                    bspot_id: t.bspot_id
                                }), r = t.bspot_id ? "/package/explain/pages/guide/guide" : "/package/explain/pages/scenic/scenic");
                            }
                            console.log(r, i), e.reLaunch({
                                url: "".concat(r, "?").concat(o.default.stringify(i))
                            }), this.$uma.trackEvent("scan_portal", t);
                        } else {
                            var u = n.url, l = b(n, a), f = decodeURIComponent(u || "").split("?"), d = s(f, 2), p = d[0], g = d[1];
                            Object.assign(l, o.default.parse(g)), console.log(P(p), l), e.reLaunch({
                                url: "".concat(P(p), "?").concat(o.default.stringify(l))
                            });
                        }
                    }
                } ]), i;
            }(c.Vue);
            S = (0, r.__decorate)([ c.Component ], S);
            var E = S;
            n.default = E;
            var P = function P(e) {
                var n = {
                    "/pages/moduleExplain/scenicIndex/scenicIndex": "/package/explain/pages/scenic/scenic",
                    "/pages/moduleExplain/scenicGuide/scenicGuide": "/package/explain/pages/guide/guide",
                    "/pages/moduleExplain/scenicList/scenicList": "/package/explain/pages/list/list",
                    "/pages/moduleSchool/courseIndex/courseIndex": "/package/school/pages/course/course",
                    "/pages/moduleExhibition/exhibitionList/exhibitionList": "/package/exhibition/pages/list/list",
                    "/pages/moduleExhibition/exhibitionIndex/exhibitionIndex": "/package/exhibition/pages/detail/detail",
                    "/pages/moduleCultural/culturalIndex/culturalIndex": "/package/cultural/pages/index/index"
                };
                return n[e] || e || "/pages/index/index";
            };
        }).call(this, t("543d")["default"]);
    }
}, [ [ "0082", "common/runtime", "common/vendor" ] ] ]);