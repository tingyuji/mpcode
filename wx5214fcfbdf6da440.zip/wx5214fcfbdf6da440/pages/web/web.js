require("../../@babel/runtime/helpers/Arrayincludes");

var _typeof2 = require("../../@babel/runtime/helpers/typeof");

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "pages/web/web" ], {
    "028c": function c(t, e, n) {
        "use strict";
        (function(t) {
            n("6cdc");
            var e = o(n("d5d4"));
            function o(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            t(e.default);
        }).call(this, n("543d")["createPage"]);
    },
    "8dbe": function dbe(t, e, n) {
        "use strict";
        n.r(e);
        var o = n("e2a0"), r = n.n(o);
        for (var u in o) [ "default" ].indexOf(u) < 0 && function(t) {
            n.d(e, t, function() {
                return o[t];
            });
        }(u);
        e["default"] = r.a;
    },
    "9ff1": function ff1(t, e, n) {
        "use strict";
        var o;
        n.d(e, "b", function() {
            return r;
        }), n.d(e, "c", function() {
            return u;
        }), n.d(e, "a", function() {
            return o;
        });
        var r = function r() {
            var t = this, e = t.$createElement;
            t._self._c;
        }, u = [];
    },
    d5d4: function d5d4(t, e, n) {
        "use strict";
        n.r(e);
        var o = n("9ff1"), r = n("8dbe");
        for (var u in r) [ "default" ].indexOf(u) < 0 && function(t) {
            n.d(e, t, function() {
                return r[t];
            });
        }(u);
        var c, i = n("f0c5"), a = Object(i["a"])(r["default"], o["b"], o["c"], !1, null, null, null, !1, o["a"], c);
        e["default"] = a.exports;
    },
    e2a0: function e2a0(t, e, n) {
        "use strict";
        (function(t) {
            function o(t) {
                return o = "function" === typeof Symbol && "symbol" === _typeof2(Symbol.iterator) ? function(t) {
                    return _typeof2(t);
                } : function(t) {
                    return t && "function" === typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : _typeof2(t);
                }, o(t);
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var r = n("9ab4"), u = n("60a3"), c = p(n("50f2")), i = p(n("422e")), a = p(n("9050")), f = p(n("5367")), l = p(n("5274")), s = p(n("75c8")), d = p(n("4328"));
            function p(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            function v(t, e) {
                if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function");
            }
            function y(t, e) {
                for (var n = 0; n < e.length; n++) {
                    var o = e[n];
                    o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), 
                    Object.defineProperty(t, o.key, o);
                }
            }
            function b(t, e, n) {
                return e && y(t.prototype, e), n && y(t, n), t;
            }
            function h(t, e) {
                if ("function" !== typeof e && null !== e) throw new TypeError("Super expression must either be null or a function");
                t.prototype = Object.create(e && e.prototype, {
                    constructor: {
                        value: t,
                        writable: !0,
                        configurable: !0
                    }
                }), e && g(t, e);
            }
            function g(t, e) {
                return g = Object.setPrototypeOf || function(t, e) {
                    return t.__proto__ = e, t;
                }, g(t, e);
            }
            function m(t) {
                var e = O();
                return function() {
                    var n, o = j(t);
                    if (e) {
                        var r = j(this).constructor;
                        n = Reflect.construct(o, arguments, r);
                    } else n = o.apply(this, arguments);
                    return _(this, n);
                };
            }
            function _(t, e) {
                if (e && ("object" === o(e) || "function" === typeof e)) return e;
                if (void 0 !== e) throw new TypeError("Derived constructors may only return object or undefined");
                return w(t);
            }
            function w(t) {
                if (void 0 === t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                return t;
            }
            function O() {
                if ("undefined" === typeof Reflect || !Reflect.construct) return !1;
                if (Reflect.construct.sham) return !1;
                if ("function" === typeof Proxy) return !0;
                try {
                    return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
                    !0;
                } catch (t) {
                    return !1;
                }
            }
            function j(t) {
                return j = Object.setPrototypeOf ? Object.getPrototypeOf : function(t) {
                    return t.__proto__ || Object.getPrototypeOf(t);
                }, j(t);
            }
            var C = function(e) {
                h(o, e);
                var n = m(o);
                function o() {
                    var t;
                    return v(this, o), t = n.apply(this, arguments), t.url = "", t;
                }
                return b(o, [ {
                    key: "onLoad",
                    value: function value(e) {
                        var n = this;
                        this.init(e.utm_tid).then(function() {
                            var o = function o() {
                                var t = decodeURIComponent(e.url);
                                n.shareConfig = {
                                    path: "/pages/web/web?".concat(d.default.stringify({
                                        url: t
                                    }))
                                };
                                var o = encodeURIComponent(l.default.getCpl());
                                if (t += "".concat(t.includes("?") ? "&" : "?", "cpl=").concat(o), s.default.check()) {
                                    var r = encodeURIComponent(l.default.getAuth(s.default.get()));
                                    t += "&auth=".concat(r, "&access_token=").concat(r);
                                }
                                console.log("url", t), n.url = t.startsWith("https://") ? t : "".concat(a.default.get()).concat(t);
                            };
                            "1" === e.login ? f.default.checkLogin().then(o).catch(function() {
                                return t.navigateBack({});
                            }) : o();
                        });
                    }
                }, {
                    key: "onMessage",
                    value: function value(t) {
                        var e = t.detail.data.find(function(t) {
                            return "share" === t.type;
                        });
                        null !== e && void 0 !== e && e.url && (this.shareConfig.path = "/pages/web/web?".concat(d.default.stringify({
                            url: e.url,
                            login: null === e || void 0 === e ? void 0 : e.login
                        }))), null !== e && void 0 !== e && e.title && (this.shareConfig.title = e.title), 
                        null !== e && void 0 !== e && e.imageUrl && (this.shareConfig.imageUrl = e.imageUrl);
                    }
                } ]), o;
            }((0, u.Mixins)(c.default, i.default));
            C = (0, r.__decorate)([ u.Component ], C);
            var k = C;
            e.default = k;
        }).call(this, n("543d")["default"]);
    }
}, [ [ "028c", "common/runtime", "common/vendor" ] ] ]);