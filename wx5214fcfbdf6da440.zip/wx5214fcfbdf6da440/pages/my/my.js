var _typeof2 = require("../../@babel/runtime/helpers/typeof");

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "pages/my/my" ], {
    "0187": function _(t, e, n) {
        "use strict";
        n.r(e);
        var o = n("d243"), i = n("44c4");
        for (var r in i) [ "default" ].indexOf(r) < 0 && function(t) {
            n.d(e, t, function() {
                return i[t];
            });
        }(r);
        n("5835");
        var u, c = n("f0c5"), a = Object(c["a"])(i["default"], o["b"], o["c"], !1, null, null, null, !1, o["a"], u);
        e["default"] = a.exports;
    },
    "44c4": function c4(t, e, n) {
        "use strict";
        n.r(e);
        var o = n("9444"), i = n.n(o);
        for (var r in o) [ "default" ].indexOf(r) < 0 && function(t) {
            n.d(e, t, function() {
                return o[t];
            });
        }(r);
        e["default"] = i.a;
    },
    "565c": function c(t, e, n) {},
    5835: function _(t, e, n) {
        "use strict";
        var o = n("565c"), i = n.n(o);
        i.a;
    },
    "71dc": function dc(t, e, n) {
        "use strict";
        (function(t) {
            n("6cdc");
            var e = o(n("0187"));
            function o(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            t(e.default);
        }).call(this, n("543d")["createPage"]);
    },
    9444: function _(t, e, n) {
        "use strict";
        (function(t) {
            function o(t) {
                return o = "function" === typeof Symbol && "symbol" === _typeof2(Symbol.iterator) ? function(t) {
                    return _typeof2(t);
                } : function(t) {
                    return t && "function" === typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : _typeof2(t);
                }, o(t);
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var i = n("9ab4"), r = n("60a3"), u = f(n("5367")), c = f(n("7234")), a = f(n("75c8")), l = f(n("8d00")), s = f(n("a227"));
            function f(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            function p(t, e) {
                if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function");
            }
            function d(t, e) {
                for (var n = 0; n < e.length; n++) {
                    var o = e[n];
                    o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), 
                    Object.defineProperty(t, o.key, o);
                }
            }
            function v(t, e, n) {
                return e && d(t.prototype, e), n && d(t, n), t;
            }
            function h(t, e) {
                if ("function" !== typeof e && null !== e) throw new TypeError("Super expression must either be null or a function");
                t.prototype = Object.create(e && e.prototype, {
                    constructor: {
                        value: t,
                        writable: !0,
                        configurable: !0
                    }
                }), e && g(t, e);
            }
            function g(t, e) {
                return g = Object.setPrototypeOf || function(t, e) {
                    return t.__proto__ = e, t;
                }, g(t, e);
            }
            function y(t) {
                var e = k();
                return function() {
                    var n, o = _(t);
                    if (e) {
                        var i = _(this).constructor;
                        n = Reflect.construct(o, arguments, i);
                    } else n = o.apply(this, arguments);
                    return b(this, n);
                };
            }
            function b(t, e) {
                if (e && ("object" === o(e) || "function" === typeof e)) return e;
                if (void 0 !== e) throw new TypeError("Derived constructors may only return object or undefined");
                return m(t);
            }
            function m(t) {
                if (void 0 === t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                return t;
            }
            function k() {
                if ("undefined" === typeof Reflect || !Reflect.construct) return !1;
                if (Reflect.construct.sham) return !1;
                if ("function" === typeof Proxy) return !0;
                try {
                    return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
                    !0;
                } catch (t) {
                    return !1;
                }
            }
            function _(t) {
                return _ = Object.setPrototypeOf ? Object.getPrototypeOf : function(t) {
                    return t.__proto__ || Object.getPrototypeOf(t);
                }, _(t);
            }
            var w = function(e) {
                h(o, e);
                var n = y(o);
                function o() {
                    var t;
                    return p(this, o), t = n.apply(this, arguments), t.isIos = !0, t.avatarUrl = "", 
                    t.nickname = "", t.vipState = 0, t.vipDate = "", t.productVisible = !1, t.productList = [], 
                    t.adList = [], t.couponNum = 0, t.orderMenuList = [ {
                        url: "/package/order/pages/scenic/scenic",
                        icon: "",
                        title: "景区订单"
                    }, {
                        url: "/package/order/pages/course/course",
                        icon: "",
                        title: "课程订单"
                    }, {
                        url: "/package/order/pages/gold/gold",
                        icon: "",
                        title: "金牌说订单"
                    }, {
                        url: "/package/order/pages/list/list",
                        icon: "",
                        title: "商品订单"
                    } ], t.serviceMenuList = [ {
                        url: "/package/user/pages/collect/collect",
                        icon: "",
                        title: "收藏",
                        login: 0
                    }, {
                        url: "/package/user/pages/follow/follow",
                        icon: "",
                        title: "关注"
                    }, {
                        url: "/package/user/pages/comment/comment",
                        icon: "",
                        title: "评论"
                    }, {
                        url: "/package/user/pages/like/like",
                        icon: "",
                        title: "点赞"
                    } ], t.otherMenuList = [], t;
                }
                return v(o, [ {
                    key: "onLoad",
                    value: function value() {
                        this.updateUserInfo(), this.getProductList();
                        var t = l.default.get();
                        this.serviceMenuList.push({
                            url: t.user_address_url,
                            icon: "",
                            title: "地址管理",
                            login: 1
                        }, {
                            url: t.tour_user_info_url,
                            icon: "",
                            title: "常用信息",
                            login: 1
                        }), this.otherMenuList = [ {
                            url: t.feedback,
                            icon: "",
                            title: "意见反馈",
                            login: 1
                        }, {
                            url: "/package/user/pages/contact/contact",
                            icon: "",
                            title: "联系客服"
                        }, {
                            url: "/package/user/pages/setting/setting",
                            icon: "",
                            title: "设置"
                        } ], this.isIos = getApp().globalData.ios, this.isIos || this.otherMenuList.unshift({
                            url: t.business,
                            icon: "",
                            title: "商务合作"
                        }, {
                            url: t.help_center,
                            icon: "",
                            title: "帮助中心"
                        }, {
                            url: t.pay_desc,
                            icon: "",
                            title: "收费说明"
                        });
                    }
                }, {
                    key: "onShow",
                    value: function value() {
                        this.updateUserInfo();
                    }
                }, {
                    key: "updateUserInfo",
                    value: function value() {
                        if (a.default.check()) {
                            var t = a.default.get();
                            this.avatarUrl = t.third_img, this.nickname = t.nick_name, this.updateVipInfo();
                        } else this.avatarUrl = "/static/my/avatar.png", this.nickname = "登录/注册", this.vipState = 0, 
                        this.couponNum = 0;
                    }
                }, {
                    key: "updateVipInfo",
                    value: function value() {
                        var t = this;
                        c.default.get("/user/center").then(function(e) {
                            var n = e.member_data;
                            t.vipState = n.status, t.vipDate = n.end_time, t.vipIntroUrl = n.url, t.couponNum = n.coupon_count;
                        });
                    }
                }, {
                    key: "getProductList",
                    value: function value() {
                        var t = this;
                        c.default.get("/member_vip/product_list").then(function(e) {
                            t.productList = e.product_vip_list, t.adList = e.ad_vip_list;
                        });
                    }
                }, {
                    key: "navigateTo",
                    value: function value(e) {
                        var n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
                        t.navigateTo({
                            url: e.startsWith("https://") ? "/pages/web/web?url=".concat(encodeURIComponent(e), "&login=").concat(n) : e
                        });
                    }
                }, {
                    key: "avatarClick",
                    value: function value() {
                        a.default.check() ? t.navigateTo({
                            url: "/package/user/pages/detail/detail"
                        }) : u.default.login().catch(function() {});
                    }
                }, {
                    key: "vipIntroClick",
                    value: function value() {
                        this.navigateTo(this.vipIntroUrl);
                    }
                }, {
                    key: "productClick",
                    value: function value(t) {
                        this.navigateTo(t), this.productVisible = !1;
                    }
                }, {
                    key: "rechargeClick",
                    value: function value() {
                        s.default.showToast("为保证您的资金安全，请到三毛游APP进行充值");
                    }
                }, {
                    key: "activeClick",
                    value: function value() {
                        var t = this;
                        u.default.checkLogin().then(function() {
                            return t.$refs.activation.open();
                        });
                    }
                } ]), o;
            }(r.Vue);
            w = (0, i.__decorate)([ r.Component ], w);
            var O = w;
            e.default = O;
        }).call(this, n("543d")["default"]);
    },
    d243: function d243(t, e, n) {
        "use strict";
        n.d(e, "b", function() {
            return i;
        }), n.d(e, "c", function() {
            return r;
        }), n.d(e, "a", function() {
            return o;
        });
        var o = {
            overlay: function overlay() {
                return n.e("components/overlay/overlay").then(n.bind(null, "9c32"));
            },
            activation: function activation() {
                return n.e("components/activation/activation").then(n.bind(null, "c210"));
            }
        }, i = function i() {
            var t = this, e = t.$createElement;
            t._self._c;
            t._isMounted || (t.e0 = function(e) {
                t.productVisible = !0;
            }, t.e1 = function(e) {
                t.productVisible = !1;
            });
        }, r = [];
    }
}, [ [ "71dc", "common/runtime", "common/vendor" ] ] ]);