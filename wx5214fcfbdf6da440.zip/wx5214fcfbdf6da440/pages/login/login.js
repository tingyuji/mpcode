var _typeof2 = require("../../@babel/runtime/helpers/typeof");

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "pages/login/login" ], {
    6726: function _(e, t, n) {
        "use strict";
        (function(e) {
            function o(e) {
                return o = "function" === typeof Symbol && "symbol" === _typeof2(Symbol.iterator) ? function(e) {
                    return _typeof2(e);
                } : function(e) {
                    return e && "function" === typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : _typeof2(e);
                }, o(e);
            }
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = n("9ab4"), c = n("60a3"), i = d(n("27f8")), u = d(n("8d00")), a = d(n("a227")), f = d(n("7234")), l = d(n("75c8")), s = n("eb95");
            function d(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            function p(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(e);
                    t && (o = o.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable;
                    })), n.push.apply(n, o);
                }
                return n;
            }
            function b(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? p(Object(n), !0).forEach(function(t) {
                        y(e, t, n[t]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : p(Object(n)).forEach(function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
                    });
                }
                return e;
            }
            function y(e, t, n) {
                return t in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e;
            }
            function h(e, t) {
                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
            }
            function v(e, t) {
                for (var n = 0; n < t.length; n++) {
                    var o = t[n];
                    o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), 
                    Object.defineProperty(e, o.key, o);
                }
            }
            function m(e, t, n) {
                return t && v(e.prototype, t), n && v(e, n), e;
            }
            function g(e, t) {
                if ("function" !== typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
                e.prototype = Object.create(t && t.prototype, {
                    constructor: {
                        value: e,
                        writable: !0,
                        configurable: !0
                    }
                }), t && O(e, t);
            }
            function O(e, t) {
                return O = Object.setPrototypeOf || function(e, t) {
                    return e.__proto__ = t, e;
                }, O(e, t);
            }
            function w(e) {
                var t = k();
                return function() {
                    var n, o = P(e);
                    if (t) {
                        var r = P(this).constructor;
                        n = Reflect.construct(o, arguments, r);
                    } else n = o.apply(this, arguments);
                    return _(this, n);
                };
            }
            function _(e, t) {
                if (t && ("object" === o(t) || "function" === typeof t)) return t;
                if (void 0 !== t) throw new TypeError("Derived constructors may only return object or undefined");
                return j(e);
            }
            function j(e) {
                if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                return e;
            }
            function k() {
                if ("undefined" === typeof Reflect || !Reflect.construct) return !1;
                if (Reflect.construct.sham) return !1;
                if ("function" === typeof Proxy) return !0;
                try {
                    return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
                    !0;
                } catch (e) {
                    return !1;
                }
            }
            function P(e) {
                return P = Object.setPrototypeOf ? Object.getPrototypeOf : function(e) {
                    return e.__proto__ || Object.getPrototypeOf(e);
                }, P(e);
            }
            var R = function(t) {
                g(o, t);
                var n = w(o);
                function o() {
                    var e;
                    return h(this, o), e = n.apply(this, arguments), e.checked = !1, e.phone = "", e.code = "", 
                    e.modalVisible = !1, e.openType = "getUserInfo", e;
                }
                return m(o, [ {
                    key: "onLoad",
                    value: function value() {
                        var t = this;
                        this.openType = "", e.login({
                            success: function success(e) {
                                return t.loginRes = e;
                            }
                        });
                    }
                }, {
                    key: "checkboxClick",
                    value: function value() {
                        this.checked = !this.checked;
                    }
                }, {
                    key: "agreementClick",
                    value: function value() {
                        e.navigateTo({
                            url: "/pages/web/web?url=".concat(encodeURIComponent(u.default.get().user_agreement))
                        });
                    }
                }, {
                    key: "loginClick",
                    value: function value() {
                        a.default.showToast("请先阅读并同意三毛游用户服务协议");
                    }
                }, {
                    key: "onGetPhoneNumber",
                    value: function value(t) {
                        var n = this, o = t.detail;
                        o.errMsg.includes("ok") && (this.mobile = o, a.default.showLoading(), f.default.post("/v1/mini_app/login", b(b({}, this.loginRes), {}, {
                            mobile: {
                                encryptedData: o.encryptedData,
                                iv: o.iv,
                                code: o.code
                            }
                        })).then(function(t) {
                            l.default.set(t), e.hideLoading(), n.eventChannel.emit("success"), e.$emit(s.EV_LOGIN, {
                                type: "success"
                            });
                        }).catch(function(t) {
                            console.error(t), e.hideLoading(), a.default.showToast(t.message);
                        }));
                    }
                }, {
                    key: "onGetUserInfo",
                    value: function value(e) {
                        this.login(e.detail);
                    }
                }, {
                    key: "onConfirm",
                    value: function value() {
                        var t = this;
                        e.getUserProfile({
                            desc: "为同步您的个人数据",
                            success: function success(e) {
                                return t.login(e);
                            }
                        });
                    }
                }, {
                    key: "login",
                    value: function value(t) {
                        var n = this;
                        a.default.showLoading(), f.default.post("/mini_member_login/login", this.loginRes).then(function(o) {
                            return l.default.set(o), f.default.post("/mini_member_login/authorization", {
                                mobile: n.mobile,
                                user_info: t
                            }).then(function(t) {
                                l.default.set(t), e.hideLoading(), n.eventChannel.emit("success");
                            });
                        }).catch(function(t) {
                            console.error(t), l.default.remove(), e.hideLoading(), a.default.showToast(t.message);
                        });
                    }
                } ]), o;
            }((0, c.Mixins)(i.default));
            R = (0, r.__decorate)([ c.Component ], R);
            var C = R;
            t.default = C;
        }).call(this, n("543d")["default"]);
    },
    a86a: function a86a(e, t, n) {
        "use strict";
        n.r(t);
        var o = n("ed27"), r = n("c66f");
        for (var c in r) [ "default" ].indexOf(c) < 0 && function(e) {
            n.d(t, e, function() {
                return r[e];
            });
        }(c);
        n("bc24");
        var i, u = n("f0c5"), a = Object(u["a"])(r["default"], o["b"], o["c"], !1, null, null, null, !1, o["a"], i);
        t["default"] = a.exports;
    },
    bc24: function bc24(e, t, n) {
        "use strict";
        var o = n("fcc3"), r = n.n(o);
        r.a;
    },
    c66f: function c66f(e, t, n) {
        "use strict";
        n.r(t);
        var o = n("6726"), r = n.n(o);
        for (var c in o) [ "default" ].indexOf(c) < 0 && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(c);
        t["default"] = r.a;
    },
    e150: function e150(e, t, n) {
        "use strict";
        (function(e) {
            n("6cdc");
            var t = o(n("a86a"));
            function o(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            e(t.default);
        }).call(this, n("543d")["createPage"]);
    },
    ed27: function ed27(e, t, n) {
        "use strict";
        n.d(t, "b", function() {
            return r;
        }), n.d(t, "c", function() {
            return c;
        }), n.d(t, "a", function() {
            return o;
        });
        var o = {
            modal: function modal() {
                return n.e("components/modal/modal").then(n.bind(null, "c9cb"));
            }
        }, r = function r() {
            var e = this, t = e.$createElement;
            e._self._c;
        }, c = [];
    },
    fcc3: function fcc3(e, t, n) {}
}, [ [ "e150", "common/runtime", "common/vendor" ] ] ]);