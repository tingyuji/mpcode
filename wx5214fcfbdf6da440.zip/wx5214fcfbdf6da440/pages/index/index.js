var _typeof2 = require("../../@babel/runtime/helpers/typeof");

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "pages/index/index" ], {
    "0048": function _(t, e, n) {
        "use strict";
        n.d(e, "b", function() {
            return i;
        }), n.d(e, "c", function() {
            return r;
        }), n.d(e, "a", function() {
            return o;
        });
        var o = {
            searchBar: function searchBar() {
                return n.e("components/search-bar/search-bar").then(n.bind(null, "2f4c"));
            },
            moduleTitle: function moduleTitle() {
                return n.e("components/module-title/module-title").then(n.bind(null, "4cbf"));
            },
            loadMore: function loadMore() {
                return n.e("components/load-more/load-more").then(n.bind(null, "fbce"));
            },
            activation: function activation() {
                return n.e("components/activation/activation").then(n.bind(null, "c210"));
            }
        }, i = function i() {
            var t = this, e = t.$createElement;
            t._self._c;
        }, r = [];
    },
    "4d6f": function d6f(t, e, n) {},
    a547: function a547(t, e, n) {
        "use strict";
        n.r(e);
        var o = n("f374"), i = n.n(o);
        for (var r in o) [ "default" ].indexOf(r) < 0 && function(t) {
            n.d(e, t, function() {
                return o[t];
            });
        }(r);
        e["default"] = i.a;
    },
    b297: function b297(t, e, n) {
        "use strict";
        var o = n("4d6f"), i = n.n(o);
        i.a;
    },
    df45: function df45(t, e, n) {
        "use strict";
        (function(t) {
            n("6cdc");
            var e = o(n("f75a"));
            function o(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            t(e.default);
        }).call(this, n("543d")["createPage"]);
    },
    f374: function f374(t, e, n) {
        "use strict";
        (function(t) {
            function o(t) {
                return o = "function" === typeof Symbol && "symbol" === _typeof2(Symbol.iterator) ? function(t) {
                    return _typeof2(t);
                } : function(t) {
                    return t && "function" === typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : _typeof2(t);
                }, o(t);
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var i = n("9ab4"), r = n("60a3"), a = y(n("50f2")), u = y(n("422e")), c = y(n("326b")), l = y(n("7234")), s = y(n("a227")), f = y(n("29a5")), d = y(n("8d00")), p = y(n("5367")), h = y(n("75c8")), v = n("eb95");
            function y(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            function g(t, e) {
                return w(t) || k(t, e) || b(t, e) || m();
            }
            function m() {
                throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
            }
            function b(t, e) {
                if (t) {
                    if ("string" === typeof t) return _(t, e);
                    var n = Object.prototype.toString.call(t).slice(8, -1);
                    return "Object" === n && t.constructor && (n = t.constructor.name), "Map" === n || "Set" === n ? Array.from(t) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? _(t, e) : void 0;
                }
            }
            function _(t, e) {
                (null == e || e > t.length) && (e = t.length);
                for (var n = 0, o = new Array(e); n < e; n++) o[n] = t[n];
                return o;
            }
            function k(t, e) {
                var n = null == t ? null : "undefined" !== typeof Symbol && t[Symbol.iterator] || t["@@iterator"];
                if (null != n) {
                    var o, i, r = [], a = !0, u = !1;
                    try {
                        for (n = n.call(t); !(a = (o = n.next()).done); a = !0) if (r.push(o.value), e && r.length === e) break;
                    } catch (c) {
                        u = !0, i = c;
                    } finally {
                        try {
                            a || null == n["return"] || n["return"]();
                        } finally {
                            if (u) throw i;
                        }
                    }
                    return r;
                }
            }
            function w(t) {
                if (Array.isArray(t)) return t;
            }
            function x(t, e) {
                if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function");
            }
            function L(t, e) {
                for (var n = 0; n < e.length; n++) {
                    var o = e[n];
                    o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), 
                    Object.defineProperty(t, o.key, o);
                }
            }
            function T(t, e, n) {
                return e && L(t.prototype, e), n && L(t, n), t;
            }
            function C(t, e) {
                if ("function" !== typeof e && null !== e) throw new TypeError("Super expression must either be null or a function");
                t.prototype = Object.create(e && e.prototype, {
                    constructor: {
                        value: t,
                        writable: !0,
                        configurable: !0
                    }
                }), e && O(t, e);
            }
            function O(t, e) {
                return O = Object.setPrototypeOf || function(t, e) {
                    return t.__proto__ = e, t;
                }, O(t, e);
            }
            function I(t) {
                var e = P();
                return function() {
                    var n, o = R(t);
                    if (e) {
                        var i = R(this).constructor;
                        n = Reflect.construct(o, arguments, i);
                    } else n = o.apply(this, arguments);
                    return j(this, n);
                };
            }
            function j(t, e) {
                if (e && ("object" === o(e) || "function" === typeof e)) return e;
                if (void 0 !== e) throw new TypeError("Derived constructors may only return object or undefined");
                return S(t);
            }
            function S(t) {
                if (void 0 === t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                return t;
            }
            function P() {
                if ("undefined" === typeof Reflect || !Reflect.construct) return !1;
                if (Reflect.construct.sham) return !1;
                if ("function" === typeof Proxy) return !0;
                try {
                    return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
                    !0;
                } catch (t) {
                    return !1;
                }
            }
            function R(t) {
                return R = Object.setPrototypeOf ? Object.getPrototypeOf : function(t) {
                    return t.__proto__ || Object.getPrototypeOf(t);
                }, R(t);
            }
            var A = function A() {
                n.e("pages/index/components/add-my-mini").then(function() {
                    return resolve(n("d088"));
                }.bind(null, n)).catch(n.oe);
            }, M = function M() {
                n.e("pages/index/components/my-trip").then(function() {
                    return resolve(n("12d6"));
                }.bind(null, n)).catch(n.oe);
            }, D = function D() {
                n.e("pages/index/components/scenic-item").then(function() {
                    return resolve(n("6590"));
                }.bind(null, n)).catch(n.oe);
            }, E = function(e) {
                C(o, e);
                var n = I(o);
                function o() {
                    var t;
                    return x(this, o), t = n.apply(this, arguments), t.swipeIndex = 0, t.bannerList = [], 
                    t.moduleList = [ {
                        icon: "/static/index/jhm.png",
                        name: "激活码"
                    }, {
                        icon: "/static/index/hwjj.png",
                        name: "景区导览",
                        url: "/package/explain/pages/list/list"
                    }, {
                        icon: "/static/index/jps.png",
                        name: "金牌说",
                        url: "/package/guider/pages/list/list"
                    }, {
                        icon: "/static/index/zl.png",
                        name: "展览",
                        url: "/package/exhibition/pages/list/list"
                    } ], t.tripType = 1, t.tripNum = 0, t.tripList = [], t.activityList = [], t.cityInfo = null, 
                    t.sortId = 1, t.sortList = [ {
                        id: 1,
                        name: "距离"
                    }, {
                        id: 2,
                        name: "推荐"
                    } ], t.noPositionTip = "", t;
                }
                return T(o, [ {
                    key: "onLoad",
                    value: function value(e) {
                        var n = this;
                        this.init(e.utm_tid).then(function() {
                            n.reload();
                            var o = d.default.get();
                            1 === o.is_open_pay && n.moduleList.push({
                                icon: "/static/index/xt.png",
                                name: "学堂",
                                url: "/package/school/pages/index/index"
                            }), getApp().globalData.ios || n.moduleList.push({
                                icon: "/static/index/bzzx.png",
                                name: "帮助中心",
                                url: o.help_center
                            }), e.activationCode && n.activeClick(e.activationCode), console.log("订阅登录/退出通知事件------------------------"), 
                            t.$on(v.EV_LOGIN, function() {
                                console.log("首页，触发登录通知事件------------------------"), n.getTripList();
                            }), t.$on(v.EV_LOGOUT, function() {
                                console.log("首页，触发退出通知事件------------------------"), n.getTripList();
                            });
                        });
                    }
                }, {
                    key: "onPullDownRefresh",
                    value: function value() {
                        this.reload();
                    }
                }, {
                    key: "onReachBottom",
                    value: function value() {
                        this.loadMoreList();
                    }
                }, {
                    key: "reload",
                    value: function value() {
                        this.getDetail().then(function() {
                            return t.stopPullDownRefresh();
                        }), this.getTripList(), this.reloadScenic(getApp().globalData.position);
                    }
                }, {
                    key: "getDetail",
                    value: function value() {
                        var t = this;
                        return l.default.get("/home/mini_index").then(function(e) {
                            t.bannerList = e.mini_banner, t.activityList = e.hot_activity;
                        }).catch(function(t) {
                            console.error(t), s.default.showToast(t.message);
                        });
                    }
                }, {
                    key: "getTripList",
                    value: function value() {
                        var t = this;
                        h.default.check() ? l.default.get("/v1/gold_tour/user_tour_card").then(function(e) {
                            t.tripType = e.title.title_type, t.tripNum = e.title.count, t.tripList = e.list;
                        }).catch(function(t) {
                            console.error(t), s.default.showToast(t.message);
                        }) : this.tripList = [];
                    }
                }, {
                    key: "reloadScenic",
                    value: function value(t) {
                        var e = this;
                        this.getCityInfo(t).then(function(t) {
                            e.cityInfo = t, e.reloadList();
                        });
                    }
                }, {
                    key: "getCityInfo",
                    value: function value(t) {
                        return t.lng ? l.default.get("/home/get_geo").catch(function(t) {
                            return console.error(t), s.default.showToast(t.message), null;
                        }) : Promise.resolve(null);
                    }
                }, {
                    key: "getList",
                    value: function value() {
                        var t, e = this;
                        return l.default.get("/home/mini_home_waterfall", {
                            city_id: null === (t = this.cityInfo) || void 0 === t ? void 0 : t.city_id,
                            sort: this.sortId,
                            page: this.page
                        }).then(function(t) {
                            return e.noPositionTip = t.tips, {
                                list: t.items,
                                size: t.pagination.size
                            };
                        });
                    }
                }, {
                    key: "onSwipeChange",
                    value: function value(t) {
                        this.swipeIndex = t.detail.current;
                    }
                }, {
                    key: "navigateTo",
                    value: function value(e) {
                        var n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
                        t.navigateTo({
                            url: e.startsWith("https://") ? "/pages/web/web?url=".concat(encodeURIComponent(e), "&login=").concat(n) : e
                        });
                    }
                }, {
                    key: "bannerClick",
                    value: function value(t) {
                        var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
                        t = t.replace("/pages/moduleCultural/culturalIndex/culturalIndex", "/package/cultural/pages/index/index"), 
                        this.navigateTo(t, e);
                    }
                }, {
                    key: "moduleClick",
                    value: function value(t) {
                        t ? this.navigateTo(t) : this.activeClick();
                    }
                }, {
                    key: "tripCloseClick",
                    value: function value(t) {
                        var e = this.tripList.splice(t, 1), n = g(e, 1), o = n[0];
                        l.default.post("/gold_tour/close_travel_card", {
                            id: o.id
                        }).catch(function(t) {
                            console.error(t), s.default.showToast(t.message);
                        });
                    }
                }, {
                    key: "tripCommentClick",
                    value: function value(e) {
                        t.navigateTo({
                            url: "/pages/web/web?url=".concat(encodeURIComponent(e))
                        });
                    }
                }, {
                    key: "activeClick",
                    value: function value(t) {
                        var e = this;
                        p.default.checkLogin().then(function() {
                            return e.$refs.activation.open(t);
                        });
                    }
                }, {
                    key: "locationClick",
                    value: function value() {
                        var e = this;
                        f.default.auth("scope.userLocation").then(function() {
                            t.getLocation({
                                success: function success(t) {
                                    var n = {
                                        lng: t.longitude + "",
                                        lat: t.latitude + ""
                                    };
                                    getApp().globalData.position = n, e.reloadScenic(n);
                                }
                            });
                        });
                    }
                }, {
                    key: "scenicSortClick",
                    value: function value(t) {
                        this.sortId = t, this.reloadList();
                    }
                } ]), o;
            }((0, r.Mixins)(a.default, u.default, c.default));
            E = (0, i.__decorate)([ (0, r.Component)({
                components: {
                    AddMyMini: A,
                    myTrip: M,
                    ScenicItem: D
                }
            }) ], E);
            var z = E;
            e.default = z;
        }).call(this, n("543d")["default"]);
    },
    f75a: function f75a(t, e, n) {
        "use strict";
        n.r(e);
        var o = n("0048"), i = n("a547");
        for (var r in i) [ "default" ].indexOf(r) < 0 && function(t) {
            n.d(e, t, function() {
                return i[t];
            });
        }(r);
        n("b297");
        var a, u = n("f0c5"), c = Object(u["a"])(i["default"], o["b"], o["c"], !1, null, null, null, !1, o["a"], a);
        e["default"] = c.exports;
    }
}, [ [ "df45", "common/runtime", "common/vendor" ] ] ]);