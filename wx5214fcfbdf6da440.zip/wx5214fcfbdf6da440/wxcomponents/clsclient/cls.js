var _math = require("./math");

function getPosForward(pose) {
    // 获取相机位置、朝向
    var mat = new _math.Mat4();
    mat.set(pose);
    var cameraMat = mat.clone().getInverse();
    // console.log('pose', mat);
    // console.log('cameraMat', cameraMat);
        var cameraPos = new _math.Vec3(cameraMat.data[3], cameraMat.data[7], cameraMat.data[11]);
    // console.log('cameraPos', cameraPos);
        var nor = new _math.Vec3(cameraMat.data[2], cameraMat.data[6], cameraMat.data[10]);
    var cameraForward = nor.normalize().scale(-1);
    // console.log('forward', cameraForward);
        return {
        cameraPos: cameraPos,
        cameraForward: cameraForward
    };
}

function getDisAngle(contents, cameraPos, cameraForward) {
    // 获取模型文件与相机的距离、角度
    contents.forEach(function(item) {
        var p = new _math.Vec3(item.position.x, item.position.y, item.position.z);
        item.distance = cameraPos.distance(p);
        var diff = p.clone().sub(cameraPos);
        item.angle = cameraForward.getAngle(diff);
    });
    contents.sort(function(a, b) {
        return a.distance - b.distance;
    });
    // let newContents = contents.filter(item => item.angle < 30)
        console.log("schemaList---", contents);
    // console.log('newContents---', newContents)
    // return newContents;
        return contents;
}

function encode(_str) {
    var staticchars = "PXhw7UT1B0a9kQDKZsjIASmOezxYG4CHo5Jyfg2b8FLpEvRr3WtVnlqMidu6cN";
    var encodechars = "";
    for (var i = 0; i < _str.length; i++) {
        var num0 = staticchars.indexOf(_str[i]);
        if (num0 == -1) {
            var code = _str[i];
        } else {
            var code = staticchars[(num0 + 3) % 62];
        }
        var num1 = parseInt(Math.random() * 62, 10);
        var num2 = parseInt(Math.random() * 62, 10);
        encodechars += staticchars[num1] + code + staticchars[num2];
    }
    return encodechars;
}

module.exports = {
    getPosForward: getPosForward,
    getDisAngle: getDisAngle,
    encode: encode
};