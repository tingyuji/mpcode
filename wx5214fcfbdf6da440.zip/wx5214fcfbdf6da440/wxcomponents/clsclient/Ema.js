Object.defineProperty(exports, "__esModule", {
    value: true
});

exports.cubeListsFromEma = cubeListsFromEma;

exports.cubesFromManifest = cubesFromManifest;

var _createForOfIteratorHelper2 = require("../../@babel/runtime/helpers/createForOfIteratorHelper");

function cubesFromManifest(manifest) {
    return manifest.contents.map(function(content) {
        return {
            name: content.name,
            position: content.position,
            euler: content.rotation,
            scale: content.scale,
            origin: content
        };
    });
}

function cubeListsFromEma(ema) {
    var clusters = {};
    var blocks = {};
    var maps = {};
    if (ema.clusters) {
        var _iterator = _createForOfIteratorHelper2(ema.clusters), _step;
        try {
            for (_iterator.s(); !(_step = _iterator.n()).done; ) {
                var cluster = _step.value;
                clusters[cluster.id] = [];
            }
        } catch (err) {
            _iterator.e(err);
        } finally {
            _iterator.f();
        }
    }
    if (ema.blocks) {
        var _iterator2 = _createForOfIteratorHelper2(ema.blocks), _step2;
        try {
            for (_iterator2.s(); !(_step2 = _iterator2.n()).done; ) {
                var block = _step2.value;
                blocks[block.id] = [];
            }
        } catch (err) {
            _iterator2.e(err);
        } finally {
            _iterator2.f();
        }
    }
    if (ema.extensions) {
        var aliasExtension = ema.extensions.find(function(e) {
            return e.vender === "EasyAR" && e.name === "BlockAlias";
        });
        if (aliasExtension) {
            if (aliasExtension.details.blocks) {
                var _iterator3 = _createForOfIteratorHelper2(aliasExtension.details.blocks), _step3;
                try {
                    for (_iterator3.s(); !(_step3 = _iterator3.n()).done; ) {
                        var blockAlias = _step3.value;
                        var src = blockAlias.id;
                        var _iterator4 = _createForOfIteratorHelper2(blockAlias.aliases), _step4;
                        try {
                            for (_iterator4.s(); !(_step4 = _iterator4.n()).done; ) {
                                var dest = _step4.value;
                                blocks[dest] = blocks[src];
                            }
                        } catch (err) {
                            _iterator4.e(err);
                        } finally {
                            _iterator4.f();
                        }
                    }
                } catch (err) {
                    _iterator3.e(err);
                } finally {
                    _iterator3.f();
                }
            }
        }
    }
    if (ema.annotations) {
        var _iterator5 = _createForOfIteratorHelper2(ema.annotations), _step5;
        try {
            for (_iterator5.s(); !(_step5 = _iterator5.n()).done; ) {
                var annotation = _step5.value;
                if (annotation.parent) {
                    var parentArray = null;
                    switch (annotation.parent.type) {
                      case "cluster":
                        parentArray = clusters[annotation.parent.id];
                        break;

                      case "block":
                        parentArray = blocks[annotation.parent.id];
                        break;

                      case "map":
                        parentArray = maps[annotation.parent.id] || [];
                        maps[annotation.parent.id] = parentArray;
                        break;
                    }
                    if (parentArray) {
                        parentArray.push({
                            name: annotation.name,
                            position: annotation.transform.position,
                            quat: annotation.transform.rotation,
                            scale: annotation.transform.scale,
                            origin: annotation
                        });
                    } else {
                        console.log("annotation ".concat(annotation.name, " 未找到parent"));
                    }
                } else {
                    console.log("annotation ".concat(annotation.name, " 没有parent"));
                }
            }
        } catch (err) {
            _iterator5.e(err);
        } finally {
            _iterator5.f();
        }
    }
    console.log({
        clusters: clusters,
        blocks: blocks,
        maps: maps
    });
    return {
        clusters: clusters,
        blocks: blocks,
        maps: maps
    };
}