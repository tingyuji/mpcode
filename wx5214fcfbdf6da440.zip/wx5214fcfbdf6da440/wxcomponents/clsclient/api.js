Object.defineProperty(exports, "__esModule", {
    value: true
});

exports.api = void 0;

var _config = require("./config");

var _requirePlugin = requirePlugin("SPARPlugin"), sha256 = _requirePlugin.sha256;

function request(url, method, params, header, data) {
    var keys = Object.keys(params || {});
    var paramString = keys.length ? keys.map(function(key) {
        return "".concat(key, "=").concat(encodeURIComponent(params[key]));
    }).join("&") : undefined;
    var urlFinal = url + (paramString ? "?".concat(paramString) : "");
    return new Promise(function(resolve, reject) {
        var option = {
            url: urlFinal,
            method: method,
            success: function success(res) {
                resolve(res.data);
            },
            fail: function fail(e) {
                reject(e);
            }
        };
        if (header) option.header = header;
        if (data) option.data = data;
        wx.request(option);
    });
}

function getClsInfoAnonymous(id) {
    return request("".concat(_config.config.globalUrl, "/anonymous/cls/").concat(id), "GET", {}, null, null);
}

//获取启动方案中的map
function getMaps(startSchemaId, ocKey, ocSecret) {
    var timestamp = new Date().getTime();
    var loadARBindings = true;
    var params = {
        ocKey: ocKey,
        timestamp: timestamp,
        loadARBindings: loadARBindings
    };
    var signStr = Object.keys(params).sort().map(function(key) {
        return "".concat(key).concat(params[key]);
    }).concat(ocSecret).join("");
    params.signature = sha256(signStr);
    return request("".concat(_config.config.arocUrl, "/startschema/").concat(startSchemaId), "GET", params, null, null);
}

//获取启动方案中指定target的manifest
function getManifest(startSchemaId, targetId, ocKey, apiKey, apiSecret) {
    var timestamp = new Date().getTime();
    var params = {
        appId: ocKey,
        timestamp: timestamp,
        apiKey: apiKey
    };
    var signStr = Object.keys(params).sort().map(function(key) {
        return "".concat(key).concat(params[key]);
    }).concat(apiSecret).join("");
    params.signature = sha256(signStr);
    return request("".concat(_config.config.arocUrl, "/arpackage/schema/").concat(startSchemaId, "/target/").concat(targetId), "GET", params, null, null);
}

// 支持多token
var tokens = {};

var tokenExpireTimes = {};

//获取一个CLS的token
function getToken(apiKey, apiSecret) {
    var timestamp = new Date().getTime();
    if (tokenExpireTimes[apiKey] && timestamp < tokenExpireTimes[apiKey]) {
        return Promise.resolve(tokens[apiKey]);
    }
    var expires = 3600;
    tokenExpireTimes[apiKey] = timestamp + expires * 1e3;
    var params = {
        expires: expires,
        timestamp: timestamp,
        apiKey: apiKey
    };
    var signStr = Object.keys(params).sort().map(function(key) {
        return "".concat(key).concat(params[key]);
    }).concat(apiSecret).join("");
    params.signature = sha256(signStr);
    return request("".concat(_config.config.uacUrl, "/token/v2"), "POST", null, null, params).then(function(res) {
        if (res.result && res.result.token) {
            tokens[apiKey] = res.result.token;
            return tokens[apiKey];
        }
        console.log("token error");
        return "TOKEN_ERROR";
    });
}

var api = {
    request: request,
    getClsInfoAnonymous: getClsInfoAnonymous,
    getMaps: getMaps,
    getManifest: getManifest,
    getToken: getToken
};

exports.api = api;