Object.defineProperty(exports, "__esModule", {
    value: true
});

exports.MultiSwitch = void 0;

var _classCallCheck2 = require("../../@babel/runtime/helpers/classCallCheck");

var _createClass2 = require("../../@babel/runtime/helpers/createClass");

var MultiSwitch = /* */ function() {
    function MultiSwitch(keys) {
        _classCallCheck2(this, MultiSwitch);
        this.allSet = new Set(keys);
        this.offSet = new Set(keys);
        this.callbackAllOn = [];
        this.callbackAnyOff = [];
        var currOn = !this.offSet.size;
        this._testAndTrigger(false, currOn);
    }
    _createClass2(MultiSwitch, [ {
        key: "on",
        value: function on(key) {
            if (!this.allSet.has(key)) return;
            var prevOn = !this.offSet.size;
            this.offSet.delete(key);
            var currOn = !this.offSet.size;
            this._testAndTrigger(prevOn, currOn);
        }
    }, {
        key: "off",
        value: function off(key) {
            if (!this.allSet.has(key)) return;
            var prevOn = !this.offSet.size;
            this.offSet.add(key);
            var currOn = !this.offSet.size;
            this._testAndTrigger(prevOn, currOn);
        }
    }, {
        key: "_testAndTrigger",
        value: function _testAndTrigger(prevOn, currOn) {
            if (!prevOn && currOn) {
                this._triggerAllOn();
            } else if (prevOn && !currOn) {
                this._triggerAnyOff();
            }
        }
    }, {
        key: "_triggerAllOn",
        value: function _triggerAllOn() {
            this.callbackAllOn.slice().forEach(function(i) {
                return i();
            });
        }
    }, {
        key: "_triggerAnyOff",
        value: function _triggerAnyOff() {
            this.callbackAnyOff.slice().forEach(function(i) {
                return i();
            });
        }
    }, {
        key: "registerAllOn",
        value: function registerAllOn(callback) {
            this.callbackAllOn.push(callback);
        }
    }, {
        key: "registerAnyOff",
        value: function registerAnyOff(callback) {
            this.callbackAnyOff.push(callback);
        }
    }, {
        key: "unregisterAllOn",
        value: function unregisterAllOn(callback) {
            this.callbackAllOn = this.callbackAllOn.filter(function(i) {
                return i !== callback;
            });
        }
    }, {
        key: "unregisterAnyOff",
        value: function unregisterAnyOff(callback) {
            this.callbackAnyOff = this.callbackAnyOff.filter(function(i) {
                return i !== callback;
            });
        }
    } ]);
    return MultiSwitch;
}();

exports.MultiSwitch = MultiSwitch;