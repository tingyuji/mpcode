var _classCallCheck2 = require("../../@babel/runtime/helpers/classCallCheck");

var _createClass2 = require("../../@babel/runtime/helpers/createClass");

var _MultiSwitch = require("./MultiSwitch");

var _api = require("./api");

var _Ema = require("./Ema");

var _util = require("./util");

var _base64ToArrayBuffer = require("./base64ToArrayBuffer");

var _text = require("./text.min");

var _config = require("./config");

var _requirePlugin = requirePlugin("SPARPlugin"), sensorDeviceMotion = _requirePlugin.sensorDeviceMotion;

var systemInfo = wx.getSystemInfoSync();

var isDevTools = systemInfo.platform === "devtools";

var ClsClientContext = /* */ function() {
    function ClsClientContext(self) {
        _classCallCheck2(this, ClsClientContext);
        this.self = self;
    }
    _createClass2(ClsClientContext, [ {
        key: "run",
        value: function run() {
            return this.self.__fire(this.self.deviceMotion);
        }
    } ]);
    return ClsClientContext;
}();

var ClsCameraContext = /* */ function() {
    function ClsCameraContext(self) {
        _classCallCheck2(this, ClsCameraContext);
        this.self = self;
    }
    _createClass2(ClsCameraContext, [ {
        key: "takePhoto",
        value: function takePhoto(option) {
            return this.self.cameraCtx.takePhoto(option);
        }
    }, {
        key: "getFrame",
        value: function getFrame() {
            return this.self.frame;
        }
    } ]);
    return ClsCameraContext;
}();

var JPEG_QUALITY = 70;

Component({
    //events:
    // load(clsClientContext: ClsClientContext, clsCameraContext: ClsCameraContext)
    // result(result: {statusCode, msg, timestamp, result, deviceMotion, worlds})
    // error(msg: string)
    properties: {
        includePerf: {
            type: Boolean,
            value: false
        },
        //(必须初始化时设置) cls服务器地址配置，包含 portalUrl, globalUrl, arocUrl, clsUrl, uacUrl 这5个服务器的URL
        serverConfig: {
            type: Object,
            value: null
        },
        //(只加载一次) cls配置参数，包含 apiKey, apiSecret, ocKey, ocSecret, schemaId
        clsConfig: {
            type: Object,
            value: null
        },
        //(可实时修改) 两次cls请求的最短时间间隔，第二次请求时如果短于此间隔，__fire直接返回false，不触发onResult事件
        minInterval: {
            type: Number,
            value: 500
        },
        //(可实时修改) 是否自动持续定位
        running: {
            type: Boolean,
            value: true
        },
        //(可实时修改) 是否需要携带设备朝向信息，会放在onResult事件的deviceMotion属性中
        requireDeviceMotion: {
            type: Boolean,
            value: true
        }
    },
    data: {
        canvasW: 480,
        canvasH: 640
    },
    lifetimes: {
        attached: function attached() {
            var _this = this;
            // console.log("lifetimes attached");
            //分别是：是否attach、cls和oc数据加载完毕、相机加载完毕、canvas加载完毕、传入参数loop开启、页面是否显示
                        this.loopSwitch = new _MultiSwitch.MultiSwitch([ "attach", "data", "camera", "canvas", "param", "show" ]);
            this.loadSwitch = new _MultiSwitch.MultiSwitch([ "attach", "data", "camera", "canvas" ]);
            this.onSwitch("attach");
            this.onSwitch("wait");
            this.loadSwitch.registerAllOn(function() {
                // console.log("trigger onLoad");
                _this.triggerEvent("load", {
                    clsClientContext: new ClsClientContext(_this),
                    clsCameraContext: new ClsCameraContext(_this)
                });
                // console.log("after trigger onLoad");
                        });
            this.loopSwitch.registerAllOn(function() {
                return _this._beginLoop();
            });
            this.loopSwitch.registerAnyOff(function() {
                return _this._stopLoop();
            });
            if (this.data.running) {
                //observer比attached更早，那边用if保护，这里检查一次当前值
                this.onSwitch("param");
            } else {
                this.offSwitch("param");
            }
            this.deviceMotionSwitch = new _MultiSwitch.MultiSwitch([ "show", "param" ]);
            this.deviceMotionSwitch.registerAllOn(function() {
                sensorDeviceMotion.on("clsclient");
            });
            this.deviceMotionSwitch.registerAnyOff(function() {
                sensorDeviceMotion.off("clsclient");
            });
            if (this.data.requireDeviceMotion) {
                //observer比attached更早，那边用if保护，这里检查一次当前值
                this.deviceMotionSwitch.on("param");
            } else {
                this.deviceMotionSwitch.off("param");
            }
            //开发工具不会触发onCameraInit，需要手动调用
                        if (isDevTools) {
                setTimeout(function() {
                    return _this.onCameraInit();
                });
            }
            if (this.data.clsConfig) this._loadData();
            if (isDevTools) {
                this.deviceMotion = {
                    alpha: 200,
                    beta: -90,
                    gamma: 0
                };
            }
            sensorDeviceMotion.register("clsclient", function(res) {
                _this.deviceMotion = res;
            });
        },
        detached: function detached() {
            // console.log("lifetimes detached");
            if (this.listener) this.listener.stop();
            sensorDeviceMotion.unregister("clsclient");
            this.offSwitch("attach");
        },
        error: function error(err) {
            // console.log(err);
            this.triggerEvent("error", err);
        }
    },
    methods: {
        onSwitch: function onSwitch(key) {
            this.loopSwitch.on(key);
            this.loadSwitch.on(key);
        },
        offSwitch: function offSwitch(key) {
            this.loopSwitch.off(key);
            this.loadSwitch.off(key);
        },
        onCameraInit: function onCameraInit() {
            var _this2 = this;
            if (this.cameraInitDone) return;
            this.cameraInitDone = true;
            this.cameraCtx = wx.createCameraContext();
            this.listener = this.cameraCtx.onCameraFrame(function(frame) {
                if (!_this2.canvas) return;
                var canvas = _this2.canvas;
                if (canvas.width !== frame.width || canvas.height !== frame.height) {
                    _this2.setData({
                        canvasW: frame.width,
                        canvasH: frame.height
                    });
                    canvas.width = frame.width;
                    canvas.height = frame.height;
                    _this2.__resetCameraParam();
                }
                //如果颜色全都一样就跳过
                                var challenges = [ [ .5, .5 ], [ .25, .5 ], [ .75, .5 ], [ .5, .25 ], [ .5, .75 ] ];
                var buffer = new Uint8ClampedArray(frame.data);
                var init = [], same = init;
                for (var _i = 0, _challenges = challenges; _i < _challenges.length; _i++) {
                    var challenge = _challenges[_i];
                    var x = challenge[0] * frame.width;
                    var y = challenge[1] * frame.height;
                    var r = buffer[(frame.width * y + x) * 4];
                    var g = buffer[(frame.width * y + x) * 4 + 1];
                    var b = buffer[(frame.width * y + x) * 4 + 2];
                    if (same === init) {
                        same = [ r, g, b ];
                    } else if (same) {
                        if (!(same[0] === r && same[1] === g && same[2] === b)) {
                            same = false;
                        }
                    }
                }
                if (same) return;
                if (_this2.data.requireDeviceMotion) {
                    if (_this2.deviceMotion) {
                        _this2.__setFrame(frame);
                    }
                } else {
                    _this2.__setFrame(frame);
                }
            });
            this.listener.start();
            this.onSwitch("camera");
            var query = wx.createSelectorQuery().in(this);
            query.select("#capture").fields({
                node: true,
                size: true
            }).exec(function(res) {
                var canvas = res[0].node;
                var ctx = canvas.getContext("2d");
                //默认设置480*640，medium设置下手头的设备都是480*640
                                canvas.width = _this2.data.canvasW;
                canvas.height = _this2.data.canvasH;
                _this2.canvas = canvas;
                _this2.context = ctx;
                _this2.__resetCameraParam();
                _this2.onSwitch("canvas");
            });
        },
        _loadData: function _loadData() {
            var _this3 = this;
            if (this.data.serverConfig) (0, _config.setClsConfig)(this.data.serverConfig);
            this.config = {
                apiKey: this.data.clsConfig.apiKey,
                apiSecret: this.data.clsConfig.apiSecret,
                ocKey: this.data.clsConfig.ocKey,
                ocSecret: this.data.clsConfig.ocSecret,
                schemaId: this.data.clsConfig.schemaId
            };
            this.clsdata = {
                schema: undefined,
                clsAppId: undefined,
                ema: undefined,
                emc: undefined,
                clsVersion: undefined,
                //"2"
                mapIds: undefined,
                manifestMap: {}
            };
            var schemaPromise = _api.api.getMaps(this.config.schemaId, this.config.ocKey, this.config.ocSecret).then(function(res) {
                _this3.clsdata.schema = res.result;
                _this3.clsdata.clsAppId = JSON.parse(_this3.clsdata.schema.arcloudIdToStart)[0];
                _this3.clsdata.mapIds = _this3.clsdata.schema.arBindings.map(function(i) {
                    return i.target;
                });
            });
            var emaPromise = schemaPromise.then(function() {
                if (_this3.clsdata.schema.emaFile) {
                    return _api.api.request(_this3.clsdata.schema.emaFile, "GET", {}, {}, null).then(function(res) {
                        _this3.clsdata.ema = res;
                        var _cubeListsFromEma = (0, _Ema.cubeListsFromEma)(res), clusters = _cubeListsFromEma.clusters, blocks = _cubeListsFromEma.blocks, maps = _cubeListsFromEma.maps;
                        _this3.clsdata.emaClusters = clusters;
                        _this3.clsdata.emaBlocks = blocks;
                        _this3.clsdata.emaMaps = maps;
                    });
                }
            });
            var clsVersionPromise = schemaPromise.then(function() {
                return _api.api.getClsInfoAnonymous(_this3.clsdata.clsAppId);
            }).then(function(r) {
                _this3.clsdata.clsVersion = r.version.charAt(0);
            });
            var manifestPromise = schemaPromise.then(function() {
                return Promise.all(_this3.clsdata.mapIds.map(function(mapId) {
                    return _api.api.getManifest(_this3.config.schemaId, mapId, _this3.config.ocKey, _this3.config.apiKey, _this3.config.apiSecret).then(function(r) {
                        if (r.result && r.result.manifest) {
                            var manifest = JSON.parse(r.result.manifest);
                            if (manifest && manifest.contents && manifest.contents.length) {
                                _this3.clsdata.manifestMap[mapId] = (0, _Ema.cubesFromManifest)(manifest);
                            }
                        }
                    });
                }));
            });
            var tokenPromise = _api.api.getToken(this.config.apiKey, this.config.apiSecret);
            var loadPromise = Promise.all([ emaPromise, clsVersionPromise, manifestPromise, tokenPromise ]);
            loadPromise.then(function() {
                // console.log("data load complete!");
                // console.log(this.clsdata);
                _this3.onSwitch("data");
            }).catch(function(e) {
                console.log(e);
                _this3.triggerEvent("error", e);
            });
        },
        _beginLoop: function _beginLoop() {
            // console.log("beginLoop");
            //看情况开启设备方向
            //标记循环开启状态
            this.inLoop = true;
            this.busy = false;
        },
        _stopLoop: function _stopLoop() {
            // console.log("stopLoop");
            if (this.request) {
                //杀掉请求
                this.request.abort();
            }
            this.inLoop = false;
            this.busy = false;
        },
        __setFrame: function __setFrame(frame) {
            this.frame = frame;
            if (this.busy) return;
            this.__trigger();
        },
        __trigger: function __trigger() {
            if (this.inLoop) {
                this.__fire(this.deviceMotion);
            } else if (this.fireOnce) {
                this.fireOnce = false;
                this.__fire(this.deviceMotion);
            }
        },
        __fire: function __fire(deviceMotion) {
            var _this4 = this;
            if (this.busy) return false;
            var now = new Date().getTime();
            if (this.lastFire && now - this.lastFire < this.data.minInterval) return;
            this.lastFire = now;
            var profile = {};
            profile.startTime = new Date().getTime();
            this.busy = true;
            var token = undefined;
            _api.api.getToken(this.config.apiKey, this.config.apiSecret).then(function(t) {
                return token = t;
            }).then(function(_) {
                return _this4.__compress();
            }).then(function(base64) {
                profile.base64Time = new Date().getTime();
                var data = _this4.__composeRequestFile(base64, token);
                profile.requestTime = new Date().getTime();
                return _this4.__sendClsRequest(data);
            }).then(function(r) {
                profile.responseTime = new Date().getTime();
                _this4.__clsResult(r, deviceMotion, profile);
            }).catch(function(e) {
                if (!(e && e.errMsg === "request:fail abort")) {
                    _this4.__clsError(e, profile);
                }
            }).then(function() {
                _this4.busy = false;
            });
            return true;
        },
        __compress: function __compress() {
            var _this5 = this;
            return new Promise(function(resolve, reject) {
                var canvas = _this5.canvas;
                var ctx = _this5.context;
                var ctxImageData = ctx.createImageData(_this5.frame.width, _this5.frame.height);
                ctxImageData.data.set(new Uint8ClampedArray(_this5.frame.data));
                ctx.putImageData(ctxImageData, 0, 0);
                var dataurl = canvas.toDataURL("image/jpeg", JPEG_QUALITY / 100);
                var base64 = dataurl.substr(23);
                resolve(base64);
            });
        },
        __composeRequestFile: function __composeRequestFile(image, token) {
            var params = {
                appId: this.clsdata.clsAppId,
                cameraParam: this.cameraParam
            };
            if (this.data.includePerf) params.tprofile = 1;
            var imageBuffer = (0, _base64ToArrayBuffer.base64ToArrayBuffer)(image);
            var banr1 = Object.keys(params).map(function(key) {
                return "\r\n--XXX" + '\r\nContent-Disposition: form-data;name="'.concat(key, '"') + "\r\n" + "\r\n" + params[key];
            }).join("") + "\r\n--XXX" + '\r\nContent-Disposition: form-data;name="image"; filename="image.jpg"' + "\r\nContent-Type: application/octet-stream" + "\r\nContent-Transfer-Encoding: binary" + "\r\n" + "\r\n";
            var banr2 = "\r\n--XXX--";
            var textEncoder = new _text.text.TextEncoder();
            var buffer1 = textEncoder.encode(banr1);
            var buffer2 = new Uint8Array(imageBuffer);
            var buffer3 = textEncoder.encode(banr2);
            var all = new Uint8Array(buffer1.length + buffer2.length + buffer3.length);
            all.set(buffer1, 0);
            all.set(buffer2, buffer1.length);
            all.set(buffer3, buffer1.length + buffer2.length);
            var arraybuffer = all.buffer;
            var version = this.clsdata.clsVersion;
            if (version === "2") version = "3";
            //如果是v2，就把url改写成v3
                        return {
                url: "".concat(_config.config.clsUrl, "/v").concat(version, "/file/localize"),
                data: arraybuffer,
                header: {
                    "content-type": "multipart/form-data; boundary=XXX",
                    Authorization: token
                }
            };
        },
        __sendClsRequest: function __sendClsRequest(req) {
            var _this6 = this;
            return new Promise(function(resolve, reject) {
                var options = Object.assign({
                    method: "POST",
                    success: function success(res) {
                        resolve(res.data);
                    },
                    fail: function fail(err) {
                        reject(err);
                    },
                    complete: function complete() {
                        _this6.request = undefined;
                    }
                }, req);
                _this6.request = wx.request(options);
            });
        },
        __clsResult: function __clsResult(res, deviceMotion, profile) {
            var params = {};
            params.statusCode = res.statusCode;
            params.msg = res.msg;
            if (this.data.includePerf) {
                params.clientPerf = profile;
                if (res.perf) {
                    params.serverPerf = res.perf;
                }
            }
            if (res.timestamp) params.timestamp = res.timestamp;
            if (res.statusCode === 0) {
                var result = res.result[0];
                params.result = result;
                var worlds = [];
                //构造manifest、ema(cluster/block)中的点位信息，每一项都统一为{ pose, position, forward, deviceMotion, [{name,position,euler/quat,scale}] }
                //来源：manifest (v1/v2)
                                if (result.mapId && this.clsdata.manifestMap[result.mapId]) {
                    var contents = this.clsdata.manifestMap[result.mapId];
                    var worldTransform = (0, _util.processPoseSchema)(result.pose);
                    var cameraTransform = (0, _util.processPoseCamera)(result.pose);
                    worlds.push({
                        type: "manifest",
                        contents: contents,
                        pose: result.pose,
                        worldTransform: worldTransform,
                        cameraTransform: cameraTransform
                    });
                }
                //来源：ema中的map (v4)
                                if (result.mapId && this.clsdata.emaMaps) {
                    var mapCubeList = this.clsdata.emaMaps[result.mapId];
                    if (mapCubeList && mapCubeList.length) {
                        var _worldTransform = (0, _util.processPoseSchema)(result.pose);
                        var _cameraTransform = (0, _util.processPoseCamera)(result.pose);
                        worlds.push({
                            type: "map",
                            contents: mapCubeList,
                            pose: result.pose,
                            worldTransform: _worldTransform,
                            cameraTransform: _cameraTransform
                        });
                    }
                }
                //来源：ema中的block (v2/v3)
                                if (result.block && result.block.id && this.clsdata.emaBlocks) {
                    var blockCubeList = this.clsdata.emaBlocks[result.block.id];
                    if (blockCubeList && blockCubeList.length) {
                        var _worldTransform2 = (0, _util.processPoseSchema)(result.pose);
                        var _cameraTransform2 = (0, _util.processPoseCamera)(result.pose);
                        worlds.push({
                            type: "block",
                            contents: blockCubeList,
                            pose: result.pose,
                            worldTransform: _worldTransform2,
                            cameraTransform: _cameraTransform2
                        });
                    }
                }
                //来源：ema中的cluster (v2/v3)
                                if (result.cluster && result.cluster.id && this.clsdata.emaClusters) {
                    var clusterCubeList = this.clsdata.emaClusters[result.cluster.id];
                    if (clusterCubeList && clusterCubeList.length) {
                        var _worldTransform3 = (0, _util.processPoseSchema)(result.pose);
                        var _cameraTransform3 = (0, _util.processPoseCamera)(result.pose);
                        worlds.push({
                            type: "cluster",
                            contents: clusterCubeList,
                            pose: result.cluster.pose,
                            worldTransform: _worldTransform3,
                            cameraTransform: _cameraTransform3
                        });
                    }
                }
                params.worlds = worlds;
                if (this.data.requireDeviceMotion && deviceMotion) params.deviceMotion = deviceMotion;
            } else {}
            this.triggerEvent("result", params);
        },
        __clsError: function __clsError(err, profile) {
            var params = {};
            params.error = err;
            params.msg = err.errMsg;
            if (this.data.includePerf) params.clientPerf = profile;
            this.triggerEvent("result", params);
        },
        __resetCameraParam: function __resetCameraParam() {
            var canvas = this.canvas;
            var size = [ 480, 640 ];
            var focal = [ 544, 544 ];
            var ratio = canvas.height / size[1];
            var focalLength = [ focal[0] * ratio, focal[1] * ratio ];
            var principalPoint = [ canvas.width / 2, canvas.height / 2 ];
            this.cameraParam = "[" + focalLength[0] + "," + focalLength[1] + "," + principalPoint[0] + "," + principalPoint[1] + "]";
        }
    },
    observers: {
        clsConfig: function clsConfig(_clsConfig) {
            if (!_clsConfig || this.clsConfigLoadKey && this.clsConfigLoadKey === _clsConfig.apiKey) return;
            this.clsConfigLoadKey = _clsConfig.apiKey;
            this._loadData();
        },
        running: function running(enabled) {
            if (!this.loopSwitch) return;
            if (enabled) {
                this.onSwitch("param");
            } else {
                this.offSwitch("param");
            }
        },
        requireDeviceMotion: function requireDeviceMotion(enabled) {
            if (!this.deviceMotionSwitch) return;
            if (enabled) {
                this.deviceMotionSwitch.on("param");
            } else {
                this.deviceMotionSwitch.off("param");
            }
        }
    },
    pageLifetimes: {
        show: function show() {
            this.onSwitch("show");
            if (this.listener) this.listener.start();
            this.deviceMotionSwitch.on("show");
        },
        hide: function hide() {
            this.offSwitch("show");
            this.deviceMotionSwitch.off("show");
        }
    }
});