Object.defineProperty(exports, "__esModule", {
    value: true
});

exports.config = void 0;

exports.setClsConfig = setClsConfig;

var portalUrl = "https://portal-cn-api.easyar.com";

var globalUrl = "https://global.easyar.cn";

var arocUrl = "https://aroc-api.easyar.com";

var clsUrl = "https://cls-api.easyar.com";

var uacUrl = "https://uac.easyar.com";

var config = {
    portalUrl: portalUrl,
    globalUrl: globalUrl,
    arocUrl: arocUrl,
    clsUrl: clsUrl,
    uacUrl: uacUrl
};

exports.config = config;

function setClsConfig(newConfig) {
    exports.config = config = Object.assign(config, newConfig);
}