var _createForOfIteratorHelper2 = require("../../@babel/runtime/helpers/createForOfIteratorHelper");

var _qqmap = require("./qqmap");

var _util = require("./util");

var _config = require("./config");

var _requirePlugin = requirePlugin("SPARPlugin"), sensorCompass = _requirePlugin.sensorCompass, sensorDeviceMotion = _requirePlugin.sensorDeviceMotion;

// const app = getApp();
var systemInfo = wx.getSystemInfoSync();

var platform = systemInfo.platform;

Component({
    properties: {
        enabled: {
            type: Boolean,
            value: false
        },
        // targets: {type: Array, value: []},
        lng: {
            type: Number,
            value: 0
        },
        lat: {
            type: Number,
            value: 0
        },
        maxDistance: {
            type: Number,
            value: 30
        },
        maxVAngle: {
            type: Number,
            value: 30
        },
        maxHAngle: {
            type: Number,
            value: 30
        }
    },
    data: {},
    lifetimes: {
        attached: function attached() {
            this.sensorOn();
            this.lastTestTime = 0;
        },
        ready: function ready() {},
        detached: function detached() {
            this.sensorOff();
        }
    },
    observers: {
        "lng, lat, enabled": function lngLatEnabled(lng, lat, enabled) {
            // this.lastLngLatTime = new Date().getTime();
            // console.log('lng,lat', lng, lat, this.data.enabled, this.ready)
            if (this.data.enabled && this.ready) {
                this.test();
            }
        }
    },
    methods: {
        test: function test() {
            var now = new Date().getTime();
            // if (this.lastLngLatTime + 10000 < now) return; //经纬度有效期10秒
                        if (this.lastTestTime + 500 > now) return;
            //最多0.5秒测试一次
                        this.lastTestTime = now;
            if (Math.abs(this.beta + 90) > this.data.maxVAngle) return;
            var lng = this.data.lng;
            var lat = this.data.lat;
            if (!_config.targets) return;
            var arr = [];
            if (_config.targets && _config.targets.length) {
                var _iterator = _createForOfIteratorHelper2(_config.targets), _step;
                try {
                    for (_iterator.s(); !(_step = _iterator.n()).done; ) {
                        var target = _step.value;
                        var dlng = (0, _qqmap.lngDistance)(lng, lat, target.lng, target.lat);
                        var dlat = (0, _qqmap.latDistance)(lng, lat, target.lng, target.lat);
                        // console.log('dlng,dlat', dlng, dlat, lng,lat)
                                                if (dlng < this.data.maxDistance && dlat < this.data.maxDistance) {
                            var d = Math.hypot(dlng, dlat);
                            if (d < this.data.maxDistance && d < target.distance) {
                                var angle = Math.atan2(dlng, dlat) * 180 / Math.PI;
                                if (this.insight(angle, target.angle1, target.angle2)) {
                                    // this.triggerEvent("result", target); // 有满足条件的点位直接触发
                                    // break;
                                    target.d = d;
                                    arr.push(target);
                                }
                            }
                        }
                    }
                } catch (err) {
                    _iterator.e(err);
                } finally {
                    _iterator.f();
                }
                arr.sort(function(a, b) {
                    return a.d - b.d;
                });
                if (arr[0]) {
                    this.triggerEvent("result", arr[0]);
                    // 从符合条件的点位中选取距离最近的触发
                                }
            }
        },
        updateAlpha: function updateAlpha(alpha) {
            this.ready = true;
            this.alpha = alpha;
            if (this.data.enabled && this.ready && this.data.lng && this.data.lat) {
                this.test();
            }
        },
        updateBeta: function updateBeta(beta) {
            this.ready = true;
            this.beta = beta;
        },
        insight: function insight(angle, angle1, angle2) {
            //angle是位置和点位连线的实际角度，angle1和angle2是位置相对于点位的期望角度
            angle1 = (angle1 + 360 + 180) % 360;
            angle2 = (angle2 + 360 + 180) % 360;
            var myAlpha = (this.alpha + 360) % 360;
            if (angle2 < angle1) angle2 += 360;
            if (myAlpha < angle1) myAlpha += 360;
            console.log(angle1, myAlpha, angle2);
            //要求alpha必须在angle1和angle2之间
                        if (!(angle1 < myAlpha && myAlpha < angle2)) return;
            angle = (angle + 360) % 360;
            var dir = (this.alpha + 360) % 360;
            var d1 = Math.abs(dir - angle);
            var d2 = Math.abs(dir - angle + 360);
            var d3 = Math.abs(dir - angle - 360);
            if (_util.IS_DEVTOOLS) return true;
            console.log("d1d2d3", Math.min(d1, d2, d3));
            return Math.min(d1, d2, d3) < this.data.maxHAngle;
        },
        sensorOn: function sensorOn() {
            var _this = this;
            if (this.isSensorOn) return;
            this.isSensorOn = true;
            if (_util.IS_DEVTOOLS) {
                this.updateAlpha(-90);
            }
            if (platform === "ios") {
                sensorCompass.register("gps-".concat(this.radarIndex), (0, _util.throttle)(function(res) {
                    _this.updateAlpha(res.direction);
                }, 200));
                sensorCompass.on("gps-".concat(this.radarIndex));
            }
            sensorDeviceMotion.register("gps-".concat(this.radarIndex), (0, _util.throttle)(function(deviceMotion) {
                if (platform === "android") {
                    _this.updateBeta(deviceMotion.beta);
                    _this.updateAlpha(deviceMotion.alpha);
                } else {
                    _this.updateBeta(-deviceMotion.beta);
                }
            }, 500));
            sensorDeviceMotion.on("gps-".concat(this.radarIndex));
        },
        sensorOff: function sensorOff() {
            this.isSensorOn = false;
            if (platform === "ios") {
                sensorCompass.off("gps-".concat(this.radarIndex));
            }
            sensorDeviceMotion.unregister("gps-".concat(this.radarIndex));
        }
    },
    pageLifetimes: {
        show: function show() {
            this.sensorOn();
        },
        hide: function hide() {
            this.sensorOff();
        }
    }
});