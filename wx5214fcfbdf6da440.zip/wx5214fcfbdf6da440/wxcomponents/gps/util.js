Object.defineProperty(exports, "__esModule", {
    value: true
});

exports.IS_IOS = exports.IS_DEVTOOLS = exports.IS_ANDROID = void 0;

exports.analysisPose = analysisPose;

exports.getAccountInfo = getAccountInfo;

exports.getSystemInfo = getSystemInfo;

exports.processPoseCamera = processPoseCamera;

exports.processPoseSchema = processPoseSchema;

exports.throttle = throttle;

var _math = require("./math");

var systemInfo = wx.getSystemInfoSync();

var accountInfo = wx.getAccountInfoSync();

var IS_ANDROID = systemInfo.platform === "android";

exports.IS_ANDROID = IS_ANDROID;

var IS_DEVTOOLS = systemInfo.platform === "devtools";

exports.IS_DEVTOOLS = IS_DEVTOOLS;

var IS_IOS = systemInfo.platform === "ios";

exports.IS_IOS = IS_IOS;

function getSystemInfo() {
    return systemInfo;
}

function getAccountInfo() {
    return accountInfo;
}

function analysisPose(pose) {
    var mat = new _math.Mat4();
    mat.set(pose);
    var cameraMat = mat.clone().getInverse();
    var position = new _math.Vec3(cameraMat.data[3], cameraMat.data[7], cameraMat.data[11]);
    var nor = new _math.Vec3(cameraMat.data[2], cameraMat.data[6], cameraMat.data[10]);
    return {
        position: position,
        nor: nor
    };
}

function processPoseSchema(pose) {
    var mat = new _math.Mat4();
    mat.set(pose);
    var cameraMat = mat.clone().transpose();
    var _cameraMat$decompose = cameraMat.decompose(), position = _cameraMat$decompose.position, rotation = _cameraMat$decompose.rotation, scale = _cameraMat$decompose.scale;
    var nor = new _math.Vec3(cameraMat.data[8], cameraMat.data[9], cameraMat.data[10]);
    var forward = nor.normalize().scale(-1);
    return {
        position: position,
        forward: forward,
        rotation: rotation,
        scale: scale
    };
}

function processPoseCamera(pose) {
    var mat = new _math.Mat4();
    mat.set(pose);
    var cameraMat = mat.clone().transpose().getInverse();
    var _cameraMat$decompose2 = cameraMat.decompose(), position = _cameraMat$decompose2.position, rotation = _cameraMat$decompose2.rotation, scale = _cameraMat$decompose2.scale;
    var nor = new _math.Vec3(cameraMat.data[8], cameraMat.data[9], cameraMat.data[10]);
    var forward = nor.normalize().scale(-1);
    return {
        position: position,
        forward: forward,
        rotation: rotation,
        scale: scale
    };
}

// 函数节流
function throttle(fn, wait) {
    var timer;
    var i = 0;
    return function() {
        i++;
        if (!timer) {
            timer = setTimeout(function() {
                return timer = null;
            }, wait);
            i = 0;
            for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
                args[_key] = arguments[_key];
            }
            return fn.apply(this, args);
        }
    };
}