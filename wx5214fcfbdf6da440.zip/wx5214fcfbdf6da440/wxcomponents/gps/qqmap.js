Object.defineProperty(exports, "__esModule", {
    value: true
});

exports.LAT_SCALE = exports.EATH_RADIUS = void 0;

exports.latAddMeter = latAddMeter;

exports.latDistance = latDistance;

exports.lngAddMeter = lngAddMeter;

exports.lngDistance = lngDistance;

exports.lnglatDistance = lnglatDistance;

/**
 * 转换弧度
 * @param d
 * @returns {number}
 */ function getRad(d) {
    var PI = Math.PI;
    return d * PI / 180;
}

/**
 * 根据经纬度计算两点间距离
 * @param lng1
 * @param lat1
 * @param lng2
 * @param lat2
 * @returns {number} 距离 单位米
 */ function lnglatDistance(lng1, lat1, lng2, lat2) {
    var f = getRad((lat1 + lat2) / 2);
    var g = getRad((lat1 - lat2) / 2);
    var l = getRad((lng1 - lng2) / 2);
    var sg = Math.sin(g);
    var sl = Math.sin(l);
    var sf = Math.sin(f);
    var s, c, w, r, d, h1, h2;
    var a = 6378137;
    //The Radius of eath in meter.
        var fl = 1 / 298.257;
    sg = sg * sg;
    sl = sl * sl;
    sf = sf * sf;
    s = sg * (1 - sl) + (1 - sf) * sl;
    c = (1 - sg) * (1 - sl) + sf * sl;
    w = Math.atan(Math.sqrt(s / c));
    r = Math.sqrt(s * c) / w;
    d = 2 * w * a;
    h1 = (3 * r - 1) / 2 / c;
    h2 = (3 * r + 1) / 2 / s;
    s = d * (1 + fl * (h1 * sf * (1 - sg) - h2 * (1 - sf) * sg));
    return s;
}

var EATH_RADIUS = 6378137;

// The Radius of eath in meter.
exports.EATH_RADIUS = EATH_RADIUS;

var LAT_SCALE = EATH_RADIUS * Math.PI * 2 / 360;

exports.LAT_SCALE = LAT_SCALE;

function lngDistance(lng1, lat1, lng2, lat2) {
    return (lng2 - lng1) * LAT_SCALE * Math.cos((lat1 + lat2) / 2 / 180 * Math.PI);
}

function latDistance(lng1, lat1, lng2, lat2) {
    return (lat2 - lat1) * LAT_SCALE;
}

function lngAddMeter(lng, lat, meter) {
    return lng + meter / (LAT_SCALE * Math.cos(lat / 180 * Math.PI));
}

function latAddMeter(lng, lat, meter) {
    return lat + meter / LAT_SCALE;
}