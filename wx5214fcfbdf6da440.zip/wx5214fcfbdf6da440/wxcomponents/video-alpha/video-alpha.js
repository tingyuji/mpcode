var _MultiSwitch = require("./MultiSwitch");

Component({
    properties: {
        src: {
            type: String,
            value: null
        },
        fps: {
            type: Number,
            value: 20
        }
    },
    data: {},
    lifetimes: {
        attached: function attached() {
            var _this = this;
            this.switch = new _MultiSwitch.MultiSwitch([ "attach", "load", "show", "metadata", "play" ]);
            this.switch.registerAllOn(function() {
                return _this.start();
            });
            this.switch.registerAnyOff(function() {
                return _this.stop();
            });
            this.switch.on("attach");
            this.switch.on("show");
            this.load();
        },
        detached: function detached() {
            this.switch.off("attach");
        }
    },
    methods: {
        videoPlay: function videoPlay() {
            this.switch.on("play");
        },
        videoPause: function videoPause() {
            this.switch.off("play");
        },
        load: function load() {
            var _this2 = this;
            this.loadPromise = Promise.all([ new Promise(function(resolve) {
                wx.createSelectorQuery().in(_this2).select("#video").context(function(res) {
                    _this2.videoContext = res.context;
                    resolve();
                }).exec();
            }), new Promise(function(resolve) {
                wx.createSelectorQuery().in(_this2).selectAll("#draw").node(function(res1) {
                    var canvas1 = res1[0].node;
                    _this2.canvas1 = canvas1;
                    _this2.context1 = canvas1.getContext("2d");
                    resolve();
                }).exec();
            }), new Promise(function(resolve) {
                wx.createSelectorQuery().in(_this2).selectAll("#videoContent").node(function(res2) {
                    var canvas2 = res2[0].node;
                    _this2.canvas2 = canvas2;
                    _this2.context2 = canvas2.getContext("2d");
                    resolve();
                }).exec();
            }) ]);
            this.loadPromise.then(function() {
                _this2.switch.on("load");
            });
        },
        start: function start() {
            var _this3 = this;
            var fps = this.data.fps;
            if (fps > 24) fps = 24;
            if (fps < 1) fps = 1;
            var delay = 1e3 / fps;
            this.interval = setInterval(function() {
                _this3.draw();
            }, delay);
            console.log("start");
        },
        stop: function stop() {
            clearInterval(this.interval);
            console.log("stop");
            // this.triggerEvent("hideVideo");
                },
        videoEnded: function videoEnded() {
            this.triggerEvent("hideVideo");
        },
        draw: function draw() {
            var vw = this.vw;
            var vh = this.vh;
            var rw = this.rw;
            var rh = this.rh;
            this.context2.drawImage(this.videoContext, 0, 0, vw, vh);
            var imagedata = this.context2.getImageData(0, 0, vw, vh);
            var buffer = imagedata.data;
            for (var y = 0; y < rh; y++) {
                this.renderBuffer.set(buffer.subarray(y * vw * 4, (y + .5) * vw * 4), y * rw * 4);
                for (var x = 0; x < rw; x++) {
                    var offset = (y * rw + x) * 4;
                    var offset2 = (y * vw + x + rw) * 4;
                    this.renderBuffer[offset + 3] = buffer[offset2];
                }
            }
            var imagedata2 = this.context1.createImageData(rw, rh);
            imagedata2.data.set(this.renderBuffer);
            this.context1.clearRect(0, 0, rw, rh);
            this.context1.putImageData(imagedata2, 0, 0);
        },
        loadedmetadata: function loadedmetadata(e) {
            var _this4 = this;
            this.loadPromise.then(function() {
                //只支持第一次回调
                if (_this4.videoMeta) return;
                _this4.videoMeta = true;
                var vw = e.detail.width;
                var vh = e.detail.height;
                var rw = e.detail.width / 2;
                var rh = e.detail.height;
                _this4.vw = vw;
                _this4.vh = vh;
                _this4.rw = rw;
                _this4.rh = rh;
                _this4.renderBuffer = new Uint8ClampedArray(rw * rh * 4);
                //告诉外面尺寸，让外面可以控制父节点尺寸
                                _this4.triggerEvent("loadedmetadata", e.detail);
                _this4.canvas1.width = rw;
                _this4.canvas1.height = rh;
                _this4.canvas2.width = vw;
                _this4.canvas2.height = rh;
                _this4.setData({
                    videoWidth: vw,
                    videoHeight: vh,
                    renderWidth: rw,
                    renderHeight: rh
                }, function() {
                    _this4.switch.on("metadata");
                });
            });
        }
    },
    pageLifetimes: {
        show: function show() {
            this.switch.on("show");
        },
        hide: function hide() {
            this.switch.off("show");
        }
    }
});