var _typeof2 = require("../@babel/runtime/helpers/typeof");

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "common/main" ], {
    "3dfd": function dfd(t, e, n) {
        "use strict";
        n.r(e);
        var o = n("6f68");
        for (var r in o) [ "default" ].indexOf(r) < 0 && function(t) {
            n.d(e, t, function() {
                return o[t];
            });
        }(r);
        n("5c0bb");
        var u, c, f, i, a = n("f0c5"), l = Object(a["a"])(o["default"], u, c, !1, null, null, null, !1, f, i);
        e["default"] = l.exports;
    },
    "5c0bb": function c0bb(t, e, n) {
        "use strict";
        var o = n("c060"), r = n.n(o);
        r.a;
    },
    "6f68": function f68(t, e, n) {
        "use strict";
        n.r(e);
        var o = n("7ccf"), r = n.n(o);
        for (var u in o) [ "default" ].indexOf(u) < 0 && function(t) {
            n.d(e, t, function() {
                return o[t];
            });
        }(u);
        e["default"] = r.a;
    },
    "7ccf": function ccf(t, e, n) {
        "use strict";
        (function(t) {
            function o(t) {
                return o = "function" === typeof Symbol && "symbol" === _typeof2(Symbol.iterator) ? function(t) {
                    return _typeof2(t);
                } : function(t) {
                    return t && "function" === typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : _typeof2(t);
                }, o(t);
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var r = n("9ab4"), u = n("60a3");
            function c(t, e) {
                if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function");
            }
            function f(t, e) {
                for (var n = 0; n < e.length; n++) {
                    var o = e[n];
                    o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), 
                    Object.defineProperty(t, o.key, o);
                }
            }
            function i(t, e, n) {
                return e && f(t.prototype, e), n && f(t, n), t;
            }
            function a(t, e) {
                if ("function" !== typeof e && null !== e) throw new TypeError("Super expression must either be null or a function");
                t.prototype = Object.create(e && e.prototype, {
                    constructor: {
                        value: t,
                        writable: !0,
                        configurable: !0
                    }
                }), e && l(t, e);
            }
            function l(t, e) {
                return l = Object.setPrototypeOf || function(t, e) {
                    return t.__proto__ = e, t;
                }, l(t, e);
            }
            function p(t) {
                var e = y();
                return function() {
                    var n, o = b(t);
                    if (e) {
                        var r = b(this).constructor;
                        n = Reflect.construct(o, arguments, r);
                    } else n = o.apply(this, arguments);
                    return s(this, n);
                };
            }
            function s(t, e) {
                if (e && ("object" === o(e) || "function" === typeof e)) return e;
                if (void 0 !== e) throw new TypeError("Derived constructors may only return object or undefined");
                return d(t);
            }
            function d(t) {
                if (void 0 === t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                return t;
            }
            function y() {
                if ("undefined" === typeof Reflect || !Reflect.construct) return !1;
                if (Reflect.construct.sham) return !1;
                if ("function" === typeof Proxy) return !0;
                try {
                    return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
                    !0;
                } catch (t) {
                    return !1;
                }
            }
            function b(t) {
                return b = Object.setPrototypeOf ? Object.getPrototypeOf : function(t) {
                    return t.__proto__ || Object.getPrototypeOf(t);
                }, b(t);
            }
            var v = function(e) {
                a(o, e);
                var n = p(o);
                function o() {
                    return c(this, o), n.apply(this, arguments);
                }
                return i(o, [ {
                    key: "onLaunch",
                    value: function value(e) {
                        console.log(e), t.setInnerAudioOption({
                            obeyMuteSwitch: !1
                        });
                    }
                } ]), o;
            }(u.Vue);
            v = (0, r.__decorate)([ u.Component ], v);
            var m = v;
            e.default = m;
        }).call(this, n("543d")["default"]);
    },
    c060: function c060(t, e, n) {},
    cd49: function cd49(t, e, n) {
        "use strict";
        (function(t) {
            n("6cdc");
            var e = u(n("66fd")), o = u(n("3dfd")), r = u(n("45ee"));
            function u(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            r.default.init({
                appKey: "60f515b82a1a2a58e7dc6bd0",
                useOpenid: !1,
                autoGetOpenid: !1
            }), e.default.use({
                install: function install(t) {
                    t.prototype.$uma = r.default;
                }
            }), e.default.config.productionTip = !1, t(new o.default()).$mount();
        }).call(this, n("543d")["createApp"]);
    }
}, [ [ "cd49", "common/runtime", "common/vendor" ] ] ]);