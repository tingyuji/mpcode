var _typeof2 = require("../../@babel/runtime/helpers/typeof");

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "components/image-map/image-map" ], {
    "0b23": function b23(t, n, e) {
        "use strict";
        var o;
        e.d(n, "b", function() {
            return r;
        }), e.d(n, "c", function() {
            return i;
        }), e.d(n, "a", function() {
            return o;
        });
        var r = function r() {
            var t = this, n = t.$createElement;
            t._self._c;
        }, i = [];
    },
    3250: function _(t, n, e) {
        "use strict";
        var o = e("4658"), r = e.n(o);
        r.a;
    },
    "3fb5": function fb5(t, n, e) {
        "use strict";
        e.r(n);
        var o = e("507c"), r = e.n(o);
        for (var i in o) [ "default" ].indexOf(i) < 0 && function(t) {
            e.d(n, t, function() {
                return o[t];
            });
        }(i);
        n["default"] = r.a;
    },
    4658: function _(t, n, e) {},
    "507c": function c(t, n, e) {
        "use strict";
        (function(t) {
            function o(t) {
                return o = "function" === typeof Symbol && "symbol" === _typeof2(Symbol.iterator) ? function(t) {
                    return _typeof2(t);
                } : function(t) {
                    return t && "function" === typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : _typeof2(t);
                }, o(t);
            }
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var r = e("9ab4"), i = e("60a3");
            function a(t, n) {
                return s(t) || f(t, n) || l(t, n) || u();
            }
            function u() {
                throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
            }
            function l(t, n) {
                if (t) {
                    if ("string" === typeof t) return c(t, n);
                    var e = Object.prototype.toString.call(t).slice(8, -1);
                    return "Object" === e && t.constructor && (e = t.constructor.name), "Map" === e || "Set" === e ? Array.from(t) : "Arguments" === e || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(e) ? c(t, n) : void 0;
                }
            }
            function c(t, n) {
                (null == n || n > t.length) && (n = t.length);
                for (var e = 0, o = new Array(n); e < n; e++) o[e] = t[e];
                return o;
            }
            function f(t, n) {
                var e = null == t ? null : "undefined" !== typeof Symbol && t[Symbol.iterator] || t["@@iterator"];
                if (null != e) {
                    var o, r, i = [], a = !0, u = !1;
                    try {
                        for (e = e.call(t); !(a = (o = e.next()).done); a = !0) if (i.push(o.value), n && i.length === n) break;
                    } catch (l) {
                        u = !0, r = l;
                    } finally {
                        try {
                            a || null == e["return"] || e["return"]();
                        } finally {
                            if (u) throw r;
                        }
                    }
                    return i;
                }
            }
            function s(t) {
                if (Array.isArray(t)) return t;
            }
            function h(t, n) {
                if (!(t instanceof n)) throw new TypeError("Cannot call a class as a function");
            }
            function d(t, n) {
                for (var e = 0; e < n.length; e++) {
                    var o = n[e];
                    o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), 
                    Object.defineProperty(t, o.key, o);
                }
            }
            function p(t, n, e) {
                return n && d(t.prototype, n), e && d(t, e), t;
            }
            function v(t, n) {
                if ("function" !== typeof n && null !== n) throw new TypeError("Super expression must either be null or a function");
                t.prototype = Object.create(n && n.prototype, {
                    constructor: {
                        value: t,
                        writable: !0,
                        configurable: !0
                    }
                }), n && m(t, n);
            }
            function m(t, n) {
                return m = Object.setPrototypeOf || function(t, n) {
                    return t.__proto__ = n, t;
                }, m(t, n);
            }
            function y(t) {
                var n = w();
                return function() {
                    var e, o = x(t);
                    if (n) {
                        var r = x(this).constructor;
                        e = Reflect.construct(o, arguments, r);
                    } else e = o.apply(this, arguments);
                    return b(this, e);
                };
            }
            function b(t, n) {
                if (n && ("object" === o(n) || "function" === typeof n)) return n;
                if (void 0 !== n) throw new TypeError("Derived constructors may only return object or undefined");
                return g(t);
            }
            function g(t) {
                if (void 0 === t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                return t;
            }
            function w() {
                if ("undefined" === typeof Reflect || !Reflect.construct) return !1;
                if (Reflect.construct.sham) return !1;
                if ("function" === typeof Proxy) return !0;
                try {
                    return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
                    !0;
                } catch (t) {
                    return !1;
                }
            }
            function x(t) {
                return x = Object.setPrototypeOf ? Object.getPrototypeOf : function(t) {
                    return t.__proto__ || Object.getPrototypeOf(t);
                }, x(t);
            }
            var O = function(n) {
                v(o, n);
                var e = y(o);
                function o() {
                    var t;
                    return h(this, o), t = e.apply(this, arguments), t.width = 0, t.height = 0, t.transform = "", 
                    t;
                }
                return p(o, [ {
                    key: "mounted",
                    value: function value() {
                        var n = this, e = t.createSelectorQuery().in(this);
                        e.select(".image-map").boundingClientRect(function(t) {
                            return n.containerRect = t;
                        }).exec();
                    }
                }, {
                    key: "onImageLoad",
                    value: function value(t) {
                        var n = t.detail, e = n.width, o = n.height;
                        this.width = e, this.height = o;
                        var r = this.containerRect, i = r.width, a = r.height, u = Number(i / e), l = Number(a / o), c = Math.min(Math.min(u, l), 1), f = e * c, s = o * c, h = (i - f) / 2, d = (a - s) / 2;
                        this.options = {
                            maxScale: 2.5,
                            minScale: c,
                            maxLeft: h,
                            maxTop: d,
                            minWidth: f,
                            minHeight: s
                        }, console.log("options", this.options);
                        var p = u, v = (i - e * p) / 2, m = (a - o * p) / 2;
                        this.transformImage(v, m, p);
                    }
                }, {
                    key: "onTouchStart",
                    value: function value(t) {
                        this.lastPointList = Array.from(t.touches).map(function(t) {
                            return new S(t.pageX, t.pageY);
                        });
                    }
                }, {
                    key: "onTouchMove",
                    value: function value(t) {
                        var n = Array.from(t.touches).map(function(t) {
                            return new S(t.pageX, t.pageY);
                        });
                        if (1 === n.length) {
                            var e = a(this.lastPointList, 1), o = e[0], r = a(n, 1), i = r[0];
                            if (o.distance(i) < 3) return;
                            this.translate(o, i), this.lastPointList = [ i ];
                        } else {
                            var u = a(this.lastPointList, 2), l = u[0], c = u[1], f = a(n, 2), s = f[0], h = f[1], d = l.distance(c), p = s.distance(h);
                            if (Math.abs(p - d) < 3) return;
                            var v = new S((s.left + h.left) / 2, (s.top + h.top) / 2), m = this.currentOptions, y = (null === m || void 0 === m ? void 0 : m.width) * p / d / this.width - (null === m || void 0 === m ? void 0 : m.scale);
                            this.scale(y, v), this.lastPointList = n;
                        }
                    }
                }, {
                    key: "onClick",
                    value: function value() {}
                }, {
                    key: "transformImage",
                    value: function value(t, n, e) {
                        this.transform = "translate3d(".concat(t, "px, ").concat(n, "px, 0px) scale3d(").concat(e, ", ").concat(e, ", 1)");
                        var o = Number(e);
                        return this.currentOptions = {
                            left: Number(t),
                            top: Number(n),
                            width: this.width * o,
                            height: this.height * o,
                            scale: o
                        }, o;
                    }
                }, {
                    key: "translate",
                    value: function value(t, n) {
                        var e = this.currentOptions, o = (null === e || void 0 === e ? void 0 : e.left) + n.left - t.left, r = (null === e || void 0 === e ? void 0 : e.top) + n.top - t.top, i = this.transformLimit(o, r, null === e || void 0 === e ? void 0 : e.width, null === e || void 0 === e ? void 0 : e.height);
                        this.transformImage(i.left, i.top, null === e || void 0 === e ? void 0 : e.scale);
                    }
                }, {
                    key: "transformLimit",
                    value: function value(t, n, e, o) {
                        var r = this.options, i = Math.min(t, null === r || void 0 === r ? void 0 : r.maxLeft);
                        i += Math.max(0, (null === r || void 0 === r ? void 0 : r.maxLeft) + (null === r || void 0 === r ? void 0 : r.minWidth) - (i + e));
                        var a = Math.min(n, null === r || void 0 === r ? void 0 : r.maxTop);
                        return a += Math.max(0, (null === r || void 0 === r ? void 0 : r.maxTop) + (null === r || void 0 === r ? void 0 : r.minHeight) - (a + o)), 
                        new S(i, a);
                    }
                }, {
                    key: "scale",
                    value: function value(t, n) {
                        var e = this.currentOptions, o = Number((null === e || void 0 === e ? void 0 : e.scale) + t), r = this.options;
                        o = Math.max(null === r || void 0 === r ? void 0 : r.minScale, o), o = Math.min(null === r || void 0 === r ? void 0 : r.maxScale, o);
                        var i = this.containerRect, a = n.left - i.left - (null === e || void 0 === e ? void 0 : e.left), u = n.top - i.top - (null === e || void 0 === e ? void 0 : e.top), l = this.width * o, c = this.height * o, f = l / (null === e || void 0 === e ? void 0 : e.width), s = (null === e || void 0 === e ? void 0 : e.left) - (a * f - a), h = (null === e || void 0 === e ? void 0 : e.top) - (u * f - u), d = this.transformLimit(s, h, l, c);
                        this.transformImage(d.left, d.top, o);
                    }
                } ]), o;
            }(i.Vue);
            (0, r.__decorate)([ (0, i.Prop)({
                type: String,
                required: !0
            }) ], O.prototype, "src", void 0), (0, r.__decorate)([ (0, i.Emit)("map-click") ], O.prototype, "onClick", null), 
            (0, r.__decorate)([ (0, i.Emit)("scale-change") ], O.prototype, "transformImage", null), 
            O = (0, r.__decorate)([ i.Component ], O);
            var _ = O;
            n.default = _;
            var S = function() {
                function t(n, e) {
                    h(this, t), this.left = 0, this.top = 0, this.left = n, this.top = e;
                }
                return p(t, [ {
                    key: "distance",
                    value: function value(t) {
                        return Math.sqrt(Math.pow(t.top - this.top, 2) + Math.pow(t.left - this.left, 2));
                    }
                } ]), t;
            }();
        }).call(this, e("543d")["default"]);
    },
    "9e96": function e96(t, n, e) {
        "use strict";
        e.r(n);
        var o = e("0b23"), r = e("3fb5");
        for (var i in r) [ "default" ].indexOf(i) < 0 && function(t) {
            e.d(n, t, function() {
                return r[t];
            });
        }(i);
        e("3250");
        var a, u = e("f0c5"), l = Object(u["a"])(r["default"], o["b"], o["c"], !1, null, null, null, !1, o["a"], a);
        n["default"] = l.exports;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "components/image-map/image-map-create-component", {
    "components/image-map/image-map-create-component": function componentsImageMapImageMapCreateComponent(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("9e96"));
    }
}, [ [ "components/image-map/image-map-create-component" ] ] ]);