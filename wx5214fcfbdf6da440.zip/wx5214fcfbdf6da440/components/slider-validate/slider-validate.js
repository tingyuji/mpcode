var _typeof2 = require("../../@babel/runtime/helpers/typeof");

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "components/slider-validate/slider-validate" ], {
    "0251": function _(e, t, n) {
        "use strict";
        function r(e) {
            return r = "function" === typeof Symbol && "symbol" === _typeof2(Symbol.iterator) ? function(e) {
                return _typeof2(e);
            } : function(e) {
                return e && "function" === typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : _typeof2(e);
            }, r(e);
        }
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var o = n("9ab4"), u = n("60a3"), i = s(n("7234")), c = s(n("6d83")), a = s(n("a227")), f = s(n("9050")), l = n("d257");
        function s(e) {
            return e && e.__esModule ? e : {
                default: e
            };
        }
        function d(e, t) {
            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
        }
        function p(e, t) {
            for (var n = 0; n < t.length; n++) {
                var r = t[n];
                r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), 
                Object.defineProperty(e, r.key, r);
            }
        }
        function v(e, t, n) {
            return t && p(e.prototype, t), n && p(e, n), e;
        }
        function y(e, t) {
            if ("function" !== typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
            e.prototype = Object.create(t && t.prototype, {
                constructor: {
                    value: e,
                    writable: !0,
                    configurable: !0
                }
            }), t && h(e, t);
        }
        function h(e, t) {
            return h = Object.setPrototypeOf || function(e, t) {
                return e.__proto__ = t, e;
            }, h(e, t);
        }
        function g(e) {
            var t = _();
            return function() {
                var n, r = O(e);
                if (t) {
                    var o = O(this).constructor;
                    n = Reflect.construct(r, arguments, o);
                } else n = r.apply(this, arguments);
                return b(this, n);
            };
        }
        function b(e, t) {
            if (t && ("object" === r(t) || "function" === typeof t)) return t;
            if (void 0 !== t) throw new TypeError("Derived constructors may only return object or undefined");
            return m(e);
        }
        function m(e) {
            if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return e;
        }
        function _() {
            if ("undefined" === typeof Reflect || !Reflect.construct) return !1;
            if (Reflect.construct.sham) return !1;
            if ("function" === typeof Proxy) return !0;
            try {
                return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
                !0;
            } catch (e) {
                return !1;
            }
        }
        function O(e) {
            return O = Object.setPrototypeOf ? Object.getPrototypeOf : function(e) {
                return e.__proto__ || Object.getPrototypeOf(e);
            }, O(e);
        }
        var k = 679, w = 382, x = 180, P = .4, S = function(e) {
            y(n, e);
            var t = g(n);
            function n() {
                var e;
                return d(this, n), e = t.apply(this, arguments), e.baseUrl = f.default.get(), e.uuid = "", 
                e.imageWidth = k * P, e.imageHeight = w * P, e.fillSize = c.default.rpxToPx(x * P), 
                e.triggerSize = c.default.rpxToPx(48), e.fillLeft = 0, e.triggerLeft = 0, e.success = !1, 
                e;
            }
            return v(n, [ {
                key: "valueChange",
                value: function value() {
                    this.value && this.getImage();
                }
            }, {
                key: "emitSuccess",
                value: function value(e) {
                    var t = this;
                    return this.success = !0, (0, l.delay)(function() {
                        return t.closeClick();
                    }, 1e3), e;
                }
            }, {
                key: "closeClick",
                value: function value() {
                    return !1;
                }
            }, {
                key: "getImage",
                value: function value() {
                    var e = this;
                    this.triggerLeft = 0, i.default.get("/v1/img_verification/get_pic_uuid").then(function(t) {
                        e.uuid = t.uuid;
                    }).catch(function(e) {
                        console.error(e), a.default.showToast(e.message);
                    });
                }
            }, {
                key: "onTriggerChange",
                value: function value(e) {
                    var t = this;
                    this.$nextTick(function() {
                        return t.fillLeft = e.detail.x;
                    });
                }
            }, {
                key: "onTriggerTouchEnd",
                value: function value() {
                    var e = this, t = this.fillLeft / P;
                    this.triggerLeft = this.fillLeft, i.default.get("/v1/img_verification/verification", {
                        uuid: this.uuid,
                        value: t
                    }).then(function(t) {
                        console.log(t), e.emitSuccess("");
                    }).catch(function(t) {
                        console.error(t), e.getImage();
                    });
                }
            } ]), n;
        }(u.Vue);
        (0, o.__decorate)([ (0, u.Prop)(Boolean) ], S.prototype, "value", void 0), (0, o.__decorate)([ (0, 
        u.Prop)({
            type: Number,
            default: 1005
        }) ], S.prototype, "zIndex", void 0), (0, o.__decorate)([ (0, u.Watch)("value") ], S.prototype, "valueChange", null), 
        (0, o.__decorate)([ (0, u.Emit)("success") ], S.prototype, "emitSuccess", null), 
        (0, o.__decorate)([ (0, u.Emit)("input") ], S.prototype, "closeClick", null), S = (0, 
        o.__decorate)([ u.Component ], S);
        var j = S;
        t.default = j;
    },
    "7adf": function adf(e, t, n) {},
    a38c: function a38c(e, t, n) {
        "use strict";
        n.r(t);
        var r = n("d809"), o = n("b0f3");
        for (var u in o) [ "default" ].indexOf(u) < 0 && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(u);
        n("d8ac");
        var i, c = n("f0c5"), a = Object(c["a"])(o["default"], r["b"], r["c"], !1, null, null, null, !1, r["a"], i);
        t["default"] = a.exports;
    },
    b0f3: function b0f3(e, t, n) {
        "use strict";
        n.r(t);
        var r = n("0251"), o = n.n(r);
        for (var u in r) [ "default" ].indexOf(u) < 0 && function(e) {
            n.d(t, e, function() {
                return r[e];
            });
        }(u);
        t["default"] = o.a;
    },
    d809: function d809(e, t, n) {
        "use strict";
        n.d(t, "b", function() {
            return o;
        }), n.d(t, "c", function() {
            return u;
        }), n.d(t, "a", function() {
            return r;
        });
        var r = {
            overlay: function overlay() {
                return n.e("components/overlay/overlay").then(n.bind(null, "9c32"));
            }
        }, o = function o() {
            var e = this, t = e.$createElement;
            e._self._c;
        }, u = [];
    },
    d8ac: function d8ac(e, t, n) {
        "use strict";
        var r = n("7adf"), o = n.n(r);
        o.a;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "components/slider-validate/slider-validate-create-component", {
    "components/slider-validate/slider-validate-create-component": function componentsSliderValidateSliderValidateCreateComponent(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("a38c"));
    }
}, [ [ "components/slider-validate/slider-validate-create-component" ] ] ]);