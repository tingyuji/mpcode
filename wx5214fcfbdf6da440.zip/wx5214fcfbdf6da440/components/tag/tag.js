var _typeof2 = require("../../@babel/runtime/helpers/typeof");

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "components/tag/tag" ], {
    "1d17": function d17(t, e, o) {
        "use strict";
        o.r(e);
        var r = o("6cca"), n = o.n(r);
        for (var c in r) [ "default" ].indexOf(c) < 0 && function(t) {
            o.d(e, t, function() {
                return r[t];
            });
        }(c);
        e["default"] = n.a;
    },
    "6a4e": function a4e(t, e, o) {
        "use strict";
        var r = o("cb5a"), n = o.n(r);
        n.a;
    },
    "6cca": function cca(t, e, o) {
        "use strict";
        function r(t) {
            return r = "function" === typeof Symbol && "symbol" === _typeof2(Symbol.iterator) ? function(t) {
                return _typeof2(t);
            } : function(t) {
                return t && "function" === typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : _typeof2(t);
            }, r(t);
        }
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var n = o("9ab4"), c = o("60a3");
        function u(t, e) {
            if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function");
        }
        function a(t, e) {
            if ("function" !== typeof e && null !== e) throw new TypeError("Super expression must either be null or a function");
            t.prototype = Object.create(e && e.prototype, {
                constructor: {
                    value: t,
                    writable: !0,
                    configurable: !0
                }
            }), e && i(t, e);
        }
        function i(t, e) {
            return i = Object.setPrototypeOf || function(t, e) {
                return t.__proto__ = e, t;
            }, i(t, e);
        }
        function f(t) {
            var e = d();
            return function() {
                var o, r = s(t);
                if (e) {
                    var n = s(this).constructor;
                    o = Reflect.construct(r, arguments, n);
                } else o = r.apply(this, arguments);
                return p(this, o);
            };
        }
        function p(t, e) {
            if (e && ("object" === r(e) || "function" === typeof e)) return e;
            if (void 0 !== e) throw new TypeError("Derived constructors may only return object or undefined");
            return l(t);
        }
        function l(t) {
            if (void 0 === t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return t;
        }
        function d() {
            if ("undefined" === typeof Reflect || !Reflect.construct) return !1;
            if (Reflect.construct.sham) return !1;
            if ("function" === typeof Proxy) return !0;
            try {
                return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {})), 
                !0;
            } catch (t) {
                return !1;
            }
        }
        function s(t) {
            return s = Object.setPrototypeOf ? Object.getPrototypeOf : function(t) {
                return t.__proto__ || Object.getPrototypeOf(t);
            }, s(t);
        }
        var y = function(t) {
            a(o, t);
            var e = f(o);
            function o() {
                return u(this, o), e.apply(this, arguments);
            }
            return o;
        }(c.Vue);
        (0, n.__decorate)([ (0, c.Prop)({
            type: String,
            required: !0
        }) ], y.prototype, "content", void 0), (0, n.__decorate)([ (0, c.Prop)({
            type: String,
            default: "#e2a71a"
        }) ], y.prototype, "color", void 0), (0, n.__decorate)([ (0, c.Prop)({
            type: String,
            default: "rgba(226, 167, 26, 0.4)"
        }) ], y.prototype, "borderColor", void 0), (0, n.__decorate)([ (0, c.Prop)({
            type: String,
            default: "small"
        }) ], y.prototype, "size", void 0), (0, n.__decorate)([ (0, c.Prop)({
            type: Boolean,
            default: !0
        }) ], y.prototype, "border", void 0), (0, n.__decorate)([ (0, c.Prop)({
            type: String,
            default: "rgba(255, 163, 0, 0.1)"
        }) ], y.prototype, "backgroundColor", void 0), (0, n.__decorate)([ (0, c.Prop)(Boolean) ], y.prototype, "background", void 0), 
        y = (0, n.__decorate)([ c.Component ], y);
        var b = y;
        e.default = b;
    },
    caaa: function caaa(t, e, o) {
        "use strict";
        o.r(e);
        var r = o("f622"), n = o("1d17");
        for (var c in n) [ "default" ].indexOf(c) < 0 && function(t) {
            o.d(e, t, function() {
                return n[t];
            });
        }(c);
        o("6a4e");
        var u, a = o("f0c5"), i = Object(a["a"])(n["default"], r["b"], r["c"], !1, null, null, null, !1, r["a"], u);
        e["default"] = i.exports;
    },
    cb5a: function cb5a(t, e, o) {},
    f622: function f622(t, e, o) {
        "use strict";
        var r;
        o.d(e, "b", function() {
            return n;
        }), o.d(e, "c", function() {
            return c;
        }), o.d(e, "a", function() {
            return r;
        });
        var n = function n() {
            var t = this, e = t.$createElement;
            t._self._c;
        }, c = [];
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "components/tag/tag-create-component", {
    "components/tag/tag-create-component": function componentsTagTagCreateComponent(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("caaa"));
    }
}, [ [ "components/tag/tag-create-component" ] ] ]);