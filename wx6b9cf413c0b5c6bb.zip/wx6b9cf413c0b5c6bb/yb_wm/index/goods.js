(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "yb_wm/index/goods" ], {
    "1cb6": function(t, e, o) {
        "use strict";
        o.d(e, "b", function() {
            return r;
        }), o.d(e, "c", function() {
            return s;
        }), o.d(e, "a", function() {
            return n;
        });
        var n = {
            vTabs: function() {
                return o.e("components/v-tabs/v-tabs").then(o.bind(null, "813a"));
            }
        }, r = function() {
            var t = this, e = t.$createElement, o = (t._self._c, t.sjxx.moreSet && !t.newPage && 1 == t.nowGoodload ? t.__map(t.catrgoryList, function(e, o) {
                var n = t.__get_orig(e), r = t.getReturnList(1, e);
                return {
                    $orig: n,
                    l0: r
                };
            }) : null), n = t.sjxx.moreSet && !t.newPage && 1 != t.nowGoodload && t.catrgoryList.length ? t.getReturnList(2) : null;
            t._isMounted || (t.e0 = function(e) {
                t.showShopInfo = !t.showShopInfo;
            }, t.e1 = function(e, o) {
                var n = arguments[arguments.length - 1].currentTarget.dataset, r = n.eventParams || n["event-params"];
                o = r.co;
                return t.goodinfo(o.id);
            }, t.e2 = function(e, o) {
                var n = arguments[arguments.length - 1].currentTarget.dataset, r = n.eventParams || n["event-params"];
                o = r.co;
                return t.goodinfo(o.id);
            }, t.e3 = function(e) {
                t.tcyhqshow = !1;
            }), t.$mp.data = Object.assign({}, {
                $root: {
                    l1: o,
                    l2: n
                }
            });
        }, s = [];
    },
    2793: function(t, e, o) {
        "use strict";
        (function(t) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var n = c(o("a34a")), r = o("26cb"), s = c(o("e1c0")), i = o("ddcf"), a = o("a669"), u = c(o("3f2a"));
            function c(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            function d(t, e) {
                var o;
                if ("undefined" === typeof Symbol || null == t[Symbol.iterator]) {
                    if (Array.isArray(t) || (o = l(t)) || e && t && "number" === typeof t.length) {
                        o && (t = o);
                        var n = 0, r = function() {};
                        return {
                            s: r,
                            n: function() {
                                return n >= t.length ? {
                                    done: !0
                                } : {
                                    done: !1,
                                    value: t[n++]
                                };
                            },
                            e: function(t) {
                                throw t;
                            },
                            f: r
                        };
                    }
                    throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
                }
                var s, i = !0, a = !1;
                return {
                    s: function() {
                        o = t[Symbol.iterator]();
                    },
                    n: function() {
                        var t = o.next();
                        return i = t.done, t;
                    },
                    e: function(t) {
                        a = !0, s = t;
                    },
                    f: function() {
                        try {
                            i || null == o.return || o.return();
                        } finally {
                            if (a) throw s;
                        }
                    }
                };
            }
            function l(t, e) {
                if (t) {
                    if ("string" === typeof t) return h(t, e);
                    var o = Object.prototype.toString.call(t).slice(8, -1);
                    return "Object" === o && t.constructor && (o = t.constructor.name), "Map" === o || "Set" === o ? Array.from(t) : "Arguments" === o || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(o) ? h(t, e) : void 0;
                }
            }
            function h(t, e) {
                (null == e || e > t.length) && (e = t.length);
                for (var o = 0, n = new Array(e); o < e; o++) n[o] = t[o];
                return n;
            }
            function f(t, e) {
                var o = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(t);
                    e && (n = n.filter(function(e) {
                        return Object.getOwnPropertyDescriptor(t, e).enumerable;
                    })), o.push.apply(o, n);
                }
                return o;
            }
            function g(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var o = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? f(Object(o), !0).forEach(function(e) {
                        p(t, e, o[e]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(o)) : f(Object(o)).forEach(function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(o, e));
                    });
                }
                return t;
            }
            function p(t, e, o) {
                return e in t ? Object.defineProperty(t, e, {
                    value: o,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[e] = o, t;
            }
            function m(t, e, o, n, r, s, i) {
                try {
                    var a = t[s](i), u = a.value;
                } catch (c) {
                    return void o(c);
                }
                a.done ? e(u) : Promise.resolve(u).then(n, r);
            }
            function x(t) {
                return function() {
                    var e = this, o = arguments;
                    return new Promise(function(n, r) {
                        var s = t.apply(e, o);
                        function i(t) {
                            m(s, n, r, i, a, "next", t);
                        }
                        function a(t) {
                            m(s, n, r, i, a, "throw", t);
                        }
                        i(void 0);
                    });
                };
            }
            var y = function() {
                o.e("components/third/uni-nav-bar").then(function() {
                    return resolve(o("46cf"));
                }.bind(null, o)).catch(o.oe);
            }, w = function() {
                o.e("components/goods/index").then(function() {
                    return resolve(o("7c5f"));
                }.bind(null, o)).catch(o.oe);
            }, b = function() {
                o.e("components/goods/goods-car").then(function() {
                    return resolve(o("cf29"));
                }.bind(null, o)).catch(o.oe);
            }, v = function() {
                Promise.all([ o.e("common/vendor"), o.e("components/goods/spec") ]).then(function() {
                    return resolve(o("a5de"));
                }.bind(null, o)).catch(o.oe);
            }, I = function() {
                o.e("components/common/load").then(function() {
                    return resolve(o("bdf2"));
                }.bind(null, o)).catch(o.oe);
            }, j = function() {
                o.e("components/common/popup").then(function() {
                    return resolve(o("b94e"));
                }.bind(null, o)).catch(o.oe);
            }, L = function() {
                o.e("components/common/modal").then(function() {
                    return resolve(o("62f5"));
                }.bind(null, o)).catch(o.oe);
            }, S = function() {
                o.e("components/common/jzz").then(function() {
                    return resolve(o("70be"));
                }.bind(null, o)).catch(o.oe);
            }, _ = function() {
                o.e("components/common/tips").then(function() {
                    return resolve(o("be30"));
                }.bind(null, o)).catch(o.oe);
            }, T = function() {
                o.e("components/common/functionCmp/swiper").then(function() {
                    return resolve(o("adc8"));
                }.bind(null, o)).catch(o.oe);
            }, z = function() {
                o.e("components/template/tcyhq").then(function() {
                    return resolve(o("65eb"));
                }.bind(null, o)).catch(o.oe);
            }, O = function() {
                o.e("components/template/tcgg").then(function() {
                    return resolve(o("bcbd"));
                }.bind(null, o)).catch(o.oe);
            }, C = function() {
                o.e("components/goods/store/store-info").then(function() {
                    return resolve(o("9a87"));
                }.bind(null, o)).catch(o.oe);
            }, k = function() {
                o.e("components/goods/store/store-shop").then(function() {
                    return resolve(o("2735"));
                }.bind(null, o)).catch(o.oe);
            }, A = function() {
                o.e("components/v-tabs/v-tabs").then(function() {
                    return resolve(o("813a"));
                }.bind(null, o)).catch(o.oe);
            }, M = function() {
                o.e("yb_wm/index/components/good_tab").then(function() {
                    return resolve(o("3e19"));
                }.bind(null, o)).catch(o.oe);
            }, D = function() {
                o.e("yb_wm/index/components/good_item").then(function() {
                    return resolve(o("6f58"));
                }.bind(null, o)).catch(o.oe);
            }, P = getApp().globalData, q = {
                components: {
                    uniNavBar: y,
                    goods: w,
                    goodsCar: b,
                    spec: v,
                    load: I,
                    mgPopup: j,
                    mgModal: L,
                    jzz: S,
                    tips: _,
                    MgSwiper: T,
                    tcyhq: z,
                    tcgg: O,
                    storeInfo: C,
                    storeShop: k,
                    vTabs: A,
                    goodItem: D,
                    goodTab: M
                },
                data: function() {
                    return {
                        is_onload: !1,
                        showloading: !0,
                        catrgoryList: [],
                        goodsList: [],
                        sIndex: 0,
                        rsiv: "",
                        rsiv2: "",
                        lsiv: "",
                        showGg: !1,
                        buyType: 2,
                        showShopInfo: !1,
                        showShopSelect: !1,
                        outin: "1",
                        goodsInfo: {},
                        showjz: !1,
                        tcyhqshow: !1,
                        tcCoupon: {},
                        tcggshow: !1,
                        tcggList: [],
                        showCar: !1,
                        startMoney: "",
                        xdtype: "",
                        issc: !1,
                        sjyhq: [],
                        flid: "",
                        jsgdwb: !1,
                        sjqb: [],
                        showhdp: 0,
                        getshowcar: !0,
                        hasTabbar: !1,
                        categoryId: "",
                        top_id: "id_0"
                    };
                },
                mixins: [ i.utilMixins, u.default ],
                onLoad: function(e) {
                    var o = this;
                    return x(n.default.mark(function r() {
                        return n.default.wrap(function(n) {
                            while (1) switch (n.prev = n.next) {
                              case 0:
                                return o.pageType = 0, t.$on("qjjtsj", function(t) {
                                    console.log(t), t.showgwc ? o.showCar = !0 : t.hasOwnProperty("flid") ? (o.flid = "", 
                                    setTimeout(function() {
                                        o.flid = t.flid, o.newGoodLoad && o.getNewList(o.flid);
                                    })) : t.wmtz ? o.$refs.goodscar.goPay(2) : (o.xdtype = "", o.xdtype = t);
                                }), o.storeId = s.default.getOptions(e, {
                                    key: "storeId",
                                    q1: o.storeInfo.id
                                }) || "", console.log("this.storeInfothis.storeInfothis.storeInfo", o.storeInfo, o.storeId), 
                                o.query = e, n.next = 7, o.getLoginInfo({
                                    inviteId: e.userId
                                });

                              case 7:
                                o.getDw(), o.getSystem(), o.getLayout(), o.getConfig({
                                    key: "orderset",
                                    api: "ddsz"
                                }).then(function() {
                                    "1" == o.orderset.orderStore && (o.showShopSelect = !0);
                                }), o.is_onload = !0;

                              case 12:
                              case "end":
                                return n.stop();
                            }
                        }, r);
                    }))();
                },
                mounted: function() {},
                onHide: function() {
                    this.startMoney = "";
                },
                computed: g(g(g({}, (0, r.mapState)([ "sjxx" ])), (0, r.mapState)({
                    scarList: function(t) {
                        return t.scarList.out.data || [];
                    },
                    storeInfo: function(t) {
                        return t.config.storeInfo;
                    },
                    orderset: function(t) {
                        return t.config.orderset;
                    }
                })), {}, {
                    pageHeight: function() {
                        if (!getApp().sgheight) {
                            var e = t.getSystemInfoSync(), o = +(e.statusBarHeight + 44 + t.upx2px(228)).toFixed(2) + (1 == this.goodSecondaryCategory ? 30 : 0), n = 224 + (1 == this.goodSecondaryCategory ? 30 : 0);
                            getApp().sgheight = {
                                topH: o,
                                topH2: n
                            };
                        }
                        return getApp().sgheight;
                    },
                    lbswiper: function() {
                        return {
                            class: "mt10 mb20",
                            swiper: this.sjxx.moreSet && this.sjxx.moreSet.orderMedia.map(function(t) {
                                return {
                                    url: t
                                };
                            }),
                            duration: "",
                            mode: "",
                            height: "260",
                            radius: "8",
                            auto: !0,
                            interval: 5
                        };
                    },
                    ModeArr: function() {
                        var t = [];
                        return this.sjxx.moreSet && (2 == this.sjxx.moreSet.distributionSupport.length ? (t = [ {
                            name: this.sjxx.moreSet.selfName,
                            value: "2"
                        }, {
                            name: this.sjxx.moreSet.outName,
                            value: "1"
                        } ], 2 == this.sjxx.moreSet.auto && t.reverse(), null != P.xzdzInfo && t.reverse(), 
                        this.buyType = +t[0].value, this.xdtype && (this.buyType = this.xdtype)) : this.sjxx.moreSet.distributionSupport.find(function(t) {
                            return 1 == t;
                        }) ? this.buyType = 1 : this.sjxx.moreSet.distributionSupport.find(function(t) {
                            return 2 == t;
                        }) && (this.buyType = 2)), t;
                    },
                    isClose: function() {
                        return this.sjxx.shopData && (1 == this.sjxx.shopData.storeOpen || 2 == this.sjxx.shopData.storeOpen && 1 == this.sjxx.moreSet.status);
                    },
                    cshow: function() {
                        return this.scarList.length > 0;
                    },
                    leftpb: function() {
                        return 1 == this.system.outTabbar ? this.cshow ? "305rpx" : "115rpx" : this.cshow ? "260rpx" : "115rpx";
                    },
                    rightpb: function() {
                        return this.system.outTabbar, this.cshow ? "230rpx" : "115rpx";
                    },
                    getreet: function() {
                        return this.isIpx && !this.hasTabbar ? "40" : !this.isIpx && this.hasTabbar ? "115" : this.isIpx && this.hasTabbar ? "155" : "0";
                    },
                    getreet2: function() {
                        return this.isIpx && !this.hasTabbar ? "132" : !this.isIpx && this.hasTabbar ? "225" : this.isIpx && this.hasTabbar ? "265" : "110";
                    },
                    qhfl: function() {
                        return {
                            jsgdwb: this.jsgdwb,
                            flid: this.flid
                        };
                    },
                    ztqs: function() {
                        return "rgba(".concat(this.cTR(this.tColor), ",0.1)");
                    },
                    mjtxt: function() {
                        return this.sjxx.discount && 1 == this.sjxx.discount.reduce.type ? "".concat(this.sjxx.discount.reduce.moneyArr[0].fullMoney, "减").concat(this.sjxx.discount.reduce.moneyArr[0].money) : this.sjxx.discount && 2 == this.sjxx.discount.reduce.type ? this.sjxx.discount.reduce.moneyArr.map(function(t) {
                            return "满".concat(t.fullMoney, "减").concat(t.money);
                        }).reverse().toString() : void 0;
                    }
                }),
                watch: {
                    qhfl: {
                        handler: function(t) {
                            var e = this;
                            if (t.jsgdwb && t.flid && this.sjxx.data.find(function(e) {
                                return e.id == t.flid;
                            })) {
                                var o = this.sjxx.data.findIndex(function(e) {
                                    return e.id == t.flid;
                                });
                                this.sIndex = o, this.oneIndex = o, this.top_id = "id_" + o, this.noscroll = !0, 
                                this.lsiv = "l".concat(o - 3), this.rsiv = "r".concat(o), setTimeout(function() {
                                    e.noscroll = !1;
                                }, 500);
                            }
                        },
                        immediate: !0
                    }
                },
                methods: g(g(g({}, (0, r.mapActions)([ "getSjxx", "getSjxxdata", "getConfig", "supdCar", "getMycar" ])), (0, 
                r.mapMutations)([ "setScarList" ])), {}, {
                    tbrh: function(t) {
                        this.hasTabbar = !0;
                    },
                    getDw: function() {
                        var t = this;
                        return x(n.default.mark(function e() {
                            var o, r, s, i;
                            return n.default.wrap(function(e) {
                                while (1) switch (e.prev = e.next) {
                                  case 0:
                                    if (t.systemName) {
                                        e.next = 2;
                                        break;
                                    }
                                    return e.abrupt("return");

                                  case 2:
                                    return o = {
                                        latitude: "39.906930",
                                        longitude: "116.397570"
                                    }, getApp().globalData.gdlocation && JSON.stringify(getApp().globalData.gdlocation) == JSON.stringify(o) && (getApp().globalData.gdlocation = null), 
                                    e.next = 6, (0, a.getDw)({
                                        t: 0
                                    });

                                  case 6:
                                    return r = e.sent, e.next = 9, t.util.request({
                                        url: t.api.zjdp,
                                        data: {
                                            storeId: "",
                                            lat: r.latitude,
                                            lng: r.longitude
                                        }
                                    });

                                  case 9:
                                    s = e.sent, i = s.data, t.storeId = i.id, t.getConfig({
                                        key: "storeInfo",
                                        data: {
                                            id: i.id,
                                            name: i.name,
                                            distance: i.distance
                                        }
                                    }), t.refreshInfo();

                                  case 14:
                                  case "end":
                                    return e.stop();
                                }
                            }, e);
                        }))();
                    },
                    changeStore: function(t) {
                        this.showloading = !0, this.tcyhqshow = this.tcggshow = this.jsgdwb = !1, this.startMoney = "", 
                        this.xdtype = this.flid = "", this.sIndex = 0, this.storeId = t.id, this.refreshInfo("resetAdr");
                    },
                    refreshInfo: function(t) {
                        var e = this;
                        return x(n.default.mark(function o() {
                            return n.default.wrap(function(o) {
                                while (1) switch (o.prev = o.next) {
                                  case 0:
                                    e.storeId = s.default.getOptions(e.query, {
                                        key: "storeId",
                                        q1: e.storeInfo.id
                                    }) || "", e.sIndex = 0, e.rsiv = "r0", "resetAdr" == t && (P.xzdzInfo = null), e.init();

                                  case 5:
                                  case "end":
                                    return o.stop();
                                }
                            }, o);
                        }))();
                    },
                    init: function(t) {
                        var e = this;
                        return x(n.default.mark(function t() {
                            var o, r, i, a, u, c, l, h;
                            return n.default.wrap(function(t) {
                                while (1) switch (t.prev = t.next) {
                                  case 0:
                                    return e.loadShow = !0, e.oneIndex = 0, e.showloading = !0, t.next = 5, getApp().globalData.gdlocation;

                                  case 5:
                                    return o = t.sent, t.next = 8, e.getSjxx({
                                        storeId: e.storeId,
                                        lat: null === o || void 0 === o ? void 0 : o.latitude,
                                        lng: null === o || void 0 === o ? void 0 : o.longitude,
                                        nowGoodload: e.newGoodLoad
                                    });

                                  case 8:
                                    return t.next = 10, e.getMycar({
                                        storeId: e.sjxx.shopData.id
                                    });

                                  case 10:
                                    e.catrgoryList = {}, e.storeId = e.sjxx.shopData.id, e.goodsList = s.default.deepCopy(e.sjxx.recommendData), 
                                    e.catrgoryList = s.default.deepCopy(e.sjxx.data), r = d(e.catrgoryList);
                                    try {
                                        for (r.s(); !(i = r.n()).done; ) a = i.value, a.childCategory && a.childCategory.length ? a.childCategory.unshift({
                                            name: "全部",
                                            id: ""
                                        }) : a.childCategory = [ {
                                            name: "全部",
                                            id: ""
                                        } ], a.value = 0, a.typeId = "";
                                    } catch (f) {
                                        r.e(f);
                                    } finally {
                                        r.f();
                                    }
                                    if (!(e.newGoodLoad && e.catrgoryList && e.catrgoryList.length)) {
                                        t.next = 19;
                                        break;
                                    }
                                    return t.next = 19, e.getNewList(e.flid ? e.flid : e.catrgoryList[0].id);

                                  case 19:
                                    for (e.showloading = !1, u = 0; u < e.scarList.length; u++) {
                                        if (!e.newGoodLoad) for (c = 0; c < e.catrgoryList.length; c++) for (l = 0; l < e.catrgoryList[c].goods.length; l++) e.catrgoryList[c].goods[l].id == e.scarList[u].goodsId && (e.catrgoryList[c].goods[l].num = +e.catrgoryList[c].goods[l].num + +e.scarList[u].num);
                                        for (h = 0; h < e.goodsList.length; h++) e.goodsList[h].id == e.scarList[u].goodsId && (e.goodsList[h].num = 0, 
                                        e.goodsList[h].num = +e.goodsList[h].num + +e.scarList[u].num);
                                    }
                                    e.$nextTick(function() {
                                        setTimeout(function() {
                                            e.getHeightList();
                                        }, 100);
                                    }), e.getConfig({
                                        key: "storeInfo",
                                        data: {
                                            id: e.sjxx.shopData.id,
                                            name: e.sjxx.shopData.name,
                                            distance: e.sjxx.shopData.distance
                                        }
                                    }), setTimeout(x(n.default.mark(function t() {
                                        return n.default.wrap(function(t) {
                                            while (1) switch (t.prev = t.next) {
                                              case 0:
                                                return t.next = 2, e.getOtherData();

                                              case 2:
                                                e.addFwjl({
                                                    storeId: e.storeId,
                                                    origin: "2"
                                                });

                                              case 3:
                                              case "end":
                                                return t.stop();
                                            }
                                        }, t);
                                    })), 1e3);

                                  case 24:
                                  case "end":
                                    return t.stop();
                                }
                            }, t);
                        }))();
                    },
                    getOtherData: function() {
                        var t = this;
                        return x(n.default.mark(function e() {
                            var o, r;
                            return n.default.wrap(function(e) {
                                while (1) switch (e.prev = e.next) {
                                  case 0:
                                    return t.issc = 1 == t.sjxx.shopData.isCollection, e.next = 3, t.util.request({
                                        url: t.api.qtsjjh,
                                        data: {
                                            location: 1,
                                            storeId: t.storeId
                                        }
                                    });

                                  case 3:
                                    o = e.sent, r = o.data, r.windowCoupon.hasOwnProperty("name") && (t.tcCoupon = r.windowCoupon, 
                                    t.tcyhqshow = !0), t.sjyhq = r.storeCoupon, t.sjqb = r.rollBag;

                                  case 8:
                                  case "end":
                                    return e.stop();
                                }
                            }, e);
                        }))();
                    },
                    getHeightList: function() {
                        var e = this, o = t.createSelectorQuery();
                        o.selectAll(".c-item").boundingClientRect(function(t) {
                            var o = [], n = 0;
                            t.forEach(function(t) {
                                n += t.height, o.push(n);
                            }), e.right_height = o, e.jsgdwb = !0;
                        }).exec();
                    },
                    choose: function(t) {
                        var e = this;
                        if (1 == this.nowGoodload) {
                            if (this.sIndex == t) return;
                            this.sIndex = t, this.noscroll = !0, this.lsiv = "l".concat(t - 3), this.rsiv = "r".concat(t), 
                            setTimeout(function() {
                                e.noscroll = !1;
                            }, 500);
                        } else {
                            if (this.sIndex == t) return;
                            this.sIndex = t, this.swiperChange(t), this.newGoodLoad && this.getNewList(this.catrgoryList[t].id);
                        }
                    },
                    myscroll: function(t) {
                        if (!this.noscroll) {
                            var e = t.detail.scrollTop;
                            this.showhdp = e > 10 ? 1 : 0;
                            for (var o = 0; o < this.right_height.length; o++) if (e < this.right_height[0]) this.sIndex = 0, 
                            this.lsiv = "l0"; else if (e >= this.right_height[o - 1] && e < this.right_height[o]) {
                                this.sIndex = o, this.lsiv = "l".concat(o - 3), this.rsiv = "";
                                break;
                            }
                        }
                    },
                    myscrolltoupper: function(t) {
                        "top" == t.detail.direction && (this.showhdp = 0);
                    },
                    swiperChange: function(t) {
                        var e = this;
                        return x(n.default.mark(function o() {
                            return n.default.wrap(function(o) {
                                while (1) switch (o.prev = o.next) {
                                  case 0:
                                    e.rsiv2 = "", setTimeout(function() {
                                        e.rsiv2 = "r0";
                                    }, 50), e.lsiv = "l".concat(t - 3);

                                  case 3:
                                  case "end":
                                    return o.stop();
                                }
                            }, o);
                        }))();
                    },
                    refreshList: function() {
                        var t = this;
                        return x(n.default.mark(function e() {
                            var o, r, s, i, a, u, c, d, l, h, f, g, p, m;
                            return n.default.wrap(function(e) {
                                while (1) switch (e.prev = e.next) {
                                  case 0:
                                    return t.getshowcar = !1, o = getApp().globalData.gdlocation, console.log(o), null != P.xzdzInfo && (o.latitude = P.xzdzInfo.lat, 
                                    o.longitude = P.xzdzInfo.lng), e.next = 6, t.getSjxxdata({
                                        storeId: t.storeId,
                                        lat: o.latitude,
                                        lng: o.longitude,
                                        nowGoodload: t.newGoodLoad
                                    });

                                  case 6:
                                    return e.next = 8, t.getMycar({
                                        storeId: t.sjxx.shopData.id
                                    });

                                  case 8:
                                    if (r = t.scarList, s = t.catrgoryList, t.newGoodLoad) for (i = 0; i < r.length; i++) for (a = 0; a < t.newList.length; a++) t.newList[a].id == r[i].goodsId && (t.newList[a].num = 0, 
                                    t.newList[a].num += +r[i].num); else for (u = 0, c = s.length; u < c; u++) for (d = 0, 
                                    l = s[u].goods.length; d < l; d++) for (s[u].goods[d].num = 0, h = 0; h < r.length; h++) s[u].goods[d].id == r[h].goodsId && (s[u].goods[d].num += +r[h].num);
                                    for (f = t.goodsList, g = 0, p = f.length; g < p; g++) for (f[g].num = 0, m = 0; m < r.length; m++) f[g].id == r[m].goodsId && (f[g].num += +r[m].num);
                                    t.getshowcar = !0;

                                  case 13:
                                  case "end":
                                    return e.stop();
                                }
                            }, e);
                        }))();
                    },
                    updList: function(t) {
                        var e = this;
                        return x(n.default.mark(function o() {
                            var r, s, i, a, u, c, d, l, h, f;
                            return n.default.wrap(function(o) {
                                while (1) switch (o.prev = o.next) {
                                  case 0:
                                    return console.log("updList", t), o.prev = 1, o.next = 4, e.supdCar("1" == t.e.addwz ? t.e.g.ggnum ? {
                                        storeId: e.storeId,
                                        type: t.type,
                                        goodsId: t.e.g.id,
                                        groupId: t.e.g.groupId || "",
                                        material: t.e.g.material || [],
                                        attribute: t.e.g.attribute || "",
                                        specsName: t.e.g.specsName || "",
                                        num: t.e.g.ggnum
                                    } : {
                                        storeId: e.storeId,
                                        type: t.type,
                                        goodsId: t.e.g.id,
                                        groupId: t.e.g.groupId || ""
                                    } : {
                                        storeId: e.storeId,
                                        type: t.type,
                                        goodsId: t.e.g.goodsId,
                                        id: t.e.g.id,
                                        groupId: t.e.g.groupId || ""
                                    });

                                  case 4:
                                    if (r = o.sent, r >= 0) {
                                        if (s = e.catrgoryList, e.newGoodLoad) for (i = 0; i < e.newList.length; i++) ("1" == t.e.addwz && e.newList[i].id == t.e.g.id || "2" == t.e.addwz && e.newList[i].id == t.e.g.goodsId) && (e.newList[i].num = r); else for (a = 0, 
                                        u = s.length; a < u; a++) for (c = 0, d = s[a].goods.length; c < d; c++) ("1" == t.e.addwz && s[a].goods[c].id == t.e.g.id || "2" == t.e.addwz && s[a].goods[c].id == t.e.g.goodsId) && (s[a].goods[c].num = r);
                                        for (l = e.goodsList, h = 0, f = l.length; h < f; h++) ("1" == t.e.addwz && l[h].id == t.e.g.id || "2" == t.e.addwz && l[h].id == t.e.g.goodsId) && (l[h].num = r);
                                    }
                                    e.showjz = !1, o.next = 13;
                                    break;

                                  case 9:
                                    o.prev = 9, o.t0 = o["catch"](1), e.showjz = !1, console.log(o.t0);

                                  case 13:
                                  case "end":
                                    return o.stop();
                                }
                            }, o, null, [ [ 1, 9 ] ]);
                        }))();
                    },
                    dec: function(t) {
                        var e = this;
                        return x(n.default.mark(function o() {
                            return n.default.wrap(function(o) {
                                while (1) switch (o.prev = o.next) {
                                  case 0:
                                    e.isClose && (e.showjz = !0, e.updList({
                                        type: 2,
                                        e: t
                                    }));

                                  case 1:
                                  case "end":
                                    return o.stop();
                                }
                            }, o);
                        }))();
                    },
                    add: function(t) {
                        var e = this;
                        return x(n.default.mark(function o() {
                            return n.default.wrap(function(o) {
                                while (1) switch (o.prev = o.next) {
                                  case 0:
                                    if (!e.isClose) {
                                        o.next = 7;
                                        break;
                                    }
                                    if (!(t.g.SalesStock && t.g.SalesStock <= 0)) {
                                        o.next = 3;
                                        break;
                                    }
                                    return o.abrupt("return", e.util.message("商品已售罄", 3));

                                  case 3:
                                    if (!(t.g.stock <= 0)) {
                                        o.next = 5;
                                        break;
                                    }
                                    return o.abrupt("return", e.util.message("商品已售罄", 3));

                                  case 5:
                                    e.showjz = !0, 1 != t.g.isSpecs && 1 != t.g.isMaterial && 1 != t.g.isAttr || t.g.hasOwnProperty("groupId") ? e.updList({
                                        type: 1,
                                        e: t
                                    }) : (e.showGg = !0, e.goodsInfo = t.g, e.showjz = !1);

                                  case 7:
                                  case "end":
                                    return o.stop();
                                }
                            }, o);
                        }))();
                    },
                    celarCar: function(t) {
                        var e = this.catrgoryList;
                        if (this.newGoodLoad) for (var o = 0; o < this.newList.length; o++) this.newList[o].num = 0; else for (var n = 0, r = e.length; n < r; n++) for (var s = 0, i = e[n].goods.length; s < i; s++) e[n].goods[s].num = 0;
                        for (var a = this.goodsList, u = 0, c = a.length; u < c; u++) a[u].num = 0;
                    },
                    changeBuyType: function(t) {
                        if (console.log("用户切换", t.value, this.buyType, this.ModeArr[0].value), t.value != this.buyType) {
                            if (1 == t.value && 2 == this.ModeArr[0].value) return console.log("用户想切换外1卖"), 
                            P.xzdzInfo = null, void this.go({
                                t: 1,
                                url: "/yb_wm/my/address/index?from=2&storeId=".concat(this.storeId)
                            });
                            2 == t.value && (P.xzdzInfo = null), this.buyType = 1 == this.buyType ? 2 : 1;
                        }
                    },
                    trigger: function(t) {
                        this.go({
                            t: t.index > 1 ? 1 : 2,
                            url: t.item.url
                        }), console.log(t);
                    },
                    lfName: function(t) {
                        t.substr(0, 2), t.substr(2, 4);
                        return t.substr(0, 2);
                    },
                    lsName: function(t) {
                        return t.substr(2, 5);
                    },
                    onmore: function() {
                        this.go({
                            url: "/yb_wm/shop/search/out?page=shopGoods"
                        });
                    },
                    goodinfo: function(t) {
                        this.go({
                            t: 1,
                            url: "/yb_wm/shop/out/goods-dl?gid=".concat(t, "&storeId=").concat(this.storeId, "&page=shopGoods&buyType=").concat(this.buyType)
                        });
                    },
                    goSelect: function() {
                        2 == this.system.storeSet.storeModel && this.go({
                            url: "/yb_wm/shop/select/index?page=goods&storeId=" + this.storeId
                        });
                    },
                    scdp: s.default.throttle(function() {
                        var t = x(n.default.mark(function t(e) {
                            var o;
                            return n.default.wrap(function(t) {
                                while (1) switch (t.prev = t.next) {
                                  case 0:
                                    return t.next = 2, this.util.request({
                                        url: this.api.scjk,
                                        method: "POST",
                                        data: {
                                            collectionId: this.storeId,
                                            type: 1
                                        }
                                    });

                                  case 2:
                                    o = t.sent, o && (this.issc = !this.issc, this.util.message((this.issc ? "" : "取消") + "收藏成功", 3));

                                  case 4:
                                  case "end":
                                    return t.stop();
                                }
                            }, t, this);
                        }));
                        return function(e) {
                            return t.apply(this, arguments);
                        };
                    }(), 1e3)
                }),
                updated: function() {},
                onShow: function() {
                    if (this.newGoodLoad) for (var t = 0; t < this.newList.length; t++) this.newList[t].num = 0;
                    this.sjxx.moreSet && (this.storeId != this.storeInfo.id ? this.changeStore(this.storeInfo) : this.ModeArr.length && 2 == this.ModeArr[0].value && (1 != this.buyType && P.xzdzInfo ? (this.buyType = 1, 
                    console.log("选择了地址")) : 1 != this.buyType || P.xzdzInfo || (this.buyType = 2)), 
                    this.$refs.goodscar.closeCar()), console.log("onshow refreshList"), this.is_onload && this.refreshList(), 
                    console.log("goods onShowonShowonShow", P.xzdzInfo);
                },
                onShareAppMessage: function() {
                    var t = "yb_cy/shop/goods?storeId=".concat(this.storeId, "&userId=").concat(this.uId);
                    return this.util.mpShare({
                        t: this.sjxx.storeInfo.name,
                        p: t
                    });
                }
            };
            e.default = q;
        }).call(this, o("543d")["default"]);
    },
    "44e5": function(t, e, o) {
        "use strict";
        o.r(e);
        var n = o("1cb6"), r = o("6d39");
        for (var s in r) "default" !== s && function(t) {
            o.d(e, t, function() {
                return r[t];
            });
        }(s);
        o("f3fa");
        var i, a = o("f0c5"), u = Object(a["a"])(r["default"], n["b"], n["c"], !1, null, "6412b931", null, !1, n["a"], i);
        e["default"] = u.exports;
    },
    "511b": function(t, e, o) {
        "use strict";
        (function(t) {
            o("35e6");
            n(o("66fd"));
            var e = n(o("44e5"));
            function n(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            wx.__webpack_require_UNI_MP_PLUGIN__ = o, t(e.default);
        }).call(this, o("543d")["createPage"]);
    },
    "6d39": function(t, e, o) {
        "use strict";
        o.r(e);
        var n = o("2793"), r = o.n(n);
        for (var s in n) "default" !== s && function(t) {
            o.d(e, t, function() {
                return n[t];
            });
        }(s);
        e["default"] = r.a;
    },
    "918a": function(t, e, o) {},
    f3fa: function(t, e, o) {
        "use strict";
        var n = o("918a"), r = o.n(n);
        r.a;
    }
}, [ [ "511b", "common/runtime", "common/vendor" ] ] ]);