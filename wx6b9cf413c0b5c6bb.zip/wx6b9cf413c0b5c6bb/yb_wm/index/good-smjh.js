(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "yb_wm/index/good-smjh" ], {
    "375d": function(e, o, t) {
        "use strict";
        t.r(o);
        var n = t("42ae"), r = t.n(n);
        for (var a in n) "default" !== a && function(e) {
            t.d(o, e, function() {
                return n[e];
            });
        }(a);
        o["default"] = r.a;
    },
    "409d": function(e, o, t) {
        "use strict";
        t.r(o);
        var n = t("888d"), r = t("375d");
        for (var a in r) "default" !== a && function(e) {
            t.d(o, e, function() {
                return r[e];
            });
        }(a);
        var u, c = t("f0c5"), d = Object(c["a"])(r["default"], n["b"], n["c"], !1, null, "67b32c5b", null, !1, n["a"], u);
        o["default"] = d.exports;
    },
    "42ae": function(e, o, t) {
        "use strict";
        (function(e) {
            Object.defineProperty(o, "__esModule", {
                value: !0
            }), o.default = void 0;
            t("26cb"), n(t("e1c0"));
            function n(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            var r = function() {
                t.e("components/common/load").then(function() {
                    return resolve(t("bdf2"));
                }.bind(null, t)).catch(t.oe);
            }, a = {
                name: "good-smjh",
                components: {
                    load: r
                },
                data: function() {
                    return {
                        showloading: !0
                    };
                },
                onLoad: function(o) {
                    this.getSystem();
                    var t = "";
                    o.storeId && (t = o.storeId);
                    var n = "";
                    o.params && (n = o.params);
                    var r = "";
                    r = o.otype ? o.otype : "goods", e.setStorageSync("goods_storeId", t), e.setStorageSync("goods_params", n);
                    var a = 2, u = "";
                    switch (r) {
                      case "fastOrder":
                        u = "/yb_wm/shop/ffmode/goods";
                        break;

                      case "goods":
                        u = "/yb_wm/index/goods", a = 3;
                        break;

                      default:
                        break;
                    }
                    console.log("中转界面"), console.log("url", u), this.go({
                        t: a,
                        url: u
                    });
                },
                computed: {},
                methods: {}
            };
            o.default = a;
        }).call(this, t("543d")["default"]);
    },
    4494: function(e, o, t) {
        "use strict";
        (function(e) {
            t("35e6");
            n(t("66fd"));
            var o = n(t("409d"));
            function n(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            wx.__webpack_require_UNI_MP_PLUGIN__ = t, e(o.default);
        }).call(this, t("543d")["createPage"]);
    },
    "888d": function(e, o, t) {
        "use strict";
        var n;
        t.d(o, "b", function() {
            return r;
        }), t.d(o, "c", function() {
            return a;
        }), t.d(o, "a", function() {
            return n;
        });
        var r = function() {
            var e = this, o = e.$createElement;
            e._self._c;
        }, a = [];
    }
}, [ [ "4494", "common/runtime", "common/vendor" ] ] ]);