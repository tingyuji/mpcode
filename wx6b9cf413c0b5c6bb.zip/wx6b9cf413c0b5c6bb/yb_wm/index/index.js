(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "yb_wm/index/index" ], {
    "5fdd": function(n, e, t) {
        "use strict";
        (function(n) {
            t("35e6");
            o(t("66fd"));
            var e = o(t("d343"));
            function o(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }
            wx.__webpack_require_UNI_MP_PLUGIN__ = t, n(e.default);
        }).call(this, t("543d")["createPage"]);
    },
    "6aaf": function(n, e, t) {
        "use strict";
        (function(n) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var o = u(t("a34a")), r = t("26cb"), c = t("a669"), i = u(t("e1c0"));
            function u(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }
            function s(n, e) {
                var t = Object.keys(n);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(n);
                    e && (o = o.filter(function(e) {
                        return Object.getOwnPropertyDescriptor(n, e).enumerable;
                    })), t.push.apply(t, o);
                }
                return t;
            }
            function a(n) {
                for (var e = 1; e < arguments.length; e++) {
                    var t = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? s(Object(t), !0).forEach(function(e) {
                        l(n, e, t[e]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(n, Object.getOwnPropertyDescriptors(t)) : s(Object(t)).forEach(function(e) {
                        Object.defineProperty(n, e, Object.getOwnPropertyDescriptor(t, e));
                    });
                }
                return n;
            }
            function l(n, e, t) {
                return e in n ? Object.defineProperty(n, e, {
                    value: t,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : n[e] = t, n;
            }
            function d(n, e, t, o, r, c, i) {
                try {
                    var u = n[c](i), s = u.value;
                } catch (a) {
                    return void t(a);
                }
                u.done ? e(s) : Promise.resolve(s).then(o, r);
            }
            function f(n) {
                return function() {
                    var e = this, t = arguments;
                    return new Promise(function(o, r) {
                        var c = n.apply(e, t);
                        function i(n) {
                            d(c, o, r, i, u, "next", n);
                        }
                        function u(n) {
                            d(c, o, r, i, u, "throw", n);
                        }
                        i(void 0);
                    });
                };
            }
            var h = function() {
                t.e("components/drag/voucher").then(function() {
                    return resolve(t("1b6e"));
                }.bind(null, t)).catch(t.oe);
            }, m = function() {
                t.e("components/drag/integral").then(function() {
                    return resolve(t("0373"));
                }.bind(null, t)).catch(t.oe);
            }, p = function() {
                t.e("components/drag/collect").then(function() {
                    return resolve(t("ed8c"));
                }.bind(null, t)).catch(t.oe);
            }, g = function() {
                t.e("components/drag/stores").then(function() {
                    return resolve(t("37e8"));
                }.bind(null, t)).catch(t.oe);
            }, b = function() {
                t.e("components/drag/contact").then(function() {
                    return resolve(t("7fa2"));
                }.bind(null, t)).catch(t.oe);
            }, v = function() {
                t.e("components/drag/member").then(function() {
                    return resolve(t("e195"));
                }.bind(null, t)).catch(t.oe);
            }, x = function() {
                t.e("components/drag/gather").then(function() {
                    return resolve(t("c99d"));
                }.bind(null, t)).catch(t.oe);
            }, w = function() {
                t.e("components/drag/coupon").then(function() {
                    return resolve(t("e1fb"));
                }.bind(null, t)).catch(t.oe);
            }, y = function() {
                t.e("components/drag/search").then(function() {
                    return resolve(t("cbe0"));
                }.bind(null, t)).catch(t.oe);
            }, I = function() {
                Promise.all([ t.e("common/vendor"), t.e("components/drag/fixed") ]).then(function() {
                    return resolve(t("6af3"));
                }.bind(null, t)).catch(t.oe);
            }, P = function() {
                Promise.all([ t.e("common/vendor"), t.e("components/drag/notice") ]).then(function() {
                    return resolve(t("90d5"));
                }.bind(null, t)).catch(t.oe);
            }, S = function() {
                Promise.all([ t.e("common/vendor"), t.e("components/drag/picLunbo") ]).then(function() {
                    return resolve(t("56fa"));
                }.bind(null, t)).catch(t.oe);
            }, k = function() {
                Promise.all([ t.e("common/vendor"), t.e("components/drag/btn") ]).then(function() {
                    return resolve(t("7d20"));
                }.bind(null, t)).catch(t.oe);
            }, O = function() {
                t.e("components/drag/pictures").then(function() {
                    return resolve(t("464c"));
                }.bind(null, t)).catch(t.oe);
            }, _ = function() {
                t.e("components/drag/titles").then(function() {
                    return resolve(t("07c5"));
                }.bind(null, t)).catch(t.oe);
            }, j = function() {
                Promise.all([ t.e("common/vendor"), t.e("components/drag/blank") ]).then(function() {
                    return resolve(t("860c"));
                }.bind(null, t)).catch(t.oe);
            }, z = function() {
                t.e("components/drag/lines").then(function() {
                    return resolve(t("9b4b"));
                }.bind(null, t)).catch(t.oe);
            }, T = function() {
                t.e("components/drag/storeMessage").then(function() {
                    return resolve(t("2bc5"));
                }.bind(null, t)).catch(t.oe);
            }, q = function() {
                Promise.all([ t.e("common/vendor"), t.e("components/common/functionCmp/rich-text") ]).then(function() {
                    return resolve(t("ba4f"));
                }.bind(null, t)).catch(t.oe);
            }, L = function() {
                t.e("components/drag/card").then(function() {
                    return resolve(t("273c"));
                }.bind(null, t)).catch(t.oe);
            }, C = function() {
                Promise.all([ t.e("common/vendor"), t.e("components/drag/hot") ]).then(function() {
                    return resolve(t("0f1c"));
                }.bind(null, t)).catch(t.oe);
            }, M = function() {
                t.e("components/drag/margic").then(function() {
                    return resolve(t("0082"));
                }.bind(null, t)).catch(t.oe);
            }, B = function() {
                Promise.all([ t.e("common/vendor"), t.e("components/drag/listNav") ]).then(function() {
                    return resolve(t("b005"));
                }.bind(null, t)).catch(t.oe);
            }, D = function() {
                t.e("components/drag/discount").then(function() {
                    return resolve(t("122b"));
                }.bind(null, t)).catch(t.oe);
            }, A = function() {
                t.e("components/drag/product").then(function() {
                    return resolve(t("4cf0"));
                }.bind(null, t)).catch(t.oe);
            }, N = function() {
                t.e("components/drag/ecshopProduct").then(function() {
                    return resolve(t("01d7"));
                }.bind(null, t)).catch(t.oe);
            }, U = function() {
                t.e("components/drag/susBtn").then(function() {
                    return resolve(t("37d3"));
                }.bind(null, t)).catch(t.oe);
            }, E = function() {
                t.e("components/drag/attenTion").then(function() {
                    return resolve(t("cd9b"));
                }.bind(null, t)).catch(t.oe);
            }, R = function() {
                t.e("components/drag/remind").then(function() {
                    return resolve(t("21ef"));
                }.bind(null, t)).catch(t.oe);
            }, $ = function() {
                Promise.all([ t.e("common/vendor"), t.e("components/drag/open") ]).then(function() {
                    return resolve(t("6ee0"));
                }.bind(null, t)).catch(t.oe);
            }, G = function() {
                t.e("components/third/uni-nav-bar").then(function() {
                    return resolve(t("46cf"));
                }.bind(null, t)).catch(t.oe);
            }, J = function() {
                t.e("components/common/load").then(function() {
                    return resolve(t("bdf2"));
                }.bind(null, t)).catch(t.oe);
            }, V = function() {
                t.e("components/template/tcyhq").then(function() {
                    return resolve(t("65eb"));
                }.bind(null, t)).catch(t.oe);
            }, X = function() {
                Promise.all([ t.e("common/vendor"), t.e("components/drag/zx-list") ]).then(function() {
                    return resolve(t("bd71"));
                }.bind(null, t)).catch(t.oe);
            }, Y = function() {
                t.e("components/common/footc").then(function() {
                    return resolve(t("4cad"));
                }.bind(null, t)).catch(t.oe);
            }, F = function() {
                t.e("components/drag/myBalance").then(function() {
                    return resolve(t("1da2"));
                }.bind(null, t)).catch(t.oe);
            }, W = function() {
                t.e("components/drag/store-evaluate").then(function() {
                    return resolve(t("766d"));
                }.bind(null, t)).catch(t.oe);
            }, H = function() {
                t.e("components/drag/store-couponbag").then(function() {
                    return resolve(t("eec4"));
                }.bind(null, t)).catch(t.oe);
            }, K = function() {
                t.e("components/drag/store-information").then(function() {
                    return resolve(t("5e63b"));
                }.bind(null, t)).catch(t.oe);
            }, Q = function() {
                t.e("components/drag/custom-video").then(function() {
                    return resolve(t("a768"));
                }.bind(null, t)).catch(t.oe);
            }, Z = function() {
                Promise.all([ t.e("common/vendor"), t.e("components/drag/attAccount") ]).then(function() {
                    return resolve(t("1b26"));
                }.bind(null, t)).catch(t.oe);
            }, nn = function() {
                t.e("yb_wm/index/components/yszc").then(function() {
                    return resolve(t("dc36"));
                }.bind(null, t)).catch(t.oe);
            }, en = function() {
                Promise.all([ t.e("common/vendor"), t.e("components/drag/vipModule") ]).then(function() {
                    return resolve(t("a41d"));
                }.bind(null, t)).catch(t.oe);
            }, tn = function() {
                t.e("components/drag/xiao-video").then(function() {
                    return resolve(t("54a8"));
                }.bind(null, t)).catch(t.oe);
            }, on = {
                name: "index",
                data: function() {
                    return {
                        showloading: !0,
                        shopinfo: {},
                        opcity: 0,
                        xkzxshow: !1,
                        xkzxInfo: "",
                        fqbshow: !1,
                        fqbInfo: "",
                        fwxyshow: !1
                    };
                },
                components: {
                    voucher: h,
                    integral: m,
                    collect: p,
                    stores: g,
                    contact: b,
                    member: v,
                    gather: x,
                    coupon: w,
                    searchBox: y,
                    fixedSet: I,
                    noticeSue: P,
                    picLunboBy: S,
                    btnGroup: k,
                    pictures: O,
                    titlesBar: _,
                    blank: j,
                    linesWire: z,
                    storeMessage: T,
                    bookText: q,
                    cardTab: L,
                    hotSpots: C,
                    margicCube: M,
                    listNav: B,
                    discountCoupons: D,
                    productGroup: A,
                    ecshopProduct: N,
                    susBtn: U,
                    attenTion: E,
                    orderPrompt: R,
                    openList: $,
                    uniNavBar: G,
                    load: J,
                    tcyhq: V,
                    zxList: X,
                    footc: Y,
                    myBalance: F,
                    storeEvaluate: W,
                    storeCouponbag: H,
                    storeInformation: K,
                    customVideo: Q,
                    attAccount: Z,
                    yszc: nn,
                    vipModule: en,
                    xiaoVideo: tn
                },
                onLoad: function(e) {
                    this.query = e, e && e.scene ? (this.storeId = "", this.ldxId = decodeURIComponent(e.scene).split(",")[0], 
                    this.ldxType = decodeURIComponent(e.scene).split(",")[1]) : this.storeId = i.default.getOptions(e, {
                        key: "storeId",
                        q1: this.storeInfo.id
                    }) || "", console.log("this.storeId", this.storeId, e.scene), this.xlsx(e), console.log("onLoad", e), 
                    n.getStorageSync("isYszc") || (this.fwxyshow = !0), console.log("yszz", n.getStorageSync("isYszc"));
                },
                onShow: function() {
                    var n = this;
                    return f(o.default.mark(function e() {
                        return o.default.wrap(function(e) {
                            while (1) switch (e.prev = e.next) {
                              case 0:
                                n.shopinfo.id && n.storeId != n.storeInfo.id && n.changeStore(n.storeInfo);

                              case 1:
                              case "end":
                                return e.stop();
                            }
                        }, e);
                    }))();
                },
                computed: a(a({}, (0, r.mapState)("dndc", [ "latLng" ])), (0, r.mapState)({
                    layout: function(n) {
                        return n.layout.index.body || {};
                    },
                    storeInfo: function(n) {
                        return n.config.storeInfo;
                    },
                    system: function(n) {
                        return n.system;
                    }
                })),
                methods: a(a({}, (0, r.mapActions)([ "getConfig", "getSjwifi" ])), {}, {
                    xlsx: function(n) {
                        var e = this;
                        return f(o.default.mark(function n() {
                            var t, r, i, u, s;
                            return o.default.wrap(function(n) {
                                while (1) switch (n.prev = n.next) {
                                  case 0:
                                    return n.next = 2, e.getLoginInfo({
                                        inviteId: e.query.userId || e.ldxId,
                                        type: e.ldxType
                                    });

                                  case 2:
                                    return u = n.sent, n.next = 5, e.getLayout({
                                        page: "index",
                                        id: "1",
                                        show: !0
                                    });

                                  case 5:
                                    return n.next = 7, e.getSystem();

                                  case 7:
                                    if (console.log(u), u && (console.log(u), e.getXkzx()), (null === (t = e.layout.pageSetting[0]) || void 0 === t || null === (r = t.styles) || void 0 === r || null === (i = r.newPage) || void 0 === i ? void 0 : i.url) ? setTimeout(function() {
                                        e.showloading = !1;
                                    }, 500) : e.showloading = !1, s = {
                                        latitude: "39.906930",
                                        longitude: "116.397570"
                                    }, "1" != e.system.is_gps) {
                                        n.next = 18;
                                        break;
                                    }
                                    return console.log("open——gps"), n.next = 15, (0, c.getDw)({
                                        t: 0
                                    });

                                  case 15:
                                    s = n.sent, n.next = 20;
                                    break;

                                  case 18:
                                    e.$store.commit("dndc/setLatLng", {
                                        lat: s.latitude,
                                        lng: s.longitude
                                    }), getApp().globalData.gdlocation = s;

                                  case 20:
                                    e.getAddInfo(s), e.refreshInfo();

                                  case 22:
                                  case "end":
                                    return n.stop();
                                }
                            }, n);
                        }))();
                    },
                    changeStore: function(n) {
                        this.storeId = n.id, this.refreshInfo();
                    },
                    refreshInfo: function() {
                        var n = this;
                        return f(o.default.mark(function e() {
                            var t, r;
                            return o.default.wrap(function(e) {
                                while (1) switch (e.prev = e.next) {
                                  case 0:
                                    return e.next = 2, n.util.request({
                                        url: n.api.zjdp,
                                        data: {
                                            storeId: n.storeId,
                                            lat: n.latLng.lat,
                                            lng: n.latLng.lng
                                        }
                                    });

                                  case 2:
                                    t = e.sent, r = t.data, n.storeId = r.id, n.getConfig({
                                        key: "storeInfo",
                                        data: {
                                            id: r.id,
                                            name: r.name,
                                            distance: r.distance
                                        }
                                    }), n.getSjwifi({
                                        storeId: r.id,
                                        ident: "wifi"
                                    }), n.shopinfo = r, n.$store.commit("setShopInfo", n.shopinfo), n.getSystem(), setTimeout(function() {
                                        n.addFwjl({
                                            storeId: n.storeId,
                                            origin: "1"
                                        });
                                    }, 1e3);

                                  case 11:
                                  case "end":
                                    return e.stop();
                                }
                            }, e);
                        }))();
                    },
                    getXkzx: function() {
                        var n = this;
                        return f(o.default.mark(function e() {
                            var t;
                            return o.default.wrap(function(e) {
                                while (1) switch (e.prev = e.next) {
                                  case 0:
                                    return e.next = 2, Promise.all([ n.util.request({
                                        url: n.api.xkzx,
                                        method: "POST"
                                    }), n.util.request({
                                        url: n.api.sytchj
                                    }) ]);

                                  case 2:
                                    t = e.sent, "array" != i.default.getType(t[0].data) && (n.xkzxInfo = t[0].data, 
                                    setTimeout(function() {
                                        n.xkzxshow = !0;
                                    }, 400)), t[1].data.issueCoupons.couponArr && (n.fqbInfo = t[1].data.issueCoupons, 
                                    setTimeout(function() {
                                        n.fqbshow = !0;
                                    }, 400));

                                  case 5:
                                  case "end":
                                    return e.stop();
                                }
                            }, e);
                        }))();
                    }
                }),
                onPullDownRefresh: function() {
                    var e = this;
                    return f(o.default.mark(function t() {
                        return o.default.wrap(function(t) {
                            while (1) switch (t.prev = t.next) {
                              case 0:
                                return e.showloading = !0, n.setStorageSync("firstdwtime", 0), e.getSystem({
                                    get: 1
                                }), e.$store.state.layout.index = {}, t.next = 6, e.xlsx();

                              case 6:
                                n.stopPullDownRefresh();

                              case 7:
                              case "end":
                                return t.stop();
                            }
                        }, t);
                    }))();
                },
                onShareAppMessage: function() {
                    return this.util.mpShare({
                        t: this.system.forwardTitle,
                        i: this.getImgS(this.system.forwardIcon)
                    });
                },
                onShareTimeline: function(n) {
                    return {
                        title: this.system.shareTitle,
                        imageUrl: this.getImgS(this.system.shareIcon)
                    };
                }
            };
            e.default = on;
        }).call(this, t("543d")["default"]);
    },
    c058: function(n, e, t) {
        "use strict";
        t.r(e);
        var o = t("6aaf"), r = t.n(o);
        for (var c in o) "default" !== c && function(n) {
            t.d(e, n, function() {
                return o[n];
            });
        }(c);
        e["default"] = r.a;
    },
    d343: function(n, e, t) {
        "use strict";
        t.r(e);
        var o = t("f960"), r = t("c058");
        for (var c in r) "default" !== c && function(n) {
            t.d(e, n, function() {
                return r[n];
            });
        }(c);
        var i, u = t("f0c5"), s = Object(u["a"])(r["default"], o["b"], o["c"], !1, null, "dea6f710", null, !1, o["a"], i);
        e["default"] = s.exports;
    },
    f960: function(n, e, t) {
        "use strict";
        var o;
        t.d(e, "b", function() {
            return r;
        }), t.d(e, "c", function() {
            return c;
        }), t.d(e, "a", function() {
            return o;
        });
        var r = function() {
            var n = this, e = n.$createElement;
            n._self._c;
            n._isMounted || (n.e0 = function(e) {
                n.xkzxshow = !1;
            }, n.e1 = function(e) {
                n.fqbshow = !1;
            }, n.e2 = function(e) {
                n.fwxyshow = !1;
            });
        }, c = [];
    }
}, [ [ "5fdd", "common/runtime", "common/vendor" ] ] ]);