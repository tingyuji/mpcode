(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "common/main" ], {
    "701d": function(e, t, n) {},
    "7e66": function(e, t, n) {
        "use strict";
        n.r(t);
        var o = n("9056"), r = n.n(o);
        for (var a in o) "default" !== a && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(a);
        t["default"] = r.a;
    },
    9056: function(e, t, n) {
        "use strict";
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var o = a(n("a34a")), r = a(n("88a3"));
            a(n("e1c0"));
            function a(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            function c(e, t, n, o, r, a, c) {
                try {
                    var u = e[a](c), i = u.value;
                } catch (f) {
                    return void n(f);
                }
                u.done ? t(i) : Promise.resolve(i).then(o, r);
            }
            function u(e) {
                return function() {
                    var t = this, n = arguments;
                    return new Promise(function(o, r) {
                        var a = e.apply(t, n);
                        function u(e) {
                            c(a, o, r, u, i, "next", e);
                        }
                        function i(e) {
                            c(a, o, r, u, i, "throw", e);
                        }
                        u(void 0);
                    });
                };
            }
            var i = {
                globalData: {
                    siteInfo: r.default,
                    onImgurl: "https://cypt.1903it.com/miniapp/",
                    session_key: ""
                },
                onLaunch: function(e) {
                    console.log("初始化"), this.autoUpdate();
                },
                methods: {
                    newNextTo: function(e) {
                        return this.goUrl(e), !0;
                    },
                    autoUpdate: function() {
                        var t = this, n = e.getUpdateManager();
                        n.onCheckForUpdate(function(o) {
                            o.hasUpdate && e.showModal({
                                title: "更新提示",
                                confirmText: "确定更新",
                                showCancel: !1,
                                content: "新版本已经准备好，是否重启应用？",
                                success: function(o) {
                                    o.confirm ? t.downLoadAndUpdate(n) : e.showModal({
                                        title: "温馨提示~",
                                        content: "本次版本更新涉及到新的功能添加，旧版本无法正常访问的哦~",
                                        showCancel: !1,
                                        confirmText: "确定更新",
                                        success: function(e) {
                                            e.confirm && t.downLoadAndUpdate(n);
                                        }
                                    });
                                }
                            });
                        });
                    },
                    downLoadAndUpdate: function(t) {
                        e.showLoading(), t.onUpdateReady(function() {
                            e.hideLoading(), t.applyUpdate();
                        }), t.onUpdateFailed(function() {
                            e.hideLoading(), e.showModal({
                                title: "已经有新版本了哟~",
                                content: "新版本已经上线啦~，请您删除当前小程序，重新搜索打开哟~"
                            });
                        });
                    }
                },
                onShow: function() {
                    var e = u(o.default.mark(function e(t) {
                        var n;
                        return o.default.wrap(function(e) {
                            while (1) switch (e.prev = e.next) {
                              case 0:
                                return e.next = 2, this.getLoginInfo();

                              case 2:
                                if (e.sent, !t) {
                                    e.next = 11;
                                    break;
                                }
                                if (!t.hasOwnProperty("referrerInfo")) {
                                    e.next = 11;
                                    break;
                                }
                                if ("wxeb490c6f9b154ef9" != t.referrerInfo.appId) {
                                    e.next = 11;
                                    break;
                                }
                                if (!t.referrerInfo.extraData) {
                                    e.next = 11;
                                    break;
                                }
                                return e.next = 9, this.util.request({
                                    url: this.api.jhhyk,
                                    method: "POST",
                                    data: {
                                        activate_ticket: t.referrerInfo.extraData.activate_ticket,
                                        card_id: t.referrerInfo.extraData.card_id,
                                        code: t.referrerInfo.extraData.code,
                                        userId: this.$store.state.user.userId
                                    }
                                });

                              case 9:
                                n = e.sent, console.log("%c extraData ", "color: white; background-color: #34aaff", t.referrerInfo, n.data);

                              case 11:
                              case "end":
                                return e.stop();
                            }
                        }, e, this);
                    }));
                    function t(t) {
                        return e.apply(this, arguments);
                    }
                    return t;
                }(),
                onHide: function() {}
            };
            t.default = i;
        }).call(this, n("543d")["default"]);
    },
    a77a: function(e, t, n) {
        "use strict";
        n.r(t);
        var o = n("7e66");
        for (var r in o) "default" !== r && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(r);
        n("c4db");
        var a, c, u, i, f = n("f0c5"), l = Object(f["a"])(o["default"], a, c, !1, null, null, null, !1, u, i);
        t["default"] = l.exports;
    },
    c4db: function(e, t, n) {
        "use strict";
        var o = n("701d"), r = n.n(o);
        r.a;
    },
    e66a: function(e, t, n) {
        "use strict";
        (function(e) {
            n("35e6");
            var t = i(n("66fd")), o = i(n("a77a")), r = i(n("4454")), a = i(n("884e")), c = i(n("4db2")), u = i(n("3558"));
            function i(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            function f(e, t) {
                var n = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(e);
                    t && (o = o.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable;
                    })), n.push.apply(n, o);
                }
                return n;
            }
            function l(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? f(Object(n), !0).forEach(function(t) {
                        d(e, t, n[t]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : f(Object(n)).forEach(function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
                    });
                }
                return e;
            }
            function d(e, t, n) {
                return t in e ? Object.defineProperty(e, t, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = n, e;
            }
            wx.__webpack_require_UNI_MP_PLUGIN__ = n;
            var s = function() {
                n.e("components/common/tabbar").then(function() {
                    return resolve(n("6c27"));
                }.bind(null, n)).catch(n.oe);
            }, p = function() {
                n.e("components/common/mg-img").then(function() {
                    return resolve(n("5627"));
                }.bind(null, n)).catch(n.oe);
            }, h = function() {
                n.e("components/common/mg-cell").then(function() {
                    return resolve(n("c0b8"));
                }.bind(null, n)).catch(n.oe);
            }, m = function() {
                n.e("components/login/index").then(function() {
                    return resolve(n("c290"));
                }.bind(null, n)).catch(n.oe);
            };
            t.default.component("login-sw", m), t.default.prototype.util = a.default, t.default.prototype.api = c.default, 
            t.default.config.productionTip = !1, t.default.use(u.default), t.default.component("tab-bar", s), 
            t.default.component("mg-img", p), t.default.component("mg-cell", h), o.default.mpType = "app";
            var b = new t.default(l({
                store: r.default
            }, o.default));
            e(b).$mount();
        }).call(this, n("543d")["createApp"]);
    }
}, [ [ "e66a", "common/runtime", "common/vendor" ] ] ]);