(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "components/third/uni-notice-bar" ], {
    "1d0b": function(t, e, n) {},
    2816: function(t, e, n) {
        "use strict";
        n.r(e);
        var i = n("872e"), o = n("ff88");
        for (var a in o) "default" !== a && function(t) {
            n.d(e, t, function() {
                return o[t];
            });
        }(a);
        n("fa69");
        var c, r = n("f0c5"), u = Object(r["a"])(o["default"], i["b"], i["c"], !1, null, "4393dadf", null, !1, i["a"], c);
        e["default"] = u.exports;
    },
    "872e": function(t, e, n) {
        "use strict";
        var i;
        n.d(e, "b", function() {
            return o;
        }), n.d(e, "c", function() {
            return a;
        }), n.d(e, "a", function() {
            return i;
        });
        var o = function() {
            var t = this, e = t.$createElement;
            t._self._c;
        }, a = [];
    },
    ddab: function(t, e, n) {
        "use strict";
        (function(t) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var n = {
                name: "UniNoticeBar",
                components: {},
                props: {
                    text: {
                        type: String,
                        default: ""
                    },
                    moreText: {
                        type: String,
                        default: ""
                    },
                    backgroundColor: {
                        type: String,
                        default: "#fffbe8"
                    },
                    speed: {
                        type: Number,
                        default: 50
                    },
                    color: {
                        type: String,
                        default: "#de8c17"
                    },
                    fs: {
                        type: [ String, Number ],
                        default: "28"
                    },
                    moreColor: {
                        type: String,
                        default: "#999999"
                    },
                    single: {
                        type: [ Boolean, String ],
                        default: !1
                    },
                    scrollable: {
                        type: [ Boolean, String ],
                        default: !1
                    },
                    showIcon: {
                        type: [ Boolean, String ],
                        default: !1
                    },
                    showGetMore: {
                        type: [ Boolean, String ],
                        default: !1
                    },
                    showClose: {
                        type: [ Boolean, String ],
                        default: !1
                    }
                },
                data: function() {
                    var t = "Uni_".concat(Math.ceil(1e6 * Math.random()).toString(36)), e = "Uni_".concat(Math.ceil(1e6 * Math.random()).toString(36));
                    return {
                        textWidth: 0,
                        boxWidth: 0,
                        wrapWidth: "",
                        webviewHide: !1,
                        elId: t,
                        elIdBox: e,
                        show: !0,
                        animationDuration: "none",
                        animationPlayState: "paused",
                        animationDelay: "0s"
                    };
                },
                mounted: function() {
                    var t = this;
                    this.$nextTick(function() {
                        t.initSize();
                    });
                },
                methods: {
                    initSize: function() {
                        var e = this;
                        if (this.scrollable) {
                            var n = [], i = new Promise(function(n, i) {
                                t.createSelectorQuery().in(e).select("#".concat(e.elId)).boundingClientRect().exec(function(t) {
                                    e.textWidth = t[0].width, n();
                                });
                            }), o = new Promise(function(n, i) {
                                t.createSelectorQuery().in(e).select("#".concat(e.elIdBox)).boundingClientRect().exec(function(t) {
                                    e.boxWidth = t[0].width, n();
                                });
                            });
                            n.push(i), n.push(o), Promise.all(n).then(function() {
                                e.animationDuration = "".concat(e.textWidth / e.speed, "s"), e.animationDelay = "-".concat(e.boxWidth / e.speed, "s"), 
                                setTimeout(function() {
                                    e.animationPlayState = "running";
                                }, 1e3);
                            });
                        }
                    },
                    loopAnimation: function() {},
                    clickMore: function() {
                        this.$emit("getmore");
                    },
                    close: function() {
                        this.show = !1, this.$emit("close");
                    },
                    onClick: function() {
                        this.$emit("click");
                    }
                }
            };
            e.default = n;
        }).call(this, n("543d")["default"]);
    },
    fa69: function(t, e, n) {
        "use strict";
        var i = n("1d0b"), o = n.n(i);
        o.a;
    },
    ff88: function(t, e, n) {
        "use strict";
        n.r(e);
        var i = n("ddab"), o = n.n(i);
        for (var a in i) "default" !== a && function(t) {
            n.d(e, t, function() {
                return i[t];
            });
        }(a);
        e["default"] = o.a;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "components/third/uni-notice-bar-create-component", {
    "components/third/uni-notice-bar-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("2816"));
    }
}, [ [ "components/third/uni-notice-bar-create-component" ] ] ]);