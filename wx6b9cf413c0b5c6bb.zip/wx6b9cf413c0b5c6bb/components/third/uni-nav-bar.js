(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "components/third/uni-nav-bar" ], {
    "31ee": function(t, e, n) {
        "use strict";
        var r = n("a4e6"), o = n.n(r);
        o.a;
    },
    4303: function(t, e, n) {
        "use strict";
        var r;
        n.d(e, "b", function() {
            return o;
        }), n.d(e, "c", function() {
            return u;
        }), n.d(e, "a", function() {
            return r;
        });
        var o = function() {
            var t = this, e = t.$createElement;
            t._self._c;
        }, u = [];
    },
    "46cf": function(t, e, n) {
        "use strict";
        n.r(e);
        var r = n("4303"), o = n("6809");
        for (var u in o) "default" !== u && function(t) {
            n.d(e, t, function() {
                return o[t];
            });
        }(u);
        n("31ee");
        var i, a = n("f0c5"), c = Object(a["a"])(o["default"], r["b"], r["c"], !1, null, "fcfcaef6", null, !1, r["a"], i);
        e["default"] = c.exports;
    },
    6809: function(t, e, n) {
        "use strict";
        n.r(e);
        var r = n("c174"), o = n.n(r);
        for (var u in r) "default" !== u && function(t) {
            n.d(e, t, function() {
                return r[t];
            });
        }(u);
        e["default"] = o.a;
    },
    a4e6: function(t, e, n) {},
    c174: function(t, e, n) {
        "use strict";
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var r = function() {
            n.e("components/third/uni-status-bar").then(function() {
                return resolve(n("7235"));
            }.bind(null, n)).catch(n.oe);
        }, o = function() {
            n.e("components/common/popup").then(function() {
                return resolve(n("b94e"));
            }.bind(null, n)).catch(n.oe);
        }, u = {
            name: "UniNavBar",
            components: {
                uniStatusBar: r,
                mgPopup: o
            },
            props: {
                urbd: {
                    type: Boolean,
                    default: !0
                },
                title: {
                    type: String,
                    default: ""
                },
                isleft: {
                    type: Boolean,
                    default: !0
                },
                isright: {
                    type: Boolean,
                    default: !1
                },
                leftcn: {
                    type: String,
                    default: "iconleft"
                },
                rightcn: {
                    type: String,
                    default: "iconshx"
                },
                rightText: {
                    type: String,
                    default: ""
                },
                leftIcon: {
                    type: String,
                    default: ""
                },
                rightIcon: {
                    type: String,
                    default: ""
                },
                fixed: {
                    type: [ Boolean, String ],
                    default: !1
                },
                color: {
                    type: String,
                    default: "#000000"
                },
                bg: {
                    type: String,
                    default: ""
                },
                statusBar: {
                    type: Boolean,
                    default: !1
                },
                shadow: {
                    type: Boolean,
                    default: !0
                },
                border: {
                    type: Boolean,
                    default: !0
                },
                size: {
                    type: String,
                    default: "42"
                },
                ispr: {
                    type: Boolean,
                    default: !0
                },
                uropcity: {
                    type: [ String, Number ],
                    default: "0"
                },
                uriconopcity: {
                    type: [ String, Number ],
                    default: "0.5"
                },
                leftArr: {
                    type: Array,
                    default: function() {
                        return [];
                    }
                },
                customback: {
                    type: Boolean,
                    default: !1
                },
                custommore: {
                    type: Boolean,
                    default: !1
                }
            },
            data: function() {
                return {
                    showMore: !1
                };
            },
            computed: {
                gnarr: function() {
                    return this.leftArr.length ? this.leftArr : [ {
                        icon: "zy",
                        name: "首页",
                        url: "/yb_wm/index/index"
                    }, {
                        icon: "dd",
                        name: "订单",
                        url: "/yb_wm/index/order-index"
                    }, {
                        icon: "wd",
                        name: "我的",
                        url: "/yb_wm/index/my-index"
                    } ];
                }
            },
            methods: {
                back: function() {
                    this.customback ? this.$emit("on-back") : this.go({
                        t: 1 == getCurrentPages().length ? 6 : 4,
                        url: "/yb_wm/index/index"
                    });
                },
                more: function() {
                    this.custommore ? this.$emit("on-more") : this.showMore = !0;
                },
                gogn: function(t) {
                    this.go({
                        t: 6,
                        url: this.gnarr[t].url
                    });
                }
            }
        };
        e.default = u;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "components/third/uni-nav-bar-create-component", {
    "components/third/uni-nav-bar-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("46cf"));
    }
}, [ [ "components/third/uni-nav-bar-create-component" ] ] ]);