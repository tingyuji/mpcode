(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "components/third/ls-swiper/value-card-swiper" ], {
    "0038": function(t, e, u) {},
    "135c": function(t, e, u) {
        "use strict";
        u.r(e);
        var n = u("50a3"), r = u.n(n);
        for (var a in n) "default" !== a && function(t) {
            u.d(e, t, function() {
                return n[t];
            });
        }(a);
        e["default"] = r.a;
    },
    2031: function(t, e, u) {
        "use strict";
        u.r(e);
        var n = u("6fbe"), r = u("135c");
        for (var a in r) "default" !== a && function(t) {
            u.d(e, t, function() {
                return r[t];
            });
        }(a);
        u("d130");
        var o, i = u("f0c5"), l = Object(i["a"])(r["default"], n["b"], n["c"], !1, null, "f7ae81b0", null, !1, n["a"], o);
        e["default"] = l.exports;
    },
    "50a3": function(t, e, u) {
        "use strict";
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var n = {
            props: {
                list: {
                    type: Array,
                    default: function() {
                        return [];
                    }
                },
                imgKey: {
                    type: String,
                    required: !0
                },
                height: {
                    type: Number,
                    default: 200
                },
                imgRadius: {
                    type: Number,
                    default: 0
                },
                imgShadow: {
                    type: Boolean,
                    default: !1
                },
                previousMargin: {
                    type: Number,
                    default: 0
                },
                nextMargin: {
                    type: Number,
                    default: 0
                },
                imgWidth: {
                    type: String,
                    default: "100%"
                },
                loop: {
                    type: Boolean,
                    default: !1
                },
                autoplay: {
                    type: Boolean,
                    default: !1
                },
                interval: {
                    type: Number,
                    default: 2e3
                },
                duration: {
                    type: Number,
                    default: 600
                },
                dots: {
                    type: Boolean,
                    default: !1
                },
                bottom: {
                    type: Number,
                    default: 10
                },
                crown: {
                    type: Boolean,
                    default: !1
                },
                slots: {
                    type: Boolean,
                    default: !1
                },
                swcurrent: {
                    type: Number,
                    default: 0
                }
            },
            data: function() {
                return {
                    current: 0
                };
            },
            watch: {
                swcurrent: function(t) {
                    this.current = t;
                }
            },
            methods: {
                change: function(t) {
                    var e = t.detail.current;
                    this.current = e, this.$emit("change", this.list[e]);
                }
            }
        };
        e.default = n;
    },
    "6fbe": function(t, e, u) {
        "use strict";
        var n;
        u.d(e, "b", function() {
            return r;
        }), u.d(e, "c", function() {
            return a;
        }), u.d(e, "a", function() {
            return n;
        });
        var r = function() {
            var t = this, e = t.$createElement;
            t._self._c;
        }, a = [];
    },
    d130: function(t, e, u) {
        "use strict";
        var n = u("0038"), r = u.n(n);
        r.a;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "components/third/ls-swiper/value-card-swiper-create-component", {
    "components/third/ls-swiper/value-card-swiper-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("2031"));
    }
}, [ [ "components/third/ls-swiper/value-card-swiper-create-component" ] ] ]);