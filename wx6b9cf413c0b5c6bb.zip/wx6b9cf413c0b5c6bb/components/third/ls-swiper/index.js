(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "components/third/ls-swiper/index" ], {
    "11ac": function(t, e, n) {},
    "2b38": function(t, e, n) {
        "use strict";
        var u = n("11ac"), r = n.n(u);
        r.a;
    },
    "672a": function(t, e, n) {
        "use strict";
        var u;
        n.d(e, "b", function() {
            return r;
        }), n.d(e, "c", function() {
            return a;
        }), n.d(e, "a", function() {
            return u;
        });
        var r = function() {
            var t = this, e = t.$createElement;
            t._self._c;
        }, a = [];
    },
    "73bf": function(t, e, n) {
        "use strict";
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var u = {
            props: {
                list: {
                    type: Array,
                    default: function() {
                        return [];
                    }
                },
                imgKey: {
                    type: String,
                    required: !0
                },
                height: {
                    type: Number,
                    default: 200
                },
                imgRadius: {
                    type: Number,
                    default: 0
                },
                imgShadow: {
                    type: Boolean,
                    default: !1
                },
                previousMargin: {
                    type: Number,
                    default: 0
                },
                nextMargin: {
                    type: Number,
                    default: 0
                },
                imgWidth: {
                    type: String,
                    default: "100%"
                },
                loop: {
                    type: Boolean,
                    default: !1
                },
                autoplay: {
                    type: Boolean,
                    default: !1
                },
                interval: {
                    type: Number,
                    default: 2e3
                },
                duration: {
                    type: Number,
                    default: 600
                },
                dots: {
                    type: Boolean,
                    default: !1
                },
                bottom: {
                    type: Number,
                    default: 10
                },
                crown: {
                    type: Boolean,
                    default: !1
                },
                slots: {
                    type: Boolean,
                    default: !1
                },
                swcurrent: {
                    type: Number,
                    default: 0
                }
            },
            data: function() {
                return {
                    current: 0
                };
            },
            watch: {
                swcurrent: function(t) {
                    this.current = t;
                }
            },
            methods: {
                change: function(t) {
                    var e = t.detail.current;
                    this.current = e, this.$emit("change", this.list[e]);
                }
            }
        };
        e.default = u;
    },
    "8cd2": function(t, e, n) {
        "use strict";
        n.r(e);
        var u = n("73bf"), r = n.n(u);
        for (var a in u) "default" !== a && function(t) {
            n.d(e, t, function() {
                return u[t];
            });
        }(a);
        e["default"] = r.a;
    },
    b2f8: function(t, e, n) {
        "use strict";
        n.r(e);
        var u = n("672a"), r = n("8cd2");
        for (var a in r) "default" !== a && function(t) {
            n.d(e, t, function() {
                return r[t];
            });
        }(a);
        n("2b38");
        var o, i = n("f0c5"), f = Object(i["a"])(r["default"], u["b"], u["c"], !1, null, "db746e54", null, !1, u["a"], o);
        e["default"] = f.exports;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "components/third/ls-swiper/index-create-component", {
    "components/third/ls-swiper/index-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("b2f8"));
    }
}, [ [ "components/third/ls-swiper/index-create-component" ] ] ]);