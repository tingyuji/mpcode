(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "components/common/mg-img" ], {
    "0f86": function(t, n, e) {
        "use strict";
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), n.default = void 0;
        var a = {
            name: "mg-img",
            props: {
                cname: "",
                sname: "",
                src: "",
                local: "",
                m: {
                    type: String,
                    default: "aspectFill"
                }
            },
            data: function() {
                return {};
            },
            methods: {
                getUrl: function(t) {
                    return t && "string" == typeof t ? t.indexOf("http") > -1 || t.indexOf("/static/") > -1 || t.indexOf("base64") > -1 || 1 == this.local ? t : this.url + t : "/static/no.png";
                }
            },
            computed: {}
        };
        n.default = a;
    },
    "4a12": function(t, n, e) {
        "use strict";
        e.r(n);
        var a = e("0f86"), r = e.n(a);
        for (var c in a) "default" !== c && function(t) {
            e.d(n, t, function() {
                return a[t];
            });
        }(c);
        n["default"] = r.a;
    },
    5627: function(t, n, e) {
        "use strict";
        e.r(n);
        var a = e("9a72"), r = e("4a12");
        for (var c in r) "default" !== c && function(t) {
            e.d(n, t, function() {
                return r[t];
            });
        }(c);
        e("5c10");
        var u, i = e("f0c5"), o = Object(i["a"])(r["default"], a["b"], a["c"], !1, null, "89901c9a", null, !1, a["a"], u);
        n["default"] = o.exports;
    },
    "5c10": function(t, n, e) {
        "use strict";
        var a = e("808a"), r = e.n(a);
        r.a;
    },
    "808a": function(t, n, e) {},
    "9a72": function(t, n, e) {
        "use strict";
        var a;
        e.d(n, "b", function() {
            return r;
        }), e.d(n, "c", function() {
            return c;
        }), e.d(n, "a", function() {
            return a;
        });
        var r = function() {
            var t = this, n = t.$createElement, e = (t._self._c, t.__get_style([ t.sname ])), a = t.getUrl(t.src);
            t.$mp.data = Object.assign({}, {
                $root: {
                    s0: e,
                    m0: a
                }
            });
        }, c = [];
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "components/common/mg-img-create-component", {
    "components/common/mg-img-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("5627"));
    }
}, [ [ "components/common/mg-img-create-component" ] ] ]);