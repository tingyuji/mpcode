(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "components/common/tabbar" ], {
    "0ed0": function(e, o, t) {
        "use strict";
        var n;
        t.d(o, "b", function() {
            return i;
        }), t.d(o, "c", function() {
            return l;
        }), t.d(o, "a", function() {
            return n;
        });
        var i = function() {
            var e = this, o = e.$createElement;
            e._self._c;
        }, l = [];
    },
    "6c27": function(e, o, t) {
        "use strict";
        t.r(o);
        var n = t("0ed0"), i = t("7fa4");
        for (var l in i) "default" !== l && function(e) {
            t.d(o, e, function() {
                return i[e];
            });
        }(l);
        var r, a = t("f0c5"), c = Object(a["a"])(i["default"], n["b"], n["c"], !1, null, null, null, !1, n["a"], r);
        o["default"] = c.exports;
    },
    "7fa4": function(e, o, t) {
        "use strict";
        t.r(o);
        var n = t("c358"), i = t.n(n);
        for (var l in n) "default" !== l && function(e) {
            t.d(o, e, function() {
                return n[e];
            });
        }(l);
        o["default"] = i.a;
    },
    c358: function(e, o, t) {
        "use strict";
        (function(e) {
            Object.defineProperty(o, "__esModule", {
                value: !0
            }), o.default = void 0;
            var n = t("26cb"), i = l(t("e1c0"));
            function l(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            function r(e, o) {
                var t = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    o && (n = n.filter(function(o) {
                        return Object.getOwnPropertyDescriptor(e, o).enumerable;
                    })), t.push.apply(t, n);
                }
                return t;
            }
            function a(e) {
                for (var o = 1; o < arguments.length; o++) {
                    var t = null != arguments[o] ? arguments[o] : {};
                    o % 2 ? r(Object(t), !0).forEach(function(o) {
                        c(e, o, t[o]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : r(Object(t)).forEach(function(o) {
                        Object.defineProperty(e, o, Object.getOwnPropertyDescriptor(t, o));
                    });
                }
                return e;
            }
            function c(e, o, t) {
                return o in e ? Object.defineProperty(e, o, {
                    value: t,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[o] = t, e;
            }
            var u = {
                name: "tabbar",
                props: {
                    type: {
                        type: Object,
                        default: function() {
                            return {
                                message: "hello"
                            };
                        }
                    },
                    ptype: {
                        type: String,
                        default: "index"
                    },
                    color: {
                        type: String,
                        default: ""
                    }
                },
                data: function() {
                    return {};
                },
                computed: a(a({}, (0, n.mapState)({
                    layout: function(e) {
                        return e.layout.index.body && e.layout.index.body.menu;
                    },
                    cmlayout: function(e) {
                        return e.layout.custom.body && e.layout.custom.body.menu;
                    },
                    isshopdl: function(e) {
                        return e.config.isshopdl;
                    }
                })), {}, {
                    navbar: function() {
                        var e = this;
                        if ("index" != this.ptype || this.isshopdl) {
                            if ("custom" == this.ptype && this.cmlayout) {
                                var o = {
                                    colorBg: "#fff",
                                    border_color: "rgba(0,0,0,0.05)",
                                    color: "#333",
                                    colorOff: "#888",
                                    navs: [],
                                    marginBottom: "",
                                    marginLR: "",
                                    circle: "",
                                    outType: "1"
                                };
                                if (this.cmlayout[0] && this.cmlayout[0].styles.imgUrl.length) {
                                    var t, n, l, r, a = this.cmlayout[0].styles;
                                    o.colorBg = a.colorBg, o.border_color = a.colorLine, o.color = a.colorSelect, o.colorOff = a.colorUnselect, 
                                    o.marginBottom = null === a || void 0 === a ? void 0 : a.marginBottom, o.marginLR = null === a || void 0 === a ? void 0 : a.marginLR, 
                                    o.circle = null === a || void 0 === a ? void 0 : a.circle, o.outType = "2" == (null === a || void 0 === a ? void 0 : a.outType) ? "2" : "1", 
                                    o.boxShadow = {
                                        color: null === a || void 0 === a || null === (t = a.boxShadow) || void 0 === t ? void 0 : t.color,
                                        levelDisplacement: null === a || void 0 === a || null === (n = a.boxShadow) || void 0 === n ? void 0 : n.levelDisplacement,
                                        verticalDisplacement: null === a || void 0 === a || null === (l = a.boxShadow) || void 0 === l ? void 0 : l.verticalDisplacement,
                                        fuzzyRadius: null === a || void 0 === a || null === (r = a.boxShadow) || void 0 === r ? void 0 : r.fuzzyRadius
                                    };
                                    var c = i.default.deepCopy(a.imgUrl);
                                    for (var u in c) c[u].icon = {
                                        active: c[u].front[0].img,
                                        normal: c[u].back[0].img
                                    }, c[u].link = this.changeUrl(c[u].url), delete c[u].front, delete c[u].back, delete c[u].url;
                                    o.navs = c;
                                } else o.navs = [ {
                                    icon2: "iconjiayuan",
                                    text: "首页",
                                    link: "/yb_wm/index/index"
                                }, {
                                    icon2: "iconjiayuan",
                                    text: "订单",
                                    link: "/yb_wm/index/order-index"
                                }, {
                                    icon2: "iconjiayuan",
                                    text: "我的",
                                    link: "/yb_wm/index/my-index"
                                } ];
                                o.navs.forEach(function(e) {
                                    e.t = -1 != e.link.indexOf("/index/") ? 6 : 1;
                                });
                                var d = o.navs.findIndex(function(o) {
                                    return o.link == "/" + e.util.getRoute();
                                });
                                return d > -1 && (o.navs[d].active = !0, this.$emit("refresh", !0)), o;
                            }
                        } else {
                            if (getApp().globalData.tabbar) {
                                var f = i.default.deepCopy(getApp().globalData.tabbar), s = f.navs.findIndex(function(o) {
                                    return o.link == "/" + e.util.getRoute();
                                });
                                return s > -1 ? (f.navs[s].active = !0, this.$emit("refresh", !0)) : f = null, f;
                            }
                            if (this.layout) {
                                var v = {
                                    colorBg: "#fff",
                                    border_color: "rgba(0,0,0,0.05)",
                                    color: "#333",
                                    colorOff: "#888",
                                    navs: [],
                                    marginBottom: "",
                                    marginLR: "",
                                    circle: "",
                                    outType: "1"
                                };
                                if (this.layout[0] && this.layout[0].styles.imgUrl.length) {
                                    var b, y, m, p, g = this.layout[0].styles;
                                    v.colorBg = g.colorBg, v.border_color = g.colorLine, v.color = g.colorSelect, v.colorOff = g.colorUnselect, 
                                    v.marginBottom = null === g || void 0 === g ? void 0 : g.marginBottom, v.marginLR = null === g || void 0 === g ? void 0 : g.marginLR, 
                                    v.circle = null === g || void 0 === g ? void 0 : g.circle, v.outType = "2" == (null === g || void 0 === g ? void 0 : g.outType) ? "2" : "1", 
                                    v.boxShadow = {
                                        color: null === g || void 0 === g || null === (b = g.boxShadow) || void 0 === b ? void 0 : b.color,
                                        levelDisplacement: null === g || void 0 === g || null === (y = g.boxShadow) || void 0 === y ? void 0 : y.levelDisplacement,
                                        verticalDisplacement: null === g || void 0 === g || null === (m = g.boxShadow) || void 0 === m ? void 0 : m.verticalDisplacement,
                                        fuzzyRadius: null === g || void 0 === g || null === (p = g.boxShadow) || void 0 === p ? void 0 : p.fuzzyRadius
                                    };
                                    var h = JSON.parse(JSON.stringify(g.imgUrl));
                                    for (var x in h) h[x].icon = {
                                        active: h[x].front[0].img,
                                        normal: h[x].back[0].img
                                    }, h[x].link = this.changeUrl(h[x].url), delete h[x].front, delete h[x].back, delete h[x].url;
                                    v.navs = h;
                                } else v.navs = [ {
                                    icon2: "iconjiayuan",
                                    text: "首页",
                                    link: "/yb_wm/index/index"
                                }, {
                                    icon2: "iconjiayuan",
                                    text: "点单",
                                    link: "/yb_wm/index/goods"
                                }, {
                                    icon2: "iconjiayuan",
                                    text: "订单",
                                    link: "/yb_wm/index/order-index"
                                }, {
                                    icon2: "iconjiayuan",
                                    text: "我的",
                                    link: "/yb_wm/index/my-index"
                                } ];
                                v.navs.forEach(function(e) {
                                    e.t = -1 != e.link.indexOf("/index/") ? 6 : 1;
                                }), getApp().globalData.tabbar = i.default.deepCopy(v);
                                var O = v.navs.findIndex(function(o) {
                                    return o.link == "/" + e.util.getRoute();
                                });
                                return O > -1 ? (v.navs[O].active = !0, this.$emit("refresh", !0)) : v = null, v;
                            }
                        }
                    }
                }),
                methods: {
                    goPage: i.default.throttle(function(e) {
                        if (!e[0].active) {
                            var o = 6 == e[0].t ? 6 : this.pageroute.indexOf("/index/") > -1 ? 1 : 2;
                            this.go({
                                t: o,
                                url: e[0].link
                            });
                        }
                    }, 500)
                },
                created: function() {
                    this.pageroute = this.util.getRoute(), e.hideTabBar();
                }
            };
            o.default = u;
        }).call(this, t("543d")["default"]);
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "components/common/tabbar-create-component", {
    "components/common/tabbar-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("6c27"));
    }
}, [ [ "components/common/tabbar-create-component" ] ] ]);