(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "components/common/sq-btn" ], {
    "0265": function(e, t, n) {
        "use strict";
        var o = n("a5a4"), s = n.n(o);
        s.a;
    },
    "103d": function(e, t, n) {
        "use strict";
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            n("26cb");
            var o = function() {
                n.e("components/common/modal").then(function() {
                    return resolve(n("62f5"));
                }.bind(null, n)).catch(n.oe);
            }, s = {
                name: "sq-btn",
                components: {
                    mgModal: o
                },
                props: {
                    cname: "",
                    sname: "",
                    w: "",
                    h: "",
                    t: "",
                    type: {
                        type: String,
                        default: "1"
                    },
                    storeid: {
                        type: String,
                        default: ""
                    },
                    value: {
                        type: Boolean,
                        default: !1
                    }
                },
                data: function() {
                    return {
                        loading: !1
                    };
                },
                computed: {
                    ptname: function() {
                        var e = "";
                        switch (this.api.platform) {
                          case "mini":
                            e = "微信";
                            break;

                          case "ali":
                            e = "支付宝";
                            break;

                          case "baidu":
                            e = "百度";
                            break;

                          case "toutiao":
                            e = "字节跳动";
                            break;
                        }
                        return e;
                    },
                    show: {
                        get: function() {
                            return this.value;
                        },
                        set: function(e) {
                            this.$emit("input", e);
                        }
                    }
                },
                watch: {},
                methods: {
                    share: function() {
                        e.showModal({
                            title: "提示",
                            content: "点击右上角分享",
                            showCancel: !1,
                            confirmText: "我知道了"
                        });
                    },
                    onGetAuthorize: function(e) {
                        var t = this;
                        my.getOpenUserInfo({
                            fail: function(e) {},
                            success: function(e) {
                                var n = JSON.parse(e.response).response;
                                t.refreshUser({
                                    storeId: t.storeid,
                                    portrait: n.avatar,
                                    userName: n.nickName,
                                    userId: t.uId
                                }).then(function(e) {
                                    t.$emit("refresh");
                                });
                            }
                        });
                    },
                    getAlPhoneNumber: function() {
                        var e = this;
                        my.getPhoneNumber({
                            protocols: {
                                isvAppId: this.system.aliopenappid
                            },
                            success: function(t) {
                                var n = JSON.parse(t.response);
                                e.util.request({
                                    url: e.api.jm,
                                    method: "POST",
                                    data: {
                                        data: n.response
                                    }
                                }).then(function(t) {
                                    console.log("jm res", t), t.data && (e.show = !1, 4 == e.type ? e.util.message("绑定成功", 1, 1e3) : e.$emit("refresh", t.data), 
                                    e.refreshUser({
                                        nomask: 1,
                                        get: 1,
                                        now: 1
                                    }));
                                }), console.log("getAlPhoneNumber success", n);
                            },
                            fail: function(e) {
                                console.log("getAlPhoneNumber fail", e);
                            }
                        });
                    },
                    getUserInfo: function() {
                        var t = this;
                        e.getUserInfo({
                            success: function(e) {
                                t.refreshUser({
                                    storeId: t.storeid,
                                    portrait: portrait,
                                    userName: userName,
                                    userId: userId
                                }).then(function(e) {
                                    t.$emit("refresh");
                                }), console.log("getUserInfo success", e);
                            },
                            fail: function(t) {
                                console.log("getUserInfo fail", t), e.showModal({
                                    title: "温馨提示",
                                    content: "获取头像等信息失败",
                                    showCancel: !1
                                });
                            }
                        });
                    },
                    mpGetUserInfo: function(t) {
                        var n = this;
                        if (console.log("mpGetUserInfo", t), "getUserInfo:ok" == t.detail.errMsg) {
                            var o = t.detail.userInfo.avatarUrl, s = t.detail.userInfo.nickName, r = this.uId;
                            this.refreshUser({
                                storeId: this.storeid,
                                portrait: o,
                                userName: s,
                                userId: r
                            }).then(function(e) {
                                n.$emit("refresh");
                            }), console.log(o, s, r);
                        } else e.showModal({
                            title: "温馨提示",
                            content: "获取头像等信息失败",
                            showCancel: !1
                        });
                    },
                    mpGetphonenumber: function(t) {
                        var n = this;
                        if (this.loading = !0, console.log("mpGetphonenumber", t), "getPhoneNumber:ok" != t.detail.errMsg) return this.loading = !1, 
                        void e.showModal({
                            title: "温馨提示",
                            content: "授权手机号失败",
                            showCancel: !1
                        });
                        var o = getApp().globalData.session_key, s = t.detail.encryptedData, r = t.detail.iv, a = this.uId;
                        this.util.request({
                            url: this.api.jm,
                            method: "POST",
                            data: {
                                userId: a,
                                sessionKey: o,
                                data: s,
                                iv: r
                            }
                        }).then(function(e) {
                            n.loading = !1, e.data && (n.show = !1, 4 == n.type ? n.util.message("绑定成功", 1, 1e3) : n.$emit("refresh", e.data), 
                            n.refreshUser({
                                nomask: 1,
                                get: 1,
                                now: 1
                            })), console.log(e);
                        }).catch(function() {
                            n.loading = !1;
                        }), console.log(o, s, r);
                    }
                }
            };
            t.default = s;
        }).call(this, n("543d")["default"]);
    },
    "61a8": function(e, t, n) {
        "use strict";
        n.r(t);
        var o = n("103d"), s = n.n(o);
        for (var r in o) "default" !== r && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(r);
        t["default"] = s.a;
    },
    a5a4: function(e, t, n) {},
    cdf7: function(e, t, n) {
        "use strict";
        n.r(t);
        var o = n("fd2e"), s = n("61a8");
        for (var r in s) "default" !== r && function(e) {
            n.d(t, e, function() {
                return s[e];
            });
        }(r);
        n("0265");
        var a, i = n("f0c5"), u = Object(i["a"])(s["default"], o["b"], o["c"], !1, null, "69f0359e", null, !1, o["a"], a);
        t["default"] = u.exports;
    },
    fd2e: function(e, t, n) {
        "use strict";
        var o;
        n.d(t, "b", function() {
            return s;
        }), n.d(t, "c", function() {
            return r;
        }), n.d(t, "a", function() {
            return o;
        });
        var s = function() {
            var e = this, t = e.$createElement, n = (e._self._c, 1 == e.type ? e.__get_style([ {
                width: e.w + "rpx",
                height: e.h + "rpx",
                lineHeight: e.h + "rpx"
            }, e.sname ]) : null), o = 2 == e.type ? e.__get_style([ {
                width: e.w + "rpx",
                height: e.h + "rpx",
                lineHeight: e.h + "rpx"
            }, e.sname ]) : null, s = 3 == e.type ? e.__get_style([ {
                width: e.w + "rpx",
                height: e.h + "rpx",
                lineHeight: e.h + "rpx"
            }, e.sname ]) : null;
            e._isMounted || (e.e0 = function(e) {
                return this.$emit("refresh");
            }), e.$mp.data = Object.assign({}, {
                $root: {
                    s0: n,
                    s1: o,
                    s2: s
                }
            });
        }, r = [];
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "components/common/sq-btn-create-component", {
    "components/common/sq-btn-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("cdf7"));
    }
}, [ [ "components/common/sq-btn-create-component" ] ] ]);