(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "components/common/jzz" ], {
    "24ab": function(t, n, e) {
        "use strict";
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), n.default = void 0;
        var a = {
            name: "mg-img",
            props: {
                sname: Object,
                imgn: {
                    type: String,
                    default: "zwdd"
                },
                bgcolor: "",
                mygd: {
                    type: Boolean,
                    default: !1
                },
                tcolor: {
                    type: String,
                    default: ""
                },
                nodata: "",
                otext: {
                    type: String,
                    default: ""
                },
                ttext: {
                    type: String,
                    default: ""
                }
            },
            data: function() {
                return {};
            }
        };
        n.default = a;
    },
    "46e7": function(t, n, e) {},
    "4d49": function(t, n, e) {
        "use strict";
        e.r(n);
        var a = e("24ab"), u = e.n(a);
        for (var r in a) "default" !== r && function(t) {
            e.d(n, t, function() {
                return a[t];
            });
        }(r);
        n["default"] = u.a;
    },
    "70be": function(t, n, e) {
        "use strict";
        e.r(n);
        var a = e("f3c9"), u = e("4d49");
        for (var r in u) "default" !== r && function(t) {
            e.d(n, t, function() {
                return u[t];
            });
        }(r);
        e("d61b");
        var o, c = e("f0c5"), f = Object(c["a"])(u["default"], a["b"], a["c"], !1, null, "0111dadb", null, !1, a["a"], o);
        n["default"] = f.exports;
    },
    d61b: function(t, n, e) {
        "use strict";
        var a = e("46e7"), u = e.n(a);
        u.a;
    },
    f3c9: function(t, n, e) {
        "use strict";
        var a;
        e.d(n, "b", function() {
            return u;
        }), e.d(n, "c", function() {
            return r;
        }), e.d(n, "a", function() {
            return a;
        });
        var u = function() {
            var t = this, n = t.$createElement, e = (t._self._c, t.nodata ? t.__get_style([ t.sname ]) : null);
            t.$mp.data = Object.assign({}, {
                $root: {
                    s0: e
                }
            });
        }, r = [];
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "components/common/jzz-create-component", {
    "components/common/jzz-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("70be"));
    }
}, [ [ "components/common/jzz-create-component" ] ] ]);