(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "components/common/mg-coupon" ], {
    "1c5a": function(t, e, p) {
        "use strict";
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        p("26cb");
        var y = p("ddcf"), o = function() {
            Promise.all([ p.e("common/vendor"), p.e("components/common/functionCmp/rich-text") ]).then(function() {
                return resolve(p("ba4f"));
            }.bind(null, p)).catch(p.oe);
        }, n = {
            name: "searchBox",
            components: {
                mgRtext: o
            },
            props: {
                co: {
                    type: Object,
                    default: function() {
                        return {};
                    }
                },
                gttype: {
                    type: String,
                    default: ""
                },
                ptype: {
                    type: String,
                    default: "1"
                },
                ttype: {
                    type: String,
                    default: "1"
                },
                cname: {
                    type: String,
                    default: ""
                },
                u: {
                    type: String,
                    default: "px"
                },
                color: {
                    type: String,
                    default: ""
                }
            },
            data: function() {
                return {
                    active: !1,
                    disabled: !1
                };
            },
            mixins: [ y.utilMixins ],
            computed: {
                typeName: function() {
                    var t, e = "";
                    switch (this.ptype) {
                      case "1":
                        1 == this.ttype ? (t = "领 取", e = "linear-gradient(90deg, #ff3a48, #ff3a48)") : (t = 1 == this.co.useState ? "去使用" : 2 == this.co.useState ? "已使用" : "已失效", 
                        e = 1 == this.co.useState ? "linear-gradient(90deg, #ff3a48, #ff3a48)" : "");
                        break;

                      default:
                        break;
                    }
                    return {
                        t: t,
                        c: e
                    };
                },
                fullName: function() {
                    return this.co.fullMoney > 0 ? "满".concat(Number(this.co.fullMoney) + this.dw, "可用") : "无门槛";
                },
                qbbl: function() {
                    return this.co.saleNum / this.co.totalNum >= 1 ? 1 : this.co.saleNum / this.co.totalNum;
                },
                qlx: function() {
                    return 1 == this.co.type ? "代" : 2 == this.co.type ? "折" : 3 == this.co.type ? "兑" : void 0;
                },
                iswdq: function() {
                    return 2 == this.ttype && 13 == this.co.receiveType;
                }
            },
            methods: {
                useTypeName: function(t) {
                    var e;
                    switch (+t) {
                      case 1:
                        e = "全门店通用";
                        break;

                      case 2:
                        e = "指定商户可用";
                        break;

                      case 6:
                        e = "指定商户可用";
                        break;

                      case 7:
                        e = "指定商品可用";
                        break;

                      case 8:
                        e = "指定分类可用";
                        break;

                      default:
                        break;
                    }
                    return e;
                },
                goTo: function() {
                    var t = "/yb_wm/my/coupon/coupon-dl?id=" + (this.co.couponId ? this.co.couponId : this.co.id);
                    1 == this.ptype && 2 == this.ttype || 4 == this.ptype ? t = "/yb_wm/my/coupon/coupon-dl?islq=1&receiveId=" + this.co.id : 8 == this.ptype && (t = "/yb_wm/order/coupon-bag/qbxq?id=" + this.co.id), 
                    this.go({
                        t: 1,
                        url: t
                    });
                },
                btnClick: function() {
                    var t = this;
                    (this.typeName.c || 5 == this.ptype) && ((1 == this.ptype && 1 == this.ttype || 5 == this.ptype) && (this.disabled = !0, 
                    setTimeout(function() {
                        t.disabled = !1;
                    }, 1e3)), this.$emit("btntap"));
                }
            }
        };
        e.default = n;
    },
    "6a0a": function(t, e, p) {
        "use strict";
        var y = p("7890"), o = p.n(y);
        o.a;
    },
    "76b6": function(t, e, p) {
        "use strict";
        p.r(e);
        var y = p("9098"), o = p("b927");
        for (var n in o) "default" !== n && function(t) {
            p.d(e, t, function() {
                return o[t];
            });
        }(n);
        p("6a0a");
        var c, i = p("f0c5"), u = Object(i["a"])(o["default"], y["b"], y["c"], !1, null, "17e8c21e", null, !1, y["a"], c);
        e["default"] = u.exports;
    },
    7890: function(t, e, p) {},
    9098: function(t, e, p) {
        "use strict";
        var y;
        p.d(e, "b", function() {
            return o;
        }), p.d(e, "c", function() {
            return n;
        }), p.d(e, "a", function() {
            return y;
        });
        var o = function() {
            var t = this, e = t.$createElement, p = (t._self._c, 1 == t.ptype && 1 == t.co.type ? Number(t.co.money) : null), y = 1 == t.ptype && 1 != t.co.type && 2 == t.co.type ? Number(t.co.discount) : null, o = 1 != t.ptype && 2 == t.ptype && 1 == t.co.type ? Number(t.co.money) : null, n = 1 != t.ptype && 2 == t.ptype && 1 != t.co.type && 2 == t.co.type ? Number(t.co.discount) : null, c = 1 != t.ptype && 2 != t.ptype && 3 == t.ptype ? Number(t.co.money) : null, i = 1 != t.ptype && 2 != t.ptype && 3 == t.ptype ? t.useTypeName(t.co.activityType) : null, u = 1 != t.ptype && 2 != t.ptype && 3 != t.ptype && 4 == t.ptype && 1 == t.co.type ? Number(t.co.money) : null, a = 1 != t.ptype && 2 != t.ptype && 3 != t.ptype && 4 == t.ptype && 1 != t.co.type && 2 == t.co.type ? Number(t.co.discount) : null, r = 1 == t.ptype || 2 == t.ptype || 3 == t.ptype || 4 == t.ptype || 5 != t.ptype || 1 != t.co.type && 3 != t.co.type ? null : Number(t.co.money), s = 1 != t.ptype && 2 != t.ptype && 3 != t.ptype && 4 != t.ptype && 5 == t.ptype && 1 != t.co.type && 3 != t.co.type && 2 == t.co.type ? Number(t.co.discount) : null, l = 1 != t.ptype && 2 != t.ptype && 3 != t.ptype && 4 != t.ptype && 5 != t.ptype && 6 == t.ptype ? Number(t.co.money) : null, m = 1 != t.ptype && 2 != t.ptype && 3 != t.ptype && 4 != t.ptype && 5 != t.ptype && 6 == t.ptype ? t.useTypeName(t.co.activityType) : null, f = 1 != t.ptype && 2 != t.ptype && 3 != t.ptype && 4 != t.ptype && 5 != t.ptype && 6 != t.ptype && 7 == t.ptype ? t.useTypeName(t.co.activityType) : null, d = 1 != t.ptype && 2 != t.ptype && 3 != t.ptype && 4 != t.ptype && 5 != t.ptype && 6 != t.ptype && 7 != t.ptype && 8 == t.ptype ? Number(t.co.price) : null, b = 1 != t.ptype && 2 != t.ptype && 3 != t.ptype && 4 != t.ptype && 5 != t.ptype && 6 != t.ptype && 7 != t.ptype && 8 == t.ptype ? Number(t.co.money) : null, h = 1 != t.ptype && 2 != t.ptype && 3 != t.ptype && 4 != t.ptype && 5 != t.ptype && 6 != t.ptype && 7 != t.ptype && 8 != t.ptype && 9 == t.ptype ? parseInt(100 * (1 - t.qbbl)) : null, v = 1 != t.ptype && 2 != t.ptype && 3 != t.ptype && 4 != t.ptype && 5 != t.ptype && 6 != t.ptype && 7 != t.ptype && 8 != t.ptype && 9 != t.ptype && 10 == t.ptype ? Number(t.co.money) : null, N = 1 != t.ptype && 2 != t.ptype && 3 != t.ptype && 4 != t.ptype && 5 != t.ptype && 6 != t.ptype && 7 != t.ptype && 8 != t.ptype && 9 != t.ptype && 10 == t.ptype ? t.useTypeName(t.co.activityType) : null, g = 1 != t.ptype && 2 != t.ptype && 3 != t.ptype && 4 != t.ptype && 5 != t.ptype && 6 != t.ptype && 7 != t.ptype && 8 != t.ptype && 9 != t.ptype && 10 == t.ptype ? t.useTypeName(t.co.activityType) : null;
            t._isMounted || (t.e0 = function(e) {
                e.stopPropagation(), t.active = !t.active;
            }, t.e1 = function(e) {
                1 != t.co.isUse ? t.$emit("change", t.co.id) : t.goTo();
            }, t.e2 = function(e) {
                e.stopPropagation(), t.active = !t.active;
            }, t.e3 = function(e) {
                e.stopPropagation(), t.active = !t.active;
            }, t.e4 = function(e) {
                e.stopPropagation(), t.active = !t.active;
            }), t.$mp.data = Object.assign({}, {
                $root: {
                    m0: p,
                    m1: y,
                    m2: o,
                    m3: n,
                    m4: c,
                    m5: i,
                    m6: u,
                    m7: a,
                    m8: r,
                    m9: s,
                    m10: l,
                    m11: m,
                    m12: f,
                    m13: d,
                    m14: b,
                    m15: h,
                    m16: v,
                    m17: N,
                    m18: g
                }
            });
        }, n = [];
    },
    b927: function(t, e, p) {
        "use strict";
        p.r(e);
        var y = p("1c5a"), o = p.n(y);
        for (var n in y) "default" !== n && function(t) {
            p.d(e, t, function() {
                return y[t];
            });
        }(n);
        e["default"] = o.a;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "components/common/mg-coupon-create-component", {
    "components/common/mg-coupon-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("76b6"));
    }
}, [ [ "components/common/mg-coupon-create-component" ] ] ]);