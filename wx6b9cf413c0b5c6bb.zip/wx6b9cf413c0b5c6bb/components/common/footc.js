(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "components/common/footc" ], {
    "03ef": function(t, n, o) {
        "use strict";
        o.r(n);
        var e = o("48eb"), r = o.n(e);
        for (var c in e) "default" !== c && function(t) {
            o.d(n, t, function() {
                return e[t];
            });
        }(c);
        n["default"] = r.a;
    },
    "46db": function(t, n, o) {},
    "48eb": function(t, n, o) {
        "use strict";
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), n.default = void 0;
        o("26cb");
        var e = {
            name: "footc",
            props: {
                bottom: {
                    type: String,
                    default: ""
                }
            },
            data: function() {
                return {};
            },
            methods: {
                gocopyright: function() {
                    console.log(11);
                    var t = this.system.copyright.copyright_img;
                    this.go({
                        t: 1,
                        url: "/yb_wm/my/other/copyright?t=版权说明&url=" + t
                    });
                }
            }
        };
        n.default = e;
    },
    "4cad": function(t, n, o) {
        "use strict";
        o.r(n);
        var e = o("f056"), r = o("03ef");
        for (var c in r) "default" !== c && function(t) {
            o.d(n, t, function() {
                return r[t];
            });
        }(c);
        o("911a");
        var u, a = o("f0c5"), f = Object(a["a"])(r["default"], e["b"], e["c"], !1, null, "1c7a99ea", null, !1, e["a"], u);
        n["default"] = f.exports;
    },
    "911a": function(t, n, o) {
        "use strict";
        var e = o("46db"), r = o.n(e);
        r.a;
    },
    f056: function(t, n, o) {
        "use strict";
        var e;
        o.d(n, "b", function() {
            return r;
        }), o.d(n, "c", function() {
            return c;
        }), o.d(n, "a", function() {
            return e;
        });
        var r = function() {
            var t = this, n = t.$createElement;
            t._self._c;
        }, c = [];
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "components/common/footc-create-component", {
    "components/common/footc-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("4cad"));
    }
}, [ [ "components/common/footc-create-component" ] ] ]);