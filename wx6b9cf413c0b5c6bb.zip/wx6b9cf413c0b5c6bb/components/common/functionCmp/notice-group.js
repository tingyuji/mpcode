(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "components/common/functionCmp/notice-group" ], {
    "0496": function(t, n, e) {
        "use strict";
        e.r(n);
        var r = e("9872"), o = e("fda0");
        for (var u in o) "default" !== u && function(t) {
            e.d(n, t, function() {
                return o[t];
            });
        }(u);
        e("e96b");
        var c, a = e("f0c5"), i = Object(a["a"])(o["default"], r["b"], r["c"], !1, null, "478b969c", null, !1, r["a"], c);
        n["default"] = i.exports;
    },
    5302: function(t, n, e) {},
    "6cc0": function(t, n, e) {
        "use strict";
        (function(t) {
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var r = o(e("a34a"));
            e("26cb");
            function o(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            function u(t, n, e, r, o, u, c) {
                try {
                    var a = t[u](c), i = a.value;
                } catch (f) {
                    return void e(f);
                }
                a.done ? n(i) : Promise.resolve(i).then(r, o);
            }
            function c(t) {
                return function() {
                    var n = this, e = arguments;
                    return new Promise(function(r, o) {
                        var c = t.apply(n, e);
                        function a(t) {
                            u(c, r, o, a, i, "next", t);
                        }
                        function i(t) {
                            u(c, r, o, a, i, "throw", t);
                        }
                        a(void 0);
                    });
                };
            }
            var a = function() {
                e.e("components/third/uni-notice-bar").then(function() {
                    return resolve(e("2816"));
                }.bind(null, e)).catch(e.oe);
            }, i = {
                name: "searchBox",
                components: {
                    uniNoticeBar: a
                },
                props: {
                    co: {
                        type: Object,
                        default: function() {
                            return {
                                icon: [],
                                link: {},
                                notice: {},
                                txtOrImg: 1
                            };
                        }
                    },
                    sjxx: {
                        type: Object,
                        default: function() {
                            return {};
                        }
                    },
                    u: {
                        type: String,
                        default: "px"
                    },
                    ptype: {
                        type: String,
                        default: "1"
                    },
                    type: {
                        type: String,
                        default: "1"
                    },
                    list: {
                        type: Array,
                        default: function() {
                            return [];
                        }
                    },
                    sname: Object,
                    color: {
                        type: String,
                        default: ""
                    }
                },
                data: function() {
                    return {
                        notice: "",
                        nlist: []
                    };
                },
                watch: {
                    sjxx: {
                        handler: function(t) {
                            t.storeInfo && (this.notice = t.storeInfo.notice);
                        },
                        immediate: !0
                    }
                },
                methods: {
                    goLink: function() {
                        this.goUrl(this.co.link);
                    },
                    goDl: function(n) {
                        t.setStorageSync("fwb", n.content), this.go({
                            t: 1,
                            url: "/yb_o2o/my/other/gywm?t=".concat(n.title, "&p=4")
                        });
                    }
                },
                created: function() {
                    var t = this;
                    return c(r.default.mark(function n() {
                        var e, o;
                        return r.default.wrap(function(n) {
                            while (1) switch (n.prev = n.next) {
                              case 0:
                                n.t0 = +t.ptype, n.next = 1 === n.t0 ? 3 : 2 === n.t0 ? 9 : 11;
                                break;

                              case 3:
                                return n.next = 5, t.util.request({
                                    url: t.api.Notice
                                });

                              case 5:
                                return e = n.sent, o = e.data, t.nlist = o, n.abrupt("break", 12);

                              case 9:
                                return t.nlist = t.list, n.abrupt("break", 12);

                              case 11:
                                return n.abrupt("break", 12);

                              case 12:
                              case "end":
                                return n.stop();
                            }
                        }, n);
                    }))();
                }
            };
            n.default = i;
        }).call(this, e("543d")["default"]);
    },
    9872: function(t, n, e) {
        "use strict";
        var r;
        e.d(n, "b", function() {
            return o;
        }), e.d(n, "c", function() {
            return u;
        }), e.d(n, "a", function() {
            return r;
        });
        var o = function() {
            var t = this, n = t.$createElement, e = (t._self._c, t.__get_style([ {
                backgroundColor: t.co.backgroundColor,
                borderRadius: 0 == t.co.txtOrImg ? "20rpx" : 0,
                paddingRight: 0 == t.co.txtOrImg ? "15rpx" : ""
            }, t.sname ]));
            t.$mp.data = Object.assign({}, {
                $root: {
                    s0: e
                }
            });
        }, u = [];
    },
    e96b: function(t, n, e) {
        "use strict";
        var r = e("5302"), o = e.n(r);
        o.a;
    },
    fda0: function(t, n, e) {
        "use strict";
        e.r(n);
        var r = e("6cc0"), o = e.n(r);
        for (var u in r) "default" !== u && function(t) {
            e.d(n, t, function() {
                return r[t];
            });
        }(u);
        n["default"] = o.a;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "components/common/functionCmp/notice-group-create-component", {
    "components/common/functionCmp/notice-group-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("0496"));
    }
}, [ [ "components/common/functionCmp/notice-group-create-component" ] ] ]);