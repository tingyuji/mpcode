(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "components/common/functionCmp/rich-text" ], {
    "0084": function(t, n, e) {
        "use strict";
        (function(t) {
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var r = o(e("a34a"));
            e("26cb");
            function o(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            function c(t, n, e, r, o, c, u) {
                try {
                    var a = t[c](u), i = a.value;
                } catch (l) {
                    return void e(l);
                }
                a.done ? n(i) : Promise.resolve(i).then(r, o);
            }
            function u(t) {
                return function() {
                    var n = this, e = arguments;
                    return new Promise(function(r, o) {
                        var u = t.apply(n, e);
                        function a(t) {
                            c(u, r, o, a, i, "next", t);
                        }
                        function i(t) {
                            c(u, r, o, a, i, "throw", t);
                        }
                        a(void 0);
                    });
                };
            }
            var a = function() {
                Promise.all([ e.e("common/vendor"), e.e("components/uParse/src/wxParse") ]).then(function() {
                    return resolve(e("fb9f"));
                }.bind(null, e)).catch(e.oe);
            }, i = {
                name: "searchBox",
                components: {
                    uParse: a
                },
                props: {
                    type: {
                        type: String,
                        default: "1"
                    },
                    co: {
                        type: Object,
                        default: function() {
                            return {
                                richText: "",
                                topMargin: 0
                            };
                        }
                    },
                    u: {
                        type: String,
                        default: "px"
                    },
                    color: {
                        type: String,
                        default: ""
                    },
                    content: {
                        type: String,
                        default: ""
                    }
                },
                data: function() {
                    return {};
                },
                computed: {
                    nodes: function() {
                        return 1 == this.type ? this.co.html.replace(/\<p class="ql-align-center/gi, '<p style="text-align:center" class="ql-align-center').replace(/\<img/gi, '<img style="max-width:100%;height:auto"') : (console.log(1), 
                        this.content.replace(/<img[^>]*>/gi, function(t, n) {
                            return t.replace(/style=|alt\s*?=\s*?([‘"])[\s\S]*?\1/gi, 'style="width:100%;height:auto;display:block;"');
                        }));
                    }
                },
                methods: {
                    preview: function(t, n) {
                        console.log("src: " + t);
                    },
                    navigate: function(n, e) {
                        console.log("href: " + n), t.showModal({
                            content: "点击链接为：" + n,
                            showCancel: !1
                        });
                    }
                },
                created: function() {
                    return u(r.default.mark(function t() {
                        return r.default.wrap(function(t) {
                            while (1) switch (t.prev = t.next) {
                              case 0:
                              case "end":
                                return t.stop();
                            }
                        }, t);
                    }))();
                }
            };
            n.default = i;
        }).call(this, e("543d")["default"]);
    },
    "133c": function(t, n, e) {
        "use strict";
        e.r(n);
        var r = e("0084"), o = e.n(r);
        for (var c in r) "default" !== c && function(t) {
            e.d(n, t, function() {
                return r[t];
            });
        }(c);
        n["default"] = o.a;
    },
    "44d7": function(t, n, e) {
        "use strict";
        var r = e("91dd"), o = e.n(r);
        o.a;
    },
    "5b65": function(t, n, e) {
        "use strict";
        var r;
        e.d(n, "b", function() {
            return o;
        }), e.d(n, "c", function() {
            return c;
        }), e.d(n, "a", function() {
            return r;
        });
        var o = function() {
            var t = this, n = t.$createElement;
            t._self._c;
        }, c = [];
    },
    "91dd": function(t, n, e) {},
    ba4f: function(t, n, e) {
        "use strict";
        e.r(n);
        var r = e("5b65"), o = e("133c");
        for (var c in o) "default" !== c && function(t) {
            e.d(n, t, function() {
                return o[t];
            });
        }(c);
        e("44d7");
        var u, a = e("f0c5"), i = Object(a["a"])(o["default"], r["b"], r["c"], !1, null, "ba4895a2", null, !1, r["a"], u);
        n["default"] = i.exports;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "components/common/functionCmp/rich-text-create-component", {
    "components/common/functionCmp/rich-text-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("ba4f"));
    }
}, [ [ "components/common/functionCmp/rich-text-create-component" ] ] ]);