(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "components/common/block-b" ], {
    "31c5": function(t, e, o) {
        "use strict";
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var n = {
            name: "popup",
            props: {
                cName: {
                    type: String,
                    default: ""
                },
                sname: "",
                type: {
                    type: String,
                    default: "1"
                },
                t: {
                    type: String,
                    default: ""
                },
                color: {
                    type: String,
                    default: ""
                },
                block: {
                    type: String,
                    default: ""
                }
            },
            methods: {}
        };
        e.default = n;
    },
    "569d": function(t, e, o) {
        "use strict";
        o.r(e);
        var n = o("614d"), r = o("901f");
        for (var l in r) "default" !== l && function(t) {
            o.d(e, t, function() {
                return r[t];
            });
        }(l);
        var c, a = o("f0c5"), u = Object(a["a"])(r["default"], n["b"], n["c"], !1, null, "72588308", null, !1, n["a"], c);
        e["default"] = u.exports;
    },
    "614d": function(t, e, o) {
        "use strict";
        var n;
        o.d(e, "b", function() {
            return r;
        }), o.d(e, "c", function() {
            return l;
        }), o.d(e, "a", function() {
            return n;
        });
        var r = function() {
            var t = this, e = t.$createElement, o = (t._self._c, 1 == t.type ? t.__get_style([ {
                background: t.color,
                borderColor: t.color,
                display: t.block && "block"
            }, t.sname ]) : null), n = 1 != t.type && 2 == t.type ? t.__get_style([ {
                color: t.color,
                borderColor: t.color,
                display: t.block && "block"
            }, t.sname ]) : null;
            t.$mp.data = Object.assign({}, {
                $root: {
                    s0: o,
                    s1: n
                }
            });
        }, l = [];
    },
    "901f": function(t, e, o) {
        "use strict";
        o.r(e);
        var n = o("31c5"), r = o.n(n);
        for (var l in n) "default" !== l && function(t) {
            o.d(e, t, function() {
                return n[t];
            });
        }(l);
        e["default"] = r.a;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "components/common/block-b-create-component", {
    "components/common/block-b-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("569d"));
    }
}, [ [ "components/common/block-b-create-component" ] ] ]);