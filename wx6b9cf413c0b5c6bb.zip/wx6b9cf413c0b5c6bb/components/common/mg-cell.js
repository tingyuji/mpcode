(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "components/common/mg-cell" ], {
    "646c": function(t, n, e) {
        "use strict";
        e.r(n);
        var c = e("999e"), a = e.n(c);
        for (var r in c) "default" !== r && function(t) {
            e.d(n, t, function() {
                return c[t];
            });
        }(r);
        n["default"] = a.a;
    },
    6971: function(t, n, e) {
        "use strict";
        var c = e("e3c0"), a = e.n(c);
        a.a;
    },
    "999e": function(t, n, e) {
        "use strict";
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), n.default = void 0;
        var c = {
            name: "mg-cell",
            props: {
                bgc: {
                    type: String,
                    default: ""
                },
                htc: "",
                last: "",
                cname: "",
                bbd: "",
                noc: "",
                sname: "",
                isl: "",
                isr: "",
                iconn: "",
                ht: "",
                hdc: "",
                hw: "",
                img: "",
                m: {
                    type: String,
                    default: "aspectFill"
                },
                w: "",
                h: "",
                brs: "",
                imgr: "",
                bdmw: {
                    type: String,
                    default: "0"
                },
                btt: "",
                bttc: "",
                bbt: "",
                ft: "",
                ftc: "",
                color: "",
                arrow: "",
                ac: "",
                asize: "",
                acolor: "",
                hc: {
                    type: String,
                    value: ""
                }
            },
            data: function() {
                return {};
            },
            computed: {},
            methods: {
                maskTap: function() {
                    this.$emit("input", !1);
                }
            }
        };
        n.default = c;
    },
    c0b8: function(t, n, e) {
        "use strict";
        e.r(n);
        var c = e("ff23"), a = e("646c");
        for (var r in a) "default" !== r && function(t) {
            e.d(n, t, function() {
                return a[t];
            });
        }(r);
        e("6971");
        var u, o = e("f0c5"), i = Object(o["a"])(a["default"], c["b"], c["c"], !1, null, "721e2dde", null, !1, c["a"], u);
        n["default"] = i.exports;
    },
    e3c0: function(t, n, e) {},
    ff23: function(t, n, e) {
        "use strict";
        var c;
        e.d(n, "b", function() {
            return a;
        }), e.d(n, "c", function() {
            return r;
        }), e.d(n, "a", function() {
            return c;
        });
        var a = function() {
            var t = this, n = t.$createElement, e = (t._self._c, t.__get_style([ {
                background: t.bgc
            }, t.sname ]));
            t.$mp.data = Object.assign({}, {
                $root: {
                    s0: e
                }
            });
        }, r = [];
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "components/common/mg-cell-create-component", {
    "components/common/mg-cell-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("c0b8"));
    }
}, [ [ "components/common/mg-cell-create-component" ] ] ]);