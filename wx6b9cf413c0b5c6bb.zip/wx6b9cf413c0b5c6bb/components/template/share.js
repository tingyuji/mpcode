(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "components/template/share" ], {
    "45a1": function(t, e, n) {
        "use strict";
        var o;
        n.d(e, "b", function() {
            return i;
        }), n.d(e, "c", function() {
            return c;
        }), n.d(e, "a", function() {
            return o;
        });
        var i = function() {
            var t = this, e = t.$createElement;
            t._self._c;
        }, c = [];
    },
    "64c7": function(t, e, n) {
        "use strict";
        (function(t) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            n("26cb");
            var o = function() {
                n.e("components/common/popup").then(function() {
                    return resolve(n("b94e"));
                }.bind(null, n)).catch(n.oe);
            }, i = function() {
                n.e("components/common/functionCmp/swiper").then(function() {
                    return resolve(n("adc8"));
                }.bind(null, n)).catch(n.oe);
            }, c = {
                name: "mg-share",
                components: {
                    mgPopup: o,
                    MgSwiper: i
                },
                props: {
                    co: {
                        type: Object,
                        default: function() {
                            return {};
                        }
                    },
                    value: {
                        type: Boolean,
                        default: !1
                    },
                    wxs: {
                        type: String,
                        default: "1"
                    },
                    hbs: {
                        type: Boolean,
                        default: !1
                    },
                    link: {
                        type: String,
                        default: ""
                    },
                    ptype: String,
                    mesShow: {
                        type: Boolean,
                        default: !1
                    }
                },
                data: function() {
                    return {
                        clickShow: !1,
                        timer: null
                    };
                },
                computed: {
                    show: {
                        get: function() {
                            return this.value;
                        },
                        set: function(t) {
                            this.$emit("input", t);
                        }
                    }
                },
                watch: {
                    mesShow: {
                        handler: function(t, e) {
                            t && !0 === t && this.clickShow && 1 == this.ptype && this.hbfx();
                        }
                    }
                },
                methods: {
                    share: function() {
                        this.show = !1, t.showModal({
                            title: "提示",
                            content: "点击右上角分享",
                            showCancel: !1,
                            confirmText: "我知道了"
                        });
                    },
                    fzlj: function() {
                        this.util.fz(this.link || location.href);
                    },
                    hbfx: function() {
                        if (1 != this.ptype || this.mesShow) 1 == this.ptype && (clearInterval(this.timer), 
                        this.timer = null, this.clickShow = !1, t.hideLoading()), 1 == this.ptype && (this.show = !1, 
                        t.setStorageSync("bdhc", this.co), this.go({
                            url: "/yb_wm/other/hb?type=".concat(this.ptype)
                        })), 2 == this.ptype && (this.show = !1, t.setStorageSync("bdhc", this.co), this.go({
                            url: "/yb_wm/other/hb?type=".concat(this.ptype)
                        })), console.log(this.ptype); else {
                            t.showLoading({
                                title: "加载中..."
                            }), this.clickShow = !0;
                            var e = 0;
                            this.timer = setInterval(function() {
                                if (e > 10) return clearInterval(this.timer), this.timer = null, void t.showModal({
                                    title: "提示",
                                    content: "获取图片失败，请稍后重试！",
                                    showCancel: !1,
                                    success: function(t) {
                                        t.confirm && (this.show = !1);
                                    }
                                });
                                e++;
                            }, 1e3);
                        }
                    }
                }
            };
            e.default = c;
        }).call(this, n("543d")["default"]);
    },
    "7bb5": function(t, e, n) {
        "use strict";
        n.r(e);
        var o = n("64c7"), i = n.n(o);
        for (var c in o) "default" !== c && function(t) {
            n.d(e, t, function() {
                return o[t];
            });
        }(c);
        e["default"] = i.a;
    },
    "9a2a": function(t, e, n) {
        "use strict";
        n.r(e);
        var o = n("45a1"), i = n("7bb5");
        for (var c in i) "default" !== c && function(t) {
            n.d(e, t, function() {
                return i[t];
            });
        }(c);
        n("fdd3");
        var s, u = n("f0c5"), r = Object(u["a"])(i["default"], o["b"], o["c"], !1, null, "71d22f32", null, !1, o["a"], s);
        e["default"] = r.exports;
    },
    acc8: function(t, e, n) {},
    fdd3: function(t, e, n) {
        "use strict";
        var o = n("acc8"), i = n.n(o);
        i.a;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "components/template/share-create-component", {
    "components/template/share-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("9a2a"));
    }
}, [ [ "components/template/share-create-component" ] ] ]);