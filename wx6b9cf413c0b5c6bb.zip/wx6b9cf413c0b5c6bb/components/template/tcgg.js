(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "components/template/tcgg" ], {
    "3a14": function(n, t, e) {
        "use strict";
        var r;
        e.d(t, "b", function() {
            return u;
        }), e.d(t, "c", function() {
            return o;
        }), e.d(t, "a", function() {
            return r;
        });
        var u = function() {
            var n = this, t = n.$createElement;
            n._self._c;
            n._isMounted || (n.e0 = function(t) {
                n.show = !1;
            });
        }, o = [];
    },
    6717: function(n, t, e) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var r = u(e("a34a"));
        e("26cb");
        function u(n) {
            return n && n.__esModule ? n : {
                default: n
            };
        }
        function o(n, t, e, r, u, o, c) {
            try {
                var i = n[o](c), a = i.value;
            } catch (f) {
                return void e(f);
            }
            i.done ? t(a) : Promise.resolve(a).then(r, u);
        }
        function c(n) {
            return function() {
                var t = this, e = arguments;
                return new Promise(function(r, u) {
                    var c = n.apply(t, e);
                    function i(n) {
                        o(c, r, u, i, a, "next", n);
                    }
                    function a(n) {
                        o(c, r, u, i, a, "throw", n);
                    }
                    i(void 0);
                });
            };
        }
        var i = function() {
            e.e("components/common/modal").then(function() {
                return resolve(e("62f5"));
            }.bind(null, e)).catch(e.oe);
        }, a = function() {
            e.e("components/common/functionCmp/swiper").then(function() {
                return resolve(e("adc8"));
            }.bind(null, e)).catch(e.oe);
        }, f = {
            name: "searchBox",
            components: {
                mgModal: i,
                MgSwiper: a
            },
            props: {
                co: {
                    type: Object,
                    default: function() {
                        return {};
                    }
                },
                value: {
                    type: Boolean,
                    default: !1
                },
                list: {
                    type: Array,
                    default: function() {
                        return [];
                    }
                },
                color: {
                    type: String,
                    default: ""
                }
            },
            data: function() {
                return {
                    swiper: {
                        class: "bs20",
                        swiper: {
                            children: []
                        },
                        duration: "",
                        mode: "",
                        height: "733",
                        radius: 20,
                        auto: !0,
                        interval: 5
                    }
                };
            },
            computed: {
                show: {
                    get: function() {
                        return this.value;
                    },
                    set: function(n) {
                        this.$emit("input", n);
                    }
                }
            },
            watch: {
                list: {
                    handler: function(n) {
                        var t = this;
                        return c(r.default.mark(function e() {
                            return r.default.wrap(function(e) {
                                while (1) switch (e.prev = e.next) {
                                  case 0:
                                    n.length && (t.swiper.swiper.children = n);

                                  case 1:
                                  case "end":
                                    return e.stop();
                                }
                            }, e);
                        }))();
                    },
                    immediate: !0
                }
            },
            methods: {}
        };
        t.default = f;
    },
    b182: function(n, t, e) {},
    bcbd: function(n, t, e) {
        "use strict";
        e.r(t);
        var r = e("3a14"), u = e("e703");
        for (var o in u) "default" !== o && function(n) {
            e.d(t, n, function() {
                return u[n];
            });
        }(o);
        e("e1bd");
        var c, i = e("f0c5"), a = Object(i["a"])(u["default"], r["b"], r["c"], !1, null, "3650c0a3", null, !1, r["a"], c);
        t["default"] = a.exports;
    },
    e1bd: function(n, t, e) {
        "use strict";
        var r = e("b182"), u = e.n(r);
        u.a;
    },
    e703: function(n, t, e) {
        "use strict";
        e.r(t);
        var r = e("6717"), u = e.n(r);
        for (var o in r) "default" !== o && function(n) {
            e.d(t, n, function() {
                return r[n];
            });
        }(o);
        t["default"] = u.a;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "components/template/tcgg-create-component", {
    "components/template/tcgg-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("bcbd"));
    }
}, [ [ "components/template/tcgg-create-component" ] ] ]);