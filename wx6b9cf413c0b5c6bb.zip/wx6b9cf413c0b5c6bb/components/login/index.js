(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "components/login/index" ], {
    "0143": function(e, t, o) {
        "use strict";
        var n = o("a010"), i = o.n(n);
        i.a;
    },
    4995: function(e, t, o) {
        "use strict";
        o.r(t);
        var n = o("ba4f5"), i = o.n(n);
        for (var s in n) "default" !== s && function(e) {
            o.d(t, e, function() {
                return n[e];
            });
        }(s);
        t["default"] = i.a;
    },
    "7b58": function(e, t, o) {
        "use strict";
        var n;
        o.d(t, "b", function() {
            return i;
        }), o.d(t, "c", function() {
            return s;
        }), o.d(t, "a", function() {
            return n;
        });
        var i = function() {
            var e = this, t = e.$createElement, o = (e._self._c, e.system && e.system.member && 1 == e.system.member.is_open_phone && !e.checkedTo ? e.util.bgColorHx(e.tColor, .5, 5) : null), n = e.system && e.system.member && 2 == e.system.member.is_open_phone && !e.checkedTo ? e.util.bgColorHx(e.tColor, .5, 5) : null;
            e._isMounted || (e.e0 = function(t) {
                e.checkedTo = !e.checkedTo;
            }), e.$mp.data = Object.assign({}, {
                $root: {
                    g0: o,
                    g1: n
                }
            });
        }, s = [];
    },
    a010: function(e, t, o) {},
    ba4f5: function(e, t, o) {
        "use strict";
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var n = o("26cb");
            function i(e, t) {
                var o = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable;
                    })), o.push.apply(o, n);
                }
                return o;
            }
            function s(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var o = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? i(Object(o), !0).forEach(function(t) {
                        r(e, t, o[t]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(o)) : i(Object(o)).forEach(function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(o, t));
                    });
                }
                return e;
            }
            function r(e, t, o) {
                return t in e ? Object.defineProperty(e, t, {
                    value: o,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : e[t] = o, e;
            }
            var a = function() {
                o.e("components/common/popup").then(function() {
                    return resolve(o("b94e"));
                }.bind(null, o)).catch(o.oe);
            }, c = {
                components: {
                    mgPopup: a
                },
                computed: s({}, (0, n.mapState)([ "shopInfo", "system" ])),
                watch: {
                    system: {
                        handler: function(e, t) {
                            var o;
                            this.checkedTo = "1" == (null === e || void 0 === e || null === (o = e.member) || void 0 === o ? void 0 : o.is_default_check);
                        }
                    }
                },
                data: function() {
                    return {
                        showSq: !1,
                        checkedTo: !1,
                        nickName: "",
                        avatarUrl: "",
                        mobile: "",
                        loading: !1,
                        ptname: "ali" == this.api.platform,
                        btnShow: !0,
                        storeid: ""
                    };
                },
                created: function() {},
                methods: {
                    blurtxt: function(e) {
                        console.log(e), this.nickName = e.detail.value;
                    },
                    changeVal: function(e) {
                        this.btnShow = !1, this.btnShow = !0;
                    },
                    getUserInfo: function() {
                        var t = this;
                        e.getUserInfo({
                            success: function(o) {
                                e.showLoading("登录中..."), t.refreshUser({
                                    storeId: t.storeid,
                                    portrait: portrait,
                                    userName: userName,
                                    userId: userId
                                }).then(function(o) {
                                    e.hideLoading(), t.util.message("登录成功", 1, 1e3), t.showSq = !1;
                                }), e.hideLoading(), console.log("getUserInfo success", o);
                            },
                            fail: function(t) {
                                console.log("getUserInfo fail", t), e.showModal({
                                    title: "温馨提示",
                                    content: "获取头像等信息失败",
                                    showCancel: !1
                                });
                            }
                        });
                    },
                    getAlPhoneNumber: function() {
                        var e = this;
                        console.log(0x18abef7846071c0), console.log(this.system.aliopenappid), my.getPhoneNumber({
                            protocols: {
                                isvAppId: this.system.aliopenappid
                            },
                            scopes: "auth_user",
                            success: function(t) {
                                var o = JSON.parse(t.response);
                                e.util.request({
                                    url: e.api.jm,
                                    method: "POST",
                                    data: {
                                        data: o.response
                                    }
                                }).then(function(t) {
                                    console.log("jm res", t), t.data && (e.show = !1, e.mobile = t.data, e.submitTo());
                                }), console.log("getAlPhoneNumber success", o);
                            },
                            fail: function(e) {
                                console.log("getAlPhoneNumber fail", e);
                            }
                        });
                    },
                    getUserProfile: function() {
                        var t = this;
                        if (this.judgeNext() && !this.loading) {
                            this.loading = !0;
                            try {
                                var o = this.avatarUrl, n = this.nickName ? this.nickName : "", i = this.uId;
                                e.showLoading("登录中..."), this.refreshUser({
                                    storeId: this.storeid,
                                    portrait: o,
                                    userName: n,
                                    userId: i,
                                    now: 1
                                }).then(function(o) {
                                    e.hideLoading(), t.util.message("登录成功", 1, 1e3), t.showSq = !1;
                                }).catch(function() {
                                    t.loading = !1;
                                }), e.hideLoading();
                            } catch (s) {
                                this.loading = !1, console.log(s);
                            }
                        }
                    },
                    mpGetUserInfo: function(t) {
                        var o = this;
                        if (!this.loading) if (this.loading = !0, "getUserInfo:ok" == t.detail.errMsg) {
                            var n = t.detail.userInfo.avatarUrl, i = t.detail.userInfo.nickName, s = this.uId;
                            e.showLoading("登录中..."), this.refreshUser({
                                storeId: this.storeid,
                                portrait: n,
                                userName: i,
                                userId: s,
                                now: 1
                            }).then(function(t) {
                                e.hideLoading(), o.util.message("登录成功", 1, 1e3), o.showSq = !1;
                            }).catch(function() {
                                o.loading = !1;
                            }), e.hideLoading();
                        } else this.loading = !1, e.showModal({
                            title: "温馨提示",
                            content: "获取头像等信息失败",
                            showCancel: !1
                        });
                    },
                    onGetAuthorize: function(t) {
                        var o = this;
                        console.log("onGetAuthorize", t), my.getOpenUserInfo({
                            fail: function(e) {},
                            success: function(t) {
                                var n = JSON.parse(t.response).response;
                                console.log("onGetAuthorize", n), e.showLoading("登录中..."), o.refreshUser({
                                    storeId: o.storeid,
                                    portrait: n.avatar,
                                    userName: n.nickName,
                                    userId: o.uId,
                                    now: 1
                                }).then(function(t) {
                                    e.hideLoading(), o.util.message("登录成功", 1, 1e3), o.showSq = !1;
                                }), e.hideLoading();
                            }
                        });
                    },
                    onGetAuthorizenickname: function(e) {
                        var t = this;
                        console.log("onGetAuthorize", e), my.getOpenUserInfo({
                            fail: function(e) {},
                            success: function(e) {
                                var o = JSON.parse(e.response).response;
                                console.log("onGetAuthorize", o), t.avatarUrl = o.avatar, t.nickName = o.nickName;
                            }
                        });
                    },
                    mpGetphonenumber: function(t) {
                        var o = this;
                        if (console.log("mpGetphonenumber", t), "getPhoneNumber:ok" == t.detail.errMsg) {
                            var n = getApp().globalData.session_key, i = t.detail.encryptedData, s = t.detail.iv, r = this.uId;
                            e.showLoading("登录中..."), this.util.request({
                                url: this.api.jm,
                                method: "POST",
                                data: {
                                    userId: r,
                                    sessionKey: n,
                                    data: i,
                                    iv: s
                                },
                                mask: 1
                            }).then(function(e) {
                                o.mobile = e.data, 1 == o.system.member.is_open_phone && o.submitTo();
                            });
                        } else e.showModal({
                            title: "温馨提示",
                            content: "授权手机号失败",
                            showCancel: !1
                        });
                    },
                    judgeNext: function() {
                        if ("1" == this.system.member.is_userinfo) {
                            if (!this.avatarUrl) return e.showToast({
                                icon: "none",
                                title: "请选择头像!"
                            }), !1;
                            if (!this.nickName) return e.showToast({
                                icon: "none",
                                title: "请填写昵称!"
                            }), !1;
                        }
                        return 1 != this.system.member.is_open_phone || this.mobile ? !!this.checkedTo || (e.showToast({
                            icon: "none",
                            title: "请阅读并勾选隐私协议!"
                        }), !1) : (e.showToast({
                            icon: "none",
                            title: "请先获取手机号码!"
                        }), !1);
                    },
                    submitTo: function() {
                        var t, o = this;
                        if (this.judgeNext()) {
                            var n = this.avatarUrl, i = this.nickName, s = this.uId;
                            e.showLoading("登录中..."), this.refreshUser((t = {
                                portrait: n,
                                userName: i,
                                userId: s,
                                storeId: this.storeid
                            }, r(t, "userId", this.uId), r(t, "now", 1), t)).then(function(t) {
                                e.hideLoading(), o.util.message("登录成功", 1, 1e3), o.showSq = !1;
                            }), e.hideLoading();
                        }
                    },
                    ysxyRule: function() {
                        this.go({
                            t: 1,
                            url: "/yb_wm/my/other/gywm?t=隐私政策&p=15"
                        });
                    },
                    open: function() {
                        this.showSq = !0;
                    },
                    close: function() {
                        this.showSq = !1;
                    },
                    onChooseAvatar: function(e) {
                        console.log("选择头像", e), this.avatarUrl = e.detail.avatarUrl, this.wxuploadFile();
                    },
                    wxuploadFile: function() {
                        var t = this, o = getApp().globalData.siteInfo, n = o.siteroot + "/index.php/" + this.api.sctp;
                        e.uploadFile({
                            url: n,
                            filePath: this.avatarUrl,
                            name: "image",
                            header: {
                                "content-type": "multipart/form-data",
                                token: e.getStorageSync("token"),
                                appType: this.api.platform,
                                uniacid: o.uniacid,
                                module: "yb_wm",
                                userId: e.getStorageSync("userId"),
                                logintoken: getApp().globalData.session_key
                            },
                            success: function(e) {
                                console.log(e), t.avatarUrl = e.data;
                            },
                            fail: function(e) {
                                console.log(e);
                            }
                        });
                    }
                }
            };
            t.default = c;
        }).call(this, o("543d")["default"]);
    },
    c290: function(e, t, o) {
        "use strict";
        o.r(t);
        var n = o("7b58"), i = o("4995");
        for (var s in i) "default" !== s && function(e) {
            o.d(t, e, function() {
                return i[e];
            });
        }(s);
        o("0143");
        var r, a = o("f0c5"), c = Object(a["a"])(i["default"], n["b"], n["c"], !1, null, "1dc36df6", null, !1, n["a"], r);
        t["default"] = c.exports;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "components/login/index-create-component", {
    "components/login/index-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("c290"));
    }
}, [ [ "components/login/index-create-component" ] ] ]);