(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "components/form/mg-photo" ], {
    1115: function(t, e, n) {
        "use strict";
        n.r(e);
        var r = n("24ff"), a = n.n(r);
        for (var i in r) "default" !== i && function(t) {
            n.d(e, t, function() {
                return r[t];
            });
        }(i);
        e["default"] = a.a;
    },
    "24ff": function(t, e, n) {
        "use strict";
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var r = i(n("a34a")), a = n("a669");
        function i(t) {
            return t && t.__esModule ? t : {
                default: t
            };
        }
        function o(t, e) {
            var n;
            if ("undefined" === typeof Symbol || null == t[Symbol.iterator]) {
                if (Array.isArray(t) || (n = u(t)) || e && t && "number" === typeof t.length) {
                    n && (t = n);
                    var r = 0, a = function() {};
                    return {
                        s: a,
                        n: function() {
                            return r >= t.length ? {
                                done: !0
                            } : {
                                done: !1,
                                value: t[r++]
                            };
                        },
                        e: function(t) {
                            throw t;
                        },
                        f: a
                    };
                }
                throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
            }
            var i, o = !0, c = !1;
            return {
                s: function() {
                    n = t[Symbol.iterator]();
                },
                n: function() {
                    var t = n.next();
                    return o = t.done, t;
                },
                e: function(t) {
                    c = !0, i = t;
                },
                f: function() {
                    try {
                        o || null == n.return || n.return();
                    } finally {
                        if (c) throw i;
                    }
                }
            };
        }
        function u(t, e) {
            if (t) {
                if ("string" === typeof t) return c(t, e);
                var n = Object.prototype.toString.call(t).slice(8, -1);
                return "Object" === n && t.constructor && (n = t.constructor.name), "Map" === n || "Set" === n ? Array.from(t) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? c(t, e) : void 0;
            }
        }
        function c(t, e) {
            (null == e || e > t.length) && (e = t.length);
            for (var n = 0, r = new Array(e); n < e; n++) r[n] = t[n];
            return r;
        }
        function f(t, e, n, r, a, i, o) {
            try {
                var u = t[i](o), c = u.value;
            } catch (f) {
                return void n(f);
            }
            u.done ? e(c) : Promise.resolve(c).then(r, a);
        }
        function s(t) {
            return function() {
                var e = this, n = arguments;
                return new Promise(function(r, a) {
                    var i = t.apply(e, n);
                    function o(t) {
                        f(i, r, a, o, u, "next", t);
                    }
                    function u(t) {
                        f(i, r, a, o, u, "throw", t);
                    }
                    o(void 0);
                });
            };
        }
        var l = function() {
            n.e("components/common/mg-cell").then(function() {
                return resolve(n("c0b8"));
            }.bind(null, n)).catch(n.oe);
        }, p = {
            components: {
                MgCell: l
            },
            props: {
                cname: "",
                max: {
                    type: String,
                    default: "9"
                },
                fileList: {
                    type: Array,
                    default: function() {
                        return [];
                    }
                },
                pt: {
                    type: String,
                    default: ""
                },
                mark: {
                    type: [ String, Number ],
                    default: ""
                },
                pkey: {
                    type: String,
                    default: ""
                },
                icon: {
                    type: String,
                    default: "iconjia"
                },
                title: "",
                ftitle: "",
                w: ""
            },
            data: function() {
                return {
                    filePaths: [],
                    files: []
                };
            },
            computed: {},
            watch: {
                fileList: {
                    handler: function(t) {
                        this.filePaths = Object.assign([], t.map(function(t) {
                            return {
                                url: t
                            };
                        })), t.length && (this.$emit("change-img", {
                            p: this.filePaths,
                            mark: this.mark,
                            pkey: this.pkey
                        }), "weChat" == this.api.platform && (this.files = this.filePaths));
                    },
                    immediate: !0
                }
            },
            methods: {
                add: function() {
                    var t = this;
                    return s(r.default.mark(function e() {
                        var n, i, u, c, f, s, l;
                        return r.default.wrap(function(e) {
                            while (1) switch (e.prev = e.next) {
                              case 0:
                                return e.next = 2, (0, a.choosePhoto)({
                                    num: t.max - t.filePaths.length
                                });

                              case 2:
                                if (n = e.sent, "weChat" == t.api.platform) {
                                    e.next = 8;
                                    break;
                                }
                                t.filePaths = t.filePaths.concat(n.map(function(t) {
                                    return {
                                        tmp: 1,
                                        url: t
                                    };
                                })), t.$emit("change-img", {
                                    p: t.filePaths,
                                    mark: t.mark,
                                    pkey: t.pkey
                                }), e.next = 32;
                                break;

                              case 8:
                                i = [], u = o(n), e.prev = 10, u.s();

                              case 12:
                                if ((c = u.n()).done) {
                                    e.next = 21;
                                    break;
                                }
                                return f = c.value, e.next = 16, (0, a.uploadImage)(f);

                              case 16:
                                s = e.sent, l = s.serverId, i.push(l);

                              case 19:
                                e.next = 12;
                                break;

                              case 21:
                                e.next = 26;
                                break;

                              case 23:
                                e.prev = 23, e.t0 = e["catch"](10), u.e(e.t0);

                              case 26:
                                return e.prev = 26, u.f(), e.finish(26);

                              case 29:
                                t.filePaths = t.filePaths.concat(n.map(function(t) {
                                    return {
                                        tmp: 1,
                                        url: t
                                    };
                                })), t.files = t.files.concat(i.map(function(t) {
                                    return {
                                        tmp: 1,
                                        url: t
                                    };
                                })), t.$emit("change-img", {
                                    p: t.files,
                                    mark: t.mark,
                                    pkey: t.pkey
                                });

                              case 32:
                                console.log(t.api.platform, n);

                              case 33:
                              case "end":
                                return e.stop();
                            }
                        }, e, null, [ [ 10, 23, 26, 29 ] ]);
                    }))();
                },
                deletePic: function(t) {
                    this.filePaths.splice(t, 1), "weChat" != this.api.platform ? this.$emit("change-img", {
                        p: this.filePaths,
                        mark: this.mark,
                        pkey: this.pkey
                    }) : (this.files.splice(t, 1), this.$emit("change-img", {
                        p: this.files,
                        mark: this.mark,
                        pkey: this.pkey
                    }));
                }
            }
        };
        e.default = p;
    },
    c609: function(t, e, n) {},
    ec13: function(t, e, n) {
        "use strict";
        var r;
        n.d(e, "b", function() {
            return a;
        }), n.d(e, "c", function() {
            return i;
        }), n.d(e, "a", function() {
            return r;
        });
        var a = function() {
            var t = this, e = t.$createElement;
            t._self._c;
        }, i = [];
    },
    fc64: function(t, e, n) {
        "use strict";
        var r = n("c609"), a = n.n(r);
        a.a;
    },
    fec4: function(t, e, n) {
        "use strict";
        n.r(e);
        var r = n("ec13"), a = n("1115");
        for (var i in a) "default" !== i && function(t) {
            n.d(e, t, function() {
                return a[t];
            });
        }(i);
        n("fc64");
        var o, u = n("f0c5"), c = Object(u["a"])(a["default"], r["b"], r["c"], !1, null, "4ec59927", null, !1, r["a"], o);
        e["default"] = c.exports;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "components/form/mg-photo-create-component", {
    "components/form/mg-photo-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("fec4"));
    }
}, [ [ "components/form/mg-photo-create-component" ] ] ]);