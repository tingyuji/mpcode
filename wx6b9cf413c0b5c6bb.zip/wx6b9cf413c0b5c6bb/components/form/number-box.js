(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "components/form/number-box" ], {
    "282f": function(t, e, n) {
        "use strict";
        var u = n("c5c6"), i = n.n(u);
        i.a;
    },
    "30b7": function(t, e, n) {
        "use strict";
        var u;
        n.d(e, "b", function() {
            return i;
        }), n.d(e, "c", function() {
            return a;
        }), n.d(e, "a", function() {
            return u;
        });
        var i = function() {
            var t = this, e = t.$createElement;
            t._self._c;
        }, a = [];
    },
    "30cc": function(t, e, n) {
        "use strict";
        n.r(e);
        var u = n("6553"), i = n.n(u);
        for (var a in u) "default" !== a && function(t) {
            n.d(e, t, function() {
                return u[t];
            });
        }(a);
        e["default"] = i.a;
    },
    6553: function(t, e, n) {
        "use strict";
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var u = {
            name: "UniNumberBox",
            props: {
                value: {
                    type: [ Number, String ],
                    default: 1
                },
                min: {
                    type: [ Number, String ],
                    default: 0
                },
                max: {
                    type: [ Number, String ],
                    default: 1
                },
                step: {
                    type: Number,
                    default: 1
                },
                disabled: {
                    type: Boolean,
                    default: !1
                }
            },
            data: function() {
                return {
                    inputValue: 0
                };
            },
            watch: {
                value: function(t) {
                    this.inputValue = +t;
                },
                inputValue: function(t, e) {
                    +t !== +e && this.$emit("change", t);
                }
            },
            created: function() {
                this.inputValue = +this.value;
            },
            methods: {
                _calcValue: function(t) {
                    if (!this.disabled) {
                        var e = this._getDecimalScale(), n = this.inputValue * e, u = this.step * e;
                        "minus" === t ? n -= u : "plus" === t && (n += u), n < this.min || n > this.max || (this.inputValue = n / e);
                    }
                },
                _getDecimalScale: function() {
                    var t = 1;
                    return ~~this.step !== this.step && (t = Math.pow(10, (this.step + "").split(".")[1].length)), 
                    t;
                },
                _onBlur: function(t) {
                    var e = t.detail.value;
                    e ? (e = +e, e > this.max ? e = this.max : e < this.min && (e = this.min), this.inputValue = e) : this.inputValue = 0;
                }
            }
        };
        e.default = u;
    },
    c5c6: function(t, e, n) {},
    ef5c: function(t, e, n) {
        "use strict";
        n.r(e);
        var u = n("30b7"), i = n("30cc");
        for (var a in i) "default" !== a && function(t) {
            n.d(e, t, function() {
                return i[t];
            });
        }(a);
        n("282f");
        var c, r = n("f0c5"), l = Object(r["a"])(i["default"], u["b"], u["c"], !1, null, null, null, !1, u["a"], c);
        e["default"] = l.exports;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "components/form/number-box-create-component", {
    "components/form/number-box-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("ef5c"));
    }
}, [ [ "components/form/number-box-create-component" ] ] ]);