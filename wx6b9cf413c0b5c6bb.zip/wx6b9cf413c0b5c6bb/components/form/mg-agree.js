(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "components/form/mg-agree" ], {
    3919: function(t, n, e) {
        "use strict";
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), n.default = void 0;
        var c = function() {
            e.e("components/common/mg-cell").then(function() {
                return resolve(e("c0b8"));
            }.bind(null, e)).catch(e.oe);
        }, u = {
            components: {
                MgCell: c
            },
            props: {
                title: "",
                value: "",
                color: "",
                p: "",
                cname: "",
                sname: "",
                type: {
                    type: String,
                    default: "1"
                }
            },
            data: function() {
                return {};
            },
            computed: {
                cbVal: {
                    get: function() {
                        return this.value;
                    },
                    set: function(t) {
                        this.$emit("input", t);
                    }
                }
            },
            methods: {
                checkboxChange: function(t) {
                    this.cbVal = !this.cbVal;
                }
            }
        };
        n.default = u;
    },
    "3b91": function(t, n, e) {
        "use strict";
        e.r(n);
        var c = e("3919"), u = e.n(c);
        for (var o in c) "default" !== o && function(t) {
            e.d(n, t, function() {
                return c[t];
            });
        }(o);
        n["default"] = u.a;
    },
    "3ebe": function(t, n, e) {
        "use strict";
        var c = e("c39c"), u = e.n(c);
        u.a;
    },
    "414f": function(t, n, e) {
        "use strict";
        e.r(n);
        var c = e("b646"), u = e("3b91");
        for (var o in u) "default" !== o && function(t) {
            e.d(n, t, function() {
                return u[t];
            });
        }(o);
        e("3ebe");
        var r, a = e("f0c5"), i = Object(a["a"])(u["default"], c["b"], c["c"], !1, null, "47d92e60", null, !1, c["a"], r);
        n["default"] = i.exports;
    },
    b646: function(t, n, e) {
        "use strict";
        var c;
        e.d(n, "b", function() {
            return u;
        }), e.d(n, "c", function() {
            return o;
        }), e.d(n, "a", function() {
            return c;
        });
        var u = function() {
            var t = this, n = t.$createElement;
            t._self._c;
        }, o = [];
    },
    c39c: function(t, n, e) {}
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "components/form/mg-agree-create-component", {
    "components/form/mg-agree-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("414f"));
    }
}, [ [ "components/form/mg-agree-create-component" ] ] ]);