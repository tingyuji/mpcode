(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "components/form/mg-radio" ], {
    "02bf": function(t, e, n) {},
    6158: function(t, e, n) {
        "use strict";
        n.r(e);
        var a = n("9dae"), r = n("bff1");
        for (var u in r) "default" !== u && function(t) {
            n.d(e, t, function() {
                return r[t];
            });
        }(u);
        n("dada");
        var o, i = n("f0c5"), c = Object(i["a"])(r["default"], a["b"], a["c"], !1, null, "2d0b105f", null, !1, a["a"], o);
        e["default"] = c.exports;
    },
    "9dae": function(t, e, n) {
        "use strict";
        var a;
        n.d(e, "b", function() {
            return r;
        }), n.d(e, "c", function() {
            return u;
        }), n.d(e, "a", function() {
            return a;
        });
        var r = function() {
            var t = this, e = t.$createElement, n = (t._self._c, t.__get_style([ t.rsname ]));
            t.$mp.data = Object.assign({}, {
                $root: {
                    s0: n
                }
            });
        }, u = [];
    },
    bff1: function(t, e, n) {
        "use strict";
        n.r(e);
        var a = n("e3f3"), r = n.n(a);
        for (var u in a) "default" !== u && function(t) {
            n.d(e, t, function() {
                return a[t];
            });
        }(u);
        e["default"] = r.a;
    },
    dada: function(t, e, n) {
        "use strict";
        var a = n("02bf"), r = n.n(a);
        r.a;
    },
    e3f3: function(t, e, n) {
        "use strict";
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var a = function() {
            n.e("components/common/mg-cell").then(function() {
                return resolve(n("c0b8"));
            }.bind(null, n)).catch(n.oe);
        }, r = {
            components: {
                MgCell: a
            },
            props: {
                arr: "",
                value: "",
                color: "",
                rtype: {
                    type: String,
                    default: "1"
                },
                rsname: Object,
                ranktype: {
                    type: String,
                    default: "1"
                },
                bttc: {
                    type: String,
                    default: ""
                },
                last: {
                    type: String,
                    default: ""
                }
            },
            data: function() {
                return {
                    items: [],
                    current: ""
                };
            },
            computed: {
                radioVal: {
                    get: function() {
                        return this.value;
                    },
                    set: function(t) {
                        this.$emit("input", t);
                    }
                }
            },
            methods: {
                radioChange: function(t) {
                    this.radioVal = t.detail.value, this.$emit("change", t.detail.value);
                }
            }
        };
        e.default = r;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "components/form/mg-radio-create-component", {
    "components/form/mg-radio-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("6158"));
    }
}, [ [ "components/form/mg-radio-create-component" ] ] ]);