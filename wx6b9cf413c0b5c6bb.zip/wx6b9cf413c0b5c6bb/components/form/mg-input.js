(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "components/form/mg-input" ], {
    "00e9": function(t, e, n) {
        "use strict";
        var u = n("d6a4"), i = n.n(u);
        i.a;
    },
    "0689": function(t, e, n) {
        "use strict";
        n.r(e);
        var u = n("18d7"), i = n.n(u);
        for (var a in u) "default" !== a && function(t) {
            n.d(e, t, function() {
                return u[t];
            });
        }(a);
        e["default"] = i.a;
    },
    "18d7": function(t, e, n) {
        "use strict";
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var u = function() {
            n.e("components/common/mg-cell").then(function() {
                return resolve(n("c0b8"));
            }.bind(null, n)).catch(n.oe);
        }, i = {
            name: "mg-input",
            components: {
                MgCell: u
            },
            props: {
                cname: {
                    type: String,
                    default: "p23"
                },
                sname: "",
                last: "",
                iconn: {
                    type: String,
                    default: ""
                },
                formt: {
                    type: String,
                    default: "1"
                },
                hw: {
                    type: String,
                    default: ""
                },
                isl: {
                    type: String,
                    default: ""
                },
                isr: {
                    type: String,
                    default: ""
                },
                ht: {
                    type: String,
                    default: ""
                },
                htc: {
                    type: String,
                    default: ""
                },
                ft: {
                    type: String,
                    default: ""
                },
                ftc: {
                    type: String,
                    default: ""
                },
                arrow: {
                    type: String,
                    default: ""
                },
                dis: {
                    type: [ Boolean, String ],
                    default: !1
                },
                t: {
                    type: String,
                    default: "text"
                },
                value: {
                    type: String,
                    default: ""
                },
                icn: {
                    type: String,
                    default: ""
                },
                max: {
                    type: [ String, Number ],
                    default: 60
                },
                pr: {
                    type: String,
                    default: ""
                }
            },
            data: function() {
                return {};
            },
            computed: {
                inputVal: {
                    get: function() {
                        return this.value;
                    },
                    set: function(t) {
                        this.$emit("input", t);
                    }
                }
            },
            methods: {
                switchChange: function(t) {
                    this.$emit("input", t.detail.value ? "1" : "2"), console.log(t.detail.value);
                },
                maskTap: function() {
                    this.$emit("input", !1);
                }
            }
        };
        e.default = i;
    },
    "77d6": function(t, e, n) {
        "use strict";
        n.r(e);
        var u = n("b310"), i = n("0689");
        for (var a in i) "default" !== a && function(t) {
            n.d(e, t, function() {
                return i[t];
            });
        }(a);
        n("00e9");
        var r, l = n("f0c5"), f = Object(l["a"])(i["default"], u["b"], u["c"], !1, null, "2ab3c112", null, !1, u["a"], r);
        e["default"] = f.exports;
    },
    b310: function(t, e, n) {
        "use strict";
        var u;
        n.d(e, "b", function() {
            return i;
        }), n.d(e, "c", function() {
            return a;
        }), n.d(e, "a", function() {
            return u;
        });
        var i = function() {
            var t = this, e = t.$createElement;
            t._self._c;
        }, a = [];
    },
    d6a4: function(t, e, n) {}
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "components/form/mg-input-create-component", {
    "components/form/mg-input-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("77d6"));
    }
}, [ [ "components/form/mg-input-create-component" ] ] ]);