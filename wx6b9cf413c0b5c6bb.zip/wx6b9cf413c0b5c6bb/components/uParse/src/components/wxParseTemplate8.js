(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "components/uParse/src/components/wxParseTemplate8" ], {
    1658: function(e, n, t) {
        "use strict";
        t.r(n);
        var r = t("8786"), o = t("e625");
        for (var c in o) "default" !== c && function(e) {
            t.d(n, e, function() {
                return o[e];
            });
        }(c);
        var a, u = t("f0c5"), s = Object(u["a"])(o["default"], r["b"], r["c"], !1, null, null, null, !1, r["a"], a);
        n["default"] = s.exports;
    },
    8786: function(e, n, t) {
        "use strict";
        var r;
        t.d(n, "b", function() {
            return o;
        }), t.d(n, "c", function() {
            return c;
        }), t.d(n, "a", function() {
            return r;
        });
        var o = function() {
            var e = this, n = e.$createElement;
            e._self._c;
        }, c = [];
    },
    a858: function(e, n, t) {
        "use strict";
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), n.default = void 0;
        var r = function() {
            t.e("components/uParse/src/components/wxParseTemplate9").then(function() {
                return resolve(t("3c0d"));
            }.bind(null, t)).catch(t.oe);
        }, o = function() {
            t.e("components/uParse/src/components/wxParseImg").then(function() {
                return resolve(t("4df6"));
            }.bind(null, t)).catch(t.oe);
        }, c = function() {
            t.e("components/uParse/src/components/wxParseVideo").then(function() {
                return resolve(t("c861"));
            }.bind(null, t)).catch(t.oe);
        }, a = function() {
            t.e("components/uParse/src/components/wxParseAudio").then(function() {
                return resolve(t("cc9b"));
            }.bind(null, t)).catch(t.oe);
        }, u = {
            name: "wxParseTemplate8",
            props: {
                node: {}
            },
            components: {
                wxParseTemplate: r,
                wxParseImg: o,
                wxParseVideo: c,
                wxParseAudio: a
            },
            inject: [ "uparse" ],
            methods: {
                wxParseATap: function(e) {
                    var n = e.currentTarget.dataset.href;
                    n && this.uparse.navigate(n, e);
                }
            }
        };
        n.default = u;
    },
    e625: function(e, n, t) {
        "use strict";
        t.r(n);
        var r = t("a858"), o = t.n(r);
        for (var c in r) "default" !== c && function(e) {
            t.d(n, e, function() {
                return r[e];
            });
        }(c);
        n["default"] = o.a;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "components/uParse/src/components/wxParseTemplate8-create-component", {
    "components/uParse/src/components/wxParseTemplate8-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("1658"));
    }
}, [ [ "components/uParse/src/components/wxParseTemplate8-create-component" ] ] ]);