(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "components/uParse/src/components/wxParseTemplate1" ], {
    7296: function(e, n, t) {
        "use strict";
        var r;
        t.d(n, "b", function() {
            return o;
        }), t.d(n, "c", function() {
            return c;
        }), t.d(n, "a", function() {
            return r;
        });
        var o = function() {
            var e = this, n = e.$createElement;
            e._self._c;
        }, c = [];
    },
    a7ed: function(e, n, t) {
        "use strict";
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), n.default = void 0;
        var r = function() {
            t.e("components/uParse/src/components/wxParseTemplate2").then(function() {
                return resolve(t("9840"));
            }.bind(null, t)).catch(t.oe);
        }, o = function() {
            t.e("components/uParse/src/components/wxParseImg").then(function() {
                return resolve(t("4df6"));
            }.bind(null, t)).catch(t.oe);
        }, c = function() {
            t.e("components/uParse/src/components/wxParseVideo").then(function() {
                return resolve(t("c861"));
            }.bind(null, t)).catch(t.oe);
        }, a = function() {
            t.e("components/uParse/src/components/wxParseAudio").then(function() {
                return resolve(t("cc9b"));
            }.bind(null, t)).catch(t.oe);
        }, u = {
            name: "wxParseTemplate1",
            props: {
                node: {}
            },
            components: {
                wxParseTemplate: r,
                wxParseImg: o,
                wxParseVideo: c,
                wxParseAudio: a
            },
            inject: [ "uparse" ],
            methods: {
                wxParseATap: function(e) {
                    var n = e.currentTarget.dataset.href;
                    n && this.uparse.navigate(n, e);
                }
            }
        };
        n.default = u;
    },
    b89d: function(e, n, t) {
        "use strict";
        t.r(n);
        var r = t("7296"), o = t("c4f1");
        for (var c in o) "default" !== c && function(e) {
            t.d(n, e, function() {
                return o[e];
            });
        }(c);
        var a, u = t("f0c5"), s = Object(u["a"])(o["default"], r["b"], r["c"], !1, null, null, null, !1, r["a"], a);
        n["default"] = s.exports;
    },
    c4f1: function(e, n, t) {
        "use strict";
        t.r(n);
        var r = t("a7ed"), o = t.n(r);
        for (var c in r) "default" !== c && function(e) {
            t.d(n, e, function() {
                return r[e];
            });
        }(c);
        n["default"] = o.a;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "components/uParse/src/components/wxParseTemplate1-create-component", {
    "components/uParse/src/components/wxParseTemplate1-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("b89d"));
    }
}, [ [ "components/uParse/src/components/wxParseTemplate1-create-component" ] ] ]);