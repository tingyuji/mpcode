(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "components/uParse/src/components/wxParseTemplate2" ], {
    "432d": function(e, n, t) {
        "use strict";
        var r;
        t.d(n, "b", function() {
            return o;
        }), t.d(n, "c", function() {
            return a;
        }), t.d(n, "a", function() {
            return r;
        });
        var o = function() {
            var e = this, n = e.$createElement;
            e._self._c;
        }, a = [];
    },
    9840: function(e, n, t) {
        "use strict";
        t.r(n);
        var r = t("432d"), o = t("f888");
        for (var a in o) "default" !== a && function(e) {
            t.d(n, e, function() {
                return o[e];
            });
        }(a);
        var c, u = t("f0c5"), s = Object(u["a"])(o["default"], r["b"], r["c"], !1, null, null, null, !1, r["a"], c);
        n["default"] = s.exports;
    },
    a5af: function(e, n, t) {
        "use strict";
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), n.default = void 0;
        var r = function() {
            t.e("components/uParse/src/components/wxParseTemplate3").then(function() {
                return resolve(t("a119"));
            }.bind(null, t)).catch(t.oe);
        }, o = function() {
            t.e("components/uParse/src/components/wxParseImg").then(function() {
                return resolve(t("4df6"));
            }.bind(null, t)).catch(t.oe);
        }, a = function() {
            t.e("components/uParse/src/components/wxParseVideo").then(function() {
                return resolve(t("c861"));
            }.bind(null, t)).catch(t.oe);
        }, c = function() {
            t.e("components/uParse/src/components/wxParseAudio").then(function() {
                return resolve(t("cc9b"));
            }.bind(null, t)).catch(t.oe);
        }, u = {
            name: "wxParseTemplate2",
            props: {
                node: {}
            },
            components: {
                wxParseTemplate: r,
                wxParseImg: o,
                wxParseVideo: a,
                wxParseAudio: c
            },
            inject: [ "uparse" ],
            methods: {
                wxParseATap: function(e) {
                    var n = e.currentTarget.dataset.href;
                    n && this.uparse.navigate(n, e);
                }
            }
        };
        n.default = u;
    },
    f888: function(e, n, t) {
        "use strict";
        t.r(n);
        var r = t("a5af"), o = t.n(r);
        for (var a in r) "default" !== a && function(e) {
            t.d(n, e, function() {
                return r[e];
            });
        }(a);
        n["default"] = o.a;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "components/uParse/src/components/wxParseTemplate2-create-component", {
    "components/uParse/src/components/wxParseTemplate2-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("9840"));
    }
}, [ [ "components/uParse/src/components/wxParseTemplate2-create-component" ] ] ]);