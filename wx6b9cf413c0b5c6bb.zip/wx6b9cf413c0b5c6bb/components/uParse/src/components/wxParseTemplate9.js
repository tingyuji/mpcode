(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "components/uParse/src/components/wxParseTemplate9" ], {
    "151a": function(e, n, t) {
        "use strict";
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), n.default = void 0;
        var r = function() {
            t.e("components/uParse/src/components/wxParseTemplate10").then(function() {
                return resolve(t("5b60"));
            }.bind(null, t)).catch(t.oe);
        }, c = function() {
            t.e("components/uParse/src/components/wxParseImg").then(function() {
                return resolve(t("4df6"));
            }.bind(null, t)).catch(t.oe);
        }, o = function() {
            t.e("components/uParse/src/components/wxParseVideo").then(function() {
                return resolve(t("c861"));
            }.bind(null, t)).catch(t.oe);
        }, a = function() {
            t.e("components/uParse/src/components/wxParseAudio").then(function() {
                return resolve(t("cc9b"));
            }.bind(null, t)).catch(t.oe);
        }, u = {
            name: "wxParseTemplate9",
            props: {
                node: {}
            },
            components: {
                wxParseTemplate: r,
                wxParseImg: c,
                wxParseVideo: o,
                wxParseAudio: a
            },
            inject: [ "uparse" ],
            methods: {
                wxParseATap: function(e) {
                    var n = e.currentTarget.dataset.href;
                    n && this.uparse.navigate(n, e);
                }
            }
        };
        n.default = u;
    },
    "3c0d": function(e, n, t) {
        "use strict";
        t.r(n);
        var r = t("4f5e3"), c = t("ca1c");
        for (var o in c) "default" !== o && function(e) {
            t.d(n, e, function() {
                return c[e];
            });
        }(o);
        var a, u = t("f0c5"), s = Object(u["a"])(c["default"], r["b"], r["c"], !1, null, null, null, !1, r["a"], a);
        n["default"] = s.exports;
    },
    "4f5e3": function(e, n, t) {
        "use strict";
        var r;
        t.d(n, "b", function() {
            return c;
        }), t.d(n, "c", function() {
            return o;
        }), t.d(n, "a", function() {
            return r;
        });
        var c = function() {
            var e = this, n = e.$createElement;
            e._self._c;
        }, o = [];
    },
    ca1c: function(e, n, t) {
        "use strict";
        t.r(n);
        var r = t("151a"), c = t.n(r);
        for (var o in r) "default" !== o && function(e) {
            t.d(n, e, function() {
                return r[e];
            });
        }(o);
        n["default"] = c.a;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "components/uParse/src/components/wxParseTemplate9-create-component", {
    "components/uParse/src/components/wxParseTemplate9-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("3c0d"));
    }
}, [ [ "components/uParse/src/components/wxParseTemplate9-create-component" ] ] ]);