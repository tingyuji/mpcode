(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "components/drag/custom-video" ], {
    "5f45": function(t, n, e) {
        "use strict";
        e.r(n);
        var r = e("f85e"), u = e.n(r);
        for (var o in r) "default" !== o && function(t) {
            e.d(n, t, function() {
                return r[t];
            });
        }(o);
        n["default"] = u.a;
    },
    9702: function(t, n, e) {
        "use strict";
        var r;
        e.d(n, "b", function() {
            return u;
        }), e.d(n, "c", function() {
            return o;
        }), e.d(n, "a", function() {
            return r;
        });
        var u = function() {
            var t = this, n = t.$createElement;
            t._self._c;
        }, o = [];
    },
    a768: function(t, n, e) {
        "use strict";
        e.r(n);
        var r = e("9702"), u = e("5f45");
        for (var o in u) "default" !== o && function(t) {
            e.d(n, t, function() {
                return u[t];
            });
        }(o);
        var a, c = e("f0c5"), i = Object(c["a"])(u["default"], r["b"], r["c"], !1, null, "aa3df81e", null, !1, r["a"], a);
        n["default"] = i.exports;
    },
    f85e: function(t, n, e) {
        "use strict";
        (function(t) {
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var r = u(e("a34a"));
            e("26cb");
            function u(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            function o(t, n, e, r, u, o, a) {
                try {
                    var c = t[o](a), i = c.value;
                } catch (f) {
                    return void e(f);
                }
                c.done ? n(i) : Promise.resolve(i).then(r, u);
            }
            function a(t) {
                return function() {
                    var n = this, e = arguments;
                    return new Promise(function(r, u) {
                        var a = t.apply(n, e);
                        function c(t) {
                            o(a, r, u, c, i, "next", t);
                        }
                        function i(t) {
                            o(a, r, u, c, i, "throw", t);
                        }
                        c(void 0);
                    });
                };
            }
            var c = {
                name: "searchBox",
                props: {
                    co: {
                        type: Object,
                        default: function() {
                            return {
                                icon: [ {
                                    url: ""
                                } ],
                                topMargin: 0,
                                videocon: {
                                    links: "",
                                    title: "视频名"
                                }
                            };
                        }
                    },
                    u: {
                        type: String,
                        default: "px"
                    },
                    color: {
                        type: String,
                        default: ""
                    }
                },
                data: function() {
                    return {};
                },
                methods: {
                    videoErrorCallback: function(n) {
                        t.showModal({
                            content: n.target.errMsg,
                            showCancel: !1
                        });
                    }
                },
                created: function() {
                    return a(r.default.mark(function t() {
                        return r.default.wrap(function(t) {
                            while (1) switch (t.prev = t.next) {
                              case 0:
                              case "end":
                                return t.stop();
                            }
                        }, t);
                    }))();
                }
            };
            n.default = c;
        }).call(this, e("543d")["default"]);
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "components/drag/custom-video-create-component", {
    "components/drag/custom-video-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("a768"));
    }
}, [ [ "components/drag/custom-video-create-component" ] ] ]);