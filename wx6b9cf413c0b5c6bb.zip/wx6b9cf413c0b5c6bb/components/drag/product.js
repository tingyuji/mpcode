(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "components/drag/product" ], {
    "2cbd": function(t, e, n) {
        "use strict";
        var o = n("80e1"), r = n.n(o);
        r.a;
    },
    "4cf0": function(t, e, n) {
        "use strict";
        n.r(e);
        var o = n("c364"), r = n("a542");
        for (var c in r) "default" !== c && function(t) {
            n.d(e, t, function() {
                return r[t];
            });
        }(c);
        n("2cbd");
        var u, i = n("f0c5"), a = Object(i["a"])(r["default"], o["b"], o["c"], !1, null, "16cbdd2b", null, !1, o["a"], u);
        e["default"] = a.exports;
    },
    "80e1": function(t, e, n) {},
    "83f3": function(t, e, n) {
        "use strict";
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var o = r(n("a34a"));
        n("26cb");
        function r(t) {
            return t && t.__esModule ? t : {
                default: t
            };
        }
        function c(t, e) {
            var n = Object.keys(t);
            if (Object.getOwnPropertySymbols) {
                var o = Object.getOwnPropertySymbols(t);
                e && (o = o.filter(function(e) {
                    return Object.getOwnPropertyDescriptor(t, e).enumerable;
                })), n.push.apply(n, o);
            }
            return n;
        }
        function u(t) {
            for (var e = 1; e < arguments.length; e++) {
                var n = null != arguments[e] ? arguments[e] : {};
                e % 2 ? c(Object(n), !0).forEach(function(e) {
                    i(t, e, n[e]);
                }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : c(Object(n)).forEach(function(e) {
                    Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e));
                });
            }
            return t;
        }
        function i(t, e, n) {
            return e in t ? Object.defineProperty(t, e, {
                value: n,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : t[e] = n, t;
        }
        function a(t, e, n, o, r, c, u) {
            try {
                var i = t[c](u), a = i.value;
            } catch (s) {
                return void n(s);
            }
            i.done ? e(a) : Promise.resolve(a).then(o, r);
        }
        function s(t) {
            return function() {
                var e = this, n = arguments;
                return new Promise(function(o, r) {
                    var c = t.apply(e, n);
                    function u(t) {
                        a(c, o, r, u, i, "next", t);
                    }
                    function i(t) {
                        a(c, o, r, u, i, "throw", t);
                    }
                    u(void 0);
                });
            };
        }
        var d = function() {
            n.e("components/common/jzz").then(function() {
                return resolve(n("70be"));
            }.bind(null, n)).catch(n.oe);
        }, p = {
            name: "product",
            components: {
                jzz: d
            },
            props: {
                type: {
                    type: String,
                    default: "1"
                },
                co: {
                    type: Object,
                    default: function() {
                        return {};
                    }
                },
                u: {
                    type: String,
                    default: "px"
                },
                shopinfo: Object
            },
            data: function() {
                return {
                    list: [],
                    isget: !1
                };
            },
            watch: {
                shopinfo: {
                    handler: function(t) {
                        if (t.id) if (1 == this.co.typeProduct && this.co.productName && this.co.productName.length) {
                            var e = this.co.productName.map(function(t) {
                                return t.name.id;
                            }).toString();
                            this.getData({
                                type: 1,
                                ids: e
                            }), console.log("商品组", e);
                        } else 2 == this.co.typeProduct && this.co.productGroup && this.co.productGroup.length ? this.co.productGroup[0].name.pid > 0 ? (this.getData({
                            type: 2,
                            pid: this.co.productGroup[0].name.pid,
                            id: this.co.productGroup[0].name.id,
                            num: this.co.productNum
                        }), console.log("商品组2级分类")) : (this.getData({
                            type: 2,
                            pid: this.co.productGroup[0].name.id,
                            num: this.co.productNum
                        }), console.log("商品组1级分类")) : 3 == this.co.typeProduct && this.getData({
                            type: 3,
                            ranktype: this.co.productMarket,
                            num: this.co.productNum
                        });
                    },
                    immediate: !0
                }
            },
            methods: {
                getData: function(t) {
                    var e = this;
                    return s(o.default.mark(function n() {
                        var r, c;
                        return o.default.wrap(function(n) {
                            while (1) switch (n.prev = n.next) {
                              case 0:
                                return n.next = 2, e.util.request({
                                    url: e.api.tzssp,
                                    method: "POST",
                                    data: u(u({}, t), {}, {
                                        storeId: e.shopinfo.id
                                    })
                                });

                              case 2:
                                r = n.sent, c = r.data, e.list = c, e.isget = !0;

                              case 6:
                              case "end":
                                return n.stop();
                            }
                        }, n);
                    }))();
                },
                goodinfo: function(t) {
                    this.go({
                        t: 1,
                        url: "/yb_wm/shop/out/goods-dl?gid=".concat(t, "&storeId=").concat(this.shopinfo.id, "&page=index")
                    });
                }
            },
            created: function() {}
        };
        e.default = p;
    },
    a542: function(t, e, n) {
        "use strict";
        n.r(e);
        var o = n("83f3"), r = n.n(o);
        for (var c in o) "default" !== c && function(t) {
            n.d(e, t, function() {
                return o[t];
            });
        }(c);
        e["default"] = r.a;
    },
    c364: function(t, e, n) {
        "use strict";
        var o;
        n.d(e, "b", function() {
            return r;
        }), n.d(e, "c", function() {
            return c;
        }), n.d(e, "a", function() {
            return o;
        });
        var r = function() {
            var t = this, e = t.$createElement;
            t._self._c;
        }, c = [];
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "components/drag/product-create-component", {
    "components/drag/product-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("4cf0"));
    }
}, [ [ "components/drag/product-create-component" ] ] ]);