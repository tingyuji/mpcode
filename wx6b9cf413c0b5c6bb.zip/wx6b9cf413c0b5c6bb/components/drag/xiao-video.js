(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "components/drag/xiao-video" ], {
    "54a8": function(t, e, n) {
        "use strict";
        n.r(e);
        var i = n("a4f7"), a = n("a214");
        for (var o in a) "default" !== o && function(t) {
            n.d(e, t, function() {
                return a[t];
            });
        }(o);
        n("954c");
        var c, l = n("f0c5"), u = Object(l["a"])(a["default"], i["b"], i["c"], !1, null, "66417b6e", null, !1, i["a"], c);
        e["default"] = u.exports;
    },
    9062: function(t, e, n) {
        "use strict";
        (function(t) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var n = {
                data: function() {
                    return {
                        item: {},
                        videoContext: {},
                        VodLoadText: "正在解析影片请稍等",
                        isShowControl: !1,
                        fill: "contain",
                        playbackRateIndex: 2,
                        playbackRateList: [ "0.5", "0.8", "1.0", "1.2", "1.5", "2.0" ],
                        currentTimeVod: 0
                    };
                },
                props: {
                    src: {
                        type: String,
                        default: ""
                    },
                    co: {
                        type: Object,
                        default: function() {
                            return {};
                        }
                    }
                },
                mounted: function() {},
                onReady: function(e) {
                    this.videoContext = t.createVideoContext("myVideo", this);
                },
                methods: {
                    loadedmetadata: function(t) {
                        this.VodLoadText = "";
                    },
                    speed: function(t) {
                        "jia" == t ? this.videoContext.seek(parseInt(this.currentTimeVod) + 20) : this.videoContext.seek(parseInt(this.currentTimeVod) - 20);
                    },
                    fullscreenchange: function(t) {
                        console.log(t);
                    },
                    fullscreenclick: function(t) {
                        console.log(t);
                    },
                    waiting: function(t) {
                        this.VodLoadText = "缓存中请稍等";
                    },
                    timeupdate: function(t) {
                        this.VodLoadText = "", this.currentTimeVod = t.detail.currentTime;
                    },
                    controlstoggle: function(t) {
                        t.detail.show ? this.isShowControl = !0 : this.isShowControl = !1;
                    },
                    fillTap: function() {
                        "fill" == this.fill ? this.fill = "contain" : this.fill = "fill";
                    },
                    playbackRate: function() {
                        if (this.playbackRateIndex == this.playbackRateList.length - 1) return this.playbackRateIndex = 0, 
                        void this.videoContext.playbackRate(Number(this.playbackRateList[this.playbackRateIndex]));
                        this.playbackRateIndex++, this.videoContext.playbackRate(Number(this.playbackRateList[this.playbackRateIndex]));
                    }
                }
            };
            e.default = n;
        }).call(this, n("543d")["default"]);
    },
    "954c": function(t, e, n) {
        "use strict";
        var i = n("b22c"), a = n.n(i);
        a.a;
    },
    a214: function(t, e, n) {
        "use strict";
        n.r(e);
        var i = n("9062"), a = n.n(i);
        for (var o in i) "default" !== o && function(t) {
            n.d(e, t, function() {
                return i[t];
            });
        }(o);
        e["default"] = a.a;
    },
    a4f7: function(t, e, n) {
        "use strict";
        var i;
        n.d(e, "b", function() {
            return a;
        }), n.d(e, "c", function() {
            return o;
        }), n.d(e, "a", function() {
            return i;
        });
        var a = function() {
            var t = this, e = t.$createElement;
            t._self._c;
        }, o = [];
    },
    b22c: function(t, e, n) {}
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "components/drag/xiao-video-create-component", {
    "components/drag/xiao-video-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("54a8"));
    }
}, [ [ "components/drag/xiao-video-create-component" ] ] ]);