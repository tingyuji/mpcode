(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "components/drag/margic" ], {
    "0082": function(t, n, e) {
        "use strict";
        e.r(n);
        var u = e("d52c"), r = e("5822");
        for (var c in r) "default" !== c && function(t) {
            e.d(n, t, function() {
                return r[t];
            });
        }(c);
        e("f797");
        var a, f = e("f0c5"), o = Object(f["a"])(r["default"], u["b"], u["c"], !1, null, "009411b6", null, !1, u["a"], a);
        n["default"] = o.exports;
    },
    5822: function(t, n, e) {
        "use strict";
        e.r(n);
        var u = e("ff05"), r = e.n(u);
        for (var c in u) "default" !== c && function(t) {
            e.d(n, t, function() {
                return u[t];
            });
        }(c);
        n["default"] = r.a;
    },
    d52c: function(t, n, e) {
        "use strict";
        var u;
        e.d(n, "b", function() {
            return r;
        }), e.d(n, "c", function() {
            return c;
        }), e.d(n, "a", function() {
            return u;
        });
        var r = function() {
            var t = this, n = t.$createElement;
            t._self._c;
        }, c = [];
    },
    e00a: function(t, n, e) {},
    f797: function(t, n, e) {
        "use strict";
        var u = e("e00a"), r = e.n(u);
        r.a;
    },
    ff05: function(t, n, e) {
        "use strict";
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), n.default = void 0;
        var u = {
            name: "margic",
            props: {
                co: {
                    type: Object,
                    default: function() {
                        return {};
                    }
                },
                u: {
                    type: String,
                    default: "px"
                }
            },
            data: function() {
                return {};
            },
            computed: {
                imgH: function() {
                    return 2 * this.co.height + "rpx";
                }
            },
            methods: {
                goTo: function(t) {
                    this.goUrl(t.url, t);
                }
            }
        };
        n.default = u;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "components/drag/margic-create-component", {
    "components/drag/margic-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("0082"));
    }
}, [ [ "components/drag/margic-create-component" ] ] ]);