(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "components/drag/picLunbo" ], {
    "400e": function(t, e, n) {
        "use strict";
        var r;
        n.d(e, "b", function() {
            return i;
        }), n.d(e, "c", function() {
            return u;
        }), n.d(e, "a", function() {
            return r;
        });
        var i = function() {
            var t = this, e = t.$createElement, n = (t._self._c, t.list.length && "px" == t.u ? t.getSjgd(t.co.height) : null);
            t.$mp.data = Object.assign({}, {
                $root: {
                    m0: n
                }
            });
        }, u = [];
    },
    "56fa": function(t, e, n) {
        "use strict";
        n.r(e);
        var r = n("400e"), i = n("cfa7");
        for (var u in i) "default" !== u && function(t) {
            n.d(e, t, function() {
                return i[t];
            });
        }(u);
        n("c977");
        var a, o = n("f0c5"), c = Object(o["a"])(i["default"], r["b"], r["c"], !1, null, "d61ac4d4", null, !1, r["a"], a);
        e["default"] = c.exports;
    },
    a455: function(t, e, n) {},
    c977: function(t, e, n) {
        "use strict";
        var r = n("a455"), i = n.n(r);
        i.a;
    },
    cfa7: function(t, e, n) {
        "use strict";
        n.r(e);
        var r = n("d603"), i = n.n(r);
        for (var u in r) "default" !== u && function(t) {
            n.d(e, t, function() {
                return r[t];
            });
        }(u);
        e["default"] = i.a;
    },
    d603: function(t, e, n) {
        "use strict";
        (function(t) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var r = i(n("a34a"));
            n("26cb");
            function i(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            function u(t, e, n, r, i, u, a) {
                try {
                    var o = t[u](a), c = o.value;
                } catch (l) {
                    return void n(l);
                }
                o.done ? e(c) : Promise.resolve(c).then(r, i);
            }
            function a(t) {
                return function() {
                    var e = this, n = arguments;
                    return new Promise(function(r, i) {
                        var a = t.apply(e, n);
                        function o(t) {
                            u(a, r, i, o, c, "next", t);
                        }
                        function c(t) {
                            u(a, r, i, o, c, "throw", t);
                        }
                        o(void 0);
                    });
                };
            }
            var o = {
                name: "picLunbo",
                props: {
                    co: {
                        type: Object,
                        default: function() {
                            return {};
                        }
                    },
                    storeInfo: {
                        type: Object,
                        default: function() {
                            return {};
                        }
                    },
                    u: {
                        type: String,
                        default: "px"
                    },
                    color: {
                        type: String,
                        default: ""
                    }
                },
                data: function() {
                    return {
                        StoreAd: []
                    };
                },
                computed: {
                    list: function() {
                        return 1 != this.co.reverseThree ? this.co.imgUrl || [] : this.StoreAd;
                    }
                },
                watch: {
                    storeInfo: {
                        handler: function(t) {
                            var e = this;
                            return a(r.default.mark(function t() {
                                var n, i;
                                return r.default.wrap(function(t) {
                                    while (1) switch (t.prev = t.next) {
                                      case 0:
                                        if (!e.storeInfo.id || 1 != e.co.reverseThree) {
                                            t.next = 6;
                                            break;
                                        }
                                        return t.next = 3, e.util.request({
                                            url: e.api.StoreAd,
                                            data: {
                                                type: 1,
                                                storeId: e.storeInfo.id
                                            }
                                        });

                                      case 3:
                                        n = t.sent, i = n.data, e.StoreAd = i;

                                      case 6:
                                      case "end":
                                        return t.stop();
                                    }
                                }, t);
                            }))();
                        },
                        immediate: !0
                    }
                },
                methods: {
                    goTo: function(e, n) {
                        var r = this.list[e];
                        if (r.url) this.goUrl(r.url, r); else if (r.link) switch (r.link.type) {
                          case "webUrl":
                            this.go({
                                t: 1,
                                url: "/yb_o2o/other/web-view?src=" + encodeURIComponent(JSON.stringify(r.link.url))
                            });
                            break;

                          case "miniUrl":
                            t.navigateTo({
                                url: r.link.url
                            });
                            break;

                          case "mini":
                            t.navigateToMiniProgram({
                                appId: r.link.url,
                                path: r.link.xcx_name
                            });
                            break;
                        } else if ("" == r.url) {
                            var i = this.list.map(function(t) {
                                return t.img;
                            });
                            t.previewImage({
                                current: e,
                                urls: i
                            });
                        }
                    }
                }
            };
            e.default = o;
        }).call(this, n("543d")["default"]);
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "components/drag/picLunbo-create-component", {
    "components/drag/picLunbo-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("56fa"));
    }
}, [ [ "components/drag/picLunbo-create-component" ] ] ]);