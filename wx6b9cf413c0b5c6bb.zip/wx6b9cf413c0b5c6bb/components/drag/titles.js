(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "components/drag/titles" ], {
    "07c5": function(t, n, e) {
        "use strict";
        e.r(n);
        var u = e("498d"), r = e("9c4d");
        for (var a in r) "default" !== a && function(t) {
            e.d(n, t, function() {
                return r[t];
            });
        }(a);
        e("a8a5");
        var c, o = e("f0c5"), f = Object(o["a"])(r["default"], u["b"], u["c"], !1, null, "77c55ae7", null, !1, u["a"], c);
        n["default"] = f.exports;
    },
    "498d": function(t, n, e) {
        "use strict";
        var u;
        e.d(n, "b", function() {
            return r;
        }), e.d(n, "c", function() {
            return a;
        }), e.d(n, "a", function() {
            return u;
        });
        var r = function() {
            var t = this, n = t.$createElement;
            t._self._c;
        }, a = [];
    },
    "7d1d": function(t, n, e) {},
    "9c4d": function(t, n, e) {
        "use strict";
        e.r(n);
        var u = e("f766"), r = e.n(u);
        for (var a in u) "default" !== a && function(t) {
            e.d(n, t, function() {
                return u[t];
            });
        }(a);
        n["default"] = r.a;
    },
    a8a5: function(t, n, e) {
        "use strict";
        var u = e("7d1d"), r = e.n(u);
        r.a;
    },
    f766: function(t, n, e) {
        "use strict";
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), n.default = void 0;
        var u = {
            name: "titles",
            props: {
                co: {
                    type: Object,
                    default: function() {
                        return {};
                    }
                },
                u: {
                    type: String,
                    default: "px"
                }
            },
            data: function() {
                return {};
            },
            methods: {
                goLink: function(t) {
                    this.goUrl(t.url);
                }
            },
            created: function() {}
        };
        n.default = u;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "components/drag/titles-create-component", {
    "components/drag/titles-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("07c5"));
    }
}, [ [ "components/drag/titles-create-component" ] ] ]);