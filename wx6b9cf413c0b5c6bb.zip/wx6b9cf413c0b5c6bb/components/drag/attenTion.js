(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "components/drag/attenTion" ], {
    3693: function(t, e, n) {
        "use strict";
        var r = n("de6a"), o = n.n(r);
        o.a;
    },
    4012: function(t, e, n) {
        "use strict";
        (function(t) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var r = n("26cb");
            function o(t, e) {
                var n = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(t);
                    e && (r = r.filter(function(e) {
                        return Object.getOwnPropertyDescriptor(t, e).enumerable;
                    })), n.push.apply(n, r);
                }
                return n;
            }
            function c(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var n = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? o(Object(n), !0).forEach(function(e) {
                        u(t, e, n[e]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : o(Object(n)).forEach(function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e));
                    });
                }
                return t;
            }
            function u(t, e, n) {
                return e in t ? Object.defineProperty(t, e, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[e] = n, t;
            }
            var a = {
                name: "attenTion",
                components: {},
                props: [ "co" ],
                data: function() {
                    return {};
                },
                methods: {
                    close: function() {
                        this.$store.state.config.showTips = !1, t.setStorageSync("tips", !0);
                    }
                },
                computed: c({}, (0, r.mapState)({
                    showTips: function(t) {
                        return t.config.showTips;
                    }
                }))
            };
            e.default = a;
        }).call(this, n("543d")["default"]);
    },
    "62bf": function(t, e, n) {
        "use strict";
        n.r(e);
        var r = n("4012"), o = n.n(r);
        for (var c in r) "default" !== c && function(t) {
            n.d(e, t, function() {
                return r[t];
            });
        }(c);
        e["default"] = o.a;
    },
    a36e: function(t, e, n) {
        "use strict";
        var r;
        n.d(e, "b", function() {
            return o;
        }), n.d(e, "c", function() {
            return c;
        }), n.d(e, "a", function() {
            return r;
        });
        var o = function() {
            var t = this, e = t.$createElement, n = (t._self._c, t.showTips ? t.util.getSb() : null);
            t.$mp.data = Object.assign({}, {
                $root: {
                    g0: n
                }
            });
        }, c = [];
    },
    cd9b: function(t, e, n) {
        "use strict";
        n.r(e);
        var r = n("a36e"), o = n("62bf");
        for (var c in o) "default" !== c && function(t) {
            n.d(e, t, function() {
                return o[t];
            });
        }(c);
        n("3693");
        var u, a = n("f0c5"), i = Object(a["a"])(o["default"], r["b"], r["c"], !1, null, "c603e9ca", null, !1, r["a"], u);
        e["default"] = i.exports;
    },
    de6a: function(t, e, n) {}
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "components/drag/attenTion-create-component", {
    "components/drag/attenTion-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("cd9b"));
    }
}, [ [ "components/drag/attenTion-create-component" ] ] ]);