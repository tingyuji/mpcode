(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "components/drag/vipModule" ], {
    1846: function(t, e, n) {
        "use strict";
        var r = n("9b10"), i = n.n(r);
        i.a;
    },
    "234f": function(t, e, n) {
        "use strict";
        var r;
        n.d(e, "b", function() {
            return i;
        }), n.d(e, "c", function() {
            return o;
        }), n.d(e, "a", function() {
            return r;
        });
        var i = function() {
            var t = this, e = t.$createElement, n = (t._self._c, t.isLogin && "1" == t.co.templateType && t.user.userName.length > 6 ? t.user.userName.substring(0, 6) : null), r = t.isLogin && "2" == t.co.templateType && t.user.userName.length > 6 ? t.user.userName.substring(0, 6) : null, i = t.isLogin && "2" == t.co.templateType ? t.__map(t.myData, function(e, n) {
                var r = t.__get_orig(e), i = e.hide ? null : t.returnWidth();
                return {
                    $orig: r,
                    m0: i
                };
            }) : null, o = t.isLogin && "3" == t.co.templateType ? t.returnHeight() : null, u = t.isLogin && "3" == t.co.templateType ? t.returnWidth() : null, a = t.isLogin && "3" == t.co.templateType ? t.returnWidth() : null, s = t.isLogin && "4" == t.co.templateType && t.user.userName.length > 6 ? t.user.userName.substring(0, 6) : null;
            t.$mp.data = Object.assign({}, {
                $root: {
                    g0: n,
                    g1: r,
                    l0: i,
                    m1: o,
                    m2: u,
                    m3: a,
                    g2: s
                }
            });
        }, o = [];
    },
    "2c88": function(t, e, n) {
        "use strict";
        n.r(e);
        var r = n("a95cc"), i = n.n(r);
        for (var o in r) "default" !== o && function(t) {
            n.d(e, t, function() {
                return r[t];
            });
        }(o);
        e["default"] = i.a;
    },
    "9b10": function(t, e, n) {},
    a41d: function(t, e, n) {
        "use strict";
        n.r(e);
        var r = n("234f"), i = n("2c88");
        for (var o in i) "default" !== o && function(t) {
            n.d(e, t, function() {
                return i[t];
            });
        }(o);
        n("1846");
        var u, a = n("f0c5"), s = Object(a["a"])(i["default"], r["b"], r["c"], !1, null, "23aa8f2e", null, !1, r["a"], u);
        e["default"] = s.exports;
    },
    a95cc: function(t, e, n) {
        "use strict";
        (function(t) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var r = o(n("a34a")), i = (o(n("e1c0")), n("26cb"));
            function o(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            function u(t, e) {
                var n;
                if ("undefined" === typeof Symbol || null == t[Symbol.iterator]) {
                    if (Array.isArray(t) || (n = a(t)) || e && t && "number" === typeof t.length) {
                        n && (t = n);
                        var r = 0, i = function() {};
                        return {
                            s: i,
                            n: function() {
                                return r >= t.length ? {
                                    done: !0
                                } : {
                                    done: !1,
                                    value: t[r++]
                                };
                            },
                            e: function(t) {
                                throw t;
                            },
                            f: i
                        };
                    }
                    throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
                }
                var o, u = !0, s = !1;
                return {
                    s: function() {
                        n = t[Symbol.iterator]();
                    },
                    n: function() {
                        var t = n.next();
                        return u = t.done, t;
                    },
                    e: function(t) {
                        s = !0, o = t;
                    },
                    f: function() {
                        try {
                            u || null == n.return || n.return();
                        } finally {
                            if (s) throw o;
                        }
                    }
                };
            }
            function a(t, e) {
                if (t) {
                    if ("string" === typeof t) return s(t, e);
                    var n = Object.prototype.toString.call(t).slice(8, -1);
                    return "Object" === n && t.constructor && (n = t.constructor.name), "Map" === n || "Set" === n ? Array.from(t) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? s(t, e) : void 0;
                }
            }
            function s(t, e) {
                (null == e || e > t.length) && (e = t.length);
                for (var n = 0, r = new Array(e); n < e; n++) r[n] = t[n];
                return r;
            }
            function c(t, e, n, r, i, o, u) {
                try {
                    var a = t[o](u), s = a.value;
                } catch (c) {
                    return void n(c);
                }
                a.done ? e(s) : Promise.resolve(s).then(r, i);
            }
            function l(t) {
                return function() {
                    var e = this, n = arguments;
                    return new Promise(function(r, i) {
                        var o = t.apply(e, n);
                        function u(t) {
                            c(o, r, i, u, a, "next", t);
                        }
                        function a(t) {
                            c(o, r, i, u, a, "throw", t);
                        }
                        u(void 0);
                    });
                };
            }
            function f(t, e) {
                var n = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(t);
                    e && (r = r.filter(function(e) {
                        return Object.getOwnPropertyDescriptor(t, e).enumerable;
                    })), n.push.apply(n, r);
                }
                return n;
            }
            function p(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var n = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? f(Object(n), !0).forEach(function(e) {
                        d(t, e, n[e]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : f(Object(n)).forEach(function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e));
                    });
                }
                return t;
            }
            function d(t, e, n) {
                return e in t ? Object.defineProperty(t, e, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[e] = n, t;
            }
            var g = {
                name: "vipModule",
                props: {
                    co: {
                        type: Object,
                        default: function() {
                            return {};
                        }
                    },
                    u: {
                        type: String,
                        default: "px"
                    },
                    color: {
                        type: String,
                        default: ""
                    }
                },
                data: function() {
                    return {
                        vipInfo: {},
                        vip_name: "普通会员",
                        c_growth: 0,
                        next_info: {
                            name: "",
                            condition: 0
                        },
                        jindu: 0,
                        viparr: [],
                        privilegeTotal: 0,
                        imgHeight: ""
                    };
                },
                computed: p(p({}, (0, i.mapState)({
                    vipset: function(t) {
                        return t.config.vipset;
                    }
                })), {}, {
                    myData: function() {
                        return [ {
                            hide: "false" == this.co.btnStatus[0].toString(),
                            num: this.user.integral || 0,
                            name: this.system.custom.integral,
                            url: "/yb_wm/my/integral/my-integral",
                            explain: "explain1"
                        }, {
                            hide: "false" == this.co.btnStatus[1].toString(),
                            num: this.user.balance || 0,
                            name: this.system.custom.balance,
                            url: "/yb_wm/other/recharge/yesy",
                            explain: "explain2"
                        }, {
                            hide: "false" == this.co.btnStatus[2].toString(),
                            num: this.user.couponNum || 0,
                            name: "优惠券",
                            url: "/yb_wm/my/coupon/my",
                            explain: "explain3"
                        } ];
                    }
                }),
                created: function() {
                    this.getDjlb(), this.getPrivilege();
                },
                mounted: function() {
                    this.returnHeight();
                },
                methods: {
                    getPrivilege: function() {
                        var t = this;
                        return l(r.default.mark(function e() {
                            var n, i;
                            return r.default.wrap(function(e) {
                                while (1) switch (e.prev = e.next) {
                                  case 0:
                                    return e.next = 2, t.util.request({
                                        url: t.api.ffhykqy
                                    });

                                  case 2:
                                    n = e.sent, i = n.data, t.privilegeTotal = i.length;

                                  case 5:
                                  case "end":
                                    return e.stop();
                                }
                            }, e);
                        }))();
                    },
                    returnHeight: function() {
                        var e = this;
                        this.$nextTick(function() {
                            setTimeout(function() {
                                var n = t.createSelectorQuery().in(e).select(".left_out");
                                n.boundingClientRect(function(t) {
                                    e.imgHeight = null === t || void 0 === t ? void 0 : t.height;
                                }).exec();
                            }, 500);
                        });
                    },
                    returnWidth: function() {
                        var t, e = 0, n = u(this.co.btnStatus);
                        try {
                            for (n.s(); !(t = n.n()).done; ) {
                                var r = t.value;
                                r && e++;
                            }
                        } catch (i) {
                            n.e(i);
                        } finally {
                            n.f();
                        }
                        return {
                            width: 100 / e + "%",
                            num: e
                        };
                    },
                    nextTo: function(t) {
                        console.log("url", t), this.go({
                            t: 1,
                            url: t
                        });
                    },
                    goTo: function(t) {
                        t.url.params || (t.url = JSON.parse(t.url)), this.goUrl(t.url, t);
                    },
                    getDjlb: function() {
                        var t = this;
                        return l(r.default.mark(function e() {
                            var n, i, o;
                            return r.default.wrap(function(e) {
                                while (1) switch (e.prev = e.next) {
                                  case 0:
                                    return e.next = 2, t.util.request({
                                        url: t.api.hydj
                                    });

                                  case 2:
                                    n = e.sent, i = n.data, t.viparr = i, t.$store.state.user.cardName && (t.vip_name = t.$store.state.user.cardName), 
                                    t.$store.state.user.level ? (o = parseInt(t.$store.state.user.level), t.viparr[o] ? (t.next_info = t.viparr[o], 
                                    t.c_growth = parseInt(t.next_info.condition) - parseInt(t.$store.state.user.growth), 
                                    t.jindu = parseInt(t.$store.state.user.growth) / t.next_info.condition, t.jindu = 100 * t.jindu.toFixed(2), 
                                    t.jindu > 100 && (t.jindu = 100)) : (t.jindu = 100, t.next_info = t.viparr[t.viparr.length - 1], 
                                    t.c_growth = parseInt(t.next_info.condition) - parseInt(t.$store.state.user.growth))) : (t.next_info = t.viparr[0], 
                                    t.c_growth = parseInt(t.next_info.condition) - parseInt(t.$store.state.user.growth), 
                                    t.jindu = parseInt(t.$store.state.user.growth) / t.next_info.condition, t.jindu = 100 * t.jindu.toFixed(2), 
                                    t.jindu > 100 && (t.jindu = 100));

                                  case 7:
                                  case "end":
                                    return e.stop();
                                }
                            }, e);
                        }))();
                    }
                }
            };
            e.default = g;
        }).call(this, n("543d")["default"]);
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "components/drag/vipModule-create-component", {
    "components/drag/vipModule-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("a41d"));
    }
}, [ [ "components/drag/vipModule-create-component" ] ] ]);