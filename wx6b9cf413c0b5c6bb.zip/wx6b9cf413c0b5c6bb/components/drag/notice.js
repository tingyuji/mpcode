(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "components/drag/notice" ], {
    "3c0d5": function(t, e, n) {
        "use strict";
        var r;
        n.d(e, "b", function() {
            return u;
        }), n.d(e, "c", function() {
            return a;
        }), n.d(e, "a", function() {
            return r;
        });
        var u = function() {
            var t = this, e = t.$createElement;
            t._self._c;
        }, a = [];
    },
    5303: function(t, e, n) {
        "use strict";
        (function(t) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var r = u(n("a34a"));
            n("26cb");
            function u(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            function a(t, e, n, r, u, a, c) {
                try {
                    var o = t[a](c), i = o.value;
                } catch (s) {
                    return void n(s);
                }
                o.done ? e(i) : Promise.resolve(i).then(r, u);
            }
            function c(t) {
                return function() {
                    var e = this, n = arguments;
                    return new Promise(function(r, u) {
                        var c = t.apply(e, n);
                        function o(t) {
                            a(c, r, u, o, i, "next", t);
                        }
                        function i(t) {
                            a(c, r, u, o, i, "throw", t);
                        }
                        o(void 0);
                    });
                };
            }
            var o = function() {
                n.e("components/third/uni-notice-bar").then(function() {
                    return resolve(n("2816"));
                }.bind(null, n)).catch(n.oe);
            }, i = {
                name: "searchBox",
                components: {
                    uniNoticeBar: o
                },
                props: {
                    co: {
                        type: Object,
                        default: function() {
                            return {};
                        }
                    },
                    shopinfo: {
                        type: Object,
                        default: function() {
                            return {};
                        }
                    },
                    u: {
                        type: String,
                        default: "px"
                    },
                    ptype: {
                        type: String,
                        default: "1"
                    },
                    type: {
                        type: String,
                        default: "1"
                    },
                    list: {
                        type: Array,
                        default: function() {
                            return [];
                        }
                    },
                    color: {
                        type: String,
                        default: ""
                    },
                    arrow: {
                        type: Boolean,
                        default: !0
                    }
                },
                data: function() {
                    return {
                        notice: "",
                        nlist: []
                    };
                },
                watch: {
                    shopinfo: {
                        handler: function(t) {
                            var e = this;
                            return c(r.default.mark(function n() {
                                var u, a;
                                return r.default.wrap(function(n) {
                                    while (1) switch (n.prev = n.next) {
                                      case 0:
                                        if (!t.id || 2 != e.co.source) {
                                            n.next = 6;
                                            break;
                                        }
                                        return n.next = 3, e.util.request({
                                            url: e.api.ptgg,
                                            data: {
                                                type: e.co.source,
                                                storeId: t.id
                                            }
                                        });

                                      case 3:
                                        u = n.sent, a = u.data, e.nlist = a;

                                      case 6:
                                      case "end":
                                        return n.stop();
                                    }
                                }, n);
                            }))();
                        },
                        immediate: !0
                    }
                },
                methods: {
                    goLink: function(t) {
                        this.goUrl(t.url);
                    },
                    goDl: function(e) {
                        t.setStorageSync("fwb", e.body), this.go({
                            t: 1,
                            url: "/yb_wm/my/other/gywm?t=".concat(e.title, "&p=4")
                        });
                    }
                },
                created: function() {
                    var t = this;
                    return c(r.default.mark(function e() {
                        var n, u;
                        return r.default.wrap(function(e) {
                            while (1) switch (e.prev = e.next) {
                              case 0:
                                e.t0 = +t.ptype, e.next = 1 === e.t0 ? 3 : 3 === e.t0 ? 10 : 12;
                                break;

                              case 3:
                                if (1 != t.co.source) {
                                    e.next = 9;
                                    break;
                                }
                                return e.next = 6, t.util.request({
                                    url: t.api.ptgg,
                                    data: {
                                        type: t.co.source
                                    }
                                });

                              case 6:
                                n = e.sent, u = n.data, t.nlist = u;

                              case 9:
                                return e.abrupt("break", 13);

                              case 10:
                                return t.nlist = t.list, e.abrupt("break", 13);

                              case 12:
                                return e.abrupt("break", 13);

                              case 13:
                              case "end":
                                return e.stop();
                            }
                        }, e);
                    }))();
                }
            };
            e.default = i;
        }).call(this, n("543d")["default"]);
    },
    6626: function(t, e, n) {
        "use strict";
        var r = n("9099"), u = n.n(r);
        u.a;
    },
    "700c": function(t, e, n) {
        "use strict";
        n.r(e);
        var r = n("5303"), u = n.n(r);
        for (var a in r) "default" !== a && function(t) {
            n.d(e, t, function() {
                return r[t];
            });
        }(a);
        e["default"] = u.a;
    },
    9099: function(t, e, n) {},
    "90d5": function(t, e, n) {
        "use strict";
        n.r(e);
        var r = n("3c0d5"), u = n("700c");
        for (var a in u) "default" !== a && function(t) {
            n.d(e, t, function() {
                return u[t];
            });
        }(a);
        n("6626");
        var c, o = n("f0c5"), i = Object(o["a"])(u["default"], r["b"], r["c"], !1, null, "1bda5575", null, !1, r["a"], c);
        e["default"] = i.exports;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "components/drag/notice-create-component", {
    "components/drag/notice-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("90d5"));
    }
}, [ [ "components/drag/notice-create-component" ] ] ]);