(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "components/drag/fixed" ], {
    "354b": function(t, e, n) {
        "use strict";
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var r = n("26cb"), o = n("ddcf");
        function i(t, e) {
            var n = Object.keys(t);
            if (Object.getOwnPropertySymbols) {
                var r = Object.getOwnPropertySymbols(t);
                e && (r = r.filter(function(e) {
                    return Object.getOwnPropertyDescriptor(t, e).enumerable;
                })), n.push.apply(n, r);
            }
            return n;
        }
        function c(t) {
            for (var e = 1; e < arguments.length; e++) {
                var n = null != arguments[e] ? arguments[e] : {};
                e % 2 ? i(Object(n), !0).forEach(function(e) {
                    u(t, e, n[e]);
                }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : i(Object(n)).forEach(function(e) {
                    Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e));
                });
            }
            return t;
        }
        function u(t, e, n) {
            return e in t ? Object.defineProperty(t, e, {
                value: n,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : t[e] = n, t;
        }
        var a = {
            name: "fixed",
            props: {
                co: {
                    type: Object,
                    default: function() {
                        return {};
                    }
                },
                u: {
                    type: String,
                    default: "px"
                }
            },
            data: function() {
                return {
                    whtime: ""
                };
            },
            mixins: [ o.utilMixins ],
            computed: c(c(c({}, (0, r.mapState)("dndc", [ "addInfo", "latLng" ])), (0, r.mapState)({
                storeInfo: function(t) {
                    return t.config.storeInfo;
                },
                layout: function(t) {
                    return t.layout.index.body;
                }
            })), {}, {
                address: function() {
                    return this.addInfo ? this.addInfo.maddress : "定位中...";
                },
                ztlh: function() {
                    return this.util.getSb().customNavh - 16 + "px";
                },
                dwpt: function() {
                    return 2 != this.co.orPic && 1 != this.layout.pageSetting[0].styles.modulePage ? this.ztlh : 0;
                },
                dwtop: function() {
                    return 1 == this.layout.pageSetting[0].styles.modulePage ? 0 : this.ztlh;
                }
            }),
            methods: {
                goTo: function(t) {
                    this.goUrl(t.url, t);
                },
                goSelect: function() {
                    2 == this.system.storeSet.storeModel && this.go({
                        url: "/yb_wm/shop/select/index?page=index&storeId=" + this.storeInfo.id
                    });
                },
                getWhtime: function() {
                    var t = new Date().getHours(), e = "";
                    e = t < 6 ? "凌晨" : t < 9 ? "早上" : t < 12 ? "上午" : t < 13 ? "中午" : t < 18 ? "下午" : t < 22 ? "晚上" : "夜里", 
                    this.whtime = e;
                }
            },
            created: function() {
                1 == this.co.module && this.getWhtime();
            }
        };
        e.default = a;
    },
    "3dc3": function(t, e, n) {},
    "5c7f": function(t, e, n) {
        "use strict";
        var r;
        n.d(e, "b", function() {
            return o;
        }), n.d(e, "c", function() {
            return i;
        }), n.d(e, "a", function() {
            return r;
        });
        var o = function() {
            var t = this, e = t.$createElement, n = (t._self._c, t.storeInfo.name ? t.cTR(t.co.colorBg) : null);
            t.$mp.data = Object.assign({}, {
                $root: {
                    m0: n
                }
            });
        }, i = [];
    },
    "6af3": function(t, e, n) {
        "use strict";
        n.r(e);
        var r = n("5c7f"), o = n("e06c");
        for (var i in o) "default" !== i && function(t) {
            n.d(e, t, function() {
                return o[t];
            });
        }(i);
        n("953a");
        var c, u = n("f0c5"), a = Object(u["a"])(o["default"], r["b"], r["c"], !1, null, "5f52a886", null, !1, r["a"], c);
        e["default"] = a.exports;
    },
    "953a": function(t, e, n) {
        "use strict";
        var r = n("3dc3"), o = n.n(r);
        o.a;
    },
    e06c: function(t, e, n) {
        "use strict";
        n.r(e);
        var r = n("354b"), o = n.n(r);
        for (var i in r) "default" !== i && function(t) {
            n.d(e, t, function() {
                return r[t];
            });
        }(i);
        e["default"] = o.a;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "components/drag/fixed-create-component", {
    "components/drag/fixed-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("6af3"));
    }
}, [ [ "components/drag/fixed-create-component" ] ] ]);