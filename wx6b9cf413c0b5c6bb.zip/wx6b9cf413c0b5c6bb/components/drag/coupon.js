(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "components/drag/coupon" ], {
    "0264": function(t, n, e) {
        "use strict";
        var o = e("2c90"), r = e.n(o);
        r.a;
    },
    "142d": function(t, n, e) {
        "use strict";
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), n.default = void 0;
        var o = r(e("a34a"));
        function r(t) {
            return t && t.__esModule ? t : {
                default: t
            };
        }
        function u(t, n, e, o, r, u, i) {
            try {
                var c = t[u](i), a = c.value;
            } catch (s) {
                return void e(s);
            }
            c.done ? n(a) : Promise.resolve(a).then(o, r);
        }
        function i(t) {
            return function() {
                var n = this, e = arguments;
                return new Promise(function(o, r) {
                    var i = t.apply(n, e);
                    function c(t) {
                        u(i, o, r, c, a, "next", t);
                    }
                    function a(t) {
                        u(i, o, r, c, a, "throw", t);
                    }
                    c(void 0);
                });
            };
        }
        var c = {
            name: "coupon",
            data: function() {
                return {
                    couponlist: [],
                    img: "/static/index/collect.png",
                    isshow: !1
                };
            },
            props: {
                co: {
                    type: Object,
                    default: function() {
                        return {};
                    }
                },
                shopinfo: Object
            },
            watch: {
                shopinfo: {
                    handler: function(t) {
                        console.log(t), t.id && this.getData(t.id);
                    },
                    immediate: !0
                }
            },
            methods: {
                goTo: function(t) {
                    var n = "/yb_wm/my/coupon/coupon-dl?id=" + t.id;
                    this.go({
                        t: 1,
                        url: n
                    });
                },
                qlx: function(t) {
                    return console.log(t), 1 == t.type ? "代金券" : 2 == t.type ? "折扣券" : 3 == t.type ? "兑换券" : void 0;
                },
                getData: function(t) {
                    var n = this;
                    return i(o.default.mark(function t() {
                        var e, r;
                        return o.default.wrap(function(t) {
                            while (1) switch (t.prev = t.next) {
                              case 0:
                                return n.getSystem(), t.next = 3, n.util.request({
                                    url: n.api.lqzx,
                                    method: "POST",
                                    data: {
                                        page: 1,
                                        type: 1
                                    }
                                });

                              case 3:
                                e = t.sent, r = e.data, n.couponlist = r, n.couponlist.length > 0 && (n.isshow = !0);

                              case 7:
                              case "end":
                                return t.stop();
                            }
                        }, t);
                    }))();
                }
            }
        };
        n.default = c;
    },
    "2c90": function(t, n, e) {},
    "6d10": function(t, n, e) {
        "use strict";
        e.r(n);
        var o = e("142d"), r = e.n(o);
        for (var u in o) "default" !== u && function(t) {
            e.d(n, t, function() {
                return o[t];
            });
        }(u);
        n["default"] = r.a;
    },
    "7b9f": function(t, n, e) {
        "use strict";
        var o;
        e.d(n, "b", function() {
            return r;
        }), e.d(n, "c", function() {
            return u;
        }), e.d(n, "a", function() {
            return o;
        });
        var r = function() {
            var t = this, n = t.$createElement, e = (t._self._c, t.isshow && 1 == t.co.cardType ? t.__map(t.couponlist, function(n, e) {
                var o = t.__get_orig(n), r = t.qlx(n);
                return {
                    $orig: o,
                    m0: r
                };
            }) : null), o = t.isshow && 1 != t.co.cardType ? t.__map(t.couponlist, function(n, e) {
                var o = t.__get_orig(n), r = t.qlx(n);
                return {
                    $orig: o,
                    m1: r
                };
            }) : null;
            t.$mp.data = Object.assign({}, {
                $root: {
                    l0: e,
                    l1: o
                }
            });
        }, u = [];
    },
    e1fb: function(t, n, e) {
        "use strict";
        e.r(n);
        var o = e("7b9f"), r = e("6d10");
        for (var u in r) "default" !== u && function(t) {
            e.d(n, t, function() {
                return r[t];
            });
        }(u);
        e("0264");
        var i, c = e("f0c5"), a = Object(c["a"])(r["default"], o["b"], o["c"], !1, null, "46915db4", null, !1, o["a"], i);
        n["default"] = a.exports;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "components/drag/coupon-create-component", {
    "components/drag/coupon-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("e1fb"));
    }
}, [ [ "components/drag/coupon-create-component" ] ] ]);