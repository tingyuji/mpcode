(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "components/drag/susBtn" ], {
    "355d": function(t, n, e) {
        "use strict";
        e.r(n);
        var u = e("e392"), c = e.n(u);
        for (var r in u) "default" !== r && function(t) {
            e.d(n, t, function() {
                return u[t];
            });
        }(r);
        n["default"] = c.a;
    },
    "37d3": function(t, n, e) {
        "use strict";
        e.r(n);
        var u = e("c37c"), c = e("355d");
        for (var r in c) "default" !== r && function(t) {
            e.d(n, t, function() {
                return c[t];
            });
        }(r);
        e("c855");
        var a, o = e("f0c5"), f = Object(o["a"])(c["default"], u["b"], u["c"], !1, null, "0e3c7298", null, !1, u["a"], a);
        n["default"] = f.exports;
    },
    b93a: function(t, n, e) {},
    c37c: function(t, n, e) {
        "use strict";
        var u;
        e.d(n, "b", function() {
            return c;
        }), e.d(n, "c", function() {
            return r;
        }), e.d(n, "a", function() {
            return u;
        });
        var c = function() {
            var t = this, n = t.$createElement;
            t._self._c;
        }, r = [];
    },
    c855: function(t, n, e) {
        "use strict";
        var u = e("b93a"), c = e.n(u);
        c.a;
    },
    e392: function(t, n, e) {
        "use strict";
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), n.default = void 0;
        var u = {
            name: "susBtn",
            props: {
                co: {
                    type: Object,
                    default: function() {
                        return {};
                    }
                }
            },
            data: function() {
                return {
                    img: ""
                };
            },
            methods: {
                goTo: function(t) {
                    this.goUrl(t.url, t);
                }
            },
            created: function() {}
        };
        n.default = u;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "components/drag/susBtn-create-component", {
    "components/drag/susBtn-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("37d3"));
    }
}, [ [ "components/drag/susBtn-create-component" ] ] ]);