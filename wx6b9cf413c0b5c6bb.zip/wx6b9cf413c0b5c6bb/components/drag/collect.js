(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "components/drag/collect" ], {
    "389d": function(t, n, e) {
        "use strict";
        var r;
        e.d(n, "b", function() {
            return u;
        }), e.d(n, "c", function() {
            return c;
        }), e.d(n, "a", function() {
            return r;
        });
        var u = function() {
            var t = this, n = t.$createElement;
            t._self._c;
        }, c = [];
    },
    "3f52": function(t, n, e) {},
    "6b86": function(t, n, e) {
        "use strict";
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), n.default = void 0;
        var r = u(e("a34a"));
        function u(t) {
            return t && t.__esModule ? t : {
                default: t
            };
        }
        function c(t, n, e, r, u, c, a) {
            try {
                var o = t[c](a), i = o.value;
            } catch (f) {
                return void e(f);
            }
            o.done ? n(i) : Promise.resolve(i).then(r, u);
        }
        function a(t) {
            return function() {
                var n = this, e = arguments;
                return new Promise(function(r, u) {
                    var a = t.apply(n, e);
                    function o(t) {
                        c(a, r, u, o, i, "next", t);
                    }
                    function i(t) {
                        c(a, r, u, o, i, "throw", t);
                    }
                    o(void 0);
                });
            };
        }
        var o = {
            name: "collect",
            data: function() {
                return {
                    iconUrl: "/static/index/collect.png"
                };
            },
            props: {
                co: {
                    type: Object,
                    default: function() {
                        return {};
                    }
                },
                u: {
                    type: String,
                    default: "px"
                }
            },
            methods: {
                goLink: function(t) {
                    var n = this;
                    return a(r.default.mark(function e() {
                        return r.default.wrap(function(e) {
                            while (1) switch (e.prev = e.next) {
                              case 0:
                                return e.next = 2, n.checkLogin(n);

                              case 2:
                                if (e.sent) {
                                    e.next = 4;
                                    break;
                                }
                                return e.abrupt("return");

                              case 4:
                                n.go({
                                    t: 1,
                                    url: t
                                });

                              case 5:
                              case "end":
                                return e.stop();
                            }
                        }, e);
                    }))();
                }
            }
        };
        n.default = o;
    },
    "79ee": function(t, n, e) {
        "use strict";
        var r = e("3f52"), u = e.n(r);
        u.a;
    },
    "7bc9": function(t, n, e) {
        "use strict";
        e.r(n);
        var r = e("6b86"), u = e.n(r);
        for (var c in r) "default" !== c && function(t) {
            e.d(n, t, function() {
                return r[t];
            });
        }(c);
        n["default"] = u.a;
    },
    ed8c: function(t, n, e) {
        "use strict";
        e.r(n);
        var r = e("389d"), u = e("7bc9");
        for (var c in u) "default" !== c && function(t) {
            e.d(n, t, function() {
                return u[t];
            });
        }(c);
        e("79ee");
        var a, o = e("f0c5"), i = Object(o["a"])(u["default"], r["b"], r["c"], !1, null, "0c9b709c", null, !1, r["a"], a);
        n["default"] = i.exports;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "components/drag/collect-create-component", {
    "components/drag/collect-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("ed8c"));
    }
}, [ [ "components/drag/collect-create-component" ] ] ]);