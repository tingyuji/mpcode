(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "components/drag/member" ], {
    "55e4": function(e, t, n) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var r = i(n("a34a")), o = n("26cb");
        function i(e) {
            return e && e.__esModule ? e : {
                default: e
            };
        }
        function a(e, t, n, r, o, i, a) {
            try {
                var u = e[i](a), c = u.value;
            } catch (s) {
                return void n(s);
            }
            u.done ? t(c) : Promise.resolve(c).then(r, o);
        }
        function u(e) {
            return function() {
                var t = this, n = arguments;
                return new Promise(function(r, o) {
                    var i = e.apply(t, n);
                    function u(e) {
                        a(i, r, o, u, c, "next", e);
                    }
                    function c(e) {
                        a(i, r, o, u, c, "throw", e);
                    }
                    u(void 0);
                });
            };
        }
        function c(e, t) {
            var n = Object.keys(e);
            if (Object.getOwnPropertySymbols) {
                var r = Object.getOwnPropertySymbols(e);
                t && (r = r.filter(function(t) {
                    return Object.getOwnPropertyDescriptor(e, t).enumerable;
                })), n.push.apply(n, r);
            }
            return n;
        }
        function s(e) {
            for (var t = 1; t < arguments.length; t++) {
                var n = null != arguments[t] ? arguments[t] : {};
                t % 2 ? c(Object(n), !0).forEach(function(t) {
                    f(e, t, n[t]);
                }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : c(Object(n)).forEach(function(t) {
                    Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
                });
            }
            return e;
        }
        function f(e, t, n) {
            return t in e ? Object.defineProperty(e, t, {
                value: n,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : e[t] = n, e;
        }
        var d = {
            name: "member",
            data: function() {
                return {
                    iconUrl: "/static/index/huiyuan.png",
                    vipcard: "/static/index/vip-card.png",
                    c_growth: 0,
                    vip_txtx: "获取积分升级",
                    next_info: {},
                    jindu: 0,
                    viparr: [],
                    vip_name: "普通会员",
                    vip_code: "XXXXXXXXX"
                };
            },
            props: {
                co: {
                    type: Object,
                    default: function() {
                        return {};
                    }
                },
                u: {
                    type: String,
                    default: "px"
                }
            },
            watch: {
                shopinfo: {
                    handler: function(e) {
                        console.log(e), this.getData();
                    },
                    immediate: !0
                }
            },
            computed: s({}, (0, o.mapState)({
                user: function(e) {
                    return e.user;
                }
            })),
            methods: {
                getData: function() {
                    var e = this;
                    return u(r.default.mark(function t() {
                        var n, o, i;
                        return r.default.wrap(function(t) {
                            while (1) switch (t.prev = t.next) {
                              case 0:
                                return console.log("2222222222"), t.next = 3, e.util.request({
                                    url: e.api.hydj
                                });

                              case 3:
                                n = t.sent, o = n.data, e.viparr = o, console.log("会员信息", o), e.$store.state.user.cardName && (e.vip_name = e.$store.state.user.cardName), 
                                e.$store.state.user.vipCode && (e.vip_code = e.$store.state.user.vipCode), e.$store.state.user.level ? (console.log("有会员级别"), 
                                i = parseInt(e.$store.state.user.level), console.log("下一级别会员", i), e.viparr[i] ? (e.next_info = e.viparr[i], 
                                e.c_growth = parseInt(e.next_info.condition) - parseInt(e.$store.state.user.growth), 
                                e.jindu = parseInt(e.$store.state.user.growth) / e.next_info.condition, e.jindu = 100 * e.jindu.toFixed(2), 
                                e.vip_txtx = !1, e.jindu > 100 && (e.jindu = 100)) : (e.vip_txtx = "您已经是最高级别", e.jindu = 100)) : (e.next_info = e.viparr[0], 
                                e.c_growth = parseInt(e.next_info.condition) - parseInt(e.$store.state.user.growth), 
                                e.jindu = parseInt(e.$store.state.user.growth) / e.next_info.condition, e.jindu = 100 * e.jindu.toFixed(2), 
                                e.jindu > 100 && (e.jindu = 100));

                              case 10:
                              case "end":
                                return t.stop();
                            }
                        }, t);
                    }))();
                },
                goLink: function(e) {
                    var t = this;
                    return u(r.default.mark(function n() {
                        return r.default.wrap(function(n) {
                            while (1) switch (n.prev = n.next) {
                              case 0:
                                return console.log(e), n.next = 3, t.checkLogin(t);

                              case 3:
                                if (n.sent) {
                                    n.next = 5;
                                    break;
                                }
                                return n.abrupt("return");

                              case 5:
                                t.go({
                                    t: 1,
                                    url: e
                                });

                              case 6:
                              case "end":
                                return n.stop();
                            }
                        }, n);
                    }))();
                }
            }
        };
        t.default = d;
    },
    "5a71": function(e, t, n) {
        "use strict";
        n.r(t);
        var r = n("55e4"), o = n.n(r);
        for (var i in r) "default" !== i && function(e) {
            n.d(t, e, function() {
                return r[e];
            });
        }(i);
        t["default"] = o.a;
    },
    abfb: function(e, t, n) {
        "use strict";
        var r = n("d2f6"), o = n.n(r);
        o.a;
    },
    d2f6: function(e, t, n) {},
    de46: function(e, t, n) {
        "use strict";
        var r;
        n.d(t, "b", function() {
            return o;
        }), n.d(t, "c", function() {
            return i;
        }), n.d(t, "a", function() {
            return r;
        });
        var o = function() {
            var e = this, t = e.$createElement;
            e._self._c;
        }, i = [];
    },
    e195: function(e, t, n) {
        "use strict";
        n.r(t);
        var r = n("de46"), o = n("5a71");
        for (var i in o) "default" !== i && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(i);
        n("abfb");
        var a, u = n("f0c5"), c = Object(u["a"])(o["default"], r["b"], r["c"], !1, null, "bc15a7cc", null, !1, r["a"], a);
        t["default"] = c.exports;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "components/drag/member-create-component", {
    "components/drag/member-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("e195"));
    }
}, [ [ "components/drag/member-create-component" ] ] ]);