(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "components/drag/vip" ], {
    "0996": function(t, e, n) {
        "use strict";
        var r = n("b480"), a = n.n(r);
        a.a;
    },
    "55f4": function(t, e, n) {
        "use strict";
        var r;
        n.d(e, "b", function() {
            return a;
        }), n.d(e, "c", function() {
            return o;
        }), n.d(e, "a", function() {
            return r;
        });
        var a = function() {
            var t = this, e = t.$createElement, n = (t._self._c, "1" != t.styles.templateType && t.styles.templateType || "my" != t.ptype || 2 != t.showpr ? null : t.util.getSb());
            t.$mp.data = Object.assign({}, {
                $root: {
                    g0: n
                }
            });
        }, o = [];
    },
    "563b": function(t, e, n) {
        "use strict";
        n.r(e);
        var r = n("55f4"), a = n("dff5");
        for (var o in a) "default" !== o && function(t) {
            n.d(e, t, function() {
                return a[t];
            });
        }(o);
        n("0996");
        var i, u = n("f0c5"), s = Object(u["a"])(a["default"], r["b"], r["c"], !1, null, "6fabbd58", null, !1, r["a"], i);
        e["default"] = s.exports;
    },
    a8f2: function(t, e, n) {
        "use strict";
        (function(t) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var r = o(n("a34a")), a = n("26cb");
            function o(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            function i(t, e) {
                var n = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(t);
                    e && (r = r.filter(function(e) {
                        return Object.getOwnPropertyDescriptor(t, e).enumerable;
                    })), n.push.apply(n, r);
                }
                return n;
            }
            function u(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var n = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? i(Object(n), !0).forEach(function(e) {
                        s(t, e, n[e]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : i(Object(n)).forEach(function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e));
                    });
                }
                return t;
            }
            function s(t, e, n) {
                return e in t ? Object.defineProperty(t, e, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[e] = n, t;
            }
            function c(t, e, n, r, a, o, i) {
                try {
                    var u = t[o](i), s = u.value;
                } catch (c) {
                    return void n(c);
                }
                u.done ? e(s) : Promise.resolve(s).then(r, a);
            }
            function l(t) {
                return function() {
                    var e = this, n = arguments;
                    return new Promise(function(r, a) {
                        var o = t.apply(e, n);
                        function i(t) {
                            c(o, r, a, i, u, "next", t);
                        }
                        function u(t) {
                            c(o, r, a, i, u, "throw", t);
                        }
                        i(void 0);
                    });
                };
            }
            var f = function() {
                n.e("components/common/sq-btn").then(function() {
                    return resolve(n("cdf7"));
                }.bind(null, n)).catch(n.oe);
            }, p = {
                name: "vip",
                components: {
                    sqBtn: f
                },
                data: function() {
                    return {
                        vipInfo: {},
                        vip_name: "普通会员",
                        c_growth: 0,
                        vip_txtx: "获取积分升级",
                        next_info: {
                            name: "",
                            condition: 0
                        },
                        jindu: 0,
                        viparr: []
                    };
                },
                props: {
                    styles: Object,
                    ptype: {
                        type: String,
                        default: "my"
                    },
                    showpr: {
                        type: String,
                        default: ""
                    }
                },
                methods: {
                    growCount: function(t) {
                        var e = Number(t || 0);
                        return e % 500;
                    },
                    ljdl: function() {
                        var t = this;
                        return l(r.default.mark(function e() {
                            return r.default.wrap(function(e) {
                                while (1) switch (e.prev = e.next) {
                                  case 0:
                                    return e.next = 2, t.checkLogin();

                                  case 2:
                                    if (e.sent) {
                                        e.next = 4;
                                        break;
                                    }
                                    return e.abrupt("return");

                                  case 4:
                                  case "end":
                                    return e.stop();
                                }
                            }, e);
                        }))();
                    },
                    myDataClick: function(t) {
                        var e = this;
                        return l(r.default.mark(function n() {
                            var a;
                            return r.default.wrap(function(n) {
                                while (1) switch (n.prev = n.next) {
                                  case 0:
                                    return n.next = 2, e.checkLogin();

                                  case 2:
                                    if (n.sent) {
                                        n.next = 4;
                                        break;
                                    }
                                    return n.abrupt("return");

                                  case 4:
                                    a = "", a = t.url ? t.url : "/yb_wm/my/other/kfz", e.go({
                                        t: 1,
                                        url: a
                                    });

                                  case 7:
                                  case "end":
                                    return n.stop();
                                }
                            }, n);
                        }))();
                    },
                    onChooseAvatar: function(t) {
                        console.log("选择头像", t), this.avatarUrl = t.detail.avatarUrl, this.wxuploadFile();
                    },
                    wxuploadFile: function() {
                        var e = this, n = getApp().globalData.siteInfo;
                        console.log(n);
                        var r = n.siteroot + "/index.php/" + this.api.sctp;
                        t.uploadFile({
                            url: r,
                            filePath: this.avatarUrl,
                            name: "image",
                            header: {
                                "content-type": "multipart/form-data",
                                token: t.getStorageSync("token"),
                                appType: this.api.platform,
                                uniacid: n.uniacid,
                                module: "yb_wm",
                                userId: t.getStorageSync("userId"),
                                logintoken: getApp().globalData.session_key
                            },
                            success: function(t) {
                                var n = {
                                    portrait: ""
                                };
                                e.user.portrait = t.data, n.portrait = t.data, e.util.request({
                                    url: e.api.xgtx,
                                    method: "POST",
                                    mask: 1,
                                    data: n
                                });
                            },
                            fail: function(t) {
                                console.log(t);
                            }
                        });
                    },
                    countBack: function() {
                        var t = 0;
                        return "https://cypt.1903it.com/miniapp/mrtx.png" != this.user.portrait && t++, 
                        this.user.userName && t++, this.user.realName && t++, this.user.userTel && t++, 
                        t / 4 * 100;
                    },
                    getDjlb: function() {
                        var t = this;
                        return l(r.default.mark(function e() {
                            var n, a, o;
                            return r.default.wrap(function(e) {
                                while (1) switch (e.prev = e.next) {
                                  case 0:
                                    return e.next = 2, t.util.request({
                                        url: t.api.hydj
                                    });

                                  case 2:
                                    n = e.sent, a = n.data, console.log("获取到的会员信息", a), t.viparr = a, t.$store.state.user.cardName && (t.vip_name = t.$store.state.user.cardName), 
                                    t.$store.state.user.level ? (console.log("有会员级别"), o = parseInt(t.$store.state.user.level), 
                                    console.log("下一级别会员", o), t.viparr[o] ? (t.next_info = t.viparr[o], t.c_growth = parseInt(t.next_info.condition) - parseInt(t.$store.state.user.growth), 
                                    t.jindu = parseInt(t.$store.state.user.growth) / t.next_info.condition, t.jindu = 100 * t.jindu.toFixed(2), 
                                    t.vip_txtx = !1, t.jindu > 100 && (t.jindu = 100)) : (t.vip_txtx = "您已经是最高级别", t.jindu = 100, 
                                    t.next_info = t.viparr[t.viparr.length - 1], t.c_growth = parseInt(t.next_info.condition) - parseInt(t.$store.state.user.growth))) : (t.next_info = t.viparr[0], 
                                    t.c_growth = parseInt(t.next_info.condition) - parseInt(t.$store.state.user.growth), 
                                    t.jindu = parseInt(t.$store.state.user.growth) / t.next_info.condition, t.jindu = 100 * t.jindu.toFixed(2), 
                                    t.jindu > 100 && (t.jindu = 100));

                                  case 8:
                                  case "end":
                                    return e.stop();
                                }
                            }, e);
                        }))();
                    }
                },
                computed: u(u({}, (0, a.mapState)({
                    vipset: function(t) {
                        return t.config.vipset;
                    }
                })), {}, {
                    myData: function() {
                        return [ {
                            hide: "false" == this.styles.btnStatus[0].toString(),
                            num: this.user.balance || 0,
                            name: this.system.custom.balance,
                            url: "/yb_wm/other/recharge/yesy"
                        }, {
                            hide: "false" == this.styles.btnStatus[1].toString(),
                            num: this.user.integral || 0,
                            name: this.system.custom.integral,
                            url: "/yb_wm/my/integral/my-integral"
                        }, {
                            hide: "false" == this.styles.btnStatus[2].toString(),
                            num: this.user.couponNum || 0,
                            name: "优惠券",
                            url: "/yb_wm/my/coupon/my"
                        }, {
                            hide: "false" == this.styles.btnStatus[3].toString(),
                            num: this.user.valuecard || 0,
                            name: "储值卡",
                            url: "/yb_wm/other/recharge/valuecard"
                        } ];
                    }
                }),
                created: function() {
                    console.log("user", this.user, this.styles), this.getDjlb();
                }
            };
            e.default = p;
        }).call(this, n("543d")["default"]);
    },
    b480: function(t, e, n) {},
    dff5: function(t, e, n) {
        "use strict";
        n.r(e);
        var r = n("a8f2"), a = n.n(r);
        for (var o in r) "default" !== o && function(t) {
            n.d(e, t, function() {
                return r[t];
            });
        }(o);
        e["default"] = a.a;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "components/drag/vip-create-component", {
    "components/drag/vip-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("563b"));
    }
}, [ [ "components/drag/vip-create-component" ] ] ]);