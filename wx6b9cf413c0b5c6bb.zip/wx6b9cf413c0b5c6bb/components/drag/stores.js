(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "components/drag/stores" ], {
    "37e8": function(n, t, e) {
        "use strict";
        e.r(t);
        var r = e("da6b"), u = e("b298");
        for (var a in u) "default" !== a && function(n) {
            e.d(t, n, function() {
                return u[n];
            });
        }(a);
        e("9ecf");
        var c, f = e("f0c5"), o = Object(f["a"])(u["default"], r["b"], r["c"], !1, null, "0eba07a3", null, !1, r["a"], c);
        t["default"] = o.exports;
    },
    "61ec": function(n, t, e) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var r = {
            name: "stores",
            data: function() {
                return {};
            }
        };
        t.default = r;
    },
    "9ecf": function(n, t, e) {
        "use strict";
        var r = e("f6c7"), u = e.n(r);
        u.a;
    },
    b298: function(n, t, e) {
        "use strict";
        e.r(t);
        var r = e("61ec"), u = e.n(r);
        for (var a in r) "default" !== a && function(n) {
            e.d(t, n, function() {
                return r[n];
            });
        }(a);
        t["default"] = u.a;
    },
    da6b: function(n, t, e) {
        "use strict";
        var r;
        e.d(t, "b", function() {
            return u;
        }), e.d(t, "c", function() {
            return a;
        }), e.d(t, "a", function() {
            return r;
        });
        var u = function() {
            var n = this, t = n.$createElement;
            n._self._c;
        }, a = [];
    },
    f6c7: function(n, t, e) {}
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "components/drag/stores-create-component", {
    "components/drag/stores-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("37e8"));
    }
}, [ [ "components/drag/stores-create-component" ] ] ]);