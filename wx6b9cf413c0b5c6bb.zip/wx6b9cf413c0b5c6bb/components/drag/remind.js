(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "components/drag/remind" ], {
    "21ef": function(n, t, e) {
        "use strict";
        e.r(t);
        var u = e("e787"), i = e("235d");
        for (var c in i) "default" !== c && function(n) {
            e.d(t, n, function() {
                return i[n];
            });
        }(c);
        e("ba50");
        var r, a = e("f0c5"), o = Object(a["a"])(i["default"], u["b"], u["c"], !1, null, "20dffbe3", null, !1, u["a"], r);
        t["default"] = o.exports;
    },
    "235d": function(n, t, e) {
        "use strict";
        e.r(t);
        var u = e("7440"), i = e.n(u);
        for (var c in u) "default" !== c && function(n) {
            e.d(t, n, function() {
                return u[n];
            });
        }(c);
        t["default"] = i.a;
    },
    7440: function(n, t, e) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var u = {
            name: "remind",
            data: function() {
                return {
                    img: "../../../static/tubiao/xuanfu.png",
                    activeIndex: 0,
                    intnum: void 0
                };
            },
            computed: {
                top: function() {
                    return 30 * -this.activeIndex + "px";
                }
            },
            props: [ "co" ],
            mounted: function() {},
            methods: {
                ScrollUp: function() {
                    var n = this;
                    this.intnum = setInterval(function(t) {
                        n.activeIndex < n.co.numberList.length ? n.activeIndex += 1 : n.activeIndex = 0;
                    }, 1e3);
                },
                Stop: function() {
                    clearInterval(this.intnum);
                },
                Up: function() {
                    this.ScrollUp();
                }
            }
        };
        t.default = u;
    },
    ba50: function(n, t, e) {
        "use strict";
        var u = e("d304"), i = e.n(u);
        i.a;
    },
    d304: function(n, t, e) {},
    e787: function(n, t, e) {
        "use strict";
        var u;
        e.d(t, "b", function() {
            return i;
        }), e.d(t, "c", function() {
            return c;
        }), e.d(t, "a", function() {
            return u;
        });
        var i = function() {
            var n = this, t = n.$createElement;
            n._self._c;
        }, c = [];
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "components/drag/remind-create-component", {
    "components/drag/remind-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("21ef"));
    }
}, [ [ "components/drag/remind-create-component" ] ] ]);