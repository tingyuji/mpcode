(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "components/drag/gather" ], {
    "16c4": function(t, n, e) {
        "use strict";
        var r;
        e.d(n, "b", function() {
            return u;
        }), e.d(n, "c", function() {
            return o;
        }), e.d(n, "a", function() {
            return r;
        });
        var u = function() {
            var t = this, n = t.$createElement;
            t._self._c;
        }, o = [];
    },
    "50b4": function(t, n, e) {
        "use strict";
        var r = e("7777"), u = e.n(r);
        u.a;
    },
    "6c66": function(t, n, e) {
        "use strict";
        e.r(n);
        var r = e("ccb6"), u = e.n(r);
        for (var o in r) "default" !== o && function(t) {
            e.d(n, t, function() {
                return r[t];
            });
        }(o);
        n["default"] = u.a;
    },
    7777: function(t, n, e) {},
    c99d: function(t, n, e) {
        "use strict";
        e.r(n);
        var r = e("16c4"), u = e("6c66");
        for (var o in u) "default" !== o && function(t) {
            e.d(n, t, function() {
                return u[t];
            });
        }(o);
        e("50b4");
        var a, c = e("f0c5"), i = Object(c["a"])(u["default"], r["b"], r["c"], !1, null, "4d0ebd8e", null, !1, r["a"], a);
        n["default"] = i.exports;
    },
    ccb6: function(t, n, e) {
        "use strict";
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), n.default = void 0;
        var r = u(e("a34a"));
        function u(t) {
            return t && t.__esModule ? t : {
                default: t
            };
        }
        function o(t, n, e, r, u, o, a) {
            try {
                var c = t[o](a), i = c.value;
            } catch (d) {
                return void e(d);
            }
            c.done ? n(i) : Promise.resolve(i).then(r, u);
        }
        function a(t) {
            return function() {
                var n = this, e = arguments;
                return new Promise(function(r, u) {
                    var a = t.apply(n, e);
                    function c(t) {
                        o(a, r, u, c, i, "next", t);
                    }
                    function i(t) {
                        o(a, r, u, c, i, "throw", t);
                    }
                    c(void 0);
                });
            };
        }
        var c = {
            name: "gather",
            data: function() {
                return {
                    jdData: {
                        orderNum: 6,
                        finish_count: 0,
                        saleNum: 6
                    },
                    jindu: 0
                };
            },
            onLoad: function() {
                return a(r.default.mark(function t() {
                    return r.default.wrap(function(t) {
                        while (1) switch (t.prev = t.next) {
                          case 0:
                          case "end":
                            return t.stop();
                        }
                    }, t);
                }))();
            },
            props: {
                co: {
                    type: Object,
                    default: function() {
                        return {};
                    }
                },
                shopinfo: Object
            },
            watch: {
                shopinfo: {
                    handler: function(t) {
                        console.log(t), t.id && this.getData(t.id);
                    },
                    immediate: !0
                }
            },
            onshow: function() {
                console.log(co.cardType);
            },
            methods: {
                getData: function(t) {
                    var n = this;
                    return a(r.default.mark(function e() {
                        var u, o;
                        return r.default.wrap(function(e) {
                            while (1) switch (e.prev = e.next) {
                              case 0:
                                return n.getSystem(), e.next = 3, n.util.request({
                                    url: n.api.newcollectList,
                                    data: {
                                        storeId: t
                                    }
                                });

                              case 3:
                                u = e.sent, o = u.data, o.orderNum && (n.jindu = o.finish_count / o.orderNum, n.jindu = 100 * n.jindu.toFixed(2), 
                                n.jdData = o);

                              case 6:
                              case "end":
                                return e.stop();
                            }
                        }, e);
                    }))();
                },
                goTo: function() {
                    this.go({
                        t: 1,
                        url: "/yb_wm/order/jd"
                    });
                }
            }
        };
        n.default = c;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "components/drag/gather-create-component", {
    "components/drag/gather-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("c99d"));
    }
}, [ [ "components/drag/gather-create-component" ] ] ]);