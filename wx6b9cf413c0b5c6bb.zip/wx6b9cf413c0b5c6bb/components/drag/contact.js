(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "components/drag/contact" ], {
    "124e": function(n, t, e) {
        "use strict";
        var r = e("e3de"), u = e.n(r);
        u.a;
    },
    1853: function(n, t, e) {
        "use strict";
        (function(n) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var r = u(e("a34a"));
            function u(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }
            function c(n, t, e, r, u, c, a) {
                try {
                    var o = n[c](a), i = o.value;
                } catch (f) {
                    return void e(f);
                }
                o.done ? t(i) : Promise.resolve(i).then(r, u);
            }
            function a(n) {
                return function() {
                    var t = this, e = arguments;
                    return new Promise(function(r, u) {
                        var a = n.apply(t, e);
                        function o(n) {
                            c(a, r, u, o, i, "next", n);
                        }
                        function i(n) {
                            c(a, r, u, o, i, "throw", n);
                        }
                        o(void 0);
                    });
                };
            }
            var o = {
                name: "contact",
                data: function() {
                    return {
                        iconUrl: "/static/index/wechat.png",
                        cardUrl: "/static/index/wechat.png"
                    };
                },
                props: {
                    co: {
                        type: Object,
                        default: function() {
                            return {};
                        }
                    },
                    shopinfo: Object
                },
                onLoad: function() {
                    return a(r.default.mark(function n() {
                        return r.default.wrap(function(n) {
                            while (1) switch (n.prev = n.next) {
                              case 0:
                              case "end":
                                return n.stop();
                            }
                        }, n);
                    }))();
                },
                methods: {
                    showimg: function() {
                        var t = [];
                        t[0] = this.co.cardUrl.img, n.previewImage({
                            current: 0,
                            urls: t
                        });
                    }
                }
            };
            t.default = o;
        }).call(this, e("543d")["default"]);
    },
    2908: function(n, t, e) {
        "use strict";
        e.r(t);
        var r = e("1853"), u = e.n(r);
        for (var c in r) "default" !== c && function(n) {
            e.d(t, n, function() {
                return r[n];
            });
        }(c);
        t["default"] = u.a;
    },
    "7fa2": function(n, t, e) {
        "use strict";
        e.r(t);
        var r = e("cd5f"), u = e("2908");
        for (var c in u) "default" !== c && function(n) {
            e.d(t, n, function() {
                return u[n];
            });
        }(c);
        e("124e");
        var a, o = e("f0c5"), i = Object(o["a"])(u["default"], r["b"], r["c"], !1, null, "33669d1a", null, !1, r["a"], a);
        t["default"] = i.exports;
    },
    cd5f: function(n, t, e) {
        "use strict";
        var r;
        e.d(t, "b", function() {
            return u;
        }), e.d(t, "c", function() {
            return c;
        }), e.d(t, "a", function() {
            return r;
        });
        var u = function() {
            var n = this, t = n.$createElement;
            n._self._c;
        }, c = [];
    },
    e3de: function(n, t, e) {}
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "components/drag/contact-create-component", {
    "components/drag/contact-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("7fa2"));
    }
}, [ [ "components/drag/contact-create-component" ] ] ]);