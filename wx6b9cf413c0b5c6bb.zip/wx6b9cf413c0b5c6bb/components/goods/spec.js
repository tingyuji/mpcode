(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "components/goods/spec" ], {
    "1ac51": function(t, o, n) {
        "use strict";
        var e;
        n.d(o, "b", function() {
            return r;
        }), n.d(o, "c", function() {
            return i;
        }), n.d(o, "a", function() {
            return e;
        });
        var r = function() {
            var t = this, o = t.$createElement, n = (t._self._c, !t.loading && t.goodsInfo.id ? Number(t.xzSpecInfo.vipPrice) : null), e = !t.loading && t.goodsInfo.id ? Number(t.xzSpecInfo.SalesPrice) : null, r = !t.loading && t.goodsInfo.id && 1 == t.goodsInfo.isSpecs && t.goodsInfo.specsData.length ? Number(t.xzSpecInfo.SalesPrice) : null, i = !t.loading && t.goodsInfo.id && t.xzSxInfo.arr.length ? t.xzSxInfo.arr.map(function(t) {
                return t.name;
            }).toString() : null, a = !t.loading && t.goodsInfo.id && t.xzJlInfo.arr.length ? t.xzJlInfo.arr.map(function(t) {
                return t.materialName;
            }).toString() : null;
            t._isMounted || (t.e0 = function(o) {
                t.showGg = !1;
            }), t.$mp.data = Object.assign({}, {
                $root: {
                    m0: n,
                    m1: e,
                    m2: r,
                    g0: i,
                    g1: a
                }
            });
        }, i = [];
    },
    6532: function(t, o, n) {
        "use strict";
        var e = n("a882"), r = n.n(e);
        r.a;
    },
    a5de: function(t, o, n) {
        "use strict";
        n.r(o);
        var e = n("1ac51"), r = n("ff77");
        for (var i in r) "default" !== i && function(t) {
            n.d(o, t, function() {
                return r[t];
            });
        }(i);
        n("6532");
        var a, s = n("f0c5"), c = Object(s["a"])(r["default"], e["b"], e["c"], !1, null, "fef5b492", null, !1, e["a"], a);
        o["default"] = c.exports;
    },
    a882: function(t, o, n) {},
    b326: function(t, o, n) {
        "use strict";
        Object.defineProperty(o, "__esModule", {
            value: !0
        }), o.default = void 0;
        var e = a(n("a34a")), r = n("26cb"), i = a(n("e1c0"));
        function a(t) {
            return t && t.__esModule ? t : {
                default: t
            };
        }
        function s(t, o, n, e, r, i, a) {
            try {
                var s = t[i](a), c = s.value;
            } catch (u) {
                return void n(u);
            }
            s.done ? o(c) : Promise.resolve(c).then(e, r);
        }
        function c(t) {
            return function() {
                var o = this, n = arguments;
                return new Promise(function(e, r) {
                    var i = t.apply(o, n);
                    function a(t) {
                        s(i, e, r, a, c, "next", t);
                    }
                    function c(t) {
                        s(i, e, r, a, c, "throw", t);
                    }
                    a(void 0);
                });
            };
        }
        function u(t, o) {
            var n = Object.keys(t);
            if (Object.getOwnPropertySymbols) {
                var e = Object.getOwnPropertySymbols(t);
                o && (e = e.filter(function(o) {
                    return Object.getOwnPropertyDescriptor(t, o).enumerable;
                })), n.push.apply(n, e);
            }
            return n;
        }
        function f(t) {
            for (var o = 1; o < arguments.length; o++) {
                var n = null != arguments[o] ? arguments[o] : {};
                o % 2 ? u(Object(n), !0).forEach(function(o) {
                    l(t, o, n[o]);
                }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : u(Object(n)).forEach(function(o) {
                    Object.defineProperty(t, o, Object.getOwnPropertyDescriptor(n, o));
                });
            }
            return t;
        }
        function l(t, o, n) {
            return o in t ? Object.defineProperty(t, o, {
                value: n,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : t[o] = n, t;
        }
        var d = function() {
            n.e("components/common/popup").then(function() {
                return resolve(n("b94e"));
            }.bind(null, n)).catch(n.oe);
        }, g = function() {
            n.e("components/common/block-b").then(function() {
                return resolve(n("569d"));
            }.bind(null, n)).catch(n.oe);
        }, p = {
            name: "popup",
            components: {
                mgPopup: d,
                bkB: g
            },
            props: {
                co: {
                    type: Object,
                    default: function() {
                        return {};
                    }
                },
                cname: {
                    type: String,
                    default: ""
                },
                value: {
                    type: Boolean,
                    default: !1
                },
                width: {
                    type: String,
                    default: "70%"
                },
                zindex: {
                    type: Number,
                    default: 999
                },
                outin: {
                    type: String,
                    default: "1"
                },
                storeid: {
                    type: String,
                    default: ""
                },
                systemGood: {
                    type: Object,
                    default: function() {
                        return {};
                    }
                },
                judgeObj: {
                    type: Object,
                    default: null
                }
            },
            data: function() {
                return {
                    loading: !0,
                    goodsInfo: {},
                    goodsSpces: [],
                    specs: {},
                    now_pic_url: ""
                };
            },
            methods: {
                clickSpec: function(t) {
                    var o = this.goodsInfo.specsData;
                    for (var n in o) o[n].a = n == t ? 1 : 0;
                },
                clickSpec2: function(t) {
                    var o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0, n = this.goodsInfo.specsData[t].attr_list;
                    for (var e in console.log(n), n) n[e].a = e == o ? 1 : 0;
                },
                clickAttribute: function(t, o) {
                    var n = this.goodsInfo.attrData;
                    for (var e in n[t].attrStr) n[t].attrStr[e].a = e == o ? 1 : 0;
                },
                clickMaterial: function(t) {
                    this.goodsInfo.meterialData;
                    this.$set(this.goodsInfo.meterialData[t], "a", 1 == this.goodsInfo.meterialData[t].a ? 0 : 1);
                },
                addSpec: function() {
                    this.xzSpecInfo.SalesStock && this.goodsInfo.ggnum == this.xzSpecInfo.SalesStock || (this.goodsInfo.ggnum += 1);
                },
                decSpec: function() {
                    1 != this.goodsInfo.ggnum && (this.goodsInfo.ggnum -= 1);
                },
                jrgwc: i.default.throttle(function(t) {
                    var o = this;
                    console.log("加入购物车"), console.log("this.xzSpecInfo", this.xzSpecInfo);
                    var n, e = Object.assign({}, this.xzSpecInfo), r = {
                        jlmoney: this.xzJlInfo.money,
                        material: this.xzJlInfo.arr.map(function(t) {
                            return {
                                materialId: t.id,
                                num: 1
                            };
                        }),
                        jldata: "",
                        jlids: ""
                    }, i = {
                        attribute: ""
                    };
                    if (console.log("specInfo", e), e.groupId = e.id || "", delete e.id, i.attribute = this.xzSxInfo.arr.map(function(t) {
                        return t.name;
                    }).toString(), r.jldata = this.xzJlInfo.arr.map(function(t) {
                        return t.materialName;
                    }).toString(), r.jlids = this.xzJlInfo.arr.map(function(t) {
                        return t.id;
                    }).toString(), n = 1 != this.co.isSpecs && 1 != this.co.isMaterial && 1 != this.co.isAttr ? this.carList.find(function(t) {
                        return t.goodsId == o.co.id;
                    }) : this.carList.find(function(t) {
                        return t.goodsId == o.co.id && t.groupId == e.groupId && t.materialIds == r.jlids && t.attribute == i.attribute;
                    }), n) {
                        if (this.co.maxNum > 0 && Number(n.num) + Number(this.goodsInfo.ggnum) > this.co.maxNum) return this.util.message("此商品限购".concat(this.co.maxNum, "份"), 3);
                    } else {
                        if (this.co.minNum > 1 && this.co.minNum > this.goodsInfo.ggnum) return this.util.message("此商品".concat(this.co.minNum, "份起购"), 3);
                        if (this.co.maxNum > 0 && this.goodsInfo.ggnum > this.co.maxNum) return this.util.message("此商品限购".concat(this.co.maxNum, "份"), 3);
                    }
                    var a = Object.assign({
                        ggnum: this.goodsInfo.ggnum
                    }, this.co, e, i, r);
                    console.log(), this.$emit("add", {
                        g: a,
                        addwz: 1
                    }), this.showGg = !1;
                }, 300)
            },
            computed: f(f({}, (0, r.mapState)({
                carList: function(t) {
                    return t.scarList.data || [];
                }
            })), {}, {
                showGg: {
                    get: function() {
                        return this.value;
                    },
                    set: function(t) {
                        this.$emit("input", t);
                    }
                },
                xzSpecInfo: function() {
                    var t = {
                        arr: []
                    };
                    if (1 == this.goodsInfo.isSpecs && this.goodsInfo.specsData.length && 3 != this.goodsInfo.specType) return this.goodsInfo.specsData.find(function(t) {
                        return t.a;
                    });
                    if (3 == this.goodsInfo.specType) {
                        if (1 == this.goodsInfo.isSpecs && this.goodsInfo.specsData.length) {
                            var o = this.goodsInfo.specsData, n = [], e = [], r = "";
                            for (var i in o) for (var a in o[i].attr_list) if (o[i].attr_list[a].a) {
                                n.push(o[i].attr_list[a]), e.push(o[i].attr_list[a].attr_id), r += " " + o[i].attr_list[a].attr_name;
                                break;
                            }
                            if (t.arr = n, console.log("xzSpecInfo", e), e) {
                                var s = "";
                                for (var c in e) s += 0 == c ? e[c] : ":" + e[c];
                                console.log("sign", s);
                                var u = this.goodsSpces;
                                for (var f in console.log("goodsSpaces", u), u) u[f].sign_id == s && (t.id = u[f].id, 
                                t.specsName = r, t.SalesStock = u[f].stock, t.SalesPrice = u[f].price, t.vipPrice = u[f].vipPrice, 
                                this.now_pic_url = u[f].pic_url);
                            }
                        }
                        return console.log("obj", t), t;
                    }
                    return t;
                },
                xzSxInfo: function() {
                    var t = {
                        arr: []
                    };
                    if (1 == this.goodsInfo.isAttr && this.goodsInfo.attrData.length) {
                        var o = this.goodsInfo.attrData, n = [];
                        for (var e in o) for (var r in o[e].attrStr) if (o[e].attrStr[r].a) {
                            n.push(o[e].attrStr[r]);
                            break;
                        }
                        t.arr = n;
                    }
                    return t;
                },
                xzJlInfo: function() {
                    var t = this, o = {
                        money: 0,
                        arr: []
                    };
                    if (1 == this.goodsInfo.isMaterial && this.goodsInfo.meterialData.length) {
                        var n = [];
                        this.goodsInfo.meterialData.forEach(function(e) {
                            e.a && (o.money += (t.outin, +e.SalesPrice), n.push(e));
                        }), o.money = +o.money.toFixed(2), o.arr = n;
                    }
                    return o;
                },
                xzspxx: function() {
                    var t = [];
                    console.log("this.xzSpecInfo", this.xzSpecInfo), this.xzSpecInfo.id && (t.push(this.xzSpecInfo.specsName), 
                    console.log("xzspxx", this.xzSpecInfo)), this.xzSxInfo.arr.length && t.push();
                }
            }),
            watch: {
                value: function(t) {
                    var o = this;
                    return c(e.default.mark(function n() {
                        var r, i;
                        return e.default.wrap(function(n) {
                            while (1) switch (n.prev = n.next) {
                              case 0:
                                if (!t) {
                                    n.next = 14;
                                    break;
                                }
                                return o.loading = !0, o.goodsInfo = {}, n.next = 5, o.util.request({
                                    url: o.api.ggxq,
                                    data: {
                                        id: o.co.id,
                                        storeId: o.storeid
                                    }
                                });

                              case 5:
                                r = n.sent, i = r.data, 1 != o.co.isSpecs || !i.specsData || 1 != i.specType && 2 != i.specType || i.specsData.forEach(function(t, o) {
                                    t.a = 0 == o ? 1 : 0;
                                }), 1 == o.co.isSpecs && i.specsData && 3 == i.specType && i.specsData.forEach(function(t, o) {
                                    t.attr_list.forEach(function(t, o) {
                                        t.a = 0 == o ? 1 : 0;
                                    });
                                }), 1 == o.co.isAttr && i.attrData && i.attrData.forEach(function(t) {
                                    t.attrStr.forEach(function(t, o) {
                                        t.a = 0 == o ? 1 : 0;
                                    });
                                }), o.goodsInfo = Object.assign({}, o.co, i, {
                                    ggnum: 1
                                }), o.goodsSpces = i.goods_attr, console.log("this.goodsSpces", o.goodsSpces), o.loading = !1;

                              case 14:
                              case "end":
                                return n.stop();
                            }
                        }, n);
                    }))();
                }
            }
        };
        o.default = p;
    },
    ff77: function(t, o, n) {
        "use strict";
        n.r(o);
        var e = n("b326"), r = n.n(e);
        for (var i in e) "default" !== i && function(t) {
            n.d(o, t, function() {
                return e[t];
            });
        }(i);
        o["default"] = r.a;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "components/goods/spec-create-component", {
    "components/goods/spec-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("a5de"));
    }
}, [ [ "components/goods/spec-create-component" ] ] ]);