(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "components/goods/goods-car" ], {
    "27a5": function(t, e, n) {
        "use strict";
        n.r(e);
        var r = n("fe33"), o = n.n(r);
        for (var s in r) "default" !== s && function(t) {
            n.d(e, t, function() {
                return r[t];
            });
        }(s);
        e["default"] = o.a;
    },
    cf29: function(t, e, n) {
        "use strict";
        n.r(e);
        var r = n("fa2f"), o = n("27a5");
        for (var s in o) "default" !== s && function(t) {
            n.d(e, t, function() {
                return o[t];
            });
        }(s);
        n("ff98");
        var i, a = n("f0c5"), u = Object(a["a"])(o["default"], r["b"], r["c"], !1, null, "7c83e626", null, !1, r["a"], i);
        e["default"] = u.exports;
    },
    f262: function(t, e, n) {},
    fa2f: function(t, e, n) {
        "use strict";
        var r;
        n.d(e, "b", function() {
            return o;
        }), n.d(e, "c", function() {
            return s;
        }), n.d(e, "a", function() {
            return r;
        });
        var o = function() {
            var t = this, e = t.$createElement, n = (t._self._c, 1 == t.type || 2 == t.type ? t.__get_style([ {
                bottom: t.carBtm + "rpx"
            }, t.sname, t.newCssShow ? {
                marginBottom: "2" == t.newCss.outType ? t.newCss.marginBottom + "px" : "",
                marginLeft: "2" == t.newCss.outType ? t.newCss.marginLR + "px" : "",
                marginRight: "2" == t.newCss.outType ? t.newCss.marginLR + "px" : "",
                borderRadius: "2" == t.newCss.outType ? t.newCss.circle + "px" : "",
                width: "2" == t.newCss.outType ? 100 - 2 * t.newCss.marginLR / 375 * 100 + "%" : "100%"
            } : "" ]) : null), r = 1 == t.type || 2 == t.type ? t.__get_style([ t.newCssShow ? {
                borderRadius: "2" == t.newCss.outType ? t.newCss.circle + "px" : "",
                background: "2" == t.newCss.outType ? "#fff" : "",
                boxShadow: "2" == t.newCss.outType ? "2rpx 2rpx 15rpx #DEDEDE" : ""
            } : "" ]) : null, o = 1 == t.type || 2 == t.type ? t.__get_style([ t.newCssShow ? {
                boxShadow: "2" == t.newCss.outType ? "2rpx 2rpx 15rpx #DEDEDE" : ""
            } : "" ]) : null, s = 1 != t.type && 2 != t.type || 1 != t.buytype || "1" != t.sjxx.shopData.distribution.isshow ? null : Number(Number(t.sjxx.shopData.distribution.money).toFixed(2)), i = 1 == t.type || 2 == t.type ? t.__get_style([ {
                background: t.qsText.reach ? t.tColor : "#999",
                border: t.qsText.reach ? "1rpx solid " + t.tColor : ""
            }, t.newCssShow ? {
                borderRadius: "2" == t.newCss.outType ? "0 " + t.newCss.circle + "px " + t.newCss.circle + "px 0" : ""
            } : "" ]) : null, a = 1 == t.type || 2 == t.type ? t.__map(t.carList, function(e, n) {
                var r = t.__get_orig(e), o = e.discountNum > 0 ? t.blxs(e.num * e.money) : null;
                return {
                    $orig: r,
                    m1: o
                };
            }) : null, u = 1 != t.type && 2 != t.type && 3 == t.type ? t.__get_style([ {
                bottom: t.carBtm + "rpx"
            }, t.sname ]) : null, c = 1 != t.type && 2 != t.type && 3 == t.type ? t.__map(t.carList, function(e, n) {
                var r = t.__get_orig(e), o = t.itemTotal(e);
                return {
                    $orig: r,
                    m2: o
                };
            }) : null, l = 1 != t.type && 2 != t.type && 3 != t.type && 4 == t.type ? t.__get_style([ {
                bottom: t.carBtm + "rpx"
            }, t.sname ]) : null, p = 1 != t.type && 2 != t.type && 3 != t.type && 4 == t.type && 1 == t.buytype && "1" == t.sjxx.shopData.distribution.isshow ? Number(Number(t.sjxx.shopData.distribution.money).toFixed(2)) : null, d = 1 != t.type && 2 != t.type && 3 != t.type && 4 == t.type ? t.__map(t.carList, function(e, n) {
                var r = t.__get_orig(e), o = e.discountNum > 0 ? t.blxs(e.num * e.money) : null;
                return {
                    $orig: r,
                    m4: o
                };
            }) : null;
            t._isMounted || (t.e0 = function(e) {
                t.ydshow = !1;
            }, t.e1 = function(e) {
                t.ydshow = !1;
            }), t.$mp.data = Object.assign({}, {
                $root: {
                    s0: n,
                    s1: r,
                    s2: o,
                    m0: s,
                    s3: i,
                    l0: a,
                    s4: u,
                    l1: c,
                    s5: l,
                    m3: p,
                    l2: d
                }
            });
        }, s = [];
    },
    fe33: function(t, e, n) {
        "use strict";
        (function(t) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var r = a(n("a34a")), o = n("26cb"), s = a(n("e1c0")), i = n("ddcf");
            function a(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            function u(t, e, n, r, o, s, i) {
                try {
                    var a = t[s](i), u = a.value;
                } catch (c) {
                    return void n(c);
                }
                a.done ? e(u) : Promise.resolve(u).then(r, o);
            }
            function c(t) {
                return function() {
                    var e = this, n = arguments;
                    return new Promise(function(r, o) {
                        var s = t.apply(e, n);
                        function i(t) {
                            u(s, r, o, i, a, "next", t);
                        }
                        function a(t) {
                            u(s, r, o, i, a, "throw", t);
                        }
                        i(void 0);
                    });
                };
            }
            function l(t, e) {
                var n = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var r = Object.getOwnPropertySymbols(t);
                    e && (r = r.filter(function(e) {
                        return Object.getOwnPropertyDescriptor(t, e).enumerable;
                    })), n.push.apply(n, r);
                }
                return n;
            }
            function p(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var n = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? l(Object(n), !0).forEach(function(e) {
                        d(t, e, n[e]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : l(Object(n)).forEach(function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e));
                    });
                }
                return t;
            }
            function d(t, e, n) {
                return e in t ? Object.defineProperty(t, e, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[e] = n, t;
            }
            var f = function() {
                n.e("components/goods/add-goods").then(function() {
                    return resolve(n("cc62"));
                }.bind(null, n)).catch(n.oe);
            }, h = function() {
                n.e("components/common/popup").then(function() {
                    return resolve(n("b94e"));
                }.bind(null, n)).catch(n.oe);
            }, y = function() {
                n.e("components/common/sq-btn").then(function() {
                    return resolve(n("cdf7"));
                }.bind(null, n)).catch(n.oe);
            }, m = {
                name: "goods-car",
                components: {
                    addGoods: f,
                    mgPopup: h,
                    sqBtn: y
                },
                props: {
                    type: {
                        type: String,
                        default: "1"
                    },
                    cName: {
                        type: String,
                        default: ""
                    },
                    sname: "",
                    carBtm: {
                        type: [ String, Number ],
                        default: ""
                    },
                    carlistPab: {
                        type: [ String, Number ],
                        default: ""
                    },
                    zIndex: {
                        type: Number,
                        default: 999
                    },
                    ingopay: {
                        type: String,
                        default: "1"
                    },
                    buytype: {
                        type: Number,
                        default: 2
                    },
                    sjxx: {
                        type: Object,
                        default: function() {
                            return {};
                        }
                    },
                    goodsList: {
                        type: Array,
                        default: function() {
                            return [];
                        }
                    },
                    startmoney: {
                        type: [ String, Number ],
                        default: ""
                    },
                    show: Boolean,
                    outin: {
                        type: String,
                        default: "1"
                    },
                    tableinfo: "",
                    newCssShow: {
                        type: Boolean,
                        default: !1
                    }
                },
                data: function() {
                    return {
                        showCar: !1,
                        ydshow: !0,
                        showSqtel: !1,
                        msgOpenByBalance: 0
                    };
                },
                watch: {
                    showCar: function(t) {
                        this.$emit("update:show", t);
                    },
                    show: function(t) {
                        t && (this.showCar = t);
                    },
                    mjInfo: {
                        handler: function(t) {
                            t.discount.length > 0 && this.$emit("hasmj", !0);
                        },
                        immediate: !0
                    }
                },
                mixins: [ i.utilMixins ],
                computed: p(p(p({}, (0, o.mapState)([ "newGoodLoad" ])), (0, o.mapState)({
                    vscarList: function(t) {
                        return t.scarList;
                    }
                })), {}, {
                    scarList: function() {
                        return 1 == this.outin ? this.vscarList.out : 3 == this.outin ? this.vscarList.fast : 2 == this.outin ? this.vscarList.ins : void 0;
                    },
                    carList: function() {
                        return this.scarList.data || [];
                    },
                    yysj: function() {
                        var t = "", e = this.sjxx.moreSet;
                        return 1 == e.timeType ? t = "24小时营业" : 2 == e.timeType && e.timeArr && (t = "".concat(e.timeArr[0].startTime, "-").concat(e.timeArr[0].ciri ? "次日" : "").concat(e.timeArr[0].endTime), 
                        e.timeArr[1] && (t += " " + "".concat(e.timeArr[1].startTime, "-").concat(e.timeArr[1].ciri ? "次日" : "").concat(e.timeArr[1].endTime)), 
                        e.timeArr[2] && (t += " " + "".concat(e.timeArr[2].startTime, "-").concat(e.timeArr[2].ciri ? "次日" : "").concat(e.timeArr[2].endTime))), 
                        t;
                    },
                    cshow: function() {
                        return 0 == this.carList.length && (this.showCar = !1), 2 == this.type || 3 == this.type ? this.addgb : (1 == this.sjxx.shopData.storeOpen || 2 == this.sjxx.shopData.storeOpen && 1 == this.sjxx.moreSet.status) && this.carList.length > 0;
                    },
                    addgb: function() {
                        return 1 == this.sjxx.shopData.storeOpen || 2 == this.sjxx.shopData.storeOpen && 1 == this.sjxx.moreSet.status;
                    },
                    xxshow: function() {
                        return 1 != this.sjxx.shopData.storeOpen && this.ydshow;
                    },
                    havezq: function() {
                        return this.sjxx.moreSet.distributionSupport && this.sjxx.moreSet.distributionSupport.find(function(t) {
                            return 2 == t;
                        });
                    },
                    getTotal: function() {
                        var t = 0;
                        return this.carList.forEach(function(e) {
                            t += +e.num;
                        }), {
                            total: +this.scarList.oldPrice || 0,
                            price: +this.scarList.price,
                            spzj: +(this.scarList.oldPrice - this.scarList.boxMoney).toFixed(2),
                            bzf: +this.scarList.boxMoney || 0,
                            num: t,
                            hyzk: this.blxs(this.scarList.vipDiscount)
                        };
                    },
                    carPrice: function() {
                        var t = this.mjInfo.mjMoney;
                        return {
                            reduceMoney: t,
                            nowPrice: this.getTotal.price
                        };
                    },
                    mjInfo: function() {
                        var t = this.getTotal.spzj, e = [], n = "", r = this.scarList.reduce, o = -1, s = "";
                        return this.sjxx.discount.reduce.type ? (e = [].concat(this.sjxx.discount.reduce.moneyArr), 
                        n = this.sjxx.discount.reduce.type, e.length && (1 == n ? s = Math.floor(t / e[0].fullMoney) <= 0 ? "每满".concat(this.sl + e[0].fullMoney, "减").concat(e[0].money) : "已减".concat(this.sl + r) : (o = e.findIndex(function(e) {
                            return t >= e.fullMoney;
                        }), -1 == o ? s = "满".concat(this.sl).concat(e[e.length - 1].fullMoney, "减").concat(this.sl).concat(e[e.length - 1].money, ",还差").concat(this.sl).concat((e[e.length - 1].fullMoney - t).toFixed(2)) : 0 == o ? s = "已减".concat(this.sl + r) : o > 0 && (s = "已减".concat(this.sl + r, ",再满").concat(this.sl + e[o - 1].fullMoney, "减").concat(this.sl + e[o - 1].money))))) : r = 0, 
                        1 == this.buytype && +this.startMoney > this.getTotal.total && (s = "还差".concat(this.sl).concat((+this.startMoney - this.getTotal.total).toFixed(2), "起送")), 
                        {
                            mjMoney: r,
                            text: s,
                            discount: [].concat(e).reverse()
                        };
                    },
                    startMoney: function() {
                        return this.startmoney || this.sjxx.shopData.distribution.startMoney;
                    },
                    sendCouponConfig: function() {
                        var t = this;
                        return c(r.default.mark(function e() {
                            var n, o;
                            return r.default.wrap(function(e) {
                                while (1) switch (e.prev = e.next) {
                                  case 0:
                                    return n = {
                                        ident: "sendCouponSet"
                                    }, e.next = 3, t.util.request({
                                        url: t.api.config,
                                        method: "get",
                                        data: n
                                    });

                                  case 3:
                                    o = e.sent, o.data.hasOwnProperty("msgOpenByBalance") && o.data.msgOpenByBalance && (t.msgOpenByBalance = o.data.msgOpenByBalance);

                                  case 5:
                                  case "end":
                                    return e.stop();
                                }
                            }, e);
                        }))();
                    },
                    qsText: function() {
                        var t = this.getTotal.total, e = +this.startMoney, n = "", r = !1;
                        if (this.type <= 2 || 4 == this.type) if (t <= 0 || !this.carList.length) n = 1 == this.buytype ? this.sl + e + "起送" : "去下单"; else if (t < e && 1 == this.buytype) {
                            var o = +(e - t).toFixed(2);
                            n = "差".concat(this.sl) + o + "起送";
                        } else n = "去结算", r = !0; else 3 == this.type && (r = !0, n = t <= 0 || !this.carList.length ? "查看购物车" : "选好了");
                        return {
                            text: n,
                            reach: r
                        };
                    },
                    havebxp: {
                        get: function() {
                            return this.sjxx.data.findIndex(function(t) {
                                return 1 == t.isRequire;
                            }) > -1;
                        }
                    },
                    newCss: {
                        get: function() {
                            var t, e, n = {
                                marginBottom: "",
                                marginLR: "",
                                circle: "",
                                outType: "1"
                            };
                            if (null === (t = this.$store.state.layout.index.body) || void 0 === t || null === (e = t.menu[0]) || void 0 === e ? void 0 : e.styles) {
                                var r, o, s = null === (r = this.$store.state.layout.index.body) || void 0 === r || null === (o = r.menu[0]) || void 0 === o ? void 0 : o.styles;
                                n = {
                                    marginBottom: Number(s.marginBottom ? s.marginBottom : 0) / 2,
                                    marginLR: s.marginLR || "",
                                    circle: s.circle || "",
                                    outType: "2" == (null === s || void 0 === s ? void 0 : s.outType) ? "2" : "1"
                                };
                            }
                            return n;
                        }
                    }
                }),
                methods: p(p(p({}, (0, o.mapMutations)([ "setCarList" ])), (0, o.mapActions)([ "clearMycar", "getConfig" ])), {}, {
                    openCar: function() {
                        this.showCar = !0;
                    },
                    closeCar: function() {
                        this.showCar = !1;
                    },
                    qsTextt: function() {
                        return this.qsText;
                    },
                    dec: function(t, e) {
                        this.$emit("dec", {
                            addwz: t.addwz,
                            g: e
                        });
                    },
                    add: function(t, e) {
                        this.$emit("add", {
                            addwz: t.addwz,
                            g: e
                        });
                    },
                    clearCar: function() {
                        var t = this;
                        return c(r.default.mark(function e() {
                            return r.default.wrap(function(e) {
                                while (1) switch (e.prev = e.next) {
                                  case 0:
                                    return e.prev = 0, e.next = 3, t.util.modal("确认清空购物车吗？");

                                  case 3:
                                    return e.next = 5, t.clearMycar({
                                        storeId: t.sjxx.shopData.id,
                                        item: t.outin,
                                        key: 1 == t.outin ? "out" : 2 == t.outin ? "ins" : "fast"
                                    });

                                  case 5:
                                    t.$emit("celar"), t.showCar = !1, e.next = 11;
                                    break;

                                  case 9:
                                    e.prev = 9, e.t0 = e["catch"](0);

                                  case 11:
                                  case "end":
                                    return e.stop();
                                }
                            }, e, null, [ [ 0, 9 ] ]);
                        }))();
                    },
                    goPay: function(e) {
                        var n = this;
                        return c(r.default.mark(function o() {
                            var s, i, a, u, c, l, p, d, f, h;
                            return r.default.wrap(function(r) {
                                while (1) switch (r.prev = r.next) {
                                  case 0:
                                    if (n.qsText.reach) {
                                        r.next = 2;
                                        break;
                                    }
                                    return r.abrupt("return");

                                  case 2:
                                    return r.next = 4, n.checkLogin(n);

                                  case 4:
                                    if (r.sent) {
                                        r.next = 6;
                                        break;
                                    }
                                    return r.abrupt("return");

                                  case 6:
                                    if (n.loading = !0, n.jjmbxx) {
                                        r.next = 18;
                                        break;
                                    }
                                    return r.prev = 8, r.next = 11, n.requestSM("sendCoupon");

                                  case 11:
                                    r.next = 18;
                                    break;

                                  case 13:
                                    return r.prev = 13, r.t0 = r["catch"](8), n.jjmbxx = !0, n.loading = !1, r.abrupt("return");

                                  case 18:
                                    if (1 != n.system.member.payType || n.user.userTel) {
                                        r.next = 20;
                                        break;
                                    }
                                    return r.abrupt("return", n.showSqtel = !0);

                                  case 20:
                                    if (console.log(n.carList, "this.ingopay == 1", 1 == n.ingopay), 1 != n.ingopay) {
                                        r.next = 43;
                                        break;
                                    }
                                    if (1 != n.buytype || getApp().globalData.xzdzInfo) {
                                        r.next = 25;
                                        break;
                                    }
                                    return n.go({
                                        t: 1,
                                        url: "/yb_wm/my/address/index?from=3&storeId=".concat(n.sjxx.shopData.id)
                                    }), r.abrupt("return");

                                  case 25:
                                    if (!n.havebxp || 3 == n.type) {
                                        r.next = 30;
                                        break;
                                    }
                                    for (s = n.goodsList.filter(function(t) {
                                        return 1 == t.isRequire;
                                    }), i = 0, a = n.carList.map(function(t) {
                                        return t.typePid;
                                    }), u = [], c = 0; c < s.length; c++) -1 != a.indexOf(s[c].id) ? i += 1 : u.push(s[c].name);
                                    if (!(i < s.length)) {
                                        r.next = 30;
                                        break;
                                    }
                                    return r.abrupt("return", n.util.message("请先添加“".concat(u.join("、"), "”分类下的必选品"), 3, 3e3));

                                  case 30:
                                    if (!n.havebxp || 3 != n.type) {
                                        r.next = 36;
                                        break;
                                    }
                                    if ("选好了" != n.qsText.text || !n.tableinfo || n.tableinfo.orderInfo.goodsArr) {
                                        r.next = 36;
                                        break;
                                    }
                                    for (l = n.goodsList.filter(function(t) {
                                        return 1 == t.isRequire;
                                    }), p = 0, d = n.carList.map(function(t) {
                                        return t.typePid;
                                    }), f = [], h = 0; h < l.length; h++) -1 != d.indexOf(l[h].id) ? p += 1 : f.push(l[h].name);
                                    if (!(p < l.length)) {
                                        r.next = 36;
                                        break;
                                    }
                                    return r.abrupt("return", n.util.message("请先添加“".concat(f.join("、"), "”分类下的必选品"), 3, 3e3));

                                  case 36:
                                    n.util.showLoading(), 2 != n.outin && t.setStorageSync("carInfo", {
                                        carList: n.carList,
                                        getTotal: n.getTotal,
                                        mjInfo: n.mjInfo,
                                        carPrice: n.carPrice,
                                        sjxx: {
                                            discount: n.sjxx.discount,
                                            moreSet: n.sjxx.moreSet,
                                            outSet: n.sjxx.moreSet.distributionSupport,
                                            shopData: n.sjxx.shopData
                                        },
                                        buyType: n.buytype
                                    }), 1 == n.outin ? n.go({
                                        t: e || 1,
                                        url: "/yb_wm/shop/out/pay-order"
                                    }) : 3 == n.outin ? n.go({
                                        url: "/yb_wm/shop/ffmode/pay-order"
                                    }) : 2 == n.outin && (t.setStorageSync("carInfo", {
                                        sjxx: {
                                            discount: n.sjxx.discount,
                                            moreSet: n.sjxx.moreSet,
                                            outSet: n.sjxx.moreSet.distributionSupport,
                                            shopData: n.sjxx.shopData
                                        }
                                    }), n.go({
                                        url: "/yb_wm/shop/in/car?tableInfo=" + encodeURIComponent(JSON.stringify(n.tableinfo))
                                    })), n.showCar = !1, t.hideLoading(), r.next = 45;
                                    break;

                                  case 43:
                                    console.log("laidao  "), n.$emit("gopay");

                                  case 45:
                                  case "end":
                                    return r.stop();
                                }
                            }, o, null, [ [ 8, 13 ] ]);
                        }))();
                    },
                    itemTotal: function(t) {
                        return +(t.money * t.num).toFixed(2);
                    },
                    colorToRGB: function(t) {
                        return s.default.colorToRGB(t);
                    }
                }),
                created: function() {}
            };
            e.default = m;
        }).call(this, n("543d")["default"]);
    },
    ff98: function(t, e, n) {
        "use strict";
        var r = n("f262"), o = n.n(r);
        o.a;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "components/goods/goods-car-create-component", {
    "components/goods/goods-car-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("cf29"));
    }
}, [ [ "components/goods/goods-car-create-component" ] ] ]);