(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "components/goods/add-goods" ], {
    "212e": function(t, e, n) {
        "use strict";
        var o;
        n.d(e, "b", function() {
            return a;
        }), n.d(e, "c", function() {
            return d;
        }), n.d(e, "a", function() {
            return o;
        });
        var a = function() {
            var t = this, e = t.$createElement;
            t._self._c;
            t._isMounted || (t.e0 = function(e) {
                e.stopPropagation(), t.isClose && t.$emit("add", {
                    addwz: t.addwz
                });
            }, t.e1 = function(e) {
                e.stopPropagation(), t.isClose && t.$emit("dec", {
                    addwz: t.addwz
                });
            }, t.e2 = function(e) {
                e.stopPropagation(), t.isClose && t.$emit("add", {
                    addwz: t.addwz
                });
            });
        }, d = [];
    },
    "9ec1": function(t, e, n) {
        "use strict";
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        n("26cb");
        var o = {
            name: "add-goods",
            props: {
                co: {
                    type: Object,
                    default: function() {
                        return {};
                    }
                },
                cname: {
                    type: String,
                    default: ""
                },
                numc: String,
                addwz: {
                    type: String,
                    default: "1"
                },
                outin: {
                    type: String,
                    default: "1"
                },
                pcname: "",
                isprice: {
                    type: Number,
                    default: 1
                },
                isyprice: {
                    type: Boolean,
                    default: !1
                },
                isunit: {
                    type: Boolean,
                    default: !1
                },
                showspec: {
                    type: Boolean,
                    default: !0
                },
                showjj: {
                    type: Boolean,
                    default: !0
                },
                nocheckgd: {
                    type: Boolean,
                    default: !1
                },
                addgb: {
                    type: Boolean,
                    default: !0
                },
                color: {
                    type: String,
                    default: ""
                }
            },
            data: function() {
                return {};
            },
            computed: {
                isClose: function() {
                    return this.nocheckgd || this.addgb;
                }
            },
            methods: {}
        };
        e.default = o;
    },
    ad61: function(t, e, n) {
        "use strict";
        n.r(e);
        var o = n("9ec1"), a = n.n(o);
        for (var d in o) "default" !== d && function(t) {
            n.d(e, t, function() {
                return o[t];
            });
        }(d);
        e["default"] = a.a;
    },
    cc62: function(t, e, n) {
        "use strict";
        n.r(e);
        var o = n("212e"), a = n("ad61");
        for (var d in a) "default" !== d && function(t) {
            n.d(e, t, function() {
                return a[t];
            });
        }(d);
        n("f33c");
        var u, c = n("f0c5"), i = Object(c["a"])(a["default"], o["b"], o["c"], !1, null, "637431a6", null, !1, o["a"], u);
        e["default"] = i.exports;
    },
    f058: function(t, e, n) {},
    f33c: function(t, e, n) {
        "use strict";
        var o = n("f058"), a = n.n(o);
        a.a;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "components/goods/add-goods-create-component", {
    "components/goods/add-goods-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("cc62"));
    }
}, [ [ "components/goods/add-goods-create-component" ] ] ]);