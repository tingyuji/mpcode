(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "components/goods/ecshop/get-address" ], {
    3050: function(e, t, r) {
        "use strict";
        var n;
        r.d(t, "b", function() {
            return o;
        }), r.d(t, "c", function() {
            return c;
        }), r.d(t, "a", function() {
            return n;
        });
        var o = function() {
            var e = this, t = e.$createElement;
            e._self._c;
        }, c = [];
    },
    5845: function(e, t, r) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0;
        var n = r("26cb");
        function o(e, t) {
            var r = Object.keys(e);
            if (Object.getOwnPropertySymbols) {
                var n = Object.getOwnPropertySymbols(e);
                t && (n = n.filter(function(t) {
                    return Object.getOwnPropertyDescriptor(e, t).enumerable;
                })), r.push.apply(r, n);
            }
            return r;
        }
        function c(e) {
            for (var t = 1; t < arguments.length; t++) {
                var r = null != arguments[t] ? arguments[t] : {};
                t % 2 ? o(Object(r), !0).forEach(function(t) {
                    s(e, t, r[t]);
                }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : o(Object(r)).forEach(function(t) {
                    Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t));
                });
            }
            return e;
        }
        function s(e, t, r) {
            return t in e ? Object.defineProperty(e, t, {
                value: r,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : e[t] = r, e;
        }
        var a = {
            name: "get-address",
            props: {
                cname: "",
                address: "",
                ptype: {
                    type: String,
                    default: "1"
                },
                color: {
                    type: String,
                    default: "#333"
                },
                mw: {
                    type: String,
                    default: "360"
                }
            },
            data: function() {
                return {};
            },
            computed: c(c({}, (0, n.mapState)([ "sjxx" ])), {}, {
                desc: function() {
                    return this.address ? "".concat(this.address.userName, "(").concat(this.address.sex, ") ").concat(this.address.userTel) : "请选择地址";
                }
            }),
            methods: {
                goChoose: function() {
                    "1" == this.ptype ? this.go({
                        t: 1,
                        url: "/yb_wm/my/address/ecshop-index?from=1&storeId=".concat(this.sjxx.shopData.id, "&is_ecshop=1")
                    }) : "2" == this.ptype && this.go({
                        t: 1,
                        url: "/yb_wm/my/address/ecshop-index?from=5&is_ecshop=1"
                    });
                }
            }
        };
        t.default = a;
    },
    "5b41": function(e, t, r) {
        "use strict";
        r.r(t);
        var n = r("3050"), o = r("75f4");
        for (var c in o) "default" !== c && function(e) {
            r.d(t, e, function() {
                return o[e];
            });
        }(c);
        var s, a = r("f0c5"), u = Object(a["a"])(o["default"], n["b"], n["c"], !1, null, "30c122b8", null, !1, n["a"], s);
        t["default"] = u.exports;
    },
    "75f4": function(e, t, r) {
        "use strict";
        r.r(t);
        var n = r("5845"), o = r.n(n);
        for (var c in n) "default" !== c && function(e) {
            r.d(t, e, function() {
                return n[e];
            });
        }(c);
        t["default"] = o.a;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "components/goods/ecshop/get-address-create-component", {
    "components/goods/ecshop/get-address-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("5b41"));
    }
}, [ [ "components/goods/ecshop/get-address-create-component" ] ] ]);