(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "components/goods/ecshop/add-goods" ], {
    "17b6": function(t, e, n) {
        "use strict";
        var o;
        n.d(e, "b", function() {
            return a;
        }), n.d(e, "c", function() {
            return d;
        }), n.d(e, "a", function() {
            return o;
        });
        var a = function() {
            var t = this, e = t.$createElement;
            t._self._c;
            t._isMounted || (t.e0 = function(e) {
                e.stopPropagation(), t.isClose && t.$emit("add", {
                    addwz: t.addwz
                });
            }, t.e1 = function(e) {
                e.stopPropagation(), t.isClose && t.$emit("dec", {
                    addwz: t.addwz
                });
            }, t.e2 = function(e) {
                e.stopPropagation(), t.isClose && t.$emit("add", {
                    addwz: t.addwz
                });
            });
        }, d = [];
    },
    "5ac1": function(t, e, n) {
        "use strict";
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        n("26cb");
        var o = {
            name: "add-goods",
            props: {
                co: {
                    type: Object,
                    default: function() {
                        return {};
                    }
                },
                cname: {
                    type: String,
                    default: ""
                },
                numc: String,
                addwz: {
                    type: String,
                    default: "1"
                },
                outin: {
                    type: String,
                    default: "1"
                },
                pcname: "",
                isprice: {
                    type: Number,
                    default: 1
                },
                isyprice: {
                    type: Boolean,
                    default: !1
                },
                isunit: {
                    type: Boolean,
                    default: !1
                },
                showspec: {
                    type: Boolean,
                    default: !0
                },
                showjj: {
                    type: Boolean,
                    default: !0
                },
                nocheckgd: {
                    type: Boolean,
                    default: !1
                },
                addgb: {
                    type: Boolean,
                    default: !0
                },
                color: {
                    type: String,
                    default: ""
                }
            },
            data: function() {
                return {};
            },
            computed: {
                isClose: function() {
                    return this.nocheckgd || this.addgb;
                }
            },
            methods: {}
        };
        e.default = o;
    },
    "77fc": function(t, e, n) {},
    a471: function(t, e, n) {
        "use strict";
        n.r(e);
        var o = n("5ac1"), a = n.n(o);
        for (var d in o) "default" !== d && function(t) {
            n.d(e, t, function() {
                return o[t];
            });
        }(d);
        e["default"] = a.a;
    },
    b826: function(t, e, n) {
        "use strict";
        n.r(e);
        var o = n("17b6"), a = n("a471");
        for (var d in a) "default" !== d && function(t) {
            n.d(e, t, function() {
                return a[t];
            });
        }(d);
        n("d5d67");
        var u, c = n("f0c5"), i = Object(c["a"])(a["default"], o["b"], o["c"], !1, null, "6e18b89e", null, !1, o["a"], u);
        e["default"] = i.exports;
    },
    d5d67: function(t, e, n) {
        "use strict";
        var o = n("77fc"), a = n.n(o);
        a.a;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "components/goods/ecshop/add-goods-create-component", {
    "components/goods/ecshop/add-goods-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("b826"));
    }
}, [ [ "components/goods/ecshop/add-goods-create-component" ] ] ]);