(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "components/goods/index" ], {
    "027a": function(t, e, o) {},
    "0ded": function(t, e, o) {
        "use strict";
        var n;
        o.d(e, "b", function() {
            return i;
        }), o.d(e, "c", function() {
            return c;
        }), o.d(e, "a", function() {
            return n;
        });
        var i = function() {
            var t = this, e = t.$createElement, o = (t._self._c, 1 == t.type ? t.__map(t.dList, function(e, o) {
                var n = t.__get_orig(e), i = t.vipPrice(e), c = i ? t.vipPrice(e) : null, a = t.isunit(e), r = t.isyprice(e);
                return {
                    $orig: n,
                    m0: i,
                    m1: c,
                    m2: a,
                    m3: r
                };
            }) : null), n = 1 != t.type && 2 != t.type && 3 == t.type && t.co.labelName ? t.cTR(t.co.labelColor) : null, i = 1 != t.type && 2 != t.type && 3 == t.type ? Number(t.co.vipPrice) : null, c = 1 != t.type && 2 != t.type && 3 == t.type ? Number(t.co.activityGoodData.activityMoney) : null, a = 1 != t.type && 2 != t.type && 3 == t.type ? t.isunit(t.co) : null, r = 1 != t.type && 2 != t.type && 3 == t.type ? t.isyprice(t.co) : null, u = 1 != t.type && 2 != t.type && 3 == t.type && t.co.activityGoodData.type > 0 && t.co.activityGoodData.type < 3 && 1 != t.co.activityGoodData.type ? Number(t.co.activityGoodData.discount) : null, p = 1 != t.type && 2 != t.type && 3 == t.type && t.co.activityGoodData.type > 0 && !(t.co.activityGoodData.type < 3) && 3 != t.co.activityGoodData.type && 4 == t.co.activityGoodData.type ? Number(t.co.activityGoodData.discount) : null, d = 1 != t.type && 2 != t.type && 3 != t.type && 6 == t.type ? t.__map(t.dList, function(e, o) {
                var n = t.__get_orig(e), i = t.itemTotal(e.money, e.num);
                return {
                    $orig: n,
                    m11: i
                };
            }) : null, y = 1 != t.type && 2 != t.type && 3 != t.type && 6 != t.type && 7 == t.type && t.co.labelName ? t.cTR(t.co.labelColor) : null, l = 1 != t.type && 2 != t.type && 3 != t.type && 6 != t.type && 7 == t.type ? Number(t.co.vipPrice) : null, s = 1 != t.type && 2 != t.type && 3 != t.type && 6 != t.type && 7 == t.type ? Number(t.co.activityGoodData.activityMoney) : null, f = 1 != t.type && 2 != t.type && 3 != t.type && 6 != t.type && 7 == t.type && t.co.activityGoodData.type > 0 && t.co.activityGoodData.type < 3 && 1 != t.co.activityGoodData.type ? Number(t.co.activityGoodData.discount) : null, m = 1 != t.type && 2 != t.type && 3 != t.type && 6 != t.type && 7 == t.type && t.co.activityGoodData.type > 0 && !(t.co.activityGoodData.type < 3) && 3 != t.co.activityGoodData.type && 4 == t.co.activityGoodData.type ? Number(t.co.activityGoodData.discount) : null;
            t.$mp.data = Object.assign({}, {
                $root: {
                    l0: o,
                    m4: n,
                    m5: i,
                    m6: c,
                    m7: a,
                    m8: r,
                    m9: u,
                    m10: p,
                    l1: d,
                    m12: y,
                    m13: l,
                    m14: s,
                    m15: f,
                    m16: m
                }
            });
        }, c = [];
    },
    6879: function(t, e, o) {
        "use strict";
        o.r(e);
        var n = o("bff9"), i = o.n(n);
        for (var c in n) "default" !== c && function(t) {
            o.d(e, t, function() {
                return n[t];
            });
        }(c);
        e["default"] = i.a;
    },
    "7c5f": function(t, e, o) {
        "use strict";
        o.r(e);
        var n = o("0ded"), i = o("6879");
        for (var c in i) "default" !== c && function(t) {
            o.d(e, t, function() {
                return i[t];
            });
        }(c);
        o("c89e");
        var a, r = o("f0c5"), u = Object(r["a"])(i["default"], n["b"], n["c"], !1, null, "7b583de5", null, !1, n["a"], a);
        e["default"] = u.exports;
    },
    bff9: function(t, e, o) {
        "use strict";
        (function(t) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var n = a(o("a34a")), i = o("26cb"), c = a(o("e1c0"));
            function a(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            function r(t, e, o, n, i, c, a) {
                try {
                    var r = t[c](a), u = r.value;
                } catch (p) {
                    return void o(p);
                }
                r.done ? e(u) : Promise.resolve(u).then(n, i);
            }
            function u(t) {
                return function() {
                    var e = this, o = arguments;
                    return new Promise(function(n, i) {
                        var c = t.apply(e, o);
                        function a(t) {
                            r(c, n, i, a, u, "next", t);
                        }
                        function u(t) {
                            r(c, n, i, a, u, "throw", t);
                        }
                        a(void 0);
                    });
                };
            }
            function p(t, e) {
                var o = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(t);
                    e && (n = n.filter(function(e) {
                        return Object.getOwnPropertyDescriptor(t, e).enumerable;
                    })), o.push.apply(o, n);
                }
                return o;
            }
            function d(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var o = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? p(Object(o), !0).forEach(function(e) {
                        y(t, e, o[e]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(o)) : p(Object(o)).forEach(function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(o, e));
                    });
                }
                return t;
            }
            function y(t, e, o) {
                return e in t ? Object.defineProperty(t, e, {
                    value: o,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[e] = o, t;
            }
            var l = function() {
                o.e("components/goods/add-goods").then(function() {
                    return resolve(o("cc62"));
                }.bind(null, o)).catch(o.oe);
            }, s = function() {
                o.e("components/common/block-b").then(function() {
                    return resolve(o("569d"));
                }.bind(null, o)).catch(o.oe);
            }, f = function() {
                o.e("components/common/mg-cell").then(function() {
                    return resolve(o("c0b8"));
                }.bind(null, o)).catch(o.oe);
            }, m = {
                name: "goods",
                components: {
                    addGoods: l,
                    bkB: s,
                    MgCell: f
                },
                props: {
                    dList: {
                        type: Array,
                        default: function() {
                            return [];
                        }
                    },
                    co: Object,
                    type: {
                        type: String,
                        default: "1"
                    },
                    showbody: {
                        type: Boolean,
                        default: !0
                    },
                    showadd: {
                        type: Boolean,
                        default: !0
                    },
                    addtype: {
                        type: String,
                        default: "1"
                    },
                    outin: {
                        type: String,
                        default: "1"
                    },
                    color: {
                        type: String,
                        default: ""
                    },
                    last: {
                        type: Boolean,
                        default: !1
                    },
                    storeid: {
                        type: String,
                        default: ""
                    },
                    addgb: {
                        type: Boolean,
                        default: !0
                    },
                    xsSpec: {
                        type: Boolean,
                        default: !0
                    }
                },
                data: function() {
                    return {};
                },
                computed: d({}, (0, i.mapState)({
                    orderset: function(t) {
                        return t.config.orderset;
                    }
                })),
                methods: {
                    dec: function(t, e) {
                        1 == this.addtype ? this.$emit("dec", e) : this.$emit("dec", {
                            addwz: t.addwz,
                            g: e
                        });
                    },
                    add: function(e, o) {
                        1 == this.addtype ? "1" == o.isPack ? (t.setStorageSync("setMealObj", o), this.go({
                            t: 1,
                            url: "/yb_wm/shop/setMeal/index"
                        })) : this.$emit("add", {
                            g: o
                        }) : "1" == o.isPack ? (t.setStorageSync("setMealObj", o), this.go({
                            t: 1,
                            url: "/yb_wm/shop/setMeal/index"
                        })) : this.$emit("add", {
                            addwz: e.addwz,
                            g: o
                        });
                    },
                    goodinfo: function(t) {
                        this.go({
                            t: 1,
                            url: "/yb_wm/shop/out/goods-dl?gid=".concat(t, "&storeId=").concat(this.storeid, "&page=shopGoods")
                        });
                    },
                    itemTotal: function(t, e) {
                        return (t * e).toFixed(2);
                    },
                    isunit: function(t) {
                        return !!t.unit;
                    },
                    isyprice: function(t) {
                        return this.co.activityGoodData.type > 0 && this.co.activityGoodData.type < 4;
                    },
                    vipPrice: function(t) {
                        return 1 == this.outin ? t.outVipPrice > 0 ? t.outVipPrice : "" : t.inVipPrice > 0 ? t.inVipPrice : "";
                    },
                    cTR: function(t) {
                        return c.default.colorToRGB(t);
                    }
                },
                created: function() {
                    return u(n.default.mark(function t() {
                        return n.default.wrap(function(t) {
                            while (1) switch (t.prev = t.next) {
                              case 0:
                              case "end":
                                return t.stop();
                            }
                        }, t);
                    }))();
                }
            };
            e.default = m;
        }).call(this, o("543d")["default"]);
    },
    c89e: function(t, e, o) {
        "use strict";
        var n = o("027a"), i = o.n(n);
        i.a;
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "components/goods/index-create-component", {
    "components/goods/index-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("7c5f"));
    }
}, [ [ "components/goods/index-create-component" ] ] ]);