(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "components/goods/store/store-info" ], {
    "88cb": function(t, e, n) {
        "use strict";
        n.r(e);
        var r = n("9851"), o = n.n(r);
        for (var c in r) "default" !== c && function(t) {
            n.d(e, t, function() {
                return r[t];
            });
        }(c);
        e["default"] = o.a;
    },
    9851: function(t, e, n) {
        "use strict";
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var r = i(n("a34a")), o = n("26cb"), c = i(n("e1c0"));
        function i(t) {
            return t && t.__esModule ? t : {
                default: t
            };
        }
        function u(t, e, n, r, o, c, i) {
            try {
                var u = t[c](i), a = u.value;
            } catch (s) {
                return void n(s);
            }
            u.done ? e(a) : Promise.resolve(a).then(r, o);
        }
        function a(t) {
            return function() {
                var e = this, n = arguments;
                return new Promise(function(r, o) {
                    var c = t.apply(e, n);
                    function i(t) {
                        u(c, r, o, i, a, "next", t);
                    }
                    function a(t) {
                        u(c, r, o, i, a, "throw", t);
                    }
                    i(void 0);
                });
            };
        }
        function s(t, e) {
            var n = Object.keys(t);
            if (Object.getOwnPropertySymbols) {
                var r = Object.getOwnPropertySymbols(t);
                e && (r = r.filter(function(e) {
                    return Object.getOwnPropertyDescriptor(t, e).enumerable;
                })), n.push.apply(n, r);
            }
            return n;
        }
        function f(t) {
            for (var e = 1; e < arguments.length; e++) {
                var n = null != arguments[e] ? arguments[e] : {};
                e % 2 ? s(Object(n), !0).forEach(function(e) {
                    l(t, e, n[e]);
                }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : s(Object(n)).forEach(function(e) {
                    Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e));
                });
            }
            return t;
        }
        function l(t, e, n) {
            return e in t ? Object.defineProperty(t, e, {
                value: n,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }) : t[e] = n, t;
        }
        var d = function() {
            n.e("components/common/popup").then(function() {
                return resolve(n("b94e"));
            }.bind(null, n)).catch(n.oe);
        }, p = function() {
            Promise.all([ n.e("common/vendor"), n.e("components/common/mg-coupon") ]).then(function() {
                return resolve(n("76b6"));
            }.bind(null, n)).catch(n.oe);
        }, m = {
            name: "mg-share",
            components: {
                mgPopup: d,
                mgCoupon: p
            },
            props: {
                co: {
                    type: Object,
                    default: function() {
                        return {};
                    }
                },
                type: {
                    type: String,
                    default: "1"
                },
                value: {
                    type: Boolean,
                    default: !1
                },
                ptype: String,
                qlist: Array,
                sjqb: Array
            },
            data: function() {
                return {
                    loading: !1,
                    sjyhqArr: [],
                    zkshow: !1
                };
            },
            computed: f(f({}, (0, o.mapState)({
                orderset: function(t) {
                    return t.config.orderset;
                }
            })), {}, {
                show: {
                    get: function() {
                        return this.value;
                    },
                    set: function(t) {
                        this.$emit("input", t);
                    }
                },
                mjtxt: function() {
                    return 1 == this.co.discount.reduce.type ? "每满".concat(this.co.discount.reduce.moneyArr[0].fullMoney, "减").concat(this.co.discount.reduce.moneyArr[0].money) : 2 == this.co.discount.reduce.type ? this.co.discount.reduce.moneyArr.map(function(t) {
                        return "满".concat(t.fullMoney, "减").concat(t.money);
                    }).reverse().toString() : void 0;
                },
                mztxt: function() {
                    return this.co.discount.give.moneyArr && this.co.discount.give.moneyArr.map(function(t) {
                        return "满".concat(t.fullMoney, "赠").concat(t.give);
                    }).reverse().toString();
                },
                yysj: function() {
                    var t = "", e = this.co.moreSet;
                    return 1 == e.timeType ? t = "24小时营业" : 2 == e.timeType && e.timeArr && (t = "".concat(e.timeArr[0].startTime, "-").concat(e.timeArr[0].ciri ? "次日" : "").concat(e.timeArr[0].endTime), 
                    e.timeArr[1] && (t += " " + "".concat(e.timeArr[1].startTime, "-").concat(e.timeArr[1].ciri ? "次日" : "").concat(e.timeArr[1].endTime)), 
                    e.timeArr[2] && (t += " " + "".concat(e.timeArr[2].startTime, "-").concat(e.timeArr[2].ciri ? "次日" : "").concat(e.timeArr[2].endTime))), 
                    t;
                }
            }),
            watch: {
                qlist: function(t) {
                    t.length ? this.sjyhqArr = c.default.deepCopy(t) : (this.sjyhqArr = [], this.zkshow = !1);
                }
            },
            methods: {
                btntap: function(t) {
                    var e = this;
                    return a(r.default.mark(function n() {
                        var o;
                        return r.default.wrap(function(n) {
                            while (1) switch (n.prev = n.next) {
                              case 0:
                                return n.next = 2, e.checkLogin(e);

                              case 2:
                                if (n.sent) {
                                    n.next = 4;
                                    break;
                                }
                                return n.abrupt("return");

                              case 4:
                                return n.next = 6, e.util.request({
                                    url: e.api.lqyhq,
                                    method: "POST",
                                    mask: 1,
                                    data: {
                                        couponId: t
                                    }
                                });

                              case 6:
                                o = n.sent, o && e.$set(e.sjyhqArr.find(function(e) {
                                    return e.id == t;
                                }), "islq", !0);

                              case 8:
                              case "end":
                                return n.stop();
                            }
                        }, n);
                    }))();
                },
                ckwz: function() {
                    this.util.ckWz({
                        lat: this.co.shopData.lat,
                        lng: this.co.shopData.lng,
                        name: this.co.shopData.name,
                        address: this.co.shopData.address
                    });
                },
                ckda: function() {
                    this.go({
                        t: 1,
                        url: "sjjs?type=2&info=" + encodeURIComponent(JSON.stringify(this.co.storeInfo))
                    });
                }
            }
        };
        e.default = m;
    },
    "9a87": function(t, e, n) {
        "use strict";
        n.r(e);
        var r = n("f0e0"), o = n("88cb");
        for (var c in o) "default" !== c && function(t) {
            n.d(e, t, function() {
                return o[t];
            });
        }(c);
        n("c509");
        var i, u = n("f0c5"), a = Object(u["a"])(o["default"], r["b"], r["c"], !1, null, "c4af7852", null, !1, r["a"], i);
        e["default"] = a.exports;
    },
    c509: function(t, e, n) {
        "use strict";
        var r = n("fe3d"), o = n.n(r);
        o.a;
    },
    f0e0: function(t, e, n) {
        "use strict";
        var r;
        n.d(e, "b", function() {
            return o;
        }), n.d(e, "c", function() {
            return c;
        }), n.d(e, "a", function() {
            return r;
        });
        var o = function() {
            var t = this, e = t.$createElement, n = (t._self._c, 1 == t.type ? t.co.moreSet.distributionSupport.find(function(t) {
                return 1 == t;
            }) : null), r = 1 == t.type && n ? t.co.moreSet.distributionSupport.find(function(t) {
                return 2 == t;
            }) : null;
            t._isMounted || (t.e0 = function(e) {
                t.show = !1;
            }, t.e1 = function(e) {
                t.zkshow = !t.zkshow;
            }, t.e2 = function(e) {
                return t.util.makeTel(t.co.shopData.storeTel);
            }), t.$mp.data = Object.assign({}, {
                $root: {
                    g0: n,
                    g1: r
                }
            });
        }, c = [];
    },
    fe3d: function(t, e, n) {}
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "components/goods/store/store-info-create-component", {
    "components/goods/store/store-info-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("9a87"));
    }
}, [ [ "components/goods/store/store-info-create-component" ] ] ]);