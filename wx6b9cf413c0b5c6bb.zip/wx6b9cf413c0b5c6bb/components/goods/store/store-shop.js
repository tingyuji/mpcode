(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "components/goods/store/store-shop" ], {
    2735: function(t, e, n) {
        "use strict";
        n.r(e);
        var r = n("61e2"), o = n("a6e2");
        for (var c in o) "default" !== c && function(t) {
            n.d(e, t, function() {
                return o[t];
            });
        }(c);
        n("b3a7");
        var i, u = n("f0c5"), a = Object(u["a"])(o["default"], r["b"], r["c"], !1, null, "d1cfc382", null, !1, r["a"], i);
        e["default"] = a.exports;
    },
    "61e2": function(t, e, n) {
        "use strict";
        var r;
        n.d(e, "b", function() {
            return o;
        }), n.d(e, "c", function() {
            return c;
        }), n.d(e, "a", function() {
            return r;
        });
        var o = function() {
            var t = this, e = t.$createElement;
            t._self._c;
            t._isMounted || (t.e0 = function(e) {
                t.show = !1;
            });
        }, c = [];
    },
    9002: function(t, e, n) {
        "use strict";
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        n("26cb");
        var r = o(n("e1c0"));
        function o(t) {
            return t && t.__esModule ? t : {
                default: t
            };
        }
        var c = function() {
            n.e("components/common/popup").then(function() {
                return resolve(n("b94e"));
            }.bind(null, n)).catch(n.oe);
        }, i = function() {
            Promise.all([ n.e("common/vendor"), n.e("components/common/mg-coupon") ]).then(function() {
                return resolve(n("76b6"));
            }.bind(null, n)).catch(n.oe);
        }, u = {
            name: "mg-share",
            components: {
                mgPopup: c,
                mgCoupon: i
            },
            props: {
                co: {
                    type: Object,
                    default: function() {
                        return {};
                    }
                },
                storeInfo: {
                    type: Object,
                    default: function() {
                        return {};
                    }
                },
                type: {
                    type: String,
                    default: "1"
                },
                value: {
                    type: Boolean,
                    default: !1
                },
                ptype: String,
                qlist: Array,
                sjqb: Array
            },
            data: function() {
                return {
                    loading: !1,
                    sjyhqArr: [],
                    zkshow: !1
                };
            },
            computed: {
                show: {
                    get: function() {
                        return this.value;
                    },
                    set: function(t) {
                        this.$emit("input", t);
                    }
                },
                yysj: function() {
                    var t = "", e = this.co.moreSet;
                    return 1 == e.timeType ? t = "24小时营业" : 2 == e.timeType && e.timeArr && (t = "".concat(e.timeArr[0].startTime, "-").concat(e.timeArr[0].ciri ? "次日" : "").concat(e.timeArr[0].endTime), 
                    e.timeArr[1] && (t += " " + "".concat(e.timeArr[1].startTime, "-").concat(e.timeArr[1].ciri ? "次日" : "").concat(e.timeArr[1].endTime)), 
                    e.timeArr[2] && (t += " " + "".concat(e.timeArr[2].startTime, "-").concat(e.timeArr[2].ciri ? "次日" : "").concat(e.timeArr[2].endTime))), 
                    t;
                }
            },
            watch: {
                qlist: function(t) {
                    t.length ? this.sjyhqArr = r.default.deepCopy(t) : (this.sjyhqArr = [], this.zkshow = !1);
                }
            },
            methods: {
                selectShop: function() {
                    this.show = !1, this.$emit("select-shop");
                }
            }
        };
        e.default = u;
    },
    a6e2: function(t, e, n) {
        "use strict";
        n.r(e);
        var r = n("9002"), o = n.n(r);
        for (var c in r) "default" !== c && function(t) {
            n.d(e, t, function() {
                return r[t];
            });
        }(c);
        e["default"] = o.a;
    },
    b3a7: function(t, e, n) {
        "use strict";
        var r = n("d168"), o = n.n(r);
        o.a;
    },
    d168: function(t, e, n) {}
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "components/goods/store/store-shop-create-component", {
    "components/goods/store/store-shop-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("2735"));
    }
}, [ [ "components/goods/store/store-shop-create-component" ] ] ]);