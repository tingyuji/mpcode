(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "components/uQrcode/uni-qrcode" ], {
    "0986": function(e, t, n) {
        "use strict";
        var a;
        n.d(t, "b", function() {
            return r;
        }), n.d(t, "c", function() {
            return o;
        }), n.d(t, "a", function() {
            return a;
        });
        var r = function() {
            var e = this, t = e.$createElement;
            e._self._c;
        }, o = [];
    },
    "455a": function(e, t, n) {
        "use strict";
        n.r(t);
        var a = n("0986"), r = n("59d4");
        for (var o in r) "default" !== o && function(e) {
            n.d(t, e, function() {
                return r[e];
            });
        }(o);
        var i, u = n("f0c5"), c = Object(u["a"])(r["default"], a["b"], a["c"], !1, null, null, null, !1, a["a"], i);
        t["default"] = c.exports;
    },
    "59d4": function(e, t, n) {
        "use strict";
        n.r(t);
        var a = n("f1d5"), r = n.n(a);
        for (var o in a) "default" !== o && function(e) {
            n.d(t, e, function() {
                return a[e];
            });
        }(o);
        t["default"] = r.a;
    },
    f1d5: function(e, t, n) {
        "use strict";
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var a = o(n("a34a")), r = o(n("d44e"));
            function o(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            function i(e, t, n, a, r, o, i) {
                try {
                    var u = e[o](i), c = u.value;
                } catch (s) {
                    return void n(s);
                }
                u.done ? t(c) : Promise.resolve(c).then(a, r);
            }
            function u(e) {
                return function() {
                    var t = this, n = arguments;
                    return new Promise(function(a, r) {
                        var o = e.apply(t, n);
                        function u(e) {
                            i(o, a, r, u, c, "next", e);
                        }
                        function c(e) {
                            i(o, a, r, u, c, "throw", e);
                        }
                        u(void 0);
                    });
                };
            }
            var c = {
                props: {
                    cid: {
                        type: String,
                        required: !0
                    },
                    text: {
                        type: String,
                        required: !0
                    },
                    size: {
                        type: Number,
                        default: 129
                    },
                    margin: {
                        type: Number,
                        default: 0
                    },
                    backgroundColor: {
                        type: String,
                        default: "#ffffff"
                    },
                    foregroundColor: {
                        type: String,
                        default: "#000000"
                    },
                    backgroundImage: {
                        type: String
                    },
                    logo: {
                        type: String
                    },
                    makeOnLoad: {
                        type: Boolean,
                        default: !1
                    }
                },
                data: function() {
                    return {};
                },
                mounted: function() {
                    this.makeOnLoad && this.make();
                },
                methods: {
                    make: function() {
                        var e = this;
                        return u(a.default.mark(function t() {
                            var n, r;
                            return a.default.wrap(function(t) {
                                while (1) switch (t.prev = t.next) {
                                  case 0:
                                    return n = {
                                        canvasId: e.cid,
                                        componentInstance: e,
                                        text: e.text,
                                        size: e.size,
                                        margin: e.margin,
                                        backgroundColor: e.backgroundImage ? "rgba(255,255,255,0)" : e.backgroundColor,
                                        foregroundColor: e.foregroundColor
                                    }, t.next = 3, e.makeSync(n);

                                  case 3:
                                    if (r = t.sent, !e.backgroundImage) {
                                        t.next = 8;
                                        break;
                                    }
                                    return t.next = 7, e.drawBackgroundImageSync(r);

                                  case 7:
                                    r = t.sent;

                                  case 8:
                                    if (!e.logo) {
                                        t.next = 12;
                                        break;
                                    }
                                    return t.next = 11, e.drawLogoSync(r);

                                  case 11:
                                    r = t.sent;

                                  case 12:
                                    return e.makeComplete(r), t.abrupt("return", r);

                                  case 14:
                                  case "end":
                                    return t.stop();
                                }
                            }, t);
                        }))();
                    },
                    makeComplete: function(e) {
                        this.$emit("makeComplete", e);
                    },
                    drawBackgroundImage: function(t) {
                        var n = this, a = e.createCanvasContext(this.cid, this);
                        a.drawImage(this.backgroundImage, 0, 0, this.size, this.size), a.drawImage(t.filePath, 0, 0, this.size, this.size), 
                        a.draw(!1, function() {
                            e.canvasToTempFilePath({
                                canvasId: n.cid,
                                success: function(e) {
                                    t.success && t.success(e.tempFilePath);
                                },
                                fail: function(e) {
                                    t.fail && t.fail(e);
                                }
                            });
                        });
                    },
                    drawBackgroundImageSync: function(e) {
                        var t = this;
                        return u(a.default.mark(function n() {
                            return a.default.wrap(function(n) {
                                while (1) switch (n.prev = n.next) {
                                  case 0:
                                    return n.abrupt("return", new Promise(function(n, a) {
                                        t.drawBackgroundImage({
                                            filePath: e,
                                            success: function(e) {
                                                n(e);
                                            },
                                            fail: function(e) {
                                                a(e);
                                            }
                                        });
                                    }));

                                  case 1:
                                  case "end":
                                    return n.stop();
                                }
                            }, n);
                        }))();
                    },
                    fillRoundRect: function(e, t, n, a, r, o) {
                        e.save(), e.translate(n, a), e.beginPath(), e.arc(r - t, o - t, t, 0, Math.PI / 2), 
                        e.lineTo(t, o), e.arc(t, o - t, t, Math.PI / 2, Math.PI), e.lineTo(0, t), e.arc(t, t, t, Math.PI, 3 * Math.PI / 2), 
                        e.lineTo(r - t, 0), e.arc(r - t, t, t, 3 * Math.PI / 2, 2 * Math.PI), e.lineTo(r, o - t), 
                        e.closePath(), e.setFillStyle("#ffffff"), e.fill(), e.restore();
                    },
                    drawLogo: function(t) {
                        var n = this, a = e.createCanvasContext(this.cid, this);
                        a.drawImage(t.filePath, 0, 0, this.size, this.size);
                        var r = this.size / 4, o = this.size / 2 - r / 2, i = o, u = r + 10, c = this.size / 2 - u / 2, s = c, f = 5;
                        this.fillRoundRect(a, f, c, s, u, u), a.drawImage(this.logo, o, i, r, r), a.draw(!1, function() {
                            e.canvasToTempFilePath({
                                canvasId: n.cid,
                                success: function(e) {
                                    t.success && t.success(e.tempFilePath);
                                },
                                fail: function(e) {
                                    t.fail && t.fail(e);
                                }
                            });
                        });
                    },
                    drawLogoSync: function(e) {
                        var t = this;
                        return u(a.default.mark(function n() {
                            return a.default.wrap(function(n) {
                                while (1) switch (n.prev = n.next) {
                                  case 0:
                                    return n.abrupt("return", new Promise(function(n, a) {
                                        t.drawLogo({
                                            filePath: e,
                                            success: function(e) {
                                                n(e);
                                            },
                                            fail: function(e) {
                                                a(e);
                                            }
                                        });
                                    }));

                                  case 1:
                                  case "end":
                                    return n.stop();
                                }
                            }, n);
                        }))();
                    },
                    makeSync: function(e) {
                        return u(a.default.mark(function t() {
                            return a.default.wrap(function(t) {
                                while (1) switch (t.prev = t.next) {
                                  case 0:
                                    return t.abrupt("return", new Promise(function(t, n) {
                                        r.default.make({
                                            canvasId: e.canvasId,
                                            componentInstance: e.componentInstance,
                                            text: e.text,
                                            size: e.size,
                                            margin: e.margin,
                                            backgroundColor: e.backgroundColor,
                                            foregroundColor: e.foregroundColor,
                                            success: function(e) {
                                                t(e);
                                            },
                                            fail: function(e) {
                                                n(e);
                                            }
                                        });
                                    }));

                                  case 1:
                                  case "end":
                                    return t.stop();
                                }
                            }, t);
                        }))();
                    }
                }
            };
            t.default = c;
        }).call(this, n("543d")["default"]);
    }
} ]);

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ "components/uQrcode/uni-qrcode-create-component", {
    "components/uQrcode/uni-qrcode-create-component": function(module, exports, __webpack_require__) {
        __webpack_require__("543d")["createComponent"](__webpack_require__("455a"));
    }
}, [ [ "components/uQrcode/uni-qrcode-create-component" ] ] ]);