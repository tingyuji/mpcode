var e = require("../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var t = require("../@babel/runtime/helpers/objectSpread2"), o = e(require("../config")), r = require("./util"), a = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, a = e.url, u = e.method, i = void 0 === u ? "GET" : u, n = e.data, c = void 0 === n ? {} : n, d = e.header, s = void 0 === d ? {} : d;
    return new Promise(function(e, u) {
        wx.request({
            url: "".concat(o.default.host).concat(a),
            method: i,
            data: c,
            enableHttp2: !0,
            header: t(t({}, s), {}, {
                Token: wx.getStorageSync("TOKEN")
            }),
            success: function(t) {
                var o = t.data;
                o && 0 === o.code ? e(o) : (o && o.code ? (0, r.showToast)("".concat(o.code, ": ").concat(o.message || "未知错误")) : (0, 
                r.showToast)("发生未知错误，请重试"), u(o));
            },
            fail: function(e) {
                u(e);
            }
        });
    });
};

exports.default = a;