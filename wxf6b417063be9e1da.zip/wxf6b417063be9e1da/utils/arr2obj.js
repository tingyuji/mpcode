Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = function(e, t) {
    var r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "name", o = {};
    return e.forEach(function(e) {
        o[e[t]] = e[r];
    }), o;
};

exports.default = e;