Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.showToast = exports.showLoading = void 0;

exports.showToast = function(o) {
    wx.showToast({
        title: o,
        icon: "none"
    });
};

exports.showLoading = function(o) {
    wx.showLoading({
        title: o || "",
        mask: !0
    });
};