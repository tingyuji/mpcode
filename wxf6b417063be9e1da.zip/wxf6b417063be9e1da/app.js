var e = require("@babel/runtime/helpers/interopRequireDefault"), t = e(require("@babel/runtime/regenerator")), r = require("@babel/runtime/helpers/asyncToGenerator"), n = require("@mp-components/mp-store"), a = e(require("@mp-components/promisify")), o = e(require("./models/store")), i = e(require("./utils/request")), u = require("./utils/util");

App((0, n.withStore)(o.default)({
    onLaunch: function() {
        var e = this, n = wx.getUpdateManager();
        n.onUpdateReady(function() {
            (0, a.default)(wx.showModal)({
                title: "更新提示",
                content: "新版本已准备好，为了更好的体验，请点击确定进行更新",
                showCancel: !1
            }).then(function() {
                n.applyUpdate();
            });
        }), (0, u.showLoading)("登录中"), (0, a.default)(wx.login)().then(r(t.default.mark(function r() {
            var n, a, o, u, s = arguments;
            return t.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (n = s.length > 0 && void 0 !== s[0] ? s[0] : {}, a = n.code) {
                        t.next = 3;
                        break;
                    }
                    return t.abrupt("return");

                  case 3:
                    return t.prev = 3, t.next = 6, (0, i.default)({
                        url: "/api/login",
                        method: "POST",
                        data: {
                            code: a
                        }
                    });

                  case 6:
                    return o = t.sent, wx.setStorageSync("TOKEN", o.data.token), u = e._mpStore.getActions(), 
                    t.next = 11, Promise.all([ u.book.getBooks({
                        initial: !0
                    }), u.category.getCategories(), u.source.getSources() ]);

                  case 11:
                    wx.hideLoading(), t.next = 17;
                    break;

                  case 14:
                    t.prev = 14, t.t0 = t.catch(3), wx.hideLoading();

                  case 17:
                  case "end":
                    return t.stop();
                }
            }, r, null, [ [ 3, 14 ] ]);
        }))).catch(function() {
            wx.hideLoading();
        });
    }
}));