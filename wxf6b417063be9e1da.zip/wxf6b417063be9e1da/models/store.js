var e = require("../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var r = require("@mp-components/mp-store"), t = e(require("./category")), o = e(require("./book")), u = e(require("./source")), a = (0, 
r.createStore)({
    category: t.default,
    book: o.default,
    source: u.default
});

exports.default = a;