var e = require("../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var t = e(require("../@babel/runtime/regenerator")), r = require("../@babel/runtime/helpers/asyncToGenerator"), a = require("../@babel/runtime/helpers/objectSpread2"), n = e(require("../utils/request")), i = function() {
    for (var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [], t = e.length, r = 0; r < t; r++) if (e[r].is_default) return a(a({}, e[r]), {}, {
        index: r
    });
    return {};
}, u = function(e, t) {
    for (var r = t.length, n = 0; n < r; n++) if (t[n].book_id === e.book_id) return a(a({}, t[n]), {}, {
        index: n
    });
    return {};
}, o = {
    state: {
        total: 0,
        list: [],
        current: {}
    },
    actions: {
        getBooks: function() {
            var e = arguments, a = this;
            return r(t.default.mark(function r() {
                var o, s, l, c;
                return t.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return o = e.length > 0 && void 0 !== e[0] ? e[0] : {}, s = o.initial, t.next = 3, 
                        (0, n.default)({
                            url: "/api/books"
                        });

                      case 3:
                        l = t.sent, (c = {
                            total: l.data.total || 0,
                            list: l.data.list || []
                        }).current = s ? i(l.data.list) : u(a.getState().current, l.data.list), a.setState(c);

                      case 7:
                      case "end":
                        return t.stop();
                    }
                }, r);
            }))();
        },
        setCurrentBook: function(e) {
            e || (e = i(this.getState().list)), this.setState({
                current: e
            }), wx.setStorageSync("BOOK_CHANGED", "true");
        }
    }
};

exports.default = o;