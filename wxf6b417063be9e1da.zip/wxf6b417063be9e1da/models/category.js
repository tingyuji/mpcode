var e = require("../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var t = e(require("../@babel/runtime/regenerator")), r = require("../@babel/runtime/helpers/asyncToGenerator"), a = e(require("../utils/request")), s = {
    state: {
        total: 0,
        list: []
    },
    actions: {
        getCategories: function() {
            var e = this;
            return r(t.default.mark(function r() {
                var s;
                return t.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return t.next = 2, (0, a.default)({
                            url: "/api/categories"
                        });

                      case 2:
                        s = t.sent, e.setState({
                            total: s.data.total || 0,
                            list: s.data.list || []
                        });

                      case 4:
                      case "end":
                        return t.stop();
                    }
                }, r);
            }))();
        }
    }
};

exports.default = s;