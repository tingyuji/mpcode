var t = require("../../@babel/runtime/helpers/interopRequireDefault"), e = require("@mp-components/mp-store"), i = t(require("../../utils/arr2obj")), o = t(require("../../utils/request")), a = require("../../utils/util");

Page((0, e.connect)(function(t) {
    return {
        categories: (0, i.default)(t.category.list, "category_id"),
        sources: (0, i.default)(t.source.list, "source_id"),
        books: (0, i.default)(t.book.list, "book_id")
    };
})({
    data: {
        item_id: "",
        item: {}
    },
    onLoad: function(t) {
        this.getItemDetail(t.item_id);
    },
    getItemDetail: function(t) {
        var e = this;
        (0, o.default)({
            url: "/api/items/".concat(t)
        }).then(function(i) {
            e.setData({
                item: i.data || {},
                item_id: t
            });
        });
    },
    deleteItem: function() {
        var t = this, e = this.data;
        e.list, e.total;
        wx.showModal({
            title: "提示",
            content: "确定要删除吗？",
            confirmColor: "#fa5151",
            success: function(e) {
                e.confirm && ((0, a.showLoading)(), (0, o.default)({
                    url: "/api/items/".concat(t.data.item_id),
                    method: "DELETE"
                }).then(function() {
                    wx.setStorageSync("DELETED_ID", t.data.item_id), (0, a.showToast)("删除成功"), setTimeout(wx.navigateBack, 200);
                }));
            }
        });
    }
}));