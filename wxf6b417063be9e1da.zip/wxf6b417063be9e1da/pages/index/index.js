var e = require("../../@babel/runtime/helpers/interopRequireDefault"), t = require("../../@babel/runtime/helpers/objectSpread2"), o = require("../../@babel/runtime/helpers/defineProperty"), r = require("@mp-components/mp-store"), n = e(require("@mp-components/promisify")), a = e(require("../../lib/dayjs.min")), i = require("../../utils/util"), s = e(require("../../utils/request"));

Page((0, r.connect)(function(e) {
    return {
        categories: e.category.list,
        books: e.book.list,
        sources: e.source.list,
        currentBook: e.book.current
    };
}, function(e) {
    return {
        setCurrentBook: e.book.setCurrentBook
    };
})({
    data: {
        amount: null,
        remark: "",
        category: 0,
        source: 0,
        date: "",
        time: "",
        tooltip: {
            msg: "",
            type: ""
        },
        windowWidth: 0
    },
    onLoad: function() {
        var e = this;
        this.setNow(), (0, n.default)(wx.getSystemInfo)().then(function(t) {
            e.setData({
                windowWidth: t.windowWidth
            });
        });
    },
    onShareAppMessage: function() {},
    setNow: function() {
        var e = (0, a.default)();
        this.setData({
            date: e.format("YYYY-MM-DD"),
            time: e.format("HH:mm")
        });
    },
    onInputChange: function(e) {
        var t = e.detail.value, r = e.currentTarget.dataset.key;
        this.setData(o({}, r, t));
    },
    onSelectChange: function(e) {
        var t = e.currentTarget.dataset, r = t.index, n = t.key;
        this.setData(o({}, n, +r));
    },
    onBookChange: function(e) {
        var o = e.detail.value, r = this.data, n = r.books, a = r.currentBook, i = n[+o];
        a.book_id !== i.book_id && (this.setCurrentBook(t(t({}, i), {}, {
            index: +o
        })), wx.showToast({
            title: "已切换到 [".concat(i.name, "]，所有页面有效"),
            icon: "none"
        }));
    },
    handleSubmit: function() {
        var e = this, t = this.data, o = t.amount, r = t.remark, n = t.categories, u = t.category, c = t.sources, d = t.source, l = t.currentBook, m = t.date, h = t.time, k = Number(o);
        k && /(^[1-9]\d*(\.\d{1,2})?$)|(^0(\.\d{1,2})?$)/.test(k) ? k > 2e7 ? wx.showToast({
            title: "金额太大了",
            icon: "none"
        }) : r ? ((0, i.showLoading)(), (0, s.default)({
            url: "/api/items",
            method: "POST",
            data: {
                amount: +(100 * k).toFixed(0),
                remark: r,
                category_id: n[u].category_id,
                source_id: c[d].source_id,
                book_id: l.book_id,
                date: (0, a.default)("".concat(m.replace(/-/g, "/"), " ").concat(h)).toISOString()
            }
        }).then(function() {
            wx.showToast({
                title: "记下了",
                icon: "none"
            }), e.setData({
                amount: null,
                remark: ""
            });
        })) : wx.showToast({
            title: "备注不能为空",
            icon: "none"
        }) : wx.showToast({
            title: "金额格式不正确",
            icon: "none"
        });
    }
}));