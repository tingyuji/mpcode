var t = require("../../@babel/runtime/helpers/interopRequireDefault"), e = require("../../@babel/runtime/helpers/objectSpread2"), a = require("../../@babel/runtime/helpers/toConsumableArray"), o = require("@mp-components/mp-store"), i = t(require("../../lib/dayjs.min")), r = t(require("../../utils/request")), s = t(require("../../utils/arr2obj")), l = require("../../utils/util"), n = {
    category_id: "all",
    name: "全部",
    order: 0
}, u = function(t) {
    return {
        start: (0, i.default)().startOf(t).format("YYYY-MM-DDT00:00:00Z")
    };
}, d = function(t) {
    return {
        start: (0, i.default)().startOf(t).subtract(1, "day").startOf(t).format("YYYY-MM-DDT00:00:00Z"),
        end: (0, i.default)().startOf(t).subtract(1, "day").format("YYYY-MM-DDT23:59:59Z")
    };
}, c = [ {
    id: "all",
    title: "全部时间",
    value: {}
}, {
    id: "today",
    title: "今天",
    value: {
        start: (0, i.default)().format("YYYY-MM-DDT00:00:00Z")
    }
}, {
    id: "this_week",
    title: "本周",
    value: u("week")
}, {
    id: "last_week",
    title: "上周",
    value: d("week")
}, {
    id: "this_month",
    title: "本月",
    value: u("month")
}, {
    id: "last_month",
    title: "上个月",
    value: d("month")
}, {
    id: "30_days",
    title: "近30天",
    value: {
        start: (0, i.default)().subtract(30, "day").format("YYYY-MM-DDT00:00:00Z")
    }
}, {
    id: "90_days",
    title: "近90天",
    value: {
        start: (0, i.default)().subtract(90, "day").format("YYYY-MM-DDT00:00:00Z")
    }
}, {
    id: "this_year",
    title: "今年",
    value: u("year")
}, {
    id: "last_year",
    title: "去年",
    value: d("year")
} ];

Page((0, o.connect)(function(t) {
    return {
        categories: (0, s.default)(t.category.list, "category_id"),
        sources: (0, s.default)(t.source.list, "source_id"),
        currentBook: t.book.current,
        categoryList: [ n ].concat(a(t.category.list))
    };
})({
    data: {
        list: [],
        total: 0,
        page: 1,
        selectedCategory: "all",
        showCategoryBox: !1,
        selectedDate: 0,
        showDateBox: !1,
        dateList: c
    },
    isLoaded: !1,
    onLoad: function() {
        var t = this;
        this.getItems(1), setTimeout(function() {
            t.isLoaded = !0;
        }, 0);
    },
    onShow: function() {
        var t = "true" === wx.getStorageSync("BOOK_CHANGED");
        if (this.isLoaded && t && (this.getItems(1), wx.pageScrollTo({
            scrollTop: 0,
            duration: 0
        }), wx.removeStorage({
            key: "BOOK_CHANGED"
        })), this.isLoaded && !t) {
            var e = wx.getStorageSync("DELETED_ID");
            if (e) {
                var a = this.data.list.filter(function(t) {
                    return t.item_id !== e;
                });
                this.setData({
                    list: a
                }), wx.removeStorage({
                    key: "DELETED_ID"
                });
            }
        }
    },
    onPullDownRefresh: function() {
        this.getItems(1), wx.stopPullDownRefresh();
    },
    onReachBottom: function() {
        var t = this.data, e = t.list, a = t.total, o = t.page;
        e.length < a && this.getItems(o + 1);
    },
    getItems: function(t) {
        var o = this;
        (0, l.showLoading)("加载中");
        var i = this.data, s = i.list, n = i.selectedCategory, u = i.selectedDate, d = i.currentBook, h = e({
            book_id: d.book_id,
            page: t
        }, c[u].value);
        n && "all" !== n && (h.category_id = n), (0, r.default)({
            url: "/api/items",
            data: h
        }).then(function(e) {
            wx.hideLoading(), o.setData({
                list: 1 === t ? e.data.list : [].concat(a(s), a(e.data.list)),
                total: e.data.total,
                page: t
            });
        }).catch(function() {
            wx.hideLoading();
        });
    },
    showCategoryBox: function() {
        this.setData({
            showCategoryBox: !0,
            showDateBox: !1
        });
    },
    closeCategoryBox: function() {
        this.setData({
            showCategoryBox: !1
        });
    },
    tapCategory: function(t) {
        var e = this;
        this.closeCategoryBox();
        var a = t.currentTarget.dataset.id;
        this.setData({
            selectedCategory: a
        }, function() {
            wx.pageScrollTo({
                scrollTop: 0
            }), e.getItems(1);
        });
    },
    showDateBox: function() {
        this.setData({
            showDateBox: !0,
            showCategoryBox: !1
        });
    },
    closeDateBox: function() {
        this.setData({
            showDateBox: !1
        });
    },
    tapDate: function(t) {
        var e = this;
        this.closeDateBox();
        var a = t.currentTarget.dataset.index;
        this.setData({
            selectedDate: +a
        }, function() {
            wx.pageScrollTo({
                scrollTop: 0
            }), e.getItems(1);
        });
    },
    goDetail: function(t) {
        var e = t.currentTarget.dataset.id;
        wx.navigateTo({
            url: "/pages/item/item?item_id=".concat(e)
        });
    }
}));