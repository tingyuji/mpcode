Page({
    data: {
        list: [ {
            title: "小程序图标",
            info: "Felicity-dys@iconfont.cn"
        }, {
            title: "导航栏图标",
            info: "Remix Design",
            link: "https://remixicon.com"
        }, {
            title: "类别图标",
            info: "Remix Design",
            link: "https://remixicon.com"
        }, {
            title: "dayjs",
            info: "Copyright (c) 2018-present, iamkun",
            link: "https://github.com/iamkun/dayjs"
        }, {
            title: "@mp-components/mp-store",
            info: "Copyright (c) 2020-present, pengtikui",
            link: "https://github.com/pengtikui/mp-store"
        }, {
            title: "@mp-components/promisify",
            info: "Copyright (c) 2020-present, pengtikui",
            link: "https://github.com/mp-components/promisify"
        } ]
    }
});