var t = require("../../@babel/runtime/helpers/interopRequireDefault"), e = t(require("../../@babel/runtime/regenerator")), o = require("../../@babel/runtime/helpers/asyncToGenerator"), a = require("@mp-components/mp-store"), n = t(require("@mp-components/promisify")), i = t(require("../../utils/request")), s = [ {
    text: "设为默认",
    value: "set_default"
}, {
    text: "修改名称",
    value: "update_name"
}, {
    text: "删除账本",
    value: "delete",
    type: "warn"
} ];

Page((0, a.connect)(function(t) {
    return {
        list: t.book.list,
        currentBook: t.book.current
    };
}, function(t) {
    return {
        getBooks: t.book.getBooks,
        setCurrentBook: t.book.setCurrentBook
    };
})({
    data: {
        showActionSheet: !1,
        actions: [],
        current: {},
        showDialog: !1,
        dialogType: -1,
        keyboard: {},
        input: ""
    },
    onPullDownRefresh: function() {
        var t = this;
        return o(e.default.mark(function o() {
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.prev = 0, e.next = 3, t.getBooks();

                  case 3:
                    e.next = 7;
                    break;

                  case 5:
                    e.prev = 5, e.t0 = e.catch(0);

                  case 7:
                    wx.stopPullDownRefresh();

                  case 8:
                  case "end":
                    return e.stop();
                }
            }, o, null, [ [ 0, 5 ] ]);
        }))();
    },
    onBookTap: function(t) {
        var e = t.currentTarget.dataset, o = e.index, a = e.id, n = this.data.list[o].is_default;
        this.setData({
            showActionSheet: !0,
            actions: n ? s.slice(1, 2) : s,
            current: {
                index: o,
                id: a
            }
        });
    },
    onAddTap: function() {
        this.setData({
            showDialog: !0,
            dialogType: 0
        });
    },
    onActionSheetClose: function() {
        this.setData({
            showActionSheet: !1,
            current: {}
        });
    },
    onActionSheetTap: function(t) {
        this.setData({
            showActionSheet: !1
        });
        var e = this.data.current;
        switch (t.detail.value) {
          case "set_default":
            this.setDefault(e);
            break;

          case "update_name":
            this.updateName(e);
            break;

          case "delete":
            this.deleteBook(e);
        }
    },
    onKeyboardHeightChange: function(t) {
        this.setData({
            keyboard: t.detail
        });
    },
    onDialogClose: function() {
        this.setData({
            showDialog: !1,
            input: "",
            dialogType: -1
        });
    },
    onDialogConfirm: function() {
        var t = this.data;
        t.input;
        switch (t.dialogType) {
          case 0:
            this.addBook();
            break;

          case 1:
            this.updateNameConfirm();
        }
    },
    onInput: function(t) {
        var e = t.detail.value;
        this.setData({
            input: e
        });
    },
    setDefault: function(t) {
        var e = this;
        (0, i.default)({
            url: "/api/books/set-default",
            method: "PUT",
            data: {
                book_id: t.id
            }
        }).then(function() {
            e.getBooks(), e.setData({
                current: {}
            }), wx.showToast({
                title: "设置成功，进入小程序时将默认使用该账本",
                icon: "none"
            });
        });
    },
    addBook: function() {
        var t = this, e = this.data.input;
        (0, i.default)({
            url: "/api/books",
            method: "POST",
            data: {
                name: e
            }
        }).then(function() {
            t.onDialogClose(), t.getBooks(), wx.showToast({
                title: "新增成功",
                icon: "none"
            });
        });
    },
    updateName: function(t) {
        var e = this.data.list[t.index].name;
        this.setData({
            showDialog: !0,
            dialogType: 1,
            input: e
        });
    },
    updateNameConfirm: function() {
        var t = this, e = this.data, o = e.current, a = e.input;
        (0, i.default)({
            url: "/api/books/".concat(o.id),
            method: "PUT",
            data: {
                name: a
            }
        }).then(function() {
            t.onDialogClose(), t.getBooks(), t.setData({
                current: {}
            }), wx.showToast({
                title: "修改成功",
                icon: "none"
            });
        });
    },
    deleteBook: function(t) {
        var e = this, o = this.data, a = o.list, s = o.currentBook, r = a[t.index];
        (0, n.default)(wx.showModal)({
            title: "提示",
            confirmColor: "#fa5151",
            content: "确定要删除 [".concat(r.name, "] 吗？该账本下的记账记录也会被一并删除！")
        }).then(function(t) {
            return !!t.confirm && (0, i.default)({
                url: "/api/books/".concat(r.book_id),
                method: "DELETE"
            });
        }).then(function(t) {
            t && (e.getBooks(), e.setData({
                current: {}
            }), wx.showToast({
                title: "删除成功",
                icon: "none"
            }), s.book_id === r.book_id ? (wx.showToast({
                title: "删除成功，当前账本已切换为默认",
                icon: "none"
            }), e.setCurrentBook()) : wx.showToast({
                title: "删除成功",
                icon: "none"
            }));
        });
    }
}));