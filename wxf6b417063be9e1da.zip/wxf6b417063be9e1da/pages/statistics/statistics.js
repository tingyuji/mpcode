var t = require("../../@babel/runtime/helpers/interopRequireDefault"), a = require("@mp-components/mp-store"), e = t(require("../../lib/dayjs.min")), n = t(require("../../utils/request")), r = require("../../utils/util"), o = t(require("../../utils/arr2obj"));

Page((0, a.connect)(function(t) {
    return {
        categories: (0, o.default)(t.category.list, "category_id"),
        currentBook: t.book.current
    };
})({
    data: {
        realtime: {
            total: 0,
            list: []
        },
        realtimeCount: {
            day: 0,
            week: 0
        },
        weeklyChart: [],
        monthly: {
            total: 0,
            list: []
        },
        monthlyCount: {
            month: 0
        },
        monthlyChart: [],
        monthRange: function() {
            for (var t, a = (0, e.default)().year(), n = (0, e.default)().month() + 1, r = [], o = 2019; o <= a; o++) for (var i = o < a ? 12 : n, u = 2019 === o ? 2 : 1; u <= i; u++) r.push("".concat(o, "-").concat((t = u) < 10 ? "0".concat(t) : t));
            return r.reverse();
        }(),
        monthIndex: 0,
        yearlyLoading: !1,
        yearly: {
            total: 0,
            list: []
        },
        yearlyCount: {
            year: 0
        },
        yearlyChart: [],
        isGetYearly: !1
    },
    onShow: function() {
        this.getRealTimeData(), this.getMonthlyData();
    },
    getRealTimeData: function() {
        var t = this, a = this.data.currentBook;
        (0, n.default)({
            url: "/api/statistics/realtime",
            data: {
                book_id: a.book_id
            }
        }).then(function(a) {
            wx.hideLoading();
            var n = (0, e.default)().endOf("day"), r = a.data.list.filter(function(t) {
                return function(t, a) {
                    return a.isSame((0, e.default)(t), "day");
                }(t.date, n);
            }).reduce(function(t, a) {
                return t + a.amount;
            }, 0), o = a.data.list.reduce(function(t, a) {
                return t + a.amount;
            }, 0);
            t.setData({
                realtime: {
                    total: a.data.total || 0,
                    list: a.data.list || []
                },
                realtimeCount: {
                    day: r,
                    week: o
                },
                weeklyChart: t.getChartData(a.data.list || [])
            });
        });
    },
    getMonthlyData: function() {
        var t = this, a = this.data, e = a.monthRange, r = a.monthIndex, o = a.currentBook;
        (0, n.default)({
            url: "/api/statistics/monthly",
            data: {
                book_id: o.book_id,
                month: e[r]
            }
        }).then(function(a) {
            wx.hideLoading();
            var e = a && a.data && a.data.list || [], n = a && a.data && a.data.total || 0, r = e.reduce(function(t, a) {
                return t + a.amount;
            }, 0);
            t.setData({
                monthly: {
                    total: n,
                    list: e
                },
                monthlyCount: {
                    month: r
                },
                monthlyChart: t.getChartData(e)
            });
        });
    },
    getYearlyData: function() {
        var t = this;
        (0, r.showLoading)("计算中");
        var a = this.data.currentBook;
        this.setData({
            isGetYearly: !0,
            yearlyLoading: !0
        }), (0, n.default)({
            url: "/api/statistics/yearly",
            data: {
                book_id: a.book_id,
                year: 2022
            }
        }).then(function(a) {
            wx.hideLoading();
            var e = a && a.data && a.data.list || [], n = a && a.data && a.data.total || 0, r = e.reduce(function(t, a) {
                return t + a.amount;
            }, 0);
            t.setData({
                yearly: {
                    total: n,
                    list: e
                },
                yearlyCount: {
                    year: r
                },
                yearlyChart: t.getChartData(e),
                yearlyLoading: !1
            }), wx.pageScrollTo({
                scrollTop: 99999,
                duration: 0
            });
        }).catch(function() {
            t.setData({
                isGetYearly: !1,
                yearlyLoading: !1
            }), wx.hideLoading();
        });
    },
    monthChange: function(t) {
        var a = this, e = Number(t.detail.value);
        this.setData({
            monthIndex: e
        }, function() {
            a.getMonthlyData();
        });
    },
    getChartData: function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [], a = this.data.categories, e = {};
        t.forEach(function(t) {
            var a = e[t.category_id] || 0;
            e[t.category_id] = a + t.amount;
        });
        var n = Object.keys(e).map(function(t) {
            return {
                category_id: t,
                category_name: a[t],
                amount: e[t]
            };
        }).sort(function(t, a) {
            return a.amount - t.amount;
        });
        return n;
    }
}));