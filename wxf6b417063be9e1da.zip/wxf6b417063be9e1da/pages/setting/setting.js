var e = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../config"));

Page({
    data: {
        version: e.default.version
    }
});