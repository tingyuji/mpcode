Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = {
    version: "v0.11.2",
    host: "https://meow.pengtikui.cn"
};

exports.default = e;