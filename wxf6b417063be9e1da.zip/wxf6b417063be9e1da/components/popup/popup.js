Component({
    properties: {
        visible: {
            type: Boolean,
            value: !1
        },
        height: {
            type: String,
            value: "800rpx"
        },
        radius: {
            type: Number,
            value: 16
        },
        bgColor: {
            type: String,
            value: "#fff"
        }
    },
    methods: {
        preventMove: function() {},
        handleMaskTap: function() {
            this.triggerEvent("close");
        }
    }
});