Component({
    properties: {
        title: {
            type: String,
            value: ""
        },
        showBack: {
            type: Boolean,
            value: !1
        },
        heading: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        statusBarHeight: 0,
        navbarHeight: 0,
        leftWidth: 0,
        backWidth: 0
    },
    methods: {
        goBack: function() {
            wx.navigateBack();
        }
    },
    lifetimes: {
        attached: function() {
            var t = wx.getSystemInfoSync(), e = wx.getMenuButtonBoundingClientRect();
            this.setData({
                navbarHeight: e.height + 3 * (e.top - t.statusBarHeight),
                statusBarHeight: t.statusBarHeight,
                leftWidth: t.windowWidth - e.right,
                backWidth: e.height
            });
        }
    }
});