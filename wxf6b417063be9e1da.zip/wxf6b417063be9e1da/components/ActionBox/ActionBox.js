Component({
    properties: {
        visible: {
            type: Boolean,
            value: !1,
            observer: function(t) {
                t ? this.setData({
                    show: !0
                }) : this.closeBox();
            }
        },
        title: {
            type: String,
            value: ""
        }
    },
    data: {
        show: !1,
        hide: !1
    },
    methods: {
        closeBox: function() {
            var t = this;
            this.setData({
                hide: !0
            }, function() {
                setTimeout(function() {
                    t.setData({
                        show: !1,
                        hide: !1
                    });
                }, 200);
            });
        },
        tapCancel: function() {
            this.triggerEvent("close");
        },
        preventMove: function() {}
    }
});