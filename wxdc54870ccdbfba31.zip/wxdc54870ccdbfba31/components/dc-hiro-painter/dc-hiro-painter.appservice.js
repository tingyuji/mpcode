$gwx_XC_0=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_0 || [];
function gz$gwx_XC_0_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_0_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_0_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_0_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'__e'])
Z(z[0])
Z([3,'content data-v-39cd90cc'])
Z([[4],[[5],[[5],[[4],[[5],[[5],[1,'touchmove']],[[4],[[5],[[4],[[5],[[5],[1,'moveHandle']],[[4],[[5],[1,'$event']]]]]]]]]],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'closeBox']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([3,'out-box'])
Z([[7],[3,'allImgOk']])
Z(z[5])
Z([[7],[3,'pathBm']])
Z(z[7])
Z([3,'top_fun fl_sb data-v-39cd90cc'])
Z([3,'__l'])
Z([3,'data-v-39cd90cc'])
Z([3,'#07c160'])
Z([3,'weixin-circle-fill'])
Z([3,'90'])
Z([3,'ffe386a8-1'])
Z(z[0])
Z([3,'share_view data-v-39cd90cc'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'creatTwens']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z(z[10])
Z(z[11])
Z(z[12])
Z([3,'moments-circel-fill'])
Z(z[14])
Z([3,'ffe386a8-2'])
Z(z[5])
Z(z[10])
Z(z[0])
Z([3,'40'])
Z(z[11])
Z([1,true])
Z([[4],[[5],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'allImgOks']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z([3,'bottom'])
Z([[7],[3,'allImgOks']])
Z([3,'ffe386a8-3'])
Z([[4],[[5],[1,'default']]])
Z([[7],[3,'allImgOkTwo']])
Z([[7],[3,'pathNine']])
Z([[7],[3,'pathThree']])
Z([[7],[3,'pathFour']])
Z([[7],[3,'isReadyTwo']])
Z(z[10])
Z(z[0])
Z([3,'out_page data-v-39cd90cc'])
Z([[4],[[5],[[4],[[5],[[5],[1,'^imgOK']],[[4],[[5],[[4],[[5],[1,'successTwo']]]]]]]]])
Z([[7],[3,'dataTwo']])
Z([3,'ffe386a8-4'])
Z([[7],[3,'isReadyTwoSixz']])
Z(z[10])
Z(z[0])
Z(z[43])
Z([[4],[[5],[[4],[[5],[[5],[1,'^imgOK']],[[4],[[5],[[4],[[5],[1,'successTwoSixz']]]]]]]]])
Z([[7],[3,'dataTwoSixz']])
Z([3,'ffe386a8-5'])
Z([[7],[3,'isReady']])
Z(z[10])
Z(z[0])
Z(z[43])
Z([[4],[[5],[[4],[[5],[[5],[1,'^imgOK']],[[4],[[5],[[4],[[5],[1,'success']]]]]]]]])
Z([[7],[3,'dataOne']])
Z([3,'ffe386a8-6'])
Z([[7],[3,'isReadySeven']])
Z(z[10])
Z(z[0])
Z(z[0])
Z(z[43])
Z([[4],[[5],[[5],[[4],[[5],[[5],[1,'^imgOK']],[[4],[[5],[[4],[[5],[1,'successSeven']]]]]]]],[[4],[[5],[[5],[1,'^imgErr']],[[4],[[5],[[4],[[5],[1,'sevenErr']]]]]]]]])
Z([[7],[3,'dataSeven']])
Z([3,'ffe386a8-7'])
Z([[7],[3,'isReadyThree']])
Z(z[10])
Z(z[0])
Z(z[43])
Z([[4],[[5],[[4],[[5],[[5],[1,'^imgOK']],[[4],[[5],[[4],[[5],[1,'successThree']]]]]]]]])
Z([[7],[3,'dataThree']])
Z([3,'ffe386a8-8'])
Z([[7],[3,'isReadyFour']])
Z(z[10])
Z(z[0])
Z(z[43])
Z([[4],[[5],[[4],[[5],[[5],[1,'^imgOK']],[[4],[[5],[[4],[[5],[1,'successFour']]]]]]]]])
Z([[7],[3,'dataFour']])
Z([3,'ffe386a8-9'])
Z([[7],[3,'isReadyFive']])
Z(z[10])
Z(z[0])
Z(z[43])
Z([[4],[[5],[[4],[[5],[[5],[1,'^imgOK']],[[4],[[5],[[4],[[5],[1,'successFive']]]]]]]]])
Z([[7],[3,'dataFive']])
Z([3,'ffe386a8-10'])
Z([[7],[3,'isReadySix']])
Z(z[10])
Z(z[0])
Z(z[43])
Z([[4],[[5],[[4],[[5],[[5],[1,'^imgOK']],[[4],[[5],[[4],[[5],[1,'successSix']]]]]]]]])
Z([[7],[3,'dataSix']])
Z([3,'ffe386a8-11'])
Z([[7],[3,'isReadyEight']])
Z(z[10])
Z(z[0])
Z(z[43])
Z([[4],[[5],[[4],[[5],[[5],[1,'^imgOK']],[[4],[[5],[[4],[[5],[1,'successEight']]]]]]]]])
Z([[7],[3,'dataEight']])
Z([3,'ffe386a8-12'])
Z([[7],[3,'isReadyNine']])
Z(z[10])
Z(z[0])
Z(z[43])
Z([[4],[[5],[[4],[[5],[[5],[1,'^imgOK']],[[4],[[5],[[4],[[5],[1,'successNine']]]]]]]]])
Z([[7],[3,'dataNinesZt']])
Z([3,'ffe386a8-13'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_0_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_0_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_0=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_0=true;
var x=['./components/dc-hiro-painter/dc-hiro-painter.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_0_1()
var oB=_mz(z,'view',['bindtap',0,'catchtouchmove',1,'class',1,'data-event-opts',2,'id',3],[],e,s,gg)
var xC=_v()
_(oB,xC)
if(_oz(z,5,e,s,gg)){xC.wxVkey=1
}
var oD=_v()
_(oB,oD)
if(_oz(z,6,e,s,gg)){oD.wxVkey=1
}
var fE=_v()
_(oB,fE)
if(_oz(z,7,e,s,gg)){fE.wxVkey=1
}
var cF=_v()
_(oB,cF)
if(_oz(z,8,e,s,gg)){cF.wxVkey=1
var oV=_n('view')
_rz(z,oV,'class',9,e,s,gg)
var cW=_mz(z,'u-icon',['bind:__l',10,'class',1,'color',2,'name',3,'size',4,'vueId',5],[],e,s,gg)
_(oV,cW)
var oX=_mz(z,'view',['bindtap',16,'class',1,'data-event-opts',2],[],e,s,gg)
var lY=_mz(z,'u-icon',['bind:__l',19,'class',1,'color',2,'name',3,'size',4,'vueId',5],[],e,s,gg)
_(oX,lY)
_(oV,oX)
_(cF,oV)
}
var hG=_v()
_(oB,hG)
if(_oz(z,25,e,s,gg)){hG.wxVkey=1
}
var aZ=_mz(z,'u-popup',['bind:__l',26,'bind:input',1,'borderRadius',2,'class',3,'closeable',4,'data-event-opts',5,'mode',6,'value',7,'vueId',8,'vueSlots',9],[],e,s,gg)
_(oB,aZ)
var oH=_v()
_(oB,oH)
if(_oz(z,36,e,s,gg)){oH.wxVkey=1
}
var cI=_v()
_(oB,cI)
if(_oz(z,37,e,s,gg)){cI.wxVkey=1
}
var oJ=_v()
_(oB,oJ)
if(_oz(z,38,e,s,gg)){oJ.wxVkey=1
}
var lK=_v()
_(oB,lK)
if(_oz(z,39,e,s,gg)){lK.wxVkey=1
}
var aL=_v()
_(oB,aL)
if(_oz(z,40,e,s,gg)){aL.wxVkey=1
var t1=_mz(z,'painter',['bind:__l',41,'bind:imgOK',1,'class',2,'data-event-opts',3,'palette',4,'vueId',5],[],e,s,gg)
_(aL,t1)
}
var tM=_v()
_(oB,tM)
if(_oz(z,47,e,s,gg)){tM.wxVkey=1
var e2=_mz(z,'painter',['bind:__l',48,'bind:imgOK',1,'class',2,'data-event-opts',3,'palette',4,'vueId',5],[],e,s,gg)
_(tM,e2)
}
var eN=_v()
_(oB,eN)
if(_oz(z,54,e,s,gg)){eN.wxVkey=1
var b3=_mz(z,'painter',['bind:__l',55,'bind:imgOK',1,'class',2,'data-event-opts',3,'palette',4,'vueId',5],[],e,s,gg)
_(eN,b3)
}
var bO=_v()
_(oB,bO)
if(_oz(z,61,e,s,gg)){bO.wxVkey=1
var o4=_mz(z,'painter',['bind:__l',62,'bind:imgErr',1,'bind:imgOK',2,'class',3,'data-event-opts',4,'palette',5,'vueId',6],[],e,s,gg)
_(bO,o4)
}
var oP=_v()
_(oB,oP)
if(_oz(z,69,e,s,gg)){oP.wxVkey=1
var x5=_mz(z,'painter',['bind:__l',70,'bind:imgOK',1,'class',2,'data-event-opts',3,'palette',4,'vueId',5],[],e,s,gg)
_(oP,x5)
}
var xQ=_v()
_(oB,xQ)
if(_oz(z,76,e,s,gg)){xQ.wxVkey=1
var o6=_mz(z,'painter',['bind:__l',77,'bind:imgOK',1,'class',2,'data-event-opts',3,'palette',4,'vueId',5],[],e,s,gg)
_(xQ,o6)
}
var oR=_v()
_(oB,oR)
if(_oz(z,83,e,s,gg)){oR.wxVkey=1
var f7=_mz(z,'painter',['bind:__l',84,'bind:imgOK',1,'class',2,'data-event-opts',3,'palette',4,'vueId',5],[],e,s,gg)
_(oR,f7)
}
var fS=_v()
_(oB,fS)
if(_oz(z,90,e,s,gg)){fS.wxVkey=1
var c8=_mz(z,'painter',['bind:__l',91,'bind:imgOK',1,'class',2,'data-event-opts',3,'palette',4,'vueId',5],[],e,s,gg)
_(fS,c8)
}
var cT=_v()
_(oB,cT)
if(_oz(z,97,e,s,gg)){cT.wxVkey=1
var h9=_mz(z,'painter',['bind:__l',98,'bind:imgOK',1,'class',2,'data-event-opts',3,'palette',4,'vueId',5],[],e,s,gg)
_(cT,h9)
}
var hU=_v()
_(oB,hU)
if(_oz(z,104,e,s,gg)){hU.wxVkey=1
var o0=_mz(z,'painter',['bind:__l',105,'bind:imgOK',1,'class',2,'data-event-opts',3,'palette',4,'vueId',5],[],e,s,gg)
_(hU,o0)
}
xC.wxXCkey=1
oD.wxXCkey=1
fE.wxXCkey=1
cF.wxXCkey=1
cF.wxXCkey=3
hG.wxXCkey=1
oH.wxXCkey=1
cI.wxXCkey=1
oJ.wxXCkey=1
lK.wxXCkey=1
aL.wxXCkey=1
aL.wxXCkey=3
tM.wxXCkey=1
tM.wxXCkey=3
eN.wxXCkey=1
eN.wxXCkey=3
bO.wxXCkey=1
bO.wxXCkey=3
oP.wxXCkey=1
oP.wxXCkey=3
xQ.wxXCkey=1
xQ.wxXCkey=3
oR.wxXCkey=1
oR.wxXCkey=3
fS.wxXCkey=1
fS.wxXCkey=3
cT.wxXCkey=1
cT.wxXCkey=3
hU.wxXCkey=1
hU.wxXCkey=3
_(r,oB)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_0";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_0();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/dc-hiro-painter/dc-hiro-painter.wxml'] = [$gwx_XC_0, './components/dc-hiro-painter/dc-hiro-painter.wxml'];else __wxAppCode__['components/dc-hiro-painter/dc-hiro-painter.wxml'] = $gwx_XC_0( './components/dc-hiro-painter/dc-hiro-painter.wxml' );
	;__wxRoute = "components/dc-hiro-painter/dc-hiro-painter";__wxRouteBegin = true;__wxAppCurrentFile__="components/dc-hiro-painter/dc-hiro-painter.js";define("components/dc-hiro-painter/dc-hiro-painter.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
(global.webpackJsonp=global.webpackJsonp||[]).push([["components/dc-hiro-painter/dc-hiro-painter"],{875:function(t,e,i){"use strict";i.r(e);var r=i(876),s=i(878);for(var o in s)"default"!==o&&function(t){i.d(e,t,(function(){return s[t]}))}(o);i(880);var p=i(17),a=Object(p.default)(s.default,r.render,r.staticRenderFns,!1,null,"39cd90cc",null,!1,r.components,void 0);a.options.__file="components/dc-hiro-painter/dc-hiro-painter.vue",e.default=a.exports},876:function(t,e,i){"use strict";i.r(e);var r=i(877);i.d(e,"render",(function(){return r.render})),i.d(e,"staticRenderFns",(function(){return r.staticRenderFns})),i.d(e,"recyclableRender",(function(){return r.recyclableRender})),i.d(e,"components",(function(){return r.components}))},877:function(t,e,i){"use strict";var r;i.r(e),i.d(e,"render",(function(){return s})),i.d(e,"staticRenderFns",(function(){return p})),i.d(e,"recyclableRender",(function(){return o})),i.d(e,"components",(function(){return r}));try{r={uIcon:function(){return i.e("uview-ui/components/u-icon/u-icon").then(i.bind(null,854))},uPopup:function(){return i.e("uview-ui/components/u-popup/u-popup").then(i.bind(null,939))}}}catch(t){if(-1===t.message.indexOf("Cannot find module")||-1===t.message.indexOf(".vue"))throw t;console.error(t.message),console.error("1. 排查组件名称拼写是否正确"),console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"),console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件")}var s=function(){var t=this;t.$createElement,t._self._c,t._isMounted||(t.e0=function(e){t.allImgOks=!0},t.e1=function(e){t.linkCopyType=0},t.e2=function(e){t.linkCopyType=1},t.e3=function(e){t.allImgOks=!1})},o=!1,p=[];s._withStripped=!0},878:function(t,e,i){"use strict";i.r(e);var r=i(879),s=i.n(r);for(var o in r)"default"!==o&&function(t){i.d(e,t,(function(){return r[t]}))}(o);e.default=s.a},879:function(t,e,i){"use strict";(function(t){function r(t,e,i){return e in t?Object.defineProperty(t,e,{value:i,enumerable:!0,configurable:!0,writable:!0}):t[e]=i,t}Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var s={props:{shareObj:{type:Object,default:{}}},components:{painter:function(){Promise.all([i.e("common/vendor"),i.e("components/dc-hiro-painter/painter")]).then(function(){return resolve(i(1170))}.bind(null,i)).catch(i.oe)}},data:function(){var t,e,i,s,o;return{allImgOks:!1,linkCopyType:0,saveUrls:"",pathSwiperTwo:["https://qiniuimg.kfmanager.com/toolplatform/img/r52j1frnssb962stt4.jpg","https://qiniuimg.kfmanager.com/toolplatform/img/r52j1frnssb962stt4.jpg"],allImgOkTwo:!1,allImgOk:!1,background:["color1","color2","color3"],indicatorDots:!0,autoplay:!0,interval:2e3,duration:500,current:0,defaultPath:"",pathSwiper:[],dataOne:{background:"#fff",width:"800rpx",height:"640rpx",borderRadius:"0rpx",views:[{type:"image",url:"https://qiniuimg.kfmanager.com/toolplatform/img/r5m8cbymk11fmkgcd7.jpg",css:{top:"0",left:"0",width:"60rpx",height:"60rpx",mode:"aspectFill",borderRadius:"12rpx"}},{type:"rect",css:{top:"516rpx",left:"60rpx",width:"680rpx",height:"112rpx",borderRadius:"56rpx",color:"#07c160"}},{type:"image",url:"https://qiniuimg.kfmanager.com/toolplatform/img/67qn4bg5c83r74ig7r.jpg",css:{top:"76rpx",left:"0rpx",width:"800rpx",height:"420rpx",mode:"aspectFill"}},{type:"text",text:"群优选团购",css:{top:"4rpx",left:"88rpx",fontSize:"44rpx",color:"#333333"}},{type:"text",text:"我要团购",css:{top:"536rpx",left:"60rpx",textAlign:"center",width:"680rpx",height:"112rpx",fontSize:"52rpx",color:"#ffffff"}}]},dataThree:{background:"#fff",width:"700rpx",height:"800rpx",views:[{type:"image",url:"https://qiniuimg.kfmanager.com/toolplatform/img/r5m8cbymk11fmkgcd7.jpg",css:{top:"70rpx",left:"275rpx",width:"150rpx",height:"150rpx",mode:"aspectFill",borderRadius:"75rpx"}},{type:"rect",css:{top:"334rpx",left:"260rpx",width:"180rpx",height:"40rpx",borderRadius:"6rpx",color:"#faf1e1"}},{type:"image",url:"https://qiniuimg.kfmanager.com/toolplatform/img/67qn4bg5c83r74ig7r.jpg",css:{top:"510rpx",left:"275rpx",width:"150rpx",height:"150rpx",borderRadius:"75rpx",mode:"aspectFill"}},{type:"image",url:"https://qiniuimg.kfmanager.com/toolplatform/img/67qn4bg5c83r74ig7r.jpg",css:{top:"550rpx",left:"316rpx",width:"70rpx",height:"70rpx",borderRadius:"35rpx",mode:"aspectFill"}},{type:"text",text:"12345",css:{top:"260rpx",left:"0rpx",width:"700rpx",textAlign:"center",fontSize:"36rpx",color:"#000"}},{type:"text",text:"美好的社群生活，从我们相聚这一刻开始",css:{top:"396rpx",left:"50rpx",width:"600rpx",textAlign:"center",fontSize:"30rpx",color:"#777"}},{type:"text",text:"社群成员",css:{top:"448rpx",left:"148rpx",fontSize:"24rpx",color:"#999"}},{type:"text",text:"8",css:{top:"444rpx",left:"270rpx",fontSize:"30rpx",color:"#08ba0b"}},{type:"text",text:" 接龙人次",css:{top:"448rpx",left:"390rpx",fontSize:"24rpx",color:"#999"}},{type:"text",text:"3002",css:{top:"444rpx",left:"510rpx",fontSize:"30rpx",color:"#08ba0b"}},{type:"text",text:"302次接龙",css:{top:"334rpx",left:"260rpx",width:"180rpx",textAlign:"center",fontSize:"30rpx",color:"#f3bf70"}},{type:"text",text:"长按识别进入主页",css:{top:"700rpx",left:"0rpx",width:"700rpx",textAlign:"center",fontSize:"30rpx",color:"#999"}}]},dataTwo:{background:"#fff",width:"510rpx",height:"928rpx",views:[{type:"image",url:"https://qiniuimg.kfmanager.com/qunjl/showrel/miniqyxs.png",css:{top:"24rpx",left:"24rpx",width:"60rpx",height:"60rpx",mode:"aspectFill",borderRadius:"30rpx"}},{type:"image",url:"https://qiniuimg.kfmanager.com/qunjl/showrel/miniqyxs.png",css:{top:"210rpx",left:"24rpx",width:"462rpx",height:"504rpx",mode:"aspectFill"}},{type:"image",url:"https://qiniuimg.kfmanager.com/qunjl/showrel/miniqyxs.png",css:{top:"777rpx",left:"360rpx",width:"120rpx",height:"120rpx",borderRadius:"60rpx",mode:"aspectFill"}},{type:"text",text:"",css:{top:"32rpx",left:"98rpx",fontSize:"22rpx",color:"#333333"}},{type:"text",text:"2021 12 02",css:{top:"64rpx",left:"98rpx",fontSize:"20rpx",color:"#999"}},{type:"text",text:"",css:{top:"104rpx",left:"24rpx",width:"462rpx",fontSize:"28rpx",color:"#000",lineHeight:"42rpx",maxLines:2,fontFamily:"宋体"}},{type:"text",text:"￥1",css:{top:"732rpx",left:"24rpx",fontSize:"28rpx",color:"#fc011a"}},{type:"text",text:"一群人正在赶来接龙",css:{top:"812rpx",left:"24rpx",fontSize:"24rpx",color:"#999999"}},{type:"text",text:"长按识别参与",css:{top:"858rpx",left:"24rpx",fontSize:"22rpx",color:"#999999"}},{type:"image",url:"https://qiniuimg.kfmanager.com/qunjl/showrel/miniqyxs.png",css:{top:"810rpx",left:"393rpx",width:"54rpx",height:"54rpx",mode:"aspectFill",borderRadius:"30rpx"}}]},dataTwoSixz:{background:"#fff",width:"510rpx",height:"928rpx",views:[{type:"image",url:"https://qiniuimg.kfmanager.com/qunjl/showrel/miniqyxs.png",css:{top:"24rpx",left:"24rpx",width:"60rpx",height:"60rpx",mode:"aspectFill",borderRadius:"30rpx"}},{type:"image",url:"https://qiniuimg.kfmanager.com/qunjl/showrel/miniqyxs.png",css:{top:"210rpx",left:"24rpx",width:"146rpx",height:"240rpx",mode:"aspectFill"}},{type:"image",url:"https://qiniuimg.kfmanager.com/qunjl/showrel/miniqyxs.png",css:{top:"210rpx",left:"182rpx",width:"146rpx",height:"240rpx",mode:"aspectFill"}},{type:"image",url:"https://qiniuimg.kfmanager.com/qunjl/showrel/miniqyxs.png",css:{top:"210rpx",left:"340rpx",width:"146rpx",height:"240rpx",mode:"aspectFill"}},{type:"image",url:"https://qiniuimg.kfmanager.com/qunjl/showrel/miniqyxs.png",css:{top:"462rpx",left:"24rpx",width:"146rpx",height:"240rpx",mode:"aspectFill"}},{type:"image",url:"https://qiniuimg.kfmanager.com/qunjl/showrel/miniqyxs.png",css:{top:"462rpx",left:"182rpx",width:"146rpx",height:"240rpx",mode:"aspectFill"}},{type:"image",url:"https://qiniuimg.kfmanager.com/qunjl/showrel/miniqyxs.png",css:{top:"462rpx",left:"340rpx",width:"146rpx",height:"240rpx",mode:"aspectFill"}},{type:"image",url:"https://qiniuimg.kfmanager.com/qunjl/showrel/miniqyxs.png",css:{top:"777rpx",left:"360rpx",width:"120rpx",height:"120rpx",borderRadius:"60rpx",mode:"aspectFill"}},{type:"text",text:"",css:{top:"32rpx",left:"98rpx",fontSize:"22rpx",color:"#333333"}},{type:"text",text:"2021 12 02",css:{top:"64rpx",left:"98rpx",fontSize:"20rpx",color:"#999"}},{type:"text",text:"",css:{top:"104rpx",left:"24rpx",width:"462rpx",fontSize:"28rpx",color:"#000",lineHeight:"42rpx",maxLines:2}},{type:"text",text:"￥1",css:{top:"732rpx",left:"24rpx",fontSize:"28rpx",color:"#fc011a"}},{type:"text",text:"一群人正在赶来接龙",css:{top:"812rpx",left:"24rpx",fontSize:"24rpx",color:"#999999"}},{type:"text",text:"长按识别参与",css:{top:"858rpx",left:"24rpx",fontSize:"22rpx",color:"#999999"}},{type:"image",url:"https://qiniuimg.kfmanager.com/qunjl/showrel/miniqyxs.png",css:{top:"810rpx",left:"393rpx",width:"54rpx",height:"54rpx",mode:"aspectFill",borderRadius:"30rpx"}}]},dataTwoBm:{background:"#fff",width:"510rpx",height:"928rpx",views:[{type:"image",url:"https://qiniuimg.kfmanager.com/qunjl/showrel/miniqyxs.png",css:{top:"24rpx",left:"24rpx",width:"70rpx",height:"70rpx",mode:"aspectFill",borderRadius:"35rpx"}},{type:"image",url:"https://qiniuimg.kfmanager.com/qunjl/showrel/miniqyxs.png",css:{top:"240rpx",left:"27rpx",width:"456rpx",height:"456rpx",mode:"aspectFill"}},{type:"image",url:"https://qiniuimg.kfmanager.com/toolplatform/img/67qn4bg5c83r74ig7r.jpg",css:{bottom:"24rpx",left:"380rpx",width:"100rpx",height:"100rpx",borderRadius:"50rpx",mode:"aspectFill"}},{type:"text",text:"群优选",css:{top:"40rpx",left:"106rpx",fontSize:"24rpx",color:"#000"}},{type:"image",url:"https://qiniuimg.kfmanager.com/qunjl/showrel/miniqyxs.png",css:{bottom:"51rpx",left:"407rpx",width:"46rpx",height:"46rpx",borderRadius:"23rpx",mode:"aspectFill"}},{type:"text",text:"群优选|接龙团购",css:{top:"160rpx",left:"24rpx",width:"456rpx",fontSize:"24rpx",fontWeight:"bold",color:"#000",lineHeight:"38rpx",maxLines:2}},{type:"text",text:"1",css:{top:"720rpx",left:"124rpx",fontSize:"32rpx",fontWeight:"bold",color:"#df4c3f"}},{type:"rect",css:{top:"786rpx",left:"24rpx",width:"456rpx",height:"2rpx",color:"#f4f4f4"}},{type:"text",text:"长按扫码参与帮卖",css:{bottom:"66rpx",left:"24rpx",fontSize:"22rpx",color:"#888888"}},{type:"text",text:"每份赚￥",css:{top:"728rpx",left:"24rpx",fontSize:"24rpx",color:"#df4c3f"}},{type:"text",text:"邀请你帮卖",css:{top:"96rpx",left:"0rpx",width:"510rpx",fontSize:"32rpx",fontWeight:"bold",color:"#07c160",textAlign:"center"}}]},dataFour:{background:"#fff",width:"300rpx",height:"300rpx",borderRadius:"0rpx",views:[{type:"image",url:"https://qiniuimg.kfmanager.com/toolplatform/img/r5m8cbymk11fmkgcd7.jpg",css:{top:"0",left:"0",width:"300rpx",height:"300rpx"}},{type:"image",url:"https://qiniuimg.kfmanager.com/toolplatform/img/67qn4bg5c83r74ig7r.jpg",css:{top:"80rpx",left:"80rpx",width:"140rpx",height:"140rpx",borderRadius:"70rpx"}}]},dataFive:{background:"#fff",width:"750rpx",height:"1229rpx",borderRadius:"0rpx",views:[{type:"image",url:"https://qiniuimg.kfmanager.com/qunjl/showrel/yqrjlpl.jpg",css:{top:"0",left:"0",width:"750rpx",height:"1229rpx"}},{type:"image",url:"https://qiniuimg.kfmanager.com/toolplatform/img/67qn4bg5c83r74ig7r.jpg",css:{top:"924rpx",left:"172rpx",width:"170rpx",height:"170rpx",borderRadius:"80rpx"}}]},dataSix:{background:"#fff",width:"800rpx",height:"640rpx",borderRadius:"0rpx",views:[{type:"text",text:"¥10.0",css:{top:"2rpx",left:"2rpx",fontSize:"48rpx",color:"#fc011a"}},{type:"rect",css:{top:"516rpx",left:"60rpx",width:"680rpx",height:"112rpx",borderRadius:"56rpx",color:"#07c160"}},{type:"text",text:"我要团购",css:{top:"536rpx",left:"60rpx",textAlign:"center",width:"680rpx",height:"112rpx",fontSize:"52rpx",color:"#ffffff"}},{type:"text",text:"12",css:{top:"130rpx",left:"0rpx",fontSize:"36rpx",color:"#000"}},{type:"image",url:"https://qiniuimg.kfmanager.com/toolplatform/img/67qn4bg5c83r74ig7r.jpg",css:{top:"124rpx",left:"90rpx",width:"56rpx",height:"56rpx"}},{type:"text",text:"北**",css:{top:"130rpx",left:"160rpx",fontSize:"36rpx",color:"#333"}},{type:"text",text:"1小时前",css:{top:"130rpx",left:"252rpx",fontSize:"32rpx",color:"#999"}},{type:"text",text:"新鲜鲫鱼大只约3斤+1290",css:(t={top:"130rpx",right:"2rpx",fontSize:"38rpx",color:"#999",width:"400rpx"},r(t,"color","#333"),r(t,"textAlign","right"),r(t,"maxLines",1),t)},{type:"text",text:"9",css:{top:"210rpx",left:"0rpx",fontSize:"36rpx",color:"#000"}},{type:"image",url:"https://qiniuimg.kfmanager.com/toolplatform/img/67qn4bg5c83r74ig7r.jpg",css:{top:"204rpx",left:"90rpx",width:"56rpx",height:"56rpx"}},{type:"text",text:"Y**",css:{top:"210rpx",left:"160rpx",fontSize:"36rpx",color:"#333"}},{type:"text",text:"3小时前",css:{top:"210rpx",left:"252rpx",fontSize:"32rpx",color:"#999"}},{type:"text",text:"新鲜鲫鱼大只约3斤",css:(e={top:"210rpx",right:"2rpx",fontSize:"38rpx",color:"#999",width:"400rpx"},r(e,"color","#333"),r(e,"textAlign","right"),r(e,"maxLines",1),e)},{type:"text",text:"9",css:{top:"290rpx",left:"0rpx",fontSize:"36rpx",color:"#000"}},{type:"image",url:"https://qiniuimg.kfmanager.com/toolplatform/img/67qn4bg5c83r74ig7r.jpg",css:{top:"284rpx",left:"90rpx",width:"56rpx",height:"56rpx"}},{type:"text",text:"Y**",css:{top:"290rpx",left:"160rpx",fontSize:"36rpx",color:"#333"}},{type:"text",text:"3小时前",css:{top:"290rpx",left:"252rpx",fontSize:"32rpx",color:"#999"}},{type:"text",text:"新鲜鲫鱼大只约3斤",css:(i={top:"290rpx",right:"2rpx",fontSize:"38rpx",color:"#999",width:"400rpx"},r(i,"color","#333"),r(i,"textAlign","right"),r(i,"maxLines",1),i)},{type:"text",text:"9",css:{top:"370rpx",left:"0rpx",fontSize:"36rpx",color:"#000"}},{type:"image",url:"https://qiniuimg.kfmanager.com/toolplatform/img/67qn4bg5c83r74ig7r.jpg",css:{top:"364rpx",left:"90rpx",width:"56rpx",height:"56rpx"}},{type:"text",text:"Y**",css:{top:"370rpx",left:"160rpx",fontSize:"36rpx",color:"#333"}},{type:"text",text:"3小时前",css:{top:"370rpx",left:"252rpx",fontSize:"32rpx",color:"#999"}},{type:"text",text:"新鲜鲫鱼大只约3斤",css:(s={top:"370rpx",right:"2rpx",fontSize:"38rpx",color:"#999",width:"400rpx"},r(s,"color","#333"),r(s,"textAlign","right"),r(s,"maxLines",1),s)},{type:"text",text:"9",css:{top:"450rpx",left:"0rpx",fontSize:"36rpx",color:"#000"}},{type:"image",url:"https://qiniuimg.kfmanager.com/toolplatform/img/67qn4bg5c83r74ig7r.jpg",css:{top:"444rpx",left:"90rpx",width:"56rpx",height:"56rpx"}},{type:"text",text:"Y**",css:{top:"450rpx",left:"160rpx",fontSize:"36rpx",color:"#333"}},{type:"text",text:"3小时前",css:{top:"450rpx",left:"252rpx",fontSize:"32rpx",color:"#999"}},{type:"text",text:"新鲜鲫鱼大只约3斤",css:(o={top:"450rpx",right:"2rpx",fontSize:"38rpx",color:"#999",width:"400rpx"},r(o,"color","#333"),r(o,"textAlign","right"),r(o,"maxLines",1),o)}]},dataSeven:{background:"#fff",width:"800rpx",height:"640rpx",borderRadius:"0rpx",views:[{type:"image",url:"https://qiniuimg.kfmanager.com/toolplatform/img/r5m8cbymk11fmkgcd7.jpg",css:{top:"0",left:"0",width:"60rpx",height:"60rpx",mode:"aspectFill",borderRadius:"12rpx"}},{type:"rect",css:{top:"516rpx",left:"60rpx",width:"680rpx",height:"112rpx",borderRadius:"56rpx",color:"#07c160"}},{type:"image",url:"https://qiniuimg.kfmanager.com/toolplatform/img/67qn4bg5c83r74ig7r.jpg",css:{top:"76rpx",left:"0rpx",width:"256rpx",height:"200rpx",mode:"aspectFill"}},{type:"image",url:"https://qiniuimg.kfmanager.com/toolplatform/img/67qn4bg5c83r74ig7r.jpg",css:{top:"76rpx",left:"272rpx",width:"256rpx",height:"200rpx",mode:"aspectFill"}},{type:"image",url:"https://qiniuimg.kfmanager.com/toolplatform/img/67qn4bg5c83r74ig7r.jpg",css:{top:"76rpx",left:"544rpx",width:"256rpx",height:"200rpx",mode:"aspectFill"}},{type:"image",url:"https://qiniuimg.kfmanager.com/toolplatform/img/67qn4bg5c83r74ig7r.jpg",css:{top:"292rpx",left:"0rpx",width:"256rpx",height:"200rpx",mode:"aspectFill"}},{type:"image",url:"https://qiniuimg.kfmanager.com/toolplatform/img/67qn4bg5c83r74ig7r.jpg",css:{top:"292rpx",left:"272rpx",width:"256rpx",height:"200rpx",mode:"aspectFill"}},{type:"image",url:"https://qiniuimg.kfmanager.com/toolplatform/img/67qn4bg5c83r74ig7r.jpg",css:{top:"292rpx",left:"544rpx",width:"256rpx",height:"200rpx",mode:"aspectFill"}},{type:"text",text:"群优选团购",css:{top:"4rpx",left:"88rpx",fontSize:"44rpx",color:"#333333"}},{type:"text",text:"我要团购",css:{top:"536rpx",left:"60rpx",textAlign:"center",width:"680rpx",height:"112rpx",fontSize:"52rpx",color:"#ffffff"}}]},dataEight:{background:"#fff",width:"800rpx",height:"640rpx",borderRadius:"0rpx",views:[{type:"image",url:"https://qiniuimg.kfmanager.com/qunjl/showrel/aaasharemt.jpg",css:{top:"0rpx",left:"0rpx",width:"800rpx",height:"640rpx",mode:"aspectFill"}},{type:"image",url:"https://qiniuimg.kfmanager.com/qunjl/showrel/aaasharemt.png",css:{top:"44rpx",left:"44rpx",width:"452rpx",height:"554rpx",mode:"aspectFill",borderRadius:"20rpx"}},{type:"text",text:"¥",css:{top:"160rpx",left:"526rpx",fontSize:"48rpx",fontWeight:"bold",color:"#e44424"}},{type:"text",text:"85.25",css:{top:"140rpx",left:"562rpx",fontSize:"72rpx",fontWeight:"bold",color:"#e44424"}}]},dataBmktt:{background:"#fff",width:"800rpx",height:"640rpx",borderRadius:"0rpx",views:[{type:"image",url:"https://qiniuimg.kfmanager.com/qunjl/showrel/bmshares.png",css:{top:"0rpx",left:"0rpx",width:"800rpx",height:"640rpx",mode:"aspectFill"}},{type:"image",url:"https://qiniuimg.kfmanager.com/qunjl/showrel/aaasharemt.png",css:{top:"72rpx",left:"60rpx",width:"134rpx",height:"134rpx",mode:"aspectFill",borderRadius:"12rpx"}},{type:"text",text:"群优选用户",css:{top:"78rpx",left:"216rpx",fontSize:"42rpx",fontWeight:"bold",color:"#000"}},{type:"text",text:"8",css:{top:"272rpx",left:"0rpx",width:"390rpx",textAlign:"center",fontSize:"72rpx",fontWeight:"bold",color:"#ed6f39"}},{type:"text",text:"855",css:{top:"272rpx",left:"390rpx",width:"410rpx",textAlign:"center",fontSize:"72rpx",fontWeight:"bold",color:"#ed6f39"}},{type:"text",text:"加入帮卖轻松赚取佣金",css:{top:"148rpx",left:"216rpx",fontSize:"36rpx",color:"#777"}}]},dataEightQyx:{background:"#fff",width:"800rpx",height:"640rpx",borderRadius:"0rpx",views:[{type:"image",url:"https://qiniuimg.kfmanager.com/qunjl/showrel/aaasharemtus.png",css:{top:"0rpx",left:"0rpx",width:"800rpx",height:"640rpx",mode:"aspectFill"}},{type:"image",url:"https://qiniuimg.kfmanager.com/qunjl/showrel/aaasharemt.png",css:{top:"170rpx",left:"64rpx",width:"362rpx",height:"422rpx",mode:"aspectFill",borderRadius:"20rpx"}},{type:"text",text:"¥",css:{top:"274rpx",left:"486rpx",fontSize:"48rpx",fontWeight:"bold",color:"#07c160"}},{type:"text",text:"85.25",css:{top:"252rpx",left:"518rpx",fontSize:"72rpx",fontWeight:"bold",color:"#07c160"}}]},dataNines:{background:"#fff",width:"630rpx",height:"760rpx",borderRadius:"0rpx",views:[{type:"image",url:"https://qiniuimg.kfmanager.com/qunjl/showrel/usercancal.png",css:{top:"0rpx",left:"0rpx",width:"630rpx",height:"760rpx",mode:"aspectFill"}},{type:"image",url:"https://qiniuimg.kfmanager.com/toolplatform/img/b7vb3i7y11p6sjsghw.jpg",css:{top:"218rpx",left:"165rpx",width:"300rpx",height:"300rpx",mode:"aspectFill",borderRadius:"20rpx"}},{type:"image",url:"https://qiniuimg.kfmanager.com/toolplatform/img/b7vb3i7y11p6sjsghw.jpg",css:{top:"300rpx",left:"249rpx",width:"134rpx",height:"134rpx",mode:"aspectFill",borderRadius:"67rpx"}},{type:"text",text:"群优选用户",css:{top:"548rpx",left:"0",width:"630rpx",textAlign:"center",fontSize:"40rpx",color:"#000"}}]},dataNinesZt:{background:"#fff",width:"690rpx",height:"1168rpx",borderRadius:"0rpx",views:[{type:"image",url:"https://qiniuimg.kfmanager.com/qunjl/showrel/ziticancal.png",css:{top:"0rpx",left:"0rpx",width:"690rpx",height:"1168rpx",mode:"aspectFill"}},{type:"image",url:"https://qiniuimg.kfmanager.com/toolplatform/img/b7vb3i7y11p6sjsghw.jpg",css:{top:"240rpx",left:"140rpx",width:"410rpx",height:"410rpx",mode:"aspectFill",borderRadius:"205rpx"}},{type:"image",url:"https://qiniuimg.kfmanager.com/toolplatform/img/b7vb3i7y11p6sjsghw.jpg",css:{top:"353rpx",left:"254rpx",width:"182rpx",height:"182rpx",mode:"aspectFill",borderRadius:"91rpx"}},{type:"text",text:"群优选用户",css:{top:"777rpx",left:"0",width:"690rpx",textAlign:"center",fontSize:"40rpx",color:"#fff"}},{type:"text",text:"自提点",css:{top:"846rpx",left:"0",width:"690rpx",textAlign:"center",fontSize:"44rpx",color:"#fff"}}]},dataEle:{background:"#fff",width:"800rpx",height:"640rpx",borderRadius:"0rpx",views:[{type:"image",url:"https://qiniuimg.kfmanager.com/qunjl/showrel/bmshares.png",css:{top:"0rpx",left:"0rpx",width:"800rpx",height:"640rpx",mode:"aspectFill"}},{type:"image",url:"https://qiniuimg.kfmanager.com/qunjl/showrel/aaasharemt.png",css:{top:"72rpx",left:"60rpx",width:"134rpx",height:"134rpx",mode:"aspectFill",borderRadius:"12rpx"}},{type:"text",text:"群优选用户",css:{top:"78rpx",left:"216rpx",fontSize:"42rpx",fontWeight:"bold",color:"#000"}},{type:"text",text:"8",css:{top:"272rpx",left:"0rpx",width:"390rpx",textAlign:"center",fontSize:"72rpx",fontWeight:"bold",color:"#ed6f39"}},{type:"text",text:"855",css:{top:"272rpx",left:"390rpx",width:"410rpx",textAlign:"center",fontSize:"72rpx",fontWeight:"bold",color:"#ed6f39"}},{type:"text",text:"加入帮卖轻松赚取佣金",css:{top:"148rpx",left:"216rpx",fontSize:"36rpx",color:"#777"}}]},dataTwens:{background:"#fff",width:"630rpx",height:"866rpx",borderRadius:"0rpx",views:[{type:"image",url:"https://qiniuimg.kfmanager.com/qunjl/showrel/kttbmyq.png",css:{top:"0rpx",left:"0rpx",width:"630rpx",height:"866rpx",mode:"aspectFill"}},{type:"image",url:"https://qiniuimg.kfmanager.com/toolplatform/img/b7vb3i7y11p6sjsghw.jpg",css:{top:"100rpx",left:"260rpx",width:"110rpx",height:"110rpx",mode:"aspectFill",borderRadius:"12rpx"}},{type:"image",url:"https://qiniuimg.kfmanager.com/toolplatform/img/b7vb3i7y11p6sjsghw.jpg",css:{top:"534rpx",left:"227rpx",width:"176rpx",height:"176rpx",mode:"aspectFill",borderRadius:"67rpx"}},{type:"text",text:"群优选用户",css:{top:"230rpx",left:"0",width:"630rpx",textAlign:"center",fontSize:"32rpx",color:"#222"}}]},appletQrImgs:"",title:"快来接龙吧",isReady:!1,isReadyTwo:!1,isReadyTwoSixz:!1,isReadyThree:!1,isReadyFour:!1,isReadyFive:!1,isReadySix:!1,isReadySeven:!1,isReadyEight:!1,isReadyNine:!1,height:320,param:{},paramTwo:{},paramThree:{},paramFour:{},paramFive:{},path:"",pathTwo:"",pathTwoSixz:"",pathThree:"",pathFour:"",pathFive:"",pathSix:"",pathSeven:"",pathEight:"",pathNine:"",pathBm:"",oooppp:!1,omageTest:"",isFirstin:!1,isPageActOne:!1}},watch:{path:{handler:function(t,e){this.shareObj.bmtzShare||this.shareObj.ztShare||this.pathSwiperGet("画图===path")}},pathSix:{handler:function(t,e){this.pathSwiperGet("画图===pathSix")}},pathSeven:{handler:function(t,e){this.pathSwiperGet("画图===pathSeven")}},pathEight:{handler:function(t,e){this.pathSwiperGet("画图===pathEight")}},pathTwo:{handler:function(t,e){this.pathSwiperGet("海报===pathTwo")}},pathTwoSixz:{handler:function(t,e){this.pathSwiperGet("海报===pathTwoSixz")}}},onLoad:function(){},created:function(){var t=this;if(console.log("父组件传值==||this.shareObj.ztShare",this.shareObj,this.isReady,this.isReadyTwo),this.shareObj.bmtzShare||this.shareObj.ztShareUser){var e=this.dataBmktt;return this.shareObj.bmtzShare?this.title=this.shareObj.nickName+"邀请你成为他的帮卖团长，轻松赚取佣金":this.shareObj.ztShare?e=JSON.parse(JSON.stringify(this.dataEle)):e.views[0].url="https://qiniuimg.kfmanager.com/qunjl/showrel/zitiuser.jpg",e.views[1].url=this.shareObj.headImg,e.views[2].text=this.shareObj.nickName,e.views[3].text=this.shareObj.memberCount+"",e.views[4].text=this.shareObj.solitaireCount+"",e.views[5].text=this.shareObj.introduction,this.dataOne=e,this.isReady=!0,!1}if(this.shareObj.ztShare)return this.creatNines(),!1;if(99===this.shareObj.typeHome){var i=this.dataFive;i.views[0].url=this.shareObj.bgImg,i.views[1].url=this.shareObj.codeImg,this.dataFive=i,this.isReadyFive=!0}else if(this.shareObj.typeHome)this.appletQrThree();else if(this.shareObj.isShop?this.title=this.shareObj.title+"   "+this.shareObj.maxSellPriceShow:this.title=this.shareObj.title,console.log("父组件传值==11"),this.shareObj.imgUrls.length){var r=this.dataOne;r.views[0].url=this.shareObj.headImg,r.views[3].text=this.shareObj.nickName,r.views[4].text=this.shareObj.shareBtn,this.shareObj.imgUrls.length?r.views[2].url=this.shareObj.imgUrls[0]:r.views[2].url="https://qiniuimg.kfmanager.com/qunjl/showrel/yqrjlpl.jpg",console.log("父组endParam==",r),this.shareObj.openPyq?this.appletQrImgUrl():(this.shareObj.isFirstin||(this.mtCssCreateQyx(),this.shareObj.rankList&&this.rankListMap(),this.shareObj.imgUrls.length>5&&this.sixImgCreate()),console.log("父组件传值==22"),this.isReady=!0,setTimeout((function(e){t.allImgOk||!t.isReady||t.isReadyTwo||t.isPageActOne||t.shareObj.isFirstin||(console.log("我进来了===画图失败超时 "),t.pathSwiper=["https://qiniuimg.kfmanager.com/qunjl/showrel/aaashare.png"],t.$emit("shareUrl","https://qiniuimg.kfmanager.com/qunjl/showrel/aaashare.png"),t.allImgOk=!0)}),5500))}else console.log("父组endParam==222",{}),this.shareObj.openPyq?this.appletQrImgUrl():(this.shareObj.shareBtn.includes("帮卖")?this.path="https://qiniuimg.kfmanager.com/qunjl/showrel/aaasharebm.png":this.path="https://qiniuimg.kfmanager.com/qunjl/showrel/aaashare.png",this.shareObj.rankList&&!this.shareObj.isFirstin&&this.rankListMap(),this.$emit("shareUrl",this.path),this.shareObj.isFirstin&&this.closeBox(99));if(this.shareObj.activityId&&!this.shareObj.isFirstin){this.addIncActShare();var s=[{pageType:6,activityId:this.shareObj.activityId,userId:this.shareObj.adminUserId}];this.sendAccessLog(s)}},methods:{informPost:function(){this.linkCopyType?this.getAppletUrlLink():this.getAppletShortLink()},getAppletShortLink:function(){var e=this,i={pageUrl:"pages/subPage/showRel?"+this.shareObj.shareScene,pageTitle:"点击跟团👉 "};this.$server.appletShortLink(i).then((function(i){if(0==i.code){var r=e;t.setClipboardData({data:r.shareObj.title+i.data.shortLink,success:function(){t.showToast({title:"复制成功",icon:"success"})}})}else setTimeout((function(e){t.hideLoading(),t.showToast({title:i.message,icon:"none"})}),500)}))},getAppletUrlLink:function(){var e={path:"pages/subPage/showRel",query:this.shareObj.shareScene};this.$server.appletUrlLink(e).then((function(e){0==e.code?t.setClipboardData({data:e.data.urlLink,success:function(){t.showToast({title:"复制成功",icon:"success"})}}):setTimeout((function(i){t.hideLoading(),t.showToast({title:e.message,icon:"none"})}),500)}))},pathSwiperGet:function(e){var i=this;console.log("监听pathSwiperGet===",e),e.includes("画图")?this.shareObj.rankList&&this.shareObj.imgUrls.length>5?this.path&&this.pathSix&&this.pathSeven&&this.pathEight&&(this.pathSwiper=[this.pathSeven,this.path,this.pathSix,this.pathEight],this.allImgOk=!0,this.isPageActOne=!0,this.$emit("shareUrl",this.pathSwiper[0]),t.hideLoading()):this.shareObj.rankList?this.shareObj.imgUrls.length?this.path&&this.pathSix&&this.pathEight&&(this.pathSwiper=[this.path,this.pathSix,this.pathEight],this.allImgOk=!0,this.isPageActOne=!0,this.$emit("shareUrl",this.pathSwiper[0]),t.hideLoading()):this.path&&this.pathSix&&(this.pathSwiper=[this.path,this.pathSix],this.allImgOk=!0,this.isPageActOne=!0,this.$emit("shareUrl",this.pathSwiper[0]),t.hideLoading()):this.shareObj.imgUrls.length>5?this.path&&this.pathSeven&&this.pathEight&&(this.pathSwiper=[this.pathSeven,this.path,this.pathEight],this.allImgOk=!0,this.isPageActOne=!0,this.$emit("shareUrl",this.pathSwiper[0]),t.hideLoading()):this.shareObj.imgUrls.length?this.path&&this.pathEight&&(this.pathSwiper=[this.path,this.pathEight],this.allImgOk=!0,this.isPageActOne=!0,this.$emit("shareUrl",this.pathSwiper[0]),t.hideLoading()):this.path&&(this.pathSwiper=[this.path],setTimeout((function(e){i.allImgOk=!0,i.isPageActOne=!0,t.hideLoading()}),600),this.$emit("shareUrl",this.pathSwiper[0])):this.shareObj.shareBtn.includes("帮卖")?(this.pathSwiperTwo=[this.pathTwo],this.allImgOkTwo=!0,t.hideLoading()):this.shareObj.imgUrls.length>5?this.pathTwo&&this.pathTwoSixz&&(this.pathSwiperTwo=[this.pathTwo,this.pathTwoSixz],this.allImgOkTwo=!0,t.hideLoading()):(this.pathSwiperTwo=[this.pathTwo],this.allImgOkTwo=!0,t.hideLoading())},mtCssCreate:function(){var t=JSON.parse(JSON.stringify(this.dataEight));t.views[1].url=this.shareObj.imgUrls[0];var e=this.shareObj.maxSellPriceShow.split("¥");console.log("qina==",e);var i=(e=e[1]).split("~");console.log("latsq==",i),(i=i[0]).length>5&&(i=(i=i.split("."))[0]),t.views[3].text=i,this.dataEight=t,this.isReadyEight=!0},mtCssCreateQyx:function(){var t=JSON.parse(JSON.stringify(this.dataEightQyx));t.views[1].url=this.shareObj.imgUrls[0];var e=this.shareObj.maxSellPriceShow.split("¥");console.log("qina==",e);var i=(e=e[1]).split("~");console.log("latsq==",i),(i=i[0]).length>5&&(i=(i=i.split("."))[0]),t.views[3].text=i,this.dataEight=t,this.isReadyEight=!0},sixImgCreate:function(){console.log("sevenErr开始绘制");var t=JSON.parse(JSON.stringify(this.dataSeven));t.views[0].url=this.shareObj.headImg,t.views[8].text=this.shareObj.nickName,t.views[9].text=this.shareObj.shareBtn,t.views[2].url=this.shareObj.imgUrls[0],t.views[3].url=this.shareObj.imgUrls[1],t.views[4].url=this.shareObj.imgUrls[2],t.views[5].url=this.shareObj.imgUrls[3],t.views[6].url=this.shareObj.imgUrls[4],t.views[7].url=this.shareObj.imgUrls[5],this.dataSeven=t,this.isReadySeven=!0,console.log("sevenErr开始绘制2")},moveHandle:function(){},rankListMap:function(){console.log("rankListMap");var t=JSON.parse(JSON.stringify(this.dataSix));t.views[0].text=this.shareObj.maxSellPriceShow,this.shareObj.rankList.forEach((function(e,i){var r=5*i+3;t.views[r].text=e.activityNumb+"",t.views[r+1].url=e.headImg,t.views[r+2].text=e.nickName,t.views[r+3].text=e.differTime,t.views[r+4].text=e.commodityName+"+"+e.commodityCount})),this.shareObj.rankList.length<5&&(t.views=t.views.slice(0,3+5*this.shareObj.rankList.length)),t.views[2].text=this.shareObj.shareBtn,this.dataSix=JSON.parse(JSON.stringify(t)),this.isReadySix=!0,console.log("跟团记录json==",this.dataSix.views)},closeBox:function(t){if(99==t)return console.log("首次关闭弹窗==",t),this.$emit("closeShare","closeShare"),!1;null!=t.target.id&&t.target.id.includes("out-")&&(console.log("关闭弹窗==",t),this.$emit("closeShare","closeShare"))},fail:function(t){this.$emit("closeShare","closeShare"),console.log("合成失败：",t)},emitChange:function(t){this.$emit("shareUrl",this.pathSwiper[t.detail.current])},emitChangeTwo:function(t){this.saveUrls=this.pathSwiperTwo[t.detail.current]},success:function(e){if(this.shareObj.bmtzShare||this.shareObj.ztShare||this.shareObj.ztShareUser)return this.pathBm=e.detail.path,this.$emit("shareUrl",this.pathBm),t.hideLoading(),this.shareObj.ztShareUser&&this.closeBox(99),!1;console.log("合成成功success1：",e),this.path=e.detail.path,this.shareObj.isFirstin&&(this.$emit("shareUrl",this.path),this.closeBox(99))},failTwo:function(t){this.$emit("closeShare","closeShare"),console.log("合成失败：",t)},successTwoSixz:function(t){console.log("合成成功success2666：",this.shareObj),this.pathTwoSixz=t.detail.path},successTwo:function(t){console.log("合成成功success2：",this.shareObj),this.pathTwo=t.detail.path},failThree:function(t){this.$emit("closeShare","closeShare"),console.log("合成失败：",t)},failFour:function(e){t.showToast({title:e.detail.error,icon:"none",duration:3e3}),console.log("合成失败：",e)},successThree:function(t){console.log("合成成功success...3：",t),this.pathThree=t.detail.path,this.$emit("shareUrl",this.pathThree)},successTest:function(t){var e=this;console.log("合成成功success...3：",t),this.path?this.pathSwiper=[this.path,t.detail.path]:setTimeout((function(i){e.pathSwiper=[e.path,t.detail.path]}),100),console.log("海报数组",this.pathSwiper)},successFour:function(t){console.log("合成成功444success...：",t),this.pathFour=t.detail.path,this.$emit("shareUrl",this.pathFour)},successFive:function(t){console.log("合成成功555success：",t),this.pathFive=t.detail.path,this.$emit("shareUrl",this.pathFive)},successSix:function(t){console.log("合成成功666success：",t),this.pathSix=t.detail.path},successEight:function(t){console.log("合成成功888success：",t),this.pathEight=t.detail.path},successNine:function(t){console.log("合成成功9999success：",t),this.pathNine=t.detail.path},successSeven:function(t){console.log("合成成功777success：",t),this.pathSeven=t.detail.path},sevenErr:function(t){console.log("合成成功失败777Err：",t),this.pathSeven=t.detail.path},openTwos:function(){t.showLoading({title:"合成海报中..."}),this.allImgOk&&(this.allImgOk=!1),console.log("海报开始合成",this.allImgOk),this.appletQrImgUrl()},openAccs:function(){t.navigateTo({url:"/pages/pageRelay/accCourse?"+this.shareObj.shareScene})},openCopylink:function(){},openFour:function(){t.showLoading({title:"合成海报中..."}),this.creatFour()},creatFour:function(){console.log("开始喝茶111");var e=this.dataFour;e.views[0].url=this.appletQrImgs,e.views[1].url=this.shareObj.headImg,this.isReadyThree=!1,this.pathThree="",this.dataFour=e,this.isReadyFour=!0,console.log("开始喝茶",this.dataFour),setTimeout((function(e){t.hideLoading()}),500)},creatNines:function(){var e=this,i={page:"pages/pageRelay/userCancal",width:600,scene:this.shareObj.shareScene};this.$server.appletQrImgUrl(i).then((function(i){if(0==i.code){var r={};1===e.shareObj.ztShare?((r=e.dataNines).views[1].url=i.data.imgUrl,r.views[2].url=e.shareObj.headImg,r.views[3].text=e.shareObj.nickName):((r=e.dataNinesZt).views[1].url=i.data.imgUrl,r.views[2].url=e.shareObj.headImg,r.views[3].text=e.shareObj.nickName,r.views[4].text=e.shareObj.zitiName),e.dataNinesZt=r,e.isReadyNine=!0,console.log("开始核销码"),setTimeout((function(e){t.hideLoading()}),500)}else setTimeout((function(e){t.hideLoading(),t.showToast({title:i.message,icon:"none"})}),500)}))},creatTwens:function(){var e=this;t.showLoading({});var i={page:"pages/subPage/myHome",width:600,scene:this.shareObj.shareScene};this.$server.appletQrImgUrl(i).then((function(i){if(0==i.code){var r={};(r=JSON.parse(JSON.stringify(e.dataTwens))).views[2].url=i.data.imgUrl,r.views[1].url=e.shareObj.headImg,r.views[3].text=e.shareObj.nickName,e.dataNinesZt=r,e.pathBm="",e.isReady=!1,e.isReadyNine=!0,console.log("开始核销码",e.dataNinesZt),setTimeout((function(e){t.hideLoading()}),500)}else setTimeout((function(e){t.hideLoading(),t.showToast({title:i.message,icon:"none"})}),500)}))},creatTwoSixs:function(t){var e=JSON.parse(JSON.stringify(this.dataTwoSixz));e.views[0].url=this.shareObj.headImg,e.views[7].url=t.data.imgUrl,this.appletQrImgs=t.data.imgUrl,e.views[8].text=this.shareObj.nickName,e.views[9].text=this.shareObj.createTime,e.views[10].text=this.shareObj.title,e.views[11].text=this.shareObj.maxSellPriceShow,e.views[1].url=this.shareObj.imgUrls[0],e.views[2].url=this.shareObj.imgUrls[1],e.views[3].url=this.shareObj.imgUrls[2],e.views[4].url=this.shareObj.imgUrls[3],e.views[5].url=this.shareObj.imgUrls[4],e.views[6].url=this.shareObj.imgUrls[5],e.views[14].url=this.shareObj.headImg,2==this.shareObj.freezeFlag&&("android"===wx.getSystemInfoSync().platform?e.views[10].text="                     "+this.shareObj.title:e.views[10].text="                    "+this.shareObj.title,e.views.push({type:"image",url:"https://qiniuimg.kfmanager.com/qunjl/showrel/shouhouwuymn.png",css:{top:"102rpx",left:"24rpx",width:"134rpx",height:"37rpx",mode:"aspectFill"}})),this.dataTwoSixz=e,this.isReadyTwoSixz=!0},appletQrImgUrl:function(){var e=this,i=(t.getStorageSync("userInfo"),{page:"pages/subPage/showRel",width:600,scene:this.shareObj.shareScene});this.$server.appletQrImgUrl(i).then((function(i){if(0==i.code){var r={};if(e.shareObj.shareBtn.includes("帮卖")){(r=JSON.parse(JSON.stringify(e.dataTwoBm))).views[0].url=e.shareObj.headImg,r.views[2].url=i.data.imgUrl,e.appletQrImgs=i.data.imgUrl,r.views[3].text=e.shareObj.nickName,r.views[4].url=e.shareObj.headImg,r.views[5].text=e.shareObj.title;var s=e.shareObj.bmMoney;s=s.replace(".00",""),r.views[6].text=s,e.shareObj.imgUrls.length?r.views[1].url=e.shareObj.imgUrls[0]:r.views[1].url="https://qiniuimg.kfmanager.com/qunjl/showrel/aaasharebmt.png",e.isReady=!1,e.path=""}else e.shareObj.imgUrls.length&&e.shareObj.imgUrls.length>5&&e.creatTwoSixs(i),(r=JSON.parse(JSON.stringify(e.dataTwo))).views[0].url=e.shareObj.headImg,r.views[2].url=i.data.imgUrl,e.appletQrImgs=i.data.imgUrl,r.views[3].text=e.shareObj.nickName,r.views[4].text=e.shareObj.createTime,r.views[5].text=e.shareObj.title,r.views[6].text=e.shareObj.maxSellPriceShow,r.views[9].url=e.shareObj.headImg,2==e.shareObj.freezeFlag&&("android"===wx.getSystemInfoSync().platform?r.views[5].text="                     "+e.shareObj.title:r.views[5].text="                    "+e.shareObj.title,r.views.push({type:"image",url:"https://qiniuimg.kfmanager.com/qunjl/showrel/shouhouwuymn.png",css:{top:"102rpx",left:"24rpx",width:"134rpx",height:"37rpx",mode:"aspectFill"}})),e.isReady=!1,e.path="",e.shareObj.imgUrls.length?r.views[1].url=e.shareObj.imgUrls[0]:r.views[1].url="https://qiniuimg.kfmanager.com/qunjl/showrel/aaasharet.png";e.dataTwo=r,e.isReadyTwo=!0}else setTimeout((function(e){t.hideLoading(),t.showToast({title:i.message,icon:"none"})}),500)}))},appletQrThree:function(){var e=this,i=(t.getStorageSync("userInfo"),{page:"pages/subPage/myHome",width:600,scene:this.shareObj.shareScene});this.$server.appletQrImgUrl(i).then((function(i){if(0==i.code){var r=e.dataThree;r.views[0].url=e.shareObj.headImg,r.views[2].url=i.data.imgUrl,r.views[3].url=e.shareObj.headImg,r.views[4].text=e.shareObj.nickName,e.shareObj.introduction.length>19&&(e.shareObj.introduction=e.shareObj.introduction.slice(0,18)+"..."),e.appletQrImgs=i.data.imgUrl,e.shareObj.introduction&&(r.views[5].text=e.shareObj.introduction),r.views[7].text=e.shareObj.memberCount+"",r.views[9].text=e.shareObj.solitaireCount+"",r.views[10].text=e.shareObj.solitaireCountShow,console.log("父组endParam==",r),e.dataThree=r,e.isReadyThree=!0}else setTimeout((function(e){t.hideLoading(),t.showToast({title:i.message,icon:"none"})}),500)}))},addIncActShare:function(){var t={activityId:this.shareObj.activityId};this.$server.incActShare(t).then((function(t){t.code}))},saveImg:function(t){var e=this,i="";2==t?i=e.saveUrls?e.saveUrls:e.pathTwo:3==t&&(i=e.pathNine),wx.saveImageToPhotosAlbum({filePath:i,success:function(t){wx.showToast({title:"保存成功",icon:"success",duration:1500}),e.$emit("closeShare","closeShare")},fail:function(t){"saveImageToPhotosAlbum:fail auth deny"==t.errMsg?wx.showModal({title:"获取权限失败",content:"是否打开设置页，允许小程序保存图片到您的相册",success:function(t){t.confirm?(console.log("用户点击确定"),wx.openSetting({success:function(t){console.log(t.authSetting),wx.showToast({title:"请再次点击保存",icon:"none",duration:2e3})}})):t.cancel&&(console.log("用户点击取消"),wx.showToast({title:"授权失败",icon:"none",duration:2e3}))}}):(console.log("ios失败===",t),wx.showModal({title:"获取权限失败",content:"是否打开设置页，允许小程序保存图片到您的相册",success:function(t){t.confirm?(console.log("用户点击确定"),wx.openSetting({success:function(t){wx.showToast({title:"授权成功，请再次点击保存",icon:"none",duration:2e3})}})):t.cancel&&console.log("用户点击取消")}}),wx.showToast({title:"保存失败，请再次点击保存",icon:"none",duration:2e3}))}})},saveImgThree:function(t){var e,i=this;e=1==t?this.pathThree:this.pathFour,wx.saveImageToPhotosAlbum({filePath:e,success:function(t){wx.showToast({title:"保存成功",icon:"success",duration:1500}),i.$emit("closeShare","closeShare")},fail:function(t){"saveImageToPhotosAlbum:fail auth deny"==t.errMsg?wx.showModal({title:"获取权限失败",content:"是否打开设置页，允许小程序保存图片到您的相册",success:function(t){t.confirm?(console.log("用户点击确定"),wx.openSetting({success:function(t){console.log(t.authSetting),wx.showToast({title:"请再次点击保存",icon:"none",duration:2e3})}})):t.cancel&&(console.log("用户点击取消"),wx.showToast({title:"授权失败",icon:"none",duration:2e3}))}}):(console.log("ios失败===",t),wx.showModal({title:"获取权限失败",content:"是否打开设置页，允许小程序保存图片到您的相册",success:function(t){t.confirm?(console.log("用户点击确定"),wx.openSetting({success:function(t){wx.showToast({title:"授权成功，请再次点击保存",icon:"none",duration:2e3})}})):t.cancel&&console.log("用户点击取消")}}),wx.showToast({title:"保存失败，请再次点击保存",icon:"none",duration:2e3}))}})}}};e.default=s}).call(this,i(1).default)},880:function(t,e,i){"use strict";i.r(e);var r=i(881),s=i.n(r);for(var o in r)"default"!==o&&function(t){i.d(e,t,(function(){return r[t]}))}(o);e.default=s.a},881:function(t,e,i){}}]),(global.webpackJsonp=global.webpackJsonp||[]).push(["components/dc-hiro-painter/dc-hiro-painter-create-component",{"components/dc-hiro-painter/dc-hiro-painter-create-component":function(t,e,i){i("1").createComponent(i(875))}},[["components/dc-hiro-painter/dc-hiro-painter-create-component"]]]);
},{isPage:false,isComponent:true,currentFile:'components/dc-hiro-painter/dc-hiro-painter.js'});require("components/dc-hiro-painter/dc-hiro-painter.js");