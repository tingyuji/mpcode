$gwx_XC_2=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_2 || [];
function gz$gwx_XC_2_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_2_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_2_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_2_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'data-v-6f011840'])
Z([3,'__l'])
Z([3,'__e'])
Z(z[2])
Z([3,'14'])
Z(z[0])
Z([[4],[[5],[[5],[[4],[[5],[[5],[1,'^close']],[[4],[[5],[[4],[[5],[1,'cancelUser']]]]]]]],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'show']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z([3,'bottom'])
Z([[7],[3,'show']])
Z([3,'476f8926-1'])
Z([[4],[[5],[1,'default']]])
Z([3,'box_log data-v-6f011840'])
Z([3,'mini_log data-v-6f011840'])
Z([3,'scaleToFill'])
Z([3,'http://qiniuimg.kfmanager.com/qunjl/logo/qyxlogons.jpg'])
Z([3,'wel_co data-v-6f011840'])
Z([3,'欢迎登录群优选|接龙团购~'])
Z([3,'wel_cois data-v-6f011840'])
Z([3,'建议改成您的微信图像和昵称，以获得更好的使用体验'])
Z([[2,'!'],[[7],[3,'showAvatar']]])
Z([3,'info_mr data-v-6f011840'])
Z([3,'avatar_mr data-v-6f011840'])
Z([3,'mini_avater data-v-6f011840'])
Z(z[13])
Z([[6],[[7],[3,'userInData']],[3,'headImage']])
Z([3,'name_mr data-v-6f011840'])
Z([a,[[6],[[7],[3,'userInData']],[3,'nickName']]])
Z(z[2])
Z([3,'wechat_in data-v-6f011840'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'getUserProfile']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z(z[22])
Z(z[13])
Z([3,'../../static/static/assets/001.png'])
Z(z[19])
Z(z[2])
Z([3,'wech_at dfcbg fl data-v-6f011840'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'setNameImage']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z(z[1])
Z(z[0])
Z([3,'#fff'])
Z([3,'weixin-fill'])
Z([3,'48'])
Z([[2,'+'],[[2,'+'],[1,'476f8926-2'],[1,',']],[1,'476f8926-1']])
Z(z[0])
Z([3,'一键登录'])
Z([[7],[3,'showAvatar']])
Z([3,'wel_avatar data-v-6f011840'])
Z(z[2])
Z([3,'avatar-wrapper data-v-6f011840'])
Z([[4],[[5],[[4],[[5],[[5],[1,'chooseavatar']],[[4],[[5],[[4],[[5],[[5],[1,'onChooseAvatar']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([3,'chooseAvatar'])
Z([3,'avatar data-v-6f011840'])
Z([3,'aspectFill'])
Z([[7],[3,'avatarUrl']])
Z(z[2])
Z([3,'weui-input data-v-6f011840'])
Z([[4],[[5],[[4],[[5],[[5],[1,'change']],[[4],[[5],[[4],[[5],[[5],[1,'getNickName']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([3,'请输入昵称'])
Z([3,'nickname'])
Z(z[2])
Z(z[35])
Z(z[36])
Z(z[0])
Z([3,'微信授权登录'])
Z(z[2])
Z([3,'zan_bu data-v-6f011840'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'cancelUser']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([3,'暂不登录'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_2_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_2_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_2=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_2=true;
var x=['./components/login-pop/login-pop.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_2_1()
var eBF=_n('view')
_rz(z,eBF,'class',0,e,s,gg)
var bCF=_mz(z,'u-popup',['bind:__l',1,'bind:close',1,'bind:input',2,'borderRadius',3,'class',4,'data-event-opts',5,'mode',6,'value',7,'vueId',8,'vueSlots',9],[],e,s,gg)
var oDF=_n('view')
_rz(z,oDF,'class',11,e,s,gg)
var cHF=_mz(z,'image',['class',12,'mode',1,'src',2],[],e,s,gg)
_(oDF,cHF)
var hIF=_n('view')
_rz(z,hIF,'class',15,e,s,gg)
var oJF=_oz(z,16,e,s,gg)
_(hIF,oJF)
_(oDF,hIF)
var cKF=_n('view')
_rz(z,cKF,'class',17,e,s,gg)
var oLF=_oz(z,18,e,s,gg)
_(cKF,oLF)
_(oDF,cKF)
var xEF=_v()
_(oDF,xEF)
if(_oz(z,19,e,s,gg)){xEF.wxVkey=1
var lMF=_n('view')
_rz(z,lMF,'class',20,e,s,gg)
var aNF=_n('view')
_rz(z,aNF,'class',21,e,s,gg)
var tOF=_mz(z,'image',['class',22,'mode',1,'src',2],[],e,s,gg)
_(aNF,tOF)
_(lMF,aNF)
var ePF=_n('view')
_rz(z,ePF,'class',25,e,s,gg)
var bQF=_oz(z,26,e,s,gg)
_(ePF,bQF)
_(lMF,ePF)
var oRF=_mz(z,'view',['bindtap',27,'class',1,'data-event-opts',2],[],e,s,gg)
var xSF=_mz(z,'image',['class',30,'mode',1,'src',2],[],e,s,gg)
_(oRF,xSF)
_(lMF,oRF)
_(xEF,lMF)
}
var oFF=_v()
_(oDF,oFF)
if(_oz(z,33,e,s,gg)){oFF.wxVkey=1
var oTF=_mz(z,'view',['bindtap',34,'class',1,'data-event-opts',2],[],e,s,gg)
var fUF=_mz(z,'u-icon',['bind:__l',37,'class',1,'color',2,'name',3,'size',4,'vueId',5],[],e,s,gg)
_(oTF,fUF)
var cVF=_n('text')
_rz(z,cVF,'class',43,e,s,gg)
var hWF=_oz(z,44,e,s,gg)
_(cVF,hWF)
_(oTF,cVF)
_(oFF,oTF)
}
var fGF=_v()
_(oDF,fGF)
if(_oz(z,45,e,s,gg)){fGF.wxVkey=1
var oXF=_n('view')
_rz(z,oXF,'class',46,e,s,gg)
var cYF=_mz(z,'button',['bindchooseavatar',47,'class',1,'data-event-opts',2,'openType',3],[],e,s,gg)
var oZF=_mz(z,'image',['class',51,'mode',1,'src',2],[],e,s,gg)
_(cYF,oZF)
_(oXF,cYF)
var l1F=_mz(z,'input',['bindchange',54,'class',1,'data-event-opts',2,'placeholder',3,'type',4],[],e,s,gg)
_(oXF,l1F)
var a2F=_mz(z,'view',['bindtap',59,'class',1,'data-event-opts',2],[],e,s,gg)
var t3F=_n('text')
_rz(z,t3F,'class',62,e,s,gg)
var e4F=_oz(z,63,e,s,gg)
_(t3F,e4F)
_(a2F,t3F)
_(oXF,a2F)
_(fGF,oXF)
}
var b5F=_mz(z,'view',['bindtap',64,'class',1,'data-event-opts',2],[],e,s,gg)
var o6F=_oz(z,67,e,s,gg)
_(b5F,o6F)
_(oDF,b5F)
xEF.wxXCkey=1
oFF.wxXCkey=1
oFF.wxXCkey=3
fGF.wxXCkey=1
_(bCF,oDF)
_(eBF,bCF)
_(r,eBF)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_2";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_2();
	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/login-pop/login-pop.wxml'] = [$gwx_XC_2, './components/login-pop/login-pop.wxml'];else __wxAppCode__['components/login-pop/login-pop.wxml'] = $gwx_XC_2( './components/login-pop/login-pop.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['components/login-pop/login-pop.wxss'] = setCssToHead([".",[1],"wel_avatar.",[1],"data-v-6f011840{margin:",[0,30]," 0;width:100%}\n.",[1],"wel_avatar .",[1],"avatar-wrapper.",[1],"data-v-6f011840{border-radius:",[0,8],";height:",[0,120],";margin:",[0,15]," auto;padding:0!important;width:",[0,120],"}\n.",[1],"wel_avatar .",[1],"avatar-wrapper .",[1],"avatar.",[1],"data-v-6f011840{height:100%;width:100%}\n.",[1],"wel_avatar .",[1],"weui-input.",[1],"data-v-6f011840{margin:",[0,15]," auto;text-align:center;width:100%}\n.",[1],"box_log.",[1],"data-v-6f011840{box-sizing:border-box;padding:",[0,30],"}\n.",[1],"wel_co.",[1],"data-v-6f011840{color:#000;font-size:",[0,44],";font-weight:700;margin-top:",[0,30],";text-align:center;width:",[0,690],"}\n.",[1],"wel_cois.",[1],"data-v-6f011840{color:#777;font-size:",[0,28],";margin-top:",[0,16],";text-align:center;width:",[0,690],"}\n.",[1],"mini_log.",[1],"data-v-6f011840{border-radius:",[0,12],";display:block;height:",[0,140],";margin:0 auto;width:",[0,140],"}\n.",[1],"zan_bu.",[1],"data-v-6f011840{background:#999;font-size:",[0,28],";line-height:",[0,90],";margin-top:",[0,30],";text-align:center}\n.",[1],"wech_at.",[1],"data-v-6f011840,.",[1],"zan_bu.",[1],"data-v-6f011840{border-radius:",[0,45],";color:#fff;height:",[0,90],";width:",[0,690],"}\n.",[1],"wech_at.",[1],"data-v-6f011840{font-size:",[0,32],";-webkit-justify-content:center;justify-content:center;margin-top:",[0,140],"}\n.",[1],"wech_at wx-text.",[1],"data-v-6f011840{margin-left:",[0,12],"}\n.",[1],"info_mr.",[1],"data-v-6f011840{display:-webkit-flex;display:flex;height:",[0,120],";margin-top:",[0,60],";width:100%}\n.",[1],"info_mr .",[1],"avatar_mr.",[1],"data-v-6f011840{border-radius:50%;height:",[0,120],";overflow:hidden;width:",[0,120],"}\n.",[1],"info_mr .",[1],"avatar_mr .",[1],"mini_avater.",[1],"data-v-6f011840{height:100%;width:100%}\n.",[1],"info_mr .",[1],"name_mr.",[1],"data-v-6f011840{color:#000;font-size:",[0,40],";line-height:",[0,120],";margin-left:",[0,30],"}\n.",[1],"info_mr .",[1],"wechat_in.",[1],"data-v-6f011840{height:",[0,40],";margin-left:",[0,70],";margin-top:",[0,40],";width:",[0,40],"}\n.",[1],"info_mr .",[1],"wechat_in \x3e wx-image.",[1],"data-v-6f011840{height:100%;width:100%}\n",],"Some selectors are not allowed in component wxss, including tag name selectors, ID selectors, and attribute selectors.(./components/login-pop/login-pop.wxss:1:1585)",{path:"./components/login-pop/login-pop.wxss"});
}