$gwx_XC_2=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_2 || [];
function gz$gwx_XC_2_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_2_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_2_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_2_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'__l'])
Z([3,'__e'])
Z(z[1])
Z([3,'14'])
Z([3,'data-v-6f011840'])
Z([[4],[[5],[[5],[[4],[[5],[[5],[1,'^close']],[[4],[[5],[[4],[[5],[1,'cancelUser']]]]]]]],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'show']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z([3,'bottom'])
Z([[7],[3,'show']])
Z([3,'476f8926-1'])
Z([[4],[[5],[1,'default']]])
Z([3,'box_log data-v-6f011840'])
Z([[2,'!'],[[7],[3,'showAvatar']]])
Z(z[11])
Z(z[1])
Z([3,'wech_at dfcbg fl data-v-6f011840'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'setNameImage']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z(z[0])
Z(z[4])
Z([3,'#fff'])
Z([3,'weixin-fill'])
Z([3,'48'])
Z([[2,'+'],[[2,'+'],[1,'476f8926-2'],[1,',']],[1,'476f8926-1']])
Z([[7],[3,'showAvatar']])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_2_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_2_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_2=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_2=true;
var x=['./components/login-pop/login-pop.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_2_1()
var eFB=_mz(z,'u-popup',['bind:__l',0,'bind:close',1,'bind:input',1,'borderRadius',2,'class',3,'data-event-opts',4,'mode',5,'value',6,'vueId',7,'vueSlots',8],[],e,s,gg)
var bGB=_n('view')
_rz(z,bGB,'class',10,e,s,gg)
var oHB=_v()
_(bGB,oHB)
if(_oz(z,11,e,s,gg)){oHB.wxVkey=1
}
var xIB=_v()
_(bGB,xIB)
if(_oz(z,12,e,s,gg)){xIB.wxVkey=1
var fKB=_mz(z,'view',['bindtap',13,'class',1,'data-event-opts',2],[],e,s,gg)
var cLB=_mz(z,'u-icon',['bind:__l',16,'class',1,'color',2,'name',3,'size',4,'vueId',5],[],e,s,gg)
_(fKB,cLB)
_(xIB,fKB)
}
var oJB=_v()
_(bGB,oJB)
if(_oz(z,22,e,s,gg)){oJB.wxVkey=1
}
oHB.wxXCkey=1
xIB.wxXCkey=1
xIB.wxXCkey=3
oJB.wxXCkey=1
_(eFB,bGB)
_(r,eFB)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_2";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_2();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/login-pop/login-pop.wxml'] = [$gwx_XC_2, './components/login-pop/login-pop.wxml'];else __wxAppCode__['components/login-pop/login-pop.wxml'] = $gwx_XC_2( './components/login-pop/login-pop.wxml' );
	;__wxRoute = "components/login-pop/login-pop";__wxRouteBegin = true;__wxAppCurrentFile__="components/login-pop/login-pop.js";define("components/login-pop/login-pop.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
(global.webpackJsonp=global.webpackJsonp||[]).push([["components/login-pop/login-pop"],{882:function(e,n,t){"use strict";t.r(n);var o=t(883),a=t(885);for(var i in a)"default"!==i&&function(e){t.d(n,e,(function(){return a[e]}))}(i);t(887);var r=t(17),s=Object(r.default)(a.default,o.render,o.staticRenderFns,!1,null,"6f011840",null,!1,o.components,void 0);s.options.__file="components/login-pop/login-pop.vue",n.default=s.exports},883:function(e,n,t){"use strict";t.r(n);var o=t(884);t.d(n,"render",(function(){return o.render})),t.d(n,"staticRenderFns",(function(){return o.staticRenderFns})),t.d(n,"recyclableRender",(function(){return o.recyclableRender})),t.d(n,"components",(function(){return o.components}))},884:function(e,n,t){"use strict";var o;t.r(n),t.d(n,"render",(function(){return a})),t.d(n,"staticRenderFns",(function(){return r})),t.d(n,"recyclableRender",(function(){return i})),t.d(n,"components",(function(){return o}));try{o={uPopup:function(){return t.e("uview-ui/components/u-popup/u-popup").then(t.bind(null,939))},uIcon:function(){return t.e("uview-ui/components/u-icon/u-icon").then(t.bind(null,854))}}}catch(e){if(-1===e.message.indexOf("Cannot find module")||-1===e.message.indexOf(".vue"))throw e;console.error(e.message),console.error("1. 排查组件名称拼写是否正确"),console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"),console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件")}var a=function(){this.$createElement,this._self._c},i=!1,r=[];a._withStripped=!0},885:function(e,n,t){"use strict";t.r(n);var o=t(886),a=t.n(o);for(var i in o)"default"!==i&&function(e){t.d(n,e,(function(){return o[e]}))}(i);n.default=a.a},886:function(e,n,t){"use strict";(function(e){Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var t={data:function(){return{show:!0,avatarUrl:"",showAvatar:!1,nickname:"",userInData:{nickName:"",headImage:""},qiniuInfo:{}}},created:function(){this.getQiniuToken(),this.getMrInfo()},methods:{getMrInfo:function(){var n=this;this.$server.defaultNickImg({}).then((function(t){0==t.code?(n.userInData.nickName=t.data.defaultName,n.userInData.headImage=t.data.defaultImg):e.showToast({title:t.message,icon:"none"})})),console.log("mr_nickName",this.userInData)},getNickName:function(e){this.userInData.nickName=e.detail.value},onChooseAvatar:function(n){var t=this,o=n.detail.avatarUrl;this.setData({avatarUrl:o});var a=this;e.showLoading({title:"上传中"});for(var i=n.detail.avatarUrl,r="."+i.split(".")[1],s="",u=0;u<18;u++)s+="abcdefghijkmnpqrstvwxyz1234567890".charAt(Math.floor(32*Math.random()));s=a.qiniuInfo.imgFolderPath+s+r,e.uploadFile({url:"https://up-z2.qiniup.com",filePath:i,name:"file",formData:{key:s,token:a.qiniuInfo.uploadToken},success:function(n){var o=a.qiniuInfo.urlPrefix+s;a.userInData.headImage=o,console.log("userInData",t.userInData),e.hideLoading()}})},getUserProfile:function(e){this.showAvatar=!0,this.userInData.headImage="",this.userInData.nickName=""},getQiniuToken:function(){var n=this,t=this;if(!(e.getStorageSync("userInfo")||{}).userId)return setTimeout((function(){t.getQiniuToken()}),1500),!1;this.$server.qiniuToken({}).then((function(t){"0"==t.code?(n.qiniuInfo=t.data,setTimeout((function(){e.hideLoading()}),1e3),e.setStorageSync("qiniuInfo",t.data)):(e.hideLoading(),setTimeout((function(){e.showToast({title:t.message,icon:none})}),1e3),console.log("qiniu==",t))}))},setNameImage:function(){var n=this,t=this.userInData;return t.nickName?t.headImage?void this.$server.setNameImage({nickName:t.nickName,headImage:t.headImage}).then((function(t){if(e.hideLoading(),t.data.nickName){var o=e.getStorageSync("userInfo");o.nickName=t.data.nickName,o.headImg=t.data.headImg,e.setStorageSync("userInfo",o),n.$emit("closeUser",o)}else e.showToast({title:t.message,icon:"none"})})):(e.showToast({title:"请先选择微信头像",icon:"none"}),!1):(e.showToast({title:"请输入微信昵称",icon:"none"}),!1)},cancelUser:function(){this.showAvatar=!1,this.$emit("closeUser",1)}}};n.default=t}).call(this,t(1).default)},887:function(e,n,t){"use strict";t.r(n);var o=t(888),a=t.n(o);for(var i in o)"default"!==i&&function(e){t.d(n,e,(function(){return o[e]}))}(i);n.default=a.a},888:function(e,n,t){}}]),(global.webpackJsonp=global.webpackJsonp||[]).push(["components/login-pop/login-pop-create-component",{"components/login-pop/login-pop-create-component":function(e,n,t){t("1").createComponent(t(882))}},[["components/login-pop/login-pop-create-component"]]]);
},{isPage:false,isComponent:true,currentFile:'components/login-pop/login-pop.js'});require("components/login-pop/login-pop.js");