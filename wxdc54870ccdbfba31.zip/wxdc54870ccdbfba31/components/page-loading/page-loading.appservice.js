$gwx_XC_4=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_4 || [];
function gz$gwx_XC_4_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_4_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_4_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_4_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_4_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_4_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_4=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_4=true;
var x=['./components/page-loading/page-loading.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_4_1()
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_4";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_4();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/page-loading/page-loading.wxml'] = [$gwx_XC_4, './components/page-loading/page-loading.wxml'];else __wxAppCode__['components/page-loading/page-loading.wxml'] = $gwx_XC_4( './components/page-loading/page-loading.wxml' );
	;__wxRoute = "components/page-loading/page-loading";__wxRouteBegin = true;__wxAppCurrentFile__="components/page-loading/page-loading.js";define("components/page-loading/page-loading.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
(global.webpackJsonp=global.webpackJsonp||[]).push([["components/page-loading/page-loading"],{1090:function(e,n,t){"use strict";t.r(n);var o=t(1091),r=t(1093);for(var c in r)"default"!==c&&function(e){t.d(n,e,(function(){return r[e]}))}(c);t(1095);var a=t(17),i=Object(a.default)(r.default,o.render,o.staticRenderFns,!1,null,"c49b4b78",null,!1,o.components,void 0);i.options.__file="components/page-loading/page-loading.vue",n.default=i.exports},1091:function(e,n,t){"use strict";t.r(n);var o=t(1092);t.d(n,"render",(function(){return o.render})),t.d(n,"staticRenderFns",(function(){return o.staticRenderFns})),t.d(n,"recyclableRender",(function(){return o.recyclableRender})),t.d(n,"components",(function(){return o.components}))},1092:function(e,n,t){"use strict";t.r(n),t.d(n,"render",(function(){return o})),t.d(n,"staticRenderFns",(function(){return c})),t.d(n,"recyclableRender",(function(){return r})),t.d(n,"components",(function(){}));var o=function(){this.$createElement,this._self._c},r=!1,c=[];o._withStripped=!0},1093:function(e,n,t){"use strict";t.r(n);var o=t(1094),r=t.n(o);for(var c in o)"default"!==c&&function(e){t.d(n,e,(function(){return o[e]}))}(c);n.default=r.a},1094:function(e,n,t){"use strict";(function(e){Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var t={data:function(){return{show:!0}},created:function(){},methods:{getUserProfile:function(e){var n=this;wx.getUserProfile({desc:"用于完善会员资料",success:function(e){n.perfectBaseInfo(e.encryptedData,e.iv),console.log("getUserProfile=",e)},fail:function(e){}})},perfectBaseInfo:function(n,t){var o=this;this.$server.perfectBaseInfo({encryptedData:n,iv:t}).then((function(n){if(n.nickName){var t=e.getStorageSync("userInfo");t.nickName=n.nickName,t.headImg=n.headImg,e.setStorageSync("userInfo",t),o.$emit("closeUser",n)}else e.showToast({title:n.message,icon:"none"})}))},cancelUser:function(){this.$emit("closeUser",1)}}};n.default=t}).call(this,t(1).default)},1095:function(e,n,t){"use strict";t.r(n);var o=t(1096),r=t.n(o);for(var c in o)"default"!==c&&function(e){t.d(n,e,(function(){return o[e]}))}(c);n.default=r.a},1096:function(e,n,t){}}]),(global.webpackJsonp=global.webpackJsonp||[]).push(["components/page-loading/page-loading-create-component",{"components/page-loading/page-loading-create-component":function(e,n,t){t("1").createComponent(t(1090))}},[["components/page-loading/page-loading-create-component"]]]);
},{isPage:false,isComponent:true,currentFile:'components/page-loading/page-loading.js'});require("components/page-loading/page-loading.js");