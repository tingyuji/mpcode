$gwx_XC_3=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_3 || [];
function gz$gwx_XC_3_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_3_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_3_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_3_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_3_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_3_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_3=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_3=true;
var x=['./components/open-keyboard/open-keyboard.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_3_1()
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_3";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_3();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/open-keyboard/open-keyboard.wxml'] = [$gwx_XC_3, './components/open-keyboard/open-keyboard.wxml'];else __wxAppCode__['components/open-keyboard/open-keyboard.wxml'] = $gwx_XC_3( './components/open-keyboard/open-keyboard.wxml' );
	;__wxRoute = "components/open-keyboard/open-keyboard";__wxRouteBegin = true;__wxAppCurrentFile__="components/open-keyboard/open-keyboard.js";define("components/open-keyboard/open-keyboard.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
(global.webpackJsonp=global.webpackJsonp||[]).push([["components/open-keyboard/open-keyboard"],{1048:function(e,n,t){"use strict";t.r(n);var o=t(1049),r=t(1051);for(var i in r)"default"!==i&&function(e){t.d(n,e,(function(){return r[e]}))}(i);t(1053);var a=t(17),s=Object(a.default)(r.default,o.render,o.staticRenderFns,!1,null,"3841cf4c",null,!1,o.components,void 0);s.options.__file="components/open-keyboard/open-keyboard.vue",n.default=s.exports},1049:function(e,n,t){"use strict";t.r(n);var o=t(1050);t.d(n,"render",(function(){return o.render})),t.d(n,"staticRenderFns",(function(){return o.staticRenderFns})),t.d(n,"recyclableRender",(function(){return o.recyclableRender})),t.d(n,"components",(function(){return o.components}))},1050:function(e,n,t){"use strict";t.r(n),t.d(n,"render",(function(){return o})),t.d(n,"staticRenderFns",(function(){return i})),t.d(n,"recyclableRender",(function(){return r})),t.d(n,"components",(function(){}));var o=function(){this.$createElement,this._self._c},r=!1,i=[];o._withStripped=!0},1051:function(e,n,t){"use strict";t.r(n);var o=t(1052),r=t.n(o);for(var i in o)"default"!==i&&function(e){t.d(n,e,(function(){return o[e]}))}(i);n.default=r.a},1052:function(e,n,t){"use strict";(function(e){Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var t={name:"keyBoard",props:{title:{default:"确认",type:String},btnColor:{default:"#bee1c1"}},data:function(){return{btnColor:this.btnColor,money:"",Cdel:"",Time:""}},watch:{money:function(e){this.$emit("update:money",e)}},methods:{touchstart:function(){var e=this;this.Time=setInterval((function(){console.log("回车==",e.money),""==e.money&&clearInterval(),e.money=e.money.substring(0,e.money.length-1)}),200)},touchend:function(){clearInterval(this.Time)},_handleKeyPress:function(e){console.log("点击传e22",e),console.log("点击传e",e.target.dataset.num);var n=e.target.dataset.num;if(-1==n||!n)return!1;switch(String(n)){case".":this._handleDecimalPoint();break;case"D":this._handleDeleteKey();break;case"C":this._handleClearKey();break;case"S":this._handleConfirmKey();break;default:this._handleNumberKey(n)}},_handleDecimalPoint:function(){if(this.money.indexOf(".")>-1)return!1;this.money.length?this.money=this.money+".":this.money="0."},_handleDeleteKey:function(){var e=this.money;if(!e.length)return!1;this.money=e.substring(0,e.length-1),this.money>0?(console.log("btnColor"),"#1aa034"!=this.btnColor&&(this.btnColor="#1aa034"),console.log("btnColor",this.btnColor)):"#bee1c1"!=this.btnColor&&(this.btnColor="#bee1c1")},_handleClearKey:function(){this.money=""},_handleNumberKey:function(e){if(10!=this.money.length){var n=this.money;if(n.indexOf(".")>-1&&n.substring(n.indexOf(".")+1).length<2&&(this.money=n+e),!(n.indexOf(".")>-1))if(0==e&&0==n.length)this.money="0.";else{if(n.length&&0===Number(n.charAt(0)))return;this.money=n+e}this.money>0?(console.log("btnColor"),"#1aa034"!=this.btnColor&&(this.btnColor="#1aa034"),console.log("btnColor",this.btnColor)):"#bee1c1"!=this.btnColor&&(this.btnColor="#bee1c1")}},_handleConfirmKey:function(){var n=this.money;if(!n.length||0==n)return e.showToast({title:"请输入付款金额",icon:"none",duration:1e3}),!1;n.indexOf(".")>-1&&n.indexOf(".")==n.length-1&&(n=Number(n.substring(0,n.length-1)).toFixed(2)),n=Number(n).toFixed(2),this.$emit("confirmEvent",n)}}};n.default=t}).call(this,t(1).default)},1053:function(e,n,t){"use strict";t.r(n);var o=t(1054),r=t.n(o);for(var i in o)"default"!==i&&function(e){t.d(n,e,(function(){return o[e]}))}(i);n.default=r.a},1054:function(e,n,t){}}]),(global.webpackJsonp=global.webpackJsonp||[]).push(["components/open-keyboard/open-keyboard-create-component",{"components/open-keyboard/open-keyboard-create-component":function(e,n,t){t("1").createComponent(t(1048))}},[["components/open-keyboard/open-keyboard-create-component"]]]);
},{isPage:false,isComponent:true,currentFile:'components/open-keyboard/open-keyboard.js'});require("components/open-keyboard/open-keyboard.js");