$gwx_XC_17=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_17 || [];
function gz$gwx_XC_17_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_17_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_17_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_17_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'TUI-message-input-container'])
Z([3,'fl_sb'])
Z([3,'padding:0 30rpx;'])
Z([3,'TUI-commom-function'])
Z([3,'index'])
Z([3,'item'])
Z([[7],[3,'commonFunctionTe']])
Z(z[4])
Z([3,'__e'])
Z([3,'TUI-commom-function-item'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'handleCommonFunctions']],[[4],[[5],[1,'$0']]]],[[4],[[5],[[4],[[5],[[4],[[5],[[5],[[5],[[5],[1,'commonFunctionTe']],[1,'']],[[7],[3,'index']]],[1,'key']]]]]]]]]]]]]]])
Z([[7],[3,'item']])
Z([3,'fl'])
Z([3,'aspectFill'])
Z([[6],[[7],[3,'imageIcon']],[[7],[3,'index']]])
Z([3,'width:36rpx;height:36rpx;'])
Z([3,'tuipl8'])
Z([a,[[6],[[7],[3,'item']],[3,'name']]])
Z(z[8])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'toSetting']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([3,'__l'])
Z([3,'#07c160'])
Z([3,'setting'])
Z([3,'40'])
Z([3,'34cfdc56-1'])
Z([3,'TUI-message-input'])
Z(z[8])
Z([3,'TUI-icon'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'switchAudio']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([[2,'?:'],[[7],[3,'isAudio']],[1,'https://qiniuimg.kfmanager.com/svg/assets/keyboard.svg'],[1,'https://qiniuimg.kfmanager.com/svg/assets/audio.svg']])
Z([[2,'!'],[[7],[3,'isAudio']]])
Z([3,'TUI-message-input-main'])
Z([1,true])
Z(z[8])
Z(z[8])
Z(z[8])
Z([3,'TUI-message-input-area'])
Z([3,'20'])
Z([[4],[[5],[[5],[[5],[[4],[[5],[[5],[1,'input']],[[4],[[5],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'inputText']],[1,'$event']],[[4],[[5]]]]]]]],[[4],[[5],[[5],[1,'onInputValueChange']],[[4],[[5],[1,'$event']]]]]]]]]],[[4],[[5],[[5],[1,'focus']],[[4],[[5],[[4],[[5],[[5],[1,'inputBindFocus']],[[4],[[5],[1,'$event']]]]]]]]]],[[4],[[5],[[5],[1,'blur']],[[4],[[5],[[4],[[5],[[5],[1,'inputBindBlur']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([3,'140'])
Z([3,'说点什么呢~'])
Z([3,'input-placeholder'])
Z([3,'text'])
Z([[7],[3,'inputText']])
Z(z[8])
Z(z[8])
Z(z[8])
Z(z[31])
Z([[4],[[5],[[5],[[5],[[4],[[5],[[5],[1,'longpress']],[[4],[[5],[[4],[[5],[[5],[1,'handleLongPress']],[[4],[[5],[1,'$event']]]]]]]]]],[[4],[[5],[[5],[1,'touchmove']],[[4],[[5],[[4],[[5],[[5],[1,'handleTouchMove']],[[4],[[5],[1,'$event']]]]]]]]]],[[4],[[5],[[5],[1,'touchend']],[[4],[[5],[[4],[[5],[[5],[1,'handleTouchEnd']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([3,'display:flex;justify-content:center;font-size:32rpx;font-family:PingFangSC-Regular;'])
Z([a,[[7],[3,'text']]])
Z([3,'TUI-message-input-functions'])
Z([3,'none'])
Z(z[8])
Z(z[27])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'handleEmoji']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([3,'https://qiniuimg.kfmanager.com/svg/assets/face-emoji.svg'])
Z([[2,'!'],[[7],[3,'sendMessageBtn']]])
Z(z[8])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'handleExtensions']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z(z[27])
Z([3,'https://qiniuimg.kfmanager.com/svg/assets/more.svg'])
Z([3,'margin-left:6rpx;'])
Z(z[8])
Z([3,'TUI-sendMessage-btn'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'sendTextMessage']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([3,'发送'])
Z([[2,'==='],[[7],[3,'displayFlag']],[1,'emoji']])
Z([3,'TUI-Emoji-area'])
Z(z[20])
Z(z[8])
Z([[4],[[5],[[4],[[5],[[5],[1,'^enterEmoji']],[[4],[[5],[[4],[[5],[1,'appendMessage']]]]]]]]])
Z([3,'34cfdc56-2'])
Z([[2,'==='],[[7],[3,'displayFlag']],[1,'extension']])
Z([3,'TUI-Extensions'])
Z(z[8])
Z([3,'TUI-Extension-slot'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'handleSendPicture']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([3,'TUI-Extension-icon'])
Z([3,'https://qiniuimg.kfmanager.com/svg/assets/take-photo.svg'])
Z([3,'TUI-Extension-slot-name'])
Z([3,'拍摄照片'])
Z(z[8])
Z(z[76])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'handleSendImage']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z(z[78])
Z([3,'https://qiniuimg.kfmanager.com/svg/assets/send-img.svg'])
Z(z[80])
Z([3,'发送图片'])
Z(z[8])
Z(z[76])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'handleShootVideo']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z(z[78])
Z([3,'https://qiniuimg.kfmanager.com/svg/assets/take-video.svg'])
Z(z[80])
Z([3,'拍摄视频'])
Z(z[8])
Z(z[76])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'handleSendVideo']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z(z[78])
Z([3,'https://qiniuimg.kfmanager.com/svg/assets/send-video.svg'])
Z(z[80])
Z([3,'发送视频'])
Z(z[8])
Z(z[76])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'handleSendOrder']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z(z[78])
Z([3,'https://qiniuimg.kfmanager.com/svg/assets/send-order.svg'])
Z(z[80])
Z([3,'发送订单'])
Z(z[20])
Z(z[8])
Z(z[8])
Z([3,'tui-cards'])
Z([[7],[3,'commonWordsData']])
Z([[4],[[5],[[5],[[4],[[5],[[5],[1,'^sendMessage']],[[4],[[5],[[4],[[5],[1,'$handleSendTextMessage']]]]]]]],[[4],[[5],[[5],[1,'^close']],[[4],[[5],[[4],[[5],[1,'$handleCloseCards']]]]]]]]])
Z([[7],[3,'displayCommonWords']])
Z([3,'34cfdc56-3'])
Z(z[20])
Z(z[8])
Z(z[8])
Z(z[113])
Z([[4],[[5],[[5],[[4],[[5],[[5],[1,'^sendCustomMessage']],[[4],[[5],[[4],[[5],[1,'$handleSendCustomMessage']]]]]]]],[[4],[[5],[[5],[1,'^close']],[[4],[[5],[[4],[[5],[1,'$handleCloseCards']]]]]]]]])
Z([[7],[3,'displayOrderList']])
Z([[7],[3,'orderListData']])
Z([3,'34cfdc56-4'])
Z(z[20])
Z(z[8])
Z(z[8])
Z(z[113])
Z(z[122])
Z([[7],[3,'displayServiceEvaluation']])
Z([3,'34cfdc56-5'])
Z([[7],[3,'popupToggle']])
Z(z[8])
Z(z[8])
Z(z[8])
Z([3,'record-modal'])
Z(z[48])
Z([3,'wrapper'])
Z([3,'modal-loading'])
Z([3,'modal-title'])
Z([a,[[2,'+'],[[2,'+'],[1,''],[[7],[3,'title']]],[1,'']]])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_17_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_17_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_17=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_17=true;
var x=['./components/tui-chat/message-input/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_17_1()
var bCM=_n('view')
var xEM=_n('view')
_rz(z,xEM,'class',0,e,s,gg)
var cHM=_mz(z,'view',['class',1,'style',1],[],e,s,gg)
var hIM=_n('view')
_rz(z,hIM,'class',3,e,s,gg)
var oJM=_v()
_(hIM,oJM)
var cKM=function(lMM,oLM,aNM,gg){
var ePM=_mz(z,'view',['bindtap',8,'class',1,'data-event-opts',2,'data-function',3],[],lMM,oLM,gg)
var bQM=_n('view')
_rz(z,bQM,'class',12,lMM,oLM,gg)
var oRM=_mz(z,'image',['mode',13,'src',1,'style',2],[],lMM,oLM,gg)
_(bQM,oRM)
var xSM=_n('text')
_rz(z,xSM,'class',16,lMM,oLM,gg)
var oTM=_oz(z,17,lMM,oLM,gg)
_(xSM,oTM)
_(bQM,xSM)
_(ePM,bQM)
_(aNM,ePM)
return aNM
}
oJM.wxXCkey=2
_2z(z,6,cKM,e,s,gg,oJM,'item','index','index')
_(cHM,hIM)
var fUM=_mz(z,'view',['bindtap',18,'data-event-opts',1],[],e,s,gg)
var cVM=_mz(z,'u-icon',['bind:__l',20,'color',1,'name',2,'size',3,'vueId',4],[],e,s,gg)
_(fUM,cVM)
_(cHM,fUM)
_(xEM,cHM)
var hWM=_n('view')
_rz(z,hWM,'class',25,e,s,gg)
var cYM=_mz(z,'image',['bindtap',26,'class',1,'data-event-opts',2,'src',3],[],e,s,gg)
_(hWM,cYM)
var oXM=_v()
_(hWM,oXM)
if(_oz(z,30,e,s,gg)){oXM.wxVkey=1
var oZM=_n('view')
_rz(z,oZM,'class',31,e,s,gg)
var l1M=_mz(z,'input',['adjustPosition',32,'bindblur',1,'bindfocus',2,'bindinput',3,'class',4,'cursorSpacing',5,'data-event-opts',6,'maxlength',7,'placeholder',8,'placeholderClass',9,'type',10,'value',11],[],e,s,gg)
_(oZM,l1M)
_(oXM,oZM)
}
else{oXM.wxVkey=2
var a2M=_mz(z,'view',['bindlongpress',44,'bindtouchend',1,'bindtouchmove',2,'class',3,'data-event-opts',4,'style',5],[],e,s,gg)
var t3M=_n('text')
var e4M=_oz(z,50,e,s,gg)
_(t3M,e4M)
_(a2M,t3M)
_(oXM,a2M)
}
var b5M=_mz(z,'view',['class',51,'hoverClass',1],[],e,s,gg)
var x7M=_mz(z,'image',['bindtap',53,'class',1,'data-event-opts',2,'src',3],[],e,s,gg)
_(b5M,x7M)
var o6M=_v()
_(b5M,o6M)
if(_oz(z,57,e,s,gg)){o6M.wxVkey=1
var o8M=_mz(z,'view',['bindtap',58,'data-event-opts',1],[],e,s,gg)
var f9M=_mz(z,'image',['class',60,'src',1,'style',2],[],e,s,gg)
_(o8M,f9M)
_(o6M,o8M)
}
else{o6M.wxVkey=2
var c0M=_mz(z,'view',['bindtap',63,'class',1,'data-event-opts',2],[],e,s,gg)
var hAN=_oz(z,66,e,s,gg)
_(c0M,hAN)
_(o6M,c0M)
}
o6M.wxXCkey=1
_(hWM,b5M)
oXM.wxXCkey=1
_(xEM,hWM)
var oFM=_v()
_(xEM,oFM)
if(_oz(z,67,e,s,gg)){oFM.wxVkey=1
var oBN=_n('view')
_rz(z,oBN,'class',68,e,s,gg)
var cCN=_mz(z,'t-u-i-emoji',['bind:__l',69,'bind:enterEmoji',1,'data-event-opts',2,'vueId',3],[],e,s,gg)
_(oBN,cCN)
_(oFM,oBN)
}
var fGM=_v()
_(xEM,fGM)
if(_oz(z,73,e,s,gg)){fGM.wxVkey=1
var oDN=_n('view')
_rz(z,oDN,'class',74,e,s,gg)
var lEN=_mz(z,'view',['bindtap',75,'class',1,'data-event-opts',2],[],e,s,gg)
var aFN=_mz(z,'image',['class',78,'src',1],[],e,s,gg)
_(lEN,aFN)
var tGN=_n('view')
_rz(z,tGN,'class',80,e,s,gg)
var eHN=_oz(z,81,e,s,gg)
_(tGN,eHN)
_(lEN,tGN)
_(oDN,lEN)
var bIN=_mz(z,'view',['bindtap',82,'class',1,'data-event-opts',2],[],e,s,gg)
var oJN=_mz(z,'image',['class',85,'src',1],[],e,s,gg)
_(bIN,oJN)
var xKN=_n('view')
_rz(z,xKN,'class',87,e,s,gg)
var oLN=_oz(z,88,e,s,gg)
_(xKN,oLN)
_(bIN,xKN)
_(oDN,bIN)
var fMN=_mz(z,'view',['bindtap',89,'class',1,'data-event-opts',2],[],e,s,gg)
var cNN=_mz(z,'image',['class',92,'src',1],[],e,s,gg)
_(fMN,cNN)
var hON=_n('view')
_rz(z,hON,'class',94,e,s,gg)
var oPN=_oz(z,95,e,s,gg)
_(hON,oPN)
_(fMN,hON)
_(oDN,fMN)
var cQN=_mz(z,'view',['bindtap',96,'class',1,'data-event-opts',2],[],e,s,gg)
var oRN=_mz(z,'image',['class',99,'src',1],[],e,s,gg)
_(cQN,oRN)
var lSN=_n('view')
_rz(z,lSN,'class',101,e,s,gg)
var aTN=_oz(z,102,e,s,gg)
_(lSN,aTN)
_(cQN,lSN)
_(oDN,cQN)
var tUN=_mz(z,'view',['bindtap',103,'class',1,'data-event-opts',2],[],e,s,gg)
var eVN=_mz(z,'image',['class',106,'src',1],[],e,s,gg)
_(tUN,eVN)
var bWN=_n('view')
_rz(z,bWN,'class',108,e,s,gg)
var oXN=_oz(z,109,e,s,gg)
_(bWN,oXN)
_(tUN,bWN)
_(oDN,tUN)
_(fGM,oDN)
}
var xYN=_mz(z,'t-u-i-common-words',['bind:__l',110,'bind:close',1,'bind:sendMessage',2,'class',3,'commonWordsMatch',4,'data-event-opts',5,'display',6,'vueId',7],[],e,s,gg)
_(xEM,xYN)
var oZN=_mz(z,'t-u-i-order-list',['bind:__l',118,'bind:close',1,'bind:sendCustomMessage',2,'class',3,'data-event-opts',4,'display',5,'orderListData',6,'vueId',7],[],e,s,gg)
_(xEM,oZN)
var f1N=_mz(z,'t-u-i-service-evaluation',['bind:__l',126,'bind:close',1,'bind:sendCustomMessage',2,'class',3,'data-event-opts',4,'display',5,'vueId',6],[],e,s,gg)
_(xEM,f1N)
oFM.wxXCkey=1
oFM.wxXCkey=3
fGM.wxXCkey=1
_(bCM,xEM)
var oDM=_v()
_(bCM,oDM)
if(_oz(z,133,e,s,gg)){oDM.wxVkey=1
var c2N=_mz(z,'view',['bindlongpress',134,'bindtouchend',1,'bindtouchmove',2,'class',3,'data-event-opts',4],[],e,s,gg)
var h3N=_n('view')
_rz(z,h3N,'class',139,e,s,gg)
var o4N=_n('view')
_rz(z,o4N,'class',140,e,s,gg)
_(h3N,o4N)
_(c2N,h3N)
var c5N=_n('view')
_rz(z,c5N,'class',141,e,s,gg)
var o6N=_oz(z,142,e,s,gg)
_(c5N,o6N)
_(c2N,c5N)
_(oDM,c2N)
}
oDM.wxXCkey=1
_(r,bCM)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_17";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_17();
	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/tui-chat/message-input/index.wxml'] = [$gwx_XC_17, './components/tui-chat/message-input/index.wxml'];else __wxAppCode__['components/tui-chat/message-input/index.wxml'] = $gwx_XC_17( './components/tui-chat/message-input/index.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['components/tui-chat/message-input/index.wxss'] = setCssToHead([".",[1],"TUI-message-input-container{background-color:#f1f1f1;border-top:",[0,2]," solid #ddd;padding-bottom:",[0,50],"}\n.",[1],"TUI-message-input{padding-bottom:",[0,16],";width:100vw}\n.",[1],"TUI-commom-function,.",[1],"TUI-message-input{-webkit-align-items:center;align-items:center;background-color:#f1f1f1;display:-webkit-flex;display:flex}\n.",[1],"TUI-commom-function{-webkit-flex-wrap:nowrap;flex-wrap:nowrap;height:",[0,106],"}\n.",[1],"TUI-commom-function-item{-webkit-align-items:center;align-items:center;border:",[0,2]," solid #ccc;border-radius:",[0,30],";box-sizing:border-box;color:#999;display:-webkit-flex;display:flex;font-size:",[0,24],";height:",[0,60],";-webkit-justify-content:center;justify-content:center;margin-left:",[0,16],";padding:0 ",[0,16],"}\n.",[1],"TUI-message-input-functions,.",[1],"TUI-message-input-main{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex}\n.",[1],"TUI-message-input-main{background-color:#fff;border-radius:",[0,5],";-webkit-flex:1;flex:1;height:",[0,66],";margin:0 ",[0,10],";padding:0 ",[0,12],"}\n.",[1],"TUI-message-input-area{height:100%;width:100%}\n.",[1],"TUI-icon{height:",[0,50],";margin:0 ",[0,16],";width:",[0,50],"}\n.",[1],"TUI-Extensions{display:-webkit-flex;display:flex;-webkit-flex-wrap:wrap;flex-wrap:wrap;height:",[0,450],";margin-left:",[0,14],";margin-right:",[0,14],";width:100vw}\n.",[1],"TUI-Extension-slot{height:",[0,170],";margin-left:",[0,26],";margin-right:",[0,26],";margin-top:",[0,24],";width:",[0,128],"}\n.",[1],"TUI-Extension-icon{height:",[0,128],";width:",[0,128],"}\n.",[1],"TUI-sendMessage-btn{-webkit-align-items:center;align-items:center;background-color:#07c160;border-radius:",[0,8],";color:#fff;display:-webkit-flex;display:flex;height:",[0,50],";margin:0 ",[0,10],";padding:0 ",[0,10],"}\n.",[1],"TUI-Emoji-area{height:",[0,450],";width:100vw}\n.",[1],"TUI-Extension-slot-name{color:#333;font-size:",[0,24],";letter-spacing:0;line-height:",[0,34],";text-align:center}\n.",[1],"record-modal{background-color:#000;border-radius:",[0,24],";display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column;height:",[0,300],";left:20vw;opacity:.8;position:fixed;top:",[0,670],";width:60vw;z-index:9999}\n.",[1],"record-modal .",[1],"wrapper{box-sizing:border-box;display:-webkit-flex;display:flex;height:",[0,200],";padding:10vw}\n.",[1],"record-modal .",[1],"wrapper .",[1],"modal-loading{-webkit-animation:loading 2s cubic-bezier(.17,.37,.43,.67) infinite;animation:loading 2s cubic-bezier(.17,.37,.43,.67) infinite;background-color:#006fff;border-radius:",[0,4],";height:",[0,16],";opacity:1;width:",[0,40],"}\n.",[1],"modal-title{color:#fff;text-align:center}\n.",[1],"tuipl8{box-sizing:border-box;padding-left:",[0,8],"}\n@-webkit-keyframes loading{0%{-webkit-transform:translate(0,0);transform:translate(0,0)}\n50%{background-color:#f5634a;-webkit-transform:translate(30vw,0);transform:translate(30vw,0);width:40px}\n100%{-webkit-transform:translate(0,0);transform:translate(0,0)}\n}@keyframes loading{0%{-webkit-transform:translate(0,0);transform:translate(0,0)}\n50%{background-color:#f5634a;-webkit-transform:translate(30vw,0);transform:translate(30vw,0);width:40px}\n100%{-webkit-transform:translate(0,0);transform:translate(0,0)}\n}",],undefined,{path:"./components/tui-chat/message-input/index.wxss"});
}