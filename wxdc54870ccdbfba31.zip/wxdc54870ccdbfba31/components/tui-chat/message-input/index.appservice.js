$gwx_XC_17=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_17 || [];
function gz$gwx_XC_17_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_17_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_17_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_17_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'TUI-message-input-container'])
Z([3,'__e'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'toSetting']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([3,'__l'])
Z([3,'#07c160'])
Z([3,'setting'])
Z([3,'40'])
Z([3,'34cfdc56-1'])
Z([[2,'==='],[[7],[3,'displayFlag']],[1,'emoji']])
Z(z[3])
Z(z[1])
Z([[4],[[5],[[4],[[5],[[5],[1,'^enterEmoji']],[[4],[[5],[[4],[[5],[1,'appendMessage']]]]]]]]])
Z([3,'34cfdc56-2'])
Z([[2,'==='],[[7],[3,'displayFlag']],[1,'extension']])
Z(z[3])
Z(z[1])
Z(z[1])
Z([3,'tui-cards'])
Z([[7],[3,'commonWordsData']])
Z([[4],[[5],[[5],[[4],[[5],[[5],[1,'^sendMessage']],[[4],[[5],[[4],[[5],[1,'$handleSendTextMessage']]]]]]]],[[4],[[5],[[5],[1,'^close']],[[4],[[5],[[4],[[5],[1,'$handleCloseCards']]]]]]]]])
Z([[7],[3,'displayCommonWords']])
Z([3,'34cfdc56-3'])
Z(z[3])
Z(z[1])
Z(z[1])
Z(z[17])
Z([[4],[[5],[[5],[[4],[[5],[[5],[1,'^sendCustomMessage']],[[4],[[5],[[4],[[5],[1,'$handleSendCustomMessage']]]]]]]],[[4],[[5],[[5],[1,'^close']],[[4],[[5],[[4],[[5],[1,'$handleCloseCards']]]]]]]]])
Z([[7],[3,'displayOrderList']])
Z([[7],[3,'orderListData']])
Z([3,'34cfdc56-4'])
Z(z[3])
Z(z[1])
Z(z[1])
Z(z[17])
Z(z[26])
Z([[7],[3,'displayServiceEvaluation']])
Z([3,'34cfdc56-5'])
Z([[7],[3,'popupToggle']])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_17_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_17_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_17=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_17=true;
var x=['./components/tui-chat/message-input/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_17_1()
var oVC=_n('view')
var aXC=_n('view')
_rz(z,aXC,'class',0,e,s,gg)
var b1C=_mz(z,'view',['bindtap',1,'data-event-opts',1],[],e,s,gg)
var o2C=_mz(z,'u-icon',['bind:__l',3,'color',1,'name',2,'size',3,'vueId',4],[],e,s,gg)
_(b1C,o2C)
_(aXC,b1C)
var tYC=_v()
_(aXC,tYC)
if(_oz(z,8,e,s,gg)){tYC.wxVkey=1
var x3C=_mz(z,'t-u-i-emoji',['bind:__l',9,'bind:enterEmoji',1,'data-event-opts',2,'vueId',3],[],e,s,gg)
_(tYC,x3C)
}
var eZC=_v()
_(aXC,eZC)
if(_oz(z,13,e,s,gg)){eZC.wxVkey=1
}
var o4C=_mz(z,'t-u-i-common-words',['bind:__l',14,'bind:close',1,'bind:sendMessage',2,'class',3,'commonWordsMatch',4,'data-event-opts',5,'display',6,'vueId',7],[],e,s,gg)
_(aXC,o4C)
var f5C=_mz(z,'t-u-i-order-list',['bind:__l',22,'bind:close',1,'bind:sendCustomMessage',2,'class',3,'data-event-opts',4,'display',5,'orderListData',6,'vueId',7],[],e,s,gg)
_(aXC,f5C)
var c6C=_mz(z,'t-u-i-service-evaluation',['bind:__l',30,'bind:close',1,'bind:sendCustomMessage',2,'class',3,'data-event-opts',4,'display',5,'vueId',6],[],e,s,gg)
_(aXC,c6C)
tYC.wxXCkey=1
tYC.wxXCkey=3
eZC.wxXCkey=1
_(oVC,aXC)
var lWC=_v()
_(oVC,lWC)
if(_oz(z,37,e,s,gg)){lWC.wxVkey=1
}
lWC.wxXCkey=1
_(r,oVC)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_17";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_17();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/tui-chat/message-input/index.wxml'] = [$gwx_XC_17, './components/tui-chat/message-input/index.wxml'];else __wxAppCode__['components/tui-chat/message-input/index.wxml'] = $gwx_XC_17( './components/tui-chat/message-input/index.wxml' );
	;__wxRoute = "components/tui-chat/message-input/index";__wxRouteBegin = true;__wxAppCurrentFile__="components/tui-chat/message-input/index.js";define("components/tui-chat/message-input/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
(global.webpackJsonp=global.webpackJsonp||[]).push([["components/tui-chat/message-input/index"],{1069:function(e,t,n){"use strict";n.r(t);var i=n(1070),s=n(1072);for(var o in s)"default"!==o&&function(e){n.d(t,e,(function(){return s[e]}))}(o);n(1074);var a=n(17),r=Object(a.default)(s.default,i.render,i.staticRenderFns,!1,null,null,null,!1,i.components,void 0);r.options.__file="components/tui-chat/message-input/index.vue",t.default=r.exports},1070:function(e,t,n){"use strict";n.r(t);var i=n(1071);n.d(t,"render",(function(){return i.render})),n.d(t,"staticRenderFns",(function(){return i.staticRenderFns})),n.d(t,"recyclableRender",(function(){return i.recyclableRender})),n.d(t,"components",(function(){return i.components}))},1071:function(e,t,n){"use strict";var i;n.r(t),n.d(t,"render",(function(){return s})),n.d(t,"staticRenderFns",(function(){return a})),n.d(t,"recyclableRender",(function(){return o})),n.d(t,"components",(function(){return i}));try{i={uIcon:function(){return n.e("uview-ui/components/u-icon/u-icon").then(n.bind(null,854))}}}catch(e){if(-1===e.message.indexOf("Cannot find module")||-1===e.message.indexOf(".vue"))throw e;console.error(e.message),console.error("1. 排查组件名称拼写是否正确"),console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"),console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件")}var s=function(){this.$createElement,this._self._c},o=!1,a=[];s._withStripped=!0},1072:function(e,t,n){"use strict";n.r(t);var i=n(1073),s=n.n(i);for(var o in i)"default"!==o&&function(e){n.d(t,e,(function(){return i[e]}))}(o);t.default=s.a},1073:function(e,t,n){"use strict";(function(e){Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var i={data:function(){return{setTuisong:1,inputText:"",extensionArea:!1,sendMessageBtn:!1,displayFlag:"",isAudio:!1,bottomVal:0,startPoint:0,popupToggle:!1,isRecording:!1,canSend:!0,text:"按住说话",title:" ",notShow:!1,isShow:!0,recordTime:0,recordTimer:null,imageIcon:["http://qiniuimg.kfmanager.com/qunjl/showrel/tuiorders.png","http://qiniuimg.kfmanager.com/qunjl/showrel/tuimess.png","http://qiniuimg.kfmanager.com/qunjl/showrel/tuiwei.png"],commonFunctionTe:[{name:"发送订单",key:"1"},{name:"常用话语",key:"0"},{name:"微信二维码",key:"3"}],commonFunction:[{name:"常用语",key:"0"},{name:"发送订单",key:"1"},{name:"服务评价",key:"2"}],displayServiceEvaluation:!1,displayCommonWords:!1,displayOrderList:!1}},components:{TUIEmoji:function(){Promise.all([n.e("common/vendor"),n.e("components/tui-chat/message-elements/emoji/index")]).then(function(){return resolve(n(1256))}.bind(null,n)).catch(n.oe)},TUICommonWords:function(){n.e("components/tui-chat/message-private/common-words/index").then(function(){return resolve(n(1263))}.bind(null,n)).catch(n.oe)},TUIOrderList:function(){n.e("components/tui-chat/message-private/order-list/index").then(function(){return resolve(n(1270))}.bind(null,n)).catch(n.oe)},TUIServiceEvaluation:function(){n.e("components/tui-chat/message-private/service-evaluation/index").then(function(){return resolve(n(1277))}.bind(null,n)).catch(n.oe)}},props:{commonWordsData:{type:Array,default:function(){return[]}},conversation:{type:Object,default:function(){}},orderListData:{type:Array,default:function(){return[]}}},watch:{conversation:{handler:function(e){},immediate:!0,deep:!0}},beforeMount:function(){var t=this;this.recorderManager=e.getRecorderManager(),this.recorderManager.onStop((function(n){clearInterval(t.recordTimer);var i={duration:n.duration?n.duration:1e3*t.recordTime,tempFilePath:n.tempFilePath,fileSize:n.fileSize?n.fileSize:48*t.recordTime/8*1024};if(e.hideLoading(),t.canSend)if(i.duration<1e3)e.showToast({title:"录音时间太短",icon:"none"});else{var s=e.$TUIKit.createAudioMessage({to:t.getToAccount(),conversationType:t.conversation.type,payload:{file:i}});t.$sendTIMMessage(s)}t.setData({startPoint:0,popupToggle:!1,isRecording:!1,canSend:!0,title:" ",text:"按住说话"})}))},methods:{toSetting:function(){e.navigateTo({url:"../pageRelay/tuiChatDiy"})},switchAudio:function(){this.setData({isAudio:!this.isAudio,text:"按住说话"})},handleLongPress:function(e){var t=this;this.recorderManager.start({duration:6e4,sampleRate:44100,numberOfChannels:1,encodeBitRate:192e3,format:"aac"}),this.setData({startPoint:e.touches[0],title:"正在录音",notShow:!0,isShow:!1,isRecording:!0,popupToggle:!0,recordTime:0}),this.recordTimer=setInterval((function(){t.recordTime++}),1e3)},handleTouchMove:function(e){this.isRecording&&(this.startPoint.clientY-e.touches[e.touches.length-1].clientY>100?this.setData({text:"抬起停止",title:"松开手指，取消发送",canSend:!1}):this.startPoint.clientY-e.touches[e.touches.length-1].clientY>20?this.setData({text:"抬起停止",title:"上划可取消",canSend:!0}):this.setData({text:"抬起停止",title:"正在录音",canSend:!0}))},handleTouchEnd:function(){this.setData({isRecording:!1,popupToggle:!1}),e.hideLoading(),this.recorderManager.stop()},handleEmoji:function(){var e="emoji";"emoji"===this.displayFlag&&(e=""),this.setData({displayFlag:e})},handleExtensions:function(){var e="extension";"extension"===this.displayFlag&&(e=""),this.setData({displayFlag:e})},error:function(e){console.log(e.detail)},handleSendPicture:function(){this.sendImageMessage("camera")},handleSendImage:function(){this.sendImageMessage("album")},sendImageMessage:function(t){var n=this;e.chooseImage({sourceType:[t],count:1,success:function(t){if(t){var i=e.$TUIKit.createImageMessage({to:n.getToAccount(),conversationType:n.conversation.type,payload:{file:t},onProgress:function(e){i.percent=e}});n.$sendTIMMessage(i)}}})},handleShootVideo:function(){this.sendVideoMessage("camera")},handleSendVideo:function(){this.sendVideoMessage("album")},sendVideoMessage:function(t){var n=this;e.chooseVideo({sourceType:[t],maxDuration:60,camera:"back",success:function(t){if(t){var i=e.$TUIKit.createVideoMessage({to:n.getToAccount(),conversationType:n.conversation.type,payload:{file:t},onProgress:function(e){i.percent=e}});n.$sendTIMMessage(i)}}})},handleCommonFunctions:function(e){switch(e){case"0":this.setData({displayCommonWords:!0});break;case"1":this.setData({displayOrderList:!0});break;case"2":this.setData({displayServiceEvaluation:!0});break;case"3":this.$emit("sengReady")}},handleSendOrder:function(){this.setData({displayOrderList:!0})},appendMessage:function(e){this.setData({inputText:this.inputText+e.detail.message,sendMessageBtn:!0})},getToAccount:function(){if(!this.conversation||!this.conversation.conversationID)return"";switch(this.conversation.type){case"C2C":return this.conversation.conversationID.replace("C2C","");case"GROUP":return this.conversation.conversationID.replace("GROUP","");default:return this.conversation.conversationID}},handleCalling:function(t){if("GROUP"!==this.conversation.type){var n=t.currentTarget.dataset.value,i=this.conversation.userProfile.userID;this.$emit("handleCall",{detail:{type:n,userID:i}}),this.setData({displayFlag:""})}else e.showToast({title:"群聊暂不支持",icon:"none"})},sendTextMessage:function(t,n){var i=this.getToAccount(),s=n?t:this.inputText,o=e.$TUIKit.createTextMessage({to:i,conversationType:this.conversation.type,payload:{text:s}});this.setData({inputText:"",sendMessageBtn:!1}),this.$sendTIMMessage(o)},onInputValueChange:function(e){e.detail.value?this.setData({sendMessageBtn:!0}):this.setData({sendMessageBtn:!1})},$handleSendTextMessage:function(e){this.sendTextMessage(e.detail.message,!0),this.setData({displayCommonWords:!1})},$handleSendCustomMessage:function(t){var n=e.$TUIKit.createCustomMessage({to:this.getToAccount(),conversationType:this.conversation.type,payload:t.detail.payload});this.$sendTIMMessage(n),this.setData({displayOrderList:!1})},$handleCloseCards:function(e){switch(e.detail.key){case"0":this.setData({displayCommonWords:!1});break;case"1":this.setData({displayOrderList:!1});break;case"2":this.setData({displayServiceEvaluation:!1})}},$sendTIMMessage:function(t){if(console.log("发送消息--",t),this.$emit("sendMessage",{detail:{message:t}}),e.$TUIKit.sendMessage(t),this.setData({displayFlag:""}),1==this.setTuisong){this.setTuisong++;var n=e.getStorageSync("imcIdcid");this.$server.pushChatMsg({toUserId:n.chatId}).then((function(e){e.code}))}},handleClose:function(){this.setData({displayFlag:""})},handleServiceEvaluation:function(){this.setData({displayServiceEvaluation:!0})},inputBindFocus:function(){console.log("占位：函数 inputBindFocus 未声明")},inputBindBlur:function(){console.log("占位：函数 inputBindBlur 未声明")}}};t.default=i}).call(this,n(1).default)},1074:function(e,t,n){"use strict";n.r(t);var i=n(1075),s=n.n(i);for(var o in i)"default"!==o&&function(e){n.d(t,e,(function(){return i[e]}))}(o);t.default=s.a},1075:function(e,t,n){}}]),(global.webpackJsonp=global.webpackJsonp||[]).push(["components/tui-chat/message-input/index-create-component",{"components/tui-chat/message-input/index-create-component":function(e,t,n){n("1").createComponent(n(1069))}},[["components/tui-chat/message-input/index-create-component"]]]);
},{isPage:false,isComponent:true,currentFile:'components/tui-chat/message-input/index.js'});require("components/tui-chat/message-input/index.js");