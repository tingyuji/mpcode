$gwx_XC_10=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_10 || [];
function gz$gwx_XC_10_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_10_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_10_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_10_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_10_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_10_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_10=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_10=true;
var x=['./components/tui-chat/message-elements/face-message/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_10_1()
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_10";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_10();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/tui-chat/message-elements/face-message/index.wxml'] = [$gwx_XC_10, './components/tui-chat/message-elements/face-message/index.wxml'];else __wxAppCode__['components/tui-chat/message-elements/face-message/index.wxml'] = $gwx_XC_10( './components/tui-chat/message-elements/face-message/index.wxml' );
	;__wxRoute = "components/tui-chat/message-elements/face-message/index";__wxRouteBegin = true;__wxAppCurrentFile__="components/tui-chat/message-elements/face-message/index.js";define("components/tui-chat/message-elements/face-message/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
(global.webpackJsonp=global.webpackJsonp||[]).push([["components/tui-chat/message-elements/face-message/index"],{1242:function(e,n,t){"use strict";t.r(n);var r=t(1243),c=t(1245);for(var s in c)"default"!==s&&function(e){t.d(n,e,(function(){return c[e]}))}(s);t(1247);var a=t(17),o=Object(a.default)(c.default,r.render,r.staticRenderFns,!1,null,null,null,!1,r.components,void 0);o.options.__file="components/tui-chat/message-elements/face-message/index.vue",n.default=o.exports},1243:function(e,n,t){"use strict";t.r(n);var r=t(1244);t.d(n,"render",(function(){return r.render})),t.d(n,"staticRenderFns",(function(){return r.staticRenderFns})),t.d(n,"recyclableRender",(function(){return r.recyclableRender})),t.d(n,"components",(function(){return r.components}))},1244:function(e,n,t){"use strict";t.r(n),t.d(n,"render",(function(){return r})),t.d(n,"staticRenderFns",(function(){return s})),t.d(n,"recyclableRender",(function(){return c})),t.d(n,"components",(function(){}));var r=function(){this.$createElement,this._self._c},c=!1,s=[];r._withStripped=!0},1245:function(e,n,t){"use strict";t.r(n);var r=t(1246),c=t.n(r);for(var s in r)"default"!==s&&function(e){t.d(n,e,(function(){return r[e]}))}(s);n.default=c.a},1246:function(e,n,t){"use strict";(function(e){Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var t={data:function(){return{renderDom:[],percent:0,faceUrl:"https://web.sdk.qcloud.com/im/assets/face-elem/"}},components:{},props:{message:{type:Object},isMine:{type:Boolean,default:!0}},watch:{message:{handler:function(e){this.setData({renderDom:this.parseFace(e)})},immediate:!0,deep:!0}},methods:{parseFace:function(e){return{src:"".concat(this.faceUrl+e.payload.data,"@2x.png")}},previewImage:function(){e.previewImage({current:this.renderDom[0].src,urls:[this.renderDom[0].src]})}}};n.default=t}).call(this,t(1).default)},1247:function(e,n,t){"use strict";t.r(n);var r=t(1248),c=t.n(r);for(var s in r)"default"!==s&&function(e){t.d(n,e,(function(){return r[e]}))}(s);n.default=c.a},1248:function(e,n,t){}}]),(global.webpackJsonp=global.webpackJsonp||[]).push(["components/tui-chat/message-elements/face-message/index-create-component",{"components/tui-chat/message-elements/face-message/index-create-component":function(e,n,t){t("1").createComponent(t(1242))}},[["components/tui-chat/message-elements/face-message/index-create-component"]]]);
},{isPage:false,isComponent:true,currentFile:'components/tui-chat/message-elements/face-message/index.js'});require("components/tui-chat/message-elements/face-message/index.js");