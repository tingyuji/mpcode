$gwx_XC_14=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_14 || [];
function gz$gwx_XC_14_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_14_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_14_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_14_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'index'])
Z([3,'item'])
Z([[7],[3,'renderDom']])
Z(z[0])
Z([3,'__e'])
Z(z[4])
Z([3,'message-body-span'])
Z([[4],[[5],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'copyText']],[[4],[[5],[1,'$0']]]],[[4],[[5],[[4],[[5],[[4],[[5],[[5],[[5],[1,'renderDom']],[1,'']],[[7],[3,'index']]]]]]]]]]]]]]],[[4],[[5],[[5],[1,'longpress']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'copyText']],[[4],[[5],[1,'$0']]]],[[4],[[5],[[4],[[5],[[4],[[5],[[5],[[5],[1,'renderDom']],[1,'']],[[7],[3,'index']]]]]]]]]]]]]]]])
Z([[2,'==='],[[6],[[7],[3,'item']],[3,'name']],[1,'span']])
Z([[2,'==='],[[6],[[7],[3,'item']],[3,'name']],[1,'img']])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_14_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_14_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_14=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_14=true;
var x=['./components/tui-chat/message-elements/text-message/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_14_1()
var aJC=_v()
_(r,aJC)
var tKC=function(bMC,eLC,oNC,gg){
var oPC=_mz(z,'view',['bindlongpress',4,'bindtap',1,'class',2,'data-event-opts',3],[],bMC,eLC,gg)
var fQC=_v()
_(oPC,fQC)
if(_oz(z,8,bMC,eLC,gg)){fQC.wxVkey=1
}
var cRC=_v()
_(oPC,cRC)
if(_oz(z,9,bMC,eLC,gg)){cRC.wxVkey=1
}
fQC.wxXCkey=1
cRC.wxXCkey=1
_(oNC,oPC)
return oNC
}
aJC.wxXCkey=2
_2z(z,2,tKC,e,s,gg,aJC,'item','index','index')
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_14";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_14();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/tui-chat/message-elements/text-message/index.wxml'] = [$gwx_XC_14, './components/tui-chat/message-elements/text-message/index.wxml'];else __wxAppCode__['components/tui-chat/message-elements/text-message/index.wxml'] = $gwx_XC_14( './components/tui-chat/message-elements/text-message/index.wxml' );
	;__wxRoute = "components/tui-chat/message-elements/text-message/index";__wxRouteBegin = true;__wxAppCurrentFile__="components/tui-chat/message-elements/text-message/index.js";define("components/tui-chat/message-elements/text-message/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
(global.webpackJsonp=global.webpackJsonp||[]).push([["components/tui-chat/message-elements/text-message/index"],{1188:function(e,t,n){"use strict";n.r(t);var o=n(1189),s=n(1191);for(var c in s)"default"!==c&&function(e){n.d(t,e,(function(){return s[e]}))}(c);n(1195);var r=n(17),a=Object(r.default)(s.default,o.render,o.staticRenderFns,!1,null,null,null,!1,o.components,void 0);a.options.__file="components/tui-chat/message-elements/text-message/index.vue",t.default=a.exports},1189:function(e,t,n){"use strict";n.r(t);var o=n(1190);n.d(t,"render",(function(){return o.render})),n.d(t,"staticRenderFns",(function(){return o.staticRenderFns})),n.d(t,"recyclableRender",(function(){return o.recyclableRender})),n.d(t,"components",(function(){return o.components}))},1190:function(e,t,n){"use strict";n.r(t),n.d(t,"render",(function(){return o})),n.d(t,"staticRenderFns",(function(){return c})),n.d(t,"recyclableRender",(function(){return s})),n.d(t,"components",(function(){}));var o=function(){this.$createElement,this._self._c},s=!1,c=[];o._withStripped=!0},1191:function(e,t,n){"use strict";n.r(t);var o=n(1192),s=n.n(o);for(var c in o)"default"!==c&&function(e){n.d(t,e,(function(){return o[e]}))}(c);t.default=s.a},1192:function(e,t,n){"use strict";(function(e){Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var o=n(1193),s={data:function(){return{renderDom:[]}},components:{},props:{message:{type:Object},isMine:{type:Boolean,default:!0}},watch:{message:{handler:function(e){this.setData({renderDom:(0,o.parseText)(e)})},immediate:!0,deep:!0}},beforeMount:function(){},destroyed:function(){},methods:{copyText:function(t){e.setClipboardData({data:t.text,success:function(){e.hideLoading(),e.showToast({title:"文案已复制",icon:"none"})}})}}};t.default=s}).call(this,n(1).default)},1195:function(e,t,n){"use strict";n.r(t);var o=n(1196),s=n.n(o);for(var c in o)"default"!==c&&function(e){n.d(t,e,(function(){return o[e]}))}(c);t.default=s.a},1196:function(e,t,n){}}]),(global.webpackJsonp=global.webpackJsonp||[]).push(["components/tui-chat/message-elements/text-message/index-create-component",{"components/tui-chat/message-elements/text-message/index-create-component":function(e,t,n){n("1").createComponent(n(1188))}},[["components/tui-chat/message-elements/text-message/index-create-component"]]]);
},{isPage:false,isComponent:true,currentFile:'components/tui-chat/message-elements/text-message/index.js'});require("components/tui-chat/message-elements/text-message/index.js");