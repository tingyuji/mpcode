$gwx_XC_14=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_14 || [];
function gz$gwx_XC_14_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_14_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_14_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_14_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[4],[[5],[[2,'+'],[1,'text-message '],[[2,'?:'],[[7],[3,'isMine']],[1,'my-text'],[1,'']]]]])
Z([3,'index'])
Z([3,'item'])
Z([[7],[3,'renderDom']])
Z(z[1])
Z([3,'__e'])
Z(z[5])
Z([3,'message-body-span'])
Z([[4],[[5],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'copyText']],[[4],[[5],[1,'$0']]]],[[4],[[5],[[4],[[5],[[4],[[5],[[5],[[5],[1,'renderDom']],[1,'']],[[7],[3,'index']]]]]]]]]]]]]]],[[4],[[5],[[5],[1,'longpress']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'copyText']],[[4],[[5],[1,'$0']]]],[[4],[[5],[[4],[[5],[[4],[[5],[[5],[[5],[1,'renderDom']],[1,'']],[[7],[3,'index']]]]]]]]]]]]]]]])
Z([[2,'==='],[[6],[[7],[3,'item']],[3,'name']],[1,'span']])
Z([3,'message-body-span-text _span'])
Z([a,[[6],[[7],[3,'item']],[3,'text']]])
Z([[2,'==='],[[6],[[7],[3,'item']],[3,'name']],[1,'img']])
Z([3,'emoji-icon'])
Z([[6],[[7],[3,'item']],[3,'src']])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_14_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_14_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_14=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_14=true;
var x=['./components/tui-chat/message-elements/text-message/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_14_1()
var oRL=_n('view')
_rz(z,oRL,'class',0,e,s,gg)
var cSL=_v()
_(oRL,cSL)
var oTL=function(aVL,lUL,tWL,gg){
var bYL=_mz(z,'view',['bindlongpress',5,'bindtap',1,'class',2,'data-event-opts',3],[],aVL,lUL,gg)
var oZL=_v()
_(bYL,oZL)
if(_oz(z,9,aVL,lUL,gg)){oZL.wxVkey=1
var o2L=_n('label')
_rz(z,o2L,'class',10,aVL,lUL,gg)
var f3L=_oz(z,11,aVL,lUL,gg)
_(o2L,f3L)
_(oZL,o2L)
}
var x1L=_v()
_(bYL,x1L)
if(_oz(z,12,aVL,lUL,gg)){x1L.wxVkey=1
var c4L=_mz(z,'image',['class',13,'src',1],[],aVL,lUL,gg)
_(x1L,c4L)
}
oZL.wxXCkey=1
x1L.wxXCkey=1
_(tWL,bYL)
return tWL
}
cSL.wxXCkey=2
_2z(z,3,oTL,e,s,gg,cSL,'item','index','index')
_(r,oRL)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_14";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_14();
	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/tui-chat/message-elements/text-message/index.wxml'] = [$gwx_XC_14, './components/tui-chat/message-elements/text-message/index.wxml'];else __wxAppCode__['components/tui-chat/message-elements/text-message/index.wxml'] = $gwx_XC_14( './components/tui-chat/message-elements/text-message/index.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['components/tui-chat/message-elements/text-message/index.wxss'] = setCssToHead([".",[1],"text-message{background:#f8f8f8;border:1px solid #d9d9d9;border-radius:2px 10px 10px 10px;display:-webkit-inline-flex;display:inline-flex;line-height:",[0,52],";max-width:60vw;padding:",[0,12]," ",[0,24],"}\n.",[1],"my-text{background:rgba(0,110,255,.1);border:1px solid rgba(0,110,255,.3);border-radius:10px 2px 10px 10px}\n.",[1],"message-body-span{-webkit-align-items:center;align-items:center;color:#333;display:-webkit-flex;display:flex;-webkit-flex-wrap:wrap;flex-wrap:wrap;font-size:",[0,28],";-webkit-justify-content:center;justify-content:center;max-width:60vw;outline:none;position:relative}\n.",[1],"message-body-span-text{word-wrap:break-word;display:inline;width:100%;word-break:break-all}\n.",[1],"message-body-span-image{display:inline-block;height:",[0,32],";margin:0 ",[0,4],";width:",[0,32],"}\n.",[1],"emoji-icon{height:20px;width:20px}\n",],undefined,{path:"./components/tui-chat/message-elements/text-message/index.wxss"});
}