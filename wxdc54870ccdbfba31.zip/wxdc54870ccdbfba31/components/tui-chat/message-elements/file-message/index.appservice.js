$gwx_XC_11=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_11 || [];
function gz$gwx_XC_11_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_11_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_11_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_11_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'Show']])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_11_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_11_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_11=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_11=true;
var x=['./components/tui-chat/message-elements/file-message/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_11_1()
var oFC=_v()
_(r,oFC)
if(_oz(z,0,e,s,gg)){oFC.wxVkey=1
}
oFC.wxXCkey=1
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_11";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_11();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/tui-chat/message-elements/file-message/index.wxml'] = [$gwx_XC_11, './components/tui-chat/message-elements/file-message/index.wxml'];else __wxAppCode__['components/tui-chat/message-elements/file-message/index.wxml'] = $gwx_XC_11( './components/tui-chat/message-elements/file-message/index.wxml' );
	;__wxRoute = "components/tui-chat/message-elements/file-message/index";__wxRouteBegin = true;__wxAppCurrentFile__="components/tui-chat/message-elements/file-message/index.js";define("components/tui-chat/message-elements/file-message/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
(global.webpackJsonp=global.webpackJsonp||[]).push([["components/tui-chat/message-elements/file-message/index"],{1249:function(e,n,t){"use strict";t.r(n);var o=t(1250),a=t(1252);for(var c in a)"default"!==c&&function(e){t.d(n,e,(function(){return a[e]}))}(c);t(1254);var s=t(17),i=Object(s.default)(a.default,o.render,o.staticRenderFns,!1,null,null,null,!1,o.components,void 0);i.options.__file="components/tui-chat/message-elements/file-message/index.vue",n.default=i.exports},1250:function(e,n,t){"use strict";t.r(n);var o=t(1251);t.d(n,"render",(function(){return o.render})),t.d(n,"staticRenderFns",(function(){return o.staticRenderFns})),t.d(n,"recyclableRender",(function(){return o.recyclableRender})),t.d(n,"components",(function(){return o.components}))},1251:function(e,n,t){"use strict";t.r(n),t.d(n,"render",(function(){return o})),t.d(n,"staticRenderFns",(function(){return c})),t.d(n,"recyclableRender",(function(){return a})),t.d(n,"components",(function(){}));var o=function(){this.$createElement,this._self._c},a=!1,c=[];o._withStripped=!0},1252:function(e,n,t){"use strict";t.r(n);var o=t(1253),a=t.n(o);for(var c in o)"default"!==c&&function(e){t.d(n,e,(function(){return o[e]}))}(c);n.default=a.a},1253:function(e,n,t){"use strict";(function(e){Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var t={data:function(){return{Show:!1,filePayload:{}}},components:{},props:{message:{type:Object,default:function(){}},isMine:{type:Boolean,default:!0}},watch:{message:{handler:function(e){this.setData({filePayload:e.payload})},immediate:!0,deep:!0}},methods:{download:function(){this.setData({Show:!0})},downloadConfirm:function(){e.downloadFile({url:this.filePayload.fileUrl,success:function(n){var t=n.tempFilePath;e.openDocument({filePath:t,success:function(){console.log("打开文档成功")}})}})},cancel:function(){this.setData({Show:!1})}}};n.default=t}).call(this,t(1).default)},1254:function(e,n,t){"use strict";t.r(n);var o=t(1255),a=t.n(o);for(var c in o)"default"!==c&&function(e){t.d(n,e,(function(){return o[e]}))}(c);n.default=a.a},1255:function(e,n,t){}}]),(global.webpackJsonp=global.webpackJsonp||[]).push(["components/tui-chat/message-elements/file-message/index-create-component",{"components/tui-chat/message-elements/file-message/index-create-component":function(e,n,t){t("1").createComponent(t(1249))}},[["components/tui-chat/message-elements/file-message/index-create-component"]]]);
},{isPage:false,isComponent:true,currentFile:'components/tui-chat/message-elements/file-message/index.js'});require("components/tui-chat/message-elements/file-message/index.js");