$gwx_XC_8=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_8 || [];
function gz$gwx_XC_8_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_8_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_8_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_8_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'data-v-5c8324a9'])
Z([[2,'==='],[[6],[[6],[[7],[3,'renderDom']],[1,0]],[3,'type']],[1,'order']])
Z([3,'__e'])
Z([[4],[[5],[[5],[1,'data-v-5c8324a9']],[[2,'+'],[1,'custom-message '],[[2,'?:'],[[7],[3,'isMine']],[1,'my-custom'],[1,'']]]]])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'goOrderDet']],[[4],[[5],[1,'$0']]]],[[4],[[5],[1,'renderDom.__$n0.orderId']]]]]]]]]]])
Z([3,'display:block;width:460rpx;color:#999;'])
Z([3,'custom-yr-title data-v-5c8324a9'])
Z(z[0])
Z([3,'活动名：'])
Z([3,'yr_bbs data-v-5c8324a9'])
Z([a,[[6],[[6],[[7],[3,'renderDom']],[1,0]],[3,'activityName']]])
Z([3,'custom-yr-title fl_sb data-v-5c8324a9'])
Z(z[0])
Z([3,'接龙号：'])
Z(z[9])
Z([a,[[6],[[6],[[7],[3,'renderDom']],[1,0]],[3,'activityNumb']]])
Z(z[0])
Z([a,[[6],[[6],[[7],[3,'renderDom']],[1,0]],[3,'createTime']]])
Z([3,'custom-yr-shop data-v-5c8324a9'])
Z([3,'index'])
Z([3,'item'])
Z([[6],[[6],[[7],[3,'renderDom']],[1,0]],[3,'commodityList']])
Z(z[19])
Z([3,'custom-yr-shele fl_sb data-v-5c8324a9'])
Z(z[0])
Z([3,'aspectFill'])
Z([[6],[[7],[3,'item']],[3,'imgUrl']])
Z([3,'custom-yr-rigt fl_c data-v-5c8324a9'])
Z(z[9])
Z([a,[[6],[[7],[3,'item']],[3,'commodityName']]])
Z(z[0])
Z([a,[[6],[[7],[3,'item']],[3,'formatName']]])
Z([3,'fl_sb data-v-5c8324a9'])
Z(z[0])
Z([3,'color:#fc5757;'])
Z([a,[[2,'+'],[1,'¥'],[[6],[[7],[3,'item']],[3,'commodityPrice']]]])
Z(z[0])
Z([a,[[2,'+'],[1,'+'],[[6],[[7],[3,'item']],[3,'commodityCount']]]])
Z([[2,'==='],[[6],[[6],[[7],[3,'renderDom']],[1,0]],[3,'type']],[1,'consultion']])
Z(z[3])
Z([3,'custom-content data-v-5c8324a9'])
Z([3,'custom-content-title data-v-5c8324a9'])
Z([a,[[6],[[6],[[7],[3,'renderDom']],[1,0]],[3,'title']]])
Z(z[19])
Z(z[20])
Z([[6],[[6],[[7],[3,'renderDom']],[1,0]],[3,'item']])
Z(z[19])
Z([3,'custom-content-description data-v-5c8324a9'])
Z([[6],[[7],[3,'item']],[3,'key']])
Z([a,[[6],[[7],[3,'item']],[3,'key']]])
Z(z[47])
Z([a,[[6],[[6],[[7],[3,'renderDom']],[1,0]],[3,'description']]])
Z([[2,'==='],[[6],[[6],[[7],[3,'renderDom']],[1,0]],[3,'type']],[1,'evaluation']])
Z(z[3])
Z(z[40])
Z(z[41])
Z([a,z[42][1]])
Z([3,'custom-content-score data-v-5c8324a9'])
Z(z[19])
Z(z[20])
Z([[6],[[6],[[7],[3,'renderDom']],[1,0]],[3,'score']])
Z(z[19])
Z([3,'score-star data-v-5c8324a9'])
Z([3,'https://qiniuimg.kfmanager.com/svg/assets/star.png'])
Z(z[47])
Z([a,z[51][1]])
Z([[2,'==='],[[6],[[6],[[7],[3,'renderDom']],[1,0]],[3,'type']],[1,'group_create']])
Z(z[3])
Z([3,'custom-content-text data-v-5c8324a9'])
Z([a,[[6],[[6],[[7],[3,'renderDom']],[1,0]],[3,'text']]])
Z([[2,'==='],[[6],[[6],[[7],[3,'renderDom']],[1,0]],[3,'type']],[1,'notSupport']])
Z([3,'message-body-span text-message data-v-5c8324a9'])
Z([3,'message-body-span-text data-v-5c8324a9'])
Z([a,z[69][1]])
Z([[2,'==='],[[6],[[6],[[7],[3,'renderDom']],[1,0]],[3,'type']],[1,'imageurl']])
Z(z[2])
Z([3,'TUI-ImageMessage data-v-5c8324a9'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'previewImage']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([[4],[[5],[[5],[1,'data-v-5c8324a9']],[[2,'+'],[1,'image-message '],[[2,'?:'],[[7],[3,'isMine']],[1,'my-image'],[1,'']]]]])
Z([3,'widthFix'])
Z([[6],[[6],[[7],[3,'renderDom']],[1,0]],[3,'imgUrl']])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_8_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_8_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_8=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_8=true;
var x=['./components/tui-chat/message-elements/custom-message/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_8_1()
var lCI=_n('view')
_rz(z,lCI,'class',0,e,s,gg)
var aDI=_v()
_(lCI,aDI)
if(_oz(z,1,e,s,gg)){aDI.wxVkey=1
var oJI=_mz(z,'view',['bindtap',2,'class',1,'data-event-opts',2,'style',3],[],e,s,gg)
var fKI=_n('view')
_rz(z,fKI,'class',6,e,s,gg)
var cLI=_n('text')
_rz(z,cLI,'class',7,e,s,gg)
var hMI=_oz(z,8,e,s,gg)
_(cLI,hMI)
var oNI=_n('text')
_rz(z,oNI,'class',9,e,s,gg)
var cOI=_oz(z,10,e,s,gg)
_(oNI,cOI)
_(cLI,oNI)
_(fKI,cLI)
_(oJI,fKI)
var oPI=_n('view')
_rz(z,oPI,'class',11,e,s,gg)
var lQI=_n('text')
_rz(z,lQI,'class',12,e,s,gg)
var aRI=_oz(z,13,e,s,gg)
_(lQI,aRI)
var tSI=_n('text')
_rz(z,tSI,'class',14,e,s,gg)
var eTI=_oz(z,15,e,s,gg)
_(tSI,eTI)
_(lQI,tSI)
_(oPI,lQI)
var bUI=_n('text')
_rz(z,bUI,'class',16,e,s,gg)
var oVI=_oz(z,17,e,s,gg)
_(bUI,oVI)
_(oPI,bUI)
_(oJI,oPI)
var xWI=_n('view')
_rz(z,xWI,'class',18,e,s,gg)
var oXI=_v()
_(xWI,oXI)
var fYI=function(h1I,cZI,o2I,gg){
var o4I=_n('view')
_rz(z,o4I,'class',23,h1I,cZI,gg)
var l5I=_mz(z,'image',['class',24,'mode',1,'src',2],[],h1I,cZI,gg)
_(o4I,l5I)
var a6I=_n('view')
_rz(z,a6I,'class',27,h1I,cZI,gg)
var t7I=_n('text')
_rz(z,t7I,'class',28,h1I,cZI,gg)
var e8I=_oz(z,29,h1I,cZI,gg)
_(t7I,e8I)
_(a6I,t7I)
var b9I=_n('text')
_rz(z,b9I,'class',30,h1I,cZI,gg)
var o0I=_oz(z,31,h1I,cZI,gg)
_(b9I,o0I)
_(a6I,b9I)
var xAJ=_n('view')
_rz(z,xAJ,'class',32,h1I,cZI,gg)
var oBJ=_mz(z,'text',['class',33,'style',1],[],h1I,cZI,gg)
var fCJ=_oz(z,35,h1I,cZI,gg)
_(oBJ,fCJ)
_(xAJ,oBJ)
var cDJ=_n('text')
_rz(z,cDJ,'class',36,h1I,cZI,gg)
var hEJ=_oz(z,37,h1I,cZI,gg)
_(cDJ,hEJ)
_(xAJ,cDJ)
_(a6I,xAJ)
_(o4I,a6I)
_(o2I,o4I)
return o2I
}
oXI.wxXCkey=2
_2z(z,21,fYI,e,s,gg,oXI,'item','index','index')
_(oJI,xWI)
_(aDI,oJI)
}
var tEI=_v()
_(lCI,tEI)
if(_oz(z,38,e,s,gg)){tEI.wxVkey=1
var oFJ=_n('view')
_rz(z,oFJ,'class',39,e,s,gg)
var cGJ=_n('view')
_rz(z,cGJ,'class',40,e,s,gg)
var oHJ=_n('view')
_rz(z,oHJ,'class',41,e,s,gg)
var lIJ=_oz(z,42,e,s,gg)
_(oHJ,lIJ)
_(cGJ,oHJ)
var aJJ=_v()
_(cGJ,aJJ)
var tKJ=function(bMJ,eLJ,oNJ,gg){
var oPJ=_mz(z,'view',['class',47,'id',1],[],bMJ,eLJ,gg)
var fQJ=_oz(z,49,bMJ,eLJ,gg)
_(oPJ,fQJ)
_(oNJ,oPJ)
return oNJ
}
aJJ.wxXCkey=2
_2z(z,45,tKJ,e,s,gg,aJJ,'item','index','index')
var cRJ=_n('view')
_rz(z,cRJ,'class',50,e,s,gg)
var hSJ=_oz(z,51,e,s,gg)
_(cRJ,hSJ)
_(cGJ,cRJ)
_(oFJ,cGJ)
_(tEI,oFJ)
}
var eFI=_v()
_(lCI,eFI)
if(_oz(z,52,e,s,gg)){eFI.wxVkey=1
var oTJ=_n('view')
_rz(z,oTJ,'class',53,e,s,gg)
var cUJ=_n('view')
_rz(z,cUJ,'class',54,e,s,gg)
var oVJ=_n('view')
_rz(z,oVJ,'class',55,e,s,gg)
var lWJ=_oz(z,56,e,s,gg)
_(oVJ,lWJ)
_(cUJ,oVJ)
var aXJ=_n('view')
_rz(z,aXJ,'class',57,e,s,gg)
var tYJ=_v()
_(aXJ,tYJ)
var eZJ=function(o2J,b1J,x3J,gg){
var f5J=_mz(z,'image',['class',62,'src',1],[],o2J,b1J,gg)
_(x3J,f5J)
return x3J
}
tYJ.wxXCkey=2
_2z(z,60,eZJ,e,s,gg,tYJ,'item','index','index')
_(cUJ,aXJ)
var c6J=_n('view')
_rz(z,c6J,'class',64,e,s,gg)
var h7J=_oz(z,65,e,s,gg)
_(c6J,h7J)
_(cUJ,c6J)
_(oTJ,cUJ)
_(eFI,oTJ)
}
var bGI=_v()
_(lCI,bGI)
if(_oz(z,66,e,s,gg)){bGI.wxVkey=1
var o8J=_n('view')
_rz(z,o8J,'class',67,e,s,gg)
var c9J=_n('view')
_rz(z,c9J,'class',68,e,s,gg)
var o0J=_oz(z,69,e,s,gg)
_(c9J,o0J)
_(o8J,c9J)
_(bGI,o8J)
}
var oHI=_v()
_(lCI,oHI)
if(_oz(z,70,e,s,gg)){oHI.wxVkey=1
var lAK=_n('view')
_rz(z,lAK,'class',71,e,s,gg)
var aBK=_n('view')
_rz(z,aBK,'class',72,e,s,gg)
var tCK=_oz(z,73,e,s,gg)
_(aBK,tCK)
_(lAK,aBK)
_(oHI,lAK)
}
var xII=_v()
_(lCI,xII)
if(_oz(z,74,e,s,gg)){xII.wxVkey=1
var eDK=_mz(z,'view',['bindtap',75,'class',1,'data-event-opts',2],[],e,s,gg)
var bEK=_mz(z,'image',['class',78,'mode',1,'src',2],[],e,s,gg)
_(eDK,bEK)
_(xII,eDK)
}
aDI.wxXCkey=1
tEI.wxXCkey=1
eFI.wxXCkey=1
bGI.wxXCkey=1
oHI.wxXCkey=1
xII.wxXCkey=1
_(r,lCI)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_8";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_8();
	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/tui-chat/message-elements/custom-message/index.wxml'] = [$gwx_XC_8, './components/tui-chat/message-elements/custom-message/index.wxml'];else __wxAppCode__['components/tui-chat/message-elements/custom-message/index.wxml'] = $gwx_XC_8( './components/tui-chat/message-elements/custom-message/index.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['components/tui-chat/message-elements/custom-message/index.wxss'] = setCssToHead([".",[1],"custom-message{background-color:#fff;border:1px solid #d9d9d9;border-radius:2px 10px 10px 10px;display:-webkit-flex;display:flex;padding:",[0,10]," ",[0,24]," ",[0,20],"}\n.",[1],"my-custom{border:1px solid rgba(0,110,255,.3);border-radius:10px 2px 10px 10px}\n.",[1],"custom-content-title{color:#000;font-family:PingFangSC-Medium;font-size:",[0,24],"}\n.",[1],"custom-content-description,.",[1],"custom-content-title{letter-spacing:0;line-height:",[0,34],";margin-bottom:",[0,12],";width:",[0,278],"}\n.",[1],"custom-content-description{color:#006eff;font-family:PingFangSC-Regular;font-size:",[0,28],"}\n.",[1],"custom-content-price{color:#ff7201;font-family:PingFangSC-Medium;letter-spacing:0;line-height:",[0,50],"}\n.",[1],"custom-image{border-radius:",[0,6],";height:",[0,135],";margin-right:",[0,10],";margin-top:",[0,4],";width:",[0,135],"}\n.",[1],"custom-content-score{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;padding-bottom:",[0,12],"}\n.",[1],"custom-content-score .",[1],"score-star{height:",[0,36],";margin-right:",[0,10],";width:",[0,36],"}\n.",[1],"text-message{background:#f8f8f8;border:1px solid #d9d9d9;border-radius:2px 10px 10px 10px;display:-webkit-inline-flex;display:inline-flex;line-height:",[0,52],";max-width:60vw;padding:",[0,12]," ",[0,24],"}\n.",[1],"my-text{background:rgba(0,110,255,.1);border:1px solid rgba(0,110,255,.3);border-radius:10px 2px 10px 10px}\n.",[1],"message-body-span{-webkit-align-items:center;align-items:center;color:#333;display:-webkit-flex;display:flex;-webkit-flex-wrap:wrap;flex-wrap:wrap;font-size:",[0,28],";-webkit-justify-content:center;justify-content:center;max-width:60vw;outline:none;position:relative}\n.",[1],"message-body-span-text{word-wrap:break-word;display:inline;width:100%;word-break:break-all}\n.",[1],"custom-content-text{font-family:PingFangSC-Regular;font-size:",[0,28],";height:25px;letter-spacing:0;line-height:25px}\n.",[1],"TUI-ImageMessage{width:150px}\n.",[1],"image-message{border-radius:10px 10px 10px 10px;height:100%;width:100%}\n.",[1],"my-image{border-radius:10px 2px 10px 10px}\n.",[1],"yr_bbs.",[1],"data-v-5c8324a9{color:#333;font-size:",[0,28],";max-width:",[0,260],"}\n.",[1],"custom-yr-title.",[1],"data-v-5c8324a9{font-size:",[0,24],";height:",[0,50],";line-height:",[0,50],";overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n.",[1],"custom-yr-shop.",[1],"data-v-5c8324a9{background-color:#f7f7f7;border-radius:",[0,20],";box-sizing:border-box;margin-top:",[0,14],";padding:",[0,4]," ",[0,16]," ",[0,12]," ",[0,8],"}\n.",[1],"custom-yr-shop .",[1],"custom-yr-shele.",[1],"data-v-5c8324a9{margin-top:",[0,8],"}\n.",[1],"custom-yr-shop .",[1],"custom-yr-shele wx-image.",[1],"data-v-5c8324a9{border-radius:",[0,10],";height:",[0,100],";width:",[0,100],"}\n.",[1],"custom-yr-shop .",[1],"custom-yr-shele .",[1],"custom-yr-rigt.",[1],"data-v-5c8324a9{box-sizing:border-box;color:#999;-webkit-flex:1;flex:1;font-size:",[0,24],";-webkit-justify-content:space-between;justify-content:space-between;padding-left:",[0,20],"}\n",],"Some selectors are not allowed in component wxss, including tag name selectors, ID selectors, and attribute selectors.(./components/tui-chat/message-elements/custom-message/index.wxss:1:2285)",{path:"./components/tui-chat/message-elements/custom-message/index.wxss"});
}