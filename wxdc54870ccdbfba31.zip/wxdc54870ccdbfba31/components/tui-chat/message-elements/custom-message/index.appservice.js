$gwx_XC_8=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_8 || [];
function gz$gwx_XC_8_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_8_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_8_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_8_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'data-v-5c8324a9'])
Z([[2,'==='],[[6],[[6],[[7],[3,'renderDom']],[1,0]],[3,'type']],[1,'order']])
Z([[2,'==='],[[6],[[6],[[7],[3,'renderDom']],[1,0]],[3,'type']],[1,'consultion']])
Z([[2,'==='],[[6],[[6],[[7],[3,'renderDom']],[1,0]],[3,'type']],[1,'evaluation']])
Z([[2,'==='],[[6],[[6],[[7],[3,'renderDom']],[1,0]],[3,'type']],[1,'group_create']])
Z([[2,'==='],[[6],[[6],[[7],[3,'renderDom']],[1,0]],[3,'type']],[1,'notSupport']])
Z([[2,'==='],[[6],[[6],[[7],[3,'renderDom']],[1,0]],[3,'type']],[1,'imageurl']])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_8_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_8_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_8=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_8=true;
var x=['./components/tui-chat/message-elements/custom-message/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_8_1()
var a6B=_n('view')
_rz(z,a6B,'class',0,e,s,gg)
var t7B=_v()
_(a6B,t7B)
if(_oz(z,1,e,s,gg)){t7B.wxVkey=1
}
var e8B=_v()
_(a6B,e8B)
if(_oz(z,2,e,s,gg)){e8B.wxVkey=1
}
var b9B=_v()
_(a6B,b9B)
if(_oz(z,3,e,s,gg)){b9B.wxVkey=1
}
var o0B=_v()
_(a6B,o0B)
if(_oz(z,4,e,s,gg)){o0B.wxVkey=1
}
var xAC=_v()
_(a6B,xAC)
if(_oz(z,5,e,s,gg)){xAC.wxVkey=1
}
var oBC=_v()
_(a6B,oBC)
if(_oz(z,6,e,s,gg)){oBC.wxVkey=1
}
t7B.wxXCkey=1
e8B.wxXCkey=1
b9B.wxXCkey=1
o0B.wxXCkey=1
xAC.wxXCkey=1
oBC.wxXCkey=1
_(r,a6B)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_8";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_8();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/tui-chat/message-elements/custom-message/index.wxml'] = [$gwx_XC_8, './components/tui-chat/message-elements/custom-message/index.wxml'];else __wxAppCode__['components/tui-chat/message-elements/custom-message/index.wxml'] = $gwx_XC_8( './components/tui-chat/message-elements/custom-message/index.wxml' );
	;__wxRoute = "components/tui-chat/message-elements/custom-message/index";__wxRouteBegin = true;__wxAppCurrentFile__="components/tui-chat/message-elements/custom-message/index.js";define("components/tui-chat/message-elements/custom-message/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
(global.webpackJsonp=global.webpackJsonp||[]).push([["components/tui-chat/message-elements/custom-message/index"],{1218:function(e,t,n){"use strict";n.r(t);var r=n(1219),a=n(1221);for(var o in a)"default"!==o&&function(e){n.d(t,e,(function(){return a[e]}))}(o);n(1223),n(1225);var i=n(17),c=Object(i.default)(a.default,r.render,r.staticRenderFns,!1,null,"5c8324a9",null,!1,r.components,void 0);c.options.__file="components/tui-chat/message-elements/custom-message/index.vue",t.default=c.exports},1219:function(e,t,n){"use strict";n.r(t);var r=n(1220);n.d(t,"render",(function(){return r.render})),n.d(t,"staticRenderFns",(function(){return r.staticRenderFns})),n.d(t,"recyclableRender",(function(){return r.recyclableRender})),n.d(t,"components",(function(){return r.components}))},1220:function(e,t,n){"use strict";n.r(t),n.d(t,"render",(function(){return r})),n.d(t,"staticRenderFns",(function(){return o})),n.d(t,"recyclableRender",(function(){return a})),n.d(t,"components",(function(){}));var r=function(){this.$createElement,this._self._c},a=!1,o=[];r._withStripped=!0},1221:function(e,t,n){"use strict";n.r(t);var r=n(1222),a=n.n(r);for(var o in r)"default"!==o&&function(e){n.d(t,e,(function(){return r[e]}))}(o);t.default=a.a},1222:function(e,t,n){"use strict";(function(e){function n(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var r={data:function(){return{}},components:{},props:{message:{type:Object,default:function(){}},isMine:{type:Boolean,default:!0}},watch:{message:{handler:function(e){this.setData({message:e,renderDom:this.parseCustom(e)})},immediate:!0,deep:!0}},methods:{previewImage:function(){e.previewImage({current:this.renderDom[0].imgUrl,urls:[this.renderDom[0].imgUrl]})},goOrderDet:function(t){e.navigateTo({url:"/pages/subPage/orderDetail?id="+t})},parseCustom:function(e){if("order"===e.payload.data){var t,r=JSON.parse(e.payload.extension);return[(t={type:"order",name:"custom",activityName:r.activityName||"",orderId:r.orderId||"",createTime:r.createTime||"",price:r.price||0,activityNumb:r.activityNumb||1,commodityList:r.commodityList||[],activityId:r.activityId},n(t,"orderId",r.orderId),n(t,"description","text_link"),t)]}if("imageurl"===e.payload.data)return[{type:"imageurl",name:"custom",imgUrl:JSON.parse(e.payload.extension).imgUrl||"",description:"text_link"}];if("consultion"===e.payload.data){var a=JSON.parse(e.payload.extension);return[{type:"consultion",title:a.title||"",item:a.item||0,description:a.description}]}if("evaluation"===e.payload.data){var o=JSON.parse(e.payload.extension);return[{type:"evaluation",title:e.payload.description,score:o.score,description:o.comment}]}return"group_create"===e.payload.data?[{type:"group_create",text:e.payload.extension}]:[{type:"notSupport",text:"[自定义消息]"}]}}};t.default=r}).call(this,n(1).default)},1223:function(e,t,n){"use strict";n.r(t);var r=n(1224),a=n.n(r);for(var o in r)"default"!==o&&function(e){n.d(t,e,(function(){return r[e]}))}(o);t.default=a.a},1224:function(e,t,n){},1225:function(e,t,n){"use strict";n.r(t);var r=n(1226),a=n.n(r);for(var o in r)"default"!==o&&function(e){n.d(t,e,(function(){return r[e]}))}(o);t.default=a.a},1226:function(e,t,n){}}]),(global.webpackJsonp=global.webpackJsonp||[]).push(["components/tui-chat/message-elements/custom-message/index-create-component",{"components/tui-chat/message-elements/custom-message/index-create-component":function(e,t,n){n("1").createComponent(n(1218))}},[["components/tui-chat/message-elements/custom-message/index-create-component"]]]);
},{isPage:false,isComponent:true,currentFile:'components/tui-chat/message-elements/custom-message/index.js'});require("components/tui-chat/message-elements/custom-message/index.js");