$gwx_XC_18=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_18 || [];
function gz$gwx_XC_18_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_18_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_18_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_18_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'__e'])
Z([3,'message-list-container'])
Z([[4],[[5],[[4],[[5],[[5],[1,'refresherrefresh']],[[4],[[5],[[4],[[5],[[5],[1,'refresh']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([1,true])
Z([[7],[3,'triggered']])
Z([[7],[3,'scrollView']])
Z([[7],[3,'scrollTop']])
Z([3,'true'])
Z([3,'message-scroll'])
Z([3,'width:100%;'])
Z([[7],[3,'isCompleted']])
Z([3,'index'])
Z([3,'item'])
Z([[6],[[7],[3,'$root']],[3,'l0']])
Z([3,'ID'])
Z([3,'t-message'])
Z([3,'background-color:#f4f4f4;'])
Z([[2,'!=='],[[6],[[7],[3,'conversation']],[3,'type']],[1,'@TIM#SYSTEM']])
Z([[6],[[6],[[7],[3,'item']],[3,'$orig']],[3,'ID']])
Z([[2,'||'],[[2,'=='],[[7],[3,'index']],[1,0]],[[2,'>'],[[2,'-'],[[6],[[6],[[7],[3,'item']],[3,'$orig']],[3,'time']],[[6],[[6],[[7],[3,'messageList']],[[2,'-'],[[7],[3,'index']],[1,1]]],[3,'time']]],[1,180]]])
Z([3,'t-message-item'])
Z([[2,'==='],[[6],[[6],[[7],[3,'item']],[3,'$orig']],[3,'type']],[1,'TIMGroupTipElem']])
Z([3,'__l'])
Z([[6],[[7],[3,'item']],[3,'$orig']])
Z([[2,'+'],[1,'8fa16390-1-'],[[7],[3,'index']]])
Z([[2,'!=='],[[6],[[6],[[7],[3,'item']],[3,'$orig']],[3,'type']],[1,'TIMGroupTipElem']])
Z([[4],[[5],[[2,'?:'],[[2,'==='],[[6],[[6],[[7],[3,'item']],[3,'$orig']],[3,'flow']],[1,'out']],[1,'t-self-message'],[1,'t-recieve-message']]]])
Z([[2,'==='],[[6],[[6],[[7],[3,'item']],[3,'$orig']],[3,'flow']],[1,'in']])
Z([[2,'&&'],[[2,'==='],[[6],[[7],[3,'conversation']],[3,'type']],[1,'C2C']],[[2,'==='],[[6],[[6],[[7],[3,'item']],[3,'$orig']],[3,'flow']],[1,'out']]])
Z([[2,'==='],[[6],[[6],[[7],[3,'item']],[3,'$orig']],[3,'type']],[1,'TIMTextElem']])
Z(z[22])
Z([[2,'==='],[[6],[[6],[[7],[3,'item']],[3,'$orig']],[3,'flow']],[1,'out']])
Z(z[23])
Z([[2,'+'],[1,'8fa16390-2-'],[[7],[3,'index']]])
Z([[2,'==='],[[6],[[6],[[7],[3,'item']],[3,'$orig']],[3,'type']],[1,'TIMImageElem']])
Z(z[22])
Z(z[31])
Z(z[23])
Z([[2,'+'],[1,'8fa16390-3-'],[[7],[3,'index']]])
Z([[2,'==='],[[6],[[6],[[7],[3,'item']],[3,'$orig']],[3,'type']],[1,'TIMVideoFileElem']])
Z(z[22])
Z(z[31])
Z(z[23])
Z([[2,'+'],[1,'8fa16390-4-'],[[7],[3,'index']]])
Z([[2,'==='],[[6],[[6],[[7],[3,'item']],[3,'$orig']],[3,'type']],[1,'TIMSoundElem']])
Z(z[22])
Z(z[31])
Z(z[23])
Z([[2,'+'],[1,'8fa16390-5-'],[[7],[3,'index']]])
Z([[2,'==='],[[6],[[6],[[7],[3,'item']],[3,'$orig']],[3,'type']],[1,'TIMCustomElem']])
Z(z[22])
Z(z[31])
Z(z[23])
Z([[2,'+'],[1,'8fa16390-6-'],[[7],[3,'index']]])
Z([[2,'==='],[[6],[[6],[[7],[3,'item']],[3,'$orig']],[3,'type']],[1,'TIMFaceElem']])
Z(z[22])
Z(z[31])
Z(z[23])
Z([[2,'+'],[1,'8fa16390-7-'],[[7],[3,'index']]])
Z([[2,'==='],[[6],[[6],[[7],[3,'item']],[3,'$orig']],[3,'type']],[1,'TIMFileElem']])
Z(z[22])
Z(z[31])
Z(z[23])
Z([[2,'+'],[1,'8fa16390-8-'],[[7],[3,'index']]])
Z(z[31])
Z(z[22])
Z(z[23])
Z([[2,'+'],[1,'8fa16390-9-'],[[7],[3,'index']]])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_18_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_18_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_18=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_18=true;
var x=['./components/tui-chat/message-list/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_18_1()
var o8C=_mz(z,'scroll-view',['bindrefresherrefresh',0,'class',1,'data-event-opts',1,'refresherEnabled',2,'refresherTriggered',3,'scrollIntoView',4,'scrollTop',5,'scrollY',6],[],e,s,gg)
var c9C=_mz(z,'view',['id',8,'style',1],[],e,s,gg)
var o0C=_v()
_(c9C,o0C)
if(_oz(z,10,e,s,gg)){o0C.wxVkey=1
}
var lAD=_v()
_(c9C,lAD)
var aBD=function(eDD,tCD,bED,gg){
var xGD=_mz(z,'view',['class',15,'style',1],[],eDD,tCD,gg)
var oHD=_v()
_(xGD,oHD)
if(_oz(z,17,eDD,tCD,gg)){oHD.wxVkey=1
var fID=_n('view')
_rz(z,fID,'id',18,eDD,tCD,gg)
var cJD=_v()
_(fID,cJD)
if(_oz(z,19,eDD,tCD,gg)){cJD.wxVkey=1
}
var hKD=_n('view')
_rz(z,hKD,'class',20,eDD,tCD,gg)
var oLD=_v()
_(hKD,oLD)
if(_oz(z,21,eDD,tCD,gg)){oLD.wxVkey=1
var oND=_mz(z,'t-u-i-tip-message',['bind:__l',22,'message',1,'vueId',2],[],eDD,tCD,gg)
_(oLD,oND)
}
var cMD=_v()
_(hKD,cMD)
if(_oz(z,25,eDD,tCD,gg)){cMD.wxVkey=1
var lOD=_n('view')
_rz(z,lOD,'class',26,eDD,tCD,gg)
var aPD=_v()
_(lOD,aPD)
if(_oz(z,27,eDD,tCD,gg)){aPD.wxVkey=1
}
var tQD=_v()
_(lOD,tQD)
if(_oz(z,28,eDD,tCD,gg)){tQD.wxVkey=1
}
var bSD=_n('view')
var oTD=_v()
_(bSD,oTD)
if(_oz(z,29,eDD,tCD,gg)){oTD.wxVkey=1
var c1D=_mz(z,'t-u-i-text-message',['bind:__l',30,'isMine',1,'message',2,'vueId',3],[],eDD,tCD,gg)
_(oTD,c1D)
}
var xUD=_v()
_(bSD,xUD)
if(_oz(z,34,eDD,tCD,gg)){xUD.wxVkey=1
var o2D=_mz(z,'t-u-i-image-message',['bind:__l',35,'isMine',1,'message',2,'vueId',3],[],eDD,tCD,gg)
_(xUD,o2D)
}
var oVD=_v()
_(bSD,oVD)
if(_oz(z,39,eDD,tCD,gg)){oVD.wxVkey=1
var l3D=_mz(z,'t-u-i-video-message',['bind:__l',40,'isMine',1,'message',2,'vueId',3],[],eDD,tCD,gg)
_(oVD,l3D)
}
var fWD=_v()
_(bSD,fWD)
if(_oz(z,44,eDD,tCD,gg)){fWD.wxVkey=1
var a4D=_mz(z,'t-u-i-audio-message',['bind:__l',45,'isMine',1,'message',2,'vueId',3],[],eDD,tCD,gg)
_(fWD,a4D)
}
var cXD=_v()
_(bSD,cXD)
if(_oz(z,49,eDD,tCD,gg)){cXD.wxVkey=1
var t5D=_mz(z,'t-u-i-custom-message',['bind:__l',50,'isMine',1,'message',2,'vueId',3],[],eDD,tCD,gg)
_(cXD,t5D)
}
var hYD=_v()
_(bSD,hYD)
if(_oz(z,54,eDD,tCD,gg)){hYD.wxVkey=1
var e6D=_mz(z,'t-u-i-face-message',['bind:__l',55,'isMine',1,'message',2,'vueId',3],[],eDD,tCD,gg)
_(hYD,e6D)
}
var oZD=_v()
_(bSD,oZD)
if(_oz(z,59,eDD,tCD,gg)){oZD.wxVkey=1
var b7D=_mz(z,'t-u-i-file-message',['bind:__l',60,'isMine',1,'message',2,'vueId',3],[],eDD,tCD,gg)
_(oZD,b7D)
}
oTD.wxXCkey=1
oTD.wxXCkey=3
xUD.wxXCkey=1
xUD.wxXCkey=3
oVD.wxXCkey=1
oVD.wxXCkey=3
fWD.wxXCkey=1
fWD.wxXCkey=3
cXD.wxXCkey=1
cXD.wxXCkey=3
hYD.wxXCkey=1
hYD.wxXCkey=3
oZD.wxXCkey=1
oZD.wxXCkey=3
_(lOD,bSD)
var eRD=_v()
_(lOD,eRD)
if(_oz(z,64,eDD,tCD,gg)){eRD.wxVkey=1
}
aPD.wxXCkey=1
tQD.wxXCkey=1
eRD.wxXCkey=1
_(cMD,lOD)
}
oLD.wxXCkey=1
oLD.wxXCkey=3
cMD.wxXCkey=1
cMD.wxXCkey=3
_(fID,hKD)
cJD.wxXCkey=1
_(oHD,fID)
}
else{oHD.wxVkey=2
var o8D=_mz(z,'t-u-i-system-message',['bind:__l',65,'message',1,'vueId',2],[],eDD,tCD,gg)
_(oHD,o8D)
}
oHD.wxXCkey=1
oHD.wxXCkey=3
oHD.wxXCkey=3
_(bED,xGD)
return bED
}
lAD.wxXCkey=4
_2z(z,13,aBD,e,s,gg,lAD,'item','index','ID')
o0C.wxXCkey=1
_(o8C,c9C)
_(r,o8C)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_18";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_18();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/tui-chat/message-list/index.wxml'] = [$gwx_XC_18, './components/tui-chat/message-list/index.wxml'];else __wxAppCode__['components/tui-chat/message-list/index.wxml'] = $gwx_XC_18( './components/tui-chat/message-list/index.wxml' );
	;__wxRoute = "components/tui-chat/message-list/index";__wxRouteBegin = true;__wxAppCurrentFile__="components/tui-chat/message-list/index.js";define("components/tui-chat/message-list/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
(global.webpackJsonp=global.webpackJsonp||[]).push([["components/tui-chat/message-list/index"],{1062:function(e,t,n){"use strict";n.r(t);var s=n(1063),o=n(1065);for(var i in o)"default"!==i&&function(e){n.d(t,e,(function(){return o[e]}))}(i);n(1067);var a=n(17),r=Object(a.default)(o.default,s.render,s.staticRenderFns,!1,null,null,null,!1,s.components,void 0);r.options.__file="components/tui-chat/message-list/index.vue",t.default=r.exports},1063:function(e,t,n){"use strict";n.r(t);var s=n(1064);n.d(t,"render",(function(){return s.render})),n.d(t,"staticRenderFns",(function(){return s.staticRenderFns})),n.d(t,"recyclableRender",(function(){return s.recyclableRender})),n.d(t,"components",(function(){return s.components}))},1064:function(e,t,n){"use strict";n.r(t),n.d(t,"render",(function(){return s})),n.d(t,"staticRenderFns",(function(){return i})),n.d(t,"recyclableRender",(function(){return o})),n.d(t,"components",(function(){}));var s=function(){var e=this,t=(e.$createElement,e._self._c,e.__map(e.messageList,(function(t,n){return{$orig:e.__get_orig(t),g0:"@TIM#SYSTEM"!==e.conversation.type&&(0==n||t.time-e.messageList[n-1].time>180)&&t.time>e.toDayTime?e.$u.timeFormat(t.time,"今天 hh:MM"):null,g1:"@TIM#SYSTEM"===e.conversation.type||!(0==n||t.time-e.messageList[n-1].time>180)||t.time>e.toDayTime?null:e.$u.timeFormat(t.time,"mm月dd日 hh:MM")}})));e.$mp.data=Object.assign({},{$root:{l0:t}})},o=!1,i=[];s._withStripped=!0},1065:function(e,t,n){"use strict";n.r(t);var s=n(1066),o=n.n(s);for(var i in s)"default"!==i&&function(e){n.d(t,e,(function(){return s[e]}))}(i);t.default=o.a},1066:function(e,t,n){"use strict";(function(e){function s(e){return function(e){if(Array.isArray(e))return o(e)}(e)||function(e){if("undefined"!=typeof Symbol&&Symbol.iterator in Object(e))return Array.from(e)}(e)||function(e,t){if(e){if("string"==typeof e)return o(e,t);var n=Object.prototype.toString.call(e).slice(8,-1);return"Object"===n&&e.constructor&&(n=e.constructor.name),"Map"===n||"Set"===n?Array.from(e):"Arguments"===n||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)?o(e,t):void 0}}(e)||function(){throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}()}function o(e,t){(null==t||t>e.length)&&(t=e.length);for(var n=0,s=new Array(t);n<t;n++)s[n]=e[n];return s}Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var i={data:function(){return{avatar:"",userID:"",messageList:[],scrollView:"",scrollTop:0,triggered:!0,toDayTime:1655308800,nextReqMessageID:"",isCompleted:!1}},components:{TUITextMessage:function(){Promise.all([n.e("common/vendor"),n.e("components/tui-chat/message-elements/text-message/index")]).then(function(){return resolve(n(1188))}.bind(null,n)).catch(n.oe)},TUIImageMessage:function(){Promise.all([n.e("common/vendor"),n.e("components/tui-chat/message-elements/image-message/index")]).then(function(){return resolve(n(1197))}.bind(null,n)).catch(n.oe)},TUIVideoMessage:function(){n.e("components/tui-chat/message-elements/video-message/index").then(function(){return resolve(n(1204))}.bind(null,n)).catch(n.oe)},TUIAudioMessage:function(){n.e("components/tui-chat/message-elements/audio-message/index").then(function(){return resolve(n(1211))}.bind(null,n)).catch(n.oe)},TUICustomMessage:function(){n.e("components/tui-chat/message-elements/custom-message/index").then(function(){return resolve(n(1218))}.bind(null,n)).catch(n.oe)},TUITipMessage:function(){Promise.all([n.e("common/vendor"),n.e("components/tui-chat/message-elements/tip-message/index")]).then(function(){return resolve(n(1227))}.bind(null,n)).catch(n.oe)},TUISystemMessage:function(){Promise.all([n.e("common/vendor"),n.e("components/tui-chat/message-elements/system-message/index")]).then(function(){return resolve(n(1234))}.bind(null,n)).catch(n.oe)},TUIFaceMessage:function(){n.e("components/tui-chat/message-elements/face-message/index").then(function(){return resolve(n(1242))}.bind(null,n)).catch(n.oe)},TUIFileMessage:function(){n.e("components/tui-chat/message-elements/file-message/index").then(function(){return resolve(n(1249))}.bind(null,n)).catch(n.oe)}},props:{conversation:{type:Object,default:function(){}},imcIdcidChat:{type:String,default:function(){return""}}},watch:{conversation:{handler:function(e){var t=this;e.conversationID&&this.setData({conversation:e},(function(){t.getMessageList(e)}))},immediate:!0,deep:!0}},mounted:function(){var t=this;this.toDayTime=new Date((new Date).toLocaleDateString()).getTime()/1e3,e.$TUIKit.getMyProfile().then((function(e){t.avatar=e.data.avatar,t.userID=e.data.userID})),e.$TUIKit.on(e.$TUIKitEvent.MESSAGE_RECEIVED,this.$onMessageReceived,this),e.$TUIKit.on(e.$TUIKitEvent.MESSAGE_READ_BY_PEER,this.$onMessageReadByPeer,this)},destroyed:function(){e.$TUIKit.off(e.$TUIKitEvent.MESSAGE_RECEIVED,this.$onMessageReceived)},methods:{refresh:function(){var e=this;this.isCompleted?this.setData({isCompleted:!0,triggered:!1}):(this.getMessageList(this.conversation),setTimeout((function(){e.setData({triggered:!1})}),2e3))},getMessageList:function(t){var n=this;this.isCompleted||e.$TUIKit.getMessageList({conversationID:t.conversationID,nextReqMessageID:this.nextReqMessageID,count:15}).then((function(e){var o=e.data.messageList;console.log("消息列表IMres.data==",e.data,n.imcIdcidChat,t.conversationID),n.nextReqMessageID=e.data.nextReqMessageID,n.isCompleted=e.data.isCompleted,n.messageList=[].concat(s(o),s(n.messageList)),e.data.messageList.length||n.$server.sendIMautoMsg({fromUserId:n.imcIdcidChat}).then((function(e){0==e.code&&(n.chatInfo=e.data)})),n.$handleMessageRender(n.messageList,o)}))},updateMessageList:function(e){this.messageList=[].concat(s(this.messageList),[e]),this.scrollToButtom()},$onMessageReadByPeer:function(){this.setData({messageList:this.messageList})},scrollToButtom:function(){var t=this;e.createSelectorQuery().in(this).select("#message-scroll").boundingClientRect((function(e){t.$nextTick((function(){t.scrollTop=e.height}))})).exec()},$onMessageReceived:function(e){var t=this,n=[];e.data.forEach((function(e){e.conversationID===t.conversation.conversationID&&n.push(Object.assign(e))})),this.messageList=this.messageList.concat(n),this.scrollToButtom()},$handleMessageRender:function(e){var t=this;e.length>0&&(this.setData({messageList:e},(function(){})),this.$nextTick((function(){t.scrollTop=9999})))}}};t.default=i}).call(this,n(1).default)},1067:function(e,t,n){"use strict";n.r(t);var s=n(1068),o=n.n(s);for(var i in s)"default"!==i&&function(e){n.d(t,e,(function(){return s[e]}))}(i);t.default=o.a},1068:function(e,t,n){}}]),(global.webpackJsonp=global.webpackJsonp||[]).push(["components/tui-chat/message-list/index-create-component",{"components/tui-chat/message-list/index-create-component":function(e,t,n){n("1").createComponent(n(1062))}},[["components/tui-chat/message-list/index-create-component"]]]);
},{isPage:false,isComponent:true,currentFile:'components/tui-chat/message-list/index.js'});require("components/tui-chat/message-list/index.js");