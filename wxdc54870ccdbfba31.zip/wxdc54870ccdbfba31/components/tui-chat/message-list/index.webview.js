$gwx_XC_18=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_18 || [];
function gz$gwx_XC_18_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_18_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_18_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_18_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'__e'])
Z([3,'message-list-container'])
Z([[4],[[5],[[4],[[5],[[5],[1,'refresherrefresh']],[[4],[[5],[[4],[[5],[[5],[1,'refresh']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([1,true])
Z([[7],[3,'triggered']])
Z([[7],[3,'scrollView']])
Z([[7],[3,'scrollTop']])
Z([3,'true'])
Z([3,'message-scroll'])
Z([3,'width:100%;'])
Z([[7],[3,'isCompleted']])
Z([3,'no-message'])
Z([3,'没有更多啦'])
Z([3,'index'])
Z([3,'item'])
Z([[6],[[7],[3,'$root']],[3,'l0']])
Z([3,'ID'])
Z([3,'t-message'])
Z([3,'background-color:#f4f4f4;'])
Z([[2,'!=='],[[6],[[7],[3,'conversation']],[3,'type']],[1,'@TIM#SYSTEM']])
Z([[6],[[6],[[7],[3,'item']],[3,'$orig']],[3,'ID']])
Z([[2,'||'],[[2,'=='],[[7],[3,'index']],[1,0]],[[2,'>'],[[2,'-'],[[6],[[6],[[7],[3,'item']],[3,'$orig']],[3,'time']],[[6],[[6],[[7],[3,'messageList']],[[2,'-'],[[7],[3,'index']],[1,1]]],[3,'time']]],[1,180]]])
Z([3,'message-times'])
Z([a,[[2,'+'],[[2,'+'],[1,''],[[2,'?:'],[[2,'>'],[[6],[[6],[[7],[3,'item']],[3,'$orig']],[3,'time']],[[7],[3,'toDayTime']]],[[6],[[7],[3,'item']],[3,'g0']],[[6],[[7],[3,'item']],[3,'g1']]]],[1,'']]])
Z([3,'t-message-item'])
Z([[2,'==='],[[6],[[6],[[7],[3,'item']],[3,'$orig']],[3,'type']],[1,'TIMGroupTipElem']])
Z([3,'__l'])
Z([[6],[[7],[3,'item']],[3,'$orig']])
Z([[2,'+'],[1,'8fa16390-1-'],[[7],[3,'index']]])
Z([[2,'!=='],[[6],[[6],[[7],[3,'item']],[3,'$orig']],[3,'type']],[1,'TIMGroupTipElem']])
Z([[4],[[5],[[2,'?:'],[[2,'==='],[[6],[[6],[[7],[3,'item']],[3,'$orig']],[3,'flow']],[1,'out']],[1,'t-self-message'],[1,'t-recieve-message']]]])
Z([[2,'==='],[[6],[[6],[[7],[3,'item']],[3,'$orig']],[3,'flow']],[1,'in']])
Z([3,'t-message-avatar'])
Z([[2,'||'],[[6],[[6],[[7],[3,'item']],[3,'$orig']],[3,'avatar']],[1,'https://sdk-web-1252463788.cos.ap-hongkong.myqcloud.com/component/TUIKit/assets/avatar_21.png']])
Z([[2,'&&'],[[2,'==='],[[6],[[7],[3,'conversation']],[3,'type']],[1,'C2C']],[[2,'==='],[[6],[[6],[[7],[3,'item']],[3,'$orig']],[3,'flow']],[1,'out']]])
Z([3,'read-receipts'])
Z([[6],[[6],[[7],[3,'item']],[3,'$orig']],[3,'isPeerRead']])
Z([3,'已读'])
Z([3,'未读'])
Z([[2,'==='],[[6],[[6],[[7],[3,'item']],[3,'$orig']],[3,'type']],[1,'TIMTextElem']])
Z(z[26])
Z([[2,'==='],[[6],[[6],[[7],[3,'item']],[3,'$orig']],[3,'flow']],[1,'out']])
Z(z[27])
Z([[2,'+'],[1,'8fa16390-2-'],[[7],[3,'index']]])
Z([[2,'==='],[[6],[[6],[[7],[3,'item']],[3,'$orig']],[3,'type']],[1,'TIMImageElem']])
Z(z[26])
Z(z[41])
Z(z[27])
Z([[2,'+'],[1,'8fa16390-3-'],[[7],[3,'index']]])
Z([[2,'==='],[[6],[[6],[[7],[3,'item']],[3,'$orig']],[3,'type']],[1,'TIMVideoFileElem']])
Z(z[26])
Z(z[41])
Z(z[27])
Z([[2,'+'],[1,'8fa16390-4-'],[[7],[3,'index']]])
Z([[2,'==='],[[6],[[6],[[7],[3,'item']],[3,'$orig']],[3,'type']],[1,'TIMSoundElem']])
Z(z[26])
Z(z[41])
Z(z[27])
Z([[2,'+'],[1,'8fa16390-5-'],[[7],[3,'index']]])
Z([[2,'==='],[[6],[[6],[[7],[3,'item']],[3,'$orig']],[3,'type']],[1,'TIMCustomElem']])
Z(z[26])
Z(z[41])
Z(z[27])
Z([[2,'+'],[1,'8fa16390-6-'],[[7],[3,'index']]])
Z([[2,'==='],[[6],[[6],[[7],[3,'item']],[3,'$orig']],[3,'type']],[1,'TIMFaceElem']])
Z(z[26])
Z(z[41])
Z(z[27])
Z([[2,'+'],[1,'8fa16390-7-'],[[7],[3,'index']]])
Z([[2,'==='],[[6],[[6],[[7],[3,'item']],[3,'$orig']],[3,'type']],[1,'TIMFileElem']])
Z(z[26])
Z(z[41])
Z(z[27])
Z([[2,'+'],[1,'8fa16390-8-'],[[7],[3,'index']]])
Z(z[41])
Z(z[32])
Z(z[33])
Z(z[20])
Z(z[20])
Z(z[26])
Z(z[27])
Z([[2,'+'],[1,'8fa16390-9-'],[[7],[3,'index']]])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_18_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_18_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_18=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_18=true;
var x=['./components/tui-chat/message-list/index.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_18_1()
var a8N=_mz(z,'scroll-view',['bindrefresherrefresh',0,'class',1,'data-event-opts',1,'refresherEnabled',2,'refresherTriggered',3,'scrollIntoView',4,'scrollTop',5,'scrollY',6],[],e,s,gg)
var t9N=_mz(z,'view',['id',8,'style',1],[],e,s,gg)
var e0N=_v()
_(t9N,e0N)
if(_oz(z,10,e,s,gg)){e0N.wxVkey=1
var bAO=_n('view')
_rz(z,bAO,'class',11,e,s,gg)
var oBO=_oz(z,12,e,s,gg)
_(bAO,oBO)
_(e0N,bAO)
}
var xCO=_v()
_(t9N,xCO)
var oDO=function(cFO,fEO,hGO,gg){
var cIO=_mz(z,'view',['class',17,'style',1],[],cFO,fEO,gg)
var oJO=_v()
_(cIO,oJO)
if(_oz(z,19,cFO,fEO,gg)){oJO.wxVkey=1
var lKO=_n('view')
_rz(z,lKO,'id',20,cFO,fEO,gg)
var aLO=_v()
_(lKO,aLO)
if(_oz(z,21,cFO,fEO,gg)){aLO.wxVkey=1
var tMO=_n('view')
_rz(z,tMO,'class',22,cFO,fEO,gg)
var eNO=_oz(z,23,cFO,fEO,gg)
_(tMO,eNO)
_(aLO,tMO)
}
var bOO=_n('view')
_rz(z,bOO,'class',24,cFO,fEO,gg)
var oPO=_v()
_(bOO,oPO)
if(_oz(z,25,cFO,fEO,gg)){oPO.wxVkey=1
var oRO=_mz(z,'t-u-i-tip-message',['bind:__l',26,'message',1,'vueId',2],[],cFO,fEO,gg)
_(oPO,oRO)
}
var xQO=_v()
_(bOO,xQO)
if(_oz(z,29,cFO,fEO,gg)){xQO.wxVkey=1
var fSO=_n('view')
_rz(z,fSO,'class',30,cFO,fEO,gg)
var cTO=_v()
_(fSO,cTO)
if(_oz(z,31,cFO,fEO,gg)){cTO.wxVkey=1
var cWO=_mz(z,'image',['class',32,'src',1],[],cFO,fEO,gg)
_(cTO,cWO)
}
var hUO=_v()
_(fSO,hUO)
if(_oz(z,34,cFO,fEO,gg)){hUO.wxVkey=1
var oXO=_n('view')
_rz(z,oXO,'class',35,cFO,fEO,gg)
var lYO=_v()
_(oXO,lYO)
if(_oz(z,36,cFO,fEO,gg)){lYO.wxVkey=1
var aZO=_n('view')
var t1O=_oz(z,37,cFO,fEO,gg)
_(aZO,t1O)
_(lYO,aZO)
}
else{lYO.wxVkey=2
var e2O=_n('view')
var b3O=_oz(z,38,cFO,fEO,gg)
_(e2O,b3O)
_(lYO,e2O)
}
lYO.wxXCkey=1
_(hUO,oXO)
}
var o4O=_n('view')
var x5O=_v()
_(o4O,x5O)
if(_oz(z,39,cFO,fEO,gg)){x5O.wxVkey=1
var oBP=_mz(z,'t-u-i-text-message',['bind:__l',40,'isMine',1,'message',2,'vueId',3],[],cFO,fEO,gg)
_(x5O,oBP)
}
var o6O=_v()
_(o4O,o6O)
if(_oz(z,44,cFO,fEO,gg)){o6O.wxVkey=1
var lCP=_mz(z,'t-u-i-image-message',['bind:__l',45,'isMine',1,'message',2,'vueId',3],[],cFO,fEO,gg)
_(o6O,lCP)
}
var f7O=_v()
_(o4O,f7O)
if(_oz(z,49,cFO,fEO,gg)){f7O.wxVkey=1
var aDP=_mz(z,'t-u-i-video-message',['bind:__l',50,'isMine',1,'message',2,'vueId',3],[],cFO,fEO,gg)
_(f7O,aDP)
}
var c8O=_v()
_(o4O,c8O)
if(_oz(z,54,cFO,fEO,gg)){c8O.wxVkey=1
var tEP=_mz(z,'t-u-i-audio-message',['bind:__l',55,'isMine',1,'message',2,'vueId',3],[],cFO,fEO,gg)
_(c8O,tEP)
}
var h9O=_v()
_(o4O,h9O)
if(_oz(z,59,cFO,fEO,gg)){h9O.wxVkey=1
var eFP=_mz(z,'t-u-i-custom-message',['bind:__l',60,'isMine',1,'message',2,'vueId',3],[],cFO,fEO,gg)
_(h9O,eFP)
}
var o0O=_v()
_(o4O,o0O)
if(_oz(z,64,cFO,fEO,gg)){o0O.wxVkey=1
var bGP=_mz(z,'t-u-i-face-message',['bind:__l',65,'isMine',1,'message',2,'vueId',3],[],cFO,fEO,gg)
_(o0O,bGP)
}
var cAP=_v()
_(o4O,cAP)
if(_oz(z,69,cFO,fEO,gg)){cAP.wxVkey=1
var oHP=_mz(z,'t-u-i-file-message',['bind:__l',70,'isMine',1,'message',2,'vueId',3],[],cFO,fEO,gg)
_(cAP,oHP)
}
x5O.wxXCkey=1
x5O.wxXCkey=3
o6O.wxXCkey=1
o6O.wxXCkey=3
f7O.wxXCkey=1
f7O.wxXCkey=3
c8O.wxXCkey=1
c8O.wxXCkey=3
h9O.wxXCkey=1
h9O.wxXCkey=3
o0O.wxXCkey=1
o0O.wxXCkey=3
cAP.wxXCkey=1
cAP.wxXCkey=3
_(fSO,o4O)
var oVO=_v()
_(fSO,oVO)
if(_oz(z,74,cFO,fEO,gg)){oVO.wxVkey=1
var xIP=_mz(z,'image',['class',75,'src',1],[],cFO,fEO,gg)
_(oVO,xIP)
}
cTO.wxXCkey=1
hUO.wxXCkey=1
oVO.wxXCkey=1
_(xQO,fSO)
}
oPO.wxXCkey=1
oPO.wxXCkey=3
xQO.wxXCkey=1
xQO.wxXCkey=3
_(lKO,bOO)
aLO.wxXCkey=1
_(oJO,lKO)
}
else{oJO.wxVkey=2
var oJP=_mz(z,'view',['data-value',77,'id',1],[],cFO,fEO,gg)
var fKP=_mz(z,'t-u-i-system-message',['bind:__l',79,'message',1,'vueId',2],[],cFO,fEO,gg)
_(oJP,fKP)
_(oJO,oJP)
}
oJO.wxXCkey=1
oJO.wxXCkey=3
oJO.wxXCkey=3
_(hGO,cIO)
return hGO
}
xCO.wxXCkey=4
_2z(z,15,oDO,e,s,gg,xCO,'item','index','ID')
e0N.wxXCkey=1
_(a8N,t9N)
_(r,a8N)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_18";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_18();
	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/tui-chat/message-list/index.wxml'] = [$gwx_XC_18, './components/tui-chat/message-list/index.wxml'];else __wxAppCode__['components/tui-chat/message-list/index.wxml'] = $gwx_XC_18( './components/tui-chat/message-list/index.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['components/tui-chat/message-list/index.wxss'] = setCssToHead([".",[1],"message-list-container{height:100%;width:100%}\n.",[1],"t-message-item{padding:",[0,16]," 0}\n.",[1],"message-times{box-sizing:border-box;color:#777;font-size:",[0,24],";padding-top:",[0,20],";text-align:center;width:100%}\n.",[1],"t-recieve-message{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;-webkit-flex-direction:row;flex-direction:row;justify-items:flex-start;width:100vw}\n.",[1],"t-message-avatar{border-radius:",[0,10],";height:",[0,80],";margin-left:",[0,20],";margin-right:",[0,12],";width:",[0,80],"}\n.",[1],"t-self-message{display:-webkit-flex;display:flex;-webkit-flex-direction:row;flex-direction:row;-webkit-justify-content:flex-end;justify-content:flex-end;width:100vw}\n.",[1],"t-recieve-message-body,.",[1],"t-self-message-body{display:-webkit-flex;display:flex;-webkit-flex-wrap:wrap;flex-wrap:wrap;-webkit-justify-content:flex-start;justify-content:flex-start;outline:none}\n.",[1],"t-recieve-message-body{border-radius:2px 10px 10px 10px;margin-left:",[0,8],"}\n.",[1],"read-receipts{color:#6e7981;font-size:12px;height:42px;line-height:42px;margin-right:10px}\n.",[1],"no-message{color:#a5b5c1;font-size:12px;height:40px;position:fixed;right:0;text-align:center;top:-40px;width:100%}\n",],undefined,{path:"./components/tui-chat/message-list/index.wxss"});
}