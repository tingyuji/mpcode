$gwx_XC_5=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_5 || [];
function gz$gwx_XC_5_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_5_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_5_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_5_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'imageUploadContainer'])
Z([3,'imageUploadList'])
Z([3,'index'])
Z([3,'path'])
Z([[6],[[7],[3,'$root']],[3,'l0']])
Z(z[2])
Z([3,'imageItem'])
Z([[2,'!='],[[7],[3,'mediaType']],[1,3]])
Z([3,'__e'])
Z(z[8])
Z(z[8])
Z(z[8])
Z([[4],[[5],[[2,'?:'],[[6],[[7],[3,'path']],[3,'m0']],[1,'dragging'],[1,'']]]])
Z([[4],[[5],[[5],[[5],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'previewImage']],[[4],[[5],[1,'$event']]]]]]]]]],[[4],[[5],[[5],[1,'touchstart']],[[4],[[5],[[4],[[5],[[5],[1,'start']],[[4],[[5],[1,'$event']]]]]]]]]],[[4],[[5],[[5],[1,'touchmove']],[[4],[[5],[[4],[[5],[[5],[1,'move']],[[4],[[5],[1,'$event']]]]]]]]]],[[4],[[5],[[5],[1,'touchend']],[[4],[[5],[[4],[[5],[[5],[1,'stop']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([[7],[3,'index']])
Z([3,'true'])
Z([[6],[[7],[3,'path']],[3,'$orig']])
Z([[4],[[5],[[2,'?:'],[[6],[[7],[3,'path']],[3,'m1']],[1,'dragging'],[1,'']]]])
Z([1,true])
Z([3,'cover'])
Z(z[16])
Z([[7],[3,'isShowDel']])
Z(z[8])
Z([3,'imageDel'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'deleteImage']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z(z[14])
Z([3,'x'])
Z([[7],[3,'isShowAdd']])
Z(z[8])
Z([3,'imageUpload fl_cb'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'selectImage']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([3,'imageUploadTextss'])
Z([3,'+'])
Z([[7],[3,'showTextFlag']])
Z([3,'imageUploadTexts'])
Z([3,'添加图片'])
Z([[7],[3,'showMoveImage']])
Z([3,'moveImage'])
Z([[7],[3,'moveImagePath']])
Z([[2,'+'],[[2,'+'],[[2,'+'],[1,'left:'],[[7],[3,'posMoveImageLeft']]],[1,';']],[[2,'+'],[[2,'+'],[1,'top:'],[[7],[3,'posMoveImageTop']]],[1,';']]])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_5_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_5_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_5=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_5=true;
var x=['./components/robby-image-upload/robby-image-upload.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_5_1()
var fEH=_n('view')
_rz(z,fEH,'class',0,e,s,gg)
var hGH=_n('view')
_rz(z,hGH,'class',1,e,s,gg)
var cIH=_v()
_(hGH,cIH)
var oJH=function(aLH,lKH,tMH,gg){
var bOH=_n('view')
_rz(z,bOH,'class',6,aLH,lKH,gg)
var oPH=_v()
_(bOH,oPH)
if(_oz(z,7,aLH,lKH,gg)){oPH.wxVkey=1
var oRH=_mz(z,'image',['bindtap',8,'bindtouchend',1,'bindtouchstart',2,'catchtouchmove',3,'class',4,'data-event-opts',5,'data-index',6,'draggable',7,'src',8],[],aLH,lKH,gg)
_(oPH,oRH)
}
else{oPH.wxVkey=2
var fSH=_mz(z,'video',['class',17,'controls',1,'objectFit',2,'src',3],[],aLH,lKH,gg)
_(oPH,fSH)
}
var xQH=_v()
_(bOH,xQH)
if(_oz(z,21,aLH,lKH,gg)){xQH.wxVkey=1
var cTH=_mz(z,'view',['bindtap',22,'class',1,'data-event-opts',2,'data-index',3],[],aLH,lKH,gg)
var hUH=_oz(z,26,aLH,lKH,gg)
_(cTH,hUH)
_(xQH,cTH)
}
oPH.wxXCkey=1
xQH.wxXCkey=1
_(tMH,bOH)
return tMH
}
cIH.wxXCkey=2
_2z(z,4,oJH,e,s,gg,cIH,'path','index','index')
var oHH=_v()
_(hGH,oHH)
if(_oz(z,27,e,s,gg)){oHH.wxVkey=1
var oVH=_mz(z,'view',['bindtap',28,'class',1,'data-event-opts',2],[],e,s,gg)
var oXH=_n('text')
_rz(z,oXH,'class',31,e,s,gg)
var lYH=_oz(z,32,e,s,gg)
_(oXH,lYH)
_(oVH,oXH)
var cWH=_v()
_(oVH,cWH)
if(_oz(z,33,e,s,gg)){cWH.wxVkey=1
var aZH=_n('text')
_rz(z,aZH,'class',34,e,s,gg)
var t1H=_oz(z,35,e,s,gg)
_(aZH,t1H)
_(cWH,aZH)
}
cWH.wxXCkey=1
_(oHH,oVH)
}
oHH.wxXCkey=1
_(fEH,hGH)
var cFH=_v()
_(fEH,cFH)
if(_oz(z,36,e,s,gg)){cFH.wxVkey=1
var e2H=_mz(z,'image',['class',37,'src',1,'style',2],[],e,s,gg)
_(cFH,e2H)
}
cFH.wxXCkey=1
_(r,fEH)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_5";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_5();
	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/robby-image-upload/robby-image-upload.wxml'] = [$gwx_XC_5, './components/robby-image-upload/robby-image-upload.wxml'];else __wxAppCode__['components/robby-image-upload/robby-image-upload.wxml'] = $gwx_XC_5( './components/robby-image-upload/robby-image-upload.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['components/robby-image-upload/robby-image-upload.wxss'] = setCssToHead([".",[1],"imageUploadContainer{margin:",[0,10]," ",[0,5],";padding:",[0,10]," ",[0,5],"}\n.",[1],"dragging{-webkit-transform:scale(1.2);transform:scale(1.2)}\n.",[1],"imageUploadList{display:-webkit-flex;display:flex;-webkit-flex-wrap:wrap;flex-wrap:wrap}\n.",[1],"imageItem,.",[1],"imageUpload{height:",[0,160],";margin:",[0,10],";width:",[0,160],"}\n.",[1],"imageUpload{-webkit-align-items:center;align-items:center;background-color:#f7f7f7;display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column;-webkit-justify-content:center;justify-content:center}\n.",[1],"imageUploadImgs{height:",[0,80],";width:",[0,80],"}\n.",[1],"imageUploadTexts{font-size:",[0,24],"}\n.",[1],"imageUploadTextss{font-size:",[0,60],"}\n.",[1],"imageDel{background-color:rgba(0,0,0,.5);border-radius:",[0,17],";bottom:",[0,165],";color:#fff;font-size:",[0,30],";left:",[0,120],";line-height:",[0,35],";padding-bottom:",[0,2],";position:relative;text-align:center;width:",[0,36],"}\n.",[1],"imageItem wx-image,.",[1],"imageItem wx-video,.",[1],"moveImage{border-radius:",[0,8],";height:",[0,160],";width:",[0,160],"}\n.",[1],"imageUpload{border-radius:",[0,8],";color:#999;font-size:",[0,150],";text-align:center}\n.",[1],"moveImage{position:absolute}\n",],"Some selectors are not allowed in component wxss, including tag name selectors, ID selectors, and attribute selectors.(./components/robby-image-upload/robby-image-upload.wxss:1:820)",{path:"./components/robby-image-upload/robby-image-upload.wxss"});
}