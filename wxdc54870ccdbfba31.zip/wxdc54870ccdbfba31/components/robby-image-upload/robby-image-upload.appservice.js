$gwx_XC_5=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_5 || [];
function gz$gwx_XC_5_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_5_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_5_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_5_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'imageUploadContainer'])
Z([3,'imageUploadList'])
Z([3,'index'])
Z([3,'path'])
Z([[6],[[7],[3,'$root']],[3,'l0']])
Z(z[2])
Z([[7],[3,'isShowDel']])
Z([[7],[3,'isShowAdd']])
Z([3,'__e'])
Z([3,'imageUpload fl_cb'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'selectImage']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([[7],[3,'showTextFlag']])
Z([[7],[3,'showMoveImage']])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_5_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_5_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_5=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_5=true;
var x=['./components/robby-image-upload/robby-image-upload.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_5_1()
var oPB=_n('view')
_rz(z,oPB,'class',0,e,s,gg)
var aRB=_n('view')
_rz(z,aRB,'class',1,e,s,gg)
var eTB=_v()
_(aRB,eTB)
var bUB=function(xWB,oVB,oXB,gg){
var cZB=_v()
_(oXB,cZB)
if(_oz(z,6,xWB,oVB,gg)){cZB.wxVkey=1
}
cZB.wxXCkey=1
return oXB
}
eTB.wxXCkey=2
_2z(z,4,bUB,e,s,gg,eTB,'path','index','index')
var tSB=_v()
_(aRB,tSB)
if(_oz(z,7,e,s,gg)){tSB.wxVkey=1
var h1B=_mz(z,'view',['bindtap',8,'class',1,'data-event-opts',2],[],e,s,gg)
var o2B=_v()
_(h1B,o2B)
if(_oz(z,11,e,s,gg)){o2B.wxVkey=1
}
o2B.wxXCkey=1
_(tSB,h1B)
}
tSB.wxXCkey=1
_(oPB,aRB)
var lQB=_v()
_(oPB,lQB)
if(_oz(z,12,e,s,gg)){lQB.wxVkey=1
}
lQB.wxXCkey=1
_(r,oPB)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_5";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_5();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/robby-image-upload/robby-image-upload.wxml'] = [$gwx_XC_5, './components/robby-image-upload/robby-image-upload.wxml'];else __wxAppCode__['components/robby-image-upload/robby-image-upload.wxml'] = $gwx_XC_5( './components/robby-image-upload/robby-image-upload.wxml' );
	;__wxRoute = "components/robby-image-upload/robby-image-upload";__wxRouteBegin = true;__wxAppCurrentFile__="components/robby-image-upload/robby-image-upload.js";define("components/robby-image-upload/robby-image-upload.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
(global.webpackJsonp=global.webpackJsonp||[]).push([["components/robby-image-upload/robby-image-upload"],{918:function(e,t,i){"use strict";i.r(t);var a=i(919),s=i(921);for(var o in s)"default"!==o&&function(e){i.d(t,e,(function(){return s[e]}))}(o);i(923);var n=i(17),r=Object(n.default)(s.default,a.render,a.staticRenderFns,!1,null,null,null,!1,a.components,void 0);r.options.__file="components/robby-image-upload/robby-image-upload.vue",t.default=r.exports},919:function(e,t,i){"use strict";i.r(t);var a=i(920);i.d(t,"render",(function(){return a.render})),i.d(t,"staticRenderFns",(function(){return a.staticRenderFns})),i.d(t,"recyclableRender",(function(){return a.recyclableRender})),i.d(t,"components",(function(){return a.components}))},920:function(e,t,i){"use strict";i.r(t),i.d(t,"render",(function(){return a})),i.d(t,"staticRenderFns",(function(){return o})),i.d(t,"recyclableRender",(function(){return s})),i.d(t,"components",(function(){}));var a=function(){var e=this,t=(e.$createElement,e._self._c,e.__map(e.imageListData,(function(t,i){return{$orig:e.__get_orig(t),m0:3!=e.mediaType?e.isDragging(i):null,m1:3==e.mediaType?e.isDragging(i):null}})));e.$mp.data=Object.assign({},{$root:{l0:t}})},s=!1,o=[];a._withStripped=!0},921:function(e,t,i){"use strict";i.r(t);var a=i(922),s=i.n(a);for(var o in a)"default"!==o&&function(e){i.d(t,e,(function(){return a[e]}))}(o);t.default=s.a},922:function(e,t,i){"use strict";(function(e){Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var i={name:"robby-image-upload",props:["value","enableDel","enableAdd","enableDrag","serverUrl","formData","header","limit","fileKeyName","showUploadProgress","serverUrlDeleteImage","mediaT","showTextFlag","baiduOCR_flag"],data:function(){return{imageBasePos:{x0:-1,y0:-1,w:-1,h:-1},limits:this.limit,mediaType:this.mediaT,showMoveImage:!1,show_text:!this.showTextFlag||this.showTextFlag,moveImagePath:"",moveLeft:0,moveTop:0,deltaLeft:0,deltaTop:0,dragIndex:null,targetImageIndex:null,imageList:[],isDestroyed:!1,orcBase64:"",baiduOCR:!1,qiniuInfo:{imgFolderPath:"",uploadToken:"",urlPrefix:"",videoFolderPath:""}}},mounted:function(){console.log("传参==22222",this.value),this.imageList=this.value,this.qiniuInfo=e.getStorageSync("qiniuInfo"),!1===this.showUploadProgress?this.showUploadProgress=!1:this.showUploadProgress=!0,!0===this.baiduOCR_flag?this.baiduOCR=!0:this.baiduOCR=!1,console.log("baiduOCR",this.baiduOCR)},destroyed:function(){this.isDestroyed=!0},created:function(){console.log("传参==1111",this.mediaType,this.value),this.imageList=this.value,3==this.mediaType&&(this.limits=1)},computed:{imageListData:function(){if(this.value)return this.value},posMoveImageLeft:function(){return this.moveLeft+"px"},posMoveImageTop:function(){return this.moveTop+"px"},isShowDel:function(){return!1!==this.enableDel},isShowAdd:function(){return!1!==this.enableAdd&&!(this.limits&&this.imageList.length>=this.limits)},isDragable:function(){return!1!==this.enableDrag}},methods:{selectImage:function(){var t=this;t.imageList||(t.imageList=[]);var i=["image","video"];(t.imageList.length||0==t.mediaT)&&(i=["image"]);var a=["","","","","","","","",""];e.chooseMedia({count:t.limits?t.limits-t.imageList.length:9,mediaType:i,sizeType:["compressed"],success:function(i){var s=[];if("video"==i.type?(s.push(i.tempFiles[0].tempFilePath),t.limits=1,t.mediaType=3):(3==t.mediaType&&(t.mediaType=1),i.tempFiles.map((function(i){s.push(i.tempFilePath),console.log("cur.tempFilePath",i.tempFilePath),t.baiduOCR&&e.getFileSystemManager().readFile({filePath:i.tempFilePath,encoding:"base64",success:function(e){var i="data:image/jpeg;base64,"+e.data;t.orcBase64=i,t.$emit("getBase64",t.orcBase64),"function"==typeof callback&&callback(i)}})}))),t.limits){var o=t.limits-t.imageList.length;if(o<s.length)return void e.showToast({title:"图片总数限制为"+t.limits+"张，当前还可以选"+o+"张",icon:"none",mask:!1,duration:2e3})}if(t.serverUrl){e.showLoading({title:"上传中"});for(var n=t.imageList.length-s.length,r=[],l=(t.fileKeyName&&t.fileKeyName,0),g=function(i){r.push(new Promise((function(o,r){for(var g=n+i,m="."+s[i].split(".")[1],u=0;u<18;u++)a[i]+="abcdefghijkmnpqrstvwxyz1234567890".charAt(Math.floor(32*Math.random()));a[i]=t.qiniuInfo.imgFolderPath+a[i]+m,console.log("图片类型后缀==",s),e.uploadFile({url:t.serverUrl,name:"file",filePath:s[i],formData:{key:a[i],token:t.qiniuInfo.uploadToken},success:function(i){if(e.hideLoading(),200===i.statusCode){if(t.isDestroyed)return;l++,t.showUploadProgress&&e.showToast({title:"上传进度："+l+"/"+s.length,icon:"none",mask:!1,duration:500}),console.log("success to upload image: "+i.data),o(i.data)}else console.log("fail to upload image:"+i.data),r("fail to upload image:"+g)},fail:function(t){e.hideLoading(),console.log("fail to upload image:"+t),r("fail to upload image:"+g)}})})))},m=0;m<s.length;m++)g(m);Promise.all(r).then((function(e){if(!t.isDestroyed){for(var i=0;i<e.length;i++){console.log("robST==",e),JSON.parse(e[i]);var o=t.qiniuInfo.urlPrefix+a[i];t.imageList.push(o)}t.$emit("add",{currentImages:s,allImages:t.imageList}),t.$emit("input",t.imageList)}}))}else{for(var u=0;u<s.length;u++)t.imageList.push(s[u]);t.$emit("add",{currentImages:s,allImages:t.imageList}),t.$emit("input",t.imageList)}}})},deleteImage:function(t){var i=t.currentTarget.dataset.index,a=this.imageList[i];3==this.mediaType&&(this.mediaType=1,this.limits=9),this.imageList.splice(i,1),this.serverUrlDeleteImage&&e.request({url:this.serverUrlDeleteImage,method:"GET",data:{imagePath:a},success:function(e){console.log(e.data)}}),this.$emit("delete",{currentImage:a,allImages:this.imageList}),this.$emit("input",this.imageList)},previewImage:function(t){var i=t.currentTarget.dataset.index;e.previewImage({current:this.imageList[i],indicator:"number",loop:"true",urls:this.imageList})},initImageBasePos:function(){var t=this;e.getSystemInfo({success:function(e){var i=e.screenWidth,a=Math.ceil(.024*i),s=Math.ceil((i-2*a)/4);t.imageBasePos.x0=a,t.imageBasePos.w=s,t.imageBasePos.h=s}})},findOverlapImage:function(e,t){var i=Math.floor((e-this.imageBasePos.x0)/this.imageBasePos.w);return 4*Math.floor((t-this.imageBasePos.y0)/this.imageBasePos.h)+i},isDragging:function(e){return this.dragIndex===e},start:function(e){if(console.log(this.isDragable),this.isDragable){if(this.dragIndex=e.currentTarget.dataset.index,this.moveImagePath=this.imageList[this.dragIndex],this.showMoveImage=!0,-1===this.imageBasePos.y0){this.initImageBasePos();var t=Math.floor(this.dragIndex/4)*this.imageBasePos.h,i=e.currentTarget.offsetTop;this.imageBasePos.y0=i-t}this.moveLeft=e.target.offsetLeft,this.moveTop=e.target.offsetTop}},move:function(e){if(this.isDragable){var t=e.touches[0];this.targetImageIndex=this.findOverlapImage(t.clientX,t.clientY),0===this.deltaLeft&&(this.deltaLeft=t.clientX-this.moveLeft,this.deltaTop=t.clientY-this.moveTop),this.moveLeft=t.clientX-this.deltaLeft,this.moveTop=t.clientY-this.deltaTop}},stop:function(e){this.isDragable&&(null!==this.dragIndex&&null!==this.targetImageIndex&&(this.targetImageIndex<0&&(this.targetImageIndex=0),this.targetImageIndex>=this.imageList.length&&(this.targetImageIndex=this.imageList.length-1),this.dragIndex!==this.targetImageIndex&&(this.imageList[this.dragIndex]=this.imageList[this.targetImageIndex],this.imageList[this.targetImageIndex]=this.moveImagePath)),this.dragIndex=null,this.targetImageIndex=null,this.deltaLeft=0,this.deltaTop=0,this.showMoveImage=!1,this.$emit("input",this.imageList))}}};t.default=i}).call(this,i(1).default)},923:function(e,t,i){"use strict";i.r(t);var a=i(924),s=i.n(a);for(var o in a)"default"!==o&&function(e){i.d(t,e,(function(){return a[e]}))}(o);t.default=s.a},924:function(e,t,i){}}]),(global.webpackJsonp=global.webpackJsonp||[]).push(["components/robby-image-upload/robby-image-upload-create-component",{"components/robby-image-upload/robby-image-upload-create-component":function(e,t,i){i("1").createComponent(i(918))}},[["components/robby-image-upload/robby-image-upload-create-component"]]]);
},{isPage:false,isComponent:true,currentFile:'components/robby-image-upload/robby-image-upload.js'});require("components/robby-image-upload/robby-image-upload.js");