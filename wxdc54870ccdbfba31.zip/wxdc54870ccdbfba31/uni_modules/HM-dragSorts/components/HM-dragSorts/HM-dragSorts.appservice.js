$gwx_XC_45=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_45 || [];
function gz$gwx_XC_45_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_45_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_45_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_45_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'HM-drag-sort'])
Z([[2,'+'],[[2,'+'],[1,'height:'],[[2,'+'],[[7],[3,'ListHeight']],[1,'px']]],[1,';']])
Z([[6],[[7],[3,'shadowRow']],[3,'shopList']])
Z([[6],[[7],[3,'drag']],[3,'scroll']])
Z([[2,'+'],[1,'scrollView_'],[[7],[3,'guid']]])
Z([[7],[3,'scrollViewTop']])
Z([1,false])
Z([1,true])
Z(z[1])
Z([3,'listType'])
Z([3,'tmplist'])
Z([[7],[3,'dragList']])
Z(z[9])
Z([3,'index'])
Z([3,'row'])
Z([[7],[3,'tmplist']])
Z([3,'id'])
Z([3,'__e'])
Z([3,'modules'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'triggerClick']],[[4],[[5],[[5],[[7],[3,'index']]],[1,'$0']]]],[[4],[[5],[[4],[[5],[[5],[[4],[[5],[[5],[[5],[1,'dragList']],[1,'']],[[7],[3,'listType']]]]],[[4],[[5],[[5],[[5],[1,'']],[1,'id']],[[6],[[7],[3,'row']],[3,'id']]]]]]]]]]]]]]]])
Z([[6],[[7],[3,'row']],[3,'shopList']])
Z([[6],[[7],[3,'drag']],[3,'longpress']])
Z([[6],[[7],[3,'drag']],[3,'touchend']])
Z([[6],[[7],[3,'drag']],[3,'touchmove']])
Z([[6],[[7],[3,'drag']],[3,'touchstart']])
Z([3,'drag'])
Z([[6],[[7],[3,'row']],[3,'id']])
Z([[7],[3,'listType']])
Z([[2,'+'],[[2,'+'],[1,'height:'],[[2,'+'],[[7],[3,'rowHeight']],[1,'px']]],[1,';']])
Z([3,'__l'])
Z([3,'#999'])
Z([3,'list'])
Z([3,'40'])
Z([[2,'+'],[[2,'+'],[[2,'+'],[1,'6a622ba2-1-'],[[7],[3,'listType']]],[1,'-']],[[7],[3,'index']]])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_45_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_45_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_45=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_45=true;
var x=['./uni_modules/HM-dragSorts/components/HM-dragSorts/HM-dragSorts.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_45_1()
var t31=_mz(z,'view',['class',0,'style',1],[],e,s,gg)
var e41=_v()
_(t31,e41)
if(_oz(z,2,e,s,gg)){e41.wxVkey=1
}
var b51=_mz(z,'scroll-view',['bindscroll',3,'id',1,'scrollTop',2,'scrollWithAnimation',3,'scrollY',4,'style',5],[],e,s,gg)
var o61=_v()
_(b51,o61)
var x71=function(f91,o81,c01,gg){
var oB2=_v()
_(c01,oB2)
var cC2=function(lE2,oD2,aF2,gg){
var eH2=_mz(z,'view',['bindtap',17,'class',1,'data-event-opts',2],[],lE2,oD2,gg)
var bI2=_v()
_(eH2,bI2)
if(_oz(z,20,lE2,oD2,gg)){bI2.wxVkey=1
}
var oJ2=_mz(z,'view',['bindlongpress',21,'bindtouchend',1,'bindtouchmove',2,'bindtouchstart',3,'class',4,'data-id',5,'data-type',6,'style',7],[],lE2,oD2,gg)
var xK2=_mz(z,'u-icon',['bind:__l',29,'color',1,'name',2,'size',3,'vueId',4],[],lE2,oD2,gg)
_(oJ2,xK2)
_(eH2,oJ2)
bI2.wxXCkey=1
_(aF2,eH2)
return aF2
}
oB2.wxXCkey=4
_2z(z,15,cC2,f91,o81,gg,oB2,'row','index','id')
return c01
}
o61.wxXCkey=4
_2z(z,11,x71,e,s,gg,o61,'tmplist','listType','listType')
_(t31,b51)
e41.wxXCkey=1
_(r,t31)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_45";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_45();	if (__vd_version_info__.delayedGwx) __wxAppCode__['uni_modules/HM-dragSorts/components/HM-dragSorts/HM-dragSorts.wxml'] = [$gwx_XC_45, './uni_modules/HM-dragSorts/components/HM-dragSorts/HM-dragSorts.wxml'];else __wxAppCode__['uni_modules/HM-dragSorts/components/HM-dragSorts/HM-dragSorts.wxml'] = $gwx_XC_45( './uni_modules/HM-dragSorts/components/HM-dragSorts/HM-dragSorts.wxml' );
	;__wxRoute = "uni_modules/HM-dragSorts/components/HM-dragSorts/HM-dragSorts";__wxRouteBegin = true;__wxAppCurrentFile__="uni_modules/HM-dragSorts/components/HM-dragSorts/HM-dragSorts.js";define("uni_modules/HM-dragSorts/components/HM-dragSorts/HM-dragSorts.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
(global.webpackJsonp=global.webpackJsonp||[]).push([["uni_modules/HM-dragSorts/components/HM-dragSorts/HM-dragSorts"],{1114:function(t,i,e){"use strict";e.r(i);var n=e(1115),r=e(1117);for(var o in r)"default"!==o&&function(t){e.d(i,t,(function(){return r[t]}))}(o);e(1119);var s=e(17),l=e(1121),a=Object(s.default)(r.default,n.render,n.staticRenderFns,!1,null,null,null,!1,n.components,void 0);"function"==typeof l.default&&Object(l.default)(a),a.options.__file="uni_modules/HM-dragSorts/components/HM-dragSorts/HM-dragSorts.vue",i.default=a.exports},1115:function(t,i,e){"use strict";e.r(i);var n=e(1116);e.d(i,"render",(function(){return n.render})),e.d(i,"staticRenderFns",(function(){return n.staticRenderFns})),e.d(i,"recyclableRender",(function(){return n.recyclableRender})),e.d(i,"components",(function(){return n.components}))},1116:function(t,i,e){"use strict";var n;e.r(i),e.d(i,"render",(function(){return r})),e.d(i,"staticRenderFns",(function(){return s})),e.d(i,"recyclableRender",(function(){return o})),e.d(i,"components",(function(){return n}));try{n={uIcon:function(){return e.e("uview-ui/components/u-icon/u-icon").then(e.bind(null,854))}}}catch(t){if(-1===t.message.indexOf("Cannot find module")||-1===t.message.indexOf(".vue"))throw t;console.error(t.message),console.error("1. 排查组件名称拼写是否正确"),console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"),console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件")}var r=function(){this.$createElement,this._self._c},o=!1,s=[];r._withStripped=!0},1117:function(t,i,e){"use strict";e.r(i);var n=e(1118),r=e.n(n);for(var o in n)"default"!==o&&function(t){e.d(i,t,(function(){return n[t]}))}(o);i.default=r.a},1118:function(t,i,e){"use strict";(function(t){function e(t){return function(t){if(Array.isArray(t))return n(t)}(t)||function(t){if("undefined"!=typeof Symbol&&Symbol.iterator in Object(t))return Array.from(t)}(t)||function(t,i){if(t){if("string"==typeof t)return n(t,i);var e=Object.prototype.toString.call(t).slice(8,-1);return"Object"===e&&t.constructor&&(e=t.constructor.name),"Map"===e||"Set"===e?Array.from(t):"Arguments"===e||/^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(e)?n(t,i):void 0}}(t)||function(){throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")}()}function n(t,i){(null==i||i>t.length)&&(i=t.length);for(var e=0,n=new Array(i);e<i;e++)n[e]=t[e];return n}Object.defineProperty(i,"__esModule",{value:!0}),i.default=void 0;var r={name:"HM-dragSort",data:function(){return{guid:"",isAppH5:!1,shadowRow:{},dragList:{A:[],B:[]},ListHeight:this.listHeight,listSwitch:!0,scrollViewTop:0,scrollCommand:1,isHoldTouch:!1,isScrolling:!1,scrollTimer:null}},props:{feedbackGeneratorState:{value:Boolean,default:!0},isLongTouch:{value:Boolean,default:!1},isAutoScroll:{value:Boolean,default:!0},longTouchTime:{value:Number,default:300},list:{value:Array,default:[]},rowHeight:{value:Number,default:44},listHeight:{value:Number,default:0}},watch:{list:{handler:function(t){this.initList(t)},immediate:!0,deep:!0},listHeight:{handler:function(t){this.ListHeight=t},immediate:!0}},mounted:function(){0==this.listHeight&&(this.ListHeight=t.getSystemInfoSync().windowHeight),this.guid=this.getGuid()},methods:{getGuid:function(){function t(){return(65536*(1+Math.random())|0).toString(16).substring(1)}return t()+t()+"_"+t()+"_"+t()+"_"+t()+"_"+t()+t()+t()},loadShadowRow:function(t){this.shadowRow=JSON.parse(JSON.stringify(this.dragList[this.listSwitch?"A":"B"][t.rowIndex]))},initList:function(){for(var t=this,i=JSON.parse(JSON.stringify(this.list)),n=0,r=i.length;n<r;n++)i[n].hasOwnProperty("id")||(i[n].id="HMDragId_"+this.getGuid());this.dragList.A.length>0?setTimeout((function(){var n,r;(n=t.dragList.A).splice.apply(n,[0,t.dragList.A.length].concat(e(i))),(r=t.dragList.B).splice.apply(r,[0,t.dragList.B.length].concat(e(i)))}),50):(this.dragList.A=JSON.parse(JSON.stringify(i)),this.dragList.B=JSON.parse(JSON.stringify(i)))},triggerClick:function(t,i){var e=JSON.parse(JSON.stringify(i));"string"==typeof e.id&&e.id.indexOf("HMDragId_")>-1&&delete e.id,this.$emit("onclick",{index:t,value:JSON.parse(JSON.stringify(e))})},vibrate:function(){t.vibrateShort()},pageScroll:function(t){var i=this;if("up"==t.command||"down"==t.command){if(this.isHoldTouch||(this.isHoldTouch=!0,this.scrollViewTop=t.scrollTop),this.isScrolling)return;this.isScrolling=!0,null!=this.scrollTimer&&clearInterval(this.scrollTimer);var e=this.rowHeight*this.list.length+1-this.ListHeight;this.scrollTimer=setInterval((function(){"up"==t.command&&(i.scrollViewTop-=3),"down"==t.command&&(i.scrollViewTop+=3),i.scrollViewTop<0&&(i.scrollViewTop=0,clearInterval(i.scrollTimer)),i.scrollViewTop>e&&(i.scrollViewTop=e,clearInterval(i.scrollTimer))}),16.6)}"stop"==t.command&&this.isScrolling&&this.stopScroll()},stopScroll:function(){null!=this.scrollTimer&&clearInterval(this.scrollTimer),this.isScrolling=!1,this.scrollingtop=0},change:function(t){t.moveRow=JSON.parse(JSON.stringify(this.dragList[this.listSwitch?"A":"B"][t.index])),"string"==typeof t.moveRow.id&&t.moveRow.id.indexOf("HMDragId_")>-1&&delete t.moveRow.id,this.$emit("change",t)},sort:function(t){var i=this;this.stopScroll(),this.isHoldTouch=!1;var e=JSON.parse(JSON.stringify(this.dragList.A));e.splice(t.offset,0,e.splice(t.index,1)[0]);var n=JSON.parse(JSON.stringify(this.dragList.A[t.index])),r="A";this.listSwitch?(this.dragList.B=[],this.dragList.B=e):(this.dragList.A=[],this.dragList.A=e,r="B"),setTimeout((function(){i.resetList(r,e)}),50),"string"==typeof n.id&&n.id.indexOf("HMDragId_")>-1&&delete n.id;for(var o=JSON.parse(JSON.stringify(e)),s=0,l=o.length;s<l;s++)"string"==typeof o[s].id&&o[s].id.indexOf("HMDragId_")>-1&&delete o[s].id;this.$emit("confirm",{list:o,index:t.index,moveTo:t.offset,moveRow:n})},resetList:function(t,i){var e=this;this.listSwitch=!this.listSwitch,this.$nextTick((function(){e.dragList[t]=[],e.dragList[t]=i})),this.shadowRow={}}}};i.default=r}).call(this,e(1).default)},1119:function(t,i,e){"use strict";e.r(i);var n=e(1120),r=e.n(n);for(var o in n)"default"!==o&&function(t){e.d(i,t,(function(){return n[t]}))}(o);i.default=r.a},1120:function(t,i,e){},1121:function(t,i,e){"use strict";e.r(i);var n=e(1122);i.default=n.default},1122:function(t,i,e){"use strict";e.r(i),i.default=function(t){t.options.wxsCallMethods||(t.options.wxsCallMethods=[]),t.options.wxsCallMethods.push("loadShadowRow"),t.options.wxsCallMethods.push("pageScroll"),t.options.wxsCallMethods.push("sort"),t.options.wxsCallMethods.push("change"),t.options.wxsCallMethods.push("vibrate")}}}]),(global.webpackJsonp=global.webpackJsonp||[]).push(["uni_modules/HM-dragSorts/components/HM-dragSorts/HM-dragSorts-create-component",{"uni_modules/HM-dragSorts/components/HM-dragSorts/HM-dragSorts-create-component":function(t,i,e){e("1").createComponent(e(1114))}},[["uni_modules/HM-dragSorts/components/HM-dragSorts/HM-dragSorts-create-component"]]]);
},{isPage:false,isComponent:true,currentFile:'uni_modules/HM-dragSorts/components/HM-dragSorts/HM-dragSorts.js'});require("uni_modules/HM-dragSorts/components/HM-dragSorts/HM-dragSorts.js");