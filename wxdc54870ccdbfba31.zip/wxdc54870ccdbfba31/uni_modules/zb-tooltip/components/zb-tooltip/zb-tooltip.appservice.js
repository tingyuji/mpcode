$gwx_XC_46=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_46 || [];
function gz$gwx_XC_46_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_46_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_46_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_46_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'__e'])
Z([3,'zb_tooltip_content data-v-5c27e2dc'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'handleClick']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([3,'zb_tooltip__popper data-v-5c27e2dc'])
Z([[6],[[7],[3,'$root']],[3,'s0']])
Z([[6],[[7],[3,'$slots']],[3,'content']])
Z([3,'content'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_46_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_46_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_46=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_46=true;
var x=['./uni_modules/zb-tooltip/components/zb-tooltip/zb-tooltip.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_46_1()
var fM2=_mz(z,'view',['catchtap',0,'class',1,'data-event-opts',1],[],e,s,gg)
var cN2=_n('slot')
_(fM2,cN2)
var hO2=_mz(z,'view',['class',3,'style',1],[],e,s,gg)
var oP2=_v()
_(hO2,oP2)
if(_oz(z,5,e,s,gg)){oP2.wxVkey=1
var cQ2=_n('slot')
_rz(z,cQ2,'name',6,e,s,gg)
_(oP2,cQ2)
}
else{oP2.wxVkey=2
}
oP2.wxXCkey=1
_(fM2,hO2)
_(r,fM2)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_46";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_46();	if (__vd_version_info__.delayedGwx) __wxAppCode__['uni_modules/zb-tooltip/components/zb-tooltip/zb-tooltip.wxml'] = [$gwx_XC_46, './uni_modules/zb-tooltip/components/zb-tooltip/zb-tooltip.wxml'];else __wxAppCode__['uni_modules/zb-tooltip/components/zb-tooltip/zb-tooltip.wxml'] = $gwx_XC_46( './uni_modules/zb-tooltip/components/zb-tooltip/zb-tooltip.wxml' );
	;__wxRoute = "uni_modules/zb-tooltip/components/zb-tooltip/zb-tooltip";__wxRouteBegin = true;__wxAppCurrentFile__="uni_modules/zb-tooltip/components/zb-tooltip/zb-tooltip.js";define("uni_modules/zb-tooltip/components/zb-tooltip/zb-tooltip.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
(global.webpackJsonp=global.webpackJsonp||[]).push([["uni_modules/zb-tooltip/components/zb-tooltip/zb-tooltip"],{989:function(t,e,n){"use strict";n.r(e);var o=n(990),r=n(992);for(var i in r)"default"!==i&&function(t){n.d(e,t,(function(){return r[t]}))}(i);n(994);var c=n(17),a=Object(c.default)(r.default,o.render,o.staticRenderFns,!1,null,"5c27e2dc",null,!1,o.components,void 0);a.options.__file="uni_modules/zb-tooltip/components/zb-tooltip/zb-tooltip.vue",e.default=a.exports},990:function(t,e,n){"use strict";n.r(e);var o=n(991);n.d(e,"render",(function(){return o.render})),n.d(e,"staticRenderFns",(function(){return o.staticRenderFns})),n.d(e,"recyclableRender",(function(){return o.recyclableRender})),n.d(e,"components",(function(){return o.components}))},991:function(t,e,n){"use strict";n.r(e),n.d(e,"render",(function(){return o})),n.d(e,"staticRenderFns",(function(){return i})),n.d(e,"recyclableRender",(function(){return r})),n.d(e,"components",(function(){}));var o=function(){var t=this,e=(t.$createElement,t._self._c,t.__get_style([t.style,{visibility:t.isShow?"visible":"hidden",color:"white"===t.color?"":"#fff",boxShadow:"white"===t.color?"0 3px 6px -4px #0000001f, 0 6px 16px #00000014, 0 9px 28px 8px #0000000d":""}])),n=t.__get_style([t.arrowStyle]),o=t.placement.indexOf("bottom"),r=t.placement.indexOf("top"),i=t.placement.indexOf("right"),c=t.placement.indexOf("left");t.$mp.data=Object.assign({},{$root:{s0:e,s1:n,g0:o,g1:r,g2:i,g3:c}})},r=!1,i=[];o._withStripped=!0},992:function(t,e,n){"use strict";n.r(e);var o=n(993),r=n.n(o);for(var i in o)"default"!==i&&function(t){n.d(e,t,(function(){return o[t]}))}(i);e.default=r.a},993:function(t,e,n){"use strict";(function(t){Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var o=function(t){return t&&t.__esModule?t:{default:t}}(n(29));function r(t,e,n,o,r,i,c){try{var a=t[i](c),p=a.value}catch(t){return void n(t)}a.done?e(p):Promise.resolve(p).then(o,r)}var i={props:{visible:Boolean,color:{type:String,default:"#303133"},placement:{type:String,default:"top"},content:{type:String,default:""},show:{type:Boolean,default:!1}},data:function(){return{isShow:this.visible,title:"Hello",arrowLeft:0,query:null,style:{},arrowStyle:{}}},onLoad:function(){console.log("我是文字提示")},created:function(){console.log("我是文字提示222")},watch:{isShow:{handler:function(t){this.$emit("update:visible",t)},immediate:!0},visible:{handler:function(t){var e=this;this.isShow=t,t&&this.$nextTick((function(){e.handleClick()}))},immediate:!0}},mounted:function(){},methods:{close:function(){this.isShow=!1},fixedWrap:function(){this.isShow=!1},handleClick:function(){var e=this;t.createSelectorQuery().in(this).selectAll(".zb_tooltip_content,.zb_tooltip__popper").boundingClientRect(function(){var t=function(t){return function(){var e=this,n=arguments;return new Promise((function(o,i){var c=t.apply(e,n);function a(t){r(c,o,i,a,p,"next",t)}function p(t){r(c,o,i,a,p,"throw",t)}a(void 0)}))}}(o.default.mark((function t(n){var r,i,c,a,p,u;return o.default.wrap((function(t){for(;;)switch(t.prev=t.next){case 0:(r=n[0]).left,r.bottom,r.right,r.top,i=r.width,c=r.height,a=n[1],p={},u={},t.t0=e.placement,t.next="top"===t.t0?7:"top-start"===t.t0?11:"top-end"===t.t0?14:"bottom"===t.t0?18:"bottom-start"===t.t0?22:"bottom-end"===t.t0?26:"right"===t.t0?30:"right-start"===t.t0?34:"right-end"===t.t0?38:"left"===t.t0?42:"left-start"===t.t0?46:"left-end"===t.t0?50:54;break;case 7:return a.width>i?p.left="-".concat((a.width-i)/2,"px"):p.left="".concat(Math.abs(a.width-i)/2,"px"),p.bottom="".concat(c+8,"px"),u.left=a.width/2-6+"px",t.abrupt("break",54);case 11:return p.left="0px",p.bottom="".concat(c+8,"px"),t.abrupt("break",54);case 14:return p.right="0px",p.bottom="".concat(c+8,"px"),u.right="8px",t.abrupt("break",54);case 18:return a.width>i?p.left="-".concat((a.width-i)/2,"px"):p.left="".concat(Math.abs(a.width-i)/2,"px"),p.top="".concat(c+8,"px"),u.left=a.width/2-6+"px",t.abrupt("break",54);case 22:return p.left="0px",p.top="".concat(c+8,"px"),u.left="8px",t.abrupt("break",54);case 26:return p.right="0px",p.top="".concat(c+8,"px"),u.right="8px",t.abrupt("break",54);case 30:return p.left="".concat(i+8,"px"),a.height>c?p.top="-".concat((a.height-c)/2,"px"):p.top="".concat(Math.abs((a.height-c)/2),"px"),u.top="".concat(a.height/2-6,"px"),t.abrupt("break",54);case 34:return p.left="".concat(i+8,"px"),p.top="0px",u.top="8px",t.abrupt("break",54);case 38:return p.left="".concat(i+8,"px"),p.bottom="0px",u.bottom="8px",t.abrupt("break",54);case 42:return p.right="".concat(i+8,"px"),a.height>c?p.top="-".concat((a.height-c)/2,"px"):p.top="".concat(Math.abs((a.height-c)/2),"px"),u.top="".concat(a.height/2-6,"px"),t.abrupt("break",54);case 46:return p.right="".concat(i+8,"px"),p.top="0px",u.top="8px",t.abrupt("break",54);case 50:return p.right="".concat(i+8,"px"),p.bottom="0px",u.bottom="8px",t.abrupt("break",54);case 54:e.style=p,e.arrowStyle=u,e.isShow=!0;case 57:case"end":return t.stop()}}),t)})));return function(e){return t.apply(this,arguments)}}()).exec()}}};e.default=i}).call(this,n(1).default)},994:function(t,e,n){"use strict";n.r(e);var o=n(995),r=n.n(o);for(var i in o)"default"!==i&&function(t){n.d(e,t,(function(){return o[t]}))}(i);e.default=r.a},995:function(t,e,n){}}]),(global.webpackJsonp=global.webpackJsonp||[]).push(["uni_modules/zb-tooltip/components/zb-tooltip/zb-tooltip-create-component",{"uni_modules/zb-tooltip/components/zb-tooltip/zb-tooltip-create-component":function(t,e,n){n("1").createComponent(n(989))}},[["uni_modules/zb-tooltip/components/zb-tooltip/zb-tooltip-create-component"]]]);
},{isPage:false,isComponent:true,currentFile:'uni_modules/zb-tooltip/components/zb-tooltip/zb-tooltip.js'});require("uni_modules/zb-tooltip/components/zb-tooltip/zb-tooltip.js");