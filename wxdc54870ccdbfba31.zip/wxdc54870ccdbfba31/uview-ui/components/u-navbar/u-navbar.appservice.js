$gwx_XC_64=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_64 || [];
function gz$gwx_XC_64_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_64_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_64_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_64_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'data-v-1194bf80'])
Z([3,'u-navbar-inner data-v-1194bf80'])
Z([[6],[[7],[3,'$root']],[3,'s1']])
Z([[7],[3,'isBack']])
Z([3,'__e'])
Z([3,'u-back-wrap data-v-1194bf80'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'goBack']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([3,'__l'])
Z(z[0])
Z([[7],[3,'backIconColor']])
Z([[7],[3,'backIconName']])
Z([[7],[3,'backIconSize']])
Z([3,'21022e74-1'])
Z([[7],[3,'backText']])
Z([[7],[3,'title']])
Z([3,'right'])
Z([[2,'&&'],[[7],[3,'isFixed']],[[2,'!'],[[7],[3,'immersive']]]])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_64_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_64_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_64=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_64=true;
var x=['./uview-ui/components/u-navbar/u-navbar.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_64_1()
var o25=_n('view')
_rz(z,o25,'class',0,e,s,gg)
var o45=_mz(z,'view',['class',1,'style',1],[],e,s,gg)
var f55=_v()
_(o45,f55)
if(_oz(z,3,e,s,gg)){f55.wxVkey=1
var h75=_mz(z,'view',['bindtap',4,'class',1,'data-event-opts',2],[],e,s,gg)
var c95=_mz(z,'u-icon',['bind:__l',7,'class',1,'color',2,'name',3,'size',4,'vueId',5],[],e,s,gg)
_(h75,c95)
var o85=_v()
_(h75,o85)
if(_oz(z,13,e,s,gg)){o85.wxVkey=1
}
o85.wxXCkey=1
_(f55,h75)
}
var c65=_v()
_(o45,c65)
if(_oz(z,14,e,s,gg)){c65.wxVkey=1
}
var o05=_n('slot')
_(o45,o05)
var lA6=_n('slot')
_rz(z,lA6,'name',15,e,s,gg)
_(o45,lA6)
f55.wxXCkey=1
f55.wxXCkey=3
c65.wxXCkey=1
_(o25,o45)
var x35=_v()
_(o25,x35)
if(_oz(z,16,e,s,gg)){x35.wxVkey=1
}
x35.wxXCkey=1
_(r,o25)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_64";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_64();	if (__vd_version_info__.delayedGwx) __wxAppCode__['uview-ui/components/u-navbar/u-navbar.wxml'] = [$gwx_XC_64, './uview-ui/components/u-navbar/u-navbar.wxml'];else __wxAppCode__['uview-ui/components/u-navbar/u-navbar.wxml'] = $gwx_XC_64( './uview-ui/components/u-navbar/u-navbar.wxml' );
	;__wxRoute = "uview-ui/components/u-navbar/u-navbar";__wxRouteBegin = true;__wxAppCurrentFile__="uview-ui/components/u-navbar/u-navbar.js";define("uview-ui/components/u-navbar/u-navbar.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
(global.webpackJsonp=global.webpackJsonp||[]).push([["uview-ui/components/u-navbar/u-navbar"],{1123:function(t,e,n){"use strict";n.r(e);var r=n(1124),a=n(1126);for(var i in a)"default"!==i&&function(t){n.d(e,t,(function(){return a[t]}))}(i);n(1128);var o=n(17),u=Object(o.default)(a.default,r.render,r.staticRenderFns,!1,null,"1194bf80",null,!1,r.components,void 0);u.options.__file="uview-ui/components/u-navbar/u-navbar.vue",e.default=u.exports},1124:function(t,e,n){"use strict";n.r(e);var r=n(1125);n.d(e,"render",(function(){return r.render})),n.d(e,"staticRenderFns",(function(){return r.staticRenderFns})),n.d(e,"recyclableRender",(function(){return r.recyclableRender})),n.d(e,"components",(function(){return r.components}))},1125:function(t,e,n){"use strict";var r;n.r(e),n.d(e,"render",(function(){return a})),n.d(e,"staticRenderFns",(function(){return o})),n.d(e,"recyclableRender",(function(){return i})),n.d(e,"components",(function(){return r}));try{r={uIcon:function(){return n.e("uview-ui/components/u-icon/u-icon").then(n.bind(null,854))}}}catch(t){if(-1===t.message.indexOf("Cannot find module")||-1===t.message.indexOf(".vue"))throw t;console.error(t.message),console.error("1. 排查组件名称拼写是否正确"),console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"),console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件")}var a=function(){var t=this,e=(t.$createElement,t._self._c,t.__get_style([t.navbarStyle])),n=t.__get_style([t.navbarInnerStyle]),r=t.isBack&&t.backText?t.__get_style([t.backTextStyle]):null,a=t.title?t.__get_style([t.titleStyle]):null,i=t.isFixed&&!t.immersive?Number(t.navbarHeight):null;t.$mp.data=Object.assign({},{$root:{s0:e,s1:n,s2:r,s3:a,m0:i}})},i=!1,o=[];a._withStripped=!0},1126:function(t,e,n){"use strict";n.r(e);var r=n(1127),a=n.n(r);for(var i in r)"default"!==i&&function(t){n.d(e,t,(function(){return r[t]}))}(i);e.default=a.a},1127:function(t,e,n){"use strict";(function(t){Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var n,r=t.getSystemInfoSync();n=t.getMenuButtonBoundingClientRect();var a={name:"u-navbar",props:{height:{type:[String,Number],default:""},backIconColor:{type:String,default:"#606266"},backIconName:{type:String,default:"nav-back"},backIconSize:{type:[String,Number],default:"44"},backText:{type:String,default:""},backTextStyle:{type:Object,default:function(){return{color:"#606266"}}},title:{type:String,default:""},titleWidth:{type:[String,Number],default:"250"},titleColor:{type:String,default:"#606266"},titleBold:{type:Boolean,default:!1},titleSize:{type:[String,Number],default:32},isBack:{type:[Boolean,String],default:!0},background:{type:Object,default:function(){return{background:"#ffffff"}}},isFixed:{type:Boolean,default:!0},immersive:{type:Boolean,default:!1},borderBottom:{type:Boolean,default:!0},zIndex:{type:[String,Number],default:""},customBack:{type:Function,default:null}},data:function(){return{menuButtonInfo:n,statusBarHeight:r.statusBarHeight}},computed:{navbarInnerStyle:function(){var t={};t.height=this.navbarHeight+"px";var e=r.windowWidth-n.left;return t.marginRight=e+"px",t},navbarStyle:function(){var t={};return t.zIndex=this.zIndex?this.zIndex:this.$u.zIndex.navbar,Object.assign(t,this.background),t},titleStyle:function(){var e={},a=r.windowWidth-n.left;return e.left=(r.windowWidth-t.upx2px(this.titleWidth))/2+"px",e.right=a-(r.windowWidth-t.upx2px(this.titleWidth))/2+a+"px",e.width=t.upx2px(this.titleWidth)+"px",e},navbarHeight:function(){var t="ios"==r.platform?44:48;return this.height?this.height:t}},created:function(){console.log("标题==",this.title),console.log("fanhui==",this.backText)},methods:{goBack:function(){"function"==typeof this.customBack?this.customBack.bind(this.$u.$parent.call(this))():t.navigateBack()}}};e.default=a}).call(this,n(1).default)},1128:function(t,e,n){"use strict";n.r(e);var r=n(1129),a=n.n(r);for(var i in r)"default"!==i&&function(t){n.d(e,t,(function(){return r[t]}))}(i);e.default=a.a},1129:function(t,e,n){}}]),(global.webpackJsonp=global.webpackJsonp||[]).push(["uview-ui/components/u-navbar/u-navbar-create-component",{"uview-ui/components/u-navbar/u-navbar-create-component":function(t,e,n){n("1").createComponent(n(1123))}},[["uview-ui/components/u-navbar/u-navbar-create-component"]]]);
},{isPage:false,isComponent:true,currentFile:'uview-ui/components/u-navbar/u-navbar.js'});require("uview-ui/components/u-navbar/u-navbar.js");