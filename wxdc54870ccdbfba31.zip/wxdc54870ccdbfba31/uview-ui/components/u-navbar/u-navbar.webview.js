$gwx_XC_64=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_64 || [];
function gz$gwx_XC_64_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_64_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_64_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_64_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'data-v-1194bf80'])
Z([[4],[[5],[[5],[[5],[[5],[1,'u-navbar']],[1,'data-v-1194bf80']],[[2,'?:'],[[7],[3,'isFixed']],[1,'u-navbar-fixed'],[1,'']]],[[2,'?:'],[[7],[3,'borderBottom']],[1,'u-border-bottom'],[1,'']]]])
Z([[6],[[7],[3,'$root']],[3,'s0']])
Z([3,'u-status-bar data-v-1194bf80'])
Z([[2,'+'],[[2,'+'],[1,'height:'],[[2,'+'],[[7],[3,'statusBarHeight']],[1,'px']]],[1,';']])
Z([3,'u-navbar-inner data-v-1194bf80'])
Z([[6],[[7],[3,'$root']],[3,'s1']])
Z([[7],[3,'isBack']])
Z([3,'__e'])
Z([3,'u-back-wrap data-v-1194bf80'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'goBack']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([3,'u-icon-wrap data-v-1194bf80'])
Z([3,'__l'])
Z(z[0])
Z([[7],[3,'backIconColor']])
Z([[7],[3,'backIconName']])
Z([[7],[3,'backIconSize']])
Z([3,'21022e74-1'])
Z([[7],[3,'backText']])
Z([3,'u-icon-wrap u-back-text u-line-1 data-v-1194bf80'])
Z([[6],[[7],[3,'$root']],[3,'s2']])
Z([a,[[7],[3,'backText']]])
Z([[7],[3,'title']])
Z([3,'u-navbar-content-title data-v-1194bf80'])
Z([[6],[[7],[3,'$root']],[3,'s3']])
Z([3,'u-title u-line-1 data-v-1194bf80'])
Z([[2,'+'],[[2,'+'],[[2,'+'],[[2,'+'],[1,'color:'],[[7],[3,'titleColor']]],[1,';']],[[2,'+'],[[2,'+'],[1,'font-size:'],[[2,'+'],[[7],[3,'titleSize']],[1,'rpx']]],[1,';']]],[[2,'+'],[[2,'+'],[1,'font-weight:'],[[2,'?:'],[[7],[3,'titleBold']],[1,'bold'],[1,'normal']]],[1,';']]])
Z([a,[[2,'+'],[[2,'+'],[1,''],[[7],[3,'title']]],[1,'']]])
Z([3,'u-slot-content data-v-1194bf80'])
Z([3,'u-slot-right data-v-1194bf80'])
Z([3,'right'])
Z([[2,'&&'],[[7],[3,'isFixed']],[[2,'!'],[[7],[3,'immersive']]]])
Z([3,'u-navbar-placeholder data-v-1194bf80'])
Z([[2,'+'],[[2,'+'],[[2,'+'],[1,'width:'],[1,'100%']],[1,';']],[[2,'+'],[[2,'+'],[1,'height:'],[[2,'+'],[[2,'+'],[[6],[[7],[3,'$root']],[3,'m0']],[[7],[3,'statusBarHeight']]],[1,'px']]],[1,';']]])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_64_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_64_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_64=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_64=true;
var x=['./uview-ui/components/u-navbar/u-navbar.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_64_1()
var bWDD=_n('view')
_rz(z,bWDD,'class',0,e,s,gg)
var xYDD=_mz(z,'view',['class',1,'style',1],[],e,s,gg)
var oZDD=_mz(z,'view',['class',3,'style',1],[],e,s,gg)
_(xYDD,oZDD)
var f1DD=_mz(z,'view',['class',5,'style',1],[],e,s,gg)
var c2DD=_v()
_(f1DD,c2DD)
if(_oz(z,7,e,s,gg)){c2DD.wxVkey=1
var o4DD=_mz(z,'view',['bindtap',8,'class',1,'data-event-opts',2],[],e,s,gg)
var o6DD=_n('view')
_rz(z,o6DD,'class',11,e,s,gg)
var l7DD=_mz(z,'u-icon',['bind:__l',12,'class',1,'color',2,'name',3,'size',4,'vueId',5],[],e,s,gg)
_(o6DD,l7DD)
_(o4DD,o6DD)
var c5DD=_v()
_(o4DD,c5DD)
if(_oz(z,18,e,s,gg)){c5DD.wxVkey=1
var a8DD=_mz(z,'view',['class',19,'style',1],[],e,s,gg)
var t9DD=_oz(z,21,e,s,gg)
_(a8DD,t9DD)
_(c5DD,a8DD)
}
c5DD.wxXCkey=1
_(c2DD,o4DD)
}
var h3DD=_v()
_(f1DD,h3DD)
if(_oz(z,22,e,s,gg)){h3DD.wxVkey=1
var e0DD=_mz(z,'view',['class',23,'style',1],[],e,s,gg)
var bAED=_mz(z,'view',['class',25,'style',1],[],e,s,gg)
var oBED=_oz(z,27,e,s,gg)
_(bAED,oBED)
_(e0DD,bAED)
_(h3DD,e0DD)
}
var xCED=_n('view')
_rz(z,xCED,'class',28,e,s,gg)
var oDED=_n('slot')
_(xCED,oDED)
_(f1DD,xCED)
var fEED=_n('view')
_rz(z,fEED,'class',29,e,s,gg)
var cFED=_n('slot')
_rz(z,cFED,'name',30,e,s,gg)
_(fEED,cFED)
_(f1DD,fEED)
c2DD.wxXCkey=1
c2DD.wxXCkey=3
h3DD.wxXCkey=1
_(xYDD,f1DD)
_(bWDD,xYDD)
var oXDD=_v()
_(bWDD,oXDD)
if(_oz(z,31,e,s,gg)){oXDD.wxVkey=1
var hGED=_mz(z,'view',['class',32,'style',1],[],e,s,gg)
_(oXDD,hGED)
}
oXDD.wxXCkey=1
_(r,bWDD)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_64";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_64();
	if (__vd_version_info__.delayedGwx) __wxAppCode__['uview-ui/components/u-navbar/u-navbar.wxml'] = [$gwx_XC_64, './uview-ui/components/u-navbar/u-navbar.wxml'];else __wxAppCode__['uview-ui/components/u-navbar/u-navbar.wxml'] = $gwx_XC_64( './uview-ui/components/u-navbar/u-navbar.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['uview-ui/components/u-navbar/u-navbar.wxss'] = setCssToHead([".",[1],"u-navbar.",[1],"data-v-1194bf80{width:100%}\n.",[1],"u-navbar-fixed.",[1],"data-v-1194bf80{left:0;position:fixed;right:0;top:0;z-index:991}\n.",[1],"u-status-bar.",[1],"data-v-1194bf80{width:100%}\n.",[1],"u-navbar-inner.",[1],"data-v-1194bf80{-webkit-justify-content:space-between;justify-content:space-between;position:relative}\n.",[1],"u-back-wrap.",[1],"data-v-1194bf80,.",[1],"u-navbar-inner.",[1],"data-v-1194bf80{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;-webkit-flex-direction:row;flex-direction:row}\n.",[1],"u-back-wrap.",[1],"data-v-1194bf80{-webkit-flex:1;flex:1;-webkit-flex-grow:0;flex-grow:0;padding:",[0,14]," ",[0,14]," ",[0,14]," ",[0,24],"}\n.",[1],"u-back-text.",[1],"data-v-1194bf80{font-size:",[0,30],";padding-left:",[0,4],"}\n.",[1],"u-navbar-content-title.",[1],"data-v-1194bf80{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;-webkit-flex:1;flex:1;-webkit-flex-direction:row;flex-direction:row;-webkit-flex-shrink:0;flex-shrink:0;height:",[0,60],";-webkit-justify-content:center;justify-content:center;left:0;position:absolute;right:0;text-align:center}\n.",[1],"u-navbar-centent-slot.",[1],"data-v-1194bf80{-webkit-flex:1;flex:1}\n.",[1],"u-title.",[1],"data-v-1194bf80{-webkit-flex:1;flex:1;font-size:",[0,32],";line-height:",[0,60],"}\n.",[1],"u-navbar-right.",[1],"data-v-1194bf80{-webkit-justify-content:flex-end;justify-content:flex-end}\n.",[1],"u-navbar-right.",[1],"data-v-1194bf80,.",[1],"u-slot-content.",[1],"data-v-1194bf80{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;-webkit-flex:1;flex:1;-webkit-flex-direction:row;flex-direction:row}\n",],undefined,{path:"./uview-ui/components/u-navbar/u-navbar.wxss"});
}