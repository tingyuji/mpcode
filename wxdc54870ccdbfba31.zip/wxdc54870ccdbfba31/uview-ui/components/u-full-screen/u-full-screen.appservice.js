$gwx_XC_54=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_54 || [];
function gz$gwx_XC_54_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_54_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_54_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_54_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'__l'])
Z([3,'__e'])
Z(z[1])
Z(z[1])
Z([3,'data-v-3f8b28a6'])
Z([3,'升级'])
Z([[4],[[5],[[5],[[5],[[4],[[5],[[5],[1,'^cancel']],[[4],[[5],[[4],[[5],[1,'cancel']]]]]]]],[[4],[[5],[[5],[1,'^confirm']],[[4],[[5],[[4],[[5],[1,'confirm']]]]]]]],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'show']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z([1,true])
Z([3,'发现新版本'])
Z([[7],[3,'show']])
Z([3,'9c4b25c0-1'])
Z([[4],[[5],[1,'default']]])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_54_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_54_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_54=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_54=true;
var x=['./uview-ui/components/u-full-screen/u-full-screen.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_54_1()
var cA4=_mz(z,'u-modal',['bind:__l',0,'bind:cancel',1,'bind:confirm',1,'bind:input',2,'class',3,'confirmText',4,'data-event-opts',5,'showCancelButton',6,'title',7,'value',8,'vueId',9,'vueSlots',10],[],e,s,gg)
_(r,cA4)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_54";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_54();	if (__vd_version_info__.delayedGwx) __wxAppCode__['uview-ui/components/u-full-screen/u-full-screen.wxml'] = [$gwx_XC_54, './uview-ui/components/u-full-screen/u-full-screen.wxml'];else __wxAppCode__['uview-ui/components/u-full-screen/u-full-screen.wxml'] = $gwx_XC_54( './uview-ui/components/u-full-screen/u-full-screen.wxml' );
	;__wxRoute = "uview-ui/components/u-full-screen/u-full-screen";__wxRouteBegin = true;__wxAppCurrentFile__="uview-ui/components/u-full-screen/u-full-screen.js";define("uview-ui/components/u-full-screen/u-full-screen.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
(global.webpackJsonp=global.webpackJsonp||[]).push([["uview-ui/components/u-full-screen/u-full-screen"],{260:function(n,e,t){"use strict";(function(n){t(5),o(t(4));var e=o(t(261));function o(n){return n&&n.__esModule?n:{default:n}}wx.__webpack_require_UNI_MP_PLUGIN__=t,n(e.default)}).call(this,t(1).createPage)},261:function(n,e,t){"use strict";t.r(e);var o=t(262),r=t(264);for(var u in r)"default"!==u&&function(n){t.d(e,n,(function(){return r[n]}))}(u);t(266);var c=t(17),i=Object(c.default)(r.default,o.render,o.staticRenderFns,!1,null,"3f8b28a6",null,!1,o.components,void 0);i.options.__file="uview-ui/components/u-full-screen/u-full-screen.vue",e.default=i.exports},262:function(n,e,t){"use strict";t.r(e);var o=t(263);t.d(e,"render",(function(){return o.render})),t.d(e,"staticRenderFns",(function(){return o.staticRenderFns})),t.d(e,"recyclableRender",(function(){return o.recyclableRender})),t.d(e,"components",(function(){return o.components}))},263:function(n,e,t){"use strict";var o;t.r(e),t.d(e,"render",(function(){return r})),t.d(e,"staticRenderFns",(function(){return c})),t.d(e,"recyclableRender",(function(){return u})),t.d(e,"components",(function(){return o}));try{o={uModal:function(){return t.e("uview-ui/components/u-modal/u-modal").then(t.bind(null,961))}}}catch(n){if(-1===n.message.indexOf("Cannot find module")||-1===n.message.indexOf(".vue"))throw n;console.error(n.message),console.error("1. 排查组件名称拼写是否正确"),console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"),console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件")}var r=function(){this.$createElement,this._self._c},u=!1,c=[];r._withStripped=!0},264:function(n,e,t){"use strict";t.r(e);var o=t(265),r=t.n(o);for(var u in o)"default"!==u&&function(n){t.d(e,n,(function(){return o[n]}))}(u);e.default=r.a},265:function(n,e,t){"use strict";(function(n){Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var t={data:function(){return{show:!1,content:"\n\t\t\t\t1. 修复badge组件的size参数无效问题<br>\n\t\t\t\t2. 新增Modal模态框组件<br>\n\t\t\t\t3. 新增压窗屏组件，可以在APP上以弹窗的形式遮盖导航栏和底部tabbar<br>\n\t\t\t\t4. 修复键盘组件在微信小程序上遮罩无效的问题\n\t\t\t"}},onReady:function(){this.show=!0},methods:{cancel:function(){this.closeModal()},confirm:function(){this.closeModal()},closeModal:function(){n.navigateBack()}}};e.default=t}).call(this,t(1).default)},266:function(n,e,t){"use strict";t.r(e);var o=t(267),r=t.n(o);for(var u in o)"default"!==u&&function(n){t.d(e,n,(function(){return o[n]}))}(u);e.default=r.a},267:function(n,e,t){}},[[260,"common/runtime","common/vendor"]]]);
},{isPage:true,isComponent:true,currentFile:'uview-ui/components/u-full-screen/u-full-screen.js'});require("uview-ui/components/u-full-screen/u-full-screen.js");