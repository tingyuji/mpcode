$gwx_XC_72=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_72 || [];
function gz$gwx_XC_72_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_72_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_72_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_72_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'loading']])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_72_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_72_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_72=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_72=true;
var x=['./uview-ui/components/u-skeleton/u-skeleton.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_72_1()
var bI9=_v()
_(r,bI9)
if(_oz(z,0,e,s,gg)){bI9.wxVkey=1
}
bI9.wxXCkey=1
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_72";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_72();	if (__vd_version_info__.delayedGwx) __wxAppCode__['uview-ui/components/u-skeleton/u-skeleton.wxml'] = [$gwx_XC_72, './uview-ui/components/u-skeleton/u-skeleton.wxml'];else __wxAppCode__['uview-ui/components/u-skeleton/u-skeleton.wxml'] = $gwx_XC_72( './uview-ui/components/u-skeleton/u-skeleton.wxml' );
	;__wxRoute = "uview-ui/components/u-skeleton/u-skeleton";__wxRouteBegin = true;__wxAppCurrentFile__="uview-ui/components/u-skeleton/u-skeleton.js";define("uview-ui/components/u-skeleton/u-skeleton.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
(global.webpackJsonp=global.webpackJsonp||[]).push([["uview-ui/components/u-skeleton/u-skeleton"],{889:function(e,t,n){"use strict";n.r(t);var o=n(890),i=n(892);for(var u in i)"default"!==u&&function(e){n.d(t,e,(function(){return i[e]}))}(u);n(894);var r=n(17),c=Object(r.default)(i.default,o.render,o.staticRenderFns,!1,null,"cdb48440",null,!1,o.components,void 0);c.options.__file="uview-ui/components/u-skeleton/u-skeleton.vue",t.default=c.exports},890:function(e,t,n){"use strict";n.r(t);var o=n(891);n.d(t,"render",(function(){return o.render})),n.d(t,"staticRenderFns",(function(){return o.staticRenderFns})),n.d(t,"recyclableRender",(function(){return o.recyclableRender})),n.d(t,"components",(function(){return o.components}))},891:function(e,t,n){"use strict";n.r(t),n.d(t,"render",(function(){return o})),n.d(t,"staticRenderFns",(function(){return u})),n.d(t,"recyclableRender",(function(){return i})),n.d(t,"components",(function(){}));var o=function(){var e=this,t=(e.$createElement,e._self._c,e.$u.guid()),n=e.$u.guid(),o=e.$u.guid();e.$mp.data=Object.assign({},{$root:{g0:t,g1:n,g2:o}})},i=!1,u=[];o._withStripped=!0},892:function(e,t,n){"use strict";n.r(t);var o=n(893),i=n.n(o);for(var u in o)"default"!==u&&function(e){n.d(t,e,(function(){return o[e]}))}(u);t.default=i.a},893:function(e,t,n){"use strict";(function(e){Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var n={name:"u-skeleton",props:{elColor:{type:String,default:"#e5e5e5"},bgColor:{type:String,default:"#ffffff"},animation:{type:Boolean,default:!1},borderRadius:{type:[String,Number],default:"10"},loading:{type:Boolean,default:!0}},data:function(){return{windowWinth:750,windowHeight:1500,filletNodes:[],circleNodes:[],RectNodes:[],top:0,left:0}},methods:{selecterQueryInfo:function(){var t=this;e.createSelectorQuery().in(this.$parent).selectAll(".u-skeleton").boundingClientRect().exec((function(e){t.windowHeight=e[0][0].height,t.windowWinth=e[0][0].width,t.top=e[0][0].bottom-e[0][0].height,t.left=e[0][0].left})),this.getRectEls(),this.getCircleEls(),this.getFilletEls()},getRectEls:function(){var t=this;e.createSelectorQuery().in(this.$parent).selectAll(".u-skeleton-rect").boundingClientRect().exec((function(e){t.RectNodes=e[0]}))},getFilletEls:function(){var t=this;e.createSelectorQuery().in(this.$parent).selectAll(".u-skeleton-fillet").boundingClientRect().exec((function(e){t.filletNodes=e[0]}))},getCircleEls:function(){var t=this;e.createSelectorQuery().in(this.$parent).selectAll(".u-skeleton-circle").boundingClientRect().exec((function(e){t.circleNodes=e[0]}))}},mounted:function(){var t=e.getSystemInfoSync();this.windowHeight=t.windowHeight,this.windowWinth=t.windowWidth,this.selecterQueryInfo()}};t.default=n}).call(this,n(1).default)},894:function(e,t,n){"use strict";n.r(t);var o=n(895),i=n.n(o);for(var u in o)"default"!==u&&function(e){n.d(t,e,(function(){return o[e]}))}(u);t.default=i.a},895:function(e,t,n){}}]),(global.webpackJsonp=global.webpackJsonp||[]).push(["uview-ui/components/u-skeleton/u-skeleton-create-component",{"uview-ui/components/u-skeleton/u-skeleton-create-component":function(e,t,n){n("1").createComponent(n(889))}},[["uview-ui/components/u-skeleton/u-skeleton-create-component"]]]);
},{isPage:false,isComponent:true,currentFile:'uview-ui/components/u-skeleton/u-skeleton.js'});require("uview-ui/components/u-skeleton/u-skeleton.js");