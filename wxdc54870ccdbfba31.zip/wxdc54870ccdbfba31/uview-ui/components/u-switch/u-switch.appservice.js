$gwx_XC_74=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_74 || [];
function gz$gwx_XC_74_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_74_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_74_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_74_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'__e'])
Z([[4],[[5],[[5],[[5],[[5],[1,'u-switch']],[1,'data-v-7cafa8c0']],[[2,'?:'],[[2,'=='],[[7],[3,'value']],[1,true]],[1,'u-switch--on'],[1,'']]],[[2,'?:'],[[7],[3,'disabled']],[1,'u-switch--disabled'],[1,'']]]])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'onClick']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([[6],[[7],[3,'$root']],[3,'s0']])
Z([3,'__l'])
Z([3,'u-switch__loading data-v-7cafa8c0'])
Z([[7],[3,'loadingColor']])
Z([[7],[3,'loading']])
Z([[2,'*'],[[7],[3,'size']],[1,0.6]])
Z([3,'1945f046-1'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_74_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_74_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_74=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_74=true;
var x=['./uview-ui/components/u-switch/u-switch.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_74_1()
var oL9=_mz(z,'view',['bindtap',0,'class',1,'data-event-opts',1,'style',2],[],e,s,gg)
var fM9=_mz(z,'u-loading',['bind:__l',4,'class',1,'color',2,'show',3,'size',4,'vueId',5],[],e,s,gg)
_(oL9,fM9)
_(r,oL9)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_74";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_74();	if (__vd_version_info__.delayedGwx) __wxAppCode__['uview-ui/components/u-switch/u-switch.wxml'] = [$gwx_XC_74, './uview-ui/components/u-switch/u-switch.wxml'];else __wxAppCode__['uview-ui/components/u-switch/u-switch.wxml'] = $gwx_XC_74( './uview-ui/components/u-switch/u-switch.wxml' );
	;__wxRoute = "uview-ui/components/u-switch/u-switch";__wxRouteBegin = true;__wxAppCurrentFile__="uview-ui/components/u-switch/u-switch.js";define("uview-ui/components/u-switch/u-switch.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
(global.webpackJsonp=global.webpackJsonp||[]).push([["uview-ui/components/u-switch/u-switch"],{1034:function(e,t,n){"use strict";n.r(t);var o=n(1035),i=n(1037);for(var u in i)"default"!==u&&function(e){n.d(t,e,(function(){return i[e]}))}(u);n(1039);var r=n(17),a=Object(r.default)(i.default,o.render,o.staticRenderFns,!1,null,"7cafa8c0",null,!1,o.components,void 0);a.options.__file="uview-ui/components/u-switch/u-switch.vue",t.default=a.exports},1035:function(e,t,n){"use strict";n.r(t);var o=n(1036);n.d(t,"render",(function(){return o.render})),n.d(t,"staticRenderFns",(function(){return o.staticRenderFns})),n.d(t,"recyclableRender",(function(){return o.recyclableRender})),n.d(t,"components",(function(){return o.components}))},1036:function(e,t,n){"use strict";var o;n.r(t),n.d(t,"render",(function(){return i})),n.d(t,"staticRenderFns",(function(){return r})),n.d(t,"recyclableRender",(function(){return u})),n.d(t,"components",(function(){return o}));try{o={uLoading:function(){return n.e("uview-ui/components/u-loading/u-loading").then(n.bind(null,975))}}}catch(e){if(-1===e.message.indexOf("Cannot find module")||-1===e.message.indexOf(".vue"))throw e;console.error(e.message),console.error("1. 排查组件名称拼写是否正确"),console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"),console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件")}var i=function(){var e=this,t=(e.$createElement,e._self._c,e.__get_style([e.switchStyle])),n=e.$u.addUnit(this.size),o=e.$u.addUnit(this.size);e.$mp.data=Object.assign({},{$root:{s0:t,g0:n,g1:o}})},u=!1,r=[];i._withStripped=!0},1037:function(e,t,n){"use strict";n.r(t);var o=n(1038),i=n.n(o);for(var u in o)"default"!==u&&function(e){n.d(t,e,(function(){return o[e]}))}(u);t.default=i.a},1038:function(e,t,n){"use strict";(function(e){Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var n={name:"u-switch",props:{loading:{type:Boolean,default:!1},disabled:{type:Boolean,default:!1},size:{type:[Number,String],default:50},activeColor:{type:String,default:"#2979ff"},inactiveColor:{type:String,default:"#ffffff"},value:{type:Boolean,default:!1},vibrateShort:{type:Boolean,default:!1},activeValue:{type:[Number,String,Boolean],default:!0},inactiveValue:{type:[Number,String,Boolean],default:!1}},data:function(){return{}},computed:{switchStyle:function(){var e={};return e.fontSize=this.size+"rpx",e.backgroundColor=this.value?this.activeColor:this.inactiveColor,e},loadingColor:function(){return this.value?this.activeColor:null}},methods:{onClick:function(){var t=this;this.disabled||this.loading||(this.vibrateShort&&e.vibrateShort(),this.$emit("input",!this.value),this.$nextTick((function(){t.$emit("change",t.value?t.activeValue:t.inactiveValue)})))}}};t.default=n}).call(this,n(1).default)},1039:function(e,t,n){"use strict";n.r(t);var o=n(1040),i=n.n(o);for(var u in o)"default"!==u&&function(e){n.d(t,e,(function(){return o[e]}))}(u);t.default=i.a},1040:function(e,t,n){}}]),(global.webpackJsonp=global.webpackJsonp||[]).push(["uview-ui/components/u-switch/u-switch-create-component",{"uview-ui/components/u-switch/u-switch-create-component":function(e,t,n){n("1").createComponent(n(1034))}},[["uview-ui/components/u-switch/u-switch-create-component"]]]);
},{isPage:false,isComponent:true,currentFile:'uview-ui/components/u-switch/u-switch.js'});require("uview-ui/components/u-switch/u-switch.js");