$gwx_XC_48=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_48 || [];
function gz$gwx_XC_48_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_48_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_48_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_48_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'show']])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_48_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_48_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_48=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_48=true;
var x=['./uview-ui/components/u-badge/u-badge.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_48_1()
var o62=_v()
_(r,o62)
if(_oz(z,0,e,s,gg)){o62.wxVkey=1
}
o62.wxXCkey=1
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_48";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_48();	if (__vd_version_info__.delayedGwx) __wxAppCode__['uview-ui/components/u-badge/u-badge.wxml'] = [$gwx_XC_48, './uview-ui/components/u-badge/u-badge.wxml'];else __wxAppCode__['uview-ui/components/u-badge/u-badge.wxml'] = $gwx_XC_48( './uview-ui/components/u-badge/u-badge.wxml' );
	;__wxRoute = "uview-ui/components/u-badge/u-badge";__wxRouteBegin = true;__wxAppCurrentFile__="uview-ui/components/u-badge/u-badge.js";define("uview-ui/components/u-badge/u-badge.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
(global.webpackJsonp=global.webpackJsonp||[]).push([["uview-ui/components/u-badge/u-badge"],{903:function(t,e,n){"use strict";n.r(e);var o=n(904),r=n(906);for(var u in r)"default"!==u&&function(t){n.d(e,t,(function(){return r[t]}))}(u);n(908);var a=n(17),i=Object(a.default)(r.default,o.render,o.staticRenderFns,!1,null,"2b1712d8",null,!1,o.components,void 0);i.options.__file="uview-ui/components/u-badge/u-badge.vue",e.default=i.exports},904:function(t,e,n){"use strict";n.r(e);var o=n(905);n.d(e,"render",(function(){return o.render})),n.d(e,"staticRenderFns",(function(){return o.staticRenderFns})),n.d(e,"recyclableRender",(function(){return o.recyclableRender})),n.d(e,"components",(function(){return o.components}))},905:function(t,e,n){"use strict";n.r(e),n.d(e,"render",(function(){return o})),n.d(e,"staticRenderFns",(function(){return u})),n.d(e,"recyclableRender",(function(){return r})),n.d(e,"components",(function(){}));var o=function(){var t=this,e=(t.$createElement,t._self._c,t.show?t.__get_style([{top:t.offset[0]+"rpx",right:t.offset[1]+"rpx",fontSize:t.fontSize+"rpx",position:t.absolute?"absolute":"static",color:t.color,backgroundColor:t.bgColor},t.boxStyle]):null);t.$mp.data=Object.assign({},{$root:{s0:e}})},r=!1,u=[];o._withStripped=!0},906:function(t,e,n){"use strict";n.r(e);var o=n(907),r=n.n(o);for(var u in o)"default"!==u&&function(t){n.d(e,t,(function(){return o[t]}))}(u);e.default=r.a},907:function(t,e,n){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var o={name:"u-badge",props:{type:{type:String,default:"error"},size:{type:String,default:"default"},isDot:{type:Boolean,default:!1},count:{type:[Number,String]},overflowCount:{type:Number,default:99},showZero:{type:Boolean,default:!1},offset:{type:Array,default:function(){return[20,20]}},absolute:{type:Boolean,default:!0},fontSize:{type:[String,Number],default:"24"},color:{type:String,default:"#ffffff"},bgColor:{type:String,default:""},isCenter:{type:Boolean,default:!1}},computed:{boxStyle:function(){var t={};return this.isCenter?(t.top=0,t.right=0,t.transform="translateY(-50%) translateX(50%)"):(t.top=this.offset[0]+"rpx",t.right=this.offset[1]+"rpx",t.transform="translateY(0) translateX(0)"),"mini"==this.size&&(t.transform=t.transform+" scale(0.8)"),t},showText:function(){return this.isDot?"":this.count>this.overflowCount?"".concat(this.overflowCount,"+"):this.count},show:function(){return 0!=this.count||0!=this.showZero}}};e.default=o},908:function(t,e,n){"use strict";n.r(e);var o=n(909),r=n.n(o);for(var u in o)"default"!==u&&function(t){n.d(e,t,(function(){return o[t]}))}(u);e.default=r.a},909:function(t,e,n){}}]),(global.webpackJsonp=global.webpackJsonp||[]).push(["uview-ui/components/u-badge/u-badge-create-component",{"uview-ui/components/u-badge/u-badge-create-component":function(t,e,n){n("1").createComponent(n(903))}},[["uview-ui/components/u-badge/u-badge-create-component"]]]);
},{isPage:false,isComponent:true,currentFile:'uview-ui/components/u-badge/u-badge.js'});require("uview-ui/components/u-badge/u-badge.js");