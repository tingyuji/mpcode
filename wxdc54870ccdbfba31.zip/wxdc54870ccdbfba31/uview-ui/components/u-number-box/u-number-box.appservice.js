$gwx_XC_65=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_65 || [];
function gz$gwx_XC_65_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_65_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_65_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_65_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'u-numberbox data-v-a54b45c0'])
Z([3,'__e'])
Z(z[1])
Z([[4],[[5],[[5],[[5],[1,'u-icon-minus']],[1,'data-v-a54b45c0']],[[2,'?:'],[[2,'||'],[[7],[3,'disabled']],[[2,'<='],[[7],[3,'inputVal']],[[7],[3,'min']]]],[1,'u-icon-disabled'],[1,'']]]])
Z([[4],[[5],[[5],[[4],[[5],[[5],[1,'touchstart']],[[4],[[5],[[4],[[5],[[5],[1,'btnTouchStart']],[[4],[[5],[1,'minus']]]]]]]]]],[[4],[[5],[[5],[1,'touchend']],[[4],[[5],[[4],[[5],[[5],[1,'clearTimer']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([[2,'+'],[[2,'+'],[[2,'+'],[[2,'+'],[1,'background:'],[[7],[3,'bgColor']]],[1,';']],[[2,'+'],[[2,'+'],[1,'height:'],[[2,'+'],[[7],[3,'inputHeight']],[1,'rpx']]],[1,';']]],[[2,'+'],[[2,'+'],[1,'color:'],[[7],[3,'color']]],[1,';']]])
Z([3,'__l'])
Z([3,'data-v-a54b45c0'])
Z([3,'minus'])
Z([[7],[3,'size']])
Z([3,'041c7034-1'])
Z(z[1])
Z(z[1])
Z([[4],[[5],[[5],[[5],[1,'u-icon-plus']],[1,'data-v-a54b45c0']],[[2,'?:'],[[2,'||'],[[7],[3,'disabled']],[[2,'>='],[[7],[3,'inputVal']],[[7],[3,'max']]]],[1,'u-icon-disabled'],[1,'']]]])
Z([[4],[[5],[[5],[[4],[[5],[[5],[1,'touchstart']],[[4],[[5],[[4],[[5],[[5],[1,'btnTouchStart']],[[4],[[5],[1,'plus']]]]]]]]]],[[4],[[5],[[5],[1,'touchend']],[[4],[[5],[[4],[[5],[[5],[1,'clearTimer']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z(z[5])
Z(z[6])
Z(z[7])
Z([3,'plus'])
Z(z[9])
Z([3,'041c7034-2'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_65_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_65_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_65=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_65=true;
var x=['./uview-ui/components/u-number-box/u-number-box.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_65_1()
var tC6=_n('view')
_rz(z,tC6,'class',0,e,s,gg)
var eD6=_mz(z,'view',['catchtouchend',1,'catchtouchstart',1,'class',2,'data-event-opts',3,'style',4],[],e,s,gg)
var bE6=_mz(z,'u-icon',['bind:__l',6,'class',1,'name',2,'size',3,'vueId',4],[],e,s,gg)
_(eD6,bE6)
_(tC6,eD6)
var oF6=_mz(z,'view',['catchtouchend',11,'catchtouchstart',1,'class',2,'data-event-opts',3,'style',4],[],e,s,gg)
var xG6=_mz(z,'u-icon',['bind:__l',16,'class',1,'name',2,'size',3,'vueId',4],[],e,s,gg)
_(oF6,xG6)
_(tC6,oF6)
_(r,tC6)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_65";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_65();	if (__vd_version_info__.delayedGwx) __wxAppCode__['uview-ui/components/u-number-box/u-number-box.wxml'] = [$gwx_XC_65, './uview-ui/components/u-number-box/u-number-box.wxml'];else __wxAppCode__['uview-ui/components/u-number-box/u-number-box.wxml'] = $gwx_XC_65( './uview-ui/components/u-number-box/u-number-box.wxml' );
	;__wxRoute = "uview-ui/components/u-number-box/u-number-box";__wxRouteBegin = true;__wxAppCurrentFile__="uview-ui/components/u-number-box/u-number-box.js";define("uview-ui/components/u-number-box/u-number-box.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
(global.webpackJsonp=global.webpackJsonp||[]).push([["uview-ui/components/u-number-box/u-number-box"],{1003:function(t,n,e){"use strict";e.r(n);var i=e(1004),u=e(1006);for(var r in u)"default"!==r&&function(t){e.d(n,t,(function(){return u[t]}))}(r);e(1008);var o=e(17),a=Object(o.default)(u.default,i.render,i.staticRenderFns,!1,null,"a54b45c0",null,!1,i.components,void 0);a.options.__file="uview-ui/components/u-number-box/u-number-box.vue",n.default=a.exports},1004:function(t,n,e){"use strict";e.r(n);var i=e(1005);e.d(n,"render",(function(){return i.render})),e.d(n,"staticRenderFns",(function(){return i.staticRenderFns})),e.d(n,"recyclableRender",(function(){return i.recyclableRender})),e.d(n,"components",(function(){return i.components}))},1005:function(t,n,e){"use strict";var i;e.r(n),e.d(n,"render",(function(){return u})),e.d(n,"staticRenderFns",(function(){return o})),e.d(n,"recyclableRender",(function(){return r})),e.d(n,"components",(function(){return i}));try{i={uIcon:function(){return e.e("uview-ui/components/u-icon/u-icon").then(e.bind(null,854))}}}catch(t){if(-1===t.message.indexOf("Cannot find module")||-1===t.message.indexOf(".vue"))throw t;console.error(t.message),console.error("1. 排查组件名称拼写是否正确"),console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"),console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件")}var u=function(){this.$createElement,this._self._c},r=!1,o=[];u._withStripped=!0},1006:function(t,n,e){"use strict";e.r(n);var i=e(1007),u=e.n(i);for(var r in i)"default"!==r&&function(t){e.d(n,t,(function(){return i[t]}))}(r);n.default=u.a},1007:function(t,n,e){"use strict";(function(t){Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var e={name:"u-number-box",props:{value:{type:Number,default:1},bgColor:{type:String,default:"#F2F3F5"},min:{type:Number,default:0},max:{type:Number,default:99999},step:{type:Number,default:1},disabled:{type:Boolean,default:!1},size:{type:[Number,String],default:26},color:{type:String,default:"#323233"},inputWidth:{type:[Number,String],default:80},inputHeight:{type:[Number,String],default:50},index:{type:[Number,String],default:""},disabledInput:{type:Boolean,default:!1},cursorSpacing:{type:[Number,String],default:100},longPress:{type:Boolean,default:!0},pressTime:{type:[Number,String],default:250},positiveInteger:{type:Boolean,default:!0}},watch:{value:function(t,n){this.changeFromInner||(this.inputVal=t,this.$nextTick((function(){this.changeFromInner=!1})))},inputVal:function(t,n){var e=this;if(""!=t){var i=0;i=this.$u.test.number(t)&&t>=this.min&&t<=this.max?t:n,this.positiveInteger&&(t<0||-1!==String(t).indexOf("."))&&(i=n,this.$nextTick((function(){e.inputVal=n}))),this.handleChange(i,"change")}}},data:function(){return{inputVal:1,timer:null,changeFromInner:!1,innerChangeTimer:null}},created:function(){this.inputVal=Number(this.value)},computed:{getCursorSpacing:function(){return Number(t.upx2px(this.cursorSpacing))}},methods:{btnTouchStart:function(t){var n=this;this[t](),this.longPress&&(clearInterval(this.timer),this.timer=null,this.timer=setInterval((function(){n[t]()}),this.pressTime))},clearTimer:function(){var t=this;this.$nextTick((function(){clearInterval(t.timer),t.timer=null}))},minus:function(){this.computeVal("minus")},plus:function(){this.computeVal("plus")},calcPlus:function(t,n){var e,i,u;try{i=t.toString().split(".")[1].length}catch(t){i=0}try{u=n.toString().split(".")[1].length}catch(t){u=0}return((t*(e=Math.pow(10,Math.max(i,u)))+n*e)/e).toFixed(i>=u?i:u)},calcMinus:function(t,n){var e,i,u;try{i=t.toString().split(".")[1].length}catch(t){i=0}try{u=n.toString().split(".")[1].length}catch(t){u=0}return((t*(e=Math.pow(10,Math.max(i,u)))-n*e)/e).toFixed(i>=u?i:u)},computeVal:function(n){if(t.hideKeyboard(),!this.disabled){var e=0;"minus"===n?e=this.calcMinus(this.inputVal,this.step):"plus"===n&&(e=this.calcPlus(this.inputVal,this.step)),e<this.min||e>this.max||(this.inputVal=e,this.handleChange(e,n))}},onBlur:function(t){var n=this,e=0,i=t.detail.value;/(^\d+$)/.test(i)&&0!=i[0]||(e=this.min),(e=+i)>this.max?e=this.max:e<this.min&&(e=this.min),this.$nextTick((function(){n.inputVal=e})),this.handleChange(e,"blur")},onFocus:function(){this.$emit("focus")},handleChange:function(t,n){var e=this;this.disabled||(this.innerChangeTimer&&(clearTimeout(this.innerChangeTimer),this.innerChangeTimer=null),this.changeFromInner=!0,this.innerChangeTimer=setTimeout((function(){e.changeFromInner=!1}),150),this.$emit("input",Number(t)),this.$emit(n,{value:Number(t),index:this.index}))}}};n.default=e}).call(this,e(1).default)},1008:function(t,n,e){"use strict";e.r(n);var i=e(1009),u=e.n(i);for(var r in i)"default"!==r&&function(t){e.d(n,t,(function(){return i[t]}))}(r);n.default=u.a},1009:function(t,n,e){}}]),(global.webpackJsonp=global.webpackJsonp||[]).push(["uview-ui/components/u-number-box/u-number-box-create-component",{"uview-ui/components/u-number-box/u-number-box-create-component":function(t,n,e){e("1").createComponent(e(1003))}},[["uview-ui/components/u-number-box/u-number-box-create-component"]]]);
},{isPage:false,isComponent:true,currentFile:'uview-ui/components/u-number-box/u-number-box.js'});require("uview-ui/components/u-number-box/u-number-box.js");