$gwx_XC_56=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_56 || [];
function gz$gwx_XC_56_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_56_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_56_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_56_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'__e'])
Z([3,'u-image data-v-32babe48'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'onClick']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([[6],[[7],[3,'$root']],[3,'s0']])
Z([[2,'!'],[[7],[3,'isError']]])
Z(z[0])
Z(z[0])
Z([3,'u-image__image data-v-32babe48'])
Z([[4],[[5],[[5],[[4],[[5],[[5],[1,'error']],[[4],[[5],[[4],[[5],[[5],[1,'onErrorHandler']],[[4],[[5],[1,'$event']]]]]]]]]],[[4],[[5],[[5],[1,'load']],[[4],[[5],[[4],[[5],[[5],[1,'onLoadHandler']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([[7],[3,'lazyLoad']])
Z([[7],[3,'mode']])
Z([[7],[3,'showMenuByLongpress']])
Z([[7],[3,'src']])
Z([[2,'+'],[[2,'+'],[1,'border-radius:'],[[2,'?:'],[[2,'=='],[[7],[3,'shape']],[1,'circle']],[1,'50%'],[[6],[[7],[3,'$root']],[3,'g0']]]],[1,';']])
Z([[2,'&&'],[[7],[3,'showLoading']],[[7],[3,'loading']]])
Z([3,'u-image__loading data-v-32babe48'])
Z([[2,'+'],[[2,'+'],[[2,'+'],[1,'border-radius:'],[[2,'?:'],[[2,'=='],[[7],[3,'shape']],[1,'circle']],[1,'50%'],[[6],[[7],[3,'$root']],[3,'g1']]]],[1,';']],[[2,'+'],[[2,'+'],[1,'background-color:'],[[6],[[7],[3,'this']],[3,'bgColor']]],[1,';']]])
Z([[6],[[7],[3,'$slots']],[3,'loading']])
Z([3,'loading'])
Z([3,'__l'])
Z([3,'data-v-32babe48'])
Z([[7],[3,'height']])
Z([[7],[3,'loadingIcon']])
Z([3,'249d8bbe-1'])
Z([[7],[3,'width']])
Z([[2,'&&'],[[2,'&&'],[[7],[3,'showError']],[[7],[3,'isError']]],[[2,'!'],[[7],[3,'loading']]]])
Z([3,'u-image__error data-v-32babe48'])
Z([[2,'+'],[[2,'+'],[1,'border-radius:'],[[2,'?:'],[[2,'=='],[[7],[3,'shape']],[1,'circle']],[1,'50%'],[[6],[[7],[3,'$root']],[3,'g2']]]],[1,';']])
Z([[6],[[7],[3,'$slots']],[3,'error']])
Z([3,'error'])
Z(z[19])
Z(z[20])
Z(z[21])
Z([[7],[3,'errorIcon']])
Z([3,'249d8bbe-2'])
Z(z[24])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_56_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_56_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_56=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_56=true;
var x=['./uview-ui/components/u-image/u-image.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_56_1()
var hQBD=_mz(z,'view',['bindtap',0,'class',1,'data-event-opts',1,'style',2],[],e,s,gg)
var oRBD=_v()
_(hQBD,oRBD)
if(_oz(z,4,e,s,gg)){oRBD.wxVkey=1
var lUBD=_mz(z,'image',['binderror',5,'bindload',1,'class',2,'data-event-opts',3,'lazyLoad',4,'mode',5,'showMenuByLongpress',6,'src',7,'style',8],[],e,s,gg)
_(oRBD,lUBD)
}
var cSBD=_v()
_(hQBD,cSBD)
if(_oz(z,14,e,s,gg)){cSBD.wxVkey=1
var aVBD=_mz(z,'view',['class',15,'style',1],[],e,s,gg)
var tWBD=_v()
_(aVBD,tWBD)
if(_oz(z,17,e,s,gg)){tWBD.wxVkey=1
var eXBD=_n('slot')
_rz(z,eXBD,'name',18,e,s,gg)
_(tWBD,eXBD)
}
else{tWBD.wxVkey=2
var bYBD=_mz(z,'u-icon',['bind:__l',19,'class',1,'height',2,'name',3,'vueId',4,'width',5],[],e,s,gg)
_(tWBD,bYBD)
}
tWBD.wxXCkey=1
tWBD.wxXCkey=3
_(cSBD,aVBD)
}
var oTBD=_v()
_(hQBD,oTBD)
if(_oz(z,25,e,s,gg)){oTBD.wxVkey=1
var oZBD=_mz(z,'view',['class',26,'style',1],[],e,s,gg)
var x1BD=_v()
_(oZBD,x1BD)
if(_oz(z,28,e,s,gg)){x1BD.wxVkey=1
var o2BD=_n('slot')
_rz(z,o2BD,'name',29,e,s,gg)
_(x1BD,o2BD)
}
else{x1BD.wxVkey=2
var f3BD=_mz(z,'u-icon',['bind:__l',30,'class',1,'height',2,'name',3,'vueId',4,'width',5],[],e,s,gg)
_(x1BD,f3BD)
}
x1BD.wxXCkey=1
x1BD.wxXCkey=3
_(oTBD,oZBD)
}
oRBD.wxXCkey=1
cSBD.wxXCkey=1
cSBD.wxXCkey=3
oTBD.wxXCkey=1
oTBD.wxXCkey=3
_(r,hQBD)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_56";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_56();
	if (__vd_version_info__.delayedGwx) __wxAppCode__['uview-ui/components/u-image/u-image.wxml'] = [$gwx_XC_56, './uview-ui/components/u-image/u-image.wxml'];else __wxAppCode__['uview-ui/components/u-image/u-image.wxml'] = $gwx_XC_56( './uview-ui/components/u-image/u-image.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['uview-ui/components/u-image/u-image.wxss'] = setCssToHead([".",[1],"u-image.",[1],"data-v-32babe48{position:relative;transition:opacity .5s ease-in-out}\n.",[1],"u-image__image.",[1],"data-v-32babe48{height:100%;width:100%}\n.",[1],"u-image__error.",[1],"data-v-32babe48,.",[1],"u-image__loading.",[1],"data-v-32babe48{-webkit-align-items:center;align-items:center;background-color:#f3f4f6;color:#909399;display:-webkit-flex;display:flex;-webkit-flex-direction:row;flex-direction:row;font-size:",[0,46],";height:100%;-webkit-justify-content:center;justify-content:center;left:0;position:absolute;top:0;width:100%}\n",],undefined,{path:"./uview-ui/components/u-image/u-image.wxss"});
}