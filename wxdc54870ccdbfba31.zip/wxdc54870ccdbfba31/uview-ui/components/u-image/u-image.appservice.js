$gwx_XC_56=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_56 || [];
function gz$gwx_XC_56_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_56_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_56_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_56_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'__e'])
Z([3,'u-image data-v-32babe48'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'onClick']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([[6],[[7],[3,'$root']],[3,'s0']])
Z([[2,'!'],[[7],[3,'isError']]])
Z([[2,'&&'],[[7],[3,'showLoading']],[[7],[3,'loading']]])
Z([3,'u-image__loading data-v-32babe48'])
Z([[2,'+'],[[2,'+'],[[2,'+'],[1,'border-radius:'],[[2,'?:'],[[2,'=='],[[7],[3,'shape']],[1,'circle']],[1,'50%'],[[6],[[7],[3,'$root']],[3,'g1']]]],[1,';']],[[2,'+'],[[2,'+'],[1,'background-color:'],[[6],[[7],[3,'this']],[3,'bgColor']]],[1,';']]])
Z([[6],[[7],[3,'$slots']],[3,'loading']])
Z([3,'loading'])
Z([3,'__l'])
Z([3,'data-v-32babe48'])
Z([[7],[3,'height']])
Z([[7],[3,'loadingIcon']])
Z([3,'249d8bbe-1'])
Z([[7],[3,'width']])
Z([[2,'&&'],[[2,'&&'],[[7],[3,'showError']],[[7],[3,'isError']]],[[2,'!'],[[7],[3,'loading']]]])
Z([3,'u-image__error data-v-32babe48'])
Z([[2,'+'],[[2,'+'],[1,'border-radius:'],[[2,'?:'],[[2,'=='],[[7],[3,'shape']],[1,'circle']],[1,'50%'],[[6],[[7],[3,'$root']],[3,'g2']]]],[1,';']])
Z([[6],[[7],[3,'$slots']],[3,'error']])
Z([3,'error'])
Z(z[10])
Z(z[11])
Z(z[12])
Z([[7],[3,'errorIcon']])
Z([3,'249d8bbe-2'])
Z(z[15])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_56_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_56_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_56=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_56=true;
var x=['./uview-ui/components/u-image/u-image.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_56_1()
var xI4=_mz(z,'view',['bindtap',0,'class',1,'data-event-opts',1,'style',2],[],e,s,gg)
var oJ4=_v()
_(xI4,oJ4)
if(_oz(z,4,e,s,gg)){oJ4.wxVkey=1
}
var fK4=_v()
_(xI4,fK4)
if(_oz(z,5,e,s,gg)){fK4.wxVkey=1
var hM4=_mz(z,'view',['class',6,'style',1],[],e,s,gg)
var oN4=_v()
_(hM4,oN4)
if(_oz(z,8,e,s,gg)){oN4.wxVkey=1
var cO4=_n('slot')
_rz(z,cO4,'name',9,e,s,gg)
_(oN4,cO4)
}
else{oN4.wxVkey=2
var oP4=_mz(z,'u-icon',['bind:__l',10,'class',1,'height',2,'name',3,'vueId',4,'width',5],[],e,s,gg)
_(oN4,oP4)
}
oN4.wxXCkey=1
oN4.wxXCkey=3
_(fK4,hM4)
}
var cL4=_v()
_(xI4,cL4)
if(_oz(z,16,e,s,gg)){cL4.wxVkey=1
var lQ4=_mz(z,'view',['class',17,'style',1],[],e,s,gg)
var aR4=_v()
_(lQ4,aR4)
if(_oz(z,19,e,s,gg)){aR4.wxVkey=1
var tS4=_n('slot')
_rz(z,tS4,'name',20,e,s,gg)
_(aR4,tS4)
}
else{aR4.wxVkey=2
var eT4=_mz(z,'u-icon',['bind:__l',21,'class',1,'height',2,'name',3,'vueId',4,'width',5],[],e,s,gg)
_(aR4,eT4)
}
aR4.wxXCkey=1
aR4.wxXCkey=3
_(cL4,lQ4)
}
oJ4.wxXCkey=1
fK4.wxXCkey=1
fK4.wxXCkey=3
cL4.wxXCkey=1
cL4.wxXCkey=3
_(r,xI4)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_56";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_56();	if (__vd_version_info__.delayedGwx) __wxAppCode__['uview-ui/components/u-image/u-image.wxml'] = [$gwx_XC_56, './uview-ui/components/u-image/u-image.wxml'];else __wxAppCode__['uview-ui/components/u-image/u-image.wxml'] = $gwx_XC_56( './uview-ui/components/u-image/u-image.wxml' );
	;__wxRoute = "uview-ui/components/u-image/u-image";__wxRouteBegin = true;__wxAppCurrentFile__="uview-ui/components/u-image/u-image.js";define("uview-ui/components/u-image/u-image.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
(global.webpackJsonp=global.webpackJsonp||[]).push([["uview-ui/components/u-image/u-image"],{968:function(e,t,n){"use strict";n.r(t);var o=n(969),r=n(971);for(var i in r)"default"!==i&&function(e){n.d(t,e,(function(){return r[e]}))}(i);n(973);var a=n(17),u=Object(a.default)(r.default,o.render,o.staticRenderFns,!1,null,"32babe48",null,!1,o.components,void 0);u.options.__file="uview-ui/components/u-image/u-image.vue",t.default=u.exports},969:function(e,t,n){"use strict";n.r(t);var o=n(970);n.d(t,"render",(function(){return o.render})),n.d(t,"staticRenderFns",(function(){return o.staticRenderFns})),n.d(t,"recyclableRender",(function(){return o.recyclableRender})),n.d(t,"components",(function(){return o.components}))},970:function(e,t,n){"use strict";var o;n.r(t),n.d(t,"render",(function(){return r})),n.d(t,"staticRenderFns",(function(){return a})),n.d(t,"recyclableRender",(function(){return i})),n.d(t,"components",(function(){return o}));try{o={uIcon:function(){return n.e("uview-ui/components/u-icon/u-icon").then(n.bind(null,854))}}}catch(e){if(-1===e.message.indexOf("Cannot find module")||-1===e.message.indexOf(".vue"))throw e;console.error(e.message),console.error("1. 排查组件名称拼写是否正确"),console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"),console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件")}var r=function(){var e=this,t=(e.$createElement,e._self._c,e.__get_style([e.wrapStyle,e.backgroundStyle])),n=e.isError||"circle"==e.shape?null:e.$u.addUnit(e.borderRadius),o=e.showLoading&&e.loading&&"circle"!=e.shape?e.$u.addUnit(e.borderRadius):null,r=e.showError&&e.isError&&!e.loading&&"circle"!=e.shape?e.$u.addUnit(e.borderRadius):null;e.$mp.data=Object.assign({},{$root:{s0:t,g0:n,g1:o,g2:r}})},i=!1,a=[];r._withStripped=!0},971:function(e,t,n){"use strict";n.r(t);var o=n(972),r=n.n(o);for(var i in o)"default"!==i&&function(e){n.d(t,e,(function(){return o[e]}))}(i);t.default=r.a},972:function(e,t,n){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var o={name:"u-image",props:{src:{type:String,default:""},mode:{type:String,default:"aspectFill"},width:{type:[String,Number],default:"100%"},height:{type:[String,Number],default:"auto"},shape:{type:String,default:"square"},borderRadius:{type:[String,Number],default:0},lazyLoad:{type:Boolean,default:!0},showMenuByLongpress:{type:Boolean,default:!0},loadingIcon:{type:String,default:"photo"},errorIcon:{type:String,default:"error-circle"},showLoading:{type:Boolean,default:!0},showError:{type:Boolean,default:!0},fade:{type:Boolean,default:!0},webp:{type:Boolean,default:!1},duration:{type:[String,Number],default:500},bgColor:{type:String,default:"#f3f4f6"}},data:function(){return{isError:!1,loading:!0,opacity:1,durationTime:this.duration,backgroundStyle:{}}},watch:{src:{immediate:!0,handler:function(e){e?this.isError=!1:(this.isError=!0,this.loading=!1)}}},computed:{wrapStyle:function(){var e={};return e.width=this.$u.addUnit(this.width),e.height=this.$u.addUnit(this.height),e.borderRadius="circle"==this.shape?"50%":this.$u.addUnit(this.borderRadius),e.overflow=this.borderRadius>0?"hidden":"visible",this.fade&&(e.opacity=this.opacity,e.transition="opacity ".concat(Number(this.durationTime)/1e3,"s ease-in-out")),e}},methods:{onClick:function(){this.$emit("click")},onErrorHandler:function(e){this.loading=!1,this.isError=!0,this.$emit("error",e)},onLoadHandler:function(){var e=this;if(this.loading=!1,this.isError=!1,this.$emit("load"),!this.fade)return this.removeBgColor();this.opacity=0,this.durationTime=0,setTimeout((function(){e.durationTime=e.duration,e.opacity=1,setTimeout((function(){e.removeBgColor()}),e.durationTime)}),50)},removeBgColor:function(){this.backgroundStyle={backgroundColor:"transparent"}}}};t.default=o},973:function(e,t,n){"use strict";n.r(t);var o=n(974),r=n.n(o);for(var i in o)"default"!==i&&function(e){n.d(t,e,(function(){return o[e]}))}(i);t.default=r.a},974:function(e,t,n){}}]),(global.webpackJsonp=global.webpackJsonp||[]).push(["uview-ui/components/u-image/u-image-create-component",{"uview-ui/components/u-image/u-image-create-component":function(e,t,n){n("1").createComponent(n(968))}},[["uview-ui/components/u-image/u-image-create-component"]]]);
},{isPage:false,isComponent:true,currentFile:'uview-ui/components/u-image/u-image.js'});require("uview-ui/components/u-image/u-image.js");