$gwx_XC_68=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_68 || [];
function gz$gwx_XC_68_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_68_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_68_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_68_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_68_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_68_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_68=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_68=true;
var x=['./uview-ui/components/u-radio-group/u-radio-group.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_68_1()
var a28=_n('slot')
_(r,a28)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_68";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_68();	if (__vd_version_info__.delayedGwx) __wxAppCode__['uview-ui/components/u-radio-group/u-radio-group.wxml'] = [$gwx_XC_68, './uview-ui/components/u-radio-group/u-radio-group.wxml'];else __wxAppCode__['uview-ui/components/u-radio-group/u-radio-group.wxml'] = $gwx_XC_68( './uview-ui/components/u-radio-group/u-radio-group.wxml' );
	;__wxRoute = "uview-ui/components/u-radio-group/u-radio-group";__wxRouteBegin = true;__wxAppCurrentFile__="uview-ui/components/u-radio-group/u-radio-group.js";define("uview-ui/components/u-radio-group/u-radio-group.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
(global.webpackJsonp=global.webpackJsonp||[]).push([["uview-ui/components/u-radio-group/u-radio-group"],{1076:function(e,t,n){"use strict";n.r(t);var r=n(1077),u=n(1079);for(var i in u)"default"!==i&&function(e){n.d(t,e,(function(){return u[e]}))}(i);n(1081);var o=n(17),a=Object(o.default)(u.default,r.render,r.staticRenderFns,!1,null,"dd868428",null,!1,r.components,void 0);a.options.__file="uview-ui/components/u-radio-group/u-radio-group.vue",t.default=a.exports},1077:function(e,t,n){"use strict";n.r(t);var r=n(1078);n.d(t,"render",(function(){return r.render})),n.d(t,"staticRenderFns",(function(){return r.staticRenderFns})),n.d(t,"recyclableRender",(function(){return r.recyclableRender})),n.d(t,"components",(function(){return r.components}))},1078:function(e,t,n){"use strict";n.r(t),n.d(t,"render",(function(){return r})),n.d(t,"staticRenderFns",(function(){return i})),n.d(t,"recyclableRender",(function(){return u})),n.d(t,"components",(function(){}));var r=function(){this.$createElement,this._self._c},u=!1,i=[];r._withStripped=!0},1079:function(e,t,n){"use strict";n.r(t);var r=n(1080),u=n.n(r);for(var i in r)"default"!==i&&function(e){n.d(t,e,(function(){return r[e]}))}(i);t.default=u.a},1080:function(e,t,n){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var r={name:"u-radio-group",mixins:[function(e){return e&&e.__esModule?e:{default:e}}(n(915)).default],props:{disabled:{type:Boolean,default:!1},value:{type:[String,Number],default:""},activeColor:{type:String,default:"#2979ff"},size:{type:[String,Number],default:34},labelDisabled:{type:Boolean,default:!1},shape:{type:String,default:"circle"},iconSize:{type:[String,Number],default:20},width:{type:[String,Number],default:"auto"},wrap:{type:Boolean,default:!1}},created:function(){this.children=[]},watch:{parentData:function(){this.children.length&&this.children.map((function(e){"function"==typeof e.updateParentData&&e.updateParentData()}))}},computed:{parentData:function(){return[this.value,this.disabled,this.activeColor,this.size,this.labelDisabled,this.shape,this.iconSize,this.width,this.wrap]}},methods:{setValue:function(e){var t=this;this.children.map((function(t){t.parentData.value!=e&&(t.parentData.value="")})),this.$emit("input",e),this.$emit("change",e),setTimeout((function(){t.dispatch("u-form-item","on-form-change",e)}),60)}}};t.default=r},1081:function(e,t,n){"use strict";n.r(t);var r=n(1082),u=n.n(r);for(var i in r)"default"!==i&&function(e){n.d(t,e,(function(){return r[e]}))}(i);t.default=u.a},1082:function(e,t,n){}}]),(global.webpackJsonp=global.webpackJsonp||[]).push(["uview-ui/components/u-radio-group/u-radio-group-create-component",{"uview-ui/components/u-radio-group/u-radio-group-create-component":function(e,t,n){n("1").createComponent(n(1076))}},[["uview-ui/components/u-radio-group/u-radio-group-create-component"]]]);
},{isPage:false,isComponent:true,currentFile:'uview-ui/components/u-radio-group/u-radio-group.js'});require("uview-ui/components/u-radio-group/u-radio-group.js");