$gwx_XC_49=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_49 || [];
function gz$gwx_XC_49_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_49_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_49_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_49_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'appParameter']])
Z([3,'__e'])
Z(z[1])
Z(z[1])
Z(z[1])
Z(z[1])
Z(z[1])
Z([[4],[[5],[[5],[[5],[[5],[[5],[[5],[[5],[[5],[[5],[[5],[[5],[1,'u-btn']],[1,'u-line-1']],[1,'u-fix-ios-appearance']],[1,'data-v-6e15e680']],[[2,'+'],[1,'u-size-'],[[7],[3,'size']]]],[[2,'?:'],[[7],[3,'plain']],[[2,'+'],[[2,'+'],[1,'u-btn--'],[[7],[3,'type']]],[1,'--plain']],[1,'']]],[[2,'?:'],[[7],[3,'loading']],[1,'u-loading'],[1,'']]],[[2,'?:'],[[2,'=='],[[7],[3,'shape']],[1,'circle']],[1,'u-round-circle'],[1,'']]],[[2,'?:'],[[7],[3,'hairLine']],[[7],[3,'showHairLineBorder']],[1,'u-btn--bold-border']]],[[2,'+'],[1,'u-btn--'],[[7],[3,'type']]]],[[2,'?:'],[[7],[3,'disabled']],[[2,'+'],[[2,'+'],[1,'u-btn--'],[[7],[3,'type']]],[1,'--disabled']],[1,'']]]])
Z([[4],[[5],[[5],[[5],[[5],[[5],[[5],[[4],[[5],[[5],[1,'getphonenumber']],[[4],[[5],[[4],[[5],[[5],[1,'getphonenumber']],[[4],[[5],[1,'$event']]]]]]]]]],[[4],[[5],[[5],[1,'getuserinfo']],[[4],[[5],[[4],[[5],[[5],[1,'getuserinfo']],[[4],[[5],[1,'$event']]]]]]]]]],[[4],[[5],[[5],[1,'error']],[[4],[[5],[[4],[[5],[[5],[1,'error']],[[4],[[5],[1,'$event']]]]]]]]]],[[4],[[5],[[5],[1,'opensetting']],[[4],[[5],[[4],[[5],[[5],[1,'opensetting']],[[4],[[5],[1,'$event']]]]]]]]]],[[4],[[5],[[5],[1,'launchapp']],[[4],[[5],[[4],[[5],[[5],[1,'launchapp']],[[4],[[5],[1,'$event']]]]]]]]]],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'click']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([[7],[3,'dataName']])
Z([[7],[3,'disabled']])
Z([[7],[3,'formType']])
Z([[7],[3,'getHoverClass']])
Z([[6],[[7],[3,'$root']],[3,'m0']])
Z([[6],[[7],[3,'$root']],[3,'m1']])
Z([[7],[3,'hoverStopPropagation']])
Z([3,'u-wave-btn'])
Z([[7],[3,'lang']])
Z([[7],[3,'loading']])
Z([[7],[3,'openType']])
Z([[7],[3,'sendMessageImg']])
Z([3,'sendMessagePath'])
Z([[7],[3,'sendMessageTitle']])
Z([[7],[3,'sessionFrom']])
Z([[7],[3,'showMessageCard']])
Z([[6],[[7],[3,'$root']],[3,'s0']])
Z([[7],[3,'ripple']])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_49_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_49_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_49=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_49=true;
var x=['./uview-ui/components/u-button/u-button.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_49_1()
var a82=_mz(z,'button',['appParameter',0,'binderror',1,'bindgetphonenumber',1,'bindgetuserinfo',2,'bindlaunchapp',3,'bindopensetting',4,'catchtap',5,'class',6,'data-event-opts',7,'data-name',8,'disabled',9,'formType',10,'hoverClass',11,'hoverStartTime',12,'hoverStayTime',13,'hoverStopPropagation',14,'id',15,'lang',16,'loading',17,'openType',18,'sendMessageImg',19,'sendMessagePath',20,'sendMessageTitle',21,'sessionFrom',22,'showMessageCard',23,'style',24],[],e,s,gg)
var e02=_n('slot')
_(a82,e02)
var t92=_v()
_(a82,t92)
if(_oz(z,26,e,s,gg)){t92.wxVkey=1
}
t92.wxXCkey=1
_(r,a82)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_49";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_49();	if (__vd_version_info__.delayedGwx) __wxAppCode__['uview-ui/components/u-button/u-button.wxml'] = [$gwx_XC_49, './uview-ui/components/u-button/u-button.wxml'];else __wxAppCode__['uview-ui/components/u-button/u-button.wxml'] = $gwx_XC_49( './uview-ui/components/u-button/u-button.wxml' );
	;__wxRoute = "uview-ui/components/u-button/u-button";__wxRouteBegin = true;__wxAppCurrentFile__="uview-ui/components/u-button/u-button.js";define("uview-ui/components/u-button/u-button.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
(global.webpackJsonp=global.webpackJsonp||[]).push([["uview-ui/components/u-button/u-button"],{1041:function(t,e,n){"use strict";n.r(e);var i=n(1042),r=n(1044);for(var u in r)"default"!==u&&function(t){n.d(e,t,(function(){return r[t]}))}(u);n(1046);var o=n(17),a=Object(o.default)(r.default,i.render,i.staticRenderFns,!1,null,"6e15e680",null,!1,i.components,void 0);a.options.__file="uview-ui/components/u-button/u-button.vue",e.default=a.exports},1042:function(t,e,n){"use strict";n.r(e);var i=n(1043);n.d(e,"render",(function(){return i.render})),n.d(e,"staticRenderFns",(function(){return i.staticRenderFns})),n.d(e,"recyclableRender",(function(){return i.recyclableRender})),n.d(e,"components",(function(){return i.components}))},1043:function(t,e,n){"use strict";n.r(e),n.d(e,"render",(function(){return i})),n.d(e,"staticRenderFns",(function(){return u})),n.d(e,"recyclableRender",(function(){return r})),n.d(e,"components",(function(){}));var i=function(){var t=this,e=(t.$createElement,t._self._c,t.__get_style([t.customStyle,{overflow:t.ripple?"hidden":"visible"}])),n=Number(t.hoverStartTime),i=Number(t.hoverStayTime);t.$mp.data=Object.assign({},{$root:{s0:e,m0:n,m1:i}})},r=!1,u=[];i._withStripped=!0},1044:function(t,e,n){"use strict";n.r(e);var i=n(1045),r=n.n(i);for(var u in i)"default"!==u&&function(t){n.d(e,t,(function(){return i[t]}))}(u);e.default=r.a},1045:function(t,e,n){"use strict";(function(t){Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var n={name:"u-button",props:{hairLine:{type:Boolean,default:!0},type:{type:String,default:"default"},size:{type:String,default:"default"},shape:{type:String,default:"square"},plain:{type:Boolean,default:!1},disabled:{type:Boolean,default:!1},loading:{type:Boolean,default:!1},openType:{type:String,default:""},formType:{type:String,default:""},appParameter:{type:String,default:""},hoverStopPropagation:{type:Boolean,default:!1},lang:{type:String,default:"en"},sessionFrom:{type:String,default:""},sendMessageTitle:{type:String,default:""},sendMessagePath:{type:String,default:""},sendMessageImg:{type:String,default:""},showMessageCard:{type:Boolean,default:!1},hoverBgColor:{type:String,default:""},rippleBgColor:{type:String,default:""},ripple:{type:Boolean,default:!1},hoverClass:{type:String,default:""},customStyle:{type:Object,default:function(){return{}}},dataName:{type:String,default:""},throttleTime:{type:[String,Number],default:1e3},hoverStartTime:{type:[String,Number],default:20},hoverStayTime:{type:[String,Number],default:150}},computed:{getHoverClass:function(){return this.loading||this.disabled||this.ripple||this.hoverClass?"":this.plain?"u-"+this.type+"-plain-hover":"u-"+this.type+"-hover"},showHairLineBorder:function(){return["primary","success","error","warning"].indexOf(this.type)>=0&&!this.plain?"":"u-hairline-border"}},data:function(){return{rippleTop:0,rippleLeft:0,fields:{},waveActive:!1}},methods:{click:function(t){var e=this;this.$u.throttle((function(){!0!==e.loading&&!0!==e.disabled&&(e.ripple&&(e.waveActive=!1,e.$nextTick((function(){this.getWaveQuery(t)}))),e.$emit("click",t))}),this.throttleTime)},getWaveQuery:function(t){var e=this;this.getElQuery().then((function(n){var i,r,u=n[0];u.width&&u.width&&(u.targetWidth=u.height>u.width?u.height:u.width,u.targetWidth)&&(e.fields=u,i=t.touches[0].clientX,r=t.touches[0].clientY,e.rippleTop=r-u.top-u.targetWidth/2,e.rippleLeft=i-u.left-u.targetWidth/2,e.$nextTick((function(){e.waveActive=!0})))}))},getElQuery:function(){var e=this;return new Promise((function(n){var i="";(i=t.createSelectorQuery().in(e)).select(".u-btn").boundingClientRect(),i.exec((function(t){n(t)}))}))},getphonenumber:function(t){this.$emit("getphonenumber",t)},getuserinfo:function(t){this.$emit("getuserinfo",t)},error:function(t){this.$emit("error",t)},opensetting:function(t){this.$emit("opensetting",t)},launchapp:function(t){this.$emit("launchapp",t)}}};e.default=n}).call(this,n(1).default)},1046:function(t,e,n){"use strict";n.r(e);var i=n(1047),r=n.n(i);for(var u in i)"default"!==u&&function(t){n.d(e,t,(function(){return i[t]}))}(u);e.default=r.a},1047:function(t,e,n){}}]),(global.webpackJsonp=global.webpackJsonp||[]).push(["uview-ui/components/u-button/u-button-create-component",{"uview-ui/components/u-button/u-button-create-component":function(t,e,n){n("1").createComponent(n(1041))}},[["uview-ui/components/u-button/u-button-create-component"]]]);
},{isPage:false,isComponent:true,currentFile:'uview-ui/components/u-button/u-button.js'});require("uview-ui/components/u-button/u-button.js");