$gwx_XC_49=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_49 || [];
function gz$gwx_XC_49_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_49_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_49_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_49_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'appParameter']])
Z([3,'__e'])
Z(z[1])
Z(z[1])
Z(z[1])
Z(z[1])
Z(z[1])
Z([[4],[[5],[[5],[[5],[[5],[[5],[[5],[[5],[[5],[[5],[[5],[[5],[1,'u-btn']],[1,'u-line-1']],[1,'u-fix-ios-appearance']],[1,'data-v-6e15e680']],[[2,'+'],[1,'u-size-'],[[7],[3,'size']]]],[[2,'?:'],[[7],[3,'plain']],[[2,'+'],[[2,'+'],[1,'u-btn--'],[[7],[3,'type']]],[1,'--plain']],[1,'']]],[[2,'?:'],[[7],[3,'loading']],[1,'u-loading'],[1,'']]],[[2,'?:'],[[2,'=='],[[7],[3,'shape']],[1,'circle']],[1,'u-round-circle'],[1,'']]],[[2,'?:'],[[7],[3,'hairLine']],[[7],[3,'showHairLineBorder']],[1,'u-btn--bold-border']]],[[2,'+'],[1,'u-btn--'],[[7],[3,'type']]]],[[2,'?:'],[[7],[3,'disabled']],[[2,'+'],[[2,'+'],[1,'u-btn--'],[[7],[3,'type']]],[1,'--disabled']],[1,'']]]])
Z([[4],[[5],[[5],[[5],[[5],[[5],[[5],[[4],[[5],[[5],[1,'getphonenumber']],[[4],[[5],[[4],[[5],[[5],[1,'getphonenumber']],[[4],[[5],[1,'$event']]]]]]]]]],[[4],[[5],[[5],[1,'getuserinfo']],[[4],[[5],[[4],[[5],[[5],[1,'getuserinfo']],[[4],[[5],[1,'$event']]]]]]]]]],[[4],[[5],[[5],[1,'error']],[[4],[[5],[[4],[[5],[[5],[1,'error']],[[4],[[5],[1,'$event']]]]]]]]]],[[4],[[5],[[5],[1,'opensetting']],[[4],[[5],[[4],[[5],[[5],[1,'opensetting']],[[4],[[5],[1,'$event']]]]]]]]]],[[4],[[5],[[5],[1,'launchapp']],[[4],[[5],[[4],[[5],[[5],[1,'launchapp']],[[4],[[5],[1,'$event']]]]]]]]]],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'click']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([[7],[3,'dataName']])
Z([[7],[3,'disabled']])
Z([[7],[3,'formType']])
Z([[7],[3,'getHoverClass']])
Z([[6],[[7],[3,'$root']],[3,'m0']])
Z([[6],[[7],[3,'$root']],[3,'m1']])
Z([[7],[3,'hoverStopPropagation']])
Z([3,'u-wave-btn'])
Z([[7],[3,'lang']])
Z([[7],[3,'loading']])
Z([[7],[3,'openType']])
Z([[7],[3,'sendMessageImg']])
Z([3,'sendMessagePath'])
Z([[7],[3,'sendMessageTitle']])
Z([[7],[3,'sessionFrom']])
Z([[7],[3,'showMessageCard']])
Z([[6],[[7],[3,'$root']],[3,'s0']])
Z([[7],[3,'ripple']])
Z([[4],[[5],[[5],[[5],[1,'u-wave-ripple']],[1,'data-v-6e15e680']],[[2,'?:'],[[7],[3,'waveActive']],[1,'u-wave-active'],[1,'']]]])
Z([[2,'+'],[[2,'+'],[[2,'+'],[[2,'+'],[[2,'+'],[[2,'+'],[1,'top:'],[[2,'+'],[[7],[3,'rippleTop']],[1,'px']]],[1,';']],[[2,'+'],[[2,'+'],[1,'left:'],[[2,'+'],[[7],[3,'rippleLeft']],[1,'px']]],[1,';']]],[[2,'+'],[[2,'+'],[1,'width:'],[[2,'+'],[[6],[[7],[3,'fields']],[3,'targetWidth']],[1,'px']]],[1,';']]],[[2,'+'],[[2,'+'],[1,'height:'],[[2,'+'],[[6],[[7],[3,'fields']],[3,'targetWidth']],[1,'px']]],[1,';']]],[[2,'+'],[[2,'+'],[1,'background-color:'],[[2,'||'],[[7],[3,'rippleBgColor']],[1,'rgba(0, 0, 0, 0.15)']]],[1,';']]])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_49_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_49_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_49=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_49=true;
var x=['./uview-ui/components/u-button/u-button.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_49_1()
var cD0C=_mz(z,'button',['appParameter',0,'binderror',1,'bindgetphonenumber',1,'bindgetuserinfo',2,'bindlaunchapp',3,'bindopensetting',4,'catchtap',5,'class',6,'data-event-opts',7,'data-name',8,'disabled',9,'formType',10,'hoverClass',11,'hoverStartTime',12,'hoverStayTime',13,'hoverStopPropagation',14,'id',15,'lang',16,'loading',17,'openType',18,'sendMessageImg',19,'sendMessagePath',20,'sendMessageTitle',21,'sessionFrom',22,'showMessageCard',23,'style',24],[],e,s,gg)
var oF0C=_n('slot')
_(cD0C,oF0C)
var hE0C=_v()
_(cD0C,hE0C)
if(_oz(z,26,e,s,gg)){hE0C.wxVkey=1
var cG0C=_mz(z,'view',['class',27,'style',1],[],e,s,gg)
_(hE0C,cG0C)
}
hE0C.wxXCkey=1
_(r,cD0C)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_49";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_49();
	if (__vd_version_info__.delayedGwx) __wxAppCode__['uview-ui/components/u-button/u-button.wxml'] = [$gwx_XC_49, './uview-ui/components/u-button/u-button.wxml'];else __wxAppCode__['uview-ui/components/u-button/u-button.wxml'] = $gwx_XC_49( './uview-ui/components/u-button/u-button.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['uview-ui/components/u-button/u-button.wxss'] = setCssToHead([".",[1],"u-btn.",[1],"data-v-6e15e680::after{border:none}\n.",[1],"u-btn.",[1],"data-v-6e15e680{-webkit-align-items:center;align-items:center;border:0;box-sizing:border-box;cursor:pointer;display:-webkit-inline-flex;display:inline-flex;display:-webkit-flex;display:flex;-webkit-flex-direction:row;flex-direction:row;-webkit-justify-content:center;justify-content:center;line-height:1;overflow:visible;padding:0 ",[0,40],";position:relative;transition:all .15s;z-index:1}\n.",[1],"u-btn--bold-border.",[1],"data-v-6e15e680{border:1px solid #fff}\n.",[1],"u-btn--default.",[1],"data-v-6e15e680{background-color:#fff;border-color:#c0c4cc;color:#606266}\n.",[1],"u-btn--primary.",[1],"data-v-6e15e680{background-color:#2979ff;border-color:#2979ff;color:#fff}\n.",[1],"u-btn--success.",[1],"data-v-6e15e680{background-color:#19be6b;border-color:#19be6b;color:#fff}\n.",[1],"u-btn--error.",[1],"data-v-6e15e680{background-color:#fa3534;border-color:#fa3534;color:#fff}\n.",[1],"u-btn--warning.",[1],"data-v-6e15e680{background-color:#f90;border-color:#f90;color:#fff}\n.",[1],"u-btn--default--disabled.",[1],"data-v-6e15e680{background-color:#fff;border-color:#e4e7ed;color:#fff}\n.",[1],"u-btn--primary--disabled.",[1],"data-v-6e15e680{background-color:#a0cfff!important;border-color:#a0cfff!important;color:#fff!important}\n.",[1],"u-btn--success--disabled.",[1],"data-v-6e15e680{background-color:#71d5a1!important;border-color:#71d5a1!important;color:#fff!important}\n.",[1],"u-btn--error--disabled.",[1],"data-v-6e15e680{background-color:#fab6b6!important;border-color:#fab6b6!important;color:#fff!important}\n.",[1],"u-btn--warning--disabled.",[1],"data-v-6e15e680{background-color:#fcbd71!important;border-color:#fcbd71!important;color:#fff!important}\n.",[1],"u-btn--primary--plain.",[1],"data-v-6e15e680{background-color:#ecf5ff!important;border-color:#a0cfff!important;color:#2979ff!important}\n.",[1],"u-btn--success--plain.",[1],"data-v-6e15e680{background-color:#dbf1e1!important;border-color:#71d5a1!important;color:#19be6b!important}\n.",[1],"u-btn--error--plain.",[1],"data-v-6e15e680{background-color:#fef0f0!important;border-color:#fab6b6!important;color:#fa3534!important}\n.",[1],"u-btn--warning--plain.",[1],"data-v-6e15e680{background-color:#fdf6ec!important;border-color:#fcbd71!important;color:#f90!important}\n.",[1],"u-hairline-border.",[1],"data-v-6e15e680:after{border:1px solid;box-sizing:border-box;content:\x22 \x22;height:199.7%;left:0;pointer-events:none;position:absolute;top:0;-webkit-transform:scale(.5,.5);transform:scale(.5,.5);-webkit-transform-origin:0 0;transform-origin:0 0;width:199.8%;z-index:1}\n.",[1],"u-wave-ripple.",[1],"data-v-6e15e680{background-clip:padding-box;border-radius:100%;opacity:1;pointer-events:none;position:absolute;-webkit-transform:scale(0);transform:scale(0);-webkit-transform-origin:center;transform-origin:center;-webkit-user-select:none;user-select:none;z-index:0}\n.",[1],"u-wave-ripple.",[1],"u-wave-active.",[1],"data-v-6e15e680{opacity:0;-webkit-transform:scale(2);transform:scale(2);transition:opacity 1s linear,-webkit-transform .4s linear;transition:opacity 1s linear,transform .4s linear;transition:opacity 1s linear,transform .4s linear,-webkit-transform .4s linear}\n.",[1],"u-round-circle.",[1],"data-v-6e15e680,.",[1],"u-round-circle.",[1],"data-v-6e15e680::after{border-radius:",[0,100],"}\n.",[1],"u-loading.",[1],"data-v-6e15e680::after{background-color:hsla(0,0%,100%,.35)}\n.",[1],"u-size-default.",[1],"data-v-6e15e680{font-size:",[0,30],";height:",[0,80],";line-height:",[0,80],"}\n.",[1],"u-size-medium.",[1],"data-v-6e15e680{display:-webkit-inline-flex;display:inline-flex;font-size:",[0,26],";height:",[0,70],";line-height:",[0,70],";padding:0 ",[0,80],";width:auto}\n.",[1],"u-size-mini.",[1],"data-v-6e15e680{display:-webkit-inline-flex;display:inline-flex;font-size:",[0,22],";height:",[0,50],";line-height:",[0,50],";padding:0 ",[0,20],";width:auto}\n.",[1],"u-primary-plain-hover.",[1],"data-v-6e15e680{background:#2b85e4!important;color:#fff!important}\n.",[1],"u-default-plain-hover.",[1],"data-v-6e15e680{background:#ecf5ff!important;color:#2b85e4!important}\n.",[1],"u-success-plain-hover.",[1],"data-v-6e15e680{background:#18b566!important;color:#fff!important}\n.",[1],"u-warning-plain-hover.",[1],"data-v-6e15e680{background:#f29100!important;color:#fff!important}\n.",[1],"u-error-plain-hover.",[1],"data-v-6e15e680{background:#dd6161!important;color:#fff!important}\n.",[1],"u-info-plain-hover.",[1],"data-v-6e15e680{background:#82848a!important;color:#fff!important}\n.",[1],"u-default-hover.",[1],"data-v-6e15e680{background-color:#ecf5ff!important;border-color:#2b85e4!important;color:#2b85e4!important}\n.",[1],"u-primary-hover.",[1],"data-v-6e15e680{background:#2b85e4!important;color:#fff}\n.",[1],"u-success-hover.",[1],"data-v-6e15e680{background:#18b566!important;color:#fff}\n.",[1],"u-info-hover.",[1],"data-v-6e15e680{background:#82848a!important;color:#fff}\n.",[1],"u-warning-hover.",[1],"data-v-6e15e680{background:#f29100!important;color:#fff}\n.",[1],"u-error-hover.",[1],"data-v-6e15e680{background:#dd6161!important;color:#fff}\n",],undefined,{path:"./uview-ui/components/u-button/u-button.wxss"});
}