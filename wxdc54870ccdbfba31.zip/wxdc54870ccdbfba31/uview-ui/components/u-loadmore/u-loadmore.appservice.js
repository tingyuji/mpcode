$gwx_XC_61=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_61 || [];
function gz$gwx_XC_61_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_61_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_61_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_61_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'u-load-more-wrap data-v-874545c0'])
Z([[2,'+'],[[2,'+'],[[2,'+'],[[2,'+'],[[2,'+'],[1,'background-color:'],[[7],[3,'bgColor']]],[1,';']],[[2,'+'],[[2,'+'],[1,'margin-bottom:'],[[2,'+'],[[7],[3,'marginBottom']],[1,'rpx']]],[1,';']]],[[2,'+'],[[2,'+'],[1,'margin-top:'],[[2,'+'],[[7],[3,'marginTop']],[1,'rpx']]],[1,';']]],[[2,'+'],[[2,'+'],[1,'height:'],[[6],[[7],[3,'$root']],[3,'g0']]],[1,';']]])
Z([3,'__l'])
Z([3,'data-v-874545c0'])
Z([3,'#d4d4d4'])
Z([3,'50'])
Z([3,'61627034-1'])
Z(z[2])
Z([3,'u-loadmore-icon data-v-874545c0'])
Z([[7],[3,'iconColor']])
Z([[2,'?:'],[[2,'=='],[[7],[3,'iconType']],[1,'circle']],[1,'circle'],[1,'flower']])
Z([[2,'&&'],[[2,'=='],[[7],[3,'status']],[1,'loading']],[[7],[3,'icon']]])
Z([3,'61627034-2'])
Z(z[2])
Z(z[3])
Z(z[4])
Z(z[5])
Z([3,'61627034-3'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_61_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_61_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_61=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_61=true;
var x=['./uview-ui/components/u-loadmore/u-loadmore.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_61_1()
var cD5=_mz(z,'view',['class',0,'style',1],[],e,s,gg)
var hE5=_mz(z,'u-line',['bind:__l',2,'class',1,'color',2,'length',3,'vueId',4],[],e,s,gg)
_(cD5,hE5)
var oF5=_mz(z,'u-loading',['bind:__l',7,'class',1,'color',2,'mode',3,'show',4,'vueId',5],[],e,s,gg)
_(cD5,oF5)
var cG5=_mz(z,'u-line',['bind:__l',13,'class',1,'color',2,'length',3,'vueId',4],[],e,s,gg)
_(cD5,cG5)
_(r,cD5)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_61";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_61();	if (__vd_version_info__.delayedGwx) __wxAppCode__['uview-ui/components/u-loadmore/u-loadmore.wxml'] = [$gwx_XC_61, './uview-ui/components/u-loadmore/u-loadmore.wxml'];else __wxAppCode__['uview-ui/components/u-loadmore/u-loadmore.wxml'] = $gwx_XC_61( './uview-ui/components/u-loadmore/u-loadmore.wxml' );
	;__wxRoute = "uview-ui/components/u-loadmore/u-loadmore";__wxRouteBegin = true;__wxAppCurrentFile__="uview-ui/components/u-loadmore/u-loadmore.js";define("uview-ui/components/u-loadmore/u-loadmore.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
(global.webpackJsonp=global.webpackJsonp||[]).push([["uview-ui/components/u-loadmore/u-loadmore"],{861:function(e,t,o){"use strict";o.r(t);var n=o(862),r=o(864);for(var u in r)"default"!==u&&function(e){o.d(t,e,(function(){return r[e]}))}(u);o(866);var i=o(17),a=Object(i.default)(r.default,n.render,n.staticRenderFns,!1,null,"874545c0",null,!1,n.components,void 0);a.options.__file="uview-ui/components/u-loadmore/u-loadmore.vue",t.default=a.exports},862:function(e,t,o){"use strict";o.r(t);var n=o(863);o.d(t,"render",(function(){return n.render})),o.d(t,"staticRenderFns",(function(){return n.staticRenderFns})),o.d(t,"recyclableRender",(function(){return n.recyclableRender})),o.d(t,"components",(function(){return n.components}))},863:function(e,t,o){"use strict";var n;o.r(t),o.d(t,"render",(function(){return r})),o.d(t,"staticRenderFns",(function(){return i})),o.d(t,"recyclableRender",(function(){return u})),o.d(t,"components",(function(){return n}));try{n={uLine:function(){return o.e("uview-ui/components/u-line/u-line").then(o.bind(null,1163))},uLoading:function(){return o.e("uview-ui/components/u-loading/u-loading").then(o.bind(null,975))}}}catch(e){if(-1===e.message.indexOf("Cannot find module")||-1===e.message.indexOf(".vue"))throw e;console.error(e.message),console.error("1. 排查组件名称拼写是否正确"),console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"),console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件")}var r=function(){var e=this,t=(e.$createElement,e._self._c,e.$u.addUnit(e.height)),o=e.__get_style([e.loadTextStyle]);e.$mp.data=Object.assign({},{$root:{g0:t,s0:o}})},u=!1,i=[];r._withStripped=!0},864:function(e,t,o){"use strict";o.r(t);var n=o(865),r=o.n(n);for(var u in n)"default"!==u&&function(e){o.d(t,e,(function(){return n[e]}))}(u);t.default=r.a},865:function(e,t,o){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var n={name:"u-loadmore",props:{bgColor:{type:String,default:"transparent"},icon:{type:Boolean,default:!0},fontSize:{type:String,default:"28"},color:{type:String,default:"#606266"},status:{type:String,default:"loadmore"},iconType:{type:String,default:"circle"},loadText:{type:Object,default:function(){return{loadmore:"加载更多",loading:"正在加载...",nomore:"没有更多了"}}},isDot:{type:Boolean,default:!1},iconColor:{type:String,default:"#b7b7b7"},marginTop:{type:[String,Number],default:0},marginBottom:{type:[String,Number],default:0},height:{type:[String,Number],default:"auto"}},data:function(){return{dotText:"●"}},computed:{loadTextStyle:function(){return{color:this.color,fontSize:this.fontSize+"rpx",position:"relative",zIndex:1,backgroundColor:this.bgColor}},cricleStyle:function(){return{borderColor:"#e5e5e5 #e5e5e5 #e5e5e5 ".concat(this.circleColor)}},flowerStyle:function(){return{}},showText:function(){return"loadmore"==this.status?this.loadText.loadmore:"loading"==this.status?this.loadText.loading:"nomore"==this.status&&this.isDot?this.dotText:this.loadText.nomore}},methods:{loadMore:function(){"loadmore"==this.status&&this.$emit("loadmore")}}};t.default=n},866:function(e,t,o){"use strict";o.r(t);var n=o(867),r=o.n(n);for(var u in n)"default"!==u&&function(e){o.d(t,e,(function(){return n[e]}))}(u);t.default=r.a},867:function(e,t,o){}}]),(global.webpackJsonp=global.webpackJsonp||[]).push(["uview-ui/components/u-loadmore/u-loadmore-create-component",{"uview-ui/components/u-loadmore/u-loadmore-create-component":function(e,t,o){o("1").createComponent(o(861))}},[["uview-ui/components/u-loadmore/u-loadmore-create-component"]]]);
},{isPage:false,isComponent:true,currentFile:'uview-ui/components/u-loadmore/u-loadmore.js'});require("uview-ui/components/u-loadmore/u-loadmore.js");