$gwx_XC_62=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_62 || [];
function gz$gwx_XC_62_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_62_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_62_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_62_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'__e'])
Z(z[0])
Z([[4],[[5],[[5],[[5],[[5],[1,'u-mask']],[1,'data-v-4bfa3b00']],[[2,'?:'],[[7],[3,'zoom']],[1,'u-mask-zoom'],[1,'']]],[[2,'?:'],[[7],[3,'show']],[1,'u-mask-show'],[1,'']]]])
Z([[4],[[5],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'click']],[[4],[[5],[1,'$event']]]]]]]]]],[[4],[[5],[[5],[1,'touchmove']],[[4],[[5],[[4],[[5],[[5],[1,'e0']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([1,true])
Z([[6],[[7],[3,'$root']],[3,'s0']])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_62_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_62_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_62=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_62=true;
var x=['./uview-ui/components/u-mask/u-mask.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_62_1()
var lI5=_mz(z,'view',['bindtap',0,'catchtouchmove',1,'class',1,'data-event-opts',2,'hoverStopPropagation',3,'style',4],[],e,s,gg)
var aJ5=_n('slot')
_(lI5,aJ5)
_(r,lI5)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_62";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_62();	if (__vd_version_info__.delayedGwx) __wxAppCode__['uview-ui/components/u-mask/u-mask.wxml'] = [$gwx_XC_62, './uview-ui/components/u-mask/u-mask.wxml'];else __wxAppCode__['uview-ui/components/u-mask/u-mask.wxml'] = $gwx_XC_62( './uview-ui/components/u-mask/u-mask.wxml' );
	;__wxRoute = "uview-ui/components/u-mask/u-mask";__wxRouteBegin = true;__wxAppCurrentFile__="uview-ui/components/u-mask/u-mask.js";define("uview-ui/components/u-mask/u-mask.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
(global.webpackJsonp=global.webpackJsonp||[]).push([["uview-ui/components/u-mask/u-mask"],{1181:function(e,t,n){"use strict";n.r(t);var r=n(1182),o=n(1184);for(var u in o)"default"!==u&&function(e){n.d(t,e,(function(){return o[e]}))}(u);n(1186);var c=n(17),a=Object(c.default)(o.default,r.render,r.staticRenderFns,!1,null,"4bfa3b00",null,!1,r.components,void 0);a.options.__file="uview-ui/components/u-mask/u-mask.vue",t.default=a.exports},1182:function(e,t,n){"use strict";n.r(t);var r=n(1183);n.d(t,"render",(function(){return r.render})),n.d(t,"staticRenderFns",(function(){return r.staticRenderFns})),n.d(t,"recyclableRender",(function(){return r.recyclableRender})),n.d(t,"components",(function(){return r.components}))},1183:function(e,t,n){"use strict";n.r(t),n.d(t,"render",(function(){return r})),n.d(t,"staticRenderFns",(function(){return u})),n.d(t,"recyclableRender",(function(){return o})),n.d(t,"components",(function(){}));var r=function(){var e=this,t=(e.$createElement,e._self._c,e.__get_style([e.maskStyle,e.zoomStyle]));e._isMounted||(e.e0=function(e){e.stopPropagation(),e.preventDefault()}),e.$mp.data=Object.assign({},{$root:{s0:t}})},o=!1,u=[];r._withStripped=!0},1184:function(e,t,n){"use strict";n.r(t);var r=n(1185),o=n.n(r);for(var u in r)"default"!==u&&function(e){n.d(t,e,(function(){return r[e]}))}(u);t.default=o.a},1185:function(e,t,n){"use strict";function r(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter((function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,r)}return n}function o(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{};t%2?r(Object(n),!0).forEach((function(t){u(e,t,n[t])})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):r(Object(n)).forEach((function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))}))}return e}function u(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var c={name:"u-mask",props:{show:{type:Boolean,default:!1},zIndex:{type:[Number,String],default:""},customStyle:{type:Object,default:function(){return{}}},zoom:{type:Boolean,default:!0},duration:{type:[Number,String],default:300},maskClickAble:{type:Boolean,default:!0}},data:function(){return{zoomStyle:{transform:""},scale:"scale(1.2, 1.2)"}},watch:{show:function(e){e&&this.zoom?this.zoomStyle.transform="scale(1, 1)":!e&&this.zoom&&(this.zoomStyle.transform=this.scale)}},computed:{maskStyle:function(){var e={backgroundColor:"rgba(0, 0, 0, 0.6)"};return this.show?e.zIndex=this.zIndex?this.zIndex:this.$u.zIndex.mask:e.zIndex=-1,e.transition="all ".concat(this.duration/1e3,"s ease-in-out"),Object.keys(this.customStyle).length&&(e=o(o({},e),this.customStyle)),e}},methods:{click:function(){this.maskClickAble&&this.$emit("click")}}};t.default=c},1186:function(e,t,n){"use strict";n.r(t);var r=n(1187),o=n.n(r);for(var u in r)"default"!==u&&function(e){n.d(t,e,(function(){return r[e]}))}(u);t.default=o.a},1187:function(e,t,n){}}]),(global.webpackJsonp=global.webpackJsonp||[]).push(["uview-ui/components/u-mask/u-mask-create-component",{"uview-ui/components/u-mask/u-mask-create-component":function(e,t,n){n("1").createComponent(n(1181))}},[["uview-ui/components/u-mask/u-mask-create-component"]]]);
},{isPage:false,isComponent:true,currentFile:'uview-ui/components/u-mask/u-mask.js'});require("uview-ui/components/u-mask/u-mask.js");