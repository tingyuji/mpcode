$gwx_XC_23=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_23 || [];
function gz$gwx_XC_23_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_23_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_23_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_23_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'home_tz data-v-1375c95d'])
Z([[4],[[5],[[5],[[5],[1,'avatar']],[1,'data-v-1375c95d']],[[2,'?:'],[[6],[[7],[3,'userInfoHome']],[3,'memberLevel']],[1,'avatar avatarvip'],[1,'avatar']]]])
Z([[2,'&&'],[[6],[[7],[3,'userInfoHome']],[3,'memberLevel']],[[6],[[7],[3,'userInfoHome']],[3,'activityCount']]])
Z([[6],[[7],[3,'userInfoHome']],[3,'activityCount']])
Z([[2,'!'],[[6],[[7],[3,'userInfoHome']],[3,'focusWechat']]])
Z([3,'__l'])
Z([3,'__e'])
Z([3,'data-v-1375c95d'])
Z([3,'#909399'])
Z([[4],[[5],[[4],[[5],[[5],[1,'^click']],[[4],[[5],[[4],[[5],[1,'e0']]]]]]]]])
Z([3,'close'])
Z([3,'22'])
Z([3,'5b43e349-1'])
Z([3,'shequ_jl data-v-1375c95d'])
Z([3,'index'])
Z([3,'item'])
Z([[7],[3,'activityOwnLi']])
Z(z[14])
Z([3,'tg_con mt20 data-v-1375c95d'])
Z([[2,'!='],[[6],[[7],[3,'item']],[3,'activityType']],[1,20]])
Z(z[6])
Z(z[7])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'goOrder']],[[4],[[5],[1,'$0']]]],[[4],[[5],[[4],[[5],[[4],[[5],[[5],[[5],[[5],[1,'activityOwnLi']],[1,'']],[[7],[3,'index']]],[1,'activityId']]]]]]]]]]]]]]])
Z([3,'flex align-center yh_con data-v-1375c95d'])
Z([[2,'!='],[[6],[[7],[3,'item']],[3,'activityOwner']],[1,1]])
Z([3,'mf_ft data-v-1375c95d'])
Z([[6],[[7],[3,'item']],[3,'showTip']])
Z(z[26])
Z([[2,'&&'],[[2,'!'],[[6],[[7],[3,'item']],[3,'subscribe']]],[[6],[[7],[3,'item']],[3,'showsubscribe']]])
Z([[2,'&&'],[[6],[[7],[3,'item']],[3,'subscribe']],[[6],[[7],[3,'item']],[3,'showsubscribe']]])
Z([[2,'=='],[[6],[[7],[3,'item']],[3,'freezeFlag']],[1,2]])
Z([[6],[[7],[3,'item']],[3,'imgArrs']])
Z([3,'k'])
Z([3,'j'])
Z([[6],[[7],[3,'item']],[3,'orderInfos']])
Z(z[32])
Z([[2,'!='],[[6],[[7],[3,'j']],[3,'formatName']],[1,'默认 ']])
Z([3,'fl data-v-1375c95d'])
Z([[2,'=='],[[6],[[7],[3,'item']],[3,'activityOwner']],[1,1]])
Z(z[38])
Z([[2,'&&'],[[6],[[7],[3,'item']],[3,'oneClickHelpSell']],[[2,'=='],[[6],[[7],[3,'item']],[3,'helpSellFlag']],[1,2]]])
Z(z[40])
Z([3,'shop_infos wei_xc data-v-1375c95d'])
Z([[2,'!'],[[6],[[7],[3,'item']],[3,'hasVideo']]])
Z([3,'shop_img fl data-v-1375c95d'])
Z([[2,'||'],[[2,'||'],[[2,'=='],[[6],[[6],[[7],[3,'item']],[3,'imgArrs']],[3,'length']],[1,2]],[[2,'=='],[[6],[[6],[[7],[3,'item']],[3,'imgArrs']],[3,'length']],[1,5]]],[[2,'=='],[[6],[[6],[[7],[3,'item']],[3,'imgArrs']],[3,'length']],[1,8]]])
Z([[2,'||'],[[2,'||'],[[2,'=='],[[6],[[6],[[7],[3,'item']],[3,'imgArrs']],[3,'length']],[1,1]],[[2,'=='],[[6],[[6],[[7],[3,'item']],[3,'imgArrs']],[3,'length']],[1,4]]],[[2,'=='],[[6],[[6],[[7],[3,'item']],[3,'imgArrs']],[3,'length']],[1,7]]])
Z(z[46])
Z(z[14])
Z(z[15])
Z([[7],[3,'specialList']])
Z(z[14])
Z(z[18])
Z(z[19])
Z(z[6])
Z(z[7])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'goOrder']],[[4],[[5],[1,'$0']]]],[[4],[[5],[[4],[[5],[[4],[[5],[[5],[[5],[[5],[1,'specialList']],[1,'']],[[7],[3,'index']]],[1,'activityId']]]]]]]]]]]]]]])
Z(z[23])
Z(z[28])
Z(z[29])
Z(z[31])
Z(z[32])
Z(z[33])
Z(z[34])
Z(z[32])
Z(z[36])
Z(z[37])
Z(z[38])
Z(z[38])
Z(z[42])
Z(z[43])
Z(z[44])
Z(z[45])
Z(z[46])
Z(z[46])
Z([[2,'&&'],[[2,'!='],[[7],[3,'currentShequn']],[1,1]],[[2,'!'],[[7],[3,'activityOwnNoData']]]])
Z(z[5])
Z(z[7])
Z([[7],[3,'loadText']])
Z([1,50])
Z([[7],[3,'loadStatus']])
Z([3,'5b43e349-2'])
Z([[2,'&&'],[[2,'=='],[[7],[3,'currentShequn']],[1,1]],[[7],[3,'specialListNoData']]])
Z(z[5])
Z(z[7])
Z([1,100])
Z([3,'favor'])
Z([3,'暂无数据'])
Z([3,'5b43e349-3'])
Z([[2,'&&'],[[2,'!='],[[7],[3,'currentShequn']],[1,1]],[[7],[3,'activityOwnNoData']]])
Z(z[5])
Z(z[7])
Z(z[85])
Z(z[86])
Z(z[87])
Z([3,'5b43e349-4'])
Z([[7],[3,'showShares']])
Z(z[5])
Z(z[6])
Z(z[6])
Z([3,'zuj_fix data-v-1375c95d'])
Z([[4],[[5],[[5],[[4],[[5],[[5],[1,'^shareUrl']],[[4],[[5],[[4],[[5],[1,'shareUrl']]]]]]]],[[4],[[5],[[5],[1,'^closeShare']],[[4],[[5],[[4],[[5],[1,'closeShare']]]]]]]]])
Z([[7],[3,'shareObj']])
Z([3,'5b43e349-5'])
Z([[7],[3,'getUserBox']])
Z(z[5])
Z(z[6])
Z(z[100])
Z([[4],[[5],[[4],[[5],[[5],[1,'^closeUser']],[[4],[[5],[[4],[[5],[1,'closeUser']]]]]]]]])
Z([3,'5b43e349-6'])
Z([1,true])
Z([3,'#FFF'])
Z(z[5])
Z(z[7])
Z([[7],[3,'loadingSke']])
Z([3,'5b43e349-7'])
Z(z[5])
Z(z[6])
Z(z[6])
Z(z[7])
Z([[4],[[5],[[5],[[4],[[5],[[5],[1,'^click']],[[4],[[5],[[4],[[5],[1,'clickAct']]]]]]]],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'showAct']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z([[7],[3,'actionList']])
Z([3,'text-align:center;'])
Z([[7],[3,'showAct']])
Z([3,'5b43e349-8'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_23_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_23_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_23=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_23=true;
var x=['./pages/example/home.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_23_1()
var oRE=_n('view')
_rz(z,oRE,'class',0,e,s,gg)
var aVE=_n('view')
_rz(z,aVE,'class',1,e,s,gg)
var tWE=_v()
_(aVE,tWE)
if(_oz(z,2,e,s,gg)){tWE.wxVkey=1
}
else{tWE.wxVkey=2
var eXE=_v()
_(tWE,eXE)
if(_oz(z,3,e,s,gg)){eXE.wxVkey=1
}
eXE.wxXCkey=1
}
tWE.wxXCkey=1
_(oRE,aVE)
var cSE=_v()
_(oRE,cSE)
if(_oz(z,4,e,s,gg)){cSE.wxVkey=1
var bYE=_mz(z,'u-icon',['bind:__l',5,'bind:click',1,'class',2,'color',3,'data-event-opts',4,'name',5,'size',6,'vueId',7],[],e,s,gg)
_(cSE,bYE)
}
var oZE=_n('view')
_rz(z,oZE,'class',13,e,s,gg)
var c4E=_v()
_(oZE,c4E)
var h5E=function(c7E,o6E,o8E,gg){
var a0E=_n('view')
_rz(z,a0E,'class',18,c7E,o6E,gg)
var tAF=_v()
_(a0E,tAF)
if(_oz(z,19,c7E,o6E,gg)){tAF.wxVkey=1
var eBF=_mz(z,'view',['bindtap',20,'class',1,'data-event-opts',2],[],c7E,o6E,gg)
var xEF=_n('view')
_rz(z,xEF,'class',23,c7E,o6E,gg)
var oFF=_v()
_(xEF,oFF)
if(_oz(z,24,c7E,o6E,gg)){oFF.wxVkey=1
var hIF=_n('view')
_rz(z,hIF,'class',25,c7E,o6E,gg)
var oJF=_v()
_(hIF,oJF)
if(_oz(z,26,c7E,o6E,gg)){oJF.wxVkey=1
}
var cKF=_v()
_(hIF,cKF)
if(_oz(z,27,c7E,o6E,gg)){cKF.wxVkey=1
}
oJF.wxXCkey=1
cKF.wxXCkey=1
_(oFF,hIF)
}
var fGF=_v()
_(xEF,fGF)
if(_oz(z,28,c7E,o6E,gg)){fGF.wxVkey=1
}
var cHF=_v()
_(xEF,cHF)
if(_oz(z,29,c7E,o6E,gg)){cHF.wxVkey=1
}
oFF.wxXCkey=1
fGF.wxXCkey=1
cHF.wxXCkey=1
_(eBF,xEF)
var bCF=_v()
_(eBF,bCF)
if(_oz(z,30,c7E,o6E,gg)){bCF.wxVkey=1
}
var oDF=_v()
_(eBF,oDF)
if(_oz(z,31,c7E,o6E,gg)){oDF.wxVkey=1
}
var oLF=_v()
_(eBF,oLF)
var lMF=function(tOF,aNF,ePF,gg){
var oRF=_v()
_(ePF,oRF)
if(_oz(z,36,tOF,aNF,gg)){oRF.wxVkey=1
}
oRF.wxXCkey=1
return ePF
}
oLF.wxXCkey=2
_2z(z,34,lMF,c7E,o6E,gg,oLF,'j','k','k')
var xSF=_n('view')
_rz(z,xSF,'class',37,c7E,o6E,gg)
var oTF=_v()
_(xSF,oTF)
if(_oz(z,38,c7E,o6E,gg)){oTF.wxVkey=1
}
var fUF=_v()
_(xSF,fUF)
if(_oz(z,39,c7E,o6E,gg)){fUF.wxVkey=1
}
var cVF=_v()
_(xSF,cVF)
if(_oz(z,40,c7E,o6E,gg)){cVF.wxVkey=1
}
var hWF=_v()
_(xSF,hWF)
if(_oz(z,41,c7E,o6E,gg)){hWF.wxVkey=1
}
oTF.wxXCkey=1
fUF.wxXCkey=1
cVF.wxXCkey=1
hWF.wxXCkey=1
_(eBF,xSF)
bCF.wxXCkey=1
oDF.wxXCkey=1
_(tAF,eBF)
}
else{tAF.wxVkey=2
var oXF=_n('view')
_rz(z,oXF,'class',42,c7E,o6E,gg)
var cYF=_v()
_(oXF,cYF)
if(_oz(z,43,c7E,o6E,gg)){cYF.wxVkey=1
var oZF=_n('view')
_rz(z,oZF,'class',44,c7E,o6E,gg)
var l1F=_v()
_(oZF,l1F)
if(_oz(z,45,c7E,o6E,gg)){l1F.wxVkey=1
}
var a2F=_v()
_(oZF,a2F)
if(_oz(z,46,c7E,o6E,gg)){a2F.wxVkey=1
}
var t3F=_v()
_(oZF,t3F)
if(_oz(z,47,c7E,o6E,gg)){t3F.wxVkey=1
}
l1F.wxXCkey=1
a2F.wxXCkey=1
t3F.wxXCkey=1
_(cYF,oZF)
}
else{cYF.wxVkey=2
}
cYF.wxXCkey=1
_(tAF,oXF)
}
tAF.wxXCkey=1
_(o8E,a0E)
return o8E
}
c4E.wxXCkey=2
_2z(z,16,h5E,e,s,gg,c4E,'item','index','index')
var e4F=_v()
_(oZE,e4F)
var b5F=function(x7F,o6F,o8F,gg){
var c0F=_n('view')
_rz(z,c0F,'class',52,x7F,o6F,gg)
var hAG=_v()
_(c0F,hAG)
if(_oz(z,53,x7F,o6F,gg)){hAG.wxVkey=1
var oBG=_mz(z,'view',['bindtap',54,'class',1,'data-event-opts',2],[],x7F,o6F,gg)
var oDG=_n('view')
_rz(z,oDG,'class',57,x7F,o6F,gg)
var lEG=_v()
_(oDG,lEG)
if(_oz(z,58,x7F,o6F,gg)){lEG.wxVkey=1
}
var aFG=_v()
_(oDG,aFG)
if(_oz(z,59,x7F,o6F,gg)){aFG.wxVkey=1
}
lEG.wxXCkey=1
aFG.wxXCkey=1
_(oBG,oDG)
var cCG=_v()
_(oBG,cCG)
if(_oz(z,60,x7F,o6F,gg)){cCG.wxVkey=1
}
var tGG=_v()
_(oBG,tGG)
var eHG=function(oJG,bIG,xKG,gg){
var fMG=_v()
_(xKG,fMG)
if(_oz(z,65,oJG,bIG,gg)){fMG.wxVkey=1
}
fMG.wxXCkey=1
return xKG
}
tGG.wxXCkey=2
_2z(z,63,eHG,x7F,o6F,gg,tGG,'j','k','k')
var cNG=_n('view')
_rz(z,cNG,'class',66,x7F,o6F,gg)
var hOG=_v()
_(cNG,hOG)
if(_oz(z,67,x7F,o6F,gg)){hOG.wxVkey=1
}
var oPG=_v()
_(cNG,oPG)
if(_oz(z,68,x7F,o6F,gg)){oPG.wxVkey=1
}
hOG.wxXCkey=1
oPG.wxXCkey=1
_(oBG,cNG)
cCG.wxXCkey=1
_(hAG,oBG)
}
else{hAG.wxVkey=2
var cQG=_n('view')
_rz(z,cQG,'class',69,x7F,o6F,gg)
var oRG=_v()
_(cQG,oRG)
if(_oz(z,70,x7F,o6F,gg)){oRG.wxVkey=1
var lSG=_n('view')
_rz(z,lSG,'class',71,x7F,o6F,gg)
var aTG=_v()
_(lSG,aTG)
if(_oz(z,72,x7F,o6F,gg)){aTG.wxVkey=1
}
var tUG=_v()
_(lSG,tUG)
if(_oz(z,73,x7F,o6F,gg)){tUG.wxVkey=1
}
var eVG=_v()
_(lSG,eVG)
if(_oz(z,74,x7F,o6F,gg)){eVG.wxVkey=1
}
aTG.wxXCkey=1
tUG.wxXCkey=1
eVG.wxXCkey=1
_(oRG,lSG)
}
else{oRG.wxVkey=2
}
oRG.wxXCkey=1
_(hAG,cQG)
}
hAG.wxXCkey=1
_(o8F,c0F)
return o8F
}
e4F.wxXCkey=2
_2z(z,50,b5F,e,s,gg,e4F,'item','index','index')
var x1E=_v()
_(oZE,x1E)
if(_oz(z,75,e,s,gg)){x1E.wxVkey=1
var bWG=_mz(z,'u-loadmore',['bind:__l',76,'class',1,'loadText',2,'marginTop',3,'status',4,'vueId',5],[],e,s,gg)
_(x1E,bWG)
}
var o2E=_v()
_(oZE,o2E)
if(_oz(z,82,e,s,gg)){o2E.wxVkey=1
var oXG=_mz(z,'u-empty',['bind:__l',83,'class',1,'marginTop',2,'mode',3,'text',4,'vueId',5],[],e,s,gg)
_(o2E,oXG)
}
var f3E=_v()
_(oZE,f3E)
if(_oz(z,89,e,s,gg)){f3E.wxVkey=1
var xYG=_mz(z,'u-empty',['bind:__l',90,'class',1,'marginTop',2,'mode',3,'text',4,'vueId',5],[],e,s,gg)
_(f3E,xYG)
}
x1E.wxXCkey=1
x1E.wxXCkey=3
o2E.wxXCkey=1
o2E.wxXCkey=3
f3E.wxXCkey=1
f3E.wxXCkey=3
_(oRE,oZE)
var oTE=_v()
_(oRE,oTE)
if(_oz(z,96,e,s,gg)){oTE.wxVkey=1
var oZG=_mz(z,'dc-hiro-painter',['bind:__l',97,'bind:closeShare',1,'bind:shareUrl',2,'class',3,'data-event-opts',4,'shareObj',5,'vueId',6],[],e,s,gg)
_(oTE,oZG)
}
var lUE=_v()
_(oRE,lUE)
if(_oz(z,104,e,s,gg)){lUE.wxVkey=1
var f1G=_mz(z,'login-pop',['bind:__l',105,'bind:closeUser',1,'class',2,'data-event-opts',3,'vueId',4],[],e,s,gg)
_(lUE,f1G)
}
var c2G=_mz(z,'u-skeleton',['animation',110,'bgColor',1,'bind:__l',2,'class',3,'loading',4,'vueId',5],[],e,s,gg)
_(oRE,c2G)
var h3G=_mz(z,'u-action-sheet',['bind:__l',116,'bind:click',1,'bind:input',2,'class',3,'data-event-opts',4,'list',5,'style',6,'value',7,'vueId',8],[],e,s,gg)
_(oRE,h3G)
cSE.wxXCkey=1
cSE.wxXCkey=3
oTE.wxXCkey=1
oTE.wxXCkey=3
lUE.wxXCkey=1
lUE.wxXCkey=3
_(r,oRE)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_23";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_23();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/example/home.wxml'] = [$gwx_XC_23, './pages/example/home.wxml'];else __wxAppCode__['pages/example/home.wxml'] = $gwx_XC_23( './pages/example/home.wxml' );
	;__wxRoute = "pages/example/home";__wxRouteBegin = true;__wxAppCurrentFile__="pages/example/home.js";define("pages/example/home.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
(global.webpackJsonp=global.webpackJsonp||[]).push([["pages/example/home"],{55:function(e,t,i){"use strict";(function(e){i(5),n(i(4));var t=n(i(56));function n(e){return e&&e.__esModule?e:{default:e}}wx.__webpack_require_UNI_MP_PLUGIN__=i,e(t.default)}).call(this,i(1).createPage)},56:function(e,t,i){"use strict";i.r(t);var n=i(57),o=i(59);for(var s in o)"default"!==s&&function(e){i.d(t,e,(function(){return o[e]}))}(s);i(62),i(64);var a=i(17),c=Object(a.default)(o.default,n.render,n.staticRenderFns,!1,null,"1375c95d",null,!1,n.components,void 0);c.options.__file="pages/example/home.vue",t.default=c.exports},57:function(e,t,i){"use strict";i.r(t);var n=i(58);i.d(t,"render",(function(){return n.render})),i.d(t,"staticRenderFns",(function(){return n.staticRenderFns})),i.d(t,"recyclableRender",(function(){return n.recyclableRender})),i.d(t,"components",(function(){return n.components}))},58:function(e,t,i){"use strict";var n;i.r(t),i.d(t,"render",(function(){return o})),i.d(t,"staticRenderFns",(function(){return a})),i.d(t,"recyclableRender",(function(){return s})),i.d(t,"components",(function(){return n}));try{n={uIcon:function(){return i.e("uview-ui/components/u-icon/u-icon").then(i.bind(null,854))},uLoadmore:function(){return i.e("uview-ui/components/u-loadmore/u-loadmore").then(i.bind(null,861))},uEmpty:function(){return i.e("uview-ui/components/u-empty/u-empty").then(i.bind(null,868))},dcHiroPainter:function(){return i.e("components/dc-hiro-painter/dc-hiro-painter").then(i.bind(null,875))},loginPop:function(){return i.e("components/login-pop/login-pop").then(i.bind(null,882))},uSkeleton:function(){return i.e("uview-ui/components/u-skeleton/u-skeleton").then(i.bind(null,889))},uActionSheet:function(){return i.e("uview-ui/components/u-action-sheet/u-action-sheet").then(i.bind(null,896))}}}catch(e){if(-1===e.message.indexOf("Cannot find module")||-1===e.message.indexOf(".vue"))throw e;console.error(e.message),console.error("1. 排查组件名称拼写是否正确"),console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"),console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件")}var o=function(){var e=this;e.$createElement,e._self._c,e._isMounted||(e.e0=function(t){e.userInfoHome.focusWechat=!0},e.e1=function(t){e.openReling=!1},e.e2=function(t){e.openReling=!1})},s=!1,a=[];o._withStripped=!0},59:function(e,t,i){"use strict";i.r(t);var n=i(60),o=i.n(n);for(var s in n)"default"!==s&&function(e){i.d(t,e,(function(){return n[e]}))}(s);t.default=o.a},60:function(e,t,i){"use strict";(function(e){Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var n=function(e){return e&&e.__esModule?e:{default:e}}(i(61)),o={data:function(){return{activityOwnNoData:!1,specialListNoData:!1,loadText:{loadmore:"上拉加载更多",loading:"努力加载中...",nomore:"暂无更多推荐团购"},loadStatus:"loading",showAct:!1,currentShequn:0,listShequn:["社群团购","群优选课堂"],openReling:!1,swiperWid:"360rpx",getUserBox:!1,loadingSke:!0,showMenu:!1,shareObj:{},showShares:!1,showSharesBox:!1,shareImgMini:"",menuStyle:{},countSubData:{canApply:.28,applying:0,total:.56,hasApply:0,recommend:.26,preReceiving:0},picListInfo:{titleName:"",picItemList:[]},activityLi:[],nickName:"",activityOwnLi:[],page:1,finished:!1,pageTwo:1,finishedTwo:!1,userInfoHome:{},createLog:[],topData:{activitys:"10",communitys:"10",solitaires:"10",unReadMsg:0},specialList:[],createLogShow:[],countIndes:2,topListData:[{title:"0手续费共同抗疫",content:"上海，深圳，沈阳，长春，免一个月手续费，3月27日-4月30日，加微信客服月底返还"},{title:"邀请奖励998元",content:"邀请优秀大卖团长入驻最高奖励998元；月交易大于30000元，订阅客户500人，奖励998元；月交易大于10000元，订阅客户300人，奖励399元；月交易5000元，订阅客户100人，奖励99元；每月15日结算，上月完成推荐。客服微信：18682001955"},{title:"免费微商相册",content:"微商相册可以免费使用，展示公司产品，客户订阅可以直接公众号提醒订阅客户，实时提醒团长产品动态"}],actionList:[{text:"开启接龙"},{text:"开启售后权益保障"},{text:"隐藏接龙"},{text:"暂停接龙"},{text:"结束接龙"},{text:"删除接龙"},{text:"置顶接龙"},{text:"取消置顶"}],activityEle:{},nowSite:"",topCust:30,lefCust:103,timerTotalData:null}},computed:{getIcon:function(){}},onShareAppMessage:function(t){console.log("onShareAppMessage==",t),e.getStorageSync("userInfo");var i={title:"给你推荐超好用的社群团购小程序，快来使用吧~",path:"/pages/example/home",imageUrl:"http://qiniuimg.kfmanager.com/qunjl/showrel/sharektthomess.png",success:function(e){e.errMsg}};if("button"==t.from&&"sharebtndefu"!=t.target.id){t.target.dataset;var n=this;i.imageUrl=n.shareImgMini,i.title=n.shareObj.title,i.path="/pages/subPage/showRel?"+n.shareObj.shareScene}return i},onShow:function(){var t=this,i=e.getStorageSync("userInfo");return 1==this.userInfoHome.userType&&2==i.userType?(Object.assign(this.$data,this.$options.data()),this.userInfoHome=i,console.log("员工登录免再登录",this.userInfoHome.userType),this.activityOwnLi=[],this.getTotalData(),this.getSystemTip(),this.actAllList(),this.getUserInfo(i.userId),this.getTopList(),this.loadingSke=!1,!1):2==this.userInfoHome.userType&&1==i.userType?(this.activityOwnLi=[],this.userInfoHome=i,this.getTotalData(),this.getSystemTip(),this.actAllList(),this.getUserInfo(i.userId),this.getTopList(),this.loadingSke=!1,!1):(this.userInfoHome.nickName!=i.nickName&&(this.userInfoHome.nickName=i.nickName),this.userInfoHome.headImg!=i.headImg&&(this.userInfoHome.headImg=i.headImg),this.userInfoHome.memberLevel!=i.memberLevel&&(this.userInfoHome.memberLevel=i.memberLevel),this.queryUserStatus(this.userInfoHome),console.log("this.userInfoHome.focusWechat",this.userInfoHome.focusWechat),setTimeout((function(){}),3e3),this.getTotalData(),void(this.timerTotalData=setInterval((function(){t.getTotalData()}),5e3)))},onPullDownRefresh:function(){console.log("下拉刷新"),1==this.currentShequn?(this.pageTwo=1,this.specialList=[],this.finishedTwo=!1,this.getSpecialList(1)):(this.page=1,this.loadStatus="loading",this.activityOwnLi=[],this.finished=!1,this.actAllList(1))},onReachBottom:function(){1==this.currentShequn?this.finishedTwo||(this.pageTwo++,this.getSpecialList(1)):this.finished||(this.loadStatus="loading",this.page++,this.actAllList())},onLoad:function(t){var i=this,n=wx.getMenuButtonBoundingClientRect();setTimeout((function(e){console.log("customTwo==1",n)}),1500),this.topCust=n.top,this.lefCust=n.width+22;var o=e.getStorageSync("userInfo");if(console.log("首页业务员接受参数",o),2==o.userType)return this.userInfoHome=o,this.opearatReLogin(),setTimeout((function(e){i.getSystemTip(),i.actAllList(),i.getUserInfo(o.userId),i.getTopList(),i.loadingSke=!1}),800),!1;console.log("员工登录免再登录bug--",this.vuex_userType);var s=this;if(t.scene){var a="",c="";10==t.scene.length&&(c=t.scene),11==t.scene.length&&(a=t.scene),wx.login({success:function(t){t.code&&s.$server.login({agentId:s.$agentId,code:t.code,salesmanMobile:a,recommendUserId:c}).then((function(t){if(!t||!t.userId)return e.showToast({title:"登录失败，请重新进入小程序",icon:"none"}),!1;console.log("首页绑定业务员登录111==",t);var i=t;s.nickName=i.nickName,s.userInfoHome=i,e.setStorageSync("userInfo",i),s.getSystemTip(),i.showCommunity?s.actAllList():(s.currentShequn=1,s.getSpecialList()),s.getUserInfo(i.userId),s.userInfoHome.defaultCity?s.userInfoHome.cityList.includes(s.userInfoHome.defaultCity)&&(s.nowSite=s.userInfoHome.defaultCity,console.log("默认城市-==",s.nowSite)):s.userInfoHome.activityCount&&e.showModal({title:"尊敬的群优选团长",content:"请选择您团购所在城市区域，设置后您的团购将展示给附近区域用户",showCancel:!0,cancelText:"以后再说",confirmText:"去选择",confirmColor:"#07c160",cancelColor:"#787878",success:function(e){e.cancel||e.confirm&&(console.log("用户点击确认"),s.chooseCity())}}),s.loadingSke=!1}))},fail:function(t){e.showToast({title:"登录失败，请重新进入小程序。",icon:"none"})}})}else wx.login({success:function(t){t.code&&s.$server.login({agentId:s.$agentId,code:t.code}).then((function(t){if(!t||!t.userId)return e.showToast({title:"登录失败，请重新进入小程序",icon:"none"}),!1;console.log("首页正常登录222==",t);var i=t;s.nickName=i.nickName,s.userInfoHome=i,s.loadingSke=!1,e.setStorageSync("userInfo",i),s.getSystemTip(),i.showCommunity?s.actAllList():(s.currentShequn=1,s.getSpecialList()),s.getUserInfo(i.userId),s.userInfoHome.defaultCity?s.userInfoHome.cityList.includes(s.userInfoHome.defaultCity)&&(s.nowSite=s.userInfoHome.defaultCity,console.log("默认城市-==",s.nowSite)):s.userInfoHome.activityCount&&e.showModal({title:"尊敬的群优选团长",content:"请选择您团购所在城市，设置后您的团购将展示给同城用户",showCancel:!0,cancelText:"以后再说",confirmText:"去选择",confirmColor:"#07c160",cancelColor:"#787878",success:function(e){e.cancel||e.confirm&&(console.log("用户点击确认"),s.chooseCity())}})}))},fail:function(t){e.showToast({title:"登录失败，请重新进入小程序。",icon:"none"})}});this.getTopList(),this.getTotalData()},onHide:function(){clearInterval(this.timerTotalData)},methods:{chooseCity:function(){var t=this;e.chooseLocation({success:function(i){console.log("全部",i);var o=n.default.intoMap(i);t.userInfoHome.cityList.includes(o.REGION_CITY)&&(t.nowSite=o.REGION_CITY,console.log("默认城市-==",t.nowSite));var s={province:o.REGION_PROVINCE,city:o.REGION_CITY,area:o.REGION_COUNTRY,latitude:i.latitude,longitude:i.longitude};t.$server.modifyLocatin(s).then((function(t){0==t.code&&e.showToast({title:"设置成功",icon:"success"})}))},fail:function(e){console.log("失败",e)}})},showTipf:function(e){e.showTip=!e.showTip},showTipD:function(t,i){var n=this;e.showModal({title:"确定不看TA的团了吗",content:"点击确认后，TA的团将不在列表出现，如需在本业重新查看TA的团，可进入TA的主页订阅即可",confirmText:"确认不看",cancelText:"我再想想",cancelColor:"#999",confirmColor:"#07c160",success:function(e){e.cancel?console.log("用户点击取消"):e.confirm&&n.subscribeUser(t,i)}})},subscribeUser:function(t,i){var n=this;this.$server.subscribeUser({targetUserId:t.userId,subscribeType:i}).then((function(o){0==o.code?(t.subscribe=!0,1==i?(e.showToast({title:"订阅成功",icon:"success"}),n.userInfoHome.focusWechat||e.navigateTo({url:"./weAccount"})):(e.showToast({title:"操作成功",icon:"none"}),n.page=1,n.finished=!1,n.activityOwnLi=[],n.actAllList())):e.showToast({title:o.message,icon:"none"})}))},clickAct:function(t){var i=this;if(1==t)return 2==this.activityEle.freezeFlag?(e.showToast({title:"已开启售后权益保障",icon:"none",duration:3e3}),!1):(e.showModal({title:"开启售后权益保障",content:"开启平台担保交易，提升客户对团购的信任，确保售后无忧，订单资金将在客户确认收货后，或满5天后，自动结算至可提现余额",confirmText:"确认",cancelText:"取消",confirmColor:"#07c160",success:function(e){e.cancel?console.log("用户点击取消"):e.confirm&&i.freezeFlagSwitch(2)}}),!1);var n=2;0!=t&&(n=t+1);var o="是否确认"+this.actionList[t].text,s="请确认是否"+this.actionList[t].text,a="#07c160",c="确定";5==t?(s="只能恢复近30天内删除的接龙",a="#ff4d4d",c="删除"):3==t&&(s="暂停接龙后，用户将不能下单",a="#ff4d4d",c="暂停"),e.showModal({title:o,content:s,confirmText:c,cancelText:"取消",confirmColor:a,success:function(e){e.cancel?console.log("用户点击取消"):e.confirm&&(t>=6?i.topOrCancel(t):i.updateStatus(n))}})},showMoring:function(e,t){this.activityEle=JSON.parse(JSON.stringify(e)),this.activityEle.indexRej=t,this.showAct=!0},topOrCancel:function(t){var i=this;this.$server.topOrCancel({activityId:this.activityEle.activityId,operatorType:t-4}).then((function(t){0==t.code?(e.showToast({title:"操作成功",icon:"success"}),i.page=1,i.finished=!1,i.activityOwnLi=[],i.actAllList()):e.showToast({title:t.message,icon:"none"})}))},freezeFlagSwitch:function(t){var i=this;this.$server.freezeFlagSwitch({activityId:this.activityEle.activityId,changeFlag:t}).then((function(t){0==t.code?(e.showToast({title:"开启成功",icon:"success"}),i.activityOwnLi[i.activityEle.indexRej].freezeFlag=2):e.showToast({title:t.message,icon:"none"})}))},updateStatus:function(t){var i=this;this.$server.updateStatus({activityId:this.activityEle.activityId,status:t}).then((function(t){0==t.code?(e.showToast({title:"操作成功",icon:"success"}),i.page=1,i.finished=!1,i.activityOwnLi=[],i.actAllList()):e.showToast({title:t.message,icon:"none"})}))},showMdal:function(t){e.showModal({title:this.topListData[t].title,content:this.topListData[t].content,showCancel:!1})},goMyhome:function(t){if(!t)return!1;e.navigateTo({url:"../subPage/myHome?uid="+t})},goEditAlb:function(t,i){if(!this.userInfoHome.nickName)return this.getUserBox=!0,!1;e.navigateTo({url:"../pageRelay/issueAlbums?id="+t+"&own="+i})},delOrEdi:function(e){if(!this.userInfoHome.nickName)return this.getUserBox=!0,!1;1==e.activityOwner?this.globalDowns(e.imgArrs,e.activityName):this.goEditAlb(e.activityId,e.activityOwner)},deleteAlbums:function(t){var i=this;e.showModal({title:"温馨提示",content:"删除图文后将不可恢复，确认要删除吗？",confirmText:"删除",confirmColor:"#FF0000",success:function(n){n.confirm?i.$server.deleteAlbums({albumsId:t}).then((function(t){0==t.code?(e.showToast({title:"删除成功",icon:"success"}),i.page=1,i.activityOwnLi=[],i.finished=!1,i.actAllList()):e.showToast({title:t.message,icon:"none"})})):n.cancel&&console.log("用户点击取消")}})},closeUser:function(e){console.log("关闭授权弹窗==",e),1!=e&&(this.userInfoHome=e),this.getUserBox=!1},shareUrl:function(e){this.shareImgMini=e},closeShare:function(e){console.log("关闭分享弹窗==",e),this.showShares=!1,this.shareObj={}},openShare:function(t,i){e.showLoading({title:"加载中",mask:!0}),i?(this.shareObj.headImg=this.userInfoHome.headImg||"https://qiniuimg.kfmanager.com/qunjl/showrel/miniqyxs.png",this.shareObj.nickName=this.userInfoHome.nickName||"群优选用户",this.shareObj.solitaireCount=this.userInfoHome.solitaireCount||"5",this.shareObj.solitaireCountShow=this.userInfoHome.solitaireCount+"次团购",this.shareObj.memberCount=this.userInfoHome.memberCount,this.shareObj.introduction=this.userInfoHome.introduction,this.shareObj.typeHome=!0,this.shareObj.shareScene="uid="+this.userInfoHome.userId):(this.shareObj.title=t.activityName,this.shareObj.freezeFlag=t.freezeFlag,this.shareObj.activityId=t.activityId,this.shareObj.headImg=t.headImg||"https://qiniuimg.kfmanager.com/qunjl/showrel/miniqyxs.png",this.shareObj.nickName=t.nickName||"群优选用户",this.shareObj.createTime=t.createTime.slice(0,10),this.shareObj.maxSellPriceShow="¥"+t.maxSellPriceShow,this.shareObj.shareBtn="我要团购",this.shareObj.shareScene="id="+t.activityId+"&uid="+this.userInfoHome.userId,this.shareObj.adminUserId=t.userId,t.imgArrs?this.shareObj.imgUrls=t.shareImgs:this.shareObj.imgUrls=[],t.orderInfos.length?this.shareObj.rankList=t.orderInfos:this.shareObj.rankList=!1),this.showShares=!0,setTimeout((function(t){e.hideLoading()}),500)},goKefu:function(){e.navigateTo({url:"../subPage/groupListKf"})},goOrder:function(t){e.navigateTo({url:"../subPage/showRel?id="+t})},goCode:function(t,i,n,o){o&&e.navigateTo({url:t+"?id="+i+"&type="+o}),n?e.navigateTo({url:t+"?id="+i+"&types="+n}):e.navigateTo({url:t+"?id="+i})},goCodeYj:function(t){this.$server.oneClickHelpSell({sourceActId:t}).then((function(t){0==t.code?(e.showToast({title:"帮卖成功",icon:"success",duration:2e3}),setTimeout((function(i){e.navigateTo({url:"../subPage/showRel?id="+t.data.activityId})}),1500)):e.showToast({title:t.message,icon:"none"})}))},getUserProfile:function(e){this.getUserBox=!0},perfectBaseInfo:function(t,i){var n=this;this.$server.perfectBaseInfo({encryptedData:t,iv:i}).then((function(t){t.nickName?(n.nickName=t.nickName,e.setStorageSync("userInfo",t)):e.showToast({title:t.message,icon:"none"})}))},switchTa:function(t){e.switchTab({url:t})},changeShequn:function(t){console.log("tab==",t),this.currentShequn==t?11==t&&e.navigateTo({url:"../pageRelay/pickerCity?i="+this.nowSite}):(this.currentShequn=t,1==this.currentShequn?!this.specialList.length&&this.getSpecialList():11==this.currentShequn?this.nowSite?(this.page=1,this.loadStatus="loading",this.activityOwnLi=[],this.finished=!1,this.activityOwnNoData=!1,this.actAllList()):e.navigateTo({url:"../pageRelay/pickerCity"}):(this.page=1,this.loadStatus="loading",this.activityOwnLi=[],this.finished=!1,this.activityOwnNoData=!1,this.actAllList()))},otherFun:function(e){this.nowSite=e,this.page=1,this.loadStatus="loading",this.activityOwnLi=[],this.activityOwnNoData=!1,this.finished=!1,this.actAllList()},goOther:function(t){e.navigateTo({url:"../pageRelay/"+t})},goPage:function(t){return t?this.userInfoHome.nickName?"99"==t?(this.openReling=!0,!1):"88"==t?(3==this.userInfoHome.suppliersStatus?e.navigateTo({url:"../solitaire/issueRelayPlus?supp=1"}):e.navigateTo({url:"../pageRelay/openSupplier"}),this.openReling=!0,!1):("77"==t?e.navigateTo({url:"../pageRelay/issueAlbums"}):"issueRelayPlus"==t?e.navigateTo({url:"../solitaire/issueRelayPlus"}):"toCat"==t&&e.navigateToMiniProgram({appId:"wx062bd450ef46f645",path:"pages/tabPage/home",extraData:{},success:function(e){}}),void e.navigateTo({url:"../subPage/"+t})):(this.getUserBox=!0,!1):(e.showToast({title:"暂未开放",icon:"none"}),!1)},getTopList:function(){var t=this;this.$server.queryActCreateLog({size:100}).then((function(i){if(0==i.code){var o=[],s=[];i.data.map((function(e,t){return e.differTime=n.default.getDifferTime(e.createTime,!1),e.nickName?e.nickName.length>3?e.showName=e.nickName.slice(0,3)+"**":e.showName=e.nickName:e.showName="***",s.push({showText:e.showName+"创建了一个接龙",differTime:e.differTime}),o.push(e.showName+"刚刚创建了一个团购"),e})),t.createLog=o}else e.showToast({title:i.message,icon:"none"})}))},getTotalData:function(){var t=this;this.$server.homeTotalData().then((function(i){0==i.code?t.topData=i.data:e.showToast({title:i.message,icon:"none"})}))},getSystemTip:function(){var e=this;this.$server.systemTipMsg().then((function(t){0==t.code&&3==t.data.tipsMsgList.length&&(console.log("topListData==",t.data.tipsMsgList),e.topListData=t.data.tipsMsgList)}))},getPicList:function(){var t=this;this.$server.sysPicList({imgType:1,terminalType:1}).then((function(i){0==i.code?t.picListInfo=i.data:e.showToast({title:i.message,icon:"none"})}))},getUserInfo:function(t){var i=this;this.$server.userIndexInfo({userId:t}).then((function(t){0==t.code?(i.userInfos=t.data,i.userInfoHome.memberCount=t.data.memberCount,i.userInfoHome.solitaireCount=t.data.solitaireCount,i.userInfoHome.introduction=t.data.introduction):e.showToast({title:t.message,icon:"none"})}))},getSpecialList:function(t){var i=this;this.$server.specialActList({page:this.pageTwo,pageSize:10}).then((function(o){if(0==o.code){if(1==i.pageTwo&&0==o.data.length)return i.specialListNoData=!0,i.loadingTwo=!1,void(i.finishedTwo=!0);o.data.length<10&&(i.loadingTwo=!1,i.finishedTwo=!0);var s=o.data.map((function(e){if(e.showsubscribe=!e.subscribe,20==e.activityType)e.differTime=n.default.getDifferTime(e.createTime,!1),e.albumsDetails.length?e.albumsDetails.forEach((function(t){1==t.contentType?e.imgArrs=t.albumsDetail.split(","):2==t.contentType?e.imgArrs=t.albumsDetail:(e.imgArrs=t.albumsDetail.split(","),e.hasVideo=!0)})):(e.imgArrs=[],e.hasVideo=!1);else{if(e.differTime=n.default.getDifferTime(e.createTime,!1),e.activityDetails.length){var t="";e.activityDetails.forEach((function(i){1==i.contentType?e.showTexts=i.activityDetail:(2==i.contentType||5==i.contentType)&&(t=0!=t.length?t+","+i.activityDetail:i.activityDetail)})),e.orderInfos.length&&e.orderInfos.forEach((function(e){e.differTime=n.default.getDifferTime(e.createTime,!1),e.nickName?e.nickName=e.nickName.slice(0,1)+"**":e.nickName="群**"})),0!=t.length?(console.log("cur.imgArrs==",t),e.shareImgs=t.split(","),e.imgArrs=t.split(",",3),console.log("cur.imgArrs==",e.imgArrs)):e.imgArrs=!1}else e.imgArrs=!1,e.orderInfos.length&&e.orderInfos.forEach((function(e){e.differTime=n.default.getDifferTime(e.createTime,!1),e.nickName?e.nickName=e.nickName.slice(0,1)+"**":e.nickName="群**"}));e.minMaxPrice.maxSellPrice==e.minMaxPrice.minSellPrice?e.maxSellPriceShow=n.default.centTurnSmacker(e.minMaxPrice.maxSellPrice/100):e.maxSellPriceShow=n.default.centTurnSmacker(e.minMaxPrice.minSellPrice/100)+"~"+n.default.centTurnSmacker(e.minMaxPrice.maxSellPrice/100)}return e.activityStatusTex=["正在接龙","接龙待发布","正在跟团中","接龙已下架","接龙已暂停","接龙已结束","接龙已删除"][e.activityStatus],e}));t&&1==t&&(e.stopPullDownRefresh(),e.showToast({title:"刷新成功",icon:"none"})),i.specialList=i.specialList.concat(s)}else e.showToast({title:o.message,icon:"none"})}))},actAllList:function(t){var i=this,o={page:this.page,pageSize:6};11==this.currentShequn&&(o.city=this.nowSite||"未选择"),this.$server.actAllList(o).then((function(o){if(0==o.code){if(1==i.page&&0==o.data.length)return i.activityOwnNoData=!0,i.finished=!0,i.loadStatus="nomore",void console.log("无数据");o.data.length<6&&(i.finished=!0,i.loadStatus="nomore",console.log("无更多数据"));var s=o.data.map((function(e){if(e.showsubscribe=!e.subscribe,20==e.activityType)e.differTime=n.default.getDifferTime(e.createTime,!1),e.albumsDetails.length?e.albumsDetails.forEach((function(t){1==t.contentType?e.imgArrs=t.albumsDetail.split(","):2==t.contentType?e.imgArrs=t.albumsDetail:(e.imgArrs=t.albumsDetail.split(","),e.hasVideo=!0)})):(e.imgArrs=[],e.hasVideo=!1);else{if(e.differTime=n.default.getDifferTime(e.createTime,!1),e.activityDetails.length){var t="";e.showTip=!1,e.activityDetails.forEach((function(i){1==i.contentType?e.showTexts=i.activityDetail:(2==i.contentType||5==i.contentType)&&(t=0!=t.length?t+","+i.activityDetail:i.activityDetail)})),e.orderInfos.length&&e.orderInfos.forEach((function(e){e.differTime=n.default.getDifferTime(e.createTime,!1),e.nickName?e.nickName=e.nickName.slice(0,1)+"**":e.nickName="群**"})),0!=t.length?(console.log("cur.imgArrs==",t),e.shareImgs=t.split(","),e.imgArrs=t.split(",",3),console.log("cur.imgArrs==",e.imgArrs)):e.imgArrs=!1}else e.imgArrs=!1,e.orderInfos.length&&e.orderInfos.forEach((function(e){e.differTime=n.default.getDifferTime(e.createTime,!1),e.nickName?e.nickName=e.nickName.slice(0,1)+"**":e.nickName="群**"}));e.minMaxPrice.maxSellPrice==e.minMaxPrice.minSellPrice?e.maxSellPriceShow=n.default.centTurnSmacker(e.minMaxPrice.maxSellPrice/100):e.maxSellPriceShow=n.default.centTurnSmacker(e.minMaxPrice.minSellPrice/100)+"~"+n.default.centTurnSmacker(e.minMaxPrice.maxSellPrice/100),2==e.freezeFlag?e.activityNameShow="&emsp;&emsp;&emsp; &emsp;&emsp;"+e.activityName:e.activityNameShow=e.activityName,e.activityStatusTex=["正在接龙","接龙待发布","正在跟团中","接龙已下架","接龙已暂停","接龙已结束","接龙已删除"][e.activityStatus]}return e}));t&&1==t&&(e.stopPullDownRefresh(),e.showToast({title:"刷新成功",icon:"none"})),i.activityOwnLi=i.activityOwnLi.concat(s),setTimeout((function(e){o.data.length<6?i.loadStatus="nomore":i.loadStatus="loadmore"}),200),console.log("活动获取数据==",i.loadStatus,i.finished,i.activityOwnNoData)}else e.showToast({title:o.message,icon:"none"})}))},actOwnList:function(){var t=this;this.$server.actOwnList({page:1,pageSize:10}).then((function(i){0==i.code?t.activityOwnLi=i.data:e.showToast({title:i.message,icon:"none"})}))}}};t.default=o}).call(this,i(1).default)},62:function(e,t,i){"use strict";i.r(t);var n=i(63),o=i.n(n);for(var s in n)"default"!==s&&function(e){i.d(t,e,(function(){return n[e]}))}(s);t.default=o.a},63:function(e,t,i){},64:function(e,t,i){"use strict";i.r(t);var n=i(65),o=i.n(n);for(var s in n)"default"!==s&&function(e){i.d(t,e,(function(){return n[e]}))}(s);t.default=o.a},65:function(e,t,i){}},[[55,"common/runtime","common/vendor"]]]);
},{isPage:true,isComponent:true,currentFile:'pages/example/home.js'});require("pages/example/home.js");