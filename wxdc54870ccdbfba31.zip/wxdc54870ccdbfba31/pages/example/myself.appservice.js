$gwx_XC_24=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_24 || [];
function gz$gwx_XC_24_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_24_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_24_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_24_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'home_tz data-v-75568576'])
Z([3,'hea_info data-v-75568576'])
Z([[2,'&&'],[[6],[[7],[3,'userInfoHome']],[3,'memberLevel']],[[6],[[7],[3,'userInfoHome']],[3,'activityCount']]])
Z([[6],[[7],[3,'userInfoHome']],[3,'activityCount']])
Z([[6],[[7],[3,'userInfoHome']],[3,'memberLevel']])
Z([3,'__e'])
Z([3,'ele_view fl_cb data-v-75568576'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[1,'goPage']]]]]]]]])
Z([3,'position:relative;'])
Z([3,'__l'])
Z([3,'data-v-75568576'])
Z([3,'new'])
Z([3,'18'])
Z([3,'[0,0]'])
Z([3,'357aaa50-1'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_24_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_24_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_24=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_24=true;
var x=['./pages/example/myself.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_24_1()
var c5G=_n('view')
_rz(z,c5G,'class',0,e,s,gg)
var o6G=_n('view')
_rz(z,o6G,'class',1,e,s,gg)
var l7G=_v()
_(o6G,l7G)
if(_oz(z,2,e,s,gg)){l7G.wxVkey=1
}
else{l7G.wxVkey=2
var t9G=_v()
_(l7G,t9G)
if(_oz(z,3,e,s,gg)){t9G.wxVkey=1
}
t9G.wxXCkey=1
}
var a8G=_v()
_(o6G,a8G)
if(_oz(z,4,e,s,gg)){a8G.wxVkey=1
}
l7G.wxXCkey=1
a8G.wxXCkey=1
_(c5G,o6G)
var e0G=_mz(z,'view',['bindtap',5,'class',1,'data-event-opts',2,'style',3],[],e,s,gg)
var bAH=_mz(z,'u-badge',['bind:__l',9,'class',1,'count',2,'fontSize',3,'offset',4,'vueId',5],[],e,s,gg)
_(e0G,bAH)
_(c5G,e0G)
_(r,c5G)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_24";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_24();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/example/myself.wxml'] = [$gwx_XC_24, './pages/example/myself.wxml'];else __wxAppCode__['pages/example/myself.wxml'] = $gwx_XC_24( './pages/example/myself.wxml' );
	;__wxRoute = "pages/example/myself";__wxRouteBegin = true;__wxAppCurrentFile__="pages/example/myself.js";define("pages/example/myself.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
(global.webpackJsonp=global.webpackJsonp||[]).push([["pages/example/myself"],{66:function(e,n,t){"use strict";(function(e){t(5),o(t(4));var n=o(t(67));function o(e){return e&&e.__esModule?e:{default:e}}wx.__webpack_require_UNI_MP_PLUGIN__=t,e(n.default)}).call(this,t(1).createPage)},67:function(e,n,t){"use strict";t.r(n);var o=t(68),u=t(70);for(var a in u)"default"!==a&&function(e){t.d(n,e,(function(){return u[e]}))}(a);t(72);var r=t(17),c=Object(r.default)(u.default,o.render,o.staticRenderFns,!1,null,"75568576",null,!1,o.components,void 0);c.options.__file="pages/example/myself.vue",n.default=c.exports},68:function(e,n,t){"use strict";t.r(n);var o=t(69);t.d(n,"render",(function(){return o.render})),t.d(n,"staticRenderFns",(function(){return o.staticRenderFns})),t.d(n,"recyclableRender",(function(){return o.recyclableRender})),t.d(n,"components",(function(){return o.components}))},69:function(e,n,t){"use strict";var o;t.r(n),t.d(n,"render",(function(){return u})),t.d(n,"staticRenderFns",(function(){return r})),t.d(n,"recyclableRender",(function(){return a})),t.d(n,"components",(function(){return o}));try{o={uBadge:function(){return t.e("uview-ui/components/u-badge/u-badge").then(t.bind(null,903))}}}catch(e){if(-1===e.message.indexOf("Cannot find module")||-1===e.message.indexOf(".vue"))throw e;console.error(e.message),console.error("1. 排查组件名称拼写是否正确"),console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"),console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件")}var u=function(){this.$createElement,this._self._c},a=!1,r=[];u._withStripped=!0},70:function(e,n,t){"use strict";t.r(n);var o=t(71),u=t.n(o);for(var a in o)"default"!==a&&function(e){t.d(n,e,(function(){return o[e]}))}(a);n.default=u.a},71:function(e,n,t){"use strict";(function(e){Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var o=function(e){return e&&e.__esModule?e:{default:e}}(t(61)),u={data:function(){return{menuStyle:{},userInfoHome:{},balanceNum:"***",countSubData:{totalMoney:"0.00",refundMoney:"0.00",totalOrder:0,pendingMoney:"0.00"}}},computed:{getIcon:function(){}},onLoad:function(){this.userInfoHome=e.getStorageSync("userInfo"),this.userInfoHome.nickName.length>8&&(this.userInfoHome.nickName=this.userInfoHome.nickName.slice(0,7)+"..."),this.userTodaySellData(),e.hideShareMenu({})},onShow:function(){var n=this;setTimeout((function(){n.userInfoHome=e.getStorageSync("userInfo"),n.userInfoHome.nickName.length>8&&(n.userInfoHome.nickName=n.userInfoHome.nickName.slice(0,7)+"..."),2!=n.userInfoHome.userType?n.getBalance():n.balanceNum="***"}),200)},methods:{getBalance:function(){var n=this;this.$server.balance().then((function(t){0==t.code?n.balanceNum=o.default.centTurnSmacker(t.data.balance/100):e.showToast({title:t.message,icon:"none"})}))},switchTa:function(n){e.switchTab({url:n})},goKefu:function(){e.navigateTo({url:"../subPage/groupListKf"})},goPage:function(n){return console.log("e==",n),n?"../solitaire/issueRelayPlus"!=n||this.userInfoHome.nickName?"../authAgent/addHome"==n&&2==this.userInfoHome.userType||"../subPage/myFund"==n&&2==this.userInfoHome.userType?(e.showToast({title:"您暂无权限操作",icon:"none"}),!1):"../pageRelay/openSupplier"==n&&3==this.userInfoHome.suppliersStatus?(e.showToast({title:"您已通过审核，将为您跳转至供应商开团页",icon:"none"}),setTimeout((function(n){e.navigateTo({url:"../solitaire/issueRelayPlus?supp=1"})}),1500),!1):void e.navigateTo({url:n}):(e.showToast({title:"请先授权登录",icon:"none"}),!1):(console.log("!e==",n),e.navigateTo({url:"../pageRelay/supplierList"}),!1)},userTodaySellData:function(){var n=this;this.$server.userTodaySellData().then((function(t){0==t.code?(n.countSubData.totalMoney=o.default.centTurnSmacker(t.data.totalMoney/100),n.countSubData.pendingMoney=o.default.centTurnSmacker(t.data.pendingMoney/100),n.countSubData.refundMoney=o.default.centTurnSmacker(t.data.refundMoney/100),n.countSubData.totalOrder=t.data.totalOrder):e.showToast({title:t.message,icon:"none"})}))},loginTip:function(){var n=this;e.showModal({title:"温馨提示",content:"您已登录副团长角色账号，是否确认退出",confirmText:"退出",cancelText:"取消",confirmColor:"#ff4d4d",success:function(e){e.cancel?console.log("用户点击取消"):e.confirm&&n.loginPage()}})},loginPage:function(){var n=this;wx.login({success:function(t){var o=this;t.code&&n.$server.login({agentId:n.$agentId,code:t.code}).then((function(t){console.log("切换账号正常登录==",t);var u=t;n.userInfoHome=u,o.$u.vuex("vuex_userType",1),e.setStorageSync("userInfo",u),e.switchTab({url:"./home"})}))}})}}};n.default=u}).call(this,t(1).default)},72:function(e,n,t){"use strict";t.r(n);var o=t(73),u=t.n(o);for(var a in o)"default"!==a&&function(e){t.d(n,e,(function(){return o[e]}))}(a);n.default=u.a},73:function(e,n,t){}},[[66,"common/runtime","common/vendor"]]]);
},{isPage:true,isComponent:true,currentFile:'pages/example/myself.js'});require("pages/example/myself.js");