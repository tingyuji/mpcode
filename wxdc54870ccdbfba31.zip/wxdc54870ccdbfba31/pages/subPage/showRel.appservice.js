$gwx_XC_41=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_41 || [];
function gz$gwx_XC_41_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_41_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_41_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_41_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'award_join u-skeleton data-v-207aa5d3'])
Z([[7],[3,'paddingSa']])
Z([[6],[[7],[3,'msg']],[3,'length']])
Z([[2,'!'],[[6],[[7],[3,'shopDatas']],[3,'subscribe']]])
Z([3,'center_main data-v-207aa5d3'])
Z([3,'padding-bottom:0;'])
Z([3,'act_dels data-v-207aa5d3'])
Z([[2,'!'],[[6],[[7],[3,'userInfoHome']],[3,'focusWechat']]])
Z([3,'__l'])
Z([3,'__e'])
Z([3,'data-v-207aa5d3'])
Z([3,'#909399'])
Z([[4],[[5],[[4],[[5],[[5],[1,'^click']],[[4],[[5],[[4],[[5],[1,'e0']]]]]]]]])
Z([3,'close'])
Z([3,'22'])
Z([3,'224ad4da-1'])
Z(z[7])
Z([[2,'=='],[[6],[[7],[3,'shopDatas']],[3,'freezeFlag']],[1,2]])
Z([[6],[[6],[[7],[3,'shopDatas']],[3,'rewardList']],[3,'length']])
Z([3,'ii'])
Z([3,'zi'])
Z([[6],[[7],[3,'shopDatas']],[3,'rewardList']])
Z(z[19])
Z([[2,'=='],[[6],[[7],[3,'zi']],[3,'rewardType']],[1,4]])
Z([[7],[3,'loading']])
Z(z[24])
Z(z[24])
Z(z[24])
Z([[2,'&&'],[[6],[[6],[[7],[3,'shopDatas']],[3,'activityDetails']],[3,'length']],[[2,'!'],[[7],[3,'loading']]]])
Z([3,'index'])
Z([3,'item'])
Z([[6],[[7],[3,'shopDatas']],[3,'activityDetails']])
Z(z[29])
Z([3,'medail_ele data-v-207aa5d3'])
Z([[2,'=='],[[6],[[7],[3,'item']],[3,'contentType']],[1,1]])
Z([[2,'=='],[[6],[[7],[3,'item']],[3,'contentType']],[1,2]])
Z([[2,'=='],[[6],[[7],[3,'item']],[3,'contentType']],[1,3]])
Z([[2,'=='],[[6],[[7],[3,'item']],[3,'contentType']],[1,4]])
Z(z[9])
Z([3,'big_imggs fl data-v-207aa5d3'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'openLoc']],[[4],[[5],[[4],[[5],[[5],[[5],[[5],[1,'o']],[[4],[[5],[[5],[1,'latitude']],[[6],[[6],[[7],[3,'item']],[3,'addressData']],[1,1]]]]],[[4],[[5],[[5],[1,'longitude']],[[6],[[6],[[7],[3,'item']],[3,'addressData']],[1,2]]]]],[[4],[[5],[[5],[1,'addressName']],[[6],[[6],[[7],[3,'item']],[3,'addressData']],[1,0]]]]]]]]]]]]]]]])
Z([3,'color:#09ba08;font-weight:bold;'])
Z(z[8])
Z(z[10])
Z([3,'#09ba08'])
Z([3,'map-fill'])
Z([3,'40'])
Z([[2,'+'],[1,'224ad4da-2-'],[[7],[3,'index']]])
Z([[2,'=='],[[6],[[7],[3,'item']],[3,'contentType']],[1,5]])
Z(z[9])
Z([3,'big_imgg data-v-207aa5d3'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'globalYulan']],[[4],[[5],[[5],[1,'$0']],[1,'$1']]]],[[4],[[5],[[5],[1,'shopDatas.bigImgArr']],[[4],[[5],[[4],[[5],[[5],[[5],[[5],[1,'shopDatas.activityDetails']],[1,'']],[[7],[3,'index']]],[1,'bigImgInd']]]]]]]]]]]]]]])
Z(z[8])
Z([3,'4rpx'])
Z([3,'big_isme data-v-207aa5d3'])
Z([3,'widthFix'])
Z([[6],[[7],[3,'item']],[3,'activityDetail']])
Z([[2,'+'],[1,'224ad4da-3-'],[[7],[3,'index']]])
Z([[4],[[5],[1,'loading']]])
Z(z[8])
Z(z[10])
Z([3,'flower'])
Z([3,'loading'])
Z([[2,'+'],[[2,'+'],[[2,'+'],[1,'224ad4da-4-'],[[7],[3,'index']]],[1,',']],[[2,'+'],[1,'224ad4da-3-'],[[7],[3,'index']]]])
Z([[2,'||'],[[2,'=='],[[7],[3,'cssShow']],[1,1]],[[2,'=='],[[7],[3,'cssShow']],[1,2]]])
Z([3,'class_con1 shop_outhei data-v-207aa5d3'])
Z([[2,'&&'],[[7],[3,'isStickyTwo']],[[2,'=='],[[7],[3,'cssShow']],[1,2]]])
Z([3,'indexs'])
Z([3,'items'])
Z([[7],[3,'tabbar']])
Z(z[67])
Z(z[29])
Z(z[30])
Z([[6],[[7],[3,'items']],[3,'shopList']])
Z(z[29])
Z(z[10])
Z([3,'width:100%;'])
Z(z[9])
Z([[4],[[5],[[5],[1,'data-v-207aa5d3']],[[2,'?:'],[[2,'=='],[[6],[[7],[3,'item']],[3,'spikeFlag']],[1,2]],[1,'class_right_list_tit textin60'],[1,'class_right_list_tit']]]])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'openSkuElFl']],[[4],[[5],[[5],[[5],[[5],[1,'$0']],[1,'$1']],[[7],[3,'index']]],[[7],[3,'indexs']]]]],[[4],[[5],[[5],[[4],[[5],[[4],[[5],[[5],[[5],[1,'tabbar']],[1,'']],[[7],[3,'indexs']]]]]]],[[4],[[5],[[5],[[4],[[5],[[5],[[5],[1,'tabbar']],[1,'']],[[7],[3,'indexs']]]]],[[4],[[5],[[5],[[5],[1,'shopList']],[1,'']],[[7],[3,'index']]]]]]]]]]]]]]]])
Z([3,'flex:1;position:relative;'])
Z([[2,'&&'],[[2,'=='],[[6],[[7],[3,'item']],[3,'spikeFlag']],[1,2]],[[2,'!='],[[6],[[7],[3,'item']],[3,'timestampyrj']],[[2,'-'],[1,99]]]])
Z([[2,'=='],[[6],[[7],[3,'item']],[3,'spikeFlag']],[1,2]])
Z([[2,'>'],[[6],[[7],[3,'item']],[3,'timestampyrj']],[1,0]])
Z(z[8])
Z(z[9])
Z([3,'data-v-207aa5d3 vue-ref-in-for'])
Z([3,'#ff7622'])
Z([[4],[[5],[[4],[[5],[[5],[1,'^end']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'endTimestamp']],[[4],[[5],[1,'$0']]]],[[4],[[5],[[4],[[5],[[5],[[4],[[5],[[5],[[5],[1,'tabbar']],[1,'']],[[7],[3,'indexs']]]]],[[4],[[5],[[5],[[5],[1,'shopList']],[1,'']],[[7],[3,'index']]]]]]]]]]]]]]]])
Z([3,'uCountDown'])
Z([3,'24'])
Z(z[87])
Z(z[90])
Z([1,false])
Z([[6],[[7],[3,'item']],[3,'timestampyrj']])
Z([[2,'+'],[[2,'+'],[[2,'+'],[1,'224ad4da-5-'],[[7],[3,'indexs']]],[1,'-']],[[7],[3,'index']]])
Z([[6],[[6],[[6],[[7],[3,'item']],[3,'commodityDetails']],[1,0]],[3,'commodityDetail']])
Z([3,'class_right_list_ftit fl_sb data-v-207aa5d3'])
Z(z[10])
Z([3,'margin-bottom:16rpx;'])
Z([[2,'&&'],[[2,'!='],[[6],[[7],[3,'item']],[3,'limitBuy']],[1,99999]],[[2,'!='],[[6],[[7],[3,'item']],[3,'limitBuy']],[1,0]]])
Z([[2,'&&'],[[2,'<'],[[6],[[7],[3,'item']],[3,'defaultStock']],[1,20]],[[2,'!'],[[6],[[7],[3,'item']],[3,'formatSize']]]])
Z([[6],[[7],[3,'item']],[3,'commoditySellCount']])
Z([[2,'||'],[[2,'=='],[[6],[[7],[3,'item']],[3,'needBuy']],[1,1]],[[2,'=='],[[6],[[7],[3,'item']],[3,'needBuy']],[[2,'-'],[1,2]]]])
Z([[2,'=='],[[6],[[7],[3,'item']],[3,'groupFlag']],[1,2]])
Z([[2,'!='],[[6],[[7],[3,'item']],[3,'minSellPriceShGr']],[[6],[[7],[3,'item']],[3,'maxSellPriceShGr']]])
Z([3,'class_right_list_jg data-v-207aa5d3'])
Z([[2,'!='],[[6],[[7],[3,'item']],[3,'minSellPriceSh']],[[6],[[7],[3,'item']],[3,'maxSellPriceSh']]])
Z([[6],[[7],[3,'item']],[3,'minUnderLinePriceSh']])
Z([[2,'!='],[[6],[[7],[3,'item']],[3,'minUnderLinePriceSh']],[[6],[[7],[3,'item']],[3,'maxUnderLinePriceSh']]])
Z([[6],[[6],[[7],[3,'item']],[3,'minMaxPrice']],[3,'minWeight']])
Z([[2,'!='],[[6],[[6],[[7],[3,'item']],[3,'minMaxPrice']],[3,'maxWeight']],[[6],[[6],[[7],[3,'item']],[3,'minMaxPrice']],[3,'minWeight']]])
Z([[2,'&&'],[[6],[[7],[3,'item']],[3,'sellCommission']],[[7],[3,'canAppl']]])
Z([[2,'&&'],[[2,'=='],[[6],[[7],[3,'shopDatas']],[3,'activityStatus']],[1,2]],[[2,'=='],[[6],[[7],[3,'item']],[3,'groupFlag']],[1,2]]])
Z([[2,'&&'],[[2,'=='],[[6],[[7],[3,'shopDatas']],[3,'activityStatus']],[1,2]],[[2,'!'],[[6],[[7],[3,'item']],[3,'formatSize']]]])
Z([3,'flex align-center just-end data-v-207aa5d3'])
Z(z[9])
Z([3,'class_right_list_btn data-v-207aa5d3'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'setShopCarNum']],[[4],[[5],[[5],[1,'$0']],[1,1]]]],[[4],[[5],[[4],[[5],[[5],[[4],[[5],[[5],[[5],[1,'tabbar']],[1,'']],[[7],[3,'indexs']]]]],[[4],[[5],[[5],[[5],[1,'shopList']],[1,'']],[[7],[3,'index']]]]]]]]]]]]]]]])
Z([[2,'!'],[[2,'!'],[[6],[[7],[3,'item']],[3,'eleShopNumOut']]]])
Z(z[8])
Z(z[10])
Z([3,'#07c160'])
Z([3,'plus-circle-fill'])
Z([3,'60'])
Z([[2,'+'],[[2,'+'],[[2,'+'],[1,'224ad4da-6-'],[[7],[3,'indexs']]],[1,'-']],[[7],[3,'index']]])
Z([3,'fl num_jis mt20 data-v-207aa5d3'])
Z([[2,'!'],[[6],[[7],[3,'item']],[3,'eleShopNumOut']]])
Z(z[8])
Z(z[9])
Z(z[10])
Z(z[122])
Z([[4],[[5],[[4],[[5],[[5],[1,'^click']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'setShopCarNum']],[[4],[[5],[[5],[1,'$0']],[[2,'-'],[1,1]]]]],[[4],[[5],[[4],[[5],[[5],[[4],[[5],[[5],[[5],[1,'tabbar']],[1,'']],[[7],[3,'indexs']]]]],[[4],[[5],[[5],[[5],[1,'shopList']],[1,'']],[[7],[3,'index']]]]]]]]]]]]]]]])
Z([3,'minus-circle'])
Z(z[124])
Z([[2,'+'],[[2,'+'],[[2,'+'],[1,'224ad4da-7-'],[[7],[3,'indexs']]],[1,'-']],[[7],[3,'index']]])
Z(z[8])
Z(z[9])
Z(z[10])
Z(z[122])
Z([[4],[[5],[[4],[[5],[[5],[1,'^click']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'setShopCarNum']],[[4],[[5],[[5],[1,'$0']],[1,1]]]],[[4],[[5],[[4],[[5],[[5],[[4],[[5],[[5],[[5],[1,'tabbar']],[1,'']],[[7],[3,'indexs']]]]],[[4],[[5],[[5],[[5],[1,'shopList']],[1,'']],[[7],[3,'index']]]]]]]]]]]]]]]])
Z(z[123])
Z(z[124])
Z([[2,'+'],[[2,'+'],[[2,'+'],[1,'224ad4da-8-'],[[7],[3,'indexs']]],[1,'-']],[[7],[3,'index']]])
Z([[2,'=='],[[6],[[7],[3,'shopDatas']],[3,'activityStatus']],[1,2]])
Z(z[9])
Z(z[117])
Z(z[79])
Z(z[8])
Z(z[10])
Z(z[122])
Z(z[123])
Z(z[124])
Z([[2,'+'],[[2,'+'],[[2,'+'],[1,'224ad4da-9-'],[[7],[3,'indexs']]],[1,'-']],[[7],[3,'index']]])
Z([[2,'=='],[[7],[3,'cssShow']],[1,3]])
Z([3,'css_show shop_outhei data-v-207aa5d3'])
Z([3,'搜索'])
Z([1,true])
Z(z[8])
Z(z[9])
Z(z[9])
Z(z[9])
Z(z[9])
Z(z[10])
Z([[4],[[5],[[5],[[5],[[5],[[4],[[5],[[5],[1,'^change']],[[4],[[5],[[4],[[5],[1,'searchFunsCh']]]]]]]],[[4],[[5],[[5],[1,'^search']],[[4],[[5],[[4],[[5],[1,'searchFuns']]]]]]]],[[4],[[5],[[5],[1,'^custom']],[[4],[[5],[[4],[[5],[1,'searchFuns']]]]]]]],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'searchContent']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z([3,'80'])
Z([3,'搜索商品名称'])
Z([3,'square'])
Z(z[157])
Z(z[76])
Z([[7],[3,'searchContent']])
Z([3,'224ad4da-10'])
Z(z[67])
Z(z[68])
Z(z[69])
Z(z[67])
Z(z[29])
Z(z[30])
Z(z[73])
Z(z[29])
Z(z[10])
Z([3,'width:356rpx;padding-left:20rpx;box-sizing:border-box;'])
Z(z[9])
Z(z[78])
Z(z[79])
Z(z[80])
Z(z[81])
Z(z[82])
Z(z[83])
Z(z[8])
Z(z[9])
Z(z[86])
Z(z[87])
Z(z[88])
Z(z[89])
Z(z[90])
Z(z[87])
Z(z[90])
Z(z[93])
Z(z[94])
Z([[2,'+'],[[2,'+'],[[2,'+'],[1,'224ad4da-11-'],[[7],[3,'indexs']]],[1,'-']],[[7],[3,'index']]])
Z(z[96])
Z(z[97])
Z(z[10])
Z(z[99])
Z(z[100])
Z(z[101])
Z(z[102])
Z(z[103])
Z(z[104])
Z(z[105])
Z(z[106])
Z(z[107])
Z([[2,'&&'],[[6],[[7],[3,'item']],[3,'minUnderLinePriceSh']],[[2,'!'],[[6],[[7],[3,'item']],[3,'formatSize']]]])
Z(z[109])
Z(z[110])
Z(z[111])
Z(z[112])
Z(z[113])
Z(z[114])
Z(z[115])
Z([3,'width:324rpx;'])
Z(z[9])
Z(z[117])
Z(z[118])
Z(z[119])
Z(z[8])
Z(z[10])
Z(z[122])
Z(z[123])
Z(z[124])
Z([[2,'+'],[[2,'+'],[[2,'+'],[1,'224ad4da-12-'],[[7],[3,'indexs']]],[1,'-']],[[7],[3,'index']]])
Z(z[126])
Z(z[127])
Z(z[8])
Z(z[9])
Z(z[10])
Z(z[122])
Z(z[132])
Z(z[133])
Z(z[124])
Z([[2,'+'],[[2,'+'],[[2,'+'],[1,'224ad4da-13-'],[[7],[3,'indexs']]],[1,'-']],[[7],[3,'index']]])
Z(z[8])
Z(z[9])
Z(z[10])
Z(z[122])
Z(z[140])
Z(z[123])
Z(z[124])
Z([[2,'+'],[[2,'+'],[[2,'+'],[1,'224ad4da-14-'],[[7],[3,'indexs']]],[1,'-']],[[7],[3,'index']]])
Z(z[144])
Z(z[9])
Z(z[117])
Z(z[79])
Z(z[8])
Z(z[10])
Z(z[122])
Z(z[123])
Z(z[124])
Z([[2,'+'],[[2,'+'],[[2,'+'],[1,'224ad4da-15-'],[[7],[3,'indexs']]],[1,'-']],[[7],[3,'index']]])
Z([[2,'&&'],[[2,'&&'],[[2,'&&'],[[2,'=='],[[6],[[7],[3,'shopDatas']],[3,'activityType']],[1,1]],[[2,'=='],[[6],[[7],[3,'shopDatas']],[3,'canHelpSellFlag']],[1,2]]],[[2,'!='],[[7],[3,'isMe']],[1,1]]],[[7],[3,'canAppl']]])
Z([[2,'&&'],[[2,'&&'],[[2,'&&'],[[2,'=='],[[6],[[7],[3,'shopDatas']],[3,'activityType']],[1,1]],[[2,'=='],[[6],[[7],[3,'shopDatas']],[3,'canHelpSellFlag']],[1,2]]],[[2,'!='],[[7],[3,'isMe']],[1,1]]],[[6],[[7],[3,'shopDatas']],[3,'oneClickHelpSell']]])
Z([[2,'&&'],[[2,'&&'],[[2,'=='],[[6],[[7],[3,'shopDatas']],[3,'activityType']],[1,1]],[[2,'!='],[[7],[3,'isMe']],[1,1]]],[[7],[3,'canCopys']]])
Z([[2,'&&'],[[2,'&&'],[[2,'&&'],[[2,'=='],[[6],[[7],[3,'shopDatas']],[3,'activityType']],[1,1]],[[2,'!'],[[6],[[7],[3,'shopCarData']],[3,'length']]]],[[6],[[7],[3,'shopDatas']],[3,'activityStatus']]],[[7],[3,'showTuangou']]])
Z([[2,'&&'],[[2,'&&'],[[2,'=='],[[6],[[7],[3,'shopDatas']],[3,'activityType']],[1,2]],[[6],[[7],[3,'shopDatas']],[3,'activityStatus']]],[[2,'!='],[[7],[3,'isMe']],[1,1]]])
Z(z[4])
Z([3,'top:-222rpx;'])
Z([[2,'&&'],[[2,'=='],[[6],[[7],[3,'shopDatas']],[3,'canHelpSellFlag']],[1,2]],[[2,'=='],[[7],[3,'isMe']],[1,1]]])
Z(z[8])
Z(z[9])
Z([3,'data-v-207aa5d3 vue-ref'])
Z([3,'#303133'])
Z([3,'邀请其他团长帮卖'])
Z([[4],[[5],[[4],[[5],[[5],[1,'^updateVisible']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'__set_sync']],[[4],[[5],[[5],[[5],[1,'$0']],[1,'showSellTip']],[1,'$event']]]],[[4],[[5],[1,'']]]]]]]]]]])
Z([3,'tooltip8'])
Z([3,'top'])
Z([[7],[3,'showSellTip']])
Z([3,'224ad4da-16'])
Z([[4],[[5],[1,'default']]])
Z([[2,'||'],[[7],[3,'canAppl']],[[2,'&&'],[[2,'=='],[[6],[[7],[3,'shopDatas']],[3,'canHelpSellFlag']],[1,2]],[[2,'=='],[[7],[3,'isMe']],[1,1]]]])
Z(z[122])
Z([3,'f2f2f3'])
Z(z[8])
Z(z[9])
Z(z[10])
Z([[7],[3,'currentShequn']])
Z([[4],[[5],[[4],[[5],[[5],[1,'^change']],[[4],[[5],[[4],[[5],[1,'changeShequn']]]]]]]]])
Z(z[93])
Z([[7],[3,'listBuyShow']])
Z([3,'224ad4da-17'])
Z(z[10])
Z([[2,'!'],[[2,'=='],[[7],[3,'currentShequn']],[1,0]]])
Z([[6],[[7],[3,'rankList']],[3,'length']])
Z([3,'gtju_con data-v-207aa5d3'])
Z([[2,'!'],[[7],[3,'canAppl']]])
Z(z[29])
Z(z[30])
Z([[7],[3,'rankList']])
Z(z[29])
Z([3,'gtjl_list_ftits data-v-207aa5d3'])
Z([[6],[[7],[3,'item']],[3,'createTime']])
Z([3,'ins'])
Z([3,'is'])
Z([[6],[[7],[3,'item']],[3,'commodityList']])
Z(z[301])
Z(z[9])
Z([[4],[[5],[[5],[1,'data-v-207aa5d3']],[[2,'?:'],[[6],[[7],[3,'is']],[3,'isPick']],[1,'dfc_m'],[1,'']]]])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'rankChange']],[[4],[[5],[[5],[1,'$0']],[[7],[3,'ins']]]]],[[4],[[5],[[4],[[5],[[5],[[4],[[5],[[5],[[5],[1,'rankList']],[1,'']],[[7],[3,'index']]]]],[[4],[[5],[[5],[[5],[1,'commodityList']],[1,'']],[[7],[3,'ins']]]]]]]]]]]]]]]])
Z([3,'margin-left:10rpx;text-align:right;font-weight:500;font-size:26rpx;'])
Z([[6],[[7],[3,'is']],[3,'formatName']])
Z([[6],[[7],[3,'is']],[3,'refundMoney']])
Z([[7],[3,'hasRank']])
Z(z[279])
Z(z[8])
Z(z[10])
Z([1,0])
Z([3,'favor'])
Z([3,'暂无数据'])
Z([3,'224ad4da-18'])
Z(z[10])
Z([[2,'!'],[[2,'=='],[[7],[3,'currentShequn']],[1,1]]])
Z([[6],[[7],[3,'rankListBm']],[3,'length']])
Z(z[311])
Z(z[279])
Z(z[8])
Z(z[10])
Z(z[315])
Z(z[316])
Z(z[317])
Z([3,'224ad4da-19'])
Z([[2,'=='],[[6],[[7],[3,'shopDatas']],[3,'commentFlag']],[1,2]])
Z([3,'comment_box data-v-207aa5d3'])
Z(z[9])
Z([3,'has_comm fl data-v-207aa5d3'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'reply']],[[4],[[5],[[5],[[5],[[5],[[5],[1,'']],[1,'']],[1,'']],[1,0]],[[2,'-'],[1,1]]]]]]]]]]]])
Z(z[8])
Z(z[10])
Z([3,'#999'])
Z([3,'edit-pen'])
Z([3,'28'])
Z([3,'224ad4da-20'])
Z(z[29])
Z(z[30])
Z([[7],[3,'commentList']])
Z(z[29])
Z([3,'comment-main data-v-207aa5d3'])
Z([[6],[[7],[3,'item']],[3,'headFlag']])
Z([[2,'&&'],[[2,'&&'],[[6],[[7],[3,'item']],[3,'subList']],[[6],[[6],[[7],[3,'item']],[3,'subList']],[3,'length']]],[[2,'!'],[[6],[[7],[3,'item']],[3,'showSubList']]]])
Z(z[9])
Z([3,'fl pl_zk data-v-207aa5d3'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'zkaiSub']],[[4],[[5],[[5],[1,'$0']],[[7],[3,'index']]]]],[[4],[[5],[[4],[[5],[[4],[[5],[[5],[[5],[1,'commentList']],[1,'']],[[7],[3,'index']]]]]]]]]]]]]]]])
Z(z[8])
Z(z[10])
Z(z[337])
Z([3,'arrow-down'])
Z(z[14])
Z([[2,'+'],[1,'224ad4da-21-'],[[7],[3,'index']]])
Z([[6],[[7],[3,'item']],[3,'showSubList']])
Z([3,'eis'])
Z([3,'each'])
Z([[6],[[7],[3,'item']],[3,'subList']])
Z(z[358])
Z(z[346])
Z([[7],[3,'pSubmit']])
Z([[7],[3,'showGoTop']])
Z(z[8])
Z(z[9])
Z(z[46])
Z(z[10])
Z(z[157])
Z([[4],[[5],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'openSku']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z([3,'bottom'])
Z(z[157])
Z([[7],[3,'openSku']])
Z([3,'224ad4da-22'])
Z(z[278])
Z([3,'998'])
Z([3,'prop_boxs data-v-207aa5d3'])
Z([[6],[[7],[3,'skuDatas']],[3,'weight']])
Z(z[8])
Z(z[9])
Z(z[10])
Z([[4],[[5],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'$0']],[1,'eleShopNum']],[1,'$event']],[[4],[[5]]]]]],[[4],[[5],[1,'skuDatas']]]]]]]]]]])
Z([[6],[[7],[3,'skuDatas']],[3,'stockNumber']])
Z([[6],[[7],[3,'skuDatas']],[3,'minimumNumber']])
Z([[6],[[7],[3,'skuDatas']],[3,'eleShopNum']])
Z([[2,'+'],[[2,'+'],[1,'224ad4da-23'],[1,',']],[1,'224ad4da-22']])
Z([[6],[[7],[3,'skuDatas']],[3,'showCommodityArr']])
Z(z[8])
Z(z[9])
Z(z[46])
Z(z[10])
Z(z[157])
Z([[4],[[5],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'openCars']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z(z[371])
Z(z[157])
Z([[7],[3,'openCars']])
Z([3,'224ad4da-24'])
Z(z[278])
Z([3,'carin'])
Z([3,'carit'])
Z([[7],[3,'shopCarData']])
Z(z[399])
Z([3,'fl num_jis data-v-207aa5d3'])
Z(z[8])
Z(z[9])
Z(z[10])
Z(z[122])
Z([[4],[[5],[[4],[[5],[[5],[1,'^click']],[[4],[[5],[[4],[[5],[[5],[1,'setCarNumFl']],[[4],[[5],[[5],[[7],[3,'carin']]],[[2,'-'],[1,1]]]]]]]]]]]])
Z(z[133])
Z(z[124])
Z([[2,'+'],[[2,'+'],[[2,'+'],[1,'224ad4da-25-'],[[7],[3,'carin']]],[1,',']],[1,'224ad4da-24']])
Z(z[8])
Z(z[9])
Z(z[10])
Z(z[122])
Z([[4],[[5],[[4],[[5],[[5],[1,'^click']],[[4],[[5],[[4],[[5],[[5],[1,'setCarNumFl']],[[4],[[5],[[5],[[7],[3,'carin']]],[1,1]]]]]]]]]]])
Z(z[123])
Z(z[124])
Z([[2,'+'],[[2,'+'],[[2,'+'],[1,'224ad4da-26-'],[[7],[3,'carin']]],[1,',']],[1,'224ad4da-24']])
Z([[6],[[7],[3,'shopCarData']],[3,'length']])
Z([[2,'=='],[[7],[3,'isMe']],[1,1]])
Z([3,'can_apply fl_sb data-v-207aa5d3'])
Z(z[9])
Z([3,'fl_cb data-v-207aa5d3'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'e4']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z(z[8])
Z(z[10])
Z(z[122])
Z([3,'edit-pen-fill'])
Z([3,'32'])
Z([3,'224ad4da-27'])
Z([[2,'>'],[[6],[[7],[3,'shopDatas']],[3,'promoCodeCount']],[1,0]])
Z(z[9])
Z(z[424])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'goPage']],[[4],[[5],[1,4]]]]]]]]]]])
Z(z[8])
Z(z[10])
Z(z[122])
Z([3,'coupon-fill'])
Z(z[430])
Z([3,'224ad4da-28'])
Z(z[8])
Z(z[9])
Z([3,'14'])
Z(z[10])
Z(z[157])
Z([[4],[[5],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'showPop']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z([3,'center'])
Z([[7],[3,'showPop']])
Z([3,'224ad4da-29'])
Z(z[278])
Z(z[8])
Z(z[9])
Z(z[444])
Z(z[10])
Z(z[157])
Z([[4],[[5],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'showPopSuc']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z(z[448])
Z([[7],[3,'showPopSuc']])
Z([3,'224ad4da-30'])
Z(z[278])
Z(z[8])
Z(z[9])
Z(z[444])
Z(z[10])
Z([[4],[[5],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'showRemark']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z(z[448])
Z([[7],[3,'showRemark']])
Z([3,'224ad4da-31'])
Z(z[278])
Z(z[157])
Z(z[8])
Z(z[9])
Z(z[10])
Z(z[93])
Z([[4],[[5],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'remarkVa']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z([3,'200'])
Z([3,'-1'])
Z([3,'快来说说您的感想吧！'])
Z([3,'textarea'])
Z([[7],[3,'remarkVa']])
Z([[2,'+'],[[2,'+'],[1,'224ad4da-32'],[1,',']],[1,'224ad4da-31']])
Z([[7],[3,'openRelingOut']])
Z(z[8])
Z(z[9])
Z(z[9])
Z(z[10])
Z([[4],[[5],[[5],[[4],[[5],[[5],[1,'^click']],[[4],[[5],[[4],[[5],[1,'clickAct']]]]]]]],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'showAct']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z([[7],[3,'actionList']])
Z([3,'text-align:center;'])
Z([[7],[3,'showAct']])
Z([3,'224ad4da-33'])
Z([[7],[3,'showShares']])
Z(z[8])
Z(z[9])
Z(z[9])
Z([[4],[[5],[[5],[1,'data-v-207aa5d3']],[[2,'?:'],[[7],[3,'showFirstBox']],[1,'zuj_fixfirst'],[1,'zuj_fix']]]])
Z([[4],[[5],[[5],[[4],[[5],[[5],[1,'^shareUrl']],[[4],[[5],[[4],[[5],[1,'shareUrl']]]]]]]],[[4],[[5],[[5],[1,'^closeShare']],[[4],[[5],[[4],[[5],[1,'closeShare']]]]]]]]])
Z([[7],[3,'shareObj']])
Z([3,'224ad4da-34'])
Z([[7],[3,'getUserBox']])
Z(z[8])
Z(z[9])
Z([3,'zuj_fix data-v-207aa5d3'])
Z([[4],[[5],[[4],[[5],[[5],[1,'^closeUser']],[[4],[[5],[[4],[[5],[1,'closeUser']]]]]]]]])
Z([3,'224ad4da-35'])
Z(z[157])
Z([3,'#FFF'])
Z(z[8])
Z(z[10])
Z(z[24])
Z([3,'224ad4da-36'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_41_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_41_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_41=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_41=true;
var x=['./pages/subPage/showRel.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_41_1()
var aFU=_mz(z,'view',['class',0,'style',1],[],e,s,gg)
var tGU=_v()
_(aFU,tGU)
if(_oz(z,2,e,s,gg)){tGU.wxVkey=1
}
var eHU=_v()
_(aFU,eHU)
if(_oz(z,3,e,s,gg)){eHU.wxVkey=1
}
var hOU=_mz(z,'view',['class',4,'style',1],[],e,s,gg)
var lSU=_n('view')
_rz(z,lSU,'class',6,e,s,gg)
var aTU=_v()
_(lSU,aTU)
if(_oz(z,7,e,s,gg)){aTU.wxVkey=1
var h3U=_mz(z,'u-icon',['bind:__l',8,'bind:click',1,'class',2,'color',3,'data-event-opts',4,'name',5,'size',6,'vueId',7],[],e,s,gg)
_(aTU,h3U)
}
var tUU=_v()
_(lSU,tUU)
if(_oz(z,16,e,s,gg)){tUU.wxVkey=1
}
var eVU=_v()
_(lSU,eVU)
if(_oz(z,17,e,s,gg)){eVU.wxVkey=1
}
var bWU=_v()
_(lSU,bWU)
if(_oz(z,18,e,s,gg)){bWU.wxVkey=1
var o4U=_v()
_(bWU,o4U)
var c5U=function(l7U,o6U,a8U,gg){
var e0U=_v()
_(a8U,e0U)
if(_oz(z,23,l7U,o6U,gg)){e0U.wxVkey=1
}
e0U.wxXCkey=1
return a8U
}
o4U.wxXCkey=2
_2z(z,21,c5U,e,s,gg,o4U,'zi','ii','ii')
}
var oXU=_v()
_(lSU,oXU)
if(_oz(z,24,e,s,gg)){oXU.wxVkey=1
}
var xYU=_v()
_(lSU,xYU)
if(_oz(z,25,e,s,gg)){xYU.wxVkey=1
}
var oZU=_v()
_(lSU,oZU)
if(_oz(z,26,e,s,gg)){oZU.wxVkey=1
}
var f1U=_v()
_(lSU,f1U)
if(_oz(z,27,e,s,gg)){f1U.wxVkey=1
}
var c2U=_v()
_(lSU,c2U)
if(_oz(z,28,e,s,gg)){c2U.wxVkey=1
var bAV=_v()
_(c2U,bAV)
var oBV=function(oDV,xCV,fEV,gg){
var hGV=_n('view')
_rz(z,hGV,'class',33,oDV,xCV,gg)
var oHV=_v()
_(hGV,oHV)
if(_oz(z,34,oDV,xCV,gg)){oHV.wxVkey=1
}
else{oHV.wxVkey=2
var cIV=_v()
_(oHV,cIV)
if(_oz(z,35,oDV,xCV,gg)){cIV.wxVkey=1
}
else{cIV.wxVkey=2
var oJV=_v()
_(cIV,oJV)
if(_oz(z,36,oDV,xCV,gg)){oJV.wxVkey=1
}
else{oJV.wxVkey=2
var lKV=_v()
_(oJV,lKV)
if(_oz(z,37,oDV,xCV,gg)){lKV.wxVkey=1
var aLV=_mz(z,'view',['bindtap',38,'class',1,'data-event-opts',2,'style',3],[],oDV,xCV,gg)
var tMV=_mz(z,'u-icon',['bind:__l',42,'class',1,'color',2,'name',3,'size',4,'vueId',5],[],oDV,xCV,gg)
_(aLV,tMV)
_(lKV,aLV)
}
else{lKV.wxVkey=2
var eNV=_v()
_(lKV,eNV)
if(_oz(z,48,oDV,xCV,gg)){eNV.wxVkey=1
var bOV=_mz(z,'view',['bindtap',49,'class',1,'data-event-opts',2],[],oDV,xCV,gg)
var oPV=_mz(z,'u-image',['bind:__l',52,'borderRadius',1,'class',2,'mode',3,'src',4,'vueId',5,'vueSlots',6],[],oDV,xCV,gg)
var xQV=_mz(z,'u-loading',['bind:__l',59,'class',1,'mode',2,'slot',3,'vueId',4],[],oDV,xCV,gg)
_(oPV,xQV)
_(bOV,oPV)
_(eNV,bOV)
}
eNV.wxXCkey=1
eNV.wxXCkey=3
}
lKV.wxXCkey=1
lKV.wxXCkey=3
lKV.wxXCkey=3
}
oJV.wxXCkey=1
oJV.wxXCkey=3
}
cIV.wxXCkey=1
cIV.wxXCkey=3
}
oHV.wxXCkey=1
oHV.wxXCkey=3
_(fEV,hGV)
return fEV
}
bAV.wxXCkey=4
_2z(z,31,oBV,e,s,gg,bAV,'item','index','index')
}
aTU.wxXCkey=1
aTU.wxXCkey=3
tUU.wxXCkey=1
eVU.wxXCkey=1
bWU.wxXCkey=1
oXU.wxXCkey=1
xYU.wxXCkey=1
oZU.wxXCkey=1
f1U.wxXCkey=1
c2U.wxXCkey=1
c2U.wxXCkey=3
_(hOU,lSU)
var oPU=_v()
_(hOU,oPU)
if(_oz(z,64,e,s,gg)){oPU.wxVkey=1
var oRV=_n('view')
_rz(z,oRV,'class',65,e,s,gg)
var fSV=_v()
_(oRV,fSV)
if(_oz(z,66,e,s,gg)){fSV.wxVkey=1
}
var cTV=_v()
_(oRV,cTV)
var hUV=function(cWV,oVV,oXV,gg){
var aZV=_v()
_(oXV,aZV)
var t1V=function(b3V,e2V,o4V,gg){
var o6V=_mz(z,'view',['class',75,'style',1],[],b3V,e2V,gg)
var aDW=_mz(z,'view',['bindtap',77,'class',1,'data-event-opts',2,'style',3],[],b3V,e2V,gg)
var tEW=_v()
_(aDW,tEW)
if(_oz(z,81,b3V,e2V,gg)){tEW.wxVkey=1
}
else{tEW.wxVkey=2
var eFW=_v()
_(tEW,eFW)
if(_oz(z,82,b3V,e2V,gg)){eFW.wxVkey=1
}
eFW.wxXCkey=1
}
tEW.wxXCkey=1
_(o6V,aDW)
var f7V=_v()
_(o6V,f7V)
if(_oz(z,83,b3V,e2V,gg)){f7V.wxVkey=1
var bGW=_mz(z,'u-count-down',['bind:__l',84,'bind:end',1,'class',2,'color',3,'data-event-opts',4,'data-ref',5,'fontSize',6,'separatorColor',7,'separatorSize',8,'showDays',9,'timestamp',10,'vueId',11],[],b3V,e2V,gg)
_(f7V,bGW)
}
var c8V=_v()
_(o6V,c8V)
if(_oz(z,96,b3V,e2V,gg)){c8V.wxVkey=1
}
var oHW=_n('view')
_rz(z,oHW,'class',97,b3V,e2V,gg)
var oJW=_mz(z,'view',['class',98,'style',1],[],b3V,e2V,gg)
var fKW=_v()
_(oJW,fKW)
if(_oz(z,100,b3V,e2V,gg)){fKW.wxVkey=1
}
var cLW=_v()
_(oJW,cLW)
if(_oz(z,101,b3V,e2V,gg)){cLW.wxVkey=1
}
fKW.wxXCkey=1
cLW.wxXCkey=1
_(oHW,oJW)
var xIW=_v()
_(oHW,xIW)
if(_oz(z,102,b3V,e2V,gg)){xIW.wxVkey=1
}
xIW.wxXCkey=1
_(o6V,oHW)
var h9V=_v()
_(o6V,h9V)
if(_oz(z,103,b3V,e2V,gg)){h9V.wxVkey=1
}
var o0V=_v()
_(o6V,o0V)
if(_oz(z,104,b3V,e2V,gg)){o0V.wxVkey=1
var hMW=_v()
_(o0V,hMW)
if(_oz(z,105,b3V,e2V,gg)){hMW.wxVkey=1
}
hMW.wxXCkey=1
}
else{o0V.wxVkey=2
var oNW=_n('view')
_rz(z,oNW,'class',106,b3V,e2V,gg)
var cOW=_v()
_(oNW,cOW)
if(_oz(z,107,b3V,e2V,gg)){cOW.wxVkey=1
}
var oPW=_v()
_(oNW,oPW)
if(_oz(z,108,b3V,e2V,gg)){oPW.wxVkey=1
var lQW=_v()
_(oPW,lQW)
if(_oz(z,109,b3V,e2V,gg)){lQW.wxVkey=1
}
lQW.wxXCkey=1
}
cOW.wxXCkey=1
oPW.wxXCkey=1
_(o0V,oNW)
}
var cAW=_v()
_(o6V,cAW)
if(_oz(z,110,b3V,e2V,gg)){cAW.wxVkey=1
var aRW=_v()
_(cAW,aRW)
if(_oz(z,111,b3V,e2V,gg)){aRW.wxVkey=1
}
aRW.wxXCkey=1
}
var oBW=_v()
_(o6V,oBW)
if(_oz(z,112,b3V,e2V,gg)){oBW.wxVkey=1
}
var lCW=_v()
_(o6V,lCW)
if(_oz(z,113,b3V,e2V,gg)){lCW.wxVkey=1
}
else{lCW.wxVkey=2
var tSW=_v()
_(lCW,tSW)
if(_oz(z,114,b3V,e2V,gg)){tSW.wxVkey=1
var eTW=_n('view')
_rz(z,eTW,'class',115,b3V,e2V,gg)
var bUW=_mz(z,'view',['bindtap',116,'class',1,'data-event-opts',2,'hidden',3],[],b3V,e2V,gg)
var oVW=_mz(z,'u-icon',['bind:__l',120,'class',1,'color',2,'name',3,'size',4,'vueId',5],[],b3V,e2V,gg)
_(bUW,oVW)
_(eTW,bUW)
var xWW=_mz(z,'view',['class',126,'hidden',1],[],b3V,e2V,gg)
var oXW=_mz(z,'u-icon',['bind:__l',128,'bind:click',1,'class',2,'color',3,'data-event-opts',4,'name',5,'size',6,'vueId',7],[],b3V,e2V,gg)
_(xWW,oXW)
var fYW=_mz(z,'u-icon',['bind:__l',136,'bind:click',1,'class',2,'color',3,'data-event-opts',4,'name',5,'size',6,'vueId',7],[],b3V,e2V,gg)
_(xWW,fYW)
_(eTW,xWW)
_(tSW,eTW)
}
else{tSW.wxVkey=2
var cZW=_v()
_(tSW,cZW)
if(_oz(z,144,b3V,e2V,gg)){cZW.wxVkey=1
var h1W=_mz(z,'view',['bindtap',145,'class',1,'data-event-opts',2],[],b3V,e2V,gg)
var o2W=_mz(z,'u-icon',['bind:__l',148,'class',1,'color',2,'name',3,'size',4,'vueId',5],[],b3V,e2V,gg)
_(h1W,o2W)
_(cZW,h1W)
}
cZW.wxXCkey=1
cZW.wxXCkey=3
}
tSW.wxXCkey=1
tSW.wxXCkey=3
tSW.wxXCkey=3
}
f7V.wxXCkey=1
f7V.wxXCkey=3
c8V.wxXCkey=1
h9V.wxXCkey=1
o0V.wxXCkey=1
cAW.wxXCkey=1
oBW.wxXCkey=1
lCW.wxXCkey=1
lCW.wxXCkey=3
_(o4V,o6V)
return o4V
}
aZV.wxXCkey=4
_2z(z,73,t1V,cWV,oVV,gg,aZV,'item','index','index')
return oXV
}
cTV.wxXCkey=4
_2z(z,69,hUV,e,s,gg,cTV,'items','indexs','indexs')
fSV.wxXCkey=1
_(oPU,oRV)
}
var cQU=_v()
_(hOU,cQU)
if(_oz(z,154,e,s,gg)){cQU.wxVkey=1
var c3W=_n('view')
_rz(z,c3W,'class',155,e,s,gg)
var o4W=_mz(z,'u-search',['actionText',156,'animation',1,'bind:__l',2,'bind:change',3,'bind:custom',4,'bind:input',5,'bind:search',6,'class',7,'data-event-opts',8,'height',9,'placeholder',10,'shape',11,'showAction',12,'style',13,'value',14,'vueId',15],[],e,s,gg)
_(c3W,o4W)
var l5W=_v()
_(c3W,l5W)
var a6W=function(e8W,t7W,b9W,gg){
var xAX=_v()
_(b9W,xAX)
var oBX=function(cDX,fCX,hEX,gg){
var cGX=_mz(z,'view',['class',180,'style',1],[],cDX,fCX,gg)
var xOX=_mz(z,'view',['bindtap',182,'class',1,'data-event-opts',2,'style',3],[],cDX,fCX,gg)
var oPX=_v()
_(xOX,oPX)
if(_oz(z,186,cDX,fCX,gg)){oPX.wxVkey=1
}
else{oPX.wxVkey=2
var fQX=_v()
_(oPX,fQX)
if(_oz(z,187,cDX,fCX,gg)){fQX.wxVkey=1
}
fQX.wxXCkey=1
}
oPX.wxXCkey=1
_(cGX,xOX)
var oHX=_v()
_(cGX,oHX)
if(_oz(z,188,cDX,fCX,gg)){oHX.wxVkey=1
var cRX=_mz(z,'u-count-down',['bind:__l',189,'bind:end',1,'class',2,'color',3,'data-event-opts',4,'data-ref',5,'fontSize',6,'separatorColor',7,'separatorSize',8,'showDays',9,'timestamp',10,'vueId',11],[],cDX,fCX,gg)
_(oHX,cRX)
}
var lIX=_v()
_(cGX,lIX)
if(_oz(z,201,cDX,fCX,gg)){lIX.wxVkey=1
}
var hSX=_n('view')
_rz(z,hSX,'class',202,cDX,fCX,gg)
var cUX=_mz(z,'view',['class',203,'style',1],[],cDX,fCX,gg)
var oVX=_v()
_(cUX,oVX)
if(_oz(z,205,cDX,fCX,gg)){oVX.wxVkey=1
}
var lWX=_v()
_(cUX,lWX)
if(_oz(z,206,cDX,fCX,gg)){lWX.wxVkey=1
}
oVX.wxXCkey=1
lWX.wxXCkey=1
_(hSX,cUX)
var oTX=_v()
_(hSX,oTX)
if(_oz(z,207,cDX,fCX,gg)){oTX.wxVkey=1
}
oTX.wxXCkey=1
_(cGX,hSX)
var aJX=_v()
_(cGX,aJX)
if(_oz(z,208,cDX,fCX,gg)){aJX.wxVkey=1
}
var tKX=_v()
_(cGX,tKX)
if(_oz(z,209,cDX,fCX,gg)){tKX.wxVkey=1
var aXX=_v()
_(tKX,aXX)
if(_oz(z,210,cDX,fCX,gg)){aXX.wxVkey=1
}
aXX.wxXCkey=1
}
else{tKX.wxVkey=2
var tYX=_n('view')
_rz(z,tYX,'class',211,cDX,fCX,gg)
var eZX=_v()
_(tYX,eZX)
if(_oz(z,212,cDX,fCX,gg)){eZX.wxVkey=1
}
var b1X=_v()
_(tYX,b1X)
if(_oz(z,213,cDX,fCX,gg)){b1X.wxVkey=1
var o2X=_v()
_(b1X,o2X)
if(_oz(z,214,cDX,fCX,gg)){o2X.wxVkey=1
}
o2X.wxXCkey=1
}
eZX.wxXCkey=1
b1X.wxXCkey=1
_(tKX,tYX)
}
var eLX=_v()
_(cGX,eLX)
if(_oz(z,215,cDX,fCX,gg)){eLX.wxVkey=1
var x3X=_v()
_(eLX,x3X)
if(_oz(z,216,cDX,fCX,gg)){x3X.wxVkey=1
}
x3X.wxXCkey=1
}
var bMX=_v()
_(cGX,bMX)
if(_oz(z,217,cDX,fCX,gg)){bMX.wxVkey=1
}
var oNX=_v()
_(cGX,oNX)
if(_oz(z,218,cDX,fCX,gg)){oNX.wxVkey=1
}
else{oNX.wxVkey=2
var o4X=_v()
_(oNX,o4X)
if(_oz(z,219,cDX,fCX,gg)){o4X.wxVkey=1
var f5X=_mz(z,'view',['class',220,'style',1],[],cDX,fCX,gg)
var c6X=_mz(z,'view',['bindtap',222,'class',1,'data-event-opts',2,'hidden',3],[],cDX,fCX,gg)
var h7X=_mz(z,'u-icon',['bind:__l',226,'class',1,'color',2,'name',3,'size',4,'vueId',5],[],cDX,fCX,gg)
_(c6X,h7X)
_(f5X,c6X)
var o8X=_mz(z,'view',['class',232,'hidden',1],[],cDX,fCX,gg)
var c9X=_mz(z,'u-icon',['bind:__l',234,'bind:click',1,'class',2,'color',3,'data-event-opts',4,'name',5,'size',6,'vueId',7],[],cDX,fCX,gg)
_(o8X,c9X)
var o0X=_mz(z,'u-icon',['bind:__l',242,'bind:click',1,'class',2,'color',3,'data-event-opts',4,'name',5,'size',6,'vueId',7],[],cDX,fCX,gg)
_(o8X,o0X)
_(f5X,o8X)
_(o4X,f5X)
}
else{o4X.wxVkey=2
var lAY=_v()
_(o4X,lAY)
if(_oz(z,250,cDX,fCX,gg)){lAY.wxVkey=1
var aBY=_mz(z,'view',['bindtap',251,'class',1,'data-event-opts',2],[],cDX,fCX,gg)
var tCY=_mz(z,'u-icon',['bind:__l',254,'class',1,'color',2,'name',3,'size',4,'vueId',5],[],cDX,fCX,gg)
_(aBY,tCY)
_(lAY,aBY)
}
lAY.wxXCkey=1
lAY.wxXCkey=3
}
o4X.wxXCkey=1
o4X.wxXCkey=3
o4X.wxXCkey=3
}
oHX.wxXCkey=1
oHX.wxXCkey=3
lIX.wxXCkey=1
aJX.wxXCkey=1
tKX.wxXCkey=1
eLX.wxXCkey=1
bMX.wxXCkey=1
oNX.wxXCkey=1
oNX.wxXCkey=3
_(hEX,cGX)
return hEX
}
xAX.wxXCkey=4
_2z(z,178,oBX,e8W,t7W,gg,xAX,'item','index','index')
return b9W
}
l5W.wxXCkey=4
_2z(z,174,a6W,e,s,gg,l5W,'items','indexs','indexs')
_(cQU,c3W)
}
var oRU=_v()
_(hOU,oRU)
if(_oz(z,260,e,s,gg)){oRU.wxVkey=1
}
else{oRU.wxVkey=2
var eDY=_v()
_(oRU,eDY)
if(_oz(z,261,e,s,gg)){eDY.wxVkey=1
}
else{eDY.wxVkey=2
var bEY=_v()
_(eDY,bEY)
if(_oz(z,262,e,s,gg)){bEY.wxVkey=1
}
else{bEY.wxVkey=2
var oFY=_v()
_(bEY,oFY)
if(_oz(z,263,e,s,gg)){oFY.wxVkey=1
}
else{oFY.wxVkey=2
var xGY=_v()
_(oFY,xGY)
if(_oz(z,264,e,s,gg)){xGY.wxVkey=1
}
xGY.wxXCkey=1
}
oFY.wxXCkey=1
}
bEY.wxXCkey=1
}
eDY.wxXCkey=1
}
oPU.wxXCkey=1
oPU.wxXCkey=3
cQU.wxXCkey=1
cQU.wxXCkey=3
oRU.wxXCkey=1
_(aFU,hOU)
var oHY=_mz(z,'view',['class',265,'style',1],[],e,s,gg)
var fIY=_v()
_(oHY,fIY)
if(_oz(z,267,e,s,gg)){fIY.wxVkey=1
var oLY=_mz(z,'zb-tooltip',['bind:__l',268,'bind:updateVisible',1,'class',2,'color',3,'content',4,'data-event-opts',5,'data-ref',6,'placement',7,'visible',8,'vueId',9,'vueSlots',10],[],e,s,gg)
_(fIY,oLY)
}
var cJY=_v()
_(oHY,cJY)
if(_oz(z,279,e,s,gg)){cJY.wxVkey=1
var cMY=_mz(z,'u-tabs',['activeColor',280,'bgColor',1,'bind:__l',2,'bind:change',3,'class',4,'current',5,'data-event-opts',6,'isScroll',7,'list',8,'vueId',9],[],e,s,gg)
_(cJY,cMY)
}
else{cJY.wxVkey=2
}
var oNY=_mz(z,'view',['class',290,'hidden',1],[],e,s,gg)
var lOY=_v()
_(oNY,lOY)
if(_oz(z,292,e,s,gg)){lOY.wxVkey=1
var aPY=_n('view')
_rz(z,aPY,'class',293,e,s,gg)
var tQY=_v()
_(aPY,tQY)
if(_oz(z,294,e,s,gg)){tQY.wxVkey=1
}
var bSY=_v()
_(aPY,bSY)
var oTY=function(oVY,xUY,fWY,gg){
var hYY=_n('view')
_rz(z,hYY,'class',299,oVY,xUY,gg)
var oZY=_v()
_(hYY,oZY)
if(_oz(z,300,oVY,xUY,gg)){oZY.wxVkey=1
}
var c1Y=_v()
_(hYY,c1Y)
var o2Y=function(a4Y,l3Y,t5Y,gg){
var b7Y=_mz(z,'view',['bindtap',305,'class',1,'data-event-opts',2,'style',3],[],a4Y,l3Y,gg)
var o8Y=_v()
_(b7Y,o8Y)
if(_oz(z,309,a4Y,l3Y,gg)){o8Y.wxVkey=1
}
var x9Y=_v()
_(b7Y,x9Y)
if(_oz(z,310,a4Y,l3Y,gg)){x9Y.wxVkey=1
}
o8Y.wxXCkey=1
x9Y.wxXCkey=1
_(t5Y,b7Y)
return t5Y
}
c1Y.wxXCkey=2
_2z(z,303,o2Y,oVY,xUY,gg,c1Y,'is','ins','ins')
oZY.wxXCkey=1
_(fWY,hYY)
return fWY
}
bSY.wxXCkey=2
_2z(z,297,oTY,e,s,gg,bSY,'item','index','index')
var eRY=_v()
_(aPY,eRY)
if(_oz(z,311,e,s,gg)){eRY.wxVkey=1
}
tQY.wxXCkey=1
eRY.wxXCkey=1
_(lOY,aPY)
}
else{lOY.wxVkey=2
var o0Y=_v()
_(lOY,o0Y)
if(_oz(z,312,e,s,gg)){o0Y.wxVkey=1
var fAZ=_mz(z,'u-empty',['bind:__l',313,'class',1,'marginTop',2,'mode',3,'text',4,'vueId',5],[],e,s,gg)
_(o0Y,fAZ)
}
o0Y.wxXCkey=1
o0Y.wxXCkey=3
}
lOY.wxXCkey=1
lOY.wxXCkey=3
_(oHY,oNY)
var cBZ=_mz(z,'view',['class',319,'hidden',1],[],e,s,gg)
var hCZ=_v()
_(cBZ,hCZ)
if(_oz(z,321,e,s,gg)){hCZ.wxVkey=1
var oDZ=_v()
_(hCZ,oDZ)
if(_oz(z,322,e,s,gg)){oDZ.wxVkey=1
}
oDZ.wxXCkey=1
}
else{hCZ.wxVkey=2
var cEZ=_v()
_(hCZ,cEZ)
if(_oz(z,323,e,s,gg)){cEZ.wxVkey=1
var oFZ=_mz(z,'u-empty',['bind:__l',324,'class',1,'marginTop',2,'mode',3,'text',4,'vueId',5],[],e,s,gg)
_(cEZ,oFZ)
}
cEZ.wxXCkey=1
cEZ.wxXCkey=3
}
hCZ.wxXCkey=1
hCZ.wxXCkey=3
_(oHY,cBZ)
var hKY=_v()
_(oHY,hKY)
if(_oz(z,330,e,s,gg)){hKY.wxVkey=1
var lGZ=_n('view')
_rz(z,lGZ,'class',331,e,s,gg)
var tIZ=_mz(z,'view',['bindtap',332,'class',1,'data-event-opts',2],[],e,s,gg)
var eJZ=_mz(z,'u-icon',['bind:__l',335,'class',1,'color',2,'name',3,'size',4,'vueId',5],[],e,s,gg)
_(tIZ,eJZ)
_(lGZ,tIZ)
var bKZ=_v()
_(lGZ,bKZ)
var oLZ=function(oNZ,xMZ,fOZ,gg){
var hQZ=_n('view')
_rz(z,hQZ,'class',345,oNZ,xMZ,gg)
var oRZ=_v()
_(hQZ,oRZ)
if(_oz(z,346,oNZ,xMZ,gg)){oRZ.wxVkey=1
}
var cSZ=_v()
_(hQZ,cSZ)
if(_oz(z,347,oNZ,xMZ,gg)){cSZ.wxVkey=1
var lUZ=_mz(z,'view',['bindtap',348,'class',1,'data-event-opts',2],[],oNZ,xMZ,gg)
var aVZ=_mz(z,'u-icon',['bind:__l',351,'class',1,'color',2,'name',3,'size',4,'vueId',5],[],oNZ,xMZ,gg)
_(lUZ,aVZ)
_(cSZ,lUZ)
}
var oTZ=_v()
_(hQZ,oTZ)
if(_oz(z,357,oNZ,xMZ,gg)){oTZ.wxVkey=1
var tWZ=_v()
_(oTZ,tWZ)
var eXZ=function(oZZ,bYZ,x1Z,gg){
var f3Z=_v()
_(x1Z,f3Z)
if(_oz(z,362,oZZ,bYZ,gg)){f3Z.wxVkey=1
}
f3Z.wxXCkey=1
return x1Z
}
tWZ.wxXCkey=2
_2z(z,360,eXZ,oNZ,xMZ,gg,tWZ,'each','eis','eis')
}
oRZ.wxXCkey=1
cSZ.wxXCkey=1
cSZ.wxXCkey=3
oTZ.wxXCkey=1
_(fOZ,hQZ)
return fOZ
}
bKZ.wxXCkey=4
_2z(z,343,oLZ,e,s,gg,bKZ,'item','index','index')
var aHZ=_v()
_(lGZ,aHZ)
if(_oz(z,363,e,s,gg)){aHZ.wxVkey=1
}
aHZ.wxXCkey=1
_(hKY,lGZ)
}
fIY.wxXCkey=1
fIY.wxXCkey=3
cJY.wxXCkey=1
cJY.wxXCkey=3
hKY.wxXCkey=1
hKY.wxXCkey=3
_(aFU,oHY)
var bIU=_v()
_(aFU,bIU)
if(_oz(z,364,e,s,gg)){bIU.wxVkey=1
}
var c4Z=_mz(z,'u-popup',['bind:__l',365,'bind:input',1,'borderRadius',2,'class',3,'closeable',4,'data-event-opts',5,'mode',6,'safeAreaInsetBottom',7,'value',8,'vueId',9,'vueSlots',10,'zIndex',11],[],e,s,gg)
var h5Z=_n('view')
_rz(z,h5Z,'class',377,e,s,gg)
var o6Z=_v()
_(h5Z,o6Z)
if(_oz(z,378,e,s,gg)){o6Z.wxVkey=1
}
var o8Z=_mz(z,'u-number-box',['bind:__l',379,'bind:input',1,'class',2,'data-event-opts',3,'max',4,'min',5,'value',6,'vueId',7],[],e,s,gg)
_(h5Z,o8Z)
var c7Z=_v()
_(h5Z,c7Z)
if(_oz(z,387,e,s,gg)){c7Z.wxVkey=1
}
o6Z.wxXCkey=1
c7Z.wxXCkey=1
_(c4Z,h5Z)
_(aFU,c4Z)
var l9Z=_mz(z,'u-popup',['bind:__l',388,'bind:input',1,'borderRadius',2,'class',3,'closeable',4,'data-event-opts',5,'mode',6,'safeAreaInsetBottom',7,'value',8,'vueId',9,'vueSlots',10],[],e,s,gg)
var a0Z=_v()
_(l9Z,a0Z)
var tA1=function(bC1,eB1,oD1,gg){
var oF1=_n('view')
_rz(z,oF1,'class',403,bC1,eB1,gg)
var fG1=_mz(z,'u-icon',['bind:__l',404,'bind:click',1,'class',2,'color',3,'data-event-opts',4,'name',5,'size',6,'vueId',7],[],bC1,eB1,gg)
_(oF1,fG1)
var cH1=_mz(z,'u-icon',['bind:__l',412,'bind:click',1,'class',2,'color',3,'data-event-opts',4,'name',5,'size',6,'vueId',7],[],bC1,eB1,gg)
_(oF1,cH1)
_(oD1,oF1)
return oD1
}
a0Z.wxXCkey=4
_2z(z,401,tA1,e,s,gg,a0Z,'carit','carin','carin')
_(aFU,l9Z)
var oJU=_v()
_(aFU,oJU)
if(_oz(z,420,e,s,gg)){oJU.wxVkey=1
}
var xKU=_v()
_(aFU,xKU)
if(_oz(z,421,e,s,gg)){xKU.wxVkey=1
var hI1=_n('view')
_rz(z,hI1,'class',422,e,s,gg)
var cK1=_mz(z,'view',['bindtap',423,'class',1,'data-event-opts',2],[],e,s,gg)
var oL1=_mz(z,'u-icon',['bind:__l',426,'class',1,'color',2,'name',3,'size',4,'vueId',5],[],e,s,gg)
_(cK1,oL1)
_(hI1,cK1)
var oJ1=_v()
_(hI1,oJ1)
if(_oz(z,432,e,s,gg)){oJ1.wxVkey=1
var lM1=_mz(z,'view',['bindtap',433,'class',1,'data-event-opts',2],[],e,s,gg)
var aN1=_mz(z,'u-icon',['bind:__l',436,'class',1,'color',2,'name',3,'size',4,'vueId',5],[],e,s,gg)
_(lM1,aN1)
_(oJ1,lM1)
}
oJ1.wxXCkey=1
oJ1.wxXCkey=3
_(xKU,hI1)
}
var tO1=_mz(z,'u-popup',['bind:__l',442,'bind:input',1,'borderRadius',2,'class',3,'closeable',4,'data-event-opts',5,'mode',6,'value',7,'vueId',8,'vueSlots',9],[],e,s,gg)
_(aFU,tO1)
var eP1=_mz(z,'u-popup',['bind:__l',452,'bind:input',1,'borderRadius',2,'class',3,'closeable',4,'data-event-opts',5,'mode',6,'value',7,'vueId',8,'vueSlots',9],[],e,s,gg)
_(aFU,eP1)
var bQ1=_mz(z,'u-popup',['bind:__l',462,'bind:input',1,'borderRadius',2,'class',3,'data-event-opts',4,'mode',5,'value',6,'vueId',7,'vueSlots',8],[],e,s,gg)
var oR1=_mz(z,'u-input',['autoHeight',471,'bind:__l',1,'bind:input',2,'class',3,'clearable',4,'data-event-opts',5,'height',6,'maxlength',7,'placeholder',8,'type',9,'value',10,'vueId',11],[],e,s,gg)
_(bQ1,oR1)
_(aFU,bQ1)
var oLU=_v()
_(aFU,oLU)
if(_oz(z,483,e,s,gg)){oLU.wxVkey=1
}
var xS1=_mz(z,'u-action-sheet',['bind:__l',484,'bind:click',1,'bind:input',2,'class',3,'data-event-opts',4,'list',5,'style',6,'value',7,'vueId',8],[],e,s,gg)
_(aFU,xS1)
var fMU=_v()
_(aFU,fMU)
if(_oz(z,493,e,s,gg)){fMU.wxVkey=1
var oT1=_mz(z,'dc-hiro-painter',['bind:__l',494,'bind:closeShare',1,'bind:shareUrl',2,'class',3,'data-event-opts',4,'shareObj',5,'vueId',6],[],e,s,gg)
_(fMU,oT1)
}
var cNU=_v()
_(aFU,cNU)
if(_oz(z,501,e,s,gg)){cNU.wxVkey=1
var fU1=_mz(z,'login-pop',['bind:__l',502,'bind:closeUser',1,'class',2,'data-event-opts',3,'vueId',4],[],e,s,gg)
_(cNU,fU1)
}
var cV1=_mz(z,'u-skeleton',['animation',507,'bgColor',1,'bind:__l',2,'class',3,'loading',4,'vueId',5],[],e,s,gg)
_(aFU,cV1)
tGU.wxXCkey=1
eHU.wxXCkey=1
bIU.wxXCkey=1
oJU.wxXCkey=1
xKU.wxXCkey=1
xKU.wxXCkey=3
oLU.wxXCkey=1
fMU.wxXCkey=1
fMU.wxXCkey=3
cNU.wxXCkey=1
cNU.wxXCkey=3
_(r,aFU)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_41";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_41();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/subPage/showRel.wxml'] = [$gwx_XC_41, './pages/subPage/showRel.wxml'];else __wxAppCode__['pages/subPage/showRel.wxml'] = $gwx_XC_41( './pages/subPage/showRel.wxml' );
	;__wxRoute = "pages/subPage/showRel";__wxRouteBegin = true;__wxAppCurrentFile__="pages/subPage/showRel.js";define("pages/subPage/showRel.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
(global.webpackJsonp=global.webpackJsonp||[]).push([["pages/subPage/showRel"],{132:function(t,e,i){"use strict";(function(t){i(5),o(i(4));var e=o(i(133));function o(t){return t&&t.__esModule?t:{default:t}}wx.__webpack_require_UNI_MP_PLUGIN__=i,t(e.default)}).call(this,i(1).createPage)},133:function(t,e,i){"use strict";i.r(e);var o=i(134),s=i(136);for(var a in s)"default"!==a&&function(t){i.d(e,t,(function(){return s[t]}))}(a);i(138),i(140),i(142);var n=i(17),r=Object(n.default)(s.default,o.render,o.staticRenderFns,!1,null,"207aa5d3",null,!1,o.components,void 0);r.options.__file="pages/subPage/showRel.vue",e.default=r.exports},134:function(t,e,i){"use strict";i.r(e);var o=i(135);i.d(e,"render",(function(){return o.render})),i.d(e,"staticRenderFns",(function(){return o.staticRenderFns})),i.d(e,"recyclableRender",(function(){return o.recyclableRender})),i.d(e,"components",(function(){return o.components}))},135:function(t,e,i){"use strict";var o;i.r(e),i.d(e,"render",(function(){return s})),i.d(e,"staticRenderFns",(function(){return n})),i.d(e,"recyclableRender",(function(){return a})),i.d(e,"components",(function(){return o}));try{o={uIcon:function(){return i.e("uview-ui/components/u-icon/u-icon").then(i.bind(null,854))},uImage:function(){return i.e("uview-ui/components/u-image/u-image").then(i.bind(null,968))},uLoading:function(){return i.e("uview-ui/components/u-loading/u-loading").then(i.bind(null,975))},uCountDown:function(){return i.e("uview-ui/components/u-count-down/u-count-down").then(i.bind(null,982))},uSearch:function(){return i.e("uview-ui/components/u-search/u-search").then(i.bind(null,925))},zbTooltip:function(){return i.e("uni_modules/zb-tooltip/components/zb-tooltip/zb-tooltip").then(i.bind(null,989))},uTabs:function(){return Promise.all([i.e("common/vendor"),i.e("uview-ui/components/u-tabs/u-tabs")]).then(i.bind(null,996))},uEmpty:function(){return i.e("uview-ui/components/u-empty/u-empty").then(i.bind(null,868))},uPopup:function(){return i.e("uview-ui/components/u-popup/u-popup").then(i.bind(null,939))},uNumberBox:function(){return i.e("uview-ui/components/u-number-box/u-number-box").then(i.bind(null,1003))},uInput:function(){return Promise.all([i.e("common/vendor"),i.e("uview-ui/components/u-input/u-input")]).then(i.bind(null,910))},uActionSheet:function(){return i.e("uview-ui/components/u-action-sheet/u-action-sheet").then(i.bind(null,896))},dcHiroPainter:function(){return i.e("components/dc-hiro-painter/dc-hiro-painter").then(i.bind(null,875))},loginPop:function(){return i.e("components/login-pop/login-pop").then(i.bind(null,882))},uSkeleton:function(){return i.e("uview-ui/components/u-skeleton/u-skeleton").then(i.bind(null,889))}}}catch(t){if(-1===t.message.indexOf("Cannot find module")||-1===t.message.indexOf(".vue"))throw t;console.error(t.message),console.error("1. 排查组件名称拼写是否正确"),console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"),console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件")}var s=function(){var t=this;t.$createElement,t._self._c,t._isMounted||(t.e0=function(e){t.userInfoHome.focusWechat=!0},t.e1=function(e){t.openRelingOut=!0},t.e2=function(e){t.openCars=!1},t.e3=function(e){t.openCars=!0},t.e4=function(e){t.showAct=!0},t.e5=function(e){t.showPopSuc=!1},t.e6=function(e){t.showRemark=!1},t.e7=function(e){t.openRelingOut=!1},t.e8=function(e){t.openRelingOut=!1})},a=!1,n=[];s._withStripped=!0},136:function(t,e,i){"use strict";i.r(e);var o=i(137),s=i.n(o);for(var a in o)"default"!==a&&function(t){i.d(e,t,(function(){return o[t]}))}(a);e.default=s.a},137:function(t,e,i){"use strict";(function(t){Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var o=a(i(29)),s=a(i(61));function a(t){return t&&t.__esModule?t:{default:t}}function n(t,e,i,o,s,a,n){try{var r=t[a](n),c=r.value}catch(t){return void i(t)}r.done?e(c):Promise.resolve(c).then(o,s)}function r(t){return function(){var e=this,i=arguments;return new Promise((function(o,s){var a=t.apply(e,i);function r(t){n(a,o,s,r,c,"next",t)}function c(t){n(a,o,s,r,c,"throw",t)}r(void 0)}))}}var c={data:function(){return{maxwidths:"200",paddingSa:"",headMask:"",firstCom:!1,enterTime:"Wed Jul 27 2022 15:24:31 GMT+0800 (中国标准时间)",showHomeBtn:!1,needBuyArr:[],openRelingOut:!1,firstCommId:"",isSearch:!1,topPadding:300,searchContent:"",isSwichMenu:!1,isStickyTwo:!1,showShopTabin:0,cssShow:1,oldScTop:0,Topdistance:1200,TopdistancMax:1600,TopdistancMaxOut:2400,isSticky:!1,showSellTip:!0,listBuyShow:[{name:"跟团记录"},{name:"帮卖排行"}],currentShequn:0,hasRank:!0,rankPage:1,pageLoadings:!0,showFirstBox:!1,remarkVa:"",showRemark:!1,commentList:[],getUserBox:!1,openCars:!1,loading:!0,shareObj:{},showShares:!1,showSharesBox:!1,shareImgMini:"",sellCommission:0,relationInfo:{accessCount:0,activityBgImg:"",headImg:"",joinCount:0,nickName:"",userId:""},userInfo:{nickName:"群优选",headImg:"https://qiniuimg.kfmanager.com/qunjl/showrel/miniqyxs.png"},msg:[],rankIcon:["http://qiniuimg.kfmanager.com/qunjl/showrel/medal1.png","http://qiniuimg.kfmanager.com/qunjl/showrel/medal2.png","http://qiniuimg.kfmanager.com/qunjl/showrel/medal3.png"],rankList:[],rankListBm:[],showPop:!1,showPopSuc:!1,shopDatas:{commodityList:[{eleShopNumOut:0}]},openSku:!1,speceNameShow:"",checkPriceShow:0,checkNameShow:"商品",speceImg:"http://qiniuimg.kfmanager.com/qunjl/showrel/zswptplus.png",specePriceSh:0,formIndex:0,activityId:0,shareUserId:"",sourceType:"",comingType:0,skuDatas:{},diagoDatas:{},isMe:2,canAppl:!1,canCopys:!1,showAct:!1,userInfoHome:{},actiStatus:[{text:"我要团购",color:"#07c160"},{text:"团购尚未发布",color:"#07c160"},{text:"我要团购",color:"#07c160"},{text:"活动已下架",color:"#b5ecd0"},{text:"活动已暂停",color:"#b5ecd0"},{text:"活动已结束",color:"#b5ecd0"},{text:"活动已下架",color:"#b5ecd0"},{text:"活动暂未开始",color:"#b5ecd0"}],actionList:[{text:"修改团购"},{text:"开启团购"},{text:"开启售后权益保障"},{text:"复制团购"},{text:"分享团购内容给他人"},{text:"结束团购"}],shopCarData:[],shopCarDataMos:0,shopCarDataNum:0,weightTotal:0,userAddIng:!1,commodityListShop:[],top:"",scrollTop:0,oldScrollTop:0,current:0,menuHeight:0,menuItemHeight:0,itemId:"",tabbar:[{name:"",showSearch:!0,shopList:[{}]}],menuItemPos:[],arr:[],scrollRightTop:0,TopdistancMaxShop:1200,showTuangou:!0,timer:null,showGoTop:!1,pPlaceholder:"请输入您的感想",commentReq:{reUser:"",index:0,eidx:-1,pId:null,content:null},pUser:null,pShowTag:!1,pFocus:!1,pSubmit:!1,KeyboardHeight:0}},watch:{shopCarData:{handler:function(t,e){this.carRefresh()},immediate:!0,deep:!0}},mounted:function(){var e=this;t.onKeyboardHeightChange((function(t){e.KeyboardHeight=t.height}))},onShareAppMessage:function(e){var i={title:(t.getStorageSync("userInfo")||{}).nickName+"给您推荐了一个群优选团购",path:"/pages/subPage/showRel",imageUrl:"https://qiniuimg.kfmanager.com/qunjl/showrel/yqrjl.jpg",success:function(t){t.errMsg},fail:function(){"shareAppMessage:fail cancel"==res.errMsg||res.errMsg}};if("button"==e.from){e.target.dataset;var o=this}return o=this,i.title=o.shareObj.title,i.imageUrl=o.shareImgMini,i.path="/pages/subPage/showRel?"+o.shareObj.shareScene,i},onShow:function(t){},onLoad:function(e){var i=this;this.enterTime=new Date,this.showFirstBox=!0;var o={};if(e.scene){var s=decodeURIComponent(e.scene).split("&");console.log("msceneArr==",s);for(var a=0;a<s.length;a++){var n=s[a].split("=");o[n[0]]=n[1]}o.sType&&(this.sourceType=o.sType),setTimeout((function(t){var e=wx.getMenuButtonBoundingClientRect();i.top=e.top,i.topPadding=2*custom.top+2*custom.height+130+10}),500)}else{var r=wx.getMenuButtonBoundingClientRect();this.top=r.top,this.topPadding=2*r.top+2*r.height+130+10,console.log("状态栏信息",r,"custom.top*2+custom.height*2+search 130")}var c=e.id||o.id,h=e.can||o.can;if(this.activityId=c,!this.activityId)return t.showToast({title:"活动信息有误",icon:"none"}),setTimeout((function(e){t.switchTab({url:"../example/home"})}),1e3),!1;e.type&&(this.comingType=1),(e.uid||o.uid)&&(this.shareUserId=e.uid||o.uid),(e.c||o.c)&&(this.firstCommId=e.c||o.c);var u=t.getStorageSync("userInfo")||{},l=this,m=getCurrentPages();if(m.length>1)console.log("非小程序进入跳转页==",m),this.userInfoHome=u,h?9==h?(this.canAppl=!0,this.queryBuyRank()):8==h?(this.canCopys=!0,this.queryBuyRank()):this.queryBuyRank():this.queryBuyRank(),this.getShopDatas(c),this.queryAccess(),this.queryComment();else{if(this.showHomeBtn=!0,2==u.userType)return this.opearatReLogin(),setTimeout((function(e){console.log("员工登录免再登录",u.userType),h?9==h?(i.canAppl=!0,i.queryBuyRank()):8==h?(i.canCopys=!0,i.queryBuyRank()):i.queryBuyRank():i.queryBuyRank(),i.getShopDatas(c),i.queryAccess(),i.queryComment(),t.hideShareMenu({})}),800),!1;wx.login({success:function(e){e.code&&l.$server.login({agentId:l.$agentId,code:e.code,fromUserId:l.shareUserId}).then((function(e){if(!e||!e.userId)return t.showToast({title:"登录失败，请重新进入小程序",icon:"none"}),!1;console.log("商品展示页正常登录==",e),l.userInfoHome=e,t.setStorageSync("userInfo",e),h?9==h?(l.canAppl=!0,l.queryBuyRank()):8==h?(l.canCopys=!0,l.queryBuyRank()):l.queryBuyRank():l.queryBuyRank(),l.getShopDatas(c),l.queryAccess(),l.queryComment()}))},fail:function(e){t.showToast({title:"登录失败，请重新进入小程序。",icon:"none"})}})}t.hideShareMenu({}),t.pageScrollTo({scrollTop:0,duration:0})},onUnload:function(){console.log("团购页用户退出====onUnload");var t=(new Date).getTime()-this.enterTime.getTime(),e=Math.ceil(t/1e3),i=[{activityId:this.activityId,pageType:4,userId:this.relationInfo.userId,accessTime:e,fromUserId:this.shareUserId}];this.sendAccessLog(i)},onReachBottom:function(){var t=this;setTimeout((function(e){t.isSwichMenu}),100)},onPageScroll:function(e){var i=t.getSystemInfoSync().windowHeight;if(e.scrollTop>2*i?this.showGoTop=!0:this.showGoTop=!1,e.scrollTop<this.TopdistancMaxShop-i?!this.showTuangou&&(this.showTuangou=!0):this.showTuangou&&(this.showTuangou=!1),3==this.cssShow){if(e.scrollTop+50>=this.Topdistance-this.topPadding/2?this.isSticky=!0:this.isSticky=!1,this.isSearch)return!1;if(this.TopdistancMaxOut-t.getSystemInfoSync().windowHeight<e.scrollTop+10&&!this.isSwichMenu)return this.current=this.tabbar.length-1,!1;if(e.scrollTop>this.Topdistance&&this.TopdistancMax>e.scrollTop)for(var o=0;o<this.arr.length;o++){var s=this.arr[o]+this.Topdistance-this.topPadding/2,a=this.arr[o+1]+this.Topdistance-this.topPadding/2;if((!a||e.scrollTop>=s&&e.scrollTop<a)&&!this.isSwichMenu)return void(this.current!=o&&(this.current=o))}else e.scrollTop>this.TopdistancMax&&(this.current=this.tabbar.length-1)}if(2==this.cssShow)if(e.scrollTop>this.Topdistance&&this.TopdistancMax>e.scrollTop){this.isStickyTwo=!0;for(var n=0;n<this.arr.length;n++){var r=this.arr[n]+this.Topdistance,c=this.arr[n+1]+this.Topdistance;if((!c||e.scrollTop>=r&&e.scrollTop<c)&&!this.isSwichMenu)return void(this.current!=n&&(this.current=n))}}else this.isStickyTwo=!1;e.scrollTop+200>=i&&(this.paddingSa="{padding-bottom:'0'}")},methods:{zkaiSub:function(t,e){console.log(t),t.showSubList=!0,console.log(t)},stopPrevent:function(){},reply:function(t,e,i,o){e?(this.commentReq.pId=e,t&&(this.pPlaceholder="回复 @"+t+"："),this.commentReq.index=i,this.commentReq.eidx=o,this.commentReq.reUser=t):(this.commentReq.pId="",this.pPlaceholder="请输入您的感想",this.commentReq.index=0,this.commentReq.eidx=-1,this.commentReq.reUser=""),this.commentInput()},add:function(){null==this.commentReq.content||this.commentReq.content.length<1?t.showToast({title:"评论内容过短",duration:2e3}):this.$emit("add",this.commentReq)},addComplete:function(){this.commentReq.content=null,this.tagClose(),this.closeInput()},showMore:function(t){for(var e in this.commentList){if(this.commentList[e].id==t)return this.commentList[e].hasShowMore=!this.commentList[e].hasShowMore,void this.$forceUpdate();for(var i in this.commentList[e].subList)if(this.commentList[e].subList[i].id==t)return this.commentList[e].subList[i].hasShowMore=!this.commentList[e].subList[i].hasShowMore,void this.$forceUpdate()}},blur:function(){this.pFocus=!1},focusOn:function(){},tagClose:function(){this.showTag=!1,this.pUser=null,this.commentReq.pId=null},commentInput:function(){var t=this;this.pSubmit=!0,setTimeout((function(){t.pFocus=!0}),50)},closeInput:function(){this.pFocus=!1,this.pSubmit=!1},goCodeYj:function(e){this.$server.oneClickHelpSell({sourceActId:e}).then((function(e){0==e.code?(t.showToast({title:"帮卖成功",icon:"success",duration:2e3}),setTimeout((function(i){t.reLaunch({url:"./showRel?id="+e.data.activityId})}),1500)):t.showToast({title:e.message,icon:"none"})}))},goTopZero:function(){t.pageScrollTo({scrollTop:0,duration:800})},endTimestamp:function(t){"开始"==t.timestampyrjTip?(t.timestampyrj=(new Date(t.spikeEndTime)-Date.parse(new Date))/1e3,t.timestampyrjTip="结束"):"结束"==t.timestampyrjTip&&(t.timestampyrj=-99)},freezeFlagSwitch:function(e){var i=this;this.$server.freezeFlagSwitch({activityId:this.activityId,changeFlag:e}).then((function(e){0==e.code?(t.showToast({title:"开启成功",icon:"success"}),i.shopDatas.freezeFlag=2):t.showToast({title:e.message,icon:"none"})}))},searchFunsCh:function(e){if(console.log("搜索内容输入==",e),0==e.length){t.showLoading();var i=JSON.parse(JSON.stringify(this.tabbar));i.forEach((function(t,e){t.showSearch=t.shopList.length,t.shopList.forEach((function(t){!t.showSearch&&(t.showSearch=!0)}))})),t.hideLoading(),this.tabbar=i,this.current=0,this.isSearch=!1}},searchFuns:function(e){var i=this;if(console.log("搜索内容==",e),0==e.length)return this.searchFunsCh(),!1;t.showLoading();var o=JSON.parse(JSON.stringify(this.tabbar)),s=0,a=-1;if(o.forEach((function(t,e){t.showSearch=0,t.shopList.forEach((function(o){o.commodityName.includes(i.searchContent)?(!o.showSearch&&(o.showSearch=!0),t.showSearch++,s++,-1==a&&(a=e)):o.showSearch&&(o.showSearch=!1)}))})),t.hideLoading(),!s)return t.showToast({title:"抱歉，未有相关商品",icon:"none"}),!1;this.tabbar=o,this.current=a,this.searchContent?this.isSearch=!0:this.isSearch=!1,t.pageScrollTo({duration:100,scrollTop:this.Topdistance-this.topPadding/2})},togglePosition:function(e){this.showShopTabin=e,console.log("跳转togglePosition"),t.createSelectorQuery().select("#shopm"+e).boundingClientRect((function(i){t.createSelectorQuery().select(".award_join").boundingClientRect((function(o){0==e?t.pageScrollTo({duration:100,scrollTop:i.top-o.top-70}):t.pageScrollTo({duration:100,scrollTop:i.top-o.top})})).exec()})).exec()},GetTop:function(e){var i=this,o=this;t.getSystemInfo({success:function(s){var a=t.createSelectorQuery();a.select(".shop_outhei").boundingClientRect((function(e){o.TopdistancMaxShop=e.top,o.TopdistancMaxShop+200<t.getSystemInfoSync().windowHeight&&(i.showTuangou=!1)})).exec(),1==e||(a.select(".menu-scroll-view").boundingClientRect((function(t){o.Topdistance=t.top})).exec(),a.select(".award_join").boundingClientRect((function(t){o.TopdistancMaxOut=t.height})).exec(),3==o.cssShow?a.select(".page-view").boundingClientRect((function(t){o.TopdistancMax=t.top+t.height})).exec():a.select(".page_viewtwo").boundingClientRect((function(t){o.TopdistancMax=t.top+t.height})).exec())},fail:function(t){}})},rankChange:function(t,e){t.isPick=!t.isPick,console.log("跟团记录 ",this.rankList)},changeShequn:function(t){console.log("tab==",t),this.currentShequn=t,1==this.currentShequn&&!this.rankListBm.length&&this.querySellRank()},copyConten:function(e){t.setClipboardData({data:e,success:function(){t.showToast({title:"复制成功",icon:"success"})}})},setCarNumFl:function(e,i){var o=this;if(console.log("this.shopCarData[index]",this.shopCarData[e]),1==this.shopCarData[e].eleShopNum&&i<1)this.tabbar.forEach((function(t,i){t.shopList.forEach((function(t,i){t.id==o.shopCarData[e].id&&t.formatDetailList[0].id==o.shopCarData[e].formatId&&(t.eleShopNumOut=0)}))})),this.shopCarData.splice(e,1),this.shopCarData.length<1&&(this.openCars=!1);else{if(1==i){if(this.shopCarData[e].eleShopNum>this.shopCarData[e].stock-1)return t.showToast({title:"库存不足",icon:"none"}),!1;if(this.shopCarData[e].eleShopNum>=this.shopCarData[e].limitBuy)return t.showToast({title:"每人限购"+this.shopCarData[e].limitBuy+"件",icon:"none"}),!1}this.shopCarData[e].eleShopNum+=i,this.tabbar.forEach((function(t,i){t.shopList.forEach((function(t,i){t.id==o.shopCarData[e].id&&t.formatDetailList[0].id==o.shopCarData[e].formatId&&(t.eleShopNumOut=o.shopCarData[e].eleShopNum)}))}))}},setShopCarNum:function(e,i){var o=this;if(this.userAddIng)return console.log("拦截=="),!1;if(-2==e.needBuy)return t.showToast({title:"该商品不可购买",icon:"none"}),!1;if(2==e.spikeFlag){var s=new Date;if(Date.parse(s)<new Date(e.spikeStartTime))return t.showToast({title:"秒杀活动还未开始",icon:"none"}),!1;if(Date.parse(s)>=new Date(e.spikeEndTime))return t.showToast({title:"秒杀活动已结束",icon:"none"}),!1}this.userAddIng=!0;var a=-1;if(console.log("posInfo.++",e,i),0==e.eleShopNumOut&&(this.skuDatas=JSON.parse(JSON.stringify(e)),this.skuDatas.formIndex=0,this.skuDatas.activityId=this.activityId),this.shopCarData.forEach((function(t,i){t.id==e.id&&t.formatId==e.formatDetailList[0].id&&(a=i)})),console.log("this.setShopCarNum",e),1==e.eleShopNumOut&&i<1)return this.shopCarData.splice(a,1),this.shopCarData.length<1&&(this.openCars=!1),e.eleShopNumOut+=i,this.userAddIng=!1,!1;if(1==i){if(e.eleShopNumOut>e.defaultStock-1)return t.showToast({title:"库存不足",icon:"none"}),this.userAddIng=!1,!1;if(e.eleShopNumOut>=e.limitBuy)return console.log("每人限购",e.eleShopNumOut),t.showToast({title:"每人限购"+e.limitBuy+"件",icon:"none"}),this.userAddIng=!1,!1}e.eleShopNumOut+=i;var n=JSON.parse(JSON.stringify(this.skuDatas)),r=JSON.parse(JSON.stringify(e.formatDetailList[0]));return r.activityId=this.activityId,r.eleShopNum=e.eleShopNumOut,r.id=e.id,r.formatId="暂无",r.commodityName=e.commodityName,r.showCommodityImg=e.showCommodityImg,r.commodityCode=e.commodityCode||"",r.promoCodeCount=n.promoCodeCount,this.shareUserId?r.shareUserId=this.shareUserId:r.shareUserId="",setTimeout((function(i){if(a>=0)console.log("isCopys==SHop",e.eleShopNumOut),o.shopCarData[a].eleShopNum=e.eleShopNumOut,o.userAddIng=!1;else{console.log("this.newData.",r),r.limitBuy<n.eleShopNum&&(t.showToast({title:"每人限购"+r.limitBuy+"件",icon:"none"}),r.eleShopNum=r.limitBuy),o.userAddIng=!1,o.shopCarData.push(r);var s=[{activityId:o.activityId,pageType:3,userId:o.relationInfo.userId,commodityId:e.id}];o.sendAccessLog(s),console.log("this.shopCarData.shop",o.shopCarData)}}),500),!1},tuiDing:function(){var e=this;t.showModal({title:"提示",content:"退订主页，你将不能收到我的活动发布通知哦",confirmText:"退订",confirmColor:"#ff4d4d",success:function(t){t.cancel?console.log("用户点击取消"):t.confirm&&e.subscribeUser(2)}})},subscribeUser:function(e){var i=this;this.$server.subscribeUser({targetUserId:this.relationInfo.userId,subscribeType:e}).then((function(o){0==o.code?(i.shopDatas.subscribe=!i.shopDatas.subscribe,1==e?i.userInfoHome.focusWechat?t.showToast({title:"订阅成功"}):t.navigateTo({url:"./weAccount"}):t.showToast({title:"退订成功"})):t.showToast({title:o.message,icon:"none"})}))},closeUser:function(t){console.log("关闭授权弹窗==",t),1!=t&&(this.userInfoHome=t),this.getUserBox=!1,console.log("关闭授权弹窗==22",2)},shareUrl:function(t){console.log("分享弹窗==shareObj",t),this.shareObj.isShop&&!this.shareObj.title.includes(this.shareObj.maxSellPriceShow)&&(this.shareObj.title=this.shareObj.title+"   "+this.shareObj.maxSellPriceShow),this.shareImgMini=t},closeShare:function(t){console.log("关闭分享==",this.shareObj),this.showFirstBox=!1,this.showShares=!1},openShare:function(e,i,o){var a=this;if(this.showShares&&(this.showShares=!1),this.showPopSuc&&(this.showPopSuc=!1),this.showPop&&(this.showPop=!1),1!=i&&t.showLoading({title:"加载中",mask:!0}),this.shareObj.openPyq=9==i?9:0,this.shareObj.adminUserId=this.relationInfo.userId,"帮卖"==e?(setTimeout((function(t){a.showSellTip=!1,a.$refs.tooltip8.close()}),500),this.shareObj.title=this.shopDatas.activityName+"，快来帮卖吧",this.shopDatas.minMaxPrice.minSellCommission==this.shopDatas.minMaxPrice.maxSellCommission?this.shareObj.bmMoney=s.default.centTurnSmacker(this.shopDatas.minMaxPrice.maxSellCommission/100):this.shareObj.bmMoney=s.default.centTurnSmacker(this.shopDatas.minMaxPrice.minSellCommission/100)+"~"+s.default.centTurnSmacker(this.shopDatas.minMaxPrice.maxSellCommission/100)):(this.shareObj.title=this.shopDatas.activityName,this.shareObj.bmMoney=""),this.shareObj.freezeFlag=this.shopDatas.freezeFlag,this.shareObj.activityId=this.activityId,this.shareObj.headImg=this.relationInfo.headImg||"https://qiniuimg.kfmanager.com/qunjl/showrel/miniqyxs.png",this.shareObj.nickName=this.relationInfo.nickName||"群优选用户",this.shareObj.shareBtn="我要"+e,this.shareObj.isShop=!1,o)return this.shareObj.isShop=!0,this.shareObj.rankList=!1,o.commodityName.length>24?this.shareObj.title=o.commodityName.slice(0,23)+"...":this.shareObj.title=o.commodityName,this.shareObj.createTime=this.shopDatas.createTime.slice(0,10),this.shareObj.shareScene="id="+this.activityId+"&uid="+this.userInfoHome.userId+"&c="+o.id,o.showCommodityArr?this.shareObj.imgUrls=o.showCommodityArr.slice(0,1):this.shareObj.imgUrls=[],o.minSellPriceSh==o.maxSellPriceSh?this.shareObj.maxSellPriceShow="¥"+o.maxSellPriceSh:this.shareObj.maxSellPriceShow="¥"+o.minSellPriceSh+"~"+o.maxSellPriceSh,this.shareObj.isFirstin=!1,this.shareObj.rankList="",this.showShares=!0,setTimeout((function(e){t.hideLoading()}),3e3),!1;console.log("父组件传值==未return"),this.shareObj.shareScene="帮卖"==e?"id="+this.activityId+"&uid="+this.userInfoHome.userId+"&can=9":"团购"==e?"id="+this.activityId+"&uid="+this.userInfoHome.userId:"id="+this.activityId+"&uid="+this.userInfoHome.userId+"&can=8",this.shopDatas.imgArrs?this.shareObj.imgUrls=this.shopDatas.imgArrs:this.shareObj.imgUrls=[],2==this.tabbar[0].shopList[0].groupFlag?this.tabbar[0].shopList[0].minSellPriceShGr==this.tabbar[0].shopList[0].maxSellPriceShGr?this.shareObj.maxSellPriceShow="¥"+this.tabbar[0].shopList[0].maxSellPriceShGr:this.shareObj.maxSellPriceShow="¥"+this.tabbar[0].shopList[0].minSellPriceShGr+"~"+this.tabbar[0].shopList[0].maxSellPriceShGr:this.shopDatas.minMaxPrice.minSellPrice==this.shopDatas.minMaxPrice.maxSellPrice?this.shareObj.maxSellPriceShow="¥"+s.default.centTurnSmacker(this.shopDatas.minMaxPrice.maxSellPrice/100):this.shareObj.maxSellPriceShow="¥"+s.default.centTurnSmacker(this.shopDatas.minMaxPrice.minSellPrice/100)+"~"+s.default.centTurnSmacker(this.shopDatas.minMaxPrice.maxSellPrice/100),this.shareObj.createTime=this.shopDatas.createTime.slice(0,10),this.rankList.length&&(this.shareObj.rankList=this.rankList.slice(0,5)),this.shareObj.isFirstin=1==i,this.showFirstBox=1==i,this.showShares=!0,console.log("父组件传值==未return2",this.showShares,this.showFirstBox,this.shareObj),setTimeout((function(e){t.hideLoading()}),1e3)},goMyhome:function(){t.navigateTo({url:"./myHome?uid="+this.relationInfo.userId})},routeTo:function(){var e=getCurrentPages();console.log("pages==",e),e.length>1?t.navigateBack():t.switchTab({url:"../example/home"})},goPage:function(e){if(console.log("e==",e),!e)return t.showToast({title:"暂未开放",icon:"none"}),!1;if(1==e)t.switchTab({url:"../example/home"});else if(2==e)t.navigateTo({url:"../pageRelay/activityOrder?id="+this.activityId});else if(3==e)t.navigateTo({url:"../pageRelay/relayEarn?id="+this.activityId});else if(4==e)t.navigateTo({url:"../pageRelay/codeList?id="+this.activityId});else if(5==e)t.navigateTo({url:"./weAccount"});else if(9==e){if(!this.userInfoHome.nickName)return this.getUserBox=!0,!1;if(this.canCopys){if(!this.userInfoHome.nickName)return this.getUserBox=!0,!1;t.navigateTo({url:"../solitaire/issueRelayPlus?id="+this.activityId+"&type=3"})}else{if(!this.userInfoHome.nickName)return this.getUserBox=!0,!1;t.navigateTo({url:"../solitaire/issueRelayPlus?id="+this.activityId+"&type=2"})}}else if("issueRelayPlus"==e)t.navigateTo({url:"../solitaire/issueRelayPlus"});else{if(!this.userInfoHome.nickName)return this.getUserBox=!0,!1;t.navigateTo({url:"./"+e})}},getShopDatas:function(e){var i=this;this.$server.gbuyActInfo({activityId:e,sourceType:this.sourceType,fromUserId:this.shareUserId}).then((function(e){if(0==e.code){2==e.data.activityType&&(i.canAppl=!0),i.isMe=e.data.activityOwner,e.data.minSellPrice=s.default.centTurnSmacker(e.data.commodityList[0].shopList[0].minMaxPrice.minSellPrice/100),e.data.maxSellPrice=s.default.centTurnSmacker(e.data.commodityList[0].shopList[0].minMaxPrice.maxSellPrice/100),e.data.endTimeShow=e.data.activityEndTime.slice(5,16),e.data.differTime=s.default.getDifferTime(e.data.createTime,!1),!e.data.activityBgImg&&(e.data.activityBgImg="http://qiniuimg.kfmanager.com/qunjl/relay/bg_rep.png");var o=e.data.activityStartTime.replace(/-/g,"/");(new Date).getTime()<new Date(o).getTime()&&2==e.data.activityStatus&&(console.log("活动暂未开始"),e.data.activityStatus=7);var a=[],n=[],r=0;e.data.activityDetails.forEach((function(t){1==t.contentType&&(t.activityDetail=t.activityDetail.replaceAll("↵","/n")),2==t.contentType?(t.imgArrs=t.activityDetail.split(","),a=a.concat(t.imgArrs)):4==t.contentType?t.addressData=t.activityDetail.split(","):5==t.contentType&&(a.push(t.activityDetail),n.push(t.activityDetail),t.bigImgInd=r,r++)})),e.data.rewardList&&e.data.rewardList.forEach((function(t){t.showSurplusMoney=s.default.centTurnSmacker(t.totalMoney/t.totalCount/100,"5"),4==t.rewardType?(t.totalCount=s.default.centTurnSmacker(t.totalCount/100,5),t.totalMoney=s.default.centTurnSmacker(t.totalMoney/100,5)):t.totalMoney=s.default.centTurnSmacker(t.totalMoney/100,5)})),i.canAppl&&(i.sellCommission=s.default.centTurnSmacker(e.data.commodityList[0].shopList[0].sellCommission/100)),console.log("arrs===222",e.data),e.data.imgArrs=a,e.data.bigImgArr=n,!e.data.relationInfo.headImg&&(e.data.relationInfo.headImg="http://qiniuimg.kfmanager.com/qunjl/logo/qyxlogons.jpg"),e.data.relationInfo.memberLevel&&(i.headMask=i.headMask+" jp_tz"),e.data.subscribe&&(i.maxwidths="324"),i.relationInfo=e.data.relationInfo;var c={one:0,two:0,isOk:!1};e.data.commodityList.forEach((function(t,e){t.showSearch=t.shopList.length,t.shopList.forEach((function(t,o){if(t.showSearch=!0,2==t.groupFlag?(t.maxSellPriceShGr=s.default.centTurnSmacker(t.minMaxPrice.maxGroupPrice/100),t.minSellPriceShGr=s.default.centTurnSmacker(t.minMaxPrice.minGroupPrice/100)):(t.maxSellPriceSh=s.default.centTurnSmacker(t.minMaxPrice.maxSellPrice/100,2),t.minSellPriceSh=s.default.centTurnSmacker(t.minMaxPrice.minSellPrice/100,2)),t.minMaxPrice.maxUnderLinePrice&&(t.maxUnderLinePriceSh=s.default.centTurnSmacker(t.minMaxPrice.maxUnderLinePrice/100,2),t.minUnderLinePriceSh=s.default.centTurnSmacker(t.minMaxPrice.minUnderLinePrice/100,2)),t.commodityDetails.length>1){var a=t.commodityDetails[1].commodityDetail.split(",");t.showCommodityImg=a[0],t.showCommodityArr=a}else t.showCommodityImg="http://qiniuimg.kfmanager.com/qunjl/showrel/zswptplus.png";if(2==t.spikeFlag){var n=new Date;t.spikeStartTime=t.spikeStartTime.replace(/-/g,"/").replace("T"," "),t.spikeEndTime=t.spikeEndTime.replace(/-/g,"/").replace("T"," "),Date.parse(n)<new Date(t.spikeStartTime)?(t.timestampyrj=(new Date(t.spikeStartTime)-Date.parse(new Date))/1e3,t.timestampyrjTip="开始"):Date.parse(n)>=new Date(t.spikeEndTime)?(t.timestampyrj=-99,t.timestampyrjTip="结束"):(t.timestampyrj=(new Date(t.spikeEndTime)-Date.parse(new Date))/1e3,t.timestampyrjTip="结束")}if(t.formatSize)t.formatDetailList.forEach((function(e,i){0===e.stock?e.eleShopNum=0:e.eleShopNum=1,t.limitBuy<1?-2==t.limitBuy?(e.needBuy=-2,e.limitBuy=99999):-1==t.limitBuy?(e.needBuy=1,e.limitBuy=99999):(e.needBuy=0,e.limitBuy=99999):e.limitBuy=t.limitBuy-t.userHasBuyCount,e.commodityId=t.id,""===e.stock||null===e.stock?e.stock=99999:e.stock=e.stock,e.sellPriceShow=s.default.centTurnSmacker(e.sellPrice/100),e.underlinePriceShow=s.default.centTurnSmacker(e.underlinePrice/100),e.checkPriceShow=e.sellPriceShow,e.groupPrice&&(e.checkPriceGrShow=s.default.centTurnSmacker(e.groupPrice/100))})),t.minimumNumber=1,t.shopNum=1,t.eleShopNum=t.formatDetailList[0].eleShopNum,t.defaultStock=t.formatDetailList[0].stock,t.stockNumber=t.defaultStock,t.formatDetailList[0].imgUrl?t.speceImg=t.formatDetailList[0].imgUrl:t.speceImg="http://qiniuimg.kfmanager.com/qunjl/showrel/zswptplus.png",t.checkPriceShow=t.formatDetailList[0].sellPriceShow,t.checkPriceGrShow=t.formatDetailList[0].checkPriceGrShow,t.specePriceSh=t.formatDetailList[0].sellPrice,t.weight=t.formatDetailList[0].weight,t.formIndex=0,t.formatList.forEach((function(t,e){t.formatItemArr=t.formatItems.split(","),t.formatItemIndex=0})),i.checkPriceShow=t.sellPriceShow;else{var r={};r.commodityId=t.id,r.id="暂无",r.formatItemName=t.defaultFormat,r.sellPriceShow=s.default.centTurnSmacker(t.defaultPrice/100),r.underlinePriceShow=s.default.centTurnSmacker(t.defaultPrice/100),r.checkPriceShow=r.sellPriceShow,t.groupPrice&&(r.checkPriceGrShow=s.default.centTurnSmacker(t.groupPrice/100)),r.imgUrl=t.showCommodityImg,r.groupPrice=t.groupPrice,r.sellPrice=t.defaultPrice,t.limitBuy<1?-2==t.limitBuy?(r.needBuy=-2,t.needBuy=-2,r.limitBuy=99999,t.limitBuy=99999):-1==t.limitBuy?(r.needBuy=1,t.needBuy=1,r.limitBuy=99999,t.limitBuy=99999,i.needBuyArr.push({id:t.id,commodityName:t.commodityName,hasBuy:!1})):(r.needBuy=0,t.needBuy=0,r.limitBuy=99999,t.limitBuy=99999):(r.limitBuy=t.limitBuy,t.limitBuy=t.limitBuy),""===t.defaultStock||null===t.defaultStock?r.stock=99999:r.stock=t.defaultStock,r.weight=t.commodityWeight,t.formatDetailList=[r],t.checkPriceShow=r.sellPriceShow,t.checkPriceGrShow=r.checkPriceGrShow,t.specePriceSh=r.sellPriceShow,t.weight=t.commodityWeight,t.speceImg=t.showCommodityImg,t.eleShopNumOut=0,""===t.defaultStock||null===t.defaultStock?(t.stockNumber=99999,t.defaultStock=99999):t.stockNumber=t.defaultStock,t.shopNum=1,t.eleShopNum=1,t.formatList=[{commodityId:t.commodityId,formatItemArr:[t.defaultFormat],formatItems:t.defaultFormat,formatItemIndex:0,formatName:"规格"}],0==o&&(i.checkPriceShow=r.sellPriceShow,i.comingType&&(i.showPop=!0))}i.firstCommId&&i.firstCommId==t.id&&t.defaultStock&&(c.one=e,c.two=o,c.isOk=!0)}))})),i.tabbar=JSON.parse(JSON.stringify(e.data.commodityList)),i.shopDatas=e.data,console.log("团购tabbar",i.tabbar),i.skuDatas=i.tabbar[c.one].shopList[c.two],i.skuDatas.formIndex=0,i.skuDatas.activityId=i.activityId,c.isOk&&i.openSkuFunFl(),i.tabbar.length>3?(i.cssShow=3,setTimeout((function(t){i.GetTop(3),i.getMenuItemTop()}),1800)):1==i.tabbar.length?(i.cssShow=1,setTimeout((function(t){i.GetTop(1)}),1800)):(setTimeout((function(t){i.GetTop(2),i.getMenuItemTop()}),1800),i.cssShow=2),setTimeout((function(){i.loading=!1}),800),i.openShare("团购",1),setTimeout((function(){i.pageLoadings=!1,i.firstCom=!0,t.showShareMenu()}),1500),console.log("团购数据this.shopDatas6999",i.shopDatas)}else t.showToast({title:e.message,icon:"none"})}))},carRefresh:function(){console.log("this.shopCarData==",this.shopCarData);var t=this.$u.deepClone(this.shopCarData),e=0,i=0,o=0;t.length&&t.forEach((function(t){e+=t.eleShopNum,i+=t.eleShopNum*t.checkPriceShow,o+=t.weight*t.eleShopNum})),this.shopCarDataMos=s.default.centTurnSmacker(i),this.weightTotal=o,this.shopCarDataNum=e},goPosbuy:function(e){var i=this;if(!this.userInfoHome.nickName)return this.getUserBox=!0,!1;if(this.userAddIng)return console.log("拦截=="),!1;this.userAddIng=!0;var o=JSON.parse(JSON.stringify(this.skuDatas));if(console.log("skuDatas==",o),-1!=e){if(-2==o.needBuy)return t.showToast({title:"该商品不可购买",icon:"none"}),this.userAddIng=!1,!1;if(2==o.spikeFlag){var a=new Date;if(Date.parse(a)<new Date(o.spikeStartTime))return t.showToast({title:"秒杀活动还未开始",icon:"none"}),this.userAddIng=!1,!1;if(Date.parse(a)>=new Date(o.spikeEndTime))return t.showToast({title:"秒杀活动已结束",icon:"none"}),this.userAddIng=!1,!1}}if(o.eleShopNum<1)return t.showToast({title:"库存不足",icon:"none"}),this.userAddIng=!1,!1;this.openSku&&(this.openSku=!this.openSku);var n=JSON.parse(JSON.stringify(o.formatDetailList[o.formIndex]));if(n.activityId=o.activityId,n.eleShopNum=o.eleShopNum,n.id=o.id,n.formatId=o.formatDetailList[o.formIndex].id,n.commodityName=o.commodityName,n.showCommodityImg=o.showCommodityImg,n.commodityName=o.commodityName,n.promoCodeCount=o.promoCodeCount,this.shareUserId?n.shareUserId=this.shareUserId:n.shareUserId="",n.commodityName=o.commodityName,console.log("e==",n),e>1)if(console.log("e==",o),99==e)n.groupIsOne=!0;else{n.shopCarDataMos=s.default.centTurnSmacker(n.eleShopNum*n.groupPrice/100),n.shopCarDataNum=n.eleShopNum,n.groupFlag=2,n.sourceType=this.sourceType,2==this.shopDatas.logisticsWay&&(n.logisticsRecordIds=this.shopDatas.logisticsRecordIds,n.logisticsWay=this.shopDatas.logisticsWay),n.freezeFlag=this.shopDatas.freezeFlag,n.memberCount=this.relationInfo.memberCount,n.solitaireCount=this.relationInfo.solitaireCount,n.rewardList=this.shopDatas.rewardList,n.adminUserId=this.relationInfo.userId;var r=[n];this.userAddIng=!1,t.navigateTo({url:"./posApplyBuy?item="+encodeURIComponent(JSON.stringify(r))})}else{var c=-1,h=JSON.parse(JSON.stringify(this.needBuyArr));console.log("posInfo.++",o),this.shopCarData.forEach((function(t,e){t.id==o.id&&t.formatId==o.formatDetailList[o.formIndex].id&&(c=e),h.length&&h.forEach((function(e){e.id==t.id&&(e.hasBuy=!0)}))})),setTimeout((function(a){if(-1==e){var r="";if(console.log("必须购买",h),h.forEach((function(t){t.hasBuy||(r=t.commodityName+",必须购买")})),r)return t.showToast({title:r,icon:"none"}),i.userAddIng=!1,!1;console.log(i.shopCarData);var u=s.default.centTurnSmacker(i.shopCarDataMos-i.shopDatas.minOrderMoney/100);if(console.log("距离起购价还差",u,1*u,1*u<0),1*u<0)return t.showToast({title:"距离起购价还差"+-1*u+"元",icon:"none"}),i.userAddIng=!1,!1;i.shopCarData[0].shopCarDataNum=i.shopCarDataNum,i.shopCarData[0].shopCarDataMos=i.shopCarDataMos,i.shopCarData[0].groupFlag=o.groupFlag,i.shopCarData[0].promoCodeCount=i.shopDatas.promoCodeCount,i.shopCarData[0].sourceType=i.sourceType,i.shopCarData[0].weightTotal=i.weightTotal,i.shopCarData[0].logisticsWay=i.shopDatas.logisticsWay,2==i.shopDatas.logisticsWay&&(i.shopCarData[0].logisticsRecordIds=i.shopDatas.logisticsRecordIds);var l={templateInfo:i.shopDatas.templateInfo,shopCarData:i.shopCarData};return l.rewardList=i.shopDatas.rewardList,l.freezeFlag=i.shopDatas.freezeFlag,l.memberCount=i.relationInfo.memberCount,l.solitaireCount=i.relationInfo.solitaireCount,l.adminUserId=i.relationInfo.userId,i.userAddIng=!1,t.navigateTo({url:"./posApplyBuy?item="+encodeURIComponent(JSON.stringify(l))}),!1}if(-2==e&&(n.groupIsOne=!0,n.groupFlag=1),c>=0)console.log("isCopys==",i.shopCarData[c],i.shopCarData[c].eleShopNum,o.eleShopNum),i.shopCarData[c].eleShopNum+o.eleShopNum>o.formatDetailList[o.formIndex].stock?i.shopCarData[c].eleShopNum=o.formatDetailList[o.formIndex].stock:i.shopCarData[c].eleShopNum+=o.eleShopNum,i.shopCarData[c].limitBuy<i.shopCarData[c].eleShopNum+o.eleShopNum&&(t.showToast({title:"每人限购"+i.shopCarData[c].limitBuy+"件",icon:"none"}),i.shopCarData[c].eleShopNum=i.shopCarData[c].limitBuy),i.tabbar.forEach((function(t,e){t.shopList.forEach((function(t,e){t.id==i.shopCarData[c].id&&t.formatDetailList[0].id==i.shopCarData[c].formatId&&(t.eleShopNumOut=i.shopCarData[c].eleShopNum)}))})),i.userAddIng=!1;else{console.log("this.newData.",n),n.limitBuy<o.eleShopNum&&(t.showToast({title:"每人限购"+n.limitBuy+"件",icon:"none"}),n.eleShopNum=n.limitBuy),i.tabbar.forEach((function(t,e){t.shopList.forEach((function(t,e){t.id==n.id&&t.formatDetailList[0].id==n.formatId&&(t.eleShopNumOut=n.eleShopNum)}))})),i.shopCarData.push(n);var m=[{pageType:3,userId:i.relationInfo.userId,commodityId:n.id,activityId:i.activityId,fromUserId:i.shareUserId}];i.sendAccessLog(m),i.userAddIng=!1,console.log("this.shopCarData.",i.shopCarData)}}),500)}},checkSpecsa:function(e,i,o,s){console.log("原数据==",e,i,o,s);var a=e.formatItemIndex;e.formatItemIndex=s,console.log("后数据==",e);var n="",r=0;if(this.skuDatas.formatList.forEach((function(t,e){n=0==e?t.formatItemArr[t.formatItemIndex]:n+"/"+t.formatItemArr[t.formatItemIndex]})),this.skuDatas.formatDetailList.forEach((function(t,e){t.formatItemName==n&&(r=e)})),0==this.skuDatas.formatDetailList[r].stock)return t.showToast({title:"库存不足",icon:"none"}),e.formatItemIndex=a,!1;this.formIndex=r,this.skuDatas.formIndex=r,this.skuDatas.minimumNumber=1,this.skuDatas.eleShopNum=1,this.skuDatas.stockNumber=this.skuDatas.formatDetailList[r].stock,this.skuDatas.checkPriceShow=this.skuDatas.formatDetailList[r].sellPriceShow,this.skuDatas.weight=this.skuDatas.formatDetailList[r].weight,this.skuDatas.specePriceSh=this.skuDatas.formatDetailList[r].sellPrice,this.skuDatas.formatDetailList[r].imgUrl?this.skuDatas.speceImg=this.skuDatas.formatDetailList[r].imgUrl:this.skuDatas.speceImg="http://qiniuimg.kfmanager.com/qunjl/showrel/zswptplus.png",this.skuDatas.formatDetailList[r].checkPriceGrShow&&(this.skuDatas.checkPriceGrShow=this.skuDatas.formatDetailList[r].checkPriceGrShow)},openSkuElFl:function(e,i,o,s){if(2!=this.shopDatas.activityStatus)return!1;if(1==i.formatDetailList.length&&0===i.formatDetailList[0].stock)return t.showToast({title:"库存不足",icon:"none"}),!1;var a=[{pageType:1,userId:this.relationInfo.userId,commodityId:i.id,activityId:this.activityId,fromUserId:this.shareUserId}];this.sendAccessLog(a);var n=JSON.parse(JSON.stringify(i));i.id==this.skuDatas.id?this.openSku=!0:i.formatDetailList&&i.formatDetailList.length?(n.formatList.forEach((function(t){0!=t.formatItemIndex&&(t.formatItemIndex=0)})),this.skuDatas=n,this.skuDatas.formIndex=0,this.skuDatas.activityId=this.activityId,this.skuDatas.stockNumber=n.formatDetailList[0].stock,0===n.formatDetailList[0].stock?this.skuDatas.eleShopNum=0:this.skuDatas.eleShopNum=1,this.skuDatas.limitBuy=i.limitBuy,this.openSku=!0):(this.skuDatas=n,this.skuDatas.formIndex=0,this.skuDatas.activityId=this.activityId,this.openSku=!0)},scrollDinwei:function(){var e=this;if(2!=this.shopDatas.activityStatus)return 7==this.shopDatas.activityStatus?t.showToast({title:"活动将于"+this.shopDatas.activityStartTime+"开始",icon:"none"}):t.showToast({title:"抱歉，活动已经结束了",icon:"none"}),!1;t.createSelectorQuery().select(".shop_outhei").boundingClientRect((function(i){t.createSelectorQuery().select(".award_join").boundingClientRect((function(o){3==e.cssShow?(console.log(i,o),t.pageScrollTo({duration:300,scrollTop:i.top-o.top})):t.pageScrollTo({duration:300,scrollTop:i.top-o.top})})).exec()})).exec()},openSkuFunFl:function(){return 0!==this.tabbar[0].shopList[0].defaultStock||this.firstCommId?2!=this.shopDatas.activityStatus?(7==this.shopDatas.activityStatus?t.showToast({title:"活动将于"+this.shopDatas.activityStartTime+"开始",icon:"none"}):t.showToast({title:"抱歉，活动已经结束了",icon:"none"}),!1):void(this.openSku=!0):(t.showToast({title:"首个商品已经被抢完啦",icon:"none"}),!1)},queryAccess:function(){var e=this;this.$server.queryAccessLog({activityId:this.activityId,size:50}).then((function(i){0==i.code?(i.data.forEach((function(t){t.nickName?t.nickName=t.nickName.slice(0,2)+"*":t.nickName="**",t.differTime=s.default.getDifferTime(t.createTime,!1)})),e.msg=i.data):t.showToast({title:i.message,icon:"none"})}))},moreRank:function(){this.rankPage++,this.queryBuyRank()},querySellRank:function(){var e=this;this.$server.queryHelpSellRank({activityId:this.activityId,page:1,pageSize:100}).then((function(i){0==i.code?(i.data.forEach((function(t){t.nickName?t.nickName=t.nickName.slice(0,1)+"**":t.nickName="群优选用户",t.totalMoney=s.default.centTurnSmacker(t.totalMoney/100)})),i.data.length<99&&(e.hasRank=!1),e.rankListBm=e.rankListBm.concat(i.data)):t.showToast({title:i.message,icon:"none"})}))},queryBuyRank:function(){var e=this;this.$server.queryUserBuyRank({activityId:this.activityId,page:this.rankPage,pageSize:50}).then((function(i){0==i.code?(i.data.forEach((function(t){t.nickName?t.nickName=t.nickName.slice(0,1)+"**":t.nickName="群**",t.totalMoney=s.default.centTurnSmacker(t.totalMoney/100),t.createTime&&(t.differTime=s.default.getDifferTime(t.createTime,!1)),t.commodityList.forEach((function(e){e.isPick=!1,"默认 "==e.formatName&&(e.formatName=""),t.commodityName=e.commoditName,t.commodityCount=e.commodityCount}))})),i.data.length<50&&(e.hasRank=!1),e.rankList=e.rankList.concat(i.data),console.log("跟团记录==",e.rankList)):t.showToast({title:i.message,icon:"none"})}))},queryComment:function(e){var i=this;this.$server.queryCommentList({activityId:this.activityId,page:1,pageSize:30}).then((function(o){0==o.code?(o.data.commentList.forEach((function(t){!t.nickName&&(t.nickName="群优选用户"),!t.headImg&&(t.headImg="http://qiniuimg.kfmanager.com/qunjl/showrel/miniqyxs.png"),t.differTime=s.default.getDifferTime(t.createTime,!1),t.showSubList=!!e,t.subList&&t.subList.forEach((function(t){!t.nickName&&(t.nickName="群优选用户"),t.differTime=s.default.getDifferTime(t.createTime,!1),!t.headImg&&(t.headImg="http://qiniuimg.kfmanager.com/qunjl/showrel/miniqyxs.png")}))})),i.commentList=o.data.commentList):t.showToast({title:o.message,icon:"none"})}))},backFun:function(e){console.log("backFun",e);var i=t.getStorageSync("userInfo")||{};i.nickName&&(this.userInfo.nickName=i.nickName),i.headImg&&(this.userInfo.headImg=i.headImg),this.diagoDatas=e,this.showPopSuc=!0},showMoring:function(t){this.showAct=!0},clickAct:function(e){console.log("e==",e);var i=this;if(0==e)return this.goEdit(),!1;if(2==e)return 2==this.shopDatas.freezeFlag?(t.showToast({title:"该活动已开启售后权益保障",icon:"none",duration:3e3}),!1):(t.showModal({title:"开启售后权益保障",content:"开启平台担保交易，提升客户对团购的信任，确保售后无忧，订单资金将在客户确认收货后，或满5天后，自动结算至可提现余额",confirmText:"确认",cancelText:"取消",confirmColor:"#07c160",success:function(t){t.cancel?console.log("用户点击取消"):t.confirm&&i.freezeFlagSwitch(2)}}),!1);if(2==this.shopDatas.activityStatus&&1==e)return t.showToast({title:"活动已是开启状态",icon:"none"}),!1;if(5==this.shopDatas.activityStatus&&5==e)return t.showToast({title:"活动已是结束状态",icon:"none"}),!1;if(3==e)return t.navigateTo({url:"../solitaire/issueRelayPlus?type=3&id="+this.activityId}),!1;if(4==e)return this.openShare("复制"),!1;var o="是否确认"+this.actionList[e].text,s="请确认是否"+this.actionList[e].text,a="#07c160",n="确定";6==e?(s="只能恢复近30天内删除的团购",a="#ff4d4d",n="删除"):5==e&&(s="结束团购后，用户将不能下单",a="#ff4d4d",n="结束"),t.showModal({title:o,content:s,confirmText:n,cancelText:"取消",confirmColor:a,success:function(t){t.cancel?console.log("用户点击取消"):t.confirm&&i.updateStatus(e)}})},updateStatus:function(e){var i,o=this;i=1==e?2:5,this.$server.updateStatus({activityId:this.activityId,status:i}).then((function(e){0==e.code?(t.showToast({title:"操作成功",icon:"success"}),t.showToast({title:e.message,icon:"none"}),o.getShopDatas(o.activityId)):t.showToast({title:e.message,icon:"none"})}))},goEdit:function(e){console.log("跳转"),t.navigateTo({url:"../solitaire/issueRelayPlus?id="+this.activityId+"&types="+this.shopDatas.activityStatus})},editRemark:function(){var e=this;if(!this.remarkVa)return!1;var i={activityId:this.activityId,content:this.remarkVa};this.commentReq.pId&&(i.replyId=this.commentReq.pId),this.$server.addComment(i).then((function(i){0==i.code?(t.showToast({title:"评论成功",icon:"success"}),e.remarkVa="",e.pSubmit=!1,e.commentReq.pId="",e.queryComment(1)):t.showToast({title:i.message,icon:"none"})}))},swichMenus:function(e){var i=this;if(console.log("新点击"),e!=this.current){if(this.current=e,this.searchContent)return!1;this.isSwichMenu=!0,t.createSelectorQuery().select("#item"+e).boundingClientRect((function(e){t.createSelectorQuery().select(".award_join").boundingClientRect((function(o){3==i.cssShow?t.pageScrollTo({duration:100,scrollTop:e.top-o.top-i.topPadding/2}):t.pageScrollTo({duration:100,scrollTop:e.top-o.top-50})})).exec()})).exec(),setTimeout((function(t){i.isSwichMenu=!1}),1e3)}},swichMenu:function(t){var e=this;return r(o.default.mark((function i(){return o.default.wrap((function(i){for(;;)switch(i.prev=i.next){case 0:if(0!=e.arr.length){i.next=3;break}return i.next=3,e.getMenuItemTop();case 3:if(t!=e.current){i.next=5;break}return i.abrupt("return");case 5:e.scrollRightTop=e.oldScrollTop,e.$nextTick((function(){this.scrollRightTop=this.arr[t],this.current=t,this.leftMenuStatus(t)}));case 7:case"end":return i.stop()}}),i)})))()},getElRect:function(e,i){var o=this;new Promise((function(s,a){t.createSelectorQuery().in(o).select("."+e).fields({size:!0},(function(t){t?(o[i]=t.height,s()):setTimeout((function(){o.getElRect(e)}),10)})).exec()}))},observer:function(){var e=this;return r(o.default.mark((function i(){return o.default.wrap((function(i){for(;;)switch(i.prev=i.next){case 0:e.tabbar.map((function(i,o){t.createIntersectionObserver(e).relativeTo(".right-box",{top:0}).observe("#item"+o,(function(t){if(t.intersectionRatio>0){var i=t.id.substring(4);e.leftMenuStatus(i)}}))}));case 1:case"end":return i.stop()}}),i)})))()},leftMenuStatus:function(t){var e=this;return r(o.default.mark((function i(){return o.default.wrap((function(i){for(;;)switch(i.prev=i.next){case 0:console.log("leftMenuStatus",t),e.current=t;case 2:case"end":return i.stop()}}),i)})))()},getMenuItemTop:function(){var e=this;new Promise((function(i){var o,s=t.createSelectorQuery();o=3==e.cssShow?".class-item":".class-itemtwo",s.selectAll(o).boundingClientRect((function(t){t.length?t.forEach((function(o){e.arr.push(o.top-t[0].top),console.log("菜单this.arr==",e.arr),i()})):setTimeout((function(){e.getMenuItemTop()}),10)})).exec()}))},rightScroll:function(t){var e=this;return r(o.default.mark((function i(){return o.default.wrap((function(i){for(;;)switch(i.prev=i.next){case 0:if(e.oldScrollTop=t.detail.scrollTop,0!=e.arr.length){i.next=4;break}return i.next=4,e.getMenuItemTop();case 4:if(!e.timer){i.next=6;break}return i.abrupt("return");case 6:if(e.menuHeight){i.next=9;break}return i.next=9,e.getElRect("menu-scroll-view","menuHeight");case 9:setTimeout((function(){e.timer=null;for(var i=t.detail.scrollTop+e.menuHeight/2,o=0;o<e.arr.length;o++){var s=e.arr[o],a=e.arr[o+1];if(!a||i>=s&&i<a)return void e.leftMenuStatus(o)}}),10);case 10:case"end":return i.stop()}}),i)})))()}}};e.default=c}).call(this,i(1).default)},138:function(t,e,i){"use strict";i.r(e);var o=i(139),s=i.n(o);for(var a in o)"default"!==a&&function(t){i.d(e,t,(function(){return o[t]}))}(a);e.default=s.a},139:function(t,e,i){},140:function(t,e,i){"use strict";i.r(e);var o=i(141),s=i.n(o);for(var a in o)"default"!==a&&function(t){i.d(e,t,(function(){return o[t]}))}(a);e.default=s.a},141:function(t,e,i){},142:function(t,e,i){"use strict";i.r(e);var o=i(143),s=i.n(o);for(var a in o)"default"!==a&&function(t){i.d(e,t,(function(){return o[t]}))}(a);e.default=s.a},143:function(t,e,i){}},[[132,"common/runtime","common/vendor"]]]);
},{isPage:true,isComponent:true,currentFile:'pages/subPage/showRel.js'});require("pages/subPage/showRel.js");