$gwx_XC_28=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_28 || [];
function gz$gwx_XC_28_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_28_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_28_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_28_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'award_min data-v-72cfcb0d'])
Z([3,'min-height:100vh;background-color:#f5f5f5;padding-top:16rpx;box-sizing:border-box;'])
Z([3,'in_bbxs  data-v-72cfcb0d'])
Z([[2,'=='],[[7],[3,'pickId']],[1,1]])
Z([3,'index'])
Z([3,'item'])
Z([[7],[3,'logisticsColumnsKd']])
Z(z[4])
Z([3,'data-v-72cfcb0d'])
Z([[2,'>'],[[7],[3,'index']],[1,2]])
Z([[2,'=='],[[6],[[7],[3,'item']],[3,'contentType']],[1,2]])
Z([3,'__e'])
Z([3,'gochec fl_sb data-v-72cfcb0d'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'pickWl']],[[4],[[5],[1,3]]]]]]]]]]])
Z([3,'border-top:0.5px solid #f4f4f4;margin-top:24rpx;'])
Z([3,'__l'])
Z(z[8])
Z([3,'#787878'])
Z([3,'arrow-right'])
Z([3,'30'])
Z([3,'31abd0ce-1'])
Z([3,'in_bbxs data-v-72cfcb0d'])
Z([[2,'=='],[[7],[3,'pickId']],[1,2]])
Z(z[4])
Z(z[5])
Z([[7],[3,'logisticsColumns']])
Z(z[4])
Z(z[8])
Z(z[9])
Z(z[10])
Z(z[11])
Z(z[12])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'pickWl']],[[4],[[5],[1,2]]]]]]]]]]])
Z(z[15])
Z(z[8])
Z(z[17])
Z(z[18])
Z(z[19])
Z([3,'31abd0ce-2'])
Z(z[22])
Z(z[11])
Z(z[12])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'pickWl']],[[4],[[5],[1,4]]]]]]]]]]])
Z(z[15])
Z(z[8])
Z(z[17])
Z(z[18])
Z(z[19])
Z([3,'31abd0ce-3'])
Z(z[15])
Z(z[11])
Z(z[11])
Z([1,20])
Z(z[8])
Z([[4],[[5],[[5],[[4],[[5],[[5],[1,'^click']],[[4],[[5],[[4],[[5],[1,'addTypes']]]]]]]],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'showType']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z([[7],[3,'listType']])
Z([[7],[3,'showType']])
Z([3,'31abd0ce-4'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_28_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_28_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_28=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_28=true;
var x=['./pages/subPage/checkFlow.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_28_1()
var eFI=_mz(z,'view',['class',0,'style',1],[],e,s,gg)
var bGI=_n('view')
_rz(z,bGI,'class',2,e,s,gg)
var oHI=_v()
_(bGI,oHI)
if(_oz(z,3,e,s,gg)){oHI.wxVkey=1
var xII=_v()
_(oHI,xII)
var oJI=function(cLI,fKI,hMI,gg){
var cOI=_n('view')
_rz(z,cOI,'class',8,cLI,fKI,gg)
var oPI=_v()
_(cOI,oPI)
if(_oz(z,9,cLI,fKI,gg)){oPI.wxVkey=1
}
var lQI=_v()
_(cOI,lQI)
if(_oz(z,10,cLI,fKI,gg)){lQI.wxVkey=1
}
oPI.wxXCkey=1
lQI.wxXCkey=1
_(hMI,cOI)
return hMI
}
xII.wxXCkey=2
_2z(z,6,oJI,e,s,gg,xII,'item','index','index')
}
var aRI=_mz(z,'view',['bindtap',11,'class',1,'data-event-opts',2,'style',3],[],e,s,gg)
var tSI=_mz(z,'u-icon',['bind:__l',15,'class',1,'color',2,'name',3,'size',4,'vueId',5],[],e,s,gg)
_(aRI,tSI)
_(bGI,aRI)
oHI.wxXCkey=1
_(eFI,bGI)
var eTI=_n('view')
_rz(z,eTI,'class',21,e,s,gg)
var bUI=_v()
_(eTI,bUI)
if(_oz(z,22,e,s,gg)){bUI.wxVkey=1
var xWI=_v()
_(bUI,xWI)
var oXI=function(cZI,fYI,h1I,gg){
var c3I=_n('view')
_rz(z,c3I,'class',27,cZI,fYI,gg)
var o4I=_v()
_(c3I,o4I)
if(_oz(z,28,cZI,fYI,gg)){o4I.wxVkey=1
}
var l5I=_v()
_(c3I,l5I)
if(_oz(z,29,cZI,fYI,gg)){l5I.wxVkey=1
}
o4I.wxXCkey=1
l5I.wxXCkey=1
_(h1I,c3I)
return h1I
}
xWI.wxXCkey=2
_2z(z,25,oXI,e,s,gg,xWI,'item','index','index')
}
var a6I=_mz(z,'view',['bindtap',30,'class',1,'data-event-opts',2],[],e,s,gg)
var t7I=_mz(z,'u-icon',['bind:__l',33,'class',1,'color',2,'name',3,'size',4,'vueId',5],[],e,s,gg)
_(a6I,t7I)
_(eTI,a6I)
var oVI=_v()
_(eTI,oVI)
if(_oz(z,39,e,s,gg)){oVI.wxVkey=1
var e8I=_mz(z,'view',['bindtap',40,'class',1,'data-event-opts',2],[],e,s,gg)
var b9I=_mz(z,'u-icon',['bind:__l',43,'class',1,'color',2,'name',3,'size',4,'vueId',5],[],e,s,gg)
_(e8I,b9I)
_(oVI,e8I)
}
bUI.wxXCkey=1
oVI.wxXCkey=1
oVI.wxXCkey=3
_(eFI,eTI)
var o0I=_mz(z,'u-action-sheet',['bind:__l',49,'bind:click',1,'bind:input',2,'borderRadius',3,'class',4,'data-event-opts',5,'list',6,'value',7,'vueId',8],[],e,s,gg)
_(eFI,o0I)
_(r,eFI)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_28";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_28();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/subPage/checkFlow.wxml'] = [$gwx_XC_28, './pages/subPage/checkFlow.wxml'];else __wxAppCode__['pages/subPage/checkFlow.wxml'] = $gwx_XC_28( './pages/subPage/checkFlow.wxml' );
	;__wxRoute = "pages/subPage/checkFlow";__wxRouteBegin = true;__wxAppCurrentFile__="pages/subPage/checkFlow.js";define("pages/subPage/checkFlow.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
(global.webpackJsonp=global.webpackJsonp||[]).push([["pages/subPage/checkFlow"],{84:function(t,e,i){"use strict";(function(t){i(5),n(i(4));var e=n(i(85));function n(t){return t&&t.__esModule?t:{default:t}}wx.__webpack_require_UNI_MP_PLUGIN__=i,t(e.default)}).call(this,i(1).createPage)},85:function(t,e,i){"use strict";i.r(e);var n=i(86),s=i(88);for(var o in s)"default"!==o&&function(t){i.d(e,t,(function(){return s[t]}))}(o);i(90),i(92);var c=i(17),l=Object(c.default)(s.default,n.render,n.staticRenderFns,!1,null,"72cfcb0d",null,!1,n.components,void 0);l.options.__file="pages/subPage/checkFlow.vue",e.default=l.exports},86:function(t,e,i){"use strict";i.r(e);var n=i(87);i.d(e,"render",(function(){return n.render})),i.d(e,"staticRenderFns",(function(){return n.staticRenderFns})),i.d(e,"recyclableRender",(function(){return n.recyclableRender})),i.d(e,"components",(function(){return n.components}))},87:function(t,e,i){"use strict";var n;i.r(e),i.d(e,"render",(function(){return s})),i.d(e,"staticRenderFns",(function(){return c})),i.d(e,"recyclableRender",(function(){return o})),i.d(e,"components",(function(){return n}));try{n={uIcon:function(){return i.e("uview-ui/components/u-icon/u-icon").then(i.bind(null,854))},uActionSheet:function(){return i.e("uview-ui/components/u-action-sheet/u-action-sheet").then(i.bind(null,896))}}}catch(t){if(-1===t.message.indexOf("Cannot find module")||-1===t.message.indexOf(".vue"))throw t;console.error(t.message),console.error("1. 排查组件名称拼写是否正确"),console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"),console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件")}var s=function(){this.$createElement,this._self._c},o=!1,c=[];s._withStripped=!0},88:function(t,e,i){"use strict";i.r(e);var n=i(89),s=i.n(n);for(var o in n)"default"!==o&&function(t){i.d(e,t,(function(){return n[t]}))}(o);e.default=s.a},89:function(t,e,i){"use strict";(function(t){function i(t,e,i){return e in t?Object.defineProperty(t,e,{value:i,enumerable:!0,configurable:!0,writable:!0}):t[e]=i,t}Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var n={data:function(){var t,e,n,s,o,c;return{picknumsYj:"设置",listType:[{text:"添加填写项"},{text:"添加上传图片项"}],showType:!1,typeCheck:1,editType:1,templteName:"",editIdt:0,pickId:1,picknums:"全部",ztiArr:[],logisticsColumnsKd:[(t={typeName:"联系人姓名",typeFlag:"1",logisticsType:"1",contentType:1,id:""},i(t,"contentType",1),i(t,"publicFlag",1),t),(e={typeName:"联系电话",typeFlag:"1",logisticsType:"1",contentType:2,id:""},i(e,"contentType",1),i(e,"publicFlag",1),e),(n={typeName:"联系地址",typeFlag:"1",logisticsType:"1",contentType:1,id:""},i(n,"contentType",1),i(n,"publicFlag",1),n)],logisticsColumns:[(s={typeName:"联系人姓名",typeFlag:"1",logisticsType:"2",contentType:1,id:""},i(s,"contentType",1),i(s,"publicFlag",1),s),(o={typeName:"联系电话",typeFlag:"1",logisticsType:"2",contentType:1,id:""},i(o,"contentType",1),i(o,"publicFlag",1),o),(c={typeName:"联系地址",typeFlag:"1",logisticsType:"2",contentType:1,id:""},i(c,"contentType",1),i(c,"publicFlag",1),c)],logisticsTemplateId:""}},onShow:function(){var t=this;setTimeout((function(e){2==t.pickId&&t.ztiArr.length<1&&(t.pickId=1)}),500)},onLoad:function(e){var i=JSON.parse(decodeURIComponent(e.item));console.log("物流入参==",i),2==i.way?(this.pickId=2,this.picknums="已选择"+this.ztiArr.length+"个",this.logisticsColumns=i.logisticsColumns,this.otherFun(i.id)):(this.pickId=1,this.logisticsColumnsKd=i.logisticsColumns,i.logisticsTemplateId&&(this.logisticsTemplateId=i.logisticsTemplateId),i.logisticsTemplateName&&(this.templteName=i.logisticsTemplateName)),t.hideShareMenu({})},methods:{addTypes:function(e){this.editIdt=0,this.editType=this.pickId,console.log("点击了第".concat(e+1,"项，内容为：").concat(this.listType[e].text)),this.typeCheck!=e+1&&(this.typeCheck=e+1),t.navigateTo({url:"../pageRelay/diyEditcol?text=&type="+this.typeCheck})},diyType:function(){},pickWl:function(e){e<3&&(this.pickId=e),2==e&&t.navigateTo({url:"./addressListZti?id="+this.ztiArr}),3==e&&t.navigateTo({url:"../pageRelay/freightMu?id="+this.logisticsTemplateId+"&name="+this.templteName}),4==e&&t.navigateTo({url:"../pageRelay/awardSellZti?id="+this.ztiArr})},pickZtele:function(e,i){if(i<3&&1==this.pickId)return t.showToast({title:"快递团不可取消该信息",icon:"none"}),!1;1==e.typeFlag?e.typeFlag=2:e.typeFlag=1},goaddZti:function(){t.navigateTo({url:"./addressListZti"})},otherFun:function(t){console.log("佣金也传参",t),this.ztiArr=t,this.picknums="已选择"+t.length+"个"},gobacks:function(){var e={logisticsWay:this.pickId,logisticsRecordIds:this.ztiArr,logisticsColumns:1==this.pickId?this.logisticsColumnsKd:this.logisticsColumns};1==this.pickId&&this.logisticsTemplateId&&(e.logisticsTemplateId=this.logisticsTemplateId,e.templteName=this.templteName);var i=getCurrentPages();i[i.length-2].$vm.otherFun(e),t.navigateBack()},goPage:function(e,i){console.log("itemindex",e,i),this.editIdt=i,this.editType=this.pickId,t.navigateTo({url:"../pageRelay/diyEditcol?text="+e.typeName+"&type="+e.contentType})},textFun:function(t){console.log("sellFun",t,this.editType),2==this.editType?0!=this.editIdt?this.logisticsColumns[this.editIdt].typeName=t.text:this.logisticsColumns.push({typeName:t.text,typeFlag:"2",logisticsType:"2",contentType:t.type,publicFlag:1,id:""}):0!=this.editIdt?this.logisticsColumnsKd[this.editIdt].typeName=t.text:this.logisticsColumnsKd.push({typeName:t.text,typeFlag:"2",logisticsType:"1",contentType:t.type,publicFlag:1,id:""}),console.log("sellFunEnd",t,this.logisticsColumnsKd)},restZiti:function(t){1==t?this.logisticsColumnsKd=[{typeName:"联系人姓名",typeFlag:"1",logisticsType:"1",contentType:1,id:"",publicFlag:1},{typeName:"联系电话",typeFlag:"1",logisticsType:"1",contentType:1,id:"",publicFlag:1},{typeName:"联系地址",typeFlag:"1",logisticsType:"1",contentType:1,id:"",publicFlag:1}]:this.logisticsColumns=[{typeName:"联系人姓名",typeFlag:"1",logisticsType:"2",contentType:1,id:"",publicFlag:1},{typeName:"联系电话",typeFlag:"1",logisticsType:"2",contentType:1,id:"",publicFlag:1},{typeName:"联系地址",typeFlag:"1",logisticsType:"2",contentType:1,id:"",publicFlag:1}]},tmpFun:function(t){this.logisticsTemplateId=t.logisticsTemplateId,t.templteName&&(this.templteName=t.templteName)}}};e.default=n}).call(this,i(1).default)},90:function(t,e,i){"use strict";i.r(e);var n=i(91),s=i.n(n);for(var o in n)"default"!==o&&function(t){i.d(e,t,(function(){return n[t]}))}(o);e.default=s.a},91:function(t,e,i){},92:function(t,e,i){"use strict";i.r(e);var n=i(93),s=i.n(n);for(var o in n)"default"!==o&&function(t){i.d(e,t,(function(){return n[t]}))}(o);e.default=s.a},93:function(t,e,i){}},[[84,"common/runtime","common/vendor"]]]);
},{isPage:true,isComponent:true,currentFile:'pages/subPage/checkFlow.js'});require("pages/subPage/checkFlow.js");