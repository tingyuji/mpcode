$gwx_XC_44=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_44 || [];
function gz$gwx_XC_44_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_44_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_44_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_44_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'content'])
Z([3,'bg_img'])
Z([3,'scaleToFill'])
Z([3,'http://qiniuimg.kfmanager.com/qunjl/showrel/pay/img003.png'])
Z([3,'page_content'])
Z([3,'header_btn_back'])
Z([3,'__e'])
Z([3,'btn_back'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[1,'go_back']]]]]]]]])
Z([3,'img'])
Z([3,'aspectFit'])
Z([3,'http://qiniuimg.kfmanager.com/qunjl/showrel/pay/img002.png'])
Z([3,'img_title'])
Z(z[9])
Z([3,'widthFix'])
Z([3,'http://qiniuimg.kfmanager.com/qunjl/showrel/pay/img001.png'])
Z([3,'welfare_list'])
Z([3,'index'])
Z([3,'item'])
Z([[7],[3,'listData']])
Z(z[17])
Z([3,'welfare_li'])
Z([3,'welfare_li_title'])
Z([3,'head_info'])
Z([3,'head_img'])
Z(z[10])
Z([[6],[[7],[3,'item']],[3,'headImg']])
Z([3,'head_name'])
Z([a,[[2,'+'],[[2,'+'],[1,''],[[6],[[7],[3,'item']],[3,'nickName']]],[1,'']]])
Z(z[6])
Z([3,'btn_lhb'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'open_hb_pop']],[[4],[[5],[1,'$0']]]],[[4],[[5],[[4],[[5],[[4],[[5],[[5],[[5],[[5],[1,'listData']],[1,'']],[[7],[3,'index']]],[1,'userId']]]]]]]]]]]]]]])
Z([3,'领红包'])
Z([3,'tj'])
Z([3,'tj_text'])
Z([a,[[2,'+'],[[2,'+'],[1,'销售额: '],[[6],[[7],[3,'item']],[3,'showTotalMoney']]],[1,'元']]])
Z(z[34])
Z([a,[[2,'+'],[1,'好友: '],[[6],[[7],[3,'item']],[3,'userCount']]]])
Z(z[34])
Z([a,[[2,'+'],[1,'接龙人次: '],[[6],[[7],[3,'item']],[3,'orderCount']]]])
Z([3,'text'])
Z([a,[[2,'+'],[[2,'+'],[[2,'+'],[[2,'+'],[[2,'+'],[[2,'+'],[1,''],[[6],[[7],[3,'item']],[3,'nickName']]],[1,'是大团长，加入群优选']],[[6],[[7],[3,'item']],[3,'gapMonth']]],[1,'个月了，']],[[6],[[7],[3,'item']],[3,'orderCount']]],[1,'+人接龙过，关注私聊一起赚钱。']]])
Z([[7],[3,'hb_pop_isopen']])
Z([3,'hb_pop'])
Z([3,'hb_pop_content'])
Z([3,'hb_bg_img'])
Z(z[2])
Z([3,'http://qiniuimg.kfmanager.com/qunjl/showrel/pay/img009.png'])
Z([3,'hb_info'])
Z([3,'hb_title'])
Z([3,'hb_title_text'])
Z([3,'img_bg_left'])
Z(z[10])
Z([3,'http://qiniuimg.kfmanager.com/qunjl/showrel/pay/img007.png'])
Z([3,'恭喜获得'])
Z([3,'img_bg_right'])
Z(z[10])
Z([3,'http://qiniuimg.kfmanager.com/qunjl/showrel/pay/img008.png'])
Z([3,'hb_price'])
Z([3,'price'])
Z([a,[[7],[3,'redpackMoney']]])
Z([3,'dw'])
Z([3,'元'])
Z([3,'hb_btn_lq'])
Z([3,'hb_btn_lq_bg'])
Z(z[2])
Z([3,'http://qiniuimg.kfmanager.com/qunjl/showrel/pay/img006.png'])
Z(z[6])
Z([3,'hb_btn_lq_text'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[1,'closeHbpp']]]]]]]]])
Z([3,'开心收下'])
Z([3,'text_sm'])
Z([3,'金额可在[我的-余额]查看'])
Z(z[6])
Z([3,'btn_close'])
Z(z[69])
Z(z[2])
Z([3,'http://qiniuimg.kfmanager.com/qunjl/showrel/pay/img005.png'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_44_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_44_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_44=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_44=true;
var x=['./pages/subPage/welfare.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_44_1()
var oR6C=_n('view')
_rz(z,oR6C,'class',0,e,s,gg)
var xS6C=_mz(z,'image',['class',1,'mode',1,'src',2],[],e,s,gg)
_(oR6C,xS6C)
var oT6C=_n('view')
_rz(z,oT6C,'class',4,e,s,gg)
var cV6C=_n('view')
_rz(z,cV6C,'class',5,e,s,gg)
var hW6C=_mz(z,'view',['bindtap',6,'class',1,'data-event-opts',2],[],e,s,gg)
var oX6C=_mz(z,'image',['class',9,'mode',1,'src',2],[],e,s,gg)
_(hW6C,oX6C)
_(cV6C,hW6C)
_(oT6C,cV6C)
var cY6C=_n('view')
_rz(z,cY6C,'class',12,e,s,gg)
var oZ6C=_mz(z,'image',['class',13,'mode',1,'src',2],[],e,s,gg)
_(cY6C,oZ6C)
_(oT6C,cY6C)
var l16C=_n('view')
_rz(z,l16C,'class',16,e,s,gg)
var a26C=_v()
_(l16C,a26C)
var t36C=function(b56C,e46C,o66C,gg){
var o86C=_n('view')
_rz(z,o86C,'class',21,b56C,e46C,gg)
var f96C=_n('view')
_rz(z,f96C,'class',22,b56C,e46C,gg)
var c06C=_n('view')
_rz(z,c06C,'class',23,b56C,e46C,gg)
var hA7C=_mz(z,'image',['class',24,'mode',1,'src',2],[],b56C,e46C,gg)
_(c06C,hA7C)
var oB7C=_n('view')
_rz(z,oB7C,'class',27,b56C,e46C,gg)
var cC7C=_oz(z,28,b56C,e46C,gg)
_(oB7C,cC7C)
_(c06C,oB7C)
_(f96C,c06C)
var oD7C=_mz(z,'view',['bindtap',29,'class',1,'data-event-opts',2],[],b56C,e46C,gg)
var lE7C=_oz(z,32,b56C,e46C,gg)
_(oD7C,lE7C)
_(f96C,oD7C)
_(o86C,f96C)
var aF7C=_n('view')
_rz(z,aF7C,'class',33,b56C,e46C,gg)
var tG7C=_n('text')
_rz(z,tG7C,'class',34,b56C,e46C,gg)
var eH7C=_oz(z,35,b56C,e46C,gg)
_(tG7C,eH7C)
_(aF7C,tG7C)
var bI7C=_n('text')
_rz(z,bI7C,'class',36,b56C,e46C,gg)
var oJ7C=_oz(z,37,b56C,e46C,gg)
_(bI7C,oJ7C)
_(aF7C,bI7C)
var xK7C=_n('text')
_rz(z,xK7C,'class',38,b56C,e46C,gg)
var oL7C=_oz(z,39,b56C,e46C,gg)
_(xK7C,oL7C)
_(aF7C,xK7C)
_(o86C,aF7C)
var fM7C=_n('view')
_rz(z,fM7C,'class',40,b56C,e46C,gg)
var cN7C=_oz(z,41,b56C,e46C,gg)
_(fM7C,cN7C)
_(o86C,fM7C)
_(o66C,o86C)
return o66C
}
a26C.wxXCkey=2
_2z(z,19,t36C,e,s,gg,a26C,'item','index','index')
_(oT6C,l16C)
var fU6C=_v()
_(oT6C,fU6C)
if(_oz(z,42,e,s,gg)){fU6C.wxVkey=1
var hO7C=_n('view')
_rz(z,hO7C,'class',43,e,s,gg)
var oP7C=_n('view')
_rz(z,oP7C,'class',44,e,s,gg)
var cQ7C=_mz(z,'image',['class',45,'mode',1,'src',2],[],e,s,gg)
_(oP7C,cQ7C)
var oR7C=_n('view')
_rz(z,oR7C,'class',48,e,s,gg)
var lS7C=_n('view')
_rz(z,lS7C,'class',49,e,s,gg)
var aT7C=_n('view')
_rz(z,aT7C,'class',50,e,s,gg)
var tU7C=_mz(z,'image',['class',51,'mode',1,'src',2],[],e,s,gg)
_(aT7C,tU7C)
var eV7C=_oz(z,54,e,s,gg)
_(aT7C,eV7C)
var bW7C=_mz(z,'image',['class',55,'mode',1,'src',2],[],e,s,gg)
_(aT7C,bW7C)
_(lS7C,aT7C)
_(oR7C,lS7C)
var oX7C=_n('view')
_rz(z,oX7C,'class',58,e,s,gg)
var xY7C=_n('view')
_rz(z,xY7C,'class',59,e,s,gg)
var oZ7C=_oz(z,60,e,s,gg)
_(xY7C,oZ7C)
_(oX7C,xY7C)
var f17C=_n('view')
_rz(z,f17C,'class',61,e,s,gg)
var c27C=_oz(z,62,e,s,gg)
_(f17C,c27C)
_(oX7C,f17C)
_(oR7C,oX7C)
var h37C=_n('view')
_rz(z,h37C,'class',63,e,s,gg)
var o47C=_mz(z,'image',['class',64,'mode',1,'src',2],[],e,s,gg)
_(h37C,o47C)
var c57C=_mz(z,'view',['bindtap',67,'class',1,'data-event-opts',2],[],e,s,gg)
var o67C=_oz(z,70,e,s,gg)
_(c57C,o67C)
_(h37C,c57C)
_(oR7C,h37C)
var l77C=_n('view')
_rz(z,l77C,'class',71,e,s,gg)
var a87C=_oz(z,72,e,s,gg)
_(l77C,a87C)
_(oR7C,l77C)
_(oP7C,oR7C)
var t97C=_mz(z,'image',['bindtap',73,'class',1,'data-event-opts',2,'mode',3,'src',4],[],e,s,gg)
_(oP7C,t97C)
_(hO7C,oP7C)
_(fU6C,hO7C)
}
fU6C.wxXCkey=1
_(oR6C,oT6C)
_(r,oR6C)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_44";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_44();
	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/subPage/welfare.wxml'] = [$gwx_XC_44, './pages/subPage/welfare.wxml'];else __wxAppCode__['pages/subPage/welfare.wxml'] = $gwx_XC_44( './pages/subPage/welfare.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['pages/subPage/welfare.wxss'] = setCssToHead([".",[1],"content{padding-top:25px}\n.",[1],"bg_img{bottom:0;height:100%;left:0;position:fixed;right:0;top:0;width:100%}\n.",[1],"page_content{padding-bottom:",[0,60],";padding-top:",[0,88],";position:relative;z-index:3}\n.",[1],"header_btn_back{left:",[0,30],";padding-top:25px;position:fixed;top:",[0,14],";z-index:99}\n.",[1],"header_btn_back .",[1],"btn_back{height:",[0,70],";padding:",[0,10]," 0;width:",[0,70],"}\n.",[1],"header_btn_back .",[1],"btn_back .",[1],"img{display:block;height:",[0,70],";width:",[0,70],"}\n.",[1],"img_title{padding:0 ",[0,30],"}\n.",[1],"img_title .",[1],"img{display:block;width:100%}\n.",[1],"welfare_list{padding:",[0,20]," ",[0,30],"}\n.",[1],"welfare_li{background-color:#fff;border-radius:",[0,20],";margin-top:",[0,20],";overflow:hidden;padding:",[0,30]," ",[0,26],"}\n.",[1],"welfare_li_title{-webkit-align-items:flex-start;align-items:flex-start}\n.",[1],"head_info,.",[1],"welfare_li_title{display:-webkit-flex;display:flex}\n.",[1],"head_info{-webkit-align-items:center;align-items:center;-webkit-flex:1;flex:1}\n.",[1],"head_info .",[1],"head_img{border-radius:50%;display:block;height:",[0,80],";margin-right:",[0,16],";width:",[0,80],"}\n.",[1],"head_info .",[1],"head_name{color:#333;-webkit-flex:1;flex:1;font-size:",[0,32],";font-weight:700;line-height:",[0,48],"}\n.",[1],"welfare_li_title .",[1],"btn_lhb{background:#fd2e2e;background:-webkit-linear-gradient(left,#fead57,#fd2e2e);border-radius:",[0,10],";color:#fff;font-size:",[0,28],";font-weight:700;height:",[0,56],";line-height:",[0,56],";margin-left:",[0,30],";padding:0 ",[0,26],"}\n.",[1],"welfare_li .",[1],"tj{color:#49c265;font-size:",[0,24],";line-height:",[0,40],";margin:",[0,10]," ",[0,-16]," 0}\n.",[1],"welfare_li .",[1],"tj .",[1],"tj_text{margin:0 ",[0,16],"}\n.",[1],"welfare_li .",[1],"text{color:#333;font-size:",[0,28],";line-height:",[0,40],";margin-top:",[0,16],"}\n.",[1],"hb_pop{background-color:rgba(0,0,0,.8);bottom:0;left:0;position:fixed;right:0;top:0;z-index:999}\n.",[1],"hb_pop_content{height:",[0,672],";left:50%;margin-left:",[0,-328],";margin-top:",[0,-336],";position:fixed;top:50%;width:",[0,656],"}\n.",[1],"hb_pop_content .",[1],"hb_bg_img{bottom:0;height:100%;left:0;position:absolute;right:0;top:0;width:100%}\n.",[1],"hb_pop_content .",[1],"btn_close{bottom:",[0,-100],";height:",[0,60],";left:50%;margin-left:",[0,-30],";position:absolute;width:",[0,60],"}\n.",[1],"hb_info{padding-top:",[0,120],";position:relative;z-index:9}\n.",[1],"hb_info .",[1],"hb_title{text-align:center}\n.",[1],"hb_info .",[1],"hb_title .",[1],"hb_title_text{color:#d76817;display:inline-block;font-size:",[0,50],";font-weight:700;line-height:",[0,70],";padding:0 ",[0,118],";position:relative}\n.",[1],"hb_info .",[1],"hb_title .",[1],"hb_title_text .",[1],"img_bg_left{height:",[0,6],";left:0;margin-top:",[0,-3],";position:absolute;top:50%;width:",[0,88],"}\n.",[1],"hb_info .",[1],"hb_title .",[1],"hb_title_text .",[1],"img_bg_right{height:",[0,6],";margin-top:",[0,-3],";position:absolute;right:0;top:50%;width:",[0,88],"}\n.",[1],"hb_info .",[1],"hb_price{-webkit-align-items:flex-end;align-items:flex-end;color:#fc4532;display:-webkit-flex;display:flex;font-size:",[0,112],";font-weight:700;-webkit-justify-content:center;justify-content:center;line-height:",[0,112],";margin-top:",[0,50],"}\n.",[1],"hb_info .",[1],"hb_price .",[1],"dw{font-size:",[0,48],";line-height:",[0,80],";margin-left:",[0,16],"}\n.",[1],"hb_info .",[1],"hb_btn_lq{border-radius:",[0,56],";box-shadow:",[0,0]," ",[0,22]," ",[0,10]," ",[0,0]," rgba(206,129,54,.45);height:",[0,112],";margin:",[0,100]," auto 0;position:relative;width:",[0,360],"}\n.",[1],"hb_info .",[1],"hb_btn_lq .",[1],"hb_btn_lq_bg{bottom:0;height:100%;left:0;position:absolute;right:0;top:0;width:100%}\n.",[1],"hb_info .",[1],"hb_btn_lq .",[1],"hb_btn_lq_text{color:#fff;font-size:",[0,46],";line-height:",[0,112],";position:relative;text-align:center;z-index:3}\n.",[1],"hb_info .",[1],"text_sm{color:#bc7a1d;font-size:",[0,28],";line-height:",[0,40],";margin-top:",[0,30],";padding:0 ",[0,100],";text-align:center}\n",],undefined,{path:"./pages/subPage/welfare.wxss"});
}