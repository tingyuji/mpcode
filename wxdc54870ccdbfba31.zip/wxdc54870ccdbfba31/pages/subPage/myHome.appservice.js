$gwx_XC_37=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_37 || [];
function gz$gwx_XC_37_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_37_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_37_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_37_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'background-color:#f5f5f5;position:relative;top:0;left:0;width:750rpx;'])
Z([3,'top_content_n'])
Z([3,'position:absolute;top:208rpx;'])
Z([[7],[3,'isMe']])
Z([[2,'&&'],[[2,'!'],[[6],[[7],[3,'userInfos']],[3,'subscribe']]],[[2,'!'],[[7],[3,'isMe']]]])
Z([[2,'=='],[[6],[[7],[3,'userInfos']],[3,'indexStyle']],[1,1]])
Z([3,'index'])
Z([3,'item'])
Z([[7],[3,'activityOwnLi']])
Z(z[6])
Z([3,'tg_con_n mt20'])
Z([[2,'!='],[[6],[[7],[3,'item']],[3,'activityType']],[1,20]])
Z([3,'__e'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'goOrder']],[[4],[[5],[1,'$0']]]],[[4],[[5],[[4],[[5],[[4],[[5],[[5],[[5],[[5],[1,'activityOwnLi']],[1,'']],[[7],[3,'index']]],[1,'activityId']]]]]]]]]]]]]]])
Z([3,'sc_con_n'])
Z([3,'sc_tit_n shop_tit'])
Z([[2,'>'],[[6],[[7],[3,'item']],[3,'topFlag']],[1,0]])
Z([[2,'&&'],[[2,'=='],[[6],[[7],[3,'item']],[3,'freezeFlag']],[1,2]],[[2,'>'],[[6],[[7],[3,'item']],[3,'topFlag']],[1,0]]])
Z([[2,'=='],[[6],[[7],[3,'item']],[3,'freezeFlag']],[1,2]])
Z([[2,'=='],[[6],[[7],[3,'item']],[3,'activityType']],[1,2]])
Z([[6],[[7],[3,'item']],[3,'imgArrs']])
Z([3,'gm_list'])
Z([3,'padding-bottom:10rpx;'])
Z([3,'k'])
Z([3,'j'])
Z([[6],[[7],[3,'item']],[3,'orderInfos']])
Z(z[23])
Z([[2,'!='],[[6],[[7],[3,'j']],[3,'formatName']],[1,'默认 ']])
Z([[2,'!'],[[6],[[6],[[7],[3,'item']],[3,'orderInfos']],[3,'length']]])
Z([3,'fl'])
Z([[2,'||'],[[2,'&&'],[[6],[[7],[3,'item']],[3,'oneClickHelpSell']],[[2,'=='],[[6],[[7],[3,'item']],[3,'helpSellFlag']],[1,2]]],[[2,'=='],[[6],[[7],[3,'item']],[3,'activityType']],[1,2]]])
Z(z[30])
Z([3,'shop_infos wei_xc'])
Z([[2,'!'],[[6],[[7],[3,'item']],[3,'hasVideo']]])
Z([3,'shop_img fl'])
Z([[2,'||'],[[2,'||'],[[2,'=='],[[6],[[6],[[7],[3,'item']],[3,'imgArrs']],[3,'length']],[1,2]],[[2,'=='],[[6],[[6],[[7],[3,'item']],[3,'imgArrs']],[3,'length']],[1,5]]],[[2,'=='],[[6],[[6],[[7],[3,'item']],[3,'imgArrs']],[3,'length']],[1,8]]])
Z([[2,'||'],[[2,'||'],[[2,'=='],[[6],[[6],[[7],[3,'item']],[3,'imgArrs']],[3,'length']],[1,1]],[[2,'=='],[[6],[[6],[[7],[3,'item']],[3,'imgArrs']],[3,'length']],[1,4]]],[[2,'=='],[[6],[[6],[[7],[3,'item']],[3,'imgArrs']],[3,'length']],[1,7]]])
Z(z[36])
Z(z[6])
Z(z[7])
Z(z[8])
Z(z[6])
Z(z[11])
Z(z[12])
Z([3,'tg_con_n_t'])
Z(z[13])
Z(z[15])
Z(z[16])
Z(z[17])
Z(z[18])
Z([3,'__l'])
Z(z[12])
Z([3,'14'])
Z([1,true])
Z([[4],[[5],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'showPop']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z([3,'center'])
Z([[7],[3,'showPop']])
Z([3,'d0ef26fc-1'])
Z([[4],[[5],[1,'default']]])
Z([[7],[3,'showShares']])
Z(z[50])
Z(z[12])
Z(z[12])
Z([3,'zuj_fix'])
Z([[4],[[5],[[5],[[4],[[5],[[5],[1,'^shareUrl']],[[4],[[5],[[4],[[5],[1,'shareUrl']]]]]]]],[[4],[[5],[[5],[1,'^closeShare']],[[4],[[5],[[4],[[5],[1,'closeShare']]]]]]]]])
Z([[7],[3,'shareObj']])
Z([3,'d0ef26fc-2'])
Z(z[53])
Z([3,'#FFF'])
Z(z[50])
Z([[7],[3,'loading']])
Z([3,'d0ef26fc-3'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_37_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_37_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_37=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_37=true;
var x=['./pages/subPage/myHome.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_37_1()
var fGM=_n('view')
_rz(z,fGM,'style',0,e,s,gg)
var oJM=_mz(z,'view',['class',1,'style',1],[],e,s,gg)
var cKM=_v()
_(oJM,cKM)
if(_oz(z,3,e,s,gg)){cKM.wxVkey=1
}
var oLM=_v()
_(oJM,oLM)
if(_oz(z,4,e,s,gg)){oLM.wxVkey=1
}
cKM.wxXCkey=1
oLM.wxXCkey=1
_(fGM,oJM)
var cHM=_v()
_(fGM,cHM)
if(_oz(z,5,e,s,gg)){cHM.wxVkey=1
var lMM=_v()
_(cHM,lMM)
var aNM=function(ePM,tOM,bQM,gg){
var xSM=_n('view')
_rz(z,xSM,'class',10,ePM,tOM,gg)
var oTM=_v()
_(xSM,oTM)
if(_oz(z,11,ePM,tOM,gg)){oTM.wxVkey=1
var fUM=_mz(z,'view',['bindtap',12,'data-event-opts',1],[],ePM,tOM,gg)
var hWM=_n('view')
_rz(z,hWM,'class',14,ePM,tOM,gg)
var cYM=_n('view')
_rz(z,cYM,'class',15,ePM,tOM,gg)
var oZM=_v()
_(cYM,oZM)
if(_oz(z,16,ePM,tOM,gg)){oZM.wxVkey=1
}
var l1M=_v()
_(cYM,l1M)
if(_oz(z,17,ePM,tOM,gg)){l1M.wxVkey=1
}
else{l1M.wxVkey=2
var a2M=_v()
_(l1M,a2M)
if(_oz(z,18,ePM,tOM,gg)){a2M.wxVkey=1
}
a2M.wxXCkey=1
}
oZM.wxXCkey=1
l1M.wxXCkey=1
_(hWM,cYM)
var oXM=_v()
_(hWM,oXM)
if(_oz(z,19,ePM,tOM,gg)){oXM.wxVkey=1
}
oXM.wxXCkey=1
_(fUM,hWM)
var cVM=_v()
_(fUM,cVM)
if(_oz(z,20,ePM,tOM,gg)){cVM.wxVkey=1
}
var t3M=_mz(z,'view',['class',21,'style',1],[],ePM,tOM,gg)
var b5M=_v()
_(t3M,b5M)
var o6M=function(o8M,x7M,f9M,gg){
var hAN=_v()
_(f9M,hAN)
if(_oz(z,27,o8M,x7M,gg)){hAN.wxVkey=1
}
hAN.wxXCkey=1
return f9M
}
b5M.wxXCkey=2
_2z(z,25,o6M,ePM,tOM,gg,b5M,'j','k','k')
var e4M=_v()
_(t3M,e4M)
if(_oz(z,28,ePM,tOM,gg)){e4M.wxVkey=1
}
e4M.wxXCkey=1
_(fUM,t3M)
var oBN=_n('view')
_rz(z,oBN,'class',29,ePM,tOM,gg)
var cCN=_v()
_(oBN,cCN)
if(_oz(z,30,ePM,tOM,gg)){cCN.wxVkey=1
}
var oDN=_v()
_(oBN,oDN)
if(_oz(z,31,ePM,tOM,gg)){oDN.wxVkey=1
}
cCN.wxXCkey=1
oDN.wxXCkey=1
_(fUM,oBN)
cVM.wxXCkey=1
_(oTM,fUM)
}
else{oTM.wxVkey=2
var lEN=_n('view')
_rz(z,lEN,'class',32,ePM,tOM,gg)
var aFN=_v()
_(lEN,aFN)
if(_oz(z,33,ePM,tOM,gg)){aFN.wxVkey=1
var tGN=_n('view')
_rz(z,tGN,'class',34,ePM,tOM,gg)
var eHN=_v()
_(tGN,eHN)
if(_oz(z,35,ePM,tOM,gg)){eHN.wxVkey=1
}
var bIN=_v()
_(tGN,bIN)
if(_oz(z,36,ePM,tOM,gg)){bIN.wxVkey=1
}
var oJN=_v()
_(tGN,oJN)
if(_oz(z,37,ePM,tOM,gg)){oJN.wxVkey=1
}
eHN.wxXCkey=1
bIN.wxXCkey=1
oJN.wxXCkey=1
_(aFN,tGN)
}
else{aFN.wxVkey=2
}
aFN.wxXCkey=1
_(oTM,lEN)
}
oTM.wxXCkey=1
_(bQM,xSM)
return bQM
}
lMM.wxXCkey=2
_2z(z,8,aNM,e,s,gg,lMM,'item','index','index')
}
else{cHM.wxVkey=2
var xKN=_v()
_(cHM,xKN)
var oLN=function(cNN,fMN,hON,gg){
var cQN=_v()
_(hON,cQN)
if(_oz(z,42,cNN,fMN,gg)){cQN.wxVkey=1
var oRN=_mz(z,'view',['bindtap',43,'class',1,'data-event-opts',2],[],cNN,fMN,gg)
var lSN=_n('view')
_rz(z,lSN,'class',46,cNN,fMN,gg)
var aTN=_v()
_(lSN,aTN)
if(_oz(z,47,cNN,fMN,gg)){aTN.wxVkey=1
}
var tUN=_v()
_(lSN,tUN)
if(_oz(z,48,cNN,fMN,gg)){tUN.wxVkey=1
}
else{tUN.wxVkey=2
var eVN=_v()
_(tUN,eVN)
if(_oz(z,49,cNN,fMN,gg)){eVN.wxVkey=1
}
eVN.wxXCkey=1
}
aTN.wxXCkey=1
tUN.wxXCkey=1
_(oRN,lSN)
_(cQN,oRN)
}
cQN.wxXCkey=1
return hON
}
xKN.wxXCkey=2
_2z(z,40,oLN,e,s,gg,xKN,'item','index','index')
}
var bWN=_mz(z,'u-popup',['bind:__l',50,'bind:input',1,'borderRadius',2,'closeable',3,'data-event-opts',4,'mode',5,'value',6,'vueId',7,'vueSlots',8],[],e,s,gg)
_(fGM,bWN)
var hIM=_v()
_(fGM,hIM)
if(_oz(z,59,e,s,gg)){hIM.wxVkey=1
var oXN=_mz(z,'dc-hiro-painter',['bind:__l',60,'bind:closeShare',1,'bind:shareUrl',2,'class',3,'data-event-opts',4,'shareObj',5,'vueId',6],[],e,s,gg)
_(hIM,oXN)
}
var xYN=_mz(z,'u-skeleton',['animation',67,'bgColor',1,'bind:__l',2,'loading',3,'vueId',4],[],e,s,gg)
_(fGM,xYN)
cHM.wxXCkey=1
hIM.wxXCkey=1
hIM.wxXCkey=3
_(r,fGM)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_37";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_37();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/subPage/myHome.wxml'] = [$gwx_XC_37, './pages/subPage/myHome.wxml'];else __wxAppCode__['pages/subPage/myHome.wxml'] = $gwx_XC_37( './pages/subPage/myHome.wxml' );
	;__wxRoute = "pages/subPage/myHome";__wxRouteBegin = true;__wxAppCurrentFile__="pages/subPage/myHome.js";define("pages/subPage/myHome.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
(global.webpackJsonp=global.webpackJsonp||[]).push([["pages/subPage/myHome"],{226:function(e,t,s){"use strict";(function(e){s(5),n(s(4));var t=n(s(227));function n(e){return e&&e.__esModule?e:{default:e}}wx.__webpack_require_UNI_MP_PLUGIN__=s,e(t.default)}).call(this,s(1).createPage)},227:function(e,t,s){"use strict";s.r(t);var n=s(228),i=s(230);for(var o in i)"default"!==o&&function(e){s.d(t,e,(function(){return i[e]}))}(o);s(232);var a=s(17),r=Object(a.default)(i.default,n.render,n.staticRenderFns,!1,null,null,null,!1,n.components,void 0);r.options.__file="pages/subPage/myHome.vue",t.default=r.exports},228:function(e,t,s){"use strict";s.r(t);var n=s(229);s.d(t,"render",(function(){return n.render})),s.d(t,"staticRenderFns",(function(){return n.staticRenderFns})),s.d(t,"recyclableRender",(function(){return n.recyclableRender})),s.d(t,"components",(function(){return n.components}))},229:function(e,t,s){"use strict";var n;s.r(t),s.d(t,"render",(function(){return i})),s.d(t,"staticRenderFns",(function(){return a})),s.d(t,"recyclableRender",(function(){return o})),s.d(t,"components",(function(){return n}));try{n={uPopup:function(){return s.e("uview-ui/components/u-popup/u-popup").then(s.bind(null,939))},dcHiroPainter:function(){return s.e("components/dc-hiro-painter/dc-hiro-painter").then(s.bind(null,875))},uSkeleton:function(){return s.e("uview-ui/components/u-skeleton/u-skeleton").then(s.bind(null,889))}}}catch(e){if(-1===e.message.indexOf("Cannot find module")||-1===e.message.indexOf(".vue"))throw e;console.error(e.message),console.error("1. 排查组件名称拼写是否正确"),console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"),console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件")}var i=function(){this.$createElement,this._self._c},o=!1,a=[];i._withStripped=!0},230:function(e,t,s){"use strict";s.r(t);var n=s(231),i=s.n(n);for(var o in n)"default"!==o&&function(e){s.d(t,e,(function(){return n[e]}))}(o);t.default=i.a},231:function(e,t,s){"use strict";(function(e){Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var n=function(e){return e&&e.__esModule?e:{default:e}}(s(61)),i={data:function(){return{classMask:"my_home1 fix_banner_n my_homes",headMask:"",sortMode:0,listTab:["最新产品","销量"],currentShequn:0,firstCom:!1,showHomeBtn:!1,isMe:!1,showPop:!1,showMenu:!1,shareObj:{},showShares:!1,showSharesBox:!1,userInfoHome:{},shareImgMini:"",menuStyle:{},countSubData:{canApply:.28,applying:0,total:.56,hasApply:0,recommend:.26,preReceiving:0},loading:!0,activityLi:[],userInfos:{},nickName:"",activityOwnLi:[],page:1,finished:!1,userId:"",scanCode:!1,top:"",tabIndex:0,tabIndex1:0,helpSellUserId:"",enterTime:"Wed Jul 27 2022 15:24:31 GMT+0800 (中国标准时间)",ztUserId:""}},computed:{getIcon:function(){}},onShareAppMessage:function(t){e.getStorageSync("userInfo");var s={title:"快来接龙吧",path:"/pages/subPage/showRel",imageUrl:"https://qiniuimg.kfmanager.com/qunjl/showrel/yqrjl.jpg",success:function(e){e.errMsg}};if("button"==t.from){t.target.dataset;var n=this;s.imageUrl=n.shareImgMini,s.title=n.shareObj.title,s.path="/pages/subPage/showRel?"+n.shareObj.shareScene}return s},onShow:function(){this.userInfos.nickName&&this.getUserInfo()},onReachBottom:function(){this.finished||(this.page++,this.userActList())},onUnload:function(){var e=new Date,t=e.getTime()-this.enterTime.getTime(),s=Math.ceil(t/1e3),n=[{pageType:2,userId:this.userId,accessTime:s}];console.log("页面卸载1:",e),console.log("页面卸载2:",this.enterTime),console.log("页面卸载3:",t),console.log("页面卸载4:",s),this.sendAccessLog(n)},onLoad:function(t){var s=this;this.enterTime=new Date;var n=wx.getMenuButtonBoundingClientRect();this.top=n.top,e.hideShareMenu({});var i={};if(t.scene){var o=decodeURIComponent(t.scene).split("&");console.log("msceneArr==",o);for(var a=0;a<o.length;a++){var r=o[a].split("=");i[r[0]]=r[1]}}var c=t.z||i.z,u=t.uid||i.uid;(t.zt||i.zt)&&(this.ztUserId=t.zt||i.zt),console.log("加入的参数圆圆圆==",t,"222=",i),this.userId=u,c&&(this.helpSellUserId=this.userId,console.log("加入的参数圆圆圆==",t,"222=",this.helpSellUserId));var l=e.getStorageSync("userInfo")||{};this.userId==l.userId&&(this.isMe=!0);var m=this,h=getCurrentPages();if(h.length>1)console.log("非小程序进入跳转页==",h),this.userInfoHome=l,this.getUserInfo();else{if(this.showHomeBtn=!0,2==l.userType)return this.opearatReLogin(),setTimeout((function(e){console.log("员工登录免再登录myHome",l.userType),s.getUserInfo()}),800),!1;wx.login({success:function(t){t.code&&m.$server.login({agentId:m.$agentId,code:t.code,fromUserId:m.userId,helpSellUserId:m.helpSellUserId}).then((function(t){m.userInfoHome=t,m.userId==m.userInfoHome.userId?m.isMe=!0:m.helpSellUserId?e.showToast({title:"帮卖成功",icon:"success",duration:2e3}):m.ztUserId&&m.setAddrManager(),e.setStorageSync("userInfo",t),m.getUserInfo()}))}})}},methods:{changeShequn:function(e){console.log("tab==",e),this.currentShequn==e||(this.currentShequn=e,this.page=1,this.finished=!1,this.userActList())},setAddrManager:function(){this.$server.setAddrManager({addressId:this.ztUserId,userId:this.userId,type:2}).then((function(t){0==t.code?e.showToast({title:"加入成功",icon:"success"}):e.showToast({title:t.message,icon:"none"})}))},shareUrl:function(e){this.shareImgMini=e},closeShare:function(e){console.log("关闭分享弹窗==",e),this.showShares=!1,this.shareObj={}},goEditAlb:function(t,s){e.navigateTo({url:"../pageRelay/issueAlbums?id="+t+"&own="+s})},delOrEdi:function(e){1==e.activityOwner?this.globalDowns(e.imgArrs,e.activityName):this.goEditAlb(e.activityId,e.activityOwner)},deleteAlbums:function(t){var s=this;e.showModal({title:"温馨提示",content:"删除图文后将不可恢复，确认要删除吗？",confirmText:"删除",confirmColor:"#FF0000",success:function(n){n.confirm?s.$server.deleteAlbums({albumsId:t}).then((function(t){0==t.code?(e.showToast({title:"删除成功",icon:"success"}),s.page=1,s.activityOwnLi=[],s.finished=!1,s.userActList()):e.showToast({title:t.message,icon:"none"})})):n.cancel&&console.log("用户点击取消")}})},openShare:function(t,s){e.showLoading({title:"加载中",mask:!0}),s?(this.shareObj.headImg=this.userInfos.headImg||"https://qiniuimg.kfmanager.com/qunjl/logo/qyxlogons.jpg",this.shareObj.nickName=this.userInfos.nickName||"群优选用户",this.shareObj.solitaireCount=this.userInfos.solitaireCount||"5",this.shareObj.solitaireCountShow=this.userInfos.solitaireCount+"次团购",this.shareObj.memberCount=this.userInfos.memberCount,this.shareObj.introduction=this.userInfos.introduction,this.shareObj.typeHome=!0,this.shareObj.shareScene="uid="+this.userId):(this.shareObj.title=t.activityName,this.shareObj.freezeFlag=t.freezeFlag||1,this.shareObj.activityId=t.activityId,this.shareObj.headImg=t.headImg||"https://qiniuimg.kfmanager.com/qunjl/logo/qyxlogons.jpg",this.shareObj.nickName=t.nickName||"群优选用户",this.shareObj.createTime=t.createTime.slice(0,10),this.shareObj.maxSellPriceShow="¥"+t.maxSellPriceShow,this.shareObj.shareBtn="我要团购",this.shareObj.shareScene="id="+t.activityId+"&uid="+this.userInfoHome.userId,this.shareObj.adminUserId=t.userId,t.imgArrs?this.shareObj.imgUrls=t.shareImgs:this.shareObj.imgUrls=[],t.orderInfos.length?this.shareObj.rankList=t.orderInfos:this.shareObj.rankList=!1),this.showShares=!0,setTimeout((function(t){e.hideLoading()}),3e3)},tuiDing:function(){var t=this;e.showModal({title:"提示",content:"退订主页，你将不能收到我的活动发布通知哦",confirmText:"退订",confirmColor:"#ff4d4d",success:function(e){e.cancel?console.log("用户点击取消"):e.confirm&&t.subscribeUser(2)}})},routeTo:function(){var t=getCurrentPages();console.log("pages==",t),t.length>1?e.navigateBack():e.switchTab({url:"../example/home"})},goOrder:function(t){console.log("跳转"),e.navigateTo({url:"./showRel?id="+t})},goCode:function(t,s,n,i){i&&e.navigateTo({url:t+"?id="+s+"&type="+i}),n?e.navigateTo({url:t+"?id="+s+"&types="+n}):e.navigateTo({url:t+"?id="+s})},goCodeYj:function(t){this.$server.oneClickHelpSell({sourceActId:t}).then((function(t){0==t.code?(e.showToast({title:"帮卖成功",icon:"success",duration:2e3}),setTimeout((function(s){e.navigateTo({url:"./showRel?id="+t.data.activityId})}),1500)):e.showToast({title:t.message,icon:"none"})}))},getUserProfile:function(e){var t=this;wx.getUserProfile({desc:"用于完善会员资料",success:function(e){t.perfectBaseInfo(e.encryptedData,e.iv),console.log("getUserProfile=",e)}})},perfectBaseInfo:function(t,s){var n=this;this.$server.perfectBaseInfo({encryptedData:t,iv:s}).then((function(t){t.nickName?(n.nickName=t.nickName,e.setStorageSync("userInfo",t)):e.showToast({title:t.message,icon:"none"})}))},switchTa:function(t){e.switchTab({url:t})},goPage:function(t){e.navigateTo({url:"./editHome"})},getUserInfo:function(){var t=this;this.$server.userIndexInfo({userId:this.userId}).then((function(s){if(0==s.code){if(!s.data.introduction&&(s.data.introduction=""),s.data.memberImgList&&s.data.memberImgList.length){var i=s.data.memberImgList.map((function(e){return console.log("res.menberArr===",e),e||(e="http://qiniuimg.kfmanager.com/qunjl/logo/qyxlogons.jpg"),e}));s.data.memberImgList=i}1==s.data.indexStyle?1==s.data.maskType?t.classMask="my_home3 fix_banner_n my_homes":2==s.data.maskType?t.classMask="my_home2 fix_banner_n my_homes":3==s.data.maskType?t.classMask="my_home1 fix_banner_n my_homes":4==s.data.maskType&&(t.classMask="my_home11 fix_banner_n my_homes"):1==s.data.maskType?t.classMask="my_home6 fix_banner_n my_homess":2==s.data.maskType?t.classMask="my_home5 fix_banner_n my_homess":3==s.data.maskType?t.classMask="my_home4 fix_banner_n my_homess":4==s.data.maskType&&(t.classMask="my_home10 fix_banner_n my_homess"),s.data.memberLevel&&(t.headMask=t.headMask+" jp_tz"),s.data.timeDay=n.default.getGapMonth(s.data.createTime,1),console.log("res.data===",s.data.memberImgList),t.userInfos=s.data,t.userActList(),t.userInfos.subscribe||setTimeout((function(e){t.firstCom=!0}),500),s.data.backgroundImg&&"null"!=s.data.backgroundImg&&s.data.backgroundImg.includes("http")||t.getBgImg(),setTimeout((function(){t.loading=!1}),600)}else e.showToast({title:s.message,icon:"none"})}))},getBgImg:function(){var t=this;this.$server.queryBgImgList().then((function(s){0==s.code?(s.data.splice(1,0,{}),t.userInfos.backgroundImg=s.data[0].smallImg):e.showToast({title:s.message,icon:"none"})}))},userActList:function(){var t=this,s={page:this.page,pageSize:10,userId:this.userId};2==this.userInfos.indexStyle&&1==this.currentShequn?s.sortMode=2:s.sortMode=1,this.$server.userActList(s).then((function(s){if(0==s.code){if(1==t.page&&0==s.data.length)return t.finished=!0,void console.log("无数据");s.data.length<10&&(t.loading=!1,t.finished=!0,console.log("无更多数据"));var i=s.data.actInfoList.map((function(e){if(e.differTime=n.default.getDifferTime(e.createTime,!1),20==e.activityType)e.albumsDetails.length?e.albumsDetails.forEach((function(t){1==t.contentType?e.imgArrs=t.albumsDetail.split(","):2==t.contentType?e.imgArrs=t.albumsDetail:(e.imgArrs=t.albumsDetail.split(","),e.hasVideo=!0)})):(e.imgArrs=[],e.hasVideo=!1);else{if(e.activityDetails.length){var t="";e.activityDetails.forEach((function(s){1==s.contentType?e.showTexts=s.activityDetail:(2==s.contentType||5==s.contentType)&&(t=0!=t.length?t+","+s.activityDetail:s.activityDetail),e.orderInfos.length&&e.orderInfos.forEach((function(e){e.differTime=n.default.getDifferTime(e.createTime,!1),e.nickName?e.nickName=e.nickName.slice(0,1)+"**":e.nickName="**"}))})),0!=t.length?(console.log("cur.imgArrs==",t),e.shareImgs=t.split(","),e.imgArrs=t.split(",",2),console.log("cur.imgArrs==",e.imgArrs)):e.imgArrs=!1}else e.imgArrs=!1,e.orderInfos.length&&e.orderInfos.forEach((function(e){e.differTime=n.default.getDifferTime(e.createTime,!1),e.nickName?e.nickName=e.nickName.slice(0,1)+"**":e.nickName="**"}));e.minMaxPrice.maxSellPrice==e.minMaxPrice.minSellPrice?e.maxSellPriceShow=n.default.centTurnSmacker(e.minMaxPrice.maxSellPrice/100):e.maxSellPriceShow=n.default.centTurnSmacker(e.minMaxPrice.minSellPrice/100)+"~"+n.default.centTurnSmacker(e.minMaxPrice.maxSellPrice/100),e.minMaxPrice.maxSellCommission==e.minMaxPrice.minSellCommission?e.maxSellCommissionShow=n.default.centTurnSmacker(e.minMaxPrice.maxSellCommission/100):e.maxSellCommissionShow=n.default.centTurnSmacker(e.minMaxPrice.minSellCommission/100)+"~"+n.default.centTurnSmacker(e.minMaxPrice.maxSellCommission/100),e.minSellPriceShow=n.default.centTurnSmacker(e.minMaxPrice.minSellPrice/100),2==e.freezeFlag?e.activityNameShow="&emsp;&emsp;&emsp;&emsp;&emsp;"+e.activityName:e.activityNameShow=e.activityName,e.activityStatusTex=["正在接龙","接龙待发布","正在跟团中......","接龙已下架","接龙已暂停","接龙已结束","接龙已删除"][e.activityStatus]}return e}));1==t.page?t.activityOwnLi=i:t.activityOwnLi=t.activityOwnLi.concat(i),console.log("活动获取数据==",t.activityOwnLi)}else e.showToast({title:s.message,icon:"none"})}))},subscribeUser:function(t){var s=this;this.$server.subscribeUser({targetUserId:this.userId,subscribeType:t}).then((function(n){0==n.code?(s.userInfos.subscribe=!s.userInfos.subscribe,1==t?(e.showToast({title:"订阅成功",icon:"success"}),s.showPop&&(s.showPop=!1),s.userInfoHome.focusWechat||e.navigateTo({url:"./weAccount"})):e.showToast({title:"退订成功"})):e.showToast({title:n.message,icon:"none"})}))}}};t.default=i}).call(this,s(1).default)},232:function(e,t,s){"use strict";s.r(t);var n=s(233),i=s.n(n);for(var o in n)"default"!==o&&function(e){s.d(t,e,(function(){return n[e]}))}(o);t.default=i.a},233:function(e,t,s){}},[[226,"common/runtime","common/vendor"]]]);
},{isPage:true,isComponent:true,currentFile:'pages/subPage/myHome.js'});require("pages/subPage/myHome.js");