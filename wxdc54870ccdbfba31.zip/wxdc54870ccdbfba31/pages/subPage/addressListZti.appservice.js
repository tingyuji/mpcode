$gwx_XC_26=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_26 || [];
function gz$gwx_XC_26_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_26_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_26_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_26_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'address_list data-v-456a4294'])
Z([3,'padding-bottom:22vh;'])
Z([[7],[3,'type']])
Z([3,'__e'])
Z([3,'dfc fl rig_els data-v-456a4294'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'goPage']],[[4],[[5],[1,4]]]]]]]]]]])
Z([3,'__l'])
Z([3,'data-v-456a4294'])
Z([3,'#07c160'])
Z([3,'setting'])
Z([3,'32'])
Z([3,'67dd0de0-1'])
Z([3,'index'])
Z([3,'item'])
Z([[7],[3,'listData']])
Z(z[12])
Z([3,'list_boxs fl_sb data-v-456a4294'])
Z([[2,'!'],[[7],[3,'type']]])
Z(z[3])
Z([3,'center_info data-v-456a4294'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'pickWl']],[[4],[[5],[[5],[1,'$0']],[[7],[3,'index']]]]],[[4],[[5],[[4],[[5],[[4],[[5],[[5],[[5],[1,'listData']],[1,'']],[[7],[3,'index']]]]]]]]]]]]]]]])
Z([[2,'=='],[[6],[[7],[3,'item']],[3,'defaultFlag']],[1,2]])
Z([[6],[[7],[3,'item']],[3,'spickupImg']])
Z([3,'user_inf fl_sb data-v-456a4294'])
Z([[6],[[6],[[7],[3,'item']],[3,'managerInfo']],[3,'nickName']])
Z(z[3])
Z([3,'fl data-v-456a4294'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'addressUser']],[[4],[[5],[[5],[1,'$0']],[[7],[3,'index']]]]],[[4],[[5],[[4],[[5],[[4],[[5],[[5],[[5],[1,'listData']],[1,'']],[[7],[3,'index']]]]]]]]]]]]]]]])
Z(z[6])
Z(z[7])
Z([3,'#888'])
Z([3,'arrow-right'])
Z([3,'26'])
Z([[2,'+'],[1,'67dd0de0-2-'],[[7],[3,'index']]])
Z([[2,'!'],[[6],[[6],[[7],[3,'item']],[3,'managerInfo']],[3,'nickName']]])
Z(z[17])
Z([[7],[3,'showShares']])
Z(z[6])
Z(z[3])
Z(z[3])
Z([3,'zuj_fix data-v-456a4294'])
Z([[4],[[5],[[5],[[4],[[5],[[5],[1,'^shareUrl']],[[4],[[5],[[4],[[5],[1,'shareUrl']]]]]]]],[[4],[[5],[[5],[1,'^closeShare']],[[4],[[5],[[4],[[5],[1,'closeShare']]]]]]]]])
Z([[7],[3,'shareObj']])
Z([3,'67dd0de0-3'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_26_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_26_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_26=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_26=true;
var x=['./pages/subPage/addressListZti.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_26_1()
var oDH=_mz(z,'view',['class',0,'style',1],[],e,s,gg)
var fEH=_v()
_(oDH,fEH)
if(_oz(z,2,e,s,gg)){fEH.wxVkey=1
}
var oHH=_mz(z,'view',['bindtap',3,'class',1,'data-event-opts',2],[],e,s,gg)
var cIH=_mz(z,'u-icon',['bind:__l',6,'class',1,'color',2,'name',3,'size',4,'vueId',5],[],e,s,gg)
_(oHH,cIH)
_(oDH,oHH)
var oJH=_v()
_(oDH,oJH)
var lKH=function(tMH,aLH,eNH,gg){
var oPH=_n('view')
_rz(z,oPH,'class',16,tMH,aLH,gg)
var xQH=_v()
_(oPH,xQH)
if(_oz(z,17,tMH,aLH,gg)){xQH.wxVkey=1
}
var oRH=_mz(z,'view',['bindtap',18,'class',1,'data-event-opts',2],[],tMH,aLH,gg)
var fSH=_v()
_(oRH,fSH)
if(_oz(z,21,tMH,aLH,gg)){fSH.wxVkey=1
}
var cTH=_v()
_(oRH,cTH)
if(_oz(z,22,tMH,aLH,gg)){cTH.wxVkey=1
}
var hUH=_n('view')
_rz(z,hUH,'class',23,tMH,aLH,gg)
var oVH=_v()
_(hUH,oVH)
if(_oz(z,24,tMH,aLH,gg)){oVH.wxVkey=1
var oXH=_mz(z,'view',['bindtap',25,'class',1,'data-event-opts',2],[],tMH,aLH,gg)
var lYH=_mz(z,'u-icon',['bind:__l',28,'class',1,'color',2,'name',3,'size',4,'vueId',5],[],tMH,aLH,gg)
_(oXH,lYH)
_(oVH,oXH)
}
var cWH=_v()
_(hUH,cWH)
if(_oz(z,34,tMH,aLH,gg)){cWH.wxVkey=1
}
oVH.wxXCkey=1
oVH.wxXCkey=3
cWH.wxXCkey=1
_(oRH,hUH)
fSH.wxXCkey=1
cTH.wxXCkey=1
_(oPH,oRH)
xQH.wxXCkey=1
_(eNH,oPH)
return eNH
}
oJH.wxXCkey=4
_2z(z,14,lKH,e,s,gg,oJH,'item','index','index')
var cFH=_v()
_(oDH,cFH)
if(_oz(z,35,e,s,gg)){cFH.wxVkey=1
}
var hGH=_v()
_(oDH,hGH)
if(_oz(z,36,e,s,gg)){hGH.wxVkey=1
var aZH=_mz(z,'dc-hiro-painter',['bind:__l',37,'bind:closeShare',1,'bind:shareUrl',2,'class',3,'data-event-opts',4,'shareObj',5,'vueId',6],[],e,s,gg)
_(hGH,aZH)
}
fEH.wxXCkey=1
cFH.wxXCkey=1
hGH.wxXCkey=1
hGH.wxXCkey=3
_(r,oDH)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_26";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_26();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/subPage/addressListZti.wxml'] = [$gwx_XC_26, './pages/subPage/addressListZti.wxml'];else __wxAppCode__['pages/subPage/addressListZti.wxml'] = $gwx_XC_26( './pages/subPage/addressListZti.wxml' );
	;__wxRoute = "pages/subPage/addressListZti";__wxRouteBegin = true;__wxAppCurrentFile__="pages/subPage/addressListZti.js";define("pages/subPage/addressListZti.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
(global.webpackJsonp=global.webpackJsonp||[]).push([["pages/subPage/addressListZti"],{160:function(e,t,n){"use strict";(function(e){n(5),i(n(4));var t=i(n(161));function i(e){return e&&e.__esModule?e:{default:e}}wx.__webpack_require_UNI_MP_PLUGIN__=n,e(t.default)}).call(this,n(1).createPage)},161:function(e,t,n){"use strict";n.r(t);var i=n(162),s=n(164);for(var o in s)"default"!==o&&function(e){n.d(t,e,(function(){return s[e]}))}(o);n(166);var a=n(17),r=Object(a.default)(s.default,i.render,i.staticRenderFns,!1,null,"456a4294",null,!1,i.components,void 0);r.options.__file="pages/subPage/addressListZti.vue",t.default=r.exports},162:function(e,t,n){"use strict";n.r(t);var i=n(163);n.d(t,"render",(function(){return i.render})),n.d(t,"staticRenderFns",(function(){return i.staticRenderFns})),n.d(t,"recyclableRender",(function(){return i.recyclableRender})),n.d(t,"components",(function(){return i.components}))},163:function(e,t,n){"use strict";var i;n.r(t),n.d(t,"render",(function(){return s})),n.d(t,"staticRenderFns",(function(){return a})),n.d(t,"recyclableRender",(function(){return o})),n.d(t,"components",(function(){return i}));try{i={uIcon:function(){return n.e("uview-ui/components/u-icon/u-icon").then(n.bind(null,854))},dcHiroPainter:function(){return n.e("components/dc-hiro-painter/dc-hiro-painter").then(n.bind(null,875))}}}catch(e){if(-1===e.message.indexOf("Cannot find module")||-1===e.message.indexOf(".vue"))throw e;console.error(e.message),console.error("1. 排查组件名称拼写是否正确"),console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"),console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件")}var s=function(){this.$createElement,this._self._c},o=!1,a=[];s._withStripped=!0},164:function(e,t,n){"use strict";n.r(t);var i=n(165),s=n.n(i);for(var o in i)"default"!==o&&function(e){n.d(t,e,(function(){return i[e]}))}(o);t.default=s.a},165:function(e,t,n){"use strict";(function(e){Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0,function(e){e&&e.__esModule}(n(61));var i={data:function(){return{showShopTabin:-1,showShopCaName:"",shareObj:{},showShares:!1,shareImgMini:"",shennum:0,nums:0,canApplyAmount:0,outCheckId:0,listData:[],pickAlls:!0,type:0,userInfos:{}}},onShow:function(e){console.log("show==show"),this.getAddressList()},onLoad:function(t){e.hideShareMenu({}),console.log("onload==",t),t&&(t.id&&(this.outCheckId=t.id,console.log(this.outCheckId)),t.type&&(this.type=t.type)),this.getCategoryList();var n=e.getStorageSync("userInfo")||{};this.userInfos=n},methods:{goPage:function(){e.navigateTo({url:"../pageRelay/speceCategoryZti"})},changeCateTab:function(e,t){if(this.showShopTabin==t)return!1;this.showShopTabin=t,-1!=t&&(this.showShopCaName=e.categoryName),this.getAddressList()},getCategoryList:function(){var t=this;this.$server.categoryList({businessType:4}).then((function(n){if(0==n.code){n.data.forEach((function(e){e.categoryName.length>5?e.categoryNameShow=e.categoryName.slice(0,5):e.categoryNameShow=e.categoryName}));var i={};i.arr=n.data,i.status=1,t.$u.vuex("vuex_category_ziti",i),t.list=t.vuex_category_ziti.arr}else e.showToast({title:n.message,icon:"none"})}))},shareUrl:function(e){this.shareImgMini=e},closeShare:function(e){console.log("关闭分享弹窗==",e),this.showShares=!1,this.shareObj={}},openShare:function(t,n){e.showLoading({title:"加载中",mask:!0}),this.shareObj.headImg=this.userInfos.headImg||"https://qiniuimg.kfmanager.com/qunjl/logo/qyxlogons.jpg",this.shareObj.nickName=this.userInfos.nickName||"群优选用户",2==n?(this.shareObj.shareScene="z="+t.id+"&u="+this.userInfos.userId,this.shareObj.zitiName=t.addressName||"自提点"):this.shareObj.shareScene="z=0&u="+this.userInfos.userId,this.shareObj.ztShare=n,this.showShares=!0,setTimeout((function(t){e.hideLoading()}),2e3)},pickWl:function(e,t){this.listData[t].isPick=!this.listData[t].isPick;var n=0;this.listData.forEach((function(e,t){e.isPick&&n++})),n==this.listData.length?!this.pickAlls&&(this.pickAlls=!0):this.pickAlls&&(this.pickAlls=!1)},pickAll:function(){var e=this;this.pickAlls=!this.pickAlls,this.listData.forEach((function(t,n){e.pickAlls?!t.isPick&&(t.isPick=!0):t.isPick&&(t.isPick=!1)}))},getAddressList:function(){var t=this,n={addressType:2,addressStatus:1};-1!=this.showShopTabin&&(n.category=this.showShopCaName),this.$server.addrList(n).then((function(n){0==n.code?(console.log("列表==",n.data),n.data.forEach((function(e,n){t.outCheckId.length?t.outCheckId.includes(e.id)?e.isPick=!0:e.isPick=!1:e.isPick=!0,e.managerInfo?(e.managerInfo.nickName>5&&(e.nickName=e.nickName.slice(0,5)),e.managerInfo.nickName||(e.managerInfo.nickName="群优选用户"),e.managerInfo.headImg||(e.managerInfo.headImg="https://qiniuimg.kfmanager.com/qunjl/logo/qyxlogons.jpg")):e.managerInfo={},!e.spickupImg&&(e.spickupImg="")})),t.listData=n.data):e.showToast({title:n.message,icon:"none"})}))},gobacks:function(t){encodeURIComponent(JSON.stringify(t));var n=getCurrentPages();n[n.length-2].$vm.otherFun(t),e.navigateBack()},addAddress:function(t,n){if(t){var i=encodeURIComponent(JSON.stringify(t));e.navigateTo({url:"./editAddressZti?item="+i})}else e.navigateTo({url:"./editAddressZti"})},addressUser:function(t,n){var i=encodeURIComponent(JSON.stringify(t));t.managerInfo.nickName?e.navigateTo({url:"../pageRelay/awardSellZtiInfo?item="+i}):e.navigateTo({url:"../pageRelay/snapList?item="+i})},importLibraryShop:function(){var t=[],n={allFlag:0};if(this.listData.forEach((function(e,n){e.isPick&&t.push(e.id)})),!t.length)return e.showToast({title:"请至少选择一个提货点",icon:"none"}),!1;this.pickAlls?n.allFlag=1:n.commodityIds=t.join(),console.log("queryData==",n);var i=getCurrentPages();i[i.length-2].$vm.otherFun(t),e.navigateBack()}}};t.default=i}).call(this,n(1).default)},166:function(e,t,n){"use strict";n.r(t);var i=n(167),s=n.n(i);for(var o in i)"default"!==o&&function(e){n.d(t,e,(function(){return i[e]}))}(o);t.default=s.a},167:function(e,t,n){}},[[160,"common/runtime","common/vendor"]]]);
},{isPage:true,isComponent:true,currentFile:'pages/subPage/addressListZti.js'});require("pages/subPage/addressListZti.js");