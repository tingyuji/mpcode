$gwx_XC_39=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_39 || [];
function gz$gwx_XC_39_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_39_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_39_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_39_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'data-v-51a874a3'])
Z([3,'width:100%;min-height:100vh;background-color:#f4f4f4;padding:30rpx 26rpx;padding-bottom:130rpx;box-sizing:border-box;'])
Z([[2,'=='],[[6],[[6],[[7],[3,'posInfo']],[1,0]],[3,'logisticsWay']],[1,1]])
Z([3,'__e'])
Z([3,'pick_ads fl_sb data-v-51a874a3'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'goPickAds']],[[4],[[5],[1,1]]]]]]]]]]])
Z([[6],[[6],[[7],[3,'orderAddrs']],[1,0]],[3,'columnValue']])
Z([3,'__l'])
Z(z[0])
Z([3,'#788'])
Z([3,'arrow-right'])
Z([3,'30'])
Z([3,'3932be7a-1'])
Z([3,'zi_tid data-v-51a874a3'])
Z(z[3])
Z(z[4])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'goPickAds']],[[4],[[5],[1,2]]]]]]]]]]])
Z([3,'addre_t fl_c data-v-51a874a3'])
Z([[6],[[7],[3,'ztiInfos']],[3,'id']])
Z(z[18])
Z(z[7])
Z(z[0])
Z(z[9])
Z(z[10])
Z(z[11])
Z([3,'3932be7a-2'])
Z([[7],[3,'showOutAddres']])
Z(z[3])
Z([3,'pick_ads pick_adszt fl_sb data-v-51a874a3'])
Z(z[5])
Z(z[7])
Z(z[0])
Z(z[9])
Z(z[10])
Z(z[11])
Z([3,'3932be7a-3'])
Z([[6],[[7],[3,'outorderAddrsZti']],[3,'length']])
Z([3,'idd'])
Z([3,'crr'])
Z([[7],[3,'outorderAddrsZti']])
Z(z[37])
Z([3,'pick_adszt data-v-51a874a3'])
Z([3,'padding:0 !important;'])
Z([[2,'=='],[[6],[[7],[3,'crr']],[3,'contentType']],[1,1]])
Z(z[7])
Z(z[3])
Z(z[0])
Z([[4],[[5],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'$0']],[1,'columnValue']],[1,'$event']],[[4],[[5]]]]]],[[4],[[5],[[4],[[5],[[4],[[5],[[5],[[5],[1,'outorderAddrsZti']],[1,'']],[[7],[3,'idd']]]]]]]]]]]]]]]])
Z([[8],'padding',[1,'0 30rpx']])
Z([[6],[[7],[3,'crr']],[3,'columnName']])
Z([3,'140'])
Z([[6],[[7],[3,'crr']],[3,'placeHolder']])
Z([3,'padding-left:0;padding-right:0;'])
Z([3,'text'])
Z([[6],[[7],[3,'crr']],[3,'columnValue']])
Z([[2,'+'],[1,'3932be7a-4-'],[[7],[3,'idd']]])
Z([3,'big_imgg data-v-51a874a3'])
Z([3,'k'])
Z([3,'j'])
Z([[6],[[7],[3,'crr']],[3,'yrjarr']])
Z(z[57])
Z(z[7])
Z(z[3])
Z(z[0])
Z([[7],[3,'iconStyles']])
Z([[4],[[5],[[4],[[5],[[5],[1,'^click']],[[4],[[5],[[4],[[5],[[5],[1,'delMiniImg']],[[4],[[5],[[5],[[7],[3,'idd']]],[[7],[3,'k']]]]]]]]]]]])
Z([3,'close-circle-fill'])
Z([3,'36'])
Z([[2,'+'],[[2,'+'],[[2,'+'],[1,'3932be7a-5-'],[[7],[3,'idd']]],[1,'-']],[[7],[3,'k']]])
Z([[2,'<'],[[6],[[6],[[7],[3,'crr']],[3,'yrjarr']],[3,'length']],[1,3]])
Z(z[3])
Z([3,'up_btnb fl_cb aa_bbc data-v-51a874a3'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'upBgimg']],[[4],[[5],[[5],[1,'$0']],[[7],[3,'idd']]]]],[[4],[[5],[[4],[[5],[[4],[[5],[[5],[[5],[1,'outorderAddrsZti']],[1,'']],[[7],[3,'idd']]]]]]]]]]]]]]]])
Z(z[7])
Z(z[0])
Z([3,'#ccc'])
Z([3,'camera'])
Z([3,'50'])
Z([[2,'+'],[1,'3932be7a-6-'],[[7],[3,'idd']]])
Z([3,'heard_box data-v-51a874a3'])
Z([3,'index'])
Z([3,'item'])
Z([[7],[3,'posInfo']])
Z(z[80])
Z(z[0])
Z([[2,'<'],[[6],[[7],[3,'item']],[3,'limitBuy']],[[6],[[7],[3,'item']],[3,'stock']]])
Z(z[7])
Z(z[3])
Z(z[3])
Z(z[0])
Z([[4],[[5],[[5],[[4],[[5],[[5],[1,'^change']],[[4],[[5],[[4],[[5],[1,'valChange']]]]]]]],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'$0']],[1,'eleShopNum']],[1,'$event']],[[4],[[5]]]]]],[[4],[[5],[[4],[[5],[[4],[[5],[[5],[[5],[1,'posInfo']],[1,'']],[[7],[3,'index']]]]]]]]]]]]]]]])
Z([[6],[[7],[3,'item']],[3,'limitBuy']])
Z([1,1])
Z([[6],[[7],[3,'item']],[3,'eleShopNum']])
Z([[2,'+'],[1,'3932be7a-7-'],[[7],[3,'index']]])
Z(z[7])
Z(z[3])
Z(z[3])
Z(z[0])
Z(z[90])
Z([[6],[[7],[3,'item']],[3,'stock']])
Z(z[92])
Z(z[93])
Z([[2,'+'],[1,'3932be7a-8-'],[[7],[3,'index']]])
Z([[2,'>'],[[2,'*'],[[7],[3,'preferPriceShow']],[1,1]],[1,0]])
Z([[7],[3,'templateMoney']])
Z(z[3])
Z([3,'btm_totals data-v-51a874a3'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'showTemInfo']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([3,'font-size:24rpx;'])
Z(z[7])
Z(z[0])
Z([3,'#999'])
Z([3,'question-circle'])
Z([3,'26'])
Z([3,'3932be7a-9'])
Z([3,'re_mark data-v-51a874a3'])
Z(z[7])
Z(z[3])
Z(z[0])
Z([[4],[[5],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'remark']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z([3,'right'])
Z([3,'订单备注'])
Z([3,'其他快递请备注'])
Z([[7],[3,'remark']])
Z([3,'3932be7a-10'])
Z([[7],[3,'promoCodeCount']])
Z(z[7])
Z(z[3])
Z(z[3])
Z(z[0])
Z([[4],[[5],[[5],[[4],[[5],[[5],[1,'^blur']],[[4],[[5],[[4],[[5],[1,'getCountPreferPrice']]]]]]]],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'promoCode']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z(z[121])
Z([3,'礼品卡'])
Z([3,'请输入专属优惠券码'])
Z([[7],[3,'promoCode']])
Z([3,'3932be7a-11'])
Z([[2,'>'],[[2,'*'],[[7],[3,'promoCodePriceShow']],[1,1]],[1,0]])
Z([3,'#07c160'])
Z(z[7])
Z(z[3])
Z(z[3])
Z(z[0])
Z([[4],[[5],[[5],[[4],[[5],[[5],[1,'^change']],[[4],[[5],[[4],[[5],[1,'checkboxChange']]]]]]]],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'xieyiCh']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z([[7],[3,'xieyiCh']])
Z([3,'3932be7a-12'])
Z([[2,'!'],[[7],[3,'firstSubmsg']]])
Z(z[7])
Z(z[3])
Z(z[3])
Z([3,'14'])
Z(z[0])
Z([1,true])
Z([[4],[[5],[[5],[[4],[[5],[[5],[1,'^close']],[[4],[[5],[[4],[[5],[1,'closeWech']]]]]]]],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'showWecont']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z([3,'center'])
Z([[7],[3,'showWecont']])
Z([3,'3932be7a-13'])
Z([[4],[[5],[1,'default']]])
Z([3,'580rpx'])
Z(z[7])
Z(z[3])
Z(z[3])
Z([[8],'fontWeight',[1,'500']])
Z(z[0])
Z(z[138])
Z(z[162])
Z([3,'去支付'])
Z([[4],[[5],[[5],[[4],[[5],[[5],[1,'^confirm']],[[4],[[5],[[4],[[5],[1,'surePay']]]]]]]],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'showGoPay']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z(z[152])
Z([3,'温馨提示'])
Z([[7],[3,'showGoPay']])
Z([3,'3932be7a-14'])
Z(z[157])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_39_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_39_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_39=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_39=true;
var x=['./pages/subPage/posApplyBuy.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_39_1()
var o2R=_mz(z,'view',['class',0,'style',1],[],e,s,gg)
var l3R=_v()
_(o2R,l3R)
if(_oz(z,2,e,s,gg)){l3R.wxVkey=1
var e6R=_mz(z,'view',['bindtap',3,'class',1,'data-event-opts',2],[],e,s,gg)
var b7R=_v()
_(e6R,b7R)
if(_oz(z,6,e,s,gg)){b7R.wxVkey=1
}
var o8R=_mz(z,'u-icon',['bind:__l',7,'class',1,'color',2,'name',3,'size',4,'vueId',5],[],e,s,gg)
_(e6R,o8R)
b7R.wxXCkey=1
_(l3R,e6R)
}
else{l3R.wxVkey=2
var x9R=_n('view')
_rz(z,x9R,'class',13,e,s,gg)
var fAS=_mz(z,'view',['bindtap',14,'class',1,'data-event-opts',2],[],e,s,gg)
var cBS=_n('view')
_rz(z,cBS,'class',17,e,s,gg)
var hCS=_v()
_(cBS,hCS)
if(_oz(z,18,e,s,gg)){hCS.wxVkey=1
}
var oDS=_v()
_(cBS,oDS)
if(_oz(z,19,e,s,gg)){oDS.wxVkey=1
}
hCS.wxXCkey=1
oDS.wxXCkey=1
_(fAS,cBS)
var cES=_mz(z,'u-icon',['bind:__l',20,'class',1,'color',2,'name',3,'size',4,'vueId',5],[],e,s,gg)
_(fAS,cES)
_(x9R,fAS)
var o0R=_v()
_(x9R,o0R)
if(_oz(z,26,e,s,gg)){o0R.wxVkey=1
var oFS=_mz(z,'view',['bindtap',27,'class',1,'data-event-opts',2],[],e,s,gg)
var lGS=_mz(z,'u-icon',['bind:__l',30,'class',1,'color',2,'name',3,'size',4,'vueId',5],[],e,s,gg)
_(oFS,lGS)
_(o0R,oFS)
}
o0R.wxXCkey=1
o0R.wxXCkey=3
_(l3R,x9R)
}
var a4R=_v()
_(o2R,a4R)
if(_oz(z,36,e,s,gg)){a4R.wxVkey=1
var aHS=_v()
_(a4R,aHS)
var tIS=function(bKS,eJS,oLS,gg){
var oNS=_mz(z,'view',['class',41,'style',1],[],bKS,eJS,gg)
var fOS=_v()
_(oNS,fOS)
if(_oz(z,43,bKS,eJS,gg)){fOS.wxVkey=1
var cPS=_mz(z,'u-field',['bind:__l',44,'bind:input',1,'class',2,'data-event-opts',3,'fieldStyle',4,'label',5,'labelWidth',6,'placeholder',7,'style',8,'type',9,'value',10,'vueId',11],[],bKS,eJS,gg)
_(fOS,cPS)
}
else{fOS.wxVkey=2
var hQS=_n('view')
_rz(z,hQS,'class',56,bKS,eJS,gg)
var cSS=_v()
_(hQS,cSS)
var oTS=function(aVS,lUS,tWS,gg){
var bYS=_mz(z,'u-icon',['bind:__l',61,'bind:click',1,'class',2,'customStyle',3,'data-event-opts',4,'name',5,'size',6,'vueId',7],[],aVS,lUS,gg)
_(tWS,bYS)
return tWS
}
cSS.wxXCkey=4
_2z(z,59,oTS,bKS,eJS,gg,cSS,'j','k','k')
var oRS=_v()
_(hQS,oRS)
if(_oz(z,69,bKS,eJS,gg)){oRS.wxVkey=1
var oZS=_mz(z,'view',['bindtap',70,'class',1,'data-event-opts',2],[],bKS,eJS,gg)
var x1S=_mz(z,'u-icon',['bind:__l',73,'class',1,'color',2,'name',3,'size',4,'vueId',5],[],bKS,eJS,gg)
_(oZS,x1S)
_(oRS,oZS)
}
oRS.wxXCkey=1
oRS.wxXCkey=3
_(fOS,hQS)
}
fOS.wxXCkey=1
fOS.wxXCkey=3
fOS.wxXCkey=3
_(oLS,oNS)
return oLS
}
aHS.wxXCkey=4
_2z(z,39,tIS,e,s,gg,aHS,'crr','idd','idd')
}
var o2S=_n('view')
_rz(z,o2S,'class',79,e,s,gg)
var h5S=_v()
_(o2S,h5S)
var o6S=function(o8S,c7S,l9S,gg){
var tAT=_n('view')
_rz(z,tAT,'class',84,o8S,c7S,gg)
var eBT=_v()
_(tAT,eBT)
if(_oz(z,85,o8S,c7S,gg)){eBT.wxVkey=1
var bCT=_mz(z,'u-number-box',['bind:__l',86,'bind:change',1,'bind:input',2,'class',3,'data-event-opts',4,'max',5,'min',6,'value',7,'vueId',8],[],o8S,c7S,gg)
_(eBT,bCT)
}
else{eBT.wxVkey=2
var oDT=_mz(z,'u-number-box',['bind:__l',95,'bind:change',1,'bind:input',2,'class',3,'data-event-opts',4,'max',5,'min',6,'value',7,'vueId',8],[],o8S,c7S,gg)
_(eBT,oDT)
}
eBT.wxXCkey=1
eBT.wxXCkey=3
eBT.wxXCkey=3
_(l9S,tAT)
return l9S
}
h5S.wxXCkey=4
_2z(z,82,o6S,e,s,gg,h5S,'item','index','index')
var f3S=_v()
_(o2S,f3S)
if(_oz(z,104,e,s,gg)){f3S.wxVkey=1
}
var c4S=_v()
_(o2S,c4S)
if(_oz(z,105,e,s,gg)){c4S.wxVkey=1
var xET=_mz(z,'view',['bindtap',106,'class',1,'data-event-opts',2,'style',3],[],e,s,gg)
var oFT=_mz(z,'u-icon',['bind:__l',110,'class',1,'color',2,'name',3,'size',4,'vueId',5],[],e,s,gg)
_(xET,oFT)
_(c4S,xET)
}
f3S.wxXCkey=1
c4S.wxXCkey=1
c4S.wxXCkey=3
_(o2R,o2S)
var fGT=_n('view')
_rz(z,fGT,'class',116,e,s,gg)
var oJT=_mz(z,'u-field',['bind:__l',117,'bind:input',1,'class',2,'data-event-opts',3,'inputAlign',4,'label',5,'placeholder',6,'value',7,'vueId',8],[],e,s,gg)
_(fGT,oJT)
var cHT=_v()
_(fGT,cHT)
if(_oz(z,126,e,s,gg)){cHT.wxVkey=1
var cKT=_mz(z,'u-field',['bind:__l',127,'bind:blur',1,'bind:input',2,'class',3,'data-event-opts',4,'inputAlign',5,'label',6,'placeholder',7,'value',8,'vueId',9],[],e,s,gg)
_(cHT,cKT)
}
var hIT=_v()
_(fGT,hIT)
if(_oz(z,137,e,s,gg)){hIT.wxVkey=1
}
cHT.wxXCkey=1
cHT.wxXCkey=3
hIT.wxXCkey=1
_(o2R,fGT)
var oLT=_mz(z,'u-checkbox',['activeColor',138,'bind:__l',1,'bind:change',2,'bind:input',3,'class',4,'data-event-opts',5,'value',6,'vueId',7],[],e,s,gg)
_(o2R,oLT)
var t5R=_v()
_(o2R,t5R)
if(_oz(z,146,e,s,gg)){t5R.wxVkey=1
}
var lMT=_mz(z,'u-popup',['bind:__l',147,'bind:close',1,'bind:input',2,'borderRadius',3,'class',4,'closeable',5,'data-event-opts',6,'mode',7,'value',8,'vueId',9,'vueSlots',10,'width',11],[],e,s,gg)
_(o2R,lMT)
var aNT=_mz(z,'u-modal',['bind:__l',159,'bind:confirm',1,'bind:input',2,'cancelStyle',3,'class',4,'confirmColor',5,'confirmStyle',6,'confirmText',7,'data-event-opts',8,'showCancelButton',9,'title',10,'value',11,'vueId',12,'vueSlots',13],[],e,s,gg)
_(o2R,aNT)
l3R.wxXCkey=1
l3R.wxXCkey=3
l3R.wxXCkey=3
a4R.wxXCkey=1
a4R.wxXCkey=3
t5R.wxXCkey=1
_(r,o2R)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_39";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_39();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/subPage/posApplyBuy.wxml'] = [$gwx_XC_39, './pages/subPage/posApplyBuy.wxml'];else __wxAppCode__['pages/subPage/posApplyBuy.wxml'] = $gwx_XC_39( './pages/subPage/posApplyBuy.wxml' );
	;__wxRoute = "pages/subPage/posApplyBuy";__wxRouteBegin = true;__wxAppCurrentFile__="pages/subPage/posApplyBuy.js";define("pages/subPage/posApplyBuy.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
(global.webpackJsonp=global.webpackJsonp||[]).push([["pages/subPage/posApplyBuy"],{144:function(e,o,t){"use strict";(function(e){t(5),r(t(4));var o=r(t(145));function r(e){return e&&e.__esModule?e:{default:e}}wx.__webpack_require_UNI_MP_PLUGIN__=t,e(o.default)}).call(this,t(1).createPage)},145:function(e,o,t){"use strict";t.r(o);var r=t(146),s=t(148);for(var n in s)"default"!==n&&function(e){t.d(o,e,(function(){return s[e]}))}(n);t(150);var i=t(17),a=Object(i.default)(s.default,r.render,r.staticRenderFns,!1,null,"51a874a3",null,!1,r.components,void 0);a.options.__file="pages/subPage/posApplyBuy.vue",o.default=a.exports},146:function(e,o,t){"use strict";t.r(o);var r=t(147);t.d(o,"render",(function(){return r.render})),t.d(o,"staticRenderFns",(function(){return r.staticRenderFns})),t.d(o,"recyclableRender",(function(){return r.recyclableRender})),t.d(o,"components",(function(){return r.components}))},147:function(e,o,t){"use strict";var r;t.r(o),t.d(o,"render",(function(){return s})),t.d(o,"staticRenderFns",(function(){return i})),t.d(o,"recyclableRender",(function(){return n})),t.d(o,"components",(function(){return r}));try{r={uIcon:function(){return t.e("uview-ui/components/u-icon/u-icon").then(t.bind(null,854))},uField:function(){return t.e("uview-ui/components/u-field/u-field").then(t.bind(null,946))},uNumberBox:function(){return t.e("uview-ui/components/u-number-box/u-number-box").then(t.bind(null,1003))},uCheckbox:function(){return t.e("uview-ui/components/u-checkbox/u-checkbox").then(t.bind(null,1010))},uPopup:function(){return t.e("uview-ui/components/u-popup/u-popup").then(t.bind(null,939))},uModal:function(){return t.e("uview-ui/components/u-modal/u-modal").then(t.bind(null,961))}}}catch(e){if(-1===e.message.indexOf("Cannot find module")||-1===e.message.indexOf(".vue"))throw e;console.error(e.message),console.error("1. 排查组件名称拼写是否正确"),console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"),console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件")}var s=function(){this.$createElement,this._self._c},n=!1,i=[];s._withStripped=!0},148:function(e,o,t){"use strict";t.r(o);var r=t(149),s=t.n(r);for(var n in r)"default"!==n&&function(e){t.d(o,e,(function(){return r[e]}))}(n);o.default=s.a},149:function(e,o,t){"use strict";(function(e){Object.defineProperty(o,"__esModule",{value:!0}),o.default=void 0;var r=function(e){return e&&e.__esModule?e:{default:e}}(t(61)),s={data:function(){return{checkCountyCode:"",showGoPay:!1,iconStyles:{position:"absolute",top:"-10rpx",right:"-10rpx"},xieyiCh:!0,firstSubmsg:!0,listPay:[{text:"微信支付",color:"#333",fontSize:28},{text:"支付宝支付",color:"#333",fontSize:28}],showPayc:!1,addressName:"",addressNums:"",address:"请选择收货地址",addressId:0,addressIdZti:0,titleName:"订单确认",userInfo:"",show:!1,radio:"1",posInfo:[],orderPriceShow:0,remark:"",pageType:"h5",ztiInfos:{id:""},sendApp:{orderId:0,machineName:""},orderAddrs:[{columnType:"1",columnName:"联系人",columnValue:""},{columnType:"1",columnName:"联系电话",columnValue:""},{columnType:"1",columnName:"联系地址",columnValue:""}],orderAddrsZti:[{columnType:"2",columnName:"联系人",columnValue:""},{columnType:"2",columnName:"联系电话",columnValue:""},{columnType:"2",columnName:"联系地址",columnValue:""}],outorderAddrsZti:[],showOutAddres:!1,addressZti:"请选择提货点进行接龙",preferPrice:0,preferPriceShow:"",promoCode:"",promoCodePrice:0,promoCodePriceShow:0,promoCodeCount:0,userInfoHome:{},showWecont:!1,templateInfo:null,tempStatus:0,templateMoney:0,templateText:"",storageAddId:"",qiniuInfo:{imgFolderPath:"",uploadToken:"",urlPrefix:"",videoFolderPath:""},freezeFlag:1,memberCount:0,solitaireCount:0,adminUserId:""}},computed:{orderPricePreSh:function(){return console.log("结算页computed==",this.posInfo),this.posInfo.reduce((function(e,o){return e+o.eleShopNum*o.sellPriceShow}),0)},orderPricePre:function(){return console.log("结算页computed==",this.posInfo),(1*this.orderPricePreSh).toFixed(2)}},onLoad:function(o){var t=this;e.hideShareMenu({}),console.log("firstSubmsg==ss",e.getStorageSync("firstSubmsg")),this.qiniuInfo=e.getStorageSync("qiniuInfo"),this.userInfoHome=e.getStorageSync("userInfo"),this.storageAddId=e.getStorageSync("addressId")||"";var r=JSON.parse(decodeURIComponent(o.item));this.posInfo=r.shopCarData,this.freezeFlag=r.freezeFlag,this.memberCount=r.memberCount,this.solitaireCount=r.solitaireCount,this.templateInfo=r.templateInfo,this.rewardList=r.rewardList||[],this.adminUserId=r.adminUserId,this.promoCodeCount=this.posInfo[0].promoCodeCount,console.log("结算页posInfo==",r),this.promoCode||this.rewardList.length?setTimeout((function(e){t.getCountPreferPrice(1)}),500):(this.getDefualtAddress(),setTimeout((function(e){t.orderPriceShow=t.orderPricePre}),100)),this.posInfo[0].logisticsRecordIds,this.queryLogistList()},methods:{temCarar:function(e,o){if(this.templateInfo&&"1"==this.posInfo[0].logisticsWay){var t=0,s=0,n=0;this.posInfo.forEach((function(e){t+=e.eleShopNum,s+=e.eleShopNum*e.checkPriceShow,n+=e.weight*e.eleShopNum})),this.posInfo[0].shopCarDataMos=r.default.centTurnSmacker(s),this.posInfo[0].weightTotal=n,this.posInfo[0].shopCarDataNum=t;var i=this.templateMoney;if(console.log("this.templateInfo==",e,this.templateInfo),this.templateInfo.noDeliveryArea.includes(this.checkCountyCode)){this.templateText="目前暂不支持配送到该地区",console.log("不配送"),this.tempStatus=1,this.templateMoney=0;var a=-1*r.default.centTurnSmacker(i/100)+1*this.orderPriceShow;console.log("不包邮==111",this.orderPriceShow,this.templateMoney,i),this.orderPriceShow=r.default.centTurnSmacker(a)}else if(this.templateInfo.unconditShippingArea.includes(this.checkCountyCode)){this.templateText="该地区可享受包邮服务",console.log("包邮"),this.tempStatus=2,this.templateMoney=0;var c=-1*r.default.centTurnSmacker(i/100)+1*this.orderPriceShow;console.log("不包邮==222",this.orderPriceShow,this.templateMoney,i),this.orderPriceShow=r.default.centTurnSmacker(c)}else{this.tempStatus=3,this.templateMoney=r.default.calculateTmp(this.templateInfo,this.posInfo[0].shopCarDataNum,this.posInfo[0].weightTotal,this.posInfo[0].shopCarDataMos);var u=r.default.centTurnSmacker(this.templateMoney/100);this.templateText="需支付运费"+u+"元","0.00"==u&&(this.templateText="您已享受包邮服务"),2!=o&&(i=0);var d=1*r.default.centTurnSmacker(this.templateMoney/100)+1*this.orderPriceShow-i/100;console.log("不包邮==333",this.orderPriceShow,this.templateMoney,i,o),this.orderPriceShow=r.default.centTurnSmacker(d)}}},valChange:function(e,o){if(this.templateInfo&&"1"==this.posInfo[0].logisticsWay){var t=0,s=0,n=0;this.posInfo.forEach((function(e){t+=e.eleShopNum,s+=e.eleShopNum*e.checkPriceShow,n+=e.weight*e.eleShopNum})),this.posInfo[0].shopCarDataMos=r.default.centTurnSmacker(s),this.posInfo[0].weightTotal=n,this.posInfo[0].shopCarDataNum=t}this.promoCode||this.rewardList.length?this.getCountPreferPrice():(this.orderPriceShow=this.orderPricePre,this.temCarar(this.checkCountyCode))},delMiniImg:function(e,o){console.log("delMiniImg",e,o),this.outorderAddrsZti[e].yrjarr.splice(o,1)},upBgimg:function(o,t){var r=this;e.chooseImage({count:3-o.yrjarr.length,sizeType:["compressed"],sourceType:["camera","album"],success:function(o){e.showLoading({title:"上传中"}),o.tempFilePaths.map((function(o,s){for(var n=o,i="."+n.split(".")[1],a="",c=0;c<18;c++)a+="abcdefghijkmnpqrstvwxyz1234567890".charAt(Math.floor(32*Math.random()));a=r.qiniuInfo.imgFolderPath+a+i,e.uploadFile({url:"https://up-z2.qiniup.com",filePath:n,name:"file",formData:{key:a,token:r.qiniuInfo.uploadToken},success:function(o){var s=r.qiniuInfo.urlPrefix+a;r.outorderAddrsZti[t].yrjarr.push(s),e.hideLoading()}})}))}})},showTemInfo:function(){var o="";1==this.templateInfo.chargeType?o="统一收取运费"+r.default.centTurnSmacker(this.templateInfo.flatMoney/100)+"元":2==this.templateInfo.chargeType?o=this.templateInfo.baseNumber+"件内商品收取"+r.default.centTurnSmacker(this.templateInfo.baseMoney/100)+"元运费，每多"+this.templateInfo.extraNumber+"件多收"+r.default.centTurnSmacker(this.templateInfo.extraMoney/100)+"元":3==this.templateInfo.chargeType&&(o=this.templateInfo.baseNumber+"kg内商品收取"+r.default.centTurnSmacker(this.templateInfo.baseMoney/100)+"元运费，每多"+this.templateInfo.extraNumber+"kg多收"+r.default.centTurnSmacker(this.templateInfo.extraMoney/100)+"元"),this.templateInfo.fullNumber&&(1==this.templateInfo.shippingType&&(o=o+";满"+r.default.centTurnSmacker(this.templateInfo.fullNumber/100)+"元包邮"),2==this.templateInfo.shippingType&&(o=o+";满"+this.templateInfo.fullNumber+"件包邮"),3==this.templateInfo.shippingType&&(o=o+";满"+this.templateInfo.fullNumber+"kg包邮")),e.showModal({title:"当前运费规则",content:o,showCancel:!1,confirmColor:"#07c160",cancelColor:"#999",confirmText:"我知道了",success:function(e){e.confirm&&console.log("用户点击确定")}})},opneXieyi:function(){console.log("打开文档111"),e.navigateTo({url:"../pageRelay/register"})},goPage:function(o){e.navigateTo({url:"./"+o})},paySuccess:function(){e.setStorageSync("addressId",this.addressId),this.userInfoHome.focusWechat?this.backRel():this.showWecont=!0},openSubMsg:function(){var o=this;wx.requestSubscribeMessage({tmplIds:["sqQAmfw9o6uEgtyPTC2nPLuWKcs8hGQ3idNHFYnDcmU","1M1HzN6j-VXsc3XvyN7IZ94ungD3y7EPXJzaEVQX18s","gVmPhKom0tnPbP3rN_sOgUBDY-jf7MlMYhvELjrB7oU"],success:function(e){},fail:function(e){},complete:function(t){o.firstSubmsg=!0,console.log("模板调用==",t),e.setStorageSync("firstSubmsg",o.firstSubmsg),o.backRel()}})},closeWech:function(){this.showWecont=!1,this.firstSubmsg=e.getStorageSync("firstSubmsg")||!1,console.log("firstSubmsg==",this.firstSubmsg);var o=this;this.firstSubmsg&&wx.requestSubscribeMessage({tmplIds:["sqQAmfw9o6uEgtyPTC2nPLuWKcs8hGQ3idNHFYnDcmU","1M1HzN6j-VXsc3XvyN7IZ94ungD3y7EPXJzaEVQX18s","gVmPhKom0tnPbP3rN_sOgUBDY-jf7MlMYhvELjrB7oU"],success:function(e){},fail:function(e){},complete:function(e){console.log("mesRes==clwe==",e),o.backRel()}})},backRel:function(){var o={commodityName:this.posInfo[0].commodityName,commodityCount:this.posInfo[0].eleShopNum};setTimeout((function(){var t=getCurrentPages();t[t.length-2].$vm.backFun(o),e.navigateBack()}),500)},goPickAds:function(o){1==o?this.addressId?e.navigateTo({url:"./addressList?id="+this.addressId}):e.navigateTo({url:"./addressList"}):e.navigateTo({url:"./addressListZtiord?id="+this.posInfo[0].activityId})},otherFun:function(e){e&&(this.address=e.provinces+" "+e.address,this.addressId=e.id,this.checkCountyCode=e.countyCode,this.orderAddrs[0].columnValue=e.userName,this.orderAddrs[1].columnValue=e.userMobile,this.orderAddrs[2].columnValue=e.provinces+"/"+e.address,this.posInfo[0].logisticsRecordIds&&(this.orderAddrsZti[0].columnValue=e.userName,this.orderAddrsZti[1].columnValue=e.userMobile,this.orderAddrsZti[2].columnValue=e.provinces+"/"+e.address),this.templateInfo&&"1"==this.posInfo[0].logisticsWay?this.temCarar(this.checkCountyCode,2):(this.tempStatus=0,this.templateText="",this.templateMoney=0),console.log("地址传值==",this.orderAddrs))},otherFunZti:function(e){e&&(this.ztiInfos=e,this.addressZti=e.address,console.log("地址传值==",this.ztiInfos))},diagoBox:function(){if(2==this.posInfo[0].logisticsWay){if(!this.ztiInfos.id)return e.showToast({title:"请先选择自提点",icon:"none"}),!1;if(this.showOutAddres&&!this.orderAddrsZti[0].columnValue)return e.showToast({title:"请选择地址信息",icon:"none"}),!1}else if(!this.orderAddrs[0].columnValue)return e.showToast({title:"请选择收货地址",icon:"none"}),!1;if(this.outorderAddrsZti.length){var o="";if(this.outorderAddrsZti.forEach((function(e,t){if(2==e.contentType&&(e.columnValue=e.yrjarr.join(",")),!e.columnValue&&!o)return o=e.placeHolder,!1})),o)return e.showToast({title:o,icon:"none"}),!1}if(1==this.tempStatus)return e.showToast({title:"当前地区不支持配送，请更换地址",icon:"none"}),!1;if(!this.xieyiCh)return e.showToast({title:"请先同意《群优选用户协议》",icon:"none"}),!1;var t=this;2==this.freezeFlag?e.showModal({content:"商家已开启售后无忧，您的付款资金将在您确认收货，商家才会收到款",showCancel:!0,confirmColor:"#07c160",cancelColor:"#999",confirmText:"去支付",success:function(e){e.confirm&&(console.log("用户点击确定"),t.surePay())}}):t.surePay()},surePay:function(o){var t=this;e.showLoading({title:"创建订单..."});var r=[];this.posInfo.forEach((function(e,o){var s={commodityId:e.commodityId,commodityName:e.commodityName,formatName:e.formatItemName,commodityCount:e.eleShopNum,imgUrl:e.showCommodityImg,commodityWeight:e.weight,commodityCode:e.commodityCode||""};2==t.posInfo[0].groupFlag?s.commodityPrice=e.groupPrice:s.commodityPrice=e.sellPrice,"暂无"==e.formatId?s.formatDetailId=null:s.formatDetailId=e.formatId,r.push(s)}));var s=1*(100*this.posInfo[0].shopCarDataMos-this.preferPrice-this.promoCodePrice+1*this.templateMoney);console.log("payPrice==",s),s=s.toFixed(0),100*this.posInfo[0].shopCarDataMos-this.preferPrice-this.promoCodePrice<0&&(s=0);var n={activityId:this.posInfo[0].activityId,orderPrice:(1*(100*this.orderPricePre+1*this.templateMoney)).toFixed(0),preferPrice:this.preferPrice+this.promoCodePrice,shipFeePrice:this.templateMoney,payPrice:(100*this.orderPriceShow).toFixed(0),appType:3,payType:4,orderType:this.posInfo[0].groupFlag,shareUserId:this.posInfo[0].shareUserId,userRemark:this.remark,orderCommoditys:r,orderAddrs:this.orderAddrs,promoCode:this.promoCode,sourceType:this.posInfo[0].sourceType};this.posInfo[0].logisticsRecordIds?(this.showOutAddres?n.orderAddrs=this.orderAddrsZti.concat(this.outorderAddrsZti):n.orderAddrs=this.outorderAddrsZti,n.logisticsRecordIds=this.ztiInfos.id):this.outorderAddrsZti.length&&(n.orderAddrs=this.orderAddrs.concat(this.outorderAddrsZti)),this.$server.createGbuyOrder(n).then((function(o){if(0==o.code){var r=t,s=o.data.orderId;if(e.hideLoading(),2==o.data.orderStatus)return wx.requestSubscribeMessage({tmplIds:["sqQAmfw9o6uEgtyPTC2nPLuWKcs8hGQ3idNHFYnDcmU","1M1HzN6j-VXsc3XvyN7IZ94ungD3y7EPXJzaEVQX18s","gVmPhKom0tnPbP3rN_sOgUBDY-jf7MlMYhvELjrB7oU"],success:function(e){},fail:function(e){},complete:function(e){r.queryStatus(s)}}),!1;e.requestPayment({provider:"weixin",orderInfo:s,timeStamp:o.data.payInfo.timeStamp,nonceStr:o.data.payInfo.nonceStr,package:o.data.payInfo.packageValue,signType:o.data.payInfo.signType,paySign:o.data.payInfo.paySign,success:function(e){console.log("success:"+JSON.stringify(e))},fail:function(o){console.log("fail:"+JSON.stringify(o)),e.showToast({title:"支付失败",icon:"none"})},complete:function(e){console.log("complete:"+e),console.log("数据==:"+o),r.queryStatus(s)}})}else e.showToast({title:o.message,icon:"none"})}))},queryStatus:function(o){var t=this,r={orderId:o};this.$server.queryOrderStatus(r).then((function(o){0==o.code&&2==o.data.orderStatus?(e.showToast({title:"支付成功",icon:"success"}),t.paySuccess()):e.showToast({title:"支付失败，请稍后重试",icon:"none"})}))},queryLastOrderAddr:function(){var e=this,o={actUserId:this.adminUserId};this.$server.queryLastOrderAddr(o).then((function(o){0==o.code&&(console.log("this.outorderAddrsZti===",e.outorderAddrsZti),e.ztiInfos.id=o.data.id,e.ztiInfos.addressName=o.data.addressName,e.ztiInfos.address=o.data.address,e.ztiInfos.userName=o.data.userName,e.addressZti=o.data.address,e.outorderAddrsZti.forEach((function(e){o.data.kvList.forEach((function(o){e.columnName==o.name&&1==e.contentType&&(e.columnValue=o.value),e.columnName==o.name&&2==e.contentType&&(e.yrjarr=o.value.split(","))}))})))}))},getDefualtAddress:function(){var e=this,o={addressType:1,id:this.storageAddId};this.$server.getAddrById(o).then((function(o){if(0==o.code&&o.data){var t=o.data;if(e.address=t.provinces+" "+t.address,e.checkCountyCode=t.countyCode,e.addressId=t.id,e.orderAddrs[0].columnValue=t.userName,e.orderAddrs[1].columnValue=t.userMobile,e.orderAddrs[2].columnValue=t.provinces+"/"+t.address,e.posInfo[0].logisticsRecordIds&&(e.orderAddrsZti[0].columnValue=t.userName,e.orderAddrsZti[1].columnValue=t.userMobile,e.orderAddrsZti[2].columnValue=t.provinces+"/"+t.address),!t.countyCode)return e.templateText="目前暂不支持配送到该地区",console.log("不配送"),e.tempStatus=1,!1;if(e.templateInfo&&"1"==e.posInfo[0].logisticsWay)if(console.log("this.templateInfo",e.templateInfo),e.templateInfo.noDeliveryArea.includes(t.countyCode))e.templateText="目前暂不支持配送到该地区",console.log("不配送"),e.tempStatus=1;else if(e.templateInfo.unconditShippingArea.includes(t.countyCode))e.templateText="该地区可享受包邮服务",console.log("包邮"),e.tempStatus=2;else{e.tempStatus=3,e.templateMoney=r.default.calculateTmp(e.templateInfo,e.posInfo[0].shopCarDataNum,e.posInfo[0].weightTotal,e.posInfo[0].shopCarDataMos);var s=r.default.centTurnSmacker(e.templateMoney/100);e.templateText="需支付运费"+s+"元","0.00"==s&&(e.templateText="您已享受包邮服务"),setTimeout((function(o){var t=1*e.orderPriceShow+1*s;console.log("不包邮==",t),e.orderPriceShow=r.default.centTurnSmacker(t)}),500)}}console.log(o)}))},queryLogistList:function(){var e=this,o={activityId:this.posInfo[0].activityId,logisticsType:this.posInfo[0].logisticsWay};this.$server.queryLogistList(o).then((function(o){if(0==o.code){console.log("res.data=",o.data);var t=[],r=["请输入","请输入","请添加"];o.data.length>2&&2==e.posInfo[0].logisticsWay?"联系人姓名"==o.data[0].logisticsColumns&&"联系电话"==o.data[1].logisticsColumns&&"联系地址"==o.data[2].logisticsColumns?(o.data.forEach((function(e,o){o>2&&t.push({columnType:"2",columnName:e.logisticsColumns,columnValue:"",placeHolder:r[e.contentType]+e.logisticsColumns,contentType:e.contentType,publicFlag:e.publicFlag,yrjarr:[]})})),e.showOutAddres=!0,e.getDefualtAddress()):o.data.forEach((function(e,o){t.push({columnType:"2",columnName:e.logisticsColumns,columnValue:"",placeHolder:r[e.contentType]+e.logisticsColumns,contentType:e.contentType,publicFlag:e.publicFlag,yrjarr:[]})})):1==e.posInfo[0].logisticsWay?o.data.forEach((function(e,o){o>2&&t.push({columnType:"1",columnName:e.logisticsColumns,columnValue:"",placeHolder:r[e.contentType]+e.logisticsColumns,contentType:e.contentType,publicFlag:e.publicFlag,yrjarr:[]})})):o.data.forEach((function(e,o){t.push({columnType:"2",columnName:e.logisticsColumns,columnValue:"",placeHolder:r[e.contentType]+e.logisticsColumns,contentType:e.contentType,publicFlag:e.publicFlag,yrjarr:[]})})),e.outorderAddrsZti=t,console.log("this.outorderAddrsZti===",e.outorderAddrsZti),e.queryLastOrderAddr()}console.log(o)}))},getCountPreferPrice:function(o){var t=this,s={activityId:this.posInfo[0].activityId,totalOrderPrice:parseInt(100*this.orderPricePre)};this.promoCode&&(s.promoCode=this.promoCode),this.$server.countPreferPrice(s).then((function(s){0==s.code?(t.preferPrice=s.data.preferPrice,t.preferPriceShow=r.default.centTurnSmacker(s.data.preferPrice/100),s.data.promoCodePrice>0?(t.promoCodePrice=s.data.promoCodePrice,t.promoCodePriceShow=r.default.centTurnSmacker(s.data.promoCodePrice/100),t.orderPriceShow=r.default.centTurnSmacker(t.orderPricePre-t.preferPrice/100-s.data.promoCodePrice/100)):t.orderPriceShow=r.default.centTurnSmacker(t.orderPricePre-t.preferPrice/100),1==t.posInfo[0].logisticsWay&&o&&t.getDefualtAddress(),t.templateInfo&&"1"==t.posInfo[0].logisticsWay&&t.temCarar(t.checkCountyCode)):e.showToast({title:s.message,icon:"none"}),console.log(s)}))}}};o.default=s}).call(this,t(1).default)},150:function(e,o,t){"use strict";t.r(o);var r=t(151),s=t.n(r);for(var n in r)"default"!==n&&function(e){t.d(o,e,(function(){return r[e]}))}(n);o.default=s.a},151:function(e,o,t){}},[[144,"common/runtime","common/vendor"]]]);
},{isPage:true,isComponent:true,currentFile:'pages/subPage/posApplyBuy.js'});require("pages/subPage/posApplyBuy.js");