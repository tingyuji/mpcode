$gwx_XC_33=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_33 || [];
function gz$gwx_XC_33_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_33_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_33_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_33_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'data-v-3478ecf4'])
Z([3,'width:100%;'])
Z([3,'__e'])
Z([3,'record-li fl_sb data-v-3478ecf4'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'goUnList']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([3,'__l'])
Z(z[0])
Z([3,'#999'])
Z([3,'arrow-right'])
Z([3,'36'])
Z([3,'5aa53292-1'])
Z(z[2])
Z(z[3])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'goCustomer']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([3,'fbbs_top fl data-v-3478ecf4'])
Z([[7],[3,'unReadCount']])
Z(z[5])
Z(z[0])
Z(z[7])
Z(z[8])
Z(z[9])
Z([3,'5aa53292-2'])
Z(z[2])
Z(z[3])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'goFans']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z(z[5])
Z(z[0])
Z(z[7])
Z(z[8])
Z(z[9])
Z([3,'5aa53292-3'])
Z(z[2])
Z(z[3])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'goAnalysis']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z(z[5])
Z(z[0])
Z(z[7])
Z(z[8])
Z(z[9])
Z([3,'5aa53292-4'])
Z([3,'record-list data-v-3478ecf4'])
Z([3,'index'])
Z([3,'item'])
Z([[7],[3,'list']])
Z(z[41])
Z(z[2])
Z([3,'fbbs data-v-3478ecf4'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'imcImC']],[[4],[[5],[[5],[1,'$0']],[1,1]]]],[[4],[[5],[[4],[[5],[[4],[[5],[[5],[[5],[[5],[1,'list']],[1,'']],[[7],[3,'index']]],[1,'userId']]]]]]]]]]]]]]])
Z([[6],[[7],[3,'item']],[3,'unReadMsgCount']])
Z(z[5])
Z(z[0])
Z([[7],[3,'loadText']])
Z([1,50])
Z([[7],[3,'loadStatus']])
Z([3,'5aa53292-5'])
Z(z[5])
Z(z[2])
Z(z[2])
Z(z[0])
Z([[4],[[5],[[5],[[4],[[5],[[5],[1,'^click']],[[4],[[5],[[4],[[5],[1,'outGroup']]]]]]]],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'showAct']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z([[7],[3,'actionList']])
Z([[7],[3,'showAct']])
Z([3,'5aa53292-6'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_33_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_33_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_33=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_33=true;
var x=['./pages/subPage/groupList.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_33_1()
var oZK=_mz(z,'view',['class',0,'style',1],[],e,s,gg)
var c1K=_mz(z,'view',['bindtap',2,'class',1,'data-event-opts',2],[],e,s,gg)
var o2K=_mz(z,'u-icon',['bind:__l',5,'class',1,'color',2,'name',3,'size',4,'vueId',5],[],e,s,gg)
_(c1K,o2K)
_(oZK,c1K)
var l3K=_mz(z,'view',['bindtap',11,'class',1,'data-event-opts',2],[],e,s,gg)
var a4K=_n('view')
_rz(z,a4K,'class',14,e,s,gg)
var t5K=_v()
_(a4K,t5K)
if(_oz(z,15,e,s,gg)){t5K.wxVkey=1
}
var e6K=_mz(z,'u-icon',['bind:__l',16,'class',1,'color',2,'name',3,'size',4,'vueId',5],[],e,s,gg)
_(a4K,e6K)
t5K.wxXCkey=1
_(l3K,a4K)
_(oZK,l3K)
var b7K=_mz(z,'view',['bindtap',22,'class',1,'data-event-opts',2],[],e,s,gg)
var o8K=_mz(z,'u-icon',['bind:__l',25,'class',1,'color',2,'name',3,'size',4,'vueId',5],[],e,s,gg)
_(b7K,o8K)
_(oZK,b7K)
var x9K=_mz(z,'view',['bindtap',31,'class',1,'data-event-opts',2],[],e,s,gg)
var o0K=_mz(z,'u-icon',['bind:__l',34,'class',1,'color',2,'name',3,'size',4,'vueId',5],[],e,s,gg)
_(x9K,o0K)
_(oZK,x9K)
var fAL=_n('view')
_rz(z,fAL,'class',40,e,s,gg)
var cBL=_v()
_(fAL,cBL)
var hCL=function(cEL,oDL,oFL,gg){
var aHL=_mz(z,'view',['bindtap',45,'class',1,'data-event-opts',2],[],cEL,oDL,gg)
var tIL=_v()
_(aHL,tIL)
if(_oz(z,48,cEL,oDL,gg)){tIL.wxVkey=1
}
tIL.wxXCkey=1
_(oFL,aHL)
return oFL
}
cBL.wxXCkey=2
_2z(z,43,hCL,e,s,gg,cBL,'item','index','index')
var eJL=_mz(z,'u-loadmore',['bind:__l',49,'class',1,'loadText',2,'marginTop',3,'status',4,'vueId',5],[],e,s,gg)
_(fAL,eJL)
_(oZK,fAL)
var bKL=_mz(z,'u-action-sheet',['bind:__l',55,'bind:click',1,'bind:input',2,'class',3,'data-event-opts',4,'list',5,'value',6,'vueId',7],[],e,s,gg)
_(oZK,bKL)
_(r,oZK)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_33";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_33();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/subPage/groupList.wxml'] = [$gwx_XC_33, './pages/subPage/groupList.wxml'];else __wxAppCode__['pages/subPage/groupList.wxml'] = $gwx_XC_33( './pages/subPage/groupList.wxml' );
	;__wxRoute = "pages/subPage/groupList";__wxRouteBegin = true;__wxAppCurrentFile__="pages/subPage/groupList.js";define("pages/subPage/groupList.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
(global.webpackJsonp=global.webpackJsonp||[]).push([["pages/subPage/groupList"],{210:function(e,n,t){"use strict";(function(e){t(5),o(t(4));var n=o(t(211));function o(e){return e&&e.__esModule?e:{default:e}}wx.__webpack_require_UNI_MP_PLUGIN__=t,e(n.default)}).call(this,t(1).createPage)},211:function(e,n,t){"use strict";t.r(n);var o=t(212),i=t(214);for(var u in i)"default"!==u&&function(e){t.d(n,e,(function(){return i[e]}))}(u);t(216);var s=t(17),a=Object(s.default)(i.default,o.render,o.staticRenderFns,!1,null,"3478ecf4",null,!1,o.components,void 0);a.options.__file="pages/subPage/groupList.vue",n.default=a.exports},212:function(e,n,t){"use strict";t.r(n);var o=t(213);t.d(n,"render",(function(){return o.render})),t.d(n,"staticRenderFns",(function(){return o.staticRenderFns})),t.d(n,"recyclableRender",(function(){return o.recyclableRender})),t.d(n,"components",(function(){return o.components}))},213:function(e,n,t){"use strict";var o;t.r(n),t.d(n,"render",(function(){return i})),t.d(n,"staticRenderFns",(function(){return s})),t.d(n,"recyclableRender",(function(){return u})),t.d(n,"components",(function(){return o}));try{o={uIcon:function(){return t.e("uview-ui/components/u-icon/u-icon").then(t.bind(null,854))},uLoadmore:function(){return t.e("uview-ui/components/u-loadmore/u-loadmore").then(t.bind(null,861))},uActionSheet:function(){return t.e("uview-ui/components/u-action-sheet/u-action-sheet").then(t.bind(null,896))}}}catch(e){if(-1===e.message.indexOf("Cannot find module")||-1===e.message.indexOf(".vue"))throw e;console.error(e.message),console.error("1. 排查组件名称拼写是否正确"),console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"),console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件")}var i=function(){this.$createElement,this._self._c},u=!1,s=[];i._withStripped=!0},214:function(e,n,t){"use strict";t.r(n);var o=t(215),i=t.n(o);for(var u in o)"default"!==u&&function(e){t.d(n,e,(function(){return o[e]}))}(u);n.default=i.a},215:function(e,n,t){"use strict";(function(e){Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0,function(e){e&&e.__esModule}(t(61));var o={data:function(){return{unReadCount:0,actionList:[{text:"退出社群"}],showAct:!1,ctrlUserId:"",titleName:"我的成员",list:[],loading:!1,finished:!1,noData:!1,loadText:{loadmore:"上拉加载更多",loading:"努力加载中...",nomore:"暂无更多社群"},loadStatus:"loading",page:1,pageSize:12,pageStatu:0}},onLoad:function(n){var t=this;console.log("onLoad"),e.hideShareMenu({});var o=this,i=e.getStorageSync("userInfo")||{};if(n.type){if(2==i.userType)return this.opearatReLogin(),setTimeout((function(e){console.log("员工登录免再登录groupList",i.userType),t.comunityList()}),800),!1;wx.login({success:function(n){n.code&&o.$server.login({agentId:o.$agentId,code:n.code}).then((function(n){var t=n;e.setStorageSync("userInfo",t),o.comunityList()}))}})}else o.comunityList()},onShow:function(){console.log("woOnShow")},onReachBottom:function(){console.log("上拉加载"),this.finished||(this.loadStatus="loading",this.page++,this.comunityList())},methods:{goUnList:function(){e.navigateTo({url:"../pageRelay/helpSells"})},goCustomer:function(){this.unReadCount=0,e.navigateTo({url:"../pageRelay/myCustomer"})},goFans:function(){e.navigateTo({url:"../pageRelay/myFans"})},goAnalysis:function(){e.navigateTo({url:"../pageRelay/analysis"})},comunityList:function(){var e=this,n={page:this.page,pageSize:this.pageSize};this.$server.comunityList(n).then((function(n){if(null!=n&&0==n.code){var t=n.data.communityList.map((function(t){return t.headImg&&t.headImg.includes("http")||(t.headImg="http://qiniuimg.kfmanager.com/qunjl/showrel/miniqyxs.png"),1==e.page&&(n.data.unReadCount<100?e.unReadCount=n.data.unReadCount:e.unReadCount="99+"),!t.nickName&&(t.nickName="群优选用户"),t}));e.list=e.list.concat(t),setTimeout((function(t){n.data.communityList.length<e.pageSize?(e.finished=!0,e.loadStatus="nomore"):e.loadStatus="loadmore"}),500)}}))},subscribeUser:function(n,t){var o=this;this.$server.subscribeUser({targetUserId:this.list[n].userId,subscribeType:t}).then((function(i){0==i.code?1==t?o.list[n].subscribeFlag=!0:(e.showToast({title:"退订成功"}),o.list[n].subscribeFlag=!1):e.showToast({title:i.message,icon:"none"})}))},tuiDing:function(n){var t=this;e.showModal({title:"提示",content:"退订主页，你将不能收到我的活动发布通知哦",confirmText:"退订",confirmColor:"#ff4d4d",success:function(e){e.cancel?console.log("用户点击取消"):e.confirm&&t.subscribeUser(n,2)}})},goMyhome:function(n){e.navigateTo({url:"./myHome?uid="+n})},outGroup:function(){var n=this;this.$server.quitCommunity({userId:this.ctrlUserId}).then((function(t){0==t.code?(n.list=[],n.page=1,n.finished=!1,n.comunityList()):e.showToast({title:t.message,icon:"none"})}))},opneMenu:function(e){this.ctrlUserId=e,this.showAct=!0}}};n.default=o}).call(this,t(1).default)},216:function(e,n,t){"use strict";t.r(n);var o=t(217),i=t.n(o);for(var u in o)"default"!==u&&function(e){t.d(n,e,(function(){return o[e]}))}(u);n.default=i.a},217:function(e,n,t){}},[[210,"common/runtime","common/vendor"]]]);
},{isPage:true,isComponent:true,currentFile:'pages/subPage/groupList.js'});require("pages/subPage/groupList.js");