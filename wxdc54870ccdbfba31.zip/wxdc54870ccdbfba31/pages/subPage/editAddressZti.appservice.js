$gwx_XC_30=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_30 || [];
function gz$gwx_XC_30_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_30_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_30_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_30_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'data-v-88708844'])
Z([3,'addInfo-box data-v-88708844'])
Z([3,'top_input data-v-88708844'])
Z([3,'__l'])
Z([3,'__e'])
Z([3,'addInput-li data-v-88708844'])
Z([[4],[[5],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'$0']],[1,'addressName']],[1,'$event']],[[4],[[5]]]]]],[[4],[[5],[1,'addressInfo']]]]]]]]]]])
Z([3,'自提点名称'])
Z([3,'188'])
Z([3,'20'])
Z([3,'自提点的简称,如广州花园小区'])
Z([[6],[[7],[3,'addressInfo']],[3,'addressName']])
Z([3,'859f7e30-1'])
Z(z[3])
Z(z[4])
Z(z[4])
Z(z[0])
Z([[4],[[5],[[5],[[4],[[5],[[5],[1,'^click']],[[4],[[5],[[4],[[5],[1,'chooseLoac']]]]]]]],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'$0']],[1,'showName']],[1,'$event']],[[4],[[5]]]]]],[[4],[[5],[1,'addressInfo']]]]]]]]]]])
Z([1,true])
Z([3,'位置'])
Z(z[8])
Z([3,'请选择所在位置'])
Z([[6],[[7],[3,'addressInfo']],[3,'showName']])
Z([3,'859f7e30-2'])
Z([[4],[[5],[1,'right']]])
Z(z[3])
Z(z[4])
Z(z[0])
Z([3,'#397caf'])
Z([[4],[[5],[[4],[[5],[[5],[1,'^click']],[[4],[[5],[[4],[[5],[1,'chooseLoac']]]]]]]]])
Z([3,'map-fill'])
Z([3,'32'])
Z([3,'right'])
Z([[2,'+'],[[2,'+'],[1,'859f7e30-3'],[1,',']],[1,'859f7e30-2']])
Z(z[3])
Z(z[4])
Z(z[5])
Z([[4],[[5],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'$0']],[1,'address']],[1,'$event']],[[4],[[5]]]]]],[[4],[[5],[1,'addressInfo']]]]]]]]]]])
Z([3,'详细地址'])
Z(z[8])
Z([3,'请输入详细地址'])
Z([[6],[[7],[3,'addressInfo']],[3,'address']])
Z([3,'859f7e30-4'])
Z(z[2])
Z([3,'margin-top:20rpx;'])
Z(z[3])
Z(z[4])
Z(z[5])
Z([[4],[[5],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'$0']],[1,'userName']],[1,'$event']],[[4],[[5]]]]]],[[4],[[5],[1,'addressInfo']]]]]]]]]]])
Z([3,'姓名'])
Z(z[8])
Z(z[9])
Z([3,'请输入自提点联系人'])
Z([[6],[[7],[3,'addressInfo']],[3,'userName']])
Z([3,'859f7e30-5'])
Z(z[3])
Z(z[4])
Z(z[5])
Z([[4],[[5],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'$0']],[1,'userMobile']],[1,'$event']],[[4],[[5]]]]]],[[4],[[5],[1,'addressInfo']]]]]]]]]]])
Z([3,'电话'])
Z(z[8])
Z([3,'11'])
Z([3,'请输入自提点电话'])
Z([3,'number'])
Z([[6],[[7],[3,'addressInfo']],[3,'userMobile']])
Z([3,'859f7e30-6'])
Z([3,'big_imgg data-v-88708844'])
Z([[6],[[7],[3,'addressInfo']],[3,'spickupImg']])
Z(z[3])
Z(z[4])
Z(z[0])
Z([[7],[3,'iconStyles']])
Z([[4],[[5],[[4],[[5],[[5],[1,'^click']],[[4],[[5],[[4],[[5],[1,'delMiniImg']]]]]]]]])
Z([3,'close-circle-fill'])
Z([3,'36'])
Z([3,'859f7e30-7'])
Z([[2,'!'],[[6],[[7],[3,'addressInfo']],[3,'spickupImg']]])
Z(z[4])
Z([3,'up_btnb fl_cb aa_bbc data-v-88708844'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[1,'upBgimg']]]]]]]]])
Z(z[3])
Z(z[0])
Z([3,'#ccc'])
Z([3,'camera'])
Z([3,'50'])
Z([3,'859f7e30-8'])
Z([[6],[[7],[3,'addressInfo']],[3,'id']])
Z(z[3])
Z(z[4])
Z(z[4])
Z(z[4])
Z([3,'#07c160'])
Z([3,'去添加'])
Z(z[0])
Z(z[91])
Z([[4],[[5],[[5],[[5],[[4],[[5],[[5],[1,'^confirm']],[[4],[[5],[[4],[[5],[1,'confirmCat']]]]]]]],[[4],[[5],[[5],[1,'^cancel']],[[4],[[5],[[4],[[5],[1,'goCateg']]]]]]]],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'showCate']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z([[7],[3,'categoryArr']])
Z([[7],[3,'showCate']])
Z([3,'859f7e30-9'])
Z(z[3])
Z(z[4])
Z(z[4])
Z(z[0])
Z([[4],[[5],[[5],[[4],[[5],[[5],[1,'^confirm']],[[4],[[5],[[4],[[5],[1,'confirms']]]]]]]],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'chooseCityBox']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z([3,'region'])
Z([[7],[3,'chooseCityBox']])
Z([3,'859f7e30-10'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_30_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_30_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_30=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_30=true;
var x=['./pages/subPage/editAddressZti.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_30_1()
var tKJ=_n('view')
_rz(z,tKJ,'class',0,e,s,gg)
var eLJ=_n('view')
_rz(z,eLJ,'class',1,e,s,gg)
var oNJ=_n('view')
_rz(z,oNJ,'class',2,e,s,gg)
var xOJ=_mz(z,'u-field',['bind:__l',3,'bind:input',1,'class',2,'data-event-opts',3,'label',4,'labelWidth',5,'maxlength',6,'placeholder',7,'value',8,'vueId',9],[],e,s,gg)
_(oNJ,xOJ)
var oPJ=_mz(z,'u-field',['bind:__l',13,'bind:click',1,'bind:input',2,'class',3,'data-event-opts',4,'disabled',5,'label',6,'labelWidth',7,'placeholder',8,'value',9,'vueId',10,'vueSlots',11],[],e,s,gg)
var fQJ=_mz(z,'u-icon',['bind:__l',25,'bind:click',1,'class',2,'color',3,'data-event-opts',4,'name',5,'size',6,'slot',7,'vueId',8],[],e,s,gg)
_(oPJ,fQJ)
_(oNJ,oPJ)
var cRJ=_mz(z,'u-field',['bind:__l',34,'bind:input',1,'class',2,'data-event-opts',3,'label',4,'labelWidth',5,'placeholder',6,'value',7,'vueId',8],[],e,s,gg)
_(oNJ,cRJ)
_(eLJ,oNJ)
var hSJ=_mz(z,'view',['class',43,'style',1],[],e,s,gg)
var oTJ=_mz(z,'u-field',['bind:__l',45,'bind:input',1,'class',2,'data-event-opts',3,'label',4,'labelWidth',5,'maxlength',6,'placeholder',7,'value',8,'vueId',9],[],e,s,gg)
_(hSJ,oTJ)
var cUJ=_mz(z,'u-field',['bind:__l',55,'bind:input',1,'class',2,'data-event-opts',3,'label',4,'labelWidth',5,'maxlength',6,'placeholder',7,'type',8,'value',9,'vueId',10],[],e,s,gg)
_(hSJ,cUJ)
var oVJ=_n('view')
_rz(z,oVJ,'class',66,e,s,gg)
var lWJ=_v()
_(oVJ,lWJ)
if(_oz(z,67,e,s,gg)){lWJ.wxVkey=1
var tYJ=_mz(z,'u-icon',['bind:__l',68,'bind:click',1,'class',2,'customStyle',3,'data-event-opts',4,'name',5,'size',6,'vueId',7],[],e,s,gg)
_(lWJ,tYJ)
}
var aXJ=_v()
_(oVJ,aXJ)
if(_oz(z,76,e,s,gg)){aXJ.wxVkey=1
var eZJ=_mz(z,'view',['bindtap',77,'class',1,'data-event-opts',2],[],e,s,gg)
var b1J=_mz(z,'u-icon',['bind:__l',80,'class',1,'color',2,'name',3,'size',4,'vueId',5],[],e,s,gg)
_(eZJ,b1J)
_(aXJ,eZJ)
}
lWJ.wxXCkey=1
lWJ.wxXCkey=3
aXJ.wxXCkey=1
aXJ.wxXCkey=3
_(hSJ,oVJ)
_(eLJ,hSJ)
var bMJ=_v()
_(eLJ,bMJ)
if(_oz(z,86,e,s,gg)){bMJ.wxVkey=1
}
bMJ.wxXCkey=1
_(tKJ,eLJ)
var o2J=_mz(z,'u-select',['bind:__l',87,'bind:cancel',1,'bind:confirm',2,'bind:input',3,'cancelColor',4,'cancelText',5,'class',6,'confirmColor',7,'data-event-opts',8,'list',9,'value',10,'vueId',11],[],e,s,gg)
_(tKJ,o2J)
var x3J=_mz(z,'u-picker',['bind:__l',99,'bind:confirm',1,'bind:input',2,'class',3,'data-event-opts',4,'mode',5,'value',6,'vueId',7],[],e,s,gg)
_(tKJ,x3J)
_(r,tKJ)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_30";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_30();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/subPage/editAddressZti.wxml'] = [$gwx_XC_30, './pages/subPage/editAddressZti.wxml'];else __wxAppCode__['pages/subPage/editAddressZti.wxml'] = $gwx_XC_30( './pages/subPage/editAddressZti.wxml' );
	;__wxRoute = "pages/subPage/editAddressZti";__wxRouteBegin = true;__wxAppCurrentFile__="pages/subPage/editAddressZti.js";define("pages/subPage/editAddressZti.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
(global.webpackJsonp=global.webpackJsonp||[]).push([["pages/subPage/editAddressZti"],{176:function(e,n,o){"use strict";(function(e){o(5),t(o(4));var n=t(o(177));function t(e){return e&&e.__esModule?e:{default:e}}wx.__webpack_require_UNI_MP_PLUGIN__=o,e(n.default)}).call(this,o(1).createPage)},177:function(e,n,o){"use strict";o.r(n);var t=o(178),i=o(180);for(var s in i)"default"!==s&&function(e){o.d(n,e,(function(){return i[e]}))}(s);o(182);var a=o(17),r=Object(a.default)(i.default,t.render,t.staticRenderFns,!1,null,"88708844",null,!1,t.components,void 0);r.options.__file="pages/subPage/editAddressZti.vue",n.default=r.exports},178:function(e,n,o){"use strict";o.r(n);var t=o(179);o.d(n,"render",(function(){return t.render})),o.d(n,"staticRenderFns",(function(){return t.staticRenderFns})),o.d(n,"recyclableRender",(function(){return t.recyclableRender})),o.d(n,"components",(function(){return t.components}))},179:function(e,n,o){"use strict";var t;o.r(n),o.d(n,"render",(function(){return i})),o.d(n,"staticRenderFns",(function(){return a})),o.d(n,"recyclableRender",(function(){return s})),o.d(n,"components",(function(){return t}));try{t={uField:function(){return o.e("uview-ui/components/u-field/u-field").then(o.bind(null,946))},uIcon:function(){return o.e("uview-ui/components/u-icon/u-icon").then(o.bind(null,854))},uSelect:function(){return o.e("uview-ui/components/u-select/u-select").then(o.bind(null,1027))},uPicker:function(){return Promise.all([o.e("common/vendor"),o.e("uview-ui/components/u-picker/u-picker")]).then(o.bind(null,1017))}}}catch(e){if(-1===e.message.indexOf("Cannot find module")||-1===e.message.indexOf(".vue"))throw e;console.error(e.message),console.error("1. 排查组件名称拼写是否正确"),console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"),console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件")}var i=function(){var e=this;e.$createElement,e._self._c,e._isMounted||(e.e0=function(n){e.showCate=!0})},s=!1,a=[];i._withStripped=!0},180:function(e,n,o){"use strict";o.r(n);var t=o(181),i=o.n(t);for(var s in t)"default"!==s&&function(e){o.d(n,e,(function(){return t[e]}))}(s);n.default=i.a},181:function(e,n,o){"use strict";(function(e){Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var o={data:function(){return{categoryArr:[],showCate:!1,hasImage:!1,iconStyles:{position:"absolute",top:"-10rpx",right:"-10rpx"},shennum:0,chooseCityBox:!1,defaultCheck:!1,addressInfo:{id:"",userName:"",userMobile:"",provinces:"",address:"",defaultFlag:"",addressType:2,addressName:"",longitude:0,latitude:0,showName:"",spickupImg:"",category:"",managerUserId:"",managerInfo:{id:"",nickName:"",headImg:"",managerUserId:"",createTime:""}},managerInfo:{id:"",nickName:"",headImg:"",managerUserId:"",createTime:""},canApplyAmount:0,qiniuInfo:{imgFolderPath:"",uploadToken:"",urlPrefix:"",videoFolderPath:""}}},onShow:function(){this.getCategoryList()},onLoad:function(n){if(e.hideShareMenu({}),this.getQiniuToken(),n&&n.item){var o=JSON.parse(decodeURIComponent(n.item));this.addressInfo=o}},methods:{goCateg:function(){e.navigateTo({url:"../pageRelay/speceCategoryZti"})},otherFun:function(e){console.log("上个页面传值",e),this.addressInfo.managerInfo={id:"",nickName:e.nickName,headImg:e.headImg,managerUserId:e.userId,createTime:""},this.addressInfo.managerUserId=e.userId},getQiniuToken:function(){var n=this;this.$server.qiniuToken({}).then((function(o){"0"==o.code?(n.qiniuInfo=o.data,console.log("qiniu === ",n.qiniuInfo),n.id||setTimeout((function(){}),1200),e.setStorageSync("qiniuInfo",o.data)):console.log("qiniu==",o)}))},getCategoryList:function(){var n=this;this.$server.categoryList({businessType:4}).then((function(o){0==o.code?o.data.length&&(o.data.forEach((function(e){e.label=e.categoryName,e.value=e.id})),n.categoryArr=o.data):e.showToast({title:o.message,icon:"none"})}))},confirmCat:function(e){var n=e[0];this.addressInfo.category=n.label},openAddresUser:function(){var n=JSON.parse(JSON.stringify(this.addressInfo)),o=encodeURIComponent(JSON.stringify(this.addressInfo));this.addressInfo.managerInfo.id?e.navigateTo({url:"../pageRelay/awardSellZtiInfo?item="+o}):(n.pageType=1,o=encodeURIComponent(JSON.stringify(n)),e.navigateTo({url:"../pageRelay/snapList?item="+o}))},delMiniImg:function(e,n){console.log("delMiniImg",e,n),this.addressInfo.spickupImg=""},upBgimg:function(n,o){var t=this;e.chooseImage({count:1,sizeType:["compressed"],sourceType:["camera","album"],success:function(n){e.showLoading({title:"上传中"}),n.tempFilePaths.map((function(n,o){for(var i=n,s="."+i.split(".")[1],a="",r=0;r<18;r++)a+="abcdefghijkmnpqrstvwxyz1234567890".charAt(Math.floor(32*Math.random()));a=t.qiniuInfo.imgFolderPath+a+s,console.log("全部11==",t.qiniuInfo,a),e.uploadFile({url:"https://up-z2.qiniup.com",filePath:i,name:"file",formData:{key:a,token:t.qiniuInfo.uploadToken},success:function(n){console.log("全部",n);var o=t.qiniuInfo.urlPrefix+a;t.addressInfo.spickupImg=o,e.hideLoading()}})}))}})},chooseLoac:function(){var n=this;e.chooseLocation({success:function(e){n.addressInfo.latitude=e.latitude,n.addressInfo.longitude=e.longitude,n.addressInfo.address=e.address,n.addressInfo.showName=e.name,console.log("全部",e)},fail:function(e){console.log("失败",e)}})},changeFlag:function(e){console.log(e),console.log(this.defaultCheck)},confirms:function(e){var n;console.log("省市==",e),n=11==e.province.value||12==e.province.value||31==e.province.value||50==e.province.value?e.province.label+"/"+e.area.label:e.province.label+"/"+e.city.label+"/"+e.area.label,this.addressInfo.provinces=n,console.log("省市that==",this.addressInfo.provinces),console.log(this.addressInfo)},saveAddress:function(){if(console.log(this.addressInfo),this.addressInfo.userName)if(this.addressInfo.userMobile)if(this.addressInfo.longitude)if(this.addressInfo.address)if(this.addressInfo.addressName){var n=JSON.parse(JSON.stringify(this.addressInfo));this.$delete(n,"managerInfo"),this.$delete(n,"createTime"),this.$delete(n,"updateTime"),this.$server.updateAddress(n).then((function(n){0==n.code?(e.showToast({title:"保存成功",icon:"none"}),setTimeout((function(n){e.navigateBack()}),800)):e.showToast({title:n.message,icon:"none"})}))}else e.showToast({title:"请输入自提点名称",icon:"none"});else e.showToast({title:"请输入收货详细地址",icon:"none"});else e.showToast({title:"请选择所在位置",icon:"none"});else e.showToast({title:"请输入自提点电话",icon:"none"});else e.showToast({title:"请输入自提点联系人",icon:"none"})},delAddress:function(){var n=this;e.showModal({title:"提示",content:"您确认要删除该收货地址吗",success:function(e){e.confirm?n.delServer():e.cancel&&console.log("用户点击取消")}})},delServer:function(){this.$server.deleteAddress({id:this.addressInfo.id}).then((function(n){0==n.code?(e.showToast({title:"删除成功",icon:"none"}),setTimeout((function(n){e.navigateBack()}),800)):e.showToast({title:n.message,icon:"none"})}))}}};n.default=o}).call(this,o(1).default)},182:function(e,n,o){"use strict";o.r(n);var t=o(183),i=o.n(t);for(var s in t)"default"!==s&&function(e){o.d(n,e,(function(){return t[e]}))}(s);n.default=i.a},183:function(e,n,o){}},[[176,"common/runtime","common/vendor"]]]);
},{isPage:true,isComponent:true,currentFile:'pages/subPage/editAddressZti.js'});require("pages/subPage/editAddressZti.js");