$gwx_XC_38=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_38 || [];
function gz$gwx_XC_38_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_38_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_38_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_38_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'award_join data-v-891dd2f8'])
Z([3,'min-height:100vh;background-color:#f4f4f4;'])
Z([[2,'=='],[[6],[[7],[3,'userInfoHome']],[3,'userType']],[1,1]])
Z([3,'#07c160'])
Z([3,'__l'])
Z([3,'__e'])
Z([3,'data-v-891dd2f8'])
Z([[7],[3,'typeIds']])
Z([[4],[[5],[[4],[[5],[[5],[1,'^change']],[[4],[[5],[[4],[[5],[1,'checkTypes']]]]]]]]])
Z([[7],[3,'typeArray']])
Z([3,'subsection'])
Z([3,'9a9b89fc-1'])
Z([[2,'=='],[[6],[[7],[3,'userInfoHome']],[3,'userType']],[1,2]])
Z([[2,'=='],[[7],[3,'typeIds']],[1,1]])
Z(z[13])
Z([3,'sai_xuan fl_sb data-v-891dd2f8'])
Z(z[5])
Z([3,'left_tg fl data-v-891dd2f8'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'e0']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z(z[4])
Z(z[6])
Z([3,'#ccc'])
Z([3,'arrow-down'])
Z([3,'28'])
Z([3,'9a9b89fc-2'])
Z(z[5])
Z(z[17])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'e1']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z(z[4])
Z(z[6])
Z(z[21])
Z(z[22])
Z(z[23])
Z([3,'9a9b89fc-3'])
Z([[8],'color',[1,'#07c160']])
Z([3,'#f4f4f4'])
Z(z[4])
Z(z[5])
Z(z[5])
Z(z[5])
Z(z[6])
Z([[4],[[5],[[5],[[5],[[4],[[5],[[5],[1,'^blur']],[[4],[[5],[[4],[[5],[1,'searchFuns']]]]]]]],[[4],[[5],[[5],[1,'^search']],[[4],[[5],[[4],[[5],[1,'searchFuns']]]]]]]],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'searchContent']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z([3,'64'])
Z([3,'搜索昵称/手机号/跟团号'])
Z([3,'square'])
Z([1,false])
Z([[7],[3,'searchContent']])
Z([3,'9a9b89fc-4'])
Z([3,'index'])
Z([3,'item'])
Z([[6],[[7],[3,'$root']],[3,'l1']])
Z(z[48])
Z([3,'row_bxs data-v-891dd2f8'])
Z([[2,'&&'],[[2,'=='],[[7],[3,'typeIds']],[1,1]],[[6],[[6],[[7],[3,'item']],[3,'$orig']],[3,'superActivityUserId']]])
Z(z[5])
Z([3,'act_name fl_sb data-v-891dd2f8'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'goShow']],[[4],[[5],[1,'$0']]]],[[4],[[5],[[4],[[5],[[4],[[5],[[5],[[5],[[5],[1,'orderData']],[1,'']],[[7],[3,'index']]],[1,'activityId']]]]]]]]]]]]]]])
Z(z[4])
Z(z[6])
Z([3,'#a8a8a8'])
Z([3,'arrow-right'])
Z([3,'30'])
Z([[2,'+'],[1,'9a9b89fc-5-'],[[7],[3,'index']]])
Z([3,'k'])
Z([3,'j'])
Z([[6],[[6],[[7],[3,'item']],[3,'$orig']],[3,'commodityDetais']])
Z(z[63])
Z([3,'tc_main data-v-891dd2f8'])
Z([3,'over_lin data-v-891dd2f8'])
Z([[2,'!='],[[6],[[7],[3,'j']],[3,'formatName']],[1,'默认 ']])
Z([[2,'>'],[[6],[[7],[3,'j']],[3,'refundMoney']],[1,0]])
Z([[6],[[7],[3,'j']],[3,'refundMoney']])
Z([[6],[[7],[3,'j']],[3,'refundCount']])
Z([3,'huise_box data-v-891dd2f8'])
Z([3,'logis_name fl_sb data-v-891dd2f8'])
Z([[2,'&&'],[[2,'!'],[[6],[[6],[[7],[3,'item']],[3,'$orig']],[3,'logisticsRecordIds']]],[[6],[[6],[[6],[[7],[3,'item']],[3,'$orig']],[3,'orderLogistics']],[3,'length']]])
Z(z[5])
Z([3,'fl data-v-891dd2f8'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'goLosis']],[[4],[[5],[1,'$0']]]],[[4],[[5],[[4],[[5],[[4],[[5],[[5],[[5],[[5],[1,'orderData']],[1,'']],[[7],[3,'index']]],[1,'orderLogistics.__$n0']]]]]]]]]]]]]]])
Z([3,'color:#999;font-size:24rpx;'])
Z(z[4])
Z(z[6])
Z([3,'#999'])
Z(z[60])
Z([3,'24'])
Z([[2,'+'],[1,'9a9b89fc-6-'],[[7],[3,'index']]])
Z([[2,'=='],[[6],[[6],[[7],[3,'item']],[3,'$orig']],[3,'deliveryStatus']],[1,2]])
Z(z[77])
Z(z[79])
Z(z[7])
Z(z[5])
Z(z[77])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'goMaps']],[[4],[[5],[1,'$0']]]],[[4],[[5],[[4],[[5],[[4],[[5],[[5],[[5],[1,'orderData']],[1,'']],[[7],[3,'index']]]]]]]]]]]]]]]])
Z(z[4])
Z(z[6])
Z(z[82])
Z(z[60])
Z(z[84])
Z([[2,'+'],[1,'9a9b89fc-7-'],[[7],[3,'index']]])
Z([3,'list_l data-v-891dd2f8'])
Z(z[13])
Z(z[6])
Z([[2,'!'],[[6],[[6],[[7],[3,'item']],[3,'$orig']],[3,'logisticsRecordIds']]])
Z([3,'z'])
Z([3,'y'])
Z([[6],[[6],[[7],[3,'item']],[3,'$orig']],[3,'orderAddrs']])
Z(z[103])
Z(z[6])
Z([[2,'=='],[[6],[[7],[3,'y']],[3,'contentType']],[1,1]])
Z(z[5])
Z([3,'fl mb16 data-v-891dd2f8'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'globalYulan']],[[4],[[5],[[5],[1,'$0']],[1,0]]]],[[4],[[5],[[4],[[5],[[5],[[4],[[5],[[5],[[5],[1,'orderData']],[1,'']],[[7],[3,'index']]]]],[[4],[[5],[[5],[[5],[[5],[1,'orderAddrs']],[1,'']],[[7],[3,'z']]],[1,'yrjarr']]]]]]]]]]]]]]])
Z(z[4])
Z(z[6])
Z(z[82])
Z(z[60])
Z(z[84])
Z([[2,'+'],[[2,'+'],[[2,'+'],[1,'9a9b89fc-8-'],[[7],[3,'index']]],[1,'-']],[[7],[3,'z']]])
Z(z[103])
Z(z[104])
Z(z[105])
Z(z[103])
Z(z[6])
Z(z[108])
Z(z[5])
Z(z[110])
Z(z[111])
Z(z[4])
Z(z[6])
Z(z[82])
Z(z[60])
Z(z[84])
Z([[2,'+'],[[2,'+'],[[2,'+'],[1,'9a9b89fc-9-'],[[7],[3,'index']]],[1,'-']],[[7],[3,'z']]])
Z([[2,'=='],[[7],[3,'typeIds']],[1,0]])
Z(z[6])
Z(z[102])
Z(z[103])
Z(z[104])
Z(z[105])
Z(z[103])
Z(z[6])
Z(z[108])
Z(z[5])
Z(z[110])
Z(z[111])
Z(z[4])
Z(z[6])
Z(z[82])
Z(z[60])
Z(z[84])
Z([[2,'+'],[[2,'+'],[[2,'+'],[1,'9a9b89fc-10-'],[[7],[3,'index']]],[1,'-']],[[7],[3,'z']]])
Z(z[103])
Z(z[104])
Z(z[105])
Z(z[103])
Z(z[6])
Z(z[108])
Z(z[5])
Z(z[110])
Z(z[111])
Z(z[4])
Z(z[6])
Z(z[82])
Z(z[60])
Z(z[84])
Z([[2,'+'],[[2,'+'],[[2,'+'],[1,'9a9b89fc-11-'],[[7],[3,'index']]],[1,'-']],[[7],[3,'z']]])
Z([[6],[[6],[[6],[[7],[3,'item']],[3,'$orig']],[3,'deliverImgs']],[3,'length']])
Z([[2,'||'],[[6],[[6],[[6],[[7],[3,'item']],[3,'$orig']],[3,'orderRemarks']],[3,'length']],[[6],[[6],[[7],[3,'item']],[3,'$orig']],[3,'orderRefundRemarks']]])
Z([3,'v'])
Z([3,'u'])
Z([[6],[[7],[3,'item']],[3,'l0']])
Z(z[168])
Z([3,'list_elere data-v-891dd2f8'])
Z([3,'fl_sb data-v-891dd2f8'])
Z([[6],[[7],[3,'u']],[3,'g0']])
Z([[6],[[7],[3,'u']],[3,'g1']])
Z([[6],[[7],[3,'u']],[3,'g2']])
Z([[6],[[7],[3,'u']],[3,'g3']])
Z([3,'jujue_tyi fl_sb data-v-891dd2f8'])
Z([[2,'=='],[[6],[[6],[[7],[3,'item']],[3,'$orig']],[3,'salesStatus']],[1,2]])
Z([[2,'=='],[[6],[[6],[[7],[3,'item']],[3,'$orig']],[3,'salesStatus']],[1,5]])
Z([[2,'=='],[[6],[[6],[[7],[3,'item']],[3,'$orig']],[3,'salesStatus']],[1,4]])
Z([[6],[[6],[[7],[3,'u']],[3,'$orig']],[3,'createTime']])
Z([[6],[[6],[[7],[3,'item']],[3,'$orig']],[3,'shipFeeMoney']])
Z([[6],[[6],[[7],[3,'item']],[3,'$orig']],[3,'refundShipFeeMoney']])
Z(z[133])
Z([3,'btn_row fl data-v-891dd2f8'])
Z([[2,'=='],[[6],[[6],[[7],[3,'item']],[3,'$orig']],[3,'freezeFlag']],[1,2]])
Z(z[187])
Z([[7],[3,'noData']])
Z(z[4])
Z(z[6])
Z([1,300])
Z([3,'favor'])
Z([3,'暂无订单'])
Z([3,'9a9b89fc-12'])
Z(z[4])
Z(z[5])
Z([3,'14'])
Z(z[6])
Z([[4],[[5],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'showRemark']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z([3,'center'])
Z([[7],[3,'showRemark']])
Z([3,'9a9b89fc-13'])
Z([[4],[[5],[1,'default']]])
Z([1,true])
Z(z[4])
Z(z[5])
Z(z[6])
Z(z[45])
Z([[7],[3,'cStyle']])
Z([[4],[[5],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'remarkVa']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z([3,'200'])
Z([3,'-1'])
Z([3,'请输入您要的备注,双方可见'])
Z([3,'font-size:26rpx;'])
Z([3,'textarea'])
Z([[7],[3,'remarkVa']])
Z([[2,'+'],[[2,'+'],[1,'9a9b89fc-14'],[1,',']],[1,'9a9b89fc-13']])
Z(z[4])
Z(z[5])
Z(z[198])
Z(z[6])
Z([[4],[[5],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'showRefund']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z(z[201])
Z([[7],[3,'showRefund']])
Z([3,'9a9b89fc-15'])
Z(z[204])
Z(z[205])
Z(z[4])
Z(z[5])
Z(z[6])
Z(z[45])
Z(z[210])
Z([[4],[[5],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'remarkRefund']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z(z[212])
Z(z[213])
Z(z[214])
Z(z[215])
Z(z[216])
Z([[7],[3,'remarkRefund']])
Z([[2,'+'],[[2,'+'],[1,'9a9b89fc-16'],[1,',']],[1,'9a9b89fc-15']])
Z(z[4])
Z(z[5])
Z(z[198])
Z(z[6])
Z([[4],[[5],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'showRemarkLoc']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z([3,'bottom'])
Z([[7],[3,'showRemarkLoc']])
Z([3,'9a9b89fc-17'])
Z(z[204])
Z([3,'text_ar data-v-891dd2f8'])
Z(z[4])
Z(z[5])
Z(z[5])
Z(z[6])
Z([[4],[[5],[[5],[[4],[[5],[[5],[1,'^blur']],[[4],[[5],[[4],[[5],[1,'queryCpName']]]]]]]],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'logisticsId']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z([3,'单号'])
Z([3,'80'])
Z([3,'请输入快递单号'])
Z([[7],[3,'logisticsId']])
Z([[2,'+'],[[2,'+'],[1,'9a9b89fc-18'],[1,',']],[1,'9a9b89fc-17']])
Z([[4],[[5],[1,'right']]])
Z(z[4])
Z(z[5])
Z(z[6])
Z(z[3])
Z([[4],[[5],[[4],[[5],[[5],[1,'^click']],[[4],[[5],[[4],[[5],[1,'scanNum']]]]]]]]])
Z([3,'scan'])
Z([3,'40'])
Z([3,'right'])
Z([[2,'+'],[[2,'+'],[1,'9a9b89fc-19'],[1,',']],[1,'9a9b89fc-18']])
Z(z[4])
Z(z[5])
Z(z[6])
Z([[4],[[5],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'logisticsName']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z([3,'公司'])
Z(z[258])
Z([3,'请输入快递公司'])
Z([[7],[3,'logisticsName']])
Z([[2,'+'],[[2,'+'],[1,'9a9b89fc-20'],[1,',']],[1,'9a9b89fc-17']])
Z(z[4])
Z(z[5])
Z(z[269])
Z(z[6])
Z(z[205])
Z([[4],[[5],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'openSaixuan']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z(z[247])
Z([[7],[3,'openSaixuan']])
Z([3,'9a9b89fc-21'])
Z(z[204])
Z(z[48])
Z(z[49])
Z([[7],[3,'listSai']])
Z(z[48])
Z(z[5])
Z([3,'list_saixu fl_sb data-v-891dd2f8'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'checkActName']],[[4],[[5],[1,'$0']]]],[[4],[[5],[[4],[[5],[[4],[[5],[[5],[[5],[1,'listSai']],[1,'']],[[7],[3,'index']]]]]]]]]]]]]]]])
Z([[2,'=='],[[7],[3,'listSaiId']],[[6],[[7],[3,'item']],[3,'activityId']]])
Z(z[4])
Z(z[6])
Z(z[3])
Z([3,'checkbox-mark'])
Z(z[23])
Z([[2,'+'],[[2,'+'],[[2,'+'],[1,'9a9b89fc-22-'],[[7],[3,'index']]],[1,',']],[1,'9a9b89fc-21']])
Z(z[4])
Z(z[5])
Z(z[269])
Z(z[6])
Z(z[205])
Z([[4],[[5],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'openSaixuanTi']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z(z[247])
Z([[7],[3,'openSaixuanTi']])
Z([3,'9a9b89fc-23'])
Z(z[204])
Z([[2,'!'],[[7],[3,'firstComming']]])
Z(z[4])
Z(z[5])
Z(z[198])
Z(z[6])
Z(z[205])
Z([[4],[[5],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'showWecont']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z(z[201])
Z([[7],[3,'showWecont']])
Z([3,'9a9b89fc-24'])
Z(z[204])
Z([3,'580rpx'])
Z(z[4])
Z(z[5])
Z(z[198])
Z(z[6])
Z(z[205])
Z([[4],[[5],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'showQrcode']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z(z[201])
Z([[7],[3,'showQrcode']])
Z([3,'9a9b89fc-25'])
Z(z[204])
Z(z[326])
Z(z[334])
Z([3,'#333333'])
Z(z[4])
Z(z[5])
Z([3,'data-v-891dd2f8 vue-ref'])
Z([[4],[[5],[[4],[[5],[[5],[1,'^result']],[[4],[[5],[[4],[[5],[1,'qrR']]]]]]]]])
Z([3,'qrcode'])
Z([3,'#ffffff'])
Z([3,'../../static/uview/example/logossmall.png'])
Z(z[61])
Z([3,'true'])
Z(z[345])
Z([3,'300'])
Z([3,'upx'])
Z(z[205])
Z([[7],[3,'qrCodeVal']])
Z([[2,'+'],[[2,'+'],[1,'9a9b89fc-26'],[1,',']],[1,'9a9b89fc-25']])
Z(z[4])
Z(z[5])
Z(z[5])
Z([[8],'fontWeight',[1,'500']])
Z(z[6])
Z(z[3])
Z(z[358])
Z([3,'确认'])
Z([[4],[[5],[[5],[[4],[[5],[[5],[1,'^confirm']],[[4],[[5],[[4],[[5],[1,'sureLocs']]]]]]]],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'showGoPay']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z(z[205])
Z([3,'温馨提示'])
Z([[7],[3,'showGoPay']])
Z([3,'9a9b89fc-27'])
Z(z[204])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_38_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_38_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_38=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_38=true;
var x=['./pages/subPage/orderRel.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_38_1()
var f1N=_mz(z,'view',['class',0,'style',1],[],e,s,gg)
var c2N=_v()
_(f1N,c2N)
if(_oz(z,2,e,s,gg)){c2N.wxVkey=1
var a8N=_mz(z,'u-subsection',['activeColor',3,'bind:__l',1,'bind:change',2,'class',3,'current',4,'data-event-opts',5,'list',6,'mode',7,'vueId',8],[],e,s,gg)
_(c2N,a8N)
}
var h3N=_v()
_(f1N,h3N)
if(_oz(z,12,e,s,gg)){h3N.wxVkey=1
}
var o4N=_v()
_(f1N,o4N)
if(_oz(z,13,e,s,gg)){o4N.wxVkey=1
}
var c5N=_v()
_(f1N,c5N)
if(_oz(z,14,e,s,gg)){c5N.wxVkey=1
var t9N=_n('view')
_rz(z,t9N,'class',15,e,s,gg)
var e0N=_mz(z,'view',['bindtap',16,'class',1,'data-event-opts',2],[],e,s,gg)
var bAO=_mz(z,'u-icon',['bind:__l',19,'class',1,'color',2,'name',3,'size',4,'vueId',5],[],e,s,gg)
_(e0N,bAO)
_(t9N,e0N)
var oBO=_mz(z,'view',['bindtap',25,'class',1,'data-event-opts',2],[],e,s,gg)
var xCO=_mz(z,'u-icon',['bind:__l',28,'class',1,'color',2,'name',3,'size',4,'vueId',5],[],e,s,gg)
_(oBO,xCO)
_(t9N,oBO)
_(c5N,t9N)
}
var oDO=_mz(z,'u-search',['actionStyle',34,'bgColor',1,'bind:__l',2,'bind:blur',3,'bind:input',4,'bind:search',5,'class',6,'data-event-opts',7,'height',8,'placeholder',9,'shape',10,'showAction',11,'value',12,'vueId',13],[],e,s,gg)
_(f1N,oDO)
var fEO=_v()
_(f1N,fEO)
var cFO=function(oHO,hGO,cIO,gg){
var lKO=_n('view')
_rz(z,lKO,'class',52,oHO,hGO,gg)
var aLO=_v()
_(lKO,aLO)
if(_oz(z,53,oHO,hGO,gg)){aLO.wxVkey=1
}
var bOO=_mz(z,'view',['bindtap',54,'class',1,'data-event-opts',2],[],oHO,hGO,gg)
var oPO=_mz(z,'u-icon',['bind:__l',57,'class',1,'color',2,'name',3,'size',4,'vueId',5],[],oHO,hGO,gg)
_(bOO,oPO)
_(lKO,bOO)
var xQO=_v()
_(lKO,xQO)
var oRO=function(cTO,fSO,hUO,gg){
var cWO=_n('view')
_rz(z,cWO,'class',67,cTO,fSO,gg)
var lYO=_n('text')
_rz(z,lYO,'class',68,cTO,fSO,gg)
var aZO=_v()
_(lYO,aZO)
if(_oz(z,69,cTO,fSO,gg)){aZO.wxVkey=1
}
var t1O=_v()
_(lYO,t1O)
if(_oz(z,70,cTO,fSO,gg)){t1O.wxVkey=1
}
aZO.wxXCkey=1
t1O.wxXCkey=1
_(cWO,lYO)
var oXO=_v()
_(cWO,oXO)
if(_oz(z,71,cTO,fSO,gg)){oXO.wxVkey=1
var e2O=_v()
_(oXO,e2O)
if(_oz(z,72,cTO,fSO,gg)){e2O.wxVkey=1
}
e2O.wxXCkey=1
}
oXO.wxXCkey=1
_(hUO,cWO)
return hUO
}
xQO.wxXCkey=2
_2z(z,65,oRO,oHO,hGO,gg,xQO,'j','k','k')
var b3O=_n('view')
_rz(z,b3O,'class',73,oHO,hGO,gg)
var o4O=_n('view')
_rz(z,o4O,'class',74,oHO,hGO,gg)
var x5O=_v()
_(o4O,x5O)
if(_oz(z,75,oHO,hGO,gg)){x5O.wxVkey=1
var o6O=_mz(z,'view',['bindtap',76,'class',1,'data-event-opts',2,'style',3],[],oHO,hGO,gg)
var f7O=_mz(z,'u-icon',['bind:__l',80,'class',1,'color',2,'name',3,'size',4,'vueId',5],[],oHO,hGO,gg)
_(o6O,f7O)
_(x5O,o6O)
}
else{x5O.wxVkey=2
var c8O=_v()
_(x5O,c8O)
if(_oz(z,86,oHO,hGO,gg)){c8O.wxVkey=1
var h9O=_mz(z,'view',['class',87,'style',1],[],oHO,hGO,gg)
var o0O=_v()
_(h9O,o0O)
if(_oz(z,89,oHO,hGO,gg)){o0O.wxVkey=1
}
var cAP=_mz(z,'view',['bindtap',90,'class',1,'data-event-opts',2],[],oHO,hGO,gg)
var oBP=_mz(z,'u-icon',['bind:__l',93,'class',1,'color',2,'name',3,'size',4,'vueId',5],[],oHO,hGO,gg)
_(cAP,oBP)
_(h9O,cAP)
o0O.wxXCkey=1
_(c8O,h9O)
}
c8O.wxXCkey=1
c8O.wxXCkey=3
}
x5O.wxXCkey=1
x5O.wxXCkey=3
x5O.wxXCkey=3
_(b3O,o4O)
var lCP=_n('view')
_rz(z,lCP,'class',99,oHO,hGO,gg)
var aDP=_v()
_(lCP,aDP)
if(_oz(z,100,oHO,hGO,gg)){aDP.wxVkey=1
var oHP=_n('view')
_rz(z,oHP,'class',101,oHO,hGO,gg)
var xIP=_v()
_(oHP,xIP)
if(_oz(z,102,oHO,hGO,gg)){xIP.wxVkey=1
var oJP=_v()
_(xIP,oJP)
var fKP=function(hMP,cLP,oNP,gg){
var oPP=_n('view')
_rz(z,oPP,'class',107,hMP,cLP,gg)
var lQP=_v()
_(oPP,lQP)
if(_oz(z,108,hMP,cLP,gg)){lQP.wxVkey=1
}
else{lQP.wxVkey=2
var aRP=_mz(z,'view',['bindtap',109,'class',1,'data-event-opts',2],[],hMP,cLP,gg)
var tSP=_mz(z,'u-icon',['bind:__l',112,'class',1,'color',2,'name',3,'size',4,'vueId',5],[],hMP,cLP,gg)
_(aRP,tSP)
_(lQP,aRP)
}
lQP.wxXCkey=1
lQP.wxXCkey=3
_(oNP,oPP)
return oNP
}
oJP.wxXCkey=4
_2z(z,105,fKP,oHO,hGO,gg,oJP,'y','z','z')
}
else{xIP.wxVkey=2
var eTP=_v()
_(xIP,eTP)
var bUP=function(xWP,oVP,oXP,gg){
var cZP=_n('view')
_rz(z,cZP,'class',122,xWP,oVP,gg)
var h1P=_v()
_(cZP,h1P)
if(_oz(z,123,xWP,oVP,gg)){h1P.wxVkey=1
}
else{h1P.wxVkey=2
var o2P=_mz(z,'view',['bindtap',124,'class',1,'data-event-opts',2],[],xWP,oVP,gg)
var c3P=_mz(z,'u-icon',['bind:__l',127,'class',1,'color',2,'name',3,'size',4,'vueId',5],[],xWP,oVP,gg)
_(o2P,c3P)
_(h1P,o2P)
}
h1P.wxXCkey=1
h1P.wxXCkey=3
_(oXP,cZP)
return oXP
}
eTP.wxXCkey=4
_2z(z,120,bUP,oHO,hGO,gg,eTP,'y','z','z')
}
xIP.wxXCkey=1
xIP.wxXCkey=3
xIP.wxXCkey=3
_(aDP,oHP)
}
var tEP=_v()
_(lCP,tEP)
if(_oz(z,133,oHO,hGO,gg)){tEP.wxVkey=1
var o4P=_n('view')
_rz(z,o4P,'class',134,oHO,hGO,gg)
var l5P=_v()
_(o4P,l5P)
if(_oz(z,135,oHO,hGO,gg)){l5P.wxVkey=1
var a6P=_v()
_(l5P,a6P)
var t7P=function(b9P,e8P,o0P,gg){
var oBQ=_n('view')
_rz(z,oBQ,'class',140,b9P,e8P,gg)
var fCQ=_v()
_(oBQ,fCQ)
if(_oz(z,141,b9P,e8P,gg)){fCQ.wxVkey=1
}
else{fCQ.wxVkey=2
var cDQ=_mz(z,'view',['bindtap',142,'class',1,'data-event-opts',2],[],b9P,e8P,gg)
var hEQ=_mz(z,'u-icon',['bind:__l',145,'class',1,'color',2,'name',3,'size',4,'vueId',5],[],b9P,e8P,gg)
_(cDQ,hEQ)
_(fCQ,cDQ)
}
fCQ.wxXCkey=1
fCQ.wxXCkey=3
_(o0P,oBQ)
return o0P
}
a6P.wxXCkey=4
_2z(z,138,t7P,oHO,hGO,gg,a6P,'y','z','z')
}
else{l5P.wxVkey=2
var oFQ=_v()
_(l5P,oFQ)
var cGQ=function(lIQ,oHQ,aJQ,gg){
var eLQ=_n('view')
_rz(z,eLQ,'class',155,lIQ,oHQ,gg)
var bMQ=_v()
_(eLQ,bMQ)
if(_oz(z,156,lIQ,oHQ,gg)){bMQ.wxVkey=1
}
else{bMQ.wxVkey=2
var oNQ=_mz(z,'view',['bindtap',157,'class',1,'data-event-opts',2],[],lIQ,oHQ,gg)
var xOQ=_mz(z,'u-icon',['bind:__l',160,'class',1,'color',2,'name',3,'size',4,'vueId',5],[],lIQ,oHQ,gg)
_(oNQ,xOQ)
_(bMQ,oNQ)
}
bMQ.wxXCkey=1
bMQ.wxXCkey=3
_(aJQ,eLQ)
return aJQ
}
oFQ.wxXCkey=4
_2z(z,153,cGQ,oHO,hGO,gg,oFQ,'y','z','z')
}
l5P.wxXCkey=1
l5P.wxXCkey=3
l5P.wxXCkey=3
_(tEP,o4P)
}
var eFP=_v()
_(lCP,eFP)
if(_oz(z,166,oHO,hGO,gg)){eFP.wxVkey=1
}
var bGP=_v()
_(lCP,bGP)
if(_oz(z,167,oHO,hGO,gg)){bGP.wxVkey=1
var oPQ=_v()
_(bGP,oPQ)
var fQQ=function(hSQ,cRQ,oTQ,gg){
var oVQ=_n('view')
_rz(z,oVQ,'class',172,hSQ,cRQ,gg)
var tYQ=_n('view')
_rz(z,tYQ,'class',173,hSQ,cRQ,gg)
var eZQ=_v()
_(tYQ,eZQ)
if(_oz(z,174,hSQ,cRQ,gg)){eZQ.wxVkey=1
}
var b1Q=_v()
_(tYQ,b1Q)
if(_oz(z,175,hSQ,cRQ,gg)){b1Q.wxVkey=1
}
var o2Q=_v()
_(tYQ,o2Q)
if(_oz(z,176,hSQ,cRQ,gg)){o2Q.wxVkey=1
}
eZQ.wxXCkey=1
b1Q.wxXCkey=1
o2Q.wxXCkey=1
_(oVQ,tYQ)
var lWQ=_v()
_(oVQ,lWQ)
if(_oz(z,177,hSQ,cRQ,gg)){lWQ.wxVkey=1
var x3Q=_n('view')
_rz(z,x3Q,'class',178,hSQ,cRQ,gg)
var o4Q=_v()
_(x3Q,o4Q)
if(_oz(z,179,hSQ,cRQ,gg)){o4Q.wxVkey=1
}
var f5Q=_v()
_(x3Q,f5Q)
if(_oz(z,180,hSQ,cRQ,gg)){f5Q.wxVkey=1
}
var c6Q=_v()
_(x3Q,c6Q)
if(_oz(z,181,hSQ,cRQ,gg)){c6Q.wxVkey=1
}
o4Q.wxXCkey=1
f5Q.wxXCkey=1
c6Q.wxXCkey=1
_(lWQ,x3Q)
}
var aXQ=_v()
_(oVQ,aXQ)
if(_oz(z,182,hSQ,cRQ,gg)){aXQ.wxVkey=1
}
lWQ.wxXCkey=1
aXQ.wxXCkey=1
_(oTQ,oVQ)
return oTQ
}
oPQ.wxXCkey=2
_2z(z,170,fQQ,oHO,hGO,gg,oPQ,'u','v','v')
}
aDP.wxXCkey=1
aDP.wxXCkey=3
tEP.wxXCkey=1
tEP.wxXCkey=3
eFP.wxXCkey=1
bGP.wxXCkey=1
_(b3O,lCP)
_(lKO,b3O)
var tMO=_v()
_(lKO,tMO)
if(_oz(z,183,oHO,hGO,gg)){tMO.wxVkey=1
var h7Q=_v()
_(tMO,h7Q)
if(_oz(z,184,oHO,hGO,gg)){h7Q.wxVkey=1
}
h7Q.wxXCkey=1
}
var eNO=_v()
_(lKO,eNO)
if(_oz(z,185,oHO,hGO,gg)){eNO.wxVkey=1
var o8Q=_n('view')
_rz(z,o8Q,'class',186,oHO,hGO,gg)
var c9Q=_v()
_(o8Q,c9Q)
if(_oz(z,187,oHO,hGO,gg)){c9Q.wxVkey=1
}
var o0Q=_v()
_(o8Q,o0Q)
if(_oz(z,188,oHO,hGO,gg)){o0Q.wxVkey=1
}
c9Q.wxXCkey=1
o0Q.wxXCkey=1
_(eNO,o8Q)
}
else{eNO.wxVkey=2
}
aLO.wxXCkey=1
tMO.wxXCkey=1
eNO.wxXCkey=1
_(cIO,lKO)
return cIO
}
fEO.wxXCkey=4
_2z(z,50,cFO,e,s,gg,fEO,'item','index','index')
var o6N=_v()
_(f1N,o6N)
if(_oz(z,189,e,s,gg)){o6N.wxVkey=1
var lAR=_mz(z,'u-empty',['bind:__l',190,'class',1,'marginTop',2,'mode',3,'text',4,'vueId',5],[],e,s,gg)
_(o6N,lAR)
}
var aBR=_mz(z,'u-popup',['bind:__l',196,'bind:input',1,'borderRadius',2,'class',3,'data-event-opts',4,'mode',5,'value',6,'vueId',7,'vueSlots',8],[],e,s,gg)
var tCR=_mz(z,'u-input',['autoHeight',205,'bind:__l',1,'bind:input',2,'class',3,'clearable',4,'customStyle',5,'data-event-opts',6,'height',7,'maxlength',8,'placeholder',9,'placeholderStyle',10,'type',11,'value',12,'vueId',13],[],e,s,gg)
_(aBR,tCR)
_(f1N,aBR)
var eDR=_mz(z,'u-popup',['bind:__l',219,'bind:input',1,'borderRadius',2,'class',3,'data-event-opts',4,'mode',5,'value',6,'vueId',7,'vueSlots',8],[],e,s,gg)
var bER=_mz(z,'u-input',['autoHeight',228,'bind:__l',1,'bind:input',2,'class',3,'clearable',4,'customStyle',5,'data-event-opts',6,'height',7,'maxlength',8,'placeholder',9,'placeholderStyle',10,'type',11,'value',12,'vueId',13],[],e,s,gg)
_(eDR,bER)
_(f1N,eDR)
var oFR=_mz(z,'u-popup',['bind:__l',242,'bind:input',1,'borderRadius',2,'class',3,'data-event-opts',4,'mode',5,'value',6,'vueId',7,'vueSlots',8],[],e,s,gg)
var xGR=_n('view')
_rz(z,xGR,'class',251,e,s,gg)
var oHR=_mz(z,'u-field',['bind:__l',252,'bind:blur',1,'bind:input',2,'class',3,'data-event-opts',4,'label',5,'labelWidth',6,'placeholder',7,'value',8,'vueId',9,'vueSlots',10],[],e,s,gg)
var fIR=_mz(z,'u-icon',['bind:__l',263,'bind:click',1,'class',2,'color',3,'data-event-opts',4,'name',5,'size',6,'slot',7,'vueId',8],[],e,s,gg)
_(oHR,fIR)
_(xGR,oHR)
var cJR=_mz(z,'u-field',['bind:__l',272,'bind:input',1,'class',2,'data-event-opts',3,'label',4,'labelWidth',5,'placeholder',6,'value',7,'vueId',8],[],e,s,gg)
_(xGR,cJR)
_(oFR,xGR)
_(f1N,oFR)
var hKR=_mz(z,'u-popup',['bind:__l',281,'bind:input',1,'borderRadius',2,'class',3,'closeable',4,'data-event-opts',5,'mode',6,'value',7,'vueId',8,'vueSlots',9],[],e,s,gg)
var oLR=_v()
_(hKR,oLR)
var cMR=function(lOR,oNR,aPR,gg){
var eRR=_mz(z,'view',['bindtap',295,'class',1,'data-event-opts',2],[],lOR,oNR,gg)
var bSR=_v()
_(eRR,bSR)
if(_oz(z,298,lOR,oNR,gg)){bSR.wxVkey=1
var oTR=_mz(z,'u-icon',['bind:__l',299,'class',1,'color',2,'name',3,'size',4,'vueId',5],[],lOR,oNR,gg)
_(bSR,oTR)
}
else{bSR.wxVkey=2
}
bSR.wxXCkey=1
bSR.wxXCkey=3
_(aPR,eRR)
return aPR
}
oLR.wxXCkey=4
_2z(z,293,cMR,e,s,gg,oLR,'item','index','index')
_(f1N,hKR)
var xUR=_mz(z,'u-popup',['bind:__l',305,'bind:input',1,'borderRadius',2,'class',3,'closeable',4,'data-event-opts',5,'mode',6,'value',7,'vueId',8,'vueSlots',9],[],e,s,gg)
_(f1N,xUR)
var l7N=_v()
_(f1N,l7N)
if(_oz(z,315,e,s,gg)){l7N.wxVkey=1
}
var oVR=_mz(z,'u-popup',['bind:__l',316,'bind:input',1,'borderRadius',2,'class',3,'closeable',4,'data-event-opts',5,'mode',6,'value',7,'vueId',8,'vueSlots',9,'width',10],[],e,s,gg)
_(f1N,oVR)
var fWR=_mz(z,'u-popup',['bind:__l',327,'bind:input',1,'borderRadius',2,'class',3,'closeable',4,'data-event-opts',5,'mode',6,'value',7,'vueId',8,'vueSlots',9,'width',10],[],e,s,gg)
var cXR=_v()
_(fWR,cXR)
if(_oz(z,338,e,s,gg)){cXR.wxVkey=1
var hYR=_mz(z,'tki-qrcode',['background',339,'bind:__l',1,'bind:result',2,'class',3,'data-event-opts',4,'data-ref',5,'foreground',6,'icon',7,'iconSize',8,'loadMake',9,'pdground',10,'size',11,'unit',12,'usingComponents',13,'val',14,'vueId',15],[],e,s,gg)
_(cXR,hYR)
}
cXR.wxXCkey=1
cXR.wxXCkey=3
_(f1N,fWR)
var oZR=_mz(z,'u-modal',['bind:__l',355,'bind:confirm',1,'bind:input',2,'cancelStyle',3,'class',4,'confirmColor',5,'confirmStyle',6,'confirmText',7,'data-event-opts',8,'showCancelButton',9,'title',10,'value',11,'vueId',12,'vueSlots',13],[],e,s,gg)
_(f1N,oZR)
c2N.wxXCkey=1
c2N.wxXCkey=3
h3N.wxXCkey=1
o4N.wxXCkey=1
c5N.wxXCkey=1
c5N.wxXCkey=3
o6N.wxXCkey=1
o6N.wxXCkey=3
l7N.wxXCkey=1
_(r,f1N)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_38";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_38();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/subPage/orderRel.wxml'] = [$gwx_XC_38, './pages/subPage/orderRel.wxml'];else __wxAppCode__['pages/subPage/orderRel.wxml'] = $gwx_XC_38( './pages/subPage/orderRel.wxml' );
	;__wxRoute = "pages/subPage/orderRel";__wxRouteBegin = true;__wxAppCurrentFile__="pages/subPage/orderRel.js";define("pages/subPage/orderRel.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
(global.webpackJsonp=global.webpackJsonp||[]).push([["pages/subPage/orderRel"],{122:function(e,t,i){"use strict";(function(e){i(5),n(i(4));var t=n(i(123));function n(e){return e&&e.__esModule?e:{default:e}}wx.__webpack_require_UNI_MP_PLUGIN__=i,e(t.default)}).call(this,i(1).createPage)},123:function(e,t,i){"use strict";i.r(t);var n=i(124),o=i(126);for(var s in o)"default"!==s&&function(e){i.d(t,e,(function(){return o[e]}))}(s);i(128),i(130);var a=i(17),r=Object(a.default)(o.default,n.render,n.staticRenderFns,!1,null,"891dd2f8",null,!1,n.components,void 0);r.options.__file="pages/subPage/orderRel.vue",t.default=r.exports},124:function(e,t,i){"use strict";i.r(t);var n=i(125);i.d(t,"render",(function(){return n.render})),i.d(t,"staticRenderFns",(function(){return n.staticRenderFns})),i.d(t,"recyclableRender",(function(){return n.recyclableRender})),i.d(t,"components",(function(){return n.components}))},125:function(e,t,i){"use strict";var n;i.r(t),i.d(t,"render",(function(){return o})),i.d(t,"staticRenderFns",(function(){return a})),i.d(t,"recyclableRender",(function(){return s})),i.d(t,"components",(function(){return n}));try{n={uSubsection:function(){return i.e("uview-ui/components/u-subsection/u-subsection").then(i.bind(null,932))},uIcon:function(){return i.e("uview-ui/components/u-icon/u-icon").then(i.bind(null,854))},uSearch:function(){return i.e("uview-ui/components/u-search/u-search").then(i.bind(null,925))},uEmpty:function(){return i.e("uview-ui/components/u-empty/u-empty").then(i.bind(null,868))},uPopup:function(){return i.e("uview-ui/components/u-popup/u-popup").then(i.bind(null,939))},uInput:function(){return Promise.all([i.e("common/vendor"),i.e("uview-ui/components/u-input/u-input")]).then(i.bind(null,910))},uField:function(){return i.e("uview-ui/components/u-field/u-field").then(i.bind(null,946))},tkiQrcode:function(){return Promise.all([i.e("common/vendor"),i.e("components/tki-qrcode/tki-qrcode")]).then(i.bind(null,953))},uModal:function(){return i.e("uview-ui/components/u-modal/u-modal").then(i.bind(null,961))}}}catch(e){if(-1===e.message.indexOf("Cannot find module")||-1===e.message.indexOf(".vue"))throw e;console.error(e.message),console.error("1. 排查组件名称拼写是否正确"),console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"),console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件")}var o=function(){var e=this,t=(e.$createElement,e._self._c,e.__map(e.orderData,(function(t,i){return{$orig:e.__get_orig(t),l0:t.orderRemarks.length||t.orderRefundRemarks?e.__map(t.orderRemarks,(function(i,n){return{$orig:e.__get_orig(i),g0:2==t.salesStatus&&i.remarkValue.includes("#退款备注#")&&0==e.typeIds,g1:4==t.salesStatus&&i.remarkValue.includes("#退款备注#")&&0==e.typeIds,g2:5==t.salesStatus&&i.remarkValue.includes("#退款备注#")&&0==e.typeIds,g3:i.remarkValue.includes("#退款备注#")&&2==i.remarkType&&1==e.typeIds}})):null}})));e._isMounted||(e.e0=function(t){e.openSaixuan=!0},e.e1=function(t){e.openSaixuanTi=!0},e.e2=function(t){e.showRemark=!1},e.e3=function(t){e.showRefund=!1},e.e4=function(t){e.showRemarkLoc=!1}),e.$mp.data=Object.assign({},{$root:{l1:t}})},s=!1,a=[];o._withStripped=!0},126:function(e,t,i){"use strict";i.r(t);var n=i(127),o=i.n(n);for(var s in n)"default"!==s&&function(e){i.d(t,e,(function(){return n[e]}))}(s);t.default=o.a},127:function(e,t,i){"use strict";(function(e){Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var n=function(e){return e&&e.__esModule?e:{default:e}}(i(61)),o={data:function(){var e=n.default.getDefaulDate({format:!0});return{confirmData:{data:{},idx:0},showGoPay:!1,searchContent:"",isQuxiao:0,qrCodeVal:"2022",showQrcode:!1,showWecont:!1,firstComming:!0,date:e,dateTwo:e,saixuanName:"全部团购",saixuanTime:"全部日期",startTiTe:"开始时间",endTiTe:"结束时间",isDiyTi:!1,showRemarkLoc:!1,logisticsName:"",logisticsId:"",cStyle:{fontSize:"26rpx"},showRefund:!1,remarkRefund:"",page:1,showRemark:!1,remarkVa:"",orderStatus:0,orderStatusSai:0,orderStatusSaiTi:0,finished:!1,loading:!1,noData:!1,loadingText:"上拉可加载更多~",orderData:[],typeArray:[{name:"自购订单"},{name:"售卖订单"}],typeIds:0,tagArray:["全部","待发货","已发货","待退款","已退款","待确认收货","核销发货"],orderStatuTe:["未知","待支付","已支付","支付失败","支付中","已支付","已发货","已完成"],remarkType:["","商家备注","用户备注","退款备注"],editId:0,userInfoHome:{},tagArraySai:["全部","我发布的","我帮卖的"],tagArraySaiTi:["全部","今日","昨日","本周"],openSaixuan:!1,openSaixuanTi:!1,listSai:[{activityId:0,activityName:"全部团购",createTime:""}],listSaiId:0,qiniuInfo:{}}},onShow:function(){var t=getApp().globalData.orderStatus;t&&(this.orderStatus=t,this.page=1,this.typeIds=1,this.orderData=[],this.getOrderList(),getApp().globalData.orderStatus=0);var i=e.getStorageSync("userInfo");return console.log("Order-==onLoad",i),2==i.userType&&1==this.userInfoHome.userType?(Object.assign(this.$data,this.$options.data()),this.userInfoHome=i,this.typeIds=1,this.getOrderList(),this.countOrderSum(),this.getQiniuToken(),!1):1==i.userType&&2==this.userInfoHome.userType?(Object.assign(this.$data,this.$options.data()),this.userInfoHome=i,this.getOrderList(),this.countOrderSum(),this.getQiniuToken(),!1):void 0},onLoad:function(){var t=this;this.userInfoHome=e.getStorageSync("userInfo"),this.firstComming=e.getStorageSync("firstComming")||!1,console.log("Order-==onLoad",this.userInfoHome),e.hideShareMenu({});var i=this;if(2==this.userInfoHome.userType)return this.typeIds=1,this.opearatReLogin(),setTimeout((function(e){console.log("副团长登录免再登录",t.userInfoHome),t.getOrderList(),t.countOrderSum(),t.getQiniuToken()}),800),!1;var n=getCurrentPages();console.log("非小程序进入跳转页==",n),n.length>1?(this.userInfoHome.focusWechat||(i.showWecont=!0),i.getOrderList(),i.countOrderSum(),i.getQiniuToken()):wx.login({success:function(t){t.code&&i.$server.login({agentId:i.$agentId,code:t.code}).then((function(t){i.userInfoHome=t,e.setStorageSync("userInfo",t),i.getOrderList(),i.countOrderSum(),i.getQiniuToken(),i.userInfoHome.focusWechat||(i.showWecont=!0)}))}})},onReachBottom:function(){console.log("this.finished==",this.finished),this.finished||(this.page++,this.getOrderList())},computed:{startDate:function(){return n.default.getDefaulDate("start")},endDate:function(){return n.default.getDefaulDate("end")}},methods:{getLoctions:function(t){var i=this;e.getLocation({type:"gcj02",isHighAccuracy:!0,success:function(n){console.log("当前位置的经度："+n.longitude),console.log("当前位置的纬度："+n.latitude),i.$server.operRptLocation({activityId:t.activityId,longitude:n.longitude,latitude:n.latitude}).then((function(t){0==t.code?e.showToast({title:"已同步",icon:"success"}):e.showToast({title:t.message,icon:"none"})}))},fail:function(t){e.showToast({title:"获取位置失败，请检查是否打开或授权位置信息或稍后重试",icon:"none",duration:2500})}})},searchFuns:function(e){console.log("搜索内容==",e),this.page=1,this.noData&&(this.noData=!1),this.finished&&(this.finished=!1),this.orderData=[],this.getOrderList()},copyText:function(t){e.setClipboardData({data:t,success:function(){e.showToast({title:"单号复制成功",icon:"success"})}})},goKefu:function(){e.navigateTo({url:"../subPage/groupListKf"})},qrR:function(e){console.log("qrr",e)},creatQrcode:function(e){var t=this;this.qrCodeVal=e.buyUserId+","+e.orderId,this.showQrcode=!0,setTimeout((function(e){t.$refs.qrcode._makeCode()}),100)},goPage:function(t){this.showWecont=!1,e.navigateTo({url:"./"+t})},firstClose:function(){this.firstComming=!0,e.setStorageSync("firstComming",this.firstComming)},timeQuerys:function(){this.page=1,this.noData&&(this.noData=!1),this.finished&&(this.finished=!1),this.orderData=[],this.isDiyTi?this.saixuanTime="　".concat(this.date,"\n~").concat(this.dateTwo):this.orderStatusSaiTi>0?(n.default.getStarEndDate(this.orderStatusSaiTi),this.saixuanTime=this.tagArraySaiTi[this.orderStatusSaiTi]):this.saixuanTime="全部日期",this.getOrderList(),this.openSaixuanTi=!1},bindDateChange:function(e){this.date=e.target.value,this.startTiTe=e.target.value,!this.isDiyTi&&(this.isDiyTi=!0),"结束时间"==this.endTiTe&&(this.dateTwo=e.target.value,this.endTiTe=e.target.value),this.orderStatusSaiTi<4&&(this.orderStatusSaiTi=5)},bindDateChangeTwo:function(e){console.log("结束时间",e),this.dateTwo=e.target.value,this.endTiTe=e.target.value,!this.isDiyTi&&(this.isDiyTi=!0),"开始时间"==this.startTiTe&&(this.date=e.target.value,this.startTiTe=e.target.value),this.orderStatusSaiTi<4&&(this.orderStatusSaiTi=5)},actNameList:function(){var t=this,i={dataType:this.orderStatusSai,page:1,pageSize:100};this.$server.actNameList(i).then((function(i){0==i.code?t.listSai=t.listSai.concat(i.data):e.showToast({title:i.message,icon:"none"})}))},goLosis:function(t){e.navigateTo({url:"../pageRelay/logisticsList?id="+t.logisticsId+"&name="+t.logisticsName+"&tm="+t.createTime})},goShow:function(t){e.navigateTo({url:"./showRel?id="+t})},goDetail:function(t){e.navigateTo({url:"../pageRelay/orderDetail?id="+t+"&type="+this.typeIds})},scanNum:function(){var t=this;e.scanCode({success:function(e){t.logisticsId=e.result,t.queryCpName()},fail:function(t){e.showToast({title:"扫码失败",icon:"none"}),console.log("失败",t)}})},queryCpName:function(){var e=this;this.$server.queryCpName({logisticsId:this.logisticsId}).then((function(t){0==t.code&&(e.logisticsName=t.data.cpName)}))},checkStaus:function(t){if(t>5)return e.navigateTo({url:"../pageRelay/cancelRel"}),!1;this.orderStatus=t,this.page=1,this.noData&&(this.noData=!1),this.finished&&(this.finished=!1),this.orderData=[],this.getOrderList()},checkStausSai:function(e){this.orderStatusSai=e,this.listSai=[{activityId:0,activityName:"全部团购",createTime:""}],this.actNameList()},checkStausSaiTi:function(e){this.orderStatusSaiTi=e,this.isDiyTi&&(this.isDiyTi=!this.isDiyTi)},checkTypes:function(e){this.typeIds=e,this.searchContent="",this.page=1,this.noData&&(this.noData=!1),this.finished&&(this.finished=!1),this.orderData=[],this.getOrderList(),this.actNameList(),this.countOrderSum()},checkActName:function(e){if(this.listSaiId==e.activityId)return this.openSaixuan=!1,!1;this.listSaiId=e.activityId,this.page=1,this.noData&&(this.noData=!1),this.finished&&(this.finished=!1),this.orderData=[],this.getOrderList(),this.openSaixuan=!1,e.activityName.length<7?this.saixuanName=e.activityName:this.saixuanName=e.activityName.slice(0,6)+"..."},sureLocs:function(){var t=this;this.$server.confirmGoods({orderId:this.confirmData.data.orderId}).then((function(i){0==i.code?(e.showToast({title:"签收成功",icon:"none"}),t.orderData[t.confirmData.idx].freezeFlag=3,t.confirmData={data:{},idx:0}):e.showToast({title:i.message,icon:"none"})}))},confirmLoc:function(e,t){this.confirmData={data:e,idx:t},this.showGoPay=!0},confirmLocYanc:function(t,i){if(!t.gapConfirmTime)return e.showToast({title:"亲，距离结束时间3天才可以申请哦",icon:"none",duration:2500}),!1;if(null!=t.receivingTime)return e.showToast({title:"您已延长收货，每笔订单只能延迟一次",icon:"none",duration:2500}),!1;var n=this;e.showModal({title:"",content:"确认延长收货时间？每笔订单只能延迟一次（默认5天自动确认收货，延长增加5天）",confirmText:"确认",confirmColor:"#07c160",cancelColor:"#999",success:function(o){o.confirm?n.$server.setRecerTime({orderId:t.orderId}).then((function(t){0==t.code?(e.showToast({title:"延长成功",icon:"none"}),n.orderData[i].receivingTime="已收货"):e.showToast({title:t.message,icon:"none"})})):o.cancel&&console.log("用户点击取消")}})},showRemarkFu:function(e,t){this.showRemark=!0,this.editId=e},showRefundFu:function(t,i){if(this.editId=t,i){this.isQuxiao=1;var n=this;e.showModal({title:"是否确认取消退款",content:"",confirmText:"确认",success:function(e){e.confirm?n.editRefund():e.cancel&&(n.isQuxiao=0,console.log("用户点击取消"))}})}else this.isQuxiao=0,this.showRefund=!0},goRefund:function(t,i){e.navigateTo({url:"../pageRelay/orderRefund?item="+encodeURIComponent(JSON.stringify(t))})},goMaps:function(t){console.log("goMaps==",t),e.navigateTo({url:"../pageRelay/showMap?item="+encodeURIComponent(JSON.stringify(t))})},goActorder:function(t,i){t.superActivityUserId?e.navigateTo({url:"../pageRelay/activityOrder?id="+t.activityId+"&sid="+t.superActivityUserId}):e.navigateTo({url:"../pageRelay/activityOrder?id="+t.activityId})},noRefund:function(t){var i=this;e.showModal({title:"是否确认拒绝退款",content:"",confirmText:"确认",success:function(n){n.confirm?i.$server.refuseRefund({orderId:t.orderId}).then((function(t){0==t.code?e.showToast({title:"已拒绝退款",icon:"success"}):e.showToast({title:t.message,icon:"none"})})):n.cancel&&console.log("用户点击取消")}})},showRemarkLocFu:function(e,t){console.log("orderId==",e),this.showRemarkLoc=!0,this.editId=e},editRemarkLoc:function(){var t=this,i={orderId:this.orderData[this.editId].orderId,logisticsId:this.logisticsId,logisticsName:this.logisticsName};this.$server.modifyLogistics(i).then((function(n){0==n.code?(e.showToast({title:"标记发货成功",icon:"success"}),t.orderData[t.editId].orderLogistics.push(i),t.showRemarkLoc=!1):e.showToast({title:n.message,icon:"none"})}))},editRemark:function(){var t=this,i={orderId:this.orderData[this.editId].orderId,remarkValue:this.remarkVa};0==this.typeIds?i.remarkType=2:i.remarkType=1,this.$server.addRemark(i).then((function(n){if(0==n.code){e.showToast({title:"备注成功",icon:"success"});var o={remarkType:i.remarkType,remarkValue:t.remarkVa};t.orderData[t.editId].orderRemarks.push(o),t.showRemark=!1}else e.showToast({title:n.message,icon:"none"})}))},editRefund:function(){var t=this,i={orderId:this.orderData[this.editId].orderId,remarkValue:this.remarkRefund};this.isQuxiao?i.operatType=2:i.operatType=1,this.$server.applyRefund(i).then((function(i){if(0==i.code){if(t.isQuxiao)e.showToast({title:"取消退款成功",icon:"success"}),t.orderData[t.editId].salesStatus=i.data.salesStatus;else{e.showToast({title:"申请退款成功",icon:"success"});var n={remarkType:3,remarkValue:t.remarkRefund};t.orderData[t.editId].orderRemarks.push(n),t.orderData[t.editId].salesStatus=i.data.salesStatus}t.showRefund=!1}else e.showToast({title:i.message,icon:"none"})}))},countOrderSum:function(t){var i=this,n={userType:this.typeIds+1};this.$server.countOrderSum(n).then((function(t){if(0==t.code){var n=JSON.parse(JSON.stringify(i.tagArray));n[1]="待发货(".concat(t.data.unShipCount,")"),n[2]="已发货(".concat(t.data.shippedCount,")"),n[3]="待退款(".concat(t.data.unRefundCount,")"),n[4]="已退款(".concat(t.data.refundCount,")"),i.tagArray=n}else e.showToast({title:t.message,icon:"none"})}))},getOrderList:function(t,i){var o=this;e.showLoading({title:"加载中",mask:!0});var s={page:this.page,pageSize:5};if(this.orderStatus&&(5==this.orderStatus?s.orderStatus=8:s.orderStatus=this.orderStatus),1==this.typeIds)if(this.isDiyTi)s.startDate=this.date,s.endDate=this.dateTwo;else if(this.orderStatusSaiTi>0){var a=n.default.getStarEndDate(this.orderStatusSaiTi);s.startDate=a.startDate,s.endDate=a.endDate}this.searchContent&&(s.searchContent=this.searchContent),this.listSaiId&&(s.activityId=this.listSaiId),s.userType=this.typeIds+1,this.$server.queryOrderList(s).then((function(t){if(0==t.code){if(1==o.page&&0==t.data.length)return o.orderData=[],o.noData=!0,o.loading=!1,o.finished=!0,setTimeout((function(t){e.hideLoading()}),200),void console.log("无数据");t.data.length<5&&(o.loading=!1,o.finished=!0,console.log("无数据"));var i=t.data.map((function(e){return e.orderAddrs.forEach((function(e){2==e.contentType&&(e.yrjarr=e.columnValue.split(","))})),e.payPriceShow=n.default.centTurnSmacker(e.payPrice/100),e.shipFeeMoney&&(e.shipFeeMoneyShow=n.default.centTurnSmacker(e.shipFeeMoney/100),e.refundShipFeeMoneyShow=n.default.centTurnSmacker(e.refundShipFeeMoney/100),e.shipFeeMoneySh=n.default.centTurnSmacker((e.shipFeeMoney-e.refundShipFeeMoney)/100),e.shipFeeMoneyInp=n.default.centTurnSmacker((e.shipFeeMoney-e.refundShipFeeMoney)/100)),e.createTimeShow=e.createTime.slice(0,16),e.isPick=!0,e.nickName&&e.nickName.length>7&&(e.nickName=e.nickName.slice(0,7)+"..."),e.commodityDetais.forEach((function(e){e.isPick=!0,e.commodityPriceShow=n.default.centTurnSmacker(e.commodityPrice/100),e.commodityCountTo=1,e.refundCountSh=e.commodityCount-e.refundCount,e.commodityCountSh=e.commodityCount-e.verifyCount,e.refundMoneySh=n.default.centTurnSmacker((e.totalPrice-e.refundMoney)/100),e.refundMoneyInp=n.default.centTurnSmacker((e.totalPrice-e.refundMoney)/100)})),e}));o.orderData=o.orderData.concat(i),e.hideLoading()}else e.hideLoading(),e.showToast({title:t.message,icon:"none"})}))},getQiniuToken:function(){var t=this;this.$server.qiniuToken({}).then((function(i){"0"==i.code?(t.qiniuInfo=i.data,e.setStorageSync("qiniuInfo",i.data)):console.log("qiniu==",i)}))},imgDelivery:function(t,i){var n=this,o=this.qiniuInfo;e.chooseImage({count:1,sizeType:["compressed"],sourceType:["camera","album"],success:function(s){e.showLoading({title:"上传中"});for(var a=s.tempFilePaths[0],r="."+a.split(".")[1],u="",c=0;c<18;c++)u+="abcdefghijkmnpqrstvwxyz1234567890".charAt(Math.floor(32*Math.random()));u=o.imgFolderPath+u+r,e.uploadFile({url:"https://up-z2.qiniup.com",filePath:a,name:"file",formData:{key:u,token:o.uploadToken},success:function(e){console.log("uploadFileRes",e);var s=o.urlPrefix+u;console.log("imgUrl===",s),n.upDelivery(t,i,s)},complete:function(t){e.hideLoading()}})}})},upDelivery:function(t,i,n){var o=this;console.log("upDelivery==",t,n);var s={orderId:t.orderId,imgs:n};this.$server.addDeliverImgs(s).then((function(t){0==t.code?(o.orderData[i].deliverImgs.push(n),e.showToast({title:"已成功上传",icon:"success"})):e.showToast({title:"上传失败，请重试",icon:"none"})}))}}};t.default=o}).call(this,i(1).default)},128:function(e,t,i){"use strict";i.r(t);var n=i(129),o=i.n(n);for(var s in n)"default"!==s&&function(e){i.d(t,e,(function(){return n[e]}))}(s);t.default=o.a},129:function(e,t,i){},130:function(e,t,i){"use strict";i.r(t);var n=i(131),o=i.n(n);for(var s in n)"default"!==s&&function(e){i.d(t,e,(function(){return n[e]}))}(s);t.default=o.a},131:function(e,t,i){}},[[122,"common/runtime","common/vendor"]]]);
},{isPage:true,isComponent:true,currentFile:'pages/subPage/orderRel.js'});require("pages/subPage/orderRel.js");