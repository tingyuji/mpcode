$gwx_XC_35=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_35 || [];
function gz$gwx_XC_35_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_35_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_35_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_35_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'pay_bill data-v-154929f7'])
Z([3,'__l'])
Z([3,'__e'])
Z(z[2])
Z([3,'data-v-154929f7'])
Z([[4],[[5],[[5],[[4],[[5],[[5],[1,'^confirmEvent']],[[4],[[5],[[4],[[5],[1,'confirmEvent']]]]]]]],[[4],[[5],[[5],[1,'^updateMoney']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'__set_sync']],[[4],[[5],[[5],[[5],[1,'$0']],[1,'ipnutNum']],[1,'$event']]]],[[4],[[5],[1,'']]]]]]]]]]])
Z([[7],[3,'ipnutNum']])
Z([3,'确认支付'])
Z([3,'d846d422-1'])
Z(z[1])
Z([3,'data-v-154929f7 vue-ref'])
Z([3,'uToast'])
Z([3,'d846d422-2'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_35_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_35_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_35=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_35=true;
var x=['./pages/subPage/merchanTpay.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_35_1()
var c7L=_n('view')
_rz(z,c7L,'class',0,e,s,gg)
var o8L=_mz(z,'open-keyboard',['bind:__l',1,'bind:confirmEvent',1,'bind:updateMoney',2,'class',3,'data-event-opts',4,'money',5,'title',6,'vueId',7],[],e,s,gg)
_(c7L,o8L)
var l9L=_mz(z,'u-toast',['bind:__l',9,'class',1,'data-ref',2,'vueId',3],[],e,s,gg)
_(c7L,l9L)
_(r,c7L)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_35";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_35();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/subPage/merchanTpay.wxml'] = [$gwx_XC_35, './pages/subPage/merchanTpay.wxml'];else __wxAppCode__['pages/subPage/merchanTpay.wxml'] = $gwx_XC_35( './pages/subPage/merchanTpay.wxml' );
	;__wxRoute = "pages/subPage/merchanTpay";__wxRouteBegin = true;__wxAppCurrentFile__="pages/subPage/merchanTpay.js";define("pages/subPage/merchanTpay.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
(global.webpackJsonp=global.webpackJsonp||[]).push([["pages/subPage/merchanTpay"],{234:function(e,n,t){"use strict";(function(e){t(5),o(t(4));var n=o(t(235));function o(e){return e&&e.__esModule?e:{default:e}}wx.__webpack_require_UNI_MP_PLUGIN__=t,e(n.default)}).call(this,t(1).createPage)},235:function(e,n,t){"use strict";t.r(n);var o=t(236),r=t(238);for(var a in r)"default"!==a&&function(e){t.d(n,e,(function(){return r[e]}))}(a);t(240);var c=t(17),i=Object(c.default)(r.default,o.render,o.staticRenderFns,!1,null,"154929f7",null,!1,o.components,void 0);i.options.__file="pages/subPage/merchanTpay.vue",n.default=i.exports},236:function(e,n,t){"use strict";t.r(n);var o=t(237);t.d(n,"render",(function(){return o.render})),t.d(n,"staticRenderFns",(function(){return o.staticRenderFns})),t.d(n,"recyclableRender",(function(){return o.recyclableRender})),t.d(n,"components",(function(){return o.components}))},237:function(e,n,t){"use strict";var o;t.r(n),t.d(n,"render",(function(){return r})),t.d(n,"staticRenderFns",(function(){return c})),t.d(n,"recyclableRender",(function(){return a})),t.d(n,"components",(function(){return o}));try{o={openKeyboard:function(){return t.e("components/open-keyboard/open-keyboard").then(t.bind(null,1048))},uToast:function(){return t.e("uview-ui/components/u-toast/u-toast").then(t.bind(null,1055))}}}catch(e){if(-1===e.message.indexOf("Cannot find module")||-1===e.message.indexOf(".vue"))throw e;console.error(e.message),console.error("1. 排查组件名称拼写是否正确"),console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"),console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件")}var r=function(){this.$createElement,this._self._c},a=!1,c=[];r._withStripped=!0},238:function(e,n,t){"use strict";t.r(n);var o=t(239),r=t.n(o);for(var a in o)"default"!==a&&function(e){t.d(n,e,(function(){return o[e]}))}(a);n.default=r.a},239:function(e,n,t){"use strict";(function(e){Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0,function(e){e&&e.__esModule}(t(61));var o={data:function(){return{ipnutNum:"",customStyle:{width:"138rpx",height:"52rpx",backgroundColor:"#d63f1c",color:"#ffffff",border:"none"},fieldStyle:{fontSize:"40rpx",fontFamily:"Alibaba-PuHuiTi-M",letterSpacing:"2rpx",opacity:"1 !important"},shopDataEle:{},moneyNum:"",reteNum:0,merchantQrcode:"",authCode:""}},computed:{},onLoad:function(n){var t=decodeURIComponent(n.q);console.log("option====option",t);var o=t.split("code=")[1],r=e.getStorageSync("userInfo")||{};if(console.log("首页业务员接受参数",r),2==r.userType)this.opearatReLogin();else{var a=this;wx.login({success:function(n){n.code&&a.$server.login({agentId:a.$agentId,code:n.code}).then((function(n){var t=n;console.log("支付页登录1==",n),e.setStorageSync("userInfo",t)}))}})}o?(this.merchantQrcode=o,this.getShops()):e.showToast({title:"抱歉，未查询到该商家",icon:"none"}),console.log("详情",this.merchantQrcode)},methods:{ceshi:function(){e.navigateTo({url:"./person?num="+this.ipnutNum})},confirmEvent:function(n){var t=this;e.showLoading({title:"加载中.."}),wx.login({success:function(e){e.code&&(t.authCode=e.code,t.buyOrder())}})},getShops:function(){var n=this;if(!this.merchantQrcode)return!1;var t={merchantQrcode:this.merchantQrcode};this.$server.nologinMerchantInfo(t).then((function(t){0==t.code?n.shopDataEle=t.data:(e.showToast({title:"抱歉，未查询到该商家",icon:"none"}),setTimeout((function(){}),1e3))}))},countNum:function(e){var n=(e*this.shopDataEle.userRebatePercent/100).toFixed(2);console.log("输入值==",n),this.reteNum=n},buyOrder:function(){var n=this,t={agentId:"3178413606",merchantCode:this.shopDataEle.merchantCode,goodsDesc:this.shopDataEle.shopName,payChannel:2,payType:3,payAmount:1*(100*this.ipnutNum).toFixed(0),appId:"wxdc54870ccdbfba31",authCode:this.authCode};this.$server.createRecOrder(t).then((function(t){if(e.hideLoading(),0==t.code){var o=n,r=t.data.orderId;e.requestPayment({provider:"weixin",orderInfo:r,timeStamp:t.data.payInfo.timeStamp,nonceStr:t.data.payInfo.nonceStr,package:t.data.payInfo.package,signType:t.data.payInfo.signType,paySign:t.data.payInfo.paySign,success:function(e){console.log("success:"+JSON.stringify(e))},fail:function(e){console.log("fail:"+JSON.stringify(e))},complete:function(e){console.log("complete:"+e),console.log("数据==:"+t),o.queryStatus(r)}})}else n.$refs.uToast.show({title:"支付失败",type:"warning"})}))},queryStatus:function(n){var t=this,o={orderId:n};this.$server.queryRecOrderStatus(o).then((function(o){0==o.code&&3==o.data.orderStatus?(t.$refs.uToast.show({title:"支付成功",type:"success"}),setTimeout((function(){e.reLaunch({url:"./welfare?moid="+n})}),500)):t.$refs.uToast.show({title:"支付失败，请重试",type:"warning"})}))}}};n.default=o}).call(this,t(1).default)},240:function(e,n,t){"use strict";t.r(n);var o=t(241),r=t.n(o);for(var a in o)"default"!==a&&function(e){t.d(n,e,(function(){return o[e]}))}(a);n.default=r.a},241:function(e,n,t){}},[[234,"common/runtime","common/vendor"]]]);
},{isPage:true,isComponent:true,currentFile:'pages/subPage/merchanTpay.js'});require("pages/subPage/merchanTpay.js");