$gwx_XC_42=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_42 || [];
function gz$gwx_XC_42_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_42_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_42_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_42_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_42_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_42_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_42=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_42=true;
var x=['./pages/subPage/topUp.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_42_1()
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_42";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_42();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/subPage/topUp.wxml'] = [$gwx_XC_42, './pages/subPage/topUp.wxml'];else __wxAppCode__['pages/subPage/topUp.wxml'] = $gwx_XC_42( './pages/subPage/topUp.wxml' );
	;__wxRoute = "pages/subPage/topUp";__wxRouteBegin = true;__wxAppCurrentFile__="pages/subPage/topUp.js";define("pages/subPage/topUp.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
(global.webpackJsonp=global.webpackJsonp||[]).push([["pages/subPage/topUp"],{104:function(t,n,e){"use strict";(function(t){e(5),o(e(4));var n=o(e(105));function o(t){return t&&t.__esModule?t:{default:t}}wx.__webpack_require_UNI_MP_PLUGIN__=e,t(n.default)}).call(this,e(1).createPage)},105:function(t,n,e){"use strict";e.r(n);var o=e(106),a=e(108);for(var i in a)"default"!==i&&function(t){e.d(n,t,(function(){return a[t]}))}(i);e(110),e(112);var u=e(17),r=Object(u.default)(a.default,o.render,o.staticRenderFns,!1,null,"3d899a07",null,!1,o.components,void 0);r.options.__file="pages/subPage/topUp.vue",n.default=r.exports},106:function(t,n,e){"use strict";e.r(n);var o=e(107);e.d(n,"render",(function(){return o.render})),e.d(n,"staticRenderFns",(function(){return o.staticRenderFns})),e.d(n,"recyclableRender",(function(){return o.recyclableRender})),e.d(n,"components",(function(){return o.components}))},107:function(t,n,e){"use strict";e.r(n),e.d(n,"render",(function(){return o})),e.d(n,"staticRenderFns",(function(){return i})),e.d(n,"recyclableRender",(function(){return a})),e.d(n,"components",(function(){}));var o=function(){this.$createElement,this._self._c},a=!1,i=[];o._withStripped=!0},108:function(t,n,e){"use strict";e.r(n);var o=e(109),a=e.n(o);for(var i in o)"default"!==i&&function(t){e.d(n,t,(function(){return o[t]}))}(i);n.default=a.a},109:function(t,n,e){"use strict";(function(t){Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var o=function(t){return t&&t.__esModule?t:{default:t}}(e(61)),a={data:function(){return{balanceNum:1,totalMou:"",shuNiang:"",showNum:0,payAmount:0}},onShow:function(){t.hideShareMenu({})},onLoad:function(){this.getBalance()},methods:{chageNums:function(){var t;this.totalMou?(t=Math.ceil(100*this.totalMou*(this.balanceNum/100)),console.log("手续费===",t,this.balanceNum),this.payAmount=(100*this.totalMou+t).toFixed(0),this.showNum=o.default.centTurnSmacker(this.payAmount/100)):this.showNum="0.00"},goPage:function(n){t.navigateTo({url:"./topUp"})},gobacks:function(){var n={logisticsWay:this.pickId},e=(encodeURIComponent(JSON.stringify(n)),getCurrentPages());e[e.length-2].$vm.otherFun(n),t.navigateBack()},surePay:function(){var n=this;if(100*this.totalMou==0)return t.showToast({title:"最低充值金额为1分",icon:"none"}),!1;t.showLoading({title:"请求中",mask:!0});var e=(100*this.totalMou).toFixed(0),o={goodsName:"充值",payAmount:this.payAmount,appType:"3",payType:"4",businessType:"1",arriveAmount:e};this.$server.createOrder(o).then((function(e){if(0==e.code){var o=n,a=e.data.orderId;t.hideLoading(),t.requestPayment({provider:"weixin",orderInfo:a,timeStamp:e.data.payInfo.timeStamp,nonceStr:e.data.payInfo.nonceStr,package:e.data.payInfo.packageValue,signType:e.data.payInfo.signType,paySign:e.data.payInfo.paySign,success:function(t){console.log("success:"+JSON.stringify(t))},fail:function(n){console.log("fail:"+JSON.stringify(n)),t.showToast({title:"支付失败",icon:"none"})},complete:function(t){console.log("complete:"+t),console.log("数据==:"+e),o.queryStatus(a)}})}else t.showToast({title:e.message,icon:"none"})}))},queryStatus:function(n){var e={orderId:n};this.$server.queryOrderStatus(e).then((function(n){0==n.code&&2==n.data.orderStatus?(t.showToast({title:"支付成功",icon:"success"}),setTimeout((function(){t.navigateBack()}),1e3)):t.showToast({title:"支付失败，请稍后重试",icon:"none"})}))},getBalance:function(){var n=this;this.$server.queryTradeRate({type:1}).then((function(e){0==e.code?(n.balanceNum=100*e.data.tradeRate,(n.balanceNum+"").length>4&&(n.balanceNum=n.balanceNum.toFixed(2))):t.showToast({title:e.message,icon:"none"})}))}}};n.default=a}).call(this,e(1).default)},110:function(t,n,e){"use strict";e.r(n);var o=e(111),a=e.n(o);for(var i in o)"default"!==i&&function(t){e.d(n,t,(function(){return o[t]}))}(i);n.default=a.a},111:function(t,n,e){},112:function(t,n,e){"use strict";e.r(n);var o=e(113),a=e.n(o);for(var i in o)"default"!==i&&function(t){e.d(n,t,(function(){return o[t]}))}(i);n.default=a.a},113:function(t,n,e){}},[[104,"common/runtime","common/vendor"]]]);
},{isPage:true,isComponent:true,currentFile:'pages/subPage/topUp.js'});require("pages/subPage/topUp.js");