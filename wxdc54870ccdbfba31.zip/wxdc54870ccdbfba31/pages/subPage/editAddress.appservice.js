$gwx_XC_29=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_29 || [];
function gz$gwx_XC_29_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_29_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_29_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_29_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'data-v-260a14fe'])
Z([3,'addInfo-box data-v-260a14fe'])
Z([3,'top_input data-v-260a14fe'])
Z([3,'__l'])
Z([3,'__e'])
Z([3,'addInput-li data-v-260a14fe'])
Z([[4],[[5],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'$0']],[1,'userName']],[1,'$event']],[[4],[[5]]]]]],[[4],[[5],[1,'addressInfo']]]]]]]]]]])
Z([3,'姓名'])
Z([3,'20'])
Z([3,'请输入收货人姓名'])
Z([[6],[[7],[3,'addressInfo']],[3,'userName']])
Z([3,'9b3788b6-1'])
Z(z[3])
Z(z[4])
Z(z[5])
Z([[4],[[5],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'$0']],[1,'userMobile']],[1,'$event']],[[4],[[5]]]]]],[[4],[[5],[1,'addressInfo']]]]]]]]]]])
Z([3,'电话'])
Z([3,'请输入收货人电话'])
Z([3,'number'])
Z([[6],[[7],[3,'addressInfo']],[3,'userMobile']])
Z([3,'9b3788b6-2'])
Z(z[3])
Z(z[4])
Z([1,false])
Z(z[5])
Z([[4],[[5],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'$0']],[1,'address']],[1,'$event']],[[4],[[5]]]]]],[[4],[[5],[1,'addressInfo']]]]]]]]]]])
Z([3,'详细地址'])
Z([3,'请输入收货详细地址'])
Z([[6],[[7],[3,'addressInfo']],[3,'address']])
Z([3,'9b3788b6-3'])
Z([[6],[[7],[3,'addressInfo']],[3,'id']])
Z(z[3])
Z(z[4])
Z(z[4])
Z(z[0])
Z([[4],[[5],[[5],[[4],[[5],[[5],[1,'^confirm']],[[4],[[5],[[4],[[5],[1,'confirms']]]]]]]],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'chooseCityBox']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z([3,'region'])
Z([[7],[3,'chooseCityBox']])
Z([3,'9b3788b6-4'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_29_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_29_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_29=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_29=true;
var x=['./pages/subPage/editAddress.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_29_1()
var oBJ=_n('view')
_rz(z,oBJ,'class',0,e,s,gg)
var fCJ=_n('view')
_rz(z,fCJ,'class',1,e,s,gg)
var hEJ=_n('view')
_rz(z,hEJ,'class',2,e,s,gg)
var oFJ=_mz(z,'u-field',['bind:__l',3,'bind:input',1,'class',2,'data-event-opts',3,'label',4,'maxlength',5,'placeholder',6,'value',7,'vueId',8],[],e,s,gg)
_(hEJ,oFJ)
var cGJ=_mz(z,'u-field',['bind:__l',12,'bind:input',1,'class',2,'data-event-opts',3,'label',4,'placeholder',5,'type',6,'value',7,'vueId',8],[],e,s,gg)
_(hEJ,cGJ)
var oHJ=_mz(z,'u-field',['bind:__l',21,'bind:input',1,'borderBottom',2,'class',3,'data-event-opts',4,'label',5,'placeholder',6,'value',7,'vueId',8],[],e,s,gg)
_(hEJ,oHJ)
_(fCJ,hEJ)
var cDJ=_v()
_(fCJ,cDJ)
if(_oz(z,30,e,s,gg)){cDJ.wxVkey=1
}
cDJ.wxXCkey=1
_(oBJ,fCJ)
var lIJ=_mz(z,'u-picker',['bind:__l',31,'bind:confirm',1,'bind:input',2,'class',3,'data-event-opts',4,'mode',5,'value',6,'vueId',7],[],e,s,gg)
_(oBJ,lIJ)
_(r,oBJ)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_29";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_29();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/subPage/editAddress.wxml'] = [$gwx_XC_29, './pages/subPage/editAddress.wxml'];else __wxAppCode__['pages/subPage/editAddress.wxml'] = $gwx_XC_29( './pages/subPage/editAddress.wxml' );
	;__wxRoute = "pages/subPage/editAddress";__wxRouteBegin = true;__wxAppCurrentFile__="pages/subPage/editAddress.js";define("pages/subPage/editAddress.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
(global.webpackJsonp=global.webpackJsonp||[]).push([["pages/subPage/editAddress"],{168:function(e,n,o){"use strict";(function(e){o(5),t(o(4));var n=t(o(169));function t(e){return e&&e.__esModule?e:{default:e}}wx.__webpack_require_UNI_MP_PLUGIN__=o,e(n.default)}).call(this,o(1).createPage)},169:function(e,n,o){"use strict";o.r(n);var t=o(170),s=o(172);for(var r in s)"default"!==r&&function(e){o.d(n,e,(function(){return s[e]}))}(r);o(174);var i=o(17),a=Object(i.default)(s.default,t.render,t.staticRenderFns,!1,null,"260a14fe",null,!1,t.components,void 0);a.options.__file="pages/subPage/editAddress.vue",n.default=a.exports},170:function(e,n,o){"use strict";o.r(n);var t=o(171);o.d(n,"render",(function(){return t.render})),o.d(n,"staticRenderFns",(function(){return t.staticRenderFns})),o.d(n,"recyclableRender",(function(){return t.recyclableRender})),o.d(n,"components",(function(){return t.components}))},171:function(e,n,o){"use strict";var t;o.r(n),o.d(n,"render",(function(){return s})),o.d(n,"staticRenderFns",(function(){return i})),o.d(n,"recyclableRender",(function(){return r})),o.d(n,"components",(function(){return t}));try{t={uField:function(){return o.e("uview-ui/components/u-field/u-field").then(o.bind(null,946))},uPicker:function(){return Promise.all([o.e("common/vendor"),o.e("uview-ui/components/u-picker/u-picker")]).then(o.bind(null,1017))}}}catch(e){if(-1===e.message.indexOf("Cannot find module")||-1===e.message.indexOf(".vue"))throw e;console.error(e.message),console.error("1. 排查组件名称拼写是否正确"),console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"),console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件")}var s=function(){var e=this;e.$createElement,e._self._c,e._isMounted||(e.e0=function(n){e.chooseCityBox=!0})},r=!1,i=[];s._withStripped=!0},172:function(e,n,o){"use strict";o.r(n);var t=o(173),s=o.n(t);for(var r in t)"default"!==r&&function(e){o.d(n,e,(function(){return t[e]}))}(r);n.default=s.a},173:function(e,n,o){"use strict";(function(e){Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var o={data:function(){return{shennum:0,chooseCityBox:!1,defaultCheck:!1,addressInfo:{id:"",userName:"",userMobile:"",provinces:"",address:"",addressType:1,countyCode:"",defaultFlag:""},canApplyAmount:0}},onShow:function(){},onLoad:function(n){if(e.hideShareMenu({}),n&&n.item){var o=JSON.parse(decodeURIComponent(n.item));this.addressInfo.id=o.id,this.addressInfo.userName=o.userName,this.addressInfo.userMobile=o.userMobile,this.addressInfo.provinces=o.provinces,this.addressInfo.address=o.address,this.addressInfo.defaultFlag=o.defaultFlag,this.addressInfo.countyCode=o.countyCode,2==o.defaultFlag&&(this.defaultCheck=!0)}},methods:{changeFlag:function(e){console.log(e),console.log(this.defaultCheck)},confirms:function(e){var n,o=this;console.log("省市==",e),n=11==e.province.value||12==e.province.value||31==e.province.value||50==e.province.value?e.province.label+"/"+e.area.label:e.province.label+"/"+e.city.label+"/"+e.area.label,o.addressInfo.provinces=n,o.addressInfo.countyCode=e.area.value,console.log("省市that==",o.addressInfo.provinces),console.log(this.addressInfo)},saveAddress:function(){console.log(this.addressInfo),this.addressInfo.userName?this.addressInfo.userMobile?this.addressInfo.provinces?this.addressInfo.address?(this.defaultCheck?this.addressInfo.defaultFlag=2:this.addressInfo.defaultFlag=1,this.$server.updateAddress(this.addressInfo).then((function(n){0==n.code?(e.showToast({title:"保存成功",icon:"none"}),setTimeout((function(n){e.navigateBack()}),800)):e.showToast({title:n.message,icon:"none"})}))):e.showToast({title:"请输入收货详细地址",icon:"none"}):e.showToast({title:"请输入收货地区",icon:"none"}):e.showToast({title:"请输入收货人电话",icon:"none"}):e.showToast({title:"请输入收货人姓名",icon:"none"})},delAddress:function(){var n=this;e.showModal({title:"提示",content:"您确认要删除该收货地址吗",success:function(e){e.confirm?n.delServer():e.cancel&&console.log("用户点击取消")}})},delServer:function(){this.$server.deleteAddress({id:this.addressInfo.id}).then((function(n){0==n.code?(e.showToast({title:"删除成功",icon:"none"}),setTimeout((function(n){e.navigateBack()}),800)):e.showToast({title:n.message,icon:"none"})}))}}};n.default=o}).call(this,o(1).default)},174:function(e,n,o){"use strict";o.r(n);var t=o(175),s=o.n(t);for(var r in t)"default"!==r&&function(e){o.d(n,e,(function(){return t[e]}))}(r);n.default=s.a},175:function(e,n,o){}},[[168,"common/runtime","common/vendor"]]]);
},{isPage:true,isComponent:true,currentFile:'pages/subPage/editAddress.js'});require("pages/subPage/editAddress.js");