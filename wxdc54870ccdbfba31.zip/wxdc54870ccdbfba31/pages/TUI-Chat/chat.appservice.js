$gwx_XC_22=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_22 || [];
function gz$gwx_XC_22_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_22_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_22_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_22_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container'])
Z([3,'__e'])
Z([3,'message-list'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'triggerClose']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([3,'__l'])
Z([3,'vue-ref'])
Z([[7],[3,'conversation']])
Z([3,'messageList'])
Z(z[2])
Z([[6],[[7],[3,'imcIdcid']],[3,'chatId']])
Z([3,'317ce3e5-1'])
Z([[7],[3,'videoPlay']])
Z(z[1])
Z([3,'container-box'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'stopVideoHander']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z(z[11])
Z([[7],[3,'showOneOrder']])
Z([[7],[3,'showChat']])
Z(z[1])
Z([3,'message-input'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'e2']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([[7],[3,'getOrder']])
Z(z[4])
Z(z[1])
Z(z[1])
Z(z[5])
Z([[7],[3,'commonWordsData']])
Z(z[6])
Z([[4],[[5],[[5],[[4],[[5],[[5],[1,'^sendMessage']],[[4],[[5],[[4],[[5],[1,'sendMessage']]]]]]]],[[4],[[5],[[5],[1,'^sengReady']],[[4],[[5],[[4],[[5],[1,'sengReady']]]]]]]]])
Z([3,'messageInput'])
Z(z[19])
Z([[7],[3,'orderListData']])
Z([3,'317ce3e5-2'])
Z(z[4])
Z(z[1])
Z(z[1])
Z([3,'30'])
Z([1,true])
Z([[4],[[5],[[5],[[4],[[5],[[5],[1,'^click']],[[4],[[5],[[4],[[5],[1,'callPhones']]]]]]]],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'showKf']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z([[7],[3,'listKf']])
Z([3,'text-align:center;'])
Z([[7],[3,'showKf']])
Z([3,'317ce3e5-3'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_22_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_22_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_22=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_22=true;
var x=['./pages/TUI-Chat/chat.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_22_1()
var cEE=_n('view')
_rz(z,cEE,'class',0,e,s,gg)
var tIE=_mz(z,'view',['bindtap',1,'class',1,'data-event-opts',2],[],e,s,gg)
var eJE=_mz(z,'t-u-i-message-list',['bind:__l',4,'class',1,'conversation',2,'data-ref',3,'id',4,'imcIdcidChat',5,'vueId',6],[],e,s,gg)
_(tIE,eJE)
_(cEE,tIE)
var oFE=_v()
_(cEE,oFE)
if(_oz(z,11,e,s,gg)){oFE.wxVkey=1
var bKE=_mz(z,'view',['catchtap',12,'class',1,'data-event-opts',2],[],e,s,gg)
var oLE=_v()
_(bKE,oLE)
if(_oz(z,15,e,s,gg)){oLE.wxVkey=1
}
oLE.wxXCkey=1
_(oFE,bKE)
}
var lGE=_v()
_(cEE,lGE)
if(_oz(z,16,e,s,gg)){lGE.wxVkey=1
}
var aHE=_v()
_(cEE,aHE)
if(_oz(z,17,e,s,gg)){aHE.wxVkey=1
var xME=_mz(z,'view',['bindtap',18,'class',1,'data-event-opts',2],[],e,s,gg)
var oNE=_v()
_(xME,oNE)
if(_oz(z,21,e,s,gg)){oNE.wxVkey=1
var fOE=_mz(z,'t-u-i-message-input',['bind:__l',22,'bind:sendMessage',1,'bind:sengReady',2,'class',3,'commonWordsData',4,'conversation',5,'data-event-opts',6,'data-ref',7,'id',8,'orderListData',9,'vueId',10],[],e,s,gg)
_(oNE,fOE)
}
else{oNE.wxVkey=2
}
oNE.wxXCkey=1
oNE.wxXCkey=3
_(aHE,xME)
}
var cPE=_mz(z,'u-action-sheet',['bind:__l',33,'bind:click',1,'bind:input',2,'borderRadius',3,'cancelBtn',4,'data-event-opts',5,'list',6,'style',7,'value',8,'vueId',9],[],e,s,gg)
_(cEE,cPE)
oFE.wxXCkey=1
lGE.wxXCkey=1
aHE.wxXCkey=1
aHE.wxXCkey=3
_(r,cEE)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_22";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_22();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/TUI-Chat/chat.wxml'] = [$gwx_XC_22, './pages/TUI-Chat/chat.wxml'];else __wxAppCode__['pages/TUI-Chat/chat.wxml'] = $gwx_XC_22( './pages/TUI-Chat/chat.wxml' );
	;__wxRoute = "pages/TUI-Chat/chat";__wxRouteBegin = true;__wxAppCurrentFile__="pages/TUI-Chat/chat.js";define("pages/TUI-Chat/chat.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
(global.webpackJsonp=global.webpackJsonp||[]).push([["pages/TUI-Chat/chat"],{250:function(e,t,n){"use strict";(function(e){n(5),o(n(4));var t=o(n(251));function o(e){return e&&e.__esModule?e:{default:e}}wx.__webpack_require_UNI_MP_PLUGIN__=n,e(t.default)}).call(this,n(1).createPage)},251:function(e,t,n){"use strict";n.r(t);var o=n(252),i=n(254);for(var s in i)"default"!==s&&function(e){n.d(t,e,(function(){return i[e]}))}(s);n(256),n(258);var a=n(17),r=Object(a.default)(i.default,o.render,o.staticRenderFns,!1,null,null,null,!1,o.components,void 0);r.options.__file="pages/TUI-Chat/chat.vue",t.default=r.exports},252:function(e,t,n){"use strict";n.r(t);var o=n(253);n.d(t,"render",(function(){return o.render})),n.d(t,"staticRenderFns",(function(){return o.staticRenderFns})),n.d(t,"recyclableRender",(function(){return o.recyclableRender})),n.d(t,"components",(function(){return o.components}))},253:function(e,t,n){"use strict";var o;n.r(t),n.d(t,"render",(function(){return i})),n.d(t,"staticRenderFns",(function(){return a})),n.d(t,"recyclableRender",(function(){return s})),n.d(t,"components",(function(){return o}));try{o={uActionSheet:function(){return n.e("uview-ui/components/u-action-sheet/u-action-sheet").then(n.bind(null,896))}}}catch(e){if(-1===e.message.indexOf("Cannot find module")||-1===e.message.indexOf(".vue"))throw e;console.error(e.message),console.error("1. 排查组件名称拼写是否正确"),console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"),console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件")}var i=function(){var e=this;e.$createElement,e._self._c,e._isMounted||(e.e0=function(t){e.showMoreEle=!e.showMoreEle},e.e1=function(t){e.showOneOrder=!1},e.e2=function(t){e.showOneOrder=!1})},s=!1,a=[];i._withStripped=!0},254:function(e,t,n){"use strict";n.r(t);var o=n(255),i=n.n(o);for(var s in o)"default"!==s&&function(e){n.d(t,e,(function(){return o[e]}))}(s);t.default=i.a},255:function(e,t,n){"use strict";(function(e){Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var o=s(n(11)),i=s(n(61));function s(e){return e&&e.__esModule?e:{default:e}}var a={data:function(){return{showKf:!1,listKf:[{text:"15970682960"},{text:"15970682961"},{text:"15970682962"}],enterTime:"Wed Jul 27 2022 15:24:31 GMT+0800 (中国标准时间)",conversationName:"",conversation:{},orderListData:[],messageList:[],commonWordsData:[],isShow:!1,showChat:!0,getOrder:!1,conversationID:"",videoPlay:!1,videoMessage:{},showOneOrder:!1,showMoreEle:!0,imcIdcid:{},chatInfo:{custMobile:"",subscribe:!1},typeUser:0,userInfoHome:{}}},components:{TUIMessageList:function(){n.e("components/tui-chat/message-list/index").then(function(){return resolve(n(1062))}.bind(null,n)).catch(n.oe)},TUIMessageInput:function(){n.e("components/tui-chat/message-input/index").then(function(){return resolve(n(1069))}.bind(null,n)).catch(n.oe)}},props:{},created:function(){var t=this;e.$on("videoPlayerHandler",(function(e){t.videoPlay=e.isPlay,t.videoMessage=e.message}))},onShow:function(){this.chatScriptList()},onLoad:function(t){var n=this;o.default.log(" TUI-chat | onLoad | conversationID: ".concat(t.conversationID));var i=t.conversationID;this.setData({conversationID:i}),this.enterTime=new Date,this.userInfoHome=e.getStorageSync("userInfo");var s=e.getStorageSync("imcIdcid");this.imcIdcid=s,this.getChatInfo(),this.getMyOrderList(s.userId,s.chatId),e.$TUIKit.setMessageRead({conversationID:i}).then((function(){o.default.log("TUI-chat | setMessageRead  | ok")})),e.$TUIKit.getConversationProfile(i).then((function(e){var t=e.data.conversation;n.conversation=t,n.setData({conversationName:n.getConversationName(t),isShow:"GROUP"===t.type})}))},onUnload:function(){console.log("卸载");var e=(new Date).getTime()-this.enterTime.getTime(),t=Math.ceil(e/1e3),n=[{pageType:5,userId:this.imcIdcid.chatId,accessTime:t}];this.sendAccessLog(n)},methods:{callPhones:function(t){e.makePhoneCall({phoneNumber:this.listKf[t].text})},chatScriptList:function(){var t=this;this.$server.chatScriptList().then((function(n){0==n.code?t.commonWordsData=n.data:e.showToast({title:n.message,icon:"none"})}))},sengReady:function(){var t=e.getStorageSync("userInfo");t.chatWxQrcode?this.sendImgUrl(t.chatWxQrcode):e.navigateTo({url:"../pageRelay/tuiChatDiy"})},eleWaned:function(t,n){var o=this;if(console.log(this.conversationID),1==t){if(!this.chatInfo.custMobile)return e.showToast({title:"对方暂未预留手机号",icon:"none"}),!1;this.chatInfo.subCustMobile?this.showKf=!0:e.makePhoneCall({phoneNumber:this.chatInfo.custMobile})}else if(2==t)e.navigateTo({url:"/pages/subPage/myHome?uid="+this.imcIdcid.chatId});else if(3==t){if(this.chatInfo.subscribe)return e.showToast({title:"您已订阅对方",icon:"success"}),!1;this.$server.subscribeUser({targetUserId:this.imcIdcid.chatId,subscribeType:1}).then((function(t){0==t.code?(o.chatInfo.subscribe=!o.chatInfo.subscribe,0==t.code?(e.showToast({title:"订阅成功",icon:"success"}),e.getStorageSync("userInfo").focusWechat||e.navigateTo({url:"/pages/subPage/weAccount"})):e.showToast({title:"退订成功"})):e.showToast({title:t.message,icon:"none"})}))}else e.navigateTo({url:"/pages/subPage/weAccount"})},getChatInfo:function(){var t=this;this.$server.getInfoByUserId({userId:this.imcIdcid.chatId}).then((function(n){0==n.code?(t.chatInfo=n.data,t.chatInfo.custMobile&&(t.listKf=[{text:t.chatInfo.custMobile}]),t.chatInfo.subCustMobile&&t.chatInfo.subCustMobile.split(",").forEach((function(e){t.listKf.push({text:e})}))):e.showToast({title:n.message,icon:"none"})}))},sendOneOrder:function(){var e=this.orderListData[0];this.$refs.messageInput.$handleSendCustomMessage({detail:{payload:{data:"order",description:"text_link",extension:JSON.stringify({activityName:e.activityName,payPriceShow:e.payPriceShow,createTime:e.createTime,activityNumb:e.activityNumb,commodityList:e.commodityList,activityId:e.activityId,orderId:e.orderId})}}}),this.showOneOrder=!1},sendImgUrl:function(e){this.orderListData[0],this.$refs.messageInput.$handleSendCustomMessage({detail:{payload:{data:"imageurl",description:"text_link",extension:JSON.stringify({imgUrl:e})}}})},getMyOrderList:function(e,t){var n=this,o={page:1,pageSize:20};1==this.imcIdcid.userType?(o.activityUserId=t,o.buyUserId=e):(o.activityUserId=e,o.buyUserId=t),this.$server.queryUserOrderList(o).then((function(e){if(0==e.code){var t=[];e.data.map((function(e){var n={};return n.activityName=e.activityName,n.activityNumb=e.activityNumb,n.createTime=e.createTime,n.activityId=e.activityId,n.orderId=e.orderId,n.payPriceShow=i.default.centTurnSmacker(e.payPrice/100),n.createTimeShow=e.createTime.slice(0,16),n.commodityList=[],e.commodityDetais.forEach((function(e){e.commodityPriceShow=i.default.centTurnSmacker(e.commodityPrice/100),n.commodityList.push({imgUrl:e.imgUrl,formatName:e.formatName,commodityPrice:e.commodityPriceShow,commodityCount:e.commodityCount,commodityId:e.commodityId,commodityName:e.commodityName})})),t.push(n),e})),n.orderListData=t,n.getOrder=!0,n.orderListData.length&&(n.showOneOrder=!0)}else n.getOrder=!0})),3==this.imcIdcid.userType&&this.$server.updateChatFlag({recommendUserId:t}).then((function(e){e.code}))},stopVideoHander:function(){this.videoPlay=!1},getConversationName:function(e){return"@TIM#SYSTEM"===e.type?(this.setData({showChat:!1}),"系统通知"):"C2C"===e.type?e.remark||e.userProfile.nick||e.userProfile.userID:"GROUP"===e.type?e.groupProfile.name||e.groupProfile.groupID:void 0},sendMessage:function(e){this.$refs.messageList.updateMessageList(e.detail.message)},triggerClose:function(){this.showChat&&this.$refs.messageInput.handleClose()},goBack:function(){console.log("pagesclick=="),e.navigateBack(),e.$TUIKit.setMessageRead({conversationID:this.conversationID}).then((function(){}))}}};t.default=a}).call(this,n(1).default)},256:function(e,t,n){"use strict";n.r(t);var o=n(257),i=n.n(o);for(var s in o)"default"!==s&&function(e){n.d(t,e,(function(){return o[e]}))}(s);t.default=i.a},257:function(e,t,n){},258:function(e,t,n){"use strict";n.r(t);var o=n(259),i=n.n(o);for(var s in o)"default"!==s&&function(e){n.d(t,e,(function(){return o[e]}))}(s);t.default=i.a},259:function(e,t,n){}},[[250,"common/runtime","common/vendor"]]]);
},{isPage:true,isComponent:true,currentFile:'pages/TUI-Chat/chat.js'});require("pages/TUI-Chat/chat.js");