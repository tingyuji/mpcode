$gwx_XC_22=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_22 || [];
function gz$gwx_XC_22_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_22_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_22_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_22_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'container'])
Z([3,'tui-chatroom-navigatorbar'])
Z([3,'__e'])
Z([3,'tui-chatroom-navigatorbar-vbox'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'goBack']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([3,'tui-chatroom-navigatorbar-back'])
Z([3,'https://qiniuimg.kfmanager.com/svg/assets/backsvg.png'])
Z([3,'conversation-title'])
Z([a,[[7],[3,'conversationName']]])
Z(z[2])
Z([3,'conversation-mores fl'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'e0']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([3,'conversation-mores-top'])
Z([3,'scaleToFill'])
Z([[2,'?:'],[[7],[3,'showMoreEle']],[1,'https://qiniuimg.kfmanager.com/qunjl/showrel/shangla.png'],[1,'https://qiniuimg.kfmanager.com/qunjl/showrel/xialamore.png']])
Z([[2,'+'],[[2,'+'],[1,'color:'],[[2,'?:'],[[7],[3,'showMoreEle']],[1,''],[1,'#07c160']]],[1,';']])
Z([a,[[2,'?:'],[[7],[3,'showMoreEle']],[1,'收起'],[1,'展开']]])
Z([3,'conversation-mores-box'])
Z([[2,'!'],[[7],[3,'showMoreEle']]])
Z([3,'fl_sa'])
Z([3,'height:120rpx;'])
Z(z[2])
Z([3,'fl_cb'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'eleWaned']],[[4],[[5],[1,1]]]]]]]]]]])
Z([3,'height:96rpx;'])
Z([3,'aspectFill'])
Z([3,'https://qiniuimg.kfmanager.com/qunjl/showrel/callPhone.png'])
Z([3,'width:50rpx;height:50rpx;'])
Z([3,'font-size:26rpx;color:#333;'])
Z([3,'电话'])
Z(z[2])
Z(z[22])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'eleWaned']],[[4],[[5],[1,2]]]]]]]]]]])
Z(z[24])
Z(z[25])
Z([3,'https://qiniuimg.kfmanager.com/qunjl/showrel/homePa.png'])
Z(z[27])
Z(z[28])
Z([3,'进入Ta的主页'])
Z(z[2])
Z(z[22])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'eleWaned']],[[4],[[5],[1,3]]]]]]]]]]])
Z(z[24])
Z(z[25])
Z([3,'https://qiniuimg.kfmanager.com/qunjl/showrel/dyue.png'])
Z(z[27])
Z(z[28])
Z([3,'订阅Ta'])
Z(z[2])
Z([3,'message-list'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'triggerClose']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([3,'__l'])
Z([3,'vue-ref'])
Z([[7],[3,'conversation']])
Z([3,'messageList'])
Z(z[49])
Z([[6],[[7],[3,'imcIdcid']],[3,'chatId']])
Z([3,'317ce3e5-1'])
Z([[7],[3,'videoPlay']])
Z(z[2])
Z([3,'container-box'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'stopVideoHander']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z(z[58])
Z([3,'true'])
Z([3,'video-message'])
Z([3,'0'])
Z([3,'videoError'])
Z([3,'cover'])
Z([[6],[[6],[[7],[3,'videoMessage']],[3,'payload']],[3,'thumbUrl']])
Z([[6],[[6],[[7],[3,'videoMessage']],[3,'payload']],[3,'videoUrl']])
Z([[7],[3,'showOneOrder']])
Z([3,'fix_order'])
Z([3,'custom-yr-shele fl_sb'])
Z(z[25])
Z([[6],[[6],[[6],[[6],[[7],[3,'orderListData']],[1,0]],[3,'commodityList']],[1,0]],[3,'imgUrl']])
Z([3,'custom-yr-rigt fl_c'])
Z([3,'yr_bbs fl_sb'])
Z([a,[[6],[[6],[[6],[[6],[[7],[3,'orderListData']],[1,0]],[3,'commodityList']],[1,0]],[3,'commodityName']]])
Z(z[2])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'e1']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z(z[25])
Z([3,'https://qiniuimg.kfmanager.com/qunjl/showrel/guanbi.png'])
Z([a,[[6],[[6],[[6],[[6],[[7],[3,'orderListData']],[1,0]],[3,'commodityList']],[1,0]],[3,'formatName']]])
Z([3,'fl_sb'])
Z([3,'color:#fc5757;font-size:28rpx;'])
Z([a,[[2,'+'],[1,'¥'],[[6],[[6],[[6],[[6],[[7],[3,'orderListData']],[1,0]],[3,'commodityList']],[1,0]],[3,'commodityPrice']]]])
Z([a,[[2,'+'],[1,'+'],[[6],[[6],[[6],[[6],[[7],[3,'orderListData']],[1,0]],[3,'commodityList']],[1,0]],[3,'commodityCount']]]])
Z(z[2])
Z([3,'cen_ters'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'sendOneOrder']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([3,'发给Ta'])
Z([[7],[3,'showChat']])
Z(z[2])
Z([3,'message-input'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'e2']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([[7],[3,'getOrder']])
Z(z[51])
Z(z[2])
Z(z[2])
Z(z[52])
Z([[7],[3,'commonWordsData']])
Z(z[53])
Z([[4],[[5],[[5],[[4],[[5],[[5],[1,'^sendMessage']],[[4],[[5],[[4],[[5],[1,'sendMessage']]]]]]]],[[4],[[5],[[5],[1,'^sengReady']],[[4],[[5],[[4],[[5],[1,'sengReady']]]]]]]]])
Z([3,'messageInput'])
Z(z[93])
Z([[7],[3,'orderListData']])
Z([3,'317ce3e5-2'])
Z([3,'width:750rpx;height:240rpx;'])
Z(z[51])
Z(z[2])
Z(z[2])
Z([3,'30'])
Z([1,true])
Z([[4],[[5],[[5],[[4],[[5],[[5],[1,'^click']],[[4],[[5],[[4],[[5],[1,'callPhones']]]]]]]],[[4],[[5],[[5],[1,'^input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'showKf']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z([[7],[3,'listKf']])
Z([3,'text-align:center;'])
Z([[7],[3,'showKf']])
Z([3,'317ce3e5-3'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_22_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_22_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_22=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_22=true;
var x=['./pages/TUI-Chat/chat.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_22_1()
var o2R=_n('view')
_rz(z,o2R,'class',0,e,s,gg)
var e6R=_n('view')
_rz(z,e6R,'class',1,e,s,gg)
var b7R=_mz(z,'view',['bindtap',2,'class',1,'data-event-opts',2],[],e,s,gg)
var o8R=_mz(z,'image',['class',5,'src',1],[],e,s,gg)
_(b7R,o8R)
_(e6R,b7R)
var x9R=_n('view')
_rz(z,x9R,'class',7,e,s,gg)
var o0R=_oz(z,8,e,s,gg)
_(x9R,o0R)
_(e6R,x9R)
var fAS=_mz(z,'view',['bindtap',9,'class',1,'data-event-opts',2],[],e,s,gg)
var cBS=_n('view')
_rz(z,cBS,'class',12,e,s,gg)
var hCS=_mz(z,'image',['mode',13,'src',1],[],e,s,gg)
_(cBS,hCS)
var oDS=_n('text')
_rz(z,oDS,'style',15,e,s,gg)
var cES=_oz(z,16,e,s,gg)
_(oDS,cES)
_(cBS,oDS)
_(fAS,cBS)
_(e6R,fAS)
var oFS=_mz(z,'view',['class',17,'hidden',1],[],e,s,gg)
var lGS=_mz(z,'view',['class',19,'style',1],[],e,s,gg)
var aHS=_mz(z,'view',['bindtap',21,'class',1,'data-event-opts',2,'style',3],[],e,s,gg)
var tIS=_mz(z,'image',['mode',25,'src',1,'style',2],[],e,s,gg)
_(aHS,tIS)
var eJS=_n('text')
_rz(z,eJS,'style',28,e,s,gg)
var bKS=_oz(z,29,e,s,gg)
_(eJS,bKS)
_(aHS,eJS)
_(lGS,aHS)
var oLS=_mz(z,'view',['bindtap',30,'class',1,'data-event-opts',2,'style',3],[],e,s,gg)
var xMS=_mz(z,'image',['mode',34,'src',1,'style',2],[],e,s,gg)
_(oLS,xMS)
var oNS=_n('text')
_rz(z,oNS,'style',37,e,s,gg)
var fOS=_oz(z,38,e,s,gg)
_(oNS,fOS)
_(oLS,oNS)
_(lGS,oLS)
var cPS=_mz(z,'view',['bindtap',39,'class',1,'data-event-opts',2,'style',3],[],e,s,gg)
var hQS=_mz(z,'image',['mode',43,'src',1,'style',2],[],e,s,gg)
_(cPS,hQS)
var oRS=_n('text')
_rz(z,oRS,'style',46,e,s,gg)
var cSS=_oz(z,47,e,s,gg)
_(oRS,cSS)
_(cPS,oRS)
_(lGS,cPS)
_(oFS,lGS)
_(e6R,oFS)
_(o2R,e6R)
var oTS=_mz(z,'view',['bindtap',48,'class',1,'data-event-opts',2],[],e,s,gg)
var lUS=_mz(z,'t-u-i-message-list',['bind:__l',51,'class',1,'conversation',2,'data-ref',3,'id',4,'imcIdcidChat',5,'vueId',6],[],e,s,gg)
_(oTS,lUS)
_(o2R,oTS)
var l3R=_v()
_(o2R,l3R)
if(_oz(z,58,e,s,gg)){l3R.wxVkey=1
var aVS=_mz(z,'view',['catchtap',59,'class',1,'data-event-opts',2],[],e,s,gg)
var tWS=_v()
_(aVS,tWS)
if(_oz(z,62,e,s,gg)){tWS.wxVkey=1
var eXS=_mz(z,'video',['autoplay',63,'class',1,'direction',2,'error',3,'objectFit',4,'poster',5,'src',6],[],e,s,gg)
_(tWS,eXS)
}
tWS.wxXCkey=1
_(l3R,aVS)
}
var a4R=_v()
_(o2R,a4R)
if(_oz(z,70,e,s,gg)){a4R.wxVkey=1
var bYS=_n('view')
_rz(z,bYS,'class',71,e,s,gg)
var oZS=_n('view')
_rz(z,oZS,'class',72,e,s,gg)
var x1S=_mz(z,'image',['mode',73,'src',1],[],e,s,gg)
_(oZS,x1S)
var o2S=_n('view')
_rz(z,o2S,'class',75,e,s,gg)
var f3S=_n('view')
_rz(z,f3S,'class',76,e,s,gg)
var c4S=_n('view')
var h5S=_oz(z,77,e,s,gg)
_(c4S,h5S)
_(f3S,c4S)
var o6S=_mz(z,'image',['bindtap',78,'data-event-opts',1,'mode',2,'src',3],[],e,s,gg)
_(f3S,o6S)
_(o2S,f3S)
var c7S=_n('text')
var o8S=_oz(z,82,e,s,gg)
_(c7S,o8S)
_(o2S,c7S)
var l9S=_n('view')
_rz(z,l9S,'class',83,e,s,gg)
var a0S=_n('text')
_rz(z,a0S,'style',84,e,s,gg)
var tAT=_oz(z,85,e,s,gg)
_(a0S,tAT)
_(l9S,a0S)
var eBT=_n('text')
var bCT=_oz(z,86,e,s,gg)
_(eBT,bCT)
_(l9S,eBT)
_(o2S,l9S)
_(oZS,o2S)
_(bYS,oZS)
var oDT=_mz(z,'view',['bindtap',87,'class',1,'data-event-opts',2],[],e,s,gg)
var xET=_oz(z,90,e,s,gg)
_(oDT,xET)
_(bYS,oDT)
_(a4R,bYS)
}
var t5R=_v()
_(o2R,t5R)
if(_oz(z,91,e,s,gg)){t5R.wxVkey=1
var oFT=_mz(z,'view',['bindtap',92,'class',1,'data-event-opts',2],[],e,s,gg)
var fGT=_v()
_(oFT,fGT)
if(_oz(z,95,e,s,gg)){fGT.wxVkey=1
var cHT=_mz(z,'t-u-i-message-input',['bind:__l',96,'bind:sendMessage',1,'bind:sengReady',2,'class',3,'commonWordsData',4,'conversation',5,'data-event-opts',6,'data-ref',7,'id',8,'orderListData',9,'vueId',10],[],e,s,gg)
_(fGT,cHT)
}
else{fGT.wxVkey=2
var hIT=_n('view')
_rz(z,hIT,'style',107,e,s,gg)
_(fGT,hIT)
}
fGT.wxXCkey=1
fGT.wxXCkey=3
_(t5R,oFT)
}
var oJT=_mz(z,'u-action-sheet',['bind:__l',108,'bind:click',1,'bind:input',2,'borderRadius',3,'cancelBtn',4,'data-event-opts',5,'list',6,'style',7,'value',8,'vueId',9],[],e,s,gg)
_(o2R,oJT)
l3R.wxXCkey=1
a4R.wxXCkey=1
t5R.wxXCkey=1
t5R.wxXCkey=3
_(r,o2R)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_22";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_22();
	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/TUI-Chat/chat.wxml'] = [$gwx_XC_22, './pages/TUI-Chat/chat.wxml'];else __wxAppCode__['pages/TUI-Chat/chat.wxml'] = $gwx_XC_22( './pages/TUI-Chat/chat.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['pages/TUI-Chat/chat.wxss'] = setCssToHead([".",[1],"container{bottom:0;display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column;height:100vh;left:0;position:fixed;right:0;top:0;width:100vw}\n.",[1],"tui-chatroom-navigatorbar{background-color:#fff;border-bottom:",[0,1]," solid #f5f5f5;-webkit-flex-shrink:0;flex-shrink:0;height:",[0,176],";position:relative;width:",[0,750],";z-index:101}\n.",[1],"tui-chatroom-navigatorbar-vbox{bottom:",[0,0],";height:",[0,176],";left:",[0,0],";position:absolute;width:",[0,200],";z-index:9}\n.",[1],"tui-chatroom-navigatorbar-back{bottom:",[0,20],";height:",[0,48],";left:",[0,24],";position:absolute;width:",[0,48],";z-index:10}\n.",[1],"conversation-title{-webkit-align-items:center;align-items:center;bottom:0;color:#111;display:-webkit-flex;display:flex;font-size:",[0,32],";height:",[0,88],";-webkit-justify-content:center;justify-content:center;left:",[0,200],";line-height:",[0,56],";position:absolute;width:",[0,350],";z-index:100}\n.",[1],"conversation-mores{background-color:#fff;bottom:",[0,14],";position:absolute;width:",[0,750],";z-index:103}\n.",[1],"conversation-mores-top{color:#999;font-size:",[0,24],";left:50%;position:absolute;-webkit-transform:translateX(-50%);transform:translateX(-50%)}\n.",[1],"conversation-mores-top\x3ewx-image{height:",[0,24],";width:",[0,24],"}\n.",[1],"conversation-mores-top\x3ewx-text{box-sizing:border-box;padding-left:",[0,8],"}\n.",[1],"conversation-mores-box{background-color:#fff;bottom:",[0,-120],";height:",[0,120],";position:absolute;width:",[0,750],";z-index:102}\n.",[1],"fix_wechats{bottom:",[0,-200],";left:",[0,30],";position:absolute;z-index:102}\n.",[1],"message-list{background-color:#f5f5f5;-webkit-flex:1;flex:1;overflow-y:scroll;padding-top:",[0,110],";width:100vw}\n.",[1],"message-input{-webkit-flex-shrink:0;flex-shrink:0;width:100%}\n.",[1],"calling{bottom:0;position:fixed;right:0;top:0;z-index:199}\n.",[1],"group-profile{left:0;top:",[0,176],";z-index:1111}\n.",[1],"container-box{-webkit-align-items:center;align-items:center;background-color:rgba(0,0,0,.5);bottom:0;display:-webkit-flex;display:flex;-webkit-justify-content:center;justify-content:center;left:0;position:fixed;right:0;top:0}\n.",[1],"video-message{height:300px;width:90vw}\n.",[1],"fix_order{background-color:#fff;border-radius:",[0,20],";bottom:",[0,260],";box-sizing:border-box;left:",[0,15],";padding:",[0,10]," ",[0,30]," ",[0,8]," ",[0,16],";position:fixed;width:",[0,720],";z-index:9}\n.",[1],"fix_order .",[1],"custom-yr-shele{margin-top:",[0,8],"}\n.",[1],"fix_order .",[1],"custom-yr-shele wx-image{border-radius:",[0,16],";height:",[0,120],";width:",[0,120],"}\n.",[1],"fix_order .",[1],"custom-yr-shele .",[1],"custom-yr-rigt{box-sizing:border-box;color:#999;-webkit-flex:1;flex:1;font-size:",[0,24],";height:",[0,120],";-webkit-justify-content:space-between;justify-content:space-between;padding-left:",[0,20],"}\n.",[1],"fix_order .",[1],"custom-yr-shele .",[1],"yr_bbs{color:#333;font-size:",[0,28],"}\n.",[1],"fix_order .",[1],"custom-yr-shele .",[1],"yr_bbs wx-image{height:",[0,28],";width:",[0,28],"}\n.",[1],"fix_order .",[1],"cen_ters{color:#07c160;height:",[0,80],";line-height:",[0,80],";text-align:center;width:100%}\n",],"Some selectors are not allowed in component wxss, including tag name selectors, ID selectors, and attribute selectors.(./pages/TUI-Chat/chat.wxss:1:2538)",{path:"./pages/TUI-Chat/chat.wxss"});
}