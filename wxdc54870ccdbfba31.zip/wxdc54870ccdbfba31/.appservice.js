	if (__vd_version_info__.delayedGwx) __wxAppCode__['app.wxml'] = [, './app.wxml'];else __wxAppCode__['app.wxml'] = ( './app.wxml' );
		if (__vd_version_info__.delayedGwx) __wxAppCode__['project.config.wxml'] = [, './project.config.wxml'];else __wxAppCode__['project.config.wxml'] = ( './project.config.wxml' );
		if (__vd_version_info__.delayedGwx) __wxAppCode__['sitemap.wxml'] = [, './sitemap.wxml'];else __wxAppCode__['sitemap.wxml'] = ( './sitemap.wxml' );
	