(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "page_missionCenter/common/vendor" ], {
    /***/
    207: 
    /*!**************************************************************************************************!*\
    !*** C:/Users/86188/Desktop/文物项目/开发/cultural-edu/future-mini-program/api/missionCenter/index.js ***!
    \**************************************************************************************************/
    /*! no static exports found */
    /***/
    function _(module, exports, __webpack_require__) {
        "use strict";
        Object.defineProperty(exports, "__esModule", {
            value: true
        });
        exports.taskList = taskList;
        exports.userTask = userTask;
        var _request = _interopRequireDefault(__webpack_require__(
        /*! @/utils/request.js */
        10));
        function _interopRequireDefault(obj) {
            return obj && obj.__esModule ? obj : {
                default: obj
            };
        }
        // 查询任务列表
                function taskList(phone) {
            return (0, _request.default)({
                url: "/task/get-task-list?phone=".concat(phone),
                method: "get"
            });
        }
        /**
       * 更新用户任务
       * 
       * @url /task/update-user-task
       * 
       * @param  phone    
       * @param  task_id   
       * @param  chance_add_num   
       */
        // 更新用户任务
                function userTask(data) {
            return (0, _request.default)({
                url: "/task/update-user-task",
                method: "post",
                data: data
            });
        }
        /***/    }
} ]);