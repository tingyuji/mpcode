require("../../@babel/runtime/helpers/Arrayincludes");

require("../common/vendor.js");

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "page_missionCenter/missionCenter/missionCenter" ], {
    /***/
    201: 
    /*!*********************************************************************************************************************************************!*\
    !*** C:/Users/86188/Desktop/文物项目/开发/cultural-edu/future-mini-program/main.js?{"page":"page_missionCenter%2FmissionCenter%2FmissionCenter"} ***!
    \*********************************************************************************************************************************************/
    /*! no static exports found */
    /***/
    function _(module, exports, __webpack_require__) {
        "use strict";
        /* WEBPACK VAR INJECTION */
        /* WEBPACK VAR INJECTION */        
        /* WEBPACK VAR INJECTION */
        /* WEBPACK VAR INJECTION */
        (function(createPage) {
            __webpack_require__(
            /*! uni-pages */
            5);
            var _vue = _interopRequireDefault(__webpack_require__(
            /*! vue */
            4));
            var _missionCenter = _interopRequireDefault(__webpack_require__(
            /*! ./page_missionCenter/missionCenter/missionCenter.vue */
            202));
            function _interopRequireDefault(obj) {
                return obj && obj.__esModule ? obj : {
                    default: obj
                };
            }
            // @ts-ignore
                        wx.__webpack_require_UNI_MP_PLUGIN__ = __webpack_require__;
            createPage(_missionCenter.default);
            /* WEBPACK VAR INJECTION */        }).call(this, __webpack_require__(
        /*! ./node_modules/@dcloudio/uni-mp-weixin/dist/index.js */
        1)["createPage"]);
        /***/    },
    /***/
    202: 
    /*!**************************************************************************************************************************!*\
    !*** C:/Users/86188/Desktop/文物项目/开发/cultural-edu/future-mini-program/page_missionCenter/missionCenter/missionCenter.vue ***!
    \**************************************************************************************************************************/
    /*! no static exports found */
    /***/
    function _(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony import */        var _missionCenter_vue_vue_type_template_id_1fd78d7a_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
        /*! ./missionCenter.vue?vue&type=template&id=1fd78d7a&scoped=true& */
        203);
        /* harmony import */        var _missionCenter_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
        /*! ./missionCenter.vue?vue&type=script&lang=js& */
        205);
        /* harmony reexport (unknown) */        for (var __WEBPACK_IMPORT_KEY__ in _missionCenter_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__) {
            if (__WEBPACK_IMPORT_KEY__ !== "default") (function(key) {
                __webpack_require__.d(__webpack_exports__, key, function() {
                    return _missionCenter_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__[key];
                });
            })(__WEBPACK_IMPORT_KEY__);
        }
        /* harmony import */        var _missionCenter_vue_vue_type_style_index_0_id_1fd78d7a_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
        /*! ./missionCenter.vue?vue&type=style&index=0&id=1fd78d7a&lang=scss&scoped=true& */
        208);
        /* harmony import */        var _D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
        /*! ./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/runtime/componentNormalizer.js */
        17);
        var renderjs;
        /* normalize component */        var component = Object(_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(_missionCenter_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"], _missionCenter_vue_vue_type_template_id_1fd78d7a_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"], _missionCenter_vue_vue_type_template_id_1fd78d7a_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"], false, null, "1fd78d7a", null, false, _missionCenter_vue_vue_type_template_id_1fd78d7a_scoped_true___WEBPACK_IMPORTED_MODULE_0__["components"], renderjs);
        component.options.__file = "page_missionCenter/missionCenter/missionCenter.vue";
        /* harmony default export */        __webpack_exports__["default"] = component.exports;
        /***/    },
    /***/
    203: 
    /*!*********************************************************************************************************************************************************************!*\
    !*** C:/Users/86188/Desktop/文物项目/开发/cultural-edu/future-mini-program/page_missionCenter/missionCenter/missionCenter.vue?vue&type=template&id=1fd78d7a&scoped=true& ***!
    \*********************************************************************************************************************************************************************/
    /*! exports provided: render, staticRenderFns, recyclableRender, components */
    /***/
    function _(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony import */        var _D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_16_0_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_template_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_uni_app_loader_page_meta_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_missionCenter_vue_vue_type_template_id_1fd78d7a_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
        /*! -!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader??ref--16-0!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/template.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-uni-app-loader/page-meta.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib??vue-loader-options!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!./missionCenter.vue?vue&type=template&id=1fd78d7a&scoped=true& */
        204);
        /* harmony reexport (safe) */        __webpack_require__.d(__webpack_exports__, "render", function() {
            return _D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_16_0_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_template_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_uni_app_loader_page_meta_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_missionCenter_vue_vue_type_template_id_1fd78d7a_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"];
        });
        /* harmony reexport (safe) */        __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() {
            return _D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_16_0_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_template_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_uni_app_loader_page_meta_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_missionCenter_vue_vue_type_template_id_1fd78d7a_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"];
        });
        /* harmony reexport (safe) */        __webpack_require__.d(__webpack_exports__, "recyclableRender", function() {
            return _D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_16_0_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_template_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_uni_app_loader_page_meta_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_missionCenter_vue_vue_type_template_id_1fd78d7a_scoped_true___WEBPACK_IMPORTED_MODULE_0__["recyclableRender"];
        });
        /* harmony reexport (safe) */        __webpack_require__.d(__webpack_exports__, "components", function() {
            return _D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_16_0_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_template_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_uni_app_loader_page_meta_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_missionCenter_vue_vue_type_template_id_1fd78d7a_scoped_true___WEBPACK_IMPORTED_MODULE_0__["components"];
        });
        /***/    },
    /***/
    204: 
    /*!*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
    !*** ./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader??ref--16-0!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/template.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-uni-app-loader/page-meta.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib??vue-loader-options!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!C:/Users/86188/Desktop/文物项目/开发/cultural-edu/future-mini-program/page_missionCenter/missionCenter/missionCenter.vue?vue&type=template&id=1fd78d7a&scoped=true& ***!
    \*********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
    /*! exports provided: render, staticRenderFns, recyclableRender, components */
    /***/
    function _(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony export (binding) */        __webpack_require__.d(__webpack_exports__, "render", function() {
            return render;
        });
        /* harmony export (binding) */        __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() {
            return staticRenderFns;
        });
        /* harmony export (binding) */        __webpack_require__.d(__webpack_exports__, "recyclableRender", function() {
            return recyclableRender;
        });
        /* harmony export (binding) */        __webpack_require__.d(__webpack_exports__, "components", function() {
            return components;
        });
        var components;
        var render = function render() {
            var _vm = this;
            var _h = _vm.$createElement;
            var _c = _vm._self._c || _h;
        };
        var recyclableRender = false;
        var staticRenderFns = [];
        render._withStripped = true;
        /***/    },
    /***/
    205: 
    /*!***************************************************************************************************************************************************!*\
    !*** C:/Users/86188/Desktop/文物项目/开发/cultural-edu/future-mini-program/page_missionCenter/missionCenter/missionCenter.vue?vue&type=script&lang=js& ***!
    \***************************************************************************************************************************************************/
    /*! no static exports found */
    /***/
    function _(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony import */        var _D_soft_HBuilderX_plugins_uniapp_cli_node_modules_babel_loader_lib_index_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_12_1_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_script_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_missionCenter_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
        /*! -!./node_modules/babel-loader/lib!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader??ref--12-1!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/script.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib??vue-loader-options!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!./missionCenter.vue?vue&type=script&lang=js& */
        206);
        /* harmony import */        var _D_soft_HBuilderX_plugins_uniapp_cli_node_modules_babel_loader_lib_index_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_12_1_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_script_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_missionCenter_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0___default = /* */ __webpack_require__.n(_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_babel_loader_lib_index_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_12_1_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_script_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_missionCenter_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__);
        /* harmony reexport (unknown) */        for (var __WEBPACK_IMPORT_KEY__ in _D_soft_HBuilderX_plugins_uniapp_cli_node_modules_babel_loader_lib_index_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_12_1_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_script_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_missionCenter_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__) {
            if (__WEBPACK_IMPORT_KEY__ !== "default") (function(key) {
                __webpack_require__.d(__webpack_exports__, key, function() {
                    return _D_soft_HBuilderX_plugins_uniapp_cli_node_modules_babel_loader_lib_index_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_12_1_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_script_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_missionCenter_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__[key];
                });
            })(__WEBPACK_IMPORT_KEY__);
        }
        /* harmony default export */        __webpack_exports__["default"] = _D_soft_HBuilderX_plugins_uniapp_cli_node_modules_babel_loader_lib_index_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_12_1_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_script_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_missionCenter_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0___default.a;
        /***/    },
    /***/
    206: 
    /*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
    !*** ./node_modules/babel-loader/lib!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader??ref--12-1!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/script.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib??vue-loader-options!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!C:/Users/86188/Desktop/文物项目/开发/cultural-edu/future-mini-program/page_missionCenter/missionCenter/missionCenter.vue?vue&type=script&lang=js& ***!
    \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
    /*! no static exports found */
    /***/
    function _(module, exports, __webpack_require__) {
        "use strict";
        /* WEBPACK VAR INJECTION */
        /* WEBPACK VAR INJECTION */        
        /* WEBPACK VAR INJECTION */
        /* WEBPACK VAR INJECTION */
        (function(uni) {
            Object.defineProperty(exports, "__esModule", {
                value: true
            });
            exports.default = void 0;
            var _vuex = __webpack_require__(
            /*! vuex */
            13);
            var _index = __webpack_require__(
            /*! @/api/index.js */
            12);
            var _index2 = __webpack_require__(
            /*! @/api/missionCenter/index.js */
            207);
            function ownKeys(object, enumerableOnly) {
                var keys = Object.keys(object);
                if (Object.getOwnPropertySymbols) {
                    var symbols = Object.getOwnPropertySymbols(object);
                    if (enumerableOnly) symbols = symbols.filter(function(sym) {
                        return Object.getOwnPropertyDescriptor(object, sym).enumerable;
                    });
                    keys.push.apply(keys, symbols);
                }
                return keys;
            }
            function _objectSpread(target) {
                for (var i = 1; i < arguments.length; i++) {
                    var source = arguments[i] != null ? arguments[i] : {};
                    if (i % 2) {
                        ownKeys(Object(source), true).forEach(function(key) {
                            _defineProperty(target, key, source[key]);
                        });
                    } else if (Object.getOwnPropertyDescriptors) {
                        Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
                    } else {
                        ownKeys(Object(source)).forEach(function(key) {
                            Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
                        });
                    }
                }
                return target;
            }
            function _defineProperty(obj, key, value) {
                if (key in obj) {
                    Object.defineProperty(obj, key, {
                        value: value,
                        enumerable: true,
                        configurable: true,
                        writable: true
                    });
                } else {
                    obj[key] = value;
                }
                return obj;
            }
            var _default = {
                data: function data() {
                    return {
                        missionMain_list: [],
                        titleObj: {
                            "关注「希望学」公众号": "已完成",
                            "关注「希望学」视频号": "已完成"
                        },
                        iconObj: {
                            1: __webpack_require__(
                            /*! @/page_missionCenter/static/img/we.png */
                            100),
                            2: __webpack_require__(
                            /*! @/page_missionCenter/static/img/strategy.png */
                            99),
                            3: __webpack_require__(
                            /*! @/page_missionCenter/static/img/star.png */
                            98),
                            4: __webpack_require__(
                            /*! @/page_missionCenter/static/img/present.png */
                            96)
                        },
                        user_task: null,
                        shareUrl: null,
                        taskIndex: null,
                        shareIndex: -1,
                        goFalg: false
                    };
                },
                computed: _objectSpread(_objectSpread({}, (0, _vuex.mapState)("img", [ "image" ])), (0, 
                _vuex.mapState)("logoUser", [ "challengesNum", "userInfo", "baseURl", "top" ])),
                onShareAppMessage: function onShareAppMessage(res) {
                    if (res.from === "button") {
                        // 来自页面内分享按钮
                        console.log(res.target);
                    }
                    if (this.shareIndex >= 0) {
                        this.setShareTask(this.shareIndex);
                    } else {
                        var index = this.missionMain_list.findIndex(function(item, index) {
                            console.log(item.task_name.includes("邀请好友"));
                            return item.task_name.includes("邀请好友");
                        });
                        console.log(index, "index");
                        this.setShareTask(index);
                    }
                    return {
                        title: "1分钟极限挑战课本里的博物题",
                        path: "pages/index/index",
                        imageUrl: this.image.hbBg,
                        success: function success() {
                            console.log("hjhjkkjhkjhkjhjk");
                        }
                    };
                },
                created: function created() {
                    this.getTaskList();
                },
                onShow: function onShow() {
                    this.setShareChallenge();
                    if (this.taskIndex) {
                        this.missionMain_list[this.taskIndex].falg = false;
                    }
                },
                beforeDestroy: function beforeDestroy() {
                    clearTimeout(this.timer);
                },
                methods: _objectSpread(_objectSpread({}, (0, _vuex.mapMutations)("logoUser", [ "SET_CHALLENGSNUM_ADD" ])), {}, {
                    // 任务领取
                    toFinish: function toFinish(item, index) {
                        var _this = this;
                        this.goFalg = true;
                        var task_jump_url = item.task_jump_url, chance_add_num = item.chance_add_num, id = item.id, task_name = item.task_name, btnFalg = item.btnFalg, falg = item.falg;
                        console.log(task_jump_url, chance_add_num);
                        // toFinish(item.task_jump_url,index,item.chance_add_num)
                                                if (task_jump_url) {
                            uni.navigateTo({
                                url: "/page_link/link/link?url=".concat(encodeURIComponent(task_jump_url), "&flag=true")
                            });
                            setTimeout(function() {
                                _this.missionMain_list[index].falg = false;
                            }, 1e3);
                        }
                        if (index == 0) {
                            this.shareIndex = index;
                        } else if (task_name.includes("视频号")) {
                            this.taskIndex = index;
                            wx.openChannelsUserProfile({
                                finderUserName: "sphu9nIbcaiPqSR",
                                success: function success(res) {
                                    console.log("hkjhkjhkjhkj");
                                },
                                fail: function fail(res) {
                                    console.error(res);
                                }
                            });
                        } else if (task_name.includes("公众号")) {
                            this.taskIndex = index;
                            // uni.showToast({
                            // 	title: '请完成下方公众号关注',
                            // 	icon:'none',
                            // 	duration: 2000
                            // });
                                                        uni.navigateTo({
                                url: "/page_link/link/link?url=".concat(encodeURIComponent("https://mp.weixin.qq.com/s?__biz=Mzg3NjcyODA2Ng==&mid=2247488333&idx=1&sn=1a6b5f5b4561bfa62f814ddcbe7e9961&chksm=cf2c8920f85b0036b34bde2ad79815b280d8d2f6d85eca2b2b9e723cbe08379ba36a7b4654e6#rd"), "&flag=true")
                            });
                            console.log(1232123);
                        }
                        setTimeout(function() {
                            falg ? _this.setUpdateChance(chance_add_num, id) : "";
                        }, 2e3);
                    },
                    // 处理分享好友任务
                    setShareTask: function setShareTask(index) {
                        this.missionMain_list[index].complete_num++;
                        if (this.missionMain_list[index].complete_num == this.missionMain_list[index].task_chance) {
                            this.missionMain_list[index].falg = false;
                        }
                    },
                    goHome: function goHome() {
                        uni.navigateBack({
                            delta: 1
                        });
                    },
                    setUpdateChance: function setUpdateChance(chance_add_num, id) {
                        var _this2 = this;
                        console.log(2313212321, chance_add_num);
                        this.SET_CHALLENGSNUM_ADD(chance_add_num);
                        var obj = {
                            phone: this.userInfo.phone,
                            chance: this.challengesNum
                        };
                        (0, _index.updateChance)(obj).then(function(res) {
                            console.log(res, "res1111111");
                            _this2.goFalg = false;
                        });
                        this.updateUserTask(chance_add_num, id);
                    },
                    getTaskList: function getTaskList() {
                        var _this3 = this;
                        (0, _index2.taskList)(this.userInfo.phone).then(function(res) {
                            if (res.data.task_list.length > 0) {
                                _this3.missionMain_list = res.data.task_list.map(function(item) {
                                    var obj = res.data.user_task.find(function(_item) {
                                        return _item.task_id == item.id;
                                    });
                                    if (item.task_type) {
                                        item["icon"] = _this3.iconObj[item.task_type];
                                    } else {
                                        item["icon"] = _this3.image.search;
                                    }
                                    if (item.task_type == 1 && item.task_name.includes("邀请好友")) {
                                        item["complete_num"] = obj ? obj.complete_num : 0;
                                    }
                                    console.log(obj, "objjksjdklkjk");
                                    if (obj) {
                                        item["falg"] = obj.complete_num >= item.task_chance ? false : true;
                                    } else {
                                        item["falg"] = true;
                                    }
                                    if (!item.task_name.includes("邀请好友") && !item.task_name.includes("公众号")) {
                                        item["btnFalg"] = true;
                                    }
                                    return item;
                                });
                            }
                            if (res.data.user_task.length > 0) {
                                _this3.user_task = res.data.user_task;
                            }
                            console.log(res, "lkjljljlj", _this3.missionMain_list);
                        });
                    },
                    updateUserTask: function updateUserTask(chance_add_num, id) {
                        var obj = {
                            phone: this.userInfo.phone,
                            task_id: id,
                            chance_add_num: chance_add_num
                        };
                        (0, _index2.userTask)(obj).then(function(res) {
                            console.log(res, "khkjlkjlkj");
                        });
                    },
                    setShareChallenge: function setShareChallenge() {
                        var _this4 = this;
                        // uni.showLoading({
                        // 	title: '加载中'
                        // });
                                                (0, _index.shareChallenge)().then(function(res) {
                            // uni.hideLoading();
                            // uni.showToast({
                            // 	title: '长按保存图片，发送朋友圈，邀请更多朋友参与挑战',
                            // 	icon:'none',
                            // 	duration: 2000
                            // });
                            _this4.shareUrl = "".concat(_this4.baseURl).concat(res.data);
                            // uni.previewImage({
                            // 	urls: [`${this.shareUrl}`],
                            // 	longPressActions: {
                            // 		itemList: ['发送给朋友', '保存图片', '收藏','识别二维码'],
                            // 		success: function(data) {
                            // 			console.log('选中了第' + (data.tapIndex + 1) + '个按钮,第' + (data.index + 1) + '张图片');
                            // 		},
                            // 		fail: function(err) {
                            // 			console.log(err.errMsg);
                            // 		}
                            // 	}
                            // });
                                                });
                    }
                })
            };
            exports.default = _default;
            /* WEBPACK VAR INJECTION */        }).call(this, __webpack_require__(
        /*! ./node_modules/@dcloudio/uni-mp-weixin/dist/index.js */
        1)["default"]);
        /***/    },
    /***/
    208: 
    /*!************************************************************************************************************************************************************************************!*\
    !*** C:/Users/86188/Desktop/文物项目/开发/cultural-edu/future-mini-program/page_missionCenter/missionCenter/missionCenter.vue?vue&type=style&index=0&id=1fd78d7a&lang=scss&scoped=true& ***!
    \************************************************************************************************************************************************************************************/
    /*! no static exports found */
    /***/
    function _(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony import */        var _D_soft_HBuilderX_plugins_uniapp_cli_node_modules_mini_css_extract_plugin_dist_loader_js_ref_8_oneOf_1_0_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_css_loader_dist_cjs_js_ref_8_oneOf_1_1_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_loaders_stylePostLoader_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_8_oneOf_1_2_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_postcss_loader_src_index_js_ref_8_oneOf_1_3_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_sass_loader_dist_cjs_js_ref_8_oneOf_1_4_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_8_oneOf_1_5_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_missionCenter_vue_vue_type_style_index_0_id_1fd78d7a_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
        /*! -!./node_modules/mini-css-extract-plugin/dist/loader.js??ref--8-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--8-oneOf-1-1!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader??ref--8-oneOf-1-2!./node_modules/postcss-loader/src??ref--8-oneOf-1-3!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/sass-loader/dist/cjs.js??ref--8-oneOf-1-4!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader??ref--8-oneOf-1-5!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib??vue-loader-options!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!./missionCenter.vue?vue&type=style&index=0&id=1fd78d7a&lang=scss&scoped=true& */
        209);
        /* harmony import */        var _D_soft_HBuilderX_plugins_uniapp_cli_node_modules_mini_css_extract_plugin_dist_loader_js_ref_8_oneOf_1_0_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_css_loader_dist_cjs_js_ref_8_oneOf_1_1_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_loaders_stylePostLoader_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_8_oneOf_1_2_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_postcss_loader_src_index_js_ref_8_oneOf_1_3_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_sass_loader_dist_cjs_js_ref_8_oneOf_1_4_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_8_oneOf_1_5_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_missionCenter_vue_vue_type_style_index_0_id_1fd78d7a_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /* */ __webpack_require__.n(_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_mini_css_extract_plugin_dist_loader_js_ref_8_oneOf_1_0_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_css_loader_dist_cjs_js_ref_8_oneOf_1_1_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_loaders_stylePostLoader_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_8_oneOf_1_2_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_postcss_loader_src_index_js_ref_8_oneOf_1_3_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_sass_loader_dist_cjs_js_ref_8_oneOf_1_4_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_8_oneOf_1_5_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_missionCenter_vue_vue_type_style_index_0_id_1fd78d7a_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
        /* harmony reexport (unknown) */        for (var __WEBPACK_IMPORT_KEY__ in _D_soft_HBuilderX_plugins_uniapp_cli_node_modules_mini_css_extract_plugin_dist_loader_js_ref_8_oneOf_1_0_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_css_loader_dist_cjs_js_ref_8_oneOf_1_1_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_loaders_stylePostLoader_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_8_oneOf_1_2_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_postcss_loader_src_index_js_ref_8_oneOf_1_3_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_sass_loader_dist_cjs_js_ref_8_oneOf_1_4_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_8_oneOf_1_5_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_missionCenter_vue_vue_type_style_index_0_id_1fd78d7a_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) {
            if (__WEBPACK_IMPORT_KEY__ !== "default") (function(key) {
                __webpack_require__.d(__webpack_exports__, key, function() {
                    return _D_soft_HBuilderX_plugins_uniapp_cli_node_modules_mini_css_extract_plugin_dist_loader_js_ref_8_oneOf_1_0_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_css_loader_dist_cjs_js_ref_8_oneOf_1_1_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_loaders_stylePostLoader_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_8_oneOf_1_2_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_postcss_loader_src_index_js_ref_8_oneOf_1_3_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_sass_loader_dist_cjs_js_ref_8_oneOf_1_4_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_8_oneOf_1_5_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_missionCenter_vue_vue_type_style_index_0_id_1fd78d7a_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key];
                });
            })(__WEBPACK_IMPORT_KEY__);
        }
        /* harmony default export */        __webpack_exports__["default"] = _D_soft_HBuilderX_plugins_uniapp_cli_node_modules_mini_css_extract_plugin_dist_loader_js_ref_8_oneOf_1_0_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_css_loader_dist_cjs_js_ref_8_oneOf_1_1_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_loaders_stylePostLoader_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_8_oneOf_1_2_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_postcss_loader_src_index_js_ref_8_oneOf_1_3_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_sass_loader_dist_cjs_js_ref_8_oneOf_1_4_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_8_oneOf_1_5_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_missionCenter_vue_vue_type_style_index_0_id_1fd78d7a_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default.a;
        /***/    },
    /***/
    209: 
    /*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
    !*** ./node_modules/mini-css-extract-plugin/dist/loader.js??ref--8-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--8-oneOf-1-1!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader??ref--8-oneOf-1-2!./node_modules/postcss-loader/src??ref--8-oneOf-1-3!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/sass-loader/dist/cjs.js??ref--8-oneOf-1-4!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader??ref--8-oneOf-1-5!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib??vue-loader-options!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!C:/Users/86188/Desktop/文物项目/开发/cultural-edu/future-mini-program/page_missionCenter/missionCenter/missionCenter.vue?vue&type=style&index=0&id=1fd78d7a&lang=scss&scoped=true& ***!
    \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
    /*! no static exports found */
    /***/
    function _(module, exports, __webpack_require__) {
        // extracted by mini-css-extract-plugin
        if (false) {
            var cssReload;
        }
        /***/    }
}, [ [ 201, "common/runtime", "common/vendor", "page_missionCenter/common/vendor" ] ] ]);