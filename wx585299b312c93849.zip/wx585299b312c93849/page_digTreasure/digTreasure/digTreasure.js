require("../common/vendor.js");

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "page_digTreasure/digTreasure/digTreasure" ], {
    /***/
    130: 
    /*!***************************************************************************************************************************************!*\
    !*** C:/Users/86188/Desktop/文物项目/开发/cultural-edu/future-mini-program/main.js?{"page":"page_digTreasure%2FdigTreasure%2FdigTreasure"} ***!
    \***************************************************************************************************************************************/
    /*! no static exports found */
    /***/
    function _(module, exports, __webpack_require__) {
        "use strict";
        /* WEBPACK VAR INJECTION */
        /* WEBPACK VAR INJECTION */        
        /* WEBPACK VAR INJECTION */
        /* WEBPACK VAR INJECTION */
        (function(createPage) {
            __webpack_require__(
            /*! uni-pages */
            5);
            var _vue = _interopRequireDefault(__webpack_require__(
            /*! vue */
            4));
            var _digTreasure = _interopRequireDefault(__webpack_require__(
            /*! ./page_digTreasure/digTreasure/digTreasure.vue */
            131));
            function _interopRequireDefault(obj) {
                return obj && obj.__esModule ? obj : {
                    default: obj
                };
            }
            // @ts-ignore
                        wx.__webpack_require_UNI_MP_PLUGIN__ = __webpack_require__;
            createPage(_digTreasure.default);
            /* WEBPACK VAR INJECTION */        }).call(this, __webpack_require__(
        /*! ./node_modules/@dcloudio/uni-mp-weixin/dist/index.js */
        1)["createPage"]);
        /***/    },
    /***/
    131: 
    /*!********************************************************************************************************************!*\
    !*** C:/Users/86188/Desktop/文物项目/开发/cultural-edu/future-mini-program/page_digTreasure/digTreasure/digTreasure.vue ***!
    \********************************************************************************************************************/
    /*! no static exports found */
    /***/
    function _(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony import */        var _digTreasure_vue_vue_type_template_id_3c08bc33_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
        /*! ./digTreasure.vue?vue&type=template&id=3c08bc33&scoped=true& */
        132);
        /* harmony import */        var _digTreasure_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
        /*! ./digTreasure.vue?vue&type=script&lang=js& */
        148);
        /* harmony reexport (unknown) */        for (var __WEBPACK_IMPORT_KEY__ in _digTreasure_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__) {
            if (__WEBPACK_IMPORT_KEY__ !== "default") (function(key) {
                __webpack_require__.d(__webpack_exports__, key, function() {
                    return _digTreasure_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__[key];
                });
            })(__WEBPACK_IMPORT_KEY__);
        }
        /* harmony import */        var _digTreasure_vue_vue_type_style_index_0_id_3c08bc33_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
        /*! ./digTreasure.vue?vue&type=style&index=0&id=3c08bc33&lang=scss&scoped=true& */
        150);
        /* harmony import */        var _D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
        /*! ./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/runtime/componentNormalizer.js */
        17);
        var renderjs;
        /* normalize component */        var component = Object(_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(_digTreasure_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"], _digTreasure_vue_vue_type_template_id_3c08bc33_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"], _digTreasure_vue_vue_type_template_id_3c08bc33_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"], false, null, "3c08bc33", null, false, _digTreasure_vue_vue_type_template_id_3c08bc33_scoped_true___WEBPACK_IMPORTED_MODULE_0__["components"], renderjs);
        component.options.__file = "page_digTreasure/digTreasure/digTreasure.vue";
        /* harmony default export */        __webpack_exports__["default"] = component.exports;
        /***/    },
    /***/
    132: 
    /*!***************************************************************************************************************************************************************!*\
    !*** C:/Users/86188/Desktop/文物项目/开发/cultural-edu/future-mini-program/page_digTreasure/digTreasure/digTreasure.vue?vue&type=template&id=3c08bc33&scoped=true& ***!
    \***************************************************************************************************************************************************************/
    /*! exports provided: render, staticRenderFns, recyclableRender, components */
    /***/
    function _(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony import */        var _D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_16_0_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_template_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_uni_app_loader_page_meta_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_digTreasure_vue_vue_type_template_id_3c08bc33_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
        /*! -!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader??ref--16-0!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/template.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-uni-app-loader/page-meta.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib??vue-loader-options!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!./digTreasure.vue?vue&type=template&id=3c08bc33&scoped=true& */
        133);
        /* harmony reexport (safe) */        __webpack_require__.d(__webpack_exports__, "render", function() {
            return _D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_16_0_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_template_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_uni_app_loader_page_meta_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_digTreasure_vue_vue_type_template_id_3c08bc33_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"];
        });
        /* harmony reexport (safe) */        __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() {
            return _D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_16_0_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_template_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_uni_app_loader_page_meta_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_digTreasure_vue_vue_type_template_id_3c08bc33_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"];
        });
        /* harmony reexport (safe) */        __webpack_require__.d(__webpack_exports__, "recyclableRender", function() {
            return _D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_16_0_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_template_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_uni_app_loader_page_meta_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_digTreasure_vue_vue_type_template_id_3c08bc33_scoped_true___WEBPACK_IMPORTED_MODULE_0__["recyclableRender"];
        });
        /* harmony reexport (safe) */        __webpack_require__.d(__webpack_exports__, "components", function() {
            return _D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_16_0_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_template_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_uni_app_loader_page_meta_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_digTreasure_vue_vue_type_template_id_3c08bc33_scoped_true___WEBPACK_IMPORTED_MODULE_0__["components"];
        });
        /***/    },
    /***/
    133: 
    /*!***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
    !*** ./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader??ref--16-0!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/template.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-uni-app-loader/page-meta.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib??vue-loader-options!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!C:/Users/86188/Desktop/文物项目/开发/cultural-edu/future-mini-program/page_digTreasure/digTreasure/digTreasure.vue?vue&type=template&id=3c08bc33&scoped=true& ***!
    \***************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
    /*! exports provided: render, staticRenderFns, recyclableRender, components */
    /***/
    function _(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony export (binding) */        __webpack_require__.d(__webpack_exports__, "render", function() {
            return render;
        });
        /* harmony export (binding) */        __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() {
            return staticRenderFns;
        });
        /* harmony export (binding) */        __webpack_require__.d(__webpack_exports__, "recyclableRender", function() {
            return recyclableRender;
        });
        /* harmony export (binding) */        __webpack_require__.d(__webpack_exports__, "components", function() {
            return components;
        });
        var components;
        var render = function render() {
            var _vm = this;
            var _h = _vm.$createElement;
            var _c = _vm._self._c || _h;
            var l0 = _vm.__map(_vm.carArr, function(item, index) {
                var $orig = _vm.__get_orig(item);
                var m0 = !item.flag ? __webpack_require__(134)("./" + item.id + ".png") : null;
                return {
                    $orig: $orig,
                    m0: m0
                };
            });
            _vm.$mp.data = Object.assign({}, {
                $root: {
                    l0: l0
                }
            });
        };
        var recyclableRender = false;
        var staticRenderFns = [];
        render._withStripped = true;
        /***/    },
    /***/
    148: 
    /*!*********************************************************************************************************************************************!*\
    !*** C:/Users/86188/Desktop/文物项目/开发/cultural-edu/future-mini-program/page_digTreasure/digTreasure/digTreasure.vue?vue&type=script&lang=js& ***!
    \*********************************************************************************************************************************************/
    /*! no static exports found */
    /***/
    function _(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony import */        var _D_soft_HBuilderX_plugins_uniapp_cli_node_modules_babel_loader_lib_index_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_12_1_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_script_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_digTreasure_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
        /*! -!./node_modules/babel-loader/lib!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader??ref--12-1!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/script.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib??vue-loader-options!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!./digTreasure.vue?vue&type=script&lang=js& */
        149);
        /* harmony import */        var _D_soft_HBuilderX_plugins_uniapp_cli_node_modules_babel_loader_lib_index_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_12_1_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_script_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_digTreasure_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0___default = /* */ __webpack_require__.n(_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_babel_loader_lib_index_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_12_1_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_script_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_digTreasure_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__);
        /* harmony reexport (unknown) */        for (var __WEBPACK_IMPORT_KEY__ in _D_soft_HBuilderX_plugins_uniapp_cli_node_modules_babel_loader_lib_index_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_12_1_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_script_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_digTreasure_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__) {
            if (__WEBPACK_IMPORT_KEY__ !== "default") (function(key) {
                __webpack_require__.d(__webpack_exports__, key, function() {
                    return _D_soft_HBuilderX_plugins_uniapp_cli_node_modules_babel_loader_lib_index_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_12_1_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_script_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_digTreasure_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__[key];
                });
            })(__WEBPACK_IMPORT_KEY__);
        }
        /* harmony default export */        __webpack_exports__["default"] = _D_soft_HBuilderX_plugins_uniapp_cli_node_modules_babel_loader_lib_index_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_12_1_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_script_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_digTreasure_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0___default.a;
        /***/    },
    /***/
    149: 
    /*!****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
    !*** ./node_modules/babel-loader/lib!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader??ref--12-1!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/script.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib??vue-loader-options!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!C:/Users/86188/Desktop/文物项目/开发/cultural-edu/future-mini-program/page_digTreasure/digTreasure/digTreasure.vue?vue&type=script&lang=js& ***!
    \****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
    /*! no static exports found */
    /***/
    function _(module, exports, __webpack_require__) {
        "use strict";
        /* WEBPACK VAR INJECTION */
        /* WEBPACK VAR INJECTION */        
        /* WEBPACK VAR INJECTION */
        /* WEBPACK VAR INJECTION */
        (function(uni) {
            Object.defineProperty(exports, "__esModule", {
                value: true
            });
            exports.default = void 0;
            var _vuex = __webpack_require__(
            /*! vuex */
            13);
            var _digTreasure = __webpack_require__(
            /*! @/api/digTreasure */
            14);
            var _index2 = __webpack_require__(
            /*! @/api/index.js */
            12);
            function ownKeys(object, enumerableOnly) {
                var keys = Object.keys(object);
                if (Object.getOwnPropertySymbols) {
                    var symbols = Object.getOwnPropertySymbols(object);
                    if (enumerableOnly) symbols = symbols.filter(function(sym) {
                        return Object.getOwnPropertyDescriptor(object, sym).enumerable;
                    });
                    keys.push.apply(keys, symbols);
                }
                return keys;
            }
            function _objectSpread(target) {
                for (var i = 1; i < arguments.length; i++) {
                    var source = arguments[i] != null ? arguments[i] : {};
                    if (i % 2) {
                        ownKeys(Object(source), true).forEach(function(key) {
                            _defineProperty(target, key, source[key]);
                        });
                    } else if (Object.getOwnPropertyDescriptors) {
                        Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
                    } else {
                        ownKeys(Object(source)).forEach(function(key) {
                            Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
                        });
                    }
                }
                return target;
            }
            function _defineProperty(obj, key, value) {
                if (key in obj) {
                    Object.defineProperty(obj, key, {
                        value: value,
                        enumerable: true,
                        configurable: true,
                        writable: true
                    });
                } else {
                    obj[key] = value;
                }
                return obj;
            }
            var _default = {
                data: function data() {
                    return {
                        old: {
                            scrollTop: 0
                        },
                        carArr: [ {
                            id: 1,
                            flag: false
                        }, {
                            id: 2,
                            flag: false
                        }, {
                            id: 3,
                            flag: false
                        }, {
                            id: 4,
                            flag: false
                        }, {
                            id: 5,
                            flag: false
                        }, {
                            id: 6,
                            flag: false
                        }, {
                            id: 7,
                            flag: false
                        }, {
                            id: 8,
                            flag: false
                        }, {
                            id: 9,
                            flag: false
                        }, {
                            id: 10,
                            flag: false
                        }, {
                            id: 11,
                            flag: false
                        }, {
                            id: 12,
                            flag: false
                        } ],
                        conversionBtnFlag: true,
                        treasureBtnFlag: false,
                        againChallengeFlag: false,
                        digTreasureFlag: false,
                        shadeFlag: 1,
                        animationData: {},
                        timer: null,
                        isDisable: true,
                        scaleNum: .1,
                        lotteryImg: null,
                        lotteryTitImg: null,
                        checkImgUrl: null,
                        // entity_titile 				// entity_titile
                        // 1-卡片 2-实物
                        treasureType: 1,
                        entityTitile: null,
                        imgFalg: false,
                        imgId: null,
                        entityImg: null,
                        newsNumFlag: false,
                        conversionFlag: false,
                        conversionFlagOk: false
                    };
                },
                computed: _objectSpread(_objectSpread(_objectSpread({}, (0, _vuex.mapState)("img", [ "image" ])), (0, 
                _vuex.mapState)("logoUser", [ "userInfo", "baseURl", "treasureNum", "top" ])), (0, 
                _vuex.mapState)("digTreasure", [ "userCardsList" ])),
                onShow: function onShow() {
                    var _this = this;
                    (0, _index2.prizeList)(this.userInfo.phone).then(function(res) {
                        if (res.data.length > 0) {
                            _this.newsNumFlag = true;
                            res.data.forEach(function(item) {
                                if (item.prize_id == 15) {
                                    _this.conversionFlagOk = true;
                                }
                            });
                        }
                    });
                },
                created: function created() {
                    console.log(this.userCardsList);
                    var animation = uni.createAnimation({
                        duration: 1e3,
                        timingFunction: "ease"
                    });
                    this.animation = animation;
                    this.updateCards();
                },
                watch: {
                    treasureNum: {
                        handler: function handler(newVal, oldVal) {
                            if (newVal <= 0) {
                                this.treasureBtnFlag = true;
                            }
                        },
                        immediate: true,
                        deep: true
                    }
                },
                methods: _objectSpread(_objectSpread(_objectSpread({}, (0, _vuex.mapMutations)("digTreasure", [ "SET_USERCARDSLIST" ])), (0, 
                _vuex.mapMutations)("logoUser", [ "SET_TREASURENUM_MINUS_ONE" ])), {}, {
                    goHome: function goHome() {
                        uni.navigateBack({
                            delta: 1
                        });
                    },
                    scroll: function scroll(e) {
                        console.log(e);
                        this.old.scrollTop = e.detail.scrollTop;
                    },
                    againChallenge: function againChallenge() {
                        this.againChallengeFlag = !this.againChallengeFlag;
                    },
                    digTreasure: function digTreasure() {
                        this.digTreasureFlag = !this.digTreasureFlag;
                    },
                    // 挖宝
                    goDigTreasure: function goDigTreasure() {
                        var _this2 = this;
                        if (!this.treasureBtnFlag) {
                            console.log(21321, this.isDisable);
                            this.shadeFlag = 3;
                            setTimeout(function() {
                                _this2.setLotteryStart(true);
                            }, 1e3);
                        } else {
                            uni.showToast({
                                title: "没有挖宝次数啦，快去挑战增加次数吧",
                                icon: "none"
                            });
                        }
                    },
                    goLook: function goLook() {
                        this.animationData = {};
                        this.shadeFlag = 1;
                        if (this.conversionFlag) {
                            uni.redirectTo({
                                url: "/page_prize_center/prize_center/prize_center"
                            });
                        }
                    },
                    animationShow: function animationShow() {
                        var _this3 = this;
                        this.animationData = {};
                        this.scaleNum = 0;
                        var timer = setInterval(function() {
                            _this3.scaleNum += .1;
                            console.log(_this3.scaleNum);
                            if (_this3.scaleNum >= 1) {
                                clearInterval(timer);
                            }
                        }, 20);
                        // this.animation.scale(0, 0).step()
                        // // this.timer = setTimeout(()=>{
                        // 	this.animation.rotate(-180).scale(0.3, 0.3).rotate(-90).scale(0.6, 0.6).rotate(20).scale(0.9, 0.9).rotate(180).scale(1, 1).step()
                        // 	this.animation.rotate(0).scale(1, 1).step()
                        // 	this.animationData = this.animation.export()
                        // 	console.log(21231,'kjhhjkkj');
                        // }, 50)
                                        },
                    animationShowAgain: function animationShowAgain() {
                        var _this4 = this;
                        this.animation.translate(-500, 0).step({
                            duration: 1e3
                        });
                        this.animationData = this.animation.export();
                        this.timer = setTimeout(function() {
                            _this4.animation.translate(0).step();
                            _this4.animationData = _this4.animation.export();
                        }, 1e3);
                    },
                    setLotteryStart: function setLotteryStart(flag) {
                        var _this5 = this;
                        if (this.isDisable) {
                            this.isDisable = false;
                            (0, _digTreasure.lotteryStart)(this.userInfo.phone).then(function(res) {
                                if (res.data[0].type < 3) {
                                    _this5.treasureType = 1;
                                    _this5.lotteryImg = "".concat(_this5.baseURl, "/static/lottery_pics/larg_pic/").concat(res.data[0].id, ".png");
                                    _this5.setUserCards();
                                } else {
                                    _this5.treasureType = 2;
                                    _this5.entityTitile = res.data[0].prize_name;
                                    _this5.entityImg = "".concat(_this5.baseURl, "/static/real_prize/").concat(res.data[0].id, ".png");
                                    _this5.lotteryTitImg = "".concat(_this5.baseURl, "/static/real_prize/").concat(res.data[0].id, "_tit.png");
                                }
                                if (flag) {
                                    _this5.shadeFlag = 2;
                                    _this5.animationShow();
                                }
                                _this5.isDisable = true;
                                _this5.setUpdateLotteryChance();
                            }).catch(function(err) {
                                _this5.shadeFlag = 1;
                            });
                        }
                    },
                    setUserCards: function setUserCards() {
                        var _this6 = this;
                        (0, _digTreasure.userCards)(this.userInfo.phone).then(function(res) {
                            _this6.SET_USERCARDSLIST(res.data);
                            _this6.updateCards();
                            _this6.isDisable = true;
                        });
                    },
                    updateCards: function updateCards() {
                        var _this7 = this;
                        this.userCardsList.forEach(function(item) {
                            var _index = _this7.carArr.findIndex(function(_item) {
                                return _item.id == item.card_id;
                            });
                            _this7.carArr[_index].flag = true;
                        });
                        var id = this.carArr.find(function(item) {
                            return item.flag;
                        }).id;
                        this.imgId = id;
                        this.checkImgUrl = "".concat(this.baseURl, "/static/lottery_pics/larg_pic/").concat(id, ".png");
                        if (this.carArr.every(function(item, index) {
                            return item.flag == true;
                        })) {
                            this.conversionBtnFlag = false;
                        }
                        console.log(this.treasureBtnFlag, 8098098);
                    },
                    // 点击查看卡片
                    checkImg: function checkImg(id, falg) {
                        if (falg) {
                            this.imgId != id ? this.imgFalg = false : "";
                            this.imgId = id;
                            console.log(11111);
                            this.checkImgUrl = "".concat(this.baseURl, "/static/lottery_pics/larg_pic/").concat(id, ".png");
                        }
                    },
                    imgLoad: function imgLoad(event) {
                        this.imgFalg = true;
                    },
                    goPrize: function goPrize() {
                        uni.redirectTo({
                            url: "/page_prize_center/prize_center/prize_center"
                        });
                    },
                    // 更新挖宝次数
                    setUpdateLotteryChance: function setUpdateLotteryChance() {
                        this.SET_TREASURENUM_MINUS_ONE();
                        var obj = {
                            phone: this.userInfo.phone,
                            lotteryChance: this.treasureNum
                        };
                        console.log(obj, "jhgkjgjkh");
                        (0, _index2.updateLotteryChance)(obj);
                    },
                    goConversion: function goConversion() {
                        var _this8 = this;
                        if (!this.conversionBtnFlag && !this.conversionFlagOk) {
                            if (this.isDisable) {
                                this.isDisable = false;
                                this.shadeFlag = 3;
                                setTimeout(function() {
                                    (0, _digTreasure.convertPrize)({
                                        phone: _this8.userInfo.phone
                                    }).then(function(res) {
                                        _this8.treasureType = 2;
                                        _this8.entityTitile = res.data[0].prize_name;
                                        _this8.entityImg = "".concat(_this8.baseURl, "/static/real_prize/").concat(res.data[0].id, ".png");
                                        _this8.lotteryTitImg = "".concat(_this8.baseURl, "/static/real_prize/").concat(res.data[0].id, "_tit.png");
                                        _this8.shadeFlag = 2;
                                        _this8.animationShow();
                                    }).catch(function(err) {
                                        _this8.shadeFlag = 1;
                                    });
                                }, 1e3);
                                this.conversionFlag = true;
                            }
                            // uni.redirectTo({
                            // 	url: '/page_prize_center/prize_center/prize_center'
                            // });
                                                } else if (this.conversionBtnFlag) {
                            console.log(123231);
                            uni.showToast({
                                title: "集齐卡片后解锁,快去收集卡片吧",
                                icon: "none"
                            });
                        }
                    }
                })
            };
            exports.default = _default;
            /* WEBPACK VAR INJECTION */        }).call(this, __webpack_require__(
        /*! ./node_modules/@dcloudio/uni-mp-weixin/dist/index.js */
        1)["default"]);
        /***/    },
    /***/
    150: 
    /*!******************************************************************************************************************************************************************************!*\
    !*** C:/Users/86188/Desktop/文物项目/开发/cultural-edu/future-mini-program/page_digTreasure/digTreasure/digTreasure.vue?vue&type=style&index=0&id=3c08bc33&lang=scss&scoped=true& ***!
    \******************************************************************************************************************************************************************************/
    /*! no static exports found */
    /***/
    function _(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony import */        var _D_soft_HBuilderX_plugins_uniapp_cli_node_modules_mini_css_extract_plugin_dist_loader_js_ref_8_oneOf_1_0_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_css_loader_dist_cjs_js_ref_8_oneOf_1_1_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_loaders_stylePostLoader_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_8_oneOf_1_2_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_postcss_loader_src_index_js_ref_8_oneOf_1_3_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_sass_loader_dist_cjs_js_ref_8_oneOf_1_4_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_8_oneOf_1_5_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_digTreasure_vue_vue_type_style_index_0_id_3c08bc33_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
        /*! -!./node_modules/mini-css-extract-plugin/dist/loader.js??ref--8-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--8-oneOf-1-1!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader??ref--8-oneOf-1-2!./node_modules/postcss-loader/src??ref--8-oneOf-1-3!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/sass-loader/dist/cjs.js??ref--8-oneOf-1-4!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader??ref--8-oneOf-1-5!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib??vue-loader-options!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!./digTreasure.vue?vue&type=style&index=0&id=3c08bc33&lang=scss&scoped=true& */
        151);
        /* harmony import */        var _D_soft_HBuilderX_plugins_uniapp_cli_node_modules_mini_css_extract_plugin_dist_loader_js_ref_8_oneOf_1_0_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_css_loader_dist_cjs_js_ref_8_oneOf_1_1_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_loaders_stylePostLoader_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_8_oneOf_1_2_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_postcss_loader_src_index_js_ref_8_oneOf_1_3_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_sass_loader_dist_cjs_js_ref_8_oneOf_1_4_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_8_oneOf_1_5_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_digTreasure_vue_vue_type_style_index_0_id_3c08bc33_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /* */ __webpack_require__.n(_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_mini_css_extract_plugin_dist_loader_js_ref_8_oneOf_1_0_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_css_loader_dist_cjs_js_ref_8_oneOf_1_1_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_loaders_stylePostLoader_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_8_oneOf_1_2_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_postcss_loader_src_index_js_ref_8_oneOf_1_3_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_sass_loader_dist_cjs_js_ref_8_oneOf_1_4_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_8_oneOf_1_5_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_digTreasure_vue_vue_type_style_index_0_id_3c08bc33_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
        /* harmony reexport (unknown) */        for (var __WEBPACK_IMPORT_KEY__ in _D_soft_HBuilderX_plugins_uniapp_cli_node_modules_mini_css_extract_plugin_dist_loader_js_ref_8_oneOf_1_0_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_css_loader_dist_cjs_js_ref_8_oneOf_1_1_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_loaders_stylePostLoader_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_8_oneOf_1_2_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_postcss_loader_src_index_js_ref_8_oneOf_1_3_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_sass_loader_dist_cjs_js_ref_8_oneOf_1_4_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_8_oneOf_1_5_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_digTreasure_vue_vue_type_style_index_0_id_3c08bc33_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) {
            if (__WEBPACK_IMPORT_KEY__ !== "default") (function(key) {
                __webpack_require__.d(__webpack_exports__, key, function() {
                    return _D_soft_HBuilderX_plugins_uniapp_cli_node_modules_mini_css_extract_plugin_dist_loader_js_ref_8_oneOf_1_0_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_css_loader_dist_cjs_js_ref_8_oneOf_1_1_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_loaders_stylePostLoader_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_8_oneOf_1_2_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_postcss_loader_src_index_js_ref_8_oneOf_1_3_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_sass_loader_dist_cjs_js_ref_8_oneOf_1_4_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_8_oneOf_1_5_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_digTreasure_vue_vue_type_style_index_0_id_3c08bc33_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key];
                });
            })(__WEBPACK_IMPORT_KEY__);
        }
        /* harmony default export */        __webpack_exports__["default"] = _D_soft_HBuilderX_plugins_uniapp_cli_node_modules_mini_css_extract_plugin_dist_loader_js_ref_8_oneOf_1_0_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_css_loader_dist_cjs_js_ref_8_oneOf_1_1_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_loaders_stylePostLoader_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_8_oneOf_1_2_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_postcss_loader_src_index_js_ref_8_oneOf_1_3_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_sass_loader_dist_cjs_js_ref_8_oneOf_1_4_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_8_oneOf_1_5_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_digTreasure_vue_vue_type_style_index_0_id_3c08bc33_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default.a;
        /***/    },
    /***/
    151: 
    /*!**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
    !*** ./node_modules/mini-css-extract-plugin/dist/loader.js??ref--8-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--8-oneOf-1-1!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader??ref--8-oneOf-1-2!./node_modules/postcss-loader/src??ref--8-oneOf-1-3!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/sass-loader/dist/cjs.js??ref--8-oneOf-1-4!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader??ref--8-oneOf-1-5!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib??vue-loader-options!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!C:/Users/86188/Desktop/文物项目/开发/cultural-edu/future-mini-program/page_digTreasure/digTreasure/digTreasure.vue?vue&type=style&index=0&id=3c08bc33&lang=scss&scoped=true& ***!
    \**********************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
    /*! no static exports found */
    /***/
    function _(module, exports, __webpack_require__) {
        // extracted by mini-css-extract-plugin
        if (false) {
            var cssReload;
        }
        /***/    }
}, [ [ 130, "common/runtime", "common/vendor", "page_digTreasure/common/vendor" ] ] ]);