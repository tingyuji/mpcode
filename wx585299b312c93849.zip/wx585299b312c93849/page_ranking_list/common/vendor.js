(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "page_ranking_list/common/vendor" ], {
    /***/
    174: 
    /*!******************************************************************************************************!*\
    !*** C:/Users/86188/Desktop/文物项目/开发/cultural-edu/future-mini-program/api/page_ranking_list/index.js ***!
    \******************************************************************************************************/
    /*! no static exports found */
    /***/
    function _(module, exports, __webpack_require__) {
        "use strict";
        Object.defineProperty(exports, "__esModule", {
            value: true
        });
        exports.weekRank = weekRank;
        exports.totalRank = totalRank;
        var _request = _interopRequireDefault(__webpack_require__(
        /*! @/utils/request.js */
        10));
        function _interopRequireDefault(obj) {
            return obj && obj.__esModule ? obj : {
                default: obj
            };
        }
        // 周排名
                function weekRank() {
            return (0, _request.default)({
                url: "/rank/week-rank",
                method: "get"
            });
        }
        // 总排名
                function totalRank() {
            return (0, _request.default)({
                url: "/rank/total-rank",
                method: "get"
            });
        }
        /***/    }
} ]);