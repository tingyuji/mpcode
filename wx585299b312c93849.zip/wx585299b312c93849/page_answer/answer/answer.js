require("../../@babel/runtime/helpers/Arrayincludes");

require("../common/vendor.js");

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "page_answer/answer/answer" ], {
    /***/
    117: 
    /*!************************************************************************************************************************!*\
    !*** C:/Users/86188/Desktop/文物项目/开发/cultural-edu/future-mini-program/main.js?{"page":"page_answer%2Fanswer%2Fanswer"} ***!
    \************************************************************************************************************************/
    /*! no static exports found */
    /***/
    function _(module, exports, __webpack_require__) {
        "use strict";
        /* WEBPACK VAR INJECTION */
        /* WEBPACK VAR INJECTION */        
        /* WEBPACK VAR INJECTION */
        /* WEBPACK VAR INJECTION */
        (function(createPage) {
            __webpack_require__(
            /*! uni-pages */
            5);
            var _vue = _interopRequireDefault(__webpack_require__(
            /*! vue */
            4));
            var _answer = _interopRequireDefault(__webpack_require__(
            /*! ./page_answer/answer/answer.vue */
            118));
            function _interopRequireDefault(obj) {
                return obj && obj.__esModule ? obj : {
                    default: obj
                };
            }
            // @ts-ignore
                        wx.__webpack_require_UNI_MP_PLUGIN__ = __webpack_require__;
            createPage(_answer.default);
            /* WEBPACK VAR INJECTION */        }).call(this, __webpack_require__(
        /*! ./node_modules/@dcloudio/uni-mp-weixin/dist/index.js */
        1)["createPage"]);
        /***/    },
    /***/
    118: 
    /*!*****************************************************************************************************!*\
    !*** C:/Users/86188/Desktop/文物项目/开发/cultural-edu/future-mini-program/page_answer/answer/answer.vue ***!
    \*****************************************************************************************************/
    /*! no static exports found */
    /***/
    function _(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony import */        var _answer_vue_vue_type_template_id_b64efca0_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
        /*! ./answer.vue?vue&type=template&id=b64efca0&scoped=true& */
        119);
        /* harmony import */        var _answer_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
        /*! ./answer.vue?vue&type=script&lang=js& */
        121);
        /* harmony reexport (unknown) */        for (var __WEBPACK_IMPORT_KEY__ in _answer_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__) {
            if (__WEBPACK_IMPORT_KEY__ !== "default") (function(key) {
                __webpack_require__.d(__webpack_exports__, key, function() {
                    return _answer_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__[key];
                });
            })(__WEBPACK_IMPORT_KEY__);
        }
        /* harmony import */        var _answer_vue_vue_type_style_index_0_id_b64efca0_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
        /*! ./answer.vue?vue&type=style&index=0&id=b64efca0&lang=scss&scoped=true& */
        128);
        /* harmony import */        var _D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
        /*! ./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/runtime/componentNormalizer.js */
        17);
        var renderjs;
        /* normalize component */        var component = Object(_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(_answer_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"], _answer_vue_vue_type_template_id_b64efca0_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"], _answer_vue_vue_type_template_id_b64efca0_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"], false, null, "b64efca0", null, false, _answer_vue_vue_type_template_id_b64efca0_scoped_true___WEBPACK_IMPORTED_MODULE_0__["components"], renderjs);
        component.options.__file = "page_answer/answer/answer.vue";
        /* harmony default export */        __webpack_exports__["default"] = component.exports;
        /***/    },
    /***/
    119: 
    /*!************************************************************************************************************************************************!*\
    !*** C:/Users/86188/Desktop/文物项目/开发/cultural-edu/future-mini-program/page_answer/answer/answer.vue?vue&type=template&id=b64efca0&scoped=true& ***!
    \************************************************************************************************************************************************/
    /*! exports provided: render, staticRenderFns, recyclableRender, components */
    /***/
    function _(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony import */        var _D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_16_0_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_template_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_uni_app_loader_page_meta_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_answer_vue_vue_type_template_id_b64efca0_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
        /*! -!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader??ref--16-0!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/template.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-uni-app-loader/page-meta.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib??vue-loader-options!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!./answer.vue?vue&type=template&id=b64efca0&scoped=true& */
        120);
        /* harmony reexport (safe) */        __webpack_require__.d(__webpack_exports__, "render", function() {
            return _D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_16_0_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_template_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_uni_app_loader_page_meta_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_answer_vue_vue_type_template_id_b64efca0_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"];
        });
        /* harmony reexport (safe) */        __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() {
            return _D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_16_0_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_template_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_uni_app_loader_page_meta_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_answer_vue_vue_type_template_id_b64efca0_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"];
        });
        /* harmony reexport (safe) */        __webpack_require__.d(__webpack_exports__, "recyclableRender", function() {
            return _D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_16_0_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_template_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_uni_app_loader_page_meta_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_answer_vue_vue_type_template_id_b64efca0_scoped_true___WEBPACK_IMPORTED_MODULE_0__["recyclableRender"];
        });
        /* harmony reexport (safe) */        __webpack_require__.d(__webpack_exports__, "components", function() {
            return _D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_16_0_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_template_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_uni_app_loader_page_meta_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_answer_vue_vue_type_template_id_b64efca0_scoped_true___WEBPACK_IMPORTED_MODULE_0__["components"];
        });
        /***/    },
    /***/
    120: 
    /*!************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
    !*** ./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader??ref--16-0!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/template.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-uni-app-loader/page-meta.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib??vue-loader-options!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!C:/Users/86188/Desktop/文物项目/开发/cultural-edu/future-mini-program/page_answer/answer/answer.vue?vue&type=template&id=b64efca0&scoped=true& ***!
    \************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
    /*! exports provided: render, staticRenderFns, recyclableRender, components */
    /***/
    function _(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony export (binding) */        __webpack_require__.d(__webpack_exports__, "render", function() {
            return render;
        });
        /* harmony export (binding) */        __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() {
            return staticRenderFns;
        });
        /* harmony export (binding) */        __webpack_require__.d(__webpack_exports__, "recyclableRender", function() {
            return recyclableRender;
        });
        /* harmony export (binding) */        __webpack_require__.d(__webpack_exports__, "components", function() {
            return components;
        });
        var components;
        var render = function render() {
            var _vm = this;
            var _h = _vm.$createElement;
            var _c = _vm._self._c || _h;
            var l0 = _vm.option ? _vm.__map(_vm.option, function(item, index) {
                var $orig = _vm.__get_orig(item);
                var g0 = index.includes("q_option");
                return {
                    $orig: $orig,
                    g0: g0
                };
            }) : null;
            _vm.$mp.data = Object.assign({}, {
                $root: {
                    l0: l0
                }
            });
        };
        var recyclableRender = false;
        var staticRenderFns = [];
        render._withStripped = true;
        /***/    },
    /***/
    121: 
    /*!******************************************************************************************************************************!*\
    !*** C:/Users/86188/Desktop/文物项目/开发/cultural-edu/future-mini-program/page_answer/answer/answer.vue?vue&type=script&lang=js& ***!
    \******************************************************************************************************************************/
    /*! no static exports found */
    /***/
    function _(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony import */        var _D_soft_HBuilderX_plugins_uniapp_cli_node_modules_babel_loader_lib_index_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_12_1_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_script_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_answer_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
        /*! -!./node_modules/babel-loader/lib!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader??ref--12-1!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/script.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib??vue-loader-options!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!./answer.vue?vue&type=script&lang=js& */
        122);
        /* harmony import */        var _D_soft_HBuilderX_plugins_uniapp_cli_node_modules_babel_loader_lib_index_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_12_1_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_script_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_answer_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0___default = /* */ __webpack_require__.n(_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_babel_loader_lib_index_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_12_1_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_script_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_answer_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__);
        /* harmony reexport (unknown) */        for (var __WEBPACK_IMPORT_KEY__ in _D_soft_HBuilderX_plugins_uniapp_cli_node_modules_babel_loader_lib_index_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_12_1_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_script_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_answer_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__) {
            if (__WEBPACK_IMPORT_KEY__ !== "default") (function(key) {
                __webpack_require__.d(__webpack_exports__, key, function() {
                    return _D_soft_HBuilderX_plugins_uniapp_cli_node_modules_babel_loader_lib_index_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_12_1_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_script_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_answer_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__[key];
                });
            })(__WEBPACK_IMPORT_KEY__);
        }
        /* harmony default export */        __webpack_exports__["default"] = _D_soft_HBuilderX_plugins_uniapp_cli_node_modules_babel_loader_lib_index_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_12_1_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_script_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_answer_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0___default.a;
        /***/    },
    /***/
    122: 
    /*!*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
    !*** ./node_modules/babel-loader/lib!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader??ref--12-1!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/script.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib??vue-loader-options!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!C:/Users/86188/Desktop/文物项目/开发/cultural-edu/future-mini-program/page_answer/answer/answer.vue?vue&type=script&lang=js& ***!
    \*************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
    /*! no static exports found */
    /***/
    function _(module, exports, __webpack_require__) {
        "use strict";
        /* WEBPACK VAR INJECTION */
        /* WEBPACK VAR INJECTION */        
        /* WEBPACK VAR INJECTION */
        /* WEBPACK VAR INJECTION */
        (function(uni) {
            Object.defineProperty(exports, "__esModule", {
                value: true
            });
            exports.default = void 0;
            var _regenerator = _interopRequireDefault(__webpack_require__(
            /*! ./node_modules/@babel/runtime/regenerator */
            104));
            var _vuex = __webpack_require__(
            /*! vuex */
            13);
            var _index = __webpack_require__(
            /*! @/api/answer/index.js */
            11);
            var _util = __webpack_require__(
            /*! util */
            123);
            var _index2 = __webpack_require__(
            /*! @/api/index.js */
            12);
            function _interopRequireDefault(obj) {
                return obj && obj.__esModule ? obj : {
                    default: obj
                };
            }
            function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
                try {
                    var info = gen[key](arg);
                    var value = info.value;
                } catch (error) {
                    reject(error);
                    return;
                }
                if (info.done) {
                    resolve(value);
                } else {
                    Promise.resolve(value).then(_next, _throw);
                }
            }
            function _asyncToGenerator(fn) {
                return function() {
                    var self = this, args = arguments;
                    return new Promise(function(resolve, reject) {
                        var gen = fn.apply(self, args);
                        function _next(value) {
                            asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
                        }
                        function _throw(err) {
                            asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
                        }
                        _next(undefined);
                    });
                };
            }
            function ownKeys(object, enumerableOnly) {
                var keys = Object.keys(object);
                if (Object.getOwnPropertySymbols) {
                    var symbols = Object.getOwnPropertySymbols(object);
                    if (enumerableOnly) symbols = symbols.filter(function(sym) {
                        return Object.getOwnPropertyDescriptor(object, sym).enumerable;
                    });
                    keys.push.apply(keys, symbols);
                }
                return keys;
            }
            function _objectSpread(target) {
                for (var i = 1; i < arguments.length; i++) {
                    var source = arguments[i] != null ? arguments[i] : {};
                    if (i % 2) {
                        ownKeys(Object(source), true).forEach(function(key) {
                            _defineProperty(target, key, source[key]);
                        });
                    } else if (Object.getOwnPropertyDescriptors) {
                        Object.defineProperties(target, Object.getOwnPropertyDescriptors(source));
                    } else {
                        ownKeys(Object(source)).forEach(function(key) {
                            Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
                        });
                    }
                }
                return target;
            }
            function _defineProperty(obj, key, value) {
                if (key in obj) {
                    Object.defineProperty(obj, key, {
                        value: value,
                        enumerable: true,
                        configurable: true,
                        writable: true
                    });
                } else {
                    obj[key] = value;
                }
                return obj;
            }
            var _default = {
                data: function data() {
                    return {
                        num: 0,
                        time: 60,
                        timerId: null,
                        timeTxt: '60"',
                        option: null,
                        topicNum: 0,
                        optionFlagTrue: true,
                        optionKey: {
                            q_option_1: "A、",
                            q_option_2: "B、",
                            q_option_3: "C、",
                            q_option_4: "D、"
                        },
                        animationData: {},
                        topicArrLen: 1,
                        isDisable: true
                    };
                },
                computed: _objectSpread(_objectSpread(_objectSpread({}, (0, _vuex.mapState)("img", [ "image" ])), (0, 
                _vuex.mapState)("answer", [ "questionList", "topicArr", "optionList" ])), (0, _vuex.mapState)("logoUser", [ "baseURl", "top", "userInfo", "challengesNum" ])),
                mounted: function mounted() {
                    // this.topicNum = this.randomTopic(5, 0, 4)
                    this.topicNum = 0;
                    this.subjectSelection();
                    this.countDown();
                },
                created: function created() {
                    var _this2 = this;
                    return _asyncToGenerator(/* */ _regenerator.default.mark(function _callee() {
                        var _yield$todayScore, data;
                        return _regenerator.default.wrap(function _callee$(_context) {
                            while (1) {
                                switch (_context.prev = _context.next) {
                                  case 0:
                                    _context.next = 2;
                                    return (0, _index.todayScore)(_this2.userInfo);

                                  case 2:
                                    _yield$todayScore = _context.sent;
                                    data = _yield$todayScore.data;
                                    _this2.num = data;
                                    _this2.setUpdateChance();

                                  case 6:
                                  case "end":
                                    return _context.stop();
                                }
                            }
                        }, _callee);
                    }))();
                },
                destroyed: function destroyed() {
                    clearInterval(this.timerId);
                },
                methods: _objectSpread(_objectSpread(_objectSpread({}, (0, _vuex.mapMutations)("answer", [ "SET_TOPICARR", "SET_OPTIONLIST", "CLEAR_TOPICARR", "CLEAR_OPTIONLIST", "SET_QUESTIONLIST", "UPDATE_TODAY_SCORE" ])), (0, 
                _vuex.mapMutations)("logoUser", [ "SET_CHALLENGSNUM_ONE" ])), {}, {
                    // 随机题号
                    randomTopic: function randomTopic(len, start, end) {
                        var length = this.topicArr.length;
                        if (this.topicArr.length < len) {
                            var num = Math.floor((end - start + 1) * Math.random()) + start;
                            if (this.topicArr.indexOf(num) == -1) {
                                this.topicArr.push(num);
                            }
                            if (length >= this.topicArr.length && len != this.topicArr.length) {
                                this.randomTopic(len, start, end);
                            }
                        }
                        this.topicNum = this.topicArr[this.topicArr.length - 1];
                        if (length < len) {
                            return this.topicNum;
                        } else {
                            return this.topicNum = -1;
                        }
                    },
                    subjectSelection: function subjectSelection() {
                        if (this.topicNum != -1) {
                            var obj = JSON.parse(JSON.stringify(this.questionList[this.topicNum]));
                            for (var item in obj) {
                                if (item.includes("q_option")) {
                                    obj[item] = [ obj[item], this.image.notOption ];
                                }
                            }
                            this.option = obj;
                            console.log(this.option, "this.option");
                        }
                    },
                    goBack: function goBack() {
                        this.CLEAR_OPTIONLIST();
                        this.CLEAR_TOPICARR();
                        uni.navigateBack({
                            delta: 1
                        });
                    },
                    goEnd: function goEnd() {
                        uni.redirectTo({
                            url: "/page_answer_end/page_answer_end/page_answer_end"
                        });
                    },
                    select: function select(item) {
                        var _this3 = this;
                        if (this.isDisable) {
                            this.isDisable = false;
                            // for (let _item in this.option) {	// 你大爷的把我坑惨了（哭笑不得）
                                                        if (item == this.option["q_answer"]) {
                                this.option[item] = [ this.option[item][0], 1, this.image.questionAnswer ];
                                this.option["q_flag"] = true;
                                this.num++;
                            } else {
                                this.option[item] = [ this.option[item][0], 2, this.image.wrongAnswer ];
                                this.option[this.option["q_answer"]] = [ this.option[this.option["q_answer"]][0], this.image.notOptionT, this.image.questionAnswer ];
                                this.option["q_flag"] = false;
                            }
                            // }
                                                        console.log(this.option, "jhkhkjhkhkj");
                            this.SET_OPTIONLIST(this.option);
                            // this.topicNum = this.randomTopic(this.questionList.length, 0, this.questionList.length - 1)
                                                        if (this.topicNum < this.questionList.length - 1) {
                                setTimeout(function() {
                                    _this3.animationShow();
                                }, 1e3);
                            } else {
                                // 更新每日答题
                                this.pageJumps("答题结束");
                            }
                            (0, _index.updateTodayScore)(_objectSpread(_objectSpread({}, this.userInfo), {}, {
                                score: this.num
                            }));
                            this.UPDATE_TODAY_SCORE(this.num);
                        }
                    },
                    pageJumps: function pageJumps(title) {
                        this.getQuestionList();
                        var _this = this;
                        uni.showToast({
                            title: title,
                            icon: "loading",
                            success: function success() {
                                setTimeout(function() {
                                    _this.goEnd();
                                    _this.CLEAR_TOPICARR();
                                }, 500);
                            }
                        });
                    },
                    animationShow: function animationShow() {
                        var _this4 = this;
                        var animation = uni.createAnimation({
                            duration: 1e3,
                            timingFunction: "ease"
                        });
                        this.animation = animation;
                        this.animation.translate(-500, 0).step({
                            duration: 1e3
                        });
                        this.animationData = animation.export();
                        setTimeout(function() {
                            animation.translate(0).step();
                            _this4.animationData = animation.export();
                            ++_this4.topicNum;
                            _this4.subjectSelection();
                            // this.topicArrLen = this.topicArr.length
                                                        _this4.isDisable = true;
                        }, 500);
                    },
                    countDown: function countDown() {
                        var _this5 = this;
                        this.timerId = setInterval(function() {
                            _this5.time--;
                            _this5.timeTxt = _this5.time + '"';
                            if (_this5.time == 0) {
                                clearInterval(_this5.timerId);
                                _this5.pageJumps("答题结束");
                            }
                        }, 1e3);
                    },
                    // 刷新题库
                    getQuestionList: function getQuestionList() {
                        var _this6 = this;
                        (0, _index.questionList)().then(function(res) {
                            _this6.SET_QUESTIONLIST(res.data);
                        });
                    },
                    setUpdateChance: function setUpdateChance() {
                        console.log(21332);
                        this.SET_CHALLENGSNUM_ONE();
                        var obj = {
                            phone: this.userInfo.phone,
                            chance: this.challengesNum
                        };
                        console.log(obj, "obj");
                        (0, _index2.updateChance)(obj).then(function(res) {
                            console.log(res, "res1111111");
                        });
                    },
                    // 查看图片
                    lookImg: function lookImg(url) {
                        uni.previewImage({
                            urls: [ url ],
                            longPressActions: {
                                itemList: [ "发送给朋友", "保存图片", "收藏" ],
                                success: function success(data) {},
                                fail: function fail(err) {}
                            }
                        });
                    }
                })
            };
            exports.default = _default;
            /* WEBPACK VAR INJECTION */        }).call(this, __webpack_require__(
        /*! ./node_modules/@dcloudio/uni-mp-weixin/dist/index.js */
        1)["default"]);
        /***/    },
    /***/
    128: 
    /*!***************************************************************************************************************************************************************!*\
    !*** C:/Users/86188/Desktop/文物项目/开发/cultural-edu/future-mini-program/page_answer/answer/answer.vue?vue&type=style&index=0&id=b64efca0&lang=scss&scoped=true& ***!
    \***************************************************************************************************************************************************************/
    /*! no static exports found */
    /***/
    function _(module, __webpack_exports__, __webpack_require__) {
        "use strict";
        __webpack_require__.r(__webpack_exports__);
        /* harmony import */        var _D_soft_HBuilderX_plugins_uniapp_cli_node_modules_mini_css_extract_plugin_dist_loader_js_ref_8_oneOf_1_0_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_css_loader_dist_cjs_js_ref_8_oneOf_1_1_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_loaders_stylePostLoader_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_8_oneOf_1_2_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_postcss_loader_src_index_js_ref_8_oneOf_1_3_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_sass_loader_dist_cjs_js_ref_8_oneOf_1_4_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_8_oneOf_1_5_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_answer_vue_vue_type_style_index_0_id_b64efca0_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
        /*! -!./node_modules/mini-css-extract-plugin/dist/loader.js??ref--8-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--8-oneOf-1-1!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader??ref--8-oneOf-1-2!./node_modules/postcss-loader/src??ref--8-oneOf-1-3!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/sass-loader/dist/cjs.js??ref--8-oneOf-1-4!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader??ref--8-oneOf-1-5!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib??vue-loader-options!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!./answer.vue?vue&type=style&index=0&id=b64efca0&lang=scss&scoped=true& */
        129);
        /* harmony import */        var _D_soft_HBuilderX_plugins_uniapp_cli_node_modules_mini_css_extract_plugin_dist_loader_js_ref_8_oneOf_1_0_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_css_loader_dist_cjs_js_ref_8_oneOf_1_1_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_loaders_stylePostLoader_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_8_oneOf_1_2_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_postcss_loader_src_index_js_ref_8_oneOf_1_3_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_sass_loader_dist_cjs_js_ref_8_oneOf_1_4_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_8_oneOf_1_5_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_answer_vue_vue_type_style_index_0_id_b64efca0_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default = /* */ __webpack_require__.n(_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_mini_css_extract_plugin_dist_loader_js_ref_8_oneOf_1_0_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_css_loader_dist_cjs_js_ref_8_oneOf_1_1_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_loaders_stylePostLoader_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_8_oneOf_1_2_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_postcss_loader_src_index_js_ref_8_oneOf_1_3_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_sass_loader_dist_cjs_js_ref_8_oneOf_1_4_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_8_oneOf_1_5_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_answer_vue_vue_type_style_index_0_id_b64efca0_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__);
        /* harmony reexport (unknown) */        for (var __WEBPACK_IMPORT_KEY__ in _D_soft_HBuilderX_plugins_uniapp_cli_node_modules_mini_css_extract_plugin_dist_loader_js_ref_8_oneOf_1_0_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_css_loader_dist_cjs_js_ref_8_oneOf_1_1_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_loaders_stylePostLoader_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_8_oneOf_1_2_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_postcss_loader_src_index_js_ref_8_oneOf_1_3_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_sass_loader_dist_cjs_js_ref_8_oneOf_1_4_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_8_oneOf_1_5_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_answer_vue_vue_type_style_index_0_id_b64efca0_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__) {
            if (__WEBPACK_IMPORT_KEY__ !== "default") (function(key) {
                __webpack_require__.d(__webpack_exports__, key, function() {
                    return _D_soft_HBuilderX_plugins_uniapp_cli_node_modules_mini_css_extract_plugin_dist_loader_js_ref_8_oneOf_1_0_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_css_loader_dist_cjs_js_ref_8_oneOf_1_1_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_loaders_stylePostLoader_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_8_oneOf_1_2_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_postcss_loader_src_index_js_ref_8_oneOf_1_3_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_sass_loader_dist_cjs_js_ref_8_oneOf_1_4_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_8_oneOf_1_5_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_answer_vue_vue_type_style_index_0_id_b64efca0_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0__[key];
                });
            })(__WEBPACK_IMPORT_KEY__);
        }
        /* harmony default export */        __webpack_exports__["default"] = _D_soft_HBuilderX_plugins_uniapp_cli_node_modules_mini_css_extract_plugin_dist_loader_js_ref_8_oneOf_1_0_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_css_loader_dist_cjs_js_ref_8_oneOf_1_1_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_loaders_stylePostLoader_js_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_8_oneOf_1_2_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_postcss_loader_src_index_js_ref_8_oneOf_1_3_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_sass_loader_dist_cjs_js_ref_8_oneOf_1_4_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_webpack_preprocess_loader_index_js_ref_8_oneOf_1_5_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_vue_cli_plugin_uni_packages_vue_loader_lib_index_js_vue_loader_options_D_soft_HBuilderX_plugins_uniapp_cli_node_modules_dcloudio_webpack_uni_mp_loader_lib_style_js_answer_vue_vue_type_style_index_0_id_b64efca0_lang_scss_scoped_true___WEBPACK_IMPORTED_MODULE_0___default.a;
        /***/    },
    /***/
    129: 
    /*!*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
    !*** ./node_modules/mini-css-extract-plugin/dist/loader.js??ref--8-oneOf-1-0!./node_modules/css-loader/dist/cjs.js??ref--8-oneOf-1-1!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader??ref--8-oneOf-1-2!./node_modules/postcss-loader/src??ref--8-oneOf-1-3!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/sass-loader/dist/cjs.js??ref--8-oneOf-1-4!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/webpack-preprocess-loader??ref--8-oneOf-1-5!./node_modules/@dcloudio/vue-cli-plugin-uni/packages/vue-loader/lib??vue-loader-options!./node_modules/@dcloudio/webpack-uni-mp-loader/lib/style.js!C:/Users/86188/Desktop/文物项目/开发/cultural-edu/future-mini-program/page_answer/answer/answer.vue?vue&type=style&index=0&id=b64efca0&lang=scss&scoped=true& ***!
    \*******************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
    /*! no static exports found */
    /***/
    function _(module, exports, __webpack_require__) {
        // extracted by mini-css-extract-plugin
        if (false) {
            var cssReload;
        }
        /***/    }
}, [ [ 117, "common/runtime", "common/vendor", "page_answer/common/vendor" ] ] ]);