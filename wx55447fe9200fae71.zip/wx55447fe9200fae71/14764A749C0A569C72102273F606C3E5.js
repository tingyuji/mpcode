Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

exports.default = {
    zh_CN: {
        shareTitle: "Hello，推荐您一个MFA小程序，我也在使用哦~ 👍",
        Back: "返回",
        bat: "基于时间",
        batc: "基于计数器",
        ks: "密钥值太短",
        ke: "密钥值中含有非法字符",
        it: "输入账号详情",
        ih: "输入账户名称",
        ik: "输入你的密钥",
        add: "添加",
        nt: "注意：请妥善保管您的“密钥”或“二维码”信息，因离线数据存储极其不稳定，建议使用设置面板的“同步功能”以防止数据丢失",
        "task-ing": "執行中",
        ce: "操作失敗"
    },
    zh_HK: {
        shareTitle: "Hello，推薦您一個MFA小程序，我也在使用哦~ 👍",
        Back: "返回",
        bat: "基於時間",
        batc: "基於計數器",
        ks: "密鑰值太短",
        ke: "密鑰值中含有非法字符",
        it: "輸入賬號詳情",
        ih: "輸入賬戶名稱",
        ik: "輸入你的密鑰",
        add: "添加",
        nt: "注意：請妥善保管您的“密鑰”或“二維碼”信息，因離線數據存儲極其不穩定，建議使用設置面板的“同步功能”以防止數據丟失",
        "task-ing": "執行中",
        ce: "操作失敗"
    },
    en: {
        shareTitle: "Hello, I recommend an MFA Mini Program, I am also using it~ 👍",
        Back: "Back",
        bat: "Based on time",
        batc: "Counter based",
        ks: "The key value is too short",
        ke: "The key value contains illegal characters",
        it: "Enter account details",
        ih: "Enter account name",
        ik: "Enter your key",
        add: "Add",
        nt: 'Note: Please keep your "key" or "QR code" information properly, because offline data storage is extremely unstable, it is recommended to use the "sync function" of the settings panel to prevent data loss',
        "task-ing": "Executing",
        ce: "Op Failed"
    }
};