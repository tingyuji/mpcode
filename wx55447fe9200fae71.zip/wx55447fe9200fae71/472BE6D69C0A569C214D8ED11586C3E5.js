Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.byteLength = function(r) {
    return 3 * r.length / 4 - h(r);
}, exports.fromByteArray = function(r) {
    for (var e, o = r.length, n = o % 3, a = "", h = [], u = 0, d = o - n; u < d; u += 16383) h.push(c(r, u, u + 16383 > d ? d : u + 16383));
    1 === n ? (e = r[o - 1], a += t[e >> 2], a += t[e << 4 & 63], a += "==") : 2 === n && (e = (r[o - 2] << 8) + r[o - 1], 
    a += t[e >> 10], a += t[e >> 4 & 63], a += t[e << 2 & 63], a += "=");
    return h.push(a), h.join("");
}, exports.toByteArray = function(t) {
    var o, n, a, c, u, d = t.length;
    c = h(t), u = new r(3 * d / 4 - c), n = c > 0 ? d - 4 : d;
    var A = 0;
    for (o = 0; o < n; o += 4) a = e[t.charCodeAt(o)] << 18 | e[t.charCodeAt(o + 1)] << 12 | e[t.charCodeAt(o + 2)] << 6 | e[t.charCodeAt(o + 3)], 
    u[A++] = a >> 16 & 255, u[A++] = a >> 8 & 255, u[A++] = 255 & a;
    2 === c ? (a = e[t.charCodeAt(o)] << 2 | e[t.charCodeAt(o + 1)] >> 4, u[A++] = 255 & a) : 1 === c && (a = e[t.charCodeAt(o)] << 10 | e[t.charCodeAt(o + 1)] << 4 | e[t.charCodeAt(o + 2)] >> 2, 
    u[A++] = a >> 8 & 255, u[A++] = 255 & a);
    return u;
};

for (var r = "undefined" != typeof Uint8Array ? Uint8Array : Array, t = [], e = [], o = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", n = 0, a = o.length; n < a; ++n) t[n] = o[n], 
e[o.charCodeAt(n)] = n;

function h(r) {
    var t = r.length;
    if (t % 4 > 0) throw new Error("Invalid string. Length must be a multiple of 4");
    return "=" === r[t - 2] ? 2 : "=" === r[t - 1] ? 1 : 0;
}

function c(r, e, o) {
    for (var n, a, h = [], c = e; c < o; c += 3) n = (r[c] << 16) + (r[c + 1] << 8) + r[c + 2], 
    h.push(t[(a = n) >> 18 & 63] + t[a >> 12 & 63] + t[a >> 6 & 63] + t[63 & a]);
    return h.join("");
}

e["-".charCodeAt(0)] = 62, e["_".charCodeAt(0)] = 63;