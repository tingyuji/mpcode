Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var t = require("@babel/runtime/helpers/classCallCheck.js"), e = require("@babel/runtime/helpers/createClass.js"), r = require("472BE6D69C0A569C214D8ED11586C3E5.js"), n = require("FB6E67379C0A569C9D080F30E1E6C3E5.js"), i = /[^+\/0-9A-Za-z-_]/g;

function u(t) {
    if (t > 2147483647) throw new RangeError("Invalid typed array length");
    var e = new Uint8Array(t);
    return e.__proto__ = o.prototype, e;
}

var o = function() {
    function r(e, n, i) {
        if (t(this, r), "number" == typeof e) {
            if ("string" == typeof n) throw new Error("If encoding is specified then the first argument must be a string");
            return h(e);
        }
        return s(e, n, i);
    }
    return e(r, [ {
        key: "swap16",
        value: function() {
            var t = this.length;
            if (t % 2 != 0) throw new RangeError("Buffer size must be a multiple of 16-bits");
            for (var e = 0; e < t; e += 2) w(this, e, e + 1);
            return this;
        }
    }, {
        key: "swap32",
        value: function() {
            var t = this.length;
            if (t % 4 != 0) throw new RangeError("Buffer size must be a multiple of 32-bits");
            for (var e = 0; e < t; e += 4) w(this, e, e + 3), w(this, e + 1, e + 2);
            return this;
        }
    }, {
        key: "swap64",
        value: function() {
            var t = this.length;
            if (t % 8 != 0) throw new RangeError("Buffer size must be a multiple of 64-bits");
            for (var e = 0; e < t; e += 8) w(this, e, e + 7), w(this, e + 1, e + 6), w(this, e + 2, e + 5), 
            w(this, e + 3, e + 4);
            return this;
        }
    }, {
        key: "toString",
        value: function() {
            var t = this.length;
            return 0 === t ? "" : 0 === arguments.length ? U(this, 0, t) : p.apply(this, arguments);
        }
    }, {
        key: "equals",
        value: function(t) {
            if (!r.isBuffer(t)) throw new TypeError("Argument must be a Buffer");
            return this === t || 0 === r.compare(this, t);
        }
    }, {
        key: "inspect",
        value: function() {
            var t = "";
            return this.length > 0 && (t = this.toString("hex", 0, 50).match(/.{2}/g).join(" "), 
            this.length > 50 && (t += " ... ")), "<Buffer " + t + ">";
        }
    }, {
        key: "includes",
        value: function(t, e, r) {
            return -1 !== this.indexOf(t, e, r);
        }
    }, {
        key: "indexOf",
        value: function(t, e, r) {
            return d(this, t, e, r, !0);
        }
    }, {
        key: "lastIndexOf",
        value: function(t, e, r) {
            return d(this, t, e, r, !1);
        }
    }, {
        key: "write",
        value: function(t, e, r, n) {
            if (void 0 === e) n = "utf8", r = this.length, e = 0; else if (void 0 === r && "string" == typeof e) n = e, 
            r = this.length, e = 0; else {
                if (!isFinite(e)) throw new Error("Buffer.write(string, encoding, offset[, length]) is no longer supported");
                e >>>= 0, isFinite(r) ? (r >>>= 0, void 0 === n && (n = "utf8")) : (n = r, r = void 0);
            }
            var i = this.length - e;
            if ((void 0 === r || r > i) && (r = i), t.length > 0 && (r < 0 || e < 0) || e > this.length) throw new RangeError("Attempt to write outside buffer bounds");
            n || (n = "utf8");
            for (var u = !1; ;) switch (n) {
              case "hex":
                return E(this, t, e, r);

              case "utf8":
              case "utf-8":
                return m(this, t, e, r);

              case "ascii":
                return k(this, t, e, r);

              case "latin1":
              case "binary":
                return B(this, t, e, r);

              case "base64":
                return A(this, t, e, r);

              case "ucs2":
              case "ucs-2":
              case "utf16le":
              case "utf-16le":
                return I(this, t, e, r);

              default:
                if (u) throw new TypeError("Unknown encoding: " + n);
                n = ("" + n).toLowerCase(), u = !0;
            }
        }
    }, {
        key: "toJSON",
        value: function() {
            return {
                type: "Buffer",
                data: Array.prototype.slice.call(this._arr || this, 0)
            };
        }
    }, {
        key: "slice",
        value: function(t, e) {
            var n = this.length;
            (t = ~~t) < 0 ? (t += n) < 0 && (t = 0) : t > n && (t = n), (e = void 0 === e ? n : ~~e) < 0 ? (e += n) < 0 && (e = 0) : e > n && (e = n), 
            e < t && (e = t);
            var i = this.subarray(t, e);
            return i.__proto__ = r.prototype, i;
        }
    }, {
        key: "readUIntLE",
        value: function(t, e, r) {
            t >>>= 0, e >>>= 0, r || T(t, e, this.length);
            for (var n = this[t], i = 1, u = 0; ++u < e && (i *= 256); ) n += this[t + u] * i;
            return n;
        }
    }, {
        key: "readUIntBE",
        value: function(t, e, r) {
            t >>>= 0, e >>>= 0, r || T(t, e, this.length);
            for (var n = this[t + --e], i = 1; e > 0 && (i *= 256); ) n += this[t + --e] * i;
            return n;
        }
    }, {
        key: "readUInt8",
        value: function(t, e) {
            return t >>>= 0, e || T(t, 1, this.length), this[t];
        }
    }, {
        key: "readUInt16LE",
        value: function(t, e) {
            return t >>>= 0, e || T(t, 2, this.length), this[t] | this[t + 1] << 8;
        }
    }, {
        key: "readUInt16BE",
        value: function(t, e) {
            return t >>>= 0, e || T(t, 2, this.length), this[t] << 8 | this[t + 1];
        }
    }, {
        key: "readUInt32LE",
        value: function(t, e) {
            return t >>>= 0, e || T(t, 4, this.length), (this[t] | this[t + 1] << 8 | this[t + 2] << 16) + 16777216 * this[t + 3];
        }
    }, {
        key: "readUInt32BE",
        value: function(t, e) {
            return t >>>= 0, e || T(t, 4, this.length), 16777216 * this[t] + (this[t + 1] << 16 | this[t + 2] << 8 | this[t + 3]);
        }
    }, {
        key: "readIntLE",
        value: function(t, e, r) {
            t >>>= 0, e >>>= 0, r || T(t, e, this.length);
            for (var n = this[t], i = 1, u = 0; ++u < e && (i *= 256); ) n += this[t + u] * i;
            return n >= (i *= 128) && (n -= Math.pow(2, 8 * e)), n;
        }
    }, {
        key: "readIntBE",
        value: function(t, e, r) {
            t >>>= 0, e >>>= 0, r || T(t, e, this.length);
            for (var n = e, i = 1, u = this[t + --n]; n > 0 && (i *= 256); ) u += this[t + --n] * i;
            return u >= (i *= 128) && (u -= Math.pow(2, 8 * e)), u;
        }
    }, {
        key: "readInt8",
        value: function(t, e) {
            return t >>>= 0, e || T(t, 1, this.length), 128 & this[t] ? -1 * (255 - this[t] + 1) : this[t];
        }
    }, {
        key: "readInt16LE",
        value: function(t, e) {
            t >>>= 0, e || T(t, 2, this.length);
            var r = this[t] | this[t + 1] << 8;
            return 32768 & r ? 4294901760 | r : r;
        }
    }, {
        key: "readInt16BE",
        value: function(t, e) {
            t >>>= 0, e || T(t, 2, this.length);
            var r = this[t + 1] | this[t] << 8;
            return 32768 & r ? 4294901760 | r : r;
        }
    }, {
        key: "readInt32LE",
        value: function(t, e) {
            return t >>>= 0, e || T(t, 4, this.length), this[t] | this[t + 1] << 8 | this[t + 2] << 16 | this[t + 3] << 24;
        }
    }, {
        key: "readInt32BE",
        value: function(t, e) {
            return t >>>= 0, e || T(t, 4, this.length), this[t] << 24 | this[t + 1] << 16 | this[t + 2] << 8 | this[t + 3];
        }
    }, {
        key: "readFloatLE",
        value: function(t, e) {
            return t >>>= 0, e || T(t, 4, this.length), (0, n.read)(this, t, !0, 23, 4);
        }
    }, {
        key: "readFloatBE",
        value: function(t, e) {
            return t >>>= 0, e || T(t, 4, this.length), (0, n.read)(this, t, !1, 23, 4);
        }
    }, {
        key: "readDoubleLE",
        value: function(t, e) {
            return t >>>= 0, e || T(t, 8, this.length), (0, n.read)(this, t, !0, 52, 8);
        }
    }, {
        key: "readDoubleBE",
        value: function(t, e) {
            return t >>>= 0, e || T(t, 8, this.length), (0, n.read)(this, t, !1, 52, 8);
        }
    }, {
        key: "writeUIntLE",
        value: function(t, e, r, n) {
            t = +t, e >>>= 0, r >>>= 0, n || C(this, t, e, r, Math.pow(2, 8 * r) - 1, 0);
            var i = 1, u = 0;
            for (this[e] = 255 & t; ++u < r && (i *= 256); ) this[e + u] = t / i & 255;
            return e + r;
        }
    }, {
        key: "writeUIntBE",
        value: function(t, e, r, n) {
            t = +t, e >>>= 0, r >>>= 0, n || C(this, t, e, r, Math.pow(2, 8 * r) - 1, 0);
            var i = r - 1, u = 1;
            for (this[e + i] = 255 & t; --i >= 0 && (u *= 256); ) this[e + i] = t / u & 255;
            return e + r;
        }
    }, {
        key: "writeUInt8",
        value: function(t, e, r) {
            return t = +t, e >>>= 0, r || C(this, t, e, 1, 255, 0), this[e] = 255 & t, e + 1;
        }
    }, {
        key: "writeUInt16LE",
        value: function(t, e, r) {
            return t = +t, e >>>= 0, r || C(this, t, e, 2, 65535, 0), this[e] = 255 & t, this[e + 1] = t >>> 8, 
            e + 2;
        }
    }, {
        key: "writeUInt16BE",
        value: function(t, e, r) {
            return t = +t, e >>>= 0, r || C(this, t, e, 2, 65535, 0), this[e] = t >>> 8, this[e + 1] = 255 & t, 
            e + 2;
        }
    }, {
        key: "writeUInt32LE",
        value: function(t, e, r) {
            return t = +t, e >>>= 0, r || C(this, t, e, 4, 4294967295, 0), this[e + 3] = t >>> 24, 
            this[e + 2] = t >>> 16, this[e + 1] = t >>> 8, this[e] = 255 & t, e + 4;
        }
    }, {
        key: "writeUInt32BE",
        value: function(t, e, r) {
            return t = +t, e >>>= 0, r || C(this, t, e, 4, 4294967295, 0), this[e] = t >>> 24, 
            this[e + 1] = t >>> 16, this[e + 2] = t >>> 8, this[e + 3] = 255 & t, e + 4;
        }
    }, {
        key: "writeIntLE",
        value: function(t, e, r, n) {
            if (t = +t, e >>>= 0, !n) {
                var i = Math.pow(2, 8 * r - 1);
                C(this, t, e, r, i - 1, -i);
            }
            var u = 0, o = 1, s = 0;
            for (this[e] = 255 & t; ++u < r && (o *= 256); ) t < 0 && 0 === s && 0 !== this[e + u - 1] && (s = 1), 
            this[e + u] = (t / o >> 0) - s & 255;
            return e + r;
        }
    }, {
        key: "writeIntBE",
        value: function(t, e, r, n) {
            if (t = +t, e >>>= 0, !n) {
                var i = Math.pow(2, 8 * r - 1);
                C(this, t, e, r, i - 1, -i);
            }
            var u = r - 1, o = 1, s = 0;
            for (this[e + u] = 255 & t; --u >= 0 && (o *= 256); ) t < 0 && 0 === s && 0 !== this[e + u + 1] && (s = 1), 
            this[e + u] = (t / o >> 0) - s & 255;
            return e + r;
        }
    }, {
        key: "writeInt8",
        value: function(t, e, r) {
            return t = +t, e >>>= 0, r || C(this, t, e, 1, 127, -128), t < 0 && (t = 255 + t + 1), 
            this[e] = 255 & t, e + 1;
        }
    }, {
        key: "writeInt16LE",
        value: function(t, e, r) {
            return t = +t, e >>>= 0, r || C(this, t, e, 2, 32767, -32768), this[e] = 255 & t, 
            this[e + 1] = t >>> 8, e + 2;
        }
    }, {
        key: "writeInt16BE",
        value: function(t, e, r) {
            return t = +t, e >>>= 0, r || C(this, t, e, 2, 32767, -32768), this[e] = t >>> 8, 
            this[e + 1] = 255 & t, e + 2;
        }
    }, {
        key: "writeInt32LE",
        value: function(t, e, r) {
            return t = +t, e >>>= 0, r || C(this, t, e, 4, 2147483647, -2147483648), this[e] = 255 & t, 
            this[e + 1] = t >>> 8, this[e + 2] = t >>> 16, this[e + 3] = t >>> 24, e + 4;
        }
    }, {
        key: "writeInt32BE",
        value: function(t, e, r) {
            return t = +t, e >>>= 0, r || C(this, t, e, 4, 2147483647, -2147483648), t < 0 && (t = 4294967295 + t + 1), 
            this[e] = t >>> 24, this[e + 1] = t >>> 16, this[e + 2] = t >>> 8, this[e + 3] = 255 & t, 
            e + 4;
        }
    }, {
        key: "writeFloatLE",
        value: function(t, e, r) {
            return O(this, t, e, !0, r);
        }
    }, {
        key: "writeFloatBE",
        value: function(t, e, r) {
            return O(this, t, e, !1, r);
        }
    }, {
        key: "writeDoubleLE",
        value: function(t, e, r) {
            return P(this, t, e, !0, r);
        }
    }, {
        key: "writeDoubleBE",
        value: function(t, e, r) {
            return P(this, t, e, !1, r);
        }
    }, {
        key: "copy",
        value: function(t, e, r, n) {
            if (r || (r = 0), n || 0 === n || (n = this.length), e >= t.length && (e = t.length), 
            e || (e = 0), n > 0 && n < r && (n = r), n === r) return 0;
            if (0 === t.length || 0 === this.length) return 0;
            if (e < 0) throw new RangeError("targetStart out of bounds");
            if (r < 0 || r >= this.length) throw new RangeError("sourceStart out of bounds");
            if (n < 0) throw new RangeError("sourceEnd out of bounds");
            n > this.length && (n = this.length), t.length - e < n - r && (n = t.length - e + r);
            var i, u = n - r;
            if (this === t && r < e && e < n) for (i = u - 1; i >= 0; --i) t[i + e] = this[i + r]; else if (u < 1e3) for (i = 0; i < u; ++i) t[i + e] = this[i + r]; else Uint8Array.prototype.set.call(t, this.subarray(r, r + u), e);
            return u;
        }
    }, {
        key: "fill",
        value: function(t, e, n, i) {
            if ("string" == typeof t) {
                if ("string" == typeof e ? (i = e, e = 0, n = this.length) : "string" == typeof n && (i = n, 
                n = this.length), 1 === t.length) {
                    var u = t.charCodeAt(0);
                    u < 256 && (t = u);
                }
                if (void 0 !== i && "string" != typeof i) throw new TypeError("encoding must be a string");
                if ("string" == typeof i && !r.isEncoding(i)) throw new TypeError("Unknown encoding: " + i);
            } else "number" == typeof t && (t &= 255);
            if (e < 0 || this.length < e || this.length < n) throw new RangeError("Out of range index");
            if (n <= e) return this;
            var o;
            if (e >>>= 0, n = void 0 === n ? this.length : n >>> 0, t || (t = 0), "number" == typeof t) for (o = e; o < n; ++o) this[o] = t; else {
                var s = r.isBuffer(t) ? t : new r(t, i), f = s.length;
                for (o = 0; o < n - e; ++o) this[o + e] = s[o % f];
            }
            return this;
        }
    } ], [ {
        key: "from",
        value: function(t, e, r) {
            return s(t, e, r);
        }
    }, {
        key: "alloc",
        value: function(t, e, r) {
            return a(t, e, r);
        }
    }, {
        key: "allocUnsafe",
        value: function(t) {
            return h(t);
        }
    }, {
        key: "allocUnsafeSlow",
        value: function(t) {
            return h(t);
        }
    }, {
        key: "isBuffer",
        value: function(t) {
            return null != t && !0 === t._isBuffer;
        }
    }, {
        key: "compare",
        value: function(t, e) {
            if (!r.isBuffer(t) || !r.isBuffer(e)) throw new TypeError("Arguments must be Buffers");
            if (t === e) return 0;
            for (var n = t.length, i = e.length, u = 0, o = Math.min(n, i); u < o; ++u) if (t[u] !== e[u]) {
                n = t[u], i = e[u];
                break;
            }
            return n < i ? -1 : i < n ? 1 : 0;
        }
    }, {
        key: "isEncoding",
        value: function(t) {
            switch (String(t).toLowerCase()) {
              case "hex":
              case "utf8":
              case "utf-8":
              case "ascii":
              case "latin1":
              case "binary":
              case "base64":
              case "ucs2":
              case "ucs-2":
              case "utf16le":
              case "utf-16le":
                return !0;

              default:
                return !1;
            }
        }
    }, {
        key: "concat",
        value: function(t, e) {
            if (!Array.isArray(t)) throw new TypeError('"list" argument must be an Array of Buffers');
            if (0 === t.length) return r.alloc(0);
            var n;
            if (void 0 === e) for (e = 0, n = 0; n < t.length; ++n) e += t[n].length;
            var i = r.allocUnsafe(e), u = 0;
            for (n = 0; n < t.length; ++n) {
                var o = t[n];
                if (!r.isBuffer(o)) throw new TypeError('"list" argument must be an Array of Buffers');
                o.copy(i, u), u += o.length;
            }
            return i;
        }
    } ]), r;
}();

function s(t, e, r) {
    if ("number" == typeof t) throw new TypeError('"value" argument must not be a number');
    return D(t) ? function(t, e, r) {
        if (e < 0 || t.byteLength < e) throw new RangeError("'offset' is out of bounds");
        if (t.byteLength < e + (r || 0)) throw new RangeError("'length' is out of bounds");
        var n;
        return (n = void 0 === e && void 0 === r ? new Uint8Array(t) : void 0 === r ? new Uint8Array(t, e) : new Uint8Array(t, e, r)).__proto__ = o.prototype, 
        n;
    }(t, e, r) : "string" == typeof t ? l(t, e) : g(t);
}

function f(t) {
    if ("number" != typeof t) throw new TypeError('"size" argument must be a number');
    if (t < 0) throw new RangeError('"size" argument must not be negative');
}

function a(t, e, r) {
    return f(t), t <= 0 ? u(t) : void 0 !== e ? "string" == typeof r ? u(t).fill(e, r) : u(t).fill(e) : u(t);
}

function h(t) {
    return f(t), u(t < 0 ? 0 : 0 | y(t));
}

function l(t, e) {
    if ("string" == typeof e && "" !== e || (e = "utf8"), !o.isEncoding(e)) throw new TypeError('"encoding" must be a valid string encoding');
    var r = 0 | v(t, e), n = u(r), i = n.write(t, e);
    return i !== r && (n = n.slice(0, i)), n;
}

function c(t) {
    for (var e = t.length < 0 ? 0 : 0 | y(t.length), r = u(e), n = 0; n < e; n += 1) r[n] = 255 & t[n];
    return r;
}

function g(t) {
    if (o.isBuffer(t)) {
        var e = 0 | y(t.length), r = u(e);
        return 0 === r.length || t.copy(r, 0, 0, e), r;
    }
    if (t) {
        if (Y(t) || "length" in t) return "number" != typeof t.length || N(t.length) ? u(0) : c(t);
        if ("Buffer" === t.type && Array.isArray(t.data)) return c(t.data);
    }
    throw new TypeError("First argument must be a string, Buffer, ArrayBuffer, Array, or array-like object.");
}

function y(t) {
    if (t >= 2147483647) throw new RangeError("Attempt to allocate Buffer larger than maximum size: 0x" + 2147483647..toString(16) + " bytes");
    return 0 | t;
}

function v(t, e) {
    if (o.isBuffer(t)) return t.length;
    if (Y(t) || D(t)) return t.byteLength;
    "string" != typeof t && (t = "" + t);
    var r = t.length;
    if (0 === r) return 0;
    for (var n = !1; ;) switch (e) {
      case "ascii":
      case "latin1":
      case "binary":
        return r;

      case "utf8":
      case "utf-8":
      case void 0:
        return q(t).length;

      case "ucs2":
      case "ucs-2":
      case "utf16le":
      case "utf-16le":
        return 2 * r;

      case "hex":
        return r >>> 1;

      case "base64":
        return F(t).length;

      default:
        if (n) return q(t).length;
        e = ("" + e).toLowerCase(), n = !0;
    }
}

function p(t, e, r) {
    var n = !1;
    if ((void 0 === e || e < 0) && (e = 0), e > this.length) return "";
    if ((void 0 === r || r > this.length) && (r = this.length), r <= 0) return "";
    if ((r >>>= 0) <= (e >>>= 0)) return "";
    for (t || (t = "utf8"); ;) switch (t) {
      case "hex":
        return L(this, e, r);

      case "utf8":
      case "utf-8":
        return U(this, e, r);

      case "ascii":
        return x(this, e, r);

      case "latin1":
      case "binary":
        return S(this, e, r);

      case "base64":
        return _(this, e, r);

      case "ucs2":
      case "ucs-2":
      case "utf16le":
      case "utf-16le":
        return R(this, e, r);

      default:
        if (n) throw new TypeError("Unknown encoding: " + t);
        t = (t + "").toLowerCase(), n = !0;
    }
}

function w(t, e, r) {
    var n = t[e];
    t[e] = t[r], t[r] = n;
}

function d(t, e, r, n, i) {
    if (0 === t.length) return -1;
    if ("string" == typeof r ? (n = r, r = 0) : r > 2147483647 ? r = 2147483647 : r < -2147483648 && (r = -2147483648), 
    N(r = +r) && (r = i ? 0 : t.length - 1), r < 0 && (r = t.length + r), r >= t.length) {
        if (i) return -1;
        r = t.length - 1;
    } else if (r < 0) {
        if (!i) return -1;
        r = 0;
    }
    if ("string" == typeof e && (e = o.from(e, n)), o.isBuffer(e)) return 0 === e.length ? -1 : b(t, e, r, n, i);
    if ("number" == typeof e) return e &= 255, "function" == typeof Uint8Array.prototype.indexOf ? i ? Uint8Array.prototype.indexOf.call(t, e, r) : Uint8Array.prototype.lastIndexOf.call(t, e, r) : b(t, [ e ], r, n, i);
    throw new TypeError("val must be string, number or Buffer");
}

function b(t, e, r, n, i) {
    function u(t, e) {
        return 1 === s ? t[e] : t.readUInt16BE(e * s);
    }
    var o, s = 1, f = t.length, a = e.length;
    if (void 0 !== n && ("ucs2" === (n = String(n).toLowerCase()) || "ucs-2" === n || "utf16le" === n || "utf-16le" === n)) {
        if (t.length < 2 || e.length < 2) return -1;
        s = 2, f /= 2, a /= 2, r /= 2;
    }
    if (i) {
        var h = -1;
        for (o = r; o < f; o++) if (u(t, o) === u(e, -1 === h ? 0 : o - h)) {
            if (-1 === h && (h = o), o - h + 1 === a) return h * s;
        } else -1 !== h && (o -= o - h), h = -1;
    } else for (r + a > f && (r = f - a), o = r; o >= 0; o--) {
        for (var l = !0, c = 0; c < a; c++) if (u(t, o + c) !== u(e, c)) {
            l = !1;
            break;
        }
        if (l) return o;
    }
    return -1;
}

function E(t, e, r, n) {
    r = Number(r) || 0;
    var i = t.length - r;
    n ? (n = Number(n)) > i && (n = i) : n = i;
    var u = e.length;
    if (u % 2 != 0) throw new TypeError("Invalid hex string");
    n > u / 2 && (n = u / 2);
    for (var o = 0; o < n; ++o) {
        var s = parseInt(e.substr(2 * o, 2), 16);
        if (N(s)) return o;
        t[r + o] = s;
    }
    return o;
}

function m(t, e, r, n) {
    return j(q(e, t.length - r), t, r, n);
}

function k(t, e, r, n) {
    return j(function(t) {
        for (var e = [], r = 0; r < t.length; ++r) e.push(255 & t.charCodeAt(r));
        return e;
    }(e), t, r, n);
}

function B(t, e, r, n) {
    return k(t, e, r, n);
}

function A(t, e, r, n) {
    return j(F(e), t, r, n);
}

function I(t, e, r, n) {
    return j(function(t, e) {
        for (var r, n, i, u = [], o = 0; o < t.length && !((e -= 2) < 0); ++o) r = t.charCodeAt(o), 
        n = r >> 8, i = r % 256, u.push(i), u.push(n);
        return u;
    }(e, t.length - r), t, r, n);
}

function _(t, e, n) {
    return 0 === e && n === t.length ? (0, r.fromByteArray)(t) : (0, r.fromByteArray)(t.slice(e, n));
}

function U(t, e, r) {
    r = Math.min(t.length, r);
    for (var n = [], i = e; i < r; ) {
        var u, o, s, f, a = t[i], h = null, l = a > 239 ? 4 : a > 223 ? 3 : a > 191 ? 2 : 1;
        if (i + l <= r) switch (l) {
          case 1:
            a < 128 && (h = a);
            break;

          case 2:
            128 == (192 & (u = t[i + 1])) && (f = (31 & a) << 6 | 63 & u) > 127 && (h = f);
            break;

          case 3:
            u = t[i + 1], o = t[i + 2], 128 == (192 & u) && 128 == (192 & o) && (f = (15 & a) << 12 | (63 & u) << 6 | 63 & o) > 2047 && (f < 55296 || f > 57343) && (h = f);
            break;

          case 4:
            u = t[i + 1], o = t[i + 2], s = t[i + 3], 128 == (192 & u) && 128 == (192 & o) && 128 == (192 & s) && (f = (15 & a) << 18 | (63 & u) << 12 | (63 & o) << 6 | 63 & s) > 65535 && f < 1114112 && (h = f);
        }
        null === h ? (h = 65533, l = 1) : h > 65535 && (h -= 65536, n.push(h >>> 10 & 1023 | 55296), 
        h = 56320 | 1023 & h), n.push(h), i += l;
    }
    return function(t) {
        var e = t.length;
        if (e <= 4096) return String.fromCharCode.apply(String, t);
        for (var r = "", n = 0; n < e; ) r += String.fromCharCode.apply(String, t.slice(n, n += 4096));
        return r;
    }(n);
}

function x(t, e, r) {
    var n = "";
    r = Math.min(t.length, r);
    for (var i = e; i < r; ++i) n += String.fromCharCode(127 & t[i]);
    return n;
}

function S(t, e, r) {
    var n = "";
    r = Math.min(t.length, r);
    for (var i = e; i < r; ++i) n += String.fromCharCode(t[i]);
    return n;
}

function L(t, e, r) {
    var n = t.length;
    (!e || e < 0) && (e = 0), (!r || r < 0 || r > n) && (r = n);
    for (var i = "", u = e; u < r; ++u) i += z(t[u]);
    return i;
}

function R(t, e, r) {
    for (var n = t.slice(e, r), i = "", u = 0; u < n.length; u += 2) i += String.fromCharCode(n[u] + 256 * n[u + 1]);
    return i;
}

function T(t, e, r) {
    if (t % 1 != 0 || t < 0) throw new RangeError("offset is not uint");
    if (t + e > r) throw new RangeError("Trying to access beyond buffer length");
}

function C(t, e, r, n, i, u) {
    if (!o.isBuffer(t)) throw new TypeError('"buffer" argument must be a Buffer instance');
    if (e > i || e < u) throw new RangeError('"value" argument is out of bounds');
    if (r + n > t.length) throw new RangeError("Index out of range");
}

function M(t, e, r, n, i, u) {
    if (r + n > t.length) throw new RangeError("Index out of range");
    if (r < 0) throw new RangeError("Index out of range");
}

function O(t, e, r, i, u) {
    return e = +e, r >>>= 0, u || M(t, 0, r, 4), (0, n.write)(t, e, r, i, 23, 4), r + 4;
}

function P(t, e, r, i, u) {
    return e = +e, r >>>= 0, u || M(t, 0, r, 8), (0, n.write)(t, e, r, i, 52, 8), r + 8;
}

function z(t) {
    return t < 16 ? "0" + t.toString(16) : t.toString(16);
}

function q(t, e) {
    e = e || 1 / 0;
    for (var r, n = t.length, i = null, u = [], o = 0; o < n; ++o) {
        if ((r = t.charCodeAt(o)) > 55295 && r < 57344) {
            if (!i) {
                if (r > 56319) {
                    (e -= 3) > -1 && u.push(239, 191, 189);
                    continue;
                }
                if (o + 1 === n) {
                    (e -= 3) > -1 && u.push(239, 191, 189);
                    continue;
                }
                i = r;
                continue;
            }
            if (r < 56320) {
                (e -= 3) > -1 && u.push(239, 191, 189), i = r;
                continue;
            }
            r = 65536 + (i - 55296 << 10 | r - 56320);
        } else i && (e -= 3) > -1 && u.push(239, 191, 189);
        if (i = null, r < 128) {
            if ((e -= 1) < 0) break;
            u.push(r);
        } else if (r < 2048) {
            if ((e -= 2) < 0) break;
            u.push(r >> 6 | 192, 63 & r | 128);
        } else if (r < 65536) {
            if ((e -= 3) < 0) break;
            u.push(r >> 12 | 224, r >> 6 & 63 | 128, 63 & r | 128);
        } else {
            if (!(r < 1114112)) throw new Error("Invalid code point");
            if ((e -= 4) < 0) break;
            u.push(r >> 18 | 240, r >> 12 & 63 | 128, r >> 6 & 63 | 128, 63 & r | 128);
        }
    }
    return u;
}

function F(t) {
    return (0, r.toByteArray)(function(t) {
        if ((t = t.trim().replace(i, "")).length < 2) return "";
        for (;t.length % 4 != 0; ) t += "=";
        return t;
    }(t));
}

function j(t, e, r, n) {
    for (var i = 0; i < n && !(i + r >= e.length || i >= t.length); ++i) e[i + r] = t[i];
    return i;
}

function D(t) {
    return t instanceof ArrayBuffer || null != t && null != t.constructor && "ArrayBuffer" === t.constructor.name && "number" == typeof t.byteLength;
}

function Y(t) {
    return "function" == typeof ArrayBuffer.isView && ArrayBuffer.isView(t);
}

function N(t) {
    return t != t;
}

exports.SlowBuffer = function(t) {
    return +t != t && (t = 0), o.alloc(+t);
}, exports.INSPECT_MAX_BYTES = 50, exports.kMaxLength = 2147483647, o.TYPED_ARRAY_SUPPORT = function() {
    try {
        var t = new Uint8Array(1);
        return t.__proto__ = {
            __proto__: Uint8Array.prototype,
            foo: function() {
                return 42;
            }
        }, 42 === t.foo();
    } catch (t) {
        return !1;
    }
}(), o.TYPED_ARRAY_SUPPORT || "undefined" == typeof console || "function" != typeof console.error || console.error("This browser lacks typed array (Uint8Array) support which is required by `buffer` v5.x. Use `buffer` v4.x if you require old browser support."), 
"undefined" != typeof Symbol && Symbol.species && o[Symbol.species] === o && Object.defineProperty(o, Symbol.species, {
    value: null,
    configurable: !0,
    enumerable: !1,
    writable: !1
}), o.poolSize = 8192, o.prototype.__proto__ = Uint8Array.prototype, o.__proto__ = Uint8Array, 
o.byteLength = v, o.prototype._isBuffer = !0, o.prototype.compare = function(t, e, r, n, i) {
    if (!o.isBuffer(t)) throw new TypeError("Argument must be a Buffer");
    if (void 0 === e && (e = 0), void 0 === r && (r = t ? t.length : 0), void 0 === n && (n = 0), 
    void 0 === i && (i = this.length), e < 0 || r > t.length || n < 0 || i > this.length) throw new RangeError("out of range index");
    if (n >= i && e >= r) return 0;
    if (n >= i) return -1;
    if (e >= r) return 1;
    if (this === t) return 0;
    for (var u = (i >>>= 0) - (n >>>= 0), s = (r >>>= 0) - (e >>>= 0), f = Math.min(u, s), a = this.slice(n, i), h = t.slice(e, r), l = 0; l < f; ++l) if (a[l] !== h[l]) {
        u = a[l], s = h[l];
        break;
    }
    return u < s ? -1 : s < u ? 1 : 0;
};

var V = o;

exports.default = V;