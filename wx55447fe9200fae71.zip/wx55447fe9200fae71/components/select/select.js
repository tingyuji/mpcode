var t = require("../../@babel/runtime/helpers/objectSpread2");

Component({
    options: {
        addGlobalClass: !0,
        multipleSlots: !0
    },
    properties: {
        options: {
            type: Array,
            value: []
        },
        selected: {
            type: Object,
            value: {}
        },
        key: {
            type: String,
            value: "id"
        },
        text: {
            type: String,
            value: "name"
        }
    },
    data: {
        isShow: !1,
        current: {}
    },
    methods: {
        optionTap: function(e) {
            var s = e.target.dataset;
            this.setData({
                current: s,
                isShow: !1
            }), this.triggerEvent("change", t({}, s));
        },
        openClose: function() {
            this.setData({
                isShow: !this.data.isShow
            });
        },
        close: function() {
            this.setData({
                isShow: !1
            });
        }
    },
    lifetimes: {
        detached: function() {
            this.close();
        }
    },
    pageLifetimes: {
        show: function() {
            this.setData({
                current: this.data.options.length > 0 ? Object.assign(Object.assign({}, this.data.options[0]), this.data.selected) : {},
                key: this.data.key,
                text: this.data.text
            });
        },
        hide: function() {
            this.close();
        },
        resize: function() {
            this.close();
        }
    }
});