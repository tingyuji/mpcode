Component({
    options: {
        addGlobalClass: !0,
        multipleSlots: !0
    },
    properties: {
        width: {
            type: String,
            value: "16px"
        },
        percent: {
            type: Number,
            value: 0
        },
        deg: {
            type: Number,
            value: 0
        }
    },
    data: {},
    methods: {}
});