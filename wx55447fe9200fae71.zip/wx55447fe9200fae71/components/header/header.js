var t = getApp();

Component({
    options: {
        addGlobalClass: !0,
        multipleSlots: !0
    },
    properties: {
        bgColor: {
            type: String,
            value: ""
        },
        isCustom: {
            type: Boolean,
            value: !1
        },
        isBack: {
            type: Boolean,
            value: !1
        },
        HomePath: {
            type: String,
            value: ""
        }
    },
    data: {
        StatusBar: t.globalData.StatusBar,
        CustomBar: t.globalData.CustomBar,
        Custom: t.globalData.Custom
    },
    methods: {
        BackPage: function() {
            getCurrentPages().length > 1 && wx.navigateBack({
                delta: 1,
                fail: function(t) {
                    console.error(t);
                }
            });
        },
        toHome: function() {
            var t = getCurrentPages()[0].route;
            wx.reLaunch({
                url: this.data.HomePath || "/".concat(t),
                fail: function(t) {
                    console.error(t);
                }
            });
        }
    }
});