Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("@babel/runtime/helpers/createForOfIteratorHelper.js");

require("@babel/runtime/helpers/Objectentries.js");

var t = require("@babel/runtime/helpers/slicedToArray.js"), r = require("@babel/runtime/helpers/objectSpread2.js"), n = require("@babel/runtime/helpers/regeneratorRuntime.js"), a = require("@babel/runtime/helpers/asyncToGenerator.js"), s = require("@babel/runtime/helpers/classCallCheck.js"), i = require("@babel/runtime/helpers/createClass.js"), u = require("@babel/runtime/helpers/possibleConstructorReturn.js"), o = require("@babel/runtime/helpers/assertThisInitialized.js"), c = require("@babel/runtime/helpers/inherits.js"), h = require("@babel/runtime/helpers/createSuper.js"), p = require("280E75359C0A569C4E681D328EE6C3E5.js"), d = require("624A41A09C0A569C042C29A751B6C3E5.js"), f = y(require("432179279C0A569C254711201AC6C3E5.js")), g = require("9BF6B1F09C0A569CFD90D9F71EB6C3E5.js"), l = y(require("582381E59C0A569C3E45E9E228F6C3E5.js"));

function y(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

var _ = "https://s.luoyy.com/api/v3/", v = function(f) {
    c(j, f);
    var y, v, w, S, x, k, b, m, T, I, P, E, C, A, N, O, U, D, M, q = h(j);
    function j(e) {
        var t;
        return s(this, j), (t = q.call(this)).language = l.default[e || "zh_CN"], t.loginStatus = !1, 
        t.autoSyn = !1, t.OpenindependentPass = !1, t.independentPass = "", t.synTime = "", 
        t.code = "", t.unionid = "", t.token = "", t.session_key = "", t.localUpdateTime = 0, 
        t.originUpdateTime = 0, t.AccountInfo = wx.getAccountInfoSync(), t.initData(), u(t, o(t));
    }
    return i(j, [ {
        key: "setLanguage",
        value: function(e) {
            return this.language = l.default[e], this;
        }
    }, {
        key: "userKey",
        value: (M = a(n().mark(function e() {
            var t = this;
            return n().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.next = 2, new Promise(function(e, r) {
                        wx.getUserCryptoManager().getLatestUserKey({
                            success: e,
                            fail: function() {
                                r(new Error(t.language["s-e"]));
                            }
                        });
                    });

                  case 2:
                    return e.abrupt("return", e.sent);

                  case 3:
                  case "end":
                    return e.stop();
                }
            }, e);
        })), function() {
            return M.apply(this, arguments);
        })
    }, {
        key: "login",
        value: (D = a(n().mark(function e() {
            var t, r, a = this;
            return n().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.next = 2, new Promise(function(e, t) {
                        wx.login({
                            success: function(r) {
                                "code" in r && r.code.length > 0 ? e(r.code) : t(new Error(a.language.de));
                            },
                            fail: function() {
                                t(new Error(a.language["info-error"]));
                            }
                        });
                    });

                  case 2:
                    return t = e.sent, e.next = 5, this.requestAsync({
                        url: _ + "login",
                        header: {
                            "content-type": "application/json"
                        },
                        method: "POST",
                        data: {
                            appId: this.AccountInfo.miniProgram.appId,
                            code: t
                        }
                    });

                  case 5:
                    return r = e.sent, e.next = 8, this._handleLoginResponse(r);

                  case 8:
                    return e.abrupt("return", e.sent);

                  case 9:
                  case "end":
                    return e.stop();
                }
            }, e, this);
        })), function() {
            return D.apply(this, arguments);
        })
    }, {
        key: "_handleLoginResponse",
        value: (U = a(n().mark(function e(t) {
            var r, a, s, i, u, o, c;
            return n().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (t.statusCode >> 0 == 200) {
                        e.next = 2;
                        break;
                    }
                    throw new Error(this.language["api-e"]);

                  case 2:
                    if (t.data.code >> 0 == 200) {
                        e.next = 4;
                        break;
                    }
                    throw new g.ServerError(t.data.msg);

                  case 4:
                    return e.next = 6, this.userKey();

                  case 6:
                    if (r = e.sent, a = r.encryptKey, s = r.iv, r.version >> 0 == t.data.data.version >> 0) {
                        e.next = 12;
                        break;
                    }
                    throw new Error(this.language["s-e"]);

                  case 12:
                    if (!1 !== (i = (0, p.decrypt)(t.data.data.encrypt_data, a, (0, d.HmacMD5)(d.enc.Base64.parse(a), d.enc.Hex.parse(s)).toString(d.enc.Base64)))) {
                        e.next = 15;
                        break;
                    }
                    throw new Error(this.language["p-e"]);

                  case 15:
                    return u = i.openid, o = i.unionid, wx.setStorageSync("API_UNIONID", o), this.unionid = o, 
                    this.openid = u, c = this._extractToken(t.data.data, t.header), this.storeToken(c), 
                    this.loginStatus = !0, e.abrupt("return", !0);

                  case 23:
                  case "end":
                    return e.stop();
                }
            }, e, this);
        })), function(e) {
            return U.apply(this, arguments);
        })
    }, {
        key: "_extractToken",
        value: function(e, t) {
            var r = e.token || "", n = t.Authorization || "";
            return n ? n.substr(7) : r;
        }
    }, {
        key: "storeToken",
        value: function(e) {
            return wx.setStorageSync("API_TOKEN", e), this.token = e, !0;
        }
    }, {
        key: "checkUser",
        value: (O = a(n().mark(function e() {
            return n().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (!this.initData() || !this.loginStatus) {
                        e.next = 4;
                        break;
                    }
                    return e.next = 3, this.auth();

                  case 3:
                    return e.abrupt("return", e.sent);

                  case 4:
                    return e.abrupt("return", !1);

                  case 5:
                  case "end":
                    return e.stop();
                }
            }, e, this);
        })), function() {
            return O.apply(this, arguments);
        })
    }, {
        key: "setloginStatus",
        value: function(e) {
            return this.loginStatus = e, !0;
        }
    }, {
        key: "setautoSyn",
        value: function(e) {
            try {
                wx.setStorageSync("API_AUTOSYN", !!e), this.autoSyn = !!e;
            } catch (e) {
                return !1;
            }
            return !0;
        }
    }, {
        key: "logout",
        value: function(e) {
            var t = !!e;
            try {
                this.setloginStatus(!1), this.storeToken(""), this.setautoSyn(!1), this.unionid = "", 
                this.independentPass = "", this.localUpdateTime = 0, this.originUpdateTime = 0, 
                this.synTime = this.language["n-sync"], wx.removeStorageSync("API_UNIONID"), wx.removeStorageSync("API_INDEPENDENTPASS"), 
                wx.removeStorageSync("API_LOCALUPDATETIME"), wx.removeStorageSync("API_ORIGINUPDATETIME"), 
                wx.removeStorageSync("API_SYNTIME"), t && (wx.removeStorageSync("TOKENS"), wx.removeStorageSync("TOKEN_NUM"));
            } catch (e) {
                return !1;
            }
            return !0;
        }
    }, {
        key: "initData",
        value: function() {
            try {
                this.unionid = wx.getStorageSync("API_UNIONID") || "", this.token = wx.getStorageSync("API_TOKEN") || "", 
                this.independentPass = wx.getStorageSync("API_INDEPENDENTPASS") || "", this.localUpdateTime = wx.getStorageSync("API_LOCALUPDATETIME") || 0, 
                this.originUpdateTime = wx.getStorageSync("API_ORIGINUPDATETIME") || 0, this.synTime = wx.getStorageSync("API_SYNTIME") || this.language["n-sync"], 
                this.autoSyn = !!wx.getStorageSync("API_AUTOSYN");
            } catch (e) {
                return !1;
            }
            return this.loginStatus = this.unionid.length > 0 && this.token.length > 0, this.OpenindependentPass = this.independentPass.length > 0, 
            this.independentPass = this.OpenindependentPass ? this.independentPass : this.unionid, 
            !0;
        }
    }, {
        key: "auth",
        value: (N = a(n().mark(function e() {
            var t;
            return n().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.next = 2, this.api({
                        url: "get_user_info",
                        method: "POST"
                    });

                  case 2:
                    if ((t = e.sent).statusCode >> 0 == 200) {
                        e.next = 5;
                        break;
                    }
                    throw new Error(this.language["api-e"]);

                  case 5:
                    e.t0 = t.data.code >> 0, e.next = 200 === e.t0 ? 8 : 401 === e.t0 ? 9 : 11;
                    break;

                  case 8:
                    return e.abrupt("return", !0);

                  case 9:
                    return this.logout(), e.abrupt("break", 11);

                  case 11:
                    throw new g.ServerError(t.data.msg);

                  case 12:
                  case "end":
                    return e.stop();
                }
            }, e, this);
        })), function() {
            return N.apply(this, arguments);
        })
    }, {
        key: "api",
        value: (A = a(n().mark(function e(t) {
            var a, s;
            return n().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (this.initData() && this.loginStatus) {
                        e.next = 2;
                        break;
                    }
                    throw new Error(this.language["info-error"]);

                  case 2:
                    return (a = r({
                        url: "",
                        data: {},
                        header: {},
                        method: "GET",
                        dataType: "json",
                        responseType: "text"
                    }, t)).url = _ + a.url, a.header.Authorization = "Bearer " + this.token, a.header["Content-Type"] = "application/json", 
                    a.data.t = (30 + (Date.now() / 1e3 >> 0)).toString(), a.data.sign = (0, p.gen_sign)(a.data, (0, 
                    p.uid)(this.unionid)), e.next = 10, this.requestAsync(a);

                  case 10:
                    return "Authorization" in (s = e.sent).header && s.header.Authorization.length > 0 && this.storeToken(s.header.Authorization.substr(7)), 
                    e.abrupt("return", s);

                  case 13:
                  case "end":
                    return e.stop();
                }
            }, e, this);
        })), function(e) {
            return A.apply(this, arguments);
        })
    }, {
        key: "requestAsync",
        value: (C = a(n().mark(function e(t) {
            var r = this;
            return n().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.next = 2, new Promise(function(e, n) {
                        t.timeout = t.timeout || 6e4, t.success = e, t.fail = function() {
                            n(new Error(r.language["api-e"]));
                        }, wx.request(t);
                    });

                  case 2:
                    return e.abrupt("return", e.sent);

                  case 3:
                  case "end":
                    return e.stop();
                }
            }, e);
        })), function(e) {
            return C.apply(this, arguments);
        })
    }, {
        key: "filter_merge_data",
        value: function(e, n) {
            var a = this.localUpdateTime < this.originUpdateTime ? [ n, e ] : [ e, n ], s = t(a, 2), i = s[0], u = s[1], o = r(r({}, i), u);
            for (var c in o) "force_delete" in o[c] && !0 === o[c].force_delete && delete o[c];
            return o;
        }
    }, {
        key: "set_independent_pass",
        value: (E = a(n().mark(function e(t) {
            var r;
            return n().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.next = 2, this.get_secure_data();

                  case 2:
                    if (r = e.sent, this.Config_reset(this.filter_merge_data(r, this.Config_get()))) {
                        e.next = 5;
                        break;
                    }
                    throw new Error(this.language.de);

                  case 5:
                    return e.next = 7, this.put_secure_data(t);

                  case 7:
                    return wx.setStorageSync("API_INDEPENDENTPASS", t), this.independentPass = t, this.OpenindependentPass = !0, 
                    e.abrupt("return", !0);

                  case 11:
                  case "end":
                    return e.stop();
                }
            }, e, this);
        })), function(e) {
            return E.apply(this, arguments);
        })
    }, {
        key: "syn_data",
        value: (P = a(n().mark(function e() {
            var t;
            return n().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.next = 2, this.get_secure_data();

                  case 2:
                    if (t = e.sent, this.Config_reset(this.filter_merge_data(t, this.Config_get()))) {
                        e.next = 5;
                        break;
                    }
                    throw new Error(this.language.de);

                  case 5:
                    return e.next = 7, this.put_secure_data();

                  case 7:
                    return e.abrupt("return", e.sent);

                  case 8:
                  case "end":
                    return e.stop();
                }
            }, e, this);
        })), function() {
            return P.apply(this, arguments);
        })
    }, {
        key: "auto_sync",
        value: (I = a(n().mark(function e() {
            var t;
            return n().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (!(this.initData() && this.loginStatus && this.autoSyn)) {
                        e.next = 17;
                        break;
                    }
                    return this.emit("sync:before"), e.prev = 2, e.next = 5, this.syn_data();

                  case 5:
                    return t = e.sent, this.emit("sync", t), e.abrupt("return", t);

                  case 10:
                    throw e.prev = 10, e.t0 = e.catch(2), this.emit("sync:error", e.t0), e.t0;

                  case 14:
                    return e.prev = 14, this.emit("sync:after"), e.finish(14);

                  case 17:
                    return e.abrupt("return", !0);

                  case 18:
                  case "end":
                    return e.stop();
                }
            }, e, this, [ [ 2, 10, 14, 17 ] ]);
        })), function() {
            return I.apply(this, arguments);
        })
    }, {
        key: "get_secure_data",
        value: (T = a(n().mark(function e(t) {
            var r, a, s;
            return n().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.next = 2, this.api({
                        url: "get_secure_data",
                        method: "POST"
                    });

                  case 2:
                    if ((r = e.sent).statusCode >> 0 == 200) {
                        e.next = 5;
                        break;
                    }
                    throw new Error(this.language["api-e"]);

                  case 5:
                    e.t0 = r.data.code >> 0, e.next = 200 === e.t0 ? 8 : 401 === e.t0 ? 19 : 21;
                    break;

                  case 8:
                    if ((0, p.isset)(r.data.data)) {
                        e.next = 10;
                        break;
                    }
                    return e.abrupt("return", {});

                  case 10:
                    if (!1 !== (a = (0, p.safe_decrypt)(r.data.data.encrypt_data, (0, d.HmacMD5)(this.unionid, t || this.independentPass)))) {
                        e.next = 13;
                        break;
                    }
                    throw new Error(this.language.de);

                  case 13:
                    return s = new Date(r.data.data.updated_at).getTime(), wx.setStorageSync("API_ORIGINUPDATETIME", s), 
                    wx.setStorageSync("API_SYNTIME", r.data.data.updated_at), this.originUpdateTime = s, 
                    this.synTime = r.data.data.updated_at, e.abrupt("return", JSON.parse(a));

                  case 19:
                    return this.logout(), e.abrupt("break", 21);

                  case 21:
                    throw new g.ServerError(r.data.msg);

                  case 22:
                  case "end":
                    return e.stop();
                }
            }, e, this);
        })), function(e) {
            return T.apply(this, arguments);
        })
    }, {
        key: "put_secure_data",
        value: (m = a(n().mark(function e(t) {
            var r, a;
            return n().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.next = 2, this.api({
                        url: "put_secure_data",
                        method: "POST",
                        data: {
                            encrypt_data: (0, p.safe_encrypt)(JSON.stringify(this.Config_get()), (0, d.HmacMD5)(this.unionid, t || this.independentPass)),
                            is_independentpass: this.OpenindependentPass
                        }
                    });

                  case 2:
                    if ((r = e.sent).statusCode >> 0 == 200) {
                        e.next = 5;
                        break;
                    }
                    throw new Error(this.language["api-e"]);

                  case 5:
                    e.t0 = r.data.code >> 0, e.next = 200 === e.t0 ? 8 : 401 === e.t0 ? 14 : 16;
                    break;

                  case 8:
                    return a = new Date(r.data.data.updated_at).getTime(), wx.setStorageSync("API_ORIGINUPDATETIME", a), 
                    wx.setStorageSync("API_SYNTIME", r.data.data.updated_at), this.originUpdateTime = a, 
                    this.synTime = r.data.data.updated_at, e.abrupt("return", !0);

                  case 14:
                    return this.logout(), e.abrupt("break", 16);

                  case 16:
                    throw new g.ServerError(r.data.msg);

                  case 17:
                  case "end":
                    return e.stop();
                }
            }, e, this);
        })), function(e) {
            return m.apply(this, arguments);
        })
    }, {
        key: "Config_UUIDv4",
        value: function(e) {
            return e ? (e ^ 16 * Math.random() >> e / 4).toString(16) : ([ 1e7 ] + -1e3 + -4e3 + -8e3 + -1e11).replace(/[018]/g, this.Config_UUIDv4);
        }
    }, {
        key: "Config_isset",
        value: function(e) {
            return null != e;
        }
    }, {
        key: "Config_get",
        value: function() {
            try {
                var e = wx.getStorageSync("TOKENS") || void 0;
                if (this.Config_isset(e)) return e;
            } catch (e) {}
            return {};
        }
    }, {
        key: "Config_getNum",
        value: function() {
            try {
                var e = wx.getStorageSync("TOKEN_NUM") || void 0;
                if (this.Config_isset(e)) return e;
                e = 0;
                var t = this.Config_get();
                for (var r in t) "force_delete" in t[r] && !1 !== t[r].force_delete || e++;
                return wx.setStorageSync("TOKEN_NUM", e), e;
            } catch (e) {}
            return 0;
        }
    }, {
        key: "Config_reset",
        value: function(e) {
            try {
                var r = Object.fromEntries(Object.entries(e).sort(function(e, r) {
                    var n = t(e, 2)[1], a = t(r, 2)[1];
                    return n.sort || 1 / 0 - a.sort || 1 / 0;
                })), n = 1, a = 0;
                for (var s in r) r[s].sort = n++, "force_delete" in r[s] && !1 !== r[s].force_delete || a++;
                return wx.setStorageSync("API_LOCALUPDATETIME", Date.now()), wx.setStorageSync("TOKENS", r), 
                wx.setStorageSync("TOKEN_NUM", a), !0;
            } catch (e) {}
            return !1;
        }
    }, {
        key: "Config_inserts",
        value: (b = a(n().mark(function t(r) {
            var a, s, i, u;
            return n().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    a = this.Config_get(), s = e(r);
                    try {
                        for (s.s(); !(i = s.n()).done; ) u = i.value, a[this.Config_UUIDv4()] = u;
                    } catch (e) {
                        s.e(e);
                    } finally {
                        s.f();
                    }
                    return t.next = 5, this.Config_Save(a);

                  case 5:
                    return t.abrupt("return", t.sent);

                  case 6:
                  case "end":
                    return t.stop();
                }
            }, t, this);
        })), function(e) {
            return b.apply(this, arguments);
        })
    }, {
        key: "Config_insert",
        value: (k = a(n().mark(function e(t) {
            var r;
            return n().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return (r = this.Config_get())[this.Config_UUIDv4()] = t, e.next = 4, this.Config_Save(r);

                  case 4:
                    return e.abrupt("return", e.sent);

                  case 5:
                  case "end":
                    return e.stop();
                }
            }, e, this);
        })), function(e) {
            return k.apply(this, arguments);
        })
    }, {
        key: "Config_del",
        value: (x = a(n().mark(function e(t) {
            var r;
            return n().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (this.Config_isset(t)) {
                        e.next = 2;
                        break;
                    }
                    return e.abrupt("return", !1);

                  case 2:
                    return (r = this.Config_get())[t].is_delete = !0, e.next = 6, this.Config_Save(r);

                  case 6:
                    return e.abrupt("return", e.sent);

                  case 7:
                  case "end":
                    return e.stop();
                }
            }, e, this);
        })), function(e) {
            return x.apply(this, arguments);
        })
    }, {
        key: "Config_force_del",
        value: (S = a(n().mark(function e(t) {
            var r;
            return n().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (this.Config_isset(t)) {
                        e.next = 2;
                        break;
                    }
                    return e.abrupt("return", !1);

                  case 2:
                    return (r = this.Config_get())[t].force_delete = !0, e.next = 6, this.Config_Save(r);

                  case 6:
                    return e.abrupt("return", e.sent);

                  case 7:
                  case "end":
                    return e.stop();
                }
            }, e, this);
        })), function(e) {
            return S.apply(this, arguments);
        })
    }, {
        key: "Config_restore",
        value: (w = a(n().mark(function e(t) {
            var r;
            return n().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (this.Config_isset(t)) {
                        e.next = 2;
                        break;
                    }
                    return e.abrupt("return", !1);

                  case 2:
                    return (r = this.Config_get())[t].is_delete = !1, e.next = 6, this.Config_Save(r);

                  case 6:
                    return e.abrupt("return", e.sent);

                  case 7:
                  case "end":
                    return e.stop();
                }
            }, e, this);
        })), function(e) {
            return w.apply(this, arguments);
        })
    }, {
        key: "Config_valupdate",
        value: (v = a(n().mark(function e(t, r, a) {
            var s;
            return n().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (this.Config_isset(t)) {
                        e.next = 2;
                        break;
                    }
                    return e.abrupt("return", !1);

                  case 2:
                    return (s = this.Config_get())[t][r] = a, e.next = 6, this.Config_Save(s);

                  case 6:
                    return e.abrupt("return", e.sent);

                  case 7:
                  case "end":
                    return e.stop();
                }
            }, e, this);
        })), function(e, t, r) {
            return v.apply(this, arguments);
        })
    }, {
        key: "Config_Save",
        value: (y = a(n().mark(function e(t) {
            return n().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (!this.Config_reset(t)) {
                        e.next = 4;
                        break;
                    }
                    return e.next = 3, this.auto_sync();

                  case 3:
                    return e.abrupt("return", e.sent);

                  case 4:
                    return e.abrupt("return", !1);

                  case 5:
                  case "end":
                    return e.stop();
                }
            }, e, this);
        })), function(e) {
            return y.apply(this, arguments);
        })
    } ]), j;
}(f.default);

exports.default = v;