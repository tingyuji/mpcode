var e, t = (e = require("49E8A5879C0A569C2F8ECD80E3A6C3E5.js")) && e.__esModule ? e : {
    default: e
}, a = require("280E75359C0A569C4E681D328EE6C3E5.js");

App({
    Cloud: new t.default(),
    globalData: {
        language: "zh_CN",
        LaunchOptions: {}
    },
    onLaunch: function(e) {
        this.globalData.LaunchOptions = e, this._init();
    },
    onError: function(e) {
        console.error(e);
    },
    onPageNotFound: function() {
        wx.redirectTo({
            url: "/pages/index/index",
            fail: function(e) {
                console.error(e);
            }
        });
    },
    _init: function() {
        var e = this, t = wx.getSystemInfoSync();
        this._initLanguage(t), this._initBar(t), !0 === this._checkVersion(t) && (this._screenSecurity(t), 
        wx.onNetworkStatusChange(function(t) {
            e.Cloud.emit("net:status", t);
        }));
    },
    _initLanguage: function(e) {
        switch (e.language) {
          case "zh_TW":
            this.globalData.language = "zh_HK";
            break;

          case "en":
          case "zh_CN":
          case "zh_HK":
            this.globalData.language = e.language;
            break;

          default:
            this.globalData.language = "en";
        }
        this.Cloud.setLanguage(this.globalData.language);
    },
    _initBar: function(e) {
        this.globalData.StatusBar = e.statusBarHeight;
        var t = function() {
            var t = {
                width: 87,
                height: 32,
                left: e.safeArea.width - 87 - 10,
                top: e.statusBarHeight + 4,
                right: e.safeArea.width - 10,
                bottom: e.statusBarHeight + 6 + 32
            };
            try {
                return wx.getMenuButtonBoundingClientRect() || t;
            } catch (e) {}
            return t;
        }();
        this.globalData.Custom = t, this.globalData.CustomBar = t.bottom + t.top - e.statusBarHeight;
    },
    _checkVersion: function(e) {
        return !this.version_compare(e.SDKVersion, "2.17.3", "<") || wx.redirectTo({
            url: "/pages/errors/505/505?" + (0, a.http_build_query)({
                support: "2.17.3",
                current: e.SDKVersion
            }),
            fail: function(e) {
                console.error(e);
            }
        });
    },
    _screenSecurity: function(e) {
        return !!this.version_compare(e.SDKVersion, "2.20.1", ">=") && wx.setVisualEffectOnCapture({
            visualEffect: "hidden",
            fail: function(e) {
                console.error(e);
            }
        });
    },
    version_compare: function(e, t, a) {
        function n(e) {
            return (e = (e = ("" + e).replace(/[_\-+]/g, ".")).replace(/([^.\d]+)/g, ".$1.").replace(/\.{2,}/g, ".")).length ? e.split(".") : [ -8 ];
        }
        function r(e) {
            return e ? isNaN(e) ? o[e] || -7 : parseInt(e, 10) : 0;
        }
        var i, s, u = 0, o = {
            dev: -6,
            alpha: -5,
            a: -5,
            beta: -4,
            b: -4,
            RC: -3,
            rc: -3,
            "#": -2,
            p: 1,
            pl: 1
        };
        for (e = n(e), t = n(t), s = Math.max(e.length, t.length), i = 0; i < s; i++) if (e[i] !== t[i]) {
            if (e[i] = r(e[i]), t[i] = r(t[i]), e[i] < t[i]) {
                u = -1;
                break;
            }
            if (e[i] > t[i]) {
                u = 1;
                break;
            }
        }
        if (!a) return u;
        switch (a) {
          case ">":
          case "gt":
            return 0 < u;

          case ">=":
          case "ge":
            return 0 <= u;

          case "<=":
          case "le":
            return u <= 0;

          case "===":
          case "=":
          case "eq":
            return 0 === u;

          case "<>":
          case "!==":
          case "ne":
            return 0 !== u;

          case "":
          case "<":
          case "lt":
            return u < 0;

          default:
            return null;
        }
    }
});