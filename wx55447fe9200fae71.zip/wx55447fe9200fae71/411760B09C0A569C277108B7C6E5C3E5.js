Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

exports.default = {
    zh_CN: {
        shareTitle: "Hello，推荐您一个MFA小程序，我也在使用哦~ 👍",
        Back: "返回",
        "working principle": "工作原理",
        "login account": "登录 账户",
        one1: "不论何时登录 账户，您都会像平常一样输入用户名和密码。",
        one2: "当系统要求您提供验证码时，您可以通过该应用获得。",
        ttt: "确保账户安全且由您自己掌控",
        tt1: "当您在信任的设备上登录时，可以告诉我们不再要求在该设备上输入验证码。",
        tt2: "即便如此，您的帐号仍将得到保护，因为当您(或其他人)在其他设备上登录您的帐号时，系统还是会要求输入验证码",
        rrt: "准备好添加账户了吗？",
        rr1: "请注意，您可以随时访问 提供您二维码或密钥的网站或APP 更新自己的设置",
        rr2: "更新您的电话号码",
        rr3: "创建其他备用方式",
        rr4: "停用两步验证",
        skip: "跳过",
        complete: "完成",
        st3: "注意：请妥善保管您的“密钥”或“二维码”信息，因离线数据存储极其不稳定，建议使用设置面板的“同步功能”以防止数据丢失。"
    },
    zh_HK: {
        shareTitle: "Hello，推薦您一個MFA小程序，我也在使用哦~ 👍",
        Back: "返回",
        "working principle": "工作原理",
        "login account": "登錄 賬戶",
        one1: "不論何時登錄 賬戶，您都會像平常一樣輸入用戶名和密碼。",
        one2: "當系統要求您提供驗證碼時，您可以通過該應用獲得。",
        ttt: "確保賬戶安全且由您自己掌控",
        tt1: "當您在信任的設備上登錄時，可以告訴我們不再要求在該設備上輸入驗證碼。",
        tt2: "即便如此，您的帳號仍將得到保護，因為當您(或其他人)在其他設備上登錄您的帳號時，系統還是會要求輸入驗證碼",
        rrt: "準備好添加賬戶了嗎？",
        rr1: "請注意，您可以隨時訪問 提供您二維碼或密鑰的網站或APP 更新自己的設置",
        rr2: "更新您的電話號碼",
        rr3: "創建其他備用方式",
        rr4: "停用兩步驗證",
        skip: "跳過",
        complete: "完成",
        st3: "注意：請妥善保管您的“密鑰”或“二維碼”信息，因離線數據存儲極其不穩定，建議使用設置面板的“同步功能”以防止數據丟失。"
    },
    en: {
        shareTitle: "Hello, I recommend an MFA Mini Program, I am also using it~ 👍",
        Back: "Back",
        "working principle": "Working principle",
        "login account": "Login account",
        one1: "Whenever you log in to your account, you will enter your username and password as usual.",
        one2: "When the system asks you to provide a verification code, you can get it through the app.",
        ttt: "Keep your account safe and under your control",
        tt1: "When you log in on a trusted device, you can tell us that you no longer require a verification code on that device.",
        tt2: "Even so, your account will still be protected, because when you (or other people) log in to your account on other devices, the system will still ask for a verification code",
        rrt: "Are you ready to add an account?",
        rr1: "Please note that you can always visit the website or APP that provides your QR code or key to update your settings",
        rr2: "Update your phone number",
        rr3: "Create other alternate methods",
        rr4: "Disable two-step verification",
        skip: "Skip",
        complete: "Done",
        st3: 'Note: Please keep your "key" or "QR code" information properly, because offline data storage is extremely unstable, it is recommended to use the "sync function" of the settings panel to prevent data loss.'
    }
};