var e = require("@babel/runtime/helpers/typeof.js"), t = require("@babel/runtime/helpers/classCallCheck.js"), r = require("@babel/runtime/helpers/createClass.js"), n = function(e, t) {
    if (!t && e && e.__esModule) return e;
    if (null === e || "object" != typeof e && "function" != typeof e) return {
        default: e
    };
    var r = a(t);
    if (r && r.has(e)) return r.get(e);
    var n = {}, o = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for (var i in e) if ("default" !== i && Object.prototype.hasOwnProperty.call(e, i)) {
        var s = o ? Object.getOwnPropertyDescriptor(e, i) : null;
        s && (s.get || s.set) ? Object.defineProperty(n, i, s) : n[i] = e[i];
    }
    n.default = e, r && r.set(e, n);
    return n;
}(require("F486E6F69C0A569C92E08EF1FA17C3E5.js"));

function a(e) {
    if ("function" != typeof WeakMap) return null;
    var t = new WeakMap(), r = new WeakMap();
    return (a = function(e) {
        return e ? r : t;
    })(e);
}

var o, i, s, c, u = n.Reader, l = n.Writer, p = n.util, h = n.roots.default || (n.roots.default = {});

h.MigrationPayload = ((c = function() {
    function a(e) {
        if (t(this, a), this.otpParameters = [], e) for (var r = Object.keys(e), n = 0; n < r.length; ++n) null != e[r[n]] && (this[r[n]] = e[r[n]]);
    }
    return r(a, [ {
        key: "toJSON",
        value: function() {
            return this.constructor.toObject(this, n.util.toJSONOptions);
        }
    } ], [ {
        key: "create",
        value: function(e) {
            return new a(e);
        }
    }, {
        key: "encode",
        value: function(e, t) {
            if (t || (t = l.create()), null != e.otpParameters && e.otpParameters.length) for (var r = 0; r < e.otpParameters.length; ++r) h.MigrationPayload.OtpParameters.encode(e.otpParameters[r], t.uint32(10).fork()).ldelim();
            return null != e.version && Object.hasOwnProperty.call(e, "version") && t.uint32(16).int32(e.version), 
            null != e.batchSize && Object.hasOwnProperty.call(e, "batchSize") && t.uint32(24).int32(e.batchSize), 
            null != e.batchIndex && Object.hasOwnProperty.call(e, "batchIndex") && t.uint32(32).int32(e.batchIndex), 
            null != e.batchId && Object.hasOwnProperty.call(e, "batchId") && t.uint32(40).uint32(e.batchId), 
            t;
        }
    }, {
        key: "encodeDelimited",
        value: function(e, t) {
            return this.encode(e, t).ldelim();
        }
    }, {
        key: "decode",
        value: function(e, t) {
            e instanceof u || (e = u.create(e));
            for (var r = void 0 === t ? e.len : e.pos + t, n = new h.MigrationPayload(); e.pos < r; ) {
                var a = e.uint32();
                switch (a >>> 3) {
                  case 1:
                    n.otpParameters && n.otpParameters.length || (n.otpParameters = []), n.otpParameters.push(h.MigrationPayload.OtpParameters.decode(e, e.uint32()));
                    break;

                  case 2:
                    n.version = e.int32();
                    break;

                  case 3:
                    n.batchSize = e.int32();
                    break;

                  case 4:
                    n.batchIndex = e.int32();
                    break;

                  case 5:
                    n.batchId = e.uint32();
                    break;

                  default:
                    e.skipType(7 & a);
                }
            }
            return n;
        }
    }, {
        key: "decodeDelimited",
        value: function(e) {
            return e instanceof u || (e = new u(e)), this.decode(e, e.uint32());
        }
    }, {
        key: "verify",
        value: function(t) {
            if ("object" !== e(t) || null === t) return "object expected";
            if (null != t.otpParameters && t.hasOwnProperty("otpParameters")) {
                if (!Array.isArray(t.otpParameters)) return "otpParameters: array expected";
                for (var r = 0; r < t.otpParameters.length; ++r) {
                    var n = h.MigrationPayload.OtpParameters.verify(t.otpParameters[r]);
                    if (n) return "otpParameters." + n;
                }
            }
            return null != t.version && t.hasOwnProperty("version") && !p.isInteger(t.version) ? "version: integer expected" : null != t.batchSize && t.hasOwnProperty("batchSize") && !p.isInteger(t.batchSize) ? "batchSize: integer expected" : null != t.batchIndex && t.hasOwnProperty("batchIndex") && !p.isInteger(t.batchIndex) ? "batchIndex: integer expected" : null != t.batchId && t.hasOwnProperty("batchId") && !p.isInteger(t.batchId) ? "batchId: integer expected" : null;
        }
    }, {
        key: "fromObject",
        value: function(t) {
            if (t instanceof h.MigrationPayload) return t;
            var r = new h.MigrationPayload();
            if (t.otpParameters) {
                if (!Array.isArray(t.otpParameters)) throw TypeError(".MigrationPayload.otpParameters: array expected");
                r.otpParameters = [];
                for (var n = 0; n < t.otpParameters.length; ++n) {
                    if ("object" !== e(t.otpParameters[n])) throw TypeError(".MigrationPayload.otpParameters: object expected");
                    r.otpParameters[n] = h.MigrationPayload.OtpParameters.fromObject(t.otpParameters[n]);
                }
            }
            return null != t.version && (r.version = 0 | t.version), null != t.batchSize && (r.batchSize = 0 | t.batchSize), 
            null != t.batchIndex && (r.batchIndex = 0 | t.batchIndex), null != t.batchId && (r.batchId = t.batchId >>> 0), 
            r;
        }
    }, {
        key: "toObject",
        value: function(e, t) {
            t || (t = {});
            var r = {};
            if ((t.arrays || t.defaults) && (r.otpParameters = []), t.defaults && (r.version = 0, 
            r.batchSize = 1, r.batchIndex = 0, r.batchId = 0), e.otpParameters && e.otpParameters.length) {
                r.otpParameters = [];
                for (var n = 0; n < e.otpParameters.length; ++n) r.otpParameters[n] = h.MigrationPayload.OtpParameters.toObject(e.otpParameters[n], t);
            }
            return null != e.version && e.hasOwnProperty("version") && (r.version = e.version), 
            null != e.batchSize && e.hasOwnProperty("batchSize") && (r.batchSize = e.batchSize), 
            null != e.batchIndex && e.hasOwnProperty("batchIndex") && (r.batchIndex = e.batchIndex), 
            null != e.batchId && e.hasOwnProperty("batchId") && (r.batchId = e.batchId), r;
        }
    } ]), a;
}()).prototype.otpParameters = p.emptyArray, c.prototype.version = 0, c.prototype.batchSize = 1, 
c.prototype.batchIndex = 0, c.prototype.batchId = 0, c.Algorithm = (o = {}, (i = Object.create(o))[o[0] = "ALGORITHM_UNSPECIFIED"] = 0, 
i[o[1] = "SHA1"] = 1, i[o[2] = "SHA256"] = 2, i[o[3] = "SHA512"] = 3, i[o[4] = "MD5"] = 4, 
i), c.DigitCount = function() {
    var e = {}, t = Object.create(e);
    return t[e[0] = "DIGIT_COUNT_UNSPECIFIED"] = 0, t[e[1] = "SIX"] = 1, t[e[2] = "EIGHT"] = 2, 
    t;
}(), c.OtpType = function() {
    var e = {}, t = Object.create(e);
    return t[e[0] = "OTP_TYPE_UNSPECIFIED"] = 0, t[e[1] = "HOTP"] = 1, t[e[2] = "TOTP"] = 2, 
    t;
}(), c.OtpParameters = ((s = function() {
    function a(e) {
        if (t(this, a), e) for (var r = Object.keys(e), n = 0; n < r.length; ++n) null != e[r[n]] && (this[r[n]] = e[r[n]]);
    }
    return r(a, [ {
        key: "toJSON",
        value: function() {
            return this.constructor.toObject(this, n.util.toJSONOptions);
        }
    } ], [ {
        key: "create",
        value: function(e) {
            return new a(e);
        }
    }, {
        key: "encode",
        value: function(e, t) {
            return t || (t = l.create()), null != e.secret && Object.hasOwnProperty.call(e, "secret") && t.uint32(10).bytes(e.secret), 
            null != e.name && Object.hasOwnProperty.call(e, "name") && t.uint32(18).string(e.name), 
            null != e.issuer && Object.hasOwnProperty.call(e, "issuer") && t.uint32(26).string(e.issuer), 
            null != e.algorithm && Object.hasOwnProperty.call(e, "algorithm") && t.uint32(32).int32(e.algorithm), 
            null != e.digits && Object.hasOwnProperty.call(e, "digits") && t.uint32(40).int32(e.digits), 
            null != e.type && Object.hasOwnProperty.call(e, "type") && t.uint32(48).int32(e.type), 
            null != e.counter && Object.hasOwnProperty.call(e, "counter") && t.uint32(56).uint64(e.counter), 
            t;
        }
    }, {
        key: "encodeDelimited",
        value: function(e, t) {
            return this.encode(e, t).ldelim();
        }
    }, {
        key: "decode",
        value: function(e, t) {
            e instanceof u || (e = u.create(e));
            for (var r = void 0 === t ? e.len : e.pos + t, n = new h.MigrationPayload.OtpParameters(); e.pos < r; ) {
                var a = e.uint32();
                switch (a >>> 3) {
                  case 1:
                    n.secret = e.bytes();
                    break;

                  case 2:
                    n.name = e.string();
                    break;

                  case 3:
                    n.issuer = e.string();
                    break;

                  case 4:
                    n.algorithm = e.int32();
                    break;

                  case 5:
                    n.digits = e.int32();
                    break;

                  case 6:
                    n.type = e.int32();
                    break;

                  case 7:
                    n.counter = e.uint64();
                    break;

                  default:
                    e.skipType(7 & a);
                }
            }
            return n;
        }
    }, {
        key: "decodeDelimited",
        value: function(e) {
            return e instanceof u || (e = new u(e)), this.decode(e, e.uint32());
        }
    }, {
        key: "verify",
        value: function(t) {
            if ("object" !== e(t) || null === t) return "object expected";
            if (null != t.secret && t.hasOwnProperty("secret") && !(t.secret && "number" == typeof t.secret.length || p.isString(t.secret))) return "secret: buffer expected";
            if (null != t.name && t.hasOwnProperty("name") && !p.isString(t.name)) return "name: string expected";
            if (null != t.issuer && t.hasOwnProperty("issuer") && !p.isString(t.issuer)) return "issuer: string expected";
            if (null != t.algorithm && t.hasOwnProperty("algorithm")) switch (t.algorithm) {
              default:
                return "algorithm: enum value expected";

              case 0:
              case 1:
              case 2:
              case 3:
              case 4:
            }
            if (null != t.digits && t.hasOwnProperty("digits")) switch (t.digits) {
              default:
                return "digits: enum value expected";

              case 0:
              case 1:
              case 2:
            }
            if (null != t.type && t.hasOwnProperty("type")) switch (t.type) {
              default:
                return "type: enum value expected";

              case 0:
              case 1:
              case 2:
            }
            return null != t.counter && t.hasOwnProperty("counter") && !(p.isInteger(t.counter) || t.counter && p.isInteger(t.counter.low) && p.isInteger(t.counter.high)) ? "counter: integer|Long expected" : null;
        }
    }, {
        key: "fromObject",
        value: function(t) {
            if (t instanceof h.MigrationPayload.OtpParameters) return t;
            var r = new h.MigrationPayload.OtpParameters();
            switch (null != t.secret && ("string" == typeof t.secret ? p.base64.decode(t.secret, r.secret = p.newBuffer(p.base64.length(t.secret)), 0) : t.secret.length && (r.secret = t.secret)), 
            null != t.name && (r.name = String(t.name)), null != t.issuer && (r.issuer = String(t.issuer)), 
            t.algorithm) {
              case "ALGORITHM_UNSPECIFIED":
              case 0:
                r.algorithm = 0;
                break;

              case "SHA1":
              case 1:
                r.algorithm = 1;
                break;

              case "SHA256":
              case 2:
                r.algorithm = 2;
                break;

              case "SHA512":
              case 3:
                r.algorithm = 3;
                break;

              case "MD5":
              case 4:
                r.algorithm = 4;
            }
            switch (t.digits) {
              case "DIGIT_COUNT_UNSPECIFIED":
              case 0:
                r.digits = 0;
                break;

              case "SIX":
              case 1:
                r.digits = 1;
                break;

              case "EIGHT":
              case 2:
                r.digits = 2;
            }
            switch (t.type) {
              case "OTP_TYPE_UNSPECIFIED":
              case 0:
                r.type = 0;
                break;

              case "HOTP":
              case 1:
                r.type = 1;
                break;

              case "TOTP":
              case 2:
                r.type = 2;
            }
            return null != t.counter && (p.Long ? (r.counter = p.Long.fromValue(t.counter)).unsigned = !0 : "string" == typeof t.counter ? r.counter = parseInt(t.counter, 10) : "number" == typeof t.counter ? r.counter = t.counter : "object" === e(t.counter) && (r.counter = new p.LongBits(t.counter.low >>> 0, t.counter.high >>> 0).toNumber(!0))), 
            r;
        }
    }, {
        key: "toObject",
        value: function(e, t) {
            t || (t = {});
            var r = {};
            if (t.defaults) if (t.bytes === String ? r.secret = "" : (r.secret = [], t.bytes !== Array && (r.secret = p.newBuffer(r.secret))), 
            r.name = "", r.issuer = "", r.algorithm = t.enums === String ? "ALGORITHM_UNSPECIFIED" : 0, 
            r.digits = t.enums === String ? "DIGIT_COUNT_UNSPECIFIED" : 0, r.type = t.enums === String ? "OTP_TYPE_UNSPECIFIED" : 0, 
            p.Long) {
                var n = new p.Long(0, 0, !0);
                r.counter = t.longs === String ? n.toString() : t.longs === Number ? n.toNumber() : n;
            } else r.counter = t.longs === String ? "0" : 0;
            return null != e.secret && e.hasOwnProperty("secret") && (r.secret = t.bytes === String ? p.base64.encode(e.secret, 0, e.secret.length) : t.bytes === Array ? Array.prototype.slice.call(e.secret) : e.secret), 
            null != e.name && e.hasOwnProperty("name") && (r.name = e.name), null != e.issuer && e.hasOwnProperty("issuer") && (r.issuer = e.issuer), 
            null != e.algorithm && e.hasOwnProperty("algorithm") && (r.algorithm = t.enums === String ? h.MigrationPayload.Algorithm[e.algorithm] : e.algorithm), 
            null != e.digits && e.hasOwnProperty("digits") && (r.digits = t.enums === String ? h.MigrationPayload.DigitCount[e.digits] : e.digits), 
            null != e.type && e.hasOwnProperty("type") && (r.type = t.enums === String ? h.MigrationPayload.OtpType[e.type] : e.type), 
            null != e.counter && e.hasOwnProperty("counter") && ("number" == typeof e.counter ? r.counter = t.longs === String ? String(e.counter) : e.counter : r.counter = t.longs === String ? p.Long.prototype.toString.call(e.counter) : t.longs === Number ? new p.LongBits(e.counter.low >>> 0, e.counter.high >>> 0).toNumber(!0) : e.counter), 
            r;
        }
    } ]), a;
}()).prototype.secret = p.newBuffer([]), s.prototype.name = "", s.prototype.issuer = "", 
s.prototype.algorithm = 0, s.prototype.digits = 0, s.prototype.type = 0, s.prototype.counter = p.Long ? p.Long.fromBits(0, 0, !0) : 0, 
s), c), module.exports = h;