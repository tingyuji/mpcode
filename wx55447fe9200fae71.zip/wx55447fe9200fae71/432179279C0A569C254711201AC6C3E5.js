Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("@babel/runtime/helpers/toConsumableArray.js"), t = require("@babel/runtime/helpers/classCallCheck.js"), r = require("@babel/runtime/helpers/createClass.js"), n = function() {
    function n() {
        t(this, n), this._events = new Map(), this._maxListeners = 10;
    }
    return r(n, [ {
        key: "setMaxListeners",
        value: function(e) {
            this._maxListeners = e;
        }
    }, {
        key: "emit",
        value: function(e) {
            for (var t = arguments.length, r = new Array(t > 1 ? t - 1 : 0), n = 1; n < t; n++) r[n - 1] = arguments[n];
            if ("error" === e) {
                var s = this._events.get("error");
                if (!s || 0 === s.length) {
                    var i = r[0] instanceof Error ? r[0] : new Error('Uncaught, unspecified "error" event.');
                    throw i;
                }
            }
            var o = this._events.get(e);
            return !!o && (o.forEach(function(e) {
                return e.apply(void 0, r);
            }), !0);
        }
    }, {
        key: "addListener",
        value: function(e, t) {
            if ("function" != typeof t) throw new Error("addListener only takes instances of Function");
            var r = this._events.get(e);
            return r || (r = [], this._events.set(e, r)), r.warned || this._maxListeners > 0 && r.length >= this._maxListeners && (r.warned = !0, 
            console.error("(node) warning: possible EventEmitter memory leak detected. ".concat(r.length, " listeners added. Use emitter.setMaxListeners() to increase limit.")), 
            console.trace()), r.push(t), this;
        }
    }, {
        key: "once",
        value: function(e, t) {
            var r = this;
            return this.on(e, function n() {
                r.removeListener(e, n), t.apply(void 0, arguments);
            }), this;
        }
    }, {
        key: "removeListener",
        value: function(e, t) {
            if ("function" != typeof t) throw new Error("removeListener only takes instances of Function");
            var r = this._events.get(e);
            if (r) {
                var n = r.indexOf(t);
                -1 !== n && (r.splice(n, 1), 0 === r.length && this._events.delete(e));
            }
            return this;
        }
    }, {
        key: "removeAllListeners",
        value: function(e) {
            return e ? this._events.delete(e) : this._events.clear(), this;
        }
    }, {
        key: "listeners",
        value: function(t) {
            var r = this._events.get(t);
            return r ? e(r) : [];
        }
    } ]), n;
}();

n.prototype.on = n.prototype.addListener;

var s = n;

exports.default = s;