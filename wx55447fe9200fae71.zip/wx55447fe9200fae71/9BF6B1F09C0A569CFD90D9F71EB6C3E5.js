Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.ServerError = void 0;

var e = require("@babel/runtime/helpers/createClass.js"), r = require("@babel/runtime/helpers/classCallCheck.js"), t = require("@babel/runtime/helpers/inherits.js"), i = require("@babel/runtime/helpers/createSuper.js"), u = function(u) {
    t(l, u);
    var a = i(l);
    function l(e) {
        var t;
        return r(this, l), (t = a.call(this, e)).name = "ServerError", t;
    }
    return e(l);
}(require("@babel/runtime/helpers/wrapNativeSuper.js")(Error));

exports.ServerError = u;