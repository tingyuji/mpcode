var _typeof2 = require("@babel/runtime/helpers/typeof.js");

/*!
 * protobuf.js v6.11.0 (c) 2016, daniel wirtz
 * compiled thu, 29 apr 2021 02:20:45 utc
 * licensed under the bsd-3-clause license
 * see: https://github.com/dcodeio/protobuf.js for details
 */ !function(g) {
    var r, u, t, n;
    r = {
        1: [ function(t, r, n) {
            r.exports = function(t, r) {
                for (var n = Array(arguments.length - 1), e = 0, i = 2, o = !0; i < arguments.length; ) n[e++] = arguments[i++];
                return new Promise(function(i, s) {
                    n[e] = function(t) {
                        if (o) if (o = !1, t) s(t); else {
                            for (var r = Array(arguments.length - 1), n = 0; n < r.length; ) r[n++] = arguments[n];
                            i.apply(null, r);
                        }
                    };
                    try {
                        t.apply(r || null, n);
                    } catch (t) {
                        o && (o = !1, s(t));
                    }
                });
            };
        }, {} ],
        2: [ function(t, r, n) {
            n.length = function(t) {
                var r = t.length;
                if (!r) return 0;
                for (var n = 0; 1 < --r % 4 && "=" == (t[0 | r] || ""); ) ++n;
                return Math.ceil(3 * t.length) / 4 - n;
            };
            for (var e = Array(64), i = Array(123), o = 0; o < 64; ) i[e[o] = o < 26 ? o + 65 : o < 52 ? o + 71 : o < 62 ? o - 4 : o - 59 | 43] = o++;
            n.encode = function(t, r, n) {
                for (var i, o = null, s = [], u = 0, f = 0; r < n; ) {
                    var h = t[r++];
                    switch (f) {
                      case 0:
                        s[u++] = e[h >> 2], i = (3 & h) << 4, f = 1;
                        break;

                      case 1:
                        s[u++] = e[i | h >> 4], i = (15 & h) << 2, f = 2;
                        break;

                      case 2:
                        s[u++] = e[i | h >> 6], s[u++] = e[63 & h], f = 0;
                    }
                    8191 < u && ((o = o || []).push(String.fromCharCode.apply(String, s)), u = 0);
                }
                return f && (s[u++] = e[i], s[u++] = 61, 1 === f && (s[u++] = 61)), o ? (u && o.push(String.fromCharCode.apply(String, s.slice(0, u))), 
                o.join("")) : String.fromCharCode.apply(String, s.slice(0, u));
            };
            var s = "invalid encoding";
            n.decode = function(t, r, n) {
                for (var e, o = n, u = 0, f = 0; f < t.length; ) {
                    var h = t.charCodeAt(f++);
                    if (61 == h && 1 < u) break;
                    if ((h = i[h]) === g) throw Error(s);
                    switch (u) {
                      case 0:
                        e = h, u = 1;
                        break;

                      case 1:
                        r[n++] = e << 2 | (48 & h) >> 4, e = h, u = 2;
                        break;

                      case 2:
                        r[n++] = (15 & e) << 4 | (60 & h) >> 2, e = h, u = 3;
                        break;

                      case 3:
                        r[n++] = (3 & e) << 6 | h, u = 0;
                    }
                }
                if (1 === u) throw Error(s);
                return n - o;
            }, n.test = function(t) {
                return /^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(t);
            };
        }, {} ],
        3: [ function(t, r, n) {
            function e() {
                this.t = {};
            }
            (r.exports = e).prototype.on = function(t, r, n) {
                return (this.t[t] || (this.t[t] = [])).push({
                    fn: r,
                    ctx: n || this
                }), this;
            }, e.prototype.off = function(t, r) {
                if (t === g) this.t = {}; else if (r === g) this.t[t] = []; else for (var n = this.t[t], e = 0; e < n.length; ) n[e].fn === r ? n.splice(e, 1) : ++e;
                return this;
            }, e.prototype.emit = function(t) {
                var r = this.t[t];
                if (r) {
                    for (var n = [], e = 1; e < arguments.length; ) n.push(arguments[e++]);
                    for (e = 0; e < r.length; ) r[e].fn.apply(r[e++].ctx, n);
                }
                return this;
            };
        }, {} ],
        4: [ function(t, r, n) {
            function e(t) {
                function r(t, r, n, e) {
                    var i = r < 0 ? 1 : 0;
                    t(0 === (r = i ? -r : r) ? 0 < 1 / r ? 0 : 2147483648 : isNaN(r) ? 2143289344 : 3.4028234663852886e38 < r ? (i << 31 | 2139095040) >>> 0 : r < 1.1754943508222875e-38 ? (i << 31 | Math.round(r / 1.401298464324817e-45)) >>> 0 : (i << 31 | 127 + (i = Math.floor(Math.log(r) / Math.LN2)) << 23 | 8388607 & Math.round(r * Math.pow(2, -i) * 8388608)) >>> 0, n, e);
                }
                function n(t, r, n) {
                    return r = 2 * ((t = t(r, n)) >> 31) + 1, n = t >>> 23 & 255, t &= 8388607, 255 == n ? t ? NaN : 1 / 0 * r : 0 == n ? 1.401298464324817e-45 * r * t : r * Math.pow(2, n - 150) * (8388608 + t);
                }
                function e(t, r, n) {
                    a[0] = t, r[n] = c[0], r[n + 1] = c[1], r[n + 2] = c[2], r[n + 3] = c[3];
                }
                function f(t, r, n) {
                    a[0] = t, r[n] = c[3], r[n + 1] = c[2], r[n + 2] = c[1], r[n + 3] = c[0];
                }
                function h(t, r) {
                    return c[0] = t[r], c[1] = t[r + 1], c[2] = t[r + 2], c[3] = t[r + 3], a[0];
                }
                function l(t, r) {
                    return c[3] = t[r], c[2] = t[r + 1], c[1] = t[r + 2], c[0] = t[r + 3], a[0];
                }
                var a, c, p, y, d;
                function b(t, r, n, e, i, o) {
                    var s, u = e < 0 ? 1 : 0;
                    0 === (e = u ? -e : e) ? (t(0, i, o + r), t(0 < 1 / e ? 0 : 2147483648, i, o + n)) : isNaN(e) ? (t(0, i, o + r), 
                    t(2146959360, i, o + n)) : 1.7976931348623157e308 < e ? (t(0, i, o + r), t((u << 31 | 2146435072) >>> 0, i, o + n)) : e < 2.2250738585072014e-308 ? (t((s = e / 5e-324) >>> 0, i, o + r), 
                    t((u << 31 | s / 4294967296) >>> 0, i, o + n)) : (t(4503599627370496 * (s = e * Math.pow(2, -(e = 1024 === (e = Math.floor(Math.log(e) / Math.LN2)) ? 1023 : e))) >>> 0, i, o + r), 
                    t((u << 31 | e + 1023 << 20 | 1048576 * s & 1048575) >>> 0, i, o + n));
                }
                function g(t, r, n, e, i) {
                    return r = t(e, i + r), i = 2 * ((e = t(e, i + n)) >> 31) + 1, r = 4294967296 * (1048575 & e) + r, 
                    2047 == (n = e >>> 20 & 2047) ? r ? NaN : 1 / 0 * i : 0 == n ? 5e-324 * i * r : i * Math.pow(2, n - 1075) * (r + 4503599627370496);
                }
                function m(t, r, n) {
                    p[0] = t, r[n] = y[0], r[n + 1] = y[1], r[n + 2] = y[2], r[n + 3] = y[3], r[n + 4] = y[4], 
                    r[n + 5] = y[5], r[n + 6] = y[6], r[n + 7] = y[7];
                }
                function w(t, r, n) {
                    p[0] = t, r[n] = y[7], r[n + 1] = y[6], r[n + 2] = y[5], r[n + 3] = y[4], r[n + 4] = y[3], 
                    r[n + 5] = y[2], r[n + 6] = y[1], r[n + 7] = y[0];
                }
                function v(t, r) {
                    return y[0] = t[r], y[1] = t[r + 1], y[2] = t[r + 2], y[3] = t[r + 3], y[4] = t[r + 4], 
                    y[5] = t[r + 5], y[6] = t[r + 6], y[7] = t[r + 7], p[0];
                }
                function A(t, r) {
                    return y[7] = t[r], y[6] = t[r + 1], y[5] = t[r + 2], y[4] = t[r + 3], y[3] = t[r + 4], 
                    y[2] = t[r + 5], y[1] = t[r + 6], y[0] = t[r + 7], p[0];
                }
                return "undefined" != typeof Float32Array ? (a = new Float32Array([ -0 ]), d = 128 === (c = new Uint8Array(a.buffer))[3], 
                t.writeFloatLE = d ? e : f, t.writeFloatBE = d ? f : e, t.readFloatLE = d ? h : l, 
                t.readFloatBE = d ? l : h) : (t.writeFloatLE = r.bind(null, i), t.writeFloatBE = r.bind(null, o), 
                t.readFloatLE = n.bind(null, s), t.readFloatBE = n.bind(null, u)), "undefined" != typeof Float64Array ? (p = new Float64Array([ -0 ]), 
                d = 128 === (y = new Uint8Array(p.buffer))[7], t.writeDoubleLE = d ? m : w, t.writeDoubleBE = d ? w : m, 
                t.readDoubleLE = d ? v : A, t.readDoubleBE = d ? A : v) : (t.writeDoubleLE = b.bind(null, i, 0, 4), 
                t.writeDoubleBE = b.bind(null, o, 4, 0), t.readDoubleLE = g.bind(null, s, 0, 4), 
                t.readDoubleBE = g.bind(null, u, 4, 0)), t;
            }
            function i(t, r, n) {
                r[n] = 255 & t, r[n + 1] = t >>> 8 & 255, r[n + 2] = t >>> 16 & 255, r[n + 3] = t >>> 24;
            }
            function o(t, r, n) {
                r[n] = t >>> 24, r[n + 1] = t >>> 16 & 255, r[n + 2] = t >>> 8 & 255, r[n + 3] = 255 & t;
            }
            function s(t, r) {
                return (t[r] | t[r + 1] << 8 | t[r + 2] << 16 | t[r + 3] << 24) >>> 0;
            }
            function u(t, r) {
                return (t[r] << 24 | t[r + 1] << 16 | t[r + 2] << 8 | t[r + 3]) >>> 0;
            }
            r.exports = e(e);
        }, {} ],
        5: [ function(t, n, i) {
            function r(t) {
                try {
                    var n = eval("require")(t);
                    if (n && (n.length || Object.keys(n).length)) return n;
                } catch (t) {}
                return null;
            }
            n.exports = r;
        }, {} ],
        6: [ function(t, r, n) {
            r.exports = function(t, r, n) {
                var e = n || 8192, i = e >>> 1, o = null, s = e;
                return function(n) {
                    return n < 1 || i < n ? t(n) : (e < s + n && (o = t(e), s = 0), n = r.call(o, s, s += n), 
                    7 & s && (s = 1 + (7 | s)), n);
                };
            };
        }, {} ],
        7: [ function(t, r, n) {
            n.length = function(t) {
                for (var r, n = 0, e = 0; e < t.length; ++e) (r = t.charCodeAt(e)) < 128 ? n += 1 : r < 2048 ? n += 2 : 55296 == (64512 & r) && 56320 == (64512 & t.charCodeAt(e + 1)) ? (++e, 
                n += 4) : n += 3;
                return n;
            }, n.read = function(t, r, n) {
                if (n - r < 1) return "";
                for (var e, i = null, o = [], s = 0; r < n; ) (e = t[r++]) < 128 ? o[s++] = e : 191 < e && e < 224 ? o[s++] = (31 & e) << 6 | 63 & t[r++] : 239 < e && e < 365 ? (e = ((7 & e) << 18 | (63 & t[r++]) << 12 | (63 & t[r++]) << 6 | 63 & t[r++]) - 65536, 
                o[s++] = 55296 + (e >> 10), o[s++] = 56320 + (1023 & e)) : o[s++] = (15 & e) << 12 | (63 & t[r++]) << 6 | 63 & t[r++], 
                8191 < s && ((i = i || []).push(String.fromCharCode.apply(String, o)), s = 0);
                return i ? (s && i.push(String.fromCharCode.apply(String, o.slice(0, s))), i.join("")) : String.fromCharCode.apply(String, o.slice(0, s));
            }, n.write = function(t, r, n) {
                for (var e, i, o = n, s = 0; s < t.length; ++s) (e = t.charCodeAt(s)) < 128 ? r[n++] = e : (e < 2048 ? r[n++] = e >> 6 | 192 : (55296 == (64512 & e) && 56320 == (64512 & (i = t.charCodeAt(s + 1))) ? (++s, 
                r[n++] = (e = 65536 + ((1023 & e) << 10) + (1023 & i)) >> 18 | 240, r[n++] = e >> 12 & 63 | 128) : r[n++] = e >> 12 | 224, 
                r[n++] = e >> 6 & 63 | 128), r[n++] = 63 & e | 128);
                return n - o;
            };
        }, {} ],
        8: [ function(t, r, n) {
            var e = n;
            function i() {
                e.util.n(), e.Writer.n(e.BufferWriter), e.Reader.n(e.BufferReader);
            }
            e.build = "minimal", e.Writer = t(16), e.BufferWriter = t(17), e.Reader = t(9), 
            e.BufferReader = t(10), e.util = t(15), e.rpc = t(12), e.roots = t(11), e.configure = i, 
            i();
        }, {
            10: 10,
            11: 11,
            12: 12,
            15: 15,
            16: 16,
            17: 17,
            9: 9
        } ],
        9: [ function(t, r, n) {
            r.exports = f;
            var e, i = t(15), o = i.LongBits, s = i.utf8;
            function u(t, r) {
                return RangeError("index out of range: " + t.pos + " + " + (r || 1) + " > " + t.len);
            }
            function f(t) {
                this.buf = t, this.pos = 0, this.len = t.length;
            }
            function h() {
                return i.Buffer ? function(t) {
                    return (f.create = function(t) {
                        return i.Buffer.isBuffer(t) ? new e(t) : a(t);
                    })(t);
                } : a;
            }
            var l, a = "undefined" != typeof Uint8Array ? function(t) {
                if (t instanceof Uint8Array || Array.isArray(t)) return new f(t);
                throw Error("illegal buffer");
            } : function(t) {
                if (Array.isArray(t)) return new f(t);
                throw Error("illegal buffer");
            };
            function c() {
                var t = new o(0, 0), r = 0;
                if (!(4 < this.len - this.pos)) {
                    for (;r < 3; ++r) {
                        if (this.pos >= this.len) throw u(this);
                        if (t.lo = (t.lo | (127 & this.buf[this.pos]) << 7 * r) >>> 0, this.buf[this.pos++] < 128) return t;
                    }
                    return t.lo = (t.lo | (127 & this.buf[this.pos++]) << 7 * r) >>> 0, t;
                }
                for (;r < 4; ++r) if (t.lo = (t.lo | (127 & this.buf[this.pos]) << 7 * r) >>> 0, 
                this.buf[this.pos++] < 128) return t;
                if (t.lo = (t.lo | (127 & this.buf[this.pos]) << 28) >>> 0, t.hi = (t.hi | (127 & this.buf[this.pos]) >> 4) >>> 0, 
                this.buf[this.pos++] < 128) return t;
                if (r = 0, 4 < this.len - this.pos) {
                    for (;r < 5; ++r) if (t.hi = (t.hi | (127 & this.buf[this.pos]) << 7 * r + 3) >>> 0, 
                    this.buf[this.pos++] < 128) return t;
                } else for (;r < 5; ++r) {
                    if (this.pos >= this.len) throw u(this);
                    if (t.hi = (t.hi | (127 & this.buf[this.pos]) << 7 * r + 3) >>> 0, this.buf[this.pos++] < 128) return t;
                }
                throw Error("invalid varint encoding");
            }
            function p(t, r) {
                return (t[r - 4] | t[r - 3] << 8 | t[r - 2] << 16 | t[r - 1] << 24) >>> 0;
            }
            function y() {
                if (this.pos + 8 > this.len) throw u(this, 8);
                return new o(p(this.buf, this.pos += 4), p(this.buf, this.pos += 4));
            }
            f.create = h(), f.prototype.i = i.Array.prototype.subarray || i.Array.prototype.slice, 
            f.prototype.uint32 = (l = 4294967295, function() {
                if (l = (127 & this.buf[this.pos]) >>> 0, this.buf[this.pos++] < 128) return l;
                if (l = (l | (127 & this.buf[this.pos]) << 7) >>> 0, this.buf[this.pos++] < 128) return l;
                if (l = (l | (127 & this.buf[this.pos]) << 14) >>> 0, this.buf[this.pos++] < 128) return l;
                if (l = (l | (127 & this.buf[this.pos]) << 21) >>> 0, this.buf[this.pos++] < 128) return l;
                if (l = (l | (15 & this.buf[this.pos]) << 28) >>> 0, this.buf[this.pos++] < 128) return l;
                if ((this.pos += 5) > this.len) throw this.pos = this.len, u(this, 10);
                return l;
            }), f.prototype.int32 = function() {
                return 0 | this.uint32();
            }, f.prototype.sint32 = function() {
                var t = this.uint32();
                return t >>> 1 ^ -(1 & t) | 0;
            }, f.prototype.bool = function() {
                return 0 !== this.uint32();
            }, f.prototype.fixed32 = function() {
                if (this.pos + 4 > this.len) throw u(this, 4);
                return p(this.buf, this.pos += 4);
            }, f.prototype.sfixed32 = function() {
                if (this.pos + 4 > this.len) throw u(this, 4);
                return 0 | p(this.buf, this.pos += 4);
            }, f.prototype.float = function() {
                if (this.pos + 4 > this.len) throw u(this, 4);
                var t = i.float.readFloatLE(this.buf, this.pos);
                return this.pos += 4, t;
            }, f.prototype.double = function() {
                if (this.pos + 8 > this.len) throw u(this, 4);
                var t = i.float.readDoubleLE(this.buf, this.pos);
                return this.pos += 8, t;
            }, f.prototype.bytes = function() {
                var t = this.uint32(), r = this.pos, n = this.pos + t;
                if (n > this.len) throw u(this, t);
                return this.pos += t, Array.isArray(this.buf) ? this.buf.slice(r, n) : r === n ? new this.buf.constructor(0) : this.i.call(this.buf, r, n);
            }, f.prototype.string = function() {
                var t = this.bytes();
                return s.read(t, 0, t.length);
            }, f.prototype.skip = function(t) {
                if ("number" == typeof t) {
                    if (this.pos + t > this.len) throw u(this, t);
                    this.pos += t;
                } else do {
                    if (this.pos >= this.len) throw u(this);
                } while (128 & this.buf[this.pos++]);
                return this;
            }, f.prototype.skipType = function(t) {
                switch (t) {
                  case 0:
                    this.skip();
                    break;

                  case 1:
                    this.skip(8);
                    break;

                  case 2:
                    this.skip(this.uint32());
                    break;

                  case 3:
                    for (;4 != (t = 7 & this.uint32()); ) this.skipType(t);
                    break;

                  case 5:
                    this.skip(4);
                    break;

                  default:
                    throw Error("invalid wire type " + t + " at offset " + this.pos);
                }
                return this;
            }, f.n = function(t) {
                e = t, f.create = h(), e.n();
                var r = i.Long ? "toLong" : "toNumber";
                i.merge(f.prototype, {
                    int64: function() {
                        return c.call(this)[r](!1);
                    },
                    uint64: function() {
                        return c.call(this)[r](!0);
                    },
                    sint64: function() {
                        return c.call(this).zzDecode()[r](!1);
                    },
                    fixed64: function() {
                        return y.call(this)[r](!0);
                    },
                    sfixed64: function() {
                        return y.call(this)[r](!1);
                    }
                });
            };
        }, {
            15: 15
        } ],
        10: [ function(t, r, n) {
            r.exports = o;
            var e = t(9);
            (o.prototype = Object.create(e.prototype)).constructor = o;
            var i = t(15);
            function o(t) {
                e.call(this, t);
            }
            o.n = function() {
                i.Buffer && (o.prototype.i = i.Buffer.prototype.slice);
            }, o.prototype.string = function() {
                var t = this.uint32();
                return this.buf.utf8Slice ? this.buf.utf8Slice(this.pos, this.pos = Math.min(this.pos + t, this.len)) : this.buf.toString("utf-8", this.pos, this.pos = Math.min(this.pos + t, this.len));
            }, o.n();
        }, {
            15: 15,
            9: 9
        } ],
        11: [ function(t, r, n) {
            r.exports = {};
        }, {} ],
        12: [ function(t, r, n) {
            n.Service = t(13);
        }, {
            13: 13
        } ],
        13: [ function(t, r, n) {
            r.exports = i;
            var e = t(15);
            function i(t, r, n) {
                if ("function" != typeof t) throw TypeError("rpcImpl must be a function");
                e.EventEmitter.call(this), this.rpcImpl = t, this.requestDelimited = !!r, this.responseDelimited = !!n;
            }
            ((i.prototype = Object.create(e.EventEmitter.prototype)).constructor = i).prototype.rpcCall = function t(r, n, i, o, s) {
                if (!o) throw TypeError("request must be specified");
                var u = this;
                if (!s) return e.asPromise(t, u, r, n, i, o);
                if (!u.rpcImpl) return setTimeout(function() {
                    s(Error("already ended"));
                }, 0), g;
                try {
                    return u.rpcImpl(r, n[u.requestDelimited ? "encodeDelimited" : "encode"](o).finish(), function(t, n) {
                        if (t) return u.emit("error", t, r), s(t);
                        if (null === n) return u.end(!0), g;
                        if (!(n instanceof i)) try {
                            n = i[u.responseDelimited ? "decodeDelimited" : "decode"](n);
                        } catch (t) {
                            return u.emit("error", t, r), s(t);
                        }
                        return u.emit("data", n, r), s(null, n);
                    });
                } catch (t) {
                    return u.emit("error", t, r), setTimeout(function() {
                        s(t);
                    }, 0), g;
                }
            }, i.prototype.end = function(t) {
                return this.rpcImpl && (t || this.rpcImpl(null, null, null), this.rpcImpl = null, 
                this.emit("end").off()), this;
            };
        }, {
            15: 15
        } ],
        14: [ function(t, r, n) {
            r.exports = i;
            var e = t(15);
            function i(t, r) {
                this.lo = t >>> 0, this.hi = r >>> 0;
            }
            var o = i.zero = new i(0, 0);
            o.toNumber = function() {
                return 0;
            }, o.zzEncode = o.zzDecode = function() {
                return this;
            }, o.length = function() {
                return 1;
            }, i.zeroHash = "\0\0\0\0\0\0\0\0", i.fromNumber = function(t) {
                if (0 === t) return o;
                var r = t < 0, n = (t = r ? -t : t) >>> 0;
                t = (t - n) / 4294967296 >>> 0;
                return r && (t = ~t >>> 0, n = ~n >>> 0, 4294967295 < ++n && (n = 0, 4294967295 < ++t && (t = 0))), 
                new i(n, t);
            }, i.from = function(t) {
                if ("number" == typeof t) return i.fromNumber(t);
                if (e.isString(t)) {
                    if (!e.Long) return i.fromNumber(parseInt(t, 10));
                    t = e.Long.fromString(t);
                }
                return t.low || t.high ? new i(t.low >>> 0, t.high >>> 0) : o;
            }, i.prototype.toNumber = function(t) {
                if (!t && this.hi >>> 31) {
                    var r = 1 + ~this.lo >>> 0;
                    t = ~this.hi >>> 0;
                    return -(r + 4294967296 * (t = r ? t : t + 1 >>> 0));
                }
                return this.lo + 4294967296 * this.hi;
            }, i.prototype.toLong = function(t) {
                return e.Long ? new e.Long(0 | this.lo, 0 | this.hi, !!t) : {
                    low: 0 | this.lo,
                    high: 0 | this.hi,
                    unsigned: !!t
                };
            };
            var s = String.prototype.charCodeAt;
            i.fromHash = function(t) {
                return "\0\0\0\0\0\0\0\0" === t ? o : new i((s.call(t, 0) | s.call(t, 1) << 8 | s.call(t, 2) << 16 | s.call(t, 3) << 24) >>> 0, (s.call(t, 4) | s.call(t, 5) << 8 | s.call(t, 6) << 16 | s.call(t, 7) << 24) >>> 0);
            }, i.prototype.toHash = function() {
                return String.fromCharCode(255 & this.lo, this.lo >>> 8 & 255, this.lo >>> 16 & 255, this.lo >>> 24, 255 & this.hi, this.hi >>> 8 & 255, this.hi >>> 16 & 255, this.hi >>> 24);
            }, i.prototype.zzEncode = function() {
                var t = this.hi >> 31;
                return this.hi = ((this.hi << 1 | this.lo >>> 31) ^ t) >>> 0, this.lo = (this.lo << 1 ^ t) >>> 0, 
                this;
            }, i.prototype.zzDecode = function() {
                var t = -(1 & this.lo);
                return this.lo = ((this.lo >>> 1 | this.hi << 31) ^ t) >>> 0, this.hi = (this.hi >>> 1 ^ t) >>> 0, 
                this;
            }, i.prototype.length = function() {
                var t = this.lo, r = (this.lo >>> 28 | this.hi << 4) >>> 0, n = this.hi >>> 24;
                return 0 == n ? 0 == r ? t < 16384 ? t < 128 ? 1 : 2 : t < 2097152 ? 3 : 4 : r < 16384 ? r < 128 ? 5 : 6 : r < 2097152 ? 7 : 8 : n < 128 ? 9 : 10;
            };
        }, {
            15: 15
        } ],
        15: [ function(t, r, n) {
            var e = n;
            function i(t, r, n) {
                for (var e = Object.keys(r), i = 0; i < e.length; ++i) t[e[i]] !== g && n || (t[e[i]] = r[e[i]]);
                return t;
            }
            function o(t) {
                function r(t, n) {
                    if (!(this instanceof r)) return new r(t, n);
                    Object.defineProperty(this, "message", {
                        get: function() {
                            return t;
                        }
                    }), Error.captureStackTrace ? Error.captureStackTrace(this, r) : Object.defineProperty(this, "stack", {
                        value: Error().stack || ""
                    }), n && i(this, n);
                }
                return (r.prototype = Object.create(Error.prototype)).constructor = r, Object.defineProperty(r.prototype, "name", {
                    get: function() {
                        return t;
                    }
                }), r.prototype.toString = function() {
                    return this.name + ": " + this.message;
                }, r;
            }
            e.asPromise = t(1), e.base64 = t(2), e.EventEmitter = t(3), e.float = t(4), e.inquire = t(5), 
            e.utf8 = t(7), e.pool = t(6), e.LongBits = t(14), e.isNode = !!("undefined" != typeof global && global && global.process && global.process.versions && global.process.versions.node), 
            e.global = e.isNode && global || "undefined" != typeof window && window || "undefined" != typeof self && self || this, 
            e.emptyArray = Object.freeze ? Object.freeze([]) : [], e.emptyObject = Object.freeze ? Object.freeze({}) : {}, 
            e.isInteger = Number.isInteger || function(t) {
                return "number" == typeof t && isFinite(t) && Math.floor(t) === t;
            }, e.isString = function(t) {
                return "string" == typeof t || t instanceof String;
            }, e.isObject = function(t) {
                return t && "object" == _typeof2(t);
            }, e.isset = e.isSet = function(t, r) {
                var n = t[r];
                return null != n && t.hasOwnProperty(r) && ("object" != _typeof2(n) || 0 < (Array.isArray(n) ? n : Object.keys(n)).length);
            }, e.Buffer = function() {
                try {
                    var t = e.inquire("buffer").Buffer;
                    return t.prototype.utf8Write ? t : null;
                } catch (t) {
                    return null;
                }
            }(), e.r = null, e.u = null, e.newBuffer = function(t) {
                return "number" == typeof t ? e.Buffer ? e.u(t) : new e.Array(t) : e.Buffer ? e.r(t) : "undefined" == typeof Uint8Array ? t : new Uint8Array(t);
            }, e.Array = "undefined" != typeof Uint8Array ? Uint8Array : Array, e.Long = e.global.dcodeIO && e.global.dcodeIO.Long || e.global.Long || e.inquire("long"), 
            e.key2Re = /^true|false|0|1$/, e.key32Re = /^-?(?:0|[1-9][0-9]*)$/, e.key64Re = /^(?:[\\x00-\\xff]{8}|-?(?:0|[1-9][0-9]*))$/, 
            e.longToHash = function(t) {
                return t ? e.LongBits.from(t).toHash() : e.LongBits.zeroHash;
            }, e.longFromHash = function(t, r) {
                return t = e.LongBits.fromHash(t), e.Long ? e.Long.fromBits(t.lo, t.hi, r) : t.toNumber(!!r);
            }, e.merge = i, e.lcFirst = function(t) {
                return (t[0] || "").toLowerCase() + t.substring(1);
            }, e.newError = o, e.ProtocolError = o("ProtocolError"), e.oneOfGetter = function(t) {
                for (var r = {}, n = 0; n < t.length; ++n) r[t[n]] = 1;
                return function() {
                    for (var t = Object.keys(this), n = t.length - 1; -1 < n; --n) if (1 === r[t[n]] && this[t[n]] !== g && null !== this[t[n]]) return t[n];
                };
            }, e.oneOfSetter = function(t) {
                return function(r) {
                    for (var n = 0; n < t.length; ++n) t[n] !== r && delete this[t[n]];
                };
            }, e.toJSONOptions = {
                longs: String,
                enums: String,
                bytes: String,
                json: !0
            }, e.n = function() {
                var t = e.Buffer;
                t ? (e.r = t.from !== Uint8Array.from && t.from || function(r, n) {
                    return new t(r, n);
                }, e.u = t.allocUnsafe || function(r) {
                    return new t(r);
                }) : e.r = e.u = null;
            };
        }, {
            1: 1,
            14: 14,
            2: 2,
            3: 3,
            4: 4,
            5: 5,
            6: 6,
            7: 7
        } ],
        16: [ function(t, r, n) {
            r.exports = a;
            var e, i = t(15), o = i.LongBits, s = i.base64, u = i.utf8;
            function f(t, r, n) {
                this.fn = t, this.len = r, this.next = g, this.val = n;
            }
            function h() {}
            function l(t) {
                this.head = t.head, this.tail = t.tail, this.len = t.len, this.next = t.states;
            }
            function a() {
                this.len = 0, this.head = new f(h, 0, 0), this.tail = this.head, this.states = null;
            }
            function c() {
                return i.Buffer ? function() {
                    return (a.create = function() {
                        return new e();
                    })();
                } : function() {
                    return new a();
                };
            }
            function p(t, r, n) {
                r[n] = 255 & t;
            }
            function y(t, r) {
                this.len = t, this.next = g, this.val = r;
            }
            function d(t, r, n) {
                for (;t.hi; ) r[n++] = 127 & t.lo | 128, t.lo = (t.lo >>> 7 | t.hi << 25) >>> 0, 
                t.hi >>>= 7;
                for (;127 < t.lo; ) r[n++] = 127 & t.lo | 128, t.lo = t.lo >>> 7;
                r[n++] = t.lo;
            }
            function b(t, r, n) {
                r[n] = 255 & t, r[n + 1] = t >>> 8 & 255, r[n + 2] = t >>> 16 & 255, r[n + 3] = t >>> 24;
            }
            a.create = c(), a.alloc = function(t) {
                return new i.Array(t);
            }, i.Array !== Array && (a.alloc = i.pool(a.alloc, i.Array.prototype.subarray)), 
            a.prototype.s = function(t, r, n) {
                return this.tail = this.tail.next = new f(t, r, n), this.len += r, this;
            }, (y.prototype = Object.create(f.prototype)).fn = function(t, r, n) {
                for (;127 < t; ) r[n++] = 127 & t | 128, t >>>= 7;
                r[n] = t;
            }, a.prototype.uint32 = function(t) {
                return this.len += (this.tail = this.tail.next = new y((t >>>= 0) < 128 ? 1 : t < 16384 ? 2 : t < 2097152 ? 3 : t < 268435456 ? 4 : 5, t)).len, 
                this;
            }, a.prototype.int32 = function(t) {
                return t < 0 ? this.s(d, 10, o.fromNumber(t)) : this.uint32(t);
            }, a.prototype.sint32 = function(t) {
                return this.uint32((t << 1 ^ t >> 31) >>> 0);
            }, a.prototype.int64 = a.prototype.uint64 = function(t) {
                return t = o.from(t), this.s(d, t.length(), t);
            }, a.prototype.sint64 = function(t) {
                return t = o.from(t).zzEncode(), this.s(d, t.length(), t);
            }, a.prototype.bool = function(t) {
                return this.s(p, 1, t ? 1 : 0);
            }, a.prototype.sfixed32 = a.prototype.fixed32 = function(t) {
                return this.s(b, 4, t >>> 0);
            }, a.prototype.sfixed64 = a.prototype.fixed64 = function(t) {
                return t = o.from(t), this.s(b, 4, t.lo).s(b, 4, t.hi);
            }, a.prototype.float = function(t) {
                return this.s(i.float.writeFloatLE, 4, t);
            }, a.prototype.double = function(t) {
                return this.s(i.float.writeDoubleLE, 8, t);
            };
            var m = i.Array.prototype.set ? function(t, r, n) {
                r.set(t, n);
            } : function(t, r, n) {
                for (var e = 0; e < t.length; ++e) r[n + e] = t[e];
            };
            a.prototype.bytes = function(t) {
                var r, n = t.length >>> 0;
                return n ? (i.isString(t) && (r = a.alloc(n = s.length(t)), s.decode(t, r, 0), t = r), 
                this.uint32(n).s(m, n, t)) : this.s(p, 1, 0);
            }, a.prototype.string = function(t) {
                var r = u.length(t);
                return r ? this.uint32(r).s(u.write, r, t) : this.s(p, 1, 0);
            }, a.prototype.fork = function() {
                return this.states = new l(this), this.head = this.tail = new f(h, 0, 0), this.len = 0, 
                this;
            }, a.prototype.reset = function() {
                return this.states ? (this.head = this.states.head, this.tail = this.states.tail, 
                this.len = this.states.len, this.states = this.states.next) : (this.head = this.tail = new f(h, 0, 0), 
                this.len = 0), this;
            }, a.prototype.ldelim = function() {
                var t = this.head, r = this.tail, n = this.len;
                return this.reset().uint32(n), n && (this.tail.next = t.next, this.tail = r, this.len += n), 
                this;
            }, a.prototype.finish = function() {
                for (var t = this.head.next, r = this.constructor.alloc(this.len), n = 0; t; ) t.fn(t.val, r, n), 
                n += t.len, t = t.next;
                return r;
            }, a.n = function(t) {
                e = t, a.create = c(), e.n();
            };
        }, {
            15: 15
        } ],
        17: [ function(t, r, n) {
            r.exports = o;
            var e = t(16);
            (o.prototype = Object.create(e.prototype)).constructor = o;
            var i = t(15);
            function o() {
                e.call(this);
            }
            function s(t, r, n) {
                t.length < 40 ? i.utf8.write(t, r, n) : r.utf8Write ? r.utf8Write(t, n) : r.write(t, n);
            }
            o.n = function() {
                o.alloc = i.u, o.writeBytesBuffer = i.Buffer && i.Buffer.prototype instanceof Uint8Array && "set" === i.Buffer.prototype.set.name ? function(t, r, n) {
                    r.set(t, n);
                } : function(t, r, n) {
                    if (t.copy) t.copy(r, n, 0, t.length); else for (var e = 0; e < t.length; ) r[n++] = t[e++];
                };
            }, o.prototype.bytes = function(t) {
                var r = (t = i.isString(t) ? i.r(t, "base64") : t).length >>> 0;
                return this.uint32(r), r && this.s(o.writeBytesBuffer, r, t), this;
            }, o.prototype.string = function(t) {
                var r = i.Buffer.byteLength(t);
                return this.uint32(r), r && this.s(s, r, t), this;
            }, o.n();
        }, {
            15: 15,
            16: 16
        } ]
    }, u = {}, t = [ 8 ], n = function t(n) {
        var e = u[n];
        return e || r[n][0].call(e = u[n] = {
            exports: {}
        }, t, e, e.exports), e.exports;
    }(t[0]), n.util.global.protobuf = n, "function" == typeof define && define.amd && define([ "long" ], function(t) {
        return t && t.isLong && (n.util.Long = t, n.configure()), n;
    }), "object" == ("undefined" == typeof module ? "undefined" : _typeof2(module)) && module && module.exports && (module.exports = n);
}();