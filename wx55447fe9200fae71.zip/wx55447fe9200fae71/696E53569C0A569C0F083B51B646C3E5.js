Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

exports.default = {
    zh_CN: {
        shareTitle: "Hello，推荐您一个MFA小程序，我也在使用哦~ 👍",
        Back: "返回",
        pp: "隐私策略",
        b1: "请花一些时间熟悉我们的隐私政策，如果您有任何问题，请联系我们。",
        b2: "收集哪些信息以及如何使用信息？",
        b3: "收集的信息类别",
        b4: "为了向您提供我们的服务，我们需要您提供该服务所必需的个人信息。如果您不提供您的个人信息，我们可能无法向您提供我们相应的服务。",
        b5: "我们只会收集您选择的服务所必需的、特定的、明确及合法目的的信息，并且不会以与这些目的不相符的方式进一步处理相关信息 根据您选择的服务，我们可能收集以下信息中的一种或多种（无论其是否为个人信息）：",
        b6: "这些个人信息将会被如何使用",
        b7: "收集个人信息的目的在于向您提供产品和/或服务，并且保证我们遵照适用的相关法律。您同意我们基于本隐私政策规定的目的处理个人信息。",
        b8: "我们可能会将您的个人信息用于下列目的：",
        b9: "储存并维护与您相关的信息，用于我们运营业务或履行法律义务。",
        b10: "提供不需要与我们的服务器通信的本地服务。",
        b11: "联系方式",
        b12: "电子信箱：admin@luoyy.com"
    },
    zh_HK: {
        shareTitle: "Hello，推薦您一個MFA小程序，我也在使用哦~ 👍",
        Back: "返回",
        pp: "隱私策略",
        b1: "請花一些時間熟悉我們的隱私政策，如果您有任何問題，請聯繫我們。",
        b2: "收集哪些信息以及如何使用信息？",
        b3: "收集的信息類別",
        b4: "為了向您提供我們的服務，我們需要您提供該服務所必需的個人信息。如果您不提供您的個人信息，我們可能無法向您提供我們相應的服務。",
        b5: "我們只會收集您選擇的服務所必需的、特定的、明確及合法目的的信息，並且不會以與這些目的不相符的方式進一步處理相關信息根據您選擇的服務，我們可能收集以下信息中的一種或多種（無論其是否為個人信息）：",
        b6: "這些個人信息將會被如何使用",
        b7: "收集個人信息的目的在於向您提供產品和/或服務，並且保證我們遵照適用的相關法律。您同意我們基於本隱私政策規定的目的處理個人信息。",
        b8: "我們可能會將您的個人信息用於下列目的：",
        b9: "儲存並維護與您相關的信息，用於我們運營業務或履行法律義務。",
        b10: "提供不需要與我們的服務器通信的本地服務。",
        b11: "聯繫方式",
        b12: "電子信箱：admin@luoyy.com"
    },
    en: {
        shareTitle: "Hello, I recommend an MFA Mini Program, I am also using it~ 👍",
        Back: "Back",
        pp: "Privacy Policy",
        b1: "Please take some time to familiarize yourself with our privacy policy, if you have any questions, please contact us.",
        b2: "What information is collected and how is it used?",
        b3: "Type of information collected",
        b4: "In order to provide you with our service, we need you to provide the personal information necessary for the service. If you do not provide your personal information, we may not be able to provide you with our corresponding services.",
        b5: "We will only collect information that is necessary, specific, clear and legitimate for the service you choose, and will not further process relevant information in a way that is inconsistent with these purposes. According to the service you choose, we may Collect one or more of the following information (regardless of whether it is personal information):",
        b6: "How will this personal information be used",
        b7: "The purpose of collecting personal information is to provide you with products and/or services and to ensure that we comply with applicable laws. You agree that we process personal information for the purposes specified in this privacy policy.",
        b8: "We may use your personal information for the following purposes:",
        b9: "Store and maintain information related to you for our business operations or to fulfill legal obligations.",
        b10: "Provide local services that do not need to communicate with our server.",
        b11: "Contact information",
        b12: "E-mail: admin@luoyy.com"
    }
};