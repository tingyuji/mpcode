var o = require("@babel/runtime/helpers/typeof.js");

!function(e) {
    function r(o) {
        throw RangeError(F[o]);
    }
    function n(o, e) {
        for (var r = o.length, n = []; r--; ) n[r] = e(o[r]);
        return n;
    }
    function t(o, e) {
        var r = o.split("@"), t = "";
        return r.length > 1 && (t = r[0] + "@", o = r[1]), t + n((o = o.replace(E, ".")).split("."), e).join(".");
    }
    function f(o) {
        for (var e, r, n = [], t = 0, f = o.length; f > t; ) (e = o.charCodeAt(t++)) >= 55296 && 56319 >= e && f > t ? 56320 == (64512 & (r = o.charCodeAt(t++))) ? n.push(((1023 & e) << 10) + (1023 & r) + 65536) : (n.push(e), 
        t--) : n.push(e);
        return n;
    }
    function i(o) {
        return n(o, function(o) {
            var e = "";
            return o > 65535 && (o -= 65536, e += String.fromCharCode(o >>> 10 & 1023 | 55296), 
            o = 56320 | 1023 & o), e + String.fromCharCode(o);
        }).join("");
    }
    function u(o) {
        return 10 > o - 48 ? o - 22 : 26 > o - 65 ? o - 65 : 26 > o - 97 ? o - 97 : m;
    }
    function l(o, e) {
        return o + 22 + 75 * (26 > o) - ((0 != e) << 5);
    }
    function d(o, e, r) {
        var n = 0;
        for (o = r ? Math.floor(o / y) : o >> 1, o += Math.floor(o / e); o > O * b >> 1; n += m) o = Math.floor(o / O);
        return Math.floor(n + (O + 1) * o / (o + w));
    }
    function a(o) {
        var e, n, t, f, l, a, c, s, h, p, v = [], g = o.length, w = 0, y = j, S = M;
        for (0 > (n = o.lastIndexOf(A)) && (n = 0), t = 0; n > t; ++t) o.charCodeAt(t) >= 128 && r("not-basic"), 
        v.push(o.charCodeAt(t));
        for (f = n > 0 ? n + 1 : 0; g > f; ) {
            for (l = w, a = 1, c = m; f >= g && r("invalid-input"), ((s = u(o.charCodeAt(f++))) >= m || s > Math.floor((C - w) / a)) && r("overflow"), 
            w += s * a, !((h = S >= c ? x : c >= S + b ? b : c - S) > s); c += m) p = m - h, 
            a > Math.floor(C / p) && r("overflow"), a *= p;
            S = d(w - l, e = v.length + 1, 0 == l), Math.floor(w / e) > C - y && r("overflow"), 
            y += Math.floor(w / e), w %= e, v.splice(w++, 0, y);
        }
        return i(v);
    }
    function c(o) {
        var e, n, t, i, u, a, c, s, h, p, v, g, w, y, S, I = [];
        for (g = (o = f(o)).length, e = j, n = 0, u = M, a = 0; g > a; ++a) 128 > (v = o[a]) && I.push(String.fromCharCode(v));
        for (t = i = I.length, i && I.push(A); g > t; ) {
            for (c = C, a = 0; g > a; ++a) (v = o[a]) >= e && c > v && (c = v);
            for (w = t + 1, c - e > Math.floor((C - n) / w) && r("overflow"), n += (c - e) * w, 
            e = c, a = 0; g > a; ++a) if (e > (v = o[a]) && ++n > C && r("overflow"), v == e) {
                for (s = n, h = m; !((p = u >= h ? x : h >= u + b ? b : h - u) > s); h += m) S = s - p, 
                y = m - p, I.push(String.fromCharCode(l(p + S % y, 0))), s = Math.floor(S / y);
                I.push(String.fromCharCode(l(s, 0))), u = d(n, w, t == i), n = 0, ++t;
            }
            ++n, ++e;
        }
        return I.join("");
    }
    var s = "object" == ("undefined" == typeof exports ? "undefined" : o(exports)) && exports && !exports.nodeType && exports, h = "object" == ("undefined" == typeof module ? "undefined" : o(module)) && module && !module.nodeType && module, p = "object" == ("undefined" == typeof global ? "undefined" : o(global)) && global;
    (p.global === p || p.window === p || p.self === p) && (e = p);
    var v, g, C = 2147483647, m = 36, x = 1, b = 26, w = 38, y = 700, M = 72, j = 128, A = "-", S = /^xn--/, I = /[^\x20-\x7E]/, E = /[\x2E\u3002\uFF0E\uFF61]/g, F = {
        overflow: "Overflow: input needs wider integers to process",
        "not-basic": "Illegal input >= 0x80 (not a basic code point)",
        "invalid-input": "Invalid input"
    }, O = m - x;
    if (v = {
        version: "1.3.2",
        ucs2: {
            decode: f,
            encode: i
        },
        decode: a,
        encode: c,
        toASCII: function(o) {
            return t(o, function(o) {
                return I.test(o) ? "xn--" + c(o) : o;
            });
        },
        toUnicode: function(o) {
            return t(o, function(o) {
                return S.test(o) ? a(o.slice(4).toLowerCase()) : o;
            });
        }
    }, "function" == typeof define && "object" == o(define.amd) && define.amd) define("punycode", function() {
        return v;
    }); else if (s && h) if (module.exports == s) h.exports = v; else for (g in v) v.hasOwnProperty(g) && (s[g] = v[g]); else e.punycode = v;
}(void 0);