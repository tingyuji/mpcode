var t = require("@babel/runtime/helpers/classCallCheck.js"), s = require("@babel/runtime/helpers/createClass.js"), h = require("@babel/runtime/helpers/typeof.js"), e = require("08057D959C0A569C6E6315929737C3E5.js"), a = require("A291A1A09C0A569CC4F7C9A75C27C3E5.js"), r = /^([a-z0-9.+-]+:)/i, o = /:[0-9]*$/, n = /^(\/\/?(?!\/)[^\?\s]*)(\?[^\s]*)?$/, i = [ "{", "}", "|", "\\", "^", "`" ].concat([ "<", ">", '"', "`", " ", "\r", "\n", "    " ]), l = [ "'" ].concat(i), u = [ "%", "/", "?", ";", "#" ].concat(l), p = [ "/", "?", "#" ], c = /^[+a-z0-9A-Z_-]{0,63}$/, f = /^([+a-z0-9A-Z_-]{0,63})(.*)$/, m = {
    javascript: !0,
    "javascript:": !0
}, v = {
    javascript: !0,
    "javascript:": !0
}, g = {
    http: !0,
    https: !0,
    ftp: !0,
    gopher: !0,
    file: !0,
    "http:": !0,
    "https:": !0,
    "ftp:": !0,
    "gopher:": !0,
    "file:": !0
}, y = function(t) {
    return "string" == typeof t;
}, b = function(t) {
    return "object" == h(t) && null !== t;
}, q = function(t) {
    return null === t;
}, j = function(t) {
    return null == t;
}, x = function() {
    function i() {
        t(this, i), this.protocol = null, this.slashes = null, this.auth = null, this.host = null, 
        this.port = null, this.hostname = null, this.hash = null, this.search = null, this.query = null, 
        this.pathname = null, this.path = null, this.href = null;
    }
    return s(i, [ {
        key: "parse",
        value: function(t, s, o) {
            if (!y(t)) throw new TypeError("Parameter 'url' must be a string, not " + h(t));
            var i = t.indexOf("?"), b = -1 !== i && i < t.indexOf("#") ? "?" : "#", q = t.split(b);
            q[0] = q[0].replace(/\\/g, "/");
            var j = t = q.join(b);
            if (j = j.trim(), !o && 1 === t.split("#").length) {
                var x = n.exec(j);
                if (x) return this.path = j, this.href = j, this.pathname = x[1], x[2] ? (this.search = x[2], 
                this.query = s ? (0, e.parse)(this.search.substr(1)) : this.search.substr(1)) : s && (this.search = "", 
                this.query = {}), this;
            }
            var O = r.exec(j);
            if (O) {
                var d = (O = O[0]).toLowerCase();
                this.protocol = d, j = j.substr(O.length);
            }
            if (o || O || j.match(/^\/\/[^@\/]+@[^@\/]+/)) {
                var A = "//" === j.substr(0, 2);
                !A || O && v[O] || (j = j.substr(2), this.slashes = !0);
            }
            if (!v[O] && (A || O && !g[O])) {
                for (var k = -1, C = 0; C < p.length; C++) {
                    -1 !== (U = j.indexOf(p[C])) && (-1 === k || k > U) && (k = U);
                }
                var I, w;
                -1 !== (w = -1 === k ? j.lastIndexOf("@") : j.lastIndexOf("@", k)) && (I = j.slice(0, w), 
                j = j.slice(w + 1), this.auth = decodeURIComponent(I)), k = -1;
                for (C = 0; C < u.length; C++) {
                    var U;
                    -1 !== (U = j.indexOf(u[C])) && (-1 === k || k > U) && (k = U);
                }
                -1 === k && (k = j.length), this.host = j.slice(0, k), j = j.slice(k), this.parseHost(), 
                this.hostname = this.hostname || "";
                var R = "[" === this.hostname[0] && "]" === this.hostname[this.hostname.length - 1];
                if (!R) for (var $ = this.hostname.split(/\./), z = (C = 0, $.length); z > C; C++) {
                    var H = $[C];
                    if (H && !H.match(c)) {
                        for (var L = "", Z = 0, _ = H.length; _ > Z; Z++) L += H.charCodeAt(Z) > 127 ? "x" : H[Z];
                        if (!L.match(c)) {
                            var E = $.slice(0, C), P = $.slice(C + 1), S = H.match(f);
                            S && (E.push(S[1]), P.unshift(S[2])), P.length && (j = "/" + P.join(".") + j), this.hostname = E.join(".");
                            break;
                        }
                    }
                }
                this.hostname.length > 255 ? this.hostname = "" : this.hostname = this.hostname.toLowerCase(), 
                R || (this.hostname = (0, a.toASCII)(this.hostname));
                var T = this.port ? ":" + this.port : "", B = this.hostname || "";
                this.host = B + T, this.href += this.host, R && (this.hostname = this.hostname.substr(1, this.hostname.length - 2), 
                "/" !== j[0] && (j = "/" + j));
            }
            if (!m[d]) for (C = 0, z = l.length; z > C; C++) {
                var D = l[C];
                if (-1 !== j.indexOf(D)) {
                    var F = encodeURIComponent(D);
                    F === D && (F = escape(D)), j = j.split(D).join(F);
                }
            }
            var G = j.indexOf("#");
            -1 !== G && (this.hash = j.substr(G), j = j.slice(0, G));
            var J = j.indexOf("?");
            if (-1 !== J ? (this.search = j.substr(J), this.query = j.substr(J + 1), s && (this.query = (0, 
            e.parse)(this.query)), j = j.slice(0, J)) : s && (this.search = "", this.query = {}), 
            j && (this.pathname = j), g[d] && this.hostname && !this.pathname && (this.pathname = "/"), 
            this.pathname || this.search) {
                T = this.pathname || "";
                var K = this.search || "";
                this.path = T + K;
            }
            return this.href = this.format(), this;
        }
    }, {
        key: "format",
        value: function() {
            var t = this.auth || "";
            t && (t = (t = encodeURIComponent(t)).replace(/%3A/i, ":"), t += "@");
            var s = this.protocol || "", h = this.pathname || "", a = this.hash || "", r = !1, o = "";
            this.host ? r = t + this.host : this.hostname && (r = t + (-1 === this.hostname.indexOf(":") ? this.hostname : "[" + this.hostname + "]"), 
            this.port && (r += ":" + this.port)), this.query && b(this.query) && Object.keys(this.query).length && (o = (0, 
            e.stringify)(this.query));
            var n = this.search || o && "?" + o || "";
            return s && ":" !== s.substr(-1) && (s += ":"), this.slashes || (!s || g[s]) && !1 !== r ? (r = "//" + (r || ""), 
            h && "/" !== h.charAt(0) && (h = "/" + h)) : r || (r = ""), a && "#" !== a.charAt(0) && (a = "#" + a), 
            n && "?" !== n.charAt(0) && (n = "?" + n), s + r + (h = h.replace(/[?#]/g, function(t) {
                return encodeURIComponent(t);
            })) + (n = n.replace("#", "%23")) + a;
        }
    }, {
        key: "resolve",
        value: function(t) {
            return this.resolveObject(O(t, !1, !0)).format();
        }
    }, {
        key: "resolveObject",
        value: function(t) {
            if (y(t)) {
                var s = new i();
                s.parse(t, !1, !0), t = s;
            }
            for (var h = new i(), e = Object.keys(this), a = 0; a < e.length; a++) {
                var r = e[a];
                h[r] = this[r];
            }
            if (h.hash = t.hash, "" === t.href) return h.href = h.format(), h;
            if (t.slashes && !t.protocol) {
                for (var o = Object.keys(t), n = 0; n < o.length; n++) {
                    var l = o[n];
                    "protocol" !== l && (h[l] = t[l]);
                }
                return g[h.protocol] && h.hostname && !h.pathname && (h.path = h.pathname = "/"), 
                h.href = h.format(), h;
            }
            if (t.protocol && t.protocol !== h.protocol) {
                if (!g[t.protocol]) {
                    for (var u = Object.keys(t), p = 0; p < u.length; p++) {
                        var c = u[p];
                        h[c] = t[c];
                    }
                    return h.href = h.format(), h;
                }
                if (h.protocol = t.protocol, t.host || v[t.protocol]) h.pathname = t.pathname; else {
                    for (var f = (t.pathname || "").split("/"); f.length && !(t.host = f.shift()); ) ;
                    t.host || (t.host = ""), t.hostname || (t.hostname = ""), "" !== f[0] && f.unshift(""), 
                    f.length < 2 && f.unshift(""), h.pathname = f.join("/");
                }
                if (h.search = t.search, h.query = t.query, h.host = t.host || "", h.auth = t.auth, 
                h.hostname = t.hostname || t.host, h.port = t.port, h.pathname || h.search) {
                    var m = h.pathname || "", b = h.search || "";
                    h.path = m + b;
                }
                return h.slashes = h.slashes || t.slashes, h.href = h.format(), h;
            }
            var x = h.pathname && "/" === h.pathname.charAt(0), O = t.host || t.pathname && "/" === t.pathname.charAt(0), d = O || x || h.host && t.pathname, A = d;
            console.log(h), console.log(t);
            var k = h.pathname && h.pathname.split("/") || [], C = (f = t.pathname && t.pathname.split("/") || [], 
            h.protocol && !g[h.protocol]);
            if (C && (h.hostname = "", h.port = null, h.host && ("" === k[0] ? k[0] = h.host : k.unshift(h.host)), 
            h.host = "", t.protocol && (t.hostname = null, t.port = null, t.host && ("" === f[0] ? f[0] = t.host : f.unshift(t.host)), 
            t.host = null), d = d && ("" === f[0] || "" === k[0])), O) h.host = t.host || "" === t.host ? t.host : h.host, 
            h.hostname = t.hostname || "" === t.hostname ? t.hostname : h.hostname, h.search = t.search, 
            h.query = t.query, k = f; else if (f.length) k || (k = []), k.pop(), k = k.concat(f), 
            h.search = t.search, h.query = t.query; else if (!j(t.search)) {
                if (C) h.hostname = h.host = k.shift(), ($ = !!(h.host && h.host.indexOf("@") > 0) && h.host.split("@")) && (h.auth = $.shift(), 
                h.host = h.hostname = $.shift());
                return h.search = t.search, h.query = t.query, q(h.pathname) && q(h.search) || (h.path = (h.pathname ? h.pathname : "") + (h.search ? h.search : "")), 
                h.href = h.format(), h;
            }
            if (!k.length) return h.pathname = null, h.search ? h.path = "/" + h.search : h.path = null, 
            h.href = h.format(), h;
            for (var I = k.slice(-1)[0], w = (h.host || t.host || k.length > 1) && ("." === I || ".." === I) || "" === I, U = 0, R = k.length; R >= 0; R--) "." === (I = k[R]) ? k.splice(R, 1) : ".." === I ? (k.splice(R, 1), 
            U++) : U && (k.splice(R, 1), U--);
            if (!d && !A) for (;U--; U) k.unshift("..");
            !d || "" === k[0] || k[0] && "/" === k[0].charAt(0) || k.unshift(""), w && "/" !== k.join("/").substr(-1) && k.push("");
            var $, z = "" === k[0] || k[0] && "/" === k[0].charAt(0);
            C && (h.hostname = h.host = z ? "" : k.length ? k.shift() : "", ($ = !!(h.host && h.host.indexOf("@") > 0) && h.host.split("@")) && (h.auth = $.shift(), 
            h.host = h.hostname = $.shift()));
            return (d = d || h.host && k.length) && !z && k.unshift(""), k.length ? h.pathname = k.join("/") : (h.pathname = null, 
            h.path = null), q(h.pathname) && q(h.search) || (h.path = (h.pathname ? h.pathname : "") + (h.search ? h.search : "")), 
            h.auth = t.auth || h.auth, h.slashes = h.slashes || t.slashes, h.href = h.format(), 
            h;
        }
    }, {
        key: "parseHost",
        value: function() {
            var t = this.host, s = o.exec(t);
            s && (":" !== (s = s[0]) && (this.port = s.substr(1)), t = t.substr(0, t.length - s.length)), 
            t && (this.hostname = t);
        }
    } ]), i;
}();

function O(t, s, h) {
    if (t && b(t) && t instanceof x) return t;
    var e = new x();
    return e.parse(t, s, h), e;
}

exports.parse = O, exports.resolve = function(t, s) {
    return O(t, !1, !0).resolve(s);
}, exports.resolveObject = function(t, s) {
    return t ? O(t, !1, !0).resolveObject(s) : s;
}, exports.format = function(t) {
    return y(t) && (t = O(t)), t instanceof x ? t.format() : x.prototype.format.call(t);
}, exports.Url = x;