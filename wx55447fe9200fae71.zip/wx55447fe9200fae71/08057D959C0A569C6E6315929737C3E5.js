Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.encode = exports.decode = void 0;

var e = require("@babel/runtime/helpers/typeof.js"), r = exports.parse = function(e, r, n, t) {
    function o(e, r) {
        return Object.prototype.hasOwnProperty.call(e, r);
    }
    r = r || "&", n = n || "=";
    var s = {};
    if ("string" != typeof e || 0 === e.length) return s;
    var a = /\+/g;
    e = e.split(r);
    var u = 1e3;
    t && "number" == typeof t.maxKeys && (u = t.maxKeys);
    var c = e.length;
    u > 0 && c > u && (c = u);
    for (var p = 0; c > p; ++p) {
        var i, d, f, l, m = e[p].replace(a, "%20"), y = m.indexOf(n);
        y >= 0 ? (i = m.substr(0, y), d = m.substr(y + 1)) : (i = m, d = ""), f = decodeURIComponent(i), 
        l = decodeURIComponent(d), o(s, f) ? Array.isArray(s[f]) ? s[f].push(l) : s[f] = [ s[f], l ] : s[f] = l;
    }
    return s;
};

exports.decode = r;

var n = exports.stringify = function(r, n, t, o) {
    var s = function(r) {
        switch (e(r)) {
          case "string":
            return r;

          case "boolean":
            return r ? "true" : "false";

          case "number":
            return isFinite(r) ? r : "";

          default:
            return "";
        }
    };
    return n = n || "&", t = t || "=", null === r && (r = void 0), "object" == e(r) ? Object.keys(r).map(function(e) {
        var o = encodeURIComponent(s(e)) + t;
        return Array.isArray(r[e]) ? r[e].map(function(e) {
            return o + encodeURIComponent(s(e));
        }).join(n) : o + encodeURIComponent(s(r[e]));
    }).join(n) : o ? encodeURIComponent(s(o)) + t + encodeURIComponent(s(r)) : "";
};

exports.encode = n;