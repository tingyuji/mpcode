Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.read = function(t, o, a, r, e) {
    var M, h, p = 8 * e - r - 1, f = (1 << p) - 1, s = f >> 1, w = -7, i = a ? e - 1 : 0, n = a ? -1 : 1, u = t[o + i];
    for (i += n, M = u & (1 << -w) - 1, u >>= -w, w += p; w > 0; M = 256 * M + t[o + i], 
    i += n, w -= 8) ;
    for (h = M & (1 << -w) - 1, M >>= -w, w += r; w > 0; h = 256 * h + t[o + i], i += n, 
    w -= 8) ;
    if (0 === M) M = 1 - s; else {
        if (M === f) return h ? NaN : 1 / 0 * (u ? -1 : 1);
        h += Math.pow(2, r), M -= s;
    }
    return (u ? -1 : 1) * h * Math.pow(2, M - r);
}, exports.write = function(t, o, a, r, e, M) {
    var h, p, f, s = 8 * M - e - 1, w = (1 << s) - 1, i = w >> 1, n = 23 === e ? Math.pow(2, -24) - Math.pow(2, -77) : 0, u = r ? 0 : M - 1, N = r ? 1 : -1, l = o < 0 || 0 === o && 1 / o < 0 ? 1 : 0;
    for (o = Math.abs(o), isNaN(o) || o === 1 / 0 ? (p = isNaN(o) ? 1 : 0, h = w) : (h = Math.floor(Math.log(o) / Math.LN2), 
    o * (f = Math.pow(2, -h)) < 1 && (h--, f *= 2), (o += h + i >= 1 ? n / f : n * Math.pow(2, 1 - i)) * f >= 2 && (h++, 
    f /= 2), h + i >= w ? (p = 0, h = w) : h + i >= 1 ? (p = (o * f - 1) * Math.pow(2, e), 
    h += i) : (p = o * Math.pow(2, i - 1) * Math.pow(2, e), h = 0)); e >= 8; t[a + u] = 255 & p, 
    u += N, p /= 256, e -= 8) ;
    for (h = h << e | p, s += e; s > 0; t[a + u] = 255 & h, u += N, h /= 256, s -= 8) ;
    t[a + u - N] |= 128 * l;
};