Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

exports.default = {
    zh_CN: {
        "info-error": "身份信息获取失败",
        "s-e": "KEY获取失败",
        "p-e": "公开信息获取失败",
        "k-e": "关键数据保存失败",
        "l-s": "登录成功",
        "l-l": "已经登录",
        "n-sync": "未同步",
        "api-e": "请求API发生故障",
        se: "同步失败",
        de: "数据获取异常"
    },
    zh_HK: {
        "info-error": "身份信息獲取失敗",
        "s-e": "KEY獲取失敗",
        "p-e": "公開信息獲取失敗",
        "l-s": "登錄成功",
        "k-e": "關鍵數據保存失敗",
        "l-l": "已經登錄",
        "n-sync": "未同步",
        "api-e": "請求API發生故障",
        se: "同步失敗",
        de: "數據獲取異常"
    },
    en: {
        "info-error": "Identity information acquisition failed",
        "s-e": "KEY acquisition failed",
        "p-e": "Failed to obtain public information",
        "l-s": "Login successful",
        "k-e": "Failed to save key data",
        "l-l": "Already logged in",
        "n-sync": "Not synchronized",
        "api-e": "Request API failed",
        se: "Sync failed",
        de: "Data acquisition abnormal"
    }
};