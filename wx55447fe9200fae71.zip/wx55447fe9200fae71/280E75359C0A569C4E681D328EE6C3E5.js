Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.decrypt = function(e, t, r) {
    try {
        return JSON.parse(n.AES.decrypt(n.lib.CipherParams.create({
            ciphertext: n.enc.Base64.parse(e)
        }), n.enc.Base64.parse(t), {
            iv: n.enc.Base64.parse(r),
            mode: n.mode.CBC,
            padding: n.pad.Pkcs7
        }).toString(n.enc.Utf8));
    } catch (e) {}
    return !1;
}, exports.gen_sign = function(e, t) {
    return (0, n.HmacSHA1)(u(l(e)), n.enc.Utf8.parse(t)).toString(n.enc.Hex);
}, exports.getStorageSync = function(e) {
    try {
        e = (0, n.MD5)(e).toString(n.enc.Hex);
        var t = wx.getFileSystemManager();
        return JSON.parse(g(t.readFileSync("".concat(wx.env.USER_DATA_PATH, "/").concat(e), "binary"), e));
    } catch (e) {}
    return "";
}, exports.http_build_query = u, exports.importData = s, exports.isset = p, exports.ksort = l, 
exports.parseQrcode = function(e) {
    try {
        var t = (0, r.parse)(e, !0);
        if (!p(t)) return !1;
        if (!("protocol" in t) || !p(t.protocol)) return !1;
        if (!("query" in t) || !p(t.query)) return !1;
        if (!("hostname" in t) || !p(t.hostname)) return !1;
        switch (t.protocol.toLowerCase()) {
          case "otpauth:":
            return c(t);

          case "otpauth-migration:":
            return s(t);

          default:
            return !1;
        }
    } catch (e) {
        return !1;
    }
}, exports.parseURL = c, exports.safe_decrypt = g, exports.safe_encrypt = d, exports.setStorageSync = function(e, t) {
    try {
        e = (0, n.MD5)(e).toString(n.enc.Hex), wx.getFileSystemManager().writeFileSync("".concat(wx.env.USER_DATA_PATH, "/").concat(e), d(JSON.stringify(t), e), "binary");
    } catch (e) {}
}, exports.uid = function(e) {
    return (0, n.HmacSHA256)(e, (0, n.MD5)(e).toString(n.enc.Hex)).toString(n.enc.Hex);
};

var e, t = require("@babel/runtime/helpers/typeof.js"), r = require("0A1138559C0A569C6C7750524A47C3E5.js"), n = require("624A41A09C0A569C042C29A751B6C3E5.js"), a = (e = require("FDF35AB59C0A569C9B9532B28796C3E5.js")) && e.__esModule ? e : {
    default: e
}, o = require("36E03CA09C0A569C508654A7C676C3E5.js"), i = require("C7808C329C0A569CA1E6E435C907C3E5.js");

function c(e) {
    try {
        switch (e.hostname.toLowerCase()) {
          case "hotp":
          case "totp":
            break;

          default:
            return !1;
        }
        if (!("pathname" in e) || !p(e.pathname)) return !1;
        var t = e.pathname.substr(1).split(":"), r = Object.assign({
            secret: "",
            encoding: "base32",
            algorithm: "SHA1",
            counter: void 0,
            issuer: "",
            type: "totp",
            digits: 6,
            epoch: 0,
            step: 30,
            label: "",
            is_delete: !1
        }, e.query);
        return 0 !== r.secret.length && (r.type = e.hostname.toLowerCase(), r.counter = "totp" == r.type ? void 0 : parseInt(r.counter || 0, 10), 
        0 === r.label.length && (r.label = decodeURIComponent(1 == t.length ? t[0] : t[1])), 
        0 === r.issuer.length && t.length > 1 && (r.issuer = decodeURIComponent(t[0])), 
        "period" in r && (r.step = parseInt(r.period, 10), delete r.period), r.digits = parseInt(r.digits, 10), 
        r.step = parseInt(r.step, 10), r.epoch = parseInt(r.epoch, 10), [ r ]);
    } catch (e) {
        return !1;
    }
}

function s(e) {
    try {
        switch (e.hostname.toLowerCase()) {
          case "offline":
            break;

          default:
            return !1;
        }
        if (!("data" in e.query)) return !1;
        var t = i.MigrationPayload.decode(a.default.from(e.query.data, "base64"));
        if (p(t) && "otpParameters" in t && p(t.otpParameters)) return t.otpParameters.map(function(e) {
            var t = {
                OTP_TYPE_UNSPECIFIED: "totp",
                HOTP: "hotp",
                TOTP: "totp"
            }[i.MigrationPayload.OtpType[e.type]];
            return {
                secret: (0, o.encode)(e.secret).toString(),
                encoding: "base32",
                algorithm: {
                    ALGORITHM_UNSPECIFIED: "SHA1",
                    SHA1: "SHA1",
                    SHA256: "SHA256",
                    SHA512: "SHA512",
                    MD5: "MD5"
                }[i.MigrationPayload.Algorithm[e.algorithm]],
                counter: "totp" === t ? void 0 : e.counter,
                issuer: e.issuer,
                type: t,
                digits: {
                    DIGIT_COUNT_UNSPECIFIED: 6,
                    SIX: 6,
                    EIGHT: 8
                }[i.MigrationPayload.DigitCount[e.digits]],
                epoch: 0,
                step: 30,
                label: e.name,
                is_delete: !1
            };
        });
    } catch (e) {
        return console.error(e), !1;
    }
}

function u(e, r, n) {
    var a, o, i = function(e) {
        return e += "", encodeURIComponent(e).replace(/!/g, "%21").replace(/'/g, "%27").replace(/\(/g, "%28").replace(/\)/g, "%29").replace(/\*/g, "%2A").replace(/%20/g, "+");
    }, c = [], s = function e(r, n, a) {
        var o, c = [];
        if (!0 === n ? n = "1" : !1 === n && (n = "0"), null !== n) {
            if ("object" === t(n)) {
                for (o in n) null !== n[o] && c.push(e(r + "[" + o + "]", n[o], a));
                return c.join(a);
            }
            if ("function" != typeof n) return i(r) + "=" + i(n);
            throw new Error("There was an error processing for http_build_query().");
        }
        return "";
    };
    for (o in n || (n = "&"), e) {
        a = e[o], r && !isNaN(o) && (o = String(r) + o);
        var u = s(o, a, n);
        "" !== u && c.push(u);
    }
    return c.join(n);
}

function p(e) {
    return null != e;
}

function l(e) {
    var t = {};
    return Object.keys(e).sort().forEach(function(r) {
        t[r] = e[r];
    }), t;
}

function d(e, t) {
    try {
        var r = n.lib.WordArray.random(16), o = n.AES.encrypt(e, t, {
            iv: r,
            mode: n.mode.CBC,
            padding: n.pad.Pkcs7
        }).toString();
        r = r.toString(n.enc.Hex);
        var i = (0, n.HmacSHA256)(r + o, t).toString(n.enc.Hex);
        return new a.default(JSON.stringify({
            iv: r,
            value: o,
            mac: i
        })).toString("base64");
    } catch (e) {}
    return !1;
}

function g(e, t) {
    try {
        var r = JSON.parse(new a.default(e, "base64").toString());
        if (!("iv" in r && p(r.iv) && "value" in r && p(r.value) && "mac" in r && p(r.mac) && 16 === n.enc.Hex.parse(r.iv).sigBytes)) return !1;
        var o = n.lib.WordArray.random(16);
        return (0, n.HmacSHA256)(r.mac, o).toString() === (0, n.HmacSHA256)((0, n.HmacSHA256)(r.iv + r.value, t).toString(n.enc.Hex), o).toString() && n.AES.decrypt(r.value, t, {
            iv: n.enc.Hex.parse(r.iv),
            mode: n.mode.CBC,
            padding: n.pad.Pkcs7
        }).toString(n.enc.Utf8);
    } catch (e) {}
    return !1;
}