Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.crockford = exports.charmap = exports.base32hex = exports.Encoder = exports.Decoder = void 0, 
exports.decode = function(a, t) {
    return new p(t).finalize(a);
}, exports.encode = function(a, t) {
    return new o(t).finalize(a);
}, exports.rfc4648 = void 0;

var a, t = require("@babel/runtime/helpers/classCallCheck.js"), r = require("@babel/runtime/helpers/createClass.js"), e = (a = require("FDF35AB59C0A569C9B9532B28796C3E5.js")) && a.__esModule ? a : {
    default: a
};

var h = function(a, t) {
    return t || (t = {}), a.split("").forEach(function(a, r) {
        a in t || (t[a] = r);
    }), t;
};

exports.charmap = h;

var i = {
    alphabet: "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567",
    charmap: {
        0: 14,
        1: 8
    }
};

exports.rfc4648 = i, i.charmap = h(i.alphabet, i.charmap);

var s = {
    alphabet: "0123456789ABCDEFGHJKMNPQRSTVWXYZ",
    charmap: {
        O: 0,
        I: 1,
        L: 1
    }
};

exports.crockford = s, s.charmap = h(s.alphabet, s.charmap);

var c = {
    alphabet: "0123456789ABCDEFGHIJKLMNOPQRSTUV",
    charmap: {}
};

exports.base32hex = c, c.charmap = h(c.alphabet, c.charmap);

var p = function() {
    function a(r) {
        if (t(this, a), this.buf = [], this.shift = 8, this.carry = 0, r) {
            switch (r.type) {
              case "rfc4648":
                this.charmap = i.charmap;
                break;

              case "crockford":
                this.charmap = s.charmap;
                break;

              case "base32hex":
                this.charmap = c.charmap;
                break;

              default:
                throw new Error("invalid type");
            }
            r.charmap && (this.charmap = r.charmap);
        }
    }
    return r(a, [ {
        key: "write",
        value: function(a) {
            var t = this.charmap, r = this.buf, e = this.shift, h = this.carry;
            return a.toUpperCase().split("").forEach(function(a) {
                if ("=" != a) {
                    var i = 255 & t[a];
                    (e -= 5) > 0 ? h |= i << e : e < 0 ? (r.push(h | i >> -e), h = i << (e += 8) & 255) : (r.push(h | i), 
                    e = 8, h = 0);
                }
            }), this.shift = e, this.carry = h, this;
        }
    }, {
        key: "finalize",
        value: function(a) {
            return a && this.write(a), 8 !== this.shift && 0 !== this.carry && (this.shift = 8, 
            this.carry = 0), e.default.from(this.buf);
        }
    } ]), a;
}();

exports.Decoder = p, p.prototype.charmap = i.charmap;

var o = function() {
    function a(r) {
        if (t(this, a), this.buf = "", this.shift = 3, this.carry = 0, r) {
            switch (r.type) {
              case "rfc4648":
                this.alphabet = i.alphabet;
                break;

              case "crockford":
                this.alphabet = s.alphabet;
                break;

              case "base32hex":
                this.alphabet = c.alphabet;
                break;

              default:
                throw new Error("invalid type");
            }
            r.alphabet ? this.alphabet = r.alphabet : r.lc && (this.alphabet = this.alphabet.toLowerCase());
        }
    }
    return r(a, [ {
        key: "write",
        value: function(a) {
            var t, r, e, h = this.shift, i = this.carry;
            for (e = 0; e < a.length; e++) t = i | (r = a[e]) >> h, this.buf += this.alphabet[31 & t], 
            h > 5 && (t = r >> (h -= 5), this.buf += this.alphabet[31 & t]), i = r << (h = 5 - h), 
            h = 8 - h;
            return this.shift = h, this.carry = i, this;
        }
    }, {
        key: "finalize",
        value: function(a) {
            return a && this.write(a), 3 !== this.shift && (this.buf += this.alphabet[31 & this.carry], 
            this.shift = 3, this.carry = 0), e.default.from(this.buf);
        }
    } ]), a;
}();

exports.Encoder = o, o.prototype.alphabet = i.alphabet;