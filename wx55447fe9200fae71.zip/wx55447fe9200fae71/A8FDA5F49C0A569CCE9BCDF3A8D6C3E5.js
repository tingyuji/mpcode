Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports._counter = s, exports.digest = a, exports.counter = exports.hotp = i, 
exports.time = exports.totp = function(e) {
    if (!u((e = Object.create(e)).secret)) throw new Error("Speakeasy - totp - Missing secret");
    u(e.counter) || (e.counter = s(e));
    return i(e);
};

var e = function(e, t) {
    if (!t && e && e.__esModule) return e;
    if (null === e || "object" != typeof e && "function" != typeof e) return {
        default: e
    };
    var r = o(t);
    if (r && r.has(e)) return r.get(e);
    var n = {}, u = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for (var a in e) if ("default" !== a && Object.prototype.hasOwnProperty.call(e, a)) {
        var i = u ? Object.getOwnPropertyDescriptor(e, a) : null;
        i && (i.get || i.set) ? Object.defineProperty(n, a, i) : n[a] = e[a];
    }
    n.default = e, r && r.set(e, n);
    return n;
}(require("36E03CA09C0A569C508654A7C676C3E5.js")), t = n(require("624A41A09C0A569C042C29A751B6C3E5.js")), r = n(require("FDF35AB59C0A569C9B9532B28796C3E5.js"));

function n(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function o(e) {
    if ("function" != typeof WeakMap) return null;
    var t = new WeakMap(), r = new WeakMap();
    return (o = function(e) {
        return e ? r : t;
    })(e);
}

function u(e) {
    return null != e;
}

function a(n) {
    var o, u = n.secret, a = n.counter, i = n.encoding || "ascii", s = (n.algorithm || "sha1").toUpperCase();
    r.default.isBuffer(u) || (u = "base32" === i ? e.decode(u) : new r.default(u, i));
    var c = r.default.alloc(8), f = a;
    for (o = 0; o < 8; o++) c[7 - o] = 255 & f, f >>= 8;
    var p = t.default.algo.HMAC.create(t.default.algo[s], t.default.enc.Hex.parse(u.toString("hex")));
    return p.update(t.default.enc.Hex.parse(c.toString("hex"))), new r.default(p.finalize().toString(t.default.enc.Hex), "hex");
}

function i(e) {
    var t = e.secret, r = e.counter;
    if (!u(t)) throw new Error("Speakeasy - hotp - Missing secret");
    if (!u(r)) throw new Error("Speakeasy - hotp - Missing counter");
    var n = u(e.digits) ? e.digits : 6, o = e.digest || a(e), i = 15 & o[o.length - 1], s = (127 & o[i]) << 24 | (255 & o[i + 1]) << 16 | (255 & o[i + 2]) << 8 | 255 & o[i + 3];
    return (s = new Array(n + 1).join("0") + s.toString(10)).substr(-n);
}

function s(e) {
    var t = e.step || 30, r = u(e.time) ? 1e3 * e.time : Date.now(), n = u(e.epoch) ? 1e3 * e.epoch : 0;
    return Math.floor((r - n) / t / 1e3);
}