$gwx_XC_9=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_9 || [];
function gz$gwx_XC_9_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_9_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_9_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_9_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'html'])
Z([3,'body'])
Z([3,'div mdl-layout__container mdl-color--primary'])
Z([3,'div mdl-layout'])
Z([3,'header mdl-layout__header mdl-layout__header--scroll'])
Z([3,''])
Z([1,true])
Z([3,'backText'])
Z([a,[[6],[[7],[3,'lang']],[1,'Back']]])
Z([3,'content'])
Z([a,[[6],[[7],[3,'lang']],[1,'pp']]])
Z([3,'div mdl-layout__content mdl-color--grey-50'])
Z([3,'div mdl-grid mdl-grid--no-spacing'])
Z([3,'div mdl-cell mdl-cell--12-col'])
Z([3,'30'])
Z([3,'adError'])
Z([3,'adunit-b5807ee10980b7df'])
Z([3,'div mdl-grid ipx'])
Z(z[13])
Z([3,'div'])
Z([3,'p'])
Z([a,[[6],[[7],[3,'lang']],[1,'b1']]])
Z([3,'h3'])
Z([a,[[6],[[7],[3,'lang']],[1,'b2']]])
Z([3,'h4'])
Z([a,[[6],[[7],[3,'lang']],[1,'b3']]])
Z(z[20])
Z([a,[[6],[[7],[3,'lang']],[1,'b4']]])
Z(z[20])
Z([a,[[6],[[7],[3,'lang']],[1,'b5']]])
Z(z[24])
Z([a,[[6],[[7],[3,'lang']],[1,'b6']]])
Z(z[20])
Z([a,[[6],[[7],[3,'lang']],[1,'b7']]])
Z(z[20])
Z([a,[[6],[[7],[3,'lang']],[1,'b8']]])
Z([3,'ul'])
Z([3,'li'])
Z([a,[[6],[[7],[3,'lang']],[1,'b9']]])
Z(z[37])
Z([a,[[6],[[7],[3,'lang']],[1,'b10']]])
Z(z[22])
Z([a,[[6],[[7],[3,'lang']],[1,'b11']]])
Z(z[36])
Z(z[37])
Z([a,[[6],[[7],[3,'lang']],[1,'b12']]])
Z(z[20])
Z([3,'　'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_9_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_9_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_9=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_9=true;
var x=['./pages/setting/Privacypolicy/Privacypolicy.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_9_1()
var bQT=_n('view')
_rz(z,bQT,'class',0,e,s,gg)
var oRT=_n('view')
_rz(z,oRT,'class',1,e,s,gg)
var xST=_n('view')
_rz(z,xST,'class',2,e,s,gg)
var oTT=_n('view')
_rz(z,oTT,'class',3,e,s,gg)
var fUT=_n('view')
_rz(z,fUT,'class',4,e,s,gg)
var cVT=_mz(z,'header',['bgColor',5,'isBack',1],[],e,s,gg)
var hWT=_n('view')
_rz(z,hWT,'slot',7,e,s,gg)
var oXT=_oz(z,8,e,s,gg)
_(hWT,oXT)
_(cVT,hWT)
var cYT=_n('view')
_rz(z,cYT,'slot',9,e,s,gg)
var oZT=_oz(z,10,e,s,gg)
_(cYT,oZT)
_(cVT,cYT)
_(fUT,cVT)
_(oTT,fUT)
var l1T=_n('view')
_rz(z,l1T,'class',11,e,s,gg)
var a2T=_n('view')
_rz(z,a2T,'class',12,e,s,gg)
var t3T=_n('view')
_rz(z,t3T,'class',13,e,s,gg)
var e4T=_mz(z,'ad',['adIntervals',14,'binderror',1,'unitId',2],[],e,s,gg)
_(t3T,e4T)
_(a2T,t3T)
_(l1T,a2T)
var b5T=_n('view')
_rz(z,b5T,'class',17,e,s,gg)
var o6T=_n('view')
_rz(z,o6T,'class',18,e,s,gg)
var x7T=_n('view')
_rz(z,x7T,'class',19,e,s,gg)
var o8T=_n('view')
_rz(z,o8T,'class',20,e,s,gg)
var f9T=_oz(z,21,e,s,gg)
_(o8T,f9T)
_(x7T,o8T)
var c0T=_n('view')
_rz(z,c0T,'class',22,e,s,gg)
var hAU=_oz(z,23,e,s,gg)
_(c0T,hAU)
_(x7T,c0T)
var oBU=_n('view')
_rz(z,oBU,'class',24,e,s,gg)
var cCU=_oz(z,25,e,s,gg)
_(oBU,cCU)
_(x7T,oBU)
var oDU=_n('view')
_rz(z,oDU,'class',26,e,s,gg)
var lEU=_oz(z,27,e,s,gg)
_(oDU,lEU)
_(x7T,oDU)
var aFU=_n('view')
_rz(z,aFU,'class',28,e,s,gg)
var tGU=_oz(z,29,e,s,gg)
_(aFU,tGU)
_(x7T,aFU)
var eHU=_n('view')
_rz(z,eHU,'class',30,e,s,gg)
var bIU=_oz(z,31,e,s,gg)
_(eHU,bIU)
_(x7T,eHU)
var oJU=_n('view')
_rz(z,oJU,'class',32,e,s,gg)
var xKU=_oz(z,33,e,s,gg)
_(oJU,xKU)
_(x7T,oJU)
var oLU=_n('view')
_rz(z,oLU,'class',34,e,s,gg)
var fMU=_oz(z,35,e,s,gg)
_(oLU,fMU)
_(x7T,oLU)
var cNU=_n('view')
_rz(z,cNU,'class',36,e,s,gg)
var hOU=_n('view')
_rz(z,hOU,'class',37,e,s,gg)
var oPU=_oz(z,38,e,s,gg)
_(hOU,oPU)
_(cNU,hOU)
var cQU=_n('view')
_rz(z,cQU,'class',39,e,s,gg)
var oRU=_oz(z,40,e,s,gg)
_(cQU,oRU)
_(cNU,cQU)
_(x7T,cNU)
var lSU=_n('view')
_rz(z,lSU,'class',41,e,s,gg)
var aTU=_oz(z,42,e,s,gg)
_(lSU,aTU)
_(x7T,lSU)
var tUU=_n('view')
_rz(z,tUU,'class',43,e,s,gg)
var eVU=_n('view')
_rz(z,eVU,'class',44,e,s,gg)
var bWU=_oz(z,45,e,s,gg)
_(eVU,bWU)
_(tUU,eVU)
_(x7T,tUU)
var oXU=_n('view')
_rz(z,oXU,'class',46,e,s,gg)
var xYU=_oz(z,47,e,s,gg)
_(oXU,xYU)
_(x7T,oXU)
_(o6T,x7T)
_(b5T,o6T)
_(l1T,b5T)
_(oTT,l1T)
_(xST,oTT)
_(oRT,xST)
_(bQT,oRT)
_(r,bQT)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_9";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_9();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/setting/Privacypolicy/Privacypolicy.wxml'] = [$gwx_XC_9, './pages/setting/Privacypolicy/Privacypolicy.wxml'];else __wxAppCode__['pages/setting/Privacypolicy/Privacypolicy.wxml'] = $gwx_XC_9( './pages/setting/Privacypolicy/Privacypolicy.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['pages/setting/Privacypolicy/Privacypolicy.wxss'] = setCssToHead([".",[1],"p{word-break:break-all}\n@supports (bottom:constant(safe-area-inset-bottom)) or (bottom:env(safe-area-inset-bottom)){.",[1],"ipx{margin-bottom:env(safe-area-inset-bottom)}\n}",],undefined,{path:"./pages/setting/Privacypolicy/Privacypolicy.wxss"});
}