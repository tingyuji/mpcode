var a, e = (a = require("../../../696E53569C0A569C0F083B51B646C3E5.js")) && a.__esModule ? a : {
    default: a
};

var t = getApp();

Page({
    data: {
        lang: e.default[t.globalData.language]
    },
    adError: function() {},
    onShareAppMessage: function() {
        return {
            title: this.data.lang.shareTitle,
            path: "/pages/index/index",
            imageUrl: "/images/share.png"
        };
    },
    onAddToFavorites: function() {
        return {
            title: this.data.lang.shareTitle,
            imageUrl: "/images/share.png"
        };
    }
});