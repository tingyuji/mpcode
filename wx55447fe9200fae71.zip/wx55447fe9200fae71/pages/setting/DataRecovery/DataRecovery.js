var e, t = require("../../../@babel/runtime/helpers/regeneratorRuntime"), n = require("../../../@babel/runtime/helpers/asyncToGenerator"), a = (e = require("../../../0FF934929C0A569C699F5C953736C3E5.js")) && e.__esModule ? e : {
    default: e
};

var o = getApp();

Page({
    interstitialAd: null,
    videoAd: null,
    TEMP_TOKENS: o.Cloud.Config_get(),
    tmp_data: {},
    restoreId: void 0,
    deleteid: null,
    data: {
        CustomBar: o.globalData.CustomBar,
        DATA: {},
        DeleteModal: !0,
        deleteinfo: "",
        lang: a.default[o.globalData.language]
    },
    adError: function() {},
    onLoad: function() {
        var e = this;
        try {
            wx.createRewardedVideoAd && (this.videoAd = wx.createRewardedVideoAd({
                adUnitId: "adunit-d918d49907619d8f"
            }), this.videoAd.onError(function() {
                wx.showToast({
                    title: e.data.lang["r-e"],
                    icon: "none",
                    mask: !0,
                    duration: 1800,
                    fail: function(e) {
                        console.error(e);
                    }
                });
            }), this.videoAd.onClose(function(t) {
                if (t && t.isEnded) return e.dataRecovery();
                wx.showToast({
                    title: e.data.lang["ad-error"],
                    icon: "none",
                    mask: !0,
                    duration: 1800,
                    fail: function(e) {
                        console.error(e);
                    }
                });
            }));
        } catch (e) {
            console.error(e);
        }
        new Promise(function(t, n) {
            wx.createInterstitialAd && (e.interstitialAd = wx.createInterstitialAd({
                adUnitId: "adunit-545c2e6c9ac043ee"
            }), e.interstitialAd.onError(n), e.interstitialAd.onLoad(t));
        }).catch(function(e) {
            console.error(e);
        });
    },
    onShow: function() {
        var e = this;
        this.showCode(!0), new Promise(function(t, n) {
            var a = wx.getStorageSync("RES_AD_TIME") || 0, o = new Date(), r = o.getMonth() + 1, i = new Date([ o.getFullYear(), r < 10 ? "0" + r : r, o.getDate() ].join("-")).getTime();
            a < i ? e.interstitialAd ? e.interstitialAd.show().then(function() {
                wx.setStorageSync("RES_AD_TIME", i), t(!0);
            }).catch(n) : n(new Error(e.lang.ppl)) : t(!1);
        }).catch(function(e) {
            console.error(e);
        });
    },
    onHide: function() {},
    onUnload: function() {},
    showCode: function(e) {
        (e = e || !1) && (this.TEMP_TOKENS = o.Cloud.Config_get()), this.tmp_data = {};
        try {
            for (var t in this.TEMP_TOKENS) {
                var n = this.TEMP_TOKENS[t];
                !("is_delete" in n) || !0 !== n.is_delete || "force_delete" in n && !0 === n.force_delete || (this.tmp_data[t] = {
                    id: t,
                    issuer: n.issuer,
                    access: n.label.length > 0 && n.issuer.length > 0 ? "".concat(n.issuer, " (").concat(n.label, ")") : n.label,
                    access1: n.label.length > 0 && n.issuer.length > 0 ? "".concat(n.issuer, ":").concat(n.label) : n.label,
                    label: n.label
                });
            }
        } catch (e) {
            this.tmp_data = {};
        }
        this.setData({
            DATA: this.tmp_data
        });
    },
    dataRecovery: function() {
        var e = this;
        return n(t().mark(function n() {
            return t().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.prev = 0, t.next = 3, new Promise(function(t, n) {
                        wx.showLoading({
                            title: e.data.lang["task-ing"],
                            mask: !0,
                            success: t,
                            fail: function() {
                                n(new Error(e.data.lang.ce));
                            }
                        });
                    });

                  case 3:
                    return t.next = 5, o.Cloud.Config_restore(e.restoreId);

                  case 5:
                    e.restoreId = void 0, e.showCode(!0), wx.hideLoading({
                        fail: function(e) {
                            console.error(e);
                        }
                    }), wx.showToast({
                        title: e.data.lang["r-c"],
                        icon: "success",
                        mask: !0,
                        duration: 1200,
                        fail: function(e) {
                            console.error(e);
                        }
                    }), t.next = 15;
                    break;

                  case 11:
                    t.prev = 11, t.t0 = t.catch(0), wx.hideLoading({
                        fail: function(e) {
                            console.error(e);
                        }
                    }), wx.showToast({
                        title: t.t0.message || e.data.lang["r-e"],
                        icon: "none",
                        mask: !0,
                        duration: 1800,
                        fail: function(e) {
                            console.error(e);
                        }
                    });

                  case 15:
                  case "end":
                    return t.stop();
                }
            }, n, null, [ [ 0, 11 ] ]);
        }))();
    },
    onrestore: function(e) {
        var a = this;
        return n(t().mark(function n() {
            return t().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (a.restoreId = e.currentTarget.dataset.id, !a.videoAd) {
                        t.next = 27;
                        break;
                    }
                    return t.prev = 2, t.next = 5, new Promise(function(e, t) {
                        wx.showLoading({
                            title: a.data.lang["task-ing"],
                            mask: !0,
                            success: e,
                            fail: function() {
                                t(new Error(a.data.lang.ce));
                            }
                        });
                    });

                  case 5:
                    return t.next = 7, a.videoAd.show();

                  case 7:
                    wx.hideLoading({
                        fail: function(e) {
                            console.error(e);
                        }
                    }), t.next = 25;
                    break;

                  case 10:
                    return t.prev = 10, t.t0 = t.catch(2), t.prev = 12, t.next = 15, a.videoAd.load();

                  case 15:
                    return t.next = 17, a.videoAd.show();

                  case 17:
                    wx.hideLoading({
                        fail: function(e) {
                            console.error(e);
                        }
                    }), t.next = 25;
                    break;

                  case 20:
                    return t.prev = 20, t.t1 = t.catch(12), wx.hideLoading({
                        fail: function(e) {
                            console.error(e);
                        }
                    }), t.next = 25, a.datasync();

                  case 25:
                    t.next = 28;
                    break;

                  case 27:
                    wx.showToast({
                        title: a.data.lang.ppl,
                        icon: "none",
                        mask: !0,
                        duration: 1800,
                        fail: function(e) {
                            console.error(e);
                        }
                    });

                  case 28:
                  case "end":
                    return t.stop();
                }
            }, n, null, [ [ 2, 10 ], [ 12, 20 ] ]);
        }))();
    },
    deleteLongpress: function(e) {
        wx.vibrateShort({
            fail: function(e) {
                console.error(e);
            }
        }), this.deleteid = e.currentTarget.dataset.id, this.setData({
            MessageModal: !0,
            deleteinfo: e.currentTarget.dataset.access,
            DeleteModal: !1
        });
    },
    modalChange: function() {
        this.deleteid = null, this.setData({
            DeleteModal: !0
        });
    },
    modalDelete: function() {
        var e = this;
        return n(t().mark(function n() {
            return t().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.prev = 0, t.next = 3, new Promise(function(t, n) {
                        wx.showLoading({
                            title: e.data.lang["task-ing"],
                            mask: !0,
                            success: t,
                            fail: function() {
                                n(new Error(e.data.lang.ce));
                            }
                        });
                    });

                  case 3:
                    return t.next = 5, o.Cloud.Config_force_del(e.deleteid);

                  case 5:
                    e.deleteid = null, e.setData({
                        DeleteModal: !0
                    }), e.showCode(!0), wx.hideLoading({
                        fail: function(e) {
                            console.error(e);
                        }
                    }), t.next = 15;
                    break;

                  case 11:
                    t.prev = 11, t.t0 = t.catch(0), wx.hideLoading({
                        fail: function(e) {
                            console.error(e);
                        }
                    }), wx.showToast({
                        title: t.t0.message || e.data.lang.ce,
                        icon: "none",
                        mask: !0,
                        duration: 1800,
                        fail: function(e) {
                            console.error(e);
                        }
                    });

                  case 15:
                  case "end":
                    return t.stop();
                }
            }, n, null, [ [ 0, 11 ] ]);
        }))();
    },
    catchtouchmove: function() {
        return !1;
    },
    onShareAppMessage: function() {
        return {
            title: this.data.lang.shareTitle,
            path: "/pages/index/index",
            imageUrl: "/images/share.png"
        };
    },
    onAddToFavorites: function() {
        return {
            title: this.data.lang.shareTitle,
            imageUrl: "/images/share.png"
        };
    }
});