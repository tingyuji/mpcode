$gwx_XC_11=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_11 || [];
function gz$gwx_XC_11_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_11_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_11_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_11_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'div mdl-layout'])
Z([3,''])
Z([1,true])
Z([3,'div mdl-layout__content mdl-layout__content-flex'])
Z([3,'div mdl-grid'])
Z([[2,'!'],[[7],[3,'loginStatus']]])
Z([[7],[3,'loginStatus']])
Z(z[6])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_11_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_11_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_11=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_11=true;
var x=['./pages/setting/setting.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_11_1()
var o2B=_n('view')
_rz(z,o2B,'class',0,e,s,gg)
var c3B=_mz(z,'header',['bgColor',1,'isBack',1],[],e,s,gg)
_(o2B,c3B)
var o4B=_n('view')
_rz(z,o4B,'class',3,e,s,gg)
var a6B=_n('view')
_rz(z,a6B,'class',4,e,s,gg)
var t7B=_v()
_(a6B,t7B)
if(_oz(z,5,e,s,gg)){t7B.wxVkey=1
}
var e8B=_v()
_(a6B,e8B)
if(_oz(z,6,e,s,gg)){e8B.wxVkey=1
}
t7B.wxXCkey=1
e8B.wxXCkey=1
_(o4B,a6B)
var l5B=_v()
_(o4B,l5B)
if(_oz(z,7,e,s,gg)){l5B.wxVkey=1
}
l5B.wxXCkey=1
_(o2B,o4B)
_(r,o2B)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_11";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_11();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/setting/setting.wxml'] = [$gwx_XC_11, './pages/setting/setting.wxml'];else __wxAppCode__['pages/setting/setting.wxml'] = $gwx_XC_11( './pages/setting/setting.wxml' );
	;__wxRoute = "pages/setting/setting";__wxRouteBegin = true;__wxAppCurrentFile__="pages/setting/setting.js";define("pages/setting/setting.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var t,n=require("../../@babel/runtime/helpers/regeneratorRuntime"),a=require("../../@babel/runtime/helpers/asyncToGenerator"),o=require("../../9BF6B1F09C0A569CFD90D9F71EB6C3E5.js"),r=(t=require("../../612ED3879C0A569C0748BB80C316C3E5.js"))&&t.__esModule?t:{default:t};var i=getApp();Page({videoAd:null,data:{loginStatus:i.Cloud.loginStatus,synTime:i.Cloud.synTime,autoSyn:i.Cloud.autoSyn,AuthModal:!0,defaultAuth:!1,defaultAutoSync:!0,confirmAuth:!1,LogoutModal:!0,defaultLogoutClean:!1,automaticBackup:!1,PassModal:!0,errorMsg:"",tmp_value:"",lang:r.default[i.globalData.language]},adError:function(){},onLoad:function(){var t=this;try{wx.createRewardedVideoAd&&(this.videoAd=wx.createRewardedVideoAd({adUnitId:"adunit-5c31c630eb8775af"}),this.videoAd.onError((function(){wx.showToast({title:t.data.lang["sync-error"],icon:"none",mask:!0,duration:1800,fail:function(t){console.error(t)}})})),this.videoAd.onClose((function(n){if(n&&n.isEnded)return t.datasync();wx.showToast({title:t.data.lang["ad-error"],icon:"none",mask:!0,duration:1800,fail:function(t){console.error(t)}})})))}catch(t){console.error(t)}},onShow:function(){var t=this;return a(n().mark((function e(){return n().wrap((function(n){for(;;)switch(n.prev=n.next){case 0:return n.next=2,t.oninit();case 2:case"end":return n.stop()}}),e)})))()},oninit:function(){var t=this;return a(n().mark((function e(){return n().wrap((function(n){for(;;)switch(n.prev=n.next){case 0:return n.prev=0,n.next=3,i.Cloud.checkUser();case 3:n.next=8;break;case 5:n.prev=5,n.t0=n.catch(0),n.t0 instanceof o.ServerError&&wx.showToast({title:n.t0.message||t.data.lang["login-exp"],icon:"none",mask:!0,duration:1800,fail:function(t){console.error(t)}});case 8:return n.prev=8,t.setData({loginStatus:i.Cloud.loginStatus,synTime:i.Cloud.synTime,autoSyn:i.Cloud.autoSyn}),n.finish(8);case 11:case"end":return n.stop()}}),e,null,[[0,5,8,11]])})))()},datasync:function(){var t=this;return a(n().mark((function e(){return n().wrap((function(n){for(;;)switch(n.prev=n.next){case 0:return n.prev=0,n.next=3,new Promise((function(n,e){wx.showLoading({title:t.data.lang["data-check"],mask:!0,success:n,fail:function(){e(new Error(t.data.lang.ce))}})}));case 3:return n.next=5,i.Cloud.syn_data();case 5:wx.hideLoading({fail:function(t){console.error(t)}}),wx.showToast({title:t.data.lang["sync-ok"],icon:"success",mask:!0,duration:1200,fail:function(t){console.error(t)}}),n.next=13;break;case 9:n.prev=9,n.t0=n.catch(0),wx.hideLoading({fail:function(t){console.error(t)}}),wx.showToast({title:n.t0.message||t.data.lang["login-exp"],icon:"none",mask:!0,duration:1800,fail:function(t){console.error(t)}});case 13:return n.prev=13,t.setData({loginStatus:i.Cloud.loginStatus,synTime:i.Cloud.synTime,autoSyn:i.Cloud.autoSyn}),n.finish(13);case 16:case"end":return n.stop()}}),e,null,[[0,9,13,16]])})))()},onsyndata:function(){var t=this;return a(n().mark((function e(){return n().wrap((function(n){for(;;)switch(n.prev=n.next){case 0:if(!t.videoAd){n.next=26;break}return n.prev=1,n.next=4,new Promise((function(n,e){wx.showLoading({title:t.data.lang["task-ing"],mask:!0,success:n,fail:function(){e(new Error(t.data.lang.ce))}})}));case 4:return n.next=6,t.videoAd.show();case 6:wx.hideLoading({fail:function(t){console.error(t)}}),n.next=24;break;case 9:return n.prev=9,n.t0=n.catch(1),n.prev=11,n.next=14,t.videoAd.load();case 14:return n.next=16,t.videoAd.show();case 16:wx.hideLoading({fail:function(t){console.error(t)}}),n.next=24;break;case 19:return n.prev=19,n.t1=n.catch(11),wx.hideLoading({fail:function(t){console.error(t)}}),n.next=24,t.datasync();case 24:n.next=27;break;case 26:wx.showToast({title:t.data.lang.pgload,icon:"none",mask:!0,duration:1800,fail:function(t){console.error(t)}});case 27:case"end":return n.stop()}}),e,null,[[1,9],[11,19]])})))()},automaticBackup:function(t){var o=this;return a(n().mark((function a(){var r;return n().wrap((function(n){for(;;)switch(n.prev=n.next){case 0:if(r=!!t.detail.value,i.Cloud.setautoSyn(r)){n.next=3;break}return n.abrupt("return",wx.showToast({title:e.message||o.data.lang.ce,icon:"none",mask:!0,duration:1800,fail:function(t){console.error(t)}}));case 3:if(r){n.next=5;break}return n.abrupt("return",!0);case 5:return n.prev=5,n.next=8,new Promise((function(t,n){wx.showLoading({title:o.data.lang["task-ing"],mask:!0,success:t,fail:function(){n(new Error(o.data.lang.ce))}})}));case 8:return n.next=10,i.Cloud.auth();case 10:wx.hideLoading({fail:function(t){console.error(t)}}),n.next=18;break;case 13:n.prev=13,n.t0=n.catch(5),i.Cloud.setautoSyn(!1),wx.hideLoading({fail:function(t){console.error(t)}}),wx.showToast({title:n.t0.message||o.data.lang["login-exp"],icon:"none",mask:!0,duration:1800,fail:function(t){console.error(t)}});case 18:o.setData({loginStatus:i.Cloud.loginStatus,synTime:i.Cloud.synTime,autoSyn:i.Cloud.autoSyn});case 19:case"end":return n.stop()}}),a,null,[[5,13]])})))()},authLogin:function(){var t=this;return a(n().mark((function e(){return n().wrap((function(n){for(;;)switch(n.prev=n.next){case 0:if(t.data.defaultAuth){n.next=3;break}return t.setData({confirmAuth:!0}),n.abrupt("return",wx.showToast({title:t.data.lang["auth-confirm"],icon:"none",mask:!0,duration:800,fail:function(t){console.error(t)}}));case 3:return n.prev=3,n.next=6,new Promise((function(n,e){wx.showLoading({title:t.data.lang["login-ing"],mask:!0,success:n,fail:function(){e(new Error(t.data.lang.ce))}})}));case 6:return n.next=8,i.Cloud.login();case 8:if(wx.hideLoading({fail:function(t){console.error(t)}}),!t.data.defaultAutoSync){n.next=17;break}return i.Cloud.setautoSyn(!0),n.next=13,new Promise((function(n,e){wx.showLoading({title:t.data.lang["data-check"],mask:!0,success:n,fail:function(){e(new Error(t.data.lang.ce))}})}));case 13:return n.next=15,i.Cloud.syn_data();case 15:wx.hideLoading({fail:function(t){console.error(t)}}),wx.showToast({title:t.data.lang["sync-ok"],icon:"success",mask:!0,duration:1200,fail:function(t){console.error(t)}});case 17:t.AuthTap(),n.next=24;break;case 20:n.prev=20,n.t0=n.catch(3),wx.hideLoading({fail:function(t){console.error(t)}}),wx.showToast({title:n.t0.message||t.data.lang["login-error"],icon:"none",mask:!0,duration:1800,fail:function(t){console.error(t)}});case 24:return n.prev=24,t.setData({loginStatus:i.Cloud.loginStatus,synTime:i.Cloud.synTime,autoSyn:i.Cloud.autoSyn}),n.finish(24);case 27:case"end":return n.stop()}}),e,null,[[3,20,24,27]])})))()},showLogout:function(){this.setData({LogoutModal:!1,defaultLogoutClean:!1})},LogoutTap:function(){this.setData({LogoutModal:!0})},logout:function(){return i.Cloud.logout(this.data.defaultLogoutClean),this.setData({LogoutModal:!0,defaultLogoutClean:!1}),wx.reLaunch({url:"/pages/index/index",fail:function(t){console.error(t)}})},AuthTap:function(){this.setData({AuthModal:!0,confirmAuth:!1})},checkboxChange:function(t){this.setData({defaultAuth:t.detail.value.includes("auth"),defaultAutoSync:t.detail.value.includes("auto-sync")})},logoutCheckboxChange:function(t){this.setData({defaultLogoutClean:t.detail.value.includes("logout-clean")})},ShowAuth:function(){this.setData({AuthModal:!1,defaultAuth:!1,defaultAutoSync:!0,confirmAuth:!1})},shakeHorizontal:function(){this.setData({confirmAuth:!1})},catchtouchmove:function(){return!1},onShareAppMessage:function(){return{title:this.data.lang.shareTitle,path:"/pages/index/index",imageUrl:"/images/share.png"}},onAddToFavorites:function(){return{title:this.data.lang.shareTitle,imageUrl:"/images/share.png"}}});
},{isPage:true,isComponent:true,currentFile:'pages/setting/setting.js'});require("pages/setting/setting.js");