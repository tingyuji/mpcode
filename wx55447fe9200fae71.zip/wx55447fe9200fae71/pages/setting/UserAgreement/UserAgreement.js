var a, e = (a = require("../../../4E0C07749C0A569C286A6F735756C3E5.js")) && a.__esModule ? a : {
    default: a
};

var t = getApp();

Page({
    data: {
        lang: e.default[t.globalData.language]
    },
    adError: function() {},
    onShareAppMessage: function() {
        return {
            title: this.data.lang.shareTitle,
            path: "/pages/index/index",
            imageUrl: "/images/share.png"
        };
    },
    onAddToFavorites: function() {
        return {
            title: this.data.lang.shareTitle,
            imageUrl: "/images/share.png"
        };
    }
});