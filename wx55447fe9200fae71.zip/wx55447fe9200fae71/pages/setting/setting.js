var t, n = require("../../@babel/runtime/helpers/regeneratorRuntime"), a = require("../../@babel/runtime/helpers/asyncToGenerator"), o = require("../../9BF6B1F09C0A569CFD90D9F71EB6C3E5.js"), r = (t = require("../../612ED3879C0A569C0748BB80C316C3E5.js")) && t.__esModule ? t : {
    default: t
};

var i = getApp();

Page({
    videoAd: null,
    data: {
        loginStatus: i.Cloud.loginStatus,
        synTime: i.Cloud.synTime,
        autoSyn: i.Cloud.autoSyn,
        AuthModal: !0,
        defaultAuth: !1,
        defaultAutoSync: !0,
        confirmAuth: !1,
        LogoutModal: !0,
        defaultLogoutClean: !1,
        automaticBackup: !1,
        PassModal: !0,
        errorMsg: "",
        tmp_value: "",
        lang: r.default[i.globalData.language]
    },
    adError: function() {},
    onLoad: function() {
        var t = this;
        try {
            wx.createRewardedVideoAd && (this.videoAd = wx.createRewardedVideoAd({
                adUnitId: "adunit-5c31c630eb8775af"
            }), this.videoAd.onError(function() {
                wx.showToast({
                    title: t.data.lang["sync-error"],
                    icon: "none",
                    mask: !0,
                    duration: 1800,
                    fail: function(t) {
                        console.error(t);
                    }
                });
            }), this.videoAd.onClose(function(n) {
                if (n && n.isEnded) return t.datasync();
                wx.showToast({
                    title: t.data.lang["ad-error"],
                    icon: "none",
                    mask: !0,
                    duration: 1800,
                    fail: function(t) {
                        console.error(t);
                    }
                });
            }));
        } catch (t) {
            console.error(t);
        }
    },
    onShow: function() {
        var t = this;
        return a(n().mark(function e() {
            return n().wrap(function(n) {
                for (;;) switch (n.prev = n.next) {
                  case 0:
                    return n.next = 2, t.oninit();

                  case 2:
                  case "end":
                    return n.stop();
                }
            }, e);
        }))();
    },
    oninit: function() {
        var t = this;
        return a(n().mark(function e() {
            return n().wrap(function(n) {
                for (;;) switch (n.prev = n.next) {
                  case 0:
                    return n.prev = 0, n.next = 3, i.Cloud.checkUser();

                  case 3:
                    n.next = 8;
                    break;

                  case 5:
                    n.prev = 5, n.t0 = n.catch(0), n.t0 instanceof o.ServerError && wx.showToast({
                        title: n.t0.message || t.data.lang["login-exp"],
                        icon: "none",
                        mask: !0,
                        duration: 1800,
                        fail: function(t) {
                            console.error(t);
                        }
                    });

                  case 8:
                    return n.prev = 8, t.setData({
                        loginStatus: i.Cloud.loginStatus,
                        synTime: i.Cloud.synTime,
                        autoSyn: i.Cloud.autoSyn
                    }), n.finish(8);

                  case 11:
                  case "end":
                    return n.stop();
                }
            }, e, null, [ [ 0, 5, 8, 11 ] ]);
        }))();
    },
    datasync: function() {
        var t = this;
        return a(n().mark(function e() {
            return n().wrap(function(n) {
                for (;;) switch (n.prev = n.next) {
                  case 0:
                    return n.prev = 0, n.next = 3, new Promise(function(n, e) {
                        wx.showLoading({
                            title: t.data.lang["data-check"],
                            mask: !0,
                            success: n,
                            fail: function() {
                                e(new Error(t.data.lang.ce));
                            }
                        });
                    });

                  case 3:
                    return n.next = 5, i.Cloud.syn_data();

                  case 5:
                    wx.hideLoading({
                        fail: function(t) {
                            console.error(t);
                        }
                    }), wx.showToast({
                        title: t.data.lang["sync-ok"],
                        icon: "success",
                        mask: !0,
                        duration: 1200,
                        fail: function(t) {
                            console.error(t);
                        }
                    }), n.next = 13;
                    break;

                  case 9:
                    n.prev = 9, n.t0 = n.catch(0), wx.hideLoading({
                        fail: function(t) {
                            console.error(t);
                        }
                    }), wx.showToast({
                        title: n.t0.message || t.data.lang["login-exp"],
                        icon: "none",
                        mask: !0,
                        duration: 1800,
                        fail: function(t) {
                            console.error(t);
                        }
                    });

                  case 13:
                    return n.prev = 13, t.setData({
                        loginStatus: i.Cloud.loginStatus,
                        synTime: i.Cloud.synTime,
                        autoSyn: i.Cloud.autoSyn
                    }), n.finish(13);

                  case 16:
                  case "end":
                    return n.stop();
                }
            }, e, null, [ [ 0, 9, 13, 16 ] ]);
        }))();
    },
    onsyndata: function() {
        var t = this;
        return a(n().mark(function e() {
            return n().wrap(function(n) {
                for (;;) switch (n.prev = n.next) {
                  case 0:
                    if (!t.videoAd) {
                        n.next = 26;
                        break;
                    }
                    return n.prev = 1, n.next = 4, new Promise(function(n, e) {
                        wx.showLoading({
                            title: t.data.lang["task-ing"],
                            mask: !0,
                            success: n,
                            fail: function() {
                                e(new Error(t.data.lang.ce));
                            }
                        });
                    });

                  case 4:
                    return n.next = 6, t.videoAd.show();

                  case 6:
                    wx.hideLoading({
                        fail: function(t) {
                            console.error(t);
                        }
                    }), n.next = 24;
                    break;

                  case 9:
                    return n.prev = 9, n.t0 = n.catch(1), n.prev = 11, n.next = 14, t.videoAd.load();

                  case 14:
                    return n.next = 16, t.videoAd.show();

                  case 16:
                    wx.hideLoading({
                        fail: function(t) {
                            console.error(t);
                        }
                    }), n.next = 24;
                    break;

                  case 19:
                    return n.prev = 19, n.t1 = n.catch(11), wx.hideLoading({
                        fail: function(t) {
                            console.error(t);
                        }
                    }), n.next = 24, t.datasync();

                  case 24:
                    n.next = 27;
                    break;

                  case 26:
                    wx.showToast({
                        title: t.data.lang.pgload,
                        icon: "none",
                        mask: !0,
                        duration: 1800,
                        fail: function(t) {
                            console.error(t);
                        }
                    });

                  case 27:
                  case "end":
                    return n.stop();
                }
            }, e, null, [ [ 1, 9 ], [ 11, 19 ] ]);
        }))();
    },
    automaticBackup: function(t) {
        var o = this;
        return a(n().mark(function a() {
            var r;
            return n().wrap(function(n) {
                for (;;) switch (n.prev = n.next) {
                  case 0:
                    if (r = !!t.detail.value, i.Cloud.setautoSyn(r)) {
                        n.next = 3;
                        break;
                    }
                    return n.abrupt("return", wx.showToast({
                        title: e.message || o.data.lang.ce,
                        icon: "none",
                        mask: !0,
                        duration: 1800,
                        fail: function(t) {
                            console.error(t);
                        }
                    }));

                  case 3:
                    if (r) {
                        n.next = 5;
                        break;
                    }
                    return n.abrupt("return", !0);

                  case 5:
                    return n.prev = 5, n.next = 8, new Promise(function(t, n) {
                        wx.showLoading({
                            title: o.data.lang["task-ing"],
                            mask: !0,
                            success: t,
                            fail: function() {
                                n(new Error(o.data.lang.ce));
                            }
                        });
                    });

                  case 8:
                    return n.next = 10, i.Cloud.auth();

                  case 10:
                    wx.hideLoading({
                        fail: function(t) {
                            console.error(t);
                        }
                    }), n.next = 18;
                    break;

                  case 13:
                    n.prev = 13, n.t0 = n.catch(5), i.Cloud.setautoSyn(!1), wx.hideLoading({
                        fail: function(t) {
                            console.error(t);
                        }
                    }), wx.showToast({
                        title: n.t0.message || o.data.lang["login-exp"],
                        icon: "none",
                        mask: !0,
                        duration: 1800,
                        fail: function(t) {
                            console.error(t);
                        }
                    });

                  case 18:
                    o.setData({
                        loginStatus: i.Cloud.loginStatus,
                        synTime: i.Cloud.synTime,
                        autoSyn: i.Cloud.autoSyn
                    });

                  case 19:
                  case "end":
                    return n.stop();
                }
            }, a, null, [ [ 5, 13 ] ]);
        }))();
    },
    authLogin: function() {
        var t = this;
        return a(n().mark(function e() {
            return n().wrap(function(n) {
                for (;;) switch (n.prev = n.next) {
                  case 0:
                    if (t.data.defaultAuth) {
                        n.next = 3;
                        break;
                    }
                    return t.setData({
                        confirmAuth: !0
                    }), n.abrupt("return", wx.showToast({
                        title: t.data.lang["auth-confirm"],
                        icon: "none",
                        mask: !0,
                        duration: 800,
                        fail: function(t) {
                            console.error(t);
                        }
                    }));

                  case 3:
                    return n.prev = 3, n.next = 6, new Promise(function(n, e) {
                        wx.showLoading({
                            title: t.data.lang["login-ing"],
                            mask: !0,
                            success: n,
                            fail: function() {
                                e(new Error(t.data.lang.ce));
                            }
                        });
                    });

                  case 6:
                    return n.next = 8, i.Cloud.login();

                  case 8:
                    if (wx.hideLoading({
                        fail: function(t) {
                            console.error(t);
                        }
                    }), !t.data.defaultAutoSync) {
                        n.next = 17;
                        break;
                    }
                    return i.Cloud.setautoSyn(!0), n.next = 13, new Promise(function(n, e) {
                        wx.showLoading({
                            title: t.data.lang["data-check"],
                            mask: !0,
                            success: n,
                            fail: function() {
                                e(new Error(t.data.lang.ce));
                            }
                        });
                    });

                  case 13:
                    return n.next = 15, i.Cloud.syn_data();

                  case 15:
                    wx.hideLoading({
                        fail: function(t) {
                            console.error(t);
                        }
                    }), wx.showToast({
                        title: t.data.lang["sync-ok"],
                        icon: "success",
                        mask: !0,
                        duration: 1200,
                        fail: function(t) {
                            console.error(t);
                        }
                    });

                  case 17:
                    t.AuthTap(), n.next = 24;
                    break;

                  case 20:
                    n.prev = 20, n.t0 = n.catch(3), wx.hideLoading({
                        fail: function(t) {
                            console.error(t);
                        }
                    }), wx.showToast({
                        title: n.t0.message || t.data.lang["login-error"],
                        icon: "none",
                        mask: !0,
                        duration: 1800,
                        fail: function(t) {
                            console.error(t);
                        }
                    });

                  case 24:
                    return n.prev = 24, t.setData({
                        loginStatus: i.Cloud.loginStatus,
                        synTime: i.Cloud.synTime,
                        autoSyn: i.Cloud.autoSyn
                    }), n.finish(24);

                  case 27:
                  case "end":
                    return n.stop();
                }
            }, e, null, [ [ 3, 20, 24, 27 ] ]);
        }))();
    },
    showLogout: function() {
        this.setData({
            LogoutModal: !1,
            defaultLogoutClean: !1
        });
    },
    LogoutTap: function() {
        this.setData({
            LogoutModal: !0
        });
    },
    logout: function() {
        return i.Cloud.logout(this.data.defaultLogoutClean), this.setData({
            LogoutModal: !0,
            defaultLogoutClean: !1
        }), wx.reLaunch({
            url: "/pages/index/index",
            fail: function(t) {
                console.error(t);
            }
        });
    },
    AuthTap: function() {
        this.setData({
            AuthModal: !0,
            confirmAuth: !1
        });
    },
    checkboxChange: function(t) {
        this.setData({
            defaultAuth: t.detail.value.includes("auth"),
            defaultAutoSync: t.detail.value.includes("auto-sync")
        });
    },
    logoutCheckboxChange: function(t) {
        this.setData({
            defaultLogoutClean: t.detail.value.includes("logout-clean")
        });
    },
    ShowAuth: function() {
        this.setData({
            AuthModal: !1,
            defaultAuth: !1,
            defaultAutoSync: !0,
            confirmAuth: !1
        });
    },
    shakeHorizontal: function() {
        this.setData({
            confirmAuth: !1
        });
    },
    catchtouchmove: function() {
        return !1;
    },
    onShareAppMessage: function() {
        return {
            title: this.data.lang.shareTitle,
            path: "/pages/index/index",
            imageUrl: "/images/share.png"
        };
    },
    onAddToFavorites: function() {
        return {
            title: this.data.lang.shareTitle,
            imageUrl: "/images/share.png"
        };
    }
});