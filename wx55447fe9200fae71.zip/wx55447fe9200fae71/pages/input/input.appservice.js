$gwx_XC_6=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_6 || [];
function gz$gwx_XC_6_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_6_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_6_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_6_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'closeSelect'])
Z([3,'html'])
Z([3,'div mdl-layout'])
Z([3,''])
Z([1,true])
Z([3,'formSubmit'])
Z([3,'form'])
Z([3,'change'])
Z([3,'select'])
Z([3,'id'])
Z([[7],[3,'options']])
Z([3,'name'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_6_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_6_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_6=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_6=true;
var x=['./pages/input/input.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_6_1()
var oNB=_mz(z,'view',['catchtap',0,'class',1],[],e,s,gg)
var cOB=_n('view')
_rz(z,cOB,'class',2,e,s,gg)
var oPB=_mz(z,'header',['bgColor',3,'isBack',1],[],e,s,gg)
_(cOB,oPB)
var lQB=_mz(z,'form',['bindsubmit',5,'class',1],[],e,s,gg)
var aRB=_mz(z,'select',['bind:change',7,'id',1,'key',2,'options',3,'text',4],[],e,s,gg)
_(lQB,aRB)
_(cOB,lQB)
_(oNB,cOB)
_(r,oNB)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_6";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_6();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/input/input.wxml'] = [$gwx_XC_6, './pages/input/input.wxml'];else __wxAppCode__['pages/input/input.wxml'] = $gwx_XC_6( './pages/input/input.wxml' );
	;__wxRoute = "pages/input/input";__wxRouteBegin = true;__wxAppCurrentFile__="pages/input/input.js";define("pages/input/input.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var e,t=require("../../@babel/runtime/helpers/regeneratorRuntime"),a=require("../../@babel/runtime/helpers/asyncToGenerator"),r=require("../../@babel/runtime/helpers/defineProperty"),n=require("../../280E75359C0A569C4E681D328EE6C3E5.js"),i=(e=require("../../14764A749C0A569C72102273F606C3E5.js"))&&e.__esModule?e:{default:e};var s=getApp();Page({uri:{},data:{usernamefocus:!1,usernameinput:!1,tokenerror:!1,tokenfocus:!1,tokeninput:!1,errorMsg:i.default[s.globalData.language].ks,index:0,lang:i.default[s.globalData.language],options:[{id:0,name:i.default[s.globalData.language].bat},{id:1,name:i.default[s.globalData.language].batc}]},adError:function(){},change:function(e){this.setData({index:e.detail.id})},closeSelect:function(){this.selectComponent("#select").close()},onLoad:function(e){this.uri=e},Inputfocus:function(e){this.setData(r({},e.target.id+"focus",!0))},Inputblur:function(e){this.setData(r({},e.target.id+"focus",!1))},Inputinput:function(e){var t=e.target.id,a=e.detail.value;if("token"==t){var n=/^[A-Za-z0-7\-\s]+$/.test(a);this.setData(r({errorMsg:a.length>0&&!n?this.data.lang.ke:""},t+"error",a.length>0&&!n))}this.setData(r({},t+"input",a.length>0))},formSubmit:function(e){var r=this;return a(t().mark((function a(){var i,o;return t().wrap((function(t){for(;;)switch(t.prev=t.next){case 0:if(i=e.detail.value,!r.data.tokenerror){t.next=3;break}return t.abrupt("return",!1);case 3:if(!((o=i.token.replace(/\s/gi,"")).length<16)){t.next=6;break}return t.abrupt("return",r.setData({tokeninput:!0,errorMsg:r.data.lang.ks,tokenerror:!0}));case 6:return t.prev=6,t.next=9,new Promise((function(e,t){wx.showLoading({title:r.data.lang["task-ing"],mask:!0,success:e,fail:function(){t(new Error(r.data.lang.ce))}})}));case 9:return t.next=11,s.Cloud.Config_insert({secret:o,counter:i.type>>0==0?void 0:0,encoding:"base32",algorithm:"SHA1",issuer:"",digits:6,epoch:0,step:30,type:i.type>>0==0?"totp":"hotp",label:i.username});case 11:wx.hideLoading({fail:function(e){console.error(e)}}),t.next=17;break;case 14:t.prev=14,t.t0=t.catch(6),wx.hideLoading({fail:function(e){console.error(e)}});case 17:return t.abrupt("return",wx.reLaunch({url:"/pages/index/index?"+(0,n.http_build_query)(r.uri),fail:function(e){console.error(e)}}));case 18:case"end":return t.stop()}}),a,null,[[6,14]])})))()},onShareAppMessage:function(){return{title:this.data.lang.shareTitle,path:"/pages/index/index",imageUrl:"/images/share.png"}},onAddToFavorites:function(){return{title:this.data.lang.shareTitle,imageUrl:"/images/share.png"}}});
},{isPage:true,isComponent:true,currentFile:'pages/input/input.js'});require("pages/input/input.js");