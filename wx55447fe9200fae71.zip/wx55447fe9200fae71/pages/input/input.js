var e, t = require("../../@babel/runtime/helpers/regeneratorRuntime"), a = require("../../@babel/runtime/helpers/asyncToGenerator"), r = require("../../@babel/runtime/helpers/defineProperty"), n = require("../../280E75359C0A569C4E681D328EE6C3E5.js"), i = (e = require("../../14764A749C0A569C72102273F606C3E5.js")) && e.__esModule ? e : {
    default: e
};

var s = getApp();

Page({
    uri: {},
    data: {
        usernamefocus: !1,
        usernameinput: !1,
        tokenerror: !1,
        tokenfocus: !1,
        tokeninput: !1,
        errorMsg: i.default[s.globalData.language].ks,
        index: 0,
        lang: i.default[s.globalData.language],
        options: [ {
            id: 0,
            name: i.default[s.globalData.language].bat
        }, {
            id: 1,
            name: i.default[s.globalData.language].batc
        } ]
    },
    adError: function() {},
    change: function(e) {
        this.setData({
            index: e.detail.id
        });
    },
    closeSelect: function() {
        this.selectComponent("#select").close();
    },
    onLoad: function(e) {
        this.uri = e;
    },
    Inputfocus: function(e) {
        this.setData(r({}, e.target.id + "focus", !0));
    },
    Inputblur: function(e) {
        this.setData(r({}, e.target.id + "focus", !1));
    },
    Inputinput: function(e) {
        var t = e.target.id, a = e.detail.value;
        if ("token" == t) {
            var n = /^[A-Za-z0-7\-\s]+$/.test(a);
            this.setData(r({
                errorMsg: a.length > 0 && !n ? this.data.lang.ke : ""
            }, t + "error", a.length > 0 && !n));
        }
        this.setData(r({}, t + "input", a.length > 0));
    },
    formSubmit: function(e) {
        var r = this;
        return a(t().mark(function a() {
            var i, o;
            return t().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (i = e.detail.value, !r.data.tokenerror) {
                        t.next = 3;
                        break;
                    }
                    return t.abrupt("return", !1);

                  case 3:
                    if (!((o = i.token.replace(/\s/gi, "")).length < 16)) {
                        t.next = 6;
                        break;
                    }
                    return t.abrupt("return", r.setData({
                        tokeninput: !0,
                        errorMsg: r.data.lang.ks,
                        tokenerror: !0
                    }));

                  case 6:
                    return t.prev = 6, t.next = 9, new Promise(function(e, t) {
                        wx.showLoading({
                            title: r.data.lang["task-ing"],
                            mask: !0,
                            success: e,
                            fail: function() {
                                t(new Error(r.data.lang.ce));
                            }
                        });
                    });

                  case 9:
                    return t.next = 11, s.Cloud.Config_insert({
                        secret: o,
                        counter: i.type >> 0 == 0 ? void 0 : 0,
                        encoding: "base32",
                        algorithm: "SHA1",
                        issuer: "",
                        digits: 6,
                        epoch: 0,
                        step: 30,
                        type: i.type >> 0 == 0 ? "totp" : "hotp",
                        label: i.username
                    });

                  case 11:
                    wx.hideLoading({
                        fail: function(e) {
                            console.error(e);
                        }
                    }), t.next = 17;
                    break;

                  case 14:
                    t.prev = 14, t.t0 = t.catch(6), wx.hideLoading({
                        fail: function(e) {
                            console.error(e);
                        }
                    });

                  case 17:
                    return t.abrupt("return", wx.reLaunch({
                        url: "/pages/index/index?" + (0, n.http_build_query)(r.uri),
                        fail: function(e) {
                            console.error(e);
                        }
                    }));

                  case 18:
                  case "end":
                    return t.stop();
                }
            }, a, null, [ [ 6, 14 ] ]);
        }))();
    },
    onShareAppMessage: function() {
        return {
            title: this.data.lang.shareTitle,
            path: "/pages/index/index",
            imageUrl: "/images/share.png"
        };
    },
    onAddToFavorites: function() {
        return {
            title: this.data.lang.shareTitle,
            imageUrl: "/images/share.png"
        };
    }
});