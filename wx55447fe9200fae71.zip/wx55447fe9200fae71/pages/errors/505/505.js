var e, t = (e = require("../../../3FC1C5329C0A569C59A7AD3595D5C3E5.js")) && e.__esModule ? e : {
    default: e
}, a = require("../../../280E75359C0A569C4E681D328EE6C3E5.js");

var r = getApp();

Page({
    data: {
        CustomBar: r.globalData.CustomBar,
        lang: t.default[r.globalData.language],
        support: "",
        current: ""
    },
    onLoad: function(e) {
        (0, a.isset)(e) && (0, a.isset)(e.support) && (0, a.isset)(e.current) && this.setData({
            support: e.support,
            current: e.current
        });
    },
    onShareAppMessage: function() {
        return {
            title: this.data.lang.shareTitle,
            path: "/pages/index/index",
            imageUrl: "/images/share.png"
        };
    },
    onAddToFavorites: function() {
        return {
            title: this.data.lang.shareTitle,
            imageUrl: "/images/share.png"
        };
    }
});