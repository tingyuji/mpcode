var t, e = require("../../@babel/runtime/helpers/regeneratorRuntime"), n = require("../../@babel/runtime/helpers/asyncToGenerator"), a = require("../../280E75359C0A569C4E681D328EE6C3E5.js"), o = require("../../A8FDA5F49C0A569CCE9BCDF3A8D6C3E5.js"), r = require("../../9BF6B1F09C0A569CFD90D9F71EB6C3E5.js"), i = (t = require("../../3C9029B29C0A569C5AF641B5A3F5C3E5.js")) && t.__esModule ? t : {
    default: t
};

var s = getApp(), u = 1154 == s.globalData.LaunchOptions.scene;

Page({
    interstitialAd: null,
    Interval: void 0,
    tmp_data: {},
    TEMP_TOKENS: s.Cloud.Config_get(),
    Timeout: void 0,
    authToWelcome: !0,
    deleteid: null,
    PageShow: !1,
    data: {
        CustomBar: s.globalData.CustomBar,
        Custom: s.globalData.Custom,
        DATA: {},
        DATA_length: u ? 0 : s.Cloud.Config_getNum(),
        inSync: !1,
        loginStatus: s.Cloud.loginStatus,
        DeleteModal: !0,
        ErrorModal: !0,
        singlePageModal: !0,
        AuthModal: !0,
        defaultAuth: !1,
        defaultAutoSync: !0,
        confirmAuth: !1,
        autoShowAuth: !1,
        AutoSync: !0,
        FirstAdd: !1,
        MessageModal: !0,
        RenameModal: !0,
        InfoModal: !0,
        Panel: !0,
        deleteinfo: "",
        reid: null,
        rename: "",
        model_id: null,
        model_access: "",
        model_label: "",
        type: "",
        isLoading: !1,
        lang: i.default[s.globalData.language]
    },
    adError: function() {},
    onLoad: function(t) {
        var e = this;
        u || (s.Cloud.on("sync:before", this.beforeSync), s.Cloud.on("sync:after", this.afterSync), 
        s.Cloud.on("sync:error", function(t) {
            t instanceof r.ServerError && e.setData({
                loginStatus: s.Cloud.loginStatus
            });
        }), (0, a.isset)(t) && ((0, a.isset)(t.ErrorModal) ? this.setData({
            ErrorModal: !1
        }) : (0, a.isset)(t.FirstAdd) && this.setData({
            FirstAdd: !0
        })), new Promise(function(t, n) {
            wx.createInterstitialAd && (e.interstitialAd = wx.createInterstitialAd({
                adUnitId: "adunit-1d90aadf47944bd2"
            }), e.interstitialAd.onError(n), e.interstitialAd.onLoad(t));
        }).catch(function(t) {
            console.error(t);
        }));
    },
    onShow: function() {
        var t = this;
        return n(e().mark(function n() {
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (!u) {
                        e.next = 2;
                        break;
                    }
                    return e.abrupt("return");

                  case 2:
                    return t.setData({
                        isLoading: !0
                    }), t.PageShow = !0, e.prev = 4, e.next = 7, t.oninit();

                  case 7:
                    t.showCode(!0) && t.runCron();

                  case 8:
                    return e.prev = 8, t.setData({
                        isLoading: !1
                    }), e.finish(8);

                  case 11:
                    t.autoAuthShow(), new Promise(function(e, n) {
                        var a = s.Cloud.autoSyn || !1, o = wx.getStorageSync("AD_TIME") || 0, r = new Date(), i = r.getMonth() + 1, u = new Date([ r.getFullYear(), i < 10 ? "0" + i : i, r.getDate() ].join("-")).getTime();
                        a && o < u ? t.interstitialAd ? t.interstitialAd.show().then(function() {
                            wx.setStorageSync("AD_TIME", u), e(!0);
                        }).catch(n) : n(new Error(t.lang["pg-fail"])) : e(!1);
                    }).catch(function(t) {
                        console.error(t);
                    });

                  case 13:
                  case "end":
                    return e.stop();
                }
            }, n, null, [ [ 4, , 8, 11 ] ]);
        }))();
    },
    onHide: function() {
        this.PageShow = !1, this.stopCron();
    },
    beforeSync: function() {
        this.PageShow && this.setData({
            inSync: !0
        });
    },
    afterSync: function() {
        this.PageShow && this.setData({
            inSync: !1
        });
    },
    onUnload: function() {
        this.stopCron(), this.Timeout && clearTimeout(this.Timeout), this.Timeout = void 0;
    },
    autoAuthShow: function() {
        var t = this;
        !this.data.loginStatus && this.data.DATA_length > 0 && !wx.getStorageSync("NotAuth") && (this.Timeout || (this.Timeout = setTimeout(function() {
            t.authToWelcome = !1, t.ShowAuth(!0), t.Timeout = void 0;
        }, 360)));
    },
    oninit: function() {
        var t = this;
        return n(e().mark(function n() {
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.prev = 0, e.next = 3, s.Cloud.checkUser();

                  case 3:
                    e.next = 8;
                    break;

                  case 5:
                    e.prev = 5, e.t0 = e.catch(0), e.t0 instanceof r.ServerError && wx.showToast({
                        title: e.t0.message || t.data.lang["login-exp"],
                        icon: "none",
                        mask: !0,
                        duration: 1800,
                        fail: function(t) {
                            console.error(t);
                        }
                    });

                  case 8:
                    return e.prev = 8, t.setData({
                        inSync: !1,
                        loginStatus: s.Cloud.loginStatus
                    }), e.finish(8);

                  case 11:
                  case "end":
                    return e.stop();
                }
            }, n, null, [ [ 0, 5, 8, 11 ] ]);
        }))();
    },
    showCode: function(t) {
        if ((t = !!t) && (this.TEMP_TOKENS = s.Cloud.Config_get(), this.setData({
            DATA_length: s.Cloud.Config_getNum()
        })), 0 === this.data.DATA_length) return !1;
        this.tmp_data = {};
        try {
            var e = Date.now() / 1e3 >> 0;
            for (var n in this.TEMP_TOKENS) {
                var a = this.TEMP_TOKENS[n];
                if (!("is_delete" in a) || !0 !== a.is_delete) {
                    var r = (e + 1) % a.step, i = (0 == r ? a.step : r) / a.step;
                    this.tmp_data[n] = {
                        id: n,
                        issuer: a.issuer,
                        access: a.label.length > 0 && a.issuer.length > 0 ? "".concat(a.issuer, " (").concat(a.label, ")") : a.label,
                        access1: a.label.length > 0 && a.issuer.length > 0 ? "".concat(a.issuer, ":").concat(a.label) : a.label,
                        label: a.label,
                        step: a.step,
                        token: e % a.step == 0 || !(n in this.data.DATA) || t ? String("hotp" == a.type ? a.current_show ? (0, 
                        o.hotp)(a) : "- - - - - -" : (0, o.totp)(a)).match(/.{1,3}/g).join(" ").replace(/\s{2}/g, " ") : this.data.DATA[n].token,
                        type: a.type,
                        htop_ok: !a.current_show || a.current_time + 5 <= e,
                        show_token: !!a.show_token,
                        percent: Math.round(100 * i),
                        deg: 360 * i
                    };
                }
            }
        } catch (t) {
            this.tmp_data = {};
        }
        return this.setData({
            DATA: this.tmp_data
        }), !0;
    },
    getHotp: function(t) {
        var a = this;
        return n(e().mark(function n() {
            var i;
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (i = t.currentTarget.dataset.id, a.tmp_data = a.data.DATA, i in a.tmp_data && i in a.TEMP_TOKENS) {
                        e.next = 4;
                        break;
                    }
                    return e.abrupt("return", !1);

                  case 4:
                    return ++a.TEMP_TOKENS[i].counter, e.prev = 5, e.next = 8, new Promise(function(t, e) {
                        wx.showLoading({
                            title: a.data.lang["task-ing"],
                            mask: !0,
                            success: t,
                            fail: function() {
                                e(new Error(a.data.lang.ce));
                            }
                        });
                    });

                  case 8:
                    return e.next = 10, s.Cloud.Config_valupdate(i, "counter", a.TEMP_TOKENS[i].counter);

                  case 10:
                    wx.hideLoading({
                        fail: function(t) {
                            console.error(t);
                        }
                    }), e.next = 17;
                    break;

                  case 13:
                    e.prev = 13, e.t0 = e.catch(5), wx.hideLoading({
                        fail: function(t) {
                            console.error(t);
                        }
                    }), e.t0 instanceof r.ServerError && wx.showToast({
                        title: e.t0.message || a.data.lang["login-exp"],
                        icon: "none",
                        mask: !0,
                        duration: 1800,
                        fail: function(t) {
                            console.error(t);
                        }
                    });

                  case 17:
                    return e.prev = 17, a.setData({
                        loginStatus: s.Cloud.loginStatus
                    }), e.finish(17);

                  case 20:
                    return a.TEMP_TOKENS[i].current_show = !0, a.TEMP_TOKENS[i].current_time = Date.now() / 1e3 >> 0, 
                    a.tmp_data[i].token = String((0, o.hotp)(a.TEMP_TOKENS[i])).match(/.{1,3}/g).join(" "), 
                    a.tmp_data[i].htop_ok = !1, a.setData({
                        DATA: a.tmp_data
                    }), e.abrupt("return", !0);

                  case 26:
                  case "end":
                    return e.stop();
                }
            }, n, null, [ [ 5, 13, 17, 20 ] ]);
        }))();
    },
    showToken: function(t) {
        var e = t.currentTarget.dataset.id;
        this.tmp_data = this.data.DATA;
        try {
            if (e in this.tmp_data && e in this.TEMP_TOKENS) return this.TEMP_TOKENS[e].show_token = !this.TEMP_TOKENS[e].show_token, 
            this.tmp_data[e].show_token = this.TEMP_TOKENS[e].show_token, this.setData({
                DATA: this.tmp_data
            }), !0;
        } catch (t) {}
        return !1;
    },
    runCron: function() {
        var t = this;
        return this.Interval || (this.Interval = setInterval(function() {
            t.showCode() || t.stopCron();
        }, 1e3));
    },
    stopCron: function() {
        return this.Interval && clearInterval(this.Interval), this.Interval = void 0;
    },
    showWidget: function() {
        return this.setData({
            Panel: !1
        });
    },
    addAccount: function() {
        this.setData({
            FirstAdd: !1
        });
    },
    openScan: function() {
        var t, o = this;
        this.setData({
            Panel: !0
        }), wx.scanCode({
            scanType: [ "qrCode" ],
            success: (t = n(e().mark(function t(n) {
                var i;
                return e().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        if (!1 !== (i = (0, a.parseQrcode)(n.result))) {
                            t.next = 3;
                            break;
                        }
                        return t.abrupt("return", o.setData({
                            ErrorModal: !1
                        }));

                      case 3:
                        return t.prev = 3, t.next = 6, new Promise(function(t, e) {
                            wx.showLoading({
                                title: o.data.lang["task-ing"],
                                mask: !0,
                                success: t,
                                fail: function() {
                                    e(new Error(o.data.lang.ce));
                                }
                            });
                        });

                      case 6:
                        return t.next = 8, s.Cloud.Config_inserts(i);

                      case 8:
                        wx.hideLoading({
                            fail: function(t) {
                                console.error(t);
                            }
                        }), t.next = 15;
                        break;

                      case 11:
                        t.prev = 11, t.t0 = t.catch(3), wx.hideLoading({
                            fail: function(t) {
                                console.error(t);
                            }
                        }), t.t0 instanceof r.ServerError && wx.showToast({
                            title: t.t0.message || o.data.lang["login-exp"],
                            icon: "none",
                            mask: !0,
                            duration: 1800,
                            fail: function(t) {
                                console.error(t);
                            }
                        });

                      case 15:
                        return t.prev = 15, o.setData({
                            loginStatus: s.Cloud.loginStatus
                        }), t.finish(15);

                      case 18:
                        o.showCode(!0) && o.runCron();

                      case 19:
                      case "end":
                        return t.stop();
                    }
                }, t, null, [ [ 3, 11, 15, 18 ] ]);
            })), function(e) {
                return t.apply(this, arguments);
            }),
            fail: function(t) {
                console.error(t);
            }
        });
    },
    gotoInput: function() {
        this.setData({
            Panel: !0
        }), wx.navigateTo({
            url: "/pages/input/input",
            fail: function(t) {
                console.error(t);
            }
        });
    },
    Longpress: function(t) {
        wx.vibrateShort({
            fail: function(t) {
                console.error(t);
            }
        }), this.setData({
            MessageModal: !1,
            model_id: t.currentTarget.dataset.id,
            model_label: t.currentTarget.dataset.label,
            model_access: t.currentTarget.dataset.access,
            type: t.currentTarget.dataset.type
        });
    },
    editActionSheet: function(t) {
        this.setData({
            MessageModal: !0,
            model_id: null,
            model_access: "",
            model_label: "",
            type: "",
            reid: t.currentTarget.dataset.id,
            rename: t.currentTarget.dataset.label,
            RenameModal: !1
        });
    },
    deleteActionSheet: function(t) {
        this.deleteid = t.currentTarget.dataset.id, this.setData({
            MessageModal: !0,
            model_id: null,
            model_access: "",
            model_label: "",
            type: "",
            deleteinfo: t.currentTarget.dataset.access,
            DeleteModal: !1
        });
    },
    infoActionSheet: function(t) {
        var e = t.currentTarget.dataset.id;
        if (e in this.TEMP_TOKENS) {
            var n = this.TEMP_TOKENS[e];
            "hotp" == n.type && this.setData({
                MessageModal: !0,
                model_id: null,
                model_access: "",
                model_label: "",
                type: "",
                infoToken: String((0, o.hotp)(Object.assign(Object.create(n), {
                    counter: 0
                }))).match(/.{1,3}/g).join(" "),
                infoCounter: n.counter,
                infoAccess: t.currentTarget.dataset.access,
                InfoModal: !1
            });
        }
    },
    modalChange: function() {
        this.deleteid = null, this.setData({
            DeleteModal: !0
        });
    },
    InfoTap: function() {
        this.setData({
            InfoModal: !0
        });
    },
    ErrorTap: function() {
        this.setData({
            ErrorModal: !0
        });
    },
    PanelTap: function() {
        this.setData({
            Panel: !0
        });
    },
    MessageTap: function() {
        this.setData({
            MessageModal: !0,
            model_id: null,
            model_access: "",
            model_label: "",
            type: ""
        });
    },
    modalre: function() {
        this.setData({
            reid: null,
            RenameModal: !0
        });
    },
    modalDelete: function() {
        var t = this;
        return n(e().mark(function n() {
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.prev = 0, e.next = 3, new Promise(function(e, n) {
                        wx.showLoading({
                            title: t.data.lang["task-ing"],
                            mask: !0,
                            success: e,
                            fail: function() {
                                n(new Error(t.data.lang.ce));
                            }
                        });
                    });

                  case 3:
                    return e.next = 5, s.Cloud.Config_del(t.deleteid);

                  case 5:
                    wx.hideLoading({
                        fail: function(t) {
                            console.error(t);
                        }
                    }), e.next = 12;
                    break;

                  case 8:
                    e.prev = 8, e.t0 = e.catch(0), wx.hideLoading({
                        fail: function(t) {
                            console.error(t);
                        }
                    }), e.t0 instanceof r.ServerError && wx.showToast({
                        title: e.t0.message || t.data.lang["login-exp"],
                        icon: "none",
                        mask: !0,
                        duration: 1800,
                        fail: function(t) {
                            console.error(t);
                        }
                    });

                  case 12:
                    return e.prev = 12, t.setData({
                        loginStatus: s.Cloud.loginStatus
                    }), e.finish(12);

                  case 15:
                    t.deleteid = null, t.setData({
                        deleteinfo: "",
                        DeleteModal: !0
                    }), t.showCode(!0) && t.runCron();

                  case 18:
                  case "end":
                    return e.stop();
                }
            }, n, null, [ [ 0, 8, 12, 15 ] ]);
        }))();
    },
    modalreChange: function() {
        var t = this;
        return n(e().mark(function n() {
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.prev = 0, e.next = 3, new Promise(function(e, n) {
                        wx.showLoading({
                            title: t.data.lang["task-ing"],
                            mask: !0,
                            success: e,
                            fail: function() {
                                n(new Error(t.data.lang.ce));
                            }
                        });
                    });

                  case 3:
                    return e.next = 5, s.Cloud.Config_valupdate(t.data.reid, "label", t.data.rename);

                  case 5:
                    wx.hideLoading({
                        fail: function(t) {
                            console.error(t);
                        }
                    }), e.next = 12;
                    break;

                  case 8:
                    e.prev = 8, e.t0 = e.catch(0), wx.hideLoading({
                        fail: function(t) {
                            console.error(t);
                        }
                    }), e.t0 instanceof r.ServerError && wx.showToast({
                        title: e.t0.message || t.data.lang["login-exp"],
                        icon: "none",
                        mask: !0,
                        duration: 1800,
                        fail: function(t) {
                            console.error(t);
                        }
                    });

                  case 12:
                    return e.prev = 12, t.setData({
                        loginStatus: s.Cloud.loginStatus
                    }), e.finish(12);

                  case 15:
                    t.setData({
                        reid: null,
                        rename: "",
                        RenameModal: !0
                    }), t.showCode(!0) && t.runCron();

                  case 17:
                  case "end":
                    return e.stop();
                }
            }, n, null, [ [ 0, 8, 12, 15 ] ]);
        }))();
    },
    userNameInput: function(t) {
        this.setData({
            rename: t.detail.value
        });
    },
    catchtouchmove: function() {
        return !1;
    },
    toSettingButton: function() {
        this.setData({
            Panel: !0
        }), wx.navigateTo({
            url: "/pages/setting/setting",
            fail: function(t) {
                console.error(t);
            }
        });
    },
    toSetting: function() {
        wx.vibrateShort({
            fail: function(t) {
                console.error(t);
            }
        }), wx.navigateTo({
            url: "/pages/setting/setting",
            fail: function(t) {
                console.error(t);
            }
        });
    },
    singlePageTap: function() {
        this.setData({
            singlePageModal: !0
        });
    },
    AuthTap: function() {
        var t = this;
        this.setData({
            AuthModal: !0,
            confirmAuth: !1
        }), this.authToWelcome && wx.nextTick(function() {
            t.toWelcome();
        });
    },
    NotAuthTap: function() {
        this.setData({
            AuthModal: !0,
            confirmAuth: !1
        }), wx.setStorageSync("NotAuth", !0);
    },
    checkboxChange: function(t) {
        this.setData({
            defaultAuth: t.detail.value.includes("auth"),
            defaultAutoSync: t.detail.value.includes("auto-sync")
        });
    },
    ShowAuth: function(t) {
        this.setData({
            AuthModal: !1,
            defaultAuth: !1,
            defaultAutoSync: !0,
            confirmAuth: !1,
            autoShowAuth: !!t
        });
    },
    CloudTap: function() {
        var t = this;
        return n(e().mark(function n() {
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (t.data.loginStatus) {
                        e.next = 3;
                        break;
                    }
                    return t.authToWelcome = !1, e.abrupt("return", t.ShowAuth());

                  case 3:
                    return t.setData({
                        inSync: !0
                    }), e.prev = 4, e.next = 7, new Promise(function(e, n) {
                        wx.showLoading({
                            title: t.data.lang["data-check"],
                            mask: !0,
                            success: e,
                            fail: function() {
                                n(new Error(t.data.lang.ce));
                            }
                        });
                    });

                  case 7:
                    return e.next = 9, s.Cloud.syn_data();

                  case 9:
                    wx.hideLoading({
                        fail: function(t) {
                            console.error(t);
                        }
                    }), wx.showToast({
                        title: t.data.lang["sync-ok"],
                        icon: "success",
                        mask: !0,
                        duration: 1200,
                        fail: function(t) {
                            console.error(t);
                        }
                    }), t.showCode(!0) && t.runCron(), e.next = 18;
                    break;

                  case 14:
                    e.prev = 14, e.t0 = e.catch(4), wx.hideLoading({
                        fail: function(t) {
                            console.error(t);
                        }
                    }), wx.showToast({
                        title: e.t0.message || t.data.lang["login-error"],
                        icon: "none",
                        mask: !0,
                        duration: 1800,
                        fail: function(t) {
                            console.error(t);
                        }
                    });

                  case 18:
                    return e.prev = 18, t.setData({
                        inSync: !1,
                        loginStatus: s.Cloud.loginStatus
                    }), e.finish(18);

                  case 21:
                  case "end":
                    return e.stop();
                }
            }, n, null, [ [ 4, 14, 18, 21 ] ]);
        }))();
    },
    shakeHorizontal: function() {
        this.setData({
            confirmAuth: !1
        });
    },
    authLogin: function() {
        var t = this;
        return n(e().mark(function n() {
            return e().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (t.data.defaultAuth) {
                        e.next = 3;
                        break;
                    }
                    return t.setData({
                        confirmAuth: !0
                    }), e.abrupt("return", wx.showToast({
                        title: t.data.lang["auth-confirm"],
                        icon: "none",
                        mask: !0,
                        duration: 800,
                        fail: function(t) {
                            console.error(t);
                        }
                    }));

                  case 3:
                    return e.prev = 3, e.next = 6, new Promise(function(e, n) {
                        wx.showLoading({
                            title: t.data.lang["login-ing"],
                            mask: !0,
                            success: e,
                            fail: function() {
                                n(new Error(t.data.lang.ce));
                            }
                        });
                    });

                  case 6:
                    return e.next = 8, s.Cloud.login();

                  case 8:
                    if (wx.hideLoading({
                        fail: function(t) {
                            console.error(t);
                        }
                    }), !t.data.defaultAutoSync) {
                        e.next = 19;
                        break;
                    }
                    return s.Cloud.setautoSyn(!0), e.next = 13, new Promise(function(e, n) {
                        wx.showLoading({
                            title: t.data.lang["data-check"],
                            mask: !0,
                            success: e,
                            fail: function() {
                                n(new Error(t.data.lang.ce));
                            }
                        });
                    });

                  case 13:
                    return e.next = 15, s.Cloud.syn_data();

                  case 15:
                    wx.hideLoading({
                        fail: function(t) {
                            console.error(t);
                        }
                    }), wx.showToast({
                        title: t.data.lang["sync-ok"],
                        icon: "success",
                        mask: !0,
                        duration: 1200,
                        fail: function(t) {
                            console.error(t);
                        }
                    }), t.showCode(!0) && t.runCron(), t.data.DATA_length > 0 && (t.authToWelcome = !1);

                  case 19:
                    t.AuthTap(), e.next = 26;
                    break;

                  case 22:
                    e.prev = 22, e.t0 = e.catch(3), wx.hideLoading({
                        fail: function(t) {
                            console.error(t);
                        }
                    }), wx.showToast({
                        title: e.t0.message || t.data.lang["login-error"],
                        icon: "none",
                        mask: !0,
                        duration: 1800,
                        fail: function(t) {
                            console.error(t);
                        }
                    });

                  case 26:
                    return e.prev = 26, t.setData({
                        loginStatus: s.Cloud.loginStatus
                    }), e.finish(26);

                  case 29:
                  case "end":
                    return e.stop();
                }
            }, n, null, [ [ 3, 22, 26, 29 ] ]);
        }))();
    },
    startTap: function() {
        return u ? this.setData({
            singlePageModal: !1
        }) : this.data.loginStatus ? void this.toWelcome() : (this.authToWelcome = !0, this.ShowAuth());
    },
    toWelcome: function() {
        wx.getStorageSync("startOK") ? wx.navigateTo({
            url: "/pages/start/start",
            fail: function(t) {
                console.error(t);
            }
        }) : wx.navigateTo({
            url: "/pages/help/help",
            fail: function(t) {
                console.error(t);
            }
        });
    },
    onShareAppMessage: function() {
        return {
            title: this.data.lang.shareTitle,
            path: "/pages/index/index",
            imageUrl: "/images/share.png"
        };
    },
    onAddToFavorites: function() {
        return {
            title: this.data.lang.shareTitle,
            imageUrl: "/images/share.png"
        };
    },
    onShareTimeline: function() {
        return {
            title: this.data.lang.shareTitle,
            imageUrl: "/images/logo.png"
        };
    }
});