$gwx_XC_12=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_12 || [];
function gz$gwx_XC_12_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_12_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_12_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_12_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'html'])
Z([3,'body'])
Z([3,'div mdl-layout__container mdl-color--primary'])
Z([3,'div mdl-layout'])
Z([3,'header mdl-layout__header mdl-layout__header--scroll'])
Z([3,''])
Z([1,true])
Z([3,'backText'])
Z([a,[[6],[[7],[3,'lang']],[1,'Back']]])
Z([3,'content'])
Z([a,[[6],[[7],[3,'lang']],[1,'Authenticator']]])
Z([3,'div mdl-layout__content mdl-color--grey-50'])
Z([3,'div mdl-grid'])
Z([3,'div mdl-cell mdl-cell--12-col'])
Z([3,'h4'])
Z([a,[3,'\n                                '],[[6],[[7],[3,'lang']],[1,'add-account']],[3,'\n                            ']])
Z([3,'div'])
Z([a,[[6],[[7],[3,'lang']],[1,'add-s']]])
Z([3,'div mdl-grid mdl-grid--no-spacing'])
Z(z[13])
Z([3,'ul demo-list-icon mdl-list'])
Z([3,'openScan'])
Z([3,'li mdl-list__item mdl-button'])
Z([3,'span mdl-list__item-primary-content'])
Z([3,'i material-icons mdl-list__item-icon'])
Z([3,'photo_camera'])
Z([a,[[6],[[7],[3,'lang']],[1,'sqc']],[3,'\n                                    ']])
Z([3,'hr'])
Z([3,'gotoInput'])
Z(z[22])
Z(z[23])
Z(z[24])
Z([3,'keyboard'])
Z([a,[[6],[[7],[3,'lang']],[1,'Enter-key']],z[26][2]])
Z(z[12])
Z(z[13])
Z(z[16])
Z([a,[[6],[[7],[3,'lang']],[1,'bt']]])
Z(z[18])
Z(z[13])
Z(z[20])
Z([3,'toSetting'])
Z(z[22])
Z(z[23])
Z(z[24])
Z([3,'settings_backup_restore'])
Z([a,[[6],[[7],[3,'lang']],[1,'br']],z[26][2]])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_12_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_12_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_12=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_12=true;
var x=['./pages/start/start.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_12_1()
var cJ6=_n('view')
_rz(z,cJ6,'class',0,e,s,gg)
var hK6=_n('view')
_rz(z,hK6,'class',1,e,s,gg)
var oL6=_n('view')
_rz(z,oL6,'class',2,e,s,gg)
var cM6=_n('view')
_rz(z,cM6,'class',3,e,s,gg)
var oN6=_n('view')
_rz(z,oN6,'class',4,e,s,gg)
var lO6=_mz(z,'header',['bgColor',5,'isBack',1],[],e,s,gg)
var aP6=_n('view')
_rz(z,aP6,'slot',7,e,s,gg)
var tQ6=_oz(z,8,e,s,gg)
_(aP6,tQ6)
_(lO6,aP6)
var eR6=_n('view')
_rz(z,eR6,'slot',9,e,s,gg)
var bS6=_oz(z,10,e,s,gg)
_(eR6,bS6)
_(lO6,eR6)
_(oN6,lO6)
_(cM6,oN6)
var oT6=_n('view')
_rz(z,oT6,'class',11,e,s,gg)
var xU6=_n('view')
_rz(z,xU6,'class',12,e,s,gg)
var oV6=_n('view')
_rz(z,oV6,'class',13,e,s,gg)
var fW6=_n('view')
_rz(z,fW6,'class',14,e,s,gg)
var cX6=_oz(z,15,e,s,gg)
_(fW6,cX6)
_(oV6,fW6)
var hY6=_n('view')
_rz(z,hY6,'class',16,e,s,gg)
var oZ6=_oz(z,17,e,s,gg)
_(hY6,oZ6)
_(oV6,hY6)
_(xU6,oV6)
_(oT6,xU6)
var c16=_n('view')
_rz(z,c16,'class',18,e,s,gg)
var o26=_n('view')
_rz(z,o26,'class',19,e,s,gg)
var l36=_n('view')
_rz(z,l36,'class',20,e,s,gg)
var a46=_mz(z,'button',['catchtap',21,'class',1],[],e,s,gg)
var t56=_n('view')
_rz(z,t56,'class',23,e,s,gg)
var e66=_n('view')
_rz(z,e66,'class',24,e,s,gg)
var b76=_oz(z,25,e,s,gg)
_(e66,b76)
_(t56,e66)
var o86=_oz(z,26,e,s,gg)
_(t56,o86)
_(a46,t56)
_(l36,a46)
var x96=_n('view')
_rz(z,x96,'class',27,e,s,gg)
_(l36,x96)
var o06=_mz(z,'button',['catchtap',28,'class',1],[],e,s,gg)
var fA7=_n('view')
_rz(z,fA7,'class',30,e,s,gg)
var cB7=_n('view')
_rz(z,cB7,'class',31,e,s,gg)
var hC7=_oz(z,32,e,s,gg)
_(cB7,hC7)
_(fA7,cB7)
var oD7=_oz(z,33,e,s,gg)
_(fA7,oD7)
_(o06,fA7)
_(l36,o06)
_(o26,l36)
_(c16,o26)
_(oT6,c16)
var cE7=_n('view')
_rz(z,cE7,'class',34,e,s,gg)
var oF7=_n('view')
_rz(z,oF7,'class',35,e,s,gg)
var lG7=_n('view')
_rz(z,lG7,'class',36,e,s,gg)
var aH7=_oz(z,37,e,s,gg)
_(lG7,aH7)
_(oF7,lG7)
_(cE7,oF7)
_(oT6,cE7)
var tI7=_n('view')
_rz(z,tI7,'class',38,e,s,gg)
var eJ7=_n('view')
_rz(z,eJ7,'class',39,e,s,gg)
var bK7=_n('view')
_rz(z,bK7,'class',40,e,s,gg)
var oL7=_mz(z,'button',['catchtap',41,'class',1],[],e,s,gg)
var xM7=_n('view')
_rz(z,xM7,'class',43,e,s,gg)
var oN7=_n('view')
_rz(z,oN7,'class',44,e,s,gg)
var fO7=_oz(z,45,e,s,gg)
_(oN7,fO7)
_(xM7,oN7)
var cP7=_oz(z,46,e,s,gg)
_(xM7,cP7)
_(oL7,xM7)
_(bK7,oL7)
_(eJ7,bK7)
_(tI7,eJ7)
_(oT6,tI7)
_(cM6,oT6)
_(oL6,cM6)
_(hK6,oL6)
_(cJ6,hK6)
_(r,cJ6)
return r
}
e_[x[0]]=e_[x[0]]||{f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_12";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_12();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/start/start.wxml'] = [$gwx_XC_12, './pages/start/start.wxml'];else __wxAppCode__['pages/start/start.wxml'] = $gwx_XC_12( './pages/start/start.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['pages/start/start.wxss'] = setCssToHead([".",[1],"demo-list-icon{margin:0;padding:0}\n.",[1],"demo-list-icon .",[1],"hr{height:auto;margin:0 0 0 68px}\n",],undefined,{path:"./pages/start/start.wxss"});
}