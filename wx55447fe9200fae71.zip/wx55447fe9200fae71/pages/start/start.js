var e, r = require("../../@babel/runtime/helpers/regeneratorRuntime"), n = require("../../@babel/runtime/helpers/asyncToGenerator"), a = require("../../280E75359C0A569C4E681D328EE6C3E5.js"), t = (e = require("../../EE3A29D59C0A569C885C41D2E866C3E5.js")) && e.__esModule ? e : {
    default: e
};

var i = getApp();

Page({
    data: {
        lang: t.default[i.globalData.language]
    },
    openScan: function() {
        var e, t = this;
        wx.scanCode({
            scanType: [ "qrCode" ],
            success: (e = n(r().mark(function e(n) {
                var o;
                return r().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (!1 !== (o = (0, a.parseQrcode)(n.result))) {
                            e.next = 3;
                            break;
                        }
                        return e.abrupt("return", wx.reLaunch({
                            url: "/pages/index/index?ErrorModal=1",
                            fail: function(e) {
                                console.error(e);
                            }
                        }));

                      case 3:
                        return e.prev = 3, e.next = 6, new Promise(function(e, r) {
                            wx.showLoading({
                                title: t.data.lang["task-ing"],
                                mask: !0,
                                success: e,
                                fail: function() {
                                    r(new Error(t.data.lang.ce));
                                }
                            });
                        });

                      case 6:
                        return e.next = 8, i.Cloud.Config_inserts(o);

                      case 8:
                        wx.hideLoading({
                            fail: function(e) {
                                console.error(e);
                            }
                        }), e.next = 14;
                        break;

                      case 11:
                        e.prev = 11, e.t0 = e.catch(3), wx.hideLoading({
                            fail: function(e) {
                                console.error(e);
                            }
                        });

                      case 14:
                        return e.abrupt("return", wx.reLaunch({
                            url: "/pages/index/index?FirstAdd=1",
                            fail: function(e) {
                                console.error(e);
                            }
                        }));

                      case 15:
                      case "end":
                        return e.stop();
                    }
                }, e, null, [ [ 3, 11 ] ]);
            })), function(r) {
                return e.apply(this, arguments);
            }),
            fail: function(e) {
                console.error(e);
            }
        });
    },
    gotoInput: function() {
        wx.navigateTo({
            url: "/pages/input/input?FirstAdd=1",
            fail: function(e) {
                console.error(e);
            }
        });
    },
    toSetting: function() {
        wx.redirectTo({
            url: "/pages/setting/setting",
            fail: function(e) {
                console.error(e);
            }
        });
    },
    onShareAppMessage: function() {
        return {
            title: this.data.lang.shareTitle,
            path: "/pages/index/index",
            imageUrl: "/images/share.png"
        };
    },
    onAddToFavorites: function() {
        return {
            title: this.data.lang.shareTitle,
            imageUrl: "/images/share.png"
        };
    }
});