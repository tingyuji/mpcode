var t, a = require("../../280E75359C0A569C4E681D328EE6C3E5.js"), e = (t = require("../../411760B09C0A569C277108B7C6E5C3E5.js")) && t.__esModule ? t : {
    default: t
};

var r = getApp();

Page({
    data: {
        help_current: 0,
        is_back: !1,
        CustomBar: r.globalData.CustomBar,
        lang: e.default[r.globalData.language]
    },
    onLoad: function(t) {
        var e = {
            help_current: 0
        };
        (0, a.isset)(t) && (0, a.isset)(t.is_back) && (e.is_back = !0), this.setData(e);
    },
    Swiperchange: function(t) {
        this.setData({
            help_current: t.detail.current
        });
    },
    toNext: function() {
        this.setData({
            help_current: this.data.help_current + 1
        });
    },
    toJump: function() {
        this.data.is_back ? wx.navigateBack({
            fail: function(t) {
                console.error(t);
            }
        }) : wx.redirectTo({
            url: "/pages/start/start",
            success: function() {
                wx.setStorageSync("startOK", !0);
            },
            fail: function(t) {
                console.error(t);
            }
        });
    },
    onShareAppMessage: function() {
        return {
            title: this.data.lang.shareTitle,
            path: "/pages/index/index",
            imageUrl: "/images/share.png"
        };
    },
    onAddToFavorites: function() {
        return {
            title: this.data.lang.shareTitle,
            imageUrl: "/images/share.png"
        };
    }
});