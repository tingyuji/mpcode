Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

exports.default = {
    zh_CN: {
        shareTitle: "Hello，推荐您一个MFA小程序，我也在使用哦~ 👍",
        Back: "返回",
        about: "关于我们",
        p1: "该小程序由开发者“落叶🍂”开发和维护（注：小程序目前是免费使用，包括云同步功能，开发者从未与任何第三方有过合作，注意上当受骗）。数据全部都是前端加解密，服务端只负责存储与读取，加密密钥来源于您的公开信息，[如您设置了独立密码，则需要输入独立密码后才能解密云上存储的数据（独立密码功能还未加入），如果您忘记独立密码（独立密码是您加密数据的额外非必须密码，只有您自己知晓该密码），那么云备份的数据将不能恢复到本地（数据无法解密），您将丢失云备份的数据]，该小程序可以离线运行，所有数据存储在本地归集到微信账户下，如果您删除该小程序或清除微信的数据（包括更换设备、一些三方的清理软件清理），将导致您的数据丢失（如果您使用过同步功能，您只能找回曾经同步过且没有彻底删除的数据）。注：切换微信™账户不会丢失数据，但您不能读取另一个微信™账户下的小程序数据，请谨慎操作。",
        p2: "该小程序的图片素材来源于：Google身份验证器",
        p3: "该小程序的验证码生成代码来源于：https://github.com/railsstudent/speakeasy",
        p4: "该小程序的风格来源于：https://github.com/google/material-design-lite 和 https://github.com/weilanwl/ColorUI",
        p5: "该小程序的加密组件(CryptoJS)来源于：https://code.google.com/archive/p/crypto-js/",
        p6: "该小程序的其它组件(base32,base64,Buffer,ieee754,punycode,querystring,uri,util)来源于：https://www.npmjs.com/"
    },
    zh_HK: {
        shareTitle: "Hello，推薦您一個MFA小程序，我也在使用哦~ 👍",
        Back: "返回",
        about: "關於我們",
        p1: "該小程序由開發者“落葉🍂”開發和維護（注：小程序目前是免費使用，包括云同步功能，開發者從未與任何第三方有過合作，注意上當受騙）。數據全部都是前端加解密，服務端只負責存儲與讀取，加密密鑰來源於您的公開信息，[如您設置了獨立密碼，則需要輸入獨立密碼後才能解密雲上存儲的數據（獨立密碼功能還未加入），如果您忘記獨立密碼（獨立密碼是您加密數據的額外非必須密碼，只有您自己知曉該密碼），那麼雲備份的數據將不能恢復到本地（數據無法解密），您將丟失雲備份的數據]，該小程序可以離線運行，所有數據存儲在本地歸集到微信賬戶下，如果您刪除該小程序或清除微信的數據（包括更換設備、一些三方的清理軟件清理） ，將導致您的數據丟失（如果您使用過同步功能，您只能找回曾經同步過且沒有徹底刪除的數據）。注：切換微信™賬戶不會丟失數據，但您不能讀取另一個微信™賬戶下的小程序數據，請謹慎操作。",
        p2: "該小程序的圖片素材來源於：Google身份驗證器",
        p3: "該小程序的驗證碼生成代碼來源於：https://github.com/railsstudent/speakeasy",
        p4: "該小程序的風格來源於：https://github.com/google/material-design-lite 和 https://github.com/weilanwl/ColorUI",
        p5: "該小程序的加密組件(CryptoJS)來源於：https://code.google.com/archive/p/crypto-js/",
        p6: "該小程序的其它組件(base32,base64,Buffer,ieee754,punycode,querystring,uri,util)來源於：https://www.npmjs.com/"
    },
    en: {
        shareTitle: "Hello, I recommend an MFA Mini Program, I am also using it~ 👍",
        Back: "Back",
        about: "About us",
        p1: 'The Mini Program is developed and maintained by the developer "落叶🍂" (Note: The Mini Program is currently free to use, including the cloud synchronization function, the developer has never cooperated with any third party, beware of being deceived). All data is encrypted and decrypted by the front-end, and the server is only responsible for storage and reading. The encryption key comes from your public information. [If you set an independent password, you need to enter an independent password to decrypt the data stored on the cloud (independent The password function has not been added), if you forget the independent password (the independent password is an additional non-essential password for your encrypted data, only you know the password), then the cloud backup data will not be restored to the local (data cannot be decrypted), you The data backed up by the cloud will be lost], the applet can be run offline, and all data is stored locally under the WeChat account. If you delete the applet or clear the WeChat data (including replacement of the device, cleaning by some third-party cleaning software) , Will result in the loss of your data (if you have used the synchronization function, you can only retrieve the data that has been synchronized but has not been completely deleted). Note: Switching WeChat™ account will not lose data, but you cannot read the applet data under another WeChat™ account. Please operate with caution.',
        p2: "The picture material of this Mini Program comes from: Google Authenticator",
        p3: "The verification code generation code of this Mini Program comes from: https://github.com/railsstudent/speakeasy",
        p4: "The style of this Mini Program comes from: https://github.com/google/material-design-lite and https://github.com/weilanwl/ColorUI",
        p5: "The encryption component (CryptoJS) of this Mini Program comes from: https://code.google.com/archive/p/crypto-js/",
        p6: "Other components of the Mini Program (base32, base64, Buffer, ieee754, punycode, querystring, uri, util) are from: https://www.npmjs.com/"
    }
};