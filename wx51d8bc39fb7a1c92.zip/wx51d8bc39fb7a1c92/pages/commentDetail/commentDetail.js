var e, t, n = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/regenerator")), i = require("../../@babel/runtime/helpers/toConsumableArray"), r = require("../../@babel/runtime/helpers/asyncToGenerator"), a = require("../../@babel/runtime/helpers/defineProperty"), o = require("../../config/index"), s = require("../../api/index"), l = (a(e = {}, o.COMMENT_TYPE_DP, "dp"), 
a(e, o.COMMENT_TYPE_EXAM, "exam"), a(e, o.COMMENT_TYPE_MEDITATION, "meditation"), 
e), c = getApp(), u = (a(t = {}, o.COMMENT_TYPE_MEDITATION, "clk_mini_medi_comment_like_unfold_fold"), 
a(t, o.COMMENT_TYPE_DP, "clk_mini_test_comment_like_unfold_fold"), a(t, o.COMMENT_TYPE_EXAM, "clk_mini_prac_comment_like_unfold_fold"), 
t);

Page({
    data: {
        title: "",
        list: [],
        end: !1,
        type: ""
    },
    onLoad: function(e) {
        this.options = e, console.log(this.options);
        var t = e.title || "评论详情";
        this.setData({
            title: t,
            type: l[e.type]
        }), this.init();
    },
    onShareAppMessage: function() {
        var e = wx._getUserInfo();
        return {
            title: "".concat(e ? e.nickname : "好友", "邀请你来体验心理百科小程序，体验多种心理自助工具")
        };
    },
    init: function() {
        var e, t = this.options.type;
        this.data.end || (a(e = {}, o.COMMENT_TYPE_MEDITATION, this.getMeditaionComment), 
        a(e, o.COMMENT_TYPE_DP, this.getDpComment), a(e, o.COMMENT_TYPE_EXAM, this.getExamComment), 
        e)[t]();
    },
    getMeditaionComment: function() {
        var e = this;
        return r(n.default.mark(function t() {
            var r, a, o, l, c, u, m;
            return n.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return r = e.data.list, a = e.options.id, o = {
                        course_id: a,
                        offset: r.length,
                        limit: 20
                    }, t.next = 5, s.meditationService.getComment(o);

                  case 5:
                    l = t.sent, c = l.count, u = l.list, m = [].concat(i(r), i(u)), e.setData({
                        list: m,
                        end: m.length === c
                    });

                  case 10:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    },
    getExamComment: function() {
        var e = this;
        return r(n.default.mark(function t() {
            var r, a, o, l, c, u, m;
            return n.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return r = e.options.id, a = e.data.list, o = {
                        exam_id: r,
                        offset: a.length,
                        limit: 20
                    }, t.next = 5, s.examService.getComment(o);

                  case 5:
                    l = t.sent, c = l.count, u = l.list, m = [].concat(i(a), i(u)), e.setData({
                        list: m,
                        end: c === m.length
                    });

                  case 10:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    },
    getDpComment: function() {
        var e = this;
        return r(n.default.mark(function t() {
            var r, a, o, l, c, u, m;
            return n.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return r = e.options.id, a = e.data.list, o = {
                        plan_id: r,
                        limit: 20,
                        offset: a.length
                    }, t.next = 5, s.dpService.getComment(o);

                  case 5:
                    l = t.sent, c = l.count, u = l.list, m = [].concat(i(a), i(u)), e.setData({
                        list: m,
                        end: m.length === c
                    });

                  case 10:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    },
    handleChange: function(e) {
        var t = e.detail, n = this.options.type, i = u[n];
        wx._trackEvent(i, {
            userid: c.globalData.user_id,
            comment_id: t.id
        });
    }
});