var e = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/regenerator")), t = require("../../@babel/runtime/helpers/asyncToGenerator"), n = require("../../utils/index"), i = require("../../api/index");

Page({
    data: {
        selectedId: null,
        plan: {},
        recommendList: []
    },
    onLoad: function(e) {
        this.options = e, this.init();
    },
    onShareAppMessage: function() {
        var e = wx._getUserInfo();
        return {
            title: "".concat(e ? e.nickname : "好友", "邀请你来体验心理百科小程序，体验多种心理自助工具")
        };
    },
    init: function() {
        var n = this;
        return t(e.default.mark(function t() {
            var r, a, s, c, o;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return r = n.options.id, a = {
                        id: r
                    }, e.next = 4, i.dpService.getGuidanceDetail(a);

                  case 4:
                    s = e.sent, c = s.plan, o = s.plan_recommend, n.setData({
                        recommendList: o,
                        plan: c
                    });

                  case 8:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    handler: function(e) {
        var t = e.detail.id, n = this.data.selectedId;
        this.setData({
            selectedId: n === t ? null : t
        });
    },
    toDpDetail: function() {
        var e = this.data.selectedId;
        e && (0, n.goto)("/pages/exerciseDetail/exerciseDetail?id=".concat(e));
    }
});