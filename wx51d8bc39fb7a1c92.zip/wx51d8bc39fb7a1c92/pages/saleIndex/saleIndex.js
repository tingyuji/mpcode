var e = require("../../@babel/runtime/helpers/interopRequireDefault"), t = require("../../@babel/runtime/helpers/defineProperty");

require("../../@babel/runtime/helpers/Arrayincludes");

var a = require("../../@babel/runtime/helpers/toConsumableArray"), i = e(require("../../@babel/runtime/regenerator")), n = require("../../@babel/runtime/helpers/objectSpread2"), r = require("../../@babel/runtime/helpers/objectWithoutProperties"), s = require("../../@babel/runtime/helpers/slicedToArray"), o = require("../../@babel/runtime/helpers/asyncToGenerator"), l = require("../../api/index"), c = require("../../utils/getTime"), d = e(require("./saler/WechatSaler")), u = require("../../utils/index"), h = require("../../utils/dataCollect"), p = require("../../utils/enum"), g = [ "shop", "shop_more" ], v = getApp(), f = {
    avatar: "https://cdn.knowyourself.cc/together-wxapp/default_avatar.png",
    nickname: "待赠送"
};

function w(e) {
    var t = e;
    return t < 10 && t >= 0 && (t = "0".concat(t)), t;
}

function _(e) {
    if (!e) return {
        d: 0,
        h: 0,
        m: 0,
        s: 0
    };
    var t = new Date(e);
    return {
        d: Math.floor(t / 60 / 60 / 24),
        h: w(Math.floor(t / 60 / 60 % 24)),
        m: w(Math.floor(t / 60 % 60)),
        s: w(Math.floor(t % 60))
    };
}

Page({
    data: {
        notice: [ "邀请好友助力", "获得活动参与机会" ],
        timer: null,
        detail: null,
        shop: null,
        userList: [],
        btns: [],
        isFinish: !1,
        countDown: null,
        headerText: null,
        helperBtn: null,
        qrCode: "",
        sendDialogVisible: !1,
        title: "",
        isHelper: !1,
        isShowUserList: !0,
        receiveIndex: 0,
        receiveList: [],
        receiveDetail: {
            topSrc: "",
            bottomSrc: ""
        }
    },
    onLoad: function(e) {
        var t = this;
        this.options = e, wx.nextTick(function() {
            t.widget = t.selectComponent(".widget");
        });
    },
    onReady: function() {},
    onShow: function() {
        if (wx.getStorageSync(p.KY_WEAPP_TOKEN)) {
            var e = JSON.parse(wx.getStorageSync(p.KY_WEAPP_USER_INFO));
            v.globalData.user_id = e.id, this.init();
        } else (0, u.goto)("/pages/login/login");
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: this.data.detail.activity_share.title,
            imageUrl: this.data.detail.activity_share.x_image
        };
    },
    init: function() {
        var e = this;
        return o(i.default.mark(function t() {
            var a, o, u, h, p, f, w, _, x, m, b, D, S, k, y, T, I, A, C;
            return i.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.prev = 0, a = e.options, o = a.key, u = a.id, h = "", o && (h = decodeURIComponent(o)), 
                    p = {
                        id: u,
                        share_key: h
                    }, t.next = 7, Promise.all([ l.saleService.getDetail(p), (0, c.getTimeNow)(), l.saleService.getWinLog(u) ]);

                  case 7:
                    f = t.sent, w = s(f, 3), _ = w[0], x = _.shop, m = _.shop_more, b = r(_, g), D = w[1], 
                    (S = w[2].list).length > 0 && (1 === S.length ? e.setData({
                        receiveDetail: {
                            topSrc: S[0].user.avatar,
                            bottomSrc: S[0].user.avatar
                        }
                    }) : setInterval(function() {
                        var t = e.data.receiveIndex, a = t === e.data.receiveList.length - 1 ? 0 : t + 1;
                        e.setData({
                            receiveDetail: {
                                topSrc: S[t].user.avatar,
                                bottomSrc: S[a].user.avatar
                            },
                            receiveIndex: a
                        });
                    }, 4e3)), e.setData({
                        title: b.title,
                        shop: x.length ? x : m.map(function(e) {
                            return Object.assign({}, e, {
                                shop: e
                            });
                        }),
                        detail: n(n({}, b), {}, {
                            _key: h,
                            shop: x,
                            shop_more: m
                        }),
                        receiveIndex: 0,
                        receiveList: S
                    }), b.now && e.setUserList(), k = !1, k = !(!b || !b.now) && v.globalData.user_id !== b.now.share.user_id, 
                    e.setData({
                        isHelper: k
                    }), e.appSlaer = new d.default({
                        detail: e.data.detail,
                        now: Math.floor(D / 1e3),
                        onUpdate: e.handleUpdate,
                        isHelper: k
                    }), y = !1, T = null, b.now && (y = b.now.is_help, I = b.now.share, A = I.help_num, 
                    C = I.need_help_num, T = y ? {
                        text: "成功领取福利，立即体验",
                        handler: "toDetail"
                    } : A === C ? {
                        text: "来晚啦，我也要领福利",
                        handler: "toDetail"
                    } : {
                        text: "立即领取福利",
                        handler: "getGift"
                    }, e.setData({
                        helperBtn: T
                    })), t.next = 30;
                    break;

                  case 27:
                    t.prev = 27, t.t0 = t.catch(0), console.error(t.t0);

                  case 30:
                  case "end":
                    return t.stop();
                }
            }, t, null, [ [ 0, 27 ] ]);
        }))();
    },
    setUserList: function() {
        var e = (this.data.detail || {}).now, t = e.help_user, i = e.share.need_help_num, n = new Array(i);
        n.fill(f);
        var r = [].concat(a(t || []), n);
        r.length = i, this.setData({
            userList: r
        });
    },
    handleUpdate: function() {
        this.setData({
            btns: this.appSlaer.btns,
            countDown: _(this.appSlaer.countDown),
            headerText: this.appSlaer.headerText,
            isFinish: this.appSlaer.isFinish
        });
        var e = this.data.detail.now;
        if (this.data.isHelper) {
            var t = this.appSlaer, a = t.activityStatus, i = t.stockStatus, n = t.assistStatus;
            2 === a && 8 === i && 64 === n && this.setData({
                isFinish: !1,
                helperBtn: {
                    text: "来晚啦，我也要领福利",
                    handler: "toDetail"
                }
            });
        } else if (e) {
            var r = Number(e.share.status);
            if (1 === r) return void this.setData({
                btns: [ {
                    text: "赠送成功,开始体验",
                    class: "black",
                    handler: "receive"
                } ]
            });
            if (![ 1, 2 ].includes(r)) {
                var s = 1e3 * e.share.expired_time;
                new Date().getTime() > s && this.setData({
                    btns: [ {
                        text: "重新赠送好友",
                        handler: "reStartGive",
                        class: "black"
                    } ],
                    isShowUserList: !1
                });
            }
        }
    },
    getGift: function() {
        var e = this;
        return o(i.default.mark(function a() {
            var n, r, s;
            return i.default.wrap(function(a) {
                for (;;) switch (a.prev = a.next) {
                  case 0:
                    return wx._trackEvent("clk_mini_1to1_receive_actPage_get", {
                        userid: getApp().globalData.user_id
                    }), a.prev = 1, n = {
                        share_key: e.options.key
                    }, a.next = 5, l.saleService.postHelp(n);

                  case 5:
                    r = a.sent, r.log_id && (wx.showToast({
                        title: "领取成功"
                    }), "detail.now.is_help", e.setData((t(s = {}, "detail.now.is_help", !0), t(s, "helperBtn", {
                        text: "成功领取福利，立即体验",
                        handler: "toDetail"
                    }), s), function() {
                        e.toDetail();
                    })), a.next = 13;
                    break;

                  case 10:
                    a.prev = 10, a.t0 = a.catch(1), console.error(a.t0);

                  case 13:
                  case "end":
                    return a.stop();
                }
            }, a, null, [ [ 1, 10 ] ]);
        }))();
    },
    reStartGive: function() {
        var e = this;
        return o(i.default.mark(function t() {
            var a, n, r, s, o, c;
            return i.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return a = e.options.id, n = e.data.detail.now.shop, t.next = 4, l.saleService.getSale({
                        product_type: n.product_type,
                        product_id: n.product_id
                    });

                  case 4:
                    if ((r = t.sent).activity_shop_id) {
                        t.next = 8;
                        break;
                    }
                    return wx.showToast({
                        title: "活动已达到上限值, 请退回重新查看"
                    }), t.abrupt("return");

                  case 8:
                    return s = {
                        product_type: n.product_type,
                        product_id: n.product_id,
                        activity_id: r.id,
                        activity_shop_id: r.activity_shop_id
                    }, t.next = 11, l.saleService.getShareKey(s, {
                        loadingText: "生成分享码"
                    });

                  case 11:
                    o = t.sent, c = o.share_key, (0, h.setListData)({
                        url: "/pages/saleIndex/saleIndex?id=".concat(a, "&key=").concat(encodeURIComponent(c))
                    }), wx.redirectTo({
                        url: "/pages/saleIndex/saleIndex?id=".concat(a, "&key=").concat(encodeURIComponent(c))
                    });

                  case 15:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    },
    shareFriend: function() {
        wx._trackEvent("clk_mini_1to1_receive_actPage_get", {
            userid: getApp().globalData.user_id
        });
    },
    toHome: function() {
        wx._trackEvent("clk_520_actPage_viewTest", {
            userid: getApp().globalData.user_id,
            test_id: this.options.id
        }), (0, u.goto)("/pages/saleIndex/saleIndex?id=".concat(this.options.id));
    },
    toDetail: function() {
        var e = this.data.detail.now, t = e.product_id, a = e.product_type;
        switch (Number(a)) {
          case 1:
            (0, u.goto)("/pages/evaluationDetail/evaluationDetail?id=".concat(t));
            break;

          case 6:
            (0, u.goto)("/pages/meditationDetail/meditationDetail?id=".concat(t));
            break;

          case 4:
            (0, u.goto)("/pages/exerciseDetail/exerciseDetail?id=".concat(t));
        }
    },
    receive: function() {
        var e = this;
        return o(i.default.mark(function t() {
            var a;
            return i.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return wx._trackEvent("clk_520_actPage_get", {
                        userid: getApp().globalData.user_id
                    }), t.prev = 1, t.next = 4, l.saleService.getReceive({
                        share_key: e.options.key
                    });

                  case 4:
                    a = t.sent, a.status && e.toDetail(), t.next = 11;
                    break;

                  case 9:
                    t.prev = 9, t.t0 = t.catch(1);

                  case 11:
                  case "end":
                    return t.stop();
                }
            }, t, null, [ [ 1, 9 ] ]);
        }))();
    },
    shareMoment: function() {
        var e = this;
        return o(i.default.mark(function t() {
            var a, r, o, c;
            return i.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return wx._trackEvent("clk_520_main_share", {
                        userid: getApp().globalData.user_id
                    }), t.prev = 1, a = {
                        sceneData: n(n({}, e.options), {}, {
                            page: "pages/saleIndex/saleIndex"
                        }),
                        optional: {
                            page: "pages/index/index"
                        }
                    }, t.next = 5, Promise.all([ l.saleService.getQrcode(a) ]);

                  case 5:
                    r = t.sent, o = s(r, 1), c = o[0].object, e.setData({
                        qrCode: c,
                        sendDialogVisible: !0
                    }, function() {
                        e.renderToCanvas();
                    }), t.next = 14;
                    break;

                  case 11:
                    t.prev = 11, t.t0 = t.catch(1), console.error(t.t0);

                  case 14:
                  case "end":
                    return t.stop();
                }
            }, t, null, [ [ 1, 11 ] ]);
        }))();
    },
    closeSendDialog: function() {
        this.setData({
            sendDialogVisible: !1
        });
    },
    renderToCanvas: function() {
        var e = this, t = '\n      <view class="container" >\n        <view class="send-banner">\n          <image class="send-banner-img" src="'.concat(this.data.detail.activity_share.image, '" mode="aspectFit"></image>\n        </view>\n        <view class="content">\n          <text class="send-title-text">').concat(this.data.detail.activity_share.title, '</text>\n          <view class="footer">\n            <view class="footer-left">\n              <text class="footer-title">长按识别小程序码</text>\n              <text class="footer-desc">引领身心健康的生活方式</text>\n            </view>\n            <image class="footer-img" src="').concat(this.data.qrCode, '" />\n          </view>\n        </view>\n      </view>\n      ');
        this.widget.renderToCanvas({
            wxml: t,
            style: {
                container: {
                    width: 325,
                    height: 460,
                    backgroundColor: "#FFFFFF",
                    borderRadius: 2
                },
                sendBanner: {
                    width: 325,
                    height: 300
                },
                sendBannerImg: {
                    width: 325,
                    height: 300
                },
                content: {
                    width: 325,
                    height: 160,
                    paddingLeft: 20,
                    paddingRight: 20,
                    paddingTop: 16,
                    paddingBottom: 0
                },
                sendTitleText: {
                    width: 285,
                    height: 48,
                    fontSize: 15,
                    color: "#1A1A1A"
                },
                footer: {
                    width: 285,
                    height: 56,
                    flexDirection: "row",
                    justifyContent: "space-between",
                    alignItems: "center"
                },
                footerLeft: {
                    width: 220,
                    height: 56,
                    flexDirection: "column",
                    justifyContent: "space-around"
                },
                footerTitle: {
                    width: 220,
                    height: 28,
                    lineHeight: 28,
                    fontSize: 13,
                    color: "#1A1A1A"
                },
                footerDesc: {
                    width: 220,
                    height: 20,
                    lineHeight: 20,
                    fontSize: 11,
                    color: "#9D9D9D"
                },
                footerImg: {
                    width: 56,
                    height: 56,
                    borderRadius: 28
                }
            }
        }).then(function(t) {
            e.container = t;
        });
    },
    extraImage: function() {
        wx._trackEvent("clk_520_actPage_toMoments_savePic", {
            userid: getApp().globalData.user_id
        }), this.closeSendDialog();
        var e = this;
        this.widget.canvasToTempFilePath().then(function(t) {
            wx.saveImageToPhotosAlbum({
                filePath: t.tempFilePath,
                success: function(e) {
                    wx.showToast({
                        title: "保存成功"
                    });
                },
                fail: function() {
                    wx.showModal({
                        title: "提示",
                        content: "需要您授权保存相册",
                        showCancel: !1,
                        success: function() {
                            wx.openSetting({
                                success: function(e) {
                                    e.authSetting["scope.writePhotosAlbum"] ? wx.showModal({
                                        title: "提示",
                                        content: "获取权限成功,再次保存图片即可成功",
                                        showCancel: !1
                                    }) : wx.showModal({
                                        title: "提示",
                                        content: "获取权限失败，无法保存到相册",
                                        showCancel: !1
                                    });
                                },
                                complete: function(e) {}
                            });
                        }
                    });
                },
                complete: function() {
                    e.setData({
                        isScroll: !1,
                        sendDialogVisible: !1
                    });
                }
            });
        });
    },
    lookMore: function() {
        var e = this.data.detail, t = e.now;
        if (e.shop.length) (0, u.goto)("/pages/saleIndex/saleIndex?id=".concat(this.options.id)); else switch (Number(t.product_type)) {
          case 1:
            (0, u.goto)("/pages/evaluationCategory/evaluationCategory");
            break;

          case 6:
            (0, u.goto)("/pages/meditationCategory/meditationCategory");
            break;

          case 4:
            (0, u.goto)("/pages/exercise/exercise");
        }
    }
});