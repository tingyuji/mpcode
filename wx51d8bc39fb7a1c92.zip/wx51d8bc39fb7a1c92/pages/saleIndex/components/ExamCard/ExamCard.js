var t, e = require("../../../../@babel/runtime/helpers/defineProperty"), a = require("../../../../utils/index"), i = getApp();

Component((e(t = {
    options: {
        addGlobalClass: !0
    },
    properties: {
        target: {
            type: Object
        },
        showBtn: {
            type: Boolean
        },
        tagShow: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        itemImage: ""
    },
    lifetimes: {
        attached: function() {
            this.data.target ? ("0.00" == this.data.target.dot_show ? this.setData({
                dotShow: "小程序可用"
            }) : this.setData({
                price: !1
            }), this.setData({
                itemImage: this.data.target.mp_img_show ? this.data.target.mp_img_show : this.data.target.image_show
            })) : this.setData({
                dotShow: ""
            });
        }
    }
}, "data", {
    isIos: i.globalData.systemInfo.isIos,
    dotShow: "",
    price: !0
}), e(t, "methods", {
    handler: function() {
        var t = this.data.target, e = t.product_id, i = t.product_type;
        switch (wx._trackEvent("clk_mini_1to1_receive_actPage_viewTest", {
            userid: getApp().globalData.user_id,
            test_id: e
        }), Number(i)) {
          case 1:
            (0, a.goto)("/pages/evaluationDetail/evaluationDetail?id=".concat(e));
            break;

          case 6:
            (0, a.goto)("/pages/meditationDetail/meditationDetail?id=".concat(e));
            break;

          case 4:
            (0, a.goto)("/pages/exerciseDetail/exerciseDetail?id=".concat(e));
        }
    }
}), t));