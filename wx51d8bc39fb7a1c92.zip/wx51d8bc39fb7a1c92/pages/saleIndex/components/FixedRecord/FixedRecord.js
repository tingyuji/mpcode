var e = require("../../../../utils/index");

Component({
    properties: {},
    data: {},
    methods: {
        toRecrod: function() {
            wx._trackEvent("clk_1to1_polyPage_record", {
                userid: getApp().globalData.user_id
            }), (0, e.goto)("/pages/saleRecord/saleRecord");
        }
    }
});