Component({
    options: {
        addGlobalClass: !0
    },
    properties: {
        give_limit: {
            type: [ String, Number ],
            value: "1"
        },
        giver: {
            type: [ String, Number ],
            value: 0
        },
        user_limit: {
            type: [ String, Number ],
            value: "100"
        }
    },
    data: {
        dialogVisible: !1
    },
    methods: {
        changeDialog: function() {
            wx._trackEvent("clk_mini_1to1_receive_actPage_rule", {
                userid: getApp().globalData.user_id
            }), this.setData({
                dialogVisible: !this.data.dialogVisible
            });
        }
    }
});