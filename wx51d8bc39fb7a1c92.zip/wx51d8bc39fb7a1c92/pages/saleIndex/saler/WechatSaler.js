var e = require("../../../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var r = require("../../../@babel/runtime/helpers/createClass"), t = require("../../../@babel/runtime/helpers/classCallCheck"), i = require("../../../@babel/runtime/helpers/inherits"), l = require("../../../@babel/runtime/helpers/createSuper"), a = function(e) {
    i(u, e);
    var a = l(u);
    function u(e) {
        var r, i = e.detail, l = e.now, s = e.onUpdate, n = e.isHelper;
        return t(this, u), (r = a.call(this)).detail = i, r.now = l, r.onUpdate = s, r.isHelper = n, 
        r.init(), r;
    }
    return r(u);
}(e(require("./ISaler")).default);

exports.default = a;