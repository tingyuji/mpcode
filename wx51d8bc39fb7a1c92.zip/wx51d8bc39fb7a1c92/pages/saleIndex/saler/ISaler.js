Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = exports.STOCK_NULL = exports.STOCK_NORMAL = exports.ENUM_SHARE_SUCCESS = exports.ENUM_SHARE = exports.ASSIST_SUCCESS = exports.ASSIST_ING = exports.ACTIVITY_NO_START = exports.ACTIVITY_ING = exports.ACTIVITY_FINISH = void 0;

var t, e, s = require("../../../@babel/runtime/helpers/classCallCheck"), i = require("../../../@babel/runtime/helpers/createClass"), n = require("../../../@babel/runtime/helpers/defineProperty");

exports.ACTIVITY_ING = 1;

exports.ACTIVITY_FINISH = 2;

exports.ACTIVITY_NO_START = 4;

exports.STOCK_NORMAL = 8;

exports.STOCK_NULL = 16;

exports.ASSIST_SUCCESS = 32;

exports.ASSIST_ING = 64;

exports.ENUM_SHARE_SUCCESS = 128;

exports.ENUM_SHARE = 256;

var a = Symbol("btn"), r = (n(t = {}, 4, "活动未开始 · 距离赠送开始"), n(t, 2, "十分抱歉，由于相关规定，您暂时无法在小程序使用该功能"), 
n(t, 1, "赠送进行中，距离赠送结束"), t), o = (n(e = {}, 4, "no"), n(e, 2, "finish"), n(e, 1, "ing"), 
e), h = function() {
    function t() {
        var e;
        s(this, t), this.isHelper = !1, this.detail = {}, this.now = Math.floor(Date.now() / 1e3), 
        this.onUpdate = function() {}, this.timer = null, this.countDown = null, this.activityStatus = null, 
        this.stockStatus = null, this.assistStatus = null, this.shareStatus = null, this[a] = (n(e = {}, 300, []), 
        n(e, 332, []), n(e, 308, []), n(e, 340, []), n(e, 329, [ {
            text: "赠送给好友",
            class: "black",
            weChat: {
                btnOpenType: "share"
            },
            handler: "shareFriend"
        }, {
            text: "保存图片发到微信群",
            class: "white",
            handler: "shareMoment"
        } ]), n(e, 169, [ {
            text: "领取成功",
            class: "black",
            handler: "toDetail"
        } ]), n(e, 297, [ {
            text: "赠送成功,开始体验",
            class: "black",
            handler: "receive"
        } ]), n(e, 337, [ {
            text: "活动库存为0,请查看其他活动",
            class: "black",
            handler: "toHome"
        } ]), n(e, 305, [ {
            text: "活动库存为0,请查看其他活动",
            class: "black",
            handler: "toHome"
        } ]), n(e, 177, [ {
            text: "十分抱歉，由于相关规定，您暂时无法在小程序使用该功能",
            class: "black",
            handler: "toHome"
        } ]), n(e, 330, [ {
            class: "black",
            text: "来晚啦，我也要领福利",
            handler: "toDetail"
        } ]), n(e, 298, [ {
            text: "赠送成功,开始体验",
            class: "black",
            handler: "receive"
        } ]), n(e, 338, [ {
            text: "活动结束,请下次再参与",
            class: "black",
            handler: ""
        } ]), n(e, 306, [ {
            text: "赠送成功,开始体验",
            class: "black",
            handler: "receive"
        } ]), e);
    }
    return i(t, [ {
        key: "btns",
        get: function() {
            var t = this.activityStatus | this.stockStatus | this.assistStatus | this.shareStatus;
            return this[a][t];
        }
    }, {
        key: "headerText",
        get: function() {
            return r[this.activityStatus];
        }
    }, {
        key: "status",
        get: function() {
            return o[this.activityStatus];
        }
    }, {
        key: "isFinish",
        get: function() {
            return 2 === this.activityStatus;
        }
    }, {
        key: "init",
        value: function() {
            var t = this;
            this.initStatus(), this.checkCountDown(), setTimeout(function() {
                t.onUpdate();
            });
        }
    }, {
        key: "initStatus",
        value: function() {
            this.activityStatus = this.checkStart(), this.stockStatus = this.checkStock(), this.assistStatus = this.checkAssist(), 
            this.shareStatus = this.checkShare();
        }
    }, {
        key: "checkShare",
        value: function() {
            return this.detail.now && 2 === this.detail.now.share.status ? 128 : 256;
        }
    }, {
        key: "checkStart",
        value: function() {
            if (this.isHelper) {
                var t = this.detail.now.share.expired_time;
                return this.now >= t ? 2 : 1;
            }
            var e = this.detail, s = e.begin_time, i = e.end_time;
            return this.now < s ? 4 : this.now >= i ? 2 : 1;
        }
    }, {
        key: "checkStock",
        value: function() {
            var t = this.detail.now || {};
            return t.num - t.use_num > 0 ? 8 : 16;
        }
    }, {
        key: "checkAssist",
        value: function() {
            var t = this.detail.now || {}, e = t.help_num, s = t.help_user;
            return e = e || 0, (s = s || []).length > 0 && e === s.length ? 32 : 64;
        }
    }, {
        key: "checkCountDown",
        value: function() {
            var t;
            t = this.isHelper ? this.computeReceiveCountDown() : this.computeActivityCountDown(), 
            this.startCountDown(t);
        }
    }, {
        key: "computeActivityCountDown",
        value: function() {
            var t, e = this.detail, s = e.end_time, i = e.begin_time;
            if (this.now < i) t = i - this.now; else if (this.now >= i && this.now < s) if (this.detail.now) {
                var n = this.detail.now.share.expired_time;
                t = this.now >= n ? 0 : n - this.now;
            } else t = s - this.now; else t = 0;
            return t;
        }
    }, {
        key: "computeReceiveCountDown",
        value: function() {
            var t = this.detail.now.share.expired_time - this.now;
            return t > 0 ? t : 0;
        }
    }, {
        key: "startCountDown",
        value: function(t) {
            var e = this;
            clearTimeout(this.timer), this.timer = setTimeout(function() {
                e.now += 1, e.countDown = t, e.onUpdate(), e.initStatus(), t ? e.checkCountDown() : clearTimeout(e.timer);
            }, 1e3);
        }
    }, {
        key: "clearTimer",
        value: function() {
            clearTimeout(this.timer);
        }
    } ]), t;
}();

exports.default = h;