var e = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/regenerator")), t = require("../../@babel/runtime/helpers/asyncToGenerator"), n = require("../../api/index"), a = require("../../utils/index"), i = require("../../utils/dataCollect"), r = require("../../utils/enum"), s = require("../../utils/loginState"), o = getApp();

Page({
    data: {
        userInfo: {},
        uid: "",
        bannerList: [],
        time: 0,
        hasUserInfo: !1,
        together: {
            article_follow_count: 0,
            article_zan_count: 0,
            category_follow_count: 0
        },
        meditation: {
            days: 0,
            count: 0,
            star_count: 0
        },
        exam: {
            count: 0,
            finish_num: 0,
            star_num: 0
        }
    },
    onLoad: function(e) {
        this.initBanner();
    },
    onShow: function() {
        if (wx.getStorageSync(r.KY_WEAPP_TOKEN)) {
            var e = JSON.parse(wx.getStorageSync(r.KY_WEAPP_USER_INFO));
            this.setData({
                userInfo: e,
                hasUserInfo: !0
            }), this.init();
        }
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        var e = wx._getUserInfo();
        return {
            title: "".concat(e ? e.nickname : "好友", "邀请你来体验心理百科小程序，体验多种心理自助工具")
        };
    },
    init: function() {
        var a = this;
        return t(e.default.mark(function t() {
            var i, r, s, o, c, u, l, d;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.prev = 0, i = {
                        autoLoading: !1
                    }, e.next = 4, n.wxService.getAppUserHome(i);

                  case 4:
                    r = e.sent, s = r.id, r.create_time, o = r.first_login_days, c = r.home, u = c.together, 
                    l = c.meditation, d = c.exam, wx.setStorageSync("ky_app_exam", d), a.setData({
                        uid: s,
                        time: o,
                        together: u,
                        meditation: l,
                        exam: d
                    }), e.next = 16;
                    break;

                  case 14:
                    e.prev = 14, e.t0 = e.catch(0);

                  case 16:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 0, 14 ] ]);
        }))();
    },
    initBanner: function() {
        var a = this;
        return t(e.default.mark(function t() {
            var i, s;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.prev = 0, i = {
                        autoLoading: !1
                    }, e.next = 4, n.wxService.findBannerList(r.ENUM_BANNER_MINE, i);

                  case 4:
                    s = e.sent, a.setData({
                        bannerList: s
                    }), e.next = 10;
                    break;

                  case 8:
                    e.prev = 8, e.t0 = e.catch(0);

                  case 10:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 0, 8 ] ]);
        }))();
    },
    getUserInfo: function() {
        (0, a.goto)("/pages/login/login");
    },
    handleGoEncyclopedia: function(n) {
        return t(e.default.mark(function t() {
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.next = 2, (0, s.loginState)();

                  case 2:
                    if (e.sent) {
                        e.next = 5;
                        break;
                    }
                    return e.abrupt("return");

                  case 5:
                    wx._trackEvent("clk_mini_mine_main_bookPage", {
                        userid: o.globalData.user_id
                    }), (0, i.setListData)({
                        url: "/pages/myEncyclopedia/myEncyclopedia"
                    }), wx.navigateTo({
                        url: "../myEncyclopedia/myEncyclopedia"
                    });

                  case 8:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    handleGoMeditation: function(n) {
        return t(e.default.mark(function t() {
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.next = 2, (0, s.loginState)();

                  case 2:
                    if (e.sent) {
                        e.next = 5;
                        break;
                    }
                    return e.abrupt("return");

                  case 5:
                    wx._trackEvent("clk_mini_mine_main_mediPage", {
                        userid: o.globalData.user_id
                    }), (0, i.setListData)({
                        url: "/pages/myMeditation/myMeditation"
                    }), wx.navigateTo({
                        url: "../myMeditation/myMeditation"
                    });

                  case 8:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    handleGoAssessment: function(n) {
        return t(e.default.mark(function t() {
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.next = 2, (0, s.loginState)();

                  case 2:
                    if (e.sent) {
                        e.next = 5;
                        break;
                    }
                    return e.abrupt("return");

                  case 5:
                    wx._trackEvent("clk_mini_mine_main_testPage", {
                        userid: o.globalData.user_id
                    }), (0, i.setListData)({
                        url: "/pages/myAssessment/myAssessment"
                    }), wx.navigateTo({
                        url: "../myAssessment/myAssessment"
                    });

                  case 8:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    handleGoIssues: function() {
        wx._trackEvent("clk_mini_mine_main_app_wechat_feedback", {
            userid: o.globalData.user_id
        }), (0, a.goto)("/pages/issues/issues");
    },
    loginSuccess: function(e) {
        var t = e.currentTarget.dataset.index;
        switch (Number(t)) {
          case 0:
            this.handleGoEncyclopedia(e);
            break;

          case 1:
            this.handleGoMeditation(e);
            break;

          case 2:
            this.handleGoAssessment(e);
        }
    },
    toApp: function() {
        wx._trackEvent("clk_mini_mine_main_app_wechat_feedback", {
            userid: o.globalData.user_id
        }), wx.showModal({
            title: "温馨提示",
            content: "十分抱歉，由于相关规定，您暂时无法在小程序使用该功能",
            showCancel: !1,
            confirmText: "知道了",
            confirmColor: "#07c160"
        });
    },
    toKy: function() {
        wx._trackEvent("clk_mini_mine_main_app_wechat_feedback", {
            userid: o.globalData.user_id
        }), (0, a.goto)("/pages/customer/customer?active=0");
    },
    handleClickSwiper: function(e) {
        var t = e.detail;
        wx._trackEvent("clk_mini_mine_main_ad", {
            userid: o.globalData.user_id,
            mine_ad_id: t.id
        });
    },
    goDaySign: function() {
        (0, a.goto)("/pages/daySign/daySign");
    }
});