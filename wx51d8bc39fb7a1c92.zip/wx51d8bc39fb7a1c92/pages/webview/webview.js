var e = require("../../utils/goto"), t = require("../../utils/enum");

getApp();

Page({
    data: {
        url: ""
    },
    onLoad: function(e) {
        this.init(e);
    },
    init: function(e) {
        var t = e.url, o = decodeURIComponent(t), n = this.checkKy(o);
        this.setData({
            url: n
        });
    },
    checkKy: function(o) {
        if (/(knowyourself.cc||zhiwotansuo.cc)/g.test(o)) {
            var n = wx.getStorageSync(t.KY_WEAPP_TOKEN), i = {
                topsession: encodeURIComponent(n)
            };
            return (0, e.addParams)(o, i);
        }
        return console.log(o), o;
    },
    handleMessage: function(e) {
        console.log(e);
    }
});