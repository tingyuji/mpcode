var e = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/regenerator")), t = require("../../@babel/runtime/helpers/asyncToGenerator"), r = require("../../utils/index"), n = require("../../api/index");

Page({
    data: {
        list: [],
        activeId: null
    },
    onLoad: function(e) {
        this.init();
    },
    onShareAppMessage: function() {
        var e = wx._getUserInfo();
        return {
            title: "".concat(e ? e.nickname : "好友", "邀请你来体验心理百科小程序，体验多种心理自助工具")
        };
    },
    init: function() {
        var r = this;
        return t(e.default.mark(function t() {
            var a, i;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.next = 2, n.dpService.getGuidance();

                  case 2:
                    a = e.sent, i = a.list, r.setData({
                        list: i
                    });

                  case 5:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    onChange: function(e) {
        var t = e.currentTarget.dataset.item.id, r = this.data.activeId;
        this.setData({
            activeId: t === r ? null : t
        });
    },
    toDpRecommend: function() {
        var e = this.data.activeId;
        e && (0, r.goto)("/pages/exerciseRecommend/exerciseRecommend?id=".concat(e));
    }
});