var e = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/regenerator")), t = require("../../@babel/runtime/helpers/slicedToArray"), i = require("../../@babel/runtime/helpers/asyncToGenerator"), a = require("../../utils/index"), n = require("../../api/index"), r = require("../../utils/enum"), o = getApp();

Page({
    data: {
        bannerList: [],
        meditationList: [],
        evaluationList: [],
        exerciseList: [],
        consults: []
    },
    onLoad: function(e) {
        this.init();
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        var e = wx._getUserInfo();
        return {
            title: "".concat(e ? e.nickname : "好友", "邀请你来体验心理百科小程序，体验多种心理自助工具")
        };
    },
    init: function() {
        var a = this;
        return i(e.default.mark(function i() {
            var o, l, s, c, u, d, _, g, m;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.prev = 0, o = {
                        autoLoading: !1
                    }, e.next = 4, Promise.all([ n.wxService.findBannerList(r.ENUM_BANNER_TOOLS, o), n.wxService.getHomeResource(o) ]);

                  case 4:
                    l = e.sent, s = t(l, 2), c = s[0], u = s[1], d = u.meditations, _ = u.plans, g = u.exams, 
                    m = u.consults, a.setData({
                        bannerList: c,
                        meditationList: d,
                        evaluationList: g.map(function(e) {
                            return Object.assign({}, e, {
                                categoriesStr: e.category ? e.category.title : "",
                                image: e.operation_img_show,
                                target_id: e.id
                            });
                        }),
                        exerciseList: _.map(function(e) {
                            return Object.assign({}, e, {
                                target_id: e.id
                            });
                        }),
                        consults: m
                    }), e.next = 15;
                    break;

                  case 12:
                    e.prev = 12, e.t0 = e.catch(0), console.error(e.t0);

                  case 15:
                  case "end":
                    return e.stop();
                }
            }, i, null, [ [ 0, 12 ] ]);
        }))();
    },
    handleClickSwiper: function(e) {
        var t = e.detail;
        wx._trackEvent("clk_mini_tool_main_ad", {
            userid: o.globalData.user_id,
            tool_ad_id: t.id
        });
    },
    gomeditationAll: function() {
        wx._trackEvent("clk_mini_tool_main_medi", {
            userid: o.globalData.user_id,
            medi_id: -1
        }), (0, a.goto)("/pages/meditationCategory/meditationCategory");
    },
    gomeditationDetail: function(e) {
        var t = e.currentTarget.dataset.item, i = t.id, n = (t.course_id, t.mode);
        wx._trackEvent("clk_mini_tool_main_medi", {
            userid: o.globalData.user_id,
            medi_id: i
        }), n === r.ENUM_MEDITATION_SERIES ? (0, a.goto)("/pages/meditationDetail/meditationDetail?id=".concat(i)) : (0, 
        a.goto)("/pages/player/player?courseId=".concat(i));
    },
    goEvaluationAll: function() {
        wx._trackEvent("clk_mini_tool_main_test", {
            userid: o.globalData.user_id,
            test_id: -1
        }), (0, a.goto)("../evaluationCategory/evaluationCategory");
    },
    goEvaluationDetail: function(e) {
        var t = e.currentTarget.dataset.item;
        wx._trackEvent("clk_mini_tool_main_test", {
            userid: o.globalData.user_id,
            test_id: t.id
        });
    },
    goExerciseAll: function() {
        wx._trackEvent("clk_mini_tool_main_prac", {
            userid: o.globalData.user_id,
            prac_id: -1
        }), (0, a.goto)("/pages/exercise/exercise");
    },
    goExerciseDetail: function(e) {
        var t = e.currentTarget.dataset.item;
        wx._trackEvent("clk_mini_tool_main_prac", {
            userid: o.globalData.user_id,
            prac_id: t.id
        });
    },
    goTalkMoreDetail: function(e) {
        var t = e.currentTarget.dataset.item;
        wx._trackEvent("clk_mini_tool_main_heal", {
            userid: o.globalData.user_id,
            heal_id: t.id
        }), (0, a.goto)(t.url);
    },
    toTalkMore: function() {
        (0, a.goto)("/pages/talkMore/talkMore");
    }
});