var e = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/regenerator")), t = require("../../@babel/runtime/helpers/asyncToGenerator"), n = require("../../utils/goto"), r = require("../../api/index"), a = require("../../utils/enum"), i = getApp();

Page({
    data: {
        hasUserInfo: !1,
        is_registered: null,
        tipsVisible: !1,
        checkState: !1
    },
    onLoad: function(e) {},
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        var e = wx._getUserInfo();
        return {
            title: "".concat(e ? e.nickname : "好友", "邀请你来体验心理百科小程序，体验多种心理自助工具"),
            path: "/pages/index/index"
        };
    },
    getPhoneNumber: function(e) {},
    handleGoBack: function() {
        wx._trackEvent("clk_mini_mine_verify_cancel", {
            userid: i.globalData.user_id
        }), (0, n.goto)();
    },
    handleChangeTips: function() {
        wx._trackEvent("clk_mini_mine_verify_more", {
            userid: i.globalData.user_id
        }), this.setData({
            tipsVisible: !this.data.tipsVisible
        });
    },
    loginFun: function() {
        var n = this;
        return t(e.default.mark(function t() {
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (n.data.checkState) {
                        e.next = 3;
                        break;
                    }
                    return wx.showToast({
                        title: "请先阅读并同意月食 隐私政策",
                        icon: "none"
                    }), e.abrupt("return");

                  case 3:
                    if (wx.getStorageSync(a.KY_WEAPP_SESSION_KEY)) {
                        e.next = 7;
                        break;
                    }
                    return e.next = 7, n.login();

                  case 7:
                    n.loginSuccess();

                  case 8:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    login: function() {
        var n = this;
        return new Promise(function() {
            var r = t(e.default.mark(function r(a, i) {
                return e.default.wrap(function(r) {
                    for (;;) switch (r.prev = r.next) {
                      case 0:
                        try {
                            n.data.code || wx.login({
                                success: function(e) {
                                    e.code && n.setData({
                                        code: e.code
                                    });
                                }
                            }), wx.getUserProfile({
                                desc: "用于完善资料",
                                success: function() {
                                    var r = t(e.default.mark(function t(r) {
                                        return e.default.wrap(function(e) {
                                            for (;;) switch (e.prev = e.next) {
                                              case 0:
                                                return n.setData({
                                                    loginInfo: r
                                                }), e.next = 3, n.getToken();

                                              case 3:
                                                a();

                                              case 4:
                                              case "end":
                                                return e.stop();
                                            }
                                        }, t);
                                    }));
                                    return function(e) {
                                        return r.apply(this, arguments);
                                    };
                                }()
                            });
                        } catch (e) {
                            console.error("initLogin error=", e), i(e);
                        }

                      case 1:
                      case "end":
                        return r.stop();
                    }
                }, r);
            }));
            return function(e, t) {
                return r.apply(this, arguments);
            };
        }());
    },
    getToken: function() {
        var n = this;
        return new Promise(function() {
            var o = t(e.default.mark(function t(o, c) {
                var s, u, l, f, d, g, p, h, k, S, _;
                return e.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (e.prev = 0, s = n.data, u = s.loginInfo, l = s.code, !u) {
                            e.next = 19;
                            break;
                        }
                        return f = {
                            code: l,
                            source: "10",
                            encryptedData: u.encryptedData,
                            iv: u.iv,
                            rawData: u.rawData,
                            signature: u.signature
                        }, e.next = 6, r.loginService.getWxToken(f);

                      case 6:
                        return d = e.sent, wx.setStorageSync(a.KY_WEAPP_SESSION_KEY, d.token), e.next = 10, 
                        r.loginService.userLogin({
                            token: d.token
                        });

                      case 10:
                        g = e.sent, g.is_registered, p = g.token, h = g.user, wx.setStorageSync(a.KY_WEAPP_IS_REGISTERED, !0), 
                        p && (i.globalData.user_id = k, k = h.id, S = h.avatar, _ = h.nickname, wx.setStorageSync(a.KY_WEAPP_USER_INFO, JSON.stringify({
                            id: k,
                            avatar: S,
                            nickname: _
                        })), wx.setStorageSync(a.KY_WEAPP_TOKEN, p)), o(), e.next = 20;
                        break;

                      case 19:
                        c("初始化用户Token失败");

                      case 20:
                        e.next = 27;
                        break;

                      case 22:
                        e.prev = 22, e.t0 = e.catch(0), n.setData({
                            code: null
                        }), console.error("初始化用户Token失败=", e.t0), c(e.t0);

                      case 27:
                      case "end":
                        return e.stop();
                    }
                }, t, null, [ [ 0, 22 ] ]);
            }));
            return function(e, t) {
                return o.apply(this, arguments);
            };
        }());
    },
    loginSuccess: function() {
        this.setData({
            hasUserInfo: !0
        });
        var e = wx.getStorageSync(a.KY_WEAPP_IS_REGISTERED) || !1;
        this.setData({
            is_registered: e
        }), e && this.handleGoBack();
    },
    checkPolicyFun: function() {
        this.setData({
            checkState: !this.data.checkState
        });
    },
    toPolicyFun: function() {
        (0, n.goto)("https://kyapp.knowyourself.cc/privacyPolicy");
    }
});