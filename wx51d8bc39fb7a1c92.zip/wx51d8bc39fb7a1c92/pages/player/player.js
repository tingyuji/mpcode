var t = require("../../@babel/runtime/helpers/interopRequireWildcard"), e = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/regenerator")), a = require("../../@babel/runtime/helpers/objectSpread2"), i = require("../../@babel/runtime/helpers/asyncToGenerator"), n = require("../../config/meditation"), s = t(require("../../libs/bgaudio")), o = require("../../utils/enum"), r = require("../../api/index"), u = require("../../utils/index"), d = getApp(), c = {
    title: "该音频可在月食app免费体验",
    content: "进入客服消息，回复1即可下载",
    cancelText: "取消",
    confirmText: "点击进入"
}, l = "";

Page({
    data: {
        leftBtn: [],
        detail: {},
        show: !0,
        duration: "",
        currentTime: "00:00",
        paused: !1,
        waiting: !1,
        process: 0,
        isDialog: !1,
        dialog: {},
        isPoster: !1,
        posterData: null,
        shareData: "",
        isNew: !1
    },
    onLoad: function(t) {
        this.options = t, this.init();
    },
    onShow: function() {
        var t = this;
        setTimeout(function() {
            !1 === wx.getBackgroundAudioManager().paused ? (s.audioData.isPlay = !0, s.default.backData(t.update)) : t.setData({
                paused: !s.audioData.isPlay
            });
        }, 300);
    },
    onShareAppMessage: function() {
        var t = wx._getUserInfo(), e = this.data.shareData;
        return {
            title: "".concat(t ? t.nickname : "好友", "正在听【").concat(e.title, "】，也推荐给你！"),
            imageUrl: e.image || "../../assets/img/meditationShare.jpg"
        };
    },
    init: function() {
        this.initBtn(), l = this, this.options.continue ? (this.data.isNew = !0, this.echoDataFun(s.audioData)) : (this.data.isNew = !1, 
        this.initMeditation()), this.gitShareInfo();
    },
    echoDataFun: function(t) {
        var e = t.showDuration, a = t.info, i = t.isPlay, n = t.process;
        this.setData({
            duration: e,
            detail: a,
            paused: !i,
            process: n
        }), s.default.backData(this.update);
    },
    initMeditation: function() {
        var t = this;
        return i(e.default.mark(function i() {
            var n, o, d, c, l;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return n = t.options, o = n.courseId, d = n.lessonId, c = {
                        course_id: o,
                        lesson_id: d
                    }, e.next = 4, r.meditationService.getLesson(c);

                  case 4:
                    l = e.sent, t.setData({
                        detail: a(a({}, l), {}, {
                            _listenCount: 0
                        })
                    }), l.src ? (s.default.stop(), setTimeout(function() {
                        t.setData({
                            duration: (0, u.timeToStr)(l.duration),
                            paused: !0,
                            waiting: !1,
                            currentTime: "00:00",
                            process: 0
                        }), s.default.setData(l);
                    }, 400)) : (t.setData({
                        show: !1
                    }), t.showCustomer());

                  case 7:
                  case "end":
                    return e.stop();
                }
            }, i);
        }))();
    },
    initBtn: function() {
        this.setData({
            leftBtn: [ {
                icon: "icon-shut-down",
                handler: this.shutDown
            }, {
                icon: "icon-arrow-down-s-line",
                handler: this.back
            } ]
        });
    },
    update: function(t) {
        this.isChanging || l.setData({
            currentTime: t.currentTime,
            process: t.process,
            paused: !t.isPlay
        });
    },
    shutDown: function() {
        wx._trackEvent("clk_mini_medi_audio_play_mini", {
            userid: d.globalData.user_id
        }), this.back(), s.default.stop(), s.default.hide();
    },
    back: function() {
        wx._trackEvent("clk_mini_medi_audio_play_quit", {
            userid: d.globalData.user_id
        }), getCurrentPages().length > 1 ? (0, u.goto)() : (0, u.goto)("/pages/index/index");
    },
    togglePoster: function() {
        var t = this.data.isPoster;
        this.setData({
            isPoster: !t
        });
    },
    collect: function() {
        var t = this;
        return i(e.default.mark(function a() {
            var i, n, s, o, u, c, l, h, p;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return wx._trackEvent("clk_mini_medi_audio_play_favor", {
                        userid: d.globalData.user_id
                    }), i = t.data.detail, n = i.course_id, s = i.is_star, o = i.id, c = {
                        course_id: n,
                        lesson_id: o,
                        is_star: u = !s
                    }, e.next = 6, r.meditationService.starMeditation(c);

                  case 6:
                    l = e.sent, h = l.updated, p = u ? "收藏成功" : "取消收藏", h && (wx.showToast({
                        title: p,
                        icon: "none"
                    }), t.setData({
                        "detail.is_star": u
                    }));

                  case 10:
                  case "end":
                    return e.stop();
                }
            }, a);
        }))();
    },
    toggle: function() {
        wx.getStorageSync(o.KY_WEAPP_TOKEN) ? (wx._trackEvent("clk_mini_medi_audio_play_pause_play", {
            userid: d.globalData.user_id
        }), this.data.waiting ? wx.showToast({
            title: "音频加载中请稍后",
            icon: "none"
        }) : (this.data.paused && this.data.process ? this.change({
            detail: {
                value: this.data.process
            }
        }) : this.pagePlay(), this.setData({
            paused: !this.data.paused
        }))) : (0, u.goto)("/pages/login/login");
    },
    pagePlay: function() {
        var t = this;
        s.default.audioPlay(this.data.paused), setTimeout(function() {
            s.default.backData(t.update), s.default.onEnded(t.audioEnded);
        }, 100);
    },
    showCustomer: function() {
        var t = this;
        this.setData({
            isDialog: !0,
            dialog: a(a({}, c), {}, {
                onCancel: function() {
                    wx._trackEvent("clk_mini_medi_audio_play_cancel", {
                        userid: d.globalData.user_id
                    }), t.setData({
                        isDialog: !1
                    });
                },
                confirmButton: {
                    openType: "contact"
                },
                onConfirm: function() {
                    wx._trackEvent("clk_mini_medi_audio_play_download", {
                        userid: d.globalData.user_id
                    });
                }
            })
        });
    },
    change: function(t) {
        var e = this;
        this.isChanging = !1;
        var a = t.detail.value;
        s.default.play(), setTimeout(function() {
            var t = s.audioData.duration, i = a / 100 * t;
            s.default.seek(i), s.default.backData(e.update), s.default.onEnded(e.audioEnded);
        }, 500);
    },
    handleChanging: function() {
        this.isChanging = !0;
    },
    audioEnded: function(t) {
        var e = s.audioData.info, i = e.course.scene, o = 400 * e.playTime, r = i !== n.SCENE_MEDITATION && o >= 6e4;
        l.setData({
            paused: !0
        }), r && l.setData({
            posterData: a({}, t.card)
        }, l.togglePoster);
    },
    gitShareInfo: function() {
        var t = this;
        return i(e.default.mark(function a() {
            var i, n;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return i = "", i = t.data.isNew ? t.data.detail.course_id : t.options.courseId, 
                    e.prev = 2, e.next = 5, r.meditationService.getshare(i);

                  case 5:
                    n = e.sent, t.data.shareData = n.share_data, e.next = 12;
                    break;

                  case 9:
                    e.prev = 9, e.t0 = e.catch(2), console.log(e.t0);

                  case 12:
                  case "end":
                    return e.stop();
                }
            }, a, null, [ [ 2, 9 ] ]);
        }))();
    }
});