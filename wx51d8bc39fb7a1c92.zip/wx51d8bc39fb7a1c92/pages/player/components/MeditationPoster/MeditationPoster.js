function t(t) {
    return t < 10 ? "0".concat(t) : t;
}

var e = getApp();

Component({
    options: {
        addGlobalClass: !0
    },
    properties: {
        target: {
            type: Object,
            value: {}
        }
    },
    data: {
        navHeight: e.globalData.navHeight,
        statusBarHeight: e.globalData.navTop,
        wxmlWidth: 654,
        wxmlHeight: 1068,
        src: null
    },
    lifetimes: {
        attached: function() {
            this.init();
        }
    },
    methods: {
        init: function() {
            var t = this;
            wx.showLoading({
                title: "生成中..."
            }), this.widget = this.selectComponent(".widget"), setTimeout(function() {
                t.renderToCanvas();
            }, 1e3);
        },
        renderToCanvas: function() {
            var e = this, i = this.data, n = i.target, o = i.wxmlHeight, a = i.wxmlWidth, c = n.title, s = n.lesson_title, l = n.xcx_qrcode, h = n.m_seconds, r = n.study_seconds, g = n.m_days, m = n.verse, w = m.author, d = m.content, f = n.image, x = n.isAudio, p = 32 * Math.ceil(22 * d.length / 368), b = o - 64 + p, u = Math.ceil(h / 60), v = g, T = Math.ceil(r / 60), D = wx._getUserInfo() || {}, C = D.avatar, A = D.nickname, y = new Date().getFullYear(), H = new Date().getMonth() + 1, S = new Date().getDate(), I = new Date().getHours(), B = new Date().getMinutes(), L = "".concat(y, "-").concat(t(H), "-").concat(t(S), " ").concat(t(I), ":").concat(t(B)), W = '<view class="container">\n        <image class="header" src="'.concat(f, '" mode=\'center\'></image>\n        <view class="user">\n          <image class="avatar" src="').concat(C, '"></image>\n          <text class="nickname">').concat(A, '</text>\n        </view>\n        <view class="tip">\n          <view class="tip-l">\n            <view class="tip-l-line"></view>\n            <text class="tip-l-text">我完成了</text>\n          </view>\n          <text class="tip-r">').concat(L, '</text>\n        </view>\n        <text class="title">').concat(s, "</text>\n        ").concat(x ? "" : '<text class="summary">「 '.concat(c, " 」</text>"), '\n        <view class="tab">\n          <view class="tab-item">\n            <text class="tab-item-top">本次冥想时长</text>\n            <view class="tab-item-bottom tab-item-bottom-left">\n              <text class="currentTime">').concat(T, '</text>\n              <text class="tab-item-bottom-title">分</text>\n            </view>\n          </view>\n          <view class="tab-item">\n            <text class="tab-item-top tab-item-top-center">累计练习冥想</text>\n            <view class="tab-item-bottom tab-item-bottom-center">\n              <text class="dayTime">').concat(v, '</text>\n              <text class="tab-item-bottom-title">天</text>\n            </view>\n          </view>\n          <view class="tab-item">\n            <text class="tab-item-top tab-item-top-right">累计冥想时长</text>\n            <view class="tab-item-bottom tab-item-bottom-right">\n              <text class="tab-item-bottom-title">分</text>\n              <text class="meditationTime">').concat(u, '</text>\n            </view>\n          </view>\n        </view>\n        \n        <view class="footer">\n          <view class="footer-l">\n            <text class="footer-l-text">').concat(d, '</text>\n            <text class="footer-l-author">- ').concat(w, '</text>\n          </view>\n          <image class="footer-r" src="').concat(l, '"></image>\n        </view>\n      </view>'), k = {
                container: {
                    width: a,
                    height: b,
                    backgroundColor: "#ffffff",
                    flexDirection: "column"
                },
                header: {
                    display: "block",
                    width: a,
                    height: 408
                },
                user: {
                    width: a,
                    height: 112,
                    marginTop: 16,
                    flexDirection: "row",
                    alignItems: "center",
                    paddingLeft: 40
                },
                avatar: {
                    display: "block",
                    width: 80,
                    height: 80,
                    borderRadius: 40,
                    overflow: "hidden"
                },
                nickname: {
                    width: 400,
                    height: 36,
                    lineHeight: 36,
                    fontWeigth: 500,
                    fontSize: 30,
                    color: "#1A1A1A",
                    marginLeft: 16
                },
                tip: {
                    width: a,
                    height: 64,
                    flexDirection: "row",
                    alignItems: "center",
                    justifyContent: "space-between",
                    paddingLeft: 40,
                    paddingRight: 40
                },
                tipL: {
                    width: 176,
                    height: 28,
                    flexDirection: "row",
                    alignItems: "center"
                },
                tipLLine: {
                    display: "block",
                    width: 8,
                    height: 24,
                    backgroundColor: "#B0D3DD",
                    marginRight: 16
                },
                tipLText: {
                    width: 140,
                    height: 28,
                    fontSize: 22,
                    fontWeight: 500,
                    color: "#3B3B3B",
                    lineHeight: 28
                },
                tipR: {
                    width: 206,
                    height: 28,
                    fontSize: 22,
                    fontWeight: 400,
                    color: "#C5C5C5",
                    lineHeight: 28,
                    textAlign: "right"
                },
                title: {
                    display: "block",
                    width: a,
                    height: 40,
                    marginTop: 16,
                    fontSize: 30,
                    fontWeight: 500,
                    color: "#1A1A1A",
                    lineHeight: 40,
                    textAlign: "center"
                },
                summary: {
                    display: "block",
                    width: a,
                    height: 32,
                    marginTop: 16,
                    fontSize: 22,
                    fontWeight: 400,
                    color: "#3B3B3B",
                    lineHeight: 32,
                    textAlign: "center"
                },
                tab: {
                    width: a,
                    height: 132,
                    marginTop: 32,
                    flexDirection: "row",
                    justifyContent: "space-around",
                    paddingLeft: 40,
                    paddingRight: 40
                },
                tabItem: {
                    width: 176,
                    height: 132,
                    flexDirection: "column"
                },
                tabItemTop: {
                    display: "block",
                    width: 176,
                    height: 28,
                    fontSize: 22,
                    fontWeight: 400,
                    color: "#9D9D9D",
                    lineHeight: 28,
                    marginTop: 16,
                    marginBottom: 24
                },
                tabItemTopCenter: {
                    textAlign: "center"
                },
                tabItemTopRight: {
                    textAlign: "right"
                },
                tabItemBottom: {
                    width: 176,
                    height: 48,
                    flexDirection: "row",
                    alignItems: "baseline"
                },
                tabItemBottomTitle: {
                    width: 22,
                    height: 28,
                    fontSize: 22,
                    fontWeight: 400,
                    color: "#9D9D9D",
                    lineHeight: 28
                },
                meditationTime: {
                    width: 32 * String(u).length,
                    height: 48,
                    fontSize: 48,
                    fontWeight: 500,
                    color: "#1A1A1A",
                    lineHeight: 48
                },
                currentTime: {
                    width: 32 * String(T).length,
                    height: 48,
                    fontSize: 48,
                    fontWeight: 500,
                    color: "#1A1A1A",
                    lineHeight: 48
                },
                dayTime: {
                    width: 32 * String(v).length,
                    height: 48,
                    fontSize: 48,
                    fontWeight: 500,
                    color: "#1A1A1A",
                    lineHeight: 48
                },
                tabItemBottomCenter: {
                    justifyContent: "center"
                },
                tabItemBottomRight: {
                    flexDirection: "row-reverse"
                },
                footer: {
                    width: a,
                    height: 112 + p,
                    paddingTop: 24,
                    paddingBottom: 24,
                    paddingLeft: 40,
                    paddingRight: 40,
                    flexDirection: "row",
                    justifyContent: "space-between",
                    alignItems: "center"
                },
                footerL: {
                    width: 368,
                    height: 64 + p,
                    flexDirection: "column"
                },
                footerLText: {
                    width: 368,
                    height: p,
                    lineHeight: 32,
                    fontSize: 22,
                    fontWeight: 400,
                    color: "#6C6C6C"
                },
                footerLAuthor: {
                    width: 368,
                    height: 32,
                    textAlign: "right",
                    fontSize: 22,
                    fontWeight: 400,
                    color: "#C5C5C5",
                    lineHeight: 32,
                    marginTop: 32
                },
                footerR: {
                    display: "block",
                    width: 128,
                    height: 128,
                    borderRadius: 8
                }
            };
            this.widget.renderToCanvas({
                wxml: W,
                style: k
            }).then(function(t) {
                e.widget.canvasToTempFilePath().then(function(t) {
                    e.setData({
                        src: t.tempFilePath
                    }), wx.hideLoading();
                });
            });
        },
        close: function() {
            this.triggerEvent("onClose");
        },
        extraImage: function() {
            var t = this.data.src;
            if (!t) return wx.showToast({
                title: "生成图片失败,请重试~",
                icon: "none"
            });
            wx.saveImageToPhotosAlbum({
                filePath: t,
                success: function(t) {
                    wx.showToast({
                        title: "保存成功"
                    });
                },
                fail: function() {
                    wx.showModal({
                        title: "提示",
                        content: "需要您授权保存相册",
                        showCancel: !1,
                        success: function() {
                            wx.openSetting({
                                success: function(t) {
                                    t.authSetting["scope.writePhotosAlbum"] ? wx.showModal({
                                        title: "提示",
                                        content: "获取权限成功,再次保存图片即可成功",
                                        showCancel: !1
                                    }) : wx.showModal({
                                        title: "提示",
                                        content: "获取权限失败，无法保存到相册",
                                        showCancel: !1
                                    });
                                }
                            });
                        }
                    });
                }
            });
        }
    }
});