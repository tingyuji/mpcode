Component({
    options: {
        addGlobalClass: !0
    },
    properties: {
        dialogVisible: {
            type: Boolean
        }
    },
    data: {},
    methods: {
        changeDialog: function() {
            this.triggerEvent("change");
        }
    }
});