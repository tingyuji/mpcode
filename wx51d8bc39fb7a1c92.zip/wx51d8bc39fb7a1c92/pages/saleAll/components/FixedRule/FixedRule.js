Component({
    options: {
        addGlobalClass: !0
    },
    properties: {},
    data: {
        dialogVisible: !1
    },
    methods: {
        changeDialog: function() {
            wx._trackEvent("clk_520_main_rule", {
                userid: getApp().globalData.user_id
            }), this.setData({
                dialogVisible: !this.data.dialogVisible
            });
        }
    }
});