var t = require("../../../../utils/index");

Component({
    properties: {
        target: {
            type: Object
        }
    },
    data: {},
    methods: {
        handler: function() {
            wx._trackEvent("clk_520_main_free_to2free", {
                userid: getApp().globalData.user_id,
                test_id: this.data.target.id
            }), (0, t.goto)("/pages/evaluationDetail/evaluationDetail?id=".concat(this.data.target.id));
        }
    }
});