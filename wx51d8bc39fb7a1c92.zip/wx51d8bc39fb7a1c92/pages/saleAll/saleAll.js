var t = require("../../@babel/runtime/helpers/interopRequireDefault"), e = t(require("../../@babel/runtime/regenerator")), n = require("../../@babel/runtime/helpers/slicedToArray"), i = require("../../@babel/runtime/helpers/asyncToGenerator"), a = require("../../api/index"), s = t(require("../../libs/scroller")), o = require("./vuefy"), r = require("../../utils/getTime"), c = require("../../utils/index"), l = (getApp(), 
1621871999e3);

function u(t) {
    var e = t;
    return e < 10 && e >= 0 && (e = "0".concat(e)), e;
}

function d(t) {
    if (!t) return {
        d: 0,
        h: 0,
        m: 0,
        s: 0
    };
    var e = new Date(t);
    return {
        d: Math.floor(e / 1e3 / 60 / 60 / 24),
        h: u(Math.floor(e / 1e3 / 60 / 60 % 24)),
        m: u(Math.floor(e / 1e3 / 60 % 60)),
        s: u(Math.floor(e / 1e3 % 60))
    };
}

Page({
    data: {
        scrollTop: 0,
        offsetTop: 0,
        activeIndex: 0,
        customScrollTop: 0,
        now: null,
        timer: null,
        timeLine: [ {
            end: "2021/05/17 23:59:59",
            text: "5.17",
            card: "<span>月食恋爱课堂开学练习测评免费领</span>"
        }, {
            end: "2021/05/19 23:59:59",
            text: "5.18-5.19",
            card: "<span>互换小哥哥茶会8.8折抢购</span>"
        }, {
            end: "2021/05/20 23:59:59",
            text: "5.20",
            card: "<span>恋爱测评免费领聊愈首单免费</span>"
        }, {
            end: "2021/05/21 23:59:59",
            text: "5.21",
            card: "<span>恋爱力up小课堂&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>"
        }, {
            end: "2021/05/22 23:59:59",
            text: "5.22",
            card: "<span>恋爱学院毕业典礼&nbsp;&nbsp;</span>"
        } ],
        tabs: [ {
            id: "subject-1",
            title: "免费领测试"
        }, {
            id: "subject-2",
            title: "良性依恋训练营"
        }, {
            id: "subject-3",
            title: "聊愈免费"
        }, {
            id: "subject-4",
            title: "月食恋爱课堂"
        }, {
            id: "subject-5",
            title: "茶会8.8折"
        } ],
        countDown: {
            d: 0,
            h: 0,
            m: 0,
            s: 0
        },
        courseList: [ {
            id: 1,
            end: "2021/5/17 23:59:59",
            image: "https://cdn.knowyourself.cc/together-wxapp/subject4-1.jpg",
            sImg: "https://cdn.knowyourself.cc/together-wxapp/subject4-1-small.jpg",
            count: 100,
            title: "入学仪式，我的恋爱自测",
            tip: "5.17开启"
        }, {
            id: 2,
            end: "2021/5/19 23:59:59",
            image: "https://cdn.knowyourself.cc/together-wxapp/subject4-2.jpg",
            sImg: "https://cdn.knowyourself.cc/together-wxapp/subject4-2-s.jpg",
            count: 100,
            title: "互换小哥哥",
            tip: "5.18开启"
        }, {
            id: 3,
            end: "2021/5/20 23:59:59",
            image: "https://cdn.knowyourself.cc/together-wxapp/subject4-3.jpg",
            sImg: "https://cdn.knowyourself.cc/together-wxapp/subject4-3-s.jpg",
            count: 100,
            title: "互助学习",
            tip: "5.20开启"
        }, {
            id: 4,
            end: "2021/5/21 23:59:59",
            image: "https://cdn.knowyourself.cc/together-wxapp/subject4-4.jpg",
            sImg: "https://cdn.knowyourself.cc/together-wxapp/subject4-4-s.jpg",
            count: 100,
            title: "恋爱力up课堂学习笔记",
            tip: "5.21开启"
        }, {
            id: 5,
            end: "2021/5/22 23:59:59",
            image: "https://cdn.knowyourself.cc/together-wxapp/subject4-5.jpg",
            sImg: "https://cdn.knowyourself.cc/together-wxapp/subject4-5-s.jpg",
            count: 100,
            title: "许下爱的心愿",
            tip: "5.22开启"
        } ],
        examTopList: [ {
            id: 238,
            title: "你的理想型男友趣味测试",
            summary: "测测最吸引你的男神是哪种类型？",
            image: "https://cdn.knowyourself.cc/2021520/1.jpg",
            price: 0,
            origin: "29.9",
            tag: "人气爆款",
            btn: "限时免费测"
        }, {
            id: 223,
            title: "升级版依恋综合测试",
            summary: "全面解析你的爱情模式",
            image: "https://cdn.knowyourself.cc/2021520/2.jpg",
            price: 0,
            origin: "25.9",
            tag: "最受欢迎",
            btn: "月食APP免费测"
        } ],
        examBottomList: [ {
            id: 189,
            title: "恋爱困难户解救手册",
            summary: "怎样做，我才能顺利开始一段爱情？",
            image: "https://cdn.knowyourself.cc/2021520/3.jpg",
            price: 0,
            origin: "39.9",
            tag: "单身必测",
            btn: "赠2得1免费测"
        }, {
            id: 191,
            title: "持久热恋指南",
            summary: "来，我有一份经营爱情的秘籍",
            image: "https://cdn.knowyourself.cc/2021520/4.jpg",
            price: 0,
            origin: "39.9",
            tag: "恋爱中",
            btn: "赠2得1免费测"
        }, {
            id: 226,
            title: "亲密关系健康度测试",
            summary: "测测你的爱情，有哪些隐藏的风险",
            image: "https://cdn.knowyourself.cc/2021520/5.jpg",
            price: 0,
            origin: "29.9",
            tag: "磨合期",
            btn: "赠1得1免费测"
        }, {
            id: 120,
            title: "失恋创伤阶段测试",
            summary: "失恋康复分五步，你走到了哪一步？",
            image: "https://cdn.knowyourself.cc/2021520/6.jpg",
            price: 0,
            origin: "19.9",
            tag: "分手别慌",
            btn: "赠1得1免费测"
        } ],
        dpList: [ {
            end: "2021/05/19 23:59:59",
            btn: "限时赠送1个好友，免费解锁练习",
            text: "结束后需赠<span class='color-red'>3</span>个好友才可领取"
        }, {
            end: "2021/05/24 23:59:59",
            btn: "限时赠送1个好友，免费解锁练习",
            text: "结束后购买价格为<span class='color-red'>99</span>元"
        } ],
        dpCountDown: {
            d: 0,
            h: 0,
            m: 0,
            s: 0
        },
        show: !1,
        customerDialog: !1,
        talkDialog: !1,
        sendDialogVisible: !1,
        qrCode: ""
    },
    onLoad: function(t) {
        var e = this;
        (0, o.computed)(this, {
            currentDp: function() {
                var t = this;
                return this.data.dpList.find(function(e) {
                    var n = new Date(e.end).getTime();
                    return t.data.now < n;
                });
            },
            isFinish: function() {
                return this.data.now && this.data.now >= l;
            },
            currentTimeIndex: function() {
                for (var t = 0; t < this.data.timeLine.length; t += 1) {
                    var e = this.data.timeLine[t].end, n = new Date(e).getTime();
                    if (this.data.now <= n) return t;
                }
                return 0;
            },
            courseIndex: function() {
                for (var t = 0; t < this.data.courseList.length; t += 1) {
                    var e = this.data.courseList[t].end, n = new Date(e).getTime();
                    if (this.data.now <= n) return t;
                }
                return -1;
            },
            courseImgSrc: function() {
                for (var t = 0, e = 0; e < this.data.courseList.length; e += 1) {
                    var n = this.data.courseList[e].end, i = new Date(n).getTime();
                    if (this.data.now <= i) {
                        t = e;
                        break;
                    }
                }
                return this.data.courseList[t].image;
            }
        }), (0, o.watch)(this, {}), wx.nextTick(function() {
            e.widget = e.selectComponent(".widget");
        });
    },
    onReady: function() {},
    onShow: function() {
        this.init();
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: "恋爱学院开学啦，快领取你的恋爱教程",
            imageUrl: "https://cdn.knowyourself.cc/together-wxapp/header@3x.jpg"
        };
    },
    init: function() {
        var t = this;
        return i(e.default.mark(function i() {
            var a, s, o;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.prev = 0, e.next = 3, Promise.all([ (0, r.getTimeNow)() ]);

                  case 3:
                    a = e.sent, s = n(a, 1), o = s[0], t.setData({
                        now: o
                    }), t.data.isFinish || t.startTimer(), t.initRect(), e.next = 14;
                    break;

                  case 11:
                    e.prev = 11, e.t0 = e.catch(0), console.error(e.t0);

                  case 14:
                  case "end":
                    return e.stop();
                }
            }, i, null, [ [ 0, 11 ] ]);
        }))();
    },
    onScroll: function(t) {
        var e = t.detail.scrollTop, n = this.scroller.find(e);
        this.setData({
            scrollTop: e,
            activeIndex: n
        });
    },
    initRect: function() {
        var t = this, e = this.data, n = e.tabs, i = e.scrollTop, a = n.map(function(t) {
            return t.id;
        });
        this.scroller = new s.default({
            ids: a,
            tabId: "tab"
        }, function() {
            var e = {
                activeIndex: t.scroller.find(i)
            };
            e.offsetTop = t.scroller.offsetTop, t.setData(e);
        });
    },
    handleTab: function(t) {
        wx._trackEvent("clk_520_main_freeTest_training_lotto_class_teaParty", {
            userid: getApp().globalData.user_id
        });
        var e = t.currentTarget.dataset.index, n = this.scroller.tabRect.height, i = this.scroller.rect[e].top;
        this.setData({
            customScrollTop: i - n
        });
    },
    startTimer: function() {
        var t = this;
        clearTimeout(this.data.timer);
        var e = setTimeout(function() {
            var e = t.data.now += 1e3, n = l - e, i = new Date(t.data.currentDp.end).getTime() - e;
            t.setData({
                now: e,
                countDown: d(n),
                dpCountDown: d(i)
            }), t.data.isFinish ? clearTimeout(t.data.timer) : t.startTimer();
        }, 1e3);
        this.setData({
            timer: e
        });
    },
    getFreeTalk: function() {
        wx._trackEvent("clk_520_main_talk", {
            userid: getApp().globalData.user_id
        }), this.changeTalk();
    },
    openDialog: function() {
        wx._trackEvent("clk_520_main_join", {
            userid: getApp().globalData.user_id
        }), wx.showModal({
            title: "温馨提示",
            content: "十分抱歉，由于相关规定，您暂时无法在小程序使用该功能",
            showCancel: !1,
            confirmText: "知道了",
            confirmColor: "#07c160"
        });
    },
    changeTalk: function() {
        this.setData({
            talkDialog: !this.data.talkDialog
        });
    },
    changeCustomer: function() {
        wx._trackEvent("clk_520_main_service", {
            userid: getApp().globalData.user_id
        }), this.setData({
            customerDialog: !this.data.customerDialog
        });
    },
    shareFriends: function() {
        wx._trackEvent("clk_520_main_toFri", {
            userid: getApp().globalData.user_id
        }), (0, c.goto)("/pages/exerciseDetail/exerciseDetail?id=40");
    },
    openSendDialog: function() {
        var t = this;
        return i(e.default.mark(function i() {
            var s, o, r, c;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return wx._trackEvent("clk_520_main_share", {
                        userid: getApp().globalData.user_id
                    }), e.prev = 1, s = {
                        sceneData: {
                            page: "pages/saleAll/saleAll"
                        },
                        optional: {
                            page: "pages/index/index"
                        }
                    }, e.next = 5, Promise.all([ a.saleService.getQrcode(s) ]);

                  case 5:
                    o = e.sent, r = n(o, 1), c = r[0].object, t.setData({
                        qrCode: c,
                        sendDialogVisible: !0
                    }, function() {
                        t.renderToCanvas();
                    }), e.next = 13;
                    break;

                  case 11:
                    e.prev = 11, e.t0 = e.catch(1);

                  case 13:
                  case "end":
                    return e.stop();
                }
            }, i, null, [ [ 1, 11 ] ]);
        }))();
    },
    closeSendDialog: function() {
        this.setData({
            sendDialogVisible: !1
        });
    },
    renderToCanvas: function() {
        var t = this, e = '\n      <view class="container" >\n        <view class="send-banner">\n          <image class="send-banner-img" src="https://cdn.knowyourself.cc/together-wxapp/header@3x.jpg" mode="aspectFit"></image>\n        </view>\n        <view class="content">\n          <text class="send-title-text">一站解决你的恋爱困扰</text>\n          <view class="footer">\n            <view class="footer-left">\n              <text class="footer-title">长按识别小程序码</text>\n              <text class="footer-desc">立即获取免费爆款测评</text>\n            </view>\n            <image class="footer-img" src="'.concat(this.data.qrCode, '" />\n          </view>\n        </view>\n      </view>\n      ');
        this.widget.renderToCanvas({
            wxml: e,
            style: {
                container: {
                    width: 325,
                    height: 410,
                    backgroundColor: "#FFFFFF",
                    borderRadius: 2
                },
                sendBanner: {
                    width: 325,
                    height: 300
                },
                sendBannerImg: {
                    width: 325,
                    height: 300
                },
                content: {
                    width: 325,
                    height: 110,
                    paddingLeft: 20,
                    paddingRight: 20,
                    paddingTop: 16,
                    paddingBottom: 0
                },
                sendTitleText: {
                    width: 285,
                    height: 24,
                    fontSize: 15,
                    color: "#1A1A1A"
                },
                footer: {
                    width: 285,
                    height: 56,
                    flexDirection: "row",
                    justifyContent: "space-between",
                    alignItems: "center"
                },
                footerLeft: {
                    width: 220,
                    height: 56,
                    flexDirection: "column",
                    justifyContent: "space-around"
                },
                footerTitle: {
                    width: 220,
                    height: 28,
                    lineHeight: 28,
                    fontSize: 13,
                    color: "#1A1A1A"
                },
                footerDesc: {
                    width: 220,
                    height: 20,
                    lineHeight: 20,
                    fontSize: 11,
                    color: "#9D9D9D"
                },
                footerImg: {
                    width: 56,
                    height: 56,
                    borderRadius: 28
                }
            }
        }).then(function(e) {
            t.container = e;
        });
    },
    extraImage: function() {
        this.closeSendDialog();
        var t = this;
        this.widget.canvasToTempFilePath().then(function(e) {
            wx.saveImageToPhotosAlbum({
                filePath: e.tempFilePath,
                success: function(t) {
                    wx.showToast({
                        title: "保存成功"
                    });
                },
                fail: function() {
                    wx.showModal({
                        title: "提示",
                        content: "需要您授权保存相册",
                        showCancel: !1,
                        success: function() {
                            wx.openSetting({
                                success: function(t) {
                                    t.authSetting["scope.writePhotosAlbum"] ? wx.showModal({
                                        title: "提示",
                                        content: "获取权限成功,再次保存图片即可成功",
                                        showCancel: !1
                                    }) : wx.showModal({
                                        title: "提示",
                                        content: "获取权限失败，无法保存到相册",
                                        showCancel: !1
                                    });
                                },
                                complete: function(t) {}
                            });
                        }
                    });
                },
                complete: function() {
                    t.setData({
                        isScroll: !1,
                        sendDialogVisible: !1
                    });
                }
            });
        });
    },
    loginSuccess: function(t) {
        var e = t.currentTarget.dataset.index;
        switch (Number(e)) {
          case 0:
            this.getFreeTalk();
            break;

          default:
            this.shareFriends();
        }
    }
});