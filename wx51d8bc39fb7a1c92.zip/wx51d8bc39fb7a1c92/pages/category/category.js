var e = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/regenerator")), n = require("../../@babel/runtime/helpers/asyncToGenerator"), t = require("../../api/index"), r = require("../../utils/index"), i = getApp();

Page({
    data: {
        navList: []
    },
    onLoad: function(e) {
        this.init();
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        var e = wx._getUserInfo();
        return {
            title: "".concat(e ? e.nickname : "好友", "邀请你来体验心理百科小程序，体验多种心理自助工具")
        };
    },
    init: function() {
        var r = this;
        return n(e.default.mark(function n() {
            var i, a;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.prev = 0, e.next = 3, t.wxService.getHome();

                  case 3:
                    i = e.sent, a = i.icon, r.setData({
                        navList: a
                    }), e.next = 11;
                    break;

                  case 8:
                    e.prev = 8, e.t0 = e.catch(0), console.error(e.t0);

                  case 11:
                  case "end":
                    return e.stop();
                }
            }, n, null, [ [ 0, 8 ] ]);
        }))();
    },
    handleClickNav: function(e) {
        var n = e.currentTarget.dataset.item;
        wx._trackEvent("clk_mini_book_type_type1_12", {
            userid: i.globalData.user_id,
            type_type_id: n.id
        }), (0, r.goto)(n.url);
    }
});