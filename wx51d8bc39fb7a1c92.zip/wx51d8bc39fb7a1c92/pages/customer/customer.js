var t = {
    0: {
        title: "KnowYourself",
        footer: "点击进入客服消息回复2关注公众号"
    },
    1: {
        title: "月食app",
        footer: "点击进入客服消息回复1下载月食APP"
    }
};

Page({
    data: {
        title: "",
        footer: "",
        active: 0
    },
    onLoad: function(t) {
        this.options = t, this.init();
    },
    init: function() {
        var o = this.data.active, n = this.options.active, i = t[n] || t[o], e = i.title, a = i.footer;
        this.setData({
            active: n,
            title: e,
            footer: a
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        var t = wx._getUserInfo();
        return {
            title: "".concat(t ? t.nickname : "好友", "邀请你来体验心理百科小程序，体验多种心理自助工具")
        };
    }
});