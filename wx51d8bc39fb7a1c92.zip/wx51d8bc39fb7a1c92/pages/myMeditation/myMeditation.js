var e = require("../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../@babel/runtime/regenerator")), a = require("../../@babel/runtime/helpers/asyncToGenerator"), i = require("../../@babel/runtime/helpers/objectSpread2"), r = require("../../api/index"), n = require("../../utils/index"), o = require("../../config/meditation"), s = e(require("../../libs/lower")), u = {
    offset: 0,
    limit: 20
}, d = {
    offset: 0,
    limit: 20
}, c = function(e) {
    return e.map(function(e) {
        return i(i({}, e), {}, {
            duration: (0, n.timeToStr)(e.duration),
            play_count: (0, n.toThousands)(e.play_count)
        });
    });
}, l = getApp();

Page({
    data: {
        offsetTop: l.globalData.navHeight,
        active: 0,
        starTarget: null,
        doneTarget: null
    },
    onLoad: function(e) {
        var t = this.data.active;
        e.active && e.active !== t ? this.setData({
            active: +e.active
        }) : this.getList();
    },
    onShareAppMessage: function() {
        var e = wx._getUserInfo();
        return {
            title: "".concat(e ? e.nickname : "好友", "邀请你来体验心理百科小程序，体验多种心理自助工具")
        };
    },
    getList: function() {
        var e = this;
        return a(t.default.mark(function a() {
            var i, n, o, l;
            return t.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (i = e.data, n = i.active, o = i.starTarget, l = i.doneTarget, 0 !== n) {
                        t.next = 10;
                        break;
                    }
                    if (!o && (o = new s.default(r.meditationService.getUserCollect, u, c)), !o.end) {
                        t.next = 5;
                        break;
                    }
                    return t.abrupt("return");

                  case 5:
                    return t.next = 7, o.getList();

                  case 7:
                    e.setData({
                        starTarget: o
                    }), t.next = 16;
                    break;

                  case 10:
                    if (!l && (l = new s.default(r.meditationService.getUserLog, d, c)), !l.end) {
                        t.next = 13;
                        break;
                    }
                    return t.abrupt("return");

                  case 13:
                    return t.next = 15, l.getList();

                  case 15:
                    e.setData({
                        doneTarget: l
                    });

                  case 16:
                  case "end":
                    return t.stop();
                }
            }, a);
        }))();
    },
    handleTabChange: function(e) {
        wx._trackEvent("clk_mini_mine_mediPage_favor_history", {
            userid: l.globalData.user_id
        });
        var t = e.detail.index;
        this.setData({
            active: t
        }, this.getList);
        var a = this.data, i = a.starTarget, r = a.doneTarget;
        !(i && i.list.length && r && r.list.length) && this.getList();
    },
    toMeditation: function(e) {
        var t = e.detail, a = t.id, i = t.mode;
        wx._trackEvent("clk_mini_mine_mediPage_audio", {
            userid: l.globalData.user_id,
            mine_audio_id: a
        }), i === o.MODE_SERIES ? (0, n.goto)("/pages/meditationDetail/meditationDetail?id=".concat(a)) : (0, 
        n.goto)("/pages/player/player?courseId=".concat(a));
    },
    toMeditationCourse: function(e) {
        var t = e.detail, a = t.course_id, i = t.mode;
        wx._trackEvent("clk_mini_mine_mediPage_audio", {
            userid: l.globalData.user_id,
            mine_audio_id: a
        }), i === o.MODE_SERIES ? (0, n.goto)("/pages/meditationDetail/meditationDetail?id=".concat(a)) : (0, 
        n.goto)("/pages/player/player?courseId=".concat(a));
    }
});