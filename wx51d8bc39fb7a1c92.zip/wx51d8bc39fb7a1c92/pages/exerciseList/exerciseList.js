var e = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/regenerator")), r = require("../../@babel/runtime/helpers/asyncToGenerator"), t = require("../../api/index");

Page({
    data: {
        loading: !0,
        list: []
    },
    onLoad: function(e) {
        this.init();
    },
    onShareAppMessage: function() {
        var e = wx._getUserInfo();
        return {
            title: "".concat(e ? e.nickname : "好友", "邀请你来体验心理百科小程序，体验多种心理自助工具")
        };
    },
    init: function() {
        var n = this;
        return r(e.default.mark(function r() {
            var a, i;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.next = 2, t.dpService.getHome();

                  case 2:
                    a = e.sent, i = a.recommends, n.setData({
                        list: i,
                        loading: !1
                    });

                  case 5:
                  case "end":
                    return e.stop();
                }
            }, r);
        }))();
    }
});