var e = require("../../@babel/runtime/helpers/interopRequireDefault"), t = require("../../@babel/runtime/helpers/toConsumableArray"), r = e(require("../../@babel/runtime/regenerator")), a = require("../../@babel/runtime/helpers/asyncToGenerator"), n = require("../../api/index"), i = getApp();

Page({
    data: {
        activeIndex: 0,
        sideBarList: [],
        list: [],
        end: !1
    },
    onLoad: function(e) {
        this.init();
    },
    onShareAppMessage: function() {
        var e = wx._getUserInfo();
        return {
            title: "".concat(e ? e.nickname : "好友", "邀请你来体验心理百科小程序，体验多种心理自助工具")
        };
    },
    init: function() {
        var e = this;
        return a(r.default.mark(function t() {
            return r.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    e.getCategory(), e.getCategoryDetail();

                  case 2:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    },
    getCategory: function() {
        var e = this;
        return a(r.default.mark(function t() {
            var a;
            return r.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.next = 2, n.examService.getCategory();

                  case 2:
                    a = t.sent, e.setData({
                        sideBarList: a.sort(function(e, t) {
                            return e.sort - t.sort;
                        })
                    });

                  case 4:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    },
    getCategoryDetail: function() {
        var e = this;
        return a(r.default.mark(function a() {
            var i, s, u, c, o, d, l, f, g, p, h;
            return r.default.wrap(function(r) {
                for (;;) switch (r.prev = r.next) {
                  case 0:
                    if (i = e.data, s = i.end, u = i.list, c = i.sideBarList, o = i.activeIndex, !s) {
                        r.next = 3;
                        break;
                    }
                    return r.abrupt("return");

                  case 3:
                    return d = {
                        limit: 20,
                        offset: u.length,
                        sort: "order_count"
                    }, (l = c.length && c[o].id) && (d.category_id = l), r.next = 8, n.examService.getExamList(d);

                  case 8:
                    f = r.sent, g = f.count, p = f.list, h = [].concat(t(u), t(p)), e.setData({
                        list: h,
                        end: g === h.length
                    });

                  case 13:
                  case "end":
                    return r.stop();
                }
            }, a);
        }))();
    },
    handleChangeSideBar: function(e) {
        wx._trackEvent("clk_mini_test_main_type1_9", {
            userid: i.globalData.user_id
        });
        var t = e.currentTarget.dataset.index;
        this.setData({
            activeIndex: Number(t),
            end: !1,
            list: []
        }, this.getCategoryDetail);
    },
    handleDetail: function(e) {
        var t = e.currentTarget.dataset.item;
        wx._trackEvent("clk_mini_test_main_type_test", {
            userid: i.globalData.user_id,
            test_id: t.id
        });
    }
});