var e, t = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/regenerator")), n = require("../../@babel/runtime/helpers/toConsumableArray"), r = require("../../@babel/runtime/helpers/asyncToGenerator"), i = require("../../@babel/runtime/helpers/defineProperty"), a = require("../../api/index"), o = (i(e = {}, 0, "进行中"), 
i(e, 1, "成功"), i(e, 2, "成功"), i(e, 3, "失败"), i(e, 4, "失败"), e);

Page({
    data: {
        loading: !0,
        list: [],
        count: 0,
        isFinish: !1
    },
    onLoad: function(e) {},
    onReady: function() {},
    onShow: function() {
        this.init();
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        var e = wx._getUserInfo();
        return {
            title: "".concat(e ? e.nickname : "好友", "邀请你来体验心理百科小程序，体验多种心理自助工具")
        };
    },
    init: function() {
        var e = this;
        return r(t.default.mark(function r() {
            var i, o, u, s, c;
            return t.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.prev = 0, i = {
                        offset: e.data.list.length,
                        limit: 20
                    }, t.next = 4, a.saleService.getRecord(i);

                  case 4:
                    o = t.sent, u = o.count, s = o.list, c = new Date().getTime(), s = [].concat(n(e.data.list), n(s)).map(function(t) {
                        return Object.assign({}, t, {
                            time: e.toYMD(t.created_time),
                            statusStr: 1e3 * t.expired_time < c && 2 !== Number(t.status) ? "失败" : e.formatterStatus(t.status)
                        });
                    }), e.setData({
                        count: u,
                        list: s,
                        isFinish: s.length === u
                    }), t.next = 15;
                    break;

                  case 12:
                    t.prev = 12, t.t0 = t.catch(0), console.error(t.t0);

                  case 15:
                    return t.prev = 15, t.finish(15);

                  case 17:
                  case "end":
                    return t.stop();
                }
            }, r, null, [ [ 0, 12, 15, 17 ] ]);
        }))();
    },
    formatterStatus: function(e) {
        return o[e];
    },
    num2fill: function(e) {
        var t = e;
        return t < 10 && (t = "0".concat(t)), t;
    },
    toYMD: function(e) {
        var t = new Date(1e3 * e), n = t.getFullYear(), r = this.num2fill(t.getMonth() + 1), i = this.num2fill(t.getDate());
        return "".concat(n, "年").concat(r, "月").concat(i, "日");
    }
});