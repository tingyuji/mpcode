var t = require("../../../../utils/index");

Component({
    options: {
        addGlobalClass: !0
    },
    properties: {
        target: {
            type: Object
        },
        showBtn: {
            type: Boolean
        },
        activityid: {
            type: [ String, Number ]
        },
        key: {
            type: [ String, Number ]
        }
    },
    data: {},
    methods: {
        handler: function() {
            wx._trackEvent("clk_520_actPage_record_viewTest", {
                userid: getApp().globalData.user_id,
                test_id: this.data.activityid
            }), (0, t.goto)("/pages/saleIndex/saleIndex?id=".concat(this.data.activityid, "&key=").concat(this.data.key));
        }
    }
});