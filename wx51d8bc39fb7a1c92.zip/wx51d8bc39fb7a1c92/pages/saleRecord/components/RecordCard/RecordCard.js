Component({
    options: {
        addGlobalClass: !0
    },
    properties: {
        target: {
            type: Object
        }
    },
    data: {},
    methods: {
        handler: function() {}
    }
});