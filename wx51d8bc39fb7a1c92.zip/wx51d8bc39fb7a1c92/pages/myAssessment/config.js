Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.EXAM_ING = exports.EXAM_FINISH = void 0;

exports.EXAM_ING = 2;

exports.EXAM_FINISH = 1;