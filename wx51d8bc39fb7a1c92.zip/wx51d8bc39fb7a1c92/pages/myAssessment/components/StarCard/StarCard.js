Component({
    options: {
        addGlobalClass: !0
    },
    properties: {
        target: {
            type: Object,
            value: {}
        }
    },
    data: {
        itemImage: ""
    },
    lifetimes: {
        attached: function() {
            var t = "";
            this.data.target.exam.commend_img_show && (t = this.data.target.exam.commend_img_show), 
            this.data.target.exam.mp_img_show && (t = this.data.target.exam.mp_img_show), this.setData({
                itemImage: t
            });
        }
    },
    methods: {
        handleDelete: function() {
            this.triggerEvent("onDel", this.data.target);
        },
        handleDetial: function() {
            this.triggerEvent("onTap", this.data.target);
        }
    }
});