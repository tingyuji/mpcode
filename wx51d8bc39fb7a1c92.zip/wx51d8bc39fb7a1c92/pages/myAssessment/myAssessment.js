var e = require("../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../@babel/runtime/regenerator")), a = require("../../@babel/runtime/helpers/asyncToGenerator"), r = require("./config"), i = require("../../api/index"), n = require("../../utils/index"), s = require("../../config/index"), o = e(require("../../libs/lower")), c = getApp(), u = {
    offset: 0,
    page_size: 20,
    is_finish: r.EXAM_ING
}, g = {
    offset: 0,
    page_size: 20,
    is_finish: r.EXAM_FINISH
}, d = {
    offset: 0,
    page_size: 20
};

Page({
    data: {
        offsetTop: c.globalData.navHeight,
        active: 0,
        ingTarget: null,
        doneTarget: null,
        starTarget: null,
        exam: ""
    },
    onLoad: function(e) {
        var t = this.data.active;
        e.active && e.active !== t ? this.setData({
            active: +e.active
        }) : this.getList(), this.setData({
            exam: wx.getStorageSync("ky_app_exam")
        });
    },
    onShareAppMessage: function() {
        var e = wx._getUserInfo();
        return {
            title: "".concat(e ? e.nickname : "好友", "邀请你来体验心理百科小程序，体验多种心理自助工具")
        };
    },
    getList: function() {
        var e = this;
        return a(t.default.mark(function a() {
            var r, n, s, c, l;
            return t.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (r = e.data, n = r.active, s = r.ingTarget, c = r.doneTarget, l = r.starTarget, 
                    0 !== n) {
                        t.next = 11;
                        break;
                    }
                    if (!s && (s = new o.default(i.examService.getUserExamList, u)), !s.end) {
                        t.next = 5;
                        break;
                    }
                    return t.abrupt("return");

                  case 5:
                    return t.next = 7, s.getList();

                  case 7:
                    e.setData({
                        ingTarget: s
                    }), console.log(e.data), t.next = 28;
                    break;

                  case 11:
                    if (1 !== n) {
                        t.next = 22;
                        break;
                    }
                    if (!c && (c = new o.default(i.examService.getUserExamList, g)), !c.end) {
                        t.next = 15;
                        break;
                    }
                    return t.abrupt("return");

                  case 15:
                    return t.next = 17, c.getList();

                  case 17:
                    console.log(2), e.setData({
                        doneTarget: c
                    }), console.log(e.data), t.next = 28;
                    break;

                  case 22:
                    if (!l && (l = new o.default(i.examService.getStarList, d)), !l.end) {
                        t.next = 25;
                        break;
                    }
                    return t.abrupt("return");

                  case 25:
                    return t.next = 27, l.getList();

                  case 27:
                    e.setData({
                        starTarget: l
                    });

                  case 28:
                  case "end":
                    return t.stop();
                }
            }, a);
        }))();
    },
    handleTabChange: function(e) {
        wx._trackEvent("clk_mini_mine_testPage_paid_completed", {
            userid: c.globalData.user_id
        });
        var t = e.detail.index;
        this.setData({
            active: t
        });
        var a = this.data, r = a.ingTarget, i = a.doneTarget, n = a.starTarget;
        !(r && r.list.length && i && i.list.length && n && n.list.length) && this.getList();
    },
    toExamProcess: function(e) {
        var t = e.detail.order_id;
        wx._trackEvent("clk_mini_mine_testPage_test", {
            userid: c.globalData.user_id,
            mine_test_id: t
        }), (0, n.goto)("".concat(s.EXAM_URL, "pages/progress/progress?orderId=").concat(t));
    },
    toExam: function(e) {
        var t = e.detail;
        (0, n.goto)("/pages/evaluationDetail/evaluationDetail?id=".concat(t.exam_id));
    },
    toReport: function(e) {
        var t = e.detail.order_id;
        (0, n.goto)("".concat(s.EXAM_URL, "pages/report/report?id=").concat(t, "&type=order_id"));
    },
    unStar: function(e) {
        var r = this;
        return a(t.default.mark(function a() {
            var n, s, o, c;
            return t.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return n = e.detail, s = n.id, o = n.exam_id, t.next = 4, i.examService.setUnStar({
                        id: o
                    });

                  case 4:
                    wx.showToast({
                        title: "成功删除收藏",
                        icon: "none"
                    }), (c = r.data.starTarget).del(s), r.setData({
                        starTarget: c
                    });

                  case 8:
                  case "end":
                    return t.stop();
                }
            }, a);
        }))();
    }
});