var e, t = require("../../@babel/runtime/helpers/interopRequireDefault"), a = require("../../@babel/runtime/helpers/toConsumableArray"), n = require("../../@babel/runtime/helpers/slicedToArray"), r = t(require("../../@babel/runtime/regenerator")), i = require("../../@babel/runtime/helpers/asyncToGenerator"), c = require("../../api/index"), s = require("../../utils/index"), o = require("../../utils/enum"), u = require("../../utils/loginState"), l = getApp();

Page({
    data: {
        placeholder: "搜索你感兴趣的内容",
        searchUrl: "",
        navList: [],
        bannerList: [],
        activeIndex: o.ENUM_ARTICLE,
        tapTypeList: [],
        tapList: [],
        finish: !1
    },
    onLoad: (e = i(r.default.mark(function e(t) {
        var a, n, i;
        return r.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                if (0 === Object.keys(t).length) {
                    e.next = 12;
                    break;
                }
                if (!t.scene || void 0 === t.scene) {
                    e.next = 11;
                    break;
                }
                return e.next = 4, c.saleService.getQrcodeData({
                    scene: t.scene
                });

              case 4:
                a = e.sent, n = "/".concat(a.page, "?"), delete a.page, i = Object.keys(a).reduce(function(e, t) {
                    return e += "" === e ? "".concat(t, "=").concat(a[t]) : "&".concat(t, "=").concat(a[t]);
                }, ""), (0, s.goto)("".concat(n).concat(i)), e.next = 12;
                break;

              case 11:
                this.options = t;

              case 12:
                this.init();

              case 13:
              case "end":
                return e.stop();
            }
        }, e, this);
    })), function(t) {
        return e.apply(this, arguments);
    }),
    onShareAppMessage: function() {
        var e = wx._getUserInfo();
        return {
            title: "".concat(e ? e.nickname : "好友", "邀请你来体验心理百科小程序，体验多种心理自助工具")
        };
    },
    init: function() {
        var e = this;
        return i(r.default.mark(function t() {
            var a, i, s, o, u, l, d, p, f, g, h;
            return r.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return a = {
                        autoLoading: !1
                    }, t.next = 3, Promise.all([ c.wxService.getHome({}, a), c.wxService.searchList({
                        page: "home",
                        type: e.data.activeIndex,
                        limit: 10,
                        offset: e.data.tapList.length
                    }, a) ]);

                  case 3:
                    i = t.sent, s = n(i, 2), o = s[0], u = s[1], l = o.banner, d = o.icon, p = o.placeholder, 
                    f = u.aggregations, g = u.list, h = u.count, e.setData({
                        placeholder: 0 === p.length ? "搜索你感兴趣的内容" : p[0].title,
                        searchUrl: 0 === p.length ? "../search/search" : p[0].url,
                        bannerList: l,
                        navList: d,
                        tapTypeList: f,
                        tapList: g,
                        finish: g.length === h
                    });

                  case 10:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    },
    onSearch: function() {
        wx._trackEvent("clk_mini_book_main_search", {
            userid: l.globalData.user_id
        }), (0, s.goto)("../search/search");
    },
    handleClickNav: function(e) {
        var t = e.currentTarget.dataset.item;
        wx._trackEvent("clk_mini_book_main_type1-8", {
            userid: l.globalData.user_id,
            type_id: t.id
        }), (0, s.goto)(t.url);
    },
    handleClickNavAll: function() {
        wx._trackEvent("clk_mini_book_main_type1-8", {
            userid: l.globalData.user_id,
            type_id: -1
        }), (0, s.goto)("/pages/category/category");
    },
    handleClickSwiper: function(e) {
        var t = e.detail;
        wx._trackEvent("clk_mini_book_main_ad", {
            userid: l.globalData.user_id,
            book_ad_id: t.id
        });
    },
    handleChangeTap: function(e) {
        var t = this;
        return i(r.default.mark(function a() {
            var n;
            return r.default.wrap(function(a) {
                for (;;) switch (a.prev = a.next) {
                  case 0:
                    n = e.detail, wx._trackEvent("clk_mini_book_main_kind1_5", {
                        userid: l.globalData.user_id,
                        kind_id: n.activeIndex
                    }), t.setData({
                        tapList: [],
                        activeIndex: n.activeIndex,
                        finish: !1
                    }), t.getList();

                  case 4:
                  case "end":
                    return a.stop();
                }
            }, a);
        }))();
    },
    getList: function() {
        var e = this;
        return i(r.default.mark(function t() {
            var n, i, s, o, u;
            return r.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (t.prev = 0, !e.data.finish) {
                        t.next = 3;
                        break;
                    }
                    return t.abrupt("return");

                  case 3:
                    return n = {
                        page: "home",
                        type: e.data.activeIndex,
                        limit: 10,
                        offset: e.data.tapList.length
                    }, t.next = 6, c.wxService.searchList(n);

                  case 6:
                    i = t.sent, s = i.aggregations, o = i.list, u = i.count, e.setData({
                        tapTypeList: s,
                        tapList: [].concat(a(e.data.tapList), a(o)),
                        finish: o.length === u
                    }), t.next = 16;
                    break;

                  case 13:
                    t.prev = 13, t.t0 = t.catch(0), console.error(t.t0);

                  case 16:
                  case "end":
                    return t.stop();
                }
            }, t, null, [ [ 0, 13 ] ]);
        }))();
    },
    hanleClickTabContent: function(e) {
        var t = e.detail;
        wx._trackEvent("clk_mini_book_main_item", {
            userid: l.globalData.user_id,
            item_id: t.target_id
        });
    },
    goDaySign: function() {
        return i(r.default.mark(function e() {
            return r.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.next = 2, (0, u.loginState)();

                  case 2:
                    if (e.sent) {
                        e.next = 5;
                        break;
                    }
                    return e.abrupt("return");

                  case 5:
                    (0, s.goto)("/pages/daySign/daySign");

                  case 6:
                  case "end":
                    return e.stop();
                }
            }, e);
        }))();
    }
});