Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.STAR = void 0;

exports.STAR = 1;