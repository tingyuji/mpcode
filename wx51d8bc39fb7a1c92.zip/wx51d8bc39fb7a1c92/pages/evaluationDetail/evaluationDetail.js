var t = require("../../@babel/runtime/helpers/interopRequireDefault"), e = require("../../@babel/runtime/helpers/defineProperty"), i = t(require("../../@babel/runtime/regenerator")), r = require("../../@babel/runtime/helpers/objectSpread2"), a = require("../../@babel/runtime/helpers/slicedToArray"), n = require("../../@babel/runtime/helpers/asyncToGenerator"), o = require("../../utils/index"), s = require("../../utils/loginState"), c = t(require("../../libs/scroller")), l = require("../../config/sale"), u = require("../../api/index"), d = require("../../config/index"), _ = require("../../utils/enum"), f = require("./config"), m = getApp(), p = [ 1, 2, 4 ];

Page({
    data: {
        tabList: [ {
            id: "header-title",
            title: "测评简介"
        }, {
            id: "comment-title",
            title: "测评感悟"
        }, {
            id: "test-title",
            title: "推荐测评"
        } ],
        scrollTop: 0,
        offsetTop: null,
        customScrollTop: 0,
        activeIndex: 0,
        detail: {},
        commentList: [],
        testList: [],
        saleInfo: null,
        isIos: m.globalData.systemInfo.isIos,
        activityCountDown: null,
        butState: !0
    },
    onLoad: function(t) {
        this.options = t;
    },
    onShow: function() {
        this.init();
    },
    onUnload: function() {
        clearTimeout(this.activityTimer);
    },
    onShareAppMessage: function() {
        var t = wx._getUserInfo();
        return {
            title: "".concat(t ? t.nickname : "好友", "邀请你体验【").concat(this.data.detail.title, "】，快看看吧")
        };
    },
    init: function() {
        var t = this;
        return n(i.default.mark(function e() {
            var n, s, c, m, p, h, v, x, g, k, b, w, y, T, D, S;
            return i.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return wx.showLoading({
                        title: "加载中..",
                        mask: !0
                    }), e.prev = 1, n = t.options.id, s = {
                        id: n
                    }, c = {
                        exam_id: n,
                        offset: 0,
                        limit: 3
                    }, m = {
                        autoLoading: !1
                    }, p = {
                        product_type: d.PROJECT_TYPE.exam,
                        product_id: n
                    }, h = {
                        target_id: n,
                        type: _.ENUM_EXAM
                    }, e.next = 10, Promise.all([ u.examService.getDetail(s, m), u.examService.getComment(c, m), u.wxService.searchRecommend(h, m), u.saleService.getSale(p, m) ]);

                  case 10:
                    v = e.sent, x = a(v, 4), g = x[0], k = x[1], b = x[2], (w = x[3]) && (y = w.discount, 
                    T = w.discount_type, D = w.platform_limit, T === l.DISCOUNT_PERCENTAGE ? w._price = (0, 
                    o.divide)((0, o.multiply)(g.price, y), 100) : w._price = y, (S = t.platformLimitToArr(D)).some(function(t) {
                        return 2 === t;
                    }) ? w._title = "限时".concat(10 * y, "折") : S.some(function(t) {
                        return 1 === t;
                    }) ? w._title = "APP特价" : S.some(function(t) {
                        return 4 === t;
                    }) && (w._title = "H5特价")), t.setData({
                        detail: r(r({}, g), {}, {
                            _isStar: g.is_star === f.STAR,
                            _isReport: !!g.token,
                            _isOrdered: !!g.last_pay_order_id,
                            _isFree: !g.price,
                            _isActivity: !!w,
                            _isHelpActivity: !!w && w.type === l.HELP,
                            _isDiscountActivity: !!w && w.type === l.DISCOUNT,
                            _isDiscountFree: !!w && 0 === Number(w._price)
                        }),
                        saleInfo: w,
                        commentList: k.list,
                        testList: b.list
                    }, function() {
                        t.initRect(!0), t.checkCountDown(), wx.hideLoading();
                    }), e.next = 23;
                    break;

                  case 20:
                    e.prev = 20, e.t0 = e.catch(1), console.error(e.t0);

                  case 23:
                  case "end":
                    return e.stop();
                }
            }, e, null, [ [ 1, 20 ] ]);
        }))();
    },
    checkCountDown: function() {
        var t = this, e = this.data, i = e.detail, r = i._isActivity, a = i._isOrdered;
        e.isIos;
        if (r && !a) {
            var n = this.data.saleInfo, s = n.end_time, c = n.begin_time, l = Date.now();
            if (s *= 1e3, l >= (c *= 1e3) && l <= s) return this.setData({
                activityCountDown: (0, o.second2DHMS)(s - l)
            }), clearTimeout(this.activityTimer), void (this.activityTimer = setTimeout(function() {
                t.checkCountDown();
            }, 1e3));
            this.init();
        }
        this.setData({
            activityCountDown: null
        });
    },
    resetRect: function() {
        wx._trackEvent("clk_mini_test_detail_unfold_fold", {
            userid: m.globalData.user_id
        }), this.initRect(!1);
    },
    resetRectComment: function() {
        wx._trackEvent("clk_mini_test_detail_comment_like_unfold_fold", {
            userid: m.globalData.user_id
        }), this.initRect(!1);
    },
    initRect: function(t) {
        var e = this, i = this.data, r = i.tabList, a = i.scrollTop, n = r.map(function(t) {
            return t.id;
        });
        this.scroller = new c.default({
            ids: n,
            tabId: "tab"
        }, function() {
            var i = {
                activeIndex: e.scroller.find(a)
            };
            t && (i.offsetTop = e.scroller.offsetTop), e.setData(i);
        });
    },
    onScroll: function(t) {
        var e = t.detail.scrollTop, i = this.scroller.find(e);
        this.setData({
            scrollTop: e,
            activeIndex: i
        });
    },
    handleTab: function(t) {
        wx._trackEvent("clk_mini_test_detail_intro_comment_recommend", {
            userid: m.globalData.user_id
        });
        var e = t.currentTarget.dataset.index, i = this.scroller.tabRect.height, r = this.scroller.rect[e].top;
        this.setData({
            customScrollTop: r - i
        });
    },
    checkCollectFun: function() {
        var t = this;
        return n(i.default.mark(function e() {
            return i.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.next = 2, (0, s.loginState)();

                  case 2:
                    e.sent && t.collect();

                  case 4:
                  case "end":
                    return e.stop();
                }
            }, e);
        }))();
    },
    collect: function() {
        var t = this;
        return n(i.default.mark(function r() {
            var a, n, o, s, c;
            return i.default.wrap(function(i) {
                for (;;) switch (i.prev = i.next) {
                  case 0:
                    if (wx._trackEvent("clk_mini_test_detail_favor", {
                        userid: m.globalData.user_id
                    }), a = t.data.detail, n = a.id, o = a._isStar, s = {
                        id: n
                    }, !o) {
                        i.next = 9;
                        break;
                    }
                    return i.next = 6, u.examService.setUnStar(s);

                  case 6:
                    c = "取消收藏成功", i.next = 12;
                    break;

                  case 9:
                    return i.next = 11, u.examService.setStar(s);

                  case 11:
                    c = "收藏成功";

                  case 12:
                    wx.showToast({
                        title: c,
                        icon: "none"
                    }), t.setData(e({}, "detail._isStar", !o));

                  case 14:
                  case "end":
                    return i.stop();
                }
            }, r);
        }))();
    },
    checkToken: function() {
        this.checkExam();
    },
    checkExam: function() {
        var t = this;
        return n(i.default.mark(function e() {
            var r, a, n, o, c, l, u;
            return i.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (wx._trackEvent("clk_mini_test_detail_begin", {
                        userid: m.globalData.user_id
                    }), r = t.data.detail, a = r._isOrdered, n = r.last_pay_order_id, o = r._isFree, 
                    c = r._isActivity, l = r._isDiscountFree, u = r._isDiscountActivity, !a) {
                        e.next = 10;
                        break;
                    }
                    return e.next = 5, (0, s.loginState)();

                  case 5:
                    e.sent && t.toExamProcess(n), console.log("111==="), e.next = 27;
                    break;

                  case 10:
                    if (c || !o) {
                        e.next = 18;
                        break;
                    }
                    return e.next = 13, (0, s.loginState)();

                  case 13:
                    e.sent && t.createOrder(), console.log("222==="), e.next = 27;
                    break;

                  case 18:
                    if (!(c && u && l)) {
                        e.next = 26;
                        break;
                    }
                    return e.next = 21, (0, s.loginState)();

                  case 21:
                    e.sent && t.createOrder(), console.log("333==="), e.next = 27;
                    break;

                  case 26:
                    t.toggleCustomer();

                  case 27:
                  case "end":
                    return e.stop();
                }
            }, e);
        }))();
    },
    toggleCustomer: function() {
        wx.showModal({
            title: "温馨提示",
            content: "十分抱歉，由于相关规定，您暂时无法在小程序进行该测评",
            showCancel: !1,
            confirmText: "知道了",
            confirmColor: "#07c160"
        });
    },
    createOrder: function() {
        var t = this;
        return n(i.default.mark(function e() {
            var r, a, n, o, s, c, l, d;
            return i.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (t.data.butState) {
                        e.next = 3;
                        break;
                    }
                    return wx.showToast({
                        title: "请勿重复点击",
                        icon: "none"
                    }), e.abrupt("return");

                  case 3:
                    return t.data.butState = !1, r = t.data.detail, a = r.id, n = r.price, o = r.last_pay_order_id, 
                    s = {
                        exam_id: a,
                        total_fee: n,
                        is_new: !o
                    }, e.next = 8, u.examService.createOrder(s, {
                        loadingText: "创建订单中..."
                    });

                  case 8:
                    if (c = e.sent, l = c.order_id, d = c.order_status, t.data.butState = !0, d === _.EXAM_ORDER_PAID) {
                        e.next = 15;
                        break;
                    }
                    return wx.showModal({
                        title: "温馨提示",
                        content: "十分抱歉，由于相关规定，您暂时无法在小程序进行该测评",
                        showCancel: !1,
                        confirmText: "知道了",
                        confirmColor: "#07c160"
                    }), e.abrupt("return");

                  case 15:
                    t.toExamProcess(l);

                  case 16:
                  case "end":
                    return e.stop();
                }
            }, e);
        }))();
    },
    toExamProcess: function(t) {
        console.log("".concat(d.EXAM_URL, "pages/progress/progress?orderId=").concat(t)), 
        (0, o.goto)("".concat(d.EXAM_URL, "pages/progress/progress?orderId=").concat(t));
    },
    toReport: function() {
        wx._trackEvent("clk_mini_test_detail_report", {
            userid: m.globalData.user_id
        });
        var t = this.data.detail, e = t.token, i = t.last_pay_order_id;
        (0, o.goto)("".concat(d.EXAM_URL, "pages/report/report?type=").concat(e ? "token" : "order", "&id=").concat(e || i));
    },
    toExamCategory: function() {
        wx._trackEvent("clk_mini_test_detail_recommend_more", {
            userid: m.globalData.user_id
        }), (0, o.goto)("/pages/evaluationCategory/evaluationCategory");
    },
    toComment: function() {
        wx._trackEvent("clk_mini_test_detail_comment_more", {
            userid: m.globalData.user_id
        });
        var t = this.options.id;
        (0, o.goto)("/pages/commentDetail/commentDetail?type=".concat(d.COMMENT_TYPE_EXAM, "&id=").concat(t, "&title=测评感悟"));
    },
    handleExamCard: function(t) {
        var e = t.currentTarget.dataset.item;
        wx._trackEvent("clk_mini_test_detail_recommend", {
            userid: m.globalData.user_id,
            recommend_test_id: e.id
        });
    },
    ActivityFun: function() {
        this.data.detail._isHelpActivity ? this.getShareKey() : this.toggleCustomer();
    },
    handleActivity: function() {
        var t = this;
        return n(i.default.mark(function e() {
            return i.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.next = 2, (0, s.loginState)();

                  case 2:
                    e.sent && t.ActivityFun();

                  case 4:
                  case "end":
                    return e.stop();
                }
            }, e);
        }))();
    },
    getShareKey: function() {
        var t = this;
        return n(i.default.mark(function e() {
            var r, a, n, s, c;
            return i.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return r = t.data.saleInfo, a = t.options.id, n = {
                        product_type: d.PROJECT_TYPE.exam,
                        product_id: a,
                        activity_id: r.id,
                        activity_shop_id: r.activity_shop_id
                    }, e.next = 5, u.saleService.getShareKey(n, {
                        loadingText: "生成分享码"
                    });

                  case 5:
                    s = e.sent, c = s.share_key, (0, o.goto)("/pages/saleIndex/saleIndex?id=".concat(r.id, "&key=").concat(encodeURIComponent(c)));

                  case 8:
                  case "end":
                    return e.stop();
                }
            }, e);
        }))();
    },
    platformLimitToArr: function(t) {
        var e = p, i = e.reduce(function(t, e) {
            return t + e;
        });
        if (e.some(function(e) {
            return e === +t;
        })) return [ +t ];
        if (t === i) return e;
        for (var r = new Map(), a = 0, n = e.length; a < n; a++) {
            if (r.has(t - e[a])) return [ e[r.get(t - e[a])], e[a] ];
            r.set(e[a], a);
        }
        return [];
    }
});