var t = require("../../@babel/runtime/helpers/interopRequireDefault");

require("../../@babel/runtime/helpers/Arrayincludes");

var e, i = require("../../@babel/runtime/helpers/defineProperty"), n = t(require("../../@babel/runtime/regenerator")), r = require("../../@babel/runtime/helpers/objectSpread2"), a = require("../../@babel/runtime/helpers/slicedToArray"), o = require("../../@babel/runtime/helpers/asyncToGenerator"), s = require("../../utils/index"), c = t(require("../../libs/scroller")), l = require("../../api/index"), u = require("../../config/index"), d = require("../../config/sale"), f = require("../../utils/loginState"), _ = getApp(), m = [ 1, 2, 4 ];

Page((i(e = {
    data: {
        scrollTop: 0,
        offsetTop: null,
        customScrollTop: 0,
        activeIndex: 0,
        tabList: [ {
            id: "header-title",
            title: "冥想介绍"
        }, {
            id: "exercise-title",
            title: "冥想目录"
        }, {
            id: "comment-title",
            title: "冥想感悟"
        } ],
        detail: {},
        exerciseList: [],
        commentList: [],
        saleInfo: null,
        activityCountDown: null,
        isIos: _.globalData.systemInfo.isIos
    },
    onLoad: function(t) {
        this.options = t;
    },
    onShow: function() {
        this.init();
    },
    onUnload: function() {
        clearTimeout(this.activityTimer);
    },
    onShareAppMessage: function() {
        var t = this.shareData, e = t.image, i = t.title, n = getCurrentPages()[getCurrentPages().length - 1].route, r = (0, 
        s.addParams)(n, this.options), a = this.data.detail.title;
        return {
            path: r,
            title: i || a,
            imageUrl: e || "../../assets/img/meditationShare.jpg"
        };
    },
    init: function() {
        var t = this;
        return o(n.default.mark(function e() {
            var i, o, c, f, _, m, p, h, v, g, x, y, w, T, b, k, D, S;
            return n.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.prev = 0, wx.showLoading({
                        title: "加载中...",
                        mask: !0
                    }), i = t.options.id, o = {
                        id: i
                    }, c = {
                        course_id: i,
                        offset: 0,
                        limit: 3
                    }, f = {
                        id: i
                    }, _ = {
                        product_type: u.PROJECT_TYPE.meditation,
                        product_id: i
                    }, m = {
                        autoLoading: !1
                    }, e.next = 10, Promise.all([ l.meditationService.getDetail(o, m), l.meditationService.getComment(c, m), l.wxService.getMeditation(f, m), l.saleService.getSale(_, m) ]);

                  case 10:
                    p = e.sent, h = a(p, 4), v = h[0], g = h[1].list, x = h[2], y = x.unlock_lessons, 
                    w = x.share_data, (T = h[3]) && (b = T.discount, k = T.discount_type, D = T.platform_limit, 
                    k === d.DISCOUNT_PERCENTAGE ? T._price = (0, s.divide)((0, s.multiply)(v.dot, b), 100) : T._price = b, 
                    (S = t.platformLimitToArr(D)).some(function(t) {
                        return 2 === t;
                    }) ? T._title = "限时".concat(10 * b, "折") : S.some(function(t) {
                        return 1 === t;
                    }) ? T._title = "APP特价" : S.some(function(t) {
                        return 4 === t;
                    }) && (T._title = "H5特价")), t.shareData = w, v.lessons = v.lessons.map(function(t, e) {
                        return r(r({}, t), {}, {
                            duration: (0, s.timeToStr)(t.duration),
                            _visible: y.includes(e)
                        });
                    }), t.setData({
                        detail: r(r({}, v), {}, {
                            _isFree: !v.dot,
                            _isActivity: !!T,
                            _isOrdered: v.paid,
                            _isHelpActivity: !!T && T.type === d.HELP,
                            _isDiscountActivity: !!T && T.type === d.DISCOUNT
                        }),
                        saleInfo: T,
                        commentList: g
                    }, function() {
                        t.initRect(!0), t.checkCountDown(), wx.hideLoading();
                    }), e.next = 27;
                    break;

                  case 24:
                    e.prev = 24, e.t0 = e.catch(0), wx.showToast({
                        title: JSON.stringify(e.t0),
                        icon: "none"
                    });

                  case 27:
                  case "end":
                    return e.stop();
                }
            }, e, null, [ [ 0, 24 ] ]);
        }))();
    },
    checkCountDown: function() {
        var t = this, e = this.data, i = e.detail._isActivity;
        e.isIos;
        if (i) {
            var n = this.data.saleInfo, r = n.end_time, a = n.begin_time, o = Date.now();
            if (r *= 1e3, o >= (a *= 1e3) && o <= r) return this.setData({
                activityCountDown: (0, s.second2DHMS)(r - o)
            }), clearTimeout(this.activityTimer), void (this.activityTimer = setTimeout(function() {
                t.checkCountDown();
            }, 1e3));
            this.init();
        }
        this.setData({
            activityCountDown: null
        });
    },
    resetRect: function() {
        wx._trackEvent("clk_mini_medi_detail_unfold_fold", {
            userid: _.globalData.user_id
        }), this.initRect(!1);
    },
    resetRectComment: function(t) {
        var e = t.detail;
        wx._trackEvent("clk_mini_medi_detail_comment_like_unfold_fold", {
            userid: _.globalData.user_id,
            detail_comment_id: e.id
        }), this.initRect(!1);
    },
    initRect: function(t) {
        var e = this, i = this.data, n = i.tabList, r = i.scrollTop, a = n.map(function(t) {
            return t.id;
        });
        this.scroller = new c.default({
            ids: a,
            tabId: "tab"
        }, function() {
            var i = {
                activeIndex: e.scroller.find(r)
            };
            t && (i.offsetTop = e.scroller.offsetTop), e.setData(i);
        });
    },
    onScroll: function(t) {
        var e = t.detail.scrollTop, i = this.scroller.find(e);
        this.setData({
            scrollTop: t.detail.scrollTop,
            activeIndex: i
        });
    },
    handleTab: function(t) {
        var e = t.currentTarget.dataset.index;
        wx._trackEvent("clk_mini_medi_detail_intro_content_comment", {
            userid: _.globalData.user_id
        });
        var i = this.scroller.tabRect.height, n = this.scroller.rect[e].top;
        this.setData({
            customScrollTop: n - i
        });
    },
    handleLesson: function(t) {
        var e = t.currentTarget.dataset.item, i = e.id, n = e.course_id, r = e._visible;
        wx._trackEvent("clk_mini_medi_detail_content_detail", {
            userid: _.globalData.user_id,
            audio_id: i
        }), r ? (0, s.goto)("/pages/player/player?courseId=".concat(n, "&lessonId=").concat(i)) : this.toggleCustomer();
    },
    checkCollectFun: function() {
        var t = this;
        return o(n.default.mark(function e() {
            return n.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.next = 2, (0, f.loginState)();

                  case 2:
                    e.sent && t.collect();

                  case 4:
                  case "end":
                    return e.stop();
                }
            }, e);
        }))();
    },
    collect: function() {
        var t = this;
        return o(n.default.mark(function e() {
            var i, r, a, o, s, c;
            return n.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return i = t.data.detail.is_star, r = !i, a = {
                        course_id: t.options.id,
                        is_star: r
                    }, wx._trackEvent("clk_mini_medi_detail_favor", {
                        userid: _.globalData.user_id,
                        audio_id: t.options.id
                    }), e.next = 6, l.meditationService.starMeditation(a);

                  case 6:
                    o = e.sent, s = o.updated, c = r ? "收藏成功" : "取消收藏", s && (wx.showToast({
                        title: c,
                        icon: "none"
                    }), t.setData({
                        "detail.is_star": r
                    }));

                  case 10:
                  case "end":
                    return e.stop();
                }
            }, e);
        }))();
    },
    checkStart: function() {
        var t = this;
        return o(n.default.mark(function e() {
            var i, r;
            return n.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.next = 2, (0, f.loginState)();

                  case 2:
                    if (e.sent) {
                        e.next = 5;
                        break;
                    }
                    return e.abrupt("return");

                  case 5:
                    i = t.data.detail.lessons, r = i.find(function(t) {
                        return t._visible;
                    }) || {}, t.handleLesson({
                        currentTarget: {
                            dataset: {
                                item: r
                            }
                        }
                    });

                  case 8:
                  case "end":
                    return e.stop();
                }
            }, e);
        }))();
    },
    checkMeditation: function() {
        var t = this;
        return o(n.default.mark(function e() {
            return n.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.next = 2, (0, f.loginState)();

                  case 2:
                    if (e.sent) {
                        e.next = 5;
                        break;
                    }
                    return e.abrupt("return");

                  case 5:
                    t.data.detail._isFree ? t.checkStart() : t.toggleCustomer();

                  case 7:
                  case "end":
                    return e.stop();
                }
            }, e);
        }))();
    },
    handleActivity: function() {
        var t = this;
        return o(n.default.mark(function e() {
            return n.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.next = 2, (0, f.loginState)();

                  case 2:
                    e.sent && t.ActivityFun();

                  case 4:
                  case "end":
                    return e.stop();
                }
            }, e);
        }))();
    },
    ActivityFun: function() {
        this.data.detail._isHelpActivity ? this.getShareKey() : this.toggleCustomer();
    },
    getShareKey: function() {
        var t = this;
        return o(n.default.mark(function e() {
            var i, r, a, o, c;
            return n.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return i = t.data.saleInfo, r = t.options.id, a = {
                        product_type: u.PROJECT_TYPE.meditation,
                        product_id: r,
                        activity_id: i.id,
                        activity_shop_id: i.activity_shop_id
                    }, e.next = 5, l.saleService.getShareKey(a, {
                        loadingText: "生成分享码"
                    });

                  case 5:
                    o = e.sent, c = o.share_key, (0, s.goto)("/pages/saleIndex/saleIndex?id=".concat(i.id, "&key=").concat(encodeURIComponent(c)));

                  case 8:
                  case "end":
                    return e.stop();
                }
            }, e);
        }))();
    },
    toggleCustomer: function() {
        wx._trackEvent("clk_mini_medi_detail_play", {
            userid: _.globalData.user_id,
            audio_id: this.options.id
        }), wx.showModal({
            title: "温馨提示",
            content: "十分抱歉，由于相关规定，您暂时无法在小程序使用该功能",
            showCancel: !1,
            confirmText: "知道了",
            confirmColor: "#07c160"
        });
    },
    toComment: function() {
        var t = this.options.id;
        wx._trackEvent("clk_mini_medi_detail_comment_more", {
            userid: _.globalData.user_id
        }), (0, s.goto)("/pages/commentDetail/commentDetail?type=".concat(u.COMMENT_TYPE_MEDITATION, "&id=").concat(t, "&title=冥想感悟"));
    }
}, "getShareKey", function() {
    var t = this;
    return o(n.default.mark(function e() {
        var i, r, a, o, c;
        return n.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return i = t.data.saleInfo, r = t.options.id, a = {
                    product_type: u.PROJECT_TYPE.meditation,
                    product_id: r,
                    activity_id: i.id,
                    activity_shop_id: i.activity_shop_id
                }, e.next = 5, l.saleService.getShareKey(a, {
                    loadingText: "生成分享码"
                });

              case 5:
                o = e.sent, c = o.share_key, (0, s.goto)("/pages/saleIndex/saleIndex?id=".concat(i.id, "&key=").concat(encodeURIComponent(c)));

              case 8:
              case "end":
                return e.stop();
            }
        }, e);
    }))();
}), i(e, "platformLimitToArr", function(t) {
    var e = m, i = e.reduce(function(t, e) {
        return t + e;
    });
    if (e.some(function(e) {
        return e === +t;
    })) return [ +t ];
    if (t === i) return e;
    for (var n = new Map(), r = 0, a = e.length; r < a; r++) {
        if (n.has(t - e[r])) return [ e[n.get(t - e[r])], e[r] ];
        n.set(e[r], r);
    }
    return [];
}), e));