var t = require("../../@babel/runtime/helpers/interopRequireDefault"), e = require("../../@babel/runtime/helpers/defineProperty"), i = t(require("../../@babel/runtime/regenerator")), a = require("../../@babel/runtime/helpers/objectSpread2"), r = require("../../@babel/runtime/helpers/slicedToArray"), n = require("../../@babel/runtime/helpers/asyncToGenerator"), o = t(require("../../libs/scroller")), s = require("../../utils/index"), c = require("../../api/index"), l = require("../../config/index"), u = require("../../config/sale"), d = require("../../utils/loginState"), p = getApp(), f = [ 1, 2, 4 ];

Page({
    data: {
        scrollTop: 0,
        offsetTop: null,
        customScrollTop: 0,
        activeIndex: 0,
        tabList: [ {
            id: "header-title",
            title: "练习简介"
        }, {
            id: "subject-panel",
            title: "练习目录"
        }, {
            id: "comment-title",
            title: "练习感悟"
        } ],
        detail: {},
        commentList: [],
        subjectList: [],
        dialogVisible: !1,
        saleInfo: null,
        activityCountDown: null,
        isIos: p.globalData.systemInfo.isIos
    },
    onLoad: function(t) {
        this.options = t;
    },
    onShow: function() {
        this.init();
    },
    onUnload: function() {
        clearTimeout(this.activityTimer);
    },
    onShareAppMessage: function() {
        var t = this.shareData, e = t.imageUrl, i = t.title, a = getCurrentPages()[getCurrentPages().length - 1].route;
        return {
            path: (0, s.addParams)(a, this.options),
            title: i,
            imageUrl: e
        };
    },
    init: function() {
        var t = this;
        return n(i.default.mark(function e() {
            var n, o, d, p, f, _, m, g, h, v, w, b, y, T, x, D;
            return i.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return wx.showLoading({
                        title: "加载中...",
                        mask: !0
                    }), e.prev = 1, n = t.options.id, o = {
                        id: n
                    }, d = {
                        plan_id: n,
                        limit: 3,
                        offset: 0
                    }, p = {
                        product_type: l.PROJECT_TYPE.dp,
                        product_id: n
                    }, f = {
                        autoLoading: !1
                    }, e.next = 9, Promise.all([ c.dpService.getDetail(o, f), c.dpService.getComment(d, f), c.saleService.getSale(p, f) ]);

                  case 9:
                    _ = e.sent, m = r(_, 3), g = m[0], h = m[1], (v = m[2]) && (w = v.discount, b = v.discount_type, 
                    y = v.platform_limit, b === u.DISCOUNT_PERCENTAGE ? v._price = (0, s.divide)((0, 
                    s.multiply)(g.dot, w), 100) : v._price = w, (T = t.platformLimitToArr(y)).some(function(t) {
                        return 2 === t;
                    }) ? v._title = "限时".concat(10 * w, "折") : T.some(function(t) {
                        return 1 === t;
                    }) ? v._title = "APP特价" : T.some(function(t) {
                        return 4 === t;
                    }) && (v._title = "H5特价")), t.shareData = {
                        imageUrl: g.share_img,
                        title: g.title
                    }, g.activity_frame && ((x = wx.getStorageSync("ky-weapp-exam-detail") || "") ? (x = JSON.parse(x), 
                    (D = new Date().getTime()) >= x.start && D <= x.end || (wx.setStorageSync("ky-weapp-exam-detail", JSON.stringify({
                        start: new Date("".concat(t.getToday(), " 00:00:00")).getTime(),
                        end: new Date("".concat(t.getToday(), " 23:59:59")).getTime()
                    })), t.changeCustomer())) : (wx.setStorageSync("ky-weapp-exam-detail", JSON.stringify({
                        start: new Date("".concat(t.getToday(), " 00:00:00")).getTime(),
                        end: new Date("".concat(t.getToday(), " 23:59:59")).getTime()
                    })), t.changeCustomer())), t.setData({
                        detail: a(a({}, g), {}, {
                            _isFree: !g.dot,
                            _isActivity: !!v,
                            _isOrdered: !!g.order_id,
                            _isHelpActivity: !!v && v.type === u.HELP,
                            _isDiscountActivity: !!v && v.type === u.DISCOUNT
                        }),
                        saleInfo: v,
                        commentList: h.list,
                        subjectList: g.sub_plans
                    }, function() {
                        t.initRect(!0), t.checkCountDown(), wx.hideLoading();
                    }), e.next = 23;
                    break;

                  case 20:
                    e.prev = 20, e.t0 = e.catch(1), wx.showToast({
                        title: e.t0,
                        icon: "none"
                    });

                  case 23:
                  case "end":
                    return e.stop();
                }
            }, e, null, [ [ 1, 20 ] ]);
        }))();
    },
    checkCountDown: function() {
        var t = this, e = this.data, i = e.detail, a = i._isActivity, r = i._isOrdered;
        e.isIos;
        if (a && !r) {
            var n = this.data.saleInfo, o = n.end_time, c = n.begin_time, l = Date.now();
            if (o *= 1e3, l >= (c *= 1e3) && l <= o) return this.setData({
                activityCountDown: (0, s.second2DHMS)(o - l)
            }), clearTimeout(this.activityTimer), void (this.activityTimer = setTimeout(function() {
                t.checkCountDown();
            }, 1e3));
            this.init();
        }
        this.setData({
            activityCountDown: null
        });
    },
    handleActivity: function() {
        var t = this;
        return n(i.default.mark(function e() {
            return i.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.next = 2, (0, d.loginState)();

                  case 2:
                    if (e.sent) {
                        e.next = 5;
                        break;
                    }
                    return e.abrupt("return");

                  case 5:
                    t.data.detail._isHelpActivity ? t.getShareKey() : t.toggleCustomer();

                  case 7:
                  case "end":
                    return e.stop();
                }
            }, e);
        }))();
    },
    getShareKey: function() {
        var t = this;
        return n(i.default.mark(function e() {
            var a, r, n, o, u;
            return i.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return a = t.data.saleInfo, r = t.options.id, n = {
                        product_type: l.PROJECT_TYPE.dp,
                        product_id: r,
                        activity_id: a.id,
                        activity_shop_id: a.activity_shop_id
                    }, e.next = 5, c.saleService.getShareKey(n, {
                        loadingText: "生成分享码"
                    });

                  case 5:
                    o = e.sent, u = o.share_key, (0, s.goto)("/pages/saleIndex/saleIndex?id=".concat(a.id, "&key=").concat(encodeURIComponent(u)));

                  case 8:
                  case "end":
                    return e.stop();
                }
            }, e);
        }))();
    },
    getToday: function() {
        var t = new Date(), e = t.getFullYear(), i = t.getMonth() + 1, a = t.getDate();
        return i < 10 && (i = "0" + i), a < 10 && (a = "0" + a), e + "/" + i + "/" + a;
    },
    resetRect: function() {
        wx._trackEvent("clk_mini_prac_detail_unfold_fold", {
            userid: p.globalData.user_id
        }), this.initRect(!1);
    },
    resetRectComment: function() {
        wx._trackEvent("clk_mini_prac_detail_comment_like_unfold_fold", {
            userid: p.globalData.user_id
        }), this.initRect(!1);
    },
    initRect: function(t) {
        var e = this, i = this.data, a = i.tabList, r = i.scrollTop, n = a.map(function(t) {
            return t.id;
        });
        this.scroller = new o.default({
            ids: n,
            tabId: "tab"
        }, function() {
            var i = {
                activeIndex: e.scroller.find(r)
            };
            t && (i.offsetTop = e.scroller.offsetTop), e.setData(i);
        });
    },
    onScroll: function(t) {
        var e = t.detail.scrollTop, i = this.scroller.find(e);
        this.setData({
            scrollTop: e,
            activeIndex: i
        });
    },
    handleTab: function(t) {
        wx._trackEvent("clk_mini_prac_detail_intro_topic", {
            userid: p.globalData.user_id
        });
        var e = t.currentTarget.dataset.index, i = this.scroller.tabRect.height, a = this.scroller.rect[e].top;
        this.setData({
            customScrollTop: a - i
        });
    },
    toComment: function() {
        wx._trackEvent("clk_mini_prac_detail_comment_more", {
            userid: p.globalData.user_id
        });
        var t = this.options.id;
        (0, s.goto)("/pages/commentDetail/commentDetail?type=".concat(l.COMMENT_TYPE_DP, "&id=").concat(t, "&title=练习感悟"));
    },
    collect: function() {
        var t = this;
        return n(i.default.mark(function e() {
            var r, n, o, s;
            return i.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.next = 2, (0, d.loginState)();

                  case 2:
                    if (e.sent) {
                        e.next = 5;
                        break;
                    }
                    return e.abrupt("return");

                  case 5:
                    return wx._trackEvent("clk_mini_prac_detail_favor", {
                        userid: p.globalData.user_id
                    }), r = t.data.detail, n = r.id, o = r.is_follow, s = {
                        plan_id: n,
                        follow: !o
                    }, e.next = 11, c.dpService.setStar(s);

                  case 11:
                    t.setData({
                        detail: a(a({}, r), {}, {
                            is_follow: !o
                        })
                    });

                  case 12:
                  case "end":
                    return e.stop();
                }
            }, e);
        }))();
    },
    showSubjectList: function(t) {
        var i = t.currentTarget.dataset.index, a = t.currentTarget.dataset.idx;
        wx._trackEvent("clk_mini_prac_detail_subject", {
            userid: p.globalData.user_id,
            subject_id: this.data.subjectList[i].id
        });
        var r = "subjectList[".concat(i, "].list[").concat(a, "].isLock");
        this.setData(e({}, r, !this.data.subjectList[i].list[a].isLock));
    },
    toggleCustomer: function() {
        wx._trackEvent("clk_mini_prac_detail_begin", {
            userid: p.globalData.user_id
        }), wx.showModal({
            title: "温馨提示",
            content: "十分抱歉，由于相关规定，您暂时无法在小程序使用该功能",
            showCancel: !1,
            confirmText: "知道了",
            confirmColor: "#07c160"
        });
    },
    changeCustomer: function() {
        this.setData({
            dialogVisible: !this.data.dialogVisible
        });
    },
    platformLimitToArr: function(t) {
        var e = f, i = e.reduce(function(t, e) {
            return t + e;
        });
        if (e.some(function(e) {
            return e === +t;
        })) return [ +t ];
        if (t === i) return e;
        for (var a = new Map(), r = 0, n = e.length; r < n; r++) {
            if (a.has(t - e[r])) return [ e[a.get(t - e[r])], e[r] ];
            a.set(e[r], r);
        }
        return [];
    }
});