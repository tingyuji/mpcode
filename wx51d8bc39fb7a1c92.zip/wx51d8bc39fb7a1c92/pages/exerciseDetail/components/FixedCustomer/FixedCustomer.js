Component({
    options: {
        addGlobalClass: !0
    },
    properties: {
        dialogVisible: {
            type: Boolean,
            value: !1
        }
    },
    data: {},
    methods: {
        changeDialog: function() {
            this.triggerEvent("change");
        }
    }
});