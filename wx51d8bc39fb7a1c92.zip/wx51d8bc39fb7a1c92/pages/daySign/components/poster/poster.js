var t = require("../../../../@babel/runtime/helpers/interopRequireDefault"), e = require("../../../../@babel/runtime/helpers/defineProperty"), n = t(require("../../../../@babel/runtime/regenerator")), i = require("../../../../@babel/runtime/helpers/asyncToGenerator"), a = require("../../../../api/index");

var o = {
    0: "January",
    1: "February",
    2: "March",
    3: "April",
    4: "May",
    5: "June",
    6: "July",
    7: "August",
    8: "September",
    9: "October",
    10: "November",
    11: "December"
}, r = getApp();

Component({
    options: {
        addGlobalClass: !0
    },
    properties: {
        target: {
            type: Object,
            value: {}
        }
    },
    data: {
        headerHeight: r.globalData.navHeight,
        statusBarHeight: r.globalData.navTop,
        wxmlWidth: 612,
        wxmlHeight: 1012,
        src: null,
        sonSate: !1,
        srcState: 0
    },
    lifetimes: {
        attached: function() {
            var t = this;
            this.init(), this.triggerEvent("closePageCard"), this.setData({
                sonData: this.data.target
            }), setTimeout(function() {
                t.setData({
                    sonSate: !0
                });
            }, 1e3);
        }
    },
    methods: {
        init: function() {
            this.data.target.id ? this.draw() : this.confirm();
        },
        confirm: function() {
            var t = this;
            return i(n.default.mark(function e() {
                var i, o;
                return n.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return e.prev = 0, i = t.data.target, o = {
                            question: i.question,
                            store: i.store
                        }, e.next = 5, a.wxService.updateDaily(o, {
                            autoLoading: !1
                        });

                      case 5:
                        t.draw(), e.next = 12;
                        break;

                      case 8:
                        e.prev = 8, e.t0 = e.catch(0), console.error(e.t0), t.triggerEvent("close");

                      case 12:
                      case "end":
                        return e.stop();
                    }
                }, e, null, [ [ 0, 8 ] ]);
            }))();
        },
        draw: function() {
            var t = this, e = setInterval(function() {
                t.widget && t.widget.canvas ? (t.renderToCanvas(), clearInterval(e)) : t.widget = t.selectComponent(".widget");
            }, 400);
        },
        nameLingthFun: function(t) {
            return t.length <= 10 ? t : (console.log("".concat(t.substr(0, 10), "...")), "".concat(t.substr(0, 10), "..."));
        },
        renderToCanvas: function() {
            var t, n = this, i = this.data, a = i.target, r = i.wxmlHeight, s = i.wxmlWidth, c = a.store, l = c.image, h = c.title, g = c.summary, d = a.date, u = 48 * Math.ceil(26 * g.length / 304), w = r - 148 + u, m = d ? new Date(d) : new Date(), p = (t = m.getDate()) < 10 ? "0".concat(t) : t, f = m.getMonth(), v = JSON.parse(wx.getStorageSync("ky_weapp_userInfo")), b = v.avatar, x = v.nickname, y = this.nameLingthFun(x), C = y.length <= 10 ? 26 * y.length : 286, D = null, S = h.length <= 2 ? "title" : "titlePadRi";
            for (var F in h) Number(F) <= 2 && (D += '<view class="title-div"><text class="title-content">'.concat(h[F], "</text></view>"));
            var T = '<view class="container">\n        <view class="header">\n            <image class="logo" src="'.concat("https://cdn.knowyourself.cc/together-wxapp/day-logo.png", '"></image>\n            <view class="').concat(S, '">').concat(D, '</view>\n        </view>\n        <view class="date-con">\n            <view class="dayDiv">\n              <text class="day">').concat(p, '</text>\n              <text class="month">').concat(o[f], "</text>\n            </view>\n            <view class=\"content-div\">\n               <text class='content'>").concat(g, '</text>\n            </view>\n        </view>\n        <view class="userInfo">\n          <image class="qr" src="').concat("https://cdn.knowyourself.cc/together-wxapp/wxapp-qr.jpg", '"></image>\n          <view class="uesr">\n            <text class="userName">').concat(y, '</text>\n            <image class="userSculpture" src="').concat(b, '"></image>\n          </view>\n        </view>\n        <view class="footer">\n          <image class="bg" src="').concat(l, '"></image>\n        </view>\n      </view>'), A = {
                container: {
                    width: s,
                    height: w,
                    backgroundColor: "#FFFFFF",
                    flexDirection: "column",
                    alignItems: "center",
                    borderWidth: 24,
                    borderStyle: "solid",
                    borderColor: "#F2C899",
                    borderRadius: 12,
                    boxSizing: "border-box",
                    paddingTop: 72
                },
                header: {
                    width: 564,
                    flexDirection: "row",
                    justifyContent: "space-between",
                    alignItems: "center",
                    height: 44,
                    paddingLeft: 23,
                    paddingRight: 23
                },
                logo: {
                    width: 140,
                    height: 70
                },
                title: {
                    width: 192,
                    height: 88,
                    flexDirection: "row",
                    alignItems: "center",
                    justifyContent: "center",
                    marginTop: 8,
                    marginBottom: 8,
                    paddingRight: 23
                },
                titlePadRi: {
                    width: 288,
                    height: 88,
                    flexDirection: "row",
                    alignItems: "center",
                    justifyContent: "center",
                    marginTop: 8,
                    marginBottom: 8,
                    paddingRight: 23
                },
                titleDiv: {
                    width: 80,
                    height: 80,
                    borderWidth: 1,
                    borderStyle: "solid",
                    borderColor: "#1a1a1a",
                    borderRadius: 40,
                    backgroundColor: "#FFFFFF",
                    flexDirection: "row",
                    alignItems: "center",
                    marginLeft: 8
                },
                titleContent: e({
                    width: 40,
                    textAlign: "right",
                    height: 40,
                    lineHeight: 40,
                    fontSize: 40,
                    fontWeight: 700,
                    color: "#F2C899",
                    marginLeft: 20
                }, "color", "#1a1a1a"),
                dateCon: {
                    width: 564,
                    paddingTop: 80,
                    paddingLeft: 23,
                    paddingRight: 23,
                    flexDirection: "row",
                    justifyContent: "space-between",
                    alignItems: "center"
                },
                dayDiv: {
                    marginTop: -20
                },
                day: {
                    display: "block",
                    width: 176,
                    height: 88,
                    fontSize: 88,
                    fontWeight: "bold",
                    color: "#1A1A1A",
                    lineHeight: 88
                },
                month: {
                    display: "block",
                    width: 100,
                    height: 28,
                    fontSize: 24,
                    color: "#1A1A1A",
                    lineHeight: 28
                },
                content: {
                    width: 340,
                    height: u,
                    fontSize: 26,
                    lineHeight: 48,
                    color: "#1A1A1A"
                },
                userInfo: {
                    flexDirection: "row",
                    justifyContent: "space-between",
                    alignItems: "center",
                    width: 564,
                    paddingLeft: 23,
                    paddingRight: 23,
                    paddingTop: 60,
                    paddingBottom: 70
                },
                uesr: {
                    flexDirection: "row",
                    alignItems: "center"
                },
                userSculpture: {
                    width: 80,
                    height: 80,
                    borderRadius: 40
                },
                userName: {
                    width: C,
                    height: 28,
                    fontSize: 26,
                    lineHeight: 28,
                    color: "#1a1a1a",
                    marginRight: 12
                },
                qr: {
                    width: 128,
                    height: 128
                },
                footer: {
                    width: 564,
                    height: 360
                },
                bg: {
                    width: 564,
                    height: 360
                }
            };
            this.widget.renderToCanvas({
                wxml: T,
                style: A
            }).then(function(t) {
                n.widget.canvasToTempFilePath().then(function(t) {
                    n.setData({
                        src: t.tempFilePath,
                        srcState: 1
                    });
                }).catch(function(t) {
                    console.log(t), n.setData({
                        srcState: 2
                    });
                });
            });
        },
        back: function() {
            this.triggerEvent("back");
        },
        extraImage: function() {
            var t = this.data, e = t.src, n = t.srcState;
            switch (console.log(n), n) {
              case 0:
                return wx.showToast({
                    title: "生成图片中,请稍后~",
                    icon: "none"
                });

              case 2:
                return this.renderToCanvas(), wx.showToast({
                    title: "生成图片失败,请重试~",
                    icon: "none"
                });
            }
            wx.saveImageToPhotosAlbum({
                filePath: e,
                success: function(t) {
                    wx.showToast({
                        title: "保存成功"
                    });
                },
                fail: function() {
                    wx.showModal({
                        title: "提示",
                        content: "需要您授权保存相册",
                        showCancel: !1,
                        success: function() {
                            wx.openSetting({
                                success: function(t) {
                                    t.authSetting["scope.writePhotosAlbum"] ? wx.showModal({
                                        title: "提示",
                                        content: "获取权限成功,再次保存图片即可成功",
                                        showCancel: !1
                                    }) : wx.showModal({
                                        title: "提示",
                                        content: "获取权限失败，无法保存到相册",
                                        showCancel: !1
                                    });
                                }
                            });
                        }
                    });
                }
            });
        }
    }
});