Component({
    properties: {
        target: {
            type: Object
        }
    },
    data: {
        titleText: [],
        LOGO: "https://cdn.knowyourself.cc/together-wxapp/day-logo.png",
        qr: "https://cdn.knowyourself.cc/together-wxapp/wxapp-qr.jpg",
        MONTHS: [ "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" ],
        day: "",
        month: "",
        summary: "",
        image: "",
        nickname: "",
        avatar: ""
    },
    methods: {
        fillZero: function(t) {
            return t < 10 ? "0".concat(t) : t;
        },
        nameLingthFun: function(t) {
            return t.length <= 10 ? t : "".concat(t.substr(0, 10), "...");
        },
        htmlDataFun: function() {
            console.log(this.data.target);
            var t = this.data.target.store, e = t.image, a = t.summary, n = t.title, r = this.data.target.date, o = r ? new Date(r) : new Date(), i = JSON.parse(wx.getStorageSync("ky_weapp_userInfo")), s = i.avatar, c = i.nickname;
            this.setData({
                titleText: n,
                day: this.fillZero(o.getDate()),
                month: o.getMonth(),
                summary: a,
                image: e,
                nickname: this.nameLingthFun(c),
                avatar: s
            });
        }
    },
    ready: function() {
        this.htmlDataFun();
    }
});