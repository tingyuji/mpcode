var e = require("../../@babel/runtime/helpers/interopRequireDefault"), t = require("../../@babel/runtime/helpers/slicedToArray"), n = e(require("../../@babel/runtime/regenerator")), a = require("../../@babel/runtime/helpers/objectSpread2"), i = require("../../@babel/runtime/helpers/asyncToGenerator"), r = require("../../utils/index"), o = require("../../api/index"), s = require("../../utils/enum"), u = getApp();

Page({
    data: {
        headerHeight: u.globalData.navHeight - u.globalData.navTop,
        statusBarHeight: u.globalData.navTop,
        animationIndex: -1,
        question: null,
        questionClass: !0,
        cardStyle: "",
        isPoster: !1,
        result: {
            id: null,
            store: {
                image: "",
                title: "",
                summary: ""
            },
            question: {
                question: "",
                answer: ""
            },
            date: null
        }
    },
    onLoad: function(e) {},
    onReady: function() {},
    onShow: function() {
        this.init();
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: "快和我一起来领取今天的幸运签吧！",
            path: "pages/daySign/daySign",
            imageUrl: "https://cdn.knowyourself.cc/together-wxapp/day-share.png"
        };
    },
    init: function() {
        var e = this;
        return i(n.default.mark(function t() {
            var i, r, s, u, l, c, d;
            return n.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.prev = 0, i = e.data.result, t.next = 4, o.wxService.getDaily();

                  case 4:
                    r = t.sent, s = r.id, u = r.date, r.user_id, l = r.question, c = r.store, d = 5 == l.options.length, 
                    s ? e.setData({
                        result: {
                            id: s,
                            store: c,
                            question: {
                                question: l.question,
                                answer: l.answer
                            },
                            date: u
                        },
                        isPoster: !0,
                        questionClass: d
                    }) : e.setData({
                        question: l,
                        result: a(a({}, i), {}, {
                            store: c
                        }),
                        questionClass: d
                    }), t.next = 17;
                    break;

                  case 14:
                    t.prev = 14, t.t0 = t.catch(0), console.error(t.t0);

                  case 17:
                  case "end":
                    return t.stop();
                }
            }, t, null, [ [ 0, 14 ] ]);
        }))();
    },
    closePoster: function() {
        this.setData({
            cardStyle: "",
            animationIndex: -1,
            isPoster: !1
        });
    },
    closeCard: function() {
        this.setData({
            cardStyle: "",
            animationIndex: -1
        });
    },
    toggleCard: function(e) {
        var n = this;
        if (!(wx.getStorageSync(s.KY_WEAPP_IS_REGISTERED) || !1)) return wx.showToast({
            title: "您还没有登录哦！",
            icon: "none",
            duration: 2e3
        }), setTimeout(function() {
            (0, r.goto)("/pages/login/login");
        }, 2e3), !1;
        var i = e.currentTarget.dataset.index, o = "#card".concat(i), u = wx.createSelectorQuery().in(this);
        u.select(o).boundingClientRect(), u.select(".day-root").boundingClientRect(), u.exec(function(e) {
            var a = t(e, 2), i = a[0], r = a[1], o = i.width, s = i.height, u = r.width, l = (r.height - s) / 2 - i.top, c = (u - o) / 2 - i.left;
            n.setData({
                cardStyle: "transform: translate(".concat(c, "px, ").concat(l, "px) scale(2.29)")
            }), setTimeout(function() {
                n.setData({
                    isPoster: !0
                });
            }, 100);
        });
        var l = this.data, c = l.question, d = l.result;
        this.setData({
            animationIndex: i,
            result: a(a({}, d), {}, {
                question: {
                    question: c.question,
                    answer: c.options[i].title
                }
            })
        });
    },
    back: function() {
        1 === getCurrentPages().length ? (0, r.goto)("/pages/mine/mine") : (0, r.goto)();
    }
});