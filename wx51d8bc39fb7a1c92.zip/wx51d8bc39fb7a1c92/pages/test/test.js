var t = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../libs/scroller"));

Page({
    data: {
        list: [ {
            id: "tab1",
            height: "400px",
            back: "gold"
        }, {
            id: "tab2",
            height: "400px",
            back: "green"
        }, {
            id: "tab3",
            height: "800px",
            back: "blue"
        } ],
        scrollTop: 0,
        offsetTop: null,
        customScrollTop: 0,
        activeIndex: 0
    },
    onReady: function() {
        this.init();
    },
    onShareAppMessage: function() {
        var t = wx._getUserInfo();
        return {
            title: "".concat(t ? t.nickname : "好友", "邀请你来体验心理百科小程序，体验多种心理自助工具")
        };
    },
    init: function() {
        var e = this, i = this.data.list.map(function(t) {
            return t.id;
        });
        this.scroller = new t.default({
            ids: i,
            tabId: "tab"
        }, function() {
            e.setData({
                offsetTop: e.scroller.offsetTop
            });
        });
    },
    onScroll: function(t) {
        var e = t.detail.scrollTop, i = this.scroller.find(e);
        this.setData({
            scrollTop: t.detail.scrollTop,
            activeIndex: i
        });
    },
    handleTab: function(t) {
        var e = t.currentTarget.dataset.index, i = this.scroller.tabRect.height, r = this.scroller.rect[e].top;
        this.setData({
            customScrollTop: r - i
        });
    }
});