var e = require("../../@babel/runtime/helpers/interopRequireDefault"), t = require("../../@babel/runtime/helpers/toConsumableArray"), a = e(require("../../@babel/runtime/regenerator")), n = require("../../@babel/runtime/helpers/asyncToGenerator"), i = require("../../api/index"), r = require("../../utils/enum"), s = getApp();

Page({
    data: {
        id: null,
        pageName: "",
        navList: [],
        navTempList: [],
        maxLen: 11,
        activeNavIndex: null,
        isCollapse: !1,
        detail: {
            id: null,
            title: "",
            desc: "",
            follow: !1
        },
        activeIndex: r.ENUM_ARTICLE,
        tapTypeList: [],
        tapList: [],
        finish: !1
    },
    onLoad: function(e) {
        var t = e.id, a = e.category_id;
        this.setData({
            id: t
        }), this.init(Number(a));
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        var e = wx._getUserInfo();
        return {
            title: "".concat(e ? e.nickname : "好友", "邀请你来体验心理百科小程序，体验多种心理自助工具")
        };
    },
    init: function(e) {
        var t = this;
        return n(a.default.mark(function n() {
            var r, s, o, l, c, u;
            return a.default.wrap(function(a) {
                for (;;) switch (a.prev = a.next) {
                  case 0:
                    return a.prev = 0, a.next = 3, i.wxService.queryCategoryById(t.data.id);

                  case 3:
                    if (r = a.sent, s = r.title, 0 !== (o = r.categories).length) {
                        a.next = 9;
                        break;
                    }
                    return wx.showToast({
                        title: "暂无二级类目",
                        icon: "none"
                    }), a.abrupt("return");

                  case 9:
                    l = o.length >= t.data.maxLen, c = e || o[0].id, u = o.filter(function(e) {
                        return e.id === c;
                    })[0], console.log(), t.setData({
                        pageName: s,
                        isCollapse: l,
                        navList: l ? o.slice(0, t.data.maxLen) : o,
                        navTempList: JSON.parse(JSON.stringify(o)),
                        activeNavIndex: c,
                        detail: {
                            id: u.id,
                            title: u.title,
                            desc: u.summary,
                            follow: u.follow
                        },
                        tapList: [],
                        finish: !1
                    }), t.search(), a.next = 20;
                    break;

                  case 17:
                    a.prev = 17, a.t0 = a.catch(0), console.error(a.t0);

                  case 20:
                  case "end":
                    return a.stop();
                }
            }, n, null, [ [ 0, 17 ] ]);
        }))();
    },
    handleChangeCollapse: function() {
        var e = !this.data.isCollapse, t = JSON.parse(JSON.stringify(this.data.navTempList));
        wx._trackEvent("clk_mini_book_detail_key1_12", {
            userid: s.globalData.user_id,
            key_id: -1
        }), this.setData({
            isCollapse: e,
            navList: e ? t.slice(0, this.data.maxLen) : t
        });
    },
    handleChioceNav: function(e) {
        var t = e.currentTarget.dataset.item;
        wx._trackEvent("clk_mini_book_detail_key1_12", {
            userid: s.globalData.user_id,
            key_id: t.id
        }), this.setData({
            activeIndex: r.ENUM_ARTICLE,
            activeNavIndex: t.id,
            detail: {
                id: t.id,
                title: t.title,
                desc: t.summary,
                follow: t.follow
            },
            tapList: [],
            finish: !1
        }), this.search();
    },
    handleChangeAttention: function() {
        var e = this;
        return n(a.default.mark(function t() {
            var n;
            return a.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.next = 2, loginState();

                  case 2:
                    if (t.sent) {
                        t.next = 5;
                        break;
                    }
                    return t.abrupt("return");

                  case 5:
                    return wx._trackEvent("clk_mini_book_detail_follow", {
                        userid: s.globalData.user_id
                    }), n = e.data.detail, t.prev = 7, t.next = 10, i.wxService.apiChangeCategoryFollow(n.id, {
                        status: n.follow ? 0 : 1
                    });

                  case 10:
                    wx.showToast({
                        title: n.follow ? "取消关注成功" : "关注成功"
                    }), setTimeout(function() {
                        e.init(e.data.activeNavIndex);
                    }, 1500), t.next = 17;
                    break;

                  case 14:
                    t.prev = 14, t.t0 = t.catch(7), console.error(t.t0);

                  case 17:
                  case "end":
                    return t.stop();
                }
            }, t, null, [ [ 7, 14 ] ]);
        }))();
    },
    handleChangeTap: function(e) {
        var t = this;
        return n(a.default.mark(function n() {
            var i;
            return a.default.wrap(function(a) {
                for (;;) switch (a.prev = a.next) {
                  case 0:
                    i = e.detail, wx._trackEvent("clk_mini_book_detail_kind1_5", {
                        userid: s.globalData.user_id,
                        detail_kind_id: i.activeIndex
                    }), t.setData({
                        activeIndex: i.activeIndex,
                        tapList: [],
                        finish: !1
                    }), t.search();

                  case 4:
                  case "end":
                    return a.stop();
                }
            }, n);
        }))();
    },
    hanleClickTabContent: function(e) {
        var t = e.detail;
        wx._trackEvent("clk_mini_book_detail_item", {
            userid: s.globalData.user_id,
            detail_item_id: t.target_id
        });
    },
    search: function() {
        var e = this;
        return n(a.default.mark(function n() {
            var r, s, o, l, c;
            return a.default.wrap(function(a) {
                for (;;) switch (a.prev = a.next) {
                  case 0:
                    if (a.prev = 0, !e.data.finish) {
                        a.next = 3;
                        break;
                    }
                    return a.abrupt("return");

                  case 3:
                    return r = {
                        category_id: e.data.detail.id,
                        type: e.data.activeIndex,
                        limit: 10,
                        offset: e.data.tapList.length
                    }, a.next = 6, i.wxService.searchList(r);

                  case 6:
                    s = a.sent, o = s.aggregations, l = s.list, c = s.count, e.setData({
                        tapTypeList: o,
                        tapList: [].concat(t(e.data.tapList), t(l)),
                        finish: l.length === c
                    }), 0 === e.data.tapList.length && o.some(function(e) {
                        return e.count > 0;
                    }) && (e.setData({
                        activeIndex: o.filter(function(e) {
                            return e.count > 0;
                        })[0].type,
                        finish: !1,
                        tapList: []
                    }), e.search()), a.next = 17;
                    break;

                  case 14:
                    a.prev = 14, a.t0 = a.catch(0), console.error(a.t0);

                  case 17:
                  case "end":
                    return a.stop();
                }
            }, n, null, [ [ 0, 14 ] ]);
        }))();
    },
    loginSuccess: function() {
        this.handleChangeAttention();
    }
});