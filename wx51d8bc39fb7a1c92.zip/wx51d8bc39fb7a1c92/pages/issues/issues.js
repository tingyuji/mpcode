var t = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/regenerator")), e = require("../../@babel/runtime/helpers/asyncToGenerator"), n = require("../../api/index"), a = require("../../utils/index");

Page({
    data: {
        tabList: [ {
            type: 0,
            title: "产品建议"
        }, {
            type: 1,
            title: "程序错误"
        }, {
            type: 2,
            title: "其他"
        } ],
        active: 0,
        content: "",
        contact: ""
    },
    onShareAppMessage: function() {
        var t = wx._getUserInfo();
        return {
            title: "".concat(t ? t.nickname : "好友", "邀请你来体验心理百科小程序，体验多种心理自助工具")
        };
    },
    hanldeChangeNav: function(t) {
        var e = t.currentTarget.dataset.index;
        this.setData({
            active: e
        });
    },
    handleSubmit: function() {
        if ("" === this.data.content) return wx.showToast({
            title: "请填写内容"
        });
        this.submit();
    },
    submit: function() {
        var r = this;
        return e(t.default.mark(function e() {
            var i, c, u, s, o, l;
            return t.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return i = r.data, c = i.contact, u = i.content, s = i.active, o = i.tabList, l = {
                        contact: c,
                        content: u,
                        type: o[s].type,
                        source: 1,
                        project_id: 1
                    }, t.next = 4, n.wxService.submitFeedback(l);

                  case 4:
                    wx.showToast({
                        title: "提交成功",
                        success: function() {
                            setTimeout(function() {
                                (0, a.goto)();
                            }, 1500);
                        }
                    });

                  case 5:
                  case "end":
                    return t.stop();
                }
            }, e);
        }))();
    }
});