var e = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/regenerator")), t = require("../../@babel/runtime/helpers/asyncToGenerator"), n = require("../../utils/goto"), r = require("../../api/index"), a = require("../../utils/enum");

getApp();

Page({
    data: {
        phone: "",
        code: "",
        isGetCode: !1,
        time: 60,
        timeInter: null
    },
    onLoad: function(e) {},
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        var e = wx._getUserInfo();
        return {
            title: "".concat(e ? e.nickname : "好友", "邀请你来体验心理百科小程序，体验多种心理自助工具")
        };
    },
    handleGetCode: function() {
        var n = this;
        return t(e.default.mark(function t() {
            var a, o, i;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if ("" !== n.data.phone) {
                        e.next = 3;
                        break;
                    }
                    return wx.showToast({
                        title: "请输入手机号",
                        icon: "none"
                    }), e.abrupt("return");

                  case 3:
                    return e.prev = 3, a = {
                        mobile: n.data.phone,
                        type: 1
                    }, e.next = 7, r.loginService.apiSendCode(a);

                  case 7:
                    o = e.sent, o.send && (wx.showToast({
                        title: "发送成功",
                        icon: "none"
                    }), i = setInterval(function() {
                        var e = n.data.time - 1;
                        n.setData({
                            time: e
                        }), 0 === e && (clearInterval(n.data.timeInter), n.setData({
                            isGetCode: !1,
                            timeInter: null
                        }));
                    }, 1e3), n.setData({
                        isGetCode: !0,
                        timeInter: i
                    })), e.next = 15;
                    break;

                  case 12:
                    e.prev = 12, e.t0 = e.catch(3), console.error(e.t0);

                  case 15:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 3, 12 ] ]);
        }))();
    },
    handleSubmit: function() {
        var o = this;
        return t(e.default.mark(function t() {
            var i, u, s;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if ("" !== o.data.phone) {
                        e.next = 3;
                        break;
                    }
                    return wx.showToast({
                        title: "请输入手机号",
                        icon: "none"
                    }), e.abrupt("return");

                  case 3:
                    if ("" !== o.data.code) {
                        e.next = 6;
                        break;
                    }
                    return wx.showToast({
                        title: "请输入验证码",
                        icon: "none"
                    }), e.abrupt("return");

                  case 6:
                    return e.prev = 6, i = {
                        mobile: o.data.phone,
                        code: o.data.code
                    }, e.next = 10, r.loginService.apiBindPhone(i);

                  case 10:
                    u = e.sent, s = u.is_registered, wx.showToast({
                        title: "登录成功"
                    }), wx.setStorageSync(a.KY_WEAPP_IS_REGISTERED, s), (0, n.goto)(1), e.next = 20;
                    break;

                  case 17:
                    e.prev = 17, e.t0 = e.catch(6), console.error(e.t0);

                  case 20:
                  case "end":
                    return e.stop();
                }
            }, t, null, [ [ 6, 17 ] ]);
        }))();
    }
});