var e = require("../../@babel/runtime/helpers/interopRequireDefault"), t = require("../../@babel/runtime/helpers/slicedToArray"), a = require("../../@babel/runtime/helpers/objectSpread2"), i = require("../../@babel/runtime/helpers/toConsumableArray"), n = e(require("../../@babel/runtime/regenerator")), r = require("../../@babel/runtime/helpers/asyncToGenerator"), s = require("../../api/index"), o = require("../../utils/index"), l = require("../../utils/loginState"), c = getApp(), d = {
    talk: "案例详情"
};

Page({
    data: {
        title: "文章详情",
        id: null,
        detail: null,
        editor_data_show: !0,
        activeIndex: 1,
        tapTypeList: [],
        tapList: [],
        finish: !1,
        isLike: !1,
        isScroll: !1,
        shareDialogVisible: !1,
        shareData: null,
        sendDialogVisible: !1,
        sendImgUrl: "",
        source: ""
    },
    onLoad: function(e) {
        var t = this;
        this.options = e;
        var a = Number(e.id), i = e.source || "";
        this.setData({
            id: a,
            source: i,
            title: d[i] || "文章详情"
        }), wx.nextTick(function() {
            t.widget = t.selectComponent(".widget");
        }), this.init();
    },
    onShareAppMessage: function(e) {
        return "talk" === this.data.source ? this.data.shareData : {
            title: this.data.detail.title,
            path: "/pages/articleDetail/articleDetail?id=".concat(this.data.id),
            imgUrl: this.data.detail.image,
            complete: function() {
                this.setData({
                    shareDialogVisible: !1
                });
            }
        };
    },
    init: function() {
        var e = this;
        return r(n.default.mark(function t() {
            var a, i, r, l, c, d, u, h, g, f;
            return n.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.prev = 0, t.next = 3, s.wxService.apiQueryArticleDetail(e.data.id);

                  case 3:
                    if ((a = t.sent).create_time = (0, o.secondToStr)(a.create_time), i = a.editor_data, 
                    r = i.author, l = i.editor, c = i.image, d = i.image_editor, u = i.plan_editor, 
                    h = r || u || d || l || c, e.setData({
                        editor_data_show: h,
                        detail: a
                    }), "talk" !== e.data.source) {
                        t.next = 14;
                        break;
                    }
                    return t.next = 11, s.wxService.getArticleShare();

                  case 11:
                    g = t.sent, f = {
                        title: g.title,
                        path: "/pages/articleDetail/articleDetail?id=".concat(e.data.id, "&source=talk"),
                        imgUrl: g.image
                    }, e.setData({
                        shareData: f
                    });

                  case 14:
                    t.next = 18;
                    break;

                  case 16:
                    t.prev = 16, t.t0 = t.catch(0);

                  case 18:
                  case "end":
                    return t.stop();
                }
            }, t, null, [ [ 0, 16 ] ]);
        }))();
    },
    handleChangeTap: function(e) {
        var t = e.detail;
        wx._trackEvent("clk_mini_book_article_kind1_5", {
            userid: c.globalData.user_id,
            article_kind_id: t.activeIndex
        }), this.setData({
            tapList: [],
            activeIndex: t.activeIndex,
            finish: !1
        }), this.search();
    },
    hanleClickTabContent: function(e) {
        var t = e.detail;
        wx._trackEvent("clk_mini_book_article_item", {
            userid: c.globalData.user_id,
            article_item_id: t.target_id
        });
    },
    search: function() {
        var e = this;
        return r(n.default.mark(function t() {
            var a, r, o, l, c;
            return n.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (t.prev = 0, !e.data.finish) {
                        t.next = 3;
                        break;
                    }
                    return t.abrupt("return");

                  case 3:
                    return a = {
                        keyword_id: e.data.detail.keywords.map(function(e) {
                            return e.id;
                        }).join(","),
                        type: e.data.activeIndex,
                        limit: 10,
                        offset: e.data.tapList.length
                    }, t.next = 6, s.wxService.searchList(a);

                  case 6:
                    r = t.sent, o = r.aggregations, l = r.list, c = r.count, e.setData({
                        tapTypeList: o,
                        tapList: [].concat(i(e.data.tapList), i(l.filter(function(t) {
                            return t.target_id !== e.data.id;
                        }))),
                        finish: l.length === c
                    }), t.next = 16;
                    break;

                  case 13:
                    t.prev = 13, t.t0 = t.catch(0), console.error(t.t0);

                  case 16:
                  case "end":
                    return t.stop();
                }
            }, t, null, [ [ 0, 13 ] ]);
        }))();
    },
    handleChangeIsLike: function() {
        var e = this;
        return r(n.default.mark(function t() {
            var a;
            return n.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.next = 2, (0, l.loginState)();

                  case 2:
                    if (t.sent) {
                        t.next = 5;
                        break;
                    }
                    return t.abrupt("return");

                  case 5:
                    return wx._trackEvent("clk_mini_book_article_helpful", {
                        userid: c.globalData.user_id
                    }), t.prev = 6, a = {
                        follow_type: 2,
                        status: e.data.detail.is_zan ? 0 : 1
                    }, t.next = 10, s.wxService.apiChangeArticleStatus(e.data.detail.id, a);

                  case 10:
                    e.init(), t.next = 15;
                    break;

                  case 13:
                    t.prev = 13, t.t0 = t.catch(6);

                  case 15:
                  case "end":
                    return t.stop();
                }
            }, t, null, [ [ 6, 13 ] ]);
        }))();
    },
    handleChangeIsFollow: function() {
        var e = this;
        return r(n.default.mark(function t() {
            var a;
            return n.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.next = 2, (0, l.loginState)();

                  case 2:
                    if (t.sent) {
                        t.next = 5;
                        break;
                    }
                    return t.abrupt("return");

                  case 5:
                    return wx._trackEvent("clk_mini_book_article_favor", {
                        userid: c.globalData.user_id
                    }), t.prev = 6, a = {
                        follow_type: 1,
                        status: e.data.detail.is_follow ? 0 : 1
                    }, t.next = 10, s.wxService.apiChangeArticleStatus(e.data.detail.id, a);

                  case 10:
                    wx.showToast({
                        title: e.data.detail.is_follow ? "取消收藏" : "收藏成功"
                    }), setTimeout(function() {
                        e.init();
                    }, 1500), t.next = 16;
                    break;

                  case 14:
                    t.prev = 14, t.t0 = t.catch(6);

                  case 16:
                  case "end":
                    return t.stop();
                }
            }, t, null, [ [ 6, 14 ] ]);
        }))();
    },
    handlePreview: function(e) {
        var t = e.currentTarget.dataset.src;
        wx.previewImage({
            current: t,
            urls: [ t ]
        });
    },
    handleChangeDialog: function() {
        var e = this;
        return r(n.default.mark(function t() {
            return n.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.next = 2, (0, l.loginState)();

                  case 2:
                    if (t.sent) {
                        t.next = 5;
                        break;
                    }
                    return t.abrupt("return");

                  case 5:
                    wx._trackEvent("clk_mini_book_article_share", {
                        userid: c.globalData.user_id
                    }), e.setData({
                        isScroll: !e.data.isScroll,
                        shareDialogVisible: !e.data.shareDialogVisible
                    });

                  case 7:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    },
    renderToCanvas: function() {
        var e = this;
        return r(n.default.mark(function i() {
            var r, o, l, d, u, h;
            return n.default.wrap(function(i) {
                for (;;) switch (i.prev = i.next) {
                  case 0:
                    return console.log(111111), wx._trackEvent("clk_mini_book_article_share_picture", {
                        userid: c.globalData.user_id
                    }), r = {
                        sceneData: a(a({}, e.options), {}, {
                            page: "pages/articleDetail/articleDetail"
                        }),
                        optional: {
                            page: "pages/index/index"
                        }
                    }, i.next = 5, Promise.all([ s.saleService.getQrcode(r) ]);

                  case 5:
                    o = i.sent, l = t(o, 1), d = l[0].object, e.setData({
                        shareDialogVisible: !1,
                        sendDialogVisible: !0
                    }), u = '\n      <view class="container" >\n        <view class="send-banner">\n          <image class="send-banner-img" src="'.concat(e.data.detail.image, '" mode="aspectFit"></image>\n        </view>\n        <view class="content">\n          <text class="send-title-text">').concat(e.data.detail.title, '</text>\n          <view class="logo-panel">\n            <image class="logo-img" src="../../assets/img/ky-logo.png" />\n            <text class="logo-text">KnowYourself</text>\n          </view>\n          <view class="footer">\n            <view class="footer-left">\n              <text class="footer-title">长按识别小程序码</text>\n              <text class="footer-desc">引领身心健康的生活方式</text>\n            </view>\n            <image class="footer-img" src="').concat(d, '" />\n          </view>\n        </view>\n      </view>\n      '), 
                    h = {
                        container: {
                            width: 325,
                            height: 425,
                            backgroundColor: "#FFFFFF",
                            borderRadius: 2
                        },
                        sendBanner: {
                            width: 325,
                            height: 204
                        },
                        sendBannerImg: {
                            width: 325,
                            height: 204
                        },
                        content: {
                            width: 325,
                            height: 222,
                            paddingLeft: 20,
                            paddingRight: 20,
                            paddingTop: 16,
                            paddingBottom: 16
                        },
                        sendTitleText: {
                            width: 285,
                            height: 50,
                            fontSize: 15,
                            color: "#1A1A1A"
                        },
                        logoPanel: {
                            width: 285,
                            height: 32,
                            marginTop: 16,
                            marginBottom: 32,
                            flexDirection: "row",
                            justifyContent: "flex-start",
                            alignItems: "center"
                        },
                        logoImg: {
                            width: 32,
                            height: 32,
                            borderRadius: 16
                        },
                        logoText: {
                            width: 120,
                            height: 32,
                            fontSize: 13,
                            color: "#2B2B2B",
                            marginLeft: 8,
                            lineHeight: 32
                        },
                        footer: {
                            width: 285,
                            height: 56,
                            flexDirection: "row",
                            justifyContent: "space-between",
                            alignItems: "center"
                        },
                        footerLeft: {
                            width: 220,
                            height: 56,
                            flexDirection: "column",
                            justifyContent: "space-around"
                        },
                        footerTitle: {
                            width: 220,
                            height: 28,
                            lineHeight: 28,
                            fontSize: 13,
                            color: "#1A1A1A"
                        },
                        footerDesc: {
                            width: 220,
                            height: 20,
                            lineHeight: 20,
                            fontSize: 11,
                            color: "#9D9D9D"
                        },
                        footerImg: {
                            width: 56,
                            height: 56,
                            borderRadius: 28
                        }
                    }, e.widget.renderToCanvas({
                        wxml: u,
                        style: h
                    }).then(function(t) {
                        e.container = t, e.extraImage();
                    });

                  case 13:
                  case "end":
                    return i.stop();
                }
            }, i);
        }))();
    },
    extraImage: function() {
        wx._trackEvent("clk_mini_book_article_share_picture_save", {
            userid: c.globalData.user_id
        });
        var e = this;
        this.widget.canvasToTempFilePath().then(function(t) {
            wx.saveImageToPhotosAlbum({
                filePath: t.tempFilePath,
                success: function(e) {
                    wx.showToast({
                        title: "保存成功"
                    });
                },
                fail: function() {
                    wx.showModal({
                        title: "提示",
                        content: "需要您授权保存相册",
                        showCancel: !1,
                        success: function() {
                            wx.openSetting({
                                success: function(e) {
                                    e.authSetting["scope.writePhotosAlbum"] ? wx.showModal({
                                        title: "提示",
                                        content: "获取权限成功,再次保存图片即可成功",
                                        showCancel: !1
                                    }) : wx.showModal({
                                        title: "提示",
                                        content: "获取权限失败，无法保存到相册",
                                        showCancel: !1
                                    });
                                },
                                complete: function(e) {}
                            });
                        }
                    });
                },
                complete: function() {
                    e.setData({
                        isScroll: !1,
                        sendDialogVisible: !1
                    });
                }
            });
        });
    },
    handleCloseSendDialog: function() {
        this.setData({
            isScroll: !1,
            sendDialogVisible: !1
        });
    },
    handleTalkMore: function() {
        wx._trackEvent("clk_mini_heal_case_write", {
            userid: c.globalData.user_id
        }), wx.showModal({
            title: "温馨提示",
            content: "十分抱歉，由于相关规定，您暂时无法在小程序使用该功能",
            showCancel: !1,
            confirmText: "知道了",
            confirmColor: "#07c160"
        });
    },
    linktap: function(e) {
        "jump" === e.detail["data-behavior"] && (0, o.goto)(e.detail.href);
    },
    shareFriend: function() {
        wx._trackEvent("clk_mini_book_article_share_friend", {
            userid: c.globalData.user_id
        }), this.setData({
            shareDialogVisible: !1
        });
    },
    toArticleList: function(e) {
        var t = e.currentTarget.dataset.item, a = t.id, i = t.keyword;
        (0, o.goto)("/pages/articleList/articleList?id=".concat(a, "&title=").concat(i));
    }
});