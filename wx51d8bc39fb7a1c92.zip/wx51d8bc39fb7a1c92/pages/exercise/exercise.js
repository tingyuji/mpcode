var e = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/regenerator")), r = require("../../@babel/runtime/helpers/slicedToArray"), i = require("../../@babel/runtime/helpers/asyncToGenerator"), n = require("../../utils/index"), t = require("../../api/index"), a = require("../../utils/enum"), c = getApp();

Page({
    data: {
        bannerList: [],
        recommendList: []
    },
    onLoad: function(e) {
        this.init();
    },
    onShareAppMessage: function() {
        var e = wx._getUserInfo();
        return {
            title: "".concat(e ? e.nickname : "好友", "邀请你来体验心理百科小程序，体验多种心理自助工具")
        };
    },
    init: function() {
        var n = this;
        return i(e.default.mark(function i() {
            var c, s, o, u, l;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return wx.showLoading({
                        title: "加载中..."
                    }), e.prev = 1, c = {
                        autoLoading: !1
                    }, e.next = 5, Promise.all([ t.dpService.getHome({}, c), t.wxService.findBannerList(a.ENUM_PLAN, c) ]);

                  case 5:
                    s = e.sent, o = r(s, 2), u = o[0].recommends, l = o[1], n.setData({
                        recommendList: u,
                        bannerList: l
                    }), wx.hideLoading(), e.next = 16;
                    break;

                  case 13:
                    e.prev = 13, e.t0 = e.catch(1), wx.showToast({
                        title: JSON.stringify(e.t0),
                        icon: "none"
                    });

                  case 16:
                  case "end":
                    return e.stop();
                }
            }, i, null, [ [ 1, 13 ] ]);
        }))();
    },
    handleExercise: function(e) {
        var r = e.currentTarget.dataset.item;
        wx._trackEvent("clk_mini_prac_main_recommend", {
            userid: c.globalData.user_id,
            recommend_prac_id: r.id
        });
    },
    goExerciseAll: function() {
        wx._trackEvent("clk_mini_prac_main_recommend_more", {
            userid: c.globalData.user_id
        }), (0, n.goto)("/pages/exerciseList/exerciseList");
    },
    handleChoiceExercise: function() {
        wx._trackEvent("clk_mini_prac_main_custom", {
            userid: c.globalData.user_id
        }), (0, n.goto)("/pages/exerciseChoice/exerciseChoice");
    },
    handleClickSwiper: function(e) {
        wx._trackEvent("clk_mini_prac_main_video", {
            userid: c.globalData.user_id
        });
    }
});