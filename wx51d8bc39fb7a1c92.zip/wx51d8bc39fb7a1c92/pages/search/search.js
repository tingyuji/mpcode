var e = require("../../@babel/runtime/helpers/interopRequireDefault"), t = require("../../@babel/runtime/helpers/toConsumableArray"), a = e(require("../../@babel/runtime/regenerator")), r = require("../../@babel/runtime/helpers/asyncToGenerator"), i = require("../../utils/enum"), s = require("../../api/index"), n = require("../../utils/index"), o = getApp(), c = {
    0: "../meditationCategory/meditationCategory",
    1: "../evaluationCategory/evaluationCategory",
    2: "../exercise/exercise"
};

Page({
    data: {
        placeholder: "搜索你感兴趣的内容",
        searchUrl: "",
        searchValue: "",
        hasSearch: !1,
        hasResult: !1,
        historyList: [],
        hotList: [],
        toolList: [ {
            src: "https://kystatic.oss-cn-shanghai.aliyuncs.com/together-wxapp/meditation.jpg"
        }, {
            src: "https://kystatic.oss-cn-shanghai.aliyuncs.com/together-wxapp/exam.jpg"
        } ],
        activeIndex: i.ENUM_ARTICLE,
        tapTypeList: [],
        tapList: [],
        finish: !1
    },
    onLoad: function(e) {
        this.init();
        try {
            var t = wx.getStorageSync(i.HISTORY_KEY);
            t && this.setData({
                historyList: JSON.parse(t)
            });
        } catch (e) {
            console.error(e);
        }
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        var e = wx._getUserInfo();
        return {
            title: "".concat(e ? e.nickname : "好友", "邀请你来体验心理百科小程序，体验多种心理自助工具")
        };
    },
    init: function() {
        var e = this;
        return r(a.default.mark(function t() {
            var r, i, n;
            return a.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.next = 2, s.wxService.getHome();

                  case 2:
                    r = t.sent, i = r.hot_search, n = r.placeholder, e.setData({
                        placeholder: 0 === n.length ? "搜索你感兴趣的内容" : n[0].title,
                        searchUrl: 0 === n.length ? "../search/search" : n[0].url,
                        hotList: i
                    });

                  case 6:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    },
    handleChangeSearch: function() {},
    handleSearch: function() {
        if (wx._trackEvent("clk_mini_book_searchPage_search", {
            userid: o.globalData.user_id
        }), "" !== this.data.searchValue) {
            var e = this.data.historyList;
            e.length >= 9 && (e = e.splice(0, 1)), e.unshift(this.data.searchValue), wx.setStorageSync(i.HISTORY_KEY, JSON.stringify(e)), 
            this.setData({
                historyList: e,
                tapList: [],
                finish: !1
            }), this.search();
        } else "搜索你感兴趣的内容" !== this.data.placeholder && "" !== this.data.searchUrl && (0, 
        n.goto)(this.data.searchUrl);
    },
    handleClearSearch: function() {
        this.setData({
            searchValue: "",
            hasSearch: !1,
            hasResult: !1,
            tapList: [],
            finish: !1
        });
    },
    handleClearHistory: function() {
        wx._trackEvent("clk_mini_book_searchPage_del", {
            userid: o.globalData.user_id
        }), wx.removeStorageSync(i.HISTORY_KEY), this.setData({
            historyList: []
        });
    },
    handleChoice: function(e) {
        var t = e.currentTarget.dataset.item;
        wx._trackEvent("clk_mini_book_searchPage_history", {
            userid: o.globalData.user_id,
            his_id: t
        }), this.setData({
            searchValue: t,
            hasSearch: !0
        }), this.search();
    },
    handleChoiceHot: function(e) {
        var t = e.currentTarget.dataset.item;
        wx._trackEvent("clk_mini_book_searchPage_history", {
            userid: o.globalData.user_id,
            hot_id: t.id
        }), (0, n.goto)(t.url);
    },
    handleChangeTap: function(e) {
        var t = e.detail;
        wx._trackEvent("clk_mini_book_result_kind1_5", {
            userid: o.globalData.user_id,
            result_kind_id: t.activeIndex
        }), this.setData({
            activeIndex: t.activeIndex,
            tapList: [],
            finish: !1
        }), this.search();
    },
    hanleClickTabContent: function(e) {
        var t = e.detail;
        wx._trackEvent("clk_mini_book_result_item", {
            userid: o.globalData.user_id,
            result_item_id: t.target_id
        });
    },
    search: function() {
        var e = this;
        return r(a.default.mark(function r() {
            var i, n, o, c, h;
            return a.default.wrap(function(a) {
                for (;;) switch (a.prev = a.next) {
                  case 0:
                    if (a.prev = 0, !e.data.finish) {
                        a.next = 3;
                        break;
                    }
                    return a.abrupt("return");

                  case 3:
                    return i = {
                        keyword: e.data.searchValue,
                        type: e.data.activeIndex,
                        limit: 10,
                        offset: e.data.tapList.length
                    }, a.next = 6, s.wxService.searchList(i);

                  case 6:
                    n = a.sent, o = n.aggregations, c = n.list, h = n.count, e.setData({
                        tapTypeList: o,
                        tapList: [].concat(t(e.data.tapList), t(c)),
                        hasSearch: "" !== e.data.searchValue,
                        hasResult: 0 === c.length,
                        finish: c.length === h
                    }), 0 === e.data.tapList.length && o.some(function(e) {
                        return e.count > 0;
                    }) && (e.setData({
                        activeIndex: o.filter(function(e) {
                            return e.count > 0;
                        })[0].type,
                        finish: !1,
                        tapList: []
                    }), e.search()), a.next = 17;
                    break;

                  case 14:
                    a.prev = 14, a.t0 = a.catch(0), console.error(a.t0);

                  case 17:
                  case "end":
                    return a.stop();
                }
            }, r, null, [ [ 0, 14 ] ]);
        }))();
    },
    handleGotoTools: function(e) {
        var t = e.currentTarget.dataset.index;
        wx._trackEvent("clk_mini_book_searchPage_tool1_3", {
            userid: o.globalData.user_id,
            tools_id: t + 1
        });
        var a = c[t];
        (0, n.goto)(a);
    }
});