var e = require("../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../@babel/runtime/regenerator")), r = require("../../@babel/runtime/helpers/asyncToGenerator"), a = e(require("../../libs/lower")), i = require("../../api/index");

Page({
    data: {
        title: "",
        articleTarget: null
    },
    onLoad: function(e) {
        var t = e.id, r = e.title;
        this.params = {
            type: 1,
            keyword_id: t,
            limit: 20,
            offset: 0
        };
        var n = new a.default(i.wxService.searchList, this.params);
        this.setData({
            title: r,
            articleTarget: n
        }), this.getList();
    },
    getList: function() {
        var e = this;
        return r(t.default.mark(function r() {
            var a;
            return t.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return a = e.data.articleTarget, t.next = 3, a.getList();

                  case 3:
                    e.setData({
                        articleTarget: a
                    });

                  case 4:
                  case "end":
                    return t.stop();
                }
            }, r);
        }))();
    },
    onShareAppMessage: function() {
        var e = wx._getUserInfo();
        return {
            title: "".concat(e ? e.nickname : "好友", "邀请你来体验心理百科小程序，体验多种心理自助工具")
        };
    }
});