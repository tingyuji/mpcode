var e = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/regenerator")), t = require("../../@babel/runtime/helpers/slicedToArray"), n = require("../../@babel/runtime/helpers/asyncToGenerator"), r = require("../../utils/enum"), a = require("../../api/index"), i = getApp();

Page({
    data: {
        bannerList: [],
        caseList: [],
        commentList: []
    },
    onLoad: function(e) {
        this.init();
    },
    init: function() {
        var i = this;
        return n(e.default.mark(function n() {
            var o, s, c, u, l, m, d;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return wx.showLoading({
                        title: "加载中..."
                    }), e.prev = 1, o = {
                        autoLoading: !1
                    }, s = {
                        random: 1
                    }, e.next = 6, Promise.all([ a.consultService.getVirtualcase({}, o), a.consultService.getComment(s, o), a.wxService.findBannerList(r.ENUM_BANNER_TALK, o) ]);

                  case 6:
                    c = e.sent, u = t(c, 3), l = u[0].list, m = u[1], d = u[2], i.setData({
                        caseList: l,
                        commentList: m,
                        bannerList: d
                    }), wx.hideLoading(), e.next = 18;
                    break;

                  case 15:
                    e.prev = 15, e.t0 = e.catch(1), wx.showToast({
                        title: e.t0
                    });

                  case 18:
                  case "end":
                    return e.stop();
                }
            }, n, null, [ [ 1, 15 ] ]);
        }))();
    },
    getComment: function() {
        return n(e.default.mark(function t() {
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    onShareAppMessage: function() {
        var e = wx._getUserInfo();
        return {
            title: "".concat(e ? e.nickname : "好友", "邀请你来体验心理百科小程序，体验多种心理自助工具")
        };
    },
    toggleCustomer: function() {
        wx._trackEvent("clk_mini_heal_main_write", {
            userid: i.globalData.user_id
        }), wx.showModal({
            title: "温馨提示",
            content: "十分抱歉，由于相关规定，您暂时无法在小程序进行该测评",
            showCancel: !1,
            confirmText: "知道了",
            confirmColor: "#07c160"
        });
    },
    handleItem: function(e) {
        var t = e.currentTarget.dataset.item;
        wx._trackEvent("clk_mini_heal_main_case", {
            userid: i.globalData.user_id,
            heal_case_id: t.id
        });
    },
    resetRectComment: function() {
        wx._trackEvent("clk_mini_heal_main_comment_like_unfold_fold", {
            userid: i.globalData.user_id
        });
    }
});