var e = require("../../@babel/runtime/helpers/interopRequireDefault"), t = require("../../@babel/runtime/helpers/toConsumableArray"), a = e(require("../../@babel/runtime/regenerator")), i = require("../../@babel/runtime/helpers/asyncToGenerator"), r = require("../../@babel/runtime/helpers/defineProperty"), n = require("../../api/index"), s = require("../../utils/index"), o = require("../../config/meditation"), u = !1, d = getApp();

Page({
    data: r({
        tabIndex: 0,
        tabList: [ {
            mode: o.MODE_SERIES,
            title: "系列"
        }, {
            mode: o.MODE_AUDIO,
            title: "单音频"
        } ],
        activeIndex: 0,
        sideBarList: [],
        list: [],
        end: !1,
        type: o.TYPE_AUDIO
    }, "list", []),
    onLoad: function(e) {
        this.init();
    },
    onShareAppMessage: function() {
        var e = wx._getUserInfo();
        return {
            title: "".concat(e ? e.nickname : "好友", "邀请你来体验心理百科小程序，体验多种心理自助工具")
        };
    },
    init: function() {
        var e = this;
        return i(a.default.mark(function t() {
            return a.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    e.getCategory();

                  case 1:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    },
    getCategory: function() {
        var e = this;
        return i(a.default.mark(function t() {
            var i, r, s;
            return a.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return i = e.data.type, r = {
                        type: i
                    }, t.next = 4, n.meditationService.getCategory(r);

                  case 4:
                    s = t.sent, e.setData({
                        sideBarList: s
                    }, e.getCategoryDetail);

                  case 6:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    },
    getCategoryDetail: function() {
        var e = this;
        return i(a.default.mark(function i() {
            var r, o, d, c, l, g, m, p, _, f, b, h, y, x;
            return a.default.wrap(function(a) {
                for (;;) switch (a.prev = a.next) {
                  case 0:
                    if (r = e.data, o = r.end, d = r.list, c = r.sideBarList, l = r.activeIndex, g = r.tabIndex, 
                    m = r.tabList, p = r.type, !o) {
                        a.next = 3;
                        break;
                    }
                    return a.abrupt("return");

                  case 3:
                    return _ = m[g].mode, f = {
                        type: p,
                        mode: _,
                        limit: 20,
                        offset: d.length,
                        category_id: c[l].id
                    }, a.next = 7, n.meditationService.getCategoryDetail(f);

                  case 7:
                    if (b = a.sent, h = b.count, (y = b.list).forEach(function(e) {
                        e.duration = (0, s.timeToStr)(e.duration), e.play_count = (0, s.toThousands)(e.play_count);
                    }), x = [].concat(t(d), t(y)), e.setData({
                        list: x,
                        end: h === x.length
                    }), x.length) {
                        a.next = 18;
                        break;
                    }
                    if (!u) {
                        a.next = 16;
                        break;
                    }
                    return a.abrupt("return");

                  case 16:
                    u = !0, e.setData({
                        tabIndex: 0 === g ? 1 : 0,
                        end: !1,
                        list: []
                    }, e.getCategoryDetail);

                  case 18:
                  case "end":
                    return a.stop();
                }
            }, i);
        }))();
    },
    handleChangeSideBar: function(e) {
        u = !1;
        var t = e.currentTarget.dataset.index;
        wx._trackEvent("clk_mini_medi_main_type1_8", {
            userid: d.globalData.user_id,
            medi_main_type: t
        }), this.setData({
            activeIndex: Number(t),
            end: !1,
            list: []
        }, this.getCategoryDetail);
    },
    handleTab: function(e) {
        u = !0;
        var t = e.currentTarget.dataset.index, a = 0 === t ? "clk_mini_medi_main_series" : "clk_mini_medi_main_single";
        wx._trackEvent(a, {
            userid: d.globalData.user_id
        }), this.setData({
            tabIndex: t,
            end: !1,
            list: []
        }, this.getCategoryDetail);
    },
    handleItem: function(e) {
        var t = e.detail, a = t.id, i = t.mode;
        wx._trackEvent("clk_mini_medi_main_type_audio", {
            userid: d.globalData.user_id,
            audio_id: a
        }), i === o.MODE_SERIES ? (0, s.goto)("/pages/meditationDetail/meditationDetail?id=".concat(a)) : (0, 
        s.goto)("/pages/player/player?courseId=".concat(a));
    }
});