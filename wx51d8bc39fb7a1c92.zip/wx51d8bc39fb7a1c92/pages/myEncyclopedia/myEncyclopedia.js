var e = require("../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../@babel/runtime/regenerator")), a = require("../../@babel/runtime/helpers/asyncToGenerator"), r = require("../../api/index"), i = e(require("../../libs/lower")), n = getApp(), s = {
    offset: 0,
    limit: 20,
    follow_type: 1,
    target_type: 1
}, l = {
    offset: 0,
    limit: 20,
    follow_type: 1,
    target_type: 2
}, u = {
    offset: 0,
    limit: 20,
    follow_type: 2,
    target_type: 2
};

Page({
    data: {
        offsetTop: n.globalData.navHeight,
        active: 0,
        focusTarget: null,
        starTarget: null,
        likeTarget: null
    },
    onLoad: function(e) {
        var t = this.data.active;
        e.active && e.active !== t ? this.setData({
            active: +e.active
        }) : this.getList();
    },
    onShareAppMessage: function() {
        var e = wx._getUserInfo();
        return {
            title: "".concat(e ? e.nickname : "好友", "邀请你来体验心理百科小程序，体验多种心理自助工具")
        };
    },
    getList: function() {
        var e = this;
        return a(t.default.mark(function a() {
            var n, o, c, g, f;
            return t.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (n = e.data, o = n.active, c = n.focusTarget, g = n.starTarget, f = n.likeTarget, 
                    0 !== o) {
                        t.next = 10;
                        break;
                    }
                    if (!c && (c = new i.default(r.wxService.getFollowList, s)), !c.end) {
                        t.next = 5;
                        break;
                    }
                    return t.abrupt("return");

                  case 5:
                    return t.next = 7, c.getList();

                  case 7:
                    e.setData({
                        focusTarget: c
                    }), t.next = 25;
                    break;

                  case 10:
                    if (1 !== o) {
                        t.next = 19;
                        break;
                    }
                    if (!g && (g = new i.default(r.wxService.getFollowList, l)), !g.end) {
                        t.next = 14;
                        break;
                    }
                    return t.abrupt("return");

                  case 14:
                    return t.next = 16, g.getList();

                  case 16:
                    e.setData({
                        starTarget: g
                    }), t.next = 25;
                    break;

                  case 19:
                    if (!f && (f = new i.default(r.wxService.getFollowList, u)), !f.end) {
                        t.next = 22;
                        break;
                    }
                    return t.abrupt("return");

                  case 22:
                    return t.next = 24, f.getList();

                  case 24:
                    e.setData({
                        likeTarget: f
                    });

                  case 25:
                  case "end":
                    return t.stop();
                }
            }, a);
        }))();
    },
    handleTabChange: function(e) {
        wx._trackEvent("clk_mini_mine_bookPage_follow_favor_like", {
            userid: n.globalData.user_id
        });
        var t = e.detail.index;
        this.setData({
            active: t
        });
        var a = this.data, r = a.focusTarget, i = a.starTarget, s = a.likeTarget;
        !(r && r.list.length && i && i.list.length && s && s.list.length) && this.getList();
    },
    handleItem: function(e) {
        var t = e.currentTarget.dataset.item;
        wx._trackEvent("clk_mini_mine_bookPage_article", {
            userid: n.globalData.user_id,
            mine_article_id: t.id
        });
    }
});