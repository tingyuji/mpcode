Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.pageScrollMixin = void 0;

var e = require("../common/utils");

function r(r) {
    var n = e.getCurrentPage().vanPageScroller;
    (void 0 === n ? [] : n).forEach(function(e) {
        "function" == typeof e && e(r);
    });
}

exports.pageScrollMixin = function(n) {
    return Behavior({
        attached: function() {
            var o = e.getCurrentPage();
            Array.isArray(o.vanPageScroller) ? o.vanPageScroller.push(n.bind(this)) : o.vanPageScroller = "function" == typeof o.onPageScroll ? [ o.onPageScroll.bind(o), n.bind(this) ] : [ n.bind(this) ], 
            o.onPageScroll = r;
        },
        detached: function() {
            var r, o = e.getCurrentPage();
            o.vanPageScroller = (null === (r = o.vanPageScroller) || void 0 === r ? void 0 : r.filter(function(e) {
                return e !== n;
            })) || [];
        }
    });
};