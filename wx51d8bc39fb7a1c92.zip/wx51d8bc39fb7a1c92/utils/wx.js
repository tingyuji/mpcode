var e = require("./enum"), r = require("./goto");

wx._getUserInfo = function() {
    var r = wx.getStorageSync(e.KY_WEAPP_USER_INFO);
    if (r) try {
        r = JSON.parse(r);
    } catch (e) {}
    return r;
}, wx._forceLogin = function() {
    wx.getStorageSync(e.KY_WEAPP_TOKEN) || (0, r.goto)("/pages/login/login");
};