function t(t, r) {
    var e = t.toString(), n = r.toString(), i = 0;
    try {
        i += e.split(".")[1].length;
    } catch (t) {}
    try {
        i += n.split(".")[1].length;
    } catch (t) {}
    return Number(e.replace(".", "")) * n.replace(".", "") / Math.pow(10, i);
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.divide = function(t, r) {
    var e = function(t, r) {
        var e, n;
        try {
            e = t.toString().split(".")[1].length;
        } catch (t) {
            e = 0;
        }
        try {
            n = r.toString().split(".")[1].length;
        } catch (t) {
            n = 0;
        }
        return [ e, n ];
    }(t, r), n = e[0], i = e[1], c = +t.toString().replace(".", ""), o = +r.toString().replace(".", "");
    return c / o * Math.pow(10, i - n);
}, exports.minus = function(r, e) {
    var n, i, c, o;
    try {
        n = r.toString().split(".")[1].length;
    } catch (t) {
        n = 0;
    }
    try {
        i = e.toString().split(".")[1].length;
    } catch (t) {
        i = 0;
    }
    return c = Math.pow(10, Math.max(n, i)), o = n >= i ? n : i, +((t(r, c) - t(e, c)) / c).toFixed(o);
}, exports.multiply = t, exports.plus = function(r, e) {
    var n, i, c;
    try {
        n = r.toString().split(".")[1].length;
    } catch (t) {
        n = 0;
    }
    try {
        i = e.toString().split(".")[1].length;
    } catch (t) {
        i = 0;
    }
    return c = Math.pow(10, Math.max(n, i)), (t(r, c) + t(e, c)) / c;
};