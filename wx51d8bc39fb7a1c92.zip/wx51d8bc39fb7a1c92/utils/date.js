function t(t) {
    var e = t;
    return e < 10 && e >= 0 && (e = "0".concat(e)), e;
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.num2fill = t, exports.second2DHMS = function(e) {
    if (!e) return {
        d: 0,
        h: 0,
        m: 0,
        s: 0
    };
    var n = new Date(e), o = Math.floor(n / 1e3 / 60 / 60 / 24), c = t(Math.floor(n / 1e3 / 60 / 60 % 24)), r = t(Math.floor(n / 1e3 / 60 % 60)), a = t(Math.floor(n / 1e3 % 60));
    return {
        d: o,
        h: c,
        m: r,
        s: a
    };
}, exports.secondToMD = function(t) {
    (t = new Date(1e3 * t)).getFullYear();
    var e = t.getMonth() + 1, n = t.getDate();
    return "".concat(e, "-").concat(n);
}, exports.secondToStr = function(t) {
    var e = (t = new Date(1e3 * t)).getFullYear(), n = t.getMonth() + 1, o = t.getDate();
    return "".concat(e, "-").concat(n, "-").concat(o);
}, exports.timeToStr = function(t) {
    var e = parseInt(t / 60 / 60 % 60), n = parseInt(t / 60 % 60), o = parseInt(t % 60);
    return e = e < 10 ? "0".concat(e) : e, n = n < 10 ? "0".concat(n) : n, o = o < 10 ? "0".concat(o) : o, 
    0 === Number(e) ? "".concat(n, ":").concat(o) : "".concat(e, ":").concat(n, ":").concat(o);
};