Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.addParams = i, exports.getVarType = r, exports.goBack = function() {}, 
exports.goto = function(e) {
    var o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "navigateTo", i = r(e);
    if ("Number" === i || "Null" === i || "Undefined" === i) return o = "navigateBack", 
    void wx[o](e);
    var s = a(e), u = getCurrentPages(), c = n.some(function(e) {
        return e === s.url;
    }), p = u.length >= 10;
    p && (o = "redirectTo");
    c && (o = "reLaunch");
    (0, t.setListData)(s), wx[o](s);
}, exports.isWeb = o;

var e = require("../@babel/runtime/helpers/objectSpread2"), t = require("./dataCollect");

function r(e) {
    return Object.prototype.toString.call(e).match(/\s(\S+)]$/), RegExp.$1;
}

var n = [ "/pages/index/index", "/pages/tools/tools", "/pages/mine/mine" ];

function a(t) {
    var n = r(t), a = "", s = {};
    if ("Object" === n) {
        var u = t.path, c = t.params, p = t.events, l = t.fail, v = t.success;
        s = {
            url: a = i(u, c),
            events: p,
            fail: l,
            success: v
        };
    } else "String" === n && (a = t, o(t) && (a = "".concat("/pages/webview/webview", "?url=").concat(encodeURIComponent(t))));
    return s = e(e({}, s), {}, {
        url: a
    });
}

function o(e) {
    return /^(https||http):\/\//i.test(e);
}

function i(e, t) {
    var r = [];
    if (!t) return e;
    for (var n in t) n && r.push(n + "=" + t[n]);
    return e.indexOf("?") < 0 ? e + "?" + r.join("&") : e + "&" + r.join("&");
}