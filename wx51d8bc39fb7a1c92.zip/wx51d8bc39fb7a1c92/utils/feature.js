Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.debounce = function(e, t) {
    var r = null;
    return function() {
        clearTimeout(r), r = setTimeout(function() {
            e.apply(this);
        }, t);
    };
}, exports.getParams = function(e) {
    var t = {};
    if (!e || !e.trim()) return t;
    if (e.indexOf("?") < 0) return t;
    var r = e.substring(e.indexOf("?") + 1);
    if (r.indexOf("&") < 0) {
        var n = r.split("="), i = n[0];
        t[i] = n[1];
    } else r.split("&").forEach(function(e) {
        var r = e.split("="), n = r[0];
        t[n] = r[1];
    });
    return t;
}, exports.toThousands = function(e) {
    return (e = +e) > 1e4 ? (e / 1e4).toFixed(1) + "w" : e;
};