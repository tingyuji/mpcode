Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.loginState = function() {
    var r = wx.getStorageSync(e.KY_WEAPP_SESSION_KEY), o = !1;
    r ? o = !0 : ((0, t.goto)("/pages/login/login"), o = !1);
    return o;
};

var e = require("../utils/enum"), t = require("../utils/goto");