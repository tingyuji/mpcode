var e = require("../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var t = e(require("../@babel/runtime/regenerator")), r = require("../@babel/runtime/helpers/asyncToGenerator"), n = require("../@babel/runtime/helpers/classCallCheck"), a = require("../@babel/runtime/helpers/createClass"), i = e(require("../libs/crypto-js/index")), u = {
    secret: "DojHnUjJchVGfXl&",
    username: "wxmini"
}, s = function() {
    function e() {
        n(this, e), this.serverTimeExceed = void 0;
    }
    var s;
    return a(e, [ {
        key: "init",
        value: function() {
            return new Promise(function(t, r) {
                wx.request({
                    url: "https://time-check.knowyourself.cc/",
                    method: "GET",
                    success: function(r) {
                        var n = new Date().getTime();
                        e.instance.setServerTimeExceed(r.data - n), t();
                    },
                    fail: function(e) {
                        r(e);
                    }
                });
            });
        }
    }, {
        key: "setServerTimeExceed",
        value: function(e) {
            this.serverTimeExceed = e;
        }
    }, {
        key: "_sign",
        value: function(e, t, r, n) {
            var a = "x-date: ".concat(n, "\n").concat(t, " ").concat(e, " HTTP/1.1");
            return i.default.HmacSHA256(a, r).toString(i.default.enc.Base64);
        }
    }, {
        key: "getSign",
        value: function(e, t) {
            var r = this.serverTimeExceed + Date.now();
            e = "" + e;
            var n = u, a = n.username, i = n.secret, s = new Date(r).toUTCString(), c = this._sign(e, t, i, s);
            return {
                "X-Date": s,
                Authorization: 'hmac username="'.concat(a, '", algorithm="hmac-sha256", headers="x-date request-line", signature="').concat(c, '"')
            };
        }
    } ], [ {
        key: "getInstance",
        value: (s = r(t.default.mark(function r() {
            return t.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (e.instance) {
                        t.next = 4;
                        break;
                    }
                    return e.instance = new e(), t.next = 4, e.instance.init();

                  case 4:
                    return t.abrupt("return", e.instance);

                  case 5:
                  case "end":
                    return t.stop();
                }
            }, r);
        })), function() {
            return s.apply(this, arguments);
        })
    } ]), e;
}();

exports.default = s, s.instance = null;