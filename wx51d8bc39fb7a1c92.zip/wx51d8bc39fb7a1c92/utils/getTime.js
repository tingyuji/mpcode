Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getTimeNow = function() {
    return new Promise(function(e, t) {
        wx.request({
            url: "https://time-check.knowyourself.cc/date",
            success: function(t) {
                e(t.data);
            },
            fail: function(e) {
                t(e);
            }
        });
    });
};