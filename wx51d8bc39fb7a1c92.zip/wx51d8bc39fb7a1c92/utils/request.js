var e = require("../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = function() {
    return w.apply(this, arguments);
}, require("../@babel/runtime/helpers/Arrayincludes");

var r = e(require("../@babel/runtime/regenerator")), t = require("../@babel/runtime/helpers/objectSpread2"), n = require("../@babel/runtime/helpers/asyncToGenerator"), o = require("../config/index"), a = e(require("./sign")), i = require("./enum"), s = require("../utils/index"), c = getApp();

var u, l = [ 700, 6001 ], d = {
    "content-type": "application/json",
    "ky-transform": 1,
    "Ky-Project": "together",
    "KY-BUNDLE-ID": (u = "iOS" === wx.getSystemInfoSync().system.trim().split(" ")[0] ? "ios" : "android", 
    "".concat("cc.knowyourself.ky").concat(u).concat(".wx")),
    "ky-source": 1
}, f = {
    isSilent: !1,
    autoLoading: !0,
    loadingText: "加载中..."
};

function g(e) {
    return new Promise(function() {
        var s = n(r.default.mark(function n(s, c) {
            var u, l, f, g, p, w, S;
            return r.default.wrap(function(r) {
                for (;;) switch (r.prev = r.next) {
                  case 0:
                    return u = e.header, l = e.method, f = e.url, g = e.params, p = e.data, u = t(t({}, d), u), 
                    (w = wx.getStorageSync(i.KY_WEAPP_TOKEN)) && (u["Ky-Auth-Token"] = w, u.topsession = w), 
                    l = l || "GET", p = p || g, r.prev = 6, r.next = 9, a.default.getInstance();

                  case 9:
                    S = r.sent, Object.assign(u, S.getSign("/" + f, l)), r.next = 15;
                    break;

                  case 13:
                    r.prev = 13, r.t0 = r.catch(6);

                  case 15:
                    s({
                        url: o.BASE_URL + f,
                        method: l,
                        data: p,
                        header: u
                    });

                  case 16:
                  case "end":
                    return r.stop();
                }
            }, n, null, [ [ 6, 13 ] ]);
        }));
        return function(e, r) {
            return s.apply(this, arguments);
        };
    }());
}

function p() {
    c && (c.globalData.user_id = ""), wx.removeStorageSync(i.KY_WEAPP_TOKEN), wx.removeStorageSync(i.KY_WEAPP_USER_INFO), 
    wx.removeStorageSync(i.KY_WEAPP_IS_REGISTERED), wx.removeStorageSync(i.KY_WEAPP_SESSION_KEY);
}

function w() {
    return (w = n(r.default.mark(function e() {
        var n, o, a, i, c, u, d, w, S = arguments;
        return r.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return n = S.length > 0 && void 0 !== S[0] ? S[0] : {}, o = S.length > 1 && void 0 !== S[1] ? S[1] : f, 
                a = t(t({}, f), o), i = a.isSilent, c = a.autoLoading, u = a.loadingText, e.next = 5, 
                g(n);

              case 5:
                return d = e.sent, (w = c && !i) && wx.showLoading({
                    title: u,
                    mask: !0
                }), e.abrupt("return", new Promise(function(e, r) {
                    wx.request(t(t({}, d), {}, {
                        success: function(t) {
                            var n = t.data, o = n.status, a = n.result, c = n.err, u = n.data, d = n.errMsg, f = "";
                            if (w && wx.hideLoading(), "success" === o) return e(a);
                            if ("error" === o) {
                                var g = a.error_code, S = a.error_msg;
                                if (l.includes(g)) return wx.showModal({
                                    title: "提示",
                                    content: "登录状态失效,请重新登录",
                                    showCancel: !0,
                                    success: function(e) {
                                        p(), e.confirm ? (0, s.goto)("/pages/login/login") : e.cancel && (0, s.goto)(1);
                                    }
                                }), r(new Error("登录失效或未登录"));
                                f = "".concat(g, ": ").concat(S);
                            } else {
                                if (!c) return e(u);
                                f = c ? "".concat(c, ": ").concat(d) : JSON.stringify(t.data);
                            }
                            i || wx.showToast({
                                icon: "none",
                                title: f
                            }), r(new Error(f));
                        },
                        fail: function(e) {
                            wx.showToast({
                                icon: "none",
                                title: e.errMsg
                            }), r(e);
                        }
                    }));
                }));

              case 9:
              case "end":
                return e.stop();
            }
        }, e);
    }))).apply(this, arguments);
}