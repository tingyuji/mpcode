var e = require("../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.dataCheck = function(e) {
    var r = e.utm_source;
    e.utm_medium;
    r && (function() {
        wx.getSystemInfoAsync({
            success: function(e) {
                var r = e.system.trim().split(" ");
                a.os_version = r[1], a.os = r[0], a.system = "iOS" === r[0] ? 1 : 2;
            }
        });
        var e = wx.getAccountInfoSync();
        a.version = e.miniProgram.version;
    }(), (c = wx.getStorageSync("UUID")) ? a.device_id = c : (a.device_id = "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(e) {
        var r = 16 * Math.random() | 0;
        return ("x" === e ? r : 3 & r | 8).toString(16);
    }), wx.setStorageSync("UUID", a.device_id)), a.state = !0, a.timeNum = 1e3 * (n = 0, 
    s = 20, Math.floor(Math.random() * (s - n)) + n + 10), i(), a.timeSet = setInterval(function() {
        a.records.length && o();
    }, a.timeNum), t = e, a.parameter = t);
    var t;
    var n, s, c;
}, exports.setListData = function(e) {
    if (!a.state) return;
    var r = {
        event_id: "1",
        base_uri: e.url,
        event_data: a.parameter,
        created_at: new Date().getTime(),
        log_id: a.records.length
    };
    a.records.push(r), a.user_id || i();
    a.records.length >= 100 && o();
};

var r = e(require("../@babel/runtime/regenerator")), t = require("../@babel/runtime/helpers/asyncToGenerator"), n = require("../api/index"), a = {
    parameter: "",
    user_id: 0,
    device_id: "",
    os: "",
    os_version: "",
    version: "4.3.19",
    system: "",
    records: [],
    timeNum: 0,
    timeSet: "",
    platform: 2,
    state: !1
};

function i() {
    var e = wx.getStorageSync("ky_weapp_userInfo");
    if (e) {
        var r = JSON.parse(e).id;
        a.user_id = r;
    }
}

function o() {
    return s.apply(this, arguments);
}

function s() {
    return (s = t(r.default.mark(function e() {
        return r.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return e.prev = 0, e.next = 3, n.collectService.collectRecord(a, {
                    autoLoading: !1
                });

              case 3:
                a.records = [], e.next = 9;
                break;

              case 6:
                e.prev = 6, e.t0 = e.catch(0), console.log(e.t0);

              case 9:
              case "end":
                return e.stop();
            }
        }, e, null, [ [ 0, 6 ] ]);
    }))).apply(this, arguments);
}