Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.KY_WEAPP_USER_INFO = exports.KY_WEAPP_TOKEN = exports.KY_WEAPP_SESSION_KEY = exports.KY_WEAPP_IS_REGISTERED = exports.HISTORY_KEY = exports.EXAM_ORDER_PAID = exports.ENUM_TALK = exports.ENUM_TAG_OPTIONS = exports.ENUM_PLAN = exports.ENUM_PAGES_HISTORY = exports.ENUM_MEDITATION_SINGLE = exports.ENUM_MEDITATION_SERIES = exports.ENUM_MEDITATION = exports.ENUM_EXAM = exports.ENUM_BANNER_TOOLS = exports.ENUM_BANNER_TALK = exports.ENUM_BANNER_MINE = exports.ENUM_BANNER_HOME = exports.ENUM_BANNER_EXAM = exports.ENUM_ARTICLE = void 0;

exports.KY_WEAPP_TOKEN = "ky_weapp_token";

exports.KY_WEAPP_USER_INFO = "ky_weapp_userInfo";

exports.KY_WEAPP_IS_REGISTERED = "ky_weapp_is_registered";

exports.KY_WEAPP_SESSION_KEY = "ky_weapp_session_key";

exports.HISTORY_KEY = "ky_search_history";

exports.ENUM_PAGES_HISTORY = "ky_pages_history";

exports.ENUM_ARTICLE = 1;

exports.ENUM_EXAM = 3;

exports.ENUM_MEDITATION = 5;

exports.ENUM_PLAN = 4;

exports.ENUM_TALK = 2;

var E = [ {
    label: "文章",
    value: 1
}, {
    label: "心理测评",
    value: 3
}, {
    label: "每日练习",
    value: 4
}, {
    label: "冥想&播客",
    value: 5
}, {
    label: "聊愈",
    value: 2
} ];

exports.ENUM_TAG_OPTIONS = E;

exports.ENUM_BANNER_HOME = 1;

exports.ENUM_BANNER_TOOLS = 2;

exports.ENUM_BANNER_MINE = 3;

exports.ENUM_BANNER_EXAM = 4;

exports.ENUM_BANNER_TALK = 5;

exports.ENUM_MEDITATION_SINGLE = 1;

exports.ENUM_MEDITATION_SERIES = 2;

exports.EXAM_ORDER_PAID = 3;