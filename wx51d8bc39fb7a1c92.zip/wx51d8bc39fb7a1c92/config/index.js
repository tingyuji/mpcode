Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.wechat = exports.together = exports.order = exports.meditation_app = exports.meditation = exports.match = exports.kda = exports.home = exports.exam = exports.dp = exports.course = exports.consult = exports.community = exports.collect = exports.ad = exports.account = exports.PROJECT_TYPE = exports.EXAM_URL = exports.DATE_BASE_URL = exports.COMMENT_TYPE_MEDITATION = exports.COMMENT_TYPE_EXAM = exports.COMMENT_TYPE_DP = exports.BASE_URL = void 0;

exports.course = "course_api";

exports.ad = "ad_api";

exports.account = "ky_account";

exports.match = "match_api";

exports.meditation = "meditation";

exports.home = "home";

exports.kda = "kda";

exports.order = "order";

exports.BASE_URL = "https://api.knowyourself.cc/";

exports.consult = "consult_api";

exports.dp = "plan";

exports.community = "community";

exports.together = "together";

exports.exam = "exam_api";

exports.meditation_app = "ky_meditation";

exports.EXAM_URL = "https://exam.knowyourself.cc/";

exports.COMMENT_TYPE_MEDITATION = 1;

exports.COMMENT_TYPE_EXAM = 2;

exports.COMMENT_TYPE_DP = 3;

exports.PROJECT_TYPE = {
    exam: 1,
    consult: 2,
    course: 3,
    dp: 4,
    zxs: 5,
    meditation: 6
};

exports.DATE_BASE_URL = "https://time-check.knowyourself.cc/";

exports.wechat = "wechat-v2";

exports.collect = "point";