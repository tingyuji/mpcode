Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.HELP = exports.DISCOUNT_PRICE = exports.DISCOUNT_PERCENTAGE = exports.DISCOUNT = void 0;

exports.HELP = 1;

exports.DISCOUNT = 2;

exports.DISCOUNT_PERCENTAGE = 1;

exports.DISCOUNT_PRICE = 2;