Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.TYPE_VIDEO = exports.TYPE_AUDIO = exports.SCENE_MEDITATION = exports.MODE_SERIES = exports.MODE_AUDIO = void 0;

exports.TYPE_AUDIO = 1;

exports.TYPE_VIDEO = 2;

exports.MODE_SERIES = 2;

exports.MODE_AUDIO = 1;

exports.SCENE_MEDITATION = 1;