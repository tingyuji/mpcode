var t = require("../../utils/index");

Component({
    options: {
        addGlobalClass: !0
    },
    properties: {
        target: {
            type: Object,
            value: {}
        }
    },
    methods: {
        handler: function() {
            var e = this.data.target, a = e.parent_id, o = e.id;
            (0, t.goto)("/pages/secondaryCategory/secondaryCategory?id=".concat(a, "&category_id=").concat(o));
        }
    }
});