var t = require("../../utils/index");

Component({
    options: {
        addGlobalClass: !0
    },
    properties: {
        item: {
            type: Object
        },
        summaryClass: {
            type: String,
            value: "text-ellipsis-3"
        }
    },
    methods: {
        handleDetail: function() {
            (0, t.goto)("/pages/articleDetail/articleDetail?id=".concat(this.data.item.article_id, "&source=talk"));
        }
    }
});