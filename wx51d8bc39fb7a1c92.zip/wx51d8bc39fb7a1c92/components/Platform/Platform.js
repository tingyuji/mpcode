var t = getApp();

Component({
    data: {
        show: !1
    },
    lifetimes: {
        attached: function() {
            var a = !t.globalData.systemInfo.isIos;
            this.setData({
                show: a
            });
        }
    }
});