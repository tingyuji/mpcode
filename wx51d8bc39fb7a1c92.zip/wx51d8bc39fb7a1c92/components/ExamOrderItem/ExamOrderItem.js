var t = require("../../utils/index");

Component({
    properties: {
        target: {
            type: Object,
            value: {}
        },
        btnText: {
            type: [ String, Number ],
            value: "立即测试"
        }
    },
    data: {
        time: "",
        btnClass: "",
        btnText: "",
        itemImage: ""
    },
    lifetimes: {
        attached: function() {
            this.setData({
                time: this.data.btnText ? (0, t.secondToStr)(this.data.target.start_time) : (0, 
                t.secondToStr)(this.data.target.finish_time),
                btnClass: 0 === Number(this.data.btnText) ? "item-right-btn" : "item-right-btn-look",
                btnText: 0 === Number(this.data.btnText) ? "继续测试" : "查看报告",
                itemImage: this.data.target.exam.mp_img_show ? this.data.target.exam.mp_img_show : this.data.target.exam.commend_img_show
            });
        }
    },
    methods: {
        handler: function() {
            this.triggerEvent("onTap", this.data.target);
        },
        toExam: function() {
            var a = this.data.target.exam.id;
            (0, t.goto)("/pages/evaluationDetail/evaluationDetail?id=".concat(a));
        },
        copyFun: function(t) {
            wx.setClipboardData({
                data: t.currentTarget.dataset.text,
                success: function(t) {
                    console.log(t), wx.getClipboardData({
                        success: function(t) {
                            console.log(t), wx.showToast({
                                title: "复制成功"
                            });
                        }
                    });
                }
            });
        }
    }
});