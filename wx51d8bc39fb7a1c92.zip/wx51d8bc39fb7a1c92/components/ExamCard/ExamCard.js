var t = require("../../utils/index");

Component({
    options: {
        addGlobalClass: !0
    },
    properties: {
        target: {
            type: Object,
            value: {}
        }
    },
    data: {
        itemImage: ""
    },
    lifetimes: {
        attached: function() {
            var t = "";
            this.data.target.image && (t = this.data.target.image), this.data.target.commend_img_show && (t = this.data.target.commend_img_show), 
            this.data.target.data && this.data.target.data.mp_img && (t = this.data.target.data.mp_img), 
            this.setData({
                itemImage: t
            });
        }
    },
    methods: {
        handler: function(a) {
            var e = this.data.target.target_id;
            this.triggerEvent("onTap", e), (0, t.goto)("/pages/evaluationDetail/evaluationDetail?id=".concat(e));
        }
    }
});