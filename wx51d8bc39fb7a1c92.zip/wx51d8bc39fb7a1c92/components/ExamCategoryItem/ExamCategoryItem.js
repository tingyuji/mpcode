var t = require("../../utils/index");

Component({
    options: {
        addGlobalClass: !0
    },
    properties: {
        target: {
            type: Object,
            value: {}
        }
    },
    methods: {
        toDetail: function() {
            var a = this.data.target.id;
            (0, t.goto)("/pages/evaluationDetail/evaluationDetail?id=".concat(a));
        }
    }
});