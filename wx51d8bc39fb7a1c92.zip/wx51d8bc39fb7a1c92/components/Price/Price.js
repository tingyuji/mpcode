Component({
    properties: {
        price: {
            type: [ String, Number ],
            value: ""
        },
        priceStyle: {
            type: String,
            value: ""
        },
        origin: {
            type: [ String, Number ],
            value: 0
        },
        originStyle: {
            type: String,
            value: ""
        },
        showUnit: {
            type: Boolean,
            value: !0
        }
    }
});