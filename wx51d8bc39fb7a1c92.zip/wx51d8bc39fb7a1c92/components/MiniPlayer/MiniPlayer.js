var a = require("../../@babel/runtime/helpers/interopRequireWildcard")(require("../../libs/bgaudio")), t = require("../../utils/index"), e = (getApp(), 
"");

Component({
    options: {
        addGlobalClass: !0
    },
    pageLifetimes: {
        show: function() {
            this.init();
        },
        hide: function() {}
    },
    properties: {
        fixed: {
            type: Boolean,
            value: !0
        }
    },
    data: {
        show: !1,
        showDuration: null,
        currentTime: "00:00",
        paused: !1,
        process: 0
    },
    methods: {
        toggle: function() {
            var t = this;
            this.data.paused ? this.data.process ? this.change({
                detail: {
                    value: this.data.process
                }
            }) : (a.default.play(), setTimeout(function() {
                a.default.backData(t.update);
            }, 100)) : a.default.pause(), this.setData({
                paused: !this.data.paused
            });
        },
        init: function() {
            var t = this, i = a.audioData.title, u = a.audioData.currentTime, s = a.audioData.showDuration, o = a.audioData.isPlay, n = a.audioData.info, r = a.audioData.isShow;
            e = this, r ? this.setData({
                show: !1
            }) : (this.setData({
                show: !0,
                paused: o,
                showDuration: s,
                title: i,
                currentTime: "00:00" === u ? this.data.currentTime : u,
                bg_image: n.bg_image
            }), setTimeout(function() {
                var e = wx.getBackgroundAudioManager();
                !1 === e.paused ? (a.audioData.isPlay = !0, a.default.backData(t.update)) : t.setData({
                    paused: !a.audioData.isPlay,
                    currentTime: t._second2Str(e.currentTime)
                });
            }, 300));
        },
        update: function(a) {
            e.setData({
                currentTime: "00:00" === a.currentTime ? e.data.currentTime : a.currentTime,
                process: a.process,
                paused: !a.isPlay,
                show: !a.isShow
            });
        },
        toPlayer: function() {
            var a = (0, t.addParams)("/pages/player/player", {
                continue: !0
            });
            (0, t.goto)(a);
        },
        change: function(t) {
            var e = this, i = t.detail.value;
            a.default.play(), setTimeout(function() {
                var t = a.audioData.duration, u = i / 100 * t;
                a.default.seek(u), a.default.backData(e.update), a.default.onEnded(e.audioEnded);
            }, 500);
        },
        _fill: function(a) {
            return (a = +a) < 10 ? "0".concat(a) : a;
        },
        _second2Str: function(a) {
            a = Math.floor(a);
            var t = this._fill(~~(a / 60)), e = this._fill(a % 60);
            return "".concat(t, ":").concat(e);
        }
    }
});