var e = require("../../@babel/runtime/helpers/interopRequireDefault");

require("../../@babel/runtime/helpers/Objectvalues");

var t = require("../../@babel/runtime/helpers/createForOfIteratorHelper"), r = require("../../@babel/runtime/helpers/createClass"), n = require("../../@babel/runtime/helpers/classCallCheck"), a = require("../../@babel/runtime/helpers/inherits"), i = require("../../@babel/runtime/helpers/createSuper"), o = e(require("../../@babel/runtime/regenerator")), u = require("../../@babel/runtime/helpers/asyncToGenerator"), s = require("../../@babel/runtime/helpers/typeof");

!function(e, t) {
    if ("object" === ("undefined" == typeof exports ? "undefined" : s(exports)) && "object" === ("undefined" == typeof module ? "undefined" : s(module))) module.exports = t(); else if ("function" == typeof define && define.amd) define([], t); else {
        var r = t();
        for (var n in r) ("object" === ("undefined" == typeof exports ? "undefined" : s(exports)) ? exports : e)[n] = r[n];
    }
}(window, function() {
    return function(e) {
        var t = {};
        function r(n) {
            if (t[n]) return t[n].exports;
            var a = t[n] = {
                i: n,
                l: !1,
                exports: {}
            };
            return e[n].call(a.exports, a, a.exports, r), a.l = !0, a.exports;
        }
        return r.m = e, r.c = t, r.d = function(e, t, n) {
            r.o(e, t) || Object.defineProperty(e, t, {
                enumerable: !0,
                get: n
            });
        }, r.r = function(e) {
            "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
                value: "Module"
            }), Object.defineProperty(e, "__esModule", {
                value: !0
            });
        }, r.t = function(e, t) {
            if (1 & t && (e = r(e)), 8 & t) return e;
            if (4 & t && "object" === s(e) && e && e.__esModule) return e;
            var n = Object.create(null);
            if (r.r(n), Object.defineProperty(n, "default", {
                enumerable: !0,
                value: e
            }), 2 & t && "string" != typeof e) for (var a in e) r.d(n, a, function(t) {
                return e[t];
            }.bind(null, a));
            return n;
        }, r.n = function(e) {
            var t = e && e.__esModule ? function() {
                return e.default;
            } : function() {
                return e;
            };
            return r.d(t, "a", t), t;
        }, r.o = function(e, t) {
            return Object.prototype.hasOwnProperty.call(e, t);
        }, r.p = "", r(r.s = 1);
    }([ function(e, t) {
        e.exports = {
            hex: function(e) {
                var t = null;
                return !/^#/.test(e) || 7 !== e.length && 9 !== e.length ? null !== (t = /^(rgb|rgba)\((.+)\)/.exec(e)) ? "#" + t[2].split(",").map(function(e, t) {
                    return e = e.trim(), 1 === (e = (e = 3 === t ? Math.floor(255 * parseFloat(e)) : parseInt(e, 10)).toString(16)).length && (e = "0" + e), 
                    e;
                }).join("") : "#00000000" : e;
            },
            splitLineToCamelCase: function(e) {
                return e.split("-").map(function(e, t) {
                    return 0 === t ? e : e[0].toUpperCase() + e.slice(1);
                }).join("");
            },
            compareVersion: function(e, t) {
                e = e.split("."), t = t.split(".");
                for (var r = Math.max(e.length, t.length); e.length < r; ) e.push("0");
                for (;t.length < r; ) t.push("0");
                for (var n = 0; n < r; n++) {
                    var a = parseInt(e[n], 10), i = parseInt(t[n], 10);
                    if (a > i) return 1;
                    if (a < i) return -1;
                }
                return 0;
            }
        };
    }, function(e, t, r) {
        var n = r(2), a = r(3).Widget, i = r(5).Draw, s = r(0).compareVersion;
        Component({
            properties: {
                width: {
                    type: Number,
                    value: 400
                },
                height: {
                    type: Number,
                    value: 300
                }
            },
            data: {
                use2dCanvas: !1
            },
            lifetimes: {
                attached: function() {
                    var e = this, t = wx.getSystemInfoSync(), r = t.SDKVersion, n = t.pixelRatio, a = s(r, "2.9.2") >= 0;
                    this.dpr = n, this.setData({
                        use2dCanvas: a
                    }, function() {
                        a ? e.createSelectorQuery().select("#".concat("weui-canvas")).fields({
                            node: !0,
                            size: !0
                        }).exec(function(t) {
                            var r = t[0].node, a = r.getContext("2d");
                            r.width = t[0].width * n, r.height = t[0].height * n, a.scale(n, n), e.ctx = a, 
                            e.canvas = r;
                        }) : e.ctx = wx.createCanvasContext("weui-canvas", e);
                    });
                }
            },
            methods: {
                renderToCanvas: function(e) {
                    var t = this;
                    return u(o.default.mark(function r() {
                        var u, s, c, l, f, d, h, v, p, b;
                        return o.default.wrap(function(r) {
                            for (;;) switch (r.prev = r.next) {
                              case 0:
                                if (u = e.wxml, s = e.style, c = t.ctx, l = t.canvas, !(f = t.data.use2dCanvas) || l) {
                                    r.next = 6;
                                    break;
                                }
                                return r.abrupt("return", Promise.reject(new Error("renderToCanvas: fail canvas has not been created")));

                              case 6:
                                return c.clearRect(0, 0, t.data.width, t.data.height), d = n(u), h = d.root, v = new a(h, s), 
                                p = v.init(), t.boundary = {
                                    top: p.layoutBox.top,
                                    left: p.layoutBox.left,
                                    width: p.computedStyle.width,
                                    height: p.computedStyle.height
                                }, b = new i(c, l, f), r.next = 14, b.drawNode(p);

                              case 14:
                                if (f) {
                                    r.next = 17;
                                    break;
                                }
                                return r.next = 17, t.canvasDraw(c);

                              case 17:
                                return r.abrupt("return", Promise.resolve(p));

                              case 18:
                              case "end":
                                return r.stop();
                            }
                        }, r);
                    }))();
                },
                canvasDraw: function(e, t) {
                    return new Promise(function(r) {
                        e.draw(t, function() {
                            r();
                        });
                    });
                },
                canvasToTempFilePath: function() {
                    var e = this, t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, r = this.data.use2dCanvas;
                    return new Promise(function(n, a) {
                        var i = e.boundary, o = i.top, u = i.left, s = i.width, c = i.height, l = {
                            x: u,
                            y: o,
                            width: s,
                            height: c,
                            destWidth: s * e.dpr,
                            destHeight: c * e.dpr,
                            canvasId: "weui-canvas",
                            fileType: t.fileType || "png",
                            quality: t.quality || 1,
                            success: n,
                            fail: a
                        };
                        r && (delete l.canvasId, l.canvas = e.canvas), wx.canvasToTempFilePath(l, e);
                    });
                }
            }
        });
    }, function(e, t) {
        e.exports = function(e) {
            return e = (e = e.trim()).replace(/<!--[\s\S]*?-->/g, ""), {
                declaration: t(),
                root: r()
            };
            function t() {
                if (a(/^<\?xml\s*/)) {
                    for (var e = {
                        attributes: {}
                    }; !i() && !o("?>"); ) {
                        var t = n();
                        if (!t) return e;
                        e.attributes[t.name] = t.value;
                    }
                    return a(/\?>\s*/), e;
                }
            }
            function r() {
                var e = a(/^<([\w-:.]+)\s*/);
                if (e) {
                    for (var t, u = {
                        name: e[1],
                        attributes: {},
                        children: []
                    }; !(i() || o(">") || o("?>") || o("/>")); ) {
                        var s = n();
                        if (!s) return u;
                        u.attributes[s.name] = s.value;
                    }
                    if (a(/^\s*\/>\s*/)) return u;
                    for (a(/\??>\s*/), u.content = function() {
                        var e = a(/^([^<]*)/);
                        return e ? e[1] : "";
                    }(); t = r(); ) u.children.push(t);
                    return a(/^<\/[\w-:.]+>\s*/), u;
                }
            }
            function n() {
                var e, t = a(/([\w:-]+)\s*=\s*("[^"]*"|'[^']*'|\w+)\s*/);
                if (t) return {
                    name: t[1],
                    value: (e = t[2], e.replace(/^['"]|['"]$/g, ""))
                };
            }
            function a(t) {
                var r = e.match(t);
                if (r) return e = e.slice(r[0].length), r;
            }
            function i() {
                return 0 == e.length;
            }
            function o(t) {
                return 0 == e.indexOf(t);
            }
        };
    }, function(e, t, o) {
        var u = o(4), s = o(0).splitLineToCamelCase, c = function(e) {
            a(o, e);
            var t = i(o);
            function o(e) {
                var r;
                return n(this, o), (r = t.call(this, e.style)).name = e.name, r.attributes = e.attributes, 
                r;
            }
            return r(o);
        }(u), l = function() {
            function e(t, r) {
                n(this, e), this.xom = t, this.style = r, this.inheritProps = [ "fontSize", "lineHeight", "textAlign", "verticalAlign", "color" ];
            }
            return r(e, [ {
                key: "init",
                value: function() {
                    return this.container = this.create(this.xom), this.container.layout(), this.inheritStyle(this.container), 
                    this.container;
                }
            }, {
                key: "inheritStyle",
                value: function(e) {
                    var t = this, r = e.parent || null, n = e.children || {}, a = e.computedStyle;
                    r && this.inheritProps.forEach(function(e) {
                        a[e] = a[e] || r.computedStyle[e];
                    }), Object.values(n).forEach(function(e) {
                        t.inheritStyle(e);
                    });
                }
            }, {
                key: "create",
                value: function(e) {
                    var t = this, r = (e.attributes.class || "").split(" ");
                    r = r.map(function(e) {
                        return s(e.trim());
                    });
                    var n = {};
                    r.forEach(function(e) {
                        Object.assign(n, t.style[e] || {});
                    });
                    for (var a = {
                        name: e.name,
                        style: n
                    }, i = {}, o = 0, u = Object.keys(e.attributes); o < u.length; o++) {
                        var l = u[o], f = e.attributes[l], d = s(l);
                        i[d] = "" === f || "true" === f || "false" !== f && f;
                    }
                    i.text = e.content, a.attributes = i;
                    var h = new c(a);
                    return e.children.forEach(function(e) {
                        var r = t.create(e);
                        h.add(r);
                    }), h;
                }
            } ]), e;
        }();
        e.exports = {
            Widget: l
        };
    }, function(e, t) {
        e.exports = require("widget-ui");
    }, function(e, a) {
        var i = function() {
            function e(t, r) {
                var a = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
                n(this, e), this.ctx = t, this.canvas = r || null, this.use2dCanvas = a;
            }
            var a, i;
            return r(e, [ {
                key: "roundRect",
                value: function(e, t, r, n, a) {
                    var i = !(arguments.length > 5 && void 0 !== arguments[5]) || arguments[5], o = arguments.length > 6 && void 0 !== arguments[6] && arguments[6];
                    if (!(a < 0)) {
                        var u = this.ctx;
                        u.beginPath(), u.arc(e + a, t + a, a, Math.PI, 3 * Math.PI / 2), u.arc(e + r - a, t + a, a, 3 * Math.PI / 2, 0), 
                        u.arc(e + r - a, t + n - a, a, 0, Math.PI / 2), u.arc(e + a, t + n - a, a, Math.PI / 2, Math.PI), 
                        u.lineTo(e, t + a), o && u.stroke(), i && u.fill();
                    }
                }
            }, {
                key: "drawView",
                value: function(e, t) {
                    var r = this.ctx, n = e.left, a = e.top, i = e.width, o = e.height, u = t.borderRadius, s = void 0 === u ? 0 : u, c = t.borderWidth, l = void 0 === c ? 0 : c, f = t.borderColor, d = t.color, h = void 0 === d ? "#000" : d, v = t.backgroundColor, p = void 0 === v ? "transparent" : v;
                    r.save(), l > 0 && (r.fillStyle = f || h, this.roundRect(n, a, i, o, s)), r.fillStyle = p;
                    var b = i - 2 * l, m = o - 2 * l, x = s - l >= 0 ? s - l : 0;
                    this.roundRect(n + l, a + l, b, m, x), r.restore();
                }
            }, {
                key: "drawImage",
                value: (i = u(o.default.mark(function e(t, r, n) {
                    var a = this;
                    return o.default.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            return e.next = 2, new Promise(function(e, i) {
                                var o = a.ctx, u = a.canvas, s = n.borderRadius, c = void 0 === s ? 0 : s, l = r.left, f = r.top, d = r.width, h = r.height;
                                o.save(), a.roundRect(l, f, d, h, c, !1, !1), o.clip();
                                var v = u.createImage();
                                v.onload = function() {
                                    o.drawImage(v, l, f, d, h), o.restore(), e();
                                }, v.onerror = function() {
                                    i();
                                }, v.src = t;
                            });

                          case 2:
                          case "end":
                            return e.stop();
                        }
                    }, e);
                })), function(e, t, r) {
                    return i.apply(this, arguments);
                })
            }, {
                key: "drawText",
                value: function(e, r, n) {
                    var a = this.ctx, i = r.left, o = r.top, u = r.width, s = r.height, c = n.color, l = void 0 === c ? "#000" : c, f = n.lineHeight, d = void 0 === f ? "1.4em" : f, h = n.fontSize, v = void 0 === h ? 14 : h, p = n.textAlign, b = void 0 === p ? "left" : p, m = n.verticalAlign, x = void 0 === m ? "top" : m, y = n.backgroundColor, g = void 0 === y ? "transparent" : y;
                    if ("string" == typeof d && (d = Math.ceil(parseFloat(d.replace("em")) * v)), e && !(d > s)) {
                        switch (a.save(), a.textBaseline = "top", a.font = "".concat(v, "px sans-serif"), 
                        a.textAlign = b, a.fillStyle = g, this.roundRect(i, o, u, s, 0), a.fillStyle = l, 
                        b) {
                          case "left":
                            break;

                          case "center":
                            i += .5 * u;
                            break;

                          case "right":
                            i += u;
                        }
                        var w = a.measureText(e).width, k = Math.ceil(w / u) * d, S = Math.ceil((s - k) / 2);
                        switch (S < 0 && (S = 0), x) {
                          case "top":
                            break;

                          case "middle":
                            o += S;
                            break;

                          case "bottom":
                            o += 2 * S;
                        }
                        var C = Math.ceil((d - v) / 2);
                        if (w <= u) a.fillText(e, i, o + C); else {
                            var P, T = e.split(""), j = o, I = "", M = t(T);
                            try {
                                for (M.s(); !(P = M.n()).done; ) {
                                    var q = P.value, O = I + q;
                                    if (a.measureText(O).width > u) {
                                        if (a.fillText(I, i, o + C), I = q, (o += d) + d > j + s) break;
                                    } else I = O;
                                }
                            } catch (e) {
                                M.e(e);
                            } finally {
                                M.f();
                            }
                            o + d <= j + s && a.fillText(I, i, o + C), a.restore();
                        }
                    }
                }
            }, {
                key: "drawNode",
                value: (a = u(o.default.mark(function e(t) {
                    var r, n, a, i, u, s, c, l, f, d;
                    return o.default.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            if (r = t.layoutBox, n = t.computedStyle, a = t.name, i = t.attributes, u = i.src, 
                            s = i.text, "view" !== a) {
                                e.next = 6;
                                break;
                            }
                            this.drawView(r, n), e.next = 12;
                            break;

                          case 6:
                            if ("image" !== a) {
                                e.next = 11;
                                break;
                            }
                            return e.next = 9, this.drawImage(u, r, n);

                          case 9:
                            e.next = 12;
                            break;

                          case 11:
                            "text" === a && this.drawText(s, r, n);

                          case 12:
                            c = Object.values(t.children), l = 0, f = c;

                          case 14:
                            if (!(l < f.length)) {
                                e.next = 21;
                                break;
                            }
                            return d = f[l], e.next = 18, this.drawNode(d);

                          case 18:
                            l++, e.next = 14;
                            break;

                          case 21:
                          case "end":
                            return e.stop();
                        }
                    }, e, this);
                })), function(e) {
                    return a.apply(this, arguments);
                })
            } ]), e;
        }();
        e.exports = {
            Draw: i
        };
    } ]);
});