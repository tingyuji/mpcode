var t = require("../../utils/index");

Component({
    options: {
        addGlobalClass: !0
    },
    properties: {
        target: {
            type: Object,
            value: {}
        }
    },
    methods: {
        handler: function() {
            var e = this.data.target.id;
            (0, t.goto)("/pages/articleDetail/articleDetail?id=".concat(e));
        }
    }
});