var e = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/regenerator")), t = require("../../@babel/runtime/helpers/asyncToGenerator"), r = require("../../api/index"), n = require("../../utils/enum"), a = (require("../../utils/goto"), 
getApp());

Component({
    properties: {
        type: {
            type: [ String, Number ],
            value: ""
        },
        count: {
            type: [ String, Number ],
            value: ""
        },
        zIndex: {
            type: [ String, Number ],
            value: 11
        }
    },
    data: {
        hasUserInfo: !1,
        hasPhone: !1,
        isShow: !0,
        loginInfo: null,
        code: null
    },
    methods: {
        getUserProfile: function() {
            wx._trackEvent("clk_mini_mine_verify_wechat_phone", {
                userid: a.globalData.user_id
            }), Number(this.data.count) > 0 && this.hasCheckCount() ? this.setData({
                isShow: !1
            }) : this.hasUserInfo();
        },
        hasUserInfo: function() {
            var r = this;
            return new Promise(function() {
                var a = t(e.default.mark(function t(a, o) {
                    return e.default.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            try {
                                wx.getStorageSync(n.KY_WEAPP_SESSION_KEY) ? (r.handleSuccess(), a()) : (r.login(), 
                                Number(r.data.count) > 0 && r.setData({
                                    isShow: !1
                                }), a());
                            } catch (e) {
                                console.error("hasUserInfo error=", e), o(e);
                            }

                          case 1:
                          case "end":
                            return e.stop();
                        }
                    }, t);
                }));
                return function(e, t) {
                    return a.apply(this, arguments);
                };
            }());
        },
        login: function() {
            var r = this;
            return new Promise(function() {
                var n = t(e.default.mark(function n(a, o) {
                    return e.default.wrap(function(n) {
                        for (;;) switch (n.prev = n.next) {
                          case 0:
                            try {
                                r.data.code || wx.login({
                                    success: function(e) {
                                        e.code && r.setData({
                                            code: e.code
                                        });
                                    }
                                }), wx.getUserProfile({
                                    desc: "用于完善资料",
                                    success: function() {
                                        var n = t(e.default.mark(function t(n) {
                                            return e.default.wrap(function(e) {
                                                for (;;) switch (e.prev = e.next) {
                                                  case 0:
                                                    return r.setData({
                                                        loginInfo: n
                                                    }), e.next = 3, r.getToken();

                                                  case 3:
                                                    r.handleSuccess(), a();

                                                  case 5:
                                                  case "end":
                                                    return e.stop();
                                                }
                                            }, t);
                                        }));
                                        return function(e) {
                                            return n.apply(this, arguments);
                                        };
                                    }()
                                });
                            } catch (e) {
                                console.error("initLogin error=", e), o(e);
                            }

                          case 1:
                          case "end":
                            return n.stop();
                        }
                    }, n);
                }));
                return function(e, t) {
                    return n.apply(this, arguments);
                };
            }());
        },
        getToken: function() {
            var o = this;
            return new Promise(function() {
                var s = t(e.default.mark(function t(s, u) {
                    var i, c, l, f, h, d, g, p, S, v, w;
                    return e.default.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            if (e.prev = 0, i = o.data, c = i.loginInfo, l = i.code, !c) {
                                e.next = 20;
                                break;
                            }
                            return f = {
                                code: l,
                                source: "10",
                                encryptedData: c.encryptedData,
                                iv: c.iv,
                                rawData: c.rawData,
                                signature: c.signature
                            }, e.next = 6, r.loginService.getWxToken(f);

                          case 6:
                            return h = e.sent, wx.setStorageSync(n.KY_WEAPP_SESSION_KEY, h.token), e.next = 10, 
                            r.loginService.userLogin({
                                token: h.token
                            });

                          case 10:
                            d = e.sent, d.is_registered, g = d.token, p = d.user, wx.setStorageSync(n.KY_WEAPP_IS_REGISTERED, !0), 
                            g && (a.globalData.user_id = S, S = p.id, v = p.avatar, w = p.nickname, wx.setStorageSync(n.KY_WEAPP_USER_INFO, JSON.stringify({
                                id: S,
                                avatar: v,
                                nickname: w
                            })), wx.setStorageSync(n.KY_WEAPP_TOKEN, g)), o.setData({
                                code: null
                            }), s(), e.next = 21;
                            break;

                          case 20:
                            u("初始化用户Token失败");

                          case 21:
                            e.next = 28;
                            break;

                          case 23:
                            e.prev = 23, e.t0 = e.catch(0), o.setData({
                                code: null
                            }), console.error("初始化用户Token失败=", e.t0), u(e.t0);

                          case 28:
                          case "end":
                            return e.stop();
                        }
                    }, t, null, [ [ 0, 23 ] ]);
                }));
                return function(e, t) {
                    return s.apply(this, arguments);
                };
            }());
        },
        handleSuccess: function() {
            this.triggerEvent("handleSuccess");
        },
        hasCheckCount: function() {
            var e = getCurrentPages(), t = e[e.length - 1].route, r = !1, a = wx.getStorageSync(n.ENUM_PAGES_HISTORY);
            if ("" === a) return r;
            var o = (a = JSON.parse(a)).filter(function(e) {
                return e.pages === t;
            });
            return 0 === o.length ? r : r = o[0].value === Number(this.data.count);
        }
    },
    observers: {}
});