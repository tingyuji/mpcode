Component({
    options: {
        addGlobalClass: !0
    },
    properties: {
        target: {
            type: Object,
            value: {}
        }
    }
});