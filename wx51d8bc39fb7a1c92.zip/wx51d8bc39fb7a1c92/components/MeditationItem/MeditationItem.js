var t = require("../../utils/index"), e = require("../../utils/enum");

Component({
    options: {
        addGlobalClass: !0
    },
    properties: {
        item: {
            type: Object
        }
    },
    data: {},
    methods: {
        handleDetail: function() {
            this.data.item.data.mode === e.ENUM_MEDITATION_SERIES ? (0, t.goto)("/pages/meditationDetail/meditationDetail?id=".concat(this.data.item.target_id)) : (0, 
            t.goto)("/pages/player/player?courseId=".concat(this.data.item.target_id));
        }
    }
});