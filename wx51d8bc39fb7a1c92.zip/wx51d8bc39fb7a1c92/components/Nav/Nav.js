require("../../@babel/runtime/helpers/Arrayincludes");

var t = require("../../utils/goto"), e = getApp(), n = "/pages/index/index", a = [ n, "/pages/tools/tools", "/pages/mine/mine" ];

Component({
    options: {
        addGlobalClass: !0
    },
    properties: {
        leftBtn: {
            type: Array,
            value: []
        },
        title: {
            type: String,
            value: ""
        },
        logo: {
            type: Boolean,
            value: !1
        },
        bgColor: {
            type: String,
            value: "#fff"
        }
    },
    data: {
        statusBarHeight: e.globalData.navTop,
        navHeight: e.globalData.navHeight
    },
    lifetimes: {
        attached: function() {
            this.init();
        }
    },
    methods: {
        init: function() {
            this.data.leftBtn.length || this.initLeftBtn();
        },
        initLeftBtn: function() {
            var t = this, e = getCurrentPages(), n = e[e.length - 1].route;
            if (!a.some(function(t) {
                return t.includes(n);
            })) {
                var i = [ {
                    icon: "icon-back",
                    handler: function() {
                        return t.back();
                    }
                } ], o = {
                    icon: "icon-home",
                    handler: function() {
                        return t.toHome();
                    }
                };
                1 === e.length && (i = [ o ]), e.length > 2 && i.push(o), this.setData({
                    leftBtn: i
                });
            }
        },
        back: function() {
            (0, t.goto)();
        },
        toHome: function() {
            (0, t.goto)(n);
        },
        handler: function(t) {
            var e = t.currentTarget.dataset.index;
            this.data.leftBtn[e].handler();
        }
    }
});