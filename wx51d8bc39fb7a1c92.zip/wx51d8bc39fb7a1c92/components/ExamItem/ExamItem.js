var t = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/regenerator")), e = require("../../@babel/runtime/helpers/asyncToGenerator"), a = require("../../utils/index"), i = getApp();

Component({
    options: {
        addGlobalClass: !0
    },
    properties: {
        item: {
            type: Object
        },
        type: {
            type: [ String, Number ]
        }
    },
    data: {
        show: !1,
        itemImage: ""
    },
    lifetimes: {
        attached: function() {
            var t = !i.globalData.systemInfo.isIos, e = "";
            this.data.item.image && (e = this.data.item.image), this.data.item.data && this.data.item.data.mp_img && (e = this.data.item.data.mp_img), 
            this.data.item.mp_img_show && (e = this.data.item.mp_img_show), this.setData({
                show: t,
                itemImage: e
            });
        }
    },
    methods: {
        handleDetail: function() {
            var i = this;
            return e(t.default.mark(function e() {
                return t.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        (0, a.goto)("/pages/evaluationDetail/evaluationDetail?id=".concat(i.data.item.target_id));

                      case 1:
                      case "end":
                        return t.stop();
                    }
                }, e);
            }))();
        }
    }
});