var e = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/regenerator")), t = require("../../@babel/runtime/helpers/asyncToGenerator"), a = require("../../utils/index");

Component({
    options: {
        addGlobalClass: !0
    },
    properties: {
        item: {
            type: Object
        }
    },
    data: {
        num: 0
    },
    ready: function() {
        this.peopleNumFun(this.data.item.data.pv);
    },
    methods: {
        handleDetail: function() {
            var r = this;
            return t(e.default.mark(function t() {
                return e.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        (0, a.goto)("/pages/articleDetail/articleDetail?id=".concat(r.data.item.target_id));

                      case 1:
                      case "end":
                        return e.stop();
                    }
                }, t);
            }))();
        },
        peopleNumFun: function(e) {
            var t = 0;
            t = e <= 9999 ? e : "".concat(parseInt(e / 1e4 * 10) / 10, "W"), this.setData({
                num: t
            });
        }
    }
});