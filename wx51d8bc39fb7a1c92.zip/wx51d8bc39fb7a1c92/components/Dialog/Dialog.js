Component({
    properties: {
        visible: {
            type: Boolean,
            value: !1
        },
        dialog: {
            type: Object,
            value: {
                title: "",
                content: "",
                cancelText: "取消",
                cancelButton: {},
                onCancel: function() {},
                confirmText: "确认",
                confirmButton: {},
                onConfirm: function() {}
            }
        }
    },
    data: {},
    methods: {
        cancel: function() {
            (0, this.data.dialog.onCancel)();
        },
        confirm: function() {
            (0, this.data.dialog.onConfirm)();
        }
    }
});