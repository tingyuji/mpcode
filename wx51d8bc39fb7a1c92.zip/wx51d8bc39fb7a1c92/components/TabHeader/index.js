var e = require("../../utils/enum");

Component({
    options: {
        addGlobalClass: !0
    },
    properties: {
        type: {
            type: Array,
            value: []
        },
        activeIndex: {
            type: Number,
            value: 0
        }
    },
    data: {
        tagOptions: []
    },
    lifetimes: {
        attached: function() {}
    },
    methods: {
        handleChangeTapActive: function(e) {
            var t = e.currentTarget.dataset.item;
            this.triggerEvent("changeTap", {
                activeIndex: t.value
            });
        }
    },
    observers: {
        type: function(t) {
            var a = e.ENUM_TAG_OPTIONS.map(function(e) {
                return e.disabled = !(0 !== t.length && -1 !== t.findIndex(function(t) {
                    return t.type === e.value && t.count > 0;
                })), e;
            });
            this.setData({
                tagOptions: a
            });
        }
    }
});