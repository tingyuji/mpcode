var t = require("../../config/meditation");

Component({
    options: {
        addGlobalClass: !0
    },
    properties: {
        target: {
            type: Object,
            value: {}
        }
    },
    data: {
        MODE_SERIES: t.MODE_SERIES
    },
    methods: {
        toDetail: function() {
            var t = this.data.target;
            this.triggerEvent("onTap", t);
        }
    }
});