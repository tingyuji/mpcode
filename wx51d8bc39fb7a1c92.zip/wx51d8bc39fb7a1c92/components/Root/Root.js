var e = require("../../utils/enum");

getApp();

Component({
    options: {
        multipleSlots: !0
    },
    lifetimes: {
        attached: function() {
            this.init();
        },
        detached: function() {}
    },
    pageLifetimes: {
        show: function() {}
    },
    properties: {
        title: {
            type: String
        },
        leftBtn: {
            type: Array,
            value: []
        },
        logo: {
            type: Boolean,
            value: !1
        },
        bgColor: {
            type: String,
            value: "#fff"
        }
    },
    data: {},
    methods: {
        init: function() {
            var t = getCurrentPages(), i = t[t.length - 1].route, a = wx.getStorageSync(e.ENUM_PAGES_HISTORY);
            if ("" === a) wx.setStorageSync(e.ENUM_PAGES_HISTORY, JSON.stringify([ {
                pages: i,
                value: 1
            } ])); else {
                a = JSON.parse(a);
                for (var n = 0; n < a.length; n++) {
                    if (a[n].pages === i) {
                        a[n].value++;
                        break;
                    }
                    if (a.length - 1 === n) {
                        a.push({
                            pages: i,
                            value: 1
                        });
                        break;
                    }
                }
                wx.setStorageSync(e.ENUM_PAGES_HISTORY, JSON.stringify(a));
            }
        }
    }
});