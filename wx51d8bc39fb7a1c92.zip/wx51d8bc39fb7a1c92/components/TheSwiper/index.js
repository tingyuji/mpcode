var t = require("../../utils/goto");

Component({
    options: {
        addGlobalClass: !0
    },
    properties: {
        list: {
            type: Array,
            value: []
        },
        height: {
            type: String,
            value: "150"
        }
    },
    data: {
        indicatorDots: !0,
        vertical: !1,
        autoplay: !0,
        interval: 2e3,
        duration: 500
    },
    lifetimes: {
        attached: function() {}
    },
    methods: {
        handler: function(e) {
            var a = e.currentTarget.dataset.item;
            this.triggerEvent("clickDetail", a), (0, t.goto)(a.url);
        }
    }
});