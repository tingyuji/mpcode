Component({
    options: {
        addGlobalClass: !0
    },
    properties: {
        title: {
            type: String
        },
        hideRight: {
            type: Boolean,
            value: !1
        }
    },
    methods: {
        handleEmit: function() {
            this.triggerEvent("onTap");
        }
    }
});