var t = require("../../@babel/runtime/helpers/objectSpread2"), a = require("../../utils/enum"), e = require("../../utils/index");

Component({
    options: {
        addGlobalClass: !0
    },
    properties: {
        list: {
            type: Array,
            value: []
        },
        activeIndex: {
            type: Number,
            value: 0
        }
    },
    data: {
        showList: []
    },
    lifetimes: {
        attached: function() {}
    },
    methods: {
        handleClick: function(t) {
            var a = t.currentTarget.dataset.item;
            this.triggerEvent("click", a);
        }
    },
    observers: {
        list: function(s) {
            switch (this.data.activeIndex) {
              case a.ENUM_ARTICLE:
                var i = this.data.list.map(function(t) {
                    return Object.assign({}, t, {
                        categoriesStr: t.categories ? t.categories[0].parent.title : ""
                    });
                });
                this.setData({
                    showList: i
                });
                break;

              case a.ENUM_EXAM:
                var r = this.data.list.map(function(t) {
                    return Object.assign({}, t, {
                        categoriesStr: t.categories.length ? t.categories[0].parent.title : ""
                    });
                });
                this.setData({
                    showList: r
                });
                break;

              case a.ENUM_PLAN:
                var n = this.data.list.map(function(t) {
                    return Object.assign({}, t, {
                        sub_plan_count: t.data.sub_plan_count
                    });
                });
                this.setData({
                    showList: n
                });
                break;

              case a.ENUM_MEDITATION:
                var c = this.data.list.map(function(t) {
                    var a = Number(t.data.duration) || 0;
                    return Object.assign({}, t, {
                        duration: (0, e.timeToStr)(a)
                    });
                });
                this.setData({
                    showList: c
                });
                break;

              case a.ENUM_TALK:
                var o = this.data.list.map(function(a) {
                    return Object.assign({}, a, t(t({}, a.consult_case), {}, {
                        article_id: a.target_id
                    }));
                });
                this.setData({
                    showList: o
                });
            }
        }
    }
});