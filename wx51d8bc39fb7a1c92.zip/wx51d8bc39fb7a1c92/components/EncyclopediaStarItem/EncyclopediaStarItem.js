var t = require("../../utils/index");

Component({
    options: {
        addGlobalClass: !0
    },
    properties: {
        target: {
            type: Object,
            value: {}
        }
    },
    data: {},
    methods: {
        handler: function() {
            var a = this.data.target.id;
            (0, t.goto)("/pages/articleDetail/articleDetail?id=".concat(a));
        }
    }
});