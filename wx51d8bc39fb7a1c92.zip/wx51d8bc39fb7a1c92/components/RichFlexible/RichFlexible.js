Component({
    options: {
        addGlobalClass: !0
    },
    properties: {
        html: {
            type: String
        },
        initHeight: {
            type: String,
            value: "192rpx"
        },
        title: {
            type: [ String, Number ]
        }
    },
    data: {
        show: !1
    },
    methods: {
        toggle: function() {
            var t = this.data.show;
            this.setData({
                show: !t
            }), this.triggerEvent("onChange", !t);
        }
    }
});