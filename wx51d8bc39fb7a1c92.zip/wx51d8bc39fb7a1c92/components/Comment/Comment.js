var e = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/regenerator")), t = require("../../@babel/runtime/helpers/objectSpread2"), n = require("../../@babel/runtime/helpers/asyncToGenerator"), a = require("../../@babel/runtime/helpers/defineProperty"), r = require("../../api/index"), i = require("../../utils/index");

Component({
    options: {
        addGlobalClass: !0
    },
    properties: {
        list: {
            type: Array,
            value: []
        },
        type: {
            type: String,
            value: ""
        }
    },
    data: {
        commentList: []
    },
    lifetimes: {
        attached: function() {},
        ready: function() {}
    },
    observers: {
        list: function() {
            var e = this, t = this.data.list.map(function(e) {
                return Object.assign({}, e, {
                    fold: null,
                    _isZan: e.is_zan || e.is_star,
                    _zanCount: e.zan_count || e.praise_num,
                    create_time: (0, i.secondToStr)(e.create_time)
                });
            });
            this.setData({
                commentList: t
            }), wx.nextTick(function() {
                e.data.commentList.forEach(function(t, n) {
                    e.handleChangeComment(n);
                });
            });
        }
    },
    methods: {
        handleClickComment: function(e) {
            var t = e.currentTarget.dataset.index;
            this.handleChangeComment(t);
        },
        handleChangeComment: function(e) {
            var t = this, n = "commentList[" + e + "].fold";
            if (null === this.data.commentList[e].fold) {
                var r = wx.createSelectorQuery().in(this);
                r.select(".comment-text-".concat(e)).boundingClientRect(), r.select(".comment-content-".concat(e)).boundingClientRect(), 
                r.exec(function(r) {
                    if (r[0] && r[0].height) {
                        var i = r[0].height < r[1].height ? null : r[0].height > r[1].height;
                        t.setData(a({}, n, i), function() {
                            return t.triggerEvent("onChange", t.data.commentList[e]);
                        });
                    }
                });
            } else this.setData(a({}, n, !this.data.commentList[e].fold), function() {
                return t.triggerEvent("onChange", t.data.commentList[e]);
            });
        },
        handleZan: function(e) {
            var t = e.currentTarget.dataset, n = t.item, a = t.index, r = this.data.type;
            console.log(e, n, a), "exam" === r ? this.handleExam(n, a) : "dp" === r ? this.handleDp(n, a) : "meditation" === r && this.handleMeditation(n, a);
        },
        handleExam: function(i, o) {
            var c = this;
            return n(e.default.mark(function n() {
                var s, u, l, m, d;
                return e.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return s = i._isZan, u = i._zanCount, l = i.id, m = s ? r.examService.unZan : r.examService.zan, 
                        e.prev = 2, e.next = 5, m({
                            comment_id: l
                        });

                      case 5:
                        d = "commentList[".concat(o, "]"), c.setData(a({}, d, t(t({}, i), {}, {
                            _isZan: !s,
                            _zanCount: s ? u - 1 : u + 1
                        }))), e.next = 12;
                        break;

                      case 9:
                        e.prev = 9, e.t0 = e.catch(2), console.error(e.t0);

                      case 12:
                      case "end":
                        return e.stop();
                    }
                }, n, null, [ [ 2, 9 ] ]);
            }))();
        },
        handleDp: function(i, o) {
            var c = this;
            return n(e.default.mark(function n() {
                var s, u, l, m;
                return e.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return e.prev = 0, s = i.id, u = i._isZan, l = i._zanCount, e.next = 4, r.dpService.zan(s);

                      case 4:
                        m = "commentList[".concat(o, "]"), c.setData(a({}, m, t(t({}, i), {}, {
                            _isZan: !u,
                            _zanCount: u ? l - 1 : l + 1
                        }))), e.next = 11;
                        break;

                      case 8:
                        e.prev = 8, e.t0 = e.catch(0), console.error(e.t0);

                      case 11:
                      case "end":
                        return e.stop();
                    }
                }, n, null, [ [ 0, 8 ] ]);
            }))();
        },
        handleMeditation: function(i, o) {
            var c = this;
            return n(e.default.mark(function n() {
                var s, u, l, m;
                return e.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return e.prev = 0, s = i.id, u = i._isZan, l = i._zanCount, e.next = 4, r.meditationService.zan(s);

                      case 4:
                        m = "commentList[".concat(o, "]"), c.setData(a({}, m, t(t({}, i), {}, {
                            _isZan: !u,
                            _zanCount: u ? l - 1 : l + 1
                        }))), e.next = 11;
                        break;

                      case 8:
                        e.prev = 8, e.t0 = e.catch(0), console.error(e.t0);

                      case 11:
                      case "end":
                        return e.stop();
                    }
                }, n, null, [ [ 0, 8 ] ]);
            }))();
        }
    }
});