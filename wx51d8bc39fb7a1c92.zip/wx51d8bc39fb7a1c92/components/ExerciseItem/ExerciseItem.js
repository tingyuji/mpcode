var e = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/regenerator")), t = require("../../@babel/runtime/helpers/asyncToGenerator"), a = require("../../utils/index");

Component({
    options: {
        addGlobalClass: !0
    },
    properties: {
        item: {
            type: Object
        },
        optional: {
            type: Boolean,
            value: !1
        },
        selectedId: {
            type: Number,
            value: null
        },
        showCount: {
            type: Boolean,
            value: !1
        }
    },
    methods: {
        handleDetail: function() {
            var r = this;
            return t(e.default.mark(function t() {
                return e.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        r.data.optional ? r.triggerEvent("onTap", r.data.item) : (0, a.goto)("/pages/exerciseDetail/exerciseDetail?id=".concat(r.data.item.target_id || r.data.item.id));

                      case 2:
                      case "end":
                        return e.stop();
                    }
                }, t);
            }))();
        }
    }
});