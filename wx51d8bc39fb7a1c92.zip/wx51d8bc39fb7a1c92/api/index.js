var e = require("../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), Object.defineProperty(exports, "collectService", {
    enumerable: !0,
    get: function() {
        return o.default;
    }
}), Object.defineProperty(exports, "consultService", {
    enumerable: !0,
    get: function() {
        return r.default;
    }
}), exports.default = void 0, Object.defineProperty(exports, "dpService", {
    enumerable: !0,
    get: function() {
        return l.default;
    }
}), Object.defineProperty(exports, "examService", {
    enumerable: !0,
    get: function() {
        return t.default;
    }
}), Object.defineProperty(exports, "loginService", {
    enumerable: !0,
    get: function() {
        return u.default;
    }
}), Object.defineProperty(exports, "meditationService", {
    enumerable: !0,
    get: function() {
        return i.default;
    }
}), Object.defineProperty(exports, "saleService", {
    enumerable: !0,
    get: function() {
        return c.default;
    }
}), Object.defineProperty(exports, "wxService", {
    enumerable: !0,
    get: function() {
        return n.default;
    }
});

var r = e(require("./consult")), t = e(require("./exam")), u = e(require("./login")), i = e(require("./meditation")), n = e(require("./wx")), l = e(require("./dp")), c = e(require("./sale")), o = e(require("./collect")), a = {
    wxService: n.default,
    consultService: r.default,
    examService: t.default,
    loginService: u.default,
    meditationService: i.default,
    dpService: l.default,
    saleService: c.default,
    collectService: o.default
};

exports.default = a;