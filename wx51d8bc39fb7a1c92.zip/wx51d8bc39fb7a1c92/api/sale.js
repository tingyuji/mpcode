var e = require("../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var t = e(require("../utils/request.js")), r = require("../config/index"), a = {
    getSale: function(e, a) {
        return (0, t.default)({
            url: "".concat(r.order, "/activity/effective"),
            params: e
        }, a);
    },
    getDetail: function(e, a) {
        return (0, t.default)({
            url: "".concat(r.order, "/help_activity/").concat(e.id, "/info"),
            params: e
        }, a);
    },
    postHelp: function(e, a) {
        return (0, t.default)({
            url: "".concat(r.order, "/help_activity/help"),
            method: "POST",
            data: e
        }, a);
    },
    getShareKey: function(e, a) {
        return (0, t.default)({
            url: "".concat(r.order, "/help_activity/join"),
            method: "POST",
            data: e
        }, a);
    },
    getRecord: function(e, a) {
        return (0, t.default)({
            url: "".concat(r.order, "/help_activity/log"),
            params: e
        }, a);
    },
    getQrcode: function(e, a) {
        return (0, t.default)({
            url: "".concat(r.together, "/qrcode"),
            method: "POST",
            data: e
        }, a);
    },
    getQrcodeData: function(e, a) {
        return (0, t.default)({
            url: "".concat(r.together, "/qrcode/data"),
            params: e
        }, a);
    },
    getReceive: function(e, a) {
        return (0, t.default)({
            url: "".concat(r.order, "/help_activity/receive"),
            method: "POST",
            params: e
        }, a);
    },
    getWinLog: function(e, a) {
        return (0, t.default)({
            url: "".concat(r.order, "/help_activity/").concat(e, "/win_log"),
            method: "GET"
        }, a);
    }
};

exports.default = a;