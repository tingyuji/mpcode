var e = require("../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var t = e(require("../utils/request.js")), r = require("../config/index"), u = {
    getVirtualcase: function(e, u) {
        return (0, t.default)({
            url: "".concat(r.together, "/consult-case"),
            data: e
        }, u);
    },
    getVirtualcaseDetail: function(e, u) {
        return (0, t.default)({
            url: "".concat(r.together, "/consult-case/").concat(e.id),
            data: e
        }, u);
    },
    getComment: function(e, u) {
        return (0, t.default)({
            url: "".concat(r.consult, "/order/show-comments"),
            data: e
        }, u);
    }
};

exports.default = u;