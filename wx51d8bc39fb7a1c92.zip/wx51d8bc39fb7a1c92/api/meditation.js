var t = require("../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = t(require("../utils/request.js")), a = require("../config/index"), n = {
    getDetail: function(t, n) {
        return (0, e.default)({
            url: "".concat(a.meditation_app, "/course/").concat(t.id),
            data: t
        }, n);
    },
    getComment: function(t, n) {
        return (0, e.default)({
            url: "".concat(a.meditation_app, "/comment/list"),
            data: t
        }, n);
    },
    getLesson: function(t, n) {
        return (0, e.default)({
            url: "".concat(a.meditation_app, "/lesson/info"),
            data: t
        }, n);
    },
    getCategory: function(t, n) {
        return (0, e.default)({
            url: "".concat(a.meditation_app, "/category/").concat(t.type),
            data: t
        }, n);
    },
    getCategoryDetail: function(t, n) {
        return (0, e.default)({
            url: "".concat(a.meditation_app, "/course"),
            data: t
        }, n);
    },
    starMeditation: function(t, n) {
        return (0, e.default)({
            url: "".concat(a.meditation_app, "/course/star"),
            method: "POST",
            data: t
        }, n);
    },
    getUserCollect: function(t, n) {
        return (0, e.default)({
            url: "".concat(a.meditation_app, "/user/courses"),
            data: t
        }, n);
    },
    getUserLog: function(t, n) {
        return (0, e.default)({
            url: "".concat(a.meditation_app, "/user/logs"),
            data: t
        }, n);
    },
    sendStudy: function(t, n) {
        return (0, e.default)({
            url: "".concat(a.meditation_app, "/study/").concat(t.id),
            method: "POST",
            data: t
        }, n);
    },
    zan: function(t, n) {
        return (0, e.default)({
            url: "".concat(a.meditation_app, "/comment/").concat(t, "/star"),
            method: "POST"
        }, n);
    },
    getshare: function(t, n) {
        return (0, e.default)({
            url: "together/".concat(a.meditation_app, "/").concat(t)
        }, n);
    }
};

exports.default = n;