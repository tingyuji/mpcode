var e = require("../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var t = e(require("../utils/request.js")), r = require("../config/index.js"), u = {
    getWxToken: function(e, u) {
        return (0, t.default)({
            url: "".concat(r.wechat, "/mp/userinfo"),
            method: "POST",
            data: e
        }, u);
    },
    checkUserIsRegistered: function(e, r) {
        return (0, t.default)({
            url: "user/wechat/login",
            method: "POST",
            data: e
        }, r);
    },
    userLogin: function(e, r) {
        return (0, t.default)({
            url: "user/oauth/login",
            method: "POST",
            data: e
        }, r);
    },
    apiSendCode: function(e, r) {
        return (0, t.default)({
            url: "user/user/send-sms",
            method: "POST",
            data: e
        }, r);
    },
    apiBindPhone: function(e, r) {
        return (0, t.default)({
            url: "user/user/bind-mobile",
            method: "POST",
            data: e
        }, r);
    },
    apiBindMobile: function(e, r) {
        return (0, t.default)({
            url: "user/oauth/bind-mobile",
            method: "POST",
            data: e
        }, r);
    },
    apiBindMobileRegister: function(e, r) {
        return (0, t.default)({
            url: "user/wechat/register",
            method: "POST",
            data: e
        }, r);
    }
};

exports.default = u;