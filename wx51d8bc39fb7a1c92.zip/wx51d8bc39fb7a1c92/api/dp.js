var t = require("../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = t(require("../utils/request.js")), a = require("../config/index"), n = {
    getDetail: function(t, n) {
        return (0, e.default)({
            url: "".concat(a.dp, "/plan/").concat(t.id),
            params: t
        }, n);
    },
    getComment: function(t, n) {
        return (0, e.default)({
            url: "".concat(a.dp, "/comment/list"),
            params: t
        }, n);
    },
    setStar: function(t, n) {
        return (0, e.default)({
            url: "".concat(a.dp, "/user_plan/follow"),
            method: "POST",
            data: t
        }, n);
    },
    getHome: function(t, n) {
        return (0, e.default)({
            url: "".concat(a.dp, "/home"),
            data: t
        }, n);
    },
    getGuidance: function(t, n) {
        return (0, e.default)({
            url: "".concat(a.dp, "/guidance"),
            data: t
        }, n);
    },
    getGuidanceDetail: function(t, n) {
        return (0, e.default)({
            url: "".concat(a.dp, "/guidance/").concat(t.id),
            data: t
        }, n);
    },
    zan: function(t, n) {
        return (0, e.default)({
            url: "".concat(a.dp, "/comment/").concat(t, "/star"),
            method: "POST"
        }, n);
    }
};

exports.default = n;