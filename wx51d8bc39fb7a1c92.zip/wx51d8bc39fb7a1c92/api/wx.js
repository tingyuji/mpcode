var t = require("../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = t(require("../utils/request.js")), r = require("../config/index"), a = {
    getHome: function(t, a) {
        return (0, e.default)({
            url: "".concat(r.together, "/home"),
            method: "get",
            data: t
        }, a);
    },
    getHomeResource: function(t) {
        return (0, e.default)({
            url: "".concat(r.together, "/home/resource"),
            method: "get"
        }, t);
    },
    searchList: function(t, a) {
        return (0, e.default)({
            url: "".concat(r.together, "/search"),
            method: "get",
            data: t
        }, a);
    },
    searchRecommend: function(t, a) {
        return (0, e.default)({
            url: "".concat(r.together, "/search/recommend"),
            method: "get",
            data: t
        }, a);
    },
    getMeditation: function(t, a) {
        return (0, e.default)({
            url: "".concat(r.together, "/ky_mediation/").concat(t.id),
            data: t
        }, a);
    },
    queryCategoryById: function(t, a) {
        return (0, e.default)({
            url: "".concat(r.together, "/category/").concat(t)
        }, a);
    },
    apiChangeCategoryFollow: function(t, a, o) {
        return (0, e.default)({
            url: "".concat(r.together, "/category/").concat(t, "/follow"),
            method: "POST",
            data: a
        }, o);
    },
    apiQueryArticleDetail: function(t, a) {
        return (0, e.default)({
            url: "".concat(r.together, "/article/").concat(t)
        }, a);
    },
    submitFeedback: function(t, a) {
        return (0, e.default)({
            url: "".concat(r.community, "/user/feedback"),
            method: "POST",
            data: t
        }, a);
    },
    apiChangeArticleStatus: function(t, a, o) {
        return (0, e.default)({
            url: "".concat(r.together, "/article/").concat(t, "/follow"),
            method: "POST",
            data: a
        }, o);
    },
    findBannerList: function(t, a) {
        return (0, e.default)({
            url: "".concat(r.together, "/home/banner?type=").concat(t)
        }, a);
    },
    getAppUserHome: function(t) {
        return (0, e.default)({
            url: "".concat(r.community, "/user/home")
        }, t);
    },
    getFollowList: function(t, a) {
        return (0, e.default)({
            url: "".concat(r.together, "/user/follow-list"),
            data: t
        }, a);
    },
    getTargetKeywordsByType: function(t, a) {
        return (0, e.default)({
            url: "".concat(r.together, "/target_keyword"),
            params: t
        }, a);
    },
    getArticleShare: function(t, a) {
        return (0, e.default)({
            url: "".concat(r.together, "/consult-case/1/share"),
            params: t
        }, a);
    },
    getDaily: function(t, a) {
        return (0, e.default)({
            url: "".concat(r.together, "/user/daily"),
            params: t
        }, a);
    },
    updateDaily: function(t, a) {
        return (0, e.default)({
            url: "".concat(r.together, "/user/daily"),
            method: "POST",
            params: t
        }, a);
    }
};

exports.default = a;