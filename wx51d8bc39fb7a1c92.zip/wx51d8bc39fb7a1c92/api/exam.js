var t = require("../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = t(require("../utils/request.js")), a = require("../config/index"), r = {
    getDetail: function(t, r) {
        return (0, e.default)({
            url: "".concat(a.exam, "/exam/").concat(t.id),
            params: t
        }, r);
    },
    getRecommend: function(t, r) {
        return (0, e.default)({
            url: "".concat(a.exam, "/exam/").concat(t.id, "/recommend"),
            params: t
        }, r);
    },
    getComment: function(t, r) {
        return (0, e.default)({
            url: "".concat(a.exam, "/comment"),
            params: t
        }, r);
    },
    setStar: function(t, r) {
        return (0, e.default)({
            url: "".concat(a.exam, "/exam/").concat(t.id, "/star"),
            method: "POST",
            data: t
        }, r);
    },
    setUnStar: function(t, r) {
        return (0, e.default)({
            url: "".concat(a.exam, "/exam/").concat(t.id, "/unstar"),
            method: "POST",
            data: t
        }, r);
    },
    createOrder: function(t, r) {
        return (0, e.default)({
            url: "".concat(a.exam, "/order/0"),
            method: "POST",
            data: t
        }, r);
    },
    getUserExamList: function(t, r) {
        return (0, e.default)({
            url: "".concat(a.exam, "/userorder"),
            params: t
        }, r);
    },
    getCategory: function(t, r) {
        return (0, e.default)({
            url: "".concat(a.exam, "/category"),
            params: t
        }, r);
    },
    getExamList: function(t, r) {
        return (0, e.default)({
            url: "".concat(a.exam, "/exam"),
            params: t
        }, r);
    },
    getStarList: function(t, r) {
        return (0, e.default)({
            url: "".concat(a.exam, "/user/stars"),
            params: t
        }, r);
    },
    getPaySign: function(t, r) {
        return (0, e.default)({
            url: "".concat(a.exam, "/order/").concat(t.order_id, "/pay"),
            method: "post",
            data: t
        }, r);
    },
    unZan: function(t, r) {
        return (0, e.default)({
            url: "".concat(a.exam, "/comment/unzan"),
            method: "post",
            data: t
        }, r);
    },
    zan: function(t, r) {
        return (0, e.default)({
            url: "".concat(a.exam, "/comment/zan"),
            method: "post",
            data: t
        }, r);
    }
};

exports.default = r;