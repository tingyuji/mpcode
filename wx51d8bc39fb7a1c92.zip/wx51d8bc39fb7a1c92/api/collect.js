var e = require("../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var r = e(require("../utils/request.js")), t = require("../config/index"), u = {
    collectRecord: function(e, u) {
        return (0, r.default)({
            url: "".concat(t.collect, "/record"),
            method: "POST",
            data: e
        }, u);
    }
};

exports.default = u;