var e = require("@babel/runtime/helpers/interopRequireDefault"), t = require("@babel/runtime/helpers/objectSpread2"), n = e(require("umtrack-wx"));

require("./utils/wx");

var a = require("./utils/dataCollect");

App({
    umengConfig: {
        appKey: "608277c69e4e8b6f617f0713",
        useOpenid: !0,
        autoGetOpenid: !0,
        uploadUserInfo: !0,
        debug: !1,
        enableVerify: !1
    },
    onLaunch: function() {
        wx.cloud ? wx.cloud.init({
            traceUser: !0
        }) : console.error("请使用 2.2.3 或以上的基础库以使用云能力");
    },
    onShow: function(e) {
        this.setNavBar(), this.autoUpdate(), console.log(e), (0, a.dataCheck)(e.query), 
        (0, a.setListData)({
            url: e.path
        }), wx._trackEvent = function(e) {
            var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
            for (var a in t) if (t.hasOwnProperty(a)) {
                var o = t[a];
                t[a] = o + "";
            }
            n.default.trackEvent(e, t);
        };
    },
    globalData: {
        uma: n.default,
        navHeight: null,
        navTop: null,
        statusBarHeight: null,
        systemInfo: null,
        user_id: "",
        code: null
    },
    filterUrlParam: function(e) {
        var t = {}, n = /([^&=]+)=([\w\W]*?)(&|$|#)/g;
        if (e) for (var a, o = e; null != (a = n.exec(o)); ) t[a[1]] = a[2];
        return t;
    },
    setNavBar: function() {
        var e = this, n = wx.getMenuButtonBoundingClientRect();
        wx.getSystemInfo({
            success: function(a) {
                var o = a.windowHeight, i = a.statusBarHeight, r = a.system, u = n.top, c = i + n.height + 2 * (n.top - i), l = r.toLocaleLowerCase().includes("ios");
                e.globalData = t(t({}, e.globalData), {}, {
                    navHeight: c,
                    navTop: u,
                    statusBarHeight: i,
                    windowHeight: o,
                    systemInfo: t(t({}, a), {}, {
                        isIos: l
                    })
                });
            },
            fail: function(e) {
                console.log(e);
            }
        });
    },
    checkUpdate: function() {
        var e = wx.getUpdateManager();
        e.onCheckForUpdate(function(e) {
            console.log(" 请求完新版本信息的回调", e.hasUpdate);
        }), e.onUpdateReady(function() {
            wx.showModal({
                title: "更新提示",
                content: "新版本已经准备好，是否重启应用？",
                success: function(t) {
                    t.confirm && e.applyUpdate();
                }
            });
        });
    },
    autoUpdate: function() {
        var e = this;
        if (wx.canIUse("getUpdateManager")) {
            var t = wx.getUpdateManager();
            t.onCheckForUpdate(function(n) {
                n.hasUpdate && wx.showModal({
                    title: "更新提示",
                    content: "检测到新版本，是否下载新版本并重启小程序？",
                    success: function(n) {
                        n.confirm ? e.downLoadAndUpdate(t) : n.cancel && wx.showModal({
                            title: "温馨提示~",
                            content: "本次版本更新涉及到新的功能添加，旧版本无法正常访问的哦~",
                            showCancel: !1,
                            confirmText: "确定更新",
                            success: function(n) {
                                n.confirm && e.downLoadAndUpdate(t);
                            }
                        });
                    }
                });
            });
        } else wx.showModal({
            title: "提示",
            content: "当前微信版本过低，无法使用该功能，请升级到最新微信版本后重试。"
        });
    },
    downLoadAndUpdate: function(e) {
        wx.showLoading(), e.onUpdateReady(function() {
            wx.hideLoading(), e.applyUpdate();
        }), e.onUpdateFailed(function() {
            wx.showModal({
                title: "已经有新版本了哟~",
                content: "新版本已经上线啦~，请您删除当前小程序，重新搜索打开哟~"
            });
        });
    }
});