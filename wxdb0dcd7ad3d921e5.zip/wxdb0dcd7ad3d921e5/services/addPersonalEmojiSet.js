var e = require("../utils/request");

module.exports = function(i) {
    var r = i.emojiKey, u = i.uniqueId, s = i.emojis;
    return (0, e.request)("/splicer/addPersonalEmojiSet", {
        emojiKey: r,
        uniqueId: u,
        emojis: s
    }, "POST");
};