var e = require("../utils/request");

module.exports = function(i) {
    var r = i.emojiKey, u = i.uniqueId, o = i.emojis;
    return (0, e.request)("/splicer/getAppQrCode", {
        emojiKey: r,
        uniqueId: u,
        env: __wxConfig.envVersion,
        emojis: o
    }, "POST");
};