var e = require("../utils/request");

module.exports = function(t) {
    var r = t.baseRequest, i = t.filePath, s = t.emojiKey, u = t.layerInfo, a = t.text;
    return (0, e.request)("/splicer/addEmojiBackup", {
        baseRequest: r,
        filePath: i,
        emojiKey: s,
        layerInfo: JSON.stringify(u),
        text: a
    }, "POST", "file");
};