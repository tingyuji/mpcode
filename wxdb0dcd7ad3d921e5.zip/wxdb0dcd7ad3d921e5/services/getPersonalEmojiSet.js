var e = require("../utils/request");

module.exports = function(t) {
    var r = t.setKey, s = t.context;
    return (0, e.request)("/splicer/getPersonalEmojiSet", {
        setKey: r,
        context: s
    }, "POST");
};