var e = require("../utils/request");

module.exports = function(s) {
    var r = s.baseRequest, t = s.base64, u = s.layerInfo;
    return (0, e.request)("/splicer/setNewMixEmoji", {
        baseRequest: r,
        base64: t,
        layerInfo: u
    }, "POST");
};