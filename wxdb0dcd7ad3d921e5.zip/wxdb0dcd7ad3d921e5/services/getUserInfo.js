var e = require("../utils/request");

module.exports = function() {
    return (0, e.request)("/splicer/getUserInfo", {}, "GET");
};