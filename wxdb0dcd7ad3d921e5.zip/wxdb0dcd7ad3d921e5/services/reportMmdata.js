var t = require("../utils/request");

module.exports = function(e) {
    var r = e.context;
    return (0, t.request)("/report/report_mmdata", {
        context: r
    }, "POST");
};