var e = require("../utils/request");

module.exports = function(s) {
    var r = s.baseRequest, t = s.keys;
    return (0, e.request)("/splicer/deleteMixEmoji", {
        baseRequest: r,
        keys: t
    }, "POST");
};