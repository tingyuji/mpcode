var e = require("../utils/request");

module.exports = function(r) {
    var s = r.baseRequest, t = r.base64, u = r.layerInfo, a = r.emojiKey;
    return (0, e.request)("/splicer/updateMixEmoji", {
        baseRequest: s,
        base64: t,
        layerInfo: u,
        emojiKey: a
    }, "POST");
};