var t = require("../utils/request");

module.exports = function(e) {
    var r = e.context;
    return (0, t.requestReportPyq)("/report/report_pyq_mmdata", {
        context: r
    }, "POST");
};