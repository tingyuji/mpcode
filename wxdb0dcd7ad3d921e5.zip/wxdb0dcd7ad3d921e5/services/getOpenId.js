var e = require("../utils/request");

module.exports = function(t) {
    return (0, e.request)("/auth/getOpenId", {
        code: t
    }, "POST");
};