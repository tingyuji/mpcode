var e = require("../utils/request");

module.exports = function(r) {
    var t = r.md5;
    return (0, e.request)("/splicer/addHotEmojiBackup", {
        md5: t
    }, "POST");
};