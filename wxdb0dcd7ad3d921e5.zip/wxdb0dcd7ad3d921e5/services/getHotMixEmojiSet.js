var e = require("../utils/request");

module.exports = function(t) {
    var r = t.context;
    return (0, e.request)("/splicer/getHotMixEmojiSet", {
        context: r
    }, "POST");
};