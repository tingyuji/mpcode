var t = require("../utils/request");

module.exports = function(e) {
    var r = e.context;
    return (0, t.request)("/splicer/getMixEmojiList", {
        context: r
    }, "post");
};