var e = require("../utils/request");

module.exports = function(r) {
    var s = r.version;
    return (0, e.request)("/splicer/setUserInfo", {
        origVersion: s
    }, "POST");
};