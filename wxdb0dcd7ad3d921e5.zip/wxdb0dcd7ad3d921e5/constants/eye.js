module.exports = {
    eye: [ {
        url: "https://res.wx.qq.com/t/fed_upload/28abe040-df0f-4daf-b033-04ee02f4ba46/1.png",
        site: {
            left: 50,
            top: 50,
            height: 20,
            width: 80,
            zIndex: 1,
            config: {
                type: 3
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/28abe040-df0f-4daf-b033-04ee02f4ba46/2.png",
        site: {
            left: 47,
            top: 46.5,
            height: 20,
            width: 80,
            zIndex: 1,
            config: {
                type: 3
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/28abe040-df0f-4daf-b033-04ee02f4ba46/3.png",
        site: {
            left: 47,
            top: 65,
            height: 40,
            width: 80,
            zIndex: 1,
            config: {
                type: 3
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/28abe040-df0f-4daf-b033-04ee02f4ba46/4.png",
        site: {
            left: 27,
            top: 65,
            height: 20,
            width: 80,
            zIndex: 1,
            config: {
                type: 3
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/28abe040-df0f-4daf-b033-04ee02f4ba46/5.png",
        site: {
            left: 73,
            top: 65,
            height: 40,
            width: 80,
            zIndex: 1,
            config: {
                type: 3
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/7d0b165d-cb60-48be-897b-a36eb13718e9/6.png",
        site: {
            left: 50,
            top: 50,
            height: 25,
            width: 80,
            zIndex: 1,
            config: {
                type: 3
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/7d0b165d-cb60-48be-897b-a36eb13718e9/7.png",
        site: {
            left: 47,
            top: 46.5,
            height: 5,
            width: 80,
            zIndex: 1,
            config: {
                type: 3
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/7d0b165d-cb60-48be-897b-a36eb13718e9/8.png",
        site: {
            left: 47,
            top: 65,
            height: 30,
            width: 70,
            zIndex: 1,
            config: {
                type: 3
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/7d0b165d-cb60-48be-897b-a36eb13718e9/10.png",
        site: {
            left: 73,
            top: 65,
            height: 40,
            width: 80,
            zIndex: 1,
            config: {
                type: 3
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/28abe040-df0f-4daf-b033-04ee02f4ba46/11.png",
        site: {
            left: 50,
            top: 50,
            height: 25,
            width: 80,
            zIndex: 1,
            config: {
                type: 3
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/28abe040-df0f-4daf-b033-04ee02f4ba46/12.png",
        site: {
            left: 47,
            top: 46.5,
            height: 40,
            width: 80,
            zIndex: 1,
            config: {
                type: 3
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/28abe040-df0f-4daf-b033-04ee02f4ba46/13.png",
        site: {
            left: 47,
            top: 65,
            height: 40,
            width: 80,
            zIndex: 1,
            config: {
                type: 3
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/28abe040-df0f-4daf-b033-04ee02f4ba46/14.png",
        site: {
            left: 27,
            top: 65,
            height: 40,
            width: 80,
            zIndex: 1,
            config: {
                type: 3
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/28abe040-df0f-4daf-b033-04ee02f4ba46/15.png",
        site: {
            left: 50,
            top: 50,
            height: 30,
            width: 80,
            zIndex: 1,
            config: {
                type: 3
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/28abe040-df0f-4daf-b033-04ee02f4ba46/16.png",
        site: {
            left: 47,
            top: 46.5,
            height: 20,
            width: 80,
            zIndex: 1,
            config: {
                type: 3
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/28abe040-df0f-4daf-b033-04ee02f4ba46/17.png",
        site: {
            left: 47,
            top: 65,
            height: 35,
            width: 80,
            zIndex: 1,
            config: {
                type: 3
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/7d0b165d-cb60-48be-897b-a36eb13718e9/18.png",
        site: {
            left: 27,
            top: 65,
            height: 25,
            width: 80,
            zIndex: 1,
            config: {
                type: 3
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/7d0b165d-cb60-48be-897b-a36eb13718e9/19.png",
        site: {
            left: 73,
            top: 65,
            height: 15,
            width: 80,
            zIndex: 1,
            config: {
                type: 3
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/28abe040-df0f-4daf-b033-04ee02f4ba46/20.png",
        site: {
            left: 50,
            top: 50,
            height: 20,
            width: 80,
            zIndex: 1,
            config: {
                type: 3
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/28abe040-df0f-4daf-b033-04ee02f4ba46/21.png",
        site: {
            left: 47,
            top: 46.5,
            height: 20,
            width: 80,
            zIndex: 1,
            config: {
                type: 3
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/28abe040-df0f-4daf-b033-04ee02f4ba46/22.png",
        site: {
            left: 47,
            top: 65,
            height: 50,
            width: 80,
            zIndex: 1,
            config: {
                type: 3
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/28abe040-df0f-4daf-b033-04ee02f4ba46/23.png",
        site: {
            left: 27,
            top: 65,
            height: 20,
            width: 80,
            zIndex: 1,
            config: {
                type: 3
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/28abe040-df0f-4daf-b033-04ee02f4ba46/24.png",
        site: {
            left: 73,
            top: 65,
            height: 15,
            width: 80,
            zIndex: 1,
            config: {
                type: 3
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/28abe040-df0f-4daf-b033-04ee02f4ba46/25.png",
        site: {
            left: 50,
            top: 50,
            height: 25,
            width: 80,
            zIndex: 1,
            config: {
                type: 3
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/28abe040-df0f-4daf-b033-04ee02f4ba46/26.png",
        site: {
            left: 47,
            top: 46.5,
            height: 40,
            width: 80,
            zIndex: 1,
            config: {
                type: 3
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/28abe040-df0f-4daf-b033-04ee02f4ba46/27.png",
        site: {
            left: 47,
            top: 65,
            height: 25,
            width: 80,
            zIndex: 1,
            config: {
                type: 3
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/28abe040-df0f-4daf-b033-04ee02f4ba46/28.png",
        site: {
            left: 27,
            top: 65,
            height: 35,
            width: 80,
            zIndex: 1,
            config: {
                type: 3
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/28abe040-df0f-4daf-b033-04ee02f4ba46/29.png",
        site: {
            left: 50,
            top: 50,
            height: 40,
            width: 80,
            zIndex: 1,
            config: {
                type: 3
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/28abe040-df0f-4daf-b033-04ee02f4ba46/30.png",
        site: {
            left: 47,
            top: 46.5,
            height: 40,
            width: 80,
            zIndex: 1,
            config: {
                type: 3
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/28abe040-df0f-4daf-b033-04ee02f4ba46/31.png",
        site: {
            left: 47,
            top: 65,
            height: 10,
            width: 80,
            zIndex: 1,
            config: {
                type: 3
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/28abe040-df0f-4daf-b033-04ee02f4ba46/32.png",
        site: {
            left: 27,
            top: 65,
            height: 50,
            width: 80,
            zIndex: 1,
            config: {
                type: 3
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/28abe040-df0f-4daf-b033-04ee02f4ba46/33.png",
        site: {
            left: 73,
            top: 65,
            height: 40,
            width: 80,
            zIndex: 1,
            config: {
                type: 3
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/28abe040-df0f-4daf-b033-04ee02f4ba46/34.png",
        site: {
            left: 50,
            top: 50,
            height: 20,
            width: 80,
            zIndex: 1,
            config: {
                type: 3
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/28abe040-df0f-4daf-b033-04ee02f4ba46/35.png",
        site: {
            left: 47,
            top: 46.5,
            height: 25,
            width: 80,
            zIndex: 1,
            config: {
                type: 3
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/28abe040-df0f-4daf-b033-04ee02f4ba46/36.png",
        site: {
            left: 47,
            top: 65,
            height: 40,
            width: 80,
            zIndex: 1,
            config: {
                type: 3
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/28abe040-df0f-4daf-b033-04ee02f4ba46/37.png",
        site: {
            left: 27,
            top: 65,
            height: 20,
            width: 80,
            zIndex: 1,
            config: {
                type: 3
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/28abe040-df0f-4daf-b033-04ee02f4ba46/38.png",
        site: {
            left: 73,
            top: 65,
            height: 25,
            width: 80,
            zIndex: 1,
            config: {
                type: 3
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/28abe040-df0f-4daf-b033-04ee02f4ba46/39.png",
        site: {
            left: 50,
            top: 50,
            height: 25,
            width: 80,
            zIndex: 1,
            config: {
                type: 3
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/28abe040-df0f-4daf-b033-04ee02f4ba46/40.png",
        site: {
            left: 47,
            top: 46.5,
            height: 25,
            width: 80,
            zIndex: 1,
            config: {
                type: 3
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/28abe040-df0f-4daf-b033-04ee02f4ba46/41.png",
        site: {
            left: 47,
            top: 65,
            height: 35,
            width: 80,
            zIndex: 1,
            config: {
                type: 3
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/28abe040-df0f-4daf-b033-04ee02f4ba46/42.png",
        site: {
            left: 27,
            top: 65,
            height: 35,
            width: 80,
            zIndex: 1,
            config: {
                type: 3
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/28abe040-df0f-4daf-b033-04ee02f4ba46/43.png",
        site: {
            left: 50,
            top: 50,
            height: 40,
            width: 80,
            zIndex: 1,
            config: {
                type: 3
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/28abe040-df0f-4daf-b033-04ee02f4ba46/44.png",
        site: {
            left: 47,
            top: 46.5,
            height: 40,
            width: 80,
            zIndex: 1,
            config: {
                type: 3
            }
        }
    } ]
};