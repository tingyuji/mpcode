module.exports = {
    BASE_URL: "https://sticker.weixin.qq.com/cgi-bin/mmemotionmeshnode-bin"
};