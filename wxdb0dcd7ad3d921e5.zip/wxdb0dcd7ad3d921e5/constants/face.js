module.exports = {
    face: [ {
        url: "https://res.wx.qq.com/t/fed_upload/a1aaf7ce-345f-42f2-bf85-c6c5bd7acf09/1.png",
        site: {
            left: 50,
            top: 50,
            height: 176,
            width: 176,
            zIndex: 0,
            config: {
                type: 1
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/a1aaf7ce-345f-42f2-bf85-c6c5bd7acf09/2.png",
        site: {
            left: 50,
            top: 50,
            height: 176,
            width: 187,
            zIndex: 0,
            config: {
                type: 1
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/a1aaf7ce-345f-42f2-bf85-c6c5bd7acf09/3.png",
        site: {
            left: 50,
            top: 50,
            height: 174,
            width: 170,
            zIndex: 0,
            config: {
                type: 1
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/a1aaf7ce-345f-42f2-bf85-c6c5bd7acf09/4.png",
        site: {
            left: 50,
            top: 50,
            height: 180,
            width: 177,
            zIndex: 0,
            config: {
                type: 1
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/a1aaf7ce-345f-42f2-bf85-c6c5bd7acf09/5.png",
        site: {
            left: 50,
            top: 50,
            height: 176,
            width: 176,
            zIndex: 0,
            config: {
                type: 1
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/a1aaf7ce-345f-42f2-bf85-c6c5bd7acf09/6.png",
        site: {
            left: 50,
            top: 50,
            height: 168,
            width: 172,
            zIndex: 0,
            config: {
                type: 1
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/a1aaf7ce-345f-42f2-bf85-c6c5bd7acf09/7.png",
        site: {
            left: 50,
            top: 50,
            height: 98,
            width: 163,
            zIndex: 0,
            config: {
                type: 1
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/a1aaf7ce-345f-42f2-bf85-c6c5bd7acf09/8.png",
        site: {
            left: 50,
            top: 50,
            height: 163,
            width: 168,
            zIndex: 0,
            config: {
                type: 1
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/a1aaf7ce-345f-42f2-bf85-c6c5bd7acf09/10.png",
        site: {
            left: 50,
            top: 50,
            height: 192,
            width: 192,
            zIndex: 0,
            config: {
                type: 1
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/a1aaf7ce-345f-42f2-bf85-c6c5bd7acf09/11.png",
        site: {
            left: 50,
            top: 50,
            height: 192,
            width: 192,
            zIndex: 0,
            config: {
                type: 1
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/a1aaf7ce-345f-42f2-bf85-c6c5bd7acf09/12.png",
        site: {
            left: 50,
            top: 50,
            height: 153,
            width: 163,
            zIndex: 0,
            config: {
                type: 1
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/a1aaf7ce-345f-42f2-bf85-c6c5bd7acf09/13.png",
        site: {
            left: 50,
            top: 50,
            height: 128,
            width: 128,
            zIndex: 0,
            config: {
                type: 1
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/a1aaf7ce-345f-42f2-bf85-c6c5bd7acf09/14.png",
        site: {
            left: 50,
            top: 50,
            height: 128,
            width: 128,
            zIndex: 0,
            config: {
                type: 1
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/a1aaf7ce-345f-42f2-bf85-c6c5bd7acf09/15.png",
        site: {
            left: 50,
            top: 50,
            height: 128,
            width: 128,
            zIndex: 0,
            config: {
                type: 1
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/a1aaf7ce-345f-42f2-bf85-c6c5bd7acf09/16.png",
        site: {
            left: 50,
            top: 50,
            height: 128,
            width: 128,
            zIndex: 0,
            config: {
                type: 1
            }
        }
    } ]
};