module.exports = {
    body: [ {
        url: "https://res.wx.qq.com/t/fed_upload/ddbefeea-3546-41b4-9498-a44e3d243fac/1.png",
        site: {
            left: 73,
            top: 65,
            height: 128,
            width: 128,
            zIndex: 4,
            config: {
                type: 2
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/ddbefeea-3546-41b4-9498-a44e3d243fac/2.png",
        site: {
            left: 50,
            top: 50,
            height: 128,
            width: 128,
            zIndex: 4,
            config: {
                type: 2
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/ddbefeea-3546-41b4-9498-a44e3d243fac/3.png",
        site: {
            left: 47,
            top: 46.5,
            height: 128,
            width: 128,
            zIndex: 4,
            config: {
                type: 2
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/ddbefeea-3546-41b4-9498-a44e3d243fac/4.png",
        site: {
            left: 47,
            top: 65,
            height: 80,
            width: 89,
            zIndex: 4,
            config: {
                type: 2
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/ddbefeea-3546-41b4-9498-a44e3d243fac/5.png",
        site: {
            left: 27,
            top: 65,
            height: 72,
            width: 72,
            zIndex: 4,
            config: {
                type: 2
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/c72affab-0fd5-4ecd-a447-069ca98d85a9/6.png",
        site: {
            left: 50,
            top: 50,
            height: 127,
            width: 130,
            zIndex: 4,
            config: {
                type: 2
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/ddbefeea-3546-41b4-9498-a44e3d243fac/7.png",
        site: {
            left: 47,
            top: 46.5,
            height: 112,
            width: 91,
            zIndex: 4,
            config: {
                type: 2
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/ddbefeea-3546-41b4-9498-a44e3d243fac/8.png",
        site: {
            left: 73,
            top: 65,
            height: 87,
            width: 93,
            zIndex: 4,
            config: {
                type: 2
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/ddbefeea-3546-41b4-9498-a44e3d243fac/9.png",
        site: {
            left: 73,
            top: 65,
            height: 87,
            width: 93,
            zIndex: 4,
            config: {
                type: 2
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/c72affab-0fd5-4ecd-a447-069ca98d85a9/10.png",
        site: {
            left: 73,
            top: 65,
            height: 87,
            width: 93,
            zIndex: 4,
            config: {
                type: 2
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/c72affab-0fd5-4ecd-a447-069ca98d85a9/11.png",
        site: {
            left: 27,
            top: 65,
            height: 112,
            width: 97,
            zIndex: 4,
            config: {
                type: 2
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/c72affab-0fd5-4ecd-a447-069ca98d85a9/12.png",
        site: {
            left: 50,
            top: 50,
            height: 128,
            width: 128,
            zIndex: 4,
            config: {
                type: 2
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/ddbefeea-3546-41b4-9498-a44e3d243fac/13.png",
        site: {
            left: 47,
            top: 65,
            height: 128,
            width: 128,
            zIndex: 4,
            config: {
                type: 2
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/ddbefeea-3546-41b4-9498-a44e3d243fac/14.png",
        site: {
            left: 73,
            top: 65,
            height: 128,
            width: 128,
            zIndex: 4,
            config: {
                type: 2
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/ddbefeea-3546-41b4-9498-a44e3d243fac/15.png",
        site: {
            left: 50,
            top: 50,
            height: 128,
            width: 128,
            zIndex: 4,
            config: {
                type: 2
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/c72affab-0fd5-4ecd-a447-069ca98d85a9/16.png",
        site: {
            left: 47,
            top: 46.5,
            height: 83,
            width: 78,
            zIndex: 4,
            config: {
                type: 2
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/c72affab-0fd5-4ecd-a447-069ca98d85a9/17.png",
        site: {
            left: 47,
            top: 65,
            height: 95,
            width: 107,
            zIndex: 4,
            config: {
                type: 2
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/c72affab-0fd5-4ecd-a447-069ca98d85a9/18.png",
        site: {
            left: 27,
            top: 65,
            height: 94,
            width: 103,
            zIndex: 4,
            config: {
                type: 2
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/ddbefeea-3546-41b4-9498-a44e3d243fac/19.png",
        site: {
            left: 50,
            top: 50,
            height: 127,
            width: 106,
            zIndex: 4,
            config: {
                type: 2
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/ddbefeea-3546-41b4-9498-a44e3d243fac/20.png",
        site: {
            left: 47,
            top: 46.5,
            zIndex: 4,
            height: 97,
            width: 85,
            config: {
                type: 2
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/ddbefeea-3546-41b4-9498-a44e3d243fac/21.png",
        site: {
            left: 47,
            top: 65,
            height: 100,
            width: 77,
            zIndex: 4,
            config: {
                type: 2
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/ddbefeea-3546-41b4-9498-a44e3d243fac/22.png",
        site: {
            left: 27,
            top: 65,
            height: 86,
            width: 79,
            zIndex: 4,
            config: {
                type: 2
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/ddbefeea-3546-41b4-9498-a44e3d243fac/23.png",
        site: {
            left: 73,
            top: 65,
            height: 96,
            width: 89,
            zIndex: 4,
            config: {
                type: 2
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/ddbefeea-3546-41b4-9498-a44e3d243fac/24.png",
        site: {
            left: 50,
            top: 50,
            height: 70,
            width: 103,
            zIndex: 4,
            config: {
                type: 2
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/ddbefeea-3546-41b4-9498-a44e3d243fac/25.png",
        site: {
            left: 47,
            top: 46.5,
            height: 70,
            width: 122,
            zIndex: 4,
            config: {
                type: 2
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/ddbefeea-3546-41b4-9498-a44e3d243fac/26.png",
        site: {
            left: 27,
            top: 65,
            height: 66,
            width: 112,
            zIndex: 4,
            config: {
                type: 2
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/ddbefeea-3546-41b4-9498-a44e3d243fac/27.png",
        site: {
            left: 73,
            top: 65,
            zIndex: 4,
            height: 103,
            width: 134,
            config: {
                type: 2
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/c72affab-0fd5-4ecd-a447-069ca98d85a9/28.png",
        site: {
            left: 50,
            top: 50,
            height: 93,
            width: 106,
            zIndex: 4,
            config: {
                type: 2
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/ddbefeea-3546-41b4-9498-a44e3d243fac/29.png",
        site: {
            left: 47,
            top: 65,
            height: 83,
            width: 115,
            zIndex: 4,
            config: {
                type: 2
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/ddbefeea-3546-41b4-9498-a44e3d243fac/30.png",
        site: {
            left: 27,
            top: 65,
            height: 71,
            width: 101,
            zIndex: 4,
            config: {
                type: 2
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/ddbefeea-3546-41b4-9498-a44e3d243fac/31.png",
        site: {
            left: 73,
            top: 65,
            height: 57,
            width: 95,
            zIndex: 4,
            config: {
                type: 2
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/ddbefeea-3546-41b4-9498-a44e3d243fac/32.png",
        site: {
            left: 73,
            top: 65,
            height: 57,
            width: 95,
            zIndex: 4,
            config: {
                type: 2
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/ddbefeea-3546-41b4-9498-a44e3d243fac/33.png",
        site: {
            left: 73,
            top: 65,
            height: 57,
            width: 95,
            zIndex: 4,
            config: {
                type: 2
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/ddbefeea-3546-41b4-9498-a44e3d243fac/34.png",
        site: {
            left: 73,
            top: 65,
            height: 57,
            width: 95,
            zIndex: 4,
            config: {
                type: 2
            }
        }
    } ]
};