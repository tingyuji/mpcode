module.exports = {
    eyebrow: [ {
        url: "https://res.wx.qq.com/t/fed_upload/d4dd8fe5-8050-4c09-ab28-38dac7386b73/1.png",
        site: {
            left: 47,
            top: 65,
            height: 40,
            width: 108,
            zIndex: 2,
            config: {
                type: 6
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/d4dd8fe5-8050-4c09-ab28-38dac7386b73/2.png",
        site: {
            left: 50,
            top: 50,
            height: 27,
            width: 102,
            zIndex: 2,
            config: {
                type: 6
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/d4dd8fe5-8050-4c09-ab28-38dac7386b73/3.png",
        site: {
            left: 47,
            top: 46.5,
            height: 38,
            width: 106,
            zIndex: 2,
            config: {
                type: 6
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/d4dd8fe5-8050-4c09-ab28-38dac7386b73/4.png",
        site: {
            left: 47,
            top: 65,
            height: 44,
            width: 102,
            zIndex: 2,
            config: {
                type: 6
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/d4dd8fe5-8050-4c09-ab28-38dac7386b73/5.png",
        site: {
            left: 27,
            top: 65,
            height: 36,
            width: 114,
            zIndex: 2,
            config: {
                type: 6
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/d4dd8fe5-8050-4c09-ab28-38dac7386b73/6.png",
        site: {
            left: 73,
            top: 65,
            height: 49,
            width: 119,
            zIndex: 2,
            config: {
                type: 6
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/d4dd8fe5-8050-4c09-ab28-38dac7386b73/7.png",
        site: {
            left: 50,
            top: 50,
            height: 26,
            width: 106,
            zIndex: 2,
            config: {
                type: 6
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/d4dd8fe5-8050-4c09-ab28-38dac7386b73/8.png",
        site: {
            left: 47,
            top: 46.5,
            zIndex: 2,
            height: 40,
            width: 132,
            config: {
                type: 6
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/d4dd8fe5-8050-4c09-ab28-38dac7386b73/9.png",
        site: {
            left: 47,
            top: 65,
            height: 33,
            width: 123,
            zIndex: 2,
            config: {
                type: 6
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/d4dd8fe5-8050-4c09-ab28-38dac7386b73/10.png",
        site: {
            left: 27,
            top: 65,
            height: 15,
            width: 84,
            zIndex: 2,
            config: {
                type: 6
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/d4dd8fe5-8050-4c09-ab28-38dac7386b73/11.png",
        site: {
            left: 73,
            top: 65,
            height: 47,
            width: 122,
            zIndex: 2,
            config: {
                type: 6
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/d4dd8fe5-8050-4c09-ab28-38dac7386b73/12.png",
        site: {
            left: 50,
            top: 50,
            height: 24,
            width: 130,
            zIndex: 2,
            config: {
                type: 6
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/d4dd8fe5-8050-4c09-ab28-38dac7386b73/13.png",
        site: {
            left: 47,
            top: 46.5,
            height: 28,
            width: 109,
            zIndex: 2,
            config: {
                type: 6
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/d4dd8fe5-8050-4c09-ab28-38dac7386b73/14.png",
        site: {
            left: 47,
            top: 65,
            height: 18,
            width: 84,
            zIndex: 2,
            config: {
                type: 6
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/d4dd8fe5-8050-4c09-ab28-38dac7386b73/15.png",
        site: {
            left: 27,
            top: 65,
            height: 35,
            width: 109,
            zIndex: 2,
            config: {
                type: 6
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/d4dd8fe5-8050-4c09-ab28-38dac7386b73/16.png",
        site: {
            left: 50,
            top: 50,
            height: 27,
            width: 101,
            zIndex: 2,
            config: {
                type: 6
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/d4dd8fe5-8050-4c09-ab28-38dac7386b73/17.png",
        site: {
            left: 47,
            top: 46.5,
            height: 26,
            width: 112,
            zIndex: 2,
            config: {
                type: 6
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/d4dd8fe5-8050-4c09-ab28-38dac7386b73/18.png",
        site: {
            left: 47,
            top: 65,
            height: 20,
            width: 106,
            zIndex: 2,
            config: {
                type: 6
            }
        }
    } ]
};