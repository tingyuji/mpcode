module.exports = {
    ORIGVERSION: 1
};