module.exports = {
    acc: [ {
        url: "https://res.wx.qq.com/t/fed_upload/fa8de415-6928-426c-bd3e-9cadc2953f35/53.png",
        site: {
            left: 50,
            top: 50,
            height: 50,
            width: 60,
            zIndex: 5,
            config: {
                type: 5
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/adef75c1-4d22-4d46-8248-ea7c1118b574/35.png",
        site: {
            left: 50,
            top: 50,
            height: 128,
            width: 128,
            zIndex: 5,
            config: {
                type: 5
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/adef75c1-4d22-4d46-8248-ea7c1118b574/31.png",
        site: {
            left: 47,
            top: 46.5,
            height: 128,
            width: 128,
            zIndex: 5,
            config: {
                type: 5
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/adef75c1-4d22-4d46-8248-ea7c1118b574/33.png",
        site: {
            left: 27,
            top: 65,
            height: 128,
            width: 128,
            zIndex: 5,
            config: {
                type: 5
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/adef75c1-4d22-4d46-8248-ea7c1118b574/11.png",
        site: {
            left: 50,
            top: 50,
            height: 73,
            width: 82,
            zIndex: 5,
            config: {
                type: 5
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/adef75c1-4d22-4d46-8248-ea7c1118b574/1.png",
        site: {
            left: 50,
            top: 50,
            height: 50,
            width: 60,
            zIndex: 5,
            config: {
                type: 5
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/adef75c1-4d22-4d46-8248-ea7c1118b574/2.png",
        site: {
            left: 47,
            top: 46.5,
            height: 60,
            width: 60,
            zIndex: 5,
            config: {
                type: 5
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/adef75c1-4d22-4d46-8248-ea7c1118b574/3.png",
        site: {
            left: 47,
            top: 65,
            height: 54,
            width: 189,
            zIndex: 5,
            config: {
                type: 5
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/adef75c1-4d22-4d46-8248-ea7c1118b574/4.png",
        site: {
            left: 27,
            top: 65,
            height: 47,
            width: 184,
            zIndex: 5,
            config: {
                type: 5
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/adef75c1-4d22-4d46-8248-ea7c1118b574/5.png",
        site: {
            left: 73,
            top: 65,
            height: 53,
            width: 128,
            zIndex: 5,
            config: {
                type: 5
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/adef75c1-4d22-4d46-8248-ea7c1118b574/6.png",
        site: {
            left: 50,
            top: 50,
            height: 96,
            width: 146,
            zIndex: 5,
            config: {
                type: 5
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/adef75c1-4d22-4d46-8248-ea7c1118b574/7.png",
        site: {
            left: 47,
            top: 46.5,
            height: 51,
            width: 172,
            zIndex: 5,
            config: {
                type: 5
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/adef75c1-4d22-4d46-8248-ea7c1118b574/8.png",
        site: {
            left: 47,
            top: 65,
            height: 119,
            width: 144,
            zIndex: 5,
            config: {
                type: 5
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/adef75c1-4d22-4d46-8248-ea7c1118b574/9.png",
        site: {
            left: 27,
            top: 65,
            height: 141,
            width: 106,
            zIndex: 5,
            config: {
                type: 5
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/adef75c1-4d22-4d46-8248-ea7c1118b574/10.png",
        site: {
            left: 73,
            top: 65,
            height: 96,
            width: 82,
            zIndex: 5,
            config: {
                type: 5
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/adef75c1-4d22-4d46-8248-ea7c1118b574/12.png",
        site: {
            left: 47,
            top: 46.5,
            height: 60,
            width: 61,
            zIndex: 5,
            config: {
                type: 5
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/adef75c1-4d22-4d46-8248-ea7c1118b574/13.png",
        site: {
            left: 47,
            top: 65,
            height: 71,
            width: 71,
            zIndex: 5,
            config: {
                type: 5
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/adef75c1-4d22-4d46-8248-ea7c1118b574/14.png",
        site: {
            left: 27,
            top: 65,
            height: 76,
            width: 123,
            zIndex: 5,
            config: {
                type: 5
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/adef75c1-4d22-4d46-8248-ea7c1118b574/16.png",
        site: {
            left: 50,
            top: 50,
            height: 128,
            width: 128,
            zIndex: 5,
            config: {
                type: 5
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/adef75c1-4d22-4d46-8248-ea7c1118b574/18.png",
        site: {
            left: 47,
            top: 65,
            height: 115,
            width: 188,
            zIndex: 5,
            config: {
                type: 5
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/adef75c1-4d22-4d46-8248-ea7c1118b574/19.png",
        site: {
            left: 27,
            top: 65,
            height: 80,
            width: 175,
            zIndex: 5,
            config: {
                type: 5
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/adef75c1-4d22-4d46-8248-ea7c1118b574/21.png",
        site: {
            left: 50,
            top: 50,
            height: 94,
            width: 108,
            zIndex: 5,
            config: {
                type: 5
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/adef75c1-4d22-4d46-8248-ea7c1118b574/23.png",
        site: {
            left: 47,
            top: 65,
            height: 72,
            width: 72,
            zIndex: 5,
            config: {
                type: 5
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/adef75c1-4d22-4d46-8248-ea7c1118b574/24.png",
        site: {
            left: 27,
            top: 65,
            height: 42,
            width: 33,
            zIndex: 5,
            config: {
                type: 5
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/adef75c1-4d22-4d46-8248-ea7c1118b574/25.png",
        site: {
            left: 73,
            top: 65,
            height: 72,
            width: 72,
            zIndex: 5,
            config: {
                type: 5
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/adef75c1-4d22-4d46-8248-ea7c1118b574/27.png",
        site: {
            left: 47,
            top: 46.5,
            height: 46,
            width: 160,
            zIndex: 5,
            config: {
                type: 5
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/adef75c1-4d22-4d46-8248-ea7c1118b574/28.png",
        site: {
            left: 47,
            top: 65,
            height: 52,
            width: 85,
            zIndex: 5,
            config: {
                type: 5
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/adef75c1-4d22-4d46-8248-ea7c1118b574/29.png",
        site: {
            left: 27,
            top: 65,
            height: 59,
            width: 65,
            zIndex: 5,
            config: {
                type: 5
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/adef75c1-4d22-4d46-8248-ea7c1118b574/30.png",
        site: {
            left: 50,
            top: 50,
            height: 16,
            width: 20,
            zIndex: 5,
            config: {
                type: 5
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/adef75c1-4d22-4d46-8248-ea7c1118b574/32.png",
        site: {
            left: 47,
            top: 65,
            height: 128,
            width: 128,
            zIndex: 5,
            config: {
                type: 5
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/adef75c1-4d22-4d46-8248-ea7c1118b574/34.png",
        site: {
            left: 73,
            top: 65,
            zIndex: 5,
            height: 128,
            width: 128,
            config: {
                type: 5
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/adef75c1-4d22-4d46-8248-ea7c1118b574/36.png",
        site: {
            left: 47,
            top: 46.5,
            height: 128,
            width: 128,
            zIndex: 5,
            config: {
                type: 5
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/adef75c1-4d22-4d46-8248-ea7c1118b574/37.png",
        site: {
            left: 47,
            top: 65,
            height: 128,
            width: 128,
            zIndex: 5,
            config: {
                type: 5
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/adef75c1-4d22-4d46-8248-ea7c1118b574/38.png",
        site: {
            left: 27,
            top: 65,
            height: 128,
            width: 128,
            zIndex: 5,
            config: {
                type: 5
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/adef75c1-4d22-4d46-8248-ea7c1118b574/39.png",
        site: {
            left: 73,
            top: 65,
            height: 128,
            width: 128,
            zIndex: 5,
            config: {
                type: 5
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/adef75c1-4d22-4d46-8248-ea7c1118b574/40.png",
        site: {
            left: 50,
            top: 50,
            height: 128,
            width: 128,
            zIndex: 5,
            config: {
                type: 5
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/adef75c1-4d22-4d46-8248-ea7c1118b574/41.png",
        site: {
            left: 47,
            top: 46.5,
            height: 128,
            width: 128,
            zIndex: 5,
            config: {
                type: 5
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/adef75c1-4d22-4d46-8248-ea7c1118b574/42.png",
        site: {
            left: 47,
            top: 65,
            height: 128,
            width: 128,
            zIndex: 5,
            config: {
                type: 5
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/adef75c1-4d22-4d46-8248-ea7c1118b574/43.png",
        site: {
            left: 27,
            top: 65,
            height: 128,
            width: 128,
            zIndex: 5,
            config: {
                type: 5
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/adef75c1-4d22-4d46-8248-ea7c1118b574/44.png",
        site: {
            left: 50,
            top: 50,
            height: 128,
            width: 128,
            zIndex: 5,
            config: {
                type: 5
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/adef75c1-4d22-4d46-8248-ea7c1118b574/45.png",
        site: {
            left: 47,
            top: 46.5,
            height: 128,
            width: 128,
            zIndex: 5,
            config: {
                type: 5
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/adef75c1-4d22-4d46-8248-ea7c1118b574/46.png",
        site: {
            left: 47,
            top: 65,
            height: 128,
            width: 128,
            zIndex: 5,
            config: {
                type: 5
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/adef75c1-4d22-4d46-8248-ea7c1118b574/47.png",
        site: {
            left: 73,
            top: 65,
            height: 128,
            width: 128,
            zIndex: 5,
            config: {
                type: 5
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/adef75c1-4d22-4d46-8248-ea7c1118b574/48.png",
        site: {
            left: 50,
            top: 50,
            height: 64,
            width: 174,
            zIndex: 5,
            config: {
                type: 5
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/adef75c1-4d22-4d46-8248-ea7c1118b574/49.png",
        site: {
            left: 47,
            top: 46.5,
            height: 86,
            width: 170,
            zIndex: 5,
            config: {
                type: 5
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/adef75c1-4d22-4d46-8248-ea7c1118b574/50.png",
        site: {
            left: 47,
            top: 65,
            height: 67,
            width: 171,
            zIndex: 5,
            config: {
                type: 5
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/adef75c1-4d22-4d46-8248-ea7c1118b574/51.png",
        site: {
            left: 47,
            top: 65,
            height: 92,
            width: 173,
            zIndex: 5,
            config: {
                type: 5
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/adef75c1-4d22-4d46-8248-ea7c1118b574/52.png",
        site: {
            left: 73,
            top: 65,
            height: 33,
            width: 162,
            zIndex: 5,
            config: {
                type: 5
            }
        }
    } ]
};