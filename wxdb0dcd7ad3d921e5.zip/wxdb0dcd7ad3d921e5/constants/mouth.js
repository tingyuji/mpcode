module.exports = {
    mouth: [ {
        url: "https://res.wx.qq.com/t/fed_upload/16516bb6-9169-4036-8951-5a573bacaef7/1.png",
        site: {
            left: 50,
            top: 50,
            height: 60,
            width: 117,
            zIndex: 3,
            config: {
                type: 4
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/16516bb6-9169-4036-8951-5a573bacaef7/2.png",
        site: {
            left: 47,
            top: 46.5,
            height: 60,
            width: 121,
            zIndex: 3,
            config: {
                type: 4
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/16516bb6-9169-4036-8951-5a573bacaef7/3.png",
        site: {
            left: 47,
            top: 65,
            height: 64,
            width: 99,
            zIndex: 3,
            config: {
                type: 4
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/16516bb6-9169-4036-8951-5a573bacaef7/4.png",
        site: {
            left: 27,
            top: 65,
            height: 77,
            width: 121,
            zIndex: 3,
            config: {
                type: 4
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/16516bb6-9169-4036-8951-5a573bacaef7/5.png",
        site: {
            left: 73,
            top: 65,
            height: 52,
            width: 97,
            zIndex: 3,
            config: {
                type: 4
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/16516bb6-9169-4036-8951-5a573bacaef7/6.png",
        site: {
            left: 50,
            top: 50,
            height: 81,
            width: 137,
            zIndex: 3,
            config: {
                type: 4
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/16516bb6-9169-4036-8951-5a573bacaef7/7.png",
        site: {
            left: 47,
            top: 46.5,
            height: 82,
            width: 74,
            zIndex: 3,
            config: {
                type: 4
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/16516bb6-9169-4036-8951-5a573bacaef7/8.png",
        site: {
            left: 47,
            top: 65,
            height: 47,
            width: 88,
            zIndex: 3,
            config: {
                type: 4
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/16516bb6-9169-4036-8951-5a573bacaef7/9.png",
        site: {
            left: 27,
            top: 65,
            height: 128,
            width: 128,
            zIndex: 3,
            config: {
                type: 4
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/16516bb6-9169-4036-8951-5a573bacaef7/10.png",
        site: {
            left: 73,
            top: 65,
            height: 73,
            width: 73,
            zIndex: 3,
            config: {
                type: 4
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/16516bb6-9169-4036-8951-5a573bacaef7/11.png",
        site: {
            left: 50,
            top: 50,
            height: 44,
            width: 115,
            zIndex: 3,
            config: {
                type: 4
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/16516bb6-9169-4036-8951-5a573bacaef7/12.png",
        site: {
            left: 47,
            top: 46.5,
            height: 66,
            width: 132,
            zIndex: 3,
            config: {
                type: 4
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/16516bb6-9169-4036-8951-5a573bacaef7/13.png",
        site: {
            left: 47,
            top: 65,
            height: 69,
            width: 127,
            zIndex: 3,
            config: {
                type: 4
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/46d96e24-653c-49d6-b2b3-ea4d10640f3d/14.png",
        site: {
            left: 27,
            top: 65,
            height: 60,
            width: 33,
            zIndex: 3,
            config: {
                type: 4
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/46d96e24-653c-49d6-b2b3-ea4d10640f3d/15.png",
        site: {
            left: 50,
            top: 50,
            height: 43,
            width: 60,
            zIndex: 3,
            config: {
                type: 4
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/16516bb6-9169-4036-8951-5a573bacaef7/16.png",
        site: {
            left: 47,
            top: 46.5,
            height: 26,
            width: 36,
            zIndex: 3,
            config: {
                type: 4
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/46d96e24-653c-49d6-b2b3-ea4d10640f3d/17.png",
        site: {
            left: 47,
            top: 65,
            height: 63,
            width: 42,
            zIndex: 3,
            config: {
                type: 4
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/46d96e24-653c-49d6-b2b3-ea4d10640f3d/18.png",
        site: {
            left: 27,
            top: 65,
            height: 48,
            width: 98,
            zIndex: 3,
            config: {
                type: 4
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/46d96e24-653c-49d6-b2b3-ea4d10640f3d/19.png",
        site: {
            left: 73,
            top: 65,
            height: 19,
            width: 52,
            zIndex: 3,
            config: {
                type: 4
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/16516bb6-9169-4036-8951-5a573bacaef7/20.png",
        site: {
            left: 50,
            top: 50,
            height: 18,
            width: 98,
            zIndex: 3,
            config: {
                type: 4
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/16516bb6-9169-4036-8951-5a573bacaef7/21.png",
        site: {
            left: 47,
            top: 46.5,
            height: 27,
            width: 103,
            zIndex: 3,
            config: {
                type: 4
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/16516bb6-9169-4036-8951-5a573bacaef7/22.png",
        site: {
            left: 47,
            top: 65,
            height: 39,
            width: 10,
            zIndex: 3,
            config: {
                type: 4
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/16516bb6-9169-4036-8951-5a573bacaef7/23.png",
        site: {
            left: 27,
            top: 65,
            height: 54,
            width: 91,
            zIndex: 3,
            config: {
                type: 4
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/16516bb6-9169-4036-8951-5a573bacaef7/24.png",
        site: {
            left: 73,
            top: 65,
            height: 38,
            width: 96,
            zIndex: 3,
            config: {
                type: 4
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/16516bb6-9169-4036-8951-5a573bacaef7/25.png",
        site: {
            left: 50,
            top: 50,
            height: 30,
            width: 44,
            zIndex: 3,
            config: {
                type: 4
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/46d96e24-653c-49d6-b2b3-ea4d10640f3d/26.png",
        site: {
            left: 47,
            top: 46.5,
            height: 71,
            width: 33,
            zIndex: 3,
            config: {
                type: 4
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/16516bb6-9169-4036-8951-5a573bacaef7/27.png",
        site: {
            left: 47,
            top: 65,
            height: 22,
            width: 34,
            zIndex: 3,
            config: {
                type: 4
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/46d96e24-653c-49d6-b2b3-ea4d10640f3d/28.png",
        site: {
            left: 27,
            top: 65,
            height: 21,
            width: 32,
            zIndex: 3,
            config: {
                type: 4
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/46d96e24-653c-49d6-b2b3-ea4d10640f3d/29.png",
        site: {
            left: 50,
            top: 50,
            height: 29,
            width: 42,
            zIndex: 3,
            config: {
                type: 4
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/16516bb6-9169-4036-8951-5a573bacaef7/30.png",
        site: {
            left: 47,
            top: 46.5,
            height: 31,
            width: 71,
            zIndex: 3,
            config: {
                type: 4
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/16516bb6-9169-4036-8951-5a573bacaef7/31.png",
        site: {
            left: 47,
            top: 65,
            height: 26,
            width: 59,
            zIndex: 3,
            config: {
                type: 4
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/46d96e24-653c-49d6-b2b3-ea4d10640f3d/32.png",
        site: {
            left: 27,
            top: 65,
            height: 14,
            width: 35,
            zIndex: 3,
            config: {
                type: 4
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/16516bb6-9169-4036-8951-5a573bacaef7/33.png",
        site: {
            left: 73,
            top: 65,
            height: 24,
            width: 52,
            zIndex: 3,
            config: {
                type: 4
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/16516bb6-9169-4036-8951-5a573bacaef7/34.png",
        site: {
            left: 50,
            top: 50,
            height: 30,
            width: 94,
            zIndex: 3,
            config: {
                type: 4
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/16516bb6-9169-4036-8951-5a573bacaef7/35.png",
        site: {
            left: 47,
            top: 46.5,
            height: 44,
            width: 109,
            zIndex: 3,
            config: {
                type: 4
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/16516bb6-9169-4036-8951-5a573bacaef7/36.png",
        site: {
            left: 47,
            top: 65,
            height: 31,
            width: 53,
            zIndex: 3,
            config: {
                type: 4
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/16516bb6-9169-4036-8951-5a573bacaef7/37.png",
        site: {
            left: 27,
            top: 65,
            height: 15,
            width: 47,
            zIndex: 3,
            config: {
                type: 4
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/16516bb6-9169-4036-8951-5a573bacaef7/38.png",
        site: {
            left: 73,
            top: 65,
            height: 19,
            width: 44,
            zIndex: 3,
            config: {
                type: 4
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/16516bb6-9169-4036-8951-5a573bacaef7/39.png",
        site: {
            left: 50,
            top: 50,
            height: 10,
            width: 39,
            zIndex: 3,
            config: {
                type: 4
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/16516bb6-9169-4036-8951-5a573bacaef7/40.png",
        site: {
            left: 47,
            top: 46.5,
            height: 31,
            width: 120,
            zIndex: 3,
            config: {
                type: 4
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/16516bb6-9169-4036-8951-5a573bacaef7/41.png",
        site: {
            left: 47,
            top: 65,
            height: 16,
            width: 71,
            zIndex: 3,
            config: {
                type: 4
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/16516bb6-9169-4036-8951-5a573bacaef7/42.png",
        site: {
            left: 27,
            top: 65,
            height: 10,
            width: 42,
            zIndex: 3,
            config: {
                type: 4
            }
        }
    }, {
        url: "https://res.wx.qq.com/t/fed_upload/16516bb6-9169-4036-8951-5a573bacaef7/43.png",
        site: {
            left: 27,
            top: 65,
            height: 10,
            width: 42,
            zIndex: 3,
            config: {
                type: 4
            }
        }
    } ]
};