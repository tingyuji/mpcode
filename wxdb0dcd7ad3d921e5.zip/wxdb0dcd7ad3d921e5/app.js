require("@babel/runtime/helpers/Arrayincludes");

var t = require("@tencent/merlin-core"), e = n(require("@tencent/merlin-behavior")), a = n(require("./report/transports"));

require("lifeCycle.js");

var i = require("./report/cube");

function n(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

e.default.init({
    adapter: "miniprogram",
    transports: [ new t.ConsoleTransport(), new a.default() ],
    collectors: []
}), App({
    onLaunch: function(t) {
        wx.onAppHide(function() {
            e.default.settle();
        });
        1001 === wx.getLaunchOptionsSync().scene ? e.default.reportElementExpose({
            key: "program_list"
        }) : [ 1005, 1006 ].includes(wx.getLaunchOptionsSync().scene) && e.default.reportElementExpose({
            key: "user_search"
        });
        var a = wx.getSystemInfoSync(), i = wx.getMenuButtonBoundingClientRect();
        this.globalData.navBarHeight = a.statusBarHeight + 44, this.globalData.menuRight = a.screenWidth - i.right, 
        this.globalData.menuTop = i.top, this.globalData.menuHeight = i.height, this.globalData.windowHeight = a.windowHeight, 
        this.globalData.windowWidth = a.windowWidth, this.globalData.canvasHeight = "100vw", 
        this.globalData.canvasWidth = "100%", this.globalData.isSmallScreen = !1, this.globalData.windowHeight < 800 && (console.log("small screen"), 
        this.globalData.canvasHeight = "80vw", this.globalData.canvasWidth = "80%", this.globalData.isSmallScreen = !0), 
        (a.model.indexOf("iPad") > -1 || this.globalData.windowWidth >= 560 && this.globalData.windowHeight > 800) && (this.globalData.canvasHeight = "60vw", 
        this.globalData.canvasWidth = "60%", this.globalData.isSmallScreen = !0, this.globalData.isPad = !0);
    },
    onError: function(t) {
        (0, i.cubeError)(t);
    },
    onUnhandledRejection: function(t) {
        (0, i.cubeError)(t.reason.message + t.reason.stack);
    },
    globalData: {
        navBarHeight: 0,
        menuRight: 0,
        menuTop: 0,
        menuHeight: 0,
        windowHeight: 0,
        windowWidth: 0,
        showBackToast: !0,
        context: "",
        hotContext: "",
        sessionstack: [],
        pauseRequest: !1
    }
});