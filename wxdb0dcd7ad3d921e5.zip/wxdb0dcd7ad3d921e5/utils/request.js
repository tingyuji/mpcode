Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.requestReportPyq = exports.request = exports.getMixEmoji = exports.getHotMixEmoji = void 0;

var e, t = require("./utils"), n = (e = require("@tencent/merlin-behavior")) && e.__esModule ? e : {
    default: e
};

var o = require("../constants/api").BASE_URL, i = (getApp(), !1), a = null;

wx.onNetworkStatusChange(function(e) {
    [ "none", "unknown" ].indexOf(e.networkType) > -1 ? n.default.enableBuffering() : n.default.settleBuffering();
});

exports.request = function(e) {
    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, o = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "GET", i = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : "axios";
    return r().then(function(a) {
        return wx.getNetworkType({
            success: function(e) {
                "none" === e.networkType && (wx.showToast({
                    title: "网络异常，请检查网络",
                    icon: "none",
                    duration: 2e3
                }), n.default.reportElementClick({
                    key: "request_error",
                    extInfo: {
                        msg: "no network"
                    }
                }));
            }
        }), "GET" === o ? Object.assign(t, {
            openid: encodeURIComponent(null == a ? void 0 : a.openid),
            sessionId: encodeURIComponent(null == a ? void 0 : a.sessionId)
        }) : Object.assign(t, {
            baseRequest: Object.assign(a)
        }), "file" === i ? d(e, t) : s(e, t, o);
    });
};

var r = function() {
    return new Promise(function(e) {
        wx.checkSession({
            success: function(t) {
                l().then(function(t) {
                    e(t);
                });
            },
            fail: function(t) {
                l(!0).then(function(t) {
                    e(t);
                });
            }
        });
    });
}, l = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
    return new Promise(function(n) {
        var o = getApp();
        if (i) return a = setInterval(function() {
            i || n(o.globalData.baseRequest);
        }, 100), void setTimeout(function() {
            clearInterval(a);
        }, 5e3);
        o && o.globalData.baseRequest && !e ? n(o.globalData.baseRequest) : (i = !0, wx.login({
            success: function(e) {
                s("/auth/getOpenId", {
                    code: e.code
                }, "POST").then(function(e) {
                    var a, r, l;
                    (e.data.error && wx.showModal({
                        title: "网络异常，请重试"
                    }), o) && (o.globalData.baseRequest = (0, t.omit)(e.data.data, [ "uin" ]), o.globalData.uin = null !== (a = null === (r = e.data) || void 0 === r || null === (l = r.data) || void 0 === l ? void 0 : l.uin) && void 0 !== a ? a : 0);
                    i = !1, n(e.data.data);
                });
            },
            fail: function() {
                i = !1;
            }
        }));
    });
}, u = function() {
    wx.setStorageSync("isBlack", !0), getApp().globalData.isBlock = !0;
    var e = wx.getFileSystemManager(), t = "".concat(wx.env.USER_DATA_PATH, "/emojiFaceList.json");
    e.writeFileSync(t, "", "utf8"), wx.showModal({
        title: "网络异常，请重试"
    });
}, s = function(e) {
    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, i = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "GET", a = arguments.length > 3 && void 0 !== arguments[3] && arguments[3];
    return new Promise(function(r, l) {
        wx.request({
            url: o + e,
            data: t,
            timeout: 6e3,
            method: i,
            success: function(e) {
                var t, o, i, l;
                -100005 === (null == e || null === (t = e.data) || void 0 === t || null === (o = t.data) || void 0 === o ? void 0 : o.ret) && (u(), 
                r(null)), (e.data.error && !a || 403 === (null === (i = e.data) || void 0 === i || null === (l = i.error) || void 0 === l ? void 0 : l.status)) && n.default.reportElementClick({
                    key: "request_error",
                    extInfo: {
                        msg: e.data.error.message
                    }
                }), r(e);
            },
            fail: function(e) {
                n.default.reportElementClick({
                    key: "request_error",
                    extInfo: {
                        msg: e
                    }
                }), l(e);
            }
        });
    });
}, d = function(e) {
    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
    return new Promise(function(i, a) {
        wx.uploadFile({
            url: "".concat(o).concat(e, "?openid=").concat(encodeURIComponent(t.baseRequest.openid), "&sessionId=").concat(encodeURIComponent(t.baseRequest.sessionId)),
            filePath: t.filePath,
            name: "image",
            timeout: 6e3,
            formData: t,
            success: function(e) {
                var t, o;
                -100005 === (null == e || null === (t = e.data) || void 0 === t || null === (o = t.data) || void 0 === o ? void 0 : o.ret) && (u(), 
                i(null)), e.data.error && n.default.reportElementClick({
                    key: "request_error",
                    extInfo: {
                        msg: e.data.error.message
                    }
                }), i(e);
            },
            fail: function(e) {
                wx.showModal({
                    title: "网络异常，请重试"
                }), n.default.reportElementClick({
                    key: "request_error",
                    extInfo: {
                        msg: e
                    }
                }), a(e);
            }
        });
    });
};

exports.getMixEmoji = function(e) {
    return new Promise(function(o, i) {
        var a = getApp();
        wx.login({
            success: function(n) {
                s("/auth/getOpenId", {
                    code: n.code,
                    withMixEmoji: !0,
                    context: e
                }, "POST").then(function(e) {
                    var n;
                    if (e) {
                        var i, r, l;
                        if (null != e && null !== (n = e.data) && void 0 !== n && n.error && wx.showModal({
                            title: "网络异常，请重试"
                        }), a) a.globalData.baseRequest = (0, t.omit)(e.data.data, [ "uin", "mixEmoji" ]), 
                        a.globalData.uin = null !== (i = null === (r = e.data) || void 0 === r || null === (l = r.data) || void 0 === l ? void 0 : l.uin) && void 0 !== i ? i : 0;
                        o(e.data.data);
                    }
                });
            },
            fail: function(e) {
                wx.showModal({
                    title: "网络异常，请重试"
                }), n.default.reportElementClick({
                    key: "request_error",
                    extInfo: {
                        msg: e
                    }
                }), i(e);
            }
        });
    });
};

exports.getHotMixEmoji = function(e) {
    return new Promise(function(o, i) {
        var a = getApp();
        wx.login({
            success: function(n) {
                s("/auth/getOpenId", {
                    code: n.code,
                    withHotMixEmoji: !0,
                    context: e
                }, "POST").then(function(e) {
                    var n;
                    if (e) {
                        var i, r, l;
                        if (null != e && null !== (n = e.data) && void 0 !== n && n.error && wx.showModal({
                            title: "网络异常，请重试"
                        }), a) a.globalData.baseRequest = (0, t.omit)(e.data.data, [ "uin", "mixEmoji" ]), 
                        a.globalData.uin = null !== (i = null === (r = e.data) || void 0 === r || null === (l = r.data) || void 0 === l ? void 0 : l.uin) && void 0 !== i ? i : 0;
                        o(e.data.data);
                    }
                });
            },
            fail: function(e) {
                wx.showModal({
                    title: "网络异常，请重试"
                }), n.default.reportElementClick({
                    key: "request_error",
                    extInfo: {
                        msg: e
                    }
                }), i(e);
            }
        });
    });
};

exports.requestReportPyq = function(e) {
    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, o = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "GET";
    return wx.getNetworkType({
        success: function(e) {
            "none" === e.networkType && (wx.showToast({
                title: "网络异常，请检查网络",
                icon: "none",
                duration: 2e3
            }), n.default.reportElementClick({
                key: "request_error",
                extInfo: {
                    msg: "no network"
                }
            }));
        }
    }), s(e, t, o);
};