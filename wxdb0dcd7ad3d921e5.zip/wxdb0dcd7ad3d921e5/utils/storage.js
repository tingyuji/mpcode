Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.clearAllFile = function() {
    var e = wx.getFileSystemManager(), t = "".concat(wx.env.USER_DATA_PATH, "/emojiFaceList.json");
    e.writeFileSync(t, "", "utf8");
}, exports.getEmojiStorage = function() {
    if (1154 === wx.getLaunchOptionsSync().scene || "mac" === wx.getSystemInfoSync().platform) return [];
    var t = wx.getFileSystemManager(), a = "".concat(wx.env.USER_DATA_PATH, "/emojiFaceList.json");
    try {
        if (e.globalData.emojiFaceList && e.globalData.emojiFaceList.length > 0) return e.globalData.emojiFaceList;
        var i = t.readFileSync(a, "utf8");
        return i ? JSON.parse(i) : [];
    } catch (e) {
        return [];
    }
}, exports.setEmojiStorage = function(t) {
    var a = wx.getFileSystemManager(), i = "".concat(wx.env.USER_DATA_PATH, "/emojiFaceList.json");
    if (e.globalData.emojiFaceList = t, "mac" === wx.getSystemInfoSync().platform) return;
    try {
        a.writeFileSync(i, "", "utf8"), a.writeFileSync(i, JSON.stringify(t), "utf8");
    } catch (e) {
        e.errMsg.indexOf("maximum size") > -1 && wx.showToast({
            title: "存储空间不足",
            icon: "none"
        });
    }
};

var e = getApp();