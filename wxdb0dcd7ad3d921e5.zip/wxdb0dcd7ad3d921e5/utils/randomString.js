Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = function(e) {
    e = e || 16;
    for (var t = "ABCDEFGHJKMNPQRSTWXYZabcdefhijkmnprstwxyz2345678", r = t.length, o = "", a = 0; a < e; a++) o += t.charAt(Math.floor(Math.random() * r));
    return o;
};

exports.default = e;