Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.omit = function(e, r) {
    var t = {};
    for (var o in e) -1 === r.indexOf(o) && (t[o] = e[o]);
    return t;
};