Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = function(e) {
    return Object.keys(e).reduce(function(t, c) {
        return t += "".concat(c, "=").concat(e[c], "&");
    }, "");
};