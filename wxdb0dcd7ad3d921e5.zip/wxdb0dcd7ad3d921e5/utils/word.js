Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = [ "自制微信表情，限时体验名额开启！", "终于可以自己做微信表情了，快来试试！", "微信狗头：我没惹你们任何一个人！", "微信表情的脑洞太大了，快来制作看看~", "找不到有趣的微信表情？自己来做一个！", "能否帮我做一个“哈哈哈哈哈”的微信表情？" ], d = [ "https://res.wx.qq.com/t/fed_upload/4ef3e318-a621-4d1e-bb84-b749c6d18656/1.jpg", "https://res.wx.qq.com/t/fed_upload/4ef3e318-a621-4d1e-bb84-b749c6d18656/2.jpg", "https://res.wx.qq.com/t/fed_upload/4ef3e318-a621-4d1e-bb84-b749c6d18656/3.jpg", "https://res.wx.qq.com/t/fed_upload/4ef3e318-a621-4d1e-bb84-b749c6d18656/4.jpg", "https://res.wx.qq.com/t/fed_upload/4ef3e318-a621-4d1e-bb84-b749c6d18656/5.jpg", "https://res.wx.qq.com/t/fed_upload/4ef3e318-a621-4d1e-bb84-b749c6d18656/6.jpg" ], t = function() {
    var t = Math.floor(6 * Math.random()) + 1;
    return {
        word: e[t - 1],
        image: d[t - 1]
    };
};

exports.default = t;