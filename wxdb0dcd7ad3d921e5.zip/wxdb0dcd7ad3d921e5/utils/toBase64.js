module.exports = function(e) {
    return new Promise(function(n, t) {
        wx.getFileSystemManager().readFile({
            filePath: e,
            encoding: "base64",
            success: function(e) {
                return n("data:image/png;base64,".concat(e.data));
            }
        });
    });
};