var e, t = (e = require("@tencent/merlin-behavior")) && e.__esModule ? e : {
    default: e
};

!function() {
    function e(e, t) {
        if (e[t]) {
            var n = e[t];
            e[t] = function(e) {
                if (a(this, t, e), "onShareAppMessage" == t) return n.call(this, e);
                n.call(this, e);
            };
        } else "onShareAppMessage" != t && (e[t] = function(e) {
            a(this, t);
        });
    }
    function a(e, a, n) {
        if ("onShow" == a) t.default.pushPage({
            name: e.pageName
        }); else if ("onLoad" == a) {
            var o = wx.getLaunchOptionsSync().scene;
            1008 != o && 1007 != o || getApp().globalData.fromTalking ? 1154 == o ? (getApp().globalData.pyqComing = !1, 
            t.default.pushPage({
                name: "enter_page"
            }), t.default.reportElementClick({
                key: "moment_front_page"
            }), t.default.settle()) : 1155 != o || getApp().globalData.pyqComing ? (t.default.pushPage({
                name: "enter_page"
            }), t.default.reportElementClick(Object.assign({
                key: o
            }, null != n && n.setkey ? {
                extInfo: {
                    if_share: 1
                }
            } : {}))) : (t.default.pushPage({
                name: "enter_page"
            }), t.default.reportElementClick({
                key: "moment"
            })) : (getApp().globalData.fromTalking = !0, t.default.pushPage({
                name: "enter_page"
            }), t.default.reportElementClick(Object.assign({
                key: "message"
            }, null != n && n.setkey ? {
                extInfo: {
                    if_share: 1
                }
            } : {}))), wx.getNetworkType({
                success: function(e) {
                    "none" === e.networkType && (wx.showToast({
                        title: "网络异常，请检查网络",
                        icon: "none",
                        duration: 2e3
                    }), t.default.reportElementClick({
                        key: "request_error",
                        extInfo: {
                            msg: "no network"
                        }
                    }));
                }
            }), n.setkey ? t.default.pushPage({
                name: e.pageName,
                extInfo: {
                    designer: n.setkey.split("_")[0]
                }
            }) : t.default.pushPage({
                name: e.pageName
            }), t.default.reportPageEnter();
        }
    }
    var n = Page;
    Page = function(t) {
        e(t, "onShow"), e(t, "onHide"), e(t, "onLoad"), e(t, "onReachBottom"), e(t, "onPullDownRefresh"), 
        e(t, "onShareAppMessage"), n(t);
    };
}();