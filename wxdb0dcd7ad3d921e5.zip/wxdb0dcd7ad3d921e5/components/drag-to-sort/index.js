Component({
    relations: {
        "../drag-item/index": {
            type: "child",
            linked: function(e) {
                this.child = this.child || [], this.child.push(e);
            },
            linkChanged: function(e) {},
            unlinked: function(e) {
                this.child = this.child || [], this.child.splice(this.child.indexOf(e), 1);
            }
        }
    },
    properties: {
        dragY: {
            type: Boolean,
            value: !1
        },
        dragX: {
            type: Boolean,
            value: !1
        },
        length: {
            type: Number,
            value: 0
        }
    },
    data: {
        allLoaded: !1
    },
    methods: {
        getScrollerRect: function() {
            var e = this.createSelectorQuery(), t = wx.createSelectorQuery();
            e.select(".drag-and-drop-list").boundingClientRect().exec(function(e) {}), t.select("#scroller").fields({
                size: !0,
                scrollOffset: !0,
                properties: [ "scrollX", "scrollY" ],
                context: !0
            }).exec(function(e) {});
        },
        noticeChildInited: function(e) {
            var t = this;
            this.child && this.posList && this.child.forEach(function(i) {
                (void 0 === e || void 0 !== e && i.data.idx == e) && i.updatePosDate(t.posList);
            });
        },
        log: function(e) {},
        allChildLinked: function(e) {
            var t = this, i = getCurrentPages();
            i[i.length - 1];
            setTimeout(function() {
                wx.createSelectorQuery().select("#scroller").scrollOffset().exec(function(e) {});
            }, 3e3);
            var n, l = 0, c = 0;
            e.forEach(function(e, t) {
                e.originalIndex = t, e.currentIndex = t, l += e.size.height, c += e.size.width;
            });
            var o = 0, s = 0;
            n = e.map(function(e, i) {
                return e.space = {
                    top: o,
                    right: c - s - e.size.width,
                    bottom: l - o - e.size.height,
                    left: s
                }, e.translate = {
                    x: 0,
                    y: 0
                }, t.data.dragY ? (e.space.left = null, e.space.right = null) : t.data.dragX && (e.space.top = null, 
                e.space.bottom = null), o += e.size.height, s += e.size.width, e;
            }), this.posList = n, this.noticeChildInited();
        },
        change: function(e) {
            this.triggerEvent("change", e);
        },
        posChange: function(e) {
            this.triggerEvent("poschange", e);
        },
        delete: function(e) {
            this.triggerEvent("delete", e);
        },
        onScroll: function(e) {
            this.triggerEvent("onscroll", e);
        }
    }
});