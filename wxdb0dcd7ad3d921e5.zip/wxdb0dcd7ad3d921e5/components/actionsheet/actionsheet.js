Component({
    options: {
        multipleSlots: !0,
        addGlobalClass: !0
    },
    properties: {
        title: {
            type: String,
            value: ""
        },
        showCancel: {
            type: Boolean,
            value: !0
        },
        cancelText: {
            type: String,
            value: "取消"
        },
        maskClass: {
            type: String,
            value: ""
        },
        extClass: {
            type: String,
            value: ""
        },
        maskClosable: {
            type: Boolean,
            value: !0
        },
        mask: {
            type: Boolean,
            value: !0
        },
        show: {
            type: Boolean,
            value: !1,
            observer: "_showChange"
        },
        actions: {
            type: Array,
            value: [],
            observer: "_groupChange"
        }
    },
    data: {
        wrapperShow: !1,
        innerShow: !1
    },
    lifetimes: {
        ready: function() {
            this._showChange(this.data.show);
        }
    },
    methods: {
        _showChange: function(t) {
            var e = this;
            t ? this.setData({
                wrapperShow: !0,
                innerShow: !0
            }) : (this.setData({
                innerShow: !1
            }), setTimeout(function() {
                e.setData({
                    wrapperShow: !1
                });
            }, 300));
        },
        _groupChange: function(t) {
            t.length > 0 && "string" != typeof t[0] && !(t[0] instanceof Array) && this.setData({
                actions: [ this.data.actions ]
            });
        },
        buttonTap: function(t) {
            var e = t.currentTarget.dataset, a = e.value, n = e.groupindex, o = e.index;
            this.triggerEvent("actiontap", {
                value: a,
                groupindex: n,
                index: o
            });
        },
        closeActionSheet: function(t) {
            var e = t.currentTarget.dataset.type;
            (this.data.maskClosable || e) && (this.setData({
                show: !1
            }), this.triggerEvent("close"));
        }
    }
});