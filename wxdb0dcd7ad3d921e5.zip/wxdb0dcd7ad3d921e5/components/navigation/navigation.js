var e, t = (e = require("@tencent/merlin-behavior")) && e.__esModule ? e : {
    default: e
};

var n = getApp();

Component({
    properties: {
        defaultData: {
            type: Object,
            value: {
                title: "我是默认标题"
            },
            observer: function(e, t) {}
        },
        nextActive: {
            type: Boolean,
            value: !1
        },
        prevActive: {
            type: Boolean,
            value: !1,
            observer: function(e, t) {}
        },
        prev: {
            type: Function,
            value: function() {}
        },
        next: {
            type: Function,
            value: function() {}
        },
        special: {
            type: Boolean,
            value: !1
        },
        showBackHome: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        navBarHeight: n.globalData.navBarHeight,
        menuRight: n.globalData.menuRight,
        menuTop: n.globalData.menuTop,
        menuHeight: n.globalData.menuHeight
    },
    attached: function() {},
    methods: {
        jumpToHome: function() {
            t.default.reportElementClick({
                key: "home"
            }), n.globalData.showBackToast ? wx.showModal({
                title: "不保留此次编辑？",
                content: "退出后，编辑结果将不会被保留",
                confirmText: "不保留",
                confirmColor: "#576B95",
                success: function(e) {
                    e.confirm ? (t.default.reportElementClick({
                        key: "drop"
                    }), wx.redirectTo({
                        url: "../index/index"
                    })) : t.default.reportElementClick({
                        key: "cancel_drop"
                    });
                }
            }) : (t.default.reportElementClick({
                key: "drop"
            }), wx.redirectTo({
                url: "../index/index"
            }));
        },
        onPrev: function() {
            this.data.prevActive && this.triggerEvent("prev");
        },
        onNext: function() {
            this.data.nextActive && this.triggerEvent("next");
        },
        backHome: function() {
            t.default.reportElementClick({
                key: "back"
            }), wx.redirectTo({
                url: "../index/index"
            });
        }
    }
});