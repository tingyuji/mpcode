Component({
    properties: {},
    data: {
        random: Math.floor(5 * Math.random()) + 1,
        images: [ "https://res.wx.qq.com/t/fed_upload/95e0e721-7d80-4026-bc02-167f6dbd2ac4/1.png", "https://res.wx.qq.com/t/fed_upload/95e0e721-7d80-4026-bc02-167f6dbd2ac4/2.png", "https://res.wx.qq.com/t/fed_upload/95e0e721-7d80-4026-bc02-167f6dbd2ac4/3.png", "https://res.wx.qq.com/t/fed_upload/95e0e721-7d80-4026-bc02-167f6dbd2ac4/4.png", "https://res.wx.qq.com/t/fed_upload/95e0e721-7d80-4026-bc02-167f6dbd2ac4/5.png" ]
    },
    methods: {}
});