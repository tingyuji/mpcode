Component({
    properties: {},
    data: {
        random: Math.floor(5 * Math.random()) + 1,
        images: [ "https://res.wx.qq.com/t/fed_upload/a5585b93-8e18-4e6b-8ffb-f2bd79572101/1.png", "https://res.wx.qq.com/t/fed_upload/a5585b93-8e18-4e6b-8ffb-f2bd79572101/2.png", "https://res.wx.qq.com/t/fed_upload/a5585b93-8e18-4e6b-8ffb-f2bd79572101/3.png", "https://res.wx.qq.com/t/fed_upload/a5585b93-8e18-4e6b-8ffb-f2bd79572101/4.png", "https://res.wx.qq.com/t/fed_upload/a5585b93-8e18-4e6b-8ffb-f2bd79572101/5.png" ]
    },
    methods: {}
});