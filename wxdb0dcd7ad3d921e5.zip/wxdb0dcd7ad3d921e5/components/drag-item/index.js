Component({
    relations: {
        "../drag-to-sort/index": {
            type: "parent",
            linked: function(t) {
                var i = this, n = t.data, e = n.dragY, s = n.dragX, o = wx.getSystemInfoSync();
                this.parent = t, this.setData({
                    dragY: e,
                    dragX: s,
                    window: {
                        width: o.windowWidth,
                        height: o.windowHeight,
                        scrollTop: 0
                    },
                    linked: !0,
                    scrollTop: 0
                }), this.updatePosList = function(n) {
                    var e = n.rect, s = n.dataset;
                    t.posList = t.posList || [], t.posList.push({
                        originalIndex: s.idx,
                        currentIndex: s.idx,
                        size: {
                            width: e.width,
                            height: e.height
                        },
                        translate: {
                            x: 0,
                            y: 0
                        }
                    }), t.posListLen = t.posListLen || 0, t.posListLen += 1, t.posListLen == t.data.length && (t.posList = t.posList.sort(i.arrayCompare("currentIndex")), 
                    t.allChildLinked(t.posList));
                };
            },
            unlinked: function(t) {
                var i = this, n = t.data, e = n.dragY, s = n.dragX, o = wx.getSystemInfoSync();
                this.setData({
                    dragY: e,
                    dragX: s,
                    window: {
                        width: o.windowWidth,
                        height: o.windowHeight
                    },
                    unlinked: !0
                }), this.updatePosList = function(n) {
                    n.rect;
                    var e, s = n.dataset;
                    t.posList = t.posList || [], t.posList.splice(null === (e = t.posList.find(function(t) {
                        return t.originalIndex === s.idx;
                    })) || void 0 === e ? void 0 : e.currentIndex, 1), t.posList.reverse(), t.posListLen -= 1, 
                    t.posList = t.posList.sort(i.arrayCompare("originalIndex")), t.allChildLinked(t.posList);
                };
            }
        }
    },
    options: {
        multipleSlots: !0
    },
    properties: {
        idx: {
            type: Number,
            value: 0
        }
    },
    data: {
        scrollTop: 0
    },
    methods: {
        getScrollerRect: function() {},
        updatePos: function(t) {
            var i = t.pos, n = t.updateIndex, e = t.oldPos, s = t.newPos, o = this.parent.posList.map(function(t) {
                return t.originalIndex == i.originalIndex ? i : t;
            });
            this.parent.posList = o, void 0 !== n ? this.parent.noticeChildInited(n) : this.parent.noticeChildInited(), 
            e != s && this.parentPosChange({
                oldPos: e,
                newPos: s
            });
        },
        updatePosDate: function(t) {
            this.setData({
                posList: t
            });
        },
        vibrateShort: function() {
            wx.vibrateShort({
                type: "light"
            });
        },
        arrayCompare: function(t) {
            return function(i, n) {
                return i[t] - n[t];
            };
        },
        log: function(t) {},
        parentChange: function(t) {
            this.parent.change(t);
        },
        parentPosChange: function(t) {
            this.parent.posChange(t);
        },
        onDelete: function(t) {
            var i = t.currentTarget.dataset.idx;
            this.parent.delete(i);
        },
        onScroll: function(t) {
            this.parent.onScroll(t);
        },
        resetFaceList: function(t) {}
    }
});