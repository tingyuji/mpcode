require("../../@babel/runtime/helpers/Arrayincludes");

var e = n(require("../../@babel/runtime/regenerator")), t = require("../../@babel/runtime/helpers/asyncToGenerator"), r = n(require("@tencent/merlin-behavior")), a = n(require("../../services/addHotEmojiBackup"));

function n(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

Component({
    properties: {
        url: {
            type: String
        },
        authorName: {
            type: String
        },
        md5: {
            type: String
        },
        isBlock: {
            type: Boolean
        }
    },
    data: {
        blockImgUrl: "https://res.wx.qq.com/t/fed_upload/10fb5cee-1d45-4ace-936b-d1a70054863c/blockWithText.png"
    },
    methods: {
        addHotFaceItem: function() {
            var n = this;
            return t(e.default.mark(function t() {
                var o, i, u, d, l, s;
                return e.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (n.data.url) {
                            e.next = 3;
                            break;
                        }
                        return wx.showToast({
                            title: "添加失败",
                            icon: "none",
                            duration: 2e3
                        }), e.abrupt("return");

                      case 3:
                        return wx.showLoading({
                            title: "正在添加",
                            mask: !0
                        }), e.next = 6, (0, a.default)({
                            md5: n.data.md5
                        });

                      case 6:
                        if (s = e.sent, r.default.reportElementClick({
                            key: "add_hot_emoji",
                            extInfo: {
                                md5: n.data.md5
                            }
                        }), wx.hideLoading(), -205 !== (null == s || null === (o = s.data) || void 0 === o || null === (i = o.data) || void 0 === i ? void 0 : i.ret)) {
                            e.next = 12;
                            break;
                        }
                        return wx.showToast({
                            title: "添加失败，超过表情包上限",
                            icon: "none",
                            duration: 2e3
                        }), e.abrupt("return");

                      case 12:
                        if (![ -1, -100005 ].includes(null == s || null === (u = s.data) || void 0 === u || null === (d = u.data) || void 0 === d ? void 0 : d.ret) && null != s && null !== (l = s.data) && void 0 !== l && l.data) {
                            e.next = 15;
                            break;
                        }
                        return wx.showToast({
                            title: "添加失败",
                            icon: "none",
                            duration: 2e3
                        }), e.abrupt("return");

                      case 15:
                        wx.showToast({
                            title: "已添加到表情"
                        });

                      case 16:
                      case "end":
                        return e.stop();
                    }
                }, t);
            }))();
        }
    }
});