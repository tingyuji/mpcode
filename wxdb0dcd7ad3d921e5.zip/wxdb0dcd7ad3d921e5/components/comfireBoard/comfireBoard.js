Component({
    properties: {
        show: {
            type: Boolean,
            value: !1
        },
        block: {
            type: Function,
            value: function() {}
        },
        comfire: {
            type: Function,
            value: function() {}
        }
    },
    data: {
        isShow: !1
    },
    observers: {
        show: function(t) {
            this.setData({
                isShow: t
            }), this.animate("#mask", [ {
                opacity: 0
            }, {
                opacity: 1
            } ], 300), this.animate("#board", [ {
                translateY: "100%"
            }, {
                translateY: "0"
            } ], 200);
        }
    },
    methods: {
        block: function() {
            wx.setStorageSync("comfireBoard", !1), this.triggerEvent("block"), this.setData({
                isShow: !1
            });
        },
        confirm: function() {
            wx.setStorageSync("comfireBoard", !0), this.triggerEvent("comfire"), this.setData({
                isShow: !1
            });
        }
    }
});