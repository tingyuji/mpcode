var t = require("../../constants/face.js"), e = require("../../constants/body.js"), a = require("../../constants/eye.js"), s = require("../../constants/mouth.js"), i = require("../../constants/eyebrow.js"), n = require("../../constants/acc.js"), c = getApp();

Component({
    properties: {
        createNewShape: {
            type: Function,
            value: function() {}
        }
    },
    data: {
        canvasHeight: c.globalData.canvasHeight,
        navBarHeight: c.globalData.navBarHeight,
        tabs: [],
        activeTab: 0
    },
    lifetimes: {
        attached: function() {
            var c = [ {
                title: "脸型",
                faces: t.face
            }, {
                title: "眼睛",
                faces: a.eye
            }, {
                title: "眉毛",
                faces: i.eyebrow
            }, {
                title: "嘴巴",
                faces: s.mouth
            }, {
                title: "身体",
                faces: e.body
            }, {
                title: "配饰",
                faces: n.acc
            } ];
            this.setData({
                tabs: c
            });
        }
    },
    methods: {
        onTabClick: function(t) {
            var e = t.detail.index;
            this.setData({
                activeTab: e
            });
        },
        onChange: function(t) {
            var e = t.detail.index;
            this.setData({
                activeTab: e
            });
        },
        handleClick: function(t) {
            var e = t.currentTarget.dataset.site;
            Object.assign(e, {
                type: this.data.tabs[this.data.activeTab].title
            }), this.triggerEvent("createNewShape", e);
        }
    }
});