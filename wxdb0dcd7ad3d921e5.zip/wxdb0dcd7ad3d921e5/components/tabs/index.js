var e = require("../../@babel/runtime/helpers/typeof");

module.exports = function(t) {
    var r = {};
    function a(e) {
        if (r[e]) return r[e].exports;
        var n = r[e] = {
            i: e,
            l: !1,
            exports: {}
        };
        return t[e].call(n.exports, n, n.exports, a), n.l = !0, n.exports;
    }
    return a.m = t, a.c = r, a.d = function(e, t, r) {
        a.o(e, t) || Object.defineProperty(e, t, {
            enumerable: !0,
            get: r
        });
    }, a.r = function(e) {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(e, "__esModule", {
            value: !0
        });
    }, a.t = function(t, r) {
        if (1 & r && (t = a(t)), 8 & r) return t;
        if (4 & r && "object" === e(t) && t && t.__esModule) return t;
        var n = Object.create(null);
        if (a.r(n), Object.defineProperty(n, "default", {
            enumerable: !0,
            value: t
        }), 2 & r && "string" != typeof t) for (var i in t) a.d(n, i, function(e) {
            return t[e];
        }.bind(null, i));
        return n;
    }, a.n = function(e) {
        var t = e && e.__esModule ? function() {
            return e.default;
        } : function() {
            return e;
        };
        return a.d(t, "a", t), t;
    }, a.o = function(e, t) {
        return Object.prototype.hasOwnProperty.call(e, t);
    }, a.p = "", a(a.s = 2);
}({
    2: function(e, t, r) {
        Component({
            options: {
                addGlobalClass: !0,
                pureDataPattern: /^_/,
                multipleSlots: !0
            },
            properties: {
                tabs: {
                    type: Array,
                    value: []
                },
                showIcon: {
                    type: Boolean,
                    value: !1
                },
                tabClass: {
                    type: String,
                    value: ""
                },
                tabsClass: {
                    type: String,
                    value: ""
                },
                swiperClass: {
                    type: String,
                    value: ""
                },
                activeClass: {
                    type: String,
                    value: ""
                },
                tabUnderlineColor: {
                    type: String,
                    value: "#07c160"
                },
                tabActiveTextColor: {
                    type: String,
                    value: "#000000"
                },
                tabInactiveTextColor: {
                    type: String,
                    value: "#000000"
                },
                tabBackgroundColor: {
                    type: String,
                    value: "#ffffff"
                },
                activeTab: {
                    type: Number,
                    value: 0
                },
                duration: {
                    type: Number,
                    value: 500
                },
                isFixed: {
                    type: Boolean,
                    value: !1
                },
                selected: {
                    type: Boolean,
                    value: !1
                },
                extraTabHeight: {
                    type: Boolean,
                    value: !1
                },
                scrollTop: {
                    type: Number,
                    value: 0
                }
            },
            data: {
                currentView: 0
            },
            observers: {
                activeTab: function(e) {
                    var t = this.data.tabs.length;
                    if (0 !== t) {
                        var r = e - 1;
                        r < 0 && (r = 0), r > t - 1 && (r = t - 1), this.setData({
                            currentView: r
                        });
                    }
                }
            },
            lifetimes: {
                created: function() {}
            },
            methods: {
                handleTabClick: function(e) {
                    var t = e.currentTarget.dataset.index, r = e.currentTarget.dataset.disable;
                    !this.data.selected && r || (this.setData({
                        activeTab: t
                    }), this.triggerEvent("tabclick", {
                        index: t
                    }));
                },
                handleSwiperChange: function(e) {
                    var t = e.detail.current;
                    this.setData({
                        activeTab: t
                    }), this.triggerEvent("change", {
                        index: t
                    });
                },
                handle: function(e) {
                    return e;
                }
            }
        });
    }
});