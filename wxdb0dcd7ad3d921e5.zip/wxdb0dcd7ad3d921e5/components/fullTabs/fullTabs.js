Component({
    options: {
        addGlobalClass: !0,
        pureDataPattern: /^_/,
        multipleSlots: !0
    },
    properties: {
        tabs: {
            type: Array,
            value: []
        },
        tabClass: {
            type: String,
            value: ""
        },
        swiperClass: {
            type: String,
            value: ""
        },
        swiperWrapClass: {
            type: String,
            value: ""
        },
        swiperWrapStyle: {
            type: String,
            value: ""
        },
        activeClass: {
            type: String,
            value: ""
        },
        tabUnderlineColor: {
            type: String,
            value: "#07c160"
        },
        tabActiveTextColor: {
            type: String,
            value: "#000000"
        },
        tabInactiveTextColor: {
            type: String,
            value: "#000000"
        },
        tabBackgroundColor: {
            type: String,
            value: "#ffffff"
        },
        activeTab: {
            type: Number,
            value: 0
        },
        duration: {
            type: Number,
            value: 500
        }
    },
    data: {
        currentView: 0
    },
    observers: {
        activeTab: function(t) {
            var e = this.data.tabs.length;
            if (0 !== e) {
                var a = t - 1;
                a < 0 && (a = 0), a > e - 1 && (a = e - 1), this.setData({
                    currentView: a
                });
            }
        }
    },
    lifetimes: {
        attached: function() {}
    },
    methods: {
        handleTabClick: function(t) {
            var e = t.currentTarget.dataset.index;
            this.setData({
                activeTab: e
            }), this.triggerEvent("tabclick", {
                index: e
            });
        },
        handleSwiperChange: function(t) {
            var e = t.detail.current;
            this.setData({
                activeTab: e
            }), this.triggerEvent("change", {
                index: e
            });
        }
    }
});