Component({
    properties: {
        color: {
            type: String
        },
        value: {
            type: String
        },
        focus: {
            type: Boolean,
            value: !1
        },
        adjustPosition: {
            type: Boolean,
            value: !1
        },
        catchtap: {
            type: Function,
            value: function() {}
        },
        inputs: {
            type: Function,
            value: function() {}
        },
        keyboardheightchange: {
            type: Function,
            value: function() {}
        },
        holdKeyboard: {
            type: Boolean,
            value: !0
        }
    },
    data: {},
    methods: {
        onKeyboardheightchange: function(t) {
            this.triggerEvent("keyboardheightchange", t);
        },
        onInput: function(t) {
            console.log(t), this.triggerEvent("inputs", t);
        },
        emptyFunc: function() {}
    }
});