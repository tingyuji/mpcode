require("../../../@babel/runtime/helpers/Objectentries"), require("../../../@babel/runtime/helpers/Arrayincludes");

var e, t, r, n = require("../../../@babel/runtime/helpers/typeof");

module.exports = (e = {}, r = function(t, r) {
    if (!e[t]) return require(r);
    if (!e[t].status) {
        var o = e[t].m;
        o._exports = o._tempexports;
        var i = Object.getOwnPropertyDescriptor(o, "exports");
        i && i.configurable && Object.defineProperty(o, "exports", {
            set: function(e) {
                "object" === n(e) && e !== o._exports && (o._exports.__proto__ = e.__proto__, Object.keys(e).forEach(function(t) {
                    o._exports[t] = e[t];
                })), o._tempexports = e;
            },
            get: function() {
                return o._tempexports;
            }
        }), e[t].status = 1, e[t].func(e[t].req, o, o.exports);
    }
    return e[t].m.exports;
}, (t = function(t, r, n) {
    e[t] = {
        status: 0,
        func: r,
        req: n,
        m: {
            exports: {},
            _tempexports: {}
        }
    };
})(1663577422808, function(e, t, r) {
    var n = this && this.__createBinding || (Object.create ? function(e, t, r, n) {
        void 0 === n && (n = r), Object.defineProperty(e, n, {
            enumerable: !0,
            get: function() {
                return t[r];
            }
        });
    } : function(e, t, r, n) {
        void 0 === n && (n = r), e[n] = t[r];
    }), o = this && this.__exportStar || function(e, t) {
        for (var r in e) "default" === r || Object.prototype.hasOwnProperty.call(t, r) || n(t, e, r);
    };
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), o(e("./Reporter"), r), o(e("./Collector"), r), o(e("./Transport"), r), o(e("./common"), r), 
    o(e("./types"), r), o(e("./transports"), r), o(e("./utils"), r);
}, function(e) {
    return r({
        "./Reporter": 1663577422809,
        "./Collector": 1663577422810,
        "./Transport": 1663577422811,
        "./common": 1663577422819,
        "./types": 1663577422820,
        "./transports": 1663577422821,
        "./utils": 1663577422815
    }[e], e);
}), t(1663577422809, function(e, t, r) {
    var n = this && this.__assign || function() {
        return (n = Object.assign || function(e) {
            for (var t, r = 1, n = arguments.length; r < n; r++) for (var o in t = arguments[r]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
            return e;
        }).apply(this, arguments);
    }, o = this && this.__awaiter || function(e, t, r, n) {
        return new (r || (r = Promise))(function(o, i) {
            function a(e) {
                try {
                    u(n.next(e));
                } catch (e) {
                    i(e);
                }
            }
            function l(e) {
                try {
                    u(n.throw(e));
                } catch (e) {
                    i(e);
                }
            }
            function u(e) {
                var t;
                e.done ? o(e.value) : (t = e.value, t instanceof r ? t : new r(function(e) {
                    e(t);
                })).then(a, l);
            }
            u((n = n.apply(e, t || [])).next());
        });
    }, i = this && this.__generator || function(e, t) {
        var r, n, o, i, a = {
            label: 0,
            sent: function() {
                if (1 & o[0]) throw o[1];
                return o[1];
            },
            trys: [],
            ops: []
        };
        return i = {
            next: l(0),
            throw: l(1),
            return: l(2)
        }, "function" == typeof Symbol && (i[Symbol.iterator] = function() {
            return this;
        }), i;
        function l(i) {
            return function(l) {
                return function(i) {
                    if (r) throw new TypeError("Generator is already executing.");
                    for (;a; ) try {
                        if (r = 1, n && (o = 2 & i[0] ? n.return : i[0] ? n.throw || ((o = n.return) && o.call(n), 
                        0) : n.next) && !(o = o.call(n, i[1])).done) return o;
                        switch (n = 0, o && (i = [ 2 & i[0], o.value ]), i[0]) {
                          case 0:
                          case 1:
                            o = i;
                            break;

                          case 4:
                            return a.label++, {
                                value: i[1],
                                done: !1
                            };

                          case 5:
                            a.label++, n = i[1], i = [ 0 ];
                            continue;

                          case 7:
                            i = a.ops.pop(), a.trys.pop();
                            continue;

                          default:
                            if (!((o = (o = a.trys).length > 0 && o[o.length - 1]) || 6 !== i[0] && 2 !== i[0])) {
                                a = 0;
                                continue;
                            }
                            if (3 === i[0] && (!o || i[1] > o[0] && i[1] < o[3])) {
                                a.label = i[1];
                                break;
                            }
                            if (6 === i[0] && a.label < o[1]) {
                                a.label = o[1], o = i;
                                break;
                            }
                            if (o && a.label < o[2]) {
                                a.label = o[2], a.ops.push(i);
                                break;
                            }
                            o[2] && a.ops.pop(), a.trys.pop();
                            continue;
                        }
                        i = t.call(e, a);
                    } catch (e) {
                        i = [ 6, e ], n = 0;
                    } finally {
                        r = o = 0;
                    }
                    if (5 & i[0]) throw i[1];
                    return {
                        value: i[0] ? i[1] : void 0,
                        done: !0
                    };
                }([ i, l ]);
            };
        }
    }, a = this && this.__read || function(e, t) {
        var r = "function" == typeof Symbol && e[Symbol.iterator];
        if (!r) return e;
        var n, o, i = r.call(e), a = [];
        try {
            for (;(void 0 === t || t-- > 0) && !(n = i.next()).done; ) a.push(n.value);
        } catch (e) {
            o = {
                error: e
            };
        } finally {
            try {
                n && !n.done && (r = i.return) && r.call(i);
            } finally {
                if (o) throw o.error;
            }
        }
        return a;
    }, l = this && this.__spreadArray || function(e, t, r) {
        if (r || 2 === arguments.length) for (var n, o = 0, i = t.length; o < i; o++) !n && o in t || (n || (n = Array.prototype.slice.call(t, 0, o)), 
        n[o] = t[o]);
        return e.concat(n || Array.prototype.slice.call(t));
    };
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), r.Reporter = void 0;
    var u = e("./Collector"), s = e("./Transport"), c = e("./adapters"), f = e("./utils"), p = function() {
        function e() {
            this.scopeInfo = {
                contextId: (0, f.uuidV4)()
            }, this.userInfo = {}, this.debug = !1, this.initialized = !1, this.buffering = !1, 
            this.buffer = [], this.adapter = new c.adapters.web(), this.collectors = [], this.transports = [], 
            this.errorHandler = function(e, t) {
                console.error("[Merlin]", {
                    stack: null == e ? void 0 : e.stack,
                    msg: null == e ? void 0 : e.message,
                    detail: t
                });
            }, this.aIdGenerator = function() {
                return (0, f.uuidV4)();
            };
        }
        return e.prototype.setOptions = function(e) {
            e.adapter && (this.adapter = new c.adapters[e.adapter]()), e.collectors && (this.collectors = e.collectors.filter(function(e) {
                return u.Collector.isCollector(e);
            })), e.transports && (this.transports = e.transports.filter(function(e) {
                return s.Transport.isTransport(e);
            })), void 0 !== e.debug && (this.debug = e.debug), e.errorHandler && (this.errorHandler = e.errorHandler), 
            e.aIdGenerator && (this.aIdGenerator = e.aIdGenerator), e.user && this.setUserInfo(e.user), 
            !1 !== e.release && (this.release = e.release || globalThis.release);
        }, e.prototype.init = function(e) {
            var t, r = this;
            if (this.initialized) this.errorHandler(new Error("reporter was already initialized")); else try {
                this.setOptions(e), this.adapter.init(this);
                var n = this.adapter.getAid();
                if (null == n ? void 0 : n.then) n.then(function(e) {
                    var t;
                    if (e && "string" == typeof e) r.log("get aid from async storage", e), r.userInfo.aid = e; else {
                        var n = null === (t = r.aIdGenerator) || void 0 === t ? void 0 : t.call(r);
                        r.userInfo.aid = n, r.adapter.saveAid(n);
                    }
                }).catch(function(e) {
                    var t, n = null === (t = r.aIdGenerator) || void 0 === t ? void 0 : t.call(r);
                    r.userInfo.aid = n, r.adapter.saveAid(n);
                }); else if (n && "string" == typeof n) this.log("get aid from storage", n), this.userInfo.aid = n; else {
                    var o = null === (t = this.aIdGenerator) || void 0 === t ? void 0 : t.call(this);
                    this.userInfo.aid = o, this.adapter.saveAid(o);
                }
                this.transports.forEach(function(e) {
                    try {
                        e.init(r);
                    } catch (e) {
                        console.error("[Merlin] transport init failed", e), r.errorHandler(new Error("transport init failed"));
                    }
                }), this.collectors.forEach(function(e) {
                    try {
                        e.init(r);
                    } catch (e) {
                        console.error("[Merlin] collector init failed", e), r.errorHandler(new Error("collector init failed"));
                    }
                }), this.initialized = !0;
            } catch (e) {
                this.errorHandler(e);
            }
        }, e.prototype.log = function() {
            for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
            this.debug && console.log.apply(console, l([ "[Merlin]" ], a(e), !1));
        }, Object.defineProperty(e.prototype, "baseContext", {
            get: function() {
                return {
                    user: this.userInfo,
                    release: this.release
                };
            },
            enumerable: !1,
            configurable: !0
        }), Object.defineProperty(e.prototype, "scopeContext", {
            get: function() {
                return this.scopeInfo;
            },
            enumerable: !1,
            configurable: !0
        }), e.prototype.setUserInfo = function(e) {
            this.userInfo = this.userInfo.aid ? n(n({}, e), {
                aid: this.userInfo.aid
            }) : e;
        }, e.prototype.enableBuffering = function() {
            this.buffering = !0;
        }, e.prototype.settleBuffering = function() {
            return o(this, void 0, void 0, function() {
                var e;
                return i(this, function(t) {
                    switch (t.label) {
                      case 0:
                        if (!this.buffering) return [ 2 ];
                        this.readLinkedData(), this.buffering = !1, t.label = 1;

                      case 1:
                        return t.trys.push([ 1, 3, , 4 ]), [ 4, this.flush() ];

                      case 2:
                        return [ 2, t.sent() ];

                      case 3:
                        return e = t.sent(), this.errorHandler(e), [ 3, 4 ];

                      case 4:
                        return [ 2 ];
                    }
                });
            });
        }, e.prototype.report = function(e) {
            if (this.initialized) try {
                this.updateScopeInfo(), this.buffer.push({
                    ctime: Date.now(),
                    type: e.type,
                    data: e.data,
                    context: this.getContext()
                }), this.flush();
            } catch (t) {
                this.errorHandler(t, e);
            } else console.warn("[Merlin] Reporter not initialized");
        }, e.prototype.readLinkedData = function() {
            this.adapter.readLinkedData();
        }, Object.defineProperty(e.prototype, "serializeLinkedData", {
            get: function() {
                return this.adapter.serializeLinkedData() || "";
            },
            enumerable: !1,
            configurable: !0
        }), Object.defineProperty(e.prototype, "objectLinkedData", {
            get: function() {
                return this.adapter.linkedData;
            },
            enumerable: !1,
            configurable: !0
        }), Object.defineProperty(e.prototype, "supportSyncStorage", {
            get: function() {
                return this.adapter.storage.supportSync;
            },
            enumerable: !1,
            configurable: !0
        }), e.prototype.getStorageItem = function() {
            for (var e, t = [], r = 0; r < arguments.length; r++) t[r] = arguments[r];
            return null === (e = this.adapter.storage) || void 0 === e ? void 0 : e.getItem.apply(e, l([], a(t), !1));
        }, e.prototype.setStorageItem = function() {
            for (var e, t = [], r = 0; r < arguments.length; r++) t[r] = arguments[r];
            null === (e = this.adapter.storage) || void 0 === e || e.setItem.apply(e, l([], a(t), !1));
        }, e.prototype.removeStorageItem = function() {
            for (var e, t = [], r = 0; r < arguments.length; r++) t[r] = arguments[r];
            null === (e = this.adapter.storage) || void 0 === e || e.removeItem.apply(e, l([], a(t), !1));
        }, e.prototype.httpPost = function() {
            for (var e, t = [], r = 0; r < arguments.length; r++) t[r] = arguments[r];
            (e = this.adapter).httpPost.apply(e, l([], a(t), !1));
        }, e.prototype.settle = function() {
            return o(this, void 0, void 0, function() {
                var e;
                return i(this, function(t) {
                    switch (t.label) {
                      case 0:
                        return t.trys.push([ 0, 2, , 3 ]), this.collectors.forEach(function(e) {
                            return e.settle();
                        }), [ 4, this.flush(!0) ];

                      case 1:
                        return t.sent(), this.adapter.settle(), [ 3, 3 ];

                      case 2:
                        return e = t.sent(), this.errorHandler(e), [ 3, 3 ];

                      case 3:
                        return [ 2 ];
                    }
                });
            });
        }, e.prototype.flush = function(e) {
            return void 0 === e && (e = !1), o(this, void 0, void 0, function() {
                var t;
                return i(this, function(r) {
                    return this.buffering ? [ 2 ] : (t = l([], a(this.buffer), !1), this.buffer.length = 0, 
                    [ 2, this.sendToTransports(t, e) ]);
                });
            });
        }, e.prototype.getContext = function() {
            return {
                base: this.baseContext,
                env: this.adapter.envInfo || {},
                scope: this.scopeContext
            };
        }, e.prototype.updateScopeInfo = function() {
            this.adapter.updateScopeInfo();
        }, e.prototype.sendToTransports = function(e, t) {
            return void 0 === t && (t = !1), Promise.all(this.transports.map(function(r) {
                return r.receiveFromReporter(e, t);
            }));
        }, e;
    }();
    r.Reporter = p;
}, function(e) {
    return r({
        "./Collector": 1663577422810,
        "./Transport": 1663577422811,
        "./adapters": 1663577422812,
        "./utils": 1663577422815
    }[e], e);
}), t(1663577422810, function(e, t, r) {
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), r.Collector = void 0;
    var n = function() {
        function e() {
            this.reporter = void 0;
        }
        return e.isCollector = function(e) {
            return e && "function" == typeof e.init && "function" == typeof e.destroy && "function" == typeof e.settle;
        }, e.prototype.init = function(e) {
            this.reporter = e;
        }, e.prototype.destroy = function() {
            this.reporter = void 0;
        }, e.prototype.settle = function() {}, e;
    }();
    r.Collector = n;
}, function(e) {
    return r({}[e], e);
}), t(1663577422811, function(e, t, r) {
    var n = this && this.__awaiter || function(e, t, r, n) {
        return new (r || (r = Promise))(function(o, i) {
            function a(e) {
                try {
                    u(n.next(e));
                } catch (e) {
                    i(e);
                }
            }
            function l(e) {
                try {
                    u(n.throw(e));
                } catch (e) {
                    i(e);
                }
            }
            function u(e) {
                var t;
                e.done ? o(e.value) : (t = e.value, t instanceof r ? t : new r(function(e) {
                    e(t);
                })).then(a, l);
            }
            u((n = n.apply(e, t || [])).next());
        });
    }, o = this && this.__generator || function(e, t) {
        var r, n, o, i, a = {
            label: 0,
            sent: function() {
                if (1 & o[0]) throw o[1];
                return o[1];
            },
            trys: [],
            ops: []
        };
        return i = {
            next: l(0),
            throw: l(1),
            return: l(2)
        }, "function" == typeof Symbol && (i[Symbol.iterator] = function() {
            return this;
        }), i;
        function l(i) {
            return function(l) {
                return function(i) {
                    if (r) throw new TypeError("Generator is already executing.");
                    for (;a; ) try {
                        if (r = 1, n && (o = 2 & i[0] ? n.return : i[0] ? n.throw || ((o = n.return) && o.call(n), 
                        0) : n.next) && !(o = o.call(n, i[1])).done) return o;
                        switch (n = 0, o && (i = [ 2 & i[0], o.value ]), i[0]) {
                          case 0:
                          case 1:
                            o = i;
                            break;

                          case 4:
                            return a.label++, {
                                value: i[1],
                                done: !1
                            };

                          case 5:
                            a.label++, n = i[1], i = [ 0 ];
                            continue;

                          case 7:
                            i = a.ops.pop(), a.trys.pop();
                            continue;

                          default:
                            if (!((o = (o = a.trys).length > 0 && o[o.length - 1]) || 6 !== i[0] && 2 !== i[0])) {
                                a = 0;
                                continue;
                            }
                            if (3 === i[0] && (!o || i[1] > o[0] && i[1] < o[3])) {
                                a.label = i[1];
                                break;
                            }
                            if (6 === i[0] && a.label < o[1]) {
                                a.label = o[1], o = i;
                                break;
                            }
                            if (o && a.label < o[2]) {
                                a.label = o[2], a.ops.push(i);
                                break;
                            }
                            o[2] && a.ops.pop(), a.trys.pop();
                            continue;
                        }
                        i = t.call(e, a);
                    } catch (e) {
                        i = [ 6, e ], n = 0;
                    } finally {
                        r = o = 0;
                    }
                    if (5 & i[0]) throw i[1];
                    return {
                        value: i[0] ? i[1] : void 0,
                        done: !0
                    };
                }([ i, l ]);
            };
        }
    }, i = this && this.__read || function(e, t) {
        var r = "function" == typeof Symbol && e[Symbol.iterator];
        if (!r) return e;
        var n, o, i = r.call(e), a = [];
        try {
            for (;(void 0 === t || t-- > 0) && !(n = i.next()).done; ) a.push(n.value);
        } catch (e) {
            o = {
                error: e
            };
        } finally {
            try {
                n && !n.done && (r = i.return) && r.call(i);
            } finally {
                if (o) throw o.error;
            }
        }
        return a;
    }, a = this && this.__spreadArray || function(e, t, r) {
        if (r || 2 === arguments.length) for (var n, o = 0, i = t.length; o < i; o++) !n && o in t || (n || (n = Array.prototype.slice.call(t, 0, o)), 
        n[o] = t[o]);
        return e.concat(n || Array.prototype.slice.call(t));
    };
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), r.Transport = void 0;
    var l = function() {
        function e(e) {
            this.sampleRate = 1, this.filter = void 0, this.bufferSize = 50, this.flushInterval = 1e4, 
            this.buffer = [], this.frequencyLimit = {
                max: 0,
                perSeconds: 0
            }, this.frequencyLimitRecordCount = 0, (null == e ? void 0 : e.filter) && (this.filter = e.filter), 
            "number" == typeof (null == e ? void 0 : e.sampleRate) && (e.sampleRate <= 0 || e.sampleRate > 1 ? (console.warn("[Merlin] 采样率必须在 (0, 1] 范围内"), 
            this.sampleRate = 1) : this.sampleRate = e.sampleRate), void 0 !== (null == e ? void 0 : e.bufferSize) && (this.bufferSize = e.bufferSize), 
            void 0 !== (null == e ? void 0 : e.flushInterval) && (this.flushInterval = e.flushInterval), 
            void 0 !== (null == e ? void 0 : e.frequencyLimit) && (this.frequencyLimit = e.frequencyLimit);
        }
        return e.isTransport = function(e) {
            return e && "function" == typeof e.init && "function" == typeof e.receiveFromReporter && "function" == typeof e.flush && "function" == typeof e.send;
        }, e.prototype.init = function(e) {
            return n(this, void 0, void 0, function() {
                var t = this;
                return o(this, function(r) {
                    return this.reporter = e, setInterval && clearInterval && (0 !== this.flushInterval && (this.flushIntervalTimer && (clearInterval(this.flushIntervalTimer), 
                    this.flushIntervalTimer = void 0), this.flushIntervalTimer = setInterval(function() {
                        t.flush();
                    }, this.flushInterval)), 0 !== this.frequencyLimit.perSeconds && (this.frequencyLimitTimer && (clearInterval(this.frequencyLimitTimer), 
                    this.frequencyLimitTimer = void 0), this.frequencyLimitTimer = setInterval(function() {
                        t.frequencyLimitRecordCount = 0;
                    }, 1e3 * this.frequencyLimit.perSeconds))), [ 2 ];
                });
            });
        }, e.prototype.receiveFromReporter = function(e, t) {
            return void 0 === t && (t = !1), n(this, void 0, void 0, function() {
                var r, n, l = this;
                return o(this, function(o) {
                    switch (o.label) {
                      case 0:
                        return r = a([], i(e), !1), this.filter && (r = r.filter(this.filter)), this.sampleRate < 1 && (r = r.filter(function() {
                            return Math.random() < l.sampleRate;
                        })), r.length && (n = this.buffer).push.apply(n, a([], i(r), !1)), t || 0 === this.bufferSize || this.buffer.length >= this.bufferSize ? [ 4, this.flush() ] : [ 3, 2 ];

                      case 1:
                        o.sent(), o.label = 2;

                      case 2:
                        return [ 2 ];
                    }
                });
            });
        }, e.prototype.flush = function() {
            return n(this, void 0, void 0, function() {
                var e, t;
                return o(this, function(r) {
                    switch (r.label) {
                      case 0:
                        if (!this.buffer.length) return [ 2 ];
                        if (e = a([], i(this.buffer), !1), this.buffer.length = 0, 0 !== this.frequencyLimit.max) {
                            if ((t = this.frequencyLimit.max - this.frequencyLimitRecordCount) <= 0) return [ 2 ];
                            t < e.length && (e.length = t), this.frequencyLimitRecordCount += e.length;
                        }
                        return [ 4, this.send(e) ];

                      case 1:
                        return r.sent(), [ 2 ];
                    }
                });
            });
        }, e;
    }();
    r.Transport = l;
}, function(e) {
    return r({}[e], e);
}), t(1663577422812, function(e, t, r) {
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), r.adapters = void 0;
    var n = e("./LiteAdapter"), o = e("./WebAdapter"), i = e("./MiniProgramAdapter");
    r.adapters = {
        lite: n.LiteAdapter,
        web: o.WebAdapter,
        miniprogram: i.MiniProgramAdapter
    };
}, function(e) {
    return r({
        "./LiteAdapter": 1663577422813,
        "./WebAdapter": 1663577422817,
        "./MiniProgramAdapter": 1663577422818
    }[e], e);
}), t(1663577422813, function(e, t, r) {
    var n, o = this && this.__extends || (n = function(e, t) {
        return (n = Object.setPrototypeOf || {
            __proto__: []
        } instanceof Array && function(e, t) {
            e.__proto__ = t;
        } || function(e, t) {
            for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (e[r] = t[r]);
        })(e, t);
    }, function(e, t) {
        if ("function" != typeof t && null !== t) throw new TypeError("Class extends value ".concat(String(t), " is not a constructor or null"));
        function r() {
            this.constructor = e;
        }
        n(e, t), e.prototype = null === t ? Object.create(t) : (r.prototype = t.prototype, 
        new r());
    }), i = this && this.__assign || function() {
        return (i = Object.assign || function(e) {
            for (var t, r = 1, n = arguments.length; r < n; r++) for (var o in t = arguments[r]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
            return e;
        }).apply(this, arguments);
    }, a = this && this.__awaiter || function(e, t, r, n) {
        return new (r || (r = Promise))(function(o, i) {
            function a(e) {
                try {
                    u(n.next(e));
                } catch (e) {
                    i(e);
                }
            }
            function l(e) {
                try {
                    u(n.throw(e));
                } catch (e) {
                    i(e);
                }
            }
            function u(e) {
                var t;
                e.done ? o(e.value) : (t = e.value, t instanceof r ? t : new r(function(e) {
                    e(t);
                })).then(a, l);
            }
            u((n = n.apply(e, t || [])).next());
        });
    }, l = this && this.__generator || function(e, t) {
        var r, n, o, i, a = {
            label: 0,
            sent: function() {
                if (1 & o[0]) throw o[1];
                return o[1];
            },
            trys: [],
            ops: []
        };
        return i = {
            next: l(0),
            throw: l(1),
            return: l(2)
        }, "function" == typeof Symbol && (i[Symbol.iterator] = function() {
            return this;
        }), i;
        function l(i) {
            return function(l) {
                return function(i) {
                    if (r) throw new TypeError("Generator is already executing.");
                    for (;a; ) try {
                        if (r = 1, n && (o = 2 & i[0] ? n.return : i[0] ? n.throw || ((o = n.return) && o.call(n), 
                        0) : n.next) && !(o = o.call(n, i[1])).done) return o;
                        switch (n = 0, o && (i = [ 2 & i[0], o.value ]), i[0]) {
                          case 0:
                          case 1:
                            o = i;
                            break;

                          case 4:
                            return a.label++, {
                                value: i[1],
                                done: !1
                            };

                          case 5:
                            a.label++, n = i[1], i = [ 0 ];
                            continue;

                          case 7:
                            i = a.ops.pop(), a.trys.pop();
                            continue;

                          default:
                            if (!((o = (o = a.trys).length > 0 && o[o.length - 1]) || 6 !== i[0] && 2 !== i[0])) {
                                a = 0;
                                continue;
                            }
                            if (3 === i[0] && (!o || i[1] > o[0] && i[1] < o[3])) {
                                a.label = i[1];
                                break;
                            }
                            if (6 === i[0] && a.label < o[1]) {
                                a.label = o[1], o = i;
                                break;
                            }
                            if (o && a.label < o[2]) {
                                a.label = o[2], a.ops.push(i);
                                break;
                            }
                            o[2] && a.ops.pop(), a.trys.pop();
                            continue;
                        }
                        i = t.call(e, a);
                    } catch (e) {
                        i = [ 6, e ], n = 0;
                    } finally {
                        r = o = 0;
                    }
                    if (5 & i[0]) throw i[1];
                    return {
                        value: i[0] ? i[1] : void 0,
                        done: !0
                    };
                }([ i, l ]);
            };
        }
    };
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), r.LiteAdapter = void 0;
    var u = e("../Adapter"), s = e("../utils"), c = function(e) {
        function t() {
            var t = null !== e && e.apply(this, arguments) || this;
            return t.storage = {
                supportSync: !1,
                setItem: function(e, t) {
                    var r, n;
                    (null === lite || void 0 === lite ? void 0 : lite.kv) && null != t && (null === (n = null === (r = lite.kv.setItem(e, JSON.stringify(t))) || void 0 === r ? void 0 : r.catch) || void 0 === n || n.call(r, function() {}));
                },
                getItem: function(e, t) {
                    return a(this, void 0, void 0, function() {
                        var r, n;
                        return l(this, function(o) {
                            switch (o.label) {
                              case 0:
                                if (!(null === lite || void 0 === lite ? void 0 : lite.kv)) return [ 2, t ];
                                o.label = 1;

                              case 1:
                                return o.trys.push([ 1, 3, , 4 ]), [ 4, lite.kv.getItem(e) ];

                              case 2:
                                return null == (r = o.sent()) ? [ 2, t ] : [ 2, JSON.parse(r) ];

                              case 3:
                                return n = o.sent(), console.error("[Merlin] getItem failed", n), [ 2, t ];

                              case 4:
                                return [ 2 ];
                            }
                        });
                    });
                },
                removeItem: function(e) {
                    var t, r;
                    (null === lite || void 0 === lite ? void 0 : lite.kv) && (null === (r = null === (t = lite.kv.removeItem(e)) || void 0 === t ? void 0 : t.catch) || void 0 === r || r.call(t, function() {}));
                }
            }, t.thisHandleRouteEnter = t.handleRouteEnter.bind(t), t.thisHandleUnload = t.handleUnload.bind(t), 
            t;
        }
        return o(t, e), t.prototype.init = function(t) {
            e.prototype.init.call(this, t), lite ? (lite.addEventListener("routeEnter", this.thisHandleRouteEnter), 
            lite.addEventListener("unload", this.thisHandleUnload)) : console.error("[Merlin] LiteAdapter can only be used in liteApp environment (with lite defined)");
        }, t.prototype.settle = function() {}, t.prototype.updateScopeInfo = function() {
            if (this.reporter && lite) {
                var e = lite.system.getSystemInfo();
                this.updateScopeInfoField("network", e.networkType), this.updateScopeInfoField("devicePixelRatio", e.pixelRatio), 
                this.handleRouteEnter();
            }
        }, t.prototype.readLinkedData = function(e) {
            var t;
            if (this.reporter && (null === lite || void 0 === lite ? void 0 : lite.router)) {
                var r = (0, s.underline2HumpObjectKey)(e || lite.router.currentQuery || {});
                r.contextId && this.updateScopeInfoField("contextId", r.contextId), r.entranceId && this.updateScopeInfoField("entranceId", r.entranceId), 
                (null === (t = this.reporter.scopeInfo.entranceInfo) || void 0 === t ? void 0 : t.subEntranceid) !== r.subEntranceid && (this.reporter.scopeInfo.entranceInfo = {
                    subEntranceid: r.subEntranceid
                }), r.reddotId && this.updateScopeInfoField("redDotInfo", {
                    id: r.reddotId
                }), r.fromAccessId && this.updateScopeInfoField("fromAccessId", r.fromAccessId), 
                r.fromElelmentId && this.updateScopeInfoField("fromElementId", r.fromElementId);
            }
        }, Object.defineProperty(t.prototype, "linkedData", {
            get: function() {
                var e, t, r, n, o, i;
                return {
                    contextId: null === (e = this.reporter) || void 0 === e ? void 0 : e.scopeInfo.contextId,
                    entranceId: null === (t = this.reporter) || void 0 === t ? void 0 : t.scopeInfo.entranceId,
                    subEntranceid: null === (n = null === (r = this.reporter) || void 0 === r ? void 0 : r.scopeInfo.entranceInfo) || void 0 === n ? void 0 : n.subEntranceid,
                    reddotId: null === (i = null === (o = this.reporter) || void 0 === o ? void 0 : o.scopeInfo.redDotInfo) || void 0 === i ? void 0 : i.id
                };
            },
            enumerable: !1,
            configurable: !0
        }), t.prototype.serializeLinkedData = function(e) {
            return (0, s.stringifyQuery)(i(i({}, this.linkedData), e));
        }, t.prototype.httpPost = function(e, t, r) {
            fetch(e, {
                method: "POST",
                headers: {
                    "Content-Type": r.contentType
                },
                body: t
            });
        }, t.prototype.handleRouteEnter = function(e) {
            if (lite && lite.router) {
                var t = (null == e ? void 0 : e.path) || lite.router.currentRoute, r = (null == e ? void 0 : e.query) || lite.router.currentQuery;
                this.readLinkedData(r), r && Object.keys(r).length > 0 && (t += "?", t += (0, s.stringifyQuery)(r)), 
                this.updateScopeInfoField("href", t);
            }
        }, t.prototype.getEnvInfo = function() {
            if (!lite) return {};
            var e = lite.system.getSystemInfo();
            return {
                userAgent: lite.system.getUserAgent(),
                deviceBrand: e.brand,
                deviceModel: e.model,
                osName: e.platform,
                osVersion: "".concat(e.system),
                appVersion: e.version,
                liteAppVersion: e.liteAppVersion,
                appId: e.appId
            };
        }, t.prototype.handleUnload = function() {
            var e, t = this;
            null === (e = this.reporter) || void 0 === e || e.settle().then(function() {
                var e;
                null === (e = t.reporter) || void 0 === e || e.log("Reporter 清算结束");
            });
        }, t;
    }(u.Adapter);
    r.LiteAdapter = c;
}, function(e) {
    return r({
        "../Adapter": 1663577422814,
        "../utils": 1663577422815
    }[e], e);
}), t(1663577422814, function(e, t, r) {
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), r.Adapter = void 0;
    var n = function() {
        function e() {
            this.envInfo = {};
        }
        return e.prototype.init = function(e) {
            this.reporter = e, this.initEnvInfo(), this.readLinkedData(), this.updateScopeInfo();
        }, e.prototype.getAid = function() {
            return this.storage.getItem("__ml::aid", void 0);
        }, e.prototype.saveAid = function(e) {
            e && this.storage.setItem("__ml::aid", e);
        }, e.prototype.updateScopeInfoField = function(e, t) {
            this.reporter && this.reporter.scopeInfo[e] !== t && (this.reporter.scopeInfo[e] = t);
        }, e.prototype.initEnvInfo = function() {
            this.reporter && (this.envInfo = this.getEnvInfo());
        }, e;
    }();
    r.Adapter = n;
}, function(e) {
    return r({}[e], e);
}), t(1663577422815, function(e, t, r) {
    var o = this && this.__values || function(e) {
        var t = "function" == typeof Symbol && Symbol.iterator, r = t && e[t], n = 0;
        if (r) return r.call(e);
        if (e && "number" == typeof e.length) return {
            next: function() {
                return e && n >= e.length && (e = void 0), {
                    value: e && e[n++],
                    done: !e
                };
            }
        };
        throw new TypeError(t ? "Object is not iterable." : "Symbol.iterator is not defined.");
    }, i = this && this.__read || function(e, t) {
        var r = "function" == typeof Symbol && e[Symbol.iterator];
        if (!r) return e;
        var n, o, i = r.call(e), a = [];
        try {
            for (;(void 0 === t || t-- > 0) && !(n = i.next()).done; ) a.push(n.value);
        } catch (e) {
            o = {
                error: e
            };
        } finally {
            try {
                n && !n.done && (r = i.return) && r.call(i);
            } finally {
                if (o) throw o.error;
            }
        }
        return a;
    };
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), r.underline2HumpObjectKey = r.underline2Hump = r.hump2Underline = r.stringifyQuery = r.getQuery = r.uuidV4 = void 0;
    var a = e("./uuid");
    function l(e) {
        return /^[A-Z]/.test(e) ? e : e.replace(/([A-Z])/g, "_$1").toLowerCase();
    }
    function u(e) {
        return /^[A-Z]/.test(e) ? e : e.replace(/(_[a-z])/g, function(e, t) {
            return t.toUpperCase().slice(1);
        });
    }
    Object.defineProperty(r, "uuidV4", {
        enumerable: !0,
        get: function() {
            return a.uuidV4;
        }
    }), r.getQuery = function(e) {
        var t, r;
        void 0 === e && (e = location.href);
        var n = e.split("#")[0], a = n.includes("?") ? n.split("?")[1] : n, l = {};
        if (!a.includes("=")) return l;
        try {
            for (var u = o(a.split("&")), s = u.next(); !s.done; s = u.next()) {
                var c = s.value, f = i(c.split("="), 2), p = f[0], d = f[1];
                l[p] = d;
            }
        } catch (e) {
            t = {
                error: e
            };
        } finally {
            try {
                s && !s.done && (r = u.return) && r.call(u);
            } finally {
                if (t) throw t.error;
            }
        }
        return l;
    }, r.stringifyQuery = function(e, t) {
        return void 0 === t && (t = !0), Object.entries(e).filter(function(e) {
            var t = i(e, 2), r = (t[0], t[1]);
            return null != r;
        }).map(function(e) {
            var r = i(e, 2), n = r[0], o = r[1];
            return "".concat(t ? l(n) : n, "=").concat(o);
        }).join("&");
    }, r.hump2Underline = l, r.underline2Hump = u, r.underline2HumpObjectKey = function(e) {
        return "object" !== n(e) ? e : Object.fromEntries(Object.entries(e).map(function(e) {
            var t = i(e, 2), r = t[0], n = t[1];
            return [ u(r), n ];
        }));
    };
}, function(e) {
    return r({
        "./uuid": 1663577422816
    }[e], e);
}), t(1663577422816, function(e, t, r) {
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), r.uuidV4 = void 0, r.uuidV4 = function() {
        try {
            var e = crypto;
            if (null == e ? void 0 : e.randomUUID) return e.randomUUID();
            if ((null == e ? void 0 : e.getRandomValues) && Uint8Array) return "10000000-1000-4000-8000-100000000000".replace(/[018]/g, function(t) {
                return (Number(t) ^ e.getRandomValues(new Uint8Array(1))[0] & 15 >> Number(t) / 4).toString(16);
            });
        } catch (e) {}
        return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(e) {
            var t = 16 * Math.random() | 0;
            return ("x" === e ? t : 3 & t | 8).toString(16);
        });
    };
}, function(e) {
    return r({}[e], e);
}), t(1663577422817, function(e, t, r) {
    var n, o = this && this.__extends || (n = function(e, t) {
        return (n = Object.setPrototypeOf || {
            __proto__: []
        } instanceof Array && function(e, t) {
            e.__proto__ = t;
        } || function(e, t) {
            for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (e[r] = t[r]);
        })(e, t);
    }, function(e, t) {
        if ("function" != typeof t && null !== t) throw new TypeError("Class extends value ".concat(String(t), " is not a constructor or null"));
        function r() {
            this.constructor = e;
        }
        n(e, t), e.prototype = null === t ? Object.create(t) : (r.prototype = t.prototype, 
        new r());
    }), i = this && this.__assign || function() {
        return (i = Object.assign || function(e) {
            for (var t, r = 1, n = arguments.length; r < n; r++) for (var o in t = arguments[r]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
            return e;
        }).apply(this, arguments);
    };
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), r.WebAdapter = void 0;
    var a = e("../Adapter"), l = e("../utils"), u = function(e) {
        function t() {
            var t = null !== e && e.apply(this, arguments) || this;
            return t.storage = {
                supportSync: !0,
                setItem: function(e, t) {
                    (null === window || void 0 === window ? void 0 : window.localStorage) && null != t && window.localStorage.setItem(e, JSON.stringify(t));
                },
                getItem: function(e, t) {
                    if (!(null === window || void 0 === window ? void 0 : window.localStorage)) return t;
                    var r = window.localStorage.getItem(e);
                    if (null == r) return t;
                    try {
                        return JSON.parse(r);
                    } catch (e) {
                        return r || t;
                    }
                },
                removeItem: function(e) {
                    (null === window || void 0 === window ? void 0 : window.localStorage) && window.localStorage.removeItem(e);
                }
            }, t.handleBeforeUnload = t.settleReporter.bind(t), t.handlePageHide = t.settleReporter.bind(t), 
            t.handleOffline = t.privateHandleOffline.bind(t), t.handleOnline = t.privateHandleOnline.bind(t), 
            t;
        }
        return o(t, e), t.prototype.init = function(t) {
            e.prototype.init.call(this, t), window ? (window.addEventListener("beforeunload", this.handleBeforeUnload), 
            window.addEventListener("pagehide", this.handlePageHide), window.addEventListener("online", this.handleOnline), 
            window.addEventListener("offline", this.handleOffline)) : console.error("[Merlin] WebAdapter can only be used in web environment (with window defined)");
        }, t.prototype.settle = function() {}, t.prototype.updateScopeInfo = function() {
            this.reporter && window && (this.updateScopeInfoField("clientHeight", window.innerHeight), 
            this.updateScopeInfoField("clientWidth", window.innerWidth), this.updateScopeInfoField("screenHeight", window.screen.availHeight), 
            this.updateScopeInfoField("screenWidth", window.screen.availWidth), this.updateScopeInfoField("devicePixelRatio", window.devicePixelRatio), 
            this.updateScopeInfoField("href", window.location.href));
        }, t.prototype.readLinkedData = function() {
            var e;
            if (this.reporter && window) {
                var t = (0, l.underline2HumpObjectKey)((0, l.getQuery)());
                t.contextId && this.updateScopeInfoField("contextId", t.contextId), t.entranceId && this.updateScopeInfoField("entranceId", t.entranceId), 
                (null === (e = this.reporter.scopeInfo.entranceInfo) || void 0 === e ? void 0 : e.subEntranceid) !== t.subEntranceid && (this.reporter.scopeInfo.entranceInfo = {
                    subEntranceid: t.subEntranceid
                }), t.reddotId && this.updateScopeInfoField("redDotInfo", {
                    id: t.reddotId
                }), t.fromAccessId && this.updateScopeInfoField("fromAccessId", t.fromAccessId), 
                t.fromElementId && this.updateScopeInfoField("fromElementId", t.fromElementId);
            }
        }, Object.defineProperty(t.prototype, "linkedData", {
            get: function() {
                var e, t, r, n, o, i;
                return {
                    contextId: null === (e = this.reporter) || void 0 === e ? void 0 : e.scopeInfo.contextId,
                    entranceId: null === (t = this.reporter) || void 0 === t ? void 0 : t.scopeInfo.entranceId,
                    subEntranceid: null === (n = null === (r = this.reporter) || void 0 === r ? void 0 : r.scopeInfo.entranceInfo) || void 0 === n ? void 0 : n.subEntranceid,
                    reddotId: null === (i = null === (o = this.reporter) || void 0 === o ? void 0 : o.scopeInfo.redDotInfo) || void 0 === i ? void 0 : i.id
                };
            },
            enumerable: !1,
            configurable: !0
        }), t.prototype.serializeLinkedData = function(e) {
            return (0, l.stringifyQuery)(i(i({}, this.linkedData), e));
        }, t.prototype.httpPost = function(e, t, r) {
            var n;
            if ("function" == typeof (null === navigator || void 0 === navigator ? void 0 : navigator.sendBeacon)) try {
                if (navigator.sendBeacon(e, new Blob([ t ], {
                    type: r.contentType
                }))) return;
            } catch (e) {}
            null === (n = null == this ? void 0 : this.reporter) || void 0 === n || n.log("未能使用 sendBeacon 发送数据，使用 fetch"), 
            fetch(e, {
                method: "POST",
                headers: {
                    "Content-Type": r.contentType
                },
                body: t
            });
        }, t.prototype.getEnvInfo = function() {
            return window ? {
                userAgent: window.navigator.userAgent
            } : {};
        }, t.prototype.settleReporter = function() {
            var e, t = this;
            null === (e = this.reporter) || void 0 === e || e.settle().then(function() {
                var e;
                null === (e = t.reporter) || void 0 === e || e.log("Reporter 清算结束");
            });
        }, t.prototype.privateHandleOffline = function() {
            var e;
            null === (e = this.reporter) || void 0 === e || e.enableBuffering();
        }, t.prototype.privateHandleOnline = function() {
            var e;
            null === (e = this.reporter) || void 0 === e || e.settleBuffering();
        }, t;
    }(a.Adapter);
    r.WebAdapter = u;
}, function(e) {
    return r({
        "../Adapter": 1663577422814,
        "../utils": 1663577422815
    }[e], e);
}), t(1663577422818, function(e, t, r) {
    var n, o = this && this.__extends || (n = function(e, t) {
        return (n = Object.setPrototypeOf || {
            __proto__: []
        } instanceof Array && function(e, t) {
            e.__proto__ = t;
        } || function(e, t) {
            for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (e[r] = t[r]);
        })(e, t);
    }, function(e, t) {
        if ("function" != typeof t && null !== t) throw new TypeError("Class extends value ".concat(String(t), " is not a constructor or null"));
        function r() {
            this.constructor = e;
        }
        n(e, t), e.prototype = null === t ? Object.create(t) : (r.prototype = t.prototype, 
        new r());
    }), i = this && this.__assign || function() {
        return (i = Object.assign || function(e) {
            for (var t, r = 1, n = arguments.length; r < n; r++) for (var o in t = arguments[r]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
            return e;
        }).apply(this, arguments);
    }, a = this && this.__awaiter || function(e, t, r, n) {
        return new (r || (r = Promise))(function(o, i) {
            function a(e) {
                try {
                    u(n.next(e));
                } catch (e) {
                    i(e);
                }
            }
            function l(e) {
                try {
                    u(n.throw(e));
                } catch (e) {
                    i(e);
                }
            }
            function u(e) {
                var t;
                e.done ? o(e.value) : (t = e.value, t instanceof r ? t : new r(function(e) {
                    e(t);
                })).then(a, l);
            }
            u((n = n.apply(e, t || [])).next());
        });
    }, l = this && this.__generator || function(e, t) {
        var r, n, o, i, a = {
            label: 0,
            sent: function() {
                if (1 & o[0]) throw o[1];
                return o[1];
            },
            trys: [],
            ops: []
        };
        return i = {
            next: l(0),
            throw: l(1),
            return: l(2)
        }, "function" == typeof Symbol && (i[Symbol.iterator] = function() {
            return this;
        }), i;
        function l(i) {
            return function(l) {
                return function(i) {
                    if (r) throw new TypeError("Generator is already executing.");
                    for (;a; ) try {
                        if (r = 1, n && (o = 2 & i[0] ? n.return : i[0] ? n.throw || ((o = n.return) && o.call(n), 
                        0) : n.next) && !(o = o.call(n, i[1])).done) return o;
                        switch (n = 0, o && (i = [ 2 & i[0], o.value ]), i[0]) {
                          case 0:
                          case 1:
                            o = i;
                            break;

                          case 4:
                            return a.label++, {
                                value: i[1],
                                done: !1
                            };

                          case 5:
                            a.label++, n = i[1], i = [ 0 ];
                            continue;

                          case 7:
                            i = a.ops.pop(), a.trys.pop();
                            continue;

                          default:
                            if (!((o = (o = a.trys).length > 0 && o[o.length - 1]) || 6 !== i[0] && 2 !== i[0])) {
                                a = 0;
                                continue;
                            }
                            if (3 === i[0] && (!o || i[1] > o[0] && i[1] < o[3])) {
                                a.label = i[1];
                                break;
                            }
                            if (6 === i[0] && a.label < o[1]) {
                                a.label = o[1], o = i;
                                break;
                            }
                            if (o && a.label < o[2]) {
                                a.label = o[2], a.ops.push(i);
                                break;
                            }
                            o[2] && a.ops.pop(), a.trys.pop();
                            continue;
                        }
                        i = t.call(e, a);
                    } catch (e) {
                        i = [ 6, e ], n = 0;
                    } finally {
                        r = o = 0;
                    }
                    if (5 & i[0]) throw i[1];
                    return {
                        value: i[0] ? i[1] : void 0,
                        done: !0
                    };
                }([ i, l ]);
            };
        }
    };
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), r.MiniProgramAdapter = void 0;
    var u = e("../Adapter"), s = e("../utils"), c = function(e) {
        function t() {
            var t = null !== e && e.apply(this, arguments) || this;
            return t.storage = {
                supportSync: !0,
                setItem: function(e, t) {
                    if ((null === wx || void 0 === wx ? void 0 : wx.setStorageSync) && null != t) try {
                        wx.setStorageSync(e, t);
                    } catch (e) {}
                },
                getItem: function(e, t) {
                    return a(this, void 0, void 0, function() {
                        var r;
                        return l(this, function(n) {
                            if (!(null === wx || void 0 === wx ? void 0 : wx.getStorageSync)) return [ 2, t ];
                            try {
                                return null == (r = wx.getStorageSync(e)) ? [ 2, t ] : [ 2, r ];
                            } catch (e) {
                                return console.error("[Merlin] getItem failed", e), [ 2, t ];
                            }
                            return [ 2 ];
                        });
                    });
                },
                removeItem: function(e) {
                    (null === wx || void 0 === wx ? void 0 : wx.removeStorageSync) && wx.removeStorageSync(e);
                }
            }, t;
        }
        return o(t, e), t.prototype.init = function(t) {
            e.prototype.init.call(this, t), wx || console.error("[Merlin] MiniProgramAdapter can only be used in Weixin MiniProgram environment (with wx defined)");
        }, t.prototype.settle = function() {}, t.prototype.updateScopeInfo = function() {
            if (this.reporter && wx) {
                var e = wx.getSystemInfoSync();
                this.updateScopeInfoField("devicePixelRatio", e.pixelRatio);
            }
        }, t.prototype.readLinkedData = function(e) {
            this.reporter && wx;
        }, Object.defineProperty(t.prototype, "linkedData", {
            get: function() {
                var e, t, r, n, o, i;
                return {
                    contextId: null === (e = this.reporter) || void 0 === e ? void 0 : e.scopeInfo.contextId,
                    entranceId: null === (t = this.reporter) || void 0 === t ? void 0 : t.scopeInfo.entranceId,
                    subEntranceid: null === (n = null === (r = this.reporter) || void 0 === r ? void 0 : r.scopeInfo.entranceInfo) || void 0 === n ? void 0 : n.subEntranceid,
                    reddotId: null === (i = null === (o = this.reporter) || void 0 === o ? void 0 : o.scopeInfo.redDotInfo) || void 0 === i ? void 0 : i.id
                };
            },
            enumerable: !1,
            configurable: !0
        }), t.prototype.serializeLinkedData = function(e) {
            return (0, s.stringifyQuery)(i(i({}, this.linkedData), e));
        }, t.prototype.httpPost = function(e, t, r) {}, t.prototype.getEnvInfo = function() {
            if (!wx) return {};
            var e = wx.getSystemInfoSync();
            return {
                deviceBrand: e.brand,
                deviceModel: e.model,
                osName: e.platform,
                osVersion: "".concat(e.system),
                lang: e.language,
                appVersion: e.version
            };
        }, t;
    }(u.Adapter);
    r.MiniProgramAdapter = c;
}, function(e) {
    return r({
        "../Adapter": 1663577422814,
        "../utils": 1663577422815
    }[e], e);
}), t(1663577422819, function(e, t, r) {
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), r.ReportItemType = void 0, function(e) {
        e.ERROR = "error", e.BEHAVIOR = "behavior", e.PERFORMANCE = "perf";
    }(r.ReportItemType || (r.ReportItemType = {}));
}, function(e) {
    return r({}[e], e);
}), t(1663577422820, function(e, t, r) {
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
}, function(e) {
    return r({}[e], e);
}), t(1663577422821, function(e, t, r) {
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), r.ConsoleTransport = void 0;
    var n = e("./ConsoleTransport");
    Object.defineProperty(r, "ConsoleTransport", {
        enumerable: !0,
        get: function() {
            return n.ConsoleTransport;
        }
    });
}, function(e) {
    return r({
        "./ConsoleTransport": 1663577422822
    }[e], e);
}), t(1663577422822, function(e, t, r) {
    var n, o = this && this.__extends || (n = function(e, t) {
        return (n = Object.setPrototypeOf || {
            __proto__: []
        } instanceof Array && function(e, t) {
            e.__proto__ = t;
        } || function(e, t) {
            for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (e[r] = t[r]);
        })(e, t);
    }, function(e, t) {
        if ("function" != typeof t && null !== t) throw new TypeError("Class extends value ".concat(String(t), " is not a constructor or null"));
        function r() {
            this.constructor = e;
        }
        n(e, t), e.prototype = null === t ? Object.create(t) : (r.prototype = t.prototype, 
        new r());
    }), i = this && this.__assign || function() {
        return (i = Object.assign || function(e) {
            for (var t, r = 1, n = arguments.length; r < n; r++) for (var o in t = arguments[r]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
            return e;
        }).apply(this, arguments);
    }, a = this && this.__read || function(e, t) {
        var r = "function" == typeof Symbol && e[Symbol.iterator];
        if (!r) return e;
        var n, o, i = r.call(e), a = [];
        try {
            for (;(void 0 === t || t-- > 0) && !(n = i.next()).done; ) a.push(n.value);
        } catch (e) {
            o = {
                error: e
            };
        } finally {
            try {
                n && !n.done && (r = i.return) && r.call(i);
            } finally {
                if (o) throw o.error;
            }
        }
        return a;
    }, l = this && this.__spreadArray || function(e, t, r) {
        if (r || 2 === arguments.length) for (var n, o = 0, i = t.length; o < i; o++) !n && o in t || (n || (n = Array.prototype.slice.call(t, 0, o)), 
        n[o] = t[o]);
        return e.concat(n || Array.prototype.slice.call(t));
    };
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), r.ConsoleTransport = void 0;
    var u = function(e) {
        function t(t) {
            var r = e.call(this, i({
                flushInterval: 0,
                bufferSize: 0
            }, t)) || this;
            return r.prefix = "[Merlin Log]", r.parser = null, r.method = "log", (null == t ? void 0 : t.prefix) && (r.prefix = t.prefix), 
            (null == t ? void 0 : t.parser) && (r.parser = t.parser), (null == t ? void 0 : t.method) && (r.method = t.method), 
            r;
        }
        return o(t, e), t.prototype.print = function() {
            for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
            "info" === this.method ? console.info.apply(console, l([], a(e), !1)) : console.log.apply(console, l([], a(e), !1));
        }, t.prototype.send = function(e) {
            var t = this;
            e.forEach(function(e) {
                t.parser ? t.print("".concat(t.prefix, "[").concat(e.type, "]").concat(new Date(e.ctime).toLocaleString()), t.parser(e)) : t.print("".concat(t.prefix, "[").concat(e.type, "]").concat(new Date(e.ctime).toLocaleString()), e.context, e.data);
            });
        }, t;
    }(e("../Transport").Transport);
    r.ConsoleTransport = u;
}, function(e) {
    return r({
        "../Transport": 1663577422811
    }[e], e);
}), r(1663577422808));