require("../../../@babel/runtime/helpers/Arrayincludes"), require("../../../@babel/runtime/helpers/Objectentries");

var e, t, r, o = require("../../../@babel/runtime/helpers/typeof");

module.exports = (e = {}, r = function(t, r) {
    if (!e[t]) return require(r);
    if (!e[t].status) {
        var n = e[t].m;
        n._exports = n._tempexports;
        var a = Object.getOwnPropertyDescriptor(n, "exports");
        a && a.configurable && Object.defineProperty(n, "exports", {
            set: function(e) {
                "object" === o(e) && e !== n._exports && (n._exports.__proto__ = e.__proto__, Object.keys(e).forEach(function(t) {
                    n._exports[t] = e[t];
                })), n._tempexports = e;
            },
            get: function() {
                return n._tempexports;
            }
        }), e[t].status = 1, e[t].func(e[t].req, n, n.exports);
    }
    return e[t].m.exports;
}, (t = function(t, r, o) {
    e[t] = {
        status: 0,
        func: r,
        req: o,
        m: {
            exports: {},
            _tempexports: {}
        }
    };
})(1663577422802, function(e, t, r) {
    var o = this && this.__createBinding || (Object.create ? function(e, t, r, o) {
        void 0 === o && (o = r), Object.defineProperty(e, o, {
            enumerable: !0,
            get: function() {
                return t[r];
            }
        });
    } : function(e, t, r, o) {
        void 0 === o && (o = r), e[o] = t[r];
    }), n = this && this.__exportStar || function(e, t) {
        for (var r in e) "default" === r || Object.prototype.hasOwnProperty.call(t, r) || o(t, e, r);
    };
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), r.behaviorReporter = r.BehaviorReporter = void 0;
    var a = e("./BehaviorReporter");
    Object.defineProperty(r, "BehaviorReporter", {
        enumerable: !0,
        get: function() {
            return a.BehaviorReporter;
        }
    }), Object.defineProperty(r, "behaviorReporter", {
        enumerable: !0,
        get: function() {
            return a.behaviorReporter;
        }
    }), n(e("./utils"), r), n(e("./common"), r), n(e("./types"), r), r.default = a.behaviorReporter;
}, function(e) {
    return r({
        "./BehaviorReporter": 1663577422803,
        "./utils": 1663577422805,
        "./common": 1663577422806,
        "./types": 1663577422807
    }[e], e);
}), t(1663577422803, function(e, t, r) {
    var o, n = this && this.__extends || (o = function(e, t) {
        return (o = Object.setPrototypeOf || {
            __proto__: []
        } instanceof Array && function(e, t) {
            e.__proto__ = t;
        } || function(e, t) {
            for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (e[r] = t[r]);
        })(e, t);
    }, function(e, t) {
        if ("function" != typeof t && null !== t) throw new TypeError("Class extends value ".concat(String(t), " is not a constructor or null"));
        function r() {
            this.constructor = e;
        }
        o(e, t), e.prototype = null === t ? Object.create(t) : (r.prototype = t.prototype, 
        new r());
    }), a = this && this.__assign || function() {
        return (a = Object.assign || function(e) {
            for (var t, r = 1, o = arguments.length; r < o; r++) for (var n in t = arguments[r]) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n]);
            return e;
        }).apply(this, arguments);
    }, i = this && this.__read || function(e, t) {
        var r = "function" == typeof Symbol && e[Symbol.iterator];
        if (!r) return e;
        var o, n, a = r.call(e), i = [];
        try {
            for (;(void 0 === t || t-- > 0) && !(o = a.next()).done; ) i.push(o.value);
        } catch (e) {
            n = {
                error: e
            };
        } finally {
            try {
                o && !o.done && (r = a.return) && r.call(a);
            } finally {
                if (n) throw n.error;
            }
        }
        return i;
    }, p = this && this.__spreadArray || function(e, t, r) {
        if (r || 2 === arguments.length) for (var o, n = 0, a = t.length; n < a; n++) !o && n in t || (o || (o = Array.prototype.slice.call(t, 0, n)), 
        o[n] = t[n]);
        return e.concat(o || Array.prototype.slice.call(t));
    };
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), r.behaviorReporter = r.BehaviorReporter = void 0;
    var c = e("@tencent/merlin-core"), s = e("./PageManager"), u = e("./common"), l = function(e) {
        function t() {
            var t = null !== e && e.apply(this, arguments) || this;
            return t.pageStackStorageLimit = 20, t.pageManager = new s.PageManager(t), t;
        }
        return n(t, e), t.prototype.setOptions = function(t) {
            void 0 !== t.pageStackStorageLimit && (this.pageStackStorageLimit = t.pageStackStorageLimit), 
            e.prototype.setOptions.call(this, t);
        }, t.prototype.init = function(t) {
            try {
                this.setOptions(t), this.pageManager.init(), e.prototype.init.call(this, t);
            } catch (e) {
                this.errorHandler(e);
            }
        }, Object.defineProperty(t.prototype, "serializeLinkedData", {
            get: function() {
                var e, t;
                return (null === (e = this.adapter) || void 0 === e ? void 0 : e.serializeLinkedData({
                    fromAccessId: null === (t = this.pageManager.currentPage) || void 0 === t ? void 0 : t.accessId
                })) || "";
            },
            enumerable: !1,
            configurable: !0
        }), t.prototype.loadPage = function() {
            return this.pageManager.load();
        }, t.prototype.pushPage = function() {
            for (var e, t = [], r = 0; r < arguments.length; r++) t[r] = arguments[r];
            (e = this.pageManager).push.apply(e, p([], i(t), !1));
        }, t.prototype.updatePage = function() {
            for (var e, t = this, r = [], o = 0; o < arguments.length; o++) r[o] = arguments[o];
            (e = this.pageManager).updatePageInfo.apply(e, p([], i(r), !1)), this.buffering && (this.buffer = this.buffer.map(function(e) {
                return a(a({}, e), {
                    context: a(a({}, e.context), {
                        scope: a(a({}, e.context.scope), t.pageManager.getPageInfo())
                    })
                });
            }));
        }, t.prototype.reportCustom = function(e) {
            this.report({
                type: c.ReportItemType.BEHAVIOR,
                data: a(a({}, e), {
                    behaviorType: u.BehaviorType.CUSTOM
                })
            });
        }, t.prototype.reportElementHover = function(e) {
            this.report({
                type: c.ReportItemType.BEHAVIOR,
                data: a(a({}, e), {
                    behaviorType: u.BehaviorType.ELEMENT_HOVER
                })
            });
        }, t.prototype.reportElementClick = function(e) {
            this.report({
                type: c.ReportItemType.BEHAVIOR,
                data: a(a({}, e), {
                    behaviorType: u.BehaviorType.ELEMENT_CLICK
                })
            });
        }, t.prototype.reportElementExpose = function(e) {
            this.report({
                type: c.ReportItemType.BEHAVIOR,
                data: a(a({}, e), {
                    behaviorType: u.BehaviorType.ELEMENT_EXPOSE
                })
            });
        }, t.prototype.reportElementConceal = function(e) {
            this.report({
                type: c.ReportItemType.BEHAVIOR,
                data: a(a({}, e), {
                    behaviorType: u.BehaviorType.ELEMENT_CONCEAL
                })
            });
        }, t.prototype.reportPageEnter = function(e) {
            this.report({
                type: c.ReportItemType.BEHAVIOR,
                data: a(a({}, e), {
                    behaviorType: u.BehaviorType.PAGE_ENTER
                })
            });
        }, t.prototype.reportPageLeave = function(e) {
            this.report({
                type: c.ReportItemType.BEHAVIOR,
                data: a(a({}, e), {
                    behaviorType: u.BehaviorType.PAGE_LEAVE
                })
            });
        }, t.prototype.reportVideoPlayStart = function(e) {
            this.report({
                type: c.ReportItemType.BEHAVIOR,
                data: a(a({}, e), {
                    behaviorType: u.BehaviorType.VIDEO_PLAY_START
                })
            });
        }, t.prototype.reportVideoPlayWaiting = function(e) {
            this.report({
                type: c.ReportItemType.BEHAVIOR,
                data: a(a({}, e), {
                    behaviorType: u.BehaviorType.VIDEO_PLAY_WAITING
                })
            });
        }, t.prototype.reportVideoPlayPause = function(e) {
            this.report({
                type: c.ReportItemType.BEHAVIOR,
                data: a(a({}, e), {
                    behaviorType: u.BehaviorType.VIDEO_PLAY_PAUSE
                })
            });
        }, t.prototype.reportVideoPlaySeek = function(e) {
            this.report({
                type: c.ReportItemType.BEHAVIOR,
                data: a(a({}, e), {
                    behaviorType: u.BehaviorType.VIDEO_PLAY_SEEK
                })
            });
        }, t.prototype.reportVideoPlayFinish = function(e) {
            this.report({
                type: c.ReportItemType.BEHAVIOR,
                data: a(a({}, e), {
                    behaviorType: u.BehaviorType.VIDEO_PLAY_FINISH
                })
            });
        }, t.prototype.getContext = function() {
            var e;
            return {
                base: this.baseContext,
                env: (null === (e = this.adapter) || void 0 === e ? void 0 : e.envInfo) || {},
                scope: a(a({}, this.scopeContext), this.pageManager.getPageInfo())
            };
        }, t;
    }(c.Reporter);
    r.BehaviorReporter = l, r.behaviorReporter = new l();
}, function(e) {
    return r({
        "./PageManager": 1663577422804,
        "./common": 1663577422806
    }[e], e);
}), t(1663577422804, function(e, t, r) {
    var n = this && this.__read || function(e, t) {
        var r = "function" == typeof Symbol && e[Symbol.iterator];
        if (!r) return e;
        var o, n, a = r.call(e), i = [];
        try {
            for (;(void 0 === t || t-- > 0) && !(o = a.next()).done; ) i.push(o.value);
        } catch (e) {
            n = {
                error: e
            };
        } finally {
            try {
                o && !o.done && (r = a.return) && r.call(a);
            } finally {
                if (n) throw n.error;
            }
        }
        return i;
    }, a = this && this.__spreadArray || function(e, t, r) {
        if (r || 2 === arguments.length) for (var o, n = 0, a = t.length; n < a; n++) !o && n in t || (o || (o = Array.prototype.slice.call(t, 0, n)), 
        o[n] = t[n]);
        return e.concat(o || Array.prototype.slice.call(t));
    };
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), r.PageManager = void 0;
    var i = e("@tencent/merlin-core"), p = e("./utils"), c = function() {
        function e(e, t) {
            var r;
            void 0 === t && (t = p.DEFAULT_PAGE_KEY), this.reporter = e, this.pageKey = t, (null === (r = globalThis.localStorage) || void 0 === r ? void 0 : r.getItem("__ml_storage__queue")) && Object.keys(globalThis.localStorage).forEach(function(e) {
                ("__ml_storage__queue" === e || e.endsWith("__ml_storage__page")) && globalThis.localStorage.removeItem(e);
            });
        }
        return e.prototype.push = function(e, t) {
            this.reporter.readLinkedData();
            var r = this.load();
            this.currentPage = r ? {
                name: e.name,
                accessId: (0, i.uuidV4)(),
                step: r.step + 1,
                refAccessId: r.accessId,
                refPageName: r.name,
                fromElementId: t,
                extInfo: e.extInfo
            } : {
                name: e.name,
                accessId: (0, i.uuidV4)(),
                step: 1,
                extInfo: e.extInfo
            }, this.save();
        }, e.prototype.getPageInfo = function() {
            if (!this.currentPage) throw new Error("currentPage not found");
            return {
                pageName: this.currentPage.name,
                refPageName: this.currentPage.refPageName,
                accessId: this.currentPage.accessId,
                refAccessId: this.currentPage.refAccessId,
                fromElementId: this.currentPage.fromElementId,
                step: this.currentPage.step,
                extInfo: this.currentPage.extInfo
            };
        }, e.prototype.updatePageInfo = function(e) {
            this.currentPage ? this.currentPage.extInfo = e : this.reporter.errorHandler(new Error("currentPage not found"));
        }, e.prototype.init = function() {
            this.load();
        }, Object.defineProperty(e.prototype, "contextId", {
            get: function() {
                return this.reporter.scopeInfo.contextId;
            },
            enumerable: !1,
            configurable: !0
        }), e.prototype.load = function() {
            var e = this;
            if (this.reporter.supportSyncStorage) {
                var t = this.reporter.getStorageItem(this.pageKey, []);
                localStorage && t && Object.keys(localStorage).forEach(function(r) {
                    r.startsWith("".concat(e.pageKey, "_")) && !t.includes(r.replace("".concat(e.pageKey, "_"), "")) && (e.reporter.log("删除遗留页面栈 ".concat(r)), 
                    e.reporter.removeStorageItem(r));
                });
                var r = this.reporter.getStorageItem(this.getStorageKey(this.contextId), void 0);
                return r && "object" === o(r) && Object.prototype.hasOwnProperty.call(r, "accessId") && Object.prototype.hasOwnProperty.call(r, "name") && Object.prototype.hasOwnProperty.call(r, "step") ? r : void 0;
            }
        }, e.prototype.getStorageKey = function(e) {
            return void 0 === e && (e = this.contextId), "".concat(this.pageKey, "_").concat(e || "");
        }, e.prototype.save = function() {
            var e;
            if (this.reporter.supportSyncStorage && this.currentPage && this.contextId) try {
                var t = this.reporter.getStorageItem(this.pageKey, []);
                if (this.reporter.log("读取回收队列", t), t.includes(this.contextId)) t.indexOf(this.contextId) !== t.length - 1 && (t.splice(t.indexOf(this.contextId), 1), 
                t.push(this.contextId), this.reporter.log("contextId 更新至队尾", t), this.reporter.setStorageItem(this.pageKey, t)); else {
                    if (t.length >= this.reporter.pageStackStorageLimit) {
                        var r = t.shift();
                        r && (this.reporter.log("存储超过上限，出队", r), this.reporter.removeStorageItem(this.getStorageKey(r)));
                    }
                    t.push(this.contextId), this.reporter.log("更新队列", t), this.reporter.setStorageItem(this.pageKey, t);
                }
                this.reporter.log("写入新的 contextId", this.contextId), this.reporter.setStorageItem(this.getStorageKey(this.contextId), {
                    name: this.currentPage.name,
                    accessId: this.currentPage.accessId,
                    step: this.currentPage.step,
                    refAccessId: this.currentPage.refAccessId,
                    fromElementId: this.currentPage.fromElementId,
                    refPageName: this.currentPage.refPageName
                });
            } catch (r) {
                if (22 === (null == r ? void 0 : r.code) || (null === (e = null == r ? void 0 : r.message) || void 0 === e ? void 0 : e.toLowerCase().includes("quota"))) {
                    t = this.reporter.getStorageItem(this.pageKey, []);
                    var o = Math.floor(t.length / 2), n = this.recycleStorage(t, o);
                    this.reporter.setStorageItem(this.pageKey, n);
                }
            }
        }, e.prototype.recycleStorage = function(e, t) {
            var r = this;
            if (e.length <= t) return e;
            this.reporter.log("回收页面栈开始，当前队列长度 ".concat(e.length));
            var o = a([], n(e), !1);
            return o.splice(t).forEach(function(e) {
                r.reporter.log("删除页面栈 ".concat(e)), r.reporter.removeStorageItem(r.getStorageKey(e));
            }), this.reporter.log("回收页面栈结束，当前队列长度 ".concat(o.length)), o;
        }, e;
    }();
    r.PageManager = c;
}, function(e) {
    return r({
        "./utils": 1663577422805
    }[e], e);
}), t(1663577422805, function(e, t, r) {
    var n = this && this.__read || function(e, t) {
        var r = "function" == typeof Symbol && e[Symbol.iterator];
        if (!r) return e;
        var o, n, a = r.call(e), i = [];
        try {
            for (;(void 0 === t || t-- > 0) && !(o = a.next()).done; ) i.push(o.value);
        } catch (e) {
            n = {
                error: e
            };
        } finally {
            try {
                o && !o.done && (r = a.return) && r.call(a);
            } finally {
                if (n) throw n.error;
            }
        }
        return i;
    };
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), r.serializeKvReportValue = r.omit = r.DEFAULT_PAGE_KEY = void 0, r.DEFAULT_PAGE_KEY = "__ml::page", 
    r.omit = function(e, t) {
        return Object.fromEntries(Object.entries(e).filter(function(e) {
            var r = n(e, 1)[0];
            return !t.includes(r);
        }));
    }, r.serializeKvReportValue = function(e) {
        return e.map(function(e) {
            var t;
            try {
                return "string" == typeof e ? e.replace(/,/g, ";") : e && "object" === o(e) ? (null === (t = JSON.stringify(e)) || void 0 === t ? void 0 : t.replace(/,/g, ";")) || "" : (null == e ? void 0 : e.toString().replace(/,/g, ";")) || "";
            } catch (e) {
                return "";
            }
        }).join(",");
    };
}, function(e) {
    return r({}[e], e);
}), t(1663577422806, function(e, t, r) {
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), r.BehaviorType = void 0, function(e) {
        e.CUSTOM = "custom", e.PAGE_ENTER = "pageEnter", e.PAGE_LEAVE = "pageLeave", e.ELEMENT_EXPOSE = "elementExpose", 
        e.ELEMENT_CONCEAL = "elementConceal", e.ELEMENT_CLICK = "elementClick", e.ELEMENT_HOVER = "elementHover", 
        e.VIDEO_PLAY_START = "videoPlayStart", e.VIDEO_PLAY_PAUSE = "videoPlayPause", e.VIDEO_PLAY_WAITING = "videoPlayWaiting", 
        e.VIDEO_PLAY_SEEK = "videoPlaySeek", e.VIDEO_PLAY_FINISH = "videoPlayFinish";
    }(r.BehaviorType || (r.BehaviorType = {}));
}, function(e) {
    return r({}[e], e);
}), t(1663577422807, function(e, t, r) {
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
}, function(e) {
    return r({}[e], e);
}), r(1663577422802));