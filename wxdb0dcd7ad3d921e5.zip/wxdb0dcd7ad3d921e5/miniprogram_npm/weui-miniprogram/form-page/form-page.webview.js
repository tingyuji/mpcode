$gwx_XC_7=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}var __WXML_GLOBAL__={};{
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_7 || [];
__WXML_GLOBAL__.debuginfo_set = __WXML_GLOBAL__.debuginfo_set || {};
var debugInfo=__WXML_GLOBAL__.debuginfo_set.$gwx_XC_7 || [];
function gz$gwx_XC_7_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_7_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_7_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_7_1=[];
(function(z){var a=11;function Z(ops,debugLine){z.push(['11182016',ops,debugLine])}
Z([3,'weui-form'],['./miniprogram_npm/weui-miniprogram/form-page/form-page.wxml',1,12])
Z([[2,'||'],[[7],[3,'title']],[[7],[3,'subtitle']]],['./miniprogram_npm/weui-miniprogram/form-page/form-page.wxml',2,18])
Z([3,'weui-form__text-area'],['./miniprogram_npm/weui-miniprogram/form-page/form-page.wxml',3,19])
Z([3,'weui-form__title'],['./miniprogram_npm/weui-miniprogram/form-page/form-page.wxml',4,23])
Z([a,[[7],[3,'title']]],['./miniprogram_npm/weui-miniprogram/form-page/form-page.wxml',4,42])
Z([3,'weui-form__desc'],['./miniprogram_npm/weui-miniprogram/form-page/form-page.wxml',5,23])
Z([a,[[7],[3,'subtitle']]],['./miniprogram_npm/weui-miniprogram/form-page/form-page.wxml',5,41])
Z(z[2][1],['./miniprogram_npm/weui-miniprogram/form-page/form-page.wxml',9,19])
Z([3,'title'],['./miniprogram_npm/weui-miniprogram/form-page/form-page.wxml',10,20])
Z([3,'weui-form__control-area'],['./miniprogram_npm/weui-miniprogram/form-page/form-page.wxml',13,15])
Z([3,'weui-form__tips-area'],['./miniprogram_npm/weui-miniprogram/form-page/form-page.wxml',16,15])
Z([3,'tips'],['./miniprogram_npm/weui-miniprogram/form-page/form-page.wxml',17,16])
Z([3,'weui-form__opr-area'],['./miniprogram_npm/weui-miniprogram/form-page/form-page.wxml',19,15])
Z([3,'button'],['./miniprogram_npm/weui-miniprogram/form-page/form-page.wxml',20,16])
Z(z[10][1],['./miniprogram_npm/weui-miniprogram/form-page/form-page.wxml',22,15])
Z([3,'suffixtips'],['./miniprogram_npm/weui-miniprogram/form-page/form-page.wxml',23,16])
Z([3,'weui-form__extra-area'],['./miniprogram_npm/weui-miniprogram/form-page/form-page.wxml',25,15])
Z([3,'weui-footer'],['./miniprogram_npm/weui-miniprogram/form-page/form-page.wxml',26,17])
Z([3,'footer'],['./miniprogram_npm/weui-miniprogram/form-page/form-page.wxml',27,18])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_7_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_7_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_7=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_7=true;
__WXML_GLOBAL__.debuginfo_set.$gwx_XC_7=debugInfo;
var x=['./miniprogram_npm/weui-miniprogram/form-page/form-page.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_7_1()
var t5D=_n('view')
_rz(z,t5D,'class',0,e,s,gg)
var e6D=_v()
_(t5D,e6D)
if(_oz(z,1,e,s,gg)){e6D.wxVkey=1
var b7D=_n('view')
_rz(z,b7D,'class',2,e,s,gg)
var o8D=_n('view')
_rz(z,o8D,'class',3,e,s,gg)
var x9D=_oz(z,4,e,s,gg)
_(o8D,x9D)
_(b7D,o8D)
var o0D=_n('view')
_rz(z,o0D,'class',5,e,s,gg)
var fAE=_oz(z,6,e,s,gg)
_(o0D,fAE)
_(b7D,o0D)
_(e6D,b7D)
}
else{e6D.wxVkey=2
var cBE=_n('view')
_rz(z,cBE,'class',7,e,s,gg)
var hCE=_n('slot')
_rz(z,hCE,'name',8,e,s,gg)
_(cBE,hCE)
_(e6D,cBE)
}
var oDE=_n('view')
_rz(z,oDE,'class',9,e,s,gg)
var cEE=_n('slot')
_(oDE,cEE)
_(t5D,oDE)
var oFE=_n('view')
_rz(z,oFE,'class',10,e,s,gg)
var lGE=_n('slot')
_rz(z,lGE,'name',11,e,s,gg)
_(oFE,lGE)
_(t5D,oFE)
var aHE=_n('view')
_rz(z,aHE,'class',12,e,s,gg)
var tIE=_n('slot')
_rz(z,tIE,'name',13,e,s,gg)
_(aHE,tIE)
_(t5D,aHE)
var eJE=_n('view')
_rz(z,eJE,'class',14,e,s,gg)
var bKE=_n('slot')
_rz(z,bKE,'name',15,e,s,gg)
_(eJE,bKE)
_(t5D,eJE)
var oLE=_n('view')
_rz(z,oLE,'class',16,e,s,gg)
var xME=_n('view')
_rz(z,xME,'class',17,e,s,gg)
var oNE=_n('slot')
_rz(z,oNE,'name',18,e,s,gg)
_(xME,oNE)
_(oLE,xME)
_(t5D,oLE)
e6D.wxXCkey=1
_(r,t5D)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
window.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_7";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(window.__webview_engine_version__)!='undefined'&&window.__webview_engine_version__+1e-6>=0.02+1e-6&&window.__mergeData__)
{
env=window.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(window.__webview_engine_version__)=='undefined'|| window.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_7();		__wxAppCode__['miniprogram_npm/weui-miniprogram/form-page/form-page.wxss'] = setCssToHead_wxfa43a4a7041a84de([],undefined,{path:"./miniprogram_npm/weui-miniprogram/form-page/form-page.wxss"});
		if (__vd_version_info__.delayedGwx) __wxAppCode__['miniprogram_npm/weui-miniprogram/form-page/form-page.wxml'] = [ $gwx_XC_7, './miniprogram_npm/weui-miniprogram/form-page/form-page.wxml' ];
		else __wxAppCode__['miniprogram_npm/weui-miniprogram/form-page/form-page.wxml'] = $gwx_XC_7( './miniprogram_npm/weui-miniprogram/form-page/form-page.wxml' );
		