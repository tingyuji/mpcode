var t, e, r = require("../../@babel/runtime/helpers/typeof");

module.exports = (t = {}, e = function(e, o) {
    if (!t[e]) return require(o);
    if (!t[e].status) {
        var n = t[e].m;
        n._exports = n._tempexports;
        var s = Object.getOwnPropertyDescriptor(n, "exports");
        s && s.configurable && Object.defineProperty(n, "exports", {
            set: function(t) {
                "object" === r(t) && t !== n._exports && (n._exports.__proto__ = t.__proto__, Object.keys(t).forEach(function(e) {
                    n._exports[e] = t[e];
                })), n._tempexports = t;
            },
            get: function() {
                return n._tempexports;
            }
        }), t[e].status = 1, t[e].func(t[e].req, n, n.exports);
    }
    return t[e].m.exports;
}, function(e, r, o) {
    t[e] = {
        status: 0,
        func: r,
        req: o,
        m: {
            exports: {},
            _tempexports: {}
        }
    };
}(1663577422823, function(t, e, r) {
    e.exports = function(t) {
        return {
            all: t = t || new Map(),
            on: function(e, r) {
                var o = t.get(e);
                o ? o.push(r) : t.set(e, [ r ]);
            },
            off: function(e, r) {
                var o = t.get(e);
                o && (r ? o.splice(o.indexOf(r) >>> 0, 1) : t.set(e, []));
            },
            emit: function(e, r) {
                var o = t.get(e);
                o && o.slice().map(function(t) {
                    t(r);
                }), (o = t.get("*")) && o.slice().map(function(t) {
                    t(e, r);
                });
            }
        };
    };
}, function(t) {
    return e({}[t], t);
}), e(1663577422823));