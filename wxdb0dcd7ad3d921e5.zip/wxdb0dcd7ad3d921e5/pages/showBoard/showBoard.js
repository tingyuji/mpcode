require("../../@babel/runtime/helpers/Arrayincludes");

var e = s(require("../../@babel/runtime/regenerator")), t = require("../../@babel/runtime/helpers/asyncToGenerator"), a = s(require("../../services/getPersonalEmojiSet")), n = s(require("@tencent/merlin-behavior")), r = s(require("../../utils/word")), o = require("../index/save");

function s(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

Page({
    pageName: "open_shared",
    data: {
        faceList: [],
        navBarHeight: getApp().globalData.navBarHeight,
        showLoading: !1,
        scene: -1,
        isMacWin: !1,
        context: "",
        showLoadingMore: !1,
        setkey: "",
        isEnd: !1
    },
    onLoad: function(n) {
        var r = this;
        return t(e.default.mark(function t() {
            var o, s, i, c, u;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if ([ "mac", "windows" ].includes(wx.getSystemInfoSync().platform) && r.setData({
                        isMacWin: !0
                    }), o = wx.getLaunchOptionsSync(), s = o.scene, r.setData({
                        scene: s,
                        showLoading: !0
                    }), 1155 === s && (getApp().globalData.pyqComing = !0), 1154 === s) {
                        e.next = 9;
                        break;
                    }
                    if (wx.getStorageSync("firstComing")) {
                        e.next = 9;
                        break;
                    }
                    return wx.redirectTo({
                        url: "../guide/guide"
                    }), e.abrupt("return");

                  case 9:
                    if (!n.setkey && !n.scene) {
                        e.next = 15;
                        break;
                    }
                    return e.next = 12, (0, a.default)({
                        setKey: null !== (i = n.setkey) && void 0 !== i ? i : n.scene,
                        context: r.data.context
                    });

                  case 12:
                    (u = e.sent).data.data.emojis.length < 12 && r.setData({
                        isEnd: !0
                    }), r.setData({
                        context: u.data.data.context,
                        faceList: u.data.data.emojis,
                        showLoading: !1,
                        setkey: null !== (c = n.setkey) && void 0 !== c ? c : n.scene
                    });

                  case 15:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    backHome: function() {
        n.default.reportElementClick({
            key: "begin_producing"
        }), getApp().globalData.canvasData = "", wx.redirectTo({
            url: "../emoji/emoji"
        });
    },
    scrolltolower: function() {
        var n = this;
        return t(e.default.mark(function t() {
            var r;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (!n.data.isEnd) {
                        e.next = 2;
                        break;
                    }
                    return e.abrupt("return");

                  case 2:
                    return n.setData({
                        showLoadingMore: !0
                    }), e.next = 5, (0, a.default)({
                        setKey: n.data.setkey,
                        context: n.data.context
                    });

                  case 5:
                    (r = e.sent).data.data.emojis.length < 12 && n.setData({
                        isEnd: !0
                    }), n.setData({
                        context: r.data.data.context,
                        faceList: n.data.faceList.concat(r.data.data.emojis),
                        showLoadingMore: !1
                    });

                  case 8:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    createshotPhoto: function() {
        var a = this;
        return t(e.default.mark(function t() {
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.abrupt("return", new Promise(function(e) {
                        wx.createSelectorQuery().select("#canvas").fields({
                            node: !0,
                            size: !0
                        }).exec(a.initCreateshotPhoto.bind(a, e));
                    }));

                  case 1:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    initCreateshotPhoto: function(a, n) {
        var r = this;
        return t(e.default.mark(function t() {
            var s, i, c;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return s = n[0].node, r.canvas = s, i = s.getContext("2d"), e.next = 5, (0, o.createTalkerImage)(i, s, r.data.faceList.map(function(e) {
                        return e.url ? e.url : "https://res.wx.qq.com/t/fed_upload/10fb5cee-1d45-4ace-936b-d1a70054863c/block.png";
                    }));

                  case 5:
                    return e.next = 7, r.onCreateshotPhoto();

                  case 7:
                    c = e.sent, r.setData({
                        shotPhotoPath: c
                    }), a(c);

                  case 10:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    onCreateshotPhoto: function() {
        var e = this;
        return new Promise(function(t) {
            var a = e.canvas.toDataURL("image/png"), n = wx.getFileSystemManager(), r = "".concat(wx.env.USER_DATA_PATH, "/").concat(Math.random().toString(36).substr(2), ".png");
            n.writeFile({
                filePath: r,
                data: a.split(",")[1],
                encoding: "base64",
                success: function() {
                    t(r);
                }
            });
        });
    },
    onShareAppMessage: function() {
        var a = this, n = (0, r.default)(), o = new Promise(function() {
            var n = t(e.default.mark(function t(n, r) {
                var o;
                return e.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return e.prev = 0, e.next = 3, a.createshotPhoto();

                      case 3:
                        o = e.sent, n({
                            imageUrl: o,
                            title: "快来看看我制作的表情",
                            path: "/pages/index/index?scene=sb_".concat(a.data.setkey)
                        }), e.next = 11;
                        break;

                      case 7:
                        e.prev = 7, e.t0 = e.catch(0), wx.showModal({
                            title: "提示",
                            content: "分享失败，请重试"
                        }), r("error");

                      case 11:
                      case "end":
                        return e.stop();
                    }
                }, t, null, [ [ 0, 7 ] ]);
            }));
            return function(e, t) {
                return n.apply(this, arguments);
            };
        }());
        return {
            title: n.word,
            path: "/pages/index/index",
            imageUrl: n.image,
            promise: o
        };
    },
    onShareTimeline: function() {}
});