require("../../@babel/runtime/helpers/Arrayincludes");

var t = n(require("../../@babel/runtime/regenerator")), a = require("../../@babel/runtime/helpers/asyncToGenerator"), e = n(require("../../utils/word")), i = n(require("@tencent/merlin-behavior")), r = n(require("../../utils/mergeQuery"));

function n(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

var s = require("../../libs/svgaplayer.weapp"), c = s.Parser, o = s.Player, h = require("../../services/setUserInfo"), u = require("../../constants/origin.js").ORIGVERSION, d = require("../../services/getUserInfo"), m = getApp();

Page({
    pageName: "emoji_new_user",
    data: {
        isShowCanvas: 1,
        imgWidth: 0,
        imgHeight: 0,
        imgTop: 0,
        endImgWidth: 0,
        endImgHeight: 0,
        endImgTop: 0,
        top: 0,
        left: 0,
        height: 0,
        width: 0,
        isShowStart: !0,
        state: 1,
        isAgree: !1,
        scene: -1,
        showImage: !1,
        newWidth: 0,
        newHeight: 0,
        newTop: 0,
        newLeft: 0,
        navBarHeight: m.globalData.navBarHeight,
        windowWidth: m.globalData.windowWidth,
        windowHeight: m.globalData.windowHeight + m.globalData.navBarHeight
    },
    onLoad: function(e) {
        var i = this;
        return a(t.default.mark(function a() {
            var n, s, c, o, h, g, f, p, l, w, x, v;
            return t.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (n = wx.getLaunchOptionsSync(), s = n.scene, i.setData({
                        scene: s
                    }), 1154 !== s) {
                        t.next = 4;
                        break;
                    }
                    return t.abrupt("return");

                  case 4:
                    if (wx.getStorageSync("firstComing")) {
                        t.next = 20;
                        break;
                    }
                    return t.next = 8, d();

                  case 8:
                    if (-100005 !== (null == (l = t.sent) || null === (c = l.data) || void 0 === c || null === (o = c.data) || void 0 === o ? void 0 : o.ret)) {
                        t.next = 15;
                        break;
                    }
                    return wx.setStorageSync("firstComing", !0), wx.setStorageSync("isBlock", !0), m.globalData.isBlock = !0, 
                    wx.redirectTo({
                        url: "../index/index"
                    }), t.abrupt("return");

                  case 15:
                    if ((null == l || null === (h = l.data) || void 0 === h || null === (g = h.data) || void 0 === g || null === (f = g.userInfo) || void 0 === f || null === (p = f.protocolInfo) || void 0 === p ? void 0 : p.origVersion) !== u) {
                        t.next = 20;
                        break;
                    }
                    return wx.setStorageSync("firstComing", !0), w = (0, r.default)(e), wx.redirectTo({
                        url: "../index/index?".concat(w)
                    }), t.abrupt("return");

                  case 20:
                    1155 != wx.getLaunchOptionsSync().scene || getApp().globalData.pyqComing || (getApp().globalData.pyqComing = !0, 
                    wx.redirectTo({
                        url: "../index/index"
                    })), wx.createSelectorQuery().select("#demoCanvas").fields({
                        node: !0,
                        size: !0
                    }).exec(i.init.bind(i)), x = wx.getSystemInfoSync(), v = x.windowWidth, x.windowHeight, 
                    i.setData({
                        imgWidth: v / 375 * 160,
                        imgHeight: v / 375 * 128,
                        imgTop: v / 375 * 146 - m.globalData.navBarHeight,
                        endImgWidth: v / 375 * 248,
                        endImgHeight: v / 375 * 200,
                        endImgTop: v / 375 * 224 - m.globalData.navBarHeight
                    });

                  case 24:
                  case "end":
                    return t.stop();
                }
            }, a);
        }))();
    },
    init: function(e) {
        var i = this;
        return a(t.default.mark(function r() {
            var n, s, c;
            return t.default.wrap(function(r) {
                for (;;) switch (r.prev = r.next) {
                  case 0:
                    n = e[0].node, s = n.getContext("2d"), c = wx.getSystemInfoSync().pixelRatio, i.dpr = c, 
                    n.height = e[0].height * c, n.width = e[0].width * c, s.scale(c, c), i.ctx = s, 
                    i.canvas = n, i.canvasTik = [ {
                        url: "https://res.wx.qq.com/t/fed_upload/a1aaf7ce-345f-42f2-bf85-c6c5bd7acf09/2.png",
                        x: e[0].width / 2 - 90,
                        y: e[0].height / 2 - 30,
                        width: 180,
                        height: 180,
                        ratio: 1,
                        options: {
                            opacity: 0
                        },
                        name: "tik1"
                    }, {
                        url: "https://res.wx.qq.com/t/fed_upload/dc41a35c-5765-4329-8913-e736ebdbfc52/19.png",
                        x: e[0].width / 2 - 10,
                        y: e[0].height / 2 - 210,
                        width: 75.6,
                        height: 11.76,
                        ratio: 180 / 28,
                        options: {
                            rotate: 5,
                            opacity: 0
                        },
                        name: "tik2"
                    }, {
                        url: "https://res.wx.qq.com/t/fed_upload/28abe040-df0f-4daf-b033-04ee02f4ba46/6.png",
                        x: e[0].width / 2 - 120,
                        y: e[0].height / 2 - 218,
                        width: 80,
                        height: 53.7,
                        ratio: 180 / 127,
                        options: {
                            opacity: 0
                        },
                        name: "tik3"
                    }, {
                        url: "https://res.wx.qq.com/t/fed_upload/3c724c77-d065-40db-8f69-863c1ba45cce/31.png",
                        x: e[0].width / 2 - 130,
                        y: e[0].height / 2 - 195,
                        width: 80,
                        height: 80,
                        ratio: 1,
                        name: "tik5",
                        options: {
                            rotate: -80,
                            opacity: 0
                        }
                    }, {
                        url: "https://res.wx.qq.com/t/fed_upload/f306a3c8-8817-4317-a604-ee4629ee9779/fire.png",
                        x: e[0].width / 2 - 150,
                        y: e[0].height / 2 - 125,
                        width: 100,
                        height: 100,
                        ratio: 1,
                        name: "tik5-1",
                        options: {
                            opacity: 0,
                            mirror: !0
                        }
                    }, {
                        url: "https://res.wx.qq.com/t/fed_upload/95ed14c0-21c7-4869-ac3b-1bd1df6667e9/9.png",
                        x: e[0].width / 2 + 70,
                        y: e[0].height / 2 - 30,
                        width: 80,
                        height: 80,
                        ratio: 1,
                        options: {
                            mirror: !0,
                            rotate: 20,
                            opacity: 0
                        },
                        name: "tik6"
                    }, {
                        url: "https://res.wx.qq.com/t/fed_upload/3c724c77-d065-40db-8f69-863c1ba45cce/16.png",
                        x: e[0].width / 2 + 115,
                        y: e[0].height / 2 - 95,
                        width: 30,
                        height: 38.3,
                        ratio: 50 / 64,
                        options: {
                            rotate: 10,
                            opacity: 0
                        },
                        name: "tik7"
                    }, {
                        url: "https://res.wx.qq.com/t/fed_upload/3c724c77-d065-40db-8f69-863c1ba45cce/16.png",
                        x: e[0].width / 2 - 150,
                        y: e[0].height / 2 - 135,
                        width: 30,
                        height: 38.3,
                        ratio: 50 / 64,
                        options: {
                            rotate: -10,
                            opacity: 0
                        },
                        name: "tik8"
                    }, {
                        url: "https://res.wx.qq.com/t/fed_upload/16516bb6-9169-4036-8951-5a573bacaef7/7.png",
                        x: e[0].width / 2 - 10,
                        y: e[0].height / 2 - 40,
                        width: 43.8,
                        height: 49,
                        ratio: .89375,
                        options: {
                            mirror: !0,
                            opacity: 0
                        },
                        name: "tik4"
                    } ], Promise.all(i.canvasTik.map(function() {
                        var e = a(t.default.mark(function a(e) {
                            var r;
                            return t.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    return t.next = 2, i.initImg(e);

                                  case 2:
                                    return r = t.sent, e.img = r, t.abrupt("return", e);

                                  case 5:
                                  case "end":
                                    return t.stop();
                                }
                            }, a);
                        }));
                        return function(t) {
                            return e.apply(this, arguments);
                        };
                    }())).then(function(t) {
                        t.forEach(function(t) {
                            i.drawImg(t.img, t.x, t.y, t.width, t.height, t.options);
                        }), setTimeout(function() {
                            i.onTapSvg();
                        }, 200);
                    });

                  case 11:
                  case "end":
                    return r.stop();
                }
            }, r);
        }))();
    },
    initImg: function(e) {
        var i = this;
        return a(t.default.mark(function a() {
            var r;
            return t.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return r = e.url, e.x, e.y, e.width, e.height, e.options, t.abrupt("return", new Promise(function(t, a) {
                        var e = i.canvas.createImage();
                        e.src = r, e.onload = function() {
                            i.ctx.save(), i.ctx.restore(), t(e);
                        };
                    }));

                  case 2:
                  case "end":
                    return t.stop();
                }
            }, a);
        }))();
    },
    drawImg: function(t, a, e, i, r, n) {
        var s;
        this.ctx.save(), this.ctx.globalAlpha = null !== (s = (null == n ? void 0 : n.opacity) < 0 ? 0 : null == n ? void 0 : n.opacity) && void 0 !== s ? s : 1, 
        this.ctx.translate(a + i / 2, e + r / 2), n && n.mirror && this.ctx.scale(-1, 1), 
        n && n.rotate && this.ctx.rotate(n.rotate * Math.PI / 180), this.ctx.translate(-(a + i / 2), -(e + r / 2)), 
        this.ctx.drawImage(t, a, e, i, r), this.ctx.restore();
    },
    cubicEaseOut: function(t, a, e, i) {
        return t /= i, e * (--t * t * t + 1) + a;
    },
    onTapSvg: function() {
        var e = this;
        return a(t.default.mark(function r() {
            var n;
            return t.default.wrap(function(r) {
                for (;;) switch (r.prev = r.next) {
                  case 0:
                    i.default.reportElementClick({
                        key: "try"
                    }), n = e, e.animate("#start", [ {
                        opacity: 1
                    }, {
                        opacity: .5
                    }, {
                        opacity: 0
                    } ], 50, function() {
                        n.setData({
                            state: 0
                        });
                    }), e.from = [ 0, 0, 0, 0 ], e.to = [ 0, 0, 0, 50 ], e.curFrame = 0, e.frames = 40, 
                    wx.nextTick(a(t.default.mark(function a() {
                        return t.default.wrap(function(t) {
                            for (;;) switch (t.prev = t.next) {
                              case 0:
                                return t.next = 2, e.renderSvga();

                              case 2:
                              case "end":
                                return t.stop();
                            }
                        }, a);
                    })));

                  case 8:
                  case "end":
                    return r.stop();
                }
            }, r);
        }))();
    },
    easeInOutCubic: function(t) {
        return t < .5 ? (1 - Math.sqrt(1 - Math.pow(2 * t, 2))) / 2 : (Math.sqrt(1 - Math.pow(-2 * t + 2, 2)) + 1) / 2;
    },
    renderSvga: function() {
        var e = this;
        return a(t.default.mark(function i() {
            var r;
            return t.default.wrap(function(i) {
                for (;;) switch (i.prev = i.next) {
                  case 0:
                    r = m.globalData.isPad ? .8 : 1, e.setData({
                        state: 2,
                        newTop: m.globalData.isPad ? 0 : e.data.windowWidth / 5,
                        newLeft: m.globalData.isPad ? e.data.windowWidth * (1 - r) / 2 : 0,
                        newHeight: e.data.windowWidth * r,
                        newWidth: e.data.windowWidth * r,
                        top: m.globalData.isPad ? e.data.windowWidth / 2.25 : e.data.windowWidth / 1.32,
                        left: m.globalData.isPad ? e.data.windowWidth / 5 : e.data.windowWidth / 7.3,
                        height: e.data.windowWidth / 3.8 * r,
                        width: e.data.windowWidth / 3.8 * r
                    }, a(t.default.mark(function a() {
                        var i, r;
                        return t.default.wrap(function(t) {
                            for (;;) switch (t.prev = t.next) {
                              case 0:
                                if (t.prev = 0, i = wx.getSystemInfoSync(), r = i.brand, ![ "vivo", "oppo", "redmi" ].includes(r.toLocaleLowerCase())) {
                                    t.next = 6;
                                    break;
                                }
                                e.setData({
                                    showImage: !0
                                }), t.next = 8;
                                break;

                              case 6:
                                return t.next = 8, e.renderNew();

                              case 8:
                                setTimeout(function() {
                                    e.animate("#end", [ {
                                        opacity: 0
                                    }, {
                                        opacity: 1
                                    } ], 150);
                                }, 2e3), t.next = 15;
                                break;

                              case 11:
                                t.prev = 11, t.t0 = t.catch(0), e.setData({
                                    showImage: !0
                                }), e.animate("#end", [ {
                                    opacity: 0
                                }, {
                                    opacity: 1
                                } ], 150);

                              case 15:
                              case "end":
                                return t.stop();
                            }
                        }, a, null, [ [ 0, 11 ] ]);
                    })));

                  case 2:
                  case "end":
                    return i.stop();
                }
            }, i);
        }))();
    },
    renderFireworks: function() {
        return a(t.default.mark(function a() {
            var e, i, r;
            return t.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return e = new c(), (i = new o()).loops = 1, t.next = 5, i.setCanvas("#fireCanvas");

                  case 5:
                    return t.next = 7, e.load("assets/fireworks.svg");

                  case 7:
                    return r = t.sent, t.next = 10, i.setVideoItem(r);

                  case 10:
                    i.startAnimation(), i.onFinished(function() {
                        i.stepToFrame(20, !1);
                    });

                  case 12:
                  case "end":
                    return t.stop();
                }
            }, a);
        }))();
    },
    renderNew: function() {
        return a(t.default.mark(function a() {
            var e, i, r;
            return t.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return e = new c(), (i = new o()).loops = 1, t.next = 5, i.setCanvas("#new");

                  case 5:
                    return t.next = 7, e.load("assets/new.svg");

                  case 7:
                    return r = t.sent, t.next = 10, i.setVideoItem(r);

                  case 10:
                    i.startAnimation(), i.onFinished(function() {
                        i.stepToFrame(170, !1);
                    });

                  case 12:
                  case "end":
                    return t.stop();
                }
            }, a);
        }))();
    },
    renderAnimation: function() {
        var e = this;
        return a(t.default.mark(function a() {
            return t.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (!(e.curFrame < 91)) {
                        t.next = 4;
                        break;
                    }
                    e.canvas.requestAnimationFrame(e.renderAnimation), t.next = 5;
                    break;

                  case 4:
                    return t.abrupt("return");

                  case 5:
                    e.curFrame++, e.ctx.clearRect(0, 0, e.canvas.width, e.canvas.height), e.curFrame >= 10 && e.curFrame < 35 && e.canvasTik.forEach(function(t) {
                        "tik1" === t.name && (t.y -= 14.5 * e.easeInOutCubic((e.curFrame - 10) / 25), e.curFrame >= 10 && e.curFrame < 33 && (t.options.opacity = e.easeInOutCubic((e.curFrame - 10) / 23))), 
                        e.drawImg(t.img, t.x, t.y, t.width, t.height, t.options);
                    }), e.curFrame >= 28 && e.curFrame < 50 && e.canvasTik.forEach(function(t) {
                        "tik3" === t.name && (t.x += 6.2 * e.easeInOutCubic((e.curFrame - 28) / 22), t.y += 6.4 * e.easeInOutCubic((e.curFrame - 28) / 22), 
                        e.curFrame >= 28 && e.curFrame < 40 && (t.options.opacity = e.easeInOutCubic((e.curFrame - 28) / 12))), 
                        e.drawImg(t.img, t.x, t.y, t.width, t.height, t.options);
                    }), e.curFrame >= 43 && e.curFrame <= 63 && e.canvasTik.forEach(function(t) {
                        "tik4" === t.name && (t.x -= 2.5 * e.easeInOutCubic((e.curFrame - 43) / 20), t.y -= 5.5 * e.easeInOutCubic((e.curFrame - 43) / 20), 
                        e.curFrame >= 43 && e.curFrame <= 54 && (t.options.opacity = e.easeInOutCubic((e.curFrame - 43) / 11))), 
                        e.drawImg(t.img, t.x, t.y, t.width, t.height, t.options);
                    }), e.curFrame >= 53 && e.curFrame <= 73 && e.canvasTik.forEach(function(t) {
                        "tik2" === t.name && (t.x -= 3.7 * e.easeInOutCubic((e.curFrame - 53) / 20), t.y += 4.3 * e.easeInOutCubic((e.curFrame - 53) / 20), 
                        e.curFrame >= 53 && e.curFrame <= 65 && (t.options.opacity = e.easeInOutCubic((e.curFrame - 53) / 12))), 
                        e.drawImg(t.img, t.x, t.y, t.width, t.height, t.options);
                    }), e.curFrame >= 64 && e.curFrame <= 81 && e.canvasTik.forEach(function(t) {
                        "tik6" === t.name && (t.x -= 3 * e.easeInOutCubic((e.curFrame - 64) / 17), t.y -= 8 * e.easeInOutCubic((e.curFrame - 64) / 17), 
                        e.curFrame >= 64 && e.curFrame <= 76 && (t.options.opacity = e.easeInOutCubic((e.curFrame - 64) / 12))), 
                        e.drawImg(t.img, t.x, t.y, t.width, t.height, t.options);
                    }), e.curFrame >= 73 && e.curFrame <= 88 && e.canvasTik.forEach(function(t) {
                        "tik8" === t.name && (t.x += 3 * e.easeInOutCubic((e.curFrame - 73) / 15), t.y -= 6.5 * e.easeInOutCubic((e.curFrame - 73) / 15), 
                        e.curFrame >= 73 && e.curFrame <= 84 && (t.options.opacity = e.easeInOutCubic((e.curFrame - 73) / 11))), 
                        e.drawImg(t.img, t.x, t.y, t.width, t.height, t.options);
                    }), e.curFrame >= 79 && e.curFrame <= 94 && e.canvasTik.forEach(function(t) {
                        "tik7" === t.name && (t.x -= 3 * e.easeInOutCubic((e.curFrame - 79) / 15), t.y -= 6.5 * e.easeInOutCubic((e.curFrame - 79) / 15), 
                        e.curFrame >= 79 && e.curFrame <= 90 && (t.options.opacity = e.easeInOutCubic((e.curFrame - 79) / 11))), 
                        e.drawImg(t.img, t.x, t.y, t.width, t.height, t.options);
                    }), e.curFrame >= 85 && e.curFrame <= 91 && e.canvasTik.forEach(function(t) {
                        "tik5-1" === t.name && (t.options.opacity = e.easeInOutCubic((e.curFrame - 85) / 6), 
                        e.setData({
                            top: t.y,
                            left: t.x,
                            height: t.height,
                            width: t.width
                        })), e.drawImg(t.img, t.x, t.y, t.width, t.height, t.options);
                    });

                  case 15:
                  case "end":
                    return t.stop();
                }
            }, a);
        }))();
    },
    anim: function(e) {
        var i = this;
        return a(t.default.mark(function e() {
            var r, n, s;
            return t.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    r = i.frames, n = i.from, s = i.to, i.start += 1, i.start < r ? i.canvas.requestAnimationFrame(i.anim) : setTimeout(a(t.default.mark(function a() {
                        return t.default.wrap(function(t) {
                            for (;;) switch (t.prev = t.next) {
                              case 0:
                                return i.start = 0, i.frames = 10, t.next = 4, i.initImg({
                                    url: "https://res.wx.qq.com/t/fed_upload/c043ca11-97ef-4b8f-b777-0726b6ad89a4/gesture.png",
                                    x: 2 * i.canvas.width,
                                    y: 2 * i.canvas.height,
                                    width: 100,
                                    height: 100
                                });

                              case 4:
                                return i.gesImg = t.sent, i.anim2(), t.abrupt("return");

                              case 7:
                              case "end":
                                return t.stop();
                            }
                        }, a);
                    })), 300), i.ctx.clearRect(0, 0, i.canvas.width, i.canvas.height), i.canvasTik.forEach(function(t) {
                        var a = i.easeInOutCubic(i.start / r);
                        "tik1" === t.name && (t.y += 3 * a, t.x -= 2.5 * a, t.width += 5 * a, t.height += 5 * a / t.ratio, 
                        i.drawImg(t.img, t.x, t.y, t.width, t.height, t.options)), "tik2" === t.name && (t.y += 4 * a, 
                        t.x -= 2.5 * a, t.width += 5 * a, t.height += 5 * a / t.ratio, t.options.opacity = .8 - a, 
                        i.drawImg(t.img, t.x, t.y, t.width, t.height, t.options)), "tik3" === t.name && (t.y += 4.1 * a, 
                        t.x -= 1.5 * a, t.width += 3 * a, t.height += 3 * a / t.ratio, t.options.opacity = .8 - a, 
                        i.drawImg(t.img, t.x, t.y, t.width, t.height, t.options)), "tik4" === t.name && (i.r = i.cubicEaseOut(i.start, n[0], s[0] - n[0], r), 
                        i.g = i.cubicEaseOut(i.start, n[1], s[1] - n[1], r), i.b = i.cubicEaseOut(i.start, n[2], s[2] - n[2], r), 
                        i.a = i.cubicEaseOut(i.start, n[3], s[3] - n[3], r), i.ctx.globalAlpha = i.a / 100, 
                        i.ctx.fillStyle = "rgba(".concat([ i.r, i.g, i.b, i.a ].join(), ")"), i.ctx.rect(0, 0, i.canvas.width, i.canvas.height), 
                        i.ctx.fill(), i.ctx.globalAlpha = 1, t.y += 20 * a, t.x -= a, t.width += 2 * a, 
                        t.height += 2 * a / t.ratio, t.options = Object.assign(t.options, {
                            rotate: 20 * -a
                        }), i.drawImg(t.img, t.x, t.y, t.width, t.height, t.options)), "tik5" === t.name && (t.y += 4 * a, 
                        t.x -= 4 * a, t.width += 3 * a, t.height += 3 * a / t.ratio, t.options.opacity = .8 - a, 
                        i.drawImg(t.img, t.x, t.y, t.width, t.height, t.options)), "tik5-1" === t.name && (t.y += 4 * a, 
                        t.x -= 4 * a, t.width += 3 * a, t.height += 3 * a / t.ratio, i.drawImg(t.img, t.x, t.y, t.width, t.height, t.options)), 
                        "tik6" === t.name && (t.y += 6 * a, t.x += 1.5 * a, t.width += 3 * a, t.height += 3 * a / t.ratio, 
                        t.options.opacity = .8 - a, i.drawImg(t.img, t.x, t.y, t.width, t.height, t.options)), 
                        "tik7" !== t.name && "tik8" !== t.name || (t.y += a, t.width += 1.2 * a, t.height += 1.2 * a / t.ratio, 
                        t.options.opacity = .8 - a, i.drawImg(t.img, t.x, t.y, t.width, t.height, t.options));
                    });

                  case 5:
                  case "end":
                    return e.stop();
                }
            }, e);
        }))();
    },
    renderShape: function() {
        var t = this;
        this.canvasTik.forEach(function(a) {
            "tik4" === a.name && (t.ctx.save(), t.ctx.globalAlpha = t.a / 100, t.ctx.fillStyle = "rgba(".concat([ t.r, t.g, t.b, t.a ].join(), ")"), 
            t.ctx.rect(0, 0, t.canvas.width, t.canvas.height), t.ctx.fill(), t.ctx.restore()), 
            t.drawImg(a.img, a.x, a.y, a.width, a.height, a.options);
        });
    },
    anim2: function(e) {
        var i = this;
        return a(t.default.mark(function a() {
            var e;
            return t.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    i.start++, i.start <= i.frames ? i.canvas.requestAnimationFrame(i.anim2) : setTimeout(function() {
                        i.start = 0, i.frames = 30, i.anim3();
                    }, 200), i.ctx.clearRect(0, 0, i.canvas.width, i.canvas.height), i.canvasTik.forEach(function(t) {
                        "tik4" === t.name && (i.ctx.save(), i.ctx.globalAlpha = i.a / 100, i.ctx.fillStyle = "rgba(".concat([ i.r, i.g, i.b, i.a ].join(), ")"), 
                        i.ctx.rect(0, 0, i.canvas.width, i.canvas.height), i.ctx.fill(), i.ctx.restore()), 
                        i.drawImg(t.img, t.x, t.y, t.width, t.height, t.options);
                    }), i.ctx.fillStyle = "white", i.ctx.font = "17px sans-serif", i.ctx.save(), i.ctx.globalAlpha = 10 * i.start / 100, 
                    e = i.canvasTik.find(function(t) {
                        return "tik4" === t.name;
                    }), i.ctx.fillText("轻触拖动元素", i.canvas.width / 2 / i.dpr - 56, i.canvas.height / 2 / i.dpr + 220), 
                    i.drawImg(i.gesImg, e.x, e.y + 45, 90, 100, {
                        rotate: i.start - 10,
                        opacity: 10 * i.start / 100
                    }), i.ctx.restore();

                  case 12:
                  case "end":
                    return t.stop();
                }
            }, a);
        }))();
    },
    anim3: function() {
        var e = this;
        return a(t.default.mark(function a() {
            var i;
            return t.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (e.start++, !(e.start <= e.frames)) {
                        t.next = 5;
                        break;
                    }
                    e.canvas.requestAnimationFrame(e.anim3), t.next = 7;
                    break;

                  case 5:
                    return setTimeout(function() {
                        e.start = 0, e.frames = 20, e.anim4();
                    }, 160), t.abrupt("return");

                  case 7:
                    e.ctx.clearRect(0, 0, e.canvas.width, e.canvas.height), e.canvasTik.forEach(function(t) {
                        "tik4" === t.name ? (e.ctx.save(), e.ctx.globalAlpha = e.a / 100, e.ctx.fillStyle = "rgba(".concat([ e.r, e.g, e.b, e.a ].join(), ")"), 
                        e.ctx.rect(0, 0, e.canvas.width, e.canvas.height), e.ctx.fill(), e.ctx.restore()) : e.drawImg(t.img, t.x, t.y, t.width, t.height, t.options);
                    }), e.ctx.fillText("轻触拖动元素", e.canvas.width / 2 / e.dpr - 56, e.canvas.height / 2 / e.dpr + 220), 
                    (i = e.canvasTik.find(function(t) {
                        return "tik4" === t.name;
                    })).y -= 9.5 * e.easeInOutCubic(e.start / e.frames), e.drawImg(i.img, i.x, i.y, i.width, i.height, i.options), 
                    e.drawImg(e.gesImg, i.x, i.y + 45, 90, 100);

                  case 14:
                  case "end":
                    return t.stop();
                }
            }, a);
        }))();
    },
    anim4: function() {
        var t = this;
        if (this.start++, this.start < this.frames) {
            this.canvas.requestAnimationFrame(this.anim4), this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height), 
            this.canvasTik.forEach(function(a) {
                "tik4" === a.name && (t.ctx.save(), t.ctx.globalAlpha = t.a / 100, t.ctx.fillStyle = "rgba(".concat([ t.r, t.g, t.b, t.a ].join(), ")"), 
                t.ctx.rect(0, 0, t.canvas.width, t.canvas.height), t.ctx.fill(), t.ctx.restore()), 
                t.drawImg(a.img, a.x, a.y, a.width, a.height, a.options);
            }), this.ctx.fillText("轻触拖动元素", this.canvas.width / 2 / this.dpr - 56, this.canvas.height / 2 / this.dpr + 220);
            var a = this.canvasTik.find(function(t) {
                return "tik4" === t.name;
            });
            this.drawImg(this.gesImg, a.x + this.start, a.y + 45 - this.start, 90, 100, {
                rotate: this.start
            });
        } else setTimeout(function() {
            t.start = 0, t.frames = 20, t.anim5();
        }, 150);
    },
    anim5: function() {
        var t = this;
        if (this.start++, !(this.start < this.frames)) return this.start = 0, this.frames = 10, 
        void this.anim6();
        this.canvas.requestAnimationFrame(this.anim5), this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height), 
        this.canvasTik.forEach(function(a) {
            "tik4" === a.name ? (t.ctx.save(), t.ctx.globalAlpha = t.a / 100, t.ctx.fillStyle = "rgba(".concat([ t.r, t.g, t.b, t.a ].join(), ")"), 
            t.ctx.rect(0, 0, t.canvas.width, t.canvas.height), t.ctx.fill(), t.ctx.restore()) : t.drawImg(a.img, a.x, a.y, a.width, a.height, a.options);
        }), this.ctx.fillText("轻触拖动元素", this.canvas.width / 2 / this.dpr - 56, this.canvas.height / 2 / this.dpr + 220);
        var a = this.canvasTik.find(function(t) {
            return "tik4" === t.name;
        });
        a.options = Object.assign({}, a.options, {
            rotate: this.start - 20
        }), this.drawImg(a.img, a.x, a.y, a.width, a.height, a.options), this.gesImgRotate = 15 - this.start, 
        this.drawImg(this.gesImg, a.x + 20 + .5 * this.start, a.y + 25 - 1.2 * this.start, 90, 100, {
            rotate: this.gesImgRotate
        });
    },
    anim6: function() {
        var t = this;
        if (this.start++, !(this.start < this.frames)) {
            this.start = 0, this.frames = 20, this.from = [ 0, 0, 0, 50 ], this.to = [ 255, 255, 255, 0 ];
            return this.canvasTik.forEach(function(t) {
                "tik2" !== t.name && "tik3" !== t.name || (t.originX = t.x - 40, t.originY = t.y - 40), 
                "tik5-1" === t.name && (t.originX = t.x - 40, t.originY = t.y + 40), "tik7" === t.name && (t.originX = t.x + 40, 
                t.originY = t.y - 40), "tik6" === t.name && (t.originX = t.x + 40, t.originY = t.y + 40), 
                "tik8" === t.name && (t.originX = t.x - 40, t.originY = t.y - 40);
            }), void this.anim8();
        }
        this.canvas.requestAnimationFrame(this.anim6), this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height), 
        this.canvasTik.forEach(function(a) {
            "tik4" === a.name && (t.ctx.save(), t.ctx.globalAlpha = t.a / 100, t.ctx.fillStyle = "rgba(".concat([ t.r, t.g, t.b, t.a ].join(), ")"), 
            t.ctx.rect(0, 0, t.canvas.width, t.canvas.height), t.ctx.fill(), t.ctx.restore()), 
            t.drawImg(a.img, a.x, a.y, a.width, a.height, a.options);
        }), this.ctx.globalAlpha = 1 - 2 * this.start / 100, this.ctx.fillText("轻触拖动元素", this.canvas.width / 2 / this.dpr - 56, this.canvas.height / 2 / this.dpr + 220);
        var a = this.canvasTik.find(function(t) {
            return "tik4" === t.name;
        });
        this.drawImg(this.gesImg, a.x + 30, a.y + 1, 90, 100, {
            rotate: this.gesImgRotate
        }), this.ctx.globalAlpha = 1;
    },
    anim8: function() {
        var e = this, i = this.to, r = this.from, n = this.frames;
        this.start++, this.start < this.frames ? this.canvas.requestAnimationFrame(this.anim8) : this.setData({
            state: 2
        }, a(t.default.mark(function i() {
            var r, n, s;
            return t.default.wrap(function(i) {
                for (;;) switch (i.prev = i.next) {
                  case 0:
                    return r = new c(), (n = new o()).loops = 1, i.next = 5, n.setCanvas("#fireCanvas");

                  case 5:
                    return i.next = 7, r.load("assets/fireworks.svg");

                  case 7:
                    return s = i.sent, i.next = 10, n.setVideoItem(s);

                  case 10:
                    e.ctx.clearRect(0, 0, e.canvas.width, e.canvas.height), e.canvasTik.forEach(function() {
                        var i = a(t.default.mark(function a(i) {
                            return t.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    "tik5-1" === i.name && (i.options.opacity = 0), e.drawImg(i.img, i.x, i.y, i.width, i.height, i.options);

                                  case 2:
                                  case "end":
                                    return t.stop();
                                }
                            }, a);
                        }));
                        return function(t) {
                            return i.apply(this, arguments);
                        };
                    }()), e.animate("#end", [ {
                        opacity: 0
                    }, {
                        opacity: 1
                    } ], 150), n.startAnimation(), n.onFinished(function() {
                        n.stepToFrame(20, !1);
                    });

                  case 15:
                  case "end":
                    return i.stop();
                }
            }, i);
        }))), this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
        var s = this.easeInOutCubic(this.start / this.frames);
        this.canvasTik.forEach(function() {
            var c = a(t.default.mark(function a(c) {
                return t.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        "tik4" === c.name ? (e.ctx.save(), e.r = e.cubicEaseOut(e.start, r[0], i[0] - r[0], n), 
                        e.g = e.cubicEaseOut(e.start, r[1], i[1] - r[1], n), e.b = e.cubicEaseOut(e.start, r[2], i[2] - r[2], n), 
                        e.a = e.cubicEaseOut(e.start, r[3], i[3] - r[3], n), e.ctx.globalAlpha = e.a / 100, 
                        e.ctx.fillStyle = "rgba(".concat([ e.r, e.g, e.b, e.a ].join(), ")"), e.ctx.rect(0, 0, e.canvas.width, e.canvas.height), 
                        e.ctx.fill(), e.ctx.restore(), e.drawImg(c.img, c.x, c.y, c.width, c.height, c.options)) : ("tik2" !== c.name && "tik3" !== c.name && "tik5-1" !== c.name || (c.options.opacity = 2 * s, 
                        c.x = c.originX + 2 * e.start, c.y = c.originY + 2 * e.start), "tik5-1" === c.name && (c.options.opacity = 2 * s, 
                        c.x = c.originX + 2 * e.start, c.y = c.originY - 2 * e.start), "tik7" === c.name && (c.options.opacity = 2 * s, 
                        c.x = c.originX - 2 * e.start, c.y = c.originY + 2 * e.start), "tik6" === c.name && (c.options.opacity = 2 * s, 
                        c.x = c.originX - 2 * e.start, c.y = c.originY - 2 * e.start), "tik8" === c.name && (c.options.opacity = 2 * s, 
                        c.x = c.originX + 2 * e.start, c.y = c.originY + 2 * e.start), "tik5" === c.name && (e.setData({
                            top: c.y,
                            left: c.x - 10,
                            height: c.height + 20,
                            width: c.width + 20
                        }), c.options.opacity = 0), e.drawImg(c.img, c.x, c.y, c.width, c.height, c.options));

                      case 1:
                      case "end":
                        return t.stop();
                    }
                }, a);
            }));
            return function(t) {
                return c.apply(this, arguments);
            };
        }());
    },
    onJumpIndex: function() {
        var e = this;
        return a(t.default.mark(function a() {
            var r;
            return t.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (i.default.reportElementClick({
                        key: "begin_producing"
                    }), e.data.isAgree) {
                        t.next = 4;
                        break;
                    }
                    return wx.showToast({
                        title: "阅读协议后才可以开始制作",
                        icon: "none"
                    }), t.abrupt("return");

                  case 4:
                    return t.next = 6, h({
                        version: u
                    });

                  case 6:
                    if ((r = t.sent) && r.data && !r.error) {
                        t.next = 10;
                        break;
                    }
                    return wx.showToast({
                        title: "网络错误",
                        icon: "none"
                    }), t.abrupt("return");

                  case 10:
                    wx.redirectTo({
                        url: "../emoji/emoji"
                    }), wx.setStorageSync("firstComing", !0);

                  case 12:
                  case "end":
                    return t.stop();
                }
            }, a);
        }))();
    },
    onTapRadio: function() {
        this.setData({
            isAgree: !this.data.isAgree
        });
    },
    onJumpAgreement: function() {
        wx.navigateTo({
            url: "../agreement/agreement"
        });
    },
    onShareAppMessage: function() {
        var t = (0, e.default)();
        return {
            title: t.word,
            path: "/pages/index/index",
            imageUrl: t.image
        };
    },
    onShareTimeline: function() {
        return {
            title: "微信创意表情 | 制作你的表情",
            path: "/pages/index/index",
            query: ""
        };
    }
});