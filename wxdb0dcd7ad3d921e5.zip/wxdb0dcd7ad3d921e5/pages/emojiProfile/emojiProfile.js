require("../../@babel/runtime/helpers/Arrayincludes");

var e = d(require("../../@babel/runtime/regenerator")), t = require("../../@babel/runtime/helpers/asyncToGenerator"), a = d(require("@tencent/merlin-behavior")), n = d(require("../../utils/word")), i = d(require("../../services/addPersonalEmojiSet")), o = require("../../utils/storage"), s = d(require("../../utils/randomString")), r = require("../index/save.js"), c = d(require("../../services/getAppQrCode")), l = d(require("../../utils/mergeQuery"));

function d(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

var u = getApp(), f = require("../../services/getMixEmojiList"), h = require("../../services/deleteMixEmoji");

Page({
    pageName: "emoji_profile",
    data: {
        selectId: [],
        faceList: [],
        blockEmojiKey: [],
        isManageState: !1,
        isSavePhoto: !1,
        navBarHeight: u.globalData.navBarHeight,
        isLoading: !1,
        emojiLoading: !1,
        hasListCache: (0, o.getEmojiStorage)(),
        scene: -1,
        showDialog: !1,
        isDisable: !1,
        isMacWin: !1,
        isEnd: !1,
        isHotEnd: !1,
        activeTab: "self",
        shareTalkerShareModal: !1,
        hotEmojiLoading: !1,
        showActionsheet: !1,
        shotPhotoPath: "",
        hotFaceList: [],
        showMoreBtn: !1,
        groups: [ "shareTalker", "savePhoto" ],
        firstHot: !1,
        isFirstHotComing: wx.getStorageSync("isFirstHotComing")
    },
    onLoad: function(a) {
        var n = this;
        return t(e.default.mark(function t() {
            var i, s, r, c, d, h, g;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if ([ "mac", "windows" ].includes(wx.getSystemInfoSync().platform) && n.setData({
                        isMacWin: !0
                    }), n.setData({
                        hasListCache: (0, o.getEmojiStorage)(),
                        isFirstHotComing: wx.getStorageSync("isFirstHotComing")
                    }), u.globalData.hotContext = "", i = wx.getLaunchOptionsSync(), s = i.scene, n.setData({
                        scene: s
                    }), 1155 === s && (getApp().globalData.pyqComing = !0), 1154 === s) {
                        e.next = 12;
                        break;
                    }
                    if (r = wx.getStorageSync("firstComing"), c = (0, l.default)(a), r) {
                        e.next = 12;
                        break;
                    }
                    return wx.redirectTo({
                        url: "../guide/guide?".concat(c)
                    }), e.abrupt("return");

                  case 12:
                    if (a && (a.setkey || a.scene) && (d = a.setkey || a.scene).startsWith("sb_") && (d = d.replace("sb_", ""), 
                    wx.navigateTo({
                        url: "/pages/showBoard/showBoard?setkey=".concat(d)
                    })), n.setData({
                        emojiLoading: !0
                    }), 1154 != s) {
                        e.next = 16;
                        break;
                    }
                    return e.abrupt("return");

                  case 16:
                    h = n, (g = (0, o.getEmojiStorage)()).length > 0 ? (n.setData({
                        faceList: g
                    }), h.setData({
                        emojiLoading: !1
                    })) : (n.setData({
                        activeTab: "hot"
                    }), wx.setStorageSync("isFirstHotComing", !0)), f({
                        context: ""
                    }).then(function(e) {
                        if (-100005 === (null == e ? void 0 : e.ret)) wx.setStorageSync("firstComing", !0), 
                        wx.showModal({
                            title: "网络异常，请重试"
                        }); else {
                            0 == g.length && e.data.data.emojis.length > 0 && n.setData({
                                activeTab: "self"
                            }), e.data.data.emojis.length < 30 && n.setData({
                                isEnd: !0
                            });
                            var t = e.data.data.emojis;
                            h.setData({
                                faceList: t,
                                hasListCache: t,
                                emojiLoading: !1,
                                isDisable: !1
                            }), u.globalData.context = e.data.data.context, (0, o.setEmojiStorage)(e.data.data.emojis);
                        }
                    });

                  case 20:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    onUnload: function() {
        (0, o.setEmojiStorage)(this.data.faceList);
    },
    back: function() {
        wx.navigateTo({
            url: "/pages/webview/webview"
        });
    },
    touchStart: function(e) {},
    downloadImage: function() {
        var e = this;
        wx.getSetting({
            success: function(t) {
                t.authSetting["scope.writePhotosAlbum"] ? e.download() : wx.authorize({
                    scope: "scope.writePhotosAlbum",
                    success: function() {
                        e.download();
                    },
                    fail: function(e) {}
                });
            }
        });
    },
    download: function() {
        var e = wx.getFileSystemManager(), t = "".concat(wx.env.USER_DATA_PATH, "/face.png");
        e.readFile({
            filePath: t,
            encoding: "base64",
            success: function(e) {
                wx.saveImageToPhotosAlbum({
                    filePath: t,
                    success: function(e) {
                        wx.showToast({
                            title: "保存成功"
                        });
                    },
                    fail: function(e) {
                        wx.showToast({
                            title: "保存失败"
                        });
                    }
                });
            },
            fail: function(e) {
                wx.showModal({
                    title: "文件写入失败"
                });
            }
        });
    },
    onSelect: function(e) {
        var t = e.currentTarget.dataset.emojikey;
        if (this.data.isManageState) {
            var n = this.data.selectId;
            n.includes(t) ? n.splice(n.indexOf(t), 1) : n.push(t), this.setData({
                selectId: n
            });
        } else u.globalData.canvasData = t ? this.data.faceList.find(function(e) {
            return e.emojiKey === t;
        }).layerInfo : "", a.default.reportElementClick({
            key: "emoji_click",
            extInfo: {
                emoji_key: t
            }
        }), wx.redirectTo({
            url: "../emoji/emoji?id=".concat(t)
        });
    },
    complete: function() {
        a.default.reportElementClick({
            key: "finish",
            extInfo: {
                emoji_count: this.data.faceList.length
            }
        }), this.setData({
            isManageState: !1,
            selectId: []
        });
    },
    delete: function() {
        var e = this;
        a.default.reportElementClick({
            key: "delete",
            extInfo: {
                deleted_emoji_count: this.data.selectId.length
            }
        }), wx.showActionSheet({
            alertText: "删除后，编辑记录将无法恢复",
            itemList: [ "删除" ],
            itemColor: "#f00",
            success: function(t) {
                0 == t.tapIndex && (wx.showLoading({
                    title: "删除中",
                    mask: !0
                }), h({
                    keys: e.data.faceList.filter(function(t) {
                        return e.data.selectId.includes(t.emojiKey);
                    })
                }).then(function(t) {
                    var n = e.data.faceList.map(function(t) {
                        if (!e.data.selectId.some(function(e) {
                            return e === t.emojiKey;
                        })) return t;
                    }).filter(function(e) {
                        return e;
                    });
                    (0, o.setEmojiStorage)(n), a.default.reportElementClick({
                        key: "delete_check",
                        extInfo: {
                            deleted_emoji_count: e.data.selectId.length
                        }
                    });
                    var i = (0, o.getEmojiStorage)();
                    e.setData({
                        faceList: n,
                        selectId: [],
                        hasListCache: i
                    }), (0, o.setEmojiStorage)(i);
                }).finally(function() {
                    wx.hideLoading(), 0 === e.data.faceList.length && wx.redirectTo({
                        url: "/pages/index/index"
                    });
                }));
            }
        });
    },
    share: function() {
        this.setData({
            showActionsheet: !0
        }), a.default.reportElementClick({
            key: "share",
            extInfo: {
                emoji_cnt: this.data.selectId.length
            }
        });
    },
    shareTalker: function() {
        this.setData({
            shareTalkerShareModal: !0
        });
    },
    manage: function() {
        a.default.reportElementClick({
            key: "manage",
            extInfo: {
                emoji_count: this.data.faceList.length
            }
        }), this.setData({
            isManageState: !0
        });
    },
    jumpToEmojiEditor: function() {
        wx.getStorageSync("firstComing") && !this.data.isDisable && (a.default.reportElementClick({
            key: "begin_producing",
            extInfo: {
                emoji_count: this.data.faceList.length
            }
        }), u.globalData.canvasData = "", wx.redirectTo({
            url: "../emoji/emoji"
        }));
    },
    scrolltolower: function() {
        var e = this, t = u.globalData.context;
        this.data.isLoading || !t || this.data.isEnd || (this.setData({
            isLoading: !0
        }), f({
            context: t
        }).then(function(t) {
            t.data.data.emojis.length < 15 && e.setData({
                isEnd: !0
            }), e.setData({
                faceList: e.data.faceList.concat(t.data.data.emojis),
                isLoading: !1
            }), u.globalData.context = t.data.data.context;
        }));
    },
    onTapFaceBtn: function(e) {
        var t = e.currentTarget.dataset.role;
        this.data.isManageState || (this.setData({
            activeTab: t
        }), a.default.reportElementClick({
            key: "switch_tab",
            extInfo: {
                tab_role: t
            }
        }));
    },
    onShareAppMessage: function() {
        var o = this, r = (0, n.default)();
        if (!this.data.isSavePhoto) {
            if (this.data.shareTalkerShareModal) {
                var c = new Promise(function() {
                    var n = t(e.default.mark(function n(r, c) {
                        var l, d;
                        return e.default.wrap(function(n) {
                            for (;;) switch (n.prev = n.next) {
                              case 0:
                                return wx.showLoading({
                                    title: "正在处理"
                                }), n.prev = 1, setTimeout(t(e.default.mark(function t() {
                                    return e.default.wrap(function(e) {
                                        for (;;) switch (e.prev = e.next) {
                                          case 0:
                                            c("error");

                                          case 1:
                                          case "end":
                                            return e.stop();
                                        }
                                    }, t);
                                })), 3e3), o.data.selectId.length > 99 && (wx.showToast({
                                    title: "表情数量超过上限",
                                    icon: "none"
                                }), c("error")), n.next = 6, (0, i.default)({
                                    emojiKey: o.data.selectId,
                                    uniqueId: (0, s.default)(8),
                                    emojis: o.filterEmojiText()
                                });

                              case 6:
                                return l = n.sent, o.setData({
                                    blockEmojiKey: l.data.data.secBlockEmojiKeys
                                }), n.next = 10, o.createshotPhoto();

                              case 10:
                                d = n.sent, a.default.reportElementClick({
                                    key: "share_to_chat",
                                    extInfo: {
                                        emoji_cnt: o.data.selectId.length
                                    }
                                }), o.setData({
                                    showActionsheet: !1,
                                    shareTalkerShareModal: !1
                                }), r({
                                    imageUrl: d,
                                    title: "快来看看我制作的表情",
                                    path: "/pages/index/index?scene=sb_".concat(l.data.data.setKey)
                                }), n.next = 20;
                                break;

                              case 16:
                                n.prev = 16, n.t0 = n.catch(1), wx.showModal({
                                    title: "提示",
                                    content: "分享失败，请重试"
                                }), c("error");

                              case 20:
                                return n.prev = 20, wx.hideLoading(), n.finish(20);

                              case 23:
                              case "end":
                                return n.stop();
                            }
                        }, n, null, [ [ 1, 16, 20, 23 ] ]);
                    }));
                    return function(e, t) {
                        return n.apply(this, arguments);
                    };
                }());
                return {
                    title: r.word,
                    path: "/pages/index/index",
                    imageUrl: r.image,
                    promise: c
                };
            }
            return {
                title: r.word,
                path: "/pages/index/index",
                imageUrl: r.image
            };
        }
    },
    onShareTimeline: function() {
        return {
            title: "微信创意表情 | 制作你的表情",
            path: "/pages/index/index",
            query: ""
        };
    },
    done: function() {
        this.setData({
            showDialog: !1
        });
    },
    savePhoto: function() {
        this.data.shareTalkerShareModal || (this.setData({
            isSavePhoto: !0
        }), wx.showLoading({
            title: "图片生成中"
        }), wx.createSelectorQuery().select("#canvas").fields({
            node: !0,
            size: !0
        }).exec(this.initCanvas.bind(this)), a.default.reportElementClick({
            key: "share_as_pic",
            extInfo: {
                emoji_cnt: this.data.selectId.length
            }
        }));
    },
    initCanvas: function(a) {
        var n = this;
        return t(e.default.mark(function t() {
            var i, o, l;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return i = a[0].node, n.canvas = i, o = i.getContext("2d"), e.next = 5, (0, c.default)({
                        emojiKey: n.data.selectId,
                        uniqueId: (0, s.default)(8),
                        emojis: n.filterEmojiText()
                    });

                  case 5:
                    return l = e.sent, e.next = 8, (0, r.createLocalImage)(o, i, n.data.selectId.map(function(e) {
                        return l.data.data.secBlockEmojiKeys.includes(e) ? "https://res.wx.qq.com/t/fed_upload/10fb5cee-1d45-4ace-936b-d1a70054863c/blockWithText.png" : n.data.faceList.find(function(t) {
                            return t.emojiKey === e;
                        }).imgBase64;
                    }), l.data.data.base64);

                  case 8:
                    wx.hideLoading(), n.onSave(), n.setData({
                        showActionsheet: !1,
                        isSavePhoto: !1
                    });

                  case 11:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    createshotPhoto: function() {
        var a = this;
        return t(e.default.mark(function t() {
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.abrupt("return", new Promise(function(e) {
                        wx.createSelectorQuery().select("#canvas").fields({
                            node: !0,
                            size: !0
                        }).exec(a.initCreateshotPhoto.bind(a, e));
                    }));

                  case 1:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    initCreateshotPhoto: function(a, n) {
        var i = this;
        return t(e.default.mark(function t() {
            var o, s, c;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return o = n[0].node, i.canvas = o, s = o.getContext("2d"), e.next = 5, (0, r.createTalkerImage)(s, o, i.data.selectId.map(function(e) {
                        return i.data.blockEmojiKey.includes(e) ? "https://res.wx.qq.com/t/fed_upload/10fb5cee-1d45-4ace-936b-d1a70054863c/block.png" : i.data.faceList.find(function(t) {
                            return t.emojiKey === e;
                        }).imgBase64;
                    }));

                  case 5:
                    return e.next = 7, i.onCreateshotPhoto();

                  case 7:
                    c = e.sent, i.setData({
                        shotPhotoPath: c
                    }), a(c);

                  case 10:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    onCreateshotPhoto: function() {
        var e = this;
        return new Promise(function(t) {
            var a = e.canvas.toDataURL("image/png"), n = wx.getFileSystemManager(), i = "".concat(wx.env.USER_DATA_PATH, "/").concat(Math.random().toString(36).substr(2), ".png");
            n.writeFile({
                filePath: i,
                data: a.split(",")[1],
                encoding: "base64",
                success: function() {
                    t(i);
                }
            });
        });
    },
    onSave: function() {
        var e = this, t = this.canvas.toDataURL("image/png"), a = wx.getFileSystemManager(), n = "".concat(wx.env.USER_DATA_PATH, "/").concat(Math.random().toString(36).substr(2), ".png");
        a.writeFile({
            filePath: n,
            data: t.split(",")[1],
            encoding: "base64",
            success: function() {
                wx.saveImageToPhotosAlbum({
                    filePath: n,
                    success: function() {
                        wx.showToast({
                            title: "已保存到系统相册"
                        });
                    },
                    fail: function() {
                        e.openConfirm();
                    }
                });
            }
        });
    },
    openConfirm: function() {
        wx.showModal({
            title: "无法保存图片到相册，你可以前往小程序「设置」中开启权限。",
            confirmText: "前往设置",
            cancelText: "我知道了",
            success: function(e) {
                e.confirm && wx.openSetting({
                    success: function(e) {}
                });
            }
        });
    },
    filterEmojiText: function() {
        var e = this;
        return this.data.selectId.map(function(t) {
            var a, n = e.data.faceList.find(function(e) {
                return e.emojiKey === t;
            });
            if (n) return {
                emojiKey: n.emojiKey,
                text: null == n || null === (a = n.layerInfo) || void 0 === a ? void 0 : a.map(function(e) {
                    if ("文字" === e.type) return e.text;
                }).filter(function(e) {
                    return e;
                })
            };
        }).filter(function(e) {
            return e;
        });
    }
});