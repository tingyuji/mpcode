Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.createLocalImage = function(t, e, i, h) {
    return g.apply(this, arguments);
}, exports.createTalkerImage = function(t, e, i) {
    return f.apply(this, arguments);
};

var t = h(require("../../@babel/runtime/regenerator")), e = require("../../@babel/runtime/helpers/asyncToGenerator"), i = h(require("../../utils/randomString"));

function h(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

var r = {
    1: {
        width: 428,
        height: 620,
        border: {
            width: 380,
            height: 380
        },
        img: {
            width: 267,
            height: 267
        },
        title1: {
            left: 32,
            top: 516
        },
        title2: {
            left: 32,
            top: 543
        },
        name: {
            left: 74,
            top: 584
        },
        qrtitle: {
            left: 350,
            top: 580
        }
    },
    2: {
        width: 428,
        height: 424,
        border: {
            width: 184,
            height: 184
        },
        img: {
            width: 117,
            height: 117
        },
        title1: {
            left: 32,
            top: 512
        },
        title2: {
            left: 32,
            top: 539
        },
        name: {
            left: 74,
            top: 393
        },
        qrtitle: {
            left: 353,
            top: 389
        }
    },
    3: {
        width: 428,
        height: 360,
        border: {
            width: 120,
            height: 120
        },
        img: {
            width: 77,
            height: 77
        },
        title1: {
            left: 32,
            top: 512
        },
        title2: {
            left: 32,
            top: 539
        },
        name: {
            left: 74,
            top: 324
        },
        qrtitle: {
            left: 350,
            top: 320
        }
    },
    4: {
        width: 428,
        height: 620,
        border: {
            width: 186,
            height: 186
        },
        img: {
            width: 117,
            height: 117
        },
        title1: {
            left: 32,
            top: 512
        },
        title2: {
            left: 32,
            top: 539
        },
        name: {
            left: 74,
            top: 584
        },
        qrtitle: {
            left: 350,
            top: 580
        }
    },
    5: {
        width: 428,
        height: 488,
        border: {
            width: 120,
            height: 120
        },
        img: {
            width: 77,
            height: 77
        },
        title1: {
            left: 32,
            top: 390
        },
        title2: {
            left: 32,
            top: 412
        },
        name: {
            left: 74,
            top: 452
        },
        qrtitle: {
            left: 350,
            top: 448
        }
    },
    6: {
        width: 428,
        height: 488,
        border: {
            width: 120,
            height: 120
        },
        img: {
            width: 77,
            height: 77
        },
        title1: {
            left: 32,
            top: 390
        },
        title2: {
            left: 32,
            top: 412
        },
        name: {
            left: 74,
            top: 452
        },
        qrtitle: {
            left: 350,
            top: 448
        }
    },
    7: {
        width: 428,
        height: 616,
        border: {
            width: 120,
            height: 120
        },
        img: {
            width: 77,
            height: 77
        },
        title1: {
            left: 32,
            top: 390
        },
        title2: {
            left: 32,
            top: 412
        },
        name: {
            left: 74,
            top: 580
        },
        qrtitle: {
            left: 350,
            top: 576
        }
    },
    8: {
        width: 428,
        height: 616,
        border: {
            width: 120,
            height: 120
        },
        img: {
            width: 77,
            height: 77
        },
        title1: {
            left: 32,
            top: 390
        },
        title2: {
            left: 32,
            top: 412
        },
        name: {
            left: 74,
            top: 580
        },
        qrtitle: {
            left: 350,
            top: 576
        }
    },
    9: {
        width: 428,
        height: 616,
        border: {
            width: 120,
            height: 120
        },
        img: {
            width: 77,
            height: 77
        },
        title1: {
            left: 32,
            top: 390
        },
        title2: {
            left: 32,
            top: 412
        },
        name: {
            left: 74,
            top: 580
        },
        qrtitle: {
            left: 350,
            top: 576
        }
    }
}, n = {
    1: {
        img: {
            height: 160,
            width: 160
        }
    },
    2: {
        img: {
            height: 84,
            width: 84
        }
    },
    3: {
        img: {
            height: 66,
            width: 66
        }
    },
    4: {
        img: {
            height: 84,
            width: 84
        }
    },
    5: {
        img: {
            height: 66,
            width: 66
        }
    },
    6: {
        img: {
            height: 66,
            width: 66
        }
    }
};

function l(t) {
    return function(e) {
        return new Promise(function(h, r) {
            var n = t.createImage(), l = wx.getFileSystemManager(), o = "".concat(wx.env.USER_DATA_PATH, "/").concat((0, 
            i.default)(), ".png");
            e.startsWith("http") ? (n.src = e, n.onload = function() {
                h({
                    ctx: n,
                    type: "image"
                });
            }, n.onerror = function() {
                wx.showToast({
                    title: "图片加载失败"
                }), r();
            }) : l.writeFile({
                filePath: o,
                data: e.replace(/^data:image\/\w+;base64,/, ""),
                encoding: "base64",
                success: function(t) {
                    n.src = o, n.onload = function() {
                        h({
                            ctx: n,
                            type: "image"
                        });
                    }, n.onerror = function() {
                        wx.showToast({
                            title: "图片加载失败"
                        }), r();
                    };
                }
            });
        });
    };
}

function o(t, e, i, h, r, n) {
    t.beginPath(), t.arc(e + n, i + n, n, Math.PI, 1.5 * Math.PI), t.moveTo(e + n, i), 
    t.lineTo(e + h - n, i), t.lineTo(e + h, i + n), t.arc(e + h - n, i + n, n, 1.5 * Math.PI, 2 * Math.PI), 
    t.lineTo(e + h, i + r - n), t.lineTo(e + h - n, i + r), t.arc(e + h - n, i + r - n, n, 0, .5 * Math.PI), 
    t.lineTo(e + n, i + r), t.lineTo(e, i + r - n), t.arc(e + n, i + r - n, n, .5 * Math.PI, Math.PI), 
    t.lineTo(e, i + n), t.lineTo(e + n, i), t.fill(), t.closePath(), t.clip();
}

function a(t, e, i) {
    var h = i.width / e.width, r = i.height / e.height, n = Math.min(h, r);
    t.drawImage(e, 0, 0, e.width, e.height, i.x + (i.width - e.width * n) / 2, i.y + (i.height - e.height * n) / 2, e.width * n, e.height * n);
}

function g() {
    return (g = e(t.default.mark(function i(h, n, g, f) {
        var d, w, c, s, u, p, m, x, v, y, b, T, P;
        return t.default.wrap(function(i) {
            for (;;) switch (i.prev = i.next) {
              case 0:
                return d = wx.getSystemInfoSync().pixelRatio, w = g.slice(0, 9), c = r[w.length], 
                s = c.width, u = c.height, p = c.border, m = c.title1, x = c.title2, v = c.name, 
                y = c.qrtitle, b = c.img, n.width = s * d, n.height = u * d, h.scale(d, d), T = l(n), 
                i.next = 9, T(f);

              case 9:
                return P = i.sent, i.next = 12, Promise.all(w.map(function() {
                    var i = e(t.default.mark(function e(i) {
                        return t.default.wrap(function(t) {
                            for (;;) switch (t.prev = t.next) {
                              case 0:
                                return t.next = 2, T(i);

                              case 2:
                                return t.abrupt("return", t.sent);

                              case 3:
                              case "end":
                                return t.stop();
                            }
                        }, e);
                    }));
                    return function(t) {
                        return i.apply(this, arguments);
                    };
                }())).then(function(t) {
                    h.save(), h.fillStyle = "#fff", h.fillRect(0, 0, s, u), h.fillStyle = "#f7f7f7";
                    var e = 1;
                    w.length <= 3 ? e = 1 : 4 === w.length ? e = 2 : w.length > 4 && w.length <= 9 && (e = 3), 
                    t.forEach(function(t, i) {
                        1 == e && (h.save(), o(h, 24 + (p.width + 8) * i, 32, p.width, p.height, 10), h.restore(), 
                        h.save(), a(h, t.ctx, {
                            x: 24 + (p.width - b.width) / 2 + (p.width + 8) * i,
                            y: 32 + (p.height - b.height) / 2,
                            width: b.width,
                            height: b.height
                        }), h.restore()), 1 !== e && (h.save(), o(h, 24 + (p.width + 8) * (i % e), 32 + (p.height + 8) * Math.floor(i / e), p.width, p.height, 10), 
                        h.restore(), h.save(), a(h, t.ctx, {
                            x: 24 + (p.width - b.width) / 2 + (p.width + 8) * (i % e),
                            y: 32 + (p.height - b.height) / 2 + (p.height + 8) * Math.floor(i / e),
                            width: b.width,
                            height: b.height
                        }), h.restore());
                    }), h.save(), h.font = "normal 600 17px PingFang SC", h.fillStyle = "#000", h.textAlign = "center";
                    var i = h.measureText("微信扫一扫").width, r = h.measureText("添加我制作的表情").width;
                    h.fillText("微信扫一扫", m.left + i / 2, v.top - 73), h.fillText("添加我制作的表情", x.left + r / 2, v.top - 48), 
                    h.restore(), h.save(), h.font = "14px normal PingFang SC", h.fillStyle = "#b3b3b3", 
                    h.textAlign = "center", h.fillText("微信创意表情", v.left, v.top), h.restore(), h.save(), 
                    h.drawImage(P.ctx, y.left - 48, y.top - 86, 96, 96), h.restore();
                });

              case 12:
              case "end":
                return i.stop();
            }
        }, i);
    }))).apply(this, arguments);
}

function f() {
    return (f = e(t.default.mark(function i(h, r, o) {
        var g, f, d, w;
        return t.default.wrap(function(i) {
            for (;;) switch (i.prev = i.next) {
              case 0:
                return g = wx.getSystemInfoSync().pixelRatio, f = o.slice(0, 6), d = n[f.length].img, 
                r.width = 231 * g, r.height = 184 * g, h.scale(g, g), w = l(r), i.next = 9, Promise.all(f.map(function() {
                    var i = e(t.default.mark(function e(i) {
                        return t.default.wrap(function(t) {
                            for (;;) switch (t.prev = t.next) {
                              case 0:
                                return t.next = 2, w(i);

                              case 2:
                                return t.abrupt("return", t.sent);

                              case 3:
                              case "end":
                                return t.stop();
                            }
                        }, e);
                    }));
                    return function(t) {
                        return i.apply(this, arguments);
                    };
                }())).then(function(t) {
                    h.save(), h.fillStyle = "#f7f7f7", h.fillRect(0, 0, 231, 184);
                    var e = t.length;
                    t.forEach(function(t, i) {
                        e <= 3 && a(h, t.ctx, {
                            x: (231 - e * d.width - 8 * (e - 1)) / 2 + i * (d.width + 8),
                            y: (184 - d.height) / 2,
                            width: d.width,
                            height: d.height
                        }), 4 == e && a(h, t.ctx, {
                            x: (231 - 2 * d.width - 8) / 2 + (d.width * (i % 2) + i % 2 * 8),
                            y: (184 - 2 * d.height) / 2 + (i <= 1 ? 0 : d.height),
                            width: d.width,
                            height: d.height
                        }), 5 == e && a(h, t.ctx, {
                            x: (231 - 3 * d.width - 24) / 2 + (i <= 2 ? i * (d.width + 8) : (i - 2.5) * (d.width + 8)),
                            y: (184 - 2 * d.height - 4) / 2 + (i <= 2 ? 0 : d.height + 4),
                            width: d.width,
                            height: d.height
                        }), 6 == e && a(h, t.ctx, {
                            x: (231 - 3 * d.width - 24) / 2 + (i <= 2 ? i * (d.width + 8) : (i - 3) * (d.width + 8)),
                            y: (184 - 2 * d.height - 4) / 2 + (i <= 2 ? 0 : d.height + 4),
                            width: d.width,
                            height: d.height
                        });
                    });
                });

              case 9:
              case "end":
                return i.stop();
            }
        }, i);
    }))).apply(this, arguments);
}