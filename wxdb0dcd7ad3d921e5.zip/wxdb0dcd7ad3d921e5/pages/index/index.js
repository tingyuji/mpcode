require("../../@babel/runtime/helpers/Arrayincludes");

var e = d(require("../../@babel/runtime/regenerator")), t = require("../../@babel/runtime/helpers/asyncToGenerator"), a = d(require("@tencent/merlin-behavior")), i = d(require("../../utils/word")), n = d(require("../../services/addPersonalEmojiSet")), o = require("../../utils/storage"), s = d(require("../../services/getHotMixEmojiSet")), r = d(require("../../utils/randomString")), c = require("./save"), l = d(require("../../services/getAppQrCode")), u = d(require("../../utils/mergeQuery"));

function d(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

var f = getApp(), h = require("../../services/getMixEmojiList"), g = require("../../services/deleteMixEmoji");

Page({
    pageName: "emoji_manage",
    data: {
        selectId: [],
        faceList: [],
        blockEmojiKey: [],
        isManageState: !1,
        isSavePhoto: !1,
        navBarHeight: f.globalData.navBarHeight,
        isLoading: !1,
        emojiLoading: !1,
        hasListCache: (0, o.getEmojiStorage)(),
        scene: -1,
        showDialog: !1,
        isDisable: !1,
        isMacWin: !1,
        isEnd: !1,
        isHotEnd: !1,
        activeTab: "self",
        shareTalkerShareModal: !1,
        hotEmojiLoading: !1,
        showActionsheet: !1,
        shotPhotoPath: "",
        hotFaceList: [],
        showMoreBtn: !1,
        groups: [ "shareTalker", "savePhoto" ],
        firstHot: !1,
        isFirstHotComing: wx.getStorageSync("isFirstHotComing"),
        isBigLoading: !1
    },
    onShow: function() {
        var a = this;
        return t(e.default.mark(function t() {
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    a.setData({
                        hasListCache: (0, o.getEmojiStorage)(),
                        faceList: (0, o.getEmojiStorage)()
                    });

                  case 1:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    onLoad: function(a) {
        var i = this;
        return t(e.default.mark(function t() {
            var n, s, r, c, l, d, g;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if ([ "mac", "windows" ].includes(wx.getSystemInfoSync().platform) && i.setData({
                        isMacWin: !0
                    }), i.setData({
                        hasListCache: (0, o.getEmojiStorage)(),
                        isFirstHotComing: wx.getStorageSync("isFirstHotComing")
                    }), f.globalData.hotContext = "", n = wx.getLaunchOptionsSync(), s = n.scene, i.setData({
                        scene: s
                    }), 1155 === s && (getApp().globalData.pyqComing = !0), 1154 === s) {
                        e.next = 12;
                        break;
                    }
                    if (r = wx.getStorageSync("firstComing"), c = (0, u.default)(a), r) {
                        e.next = 12;
                        break;
                    }
                    return wx.redirectTo({
                        url: "../guide/guide?".concat(c)
                    }), e.abrupt("return");

                  case 12:
                    if (a && (a.setkey || a.scene) && (l = a.setkey || a.scene).startsWith("sb_") && (l = l.replace("sb_", ""), 
                    wx.navigateTo({
                        url: "/pages/showBoard/showBoard?setkey=".concat(l)
                    })), a && a.isdone && (wx.getStorageSync("firstSave") ? wx.showToast({
                        title: "已添加到表情"
                    }) : (i.setData({
                        showDialog: !0
                    }), wx.setStorageSync("firstSave", !0))), i.setData({
                        emojiLoading: !0
                    }), 1154 != s) {
                        e.next = 17;
                        break;
                    }
                    return e.abrupt("return");

                  case 17:
                    d = i, (g = (0, o.getEmojiStorage)()).length > 0 ? (i.setData({
                        faceList: g
                    }), d.setData({
                        emojiLoading: !1
                    })) : (i.setData({
                        activeTab: "hot",
                        isBigLoading: !0
                    }), wx.setStorageSync("isFirstHotComing", !0)), i.getHotMixEmoji(), h({
                        context: ""
                    }).then(function(e) {
                        if (-100005 === (null == e ? void 0 : e.ret)) wx.setStorageSync("firstComing", !0), 
                        wx.showModal({
                            title: "网络异常，请重试"
                        }); else {
                            0 == g.length && e.data.data.emojis.length > 0 && i.setData({
                                activeTab: "self"
                            });
                            var t = e.data.data.emojis;
                            d.setData({
                                faceList: t,
                                hasListCache: t,
                                emojiLoading: !1,
                                isDisable: !1
                            }), f.globalData.context = e.data.data.context, (0, o.setEmojiStorage)(e.data.data.emojis);
                        }
                    });

                  case 22:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    onUnload: function() {
        (0, o.setEmojiStorage)(this.data.faceList);
    },
    back: function() {
        wx.navigateTo({
            url: "/pages/webview/webview"
        });
    },
    touchStart: function(e) {},
    downloadImage: function() {
        var e = this;
        wx.getSetting({
            success: function(t) {
                t.authSetting["scope.writePhotosAlbum"] ? e.download() : wx.authorize({
                    scope: "scope.writePhotosAlbum",
                    success: function() {
                        e.download();
                    },
                    fail: function(e) {}
                });
            }
        });
    },
    download: function() {
        var e = wx.getFileSystemManager(), t = "".concat(wx.env.USER_DATA_PATH, "/face.png");
        e.readFile({
            filePath: t,
            encoding: "base64",
            success: function(e) {
                wx.saveImageToPhotosAlbum({
                    filePath: t,
                    success: function(e) {
                        wx.showToast({
                            title: "保存成功"
                        });
                    },
                    fail: function(e) {
                        wx.showToast({
                            title: "保存失败"
                        });
                    }
                });
            },
            fail: function(e) {
                wx.showModal({
                    title: "文件写入失败"
                });
            }
        });
    },
    onSelect: function(e) {
        var t = e.currentTarget.dataset.emojikey;
        if (this.data.isManageState) {
            var i = this.data.selectId;
            i.includes(t) ? i.splice(i.indexOf(t), 1) : i.push(t), this.setData({
                selectId: i
            });
        } else f.globalData.canvasData = t ? this.data.faceList.find(function(e) {
            return e.emojiKey === t;
        }).layerInfo : "", a.default.reportElementClick({
            key: "emoji_click",
            extInfo: {
                emoji_key: t
            }
        }), wx.redirectTo({
            url: "../emoji/emoji?id=".concat(t)
        });
    },
    complete: function() {
        a.default.reportElementClick({
            key: "finish",
            extInfo: {
                emoji_count: this.data.faceList.length
            }
        }), this.setData({
            isManageState: !1,
            selectId: []
        });
    },
    delete: function() {
        var e = this;
        a.default.reportElementClick({
            key: "delete",
            extInfo: {
                deleted_emoji_count: this.data.selectId.length
            }
        }), wx.showActionSheet({
            alertText: "删除后，编辑记录将无法恢复",
            itemList: [ "删除" ],
            itemColor: "#f00",
            success: function(t) {
                0 == t.tapIndex && (wx.showLoading({
                    title: "删除中",
                    mask: !0
                }), g({
                    keys: e.data.faceList.filter(function(t) {
                        return e.data.selectId.includes(t.emojiKey);
                    })
                }).then(function(t) {
                    var i = e.data.faceList.map(function(t) {
                        if (!e.data.selectId.some(function(e) {
                            return e === t.emojiKey;
                        })) return t;
                    }).filter(function(e) {
                        return e;
                    });
                    (0, o.setEmojiStorage)(i), a.default.reportElementClick({
                        key: "delete_check",
                        extInfo: {
                            deleted_emoji_count: e.data.selectId.length
                        }
                    });
                    var n = (0, o.getEmojiStorage)();
                    0 === n.length && (e.setData({
                        isManageState: !1
                    }), 0 === e.data.hotFaceList.length && e.getHotMixEmoji()), e.setData({
                        faceList: i,
                        selectId: [],
                        hasListCache: n
                    }), wx.hideLoading();
                }));
            }
        });
    },
    share: function() {
        this.setData({
            showActionsheet: !0
        }), a.default.reportElementClick({
            key: "share",
            extInfo: {
                emoji_cnt: this.data.selectId.length
            }
        });
    },
    shareTalker: function() {
        this.setData({
            shareTalkerShareModal: !0
        });
    },
    manage: function() {
        a.default.reportElementClick({
            key: "manage",
            extInfo: {
                emoji_count: this.data.faceList.length
            }
        }), this.setData({
            isManageState: !0
        });
    },
    jumpToEmojiEditor: function() {
        wx.getStorageSync("firstComing") && !this.data.isDisable && (a.default.reportElementClick({
            key: "begin_producing",
            extInfo: {
                emoji_count: this.data.faceList.length
            }
        }), f.globalData.canvasData = "", wx.redirectTo({
            url: "../emoji/emoji"
        }));
    },
    scrolltolower: function() {
        var e = this;
        this.data.isLoading || this.data.isHotEnd || (this.setData({
            isLoading: !0
        }), (0, s.default)({
            context: f.globalData.hotContext
        }).then(function(t) {
            t.data.data.emojis.length < 12 && e.setData({
                isHotEnd: !0
            }), e.setData({
                hotFaceList: e.data.hotFaceList.concat(t.data.data.emojis),
                isLoading: !1,
                isBigLoading: !1
            }), f.globalData.hotContext = t.data.data.context;
        }));
    },
    getHotMixEmoji: function() {
        var a = this;
        return t(e.default.mark(function t() {
            var i;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (!a.data.firstHot && !a.data.hotEmojiLoading) {
                        e.next = 2;
                        break;
                    }
                    return e.abrupt("return");

                  case 2:
                    return 0 == a.data.hotFaceList.length && a.setData({
                        hotEmojiLoading: !0,
                        isLoading: !0
                    }), e.next = 5, (0, s.default)({
                        context: f.globalData.hotContext
                    });

                  case 5:
                    i = e.sent, f.globalData.hotContext = i.data.data.context, 0 === i.data.data.emojis.length && a.setData({
                        isHotEnd: !0
                    }), a.setData({
                        hotFaceList: a.data.hotFaceList.concat(i.data.data.emojis),
                        hotEmojiLoading: !1,
                        firstHot: !0,
                        isDisable: !1,
                        isLoading: !1,
                        isBigLoading: !1
                    });

                  case 9:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    onTapFaceBtn: function(e) {
        var t = e.currentTarget.dataset.role;
        this.data.isManageState || (this.setData({
            activeTab: t
        }), a.default.reportElementClick({
            key: "switch_tab",
            extInfo: {
                tab_role: t
            }
        }), "hot" === t && (wx.setStorageSync("isFirstHotComing", !0), this.getHotMixEmoji(), 
        this.setData({
            isFirstHotComing: !0
        })));
    },
    onShareAppMessage: function() {
        var o = this, s = (0, i.default)();
        if (!this.data.isSavePhoto) {
            if (this.data.shareTalkerShareModal) {
                var c = new Promise(function() {
                    var i = t(e.default.mark(function i(s, c) {
                        var l, u;
                        return e.default.wrap(function(i) {
                            for (;;) switch (i.prev = i.next) {
                              case 0:
                                return wx.showLoading({
                                    title: "正在处理"
                                }), i.prev = 1, setTimeout(t(e.default.mark(function t() {
                                    return e.default.wrap(function(e) {
                                        for (;;) switch (e.prev = e.next) {
                                          case 0:
                                            c("error");

                                          case 1:
                                          case "end":
                                            return e.stop();
                                        }
                                    }, t);
                                })), 3e3), o.data.selectId.length > 99 && (wx.showToast({
                                    title: "表情数量超过上限",
                                    icon: "none"
                                }), c("error")), i.next = 6, (0, n.default)({
                                    emojiKey: o.data.selectId,
                                    uniqueId: (0, r.default)(8),
                                    emojis: o.filterEmojiText()
                                });

                              case 6:
                                return l = i.sent, o.setData({
                                    blockEmojiKey: l.data.data.secBlockEmojiKeys
                                }), i.next = 10, o.createshotPhoto();

                              case 10:
                                u = i.sent, a.default.reportElementClick({
                                    key: "share_to_chat",
                                    extInfo: {
                                        emoji_cnt: o.data.selectId.length
                                    }
                                }), o.setData({
                                    showActionsheet: !1,
                                    shareTalkerShareModal: !1
                                }), s({
                                    imageUrl: u,
                                    title: "快来看看我制作的表情",
                                    path: "/pages/index/index?scene=sb_".concat(l.data.data.setKey)
                                }), i.next = 20;
                                break;

                              case 16:
                                i.prev = 16, i.t0 = i.catch(1), wx.showModal({
                                    title: "提示",
                                    content: "分享失败，请重试"
                                }), c("error");

                              case 20:
                                return i.prev = 20, wx.hideLoading(), i.finish(20);

                              case 23:
                              case "end":
                                return i.stop();
                            }
                        }, i, null, [ [ 1, 16, 20, 23 ] ]);
                    }));
                    return function(e, t) {
                        return i.apply(this, arguments);
                    };
                }());
                return {
                    title: s.word,
                    path: "/pages/index/index",
                    imageUrl: s.image,
                    promise: c
                };
            }
            return {
                title: s.word,
                path: "/pages/index/index",
                imageUrl: s.image
            };
        }
    },
    onShareTimeline: function() {
        return {
            title: "微信创意表情 | 制作你的表情",
            path: "/pages/index/index",
            query: ""
        };
    },
    done: function() {
        this.setData({
            showDialog: !1
        });
    },
    savePhoto: function() {
        this.data.shareTalkerShareModal || (this.setData({
            isSavePhoto: !0
        }), wx.showLoading({
            title: "图片生成中"
        }), wx.createSelectorQuery().select("#canvas").fields({
            node: !0,
            size: !0
        }).exec(this.initCanvas.bind(this)), a.default.reportElementClick({
            key: "share_as_pic",
            extInfo: {
                emoji_cnt: this.data.selectId.length
            }
        }));
    },
    initCanvas: function(a) {
        var i = this;
        return t(e.default.mark(function t() {
            var n, o, s;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return n = a[0].node, i.canvas = n, o = n.getContext("2d"), e.next = 5, (0, l.default)({
                        emojiKey: i.data.selectId,
                        uniqueId: (0, r.default)(8),
                        emojis: i.filterEmojiText()
                    });

                  case 5:
                    return s = e.sent, e.next = 8, (0, c.createLocalImage)(o, n, i.data.selectId.map(function(e) {
                        return s.data.data.secBlockEmojiKeys.includes(e) ? "https://res.wx.qq.com/t/fed_upload/10fb5cee-1d45-4ace-936b-d1a70054863c/blockWithText.png" : i.data.faceList.find(function(t) {
                            return t.emojiKey === e;
                        }).imgBase64;
                    }), s.data.data.base64);

                  case 8:
                    wx.hideLoading(), i.onSave(), i.setData({
                        showActionsheet: !1,
                        isSavePhoto: !1
                    });

                  case 11:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    createshotPhoto: function() {
        var a = this;
        return t(e.default.mark(function t() {
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.abrupt("return", new Promise(function(e) {
                        wx.createSelectorQuery().select("#canvas").fields({
                            node: !0,
                            size: !0
                        }).exec(a.initCreateshotPhoto.bind(a, e));
                    }));

                  case 1:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    initCreateshotPhoto: function(a, i) {
        var n = this;
        return t(e.default.mark(function t() {
            var o, s, r;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return o = i[0].node, n.canvas = o, s = o.getContext("2d"), e.next = 5, (0, c.createTalkerImage)(s, o, n.data.selectId.map(function(e) {
                        return n.data.blockEmojiKey.includes(e) ? "https://res.wx.qq.com/t/fed_upload/10fb5cee-1d45-4ace-936b-d1a70054863c/block.png" : n.data.faceList.find(function(t) {
                            return t.emojiKey === e;
                        }).imgBase64;
                    }));

                  case 5:
                    return e.next = 7, n.onCreateshotPhoto();

                  case 7:
                    r = e.sent, n.setData({
                        shotPhotoPath: r
                    }), a(r);

                  case 10:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    onCreateshotPhoto: function() {
        var e = this;
        return new Promise(function(t) {
            var a = e.canvas.toDataURL("image/png"), i = wx.getFileSystemManager(), n = "".concat(wx.env.USER_DATA_PATH, "/").concat(Math.random().toString(36).substr(2), ".png");
            i.writeFile({
                filePath: n,
                data: a.split(",")[1],
                encoding: "base64",
                success: function() {
                    t(n);
                }
            });
        });
    },
    onSave: function() {
        var e = this, t = this.canvas.toDataURL("image/png"), a = wx.getFileSystemManager(), i = "".concat(wx.env.USER_DATA_PATH, "/").concat(Math.random().toString(36).substr(2), ".png");
        a.writeFile({
            filePath: i,
            data: t.split(",")[1],
            encoding: "base64",
            success: function() {
                wx.saveImageToPhotosAlbum({
                    filePath: i,
                    success: function() {
                        wx.showToast({
                            title: "已保存到系统相册"
                        });
                    },
                    fail: function() {
                        e.openConfirm();
                    }
                });
            }
        });
    },
    openConfirm: function() {
        wx.showModal({
            title: "无法保存图片到相册，你可以前往小程序「设置」中开启权限。",
            confirmText: "前往设置",
            cancelText: "我知道了",
            success: function(e) {
                e.confirm && wx.openSetting({
                    success: function(e) {}
                });
            }
        });
    },
    filterEmojiText: function() {
        var e = this;
        return this.data.selectId.map(function(t) {
            var a, i = e.data.faceList.find(function(e) {
                return e.emojiKey === t;
            });
            if (i) return {
                emojiKey: i.emojiKey,
                text: null == i || null === (a = i.layerInfo) || void 0 === a ? void 0 : a.map(function(e) {
                    if ("文字" === e.type) return e.text;
                }).filter(function(e) {
                    return e;
                })
            };
        }).filter(function(e) {
            return e;
        });
    },
    onJumpEmojiProfile: function() {
        wx.navigateTo({
            url: "/pages/emojiProfile/emojiProfile"
        });
    }
});