require("../../@babel/runtime/helpers/Arrayincludes");

var t = require("../../@babel/runtime/helpers/slicedToArray"), e = require("../../@babel/runtime/helpers/objectSpread2"), i = o(require("../../@babel/runtime/regenerator")), n = require("../../@babel/runtime/helpers/asyncToGenerator"), s = require("../../@babel/runtime/helpers/classCallCheck"), h = require("../../@babel/runtime/helpers/createClass"), r = o(require("./wx-drag/shape/text")), a = require("../../report/cube"), c = require("./wx-drag/utils/calculate"), l = o(require("@tencent/merlin-behavior"));

function o(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

var u = function() {
    function o(t, e, h) {
        var r = this;
        s(this, o), this._groupSelector = [], this.lastPixel = [], this.zoom = 1, this.fingers = [], 
        this.touches = null, this.initialXY = [], this._event = {}, this._initial = {}, 
        this.touchesFingers = null, this.selectTextCount = 0, this.editTimeWait = 0, this.historyGroup = [ [] ], 
        this.canvas = t, this.ctx = t.getContext("2d"), this._groupSelector = e.canvasData || [], 
        this.onChangeGourp = h.onChangeGourp, this.setSelectedIndex = h.setSelectedIndex, 
        this.doubleAction = h.doubleAction, this.setHistory = h.setHistory, this.isSmallScreen = h.isSmallScreen, 
        this.setIn("_event", {
            doubleFingerLock: !1,
            doubleCount: 0
        }), Promise.all(this._groupSelector.map(function() {
            var t = n(i.default.mark(function t(e) {
                var n;
                return i.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return t.next = 2, r.initImage({
                            url: e.url
                        }, function(t, e) {
                            e(t._img);
                        });

                      case 2:
                        n = t.sent, e.img = n;

                      case 4:
                      case "end":
                        return t.stop();
                    }
                }, t);
            }));
            return function(e) {
                return t.apply(this, arguments);
            };
        }())).then(function() {
            var t, i, n = wx.getSystemInfoSync().pixelRatio;
            r.dpr = n, r.canvas.width = e[0].width * n, r.canvas.height = e[0].width * n, r.ctx.scale(n, n);
            var s = wx.createOffscreenCanvas({
                type: "2d",
                heigth: r.canvas.height,
                width: r.canvas.width
            });
            r.cacheCanvas = s, Object.assign(r.cacheCanvas, {
                width: r.canvas.width,
                height: r.canvas.height
            });
            var h = r._groupSelector.reduce(function(t, e) {
                var i = Object.assign({}, e);
                return t.push(i), t;
            }, []);
            r.historyGroup = r._groupSelector.length > 0 ? [ h ] : [ [] ], r.pointer = null !== (t = (null === (i = r.historyGroup) || void 0 === i ? void 0 : i.length) - 1) && void 0 !== t ? t : 0, 
            r.closeIcon = r.canvas.createImage(), r.closeIcon.src = "../../assets/minus_BG.png", 
            r.scaleIcon = r.canvas.createImage(), r.scaleIcon.src = "../../assets/refresh_BG.png", 
            r.cachectx = s.getContext("2d"), r.cachectx.scale(n, n), r._groupSelector.forEach(function(t) {
                if (t.windows) {
                    var e = r.canvas.height / r.dpr / t.windows.height;
                    t.x = t.x * e, t.y = t.y * e, t.width = t.width * e, t.height = t.height * e, t.windows = {
                        width: r.canvas.width / r.dpr,
                        height: r.canvas.height / r.dpr
                    }, Object.assign(t.origin, {
                        x: t.x,
                        y: t.y
                    });
                }
            }), r.resetSelectRender(), 0 === r._groupSelector.length && (r.ctx.fillStyle = "#7c7c7c", 
            r.ctx.font = "".concat(r.canvas.width / r.dpr / 28, "px Arial"), r.ctx.fillText("添加元素开始制作", r.canvas.width / (2 * r.dpr) - r.canvas.width / r.dpr / 7.5, r.canvas.height / (2 * r.dpr) + r.canvas.width / r.dpr / 75));
        });
    }
    var u, d, g, v, f;
    return h(o, [ {
        key: "initImage",
        value: function(t, e) {
            var s = this, h = t.url, r = (t.type, arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 5);
            return r -= 1, new Promise(function(t, c) {
                var l = s.canvas.createImage(), o = wx.getStorageSync("faceListCache");
                if (o && o.length > 0) {
                    var u = o.find(function(t) {
                        return t.originUrl === h;
                    });
                    u && (h = u.tempFilePath);
                }
                l.src = h, l.onload = function() {
                    e({
                        _img: l,
                        _height: l.height,
                        _width: l.width
                    }, t);
                }, l.onerror = n(i.default.mark(function n() {
                    return i.default.wrap(function(i) {
                        for (;;) switch (i.prev = i.next) {
                          case 0:
                            if (!(r > 0)) {
                                i.next = 7;
                                break;
                            }
                            return wx.removeStorage({
                                key: "faceListCache"
                            }), i.next = 4, s.initImage({
                                url: h
                            }, e, r);

                          case 4:
                            t(), i.next = 8;
                            break;

                          case 7:
                            wx.showToast({
                                icon: "none",
                                title: "图片加载失败，请重试"
                            });

                          case 8:
                            (0, a.cubeError)("图片加载失败"), wx.removeStorage({
                                key: "faceListCache"
                            }), c();

                          case 11:
                          case "end":
                            return i.stop();
                        }
                    }, n);
                }));
            });
        }
    }, {
        key: "createNewImage",
        value: (f = n(i.default.mark(function t(n, s, h, r, a) {
            var c, l, o, u = this, d = arguments;
            return i.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (c = d.length > 5 && void 0 !== d[5] ? d[5] : "", l = d.length > 6 && void 0 !== d[6] && d[6], 
                    o = d.length > 7 && void 0 !== d[7] ? d[7] : 1, !(this._groupSelector.length > 30)) {
                        t.next = 6;
                        break;
                    }
                    return wx.showToast({
                        title: "最多允许添加30个元素",
                        icon: "none"
                    }), t.abrupt("return");

                  case 6:
                    return t.next = 8, this.initImage(n, function(t, i) {
                        var d = t._img, g = t._height, v = t._width;
                        u.setIn("_event", {
                            multiSelectedRect: {},
                            hasMultiSelect: !1,
                            multiSelect: !1
                        }), u._multiSelector = [], u._groupSelector.forEach(function(t, e) {
                            t.selected = !1, t.id = e;
                        }), "文字" !== n.type && "涂鸦" !== n.type || (g = a, v = r), u.setBaseProps(e(e({
                            img: d,
                            x: s,
                            y: h,
                            color: n.color || "",
                            width: v,
                            height: g,
                            url: n.url,
                            type: n.type,
                            text: c,
                            selected: !0
                        }, n), {}, {
                            isCopy: l,
                            opacity: o
                        })), u.resetRender(!0), wx.vibrateShort({
                            type: "medium"
                        }), i(u._groupSelector);
                    });

                  case 8:
                    return t.abrupt("return", t.sent);

                  case 9:
                  case "end":
                    return t.stop();
                }
            }, t, this);
        })), function(t, e, i, n, s) {
            return f.apply(this, arguments);
        })
    }, {
        key: "text",
        value: (v = n(i.default.mark(function t(e, n) {
            return i.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.next = 2, (0, r.default)(e, this.canvas.width, this.canvas.height, 100, n);

                  case 2:
                    return t.abrupt("return", t.sent);

                  case 3:
                  case "end":
                    return t.stop();
                }
            }, t, this);
        })), function(t, e) {
            return v.apply(this, arguments);
        })
    }, {
        key: "setDefaultPosition",
        value: function(t, e, i) {
            var n, s;
            return "脸型" !== t && "身体" !== t && "配饰" !== t || (n = this.canvas.width / (2 * this.dpr) - e / 2, 
            s = this.canvas.height / (2 * this.dpr) - i / 2), "眼睛" === t && (n = this.canvas.width / (2 * this.dpr) - e / 2, 
            s = this.canvas.height / (2 * this.dpr) - 1.2 * i), "嘴巴" === t && (n = this.canvas.width / (2 * this.dpr) - e / 2, 
            s = this.canvas.height / (2 * this.dpr) + .5 * i), "眉毛" === t && (n = this.canvas.width / (2 * this.dpr) - e / 2, 
            s = this.canvas.height / (2 * this.dpr) - 3 * i), "文字" === t && (n = this.canvas.width / (2 * this.dpr) - e / 2, 
            s = this.canvas.height / (2 * this.dpr) - i / 2), [ n, s ];
        }
    }, {
        key: "setBaseProps",
        value: function(e) {
            var i, n, s, h, r = e.img, a = void 0 === r ? "" : r, c = e.width, l = e.height, o = e.x, u = e.y, d = e.url, g = void 0 === d ? "" : d, v = e.type, f = e.text, p = void 0 === f ? "" : f, x = e.selected, y = void 0 !== x && x, m = e.color, _ = void 0 === m ? "" : m, I = e.mirror, w = void 0 !== I && I, S = e.angle, b = void 0 === S ? 0 : S, k = e.isCopy, A = e.opacity, M = void 0 === A ? 1 : A;
            k || ("身体" === v && (c *= .7, l *= .7), "嘴巴" === v && (c *= .5, l *= .5), "脸型" === v && (c *= .85, 
            l *= .85), "眼睛" === v && (c *= .8, l *= .8), "眉毛" === v && (c *= .4, l *= .4));
            var E = this.setDefaultPosition(v, c, l), C = t(E, 2), P = C[0], R = C[1];
            P && R && (o = P, u = R), g && this._groupSelector.some(function(t) {
                return t.url === g;
            }) && (o += 16 * (Math.floor(8 * Math.random()) - 4), u += 16 * (Math.floor(8 * Math.random()) - 4)), 
            this._groupSelector.push({
                id: this._groupSelector.length,
                img: a,
                x: o,
                y: u,
                width: c,
                height: l,
                scale: 1,
                opacity: M,
                canvasType: v,
                url: g,
                type: v,
                selected: y,
                color: _,
                text: p,
                mirror: w,
                angle: b,
                extraAngle: [],
                cid: g.length > 0 && "文字" !== v && "涂鸦" !== v && null !== (i = v + (null == g || null === (n = g.match(/\d*\.png/)) || void 0 === n || null === (s = n[0]) || void 0 === s || null === (h = s.split(".")) || void 0 === h ? void 0 : h[0])) && void 0 !== i ? i : "",
                hidden: !1,
                origin: {
                    img: a,
                    x: o,
                    y: u,
                    width: c,
                    height: l,
                    angle: 0,
                    scale: 1
                },
                windows: {
                    height: this.canvas.height / this.dpr,
                    width: this.canvas.width / this.dpr
                }
            }), this.pushHistory();
        }
    }, {
        key: "renderBackground",
        value: function() {
            this.ctx.save(), this.ctx.globalAlpha = 1, this.ctx.fillStyle = "#F7F7F7", this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height), 
            this.ctx.restore(), this.ctx.beginPath(), this.ctx.globalAlpha = .1, this.ctx.lineWidth = .5, 
            this.ctx.moveTo(this.canvas.width / this.dpr / 2, 0), this.ctx.lineTo(this.canvas.width / this.dpr / 2, this.canvas.height / this.dpr), 
            this.ctx.moveTo(0, 0), this.ctx.lineTo(this.canvas.width / this.dpr, 0), this.isSmallScreen && (this.ctx.moveTo(this.canvas.width / this.dpr, 0), 
            this.ctx.lineTo(this.canvas.width / this.dpr, this.canvas.height / this.dpr), this.ctx.moveTo(0, 0), 
            this.ctx.lineTo(0, this.canvas.height / this.dpr)), this.ctx.moveTo(0, this.canvas.height / this.dpr / 2), 
            this.ctx.lineTo(this.canvas.width / this.dpr, this.canvas.height / this.dpr / 2), 
            this.ctx.stroke(), this.ctx.beginPath(), this.ctx.moveTo(0, this.canvas.height / this.dpr), 
            this.ctx.lineTo(this.canvas.width / this.dpr, this.canvas.height / this.dpr), this.ctx.stroke(), 
            this.ctx.setLineDash([ 6, 10 ]), this.ctx.lineDashOffset = 6, this.ctx.beginPath(), 
            this.ctx.moveTo(0, 0), this.ctx.lineTo(this.canvas.width / this.dpr, this.canvas.height / this.dpr), 
            this.ctx.moveTo(this.canvas.width / this.dpr, 0), this.ctx.lineTo(0, this.canvas.height / this.dpr), 
            this.ctx.stroke(), this.ctx.globalAlpha = 1, this.ctx.lineWidth = 1, this.ctx.setLineDash([ 0, 0 ]), 
            this.ctx.lineDashOffset = 0;
        }
    }, {
        key: "render",
        value: function() {
            var t = this;
            if (this._groupSelector && this._groupSelector.length > 0) {
                if (this.ctx.save(), this._groupSelector.forEach(function(e) {
                    t.drawImage(e);
                }), this.ctx.restore(), this.getIn("_event", "hasMultiSelect") && this.drawRect(this.ctx, this.getIn("_event", "multiSelectedRect"), !0), 
                !this.getIn("_event", "hasMultiSelect") && this._groupSelector.filter(function(t) {
                    return t.selected;
                }).length > 1) return;
                this._groupSelector.forEach(function(e) {
                    e.selected && t.drawRect(t.ctx, e);
                });
            }
        }
    }, {
        key: "renderPure",
        value: function() {
            var t = this;
            this.ctx.save(), this._groupSelector.forEach(function(e) {
                t.drawImage(e);
            }), this.ctx.restore();
        }
    }, {
        key: "drawRect",
        value: function(e, i) {
            var n = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
            if (!i.hidden) {
                e.save(), i.extraAngle && i.extraAngle.forEach(function(t) {
                    e.translate(t.centerX, t.centerY), e.rotate(t.angle), e.translate(-t.centerX, -t.centerY);
                });
                var s, h = this.getCenterPoint(i), r = t(h, 2), a = r[0], c = r[1];
                if (e.globalAlpha = 1, e.translate(a, c), e.rotate(i.angle), e.translate(-a, -c), 
                e.beginPath(), e.strokeStyle = "#07C160", n && (e.fillStyle = "rgba(7, 193, 96, 0.1)", 
                e.fillRect(i.x - 10, i.y - 10, i.width + 20, i.height + 20)), e.rect(i.x - 10, i.y - 10, i.width + 20, i.height + 20), 
                e.stroke(), !i.multiSelected) (this.getIn("_event", "hasMultiSelect") && !i.type || !this.getIn("_event", "hasMultiSelect") && (null == i || null === (s = i.type) || void 0 === s ? void 0 : s.length) > 0) && (e.drawImage(this.closeIcon, i.x - 24, i.y - 24, 24, 24), 
                e.drawImage(this.scaleIcon, i.x + i.width, i.y + i.height, 24, 24));
                e.restore();
            }
        }
    }, {
        key: "clear",
        value: function() {
            this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height), this.cachectx.clearRect(0, 0, this.canvas.width, this.canvas.height), 
            this.renderBackground();
        }
    }, {
        key: "clearPure",
        value: function() {
            this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height), this.cachectx.clearRect(0, 0, this.canvas.width, this.canvas.height);
        }
    }, {
        key: "clearCache",
        value: function() {
            this.cachectx.clearRect(0, 0, this.canvas.width, this.canvas.height);
        }
    }, {
        key: "delete",
        value: function() {
            l.default.reportElementClick({
                key: "delete"
            }), this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height), this.cachectx.clearRect(0, 0, this.canvas.width, this.canvas.height), 
            this._groupSelector = [];
        }
    }, {
        key: "getImageData",
        value: function(t, e, i, n) {
            return Array.from(this.cachectx.getImageData(t * this.dpr, e * this.dpr, i * this.dpr, n * this.dpr).data);
        }
    }, {
        key: "drawImage",
        value: function(t) {
            this.drawImg(this.ctx, t), this.drawCacheImage(t);
        }
    }, {
        key: "drawCacheImage",
        value: function(t) {
            this.drawImg(this.cachectx, t);
        }
    }, {
        key: "getCenterPoint",
        value: function(t) {
            return [ t.x + t.width / 2, t.y + t.height / 2 ];
        }
    }, {
        key: "getCurrentPoint",
        value: function(e) {
            var i = e.x + e.width / 2, n = e.y + e.height / 2;
            return e.extraAngle && e.extraAngle.forEach(function(e) {
                var s = (0, c.getEndPointByRotate)([ i, n ], [ e.centerX, e.centerY ], e.angle), h = t(s, 2);
                i = h[0], n = h[1];
            }), [ i, n ];
        }
    }, {
        key: "drawImg",
        value: function(e, i) {
            if (!i.hidden) {
                var n;
                e.save(), i.extraAngle && i.extraAngle.forEach(function(t) {
                    e.translate(t.centerX, t.centerY), e.rotate(t.angle), e.translate(-t.centerX, -t.centerY);
                }), i.selected && (e.globalAlpha = 1), e.globalAlpha = null !== (n = i.opacity) && void 0 !== n ? n : 1;
                var s = this.getCenterPoint(i), h = t(s, 2), r = h[0], a = h[1];
                e.translate(r, a), e.rotate(i.angle), i.mirror && e.scale(-1, 1), e.translate(-r, -a), 
                e.drawImage(i.img, i.x, i.y, i.width, i.height), e.restore();
            }
        }
    }, {
        key: "getDistance",
        value: function(t, e) {
            return Math.hypot(e.x - t.x, e.y - t.y);
        }
    }, {
        key: "isInWhere",
        value: function(e, i) {
            var n, s, h, r, a = (null === (n = i.touches[0]) || void 0 === n ? void 0 : n.x) || (null === (s = i.changedTouches[0]) || void 0 === s ? void 0 : s.x) || 0, c = (null === (h = i.touches[0]) || void 0 === h ? void 0 : h.y) || (null === (r = i.changedTouches[0]) || void 0 === r ? void 0 : r.y) || 0, l = this.getCurrentRotatePoint(e), o = t(l.scale, 2), u = o[0], d = o[1], g = t(l.close, 2), v = g[0], f = g[1];
            return e.x + e.width >= a && a >= e.x && e.y + e.height >= c && c >= e.y ? "area" : a - v >= -30 && c - f >= -30 && a - v <= 30 && c - f <= 30 ? "close" : a - u >= -30 && a - u <= 30 && c - d >= -30 && c - d <= 30 ? "scale" : "";
        }
    }, {
        key: "_deleteItem",
        value: function(t) {
            l.default.reportElementClick({
                key: "delete"
            }), this._groupSelector.splice(this._groupSelector.findIndex(function(e) {
                return e.id === t;
            }), 1), this.initialXY = [], this.touches = {}, this.onChangeGourp(!0), this.resetSelectRender(), 
            this.pushHistory();
        }
    }, {
        key: "_deleteItems",
        value: function(t) {
            l.default.reportElementClick({
                key: "batch_delete",
                extInfo: {
                    count: t.length
                }
            }), this._groupSelector = this._groupSelector.filter(function(e) {
                return !t.includes(e.id);
            }), this.initialXY = [], this.touches = {}, this.onChangeGourp(!0), this.resetSelectRender(), 
            this.pushHistory();
        }
    }, {
        key: "deleteItem",
        value: function(t) {
            l.default.reportElementClick({
                key: "delete"
            }), this._groupSelector.splice(this._groupSelector.findIndex(function(e) {
                return e.id === t;
            }), 1), this.initialXY = [], this.touches = {}, this.onChangeGourp(!0), this.resetSelectRender(), 
            this.pushHistory();
        }
    }, {
        key: "isExistSelect",
        value: function() {
            return this._groupSelector.some(function(t) {
                return t.selected;
            });
        }
    }, {
        key: "getSelectedItem",
        value: function() {
            return this._groupSelector.find(function(t) {
                return t.selected;
            });
        }
    }, {
        key: "getAreaSelectdItem",
        value: function(t) {
            var e, i = this, n = t.touches[0] || t.changedTouches[0];
            n.x, n.y;
            return this._groupSelector.forEach(function(n, s, h) {
                "area" === i.isInWhere(n, t) && (h.forEach(function(t) {
                    t.selected = !1;
                }), n.selected = !0, e = n);
            }), e;
        }
    }, {
        key: "setIn",
        value: function(t, e) {
            Object.assign(this[t], e);
        }
    }, {
        key: "getIn",
        value: function(t, e) {
            return (0, c.get)(this[t], e);
        }
    }, {
        key: "getCurrentRotatePoint",
        value: function(e) {
            var i = [ e.x, e.y ], n = i[0], s = i[1], h = e.x + e.width, r = e.y + e.height;
            e.extraAngle && e.extraAngle.forEach(function(e) {
                var i = (0, c.getEndPointByRotate)([ n, s ], [ e.centerX, e.centerY ], e.angle), a = t(i, 2);
                n = a[0], s = a[1];
                var l = (0, c.getEndPointByRotate)([ h, r ], [ e.centerX, e.centerY ], e.angle), o = t(l, 2);
                h = o[0], r = o[1];
            });
            var a = this.getCenterPoint(e), l = t(a, 2), o = l[0], u = l[1], d = (0, c.getEndPointByRotate)([ n, s ], [ o, u ], e.angle), g = t(d, 2);
            n = g[0], s = g[1];
            var v = (0, c.getEndPointByRotate)([ h, r ], [ o, u ], e.angle), f = t(v, 2);
            return h = f[0], r = f[1], {
                scale: [ h, r ],
                close: [ n, s ]
            };
        }
    }, {
        key: "curtouchstart",
        value: function(t) {
            var e = this;
            1 == t.touches.length ? (this.setIn("_initial", {
                hasTouchStart: !1
            }), this.touchTimer = setTimeout(function() {
                e.touchstart(t);
            }, 30)) : (clearTimeout(this.touchTimer), this.touchstart(t));
        }
    }, {
        key: "singletouchestart",
        value: function(t) {}
    }, {
        key: "multitouchstart",
        value: function(e) {
            this._multiSelector.length;
            var i = this.getIn("_event", "multiSelectedRect");
            if (this.setIn("_initial", {
                initialAngle: i.angle,
                initialXY: [ i.x, i.y ],
                initialWH: [ i.width, i.height ],
                initialEndXY: this.getCurrentRotatePoint(i).scale
            }), this._multiSelector.forEach(function(t) {
                t.multiOriginX = t.x, t.multiOriginY = t.y, t.multiOriginHeight = t.height, t.multiOriginWidth = t.width;
            }), "close" === this.isInWhere(i, e)) return this._deleteItems(this._multiSelector.map(function(t) {
                return t.id;
            })), this._multiSelector = [], this.setIn("_event", {
                multiSelectedRect: {},
                hasMultiSelect: !1
            }), this.setIn("_initial", {
                stick: "close"
            }), "close";
            if ("scale" === this.isInWhere(i, e)) {
                var n = t(this.getCurrentRotatePoint(i).scale, 2), s = n[0], h = n[1];
                return this.setIn("_initial", {
                    stick: "scale",
                    touches: [ {
                        x: s,
                        y: h
                    } ]
                }), this.render(), "scale";
            }
            return "area" === this.isInWhere(i, e) ? (this.setIn("_initial", {
                stick: "area"
            }), this.render(), "area") : null;
        }
    }, {
        key: "singleSelectedTouchstart",
        value: function(t) {
            var e = this, i = !1, n = this._groupSelector.find(function(t) {
                return t.selected;
            });
            if (n) {
                if (this.setIn("_initial", {
                    initialAngle: n.angle,
                    initialXY: [ n.x, n.y ],
                    initialWH: [ n.width, n.height ],
                    touches: [ {
                        x: t.touches[0].x,
                        y: t.touches[0].y
                    } ]
                }), "文字" === n.type && "area" === this.isInWhere(n, t)) {
                    this.selectTextCount = 1, this.editTimeWait = 0;
                    var s = setInterval(function() {
                        e.editTimeWait++, e.editTimeWait > 6 && clearInterval(s);
                    }, 200);
                } else this.selectTextCount = 0;
                if ("close" === this.isInWhere(n, t)) return this._deleteItem(n.id), this.setIn("_initial", {
                    stick: "close"
                }), !0;
                if ("scale" === this.isInWhere(n, t)) return this.setIn("_initial", {
                    stick: "scale",
                    initialEndXY: this.getCurrentRotatePoint(n).scale
                }), this.render(), !0;
            }
            return this._groupSelector.forEach(function(n, s, h) {
                if ("area" === e.isInWhere(n, t)) {
                    if (e.setSelectedIndex(h.length - s - 1), "脸型" === n.type) {
                        e.drawCacheImage(n);
                        var r = e.getImageData(t.touches[0].x, t.touches[0].y, 1, 1);
                        if (r.filter(function(t) {
                            return 0 != t;
                        }).length > 0) {
                            if ((0, c.equar)(r, e.lastPixel)) return;
                            h.forEach(function(t) {
                                t.selected = !1;
                            }), n.selected = !0, e.setIn("_initial", {
                                initialAngle: n.angle,
                                initialXY: [ n.x, n.y ]
                            });
                        }
                        e.lastPixel = r;
                    } else h.forEach(function(t) {
                        t.selected = !1;
                    }), n.selected = !0, e.setIn("_initial", {
                        initialAngle: n.angle,
                        initialXY: [ n.x, n.y ],
                        originZoom: n.scale,
                        initialWH: [ n.width, n.height ]
                    });
                    i = !0;
                }
            }), i;
        }
    }, {
        key: "touchstart",
        value: function(t) {
            if (this.setIn("_event", {
                hasStart: !0
            }), this.setIn("_initial", {
                hasTouchStart: !0
            }), 2 != this.getIn("_event", "doubleCount")) {
                this.setIn("_initial", {
                    stick: null,
                    touches: t.touches
                }), this.setIn("_event", {
                    doubleFingerLock: !1
                }), this.setIn("_event", {
                    slideMove: !1
                }), this.lastPixel = [], this.clear();
                var e = !1;
                if (1 === t.touches.length) {
                    var i;
                    if (this.getIn("_event", "hasMultiSelect")) {
                        if (this.multitouchstart(t)) return;
                    } else e = this.singleSelectedTouchstart(t);
                    e && this.setIn("_event", {
                        multiSelect: !1
                    }), e || this.isExistSelect() || null !== (i = this._multiSelector) && void 0 !== i && i.some(function(t) {
                        return t.multiSelected;
                    }) || (this._multiSelector = null, this.setIn("_event", {
                        multiSelect: !0,
                        hasMultiSelect: !1,
                        multiSelectedRect: {}
                    }), this.setIn("_initial", {
                        multiSelectStart: [ t.touches[0].x, t.touches[0].y ]
                    }));
                } else if (2 === t.touches.length && !this.getIn("_event", "doubleFingerLock") && !this.getIn("_event", "hasMultiSelect")) {
                    var n;
                    this.isExistSelect() ? (n = this.getSelectedItem(), this.setIn("_initial", {
                        stick: null
                    })) : n = this.getAreaSelectdItem(t), n && this.setIn("_initial", {
                        initialAngle: n.angle,
                        initialXY: [ n.x, n.y ],
                        originZoom: n.scale,
                        initialWH: [ n.width, n.height ]
                    });
                }
                this.render(), this.setIn("_event", {
                    doubleEvent: !0
                });
            }
        }
    }, {
        key: "multitouchmove",
        value: function(e) {
            var i = this, n = this.getIn("_event", "multiSelectedRect"), s = this.getIn("_initial", "initialXY"), h = t(s, 2), r = h[0], a = h[1], c = this.getIn("_initial", "initialWH"), l = t(c, 2), o = l[0], u = l[1], d = this.getIn("_initial", "initialEndXY"), g = t(d, 2), v = g[0], f = g[1], p = this.getIn("_initial", "initialAngle"), x = this.getIn("_initial", "touches"), y = this.getIn("_initial", "stick"), m = this.getCenterPoint(n), _ = t(m, 2), I = _[0], w = _[1];
            if ("scale" === y) {
                var S = p, b = Math.atan2(f - w, v - I), k = Math.atan2(e.touches[0].y - w, e.touches[0].x - I) - b + S, A = Math.sqrt(Math.pow(I - r, 2) + Math.pow(w - a, 2)), M = Math.sqrt(Math.pow(I - e.touches[0].x, 2) + Math.pow(w - e.touches[0].y, 2)), E = o + (M - A), C = u + u / o * (M - A);
                n.width = E <= 5 ? 5 : E, n.height = C <= 5 ? 5 : C, E > 5 && C > 5 && (n.x = r - (M - A) / 2, 
                n.y = a - u / o * (M - A) / 2), Object.assign(n, {
                    angle: k
                });
                var P = [ 0, 90, -180, -90 ].find(function(t) {
                    return Math.abs(Math.round(k / Math.PI * 180) - t) < 2.5;
                });
                void 0 !== P ? (this.getIn("_initial", "firstAdsorbAngle") || (this.setIn("_initial", {
                    adsorbAngle: k,
                    firstAdsorbAngle: !0
                }), wx.vibrateShort({
                    type: "medium"
                })), Object.assign(n, {
                    angle: P * Math.PI / 180
                })) : this.setIn("_initial", {
                    firstAdsorbAngle: !1
                });
            } else {
                var R = this.limitXY(n, r + e.touches[0].x - x[0].x, a + e.touches[0].y - x[0].y), T = t(R, 2), X = T[0], Y = T[1];
                Object.assign(n, {
                    x: X,
                    y: Y
                });
            }
            I * this.dpr <= this.canvas.width / 2 + 10 && I * this.dpr >= this.canvas.width / 2 - 10 && (this.getIn("_initial", "firstAdsorbX") && (this.setIn("_initial", {
                adsorbX: e.touches[0].x,
                firstAdsorbX: !1
            }), "scale" !== this.getIn("_initial", "stick") && wx.vibrateShort({
                type: "medium"
            })), this.ctx.save(), this.ctx.beginPath(), this.ctx.strokeStyle = "#57be6a", this.ctx.moveTo(this.canvas.width / this.dpr / 2, 0), 
            this.ctx.lineTo(this.canvas.width / this.dpr / 2, this.canvas.height / this.dpr), 
            this.ctx.stroke(), this.ctx.restore(), Math.abs(e.touches[0].x - this.getIn("_initial", "adsorbX")) <= 10 ? Object.assign(n, {
                x: this.canvas.width / this.dpr / 2 - n.width / 2
            }) : this.setIn("_initial", {
                firstAdsorbX: !0
            })), w * this.dpr <= this.canvas.height / 2 + 10 && w * this.dpr >= this.canvas.height / 2 - 10 && (this.getIn("_initial", "firstAdsorbY") && (this.setIn("_initial", {
                adsorbY: e.touches[0].y,
                firstAdsorbY: !1
            }), "scale" !== this.getIn("_initial", "stick") && wx.vibrateShort({
                type: "medium"
            })), this.ctx.save(), this.ctx.beginPath(), this.ctx.strokeStyle = "#57be6a", this.ctx.moveTo(0, this.canvas.height / this.dpr / 2), 
            this.ctx.lineTo(this.canvas.width / this.dpr, this.canvas.height / this.dpr / 2), 
            this.ctx.stroke(), this.ctx.restore(), Math.abs(e.touches[0].y - this.getIn("_initial", "adsorbY")) <= 10 ? Object.assign(n, {
                y: this.canvas.height / this.dpr / 2 - n.height / 2
            }) : this.setIn("_initial", {
                firstAdsorbY: !0
            })), this.setIn("_event", {
                multiSelectedRect: n
            }), this._groupSelector.forEach(function(t) {
                var s = i._multiSelector.find(function(e) {
                    return e.id === t.id;
                });
                if (s) if ("scale" === y) {
                    t.height = n.height / u * s.multiOriginHeight, t.width = n.width / o * s.multiOriginWidth, 
                    t.extraAngle[s.multiNumber] = {
                        angle: n.angle - (i.getIn("_initial", "multiRotateAngle") || 0),
                        centerX: I,
                        centerY: w
                    };
                    var h = s.multiOriginX + s.multiOriginWidth / 2 > I ? I + Math.abs(I - (s.multiOriginX + s.multiOriginWidth / 2)) * (n.width / o) - t.width / 2 : I - Math.abs(I - (s.multiOriginX + s.multiOriginWidth / 2)) * (n.width / o) - t.width / 2, r = s.multiOriginY + s.multiOriginHeight / 2 > w ? w + Math.abs(w - (s.multiOriginY + s.multiOriginHeight / 2)) * (n.height / u) - t.height / 2 : w - Math.abs(w - (s.multiOriginY + s.multiOriginHeight / 2)) * (n.height / u) - t.height / 2;
                    t.x = h, t.y = r;
                } else t.x = n.x === i.canvas.width / i.dpr / 2 - n.width / 2 || i.isLimitXY(n, n.x, n.y)[0] ? t.x : s.multiOriginX + e.touches[0].x - x[0].x, 
                t.y = n.y === i.canvas.height / i.dpr / 2 - n.height / 2 || i.isLimitXY(n, n.x, n.y)[1] ? t.y : s.multiOriginY + e.touches[0].y - x[0].y;
            });
        }
    }, {
        key: "touchmove",
        value: function(e) {
            var i = this;
            if (this.getIn("_event", "multiSelect")) return this.multiSelect(e), void this.setIn("_event", {
                slideMove: !0
            });
            if (this.getIn("_initial", "hasTouchStart") && (this.isExistSelect() || this.getIn("_event", "hasMultiSelect"))) {
                if (this.clear(), this.setIn("_event", {
                    slideMove: !0
                }), 1 !== e.touches.length || this.getIn("_event", "doubleFingerLock")) {
                    if (2 === e.touches.length && !this.getIn("_event", "hasMultiSelect")) {
                        this.setIn("_event", {
                            doubleFingerLock: !0,
                            doubleCount: 2
                        });
                        var n = this.getIn("_initial", "initialXY"), s = this.getIn("_initial", "initialWH"), h = this.getIn("_initial", "touches"), r = this.getIn("_initial", "initialAngle"), a = this.getIn("_initial", "originZoom");
                        this._groupSelector.map(function(l) {
                            if (l.selected) {
                                var o = i.getCenterPoint(l), u = t(o, 2), d = u[0], g = u[1], v = t(n, 2), f = v[0], p = v[1], x = t(s, 2), y = x[0], m = x[1], _ = e.touches.find(function(t) {
                                    return t.identifier === h[0].identifier;
                                }), I = e.touches.find(function(t) {
                                    return t.identifier === h[1].identifier;
                                });
                                _ || (_ = e.touches.find(function(t) {
                                    return t.identifier !== h[1].identifier;
                                })), I || (I = e.touches.find(function(t) {
                                    return t.identifier !== h[0].identifier;
                                }));
                                var w = i.getDistance(_, I) / i.getDistance(h[0], h[1]), S = (0, c.getRotateAngle)(h[0], h[1], _, I);
                                Object.assign(l, {
                                    img: l.img,
                                    x: f - (w - 1) * y / 2,
                                    y: p - (w - 1) * m / 2,
                                    width: y * w,
                                    height: m * w,
                                    angle: r + S,
                                    scale: w * a
                                });
                                var b = [ 0, 90, -180, -90 ].find(function(t) {
                                    return Math.abs(Math.round(l.angle / Math.PI * 180) - t) < 2.5;
                                });
                                void 0 !== b ? (i.getIn("_initial", "firstAdsorbAngle") || (i.setIn("_initial", {
                                    firstAdsorbAngle: !0
                                }), wx.vibrateShort({
                                    type: "medium"
                                })), Object.assign(l, {
                                    angle: b * Math.PI / 180
                                })) : i.setIn("_initial", {
                                    firstAdsorbAngle: !1
                                }), d * i.dpr <= i.canvas.width / 2 + 10 && d * i.dpr >= i.canvas.width / 2 - 10 && (i.getIn("_initial", "firstAdsorbX") && (i.setIn("_initial", {
                                    adsorbX: _.x,
                                    firstAdsorbX: !1
                                }), "scale" !== i.getIn("_initial", "stick") && 1 == e.touches.length && wx.vibrateShort({
                                    type: "medium"
                                })), i.ctx.save(), i.ctx.beginPath(), i.ctx.strokeStyle = "#57be6a", i.ctx.moveTo(i.canvas.width / i.dpr / 2, 0), 
                                i.ctx.lineTo(i.canvas.width / i.dpr / 2, i.canvas.height / i.dpr), i.ctx.stroke(), 
                                i.ctx.restore(), Math.abs(_.x - i.getIn("_initial", "adsorbX")) <= 10 ? Object.assign(l, {
                                    x: i.canvas.width / i.dpr / 2 - l.width / 2
                                }) : i.setIn("_initial", {
                                    firstAdsorbX: !0
                                })), g * i.dpr <= i.canvas.height / 2 + 10 && g * i.dpr >= i.canvas.height / 2 - 10 && (i.getIn("_initial", "firstAdsorbY") && (i.setIn("_initial", {
                                    adsorbY: _.y,
                                    firstAdsorbY: !1
                                }), "scale" !== i.getIn("_initial", "stick") && 1 == e.touches.length && wx.vibrateShort({
                                    type: "medium"
                                })), i.ctx.save(), i.ctx.beginPath(), i.ctx.strokeStyle = "#57be6a", i.ctx.moveTo(0, i.canvas.height / i.dpr / 2), 
                                i.ctx.lineTo(i.canvas.width / i.dpr, i.canvas.height / i.dpr / 2), i.ctx.stroke(), 
                                i.ctx.restore(), Math.abs(_.y - i.getIn("_initial", "adsorbY")) <= 10 ? Object.assign(l, {
                                    y: i.canvas.height / i.dpr / 2 - l.height / 2
                                }) : i.setIn("_initial", {
                                    firstAdsorbY: !0
                                }));
                            }
                        });
                    }
                } else if (this.getIn("_event", "hasMultiSelect")) this.multitouchmove(e); else {
                    this.isExistSelect() && (this.ctx.globalAlpha = .6);
                    var l = this.getIn("_initial", "initialXY"), o = t(l, 2), u = o[0], d = o[1], g = this.getIn("_initial", "initialWH"), v = this.getIn("_initial", "initialEndXY"), f = this.getIn("_initial", "initialAngle"), p = this.getIn("_initial", "touches"), x = this.getIn("_initial", "stick");
                    this._groupSelector.forEach(function(n) {
                        if (n.selected) {
                            var s = i.getCenterPoint(n), h = t(s, 2), r = h[0], a = h[1];
                            if ("scale" === x) {
                                var c = t(g, 2), l = c[0], o = c[1], y = t(v, 2), m = y[0], _ = y[1], I = f, w = Math.atan2(_ - a, m - r), S = Math.atan2(e.touches[0].y - a, e.touches[0].x - r) - w + I, b = Math.sqrt(Math.pow(r - u, 2) + Math.pow(a - d, 2)), k = Math.sqrt(Math.pow(r - e.touches[0].x, 2) + Math.pow(a - e.touches[0].y, 2));
                                if (n.height >= n.width) {
                                    var A = l + l / o * (k - b), M = o + (k - b);
                                    n.width = A <= 5 ? 5 : A, n.height = M <= 5 ? 5 : M, A > 5 && M > 5 && (n.x = u - l / o * (k - b) / 2, 
                                    n.y = d - (k - b) / 2);
                                } else {
                                    var E = l + (k - b), C = o + o / l * (k - b);
                                    n.width = E <= 5 ? 5 : E, n.height = C <= 5 ? 5 : C, E > 5 && C > 5 && (n.x = u - (k - b) / 2, 
                                    n.y = d - o / l * (k - b) / 2);
                                }
                                S > Math.PI ? S -= 2 * Math.PI : S < -Math.PI && (S += 2 * Math.PI), Object.assign(n, {
                                    angle: S
                                });
                                var P = [ 0, 90, -180, -90 ].find(function(t) {
                                    return Math.abs(Math.round(S / Math.PI * 180) - t) < 2.5;
                                });
                                void 0 !== P ? (i.getIn("_initial", "firstAdsorbAngle") || (i.setIn("_initial", {
                                    adsorbAngle: S,
                                    firstAdsorbAngle: !0
                                }), wx.vibrateShort({
                                    type: "medium"
                                })), Object.assign(n, {
                                    angle: P * Math.PI / 180
                                })) : i.setIn("_initial", {
                                    firstAdsorbAngle: !1
                                });
                            } else {
                                var R = i.limitXY(n, u + e.touches[0].x - p[0].x, d + e.touches[0].y - p[0].y), T = t(R, 2), X = T[0], Y = T[1];
                                Object.assign(n, {
                                    x: X,
                                    y: Y
                                });
                            }
                            r * i.dpr <= i.canvas.width / 2 + 10 && r * i.dpr >= i.canvas.width / 2 - 10 && (i.getIn("_initial", "firstAdsorbX") && (i.setIn("_initial", {
                                adsorbX: e.touches[0].x,
                                firstAdsorbX: !1
                            }), "scale" !== i.getIn("_initial", "stick") && wx.vibrateShort({
                                type: "medium"
                            })), i.ctx.save(), i.ctx.beginPath(), i.ctx.strokeStyle = "#57be6a", i.ctx.moveTo(i.canvas.width / i.dpr / 2, 0), 
                            i.ctx.lineTo(i.canvas.width / i.dpr / 2, i.canvas.height / i.dpr), i.ctx.stroke(), 
                            i.ctx.restore(), Math.abs(e.touches[0].x - i.getIn("_initial", "adsorbX")) <= 10 ? Object.assign(n, {
                                x: i.canvas.width / i.dpr / 2 - n.width / 2
                            }) : i.setIn("_initial", {
                                firstAdsorbX: !0
                            })), a * i.dpr <= i.canvas.height / 2 + 10 && a * i.dpr >= i.canvas.height / 2 - 10 && (i.getIn("_initial", "firstAdsorbY") && (i.setIn("_initial", {
                                adsorbY: e.touches[0].y,
                                firstAdsorbY: !1
                            }), "scale" !== i.getIn("_initial", "stick") && wx.vibrateShort({
                                type: "medium"
                            })), i.ctx.save(), i.ctx.beginPath(), i.ctx.strokeStyle = "#57be6a", i.ctx.moveTo(0, i.canvas.height / i.dpr / 2), 
                            i.ctx.lineTo(i.canvas.width / i.dpr, i.canvas.height / i.dpr / 2), i.ctx.stroke(), 
                            i.ctx.restore(), Math.abs(e.touches[0].y - i.getIn("_initial", "adsorbY")) <= 10 ? Object.assign(n, {
                                y: i.canvas.height / i.dpr / 2 - n.height / 2
                            }) : i.setIn("_initial", {
                                firstAdsorbY: !0
                            }));
                        }
                    });
                }
                this.render();
            }
        }
    }, {
        key: "touchend",
        value: function(e) {
            var i, n = this;
            if (!this.getIn("_event", "hasStart")) {
                var s = this._groupSelector.find(function(t) {
                    return t.selected;
                });
                s && "close" === this.isInWhere(s, e) && this.getIn("_event", "hasMultiSelect") && (this._deleteItems(this._multiSelector.map(function(t) {
                    return t.id;
                })), this._multiSelector = [], this.setIn("_event", {
                    multiSelectedRect: {},
                    hasMultiSelect: !1
                }), this.setIn("_initial", {
                    stick: "close"
                }));
            }
            if (this.setIn("_initial", {
                hasTouchStart: !1
            }), this.setIn("_initial", {
                multiRotateAngle: (null === (i = this.getIn("_event", "multiSelectedRect")) || void 0 === i ? void 0 : i.angle) || 0
            }), this.initMultiPosition(), this.getIn("_event", "doubleFingerLock") && (this.setIn("_event", {
                doubleCount: this.getIn("_event", "doubleCount") - 1
            }), this.setIn("_initial", {
                touches: e.changedTouches
            })), this.globalAlpha = 1, this.getIn("_event", "slideMove") || this.getIn("_event", "doubleFingerLock")) {
                if (this.getIn("_initial", "initialXY") && this.getIn("_initial", "initialWH") && void 0 !== this.getIn("_initial", "initialAngle")) {
                    var h = this._groupSelector.find(function(t) {
                        return t.selected;
                    }), r = this.getIn("_initial", "initialXY"), a = t(r, 2), c = a[0], o = a[1], u = this.getIn("_initial", "initialWH"), d = t(u, 2), g = d[0], v = d[1], f = this.getIn("_initial", "initialAngle");
                    (null == h ? void 0 : h.x) === c && (null == h ? void 0 : h.y) === o || l.default.reportElementClick({
                        key: "move",
                        extInfo: {
                            isInner: "area" === this.isInWhere(h, e) ? 1 : 0
                        }
                    }), (null == h ? void 0 : h.width) === g && (null == h ? void 0 : h.height) === v || l.default.reportElementClick({
                        key: "zoom"
                    }), (null == h ? void 0 : h.angle) !== f && l.default.reportElementClick({
                        key: "rotate"
                    });
                }
                this.getIn("_event", "multiSelect") || this.pushHistory();
            } else {
                var p = this._groupSelector.find(function(t) {
                    return t.selected;
                });
                p && 1 == this.selectTextCount && "文字" === p.type && "area" === this.isInWhere(p, e) && this.doubleAction(p), 
                p && "close" === this.isInWhere(p, e) && this._deleteItem(p.id), this._groupSelector.forEach(function(t, i, s) {
                    t.selected = !1, t.multiSelected = !1, "area" != n.isInWhere(t, e) || n.getIn("_initial", "stick") || (s.forEach(function(t) {
                        t.selected = !1;
                    }), t.selected = !0);
                }), this.setIn("_event", {
                    hasMultiSelect: !1,
                    multiSelectedRect: {}
                });
            }
            this.setIn("_event", {
                slideMove: !1
            }), this.setIn("_event", {
                multiSelect: !1,
                hasStart: !1
            }), this.resetRender();
        }
    }, {
        key: "multiSelect",
        value: function(e) {
            var i = this.getIn("_initial", "multiSelectStart"), n = t(i, 2), s = n[0], h = n[1], r = [ e.touches[0].x, e.touches[0].y ], a = r[0], l = r[1];
            this.clear(), this.ctx.save(), this.ctx.fillStyle = "rgba(88, 190, 106,0.2)", this.ctx.fillRect(s, h, a - s, l - h);
            var o = {
                x: a - s < 0 ? a : s,
                y: l - h < 0 ? l : h,
                width: Math.abs(a - s),
                height: Math.abs(l - h)
            };
            if (this._groupSelector.forEach(function(t) {
                t.selected = !1, (0, c.rectRect)(t, o) && (t.multiSelected = !0, t.selected = !0, 
                t.multiNumber = t.extraAngle.length);
            }), this._multiSelector = this._groupSelector.filter(function(t) {
                return t.selected;
            }), this._multiSelector.length > 1) {
                this.setIn("_event", {
                    hasMultiSelect: !0
                });
                var u = (0, c.getAllAreaPoint)(this._multiSelector), d = t(u, 4), g = d[0], v = d[1], f = d[2], p = d[3];
                this.setIn("_event", {
                    multiSelectedRect: {
                        x: g,
                        y: v,
                        width: f - g,
                        height: p - v,
                        angle: 0
                    }
                });
            } else this._multiSelector.length <= 1 && (this._groupSelector.forEach(function(t) {
                t.multiSelected = !1;
            }), this.setIn("_event", {
                hasMultiSelect: !1
            }));
            this.setIn("_initial", {
                initialXY: null
            }), this.ctx.restore(), this.render();
        }
    }, {
        key: "initMultiPosition",
        value: function() {
            this._groupSelector.forEach(function(e) {
                e.extraAngle && e.extraAngle.forEach(function(i) {
                    var n = (0, c.getEndPointByRotate)([ e.x, e.y ], [ i.centerX, i.centerY ], i.angle), s = t(n, 2), h = s[0], r = s[1], a = (0, 
                    c.getEndPointByRotate)([ e.x + e.width, e.y ], [ i.centerX, i.centerY ], i.angle), l = t(a, 2), o = l[0], u = l[1], d = (0, 
                    c.getEndPointByRotate)([ e.x, e.y + e.height ], [ i.centerX, i.centerY ], i.angle), g = t(d, 2), v = g[0], f = g[1], p = (0, 
                    c.getEndPointByRotate)([ e.x + e.width / 2, e.y + e.height / 2 ], [ i.centerX, i.centerY ], i.angle), x = t(p, 2), y = x[0], m = x[1], _ = (0, 
                    c.getOriginLeftTopPoint)([ h, r ], [ o, u ], [ v, f ], [ y, m ]), I = t(_, 2), w = I[0], S = I[1], b = (0, 
                    c.getAngle)([ y, m ], [ w, S ], [ h, r ]);
                    e.x = w, e.y = S, e.angle = b + e.angle, isNaN(e.angle) && (e.angle = 0), e.extraAngle = [];
                });
            });
        }
    }, {
        key: "limitXY",
        value: function(t, e, i) {
            return e <= .9 * -t.width && (e = .9 * -t.width), e >= this.canvas.width / this.dpr - .1 * t.width && (e = this.canvas.width / this.dpr - .1 * t.width), 
            i <= .9 * -t.height && (i = .9 * -t.height), i >= this.canvas.height / this.dpr - .1 * t.height && (i = this.canvas.height / this.dpr - .1 * t.height), 
            [ e, i ];
        }
    }, {
        key: "isLimitXY",
        value: function(t, e, i) {
            var n = !1, s = !1;
            return e <= .9 * -t.width && (n = !0), e >= this.canvas.width / this.dpr - .1 * t.width && (n = !0), 
            i <= .9 * -t.height && (s = !0), i >= this.canvas.height / this.dpr - .1 * t.height && (s = !0), 
            [ n, s ];
        }
    }, {
        key: "nextAction",
        value: function() {
            this.historyGroup[this.pointer + 1] && (l.default.reportElementClick({
                key: "redo"
            }), this.pointer = this.pointer + 1, this._groupSelector = this.historyGroup[this.pointer].reduce(function(t, e) {
                var i = Object.assign({}, e);
                return t.push(i), t;
            }, []) || [], this.setIn("_event", {
                multiSelectedRect: {},
                hasMultiSelect: !1,
                multiSelect: !1
            }), this._multiSelector = [], this.onChangeGourp(!0), this.setHistory(), this.resetRender());
        }
    }, {
        key: "prevAction",
        value: function() {
            this.historyGroup[this.pointer - 1] && (l.default.reportElementClick({
                key: "back"
            }), this.pointer = this.pointer - 1, this._groupSelector = this.historyGroup[this.pointer].reduce(function(t, e) {
                e.extraAngle = [];
                var i = Object.assign({}, e);
                return t.push(i), t;
            }, []) || [], this.setIn("_event", {
                multiSelectedRect: {},
                hasMultiSelect: !1,
                multiSelect: !1
            }), this._multiSelector = [], this.setHistory(), this.resetRender(), this.onChangeGourp(!0));
        }
    }, {
        key: "pushHistory",
        value: function() {
            var t, e;
            this.pointer != ((null === (t = this.historyGroup) || void 0 === t ? void 0 : t.length) - 1 || 0) && this.historyGroup.splice(this.pointer + 1, this.historyGroup.length - this.pointer);
            var i = this._groupSelector.reduce(function(t, e) {
                var i = Object.assign({}, e);
                return t.push(i), t;
            }, []);
            Object.assign({}, this.getIn("_event", "multiSelectedRect"));
            return this.historyGroup.push(i), this.pointer = (null === (e = this.historyGroup) || void 0 === e ? void 0 : e.length) - 1 || 0, 
            this.setHistory(), i;
        }
    }, {
        key: "getBase64Image",
        value: function() {
            return this._groupSelector.forEach(function(t) {
                t.selected = !1;
            }), this.clearPure(), this.renderPure(), {
                base64: this.canvas.toDataURL(),
                canvasData: this._groupSelector
            };
        }
    }, {
        key: "resetRender",
        value: function(t) {
            this.onChangeGourp(t), this.clear(), this.render();
        }
    }, {
        key: "resetSelectRender",
        value: function(t) {
            var e = this;
            t ? this._groupSelector = t.map(function(t) {
                return e._groupSelector.find(function(i) {
                    return i.id === e._groupSelector.length - t - 1;
                });
            }).reverse() : this._groupSelector.forEach(function(t, e) {
                t.selected = !1, t.id = e;
            }), this.resetRender();
        }
    }, {
        key: "mirror",
        value: function() {
            l.default.reportElementClick({
                key: "overturn"
            }), this._groupSelector.forEach(function(t, e, i) {
                t.selected && Object.assign(t, {
                    mirror: !t.mirror
                });
            }), wx.vibrateShort({
                type: "light"
            }), this.resetRender(), this.pushHistory();
        }
    }, {
        key: "copy",
        value: function() {
            var s = this;
            l.default.reportElementClick({
                key: "copy"
            }), this._groupSelector.length > 30 ? wx.showToast({
                title: "最多允许添加30个元素",
                icon: "none"
            }) : this._groupSelector.forEach(function() {
                var h = n(i.default.mark(function n(h, r, a) {
                    var c, l, o, u, d;
                    return i.default.wrap(function(i) {
                        for (;;) switch (i.prev = i.next) {
                          case 0:
                            if (!h.selected) {
                                i.next = 8;
                                break;
                            }
                            return a.forEach(function(t) {
                                t.selected = !1;
                            }), c = s.setDefaultPosition(h.type, h.width, h.height), l = t(c, 2), o = l[0], 
                            u = l[1], "涂鸦" === h.type && (o = h.x, u = h.y), d = Object.assign(e({}, h), {
                                id: s._groupSelector.length + 1,
                                x: o + 16 * (Math.floor(8 * Math.random()) - 4),
                                y: u + 16 * (Math.floor(8 * Math.random()) - 4),
                                selected: !0
                            }), i.next = 7, s.createNewImage(d, h.x, h.y, h.width, h.height, "", !0, h.opacity);

                          case 7:
                            s.pushHistory();

                          case 8:
                          case "end":
                            return i.stop();
                        }
                    }, n);
                }));
                return function(t, e, i) {
                    return h.apply(this, arguments);
                };
            }());
        }
    }, {
        key: "onSelecte",
        value: (g = n(i.default.mark(function t(e) {
            return i.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    this._groupSelector.forEach(function(t, i, n) {
                        t.id === n.length - e - 1 ? t.selected = !0 : t.selected = !1;
                    }), this.resetRender();

                  case 2:
                  case "end":
                    return t.stop();
                }
            }, t, this);
        })), function(t) {
            return g.apply(this, arguments);
        })
    }, {
        key: "addText",
        value: (d = n(i.default.mark(function t(e, n) {
            var s, h, r, a;
            return i.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return l.default.reportElementClick({
                        key: "add_text",
                        extInfo: {
                            text: e,
                            color: n
                        }
                    }), t.next = 3, this.text(e, n);

                  case 3:
                    return s = t.sent, h = s.url, r = s.width, a = s.height, t.next = 9, this.createNewImage({
                        url: h,
                        type: "文字",
                        color: n
                    }, 0, 0, r, a, e);

                  case 9:
                    this.onChangeGourp(!0);

                  case 10:
                  case "end":
                    return t.stop();
                }
            }, t, this);
        })), function(t, e) {
            return d.apply(this, arguments);
        })
    }, {
        key: "editText",
        value: (u = n(i.default.mark(function e(n, s, h) {
            var r, a, o, u, d = this;
            return i.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return this._groupSelector.find(function(t) {
                        return t.id === n;
                    }).text !== s && l.default.reportElementClick({
                        key: "adjust_text"
                    }), this._groupSelector.find(function(t) {
                        return t.id === n;
                    }).color !== h && l.default.reportElementClick({
                        key: "color_adjust"
                    }), e.next = 4, this.text(s, h);

                  case 4:
                    return r = e.sent, a = r.url, o = r.width, u = r.height, this._groupSelector.forEach(function(t) {
                        t.hidden = !1;
                    }), e.next = 11, this.initImage({
                        url: a
                    }, function(e, i) {
                        var r = e._img;
                        d._groupSelector.forEach(function(e) {
                            if (e.id == n) {
                                var i = e.width / e.origin.width, l = (0, c.getEndPointByRotate)([ e.x - (o / 2 - e.width / 2), e.y - (u / 2 - e.height / 2) ], [ e.x + e.width / 2, e.y + e.height / 2 ], e.angle), d = t(l, 2), g = d[0], v = d[1];
                                e = Object.assign(e, {
                                    img: r,
                                    text: s,
                                    url: a,
                                    width: o * i,
                                    height: u * i,
                                    x: g,
                                    y: v,
                                    color: h,
                                    origin: {
                                        width: o,
                                        height: u
                                    }
                                });
                            }
                        }), d.resetRender(), wx.vibrateShort({
                            type: "medium"
                        }), i();
                    });

                  case 11:
                    this.onChangeGourp(!0);

                  case 12:
                  case "end":
                    return e.stop();
                }
            }, e, this);
        })), function(t, e, i) {
            return u.apply(this, arguments);
        })
    } ]), o;
}();

module.exports = u;