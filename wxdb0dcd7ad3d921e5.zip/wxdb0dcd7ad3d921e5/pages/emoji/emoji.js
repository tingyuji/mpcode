var t = require("../../@babel/runtime/helpers/toConsumableArray"), e = o(require("../../@babel/runtime/regenerator")), a = require("../../@babel/runtime/helpers/asyncToGenerator"), n = require("../../@babel/runtime/helpers/defineProperty"), i = o(require("@tencent/merlin-behavior")), s = o(require("../../utils/word")), r = require("../../utils/storage");

function o(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

var c = require("./wx-drag.js"), h = getApp(), l = require("../../constants/face.js"), u = require("../../constants/body.js"), d = require("../../constants/eye.js"), p = require("../../constants/mouth.js"), f = require("../../constants/eyebrow.js"), g = require("../../constants/acc.js");

Page({
    pageName: "emoji_produce",
    resetCount: 0,
    penMinX: 0,
    penMinY: 0,
    penMaxX: 0,
    penMaxY: 0,
    toush: function(t) {
        var e = t.currentTarget.dataset.id, a = t.currentTarget.dataset.index;
        this.setData({
            selectIndex: a
        }), this.canvas._groupSelector.forEach(function(t) {
            t.selected = !1, t.id == e && (t.selected = !0);
        }), this.canvas.resetRender(), this.setData({
            dragStyle: !1
        }), this.canvas.onSelecte(a);
    },
    noani: function() {
        this.setData({
            dragStyle: !0
        });
    },
    throttle2: function(t, e, a) {
        var n;
        return function() {
            var i = a || this, s = arguments;
            n || (n = setTimeout(function() {
                t.apply(i, s), n = null;
            }, e));
        };
    },
    _scroll: function() {},
    onScroll: function(t) {
        this.setData({
            scrollTop: t.detail
        });
    },
    sortChange: function(t) {
        var e = this;
        i.default.reportElementClick({
            key: "layer_adjust"
        }), this.group = t.detail.sort.map(function(t, a) {
            return e.data.faceMap[t].id;
        }), this.canvas.resetSelectRender(this.group);
    },
    posChange: function(t) {
        wx.vibrateShort({
            type: "light"
        });
    },
    onDelete: function(t) {
        var e = this;
        setTimeout(function() {
            var a = e.data.faceList[t.detail].id;
            e.canvas.deleteItem(a), wx.vibrateShort({
                type: "light"
            });
        }, 30);
    },
    data: n({
        canvasScreen: {
            width: h.globalData.canvasWidth,
            height: h.globalData.canvasHeight
        },
        navBarHeight: h.globalData.navBarHeight,
        isMirror: !1,
        selected: !1,
        notText: !0,
        moving: !1,
        clickQuit: !1,
        ctx: null,
        canvas: null,
        upperZIndex: 10,
        isFixed: !0,
        id: "",
        inputVal: "",
        dragStyle: !1,
        canvasTop: "100vh",
        banTouch: !1,
        editId: void 0,
        scrollTop: 0,
        faceMap: {},
        faceList: [],
        isPentools: !1,
        keyBoardHeight: 0,
        isPenComplete: !1,
        selectColor: "#000000",
        penBase64History: [ "" ],
        isDisable: !0,
        selectIndex: null,
        penPointer: 0,
        history: [],
        pointer: 0,
        scene: 0,
        lineWidth: 5,
        isKeyBoardDone: !1,
        showEditor: !1,
        opacityController: !1,
        currentOpacity: 100,
        cacheOpacity: 100,
        group: [],
        isBlock: getApp().globalData.isBlock,
        tabs: [ {
            icon: "../../assets/tabs/outlined_smile.svg",
            activeIcon: "../../assets/tabs/filled_smile.svg",
            disable: !1
        }, {
            icon: "../../assets/tabs/outlined_pencil.svg",
            activeIcon: "../../assets/tabs/filled_pencil.svg",
            disable: !1
        }, {
            icon: "../../assets/tabs/outlined_layer.svg",
            activeIcon: "../../assets/tabs/filled_layer.svg",
            disable: !1
        }, {
            icon: "../../assets/tabs/outlined_edit.svg",
            activeIcon: "../../assets/tabs/filled_edit.svg",
            disable: !1
        } ],
        isIphoneX: h.globalData.isIphoneX,
        size: 1,
        listData: [],
        extraNodes: [ {
            type: "after",
            dragId: "plus",
            slot: "plus",
            fixed: !0
        } ],
        pageMetaScrollTop: 0
    }, "scrollTop", 100),
    onTabClick: function(t) {
        t.detail.index;
    },
    setSelectedIndex: function(t) {
        var e;
        this.setData({
            selectIndex: null !== (e = this.group && this.group[t]) && void 0 !== e ? e : t
        });
    },
    resetGroup: function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
        !this.data.id && 0 === this.canvas._groupSelector.length || this.data.id && 0 == this.resetCount ? h.globalData.showBackToast = !1 : h.globalData.showBackToast = !0, 
        t && (this.setData({
            dragStyle: !0
        }), this.setFaceList(this.canvas._groupSelector));
        var e = this.canvas._groupSelector.find(function(t) {
            return t.selected;
        });
        this.setData({
            selected: !!e,
            notText: !(!e || "文字" === e.type)
        }), 0 === this.canvas._groupSelector.length ? this.setData({
            isDisable: !0
        }) : this.setData({
            isDisable: !1
        }), this.resetCount++;
    },
    addText: function() {
        var t = this, e = setInterval(function() {
            t.canvas.editTimeWait++, t.canvas.editTimeWait > 6 && clearInterval(e);
        }, 100);
        this.setData({
            showEditor: !0,
            editId: void 0,
            inputVal: "",
            selectColor: "#000000"
        });
    },
    onChange: function(t) {
        var e = t.detail.index;
        this.setData({
            activeTab: e
        });
    },
    onLoad: function(t) {
        var n = this;
        this._options = t;
        var i = wx.getLaunchOptionsSync().scene;
        if (this.setData({
            isBlock: getApp().globalData.isBlock,
            scene: i
        }), getApp().globalData.isBlock && (0, r.setEmojiStorage)([]), 1154 !== i) {
            1155 != wx.getLaunchOptionsSync().scene || getApp().globalData.pyqComing || (getApp().globalData.pyqComing = !0, 
            wx.redirectTo({
                url: "../index/index"
            })), wx.onKeyboardHeightChange(function() {
                var t = a(e.default.mark(function t(a) {
                    return e.default.wrap(function(t) {
                        for (;;) switch (t.prev = t.next) {
                          case 0:
                            if (!(a.height - n.data.keyBoardHeight >= 0)) {
                                t.next = 5;
                                break;
                            }
                            n.setData({
                                keyBoardHeight: a.height
                            }), a.height === n.data.keyBoardHeight && n.setData({
                                isKeyBoardDone: !0
                            }), t.next = 10;
                            break;

                          case 5:
                            if (0 !== a.height) {
                                t.next = 10;
                                break;
                            }
                            if (n.data.clickQuit) {
                                t.next = 9;
                                break;
                            }
                            return t.next = 9, n.drawText();

                          case 9:
                            n.setData({
                                showEditor: !1,
                                keyBoardHeight: 0,
                                isKeyBoardDone: !0
                            });

                          case 10:
                          case "end":
                            return t.stop();
                        }
                    }, t);
                }));
                return function(e) {
                    return t.apply(this, arguments);
                };
            }()), this.position = {
                x: 150,
                y: 150,
                vx: 2,
                vy: 2
            }, this.x = -100, t.id && this.setData({
                id: t.id
            }), wx.createSelectorQuery().select("#canvas-pen").fields({
                node: !0,
                size: !0
            }).exec(this.initPenCanvas.bind(this)), wx.createSelectorQuery().select("#canvas").fields({
                node: !0,
                size: !0
            }).exec(this.init.bind(this));
            var s = [ {
                title: "脸型",
                faces: l.face
            }, {
                title: "眼睛",
                faces: d.eye
            }, {
                title: "眉毛",
                faces: f.eyebrow
            }, {
                title: "嘴巴",
                faces: p.mouth
            }, {
                title: "身体",
                faces: u.body
            }, {
                title: "配饰",
                faces: g.acc
            } ], o = wx.getStorageSync("faceListCache") || [], c = [];
            s.forEach(function(t) {
                t.faces.forEach(function(t) {
                    o.find(function(e) {
                        return e.originUrl === t.url;
                    }) || c.push(t.url);
                });
            }), this.getImageInfo(c), h.globalData.showBackToast = !1;
        }
    },
    getImageInfo: function(e) {
        var a = this, n = e.splice(0, 10);
        if (!(n.length <= 0)) return Promise.all(n.map(function(t) {
            return new Promise(function(e) {
                wx.downloadFile({
                    url: t,
                    success: function(a) {
                        wx.getFileSystemManager();
                        e(Object.assign(a, {
                            originUrl: t
                        }));
                    }
                });
            });
        })).then(function(n) {
            if (n.length > 0) {
                var i = wx.getStorageSync("faceListCache") || [];
                return i.push.apply(i, t(n)), wx.setStorageSync("faceListCache", i), a.getImageInfo(e);
            }
        }).catch(function(t) {
            wx.showToast({
                title: "预加载失败"
            });
        });
    },
    initPenCanvas: function(t) {
        var e = t[0].node, a = e.getContext("2d"), n = wx.getSystemInfoSync().pixelRatio;
        this.dpr = n, e.height = t[0].height * n, e.width = t[0].width * n, a.scale(n, n), 
        this.penctx = a, this.pencanvas = e;
    },
    init: function(t) {
        var e = t[0].node;
        t.canvasData = h.globalData.canvasData || [], this.setFaceList(t.canvasData), this.canvas = new c(e, t, {
            onChangeGourp: this.resetGroup,
            doubleAction: this.doubleAction,
            setHistory: this.setHistory,
            setSelectedIndex: this.setSelectedIndex,
            reloadPage: this.reloadPage,
            isSmallScreen: h.globalData.isSmallScreen
        }), this.setHistory();
    },
    initUpper: function(t) {
        return t;
    },
    setHistory: function() {
        this.setData({
            history: this.canvas.historyGroup,
            pointer: this.canvas.pointer
        });
    },
    prev: function() {
        this.data.isPentools, this.canvas.prevAction();
    },
    next: function() {
        this.canvas.nextAction();
    },
    doubleAction: function(t) {
        this.canvas._groupSelector.forEach(function(e) {
            e.id === t.id && "文字" === t.type && (e.hidden = !0);
        }), "文字" === t.type && (this.canvas.resetSelectRender(), this.setData({
            inputVal: t.text,
            showEditor: !0,
            editId: t.id,
            selectColor: t.color
        }));
    },
    clear: function() {
        this.canvas.delete();
    },
    reloadPage: function() {
        this.onLoad(this._options);
    },
    touchstart: function(t) {
        var e;
        if (!this.data.banTouch) {
            if (this.setData({
                selectIndex: null
            }), this.data.showEditor) return !1;
            null === (e = this.canvas) || void 0 === e || e.curtouchstart(t);
        }
    },
    touchmove: function(t) {
        var e;
        if (this.data.showEditor || this.data.banTouch) return !1;
        this.canvas._groupSelector.find(function(t) {
            return t.selected;
        }) && this.setData({
            moving: !0
        }), null === (e = this.canvas) || void 0 === e || e.touchmove(t);
    },
    touchend: function(t) {
        var e;
        if (this.data.showEditor || this.data.banTouch) return !1;
        this.setData({
            moving: !1
        }), null === (e = this.canvas) || void 0 === e || e.touchend(t);
    },
    touchstarts: function(t) {
        var e;
        null === (e = this.canvas) || void 0 === e || e.touchstart(t);
    },
    createNewShape: function(t) {
        var n = this;
        return a(e.default.mark(function a() {
            var s, r, o, c;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (!(n.canvas && (null === (s = n.canvas) || void 0 === s || null === (r = s._groupSelector) || void 0 === r ? void 0 : r.length) > 30)) {
                        e.next = 3;
                        break;
                    }
                    return wx.showToast({
                        title: "最多允许添加30个元素",
                        icon: "none"
                    }), e.abrupt("return");

                  case 3:
                    return i.default.reportElementClick({
                        key: "add"
                    }), o = t.detail, e.next = 7, n.canvas.createNewImage(o, 150, 150, o.site.width, o.site.height);

                  case 7:
                    c = e.sent, n.setFaceList(c);

                  case 9:
                  case "end":
                    return e.stop();
                }
            }, a);
        }))();
    },
    getBase64: function() {
        this.canvas.getBase64Image();
    },
    setFixed: function(t) {
        this.setData({
            isFixed: t.detail
        });
    },
    jumpToSaveBoard: function() {
        i.default.reportElementClick({
            key: "next",
            extInfo: {
                layerInfo: this.canvas._groupSelector.reduce(function(t, e) {
                    return e.cid && (t = "".concat(t + e.cid, ",")), t;
                }, "")
            }
        });
        var t = this.canvas.getBase64Image(), e = t.base64, a = t.canvasData;
        h.globalData.base64 = e, h.globalData.canvasData = a, wx.redirectTo({
            url: "../saveBoard/saveboard?id=".concat(this.data.id)
        });
    },
    resetSelectRender: function(t) {
        var e = this;
        this.canvas.resetSelectRender(t.detail.map(function(t, a) {
            return e.data.faceList.find(function(e) {
                return e.id === t.id;
            });
        })), this.setFaceList(this.canvas._groupSelector);
    },
    mirror: function() {
        this.canvas.mirror(), this.setFaceList(this.canvas._groupSelector);
    },
    opacityOpen: function() {
        i.default.reportElementClick({
            key: "opacity"
        }), this.setData({
            opacityController: !0,
            banTouch: !0
        }), this.canvas._groupSelector.forEach(function(t) {
            t.selected && (null == t.opacity && (t.opacity = 1), t.originOpacity = t.opacity);
        }), this.canvas._groupSelector.filter(function(t) {
            return t.selected;
        }).length > 1 ? this.setData({
            currentOpacity: 100
        }) : this.setData({
            currentOpacity: 100 * this.canvas._groupSelector.filter(function(t) {
                return t.selected;
            })[0].opacity
        });
    },
    setFaceList: function(e) {
        var a = this;
        setTimeout(function() {
            a.setData({
                faceList: t(e).reverse(),
                faceMap: e.reduce(function(t, e, a) {
                    return t[a] = e, t;
                }, {})
            });
        }, 50);
    },
    copy: function() {
        this.canvas.copy(), this.setFaceList(this.canvas._groupSelector);
    },
    onKeyBoard: function(t) {
        var e = 0, a = t.detail.detail.value.split("").reduce(function(t, a) {
            return /[^\u4e00-\u9fa5]/.test(a) ? e += 1 : e += 2, e <= 24 && (t += a), t;
        }, "");
        this.setData({
            inputVal: a
        });
    },
    onKeyboardHeight: function(t) {
        var n = this;
        return a(e.default.mark(function t() {
            return e.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    n.data.keyBoardHeight;

                  case 1:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    },
    drawText: function() {
        var t = this;
        return a(e.default.mark(function a() {
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (!t.data.inputVal) {
                        e.next = 10;
                        break;
                    }
                    if (void 0 === t.data.editId || !t.data.showEditor) {
                        e.next = 6;
                        break;
                    }
                    return e.next = 4, t.canvas.editText(t.data.editId, t.data.inputVal, t.data.selectColor);

                  case 4:
                    e.next = 10;
                    break;

                  case 6:
                    if (!t.data.showEditor) {
                        e.next = 10;
                        break;
                    }
                    return e.next = 9, t.canvas.addText(t.data.inputVal, t.data.selectColor);

                  case 9:
                    t.setData({
                        inputVal: ""
                    });

                  case 10:
                  case "end":
                    return e.stop();
                }
            }, a);
        }))();
    },
    quitEditor: function(t) {
        var n = this;
        return a(e.default.mark(function t() {
            return e.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (!(n.canvas.editTimeWait < 5)) {
                        t.next = 2;
                        break;
                    }
                    return t.abrupt("return");

                  case 2:
                    return n.setData({
                        clickQuit: !0
                    }), wx.hideKeyboard(), t.next = 6, n.drawText();

                  case 6:
                    n.setData({
                        showEditor: !1,
                        keyBoardHeight: 0,
                        clickQuit: !1
                    });

                  case 7:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    },
    selectColor: function(t) {
        this.setData({
            selectColor: t.currentTarget.dataset.color
        });
    },
    emptyFunc: function() {},
    points: [],
    touchstartpen: function(t) {
        this.penMinX || (this.penMinX = t.touches[0].x - this.data.lineWidth), this.penMinY || (this.penMinY = t.touches[0].y - this.data.lineWidth), 
        this.penMaxX || (this.penMaxX = t.touches[0].x + this.data.lineWidth), this.penMaxY || (this.penMaxY = t.touches[0].y + this.data.lineWidth), 
        t.touches[0].x < this.penMinX && (this.penMinX = t.touches[0].x), t.touches[0].y < this.penMinY && (this.penMinY = t.touches[0].y), 
        t.touches[0].x > this.penMaxX && (this.penMaxX = t.touches[0].x), t.touches[0].y > this.penMaxY && (this.penMaxY = t.touches[0].y), 
        this.isDrawing = !0, this.points.push({
            x: t.touches[0].x,
            y: t.touches[0].y
        });
    },
    touchmovepen: function(t) {
        this.penMinX || (this.penMinX = t.touches[0].x - this.data.lineWidth), this.penMinY || (this.penMinY = t.touches[0].y - this.data.lineWidth), 
        this.penMaxX || (this.penMaxX = t.touches[0].x + this.data.lineWidth), this.penMaxY || (this.penMaxY = t.touches[0].y + this.data.lineWidth), 
        t.touches[0].x < this.penMinX && (this.penMinX = t.touches[0].x), t.touches[0].y < this.penMinY && (this.penMinY = t.touches[0].y), 
        t.touches[0].x > this.penMaxX && (this.penMaxX = t.touches[0].x), t.touches[0].y > this.penMaxY && (this.penMaxY = t.touches[0].y), 
        this.isDrawing && this.draw(t.touches[0].x, t.touches[0].y);
    },
    touchendpen: function(t) {
        this.isDrawing && this.draw(t.changedTouches[0].x, t.changedTouches[0].y), this.points = [], 
        this.isDrawing = !1, this.setPenBase64History();
    },
    draw: function(t, e) {
        var a = this.points, n = this.penctx;
        a.push({
            x: t,
            y: e
        }), n.beginPath(), n.lineWidth = this.data.lineWidth, n.lineCap = "round", n.strokeStyle = this.data.selectColor;
        var i = (a[a.length - 2].x + a[a.length - 1].x) / 2, s = (a[a.length - 2].y + a[a.length - 1].y) / 2;
        if (2 == a.length) n.moveTo(a[a.length - 2].x, a[a.length - 2].y), n.lineTo(i, s); else {
            var r = (a[a.length - 3].x + a[a.length - 2].x) / 2, o = (a[a.length - 3].y + a[a.length - 2].y) / 2;
            n.moveTo(r, o), n.quadraticCurveTo(a[a.length - 2].x, a[a.length - 2].y, i, s);
        }
        n.stroke(), a.slice(0, 1);
    },
    onPen: function() {
        i.default.reportElementClick({
            key: "handwriting"
        }), this.canvas.resetSelectRender(), this.penMinX = void 0, this.penMinY = void 0, 
        this.penMaxX = void 0, this.penMaxY = void 0, this.setData({
            isPentools: !0,
            canvasTop: "".concat(h.globalData.navBarHeight, "px"),
            isPenComplete: !1
        });
    },
    penCancel: function() {
        this.penctx.clearRect(0, 0, this.pencanvas.width, this.pencanvas.height), this.setData({
            isPentools: !1,
            canvasTop: "100vh",
            penBase64History: [ "" ],
            penPointer: 0
        });
    },
    opacityComplete: function() {
        var t = this;
        return a(e.default.mark(function a() {
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    t.setData({
                        opacityController: !1,
                        banTouch: !1
                    });

                  case 1:
                  case "end":
                    return e.stop();
                }
            }, a);
        }))();
    },
    opacityCancel: function() {
        var t = this;
        return a(e.default.mark(function a() {
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    t.canvas._groupSelector.forEach(function(t) {
                        t.selected && (t.opacity = t.originOpacity);
                    }), t.canvas.resetRender(), t.setData({
                        opacityController: !1,
                        banTouch: !1
                    });

                  case 3:
                  case "end":
                    return e.stop();
                }
            }, a);
        }))();
    },
    penComplete: function() {
        var t = this;
        return a(e.default.mark(function a() {
            var n, i, s, r, o, c, h;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (0 !== t.data.penPointer) {
                        e.next = 3;
                        break;
                    }
                    return t.penCancel(), e.abrupt("return");

                  case 3:
                    if (t.data.isPenComplete) {
                        e.next = 28;
                        break;
                    }
                    if (t.setData({
                        isPenComplete: !0,
                        penBase64History: [ "" ],
                        penPointer: 0
                    }), t.penMinX = t.penMinX - 25, t.penMinY = t.penMinY - 25, t.penMaxX = t.penMaxX + 25, 
                    t.penMaxY = t.penMaxY + 25, n = t.penMaxX - t.penMinX, i = t.penMaxY - t.penMinY, 
                    s = t.penMinX, r = t.penMinY, !isNaN(n)) {
                        e.next = 17;
                        break;
                    }
                    return t.penctx.clearRect(0, 0, t.pencanvas.width, t.pencanvas.height), t.setData({
                        isPentools: !1,
                        canvasTop: "100vh"
                    }), e.abrupt("return");

                  case 17:
                    return o = t.penctx.getImageData(s * t.dpr, r * t.dpr, (n + 30) * t.dpr, (i + 30) * t.dpr), 
                    (c = wx.createOffscreenCanvas({
                        type: "2d",
                        width: n * t.dpr,
                        height: i * t.dpr
                    })).height = i * t.dpr, c.width = n * t.dpr, c.getContext("2d").putImageData(o, 0, 0), 
                    h = c.toDataURL("image/png"), e.next = 26, t.canvas.createNewImage({
                        url: h,
                        type: "涂鸦"
                    }, s, r, n, i);

                  case 26:
                    t.penctx.clearRect(0, 0, t.pencanvas.width, t.pencanvas.height), t.setData({
                        isPentools: !1,
                        canvasTop: "100vh"
                    });

                  case 28:
                  case "end":
                    return e.stop();
                }
            }, a);
        }))();
    },
    setPenBase64History: function() {
        var t = this.pencanvas.toDataURL("image/png"), e = this.data.penBase64History;
        this.data.penPointer != e.length && e.splice(this.data.penPointer + 1, e.length), 
        this.setData({
            penBase64History: e.concat(t)
        }), this.setData({
            penPointer: this.data.penBase64History.length - 1
        });
    },
    getPenBase64History: function(t) {
        return this.data.penBase64History[t];
    },
    penPrev: function() {
        var t = this, e = this.data.penPointer - 1;
        this.penctx.clearRect(0, 0, this.pencanvas.width, this.pencanvas.height);
        var a = this.pencanvas.createImage();
        a.src = this.getPenBase64History(e), a.onload = function() {
            t.penctx.drawImage(a, 0, 0, t.pencanvas.width / t.dpr, t.pencanvas.height / t.dpr), 
            t.setData({
                penPointer: e
            });
        }, a.onerror = function() {
            t.setData({
                penPointer: e
            });
        };
    },
    penNext: function() {
        var t = this, e = this.data.penPointer + 1;
        this.penctx.clearRect(0, 0, this.pencanvas.width, this.pencanvas.height);
        var a = this.pencanvas.createImage();
        a.src = this.getPenBase64History(e), a.onload = function() {
            t.penctx.drawImage(a, 0, 0, t.pencanvas.width / t.dpr, t.pencanvas.height / t.dpr), 
            t.setData({
                penPointer: e
            });
        };
    },
    sortEnd: function(t) {
        this.setData({
            listData: t.detail.listData
        });
    },
    change: function(t) {},
    sizeChange: function(t) {
        wx.pageScrollTo({
            scrollTop: 0
        }), this.setData({
            size: t.detail.value
        }), this.drag.columnChange();
    },
    itemClick: function(t) {},
    toggleFixed: function(t) {
        var e = t.currentTarget.dataset.key, a = this.data.listData;
        a[e].fixed = !a[e].fixed, this.setData({
            listData: a
        });
    },
    add: function(t) {
        var e = this, a = this.data.listData;
        setTimeout(function() {
            e.setData({
                listData: a
            }), e.drag.init();
        }, 300);
    },
    scroll: function(t) {
        this.setData({
            pageMetaScrollTop: t.detail.scrollTop
        });
    },
    onSelecte: function(t) {
        var e = t.currentTarget.dataset.index;
        this.setData({
            selectIndex: e
        }), this.canvas.onSelecte(e);
    },
    onShareAppMessage: function() {
        var t = (0, s.default)();
        return {
            title: t.word,
            path: "/pages/index/index",
            imageUrl: t.image
        };
    },
    onShareTimeline: function() {
        return {
            title: "微信创意表情 | 制作你的表情",
            path: "/pages/index/index",
            query: ""
        };
    },
    selectPenLine: function(t) {
        i.default.reportElementClick({
            key: "layer_adjust"
        }), this.setData({
            lineWidth: parseInt(t.currentTarget.dataset.line)
        });
    },
    sliderChange: function(t) {
        var e = this;
        this.setData({
            currentOpacity: t.detail.value
        }), this.canvas._groupSelector.forEach(function(t) {
            t.selected && (null == t.opacity && (t.opacity = 1), t.opacity = e.data.currentOpacity / 100 * (e.canvas._groupSelector.filter(function(t) {
                return t.selected;
            }).length > 1 ? t.originOpacity : 1));
        }), this.canvas.resetRender();
    }
});