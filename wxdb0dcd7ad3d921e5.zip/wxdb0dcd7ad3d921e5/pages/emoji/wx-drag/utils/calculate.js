Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.deepEqual = function t(e, n) {
    if (e === n) return !0;
    if ("object" == r(e) && null != e && "object" == r(n) && null != n) {
        if (Object.keys(e).length !== Object.keys(n).length) return !1;
        for (var o in e) {
            if (!n.hasOwnProperty(o)) return !1;
            if (!t(e[o], n[o])) return !1;
        }
        return !0;
    }
    return !1;
}, exports.equar = function(t, r) {
    if (t.length !== r.length) return !1;
    for (var e = 0; e < t.length; e++) if (t[e] !== r[e]) return !1;
    return !0;
}, exports.get = function(t, r) {
    var e = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : void 0;
    try {
        "number" == typeof r && (r = String[r]);
        var n = ("string" == typeof r ? r.split(".") : r).reduce(function(t, r) {
            return t[r];
        }, t);
        return void 0 === n ? e : n;
    } catch (t) {
        return e;
    }
}, exports.getAllAreaPoint = function(r) {
    var n, o, i, a;
    return r.forEach(function(r) {
        var u = [ [ r.x - 10, r.y - 10 ], [ r.x + r.width + 10, r.y - 10 ], [ r.x - 10, r.y + r.height + 10 ], [ r.x + r.width + 10, r.y + r.height + 10 ] ].map(function(t) {
            return e(t, [ r.x + r.width / 2, r.y + r.height / 2 ], r.angle);
        }), h = t(u, 4), c = h[0], f = h[1], s = h[2], x = h[3];
        n || (n = c[0]), o || (o = c[1]), i || (i = x[0]), a || (a = x[1]), [ c, f, s, x ].forEach(function(t) {
            t[0] < n && (n = t[0]), t[1] < o && (o = t[1]), t[0] > i && (i = t[0]), t[1] > a && (a = t[1]);
        });
    }), [ n, o, i, a ];
}, exports.getAngle = function(t, r, e) {
    return Math.atan2(e[1] - t[1], e[0] - t[0]) - Math.atan2(r[1] - t[1], r[0] - t[0]);
}, exports.getEndPointByRotate = e, exports.getOriginLeftTopPoint = function(t, r, e, n) {
    var o = Math.sqrt(Math.pow(r[0] - t[0], 2) + Math.pow(r[1] - t[1], 2)), i = Math.sqrt(Math.pow(e[0] - t[0], 2) + Math.pow(e[1] - t[1], 2));
    return [ n[0] - o / 2, n[1] - i / 2 ];
}, exports.getRotateAngle = function(t, r, e, n) {
    function o(t) {
        return Math.sqrt(t.x * t.x + t.y * t.y);
    }
    var i = {
        x: e.x - n.x,
        y: e.y - n.y
    }, a = {
        x: t.x - r.x,
        y: t.y - r.y
    }, u = i.x * a.y - i.y * a.x, h = function(t, r) {
        var e = o(t) * o(r);
        if (0 === e) return 0;
        var n = function(t, r) {
            return t.x * r.x + t.y * r.y;
        }(t, r) / e;
        return n > 1 && (n = 1), Math.acos(n);
    }(i, a);
    u > 0 && (h *= -1);
    return h;
}, exports.getRotateAngleByIcon = function(r, e, n) {
    var o = t(r, 2), i = o[0], a = o[1], u = t(e, 2), h = u[0], c = u[1], f = t(n, 2), s = f[0], x = f[1], y = [ h - i, c - a ], p = [ s - i, x - a ], g = y[0] * p[1] - y[1] * p[0], l = Math.sqrt(Math.pow(y[0], 2) + Math.pow(y[1], 2)) * Math.sqrt(Math.pow(p[0], 2) + Math.pow(p[1], 2)), M = g / l;
    return Math.asin(M);
}, exports.rectRect = function(t, r) {
    return t.x < r.x + r.width && t.x + t.width > r.x && t.y < r.y + r.height && t.y + t.height > r.y;
};

var t = require("../../../../@babel/runtime/helpers/slicedToArray"), r = require("../../../../@babel/runtime/helpers/typeof");

function e(r, e, n) {
    var o = t(e, 2), i = o[0], a = o[1], u = r[0] - i, h = r[1] - a;
    return [ u * Math.cos(n) - h * Math.sin(n) + i, u * Math.sin(n) + h * Math.cos(n) + a ];
}