var e;

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var t = (0, ((e = require("mitt")) && e.__esModule ? e : {
    default: e
}).default)();

exports.default = t;