Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var t, e = (t = require("../../../../@babel/runtime/regenerator")) && t.__esModule ? t : {
    default: t
}, i = require("../../../../@babel/runtime/helpers/asyncToGenerator");

function a(t, e, i) {
    this.canvas = t, this.ctx = t.getContext("2d");
    var a = wx.getSystemInfoSync().pixelRatio;
    this.dpr = a, this.canvas.width = e[0].width * a, this.canvas.height = e[0].width * a, 
    this.ctx.scale(a, a);
    var n = wx.createOffscreenCanvas({
        type: "2d",
        heigth: this.canvas.height,
        width: this.canvas.width
    });
    this.cacheCanvas = n, Object.assign(this.cacheCanvas, {
        width: this.canvas.width,
        height: this.canvas.height
    }), this.cachectx = n.getContext("2d"), this.cachectx.scale(a, a), this.init(i);
}

a.prototype = {
    init: function(t) {
        var a = this;
        Promise.all(t.map(function() {
            var t = i(e.default.mark(function t(i) {
                var n;
                return e.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return t.next = 2, a.initImage({
                            url: i.url
                        }, function(t, e) {
                            e(t._img);
                        });

                      case 2:
                        n = t.sent, i.img = n;

                      case 4:
                      case "end":
                        return t.stop();
                    }
                }, t);
            }));
            return function(e) {
                return t.apply(this, arguments);
            };
        }()));
    },
    initImage: function(t, e) {
        var i = this, a = t.url;
        return new Promise(function(t, n) {
            var r = i.canvas.createImage(), s = wx.getStorageSync("faceListCache");
            if (s && s.length > 0) {
                var h = s.find(function(t) {
                    return t.originUrl === a;
                });
                h && (a = h.tempFilePath);
            }
            r.src = a, r.onload = function() {
                e({
                    _img: r,
                    _height: r.height,
                    _width: r.width
                }, t);
            };
        });
    },
    onChangeShapeArray: function(t) {
        this.setShapeArray(t);
    },
    _setShapeArray: function(t) {
        this.shapeArray = t;
    },
    _getShapeArray: function() {
        return this.shapeArray;
    },
    add: function(t) {},
    draw: function() {
        var t = this, e = this._getShapeArray();
        if (e && e.length > 0) {
            if (this.ctx.save(), e.forEach(function(e) {
                t.drawImage(e);
            }), this.ctx.restore(), this.getIn("_event", "hasMultiSelect")) return void this.drawRect(this.ctx, this.getIn("_event", "multiSelectedRect"));
            this._groupSelector.forEach(function(e) {
                e.selected && t.drawRect(t.ctx, e);
            });
        }
    }
};

var n = a;

exports.default = n;