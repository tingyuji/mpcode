Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = function(e) {
    return function(t) {
        return new Promise(function(o, r) {
            var n = t.createImage();
            n.src = e, n.onload = function() {
                o({
                    ctx: n,
                    type: "image"
                });
            }, n.onerror = function() {
                wx.showToast({
                    title: "图片加载失败"
                }), r();
            };
        });
    };
};

exports.default = e;