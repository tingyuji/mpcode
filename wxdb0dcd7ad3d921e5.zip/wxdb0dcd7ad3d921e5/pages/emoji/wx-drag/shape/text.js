function t(t) {
    return !/[^\u4e00-\u9fa5]/.test(t);
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = function(e, a, n, i, r) {
    var f = wx.createOffscreenCanvas({
        type: "2d",
        height: n,
        width: a
    });
    f.width = a, f.height = n, i = a / 14;
    var o = f.getContext("2d"), s = wx.getSystemInfoSync().pixelRatio;
    o.fillStyle = r, o.font = "".concat(i, "px bold"), o.strokeStyle = "#ffffff" === r ? "#000" : "#fff", 
    o.lineWidth = 8;
    var c = 4, u = 100, g = "", h = 0, l = e.split("").reduce(function(e, a) {
        return t(a) ? e + 2 : e + 1;
    }, 0);
    1 === e.length && /[^\u4e00-\u9fa5a-zA-Z0-9]/.test(e) ? (i = a / 5, o.font = "".concat(i, "px sans-serif"), 
    c = 20, u = 200, o.strokeText(e, c, u), o.fillText(e, c, u)) : l > 24 ? e.split("").reduce(function(e, a, n, i) {
        return g += a, h += t(a) ? 2 : 1, n === i.length - 1 || h >= 24 ? (e.push(g), g = "", 
        h = 0, e) : e;
    }, []).forEach(function(t, a) {
        o.strokeText(e, c, u), o.fillText(t, c, u), u += i + 10;
    }) : (o.strokeText(e, c, u), o.fillText(e, c, u));
    for (var x = o.getImageData(0, 0, a, n), d = 0, p = 0, w = 0, v = 0, m = !1, T = 0; T < n; T++) {
        for (var y = !0, A = 0; A < a; A++) {
            x.data[4 * (T * a + A) + 3] > 0 && (d = 0 === d ? A : Math.min(d, A), w = Math.max(w, A), 
            y = !1);
        }
        y ? m || p++ : (m = !0, v = T);
    }
    var S = w - d + 7, D = v - p + 2, I = o.getImageData(d, p, S, D), _ = wx.createOffscreenCanvas({
        type: "2d",
        width: S,
        height: D
    });
    _.height = D, _.width = S, _.getContext("2d").putImageData(I, 0, 0);
    var P = _.toDataURL("image/png"), b = wx.getFileSystemManager();
    return new Promise(function(t, e) {
        b.writeFile({
            filePath: "".concat(wx.env.USER_DATA_PATH, "/text.png"),
            data: P.replace("data:image/png;base64,", ""),
            encoding: "base64",
            success: function(e) {
                wx.getImageInfo({
                    src: "".concat(wx.env.USER_DATA_PATH, "/text.png"),
                    success: function(e) {
                        t({
                            url: P,
                            width: e.width / s,
                            height: e.height / s
                        });
                    }
                });
            }
        });
    });
};

exports.default = e;