var e, n = (e = require("../../utils/word")) && e.__esModule ? e : {
    default: e
};

Page({
    pageName: "emoji_add_to_list",
    data: {
        scene: 0
    },
    onLoad: function(e) {
        this.setData({
            scene: wx.getLaunchOptionsSync().scene
        }), 1155 != wx.getLaunchOptionsSync().scene || getApp().globalData.pyqComing || (getApp().globalData.pyqComing = !0, 
        wx.redirectTo({
            url: "../index/index"
        }));
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        var e = (0, n.default)();
        return {
            title: e.word,
            path: "/pages/index/index",
            imageUrl: e.image
        };
    },
    onShareTimeline: function() {
        return {
            title: "微信创意表情 | 制作你的表情",
            path: "/pages/index/index",
            query: ""
        };
    },
    complete: function() {
        wx.redirectTo({
            url: "../index/index"
        });
    }
});