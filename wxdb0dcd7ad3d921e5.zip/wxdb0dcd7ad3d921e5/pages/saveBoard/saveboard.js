require("../../@babel/runtime/helpers/Arrayincludes");

var e = l(require("../../@babel/runtime/regenerator")), t = require("../../@babel/runtime/helpers/asyncToGenerator"), a = require("../../@babel/runtime/helpers/slicedToArray"), n = require("../emoji/wx-drag/utils/calculate"), i = l(require("../../utils/word")), o = (l(require("../../utils/randomString")), 
l(require("@tencent/merlin-behavior"))), r = require("../../utils/storage");

function l(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

var s = require("../../services/setNewMixEmoji"), c = require("../../services/updateMixEmoji"), d = require("../../services/addEmojiBackup"), u = require("../../utils/toBase64"), h = getApp();

Page({
    pageName: "emoji_finish",
    data: {
        ctx: null,
        canvas: null,
        md5: "",
        url: "",
        img: "",
        emojiKey: "",
        loading: !1,
        isShowComfire: !1,
        filePath: "",
        isDisable: !0,
        scene: 0
    },
    bindMd5: function(e) {
        this.setData({
            md5: e.detail.value
        });
    },
    bindUrl: function(e) {
        this.setData({
            url: e.detail.value
        });
    },
    randomString: function(e) {
        e = e || 16;
        for (var t = "ABCDEFGHJKMNPQRSTWXYZabcdefhijkmnprstwxyz2345678", a = t.length, n = "", i = 0; i < e; i++) n += t.charAt(Math.floor(Math.random() * a));
        return n;
    },
    onLoad: function(i) {
        var r = wx.getLaunchOptionsSync().scene;
        if (this.setData({
            scene: r
        }), 1154 !== r) {
            1155 != wx.getLaunchOptionsSync().scene || getApp().globalData.pyqComing || (getApp().globalData.pyqComing = !0, 
            wx.redirectTo({
                url: "../index/index"
            })), this.setData({
                loading: !0
            });
            var l = h.globalData.base64, d = this, g = wx.getFileSystemManager(), f = d.randomString();
            i.id && (f = i.id), o.default.reportElementExpose({
                key: "layer_info",
                extInfo: {
                    layerInfo: h.globalData.canvasData.reduce(function(e, t) {
                        return t.cid && (e = "".concat(e + t.cid, ",")), e;
                    }, ""),
                    emoji_key: f
                }
            });
            var m = "".concat(wx.env.USER_DATA_PATH, "/").concat(f, ".png"), w = l.replace(/^data:image\/\w+;base64,/, "");
            g.writeFile({
                filePath: m,
                data: w,
                encoding: "base64",
                success: function(r) {
                    var l = wx.getSystemInfoSync().pixelRatio;
                    wx.getImageInfo({
                        src: m,
                        success: function(r) {
                            var f = wx.createOffscreenCanvas({
                                type: "2d",
                                width: r.width / l,
                                height: r.heigh / l
                            }), w = f.createImage();
                            w.src = r.path;
                            w.onload = function() {
                                f.height = r.height / l, f.width = r.width / l;
                                var p = f.getContext("2d");
                                p.drawImage(w, 0, 0, r.width / l * .85, r.height / l * .85);
                                var x = (0, n.getAllAreaPoint)(h.globalData.canvasData), v = a(x, 4), y = v[0], D = v[1], b = v[2], S = v[3];
                                y = .85 * (y = y < 0 ? 0 : y) - 3, D = .85 * (D = D < 0 ? 0 : D) - 3, b = .85 * (b = b > r.width / l ? r.width / l : b) + 3, 
                                S = .85 * (S = S > r.height / l ? r.height / l : S) + 3;
                                var I, T, j = p.getImageData(y, D, b - y, S - D), q = wx.createOffscreenCanvas({
                                    type: "2d",
                                    width: b - y,
                                    height: S - D
                                });
                                q.width = b - y, q.height = S - D, q.getContext("2d").putImageData(j, 0, 0), I = q.toDataURL ? q.toDataURL("image/png") : wx.canvasToTempFilePath({
                                    canvas: q,
                                    success: (T = t(e.default.mark(function t(a) {
                                        return e.default.wrap(function(e) {
                                            for (;;) switch (e.prev = e.next) {
                                              case 0:
                                                return e.next = 2, u(a.tempFilePath);

                                              case 2:
                                                I = e.sent;

                                              case 3:
                                              case "end":
                                                return e.stop();
                                            }
                                        }, t);
                                    })), function(e) {
                                        return T.apply(this, arguments);
                                    })
                                }), g.writeFile({
                                    filePath: m,
                                    data: q.toDataURL("image/png").replace(/^data:image\/\w+;base64,/, ""),
                                    encoding: "base64",
                                    success: function() {
                                        d.setData({
                                            img: q.toDataURL(),
                                            url: m,
                                            filePath: m
                                        });
                                        var e = new Date().getTime();
                                        i.id ? c({
                                            emojiKey: i.id,
                                            base64: I,
                                            layerInfo: h.globalData.canvasData
                                        }).then(function(t) {
                                            o.default.reportElementClick({
                                                key: "loading",
                                                extInfo: {
                                                    loading: new Date().getTime() - e
                                                }
                                            }), d.setData({
                                                emojiKey: i.id
                                            }), d.setCacheLayerInfo(i.id, I);
                                        }) : s({
                                            base64: I,
                                            layerInfo: h.globalData.canvasData
                                        }).then(function(t) {
                                            var a, n;
                                            if (o.default.reportElementClick({
                                                key: "loading",
                                                extInfo: {
                                                    loading: new Date().getTime() - e
                                                }
                                            }), null != t && null !== (a = t.data) && void 0 !== a && null !== (n = a.data) && void 0 !== n && n.emojiKey) {
                                                var i = t.data.data.emojiKey;
                                                d.setData({
                                                    emojiKey: i
                                                }), d.setCacheLayerInfo(i, I);
                                            } else wx.showToast({
                                                title: "保存失败",
                                                icon: "none",
                                                duration: 2e3
                                            });
                                        });
                                    }
                                });
                            };
                        }
                    });
                }
            });
        }
    },
    setCacheLayerInfo: function(e, t) {
        var a = (0, r.getEmojiStorage)(), n = a.findIndex(function(t) {
            return t.emojiKey === e;
        });
        n > -1 && a.splice(n, 1), a.unshift({
            emojiKey: e,
            imgBase64: t,
            layerInfo: h.globalData.canvasData
        }), a.length > 15 && a.splice(15, a.length - 15), (0, r.setEmojiStorage)(a), this.setData({
            loading: !1,
            isDisable: !1
        });
    },
    init: function(e) {
        var t = e[0].width, a = e[0].height, n = e[0].node, i = n.getContext("2d"), o = wx.getSystemInfoSync().pixelRatio;
        n.width = t * o, n.height = a * o, i.scale(o, o), this.ctx = i, this.canvas = n;
        var r = this.canvas.createImage();
        r.src = "https://res.wx.qq.com/t/fed_upload/397fca8c-6702-42a5-9b9b-0343b17365e8/TAB_shopping_Color.png", 
        r.onload = function() {
            i.drawImage(r, 0, 0, 100, 100);
        };
    },
    onBase64: function() {
        var e = wx.getFileSystemManager(), t = this;
        e.readFile({
            filePath: t.data.url,
            success: function(e) {
                var a = new sMD5.ArrayBuffer();
                a.append(e.data), wx.addToEmoticon({
                    filePath: t.data.url,
                    md5: a.end(!1),
                    success: function(e) {
                        wx.redirectTo({
                            url: "../end/end"
                        });
                    }
                });
            }
        });
    },
    onSavePhotosAlbum: function() {
        this.setData({
            isShowComfire: !0
        });
    },
    download: function() {
        wx.showLoading({
            title: "正在添加",
            mask: !0
        });
        var e = new Date().getTime(), t = h.globalData.canvasData.map(function(e) {
            if ("文字" === e.type) return e.text;
        }).filter(function(e) {
            return e;
        }) || [];
        d({
            emojiKey: this.data.emojiKey,
            filePath: this.data.filePath,
            layerInfo: h.globalData.canvasData,
            text: JSON.stringify(t)
        }).then(function(t) {
            var a, n, i, r;
            o.default.reportElementClick({
                key: "add_to_catalog",
                extInfo: {
                    loading: new Date().getTime() - e
                }
            }), wx.hideLoading(), t.data && "string" == typeof t.data && (t.data = JSON.parse(t.data)), 
            -205 !== (null == t || null === (a = t.data) || void 0 === a || null === (n = a.data) || void 0 === n ? void 0 : n.ret) ? [ -1, -100005 ].includes(null == t || null === (i = t.data) || void 0 === i || null === (r = i.data) || void 0 === r ? void 0 : r.ret) ? wx.showToast({
                title: "添加失败",
                icon: "none",
                duration: 2e3
            }) : wx.redirectTo({
                url: "../index/index?&isdone=true"
            }) : wx.showToast({
                title: "添加失败，超过表情包上限",
                icon: "none",
                duration: 2e3
            });
        });
    },
    comfire: function() {
        this.download();
    },
    block: function() {},
    downloadImage: function(e) {
        var t = this;
        wx.getSetting({
            success: function(a) {
                a.authSetting["scope.writePhotosAlbum"] ? t.download(e) : wx.authorize({
                    scope: "scope.writePhotosAlbum",
                    success: function() {
                        t.download(e);
                    },
                    fail: function(e) {
                        wx.showToast({
                            title: "您拒绝了授权，请到设置中打开授权"
                        });
                    }
                });
            }
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        var e = (0, i.default)();
        return {
            title: e.word,
            path: "/pages/index/index",
            imageUrl: e.image
        };
    },
    onShareTimeline: function() {
        return {
            title: "微信创意表情 | 制作你的表情",
            path: "/pages/index/index",
            query: ""
        };
    },
    rebackEdit: function() {
        o.default.reportElementClick({
            key: "re_produce"
        }), wx.redirectTo({
            url: "../index/index"
        });
    }
});