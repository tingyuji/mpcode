var t, e, i = require("../../@babel/runtime/helpers/defineProperty"), h = (t = require("../../@babel/runtime/regenerator")) && t.__esModule ? t : {
    default: t
}, a = require("../../@babel/runtime/helpers/asyncToGenerator");

Page((i(e = {
    data: {
        faceList: [ 1, 2, 3, 4 ],
        canvasSize: {
            1: {
                width: 428,
                height: 755,
                border: {
                    width: 380,
                    height: 380
                },
                img: {
                    width: 380,
                    height: 380
                },
                title: {
                    left: 140,
                    top: 470
                },
                name: {
                    left: 75,
                    top: 720
                },
                qrtitle: {
                    left: 353,
                    top: 720
                }
            },
            2: {
                width: 428,
                height: 560,
                border: {
                    width: 186,
                    height: 186
                },
                img: {
                    width: 133,
                    height: 133
                },
                title: {
                    left: 140,
                    top: 270
                },
                name: {
                    left: 75,
                    top: 525
                },
                qrtitle: {
                    left: 353,
                    top: 525
                }
            },
            3: {
                width: 428,
                height: 492,
                border: {
                    width: 120,
                    height: 120
                },
                img: {
                    width: 77,
                    height: 77
                },
                title: {
                    left: 140,
                    top: 370
                },
                name: {
                    left: 75,
                    top: 457
                },
                qrtitle: {
                    left: 353,
                    top: 457
                }
            },
            4: {
                width: 428,
                height: 755,
                border: {
                    width: 186,
                    height: 186
                },
                img: {
                    width: 133,
                    height: 133
                },
                title: {
                    left: 140,
                    top: 470
                },
                name: {
                    left: 75,
                    top: 720
                },
                qrtitle: {
                    left: 353,
                    top: 720
                }
            },
            5: {
                width: 428,
                height: 621,
                border: {
                    width: 120,
                    height: 120
                },
                img: {
                    width: 77,
                    height: 77
                },
                title: {
                    left: 140,
                    top: 340
                },
                name: {
                    left: 75,
                    top: 586
                },
                qrtitle: {
                    left: 353,
                    top: 586
                }
            },
            6: {
                width: 428,
                height: 621,
                border: {
                    width: 120,
                    height: 120
                },
                img: {
                    width: 77,
                    height: 77
                },
                title: {
                    left: 140,
                    top: 340
                },
                name: {
                    left: 75,
                    top: 586
                },
                qrtitle: {
                    left: 353,
                    top: 586
                }
            },
            7: {
                width: 428,
                height: 755,
                border: {
                    width: 120,
                    height: 120
                },
                img: {
                    width: 77,
                    height: 77
                },
                title: {
                    left: 140,
                    top: 470
                },
                name: {
                    left: 75,
                    top: 720
                },
                qrtitle: {
                    left: 353,
                    top: 720
                }
            },
            8: {
                width: 428,
                height: 755,
                border: {
                    width: 120,
                    height: 120
                },
                img: {
                    width: 77,
                    height: 77
                },
                title: {
                    left: 140,
                    top: 470
                },
                name: {
                    left: 75,
                    top: 720
                },
                qrtitle: {
                    left: 353,
                    top: 720
                }
            },
            9: {
                width: 428,
                height: 755,
                border: {
                    width: 120,
                    height: 120
                },
                img: {
                    width: 77,
                    height: 77
                },
                title: {
                    left: 140,
                    top: 470
                },
                name: {
                    left: 75,
                    top: 720
                },
                qrtitle: {
                    left: 353,
                    top: 720
                }
            }
        },
        talkCanvasSize: {
            1: {
                img: {
                    height: 160,
                    width: 160
                }
            },
            2: {
                img: {
                    height: 84,
                    width: 84
                }
            },
            3: {
                img: {
                    height: 66,
                    width: 66
                }
            },
            4: {
                img: {
                    height: 84,
                    width: 84
                }
            },
            5: {
                img: {
                    height: 66,
                    width: 66
                }
            },
            6: {
                img: {
                    height: 66,
                    width: 66
                }
            }
        }
    },
    onLoad: function() {
        wx.createSelectorQuery().select("#canvas").fields({
            node: !0,
            size: !0
        }).exec(this.initCanvas.bind(this));
    },
    initCanvas: function(t) {
        var e = this;
        return a(h.default.mark(function i() {
            var a, n;
            return h.default.wrap(function(i) {
                for (;;) switch (i.prev = i.next) {
                  case 0:
                    return a = t[0].node, e.canvas = a, n = a.getContext("2d"), i.next = 5, e.createLocalImage(n, a);

                  case 5:
                  case "end":
                    return i.stop();
                }
            }, i);
        }))();
    },
    roundRect: function(t, e, i, h, a, n) {
        t.beginPath(), t.arc(e + n, i + n, n, Math.PI, 1.5 * Math.PI), t.moveTo(e + n, i), 
        t.lineTo(e + h - n, i), t.lineTo(e + h, i + n), t.arc(e + h - n, i + n, n, 1.5 * Math.PI, 2 * Math.PI), 
        t.lineTo(e + h, i + a - n), t.lineTo(e + h - n, i + a), t.arc(e + h - n, i + a - n, n, 0, .5 * Math.PI), 
        t.lineTo(e + n, i + a), t.lineTo(e, i + a - n), t.arc(e + n, i + a - n, n, .5 * Math.PI, Math.PI), 
        t.lineTo(e, i + n), t.lineTo(e + n, i), t.fill(), t.closePath(), t.clip();
    },
    createTalkerImage: function(t, e) {},
    createCanvasImage: function(t) {
        return function(e) {
            return new Promise(function(i, h) {
                var a = t.createImage();
                a.src = e, a.onload = function() {
                    i({
                        ctx: a,
                        type: "image"
                    });
                }, a.onerror = function() {
                    wx.showToast({
                        title: "图片加载失败"
                    }), h();
                };
            });
        };
    },
    createLocalImage: function(t, e) {
        var i = this;
        return a(h.default.mark(function a() {
            var n, o, r, l, d, g, f, c, w, s, u, m, p;
            return h.default.wrap(function(h) {
                for (;;) switch (h.prev = h.next) {
                  case 0:
                    return n = wx.getSystemInfoSync().pixelRatio, o = i.data.canvasSize[i.data.faceList.length], 
                    r = o.width, l = o.height, d = o.border, g = o.title, f = o.name, c = o.qrtitle, 
                    w = o.img, e.width = r * n, e.height = l * n, t.scale(n, n), s = i.createCanvasImage(e), 
                    h.next = 8, s("https://img.yzcdn.cn/vant/cat.jpeg");

                  case 8:
                    u = h.sent, t.save(), t.fillStyle = "#fff", t.fillRect(0, 0, r, l), t.fillStyle = "#f7f7f7", 
                    m = 1, (p = i.data.faceList.length) <= 3 ? m = 1 : 4 === p ? m = 2 : p > 4 && p <= 9 && (m = 3), 
                    i.data.faceList.forEach(function(e, h) {
                        1 == m && (t.save(), i.roundRect(t, 24 + (d.width + 8) * h, 40, d.width, d.height, 10), 
                        t.restore(), t.save(), i.drawImage(t, u.ctx, {
                            x: 24 + (d.width - w.width) / 2 + (d.width + 8) * h,
                            y: 40 + (d.height - w.height) / 2,
                            width: w.width,
                            height: w.height
                        }), t.restore()), 1 !== m && (t.save(), i.roundRect(t, 24 + (d.width + 8) * (h % m), 40 + (d.height + 8) * Math.floor(h / m), d.width, d.height, 10), 
                        t.restore(), t.save(), i.drawImage(t, u.ctx, {
                            x: 24 + (d.width - w.width) / 2 + (d.width + 8) * (h % m),
                            y: 40 + (d.height - w.height) / 2 + (d.height + 8) * Math.floor(h / m),
                            width: w.width,
                            height: w.height
                        }));
                    }), t.save(), t.font = "22px bold PingFang SC", t.fillStyle = "#000", t.textAlign = "center", 
                    t.fillText("“快来看看我制作的表情”", g.left, g.top), t.restore(), t.save(), t.font = "14px normal PingFang SC", 
                    t.fillStyle = "#b3b3b3", t.textAlign = "center", t.fillText("微信创意表情", f.left, f.top), 
                    t.restore(), t.save(), t.font = "12px normal PingFang SC", t.fillStyle = "#b3b3b3", 
                    t.textAlign = "center", t.fillText("微信扫一扫添加", c.left, c.top);

                  case 34:
                  case "end":
                    return h.stop();
                }
            }, a);
        }))();
    },
    onSave: function() {
        var t = this.canvas.toDataURL("image/png"), e = wx.getFileSystemManager(), i = "".concat(wx.env.USER_DATA_PATH, "/").concat(Math.random().toString(36).substr(2), ".png");
        e.writeFile({
            filePath: i,
            data: t.split(",")[1],
            encoding: "base64",
            success: function() {
                wx.saveImageToPhotosAlbum({
                    filePath: i,
                    success: function() {
                        wx.showToast({
                            title: "保存成功"
                        });
                    }
                });
            }
        });
    },
    drawImage: function(t, e, i) {
        var h = i.width / e.width, a = i.height / e.height, n = Math.min(h, a);
        t.drawImage(e, 0, 0, e.width, e.height, i.x + (i.width - e.width * n) / 2, i.y + (i.height - e.height * n) / 2, e.width * n, e.height * n);
    }
}, "createTalkerImage", function(t, e) {
    var i = this;
    return a(h.default.mark(function a() {
        var n, o, r, l, d;
        return h.default.wrap(function(h) {
            for (;;) switch (h.prev = h.next) {
              case 0:
                return n = wx.getSystemInfoSync().pixelRatio, o = i.data.talkCanvasSize[i.data.faceList.length].img, 
                e.width = 231 * n, e.height = 184 * n, t.scale(n, n), r = i.createCanvasImage(e), 
                h.next = 8, r("https://res.wx.qq.com/t/fed_upload/f5458095-c093-410d-ad8f-db577d4ab6f4/stodownload (4).jpeg");

              case 8:
                l = h.sent, t.save(), t.fillStyle = "#f7f7f7", t.fillRect(0, 0, 231, 184), d = i.data.faceList.length, 
                i.data.faceList.forEach(function(e, h) {
                    d <= 3 && i.drawImage(t, l.ctx, {
                        x: (231 - d * o.width - 8 * (d - 1)) / 2 + h * (o.width + 8),
                        y: (184 - o.height) / 2,
                        width: o.width,
                        height: o.height
                    }), 4 == d && i.drawImage(t, l.ctx, {
                        x: (231 - 2 * o.width - 8) / 2 + (o.width * (h % 2) + h % 2 * 8),
                        y: (184 - 2 * o.height) / 2 + (h <= 1 ? 0 : o.height),
                        width: o.width,
                        height: o.height
                    }), 5 == d && i.drawImage(t, l.ctx, {
                        x: (231 - 3 * o.width - 24) / 2 + (h <= 2 ? h * (o.width + 8) : (h - 2.5) * (o.width + 8)),
                        y: (184 - 2 * o.height - 4) / 2 + (h <= 2 ? 0 : o.height + 4),
                        width: o.width,
                        height: o.height
                    }), 6 == d && i.drawImage(t, l.ctx, {
                        x: (231 - 3 * o.width - 24) / 2 + (h <= 2 ? h * (o.width + 8) : (h - 3) * (o.width + 8)),
                        y: (184 - 2 * o.height - 4) / 2 + (h <= 2 ? 0 : o.height + 4),
                        width: o.width,
                        height: o.height
                    });
                });

              case 14:
              case "end":
                return h.stop();
            }
        }, a);
    }))();
}), i(e, "onReady", function() {}), i(e, "onShow", function() {}), i(e, "onHide", function() {}), 
i(e, "onUnload", function() {}), i(e, "onPullDownRefresh", function() {}), i(e, "onReachBottom", function() {}), 
i(e, "onShareAppMessage", function() {}), e));