function t(o, e) {
    return module.exports = t = Object.setPrototypeOf || function(t, o) {
        return t.__proto__ = o, t;
    }, t(o, e);
}

module.exports = t;