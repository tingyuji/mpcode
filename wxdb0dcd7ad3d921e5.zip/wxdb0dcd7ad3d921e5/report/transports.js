Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0, exports.serializeKvReportValue = f;

var e, r = (e = require("../@babel/runtime/regenerator")) && e.__esModule ? e : {
    default: e
}, t = require("../@babel/runtime/helpers/asyncToGenerator"), n = require("../@babel/runtime/helpers/classCallCheck"), a = require("../@babel/runtime/helpers/createClass"), i = require("../@babel/runtime/helpers/inherits"), s = require("../@babel/runtime/helpers/createSuper"), o = require("../@babel/runtime/helpers/typeof"), c = require("@tencent/merlin-core"), u = (require("@tencent/merlin-behavior"), 
require("../utils/utils")), l = require("./cube");

var d = require("../services/reportMmdata"), p = require("../services/reportPyqMmdata");

function f(e) {
    try {
        return "string" == typeof e ? e.replace(/,/g, ";") : e && "object" === o(e) ? JSON.stringify(e) && JSON.stringify(e).replace(/,/g, ";") || "" : e && e.toString().replace(/,/g, ";") || "";
    } catch (e) {
        return "";
    }
}

var v = function(e) {
    i(b, e);
    var c, v = s(b);
    function b() {
        var e;
        n(this, b);
        for (var r = arguments.length, t = new Array(r), a = 0; a < r; a++) t[a] = arguments[a];
        return (e = v.call.apply(v, [ this ].concat(t))).flushInterval = 2e4, e;
    }
    return a(b, [ {
        key: "send",
        value: (c = t(r.default.mark(function e(t) {
            var n, a;
            return r.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (n = t.map(this.parseWebStatsReportItem), a = t.map(function(e) {
                        var r = e.data, t = e.context, n = t.env;
                        return {
                            pageName: t.scope.pageName,
                            eleid: r.key,
                            msg: r.extInfo,
                            deviceModel: n.deviceModel,
                            deviceBrand: n.deviceBrand,
                            osName: n.osName,
                            osVersion: n.osVersion
                        };
                    }), 1154 !== wx.getLaunchOptionsSync().scene) {
                        e.next = 7;
                        break;
                    }
                    return e.next = 5, p({
                        context: n
                    });

                  case 5:
                    e.next = 9;
                    break;

                  case 7:
                    return e.next = 9, d({
                        context: n
                    });

                  case 9:
                    return e.next = 11, (0, l.cube)(a);

                  case 11:
                  case "end":
                    return e.stop();
                }
            }, e, this);
        })), function(e) {
            return c.apply(this, arguments);
        })
    }, {
        key: "parseWebStatsReportItem",
        value: function(e) {
            var r, t = e.data, n = e.ctime, a = e.context, i = a.env, s = a.base, c = a.scope;
            return function(e) {
                for (var r in e) void 0 !== e[r] && null !== e[r] && "" !== e[r] && "{}" != JSON.stringify(e[r]) || delete e[r], 
                "object" === o(e[r]) && (e[r] = f(e[r]));
                return e;
            }({
                12: i.deviceModel,
                13: i.deviceBrand,
                14: i.osName,
                15: i.osVersion,
                16: i.lang,
                21: 17,
                22: c.contextId,
                23: c.entranceId,
                24: n,
                25: i.location,
                26: c.network,
                27: i.browser,
                28: s.user.extra,
                29: c.redDotInfo,
                30: {},
                31: c.pageName,
                32: c.refPageName,
                33: c.accessId,
                34: c.refAccessId,
                35: c.refAccessId,
                36: c.step,
                37: c.extInfo,
                38: t.key || "",
                39: t.extInfo,
                40: t.behaviorType,
                41: (0, u.omit)(t, [ "key", "extInfo", "behaviorType" ]),
                42: {
                    screenHeight: c.screenHeight,
                    screenWidth: c.screenWidth,
                    clientHeight: c.clientHeight,
                    clientWidth: c.clientWidth
                },
                43: void 0 !== (null === (r = c.entranceInfo) || void 0 === r ? void 0 : r.subEntranceid) ? c.entranceInfo : void 0
            });
        }
    } ]), b;
}(c.Transport);

exports.default = v;