Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.cube = function(e) {
    var t = Math.ceil(new Date().getTime() / 1e3), r = wx.getSystemInfoSync(), o = getApp().globalData.uin, i = e.map(function(e) {
        return {
            biz_id: 3512,
            time: t,
            moduleName: "mmemotionmeshnode",
            label: "sticker.splicer",
            action: e.eleid,
            wechatVersion: r.version,
            model: e.deviceModel,
            vendor: e.deviceBrand,
            platform: r.platform,
            msg: e.msg,
            referer: "SDKVersion: ".concat(r.SDKVersion),
            uin: JSON.stringify(o),
            mVersion: e.osVersion
        };
    });
    wx.request({
        url: "https://cube.weixinbridge.com/cube/report/reportbizdata?f=json",
        header: {
            "content-type": "application/x-www-form-urlencoded"
        },
        data: {
            report_items: JSON.stringify(i)
        },
        method: "POST"
    });
}, exports.cubeError = function(e) {
    var t = [ {
        biz_id: 2457,
        time: Math.ceil(new Date().getTime() / 1e3),
        module_name: "mmemotionmeshnode",
        group_key: "sticker.splicer",
        uin: getApp().globalData.uin,
        error_msg: e
    } ];
    wx.request({
        url: "https://cube.weixinbridge.com/cube/report/reportbizdata?f=json",
        header: {
            "content-type": "application/x-www-form-urlencoded"
        },
        data: {
            report_items: JSON.stringify(t)
        },
        method: "POST"
    });
};