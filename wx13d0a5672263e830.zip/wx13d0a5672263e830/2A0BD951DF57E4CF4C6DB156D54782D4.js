Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("@babel/runtime/helpers/defineProperty.js"), r = require("@babel/runtime/helpers/objectSpread2.js"), t = require("@babel/runtime/helpers/typeof.js"), o = require("E71039E3DF57E4CF817651E41E5782D4.js"), i = {
    current: {},
    common: {
        museumList: [],
        alphabet: [],
        location: {},
        showCover: !1
    },
    audio: {
        isPlay: !1
    },
    user: {}
}, a = (0, o.createStore)(function() {
    var o = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : i, a = arguments.length > 1 ? arguments[1] : void 0, u = a.type, l = a.payload;
    if (!u || "string" != typeof u) throw new TypeError("type must be a string");
    if (l && "object" !== t(l)) throw new TypeError("payload must be an object");
    var n = o[u] || {};
    return r(r({}, o), {}, e({}, u, r(r({}, n), l)));
});

exports.default = a;