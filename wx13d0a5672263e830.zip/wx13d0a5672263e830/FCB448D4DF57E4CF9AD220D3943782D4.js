module.exports = {
    host: "https://www.wisdomguide.cn/wisdomguidev2",
    imgHost: "https://www.wisdomguide.cn/vguide"
};