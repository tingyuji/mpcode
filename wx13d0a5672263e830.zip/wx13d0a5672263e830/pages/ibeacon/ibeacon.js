var e = require("../../@babel/runtime/helpers/interopRequireDefault").default, t = require("../../@babel/runtime/helpers/regeneratorRuntime"), r = require("../../@babel/runtime/helpers/asyncToGenerator"), n = require("../../@babel/runtime/helpers/objectSpread2"), i = e(require("@mp-components/promisify")), a = require("@mp-components/mp-store"), s = e(require("../../68C8B816DF57E4CF0EAED011E1A782D4.js")), u = require("../../FCB448D4DF57E4CF9AD220D3943782D4.js"), c = function(e) {
    for (var t = 0; t < e.length; t += 1) if (0 != +e[t]) return e.slice(t);
    return "";
}, o = {
    11000: "系统或设备不支持",
    11001: "蓝牙服务不可用",
    11002: "位置服务不可用",
    11005: "系统错误"
}, h = getApp();

Page((0, a.connect)(function(e) {
    return n({}, e.exhibit);
})({
    data: {
        nearest: "",
        current: "",
        hasNew: !1,
        newExhibit: null,
        imgs: [],
        imgHost: u.imgHost
    },
    current: {
        last: "",
        count: 0
    },
    onLoad: function(e) {
        var t = e.id || "", r = "00000000-0000-0000-0000-000000000000".slice(0, -t.toString().length) + t;
        this.getBTGuide(t), this.startDiscovery([ r ]);
    },
    onUnload: function() {
        wx.stopBeaconDiscovery(), h.stopAudio();
    },
    getBTGuide: function(e) {
        var n = this;
        return r(t().mark(function r() {
            var i, a;
            return t().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.next = 2, (0, s.default)("/mp/bluetoothguide.html", {
                        data: {
                            museumid: e
                        },
                        ignoreResult: !0
                    });

                  case 2:
                    i = t.sent, a = [], i && i.images && i.images.forEach(function(e) {
                        a.push("https://www.wisdomguide.cn/vguide/bluetoothguide/".concat(e.image));
                    }), n.setData({
                        imgs: a
                    });

                  case 6:
                  case "end":
                    return t.stop();
                }
            }, r);
        }))();
    },
    startDiscovery: function(e) {
        var n = this;
        return r(t().mark(function r() {
            var a;
            return t().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.prev = 0, t.next = 3, (0, i.default)(wx.startBeaconDiscovery)({
                        uuids: e
                    });

                  case 3:
                    wx.onBeaconUpdate(n.onUpdate), t.next = 10;
                    break;

                  case 6:
                    t.prev = 6, t.t0 = t.catch(0), (a = o[t.t0.errCode] || t.t0.errMsg) && wx.showToast({
                        title: a,
                        icon: "none"
                    });

                  case 10:
                  case "end":
                    return t.stop();
                }
            }, r, null, [ [ 0, 6 ] ]);
        }))();
    },
    onUpdate: function(e) {
        var t = e.beacons.filter(function(e) {
            return 0 !== e.rssi && e.accuracy > 0;
        }).sort(function(e, t) {
            return e.accuracy - t.accuracy;
        });
        if (0 !== t.length) {
            var r = t[0], n = "".concat(r.major).concat(r.minor);
            if (console.log("last:", n), this.current.last === n ? this.current.count = this.current.count + 1 : (this.current.last = n, 
            this.current.count = 1), this.current.count >= 3) {
                this.setData({
                    nearest: n
                });
                var i = this.data, a = i.current, s = i.isPlay;
                !a || !s && a !== n ? (this.setData({
                    current: n
                }), h.getExhibit({
                    id: c(n)
                })) : a !== n ? this.getNewExhibit(c(n)) : a === n && this.setData({
                    hasNew: !1
                });
            }
        }
    },
    getNewExhibit: function(e) {
        var n = this;
        return r(t().mark(function r() {
            var i;
            return t().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.next = 2, (0, s.default)("/mp/exhibit.html", {
                        data: {
                            id: e
                        },
                        ignoreResult: !0
                    });

                  case 2:
                    (i = t.sent) && i.exhibit && n.setData({
                        newExhibit: i.exhibit,
                        hasNew: !0
                    });

                  case 4:
                  case "end":
                    return t.stop();
                }
            }, r);
        }))();
    },
    playNew: function() {
        var e = this.data.nearest;
        this.setData({
            current: e,
            hasNew: !1
        }), h.getExhibit({
            id: c(e)
        });
    },
    audioTap: function() {
        h.audioManager.toggle();
    },
    seekAudio: function(e) {
        h.audioManager.seek(e.detail.value);
    },
    tapMap: function(e) {
        var t = this.data.imgs, r = e.currentTarget.dataset.index;
        wx.previewImage({
            urls: t,
            current: t[r]
        });
    }
}));