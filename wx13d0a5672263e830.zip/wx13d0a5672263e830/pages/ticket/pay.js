var e = require("../../FCB448D4DF57E4CF9AD220D3943782D4.js");

Page({
    onLoad: function(n) {
        wx.requestPayment({
            timeStamp: decodeURIComponent(n.timeStamp),
            nonceStr: decodeURIComponent(n.nonceStr),
            package: "prepay_id=".concat(decodeURIComponent(n.prepay_id)),
            signType: n.signType ? decodeURIComponent(n.signType) : "MD5",
            paySign: decodeURIComponent(n.paySign),
            success: function() {},
            fail: function() {
                wx.showToast({
                    title: "支付失败",
                    icon: "none"
                });
            },
            complete: function() {
                wx.redirectTo({
                    url: "/pages/webview/webview?url=".concat(encodeURIComponent("".concat(e.host, "/tickets/index.html")))
                });
            }
        });
    }
});