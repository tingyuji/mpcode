var t = require("../../@babel/runtime/helpers/objectSpread2"), e = require("../../FCB448D4DF57E4CF9AD220D3943782D4.js"), a = getApp();

Page({
    data: {
        keyboardHeight: "env(safe-area-inset-bottom, 0)",
        comment: {},
        input: "",
        id: "",
        focus: !0,
        placeholder: "评论",
        touserid: 0,
        imgHost: e.imgHost
    },
    onLoad: function(t) {
        this.getCommentDetail(t.id), this.setData({
            id: t.id
        });
    },
    getCommentDetail: function(t) {
        var e = this;
        a.fetch("/mp/getcomment.html", {
            data: {
                id: t
            }
        }).then(function(t) {
            e.setData({
                comment: t.comment
            });
        }).catch(function(t) {
            wx.showToast({
                title: t.message,
                icon: "none"
            });
        });
    },
    handleLike: function() {
        var e = this, n = this.data.comment;
        a.fetch("/mp/commentlike.html", {
            data: {
                id: n.id
            }
        }).then(function(a) {
            wx.showToast({
                title: a.text || "点赞成功",
                icon: "none"
            }), e.setData({
                comment: t(t({}, n), {}, {
                    likeflag: 1
                })
            });
        }).catch(function(t) {
            wx.showToast({
                title: t.message,
                icon: "none"
            });
        });
    },
    handleSubmit: function() {
        var t = this.data, e = t.id, n = t.input, o = t.touserid, i = this;
        n ? a.fetch("/mp/commentreply.html", {
            method: "POST",
            data: {
                id: e,
                uid: o,
                content: n
            }
        }).then(function() {
            i.setData({
                input: "",
                placeholder: "评论",
                touserid: 0,
                focus: !1
            }), i.getCommentDetail(e);
        }).catch(function(t) {
            wx.showToast({
                title: t.message,
                icon: "none"
            });
        }) : wx.showToast({
            title: "请输入评论内容",
            icon: "none"
        });
    },
    tapReply: function(t) {
        var e = t.currentTarget.dataset, a = e.fromuserid, n = e.fromusername;
        this.setData({
            focus: !0,
            placeholder: "回复".concat(n),
            touserid: a
        });
    },
    tapComment: function() {
        this.setData({
            focus: !0,
            placeholder: "评论",
            touserid: 0
        });
    },
    handleInput: function(t) {
        this.setData({
            input: t.detail.value
        });
    },
    handleFocus: function(t) {
        this.setData({
            keyboardHeight: "".concat(t.detail.height || 0, "px")
        });
    },
    handleBlur: function() {
        this.setData({
            keyboardHeight: "env(safe-area-inset-bottom, 0)",
            focus: !1
        });
    }
});