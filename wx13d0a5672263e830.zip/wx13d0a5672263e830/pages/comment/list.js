var t = require("../../@babel/runtime/helpers/objectSpread2"), e = require("../../@babel/runtime/helpers/toConsumableArray"), n = require("../../FCB448D4DF57E4CF9AD220D3943782D4.js"), o = getApp();

Page({
    data: {
        commentList: [],
        page: 1,
        hasMore: !0,
        imgHost: n.imgHost
    },
    onLoad: function() {
        this.getCommentList({
            page: 1
        });
    },
    onPullDownRefresh: function() {
        this.getCommentList({
            page: 1
        });
    },
    onReachBottom: function() {
        var t = this.data, e = t.hasMore, n = t.page;
        e && this.getCommentList({
            page: n + 1
        });
    },
    getCommentList: function() {
        var t = this, n = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, a = n.page;
        wx.showLoading(), o.fetch("/mp/comment.html", {
            data: {
                page: a
            }
        }).then(function(n) {
            var o = n.commentlist || [];
            t.setData({
                commentList: 1 == +a ? o : [].concat(e(t.data.commentList), e(o)),
                page: a,
                hasMore: o.length > 0
            }), wx.hideLoading(), wx.stopPullDownRefresh();
        }).catch(function(t) {
            wx.hideLoading(), wx.stopPullDownRefresh(), wx.showToast({
                title: t.message,
                icon: "none"
            });
        });
    },
    handleLike: function(e) {
        var n = this, a = e.currentTarget.dataset, i = a.id, s = a.index;
        o.fetch("/mp/commentlike.html", {
            data: {
                id: i
            }
        }).then(function(e) {
            wx.showToast({
                title: e.text || "点赞成功",
                icon: "none"
            }), n.setData({
                commentList: n.data.commentList.map(function(e, n) {
                    return n == s ? t(t({}, e), {}, {
                        likeflag: 1
                    }) : e;
                })
            });
        }).catch(function(t) {
            wx.showToast({
                title: t.message,
                icon: "none"
            });
        });
    }
});