var t = require("../../@babel/runtime/helpers/interopRequireDefault").default, e = require("../../@babel/runtime/helpers/objectSpread2"), a = require("../../@babel/runtime/helpers/toConsumableArray"), n = require("../../FCB448D4DF57E4CF9AD220D3943782D4.js"), i = t(require("../../4C5FD416DF57E4CF2A39BC11019782D4.js")), s = getApp();

Page((0, i.default)(function(t) {
    return {
        current: t.current
    };
})({
    data: {
        input: "",
        imgs: []
    },
    handleInput: function(t) {
        this.setData({
            input: t.detail.value
        });
    },
    handleSubmit: function() {
        var t = this.data, e = t.input, a = t.imgs, n = this;
        e ? a.length > 0 && !a.every(function(t) {
            return 1 === t.status;
        }) ? wx.showToast({
            title: "有图片上传失败",
            icon: "none"
        }) : (wx.showLoading({
            title: "提交中",
            mask: !0
        }), s.fetch("/mp/savecomment.html", {
            method: "POST",
            data: {
                content: e,
                imagelist: a.map(function(t) {
                    return t.id;
                }).join(",")
            }
        }).then(function() {
            n.setData({
                input: "",
                imgs: []
            }), wx.showToast({
                title: "留言已提交，请等待审核",
                mask: !0,
                icon: "none"
            }), setTimeout(function() {
                return wx.navigateBack();
            }, 1500);
        }).catch(function(t) {
            wx.showToast({
                title: t.message,
                icon: "none"
            });
        })) : wx.showToast({
            title: "留言内容不能为空",
            icon: "none"
        });
    },
    chooseImage: function() {
        var t = this, e = this.data.imgs, n = 3 - e.length;
        wx.chooseImage({
            count: n,
            success: function(i) {
                var s = i.tempFilePaths.map(function(t) {
                    return {
                        temp: t,
                        id: null,
                        status: -1
                    };
                });
                t.setData({
                    imgs: [].concat(a(e), a(s))
                }, function() {
                    t.uploadImg(3 - n, !0);
                });
            }
        });
    },
    uploadImg: function(t, a) {
        var i = this.data.imgs, s = this;
        i[t] && (1 !== i[t].status ? wx.uploadFile({
            url: "".concat(n.host, "/mp/commentupload.html"),
            header: {
                Cookie: "PHPSESSID=".concat(wx.getStorageSync("SESSID"))
            },
            name: "image",
            filePath: i[t].temp,
            success: function(n) {
                n.statusCode >= 200 && n.statusCode < 300 ? (n.data = "string" == typeof n.data ? JSON.parse(n.data) : n.data, 
                n.data && 1 == +n.data.result ? i[t] = e(e({}, i[t]), {}, {
                    status: 1,
                    id: n.data.imageid
                }) : i[t] = e(e({}, i[t]), {}, {
                    status: 0
                })) : i[t] = e(e({}, i[t]), {}, {
                    status: 0
                }), s.setData({
                    imgs: i
                }, function() {
                    a && s.uploadImg(t + 1, !0);
                });
            },
            fail: function() {
                i[t] = e(e({}, i[t]), {}, {
                    status: 0
                }), s.setData({
                    imgs: i
                }, function() {
                    a && s.uploadImg(t + 1, !0);
                });
            }
        }) : a && s.uploadImg(t + 1, !0));
    },
    tapImg: function(t) {
        var e = +t.currentTarget.dataset.index, a = this.data.imgs[e], n = this;
        0 === a.status && wx.showActionSheet({
            itemList: [ "删除" ],
            success: function(t) {
                if (0 === t.tapIndex) {
                    var a = n.data.imgs;
                    a.splice(e, 1), n.setData({
                        imgs: a
                    });
                }
            }
        }), 1 === a.state && wx.previewImage({
            urls: [ a.temp ]
        });
    }
}));