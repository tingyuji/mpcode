var e = (0, require("../../@babel/runtime/helpers/interopRequireDefault").default)(require("../../4C5FD416DF57E4CF2A39BC11019782D4.js")), t = require("../../FCB448D4DF57E4CF9AD220D3943782D4.js"), n = require("../../EDD49122DF57E4CF8BB2F92525B782D4.js");

Page((0, e.default)(function(e) {
    return {
        currentMuseum: e.current.mainmuseum && e.current.mainmuseum.id
    };
})({
    data: {
        url: ""
    },
    onLoad: function(e) {
        if (e && e.url) this.setData({
            url: "".concat(decodeURIComponent(e.url), "#wechat_redirect")
        }); else {
            var u = this;
            e && e.type && wx.login({
                success: function(r) {
                    wx.getUserInfo({
                        success: function(i) {
                            var c = {
                                code: r.code,
                                encryptedData: encodeURIComponent(i.encryptedData),
                                iv: encodeURIComponent(i.iv),
                                museumid: u.data.currentMuseum,
                                type: e.type
                            };
                            u.setData({
                                url: "".concat(t.host, "/mp/initialh5.html?").concat((0, n.stringify)(c), "#wechat_redirect")
                            });
                        },
                        fail: function() {
                            wx.showToast({
                                title: "请先登录",
                                icon: "none",
                                duration: 1e3
                            }), setTimeout(function() {
                                wx.switchTab({
                                    url: "/pages/me/me"
                                });
                            }, 1e3);
                        }
                    });
                }
            });
        }
    }
}));