var t = require("../../DE27ECA7DF57E4CFB84184A0CEC782D4.js"), i = require("../../FCB448D4DF57E4CF9AD220D3943782D4.js"), e = getApp();

Page({
    data: {
        list: [],
        museumimage: "",
        imgHost: i.imgHost
    },
    onLoad: function() {
        this.getVRList();
    },
    getVRList: function() {
        var i = this;
        wx.showLoading(), e.fetch("/mp/vrlist.html").then(function(t) {
            i.setData({
                list: t.vrexhibitlist || [],
                museumimage: t.museumimage
            }), wx.hideLoading();
        }).catch(t.fetchCatchToast);
    },
    handleTap: function(t) {
        var i = t.currentTarget.dataset.index, a = this.data.list[i], n = a.url, s = a.id;
        e.fetch("/index/arvrclick.html", {
            data: {
                id: s
            }
        }), wx.navigateTo({
            url: "/pages/vr/detail?url=".concat(encodeURIComponent(n))
        });
    },
    handleLike: function(t) {
        var i = this, a = t.currentTarget.dataset.index, n = this.data.list;
        e.fetch("/index/arvrlike.html", {
            data: {
                id: n[a].id
            }
        }).then(function() {
            wx.showToast({
                title: "点赞成功",
                icon: "none"
            }), n[a].showlike = +n[a].showlike + 1, i.setData({
                list: n
            });
        });
    }
});