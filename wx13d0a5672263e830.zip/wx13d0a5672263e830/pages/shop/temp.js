Page({
    onShow: function() {
        wx.redirectTo({
            url: "/pages/webview/webview?type=5"
        });
    }
});