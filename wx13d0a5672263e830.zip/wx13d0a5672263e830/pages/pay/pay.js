Page({
    onLoad: function(e) {
        wx.requestPayment({
            timeStamp: decodeURIComponent(e.timeStamp),
            nonceStr: decodeURIComponent(e.nonceStr),
            package: "prepay_id=".concat(decodeURIComponent(e.prepay_id)),
            signType: e.signType ? decodeURIComponent(e.signType) : "MD5",
            paySign: decodeURIComponent(e.paySign),
            success: function() {},
            fail: function(e) {
                console.log("支付失败:", e), wx.showToast({
                    title: "支付失败",
                    icon: "none"
                });
            },
            complete: function() {
                wx.redirectTo({
                    url: "/pages/webview/webview?url=".concat(encodeURIComponent("https://www.wisdomguide.cn/shop/#/order"))
                });
            }
        });
    }
});