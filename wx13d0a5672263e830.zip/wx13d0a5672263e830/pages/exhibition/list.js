var t = require("../../FCB448D4DF57E4CF9AD220D3943782D4.js"), e = require("../../DE27ECA7DF57E4CFB84184A0CEC782D4.js"), i = getApp();

Page({
    data: {
        list: [],
        standing: [],
        temp: [],
        tabs: [ {
            title: "常设展览",
            key: "standing"
        }, {
            title: "临时展览",
            key: "temp"
        } ],
        active: "standing",
        museumfree: null,
        imgHost: t.imgHost,
        platform: ""
    },
    onLoad: function() {
        var t = this;
        this.getExhibitionList(), wx.getSystemInfo({
            success: function(e) {
                t.setData({
                    platform: e.platform.toLowerCase()
                });
            }
        });
    },
    tapTab: function(t) {
        this.setData({
            active: t.currentTarget.dataset.key
        });
    },
    getExhibitionList: function() {
        var t = this;
        wx.showLoading(), i.fetch("/mp/exhibitionlist.html").then(function(e) {
            t.setData({
                standing: e.standinglist || [],
                temp: e.templist || [],
                museumfree: e.museumfree
            }), wx.hideLoading();
        }).catch(e.fetchCatchToast);
    }
});