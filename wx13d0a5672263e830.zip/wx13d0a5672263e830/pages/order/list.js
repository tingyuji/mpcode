var t = require("../../DE27ECA7DF57E4CFB84184A0CEC782D4.js"), e = require("../../FCB448D4DF57E4CF9AD220D3943782D4.js"), i = getApp();

Page({
    data: {
        tabs: [ {
            title: "导览订单",
            key: "guide"
        }, {
            title: "讲解订单",
            key: "guidebook"
        }, {
            title: "门票订单",
            key: "ticket"
        } ],
        bookStatus: [ "", "待现场确认", "待使用", "已使用", "已过期", "待退款", "已退款/已取消", "已改签", "已取消" ],
        ticketStatus: [ "", "待支付", "待使用", "已使用", "已过期", "待退款", "已退款", "已改签", "已取消" ],
        active: "guide",
        imgHost: e.imgHost
    },
    onLoad: function() {
        this.getOrderList();
    },
    handleTabChange: function(t) {
        this.setData({
            active: t.currentTarget.dataset.key
        });
    },
    getOrderList: function() {
        var e = this;
        wx.showLoading(), i.fetch("/mp/orderlist.html", {
            data: {
                page: 1
            }
        }).then(function(t) {
            e.setData({
                list: {
                    guidebook: t.guidebookorderlist || [],
                    guide: t.guideorderlist || [],
                    ticket: t.ticketorderlist || []
                }
            }), wx.hideLoading();
        }).catch(t.fetchCatchToast);
    }
});