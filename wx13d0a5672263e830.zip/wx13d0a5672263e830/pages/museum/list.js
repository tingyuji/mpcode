var t = (0, require("../../@babel/runtime/helpers/interopRequireDefault").default)(require("../../4C5FD416DF57E4CF2A39BC11019782D4.js")), e = require("../../FCB448D4DF57E4CF9AD220D3943782D4.js"), a = getApp();

Page((0, t.default)(function(t) {
    return {
        list: t.common.museumList,
        alphabet: t.common.alphabet,
        location: t.common.location
    };
})({
    data: {
        intoView: null,
        listHeight: 0,
        inputVal: "",
        searchList: null,
        imgHost: e.imgHost
    },
    onLoad: function() {
        var t = this;
        this.getMuseumList(), wx.getSystemInfo({
            success: function(e) {
                var a = e.windowHeight, i = e.windowWidth;
                t.setData({
                    listHeight: a - i / 750 * 88
                });
            }
        });
    },
    getMuseumList: function() {
        wx.showLoading();
        var t = this.data.location, e = t.latitude, i = t.longitude, n = {};
        e && (n.location = "".concat(e, ",").concat(i)), a.request({
            url: "/mp/changemuseum.html",
            data: n,
            success: function(t) {
                if (t.statusCode >= 200 && t.statusCode < 300) {
                    var e = [];
                    t.data.forEach(function(t) {
                        t.list.length > 0 && e.push(t);
                    }), a.setState("common", {
                        museumList: e,
                        alphabet: e.map(function(t) {
                            return t.alphabet;
                        })
                    });
                } else wx.showToast({
                    title: t.data.text || "接口请求错误",
                    icon: "none"
                });
            },
            fail: function() {
                wx.showToast({
                    title: "网络请求错误",
                    icon: "none"
                });
            },
            complete: function() {
                wx.hideLoading();
            }
        });
    },
    handleTap: function(t) {
        wx.navigateBack({
            complete: function() {
                setTimeout(function() {
                    a.getMuseum(t.currentTarget.dataset.id), a.stopAudio();
                }, 500);
            }
        });
    },
    goTo: function(t) {
        this.setData({
            intoView: "item-".concat(t.currentTarget.dataset.key)
        });
    },
    searchList: function(t) {
        if (t) {
            var e = [];
            this.data.list.forEach(function(a) {
                var i = [];
                a.list.forEach(function(e) {
                    e.name.indexOf(t) > -1 && i.push(e);
                }), i.length > 0 && e.push({
                    alphabet: a.alphabet,
                    list: i
                });
            }), this.setData({
                searchList: e
            });
        } else this.setData({
            searchList: null
        });
    },
    inputTyping: function(t) {
        this.setData({
            inputVal: t.detail.value
        }), this.searchList(t.detail.value);
    },
    cancelSearch: function() {
        this.setData({
            inputVal: "",
            searchList: null
        });
    }
}));