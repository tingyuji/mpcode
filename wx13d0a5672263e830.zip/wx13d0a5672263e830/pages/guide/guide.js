var t = (0, require("../../@babel/runtime/helpers/interopRequireDefault").default)(require("../../4C5FD416DF57E4CF2A39BC11019782D4.js")), e = require("../../FCB448D4DF57E4CF9AD220D3943782D4.js"), i = getApp();

Page((0, t.default)(function(t) {
    return {
        current: t.current,
        showCover: t.common.showCover
    };
})({
    data: {
        showAd: !1,
        showModal: !1,
        actions: [ {
            title: "扫码讲解",
            icon: "scan",
            key: "scan"
        }, {
            title: "编码讲解",
            icon: "code",
            key: "code"
        }, {
            title: "展厅讲解",
            icon: "hall",
            key: "exhibit"
        }, {
            title: "定位导览",
            icon: "beacon",
            key: "beacon"
        }, {
            title: "VR观赏",
            icon: "vr",
            key: "vr"
        } ],
        infos: [ {
            title: "场馆信息",
            icon: "hall",
            key: "hall"
        }, {
            title: "票务信息",
            icon: "ticket",
            key: "ticket"
        }, {
            title: "推荐路线",
            icon: "nav",
            key: "nav"
        }, {
            title: "我要留言",
            icon: "comment",
            key: "comment"
        } ],
        hots: [ {
            title: "热门展览",
            key: "exhibitionlist"
        }, {
            title: "热门文物",
            key: "exhibitlist"
        } ],
        activeHot: "exhibitionlist",
        showDropdown: !1,
        imgHost: e.imgHost
    },
    onLoad: function() {
        var t = this;
        setTimeout(function() {
            t.openAd();
        }, 2e3);
    },
    onShareAppMessage: function() {
        return {
            title: "文博智慧导览",
            path: "/pages/guide/guide",
            imageUrl: "/statics/share.jpg"
        };
    },
    getUserInfo: function(t) {
        console.log("bindgetuserinfo:", t), "getUserInfo:fail auth deny" !== t.detail.errMsg && wx.login({
            success: function(e) {
                console.log("page wx.login success:", e), i.getGeoMuseum({
                    code: e.code,
                    signature: t.detail.signature,
                    encryptedData: t.detail.encryptedData,
                    iv: t.detail.iv
                }), wx.showTabBar({
                    animation: !0
                }), wx.setNavigationBarColor({
                    frontColor: "#ffffff",
                    backgroundColor: "#911c22",
                    animation: !0
                }), i.setState("common", {
                    showCover: !1
                });
            },
            fail: function(t) {
                console.log("page wx.login fail:", t);
            }
        });
    },
    tapAction: function(t) {
        if (i.globalData.isLogin) {
            var e = t.currentTarget.dataset.key;
            if (this.data.current.actions[e]) switch (e) {
              case "scan":
                this.scanCode();
                break;

              case "code":
                this.toggleModal();
                break;

              case "exhibit":
                this.toExhibition();
                break;

              case "vr":
                wx.navigateTo({
                    url: "/pages/vr/list"
                });
                break;

              case "beacon":
                wx.navigateTo({
                    url: "/pages/ibeacon/ibeacon?id=".concat(this.data.current.mainmuseum.id)
                });
            }
        } else i.toLogin();
    },
    tapInfo: function(t) {
        var e = t.currentTarget.dataset.key;
        if ("ticket" !== e && "comment" !== e || i.globalData.isLogin) switch (e) {
          case "hall":
            wx.navigateTo({
                url: "/pages/webview/webview?type=3"
            });
            break;

          case "ticket":
            wx.navigateTo({
                url: "/pages/webview/webview?type=1"
            });
            break;

          case "nav":
            wx.navigateTo({
                url: "/pages/webview/webview?type=4"
            });
            break;

          case "comment":
            wx.navigateTo({
                url: "/pages/comment/list"
            });
        } else i.toLogin();
    },
    tapHot: function(t) {
        var e = t.currentTarget.dataset.key;
        this.setData({
            activeHot: e
        });
    },
    tapHotItem: function(t) {
        var e = this.data, a = e.activeHot, o = e.current, n = +t.currentTarget.dataset.index, s = o[a][n];
        "museumlist" === a && (i.getMuseum(s.museumid, function() {
            wx.navigateTo({
                url: "/pages/exhibition/list"
            });
        }), i.stopAudio()), "exhibitionlist" === a && wx.navigateTo({
            url: "/pages/exhibit/list?id=".concat(s.exhibitionid)
        }), "exhibitlist" === a && wx.navigateTo({
            url: "/pages/exhibit/detail?id=".concat(s.exhibitid, "&from=7")
        });
    },
    tapMuseumItem: function(t) {
        i.getMuseum(t.currentTarget.dataset.id, function() {
            wx.navigateTo({
                url: "/pages/exhibition/list"
            });
        }), wx.pageScrollTo({
            scrollTop: 0
        }), i.stopAudio();
    },
    scanCode: function() {
        i.globalData.isLogin ? i.util.scanCode(function(t) {
            i.util.getScanResult(t, function(t) {
                wx.navigateTo({
                    url: "/pages/exhibit/detail?id=".concat(t.id, "&from=2")
                });
            });
        }) : this.handleLogin();
    },
    toggleModal: function() {
        i.globalData.isLogin ? this.setData({
            showModal: !this.data.showModal
        }) : this.handleLogin();
    },
    modalConfirm: function(t) {
        this.toggleModal(), wx.navigateTo({
            url: "/pages/exhibit/detail?originalid=".concat(t.detail.value, "&from=3")
        });
    },
    toExhibition: function() {
        i.globalData.isLogin ? wx.navigateTo({
            url: "/pages/exhibition/list"
        }) : this.handleLogin();
    },
    stopAudio: function() {
        i.stopAudio();
    },
    handleLogin: function() {
        wx.showToast({
            title: "请先登录",
            icon: "none",
            duration: 500
        }), setTimeout(function() {
            wx.switchTab({
                url: "/pages/me/me"
            });
        }, 500);
    },
    tapLanguageTrigger: function() {
        this.setData({
            showDropdown: !this.data.showDropdown
        });
    },
    openAd: function() {
        "true" !== wx.getStorageSync("SHOW_HUBEI_AD2") && this.setData({
            showAd: !0
        });
    },
    closeAd: function() {
        wx.setStorage({
            key: "SHOW_HUBEI_AD2",
            data: "true"
        }), this.setData({
            showAd: !1
        });
    },
    tapAd: function() {
        this.closeAd(), i.getMuseum(15);
    }
}));