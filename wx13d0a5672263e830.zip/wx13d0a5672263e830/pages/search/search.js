var t = require("../../FCB448D4DF57E4CF9AD220D3943782D4.js"), e = getApp(), i = "SEARCH_HISTORY";

Page({
    data: {
        searchResult: [],
        keyword: "",
        topKeyword: [],
        museumList: [],
        exhibitionList: [],
        exhibitList: [],
        history: [],
        imgHost: t.imgHost
    },
    onLoad: function() {
        this.getSearchInitialData();
    },
    onShow: function() {
        var t = this;
        wx.getStorage({
            key: i,
            success: function(e) {
                t.setData({
                    history: e.data.split(",")
                });
            }
        });
    },
    handleInput: function(t) {
        var e = t.detail.value;
        this.setData({
            keyword: e
        }), e && this.handleSearch(e);
    },
    handleSearch: function(t) {
        var i = this;
        t && e.fetch("/mp/search.html", {
            data: {
                keyword: t
            }
        }).then(function(t) {
            i.setData({
                searchResult: t
            });
        });
    },
    tapSearch: function() {
        var t = this.data.keyword;
        t && (this.handleSearch(t), this.setHistory(t));
    },
    handleTap: function(t) {
        var i = t.currentTarget.dataset, a = i.type, s = i.id;
        switch (a) {
          case "museum":
            wx.switchTab({
                url: "/pages/guide/guide"
            }), e.getMuseum(s), e.stopAudio();
            break;

          case "exhibition":
            wx.navigateTo({
                url: "/pages/exhibit/list?id=".concat(s)
            });
            break;

          case "exhibit":
            wx.navigateTo({
                url: "/pages/exhibit/detail?id=".concat(s, "&from=7")
            });
        }
    },
    getSearchInitialData: function() {
        var t = this;
        e.fetch("/mp/searchinitial.html", {
            ignoreResult: !0
        }).then(function(e) {
            t.setData({
                topKeyword: e.topkeyword || [],
                museumList: e.museumlist || [],
                exhibitionList: e.exhibitionlist || [],
                exhibitList: e.exhibitlist || []
            });
        });
    },
    setHistory: function(t) {
        var e = this.data.history, a = e.indexOf(t);
        a > -1 && e.splice(a, 1), e.length >= 10 && e.pop(), e.unshift(t), this.setData({
            history: e
        }), wx.setStorage({
            key: i,
            data: e.join(",")
        });
    },
    clearHistory: function() {
        wx.removeStorage({
            key: i
        }), this.setData({
            history: []
        });
    },
    tapTag: function(t) {
        var e = t.currentTarget.dataset.keyword;
        this.setData({
            keyword: e
        }), this.handleSearch(e), this.setHistory(e);
    }
});