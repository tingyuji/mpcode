var t = require("../../@babel/runtime/helpers/toConsumableArray"), i = require("../../FCB448D4DF57E4CF9AD220D3943782D4.js"), a = require("../../DE27ECA7DF57E4CFB84184A0CEC782D4.js"), e = getApp();

Page({
    data: {
        id: null,
        page: 1,
        list: [],
        canGetMore: !0,
        inputVal: "",
        exhibition: {},
        imgHost: i.imgHost
    },
    onLoad: function(t) {
        this.setData({
            id: t.id
        }, this.getList);
    },
    getList: function() {
        var t = this;
        wx.showLoading(), e.fetch("/mp/exhibition.html", {
            data: {
                id: this.data.id
            }
        }).then(function(i) {
            t.setData({
                list: i.exhibitlanglist || [],
                exhibition: i.exhibitionlang || {},
                canGetMore: !(i.exhibitlanglist.length < 10)
            }), wx.setNavigationBarTitle({
                title: "".concat(i.exhibitionlang.name, " - 展品列表")
            }), wx.hideLoading();
        }).catch(a.fetchCatchToast);
    },
    getMoreList: function() {
        wx.showLoading();
        var i = this;
        e.request({
            url: "/mp/exhibitionmore.html",
            data: {
                id: i.data.id,
                page: i.data.page + 1
            },
            success: function(a) {
                a.statusCode >= 200 && a.statusCode < 300 && (1 == a.data.result && (i.setData({
                    list: [].concat(t(i.data.list), t(a.data.exhibitlanglist)),
                    page: i.data.page + 1
                }), a.data.exhibitlanglist.length < 10 && i.setData({
                    canGetMore: !1
                })), wx.hideLoading());
            }
        });
    },
    searchList: function(t) {
        var i = this;
        e.request({
            url: "/mp/exhibitionsearch.html",
            data: {
                id: i.data.exhibition.id,
                keyword: t
            },
            success: function(t) {
                1 == t.data.result ? i.setData({
                    list: t.data.exhibitlanglist,
                    page: 1
                }) : i.setData({
                    list: [],
                    page: 1
                });
            }
        });
    },
    onReachBottom: function() {
        var t = this.data, i = t.canGetMore, a = t.inputVal;
        i && !a && this.getMoreList();
    },
    inputTyping: function(t) {
        t.detail.value ? (this.setData({
            inputVal: t.detail.value
        }), this.searchList(t.detail.value)) : this.getList();
    },
    cancelSearch: function() {
        this.setData({
            inputVal: ""
        }), this.getList();
    }
});