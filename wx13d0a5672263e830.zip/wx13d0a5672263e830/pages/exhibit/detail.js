var t = require("../../@babel/runtime/helpers/interopRequireDefault").default, e = require("../../@babel/runtime/helpers/objectSpread2"), i = require("../../@babel/runtime/helpers/slicedToArray"), a = require("@mp-components/mp-store"), n = require("../../FCB448D4DF57E4CF9AD220D3943782D4.js"), o = require("../../DE27ECA7DF57E4CFB84184A0CEC782D4.js"), s = t(require("../../68C8B816DF57E4CF0EAED011E1A782D4.js")), c = getApp();

Page((0, a.connect)(function(t) {
    return e({}, t.exhibit);
}, function(t) {
    return e({}, t.exhibit);
})({
    data: {
        showModal: !1,
        imgHost: n.imgHost,
        tradeno: null,
        isPay: !1,
        platform: "",
        iosCanPay: !1,
        retry: 0
    },
    onLoad: function(t) {
        var e = this;
        if (wx.getSystemInfo({
            success: function(t) {
                e.setData({
                    platform: t.platform.toLowerCase()
                });
            }
        }), t.q) {
            var a = +function(t) {
                var e = t.split("?")[1].split("&"), a = {};
                return e.forEach(function(t) {
                    var e = t.split("="), n = i(e, 2), o = n[0], s = n[1];
                    a[o] = s;
                }), a.e;
            }(decodeURIComponent(t.q));
            if (a) return void c.getExhibit({
                id: a,
                from: 6
            });
        }
        4 != t.from && (c.getExhibit(t), this.getIosCanPay());
    },
    onShow: function() {
        var t = this.data, e = t.tradeno, i = t.isPay;
        e && i && (this.paySuccess(e), this.setData({
            isPay: !1
        }));
    },
    getIosCanPay: function() {
        var t = this;
        (0, s.default)("/mp/getparm?parm=iosmppay").then(function(e) {
            t.setData({
                iosCanPay: 1 == e.value
            });
        });
    },
    audioTap: function() {
        c.audioManager.toggle();
    },
    seekAudio: function(t) {
        c.audioManager.seek(t.detail.value);
    },
    wxPay: function() {
        wx.showLoading();
        var t = this;
        wx.login({
            success: function(e) {
                c.request({
                    url: "/mp/weixinpay.html",
                    data: {
                        id: t.data.exhibit.id,
                        type: t.data.type,
                        code: e.code,
                        os: t.data.platform
                    },
                    success: function(e) {
                        if (1 == e.data.result) {
                            wx.hideLoading();
                            var i = e.data, a = i.timestamp, n = i.noncestr, o = i.prepayid, s = i.sign, c = i.tradeno;
                            wx.requestPayment({
                                timeStamp: a.toString(),
                                nonceStr: n,
                                package: "prepay_id=".concat(o),
                                signType: "MD5",
                                paySign: s,
                                success: function() {
                                    t.setData({
                                        tradeno: c,
                                        isPay: !0
                                    });
                                },
                                fail: function() {
                                    wx.showToast({
                                        title: "支付失败",
                                        icon: "none"
                                    });
                                }
                            });
                        } else wx.showToast({
                            title: e.data.text || "接口请求错误",
                            icon: "none"
                        });
                    },
                    fail: function() {
                        wx.showToast({
                            title: "网络请求错误",
                            icon: "none"
                        });
                    }
                });
            }
        });
    },
    paySuccess: function(t) {
        var e = this;
        wx.showLoading(), c.fetch("/mp/weixinpayappresult.html", {
            data: {
                tradeno: t
            }
        }).then(function(t) {
            c.getExhibit({
                id: t.exhibitid
            });
        }).catch(function(i) {
            e.data.retry < 3 ? (e.setData({
                retry: e.data.retry + 1
            }), e.paySuccess(t)) : wx.showToast({
                title: i.message,
                icon: "none"
            });
        });
    },
    scanNext: function() {
        c.util.scanCode(function(t) {
            c.util.getScanResult(t, function(t) {
                c.getExhibit({
                    id: t.id,
                    originalid: null
                });
            });
        });
    },
    toggleModal: function() {
        this.setData({
            showModal: !this.data.showModal
        });
    },
    modalConfirm: function(t) {
        this.toggleModal(), c.getExhibit({
            originalid: t.detail.value,
            id: null
        });
    },
    handleLike: function() {
        var t = this;
        c.fetch("/mp/exhibitlike.html", {
            data: {
                id: this.data.id
            }
        }).then(function(i) {
            t.updateState({
                exhibit: e(e({}, t.data.exhibit), {}, {
                    likeflag: 1,
                    showlike: +t.data.exhibit.showlike + 1
                })
            }), wx.showToast({
                title: i.text,
                icon: "none"
            });
        }).catch(o.fetchCatchToast);
    },
    handleStore: function() {
        var t = this;
        c.fetch("/mp/exhibitstore.html", {
            data: {
                id: this.data.id
            }
        }).then(function(i) {
            t.updateState({
                exhibit: e(e({}, t.data.exhibit), {}, {
                    collectflag: 1,
                    collect: +t.data.exhibit.collect + 1
                })
            }), wx.showToast({
                title: i.text,
                icon: "none"
            });
        }).catch(o.fetchCatchToast);
    },
    playNext: function() {
        c.playNext();
    },
    playPrev: function() {
        c.playPrev();
    },
    onShare: function() {
        wx.showShareMenu();
    },
    onShareAppMessage: function() {
        var t = this.data, e = t.exhibit;
        return {
            title: t.exhibitlang.name || e.name,
            path: "/pages/exhibit/detail?id=".concat(e.id),
            imageUrl: "".concat(n.imgHost, "/exhibit/").concat(e.exhibitionid, "/images/").concat(e.image)
        };
    },
    tapImg: function() {
        var t = this.data.exhibit;
        wx.previewImage({
            urls: [ "".concat(n.imgHost, "/exhibit/").concat(t.exhibitionid, "/images/").concat(t.image) ]
        });
    },
    preventMove: function() {}
}));