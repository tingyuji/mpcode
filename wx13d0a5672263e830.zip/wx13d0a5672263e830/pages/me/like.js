var t = require("../../DE27ECA7DF57E4CFB84184A0CEC782D4.js"), i = require("../../FCB448D4DF57E4CF9AD220D3943782D4.js"), e = getApp();

Page({
    data: {
        exhibitList: [],
        imgHost: i.imgHost
    },
    onLoad: function() {
        this.getStoreData();
    },
    getStoreData: function() {
        var i = this;
        e.fetch("/mp/mystore.html").then(function(t) {
            i.setData({
                exhibitList: t.exhibitlist || []
            });
        }).catch(t.fetchCatchToast);
    }
});