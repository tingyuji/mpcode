var e = require("../../@babel/runtime/helpers/interopRequireDefault").default, t = e(require("@mp-components/promisify")), n = e(require("../../4C5FD416DF57E4CF2A39BC11019782D4.js")), u = getApp();

Page((0, n.default)(function(e) {
    return {
        userInfo: e.user
    };
})({
    data: {
        userInfo: {},
        wxInfo: {}
    },
    onLoad: function() {
        this.getWxInfo(), this.getUserInfo();
    },
    onShareAppMessage: function() {
        return {
            title: "文博智慧导览",
            path: "/pages/guide/guide",
            imageUrl: "/statics/share.jpg"
        };
    },
    getUserInfo: function() {
        u.fetch("/mp/userinfo.html").then(function(e) {
            u.setState("user", e.userinfo || {});
        }).catch(function() {});
    },
    getWxInfo: function() {
        var e = this;
        (0, t.default)(wx.getUserInfo)().then(function(n) {
            (0, t.default)(wx.login)().then(function(t) {
                u.getGeoMuseum({
                    code: t.code,
                    signature: n.signature,
                    encryptedData: n.encryptedData,
                    iv: n.iv
                }, e.getUserInfo, !0), e.setData({
                    wxInfo: n.userInfo
                });
            });
        }).catch(function() {});
    }
}));