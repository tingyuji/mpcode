var t = (0, require("../../@babel/runtime/helpers/interopRequireDefault").default)(require("../../4C5FD416DF57E4CF2A39BC11019782D4.js")), e = getApp();

Page((0, t.default)(function(t) {
    return {
        userInfo: t.user
    };
})({
    data: {
        beancount: 0,
        couponcount: 0
    },
    onLoad: function() {
        this.getBeanData();
    },
    getBeanData: function() {
        var t = this;
        e.fetch("/mp/wisdombean.html").then(function(e) {
            t.setData({
                beancount: e.beancount || 0,
                couponcount: e.couponcount || 0
            });
        }).catch(function(t) {
            wx.showToast({
                title: t.message,
                icon: "none"
            });
        });
    }
}));