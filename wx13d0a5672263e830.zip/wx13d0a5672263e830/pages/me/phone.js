var e = require("../../@babel/runtime/helpers/defineProperty");

Page({
    data: {
        phone: ""
    },
    onLoad: function(e) {
        this.setData({
            phone: e.phone || ""
        }), wx.setNavigationBarTitle({
            title: e.phone ? "更换手机号" : "绑定手机号"
        });
    },
    handleInputChange: function(t) {
        var a = t.currentTarget.dataset.key;
        this.setData(e({}, a, t.detail.value));
    }
});