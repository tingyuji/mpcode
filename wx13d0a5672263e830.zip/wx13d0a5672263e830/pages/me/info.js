Page({
    data: {
        userInfo: {}
    },
    onLoad: function(t) {
        this.setData({
            userInfo: t
        });
    }
});