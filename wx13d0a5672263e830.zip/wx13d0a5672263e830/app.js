var t = require("@babel/runtime/helpers/interopRequireWildcard").default, e = require("@babel/runtime/helpers/interopRequireDefault").default, i = require("@babel/runtime/helpers/regeneratorRuntime"), a = require("@babel/runtime/helpers/asyncToGenerator"), n = require("@babel/runtime/helpers/objectSpread2"), o = require("@babel/runtime/helpers/slicedToArray"), u = e(require("@mp-components/promisify")), s = require("@mp-components/mp-store"), r = e(require("084801C2DF57E4CF6E2E69C5237782D4.js")), c = e(require("47473933DF57E4CF21215134745782D4.js")), h = e(require("1BC1EDD3DF57E4CF7DA785D46FB782D4.js")), d = e(require("68C8B816DF57E4CF0EAED011E1A782D4.js")), l = t(require("02340864DF57E4CF6452606368D782D4.js")), g = require("DE27ECA7DF57E4CFB84184A0CEC782D4.js"), m = e(require("2A0BD951DF57E4CF4C6DB156D54782D4.js")), f = require("FCB448D4DF57E4CF9AD220D3943782D4.js"), p = (0, 
s.createStore)(r.default);

App((0, s.withStore)(p)({
    onLaunch: function(t) {
        this.launchOptions = t || {}, this.initAudioManager();
    },
    launch: function() {
        if (!this.isLaunch) {
            this.isLaunch = !0;
            var t = this;
            this.getLocation(function() {
                (0, u.default)(wx.login)().then(function(e) {
                    console.log("app wx.login success:", e), t.getUserInfo(e.code);
                }).catch(function(t) {
                    console.log("app wx.login fail:", t);
                });
            });
        }
    },
    getLocation: function(t) {
        var e = this;
        wx.showLoading(), (0, u.default)(wx.getLocation)().then(function(i) {
            e.setState("common", {
                location: i
            }), wx.hideLoading(), t && t();
        }).catch(function(e) {
            wx.hideLoading(), t && t();
        });
    },
    getUserInfo: function(t) {
        var e = this;
        (0, u.default)(wx.getUserInfo)().then(function(i) {
            e.getGeoMuseum({
                code: t,
                signature: i.signature,
                encryptedData: i.encryptedData,
                iv: i.iv
            }), e.globalData.isLogin = !0;
        }).catch(function() {
            e.getGeoMuseum();
        });
    },
    getGeoMuseum: function() {
        var t = this, e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, i = arguments.length > 1 ? arguments[1] : void 0, a = arguments.length > 2 ? arguments[2] : void 0;
        this.globalData.isLogin = a, wx.showLoading();
        var u = e, s = this.launchOptions, r = s.path, c = s.query;
        if (c.scene) {
            var h = {};
            decodeURIComponent(c.scene).split("&").forEach(function(t) {
                var e = t.split("="), i = o(e, 2), a = i[0], n = i[1];
                h[a] = n;
            }), this.globalData.scene = h;
        }
        ("pages/guide/guide" === r || "pages/exhibit/detail" === r) && c && c.museumid && (u.museumid = c.museumid), 
        this.globalData.scene && (u.museumid = this.globalData.scene.m);
        var l = m.default.getState(), f = l.common.location, p = f.longitude, x = f.latitude;
        (0, d.default)("/mp/getgeomuseum.html", {
            data: n({
                location: "".concat(p, ",").concat(x),
                os: wx.getSystemInfoSync().platform,
                lastid: wx.getStorageSync("museumid") || 0,
                version: "0.2.0"
            }, u),
            ignoreResult: !0
        }).then(function(e) {
            t.getMuseum(a ? wx.getStorageSync("museumid") : e.museumid), wx.setStorageSync("SESSID", e.sessionid), 
            wx.hideLoading(), t.globalData.scene && (0, d.default)("/externalorder/useorder.html", {
                data: {
                    code: t.globalData.scene.c
                },
                ignoreResult: !0
            }).then(function(t) {
                1 != +t.result && wx.showToast({
                    title: t.msg,
                    icon: "none"
                });
            }).catch(g.fetchCatchToast), i && i();
        }).catch(g.fetchCatchToast);
    },
    getMuseum: function(t, e) {
        wx.showLoading();
        var i = this;
        (0, h.default)({
            url: "/mp/index.html",
            data: {
                museumid: t
            },
            success: function(a) {
                a.statusCode >= 200 && a.statusCode < 300 ? (wx.setStorageSync("museumid", t), i.setState("current", n(n({}, a.data), {}, {
                    actions: {
                        scan: a.data.scanflag || 0,
                        code: a.data.codeflag || 0,
                        exhibit: a.data.exhibitflag || 0,
                        vr: a.data.vrflag || 0,
                        beacon: a.data.btflag || 0
                    }
                })), wx.hideLoading(), i.launchExhibitData && (i.getExhibit(i.launchExhibitData), 
                i.launchExhibitData = null), e && e()) : wx.showToast({
                    title: "获取博物馆信息失败",
                    icon: "none"
                });
            },
            fail: function() {
                wx.showToast({
                    title: "获取博物馆信息失败",
                    icon: "none"
                });
            }
        });
    },
    getExhibit: function(t) {
        var e = this;
        return a(i().mark(function a() {
            var n, o, u, s;
            return i().wrap(function(i) {
                for (;;) switch (i.prev = i.next) {
                  case 0:
                    if (e.isLaunch) {
                        i.next = 3;
                        break;
                    }
                    return e.launchExhibitData = t, i.abrupt("return");

                  case 3:
                    return i.next = 5, e._mpStore.getActions().exhibit.getExhibit(t);

                  case 5:
                    n = e._mpStore.getState().exhibit, o = n.exhibit, u = n.exhibitlang, o.exhibitionid && (s = "".concat(f.imgHost, "/exhibit/").concat(o.exhibitionid, "/audios/").concat(u.audio), 
                    e.audioManager.play({
                        src: s,
                        title: u.name
                    }));

                  case 7:
                  case "end":
                    return i.stop();
                }
            }, a);
        }))();
    },
    initAudioManager: function() {
        this.audioManager = new c.default(), this.audioManager.onTimeUpdate(this.onTimeUpdate), 
        this.audioManager.onStatusChange(this.onStatusChange), this.audioManager.onPrev(this.playPrev), 
        this.audioManager.onNext(this.playNext), this.audioManager.onEnded(this.onEnded);
    },
    onTimeUpdate: function(t) {
        this._mpStore.getActions().exhibit.updateTime(t);
    },
    onStatusChange: function(t) {
        this._mpStore.getActions().exhibit.updatePlayStatus(!t);
    },
    onEnded: function() {
        this._mpStore.getState().exhibit.auto && this.playNext();
    },
    stopAudio: function() {
        this.audioManager.stop();
    },
    playPrev: function() {
        var t = this._mpStore.getState().exhibit.prev;
        t && this.getExhibit({
            id: t
        });
    },
    playNext: function() {
        var t = this._mpStore.getState().exhibit, e = t.id, i = t.next;
        this.getExhibit({
            id: i,
            prev: e
        });
    },
    getPay: function(t) {
        wx.showLoading();
        var e = this;
        (0, h.default)({
            url: "/mp/pay.html",
            data: {
                id: t
            },
            success: function(t) {
                t.statusCode >= 200 && t.statusCode < 300 && 1 == t.data.result ? (e._mpStore.getActions().exhibit.updateState({
                    type: t.data.type,
                    exhibit: t.data.exhibit,
                    exhibition: t.data.exhibition,
                    museum: t.data.museum
                }), wx.hideLoading()) : wx.showToast({
                    title: t.data.text || "接口请求错误",
                    icon: "none"
                });
            },
            fail: function() {
                wx.showToast({
                    title: "网络请求错误",
                    icon: "none"
                });
            }
        });
    },
    toLogin: function() {
        wx.showToast({
            title: "请先登录",
            icon: "none",
            duration: 1e3
        }), setTimeout(function() {
            wx.switchTab({
                url: "/pages/me/me"
            });
        }, 1e3);
    },
    request: h.default,
    fetch: d.default,
    util: l,
    store: m.default,
    setState: function(t, e) {
        m.default.dispatch({
            type: t,
            payload: e
        });
    },
    globalData: {
        siteUrl: "https://shop.wisdomguide.cn",
        isLaunch: !1,
        launchExhibitData: null
    }
}));