Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("@babel/runtime/helpers/objectSpread2.js"), r = require("@babel/runtime/helpers/objectWithoutProperties.js"), t = require("FCB448D4DF57E4CF9AD220D3943782D4.js"), o = [ "url", "header", "fail" ], a = {
    Accept: "application/json",
    "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"
}, c = function(c) {
    var i = c.url, l = c.header, n = void 0 === l ? {} : l, u = c.fail, s = r(c, o), d = e(e({}, a), n), p = wx.getStorageSync("SESSID");
    p && (d.Cookie = "PHPSESSID=".concat(p)), wx.request(e({
        url: "".concat(t.host).concat(i),
        header: d,
        fail: function(e) {
            console.log("request error:", {
                error: e,
                url: "".concat(t.host).concat(i),
                data: s.data || null
            }), u && u(e);
        }
    }, s));
};

exports.default = c;