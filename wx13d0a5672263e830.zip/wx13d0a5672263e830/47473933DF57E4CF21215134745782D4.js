Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var t = require("@babel/runtime/helpers/classCallCheck.js"), e = require("@babel/runtime/helpers/createClass.js"), n = function() {
    function n() {
        t(this, n), this._manager = wx.getBackgroundAudioManager(), this._src = "", this._title = "文博智慧导览", 
        this._manager.title = this._title, this._manager.singer = this._title, this._isStop = !1, 
        this._onStatusChange = function() {}, this._onEnded = function() {}, this._addListeners();
    }
    return e(n, [ {
        key: "_addListeners",
        value: function() {
            var t = this;
            this._manager.onPlay(function() {
                return t._handleStatusChange(!1);
            }), this._manager.onStop(function() {
                return t._handleStatusChange(!0);
            }), this._manager.onPause(function() {
                return t._handleStatusChange(!0);
            }), this._manager.onEnded(function() {
                t._handleStatusChange(!0), t._onEnded();
            }), this._manager.onError(function() {
                return t._handleStatusChange(!0);
            });
        }
    }, {
        key: "_handleStatusChange",
        value: function(t) {
            this._isStop = t, this._onStatusChange(t);
        }
    }, {
        key: "play",
        value: function(t) {
            if (t) return this._src = t.src, this._title = t.title || this._title, this._manager.title = this._title, 
            void (this._manager.src = this._src);
            this._manager.src ? this._manager.play() : (this._manager.title = this._title, this._manager.src = this._src);
        }
    }, {
        key: "pause",
        value: function() {
            this._manager.pause();
        }
    }, {
        key: "stop",
        value: function() {
            this._manager.stop();
        }
    }, {
        key: "toggle",
        value: function() {
            this._isStop ? this.play() : this.pause();
        }
    }, {
        key: "seek",
        value: function(t) {
            this._manager.seek(t);
        }
    }, {
        key: "onPrev",
        value: function(t) {
            this._manager.onPrev(t);
        }
    }, {
        key: "onNext",
        value: function(t) {
            this._manager.onNext(t);
        }
    }, {
        key: "onEnded",
        value: function(t) {
            this._onEnded = t;
        }
    }, {
        key: "onTimeUpdate",
        value: function(t) {
            var e = this;
            this._manager.onTimeUpdate(function() {
                return t({
                    currentTime: e._manager.currentTime,
                    duration: e._manager.duration
                });
            });
        }
    }, {
        key: "onStatusChange",
        value: function(t) {
            this._onStatusChange = t;
        }
    } ]), n;
}();

exports.default = n;