Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var t = require("@babel/runtime/helpers/objectSpread2.js"), e = require("@babel/runtime/helpers/objectWithoutProperties.js"), o = [ "onLoad", "onUnload" ], n = function(n) {
    if ("function" != typeof n) throw new TypeError("mapState must be a function");
    var r = getApp().store;
    return function(i) {
        var s = i.onLoad, u = i.onUnload, a = e(i, o);
        function c() {
            var e = n(r.getState());
            this.setData(t({}, e));
        }
        if (!r) throw new TypeError("store is not exist");
        return Object.assign({}, a, {
            onLoad: function(t) {
                c.call(this, t), this.unsubscribe = r.subscribe(c.bind(this, t)), "function" == typeof s && s.call(this, t);
            },
            onUnload: function() {
                "function" == typeof u && u.call(this), "function" == typeof this.unsubscribe && this.unsubscribe();
            }
        });
    };
};

exports.default = n;