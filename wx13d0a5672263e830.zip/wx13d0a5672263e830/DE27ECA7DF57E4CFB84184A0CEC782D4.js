Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.noop = exports.fetchCatchToast = void 0;

exports.fetchCatchToast = function(o) {
    wx.showToast({
        title: o.message,
        icon: "none"
    });
};

exports.noop = function() {};