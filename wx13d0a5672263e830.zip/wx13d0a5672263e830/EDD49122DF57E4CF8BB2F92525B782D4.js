Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.stringify = exports.parse = void 0;

exports.stringify = function(e) {
    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, o = [];
    Object.keys(e).forEach(function(t) {
        o.push("".concat(t, "=").concat(e[t]));
    });
    var r = o.join("&");
    return t.host && (r = "".concat(t.host, "?").concat(r)), t.redirect && (r += "#wechat_redirect"), 
    t.encode && (r = encodeURIComponent(r)), r;
};

exports.parse = function() {};