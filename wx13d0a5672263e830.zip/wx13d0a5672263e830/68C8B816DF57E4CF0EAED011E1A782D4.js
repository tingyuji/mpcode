Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("@babel/runtime/helpers/objectSpread2.js"), t = require("FCB448D4DF57E4CF9AD220D3943782D4.js"), r = {
    Accept: "application/json",
    "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"
}, a = function(a) {
    var o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, n = e(e({}, r), o.header || {}), c = wx.getStorageSync("SESSID");
    return c && (n.Cookie = "PHPSESSID=".concat(c)), new Promise(function(e, r) {
        wx.request({
            url: "".concat(t.host).concat(a),
            header: n,
            method: o.method || "GET",
            data: o.data || {},
            success: function(t) {
                t.statusCode >= 200 && t.statusCode < 300 ? o.ignoreResult || t.data && 1 == +t.data.result ? e(t.data) : r(new Error(t.data && t.data.text || "未知错误")) : r(new Error("网络请求错误"));
            },
            fail: function(e) {
                r(new Error(e.errMsg || "未知错误"));
            }
        });
    });
};

exports.default = a;