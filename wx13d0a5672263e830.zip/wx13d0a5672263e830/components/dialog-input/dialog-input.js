Component({
    properties: {
        visible: {
            type: Boolean,
            value: !1,
            observer: function(t) {
                t && this.setData({
                    value: ""
                });
            }
        }
    },
    data: {
        value: ""
    },
    methods: {
        onInput: function(t) {
            this.setData({
                value: t.detail.value
            });
        },
        onCancel: function() {
            this.triggerEvent("cancel");
        },
        onConfirm: function() {
            var t = this.data.value;
            t ? this.triggerEvent("confirm", {
                value: t
            }) : wx.showToast({
                title: "请输入展品编码",
                icon: "none"
            });
        }
    }
});