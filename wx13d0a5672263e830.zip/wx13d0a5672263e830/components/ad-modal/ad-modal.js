Component({
    properties: {
        visible: {
            type: Boolean,
            value: !1
        },
        img: {
            type: String,
            value: ""
        }
    },
    methods: {
        onTap: function() {
            this.triggerEvent("open");
        },
        onCancel: function() {
            this.triggerEvent("cancel");
        }
    }
});