Component({
    properties: {
        placeholder: {
            type: String,
            value: "搜索"
        },
        url: {
            type: String,
            value: ""
        },
        value: {
            type: String,
            value: ""
        }
    },
    data: {
        showInput: !1
    },
    methods: {
        showInput: function() {
            var t = this.properties.url;
            t ? wx.navigateTo({
                url: t
            }) : this.setData({
                showInput: !0
            });
        },
        hideInput: function() {
            this.setData({
                showInput: !1
            }), this.triggerEvent("cancel");
        },
        handleInput: function(t) {
            this.triggerEvent("input", {
                value: t.detail.value
            });
        }
    }
});