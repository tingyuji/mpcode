Component({
    properties: {
        star: {
            type: Number,
            value: 0
        }
    }
});