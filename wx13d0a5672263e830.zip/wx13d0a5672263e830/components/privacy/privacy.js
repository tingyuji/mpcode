var e = (0, require("../../@babel/runtime/helpers/interopRequireDefault").default)(require("../../6001E4A1DF57E4CF06678CA6568782D4.js"));

Component({
    data: {
        show: !1,
        privacyContractName: ""
    },
    pageLifetimes: {
        show: function() {
            var t = this, a = wx.getAppBaseInfo().SDKVersion;
            (0, e.default)(a, "2.32.3") >= 0 ? wx.getPrivacySetting({
                success: function(e) {
                    "getPrivacySetting:ok" == e.errMsg && (t.setData({
                        privacyContractName: e.privacyContractName,
                        show: e.needAuthorization
                    }), e.needAuthorization ? wx.hideTabBar() : getApp().launch());
                },
                fail: function() {
                    getApp().launch();
                }
            }) : getApp().launch();
        }
    },
    methods: {
        openPrivacyContract: function() {
            wx.openPrivacyContract();
        },
        handleAgree: function() {
            this.setData({
                show: !1
            }), wx.showTabBar(), getApp().launch();
        },
        handleDisagree: function() {
            wx.showToast({
                title: "必须同意后才可以继续使用",
                icon: "none"
            });
        },
        handleCatchtouchMove: function() {}
    }
});