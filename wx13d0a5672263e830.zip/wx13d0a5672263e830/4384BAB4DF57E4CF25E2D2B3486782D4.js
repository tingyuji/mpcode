var e = require("@babel/runtime/helpers/interopRequireDefault.js").default;

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var t = require("@babel/runtime/helpers/regeneratorRuntime.js"), i = require("@babel/runtime/helpers/objectSpread2.js"), n = require("@babel/runtime/helpers/asyncToGenerator.js"), a = e(require("68C8B816DF57E4CF0EAED011E1A782D4.js")), r = {
    state: {
        from: 0,
        id: "",
        originalid: "",
        auto: !1,
        type: null,
        exhibit: {},
        exhibitlang: {},
        exhibition: {},
        museum: {},
        next: null,
        prev: null,
        currentTime: 0,
        duration: 0,
        isPlay: !1
    },
    actions: {
        getExhibit: function(e) {
            var r = this;
            return n(t().mark(function n() {
                var u, s;
                return t().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return wx.showLoading(), r.setState(i({
                            currentTime: 0,
                            duration: 0,
                            exhibit: {}
                        }, e)), u = {}, e.id ? u.id = e.id : e.originalid && (u.originalid = e.originalid), 
                        e.museumid && (u.museumid = e.museumid), t.prev = 5, t.next = 8, (0, a.default)("/mp/exhibit.html", {
                            data: u,
                            ignoreResult: !0
                        });

                      case 8:
                        s = t.sent, wx.hideLoading(), 1 == s.result ? r.setState({
                            exhibit: s.exhibit,
                            exhibitlang: s.exhibitlang,
                            type: null,
                            exhibit_museum: s.museumlang || {},
                            exhibitionlang: s.exhibitionlang || {},
                            next: s.nextexhibitid || null
                        }) : 201 == s.result ? r.getActions().getPay({
                            id: s.id
                        }) : wx.showToast({
                            title: s.text || "接口请求错误",
                            icon: "none"
                        }), t.next = 16;
                        break;

                      case 13:
                        t.prev = 13, t.t0 = t.catch(5), wx.showToast({
                            title: t.t0.message,
                            icon: "none"
                        });

                      case 16:
                      case "end":
                        return t.stop();
                    }
                }, n, null, [ [ 5, 13 ] ]);
            }))();
        },
        getPay: function(e) {
            var i = this;
            return n(t().mark(function n() {
                var r, u;
                return t().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return r = e.id, wx.showLoading(), t.prev = 2, t.next = 5, (0, a.default)("/mp/pay.html", {
                            data: {
                                id: r
                            }
                        });

                      case 5:
                        u = t.sent, wx.hideLoading(), i.setState({
                            type: u.type,
                            exhibit: u.exhibit,
                            exhibition: u.exhibition,
                            museum: u.museum
                        }), t.next = 13;
                        break;

                      case 10:
                        t.prev = 10, t.t0 = t.catch(2), wx.showToast({
                            title: t.t0.message,
                            icon: "none"
                        });

                      case 13:
                      case "end":
                        return t.stop();
                    }
                }, n, null, [ [ 2, 10 ] ]);
            }))();
        },
        updateTime: function(e) {
            var t = this.getState().duration;
            0 != e.duration || 0 === t ? this.setState(e) : this.setState({
                duration: t,
                currentTime: 0
            });
        },
        updatePlayStatus: function(e) {
            this.setState({
                isPlay: e
            });
        },
        toggleAuto: function() {
            this.setState({
                auto: !this.getState().auto
            });
        },
        updateState: function(e) {
            this.setState(e);
        }
    }
};

exports.default = r;