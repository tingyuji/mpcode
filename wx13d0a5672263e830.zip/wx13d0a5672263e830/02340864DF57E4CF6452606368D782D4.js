var e = require("@babel/runtime/helpers/interopRequireDefault.js").default;

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.scanCode = exports.getScanResult = void 0;

var t = e(require("1BC1EDD3DF57E4CF7DA785D46FB782D4.js"));

exports.scanCode = function(e) {
    wx.scanCode({
        onlyFromCamera: !0,
        scanType: [ "qrCode" ],
        success: function(t) {
            e(t.result);
        }
    });
};

exports.getScanResult = function(e, s) {
    wx.showLoading(), (0, t.default)({
        url: "/mp/scanresult.html",
        data: {
            str: e
        },
        success: function(e) {
            e.statusCode >= 200 && e.statusCode < 300 ? 1 == e.data.result ? s(e.data) : wx.showToast({
                title: e.data.text,
                icon: "none"
            }) : wx.showToast({
                title: "接口请求错误",
                icon: "none"
            });
        },
        fail: function() {
            wx.showToast({
                title: "网络请求错误",
                icon: "none"
            });
        }
    });
};