Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../../../@babel/runtime/helpers/defineProperty"), t = require("../../../@babel/runtime/helpers/objectSpread2"), n = require("./utils.js"), r = function(r) {
    if (!(0, n.isPlainObject)(r)) throw new TypeError("`models` must be plain object");
    var i = {}, o = {}, u = [];
    function c(e) {
        return e ? i[e] || {} : i;
    }
    function a(e) {
        return e ? o[e] || {} : o;
    }
    function f(e, n) {
        i[e] = t(t({}, c(e)), n), u.forEach(function(e) {
            return e();
        });
    }
    return Object.keys(r).forEach(function(t) {
        i[t] = r[t].state || {}, o[t] = function(t, r) {
            if (!(0, n.isPlainObject)(t)) return {};
            var i = {}, o = function(t, n) {
                var i = "".concat(t, "Loading");
                f(r, e({}, i, n));
            }, u = {
                setState: function(e) {
                    f(r, e);
                },
                getState: function() {
                    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : r;
                    return c(e);
                },
                getActions: function() {
                    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : r;
                    return a(e);
                }
            };
            return Object.keys(t).forEach(function(e) {
                i[e] = function() {
                    for (var n = arguments.length, r = new Array(n), i = 0; i < n; i++) r[i] = arguments[i];
                    var c = t[e].apply(u, r);
                    return c && "function" == typeof c.then ? new Promise(function(t, n) {
                        o(e, !0), c.then(function(n) {
                            o(e, !1), t(n);
                        }).catch(function(t) {
                            o(e, !1), n(t);
                        });
                    }) : c;
                };
            }), i;
        }(r[t].actions, t);
    }), {
        getState: c,
        getActions: a,
        subscribe: function(e) {
            return u.push(e), function() {
                var t = u.indexOf(e);
                u.splice(t, 1);
            };
        }
    };
};

exports.default = r;