Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../../../@babel/runtime/helpers/objectSpread2"), t = require("../../../@babel/runtime/helpers/objectWithoutProperties"), r = [ "onLoad", "onUnload" ], n = function() {
    return {};
}, o = function(o) {
    var u = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : n;
    return function(n) {
        var i = getApp(), s = n.onLoad, a = n.onUnload, c = t(n, r);
        return e(e({
            onLoad: function(t) {
                var r = this, n = function() {
                    return r.setData(e({}, o(i._mpStore.getState())));
                };
                n(), this._unsubscribe = i._mpStore.subscribe(function() {
                    return n();
                }), s && s.call(this, t);
            },
            onUnload: function() {
                this._unsubscribe(), a && a.call(this);
            }
        }, c), u(i._mpStore.getActions()));
    };
};

exports.default = o;