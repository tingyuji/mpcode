Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.isPlainObject = void 0;

var e = require("../../../@babel/runtime/helpers/typeof");

exports.isPlainObject = function(r) {
    return "object" === e(r) && !Array.isArray(r) && null !== r;
};