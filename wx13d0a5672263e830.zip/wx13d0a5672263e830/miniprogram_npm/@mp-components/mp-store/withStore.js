Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../../../@babel/runtime/helpers/objectSpread2"), r = function(r) {
    return function(t) {
        return e(e({}, t), {}, {
            _mpStore: r
        });
    };
};

exports.default = r;