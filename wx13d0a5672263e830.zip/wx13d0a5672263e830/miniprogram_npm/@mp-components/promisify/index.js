Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = require("../../../@babel/runtime/helpers/objectSpread2"), t = function(t) {
    if ("function" == typeof t) return function() {
        var r = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return new Promise(function(n, o) {
            t(e(e({}, r), {}, {
                success: n,
                fail: o
            }));
        });
    };
};

exports.default = t;