var e, s;

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.TaskState = exports.RecogniseType = void 0, exports.TaskState = e, function(e) {
    e.UNPROCESSED = "unprocessed", e.PROCESSING = "processing", e.PROCESSED = "processed", 
    e.FAILED = "processFailed", e.PENDING = "pending", e.NULL = "";
}(e || (exports.TaskState = e = {})), exports.RecogniseType = s, function(e) {
    e.First = "first", e.Append = "append", e.Ajust = "ajust", e.AutoRecognize = "autoRecognize";
}(s || (exports.RecogniseType = s = {}));