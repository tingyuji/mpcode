var e;

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.AppearTaskStage = void 0, exports.AppearTaskStage = e, function(e) {
    e.FrontViewRecognize = "frontViewRecognize", e.MultiViewRecognize = "multiViewRecognize", 
    e.ModelDeploy = "modelDeploy", e.DigitalModelChoose = "digitalModelChoose";
}(e || (exports.AppearTaskStage = e = {}));