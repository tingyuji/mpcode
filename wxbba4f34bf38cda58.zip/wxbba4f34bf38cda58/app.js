var e, t = (e = require("@babel/runtime/regenerator")) && e.__esModule ? e : {
    default: e
}, n = require("@babel/runtime/helpers/asyncToGenerator"), r = function(e) {
    if (e && e.__esModule) return e;
    if (null === e || "object" != typeof e && "function" != typeof e) return {
        default: e
    };
    var t = c();
    if (t && t.has(e)) return t.get(e);
    var n = {}, r = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for (var a in e) if (Object.prototype.hasOwnProperty.call(e, a)) {
        var o = r ? Object.getOwnPropertyDescriptor(e, a) : null;
        o && (o.get || o.set) ? Object.defineProperty(n, a, o) : n[a] = e[a];
    }
    n.default = e, t && t.set(e, n);
    return n;
}(require("@ali/aes-tracker-miniapp")), a = require("./utils/mt"), o = require("./utils/tracker"), u = require("./utils/wechat"), i = require("./service/api");

function c() {
    if ("function" != typeof WeakMap) return null;
    var e = new WeakMap();
    return c = function() {
        return e;
    }, e;
}

App((0, r.hookApp)({
    aes: r.default,
    globalData: {
        userInfo: void 0,
        mtConfig: void 0,
        taskId: void 0
    },
    onLaunch: function() {
        var e = this;
        return n(t.default.mark(function n() {
            return t.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return e.autoUpdate(), (0, o.initUniTrack)(), wx.getSystemInfo({
                        success: function(t) {
                            e.globalData.platform = t.platform;
                        }
                    }), t.next = 5, e.getMtConfig();

                  case 5:
                    wx.getStorageSync("TOKEN");

                  case 7:
                  case "end":
                    return t.stop();
                }
            }, n);
        }))();
    },
    getMtConfig: function() {
        var e = this;
        return n(t.default.mark(function n() {
            var r;
            return t.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (!e.globalData.mtConfig) {
                        t.next = 2;
                        break;
                    }
                    return t.abrupt("return", e.globalData.mtConfig);

                  case 2:
                    return t.next = 4, (0, a.getMtConfig)();

                  case 4:
                    return r = t.sent, e.globalData.mtConfig = r, t.abrupt("return", r);

                  case 7:
                  case "end":
                    return t.stop();
                }
            }, n);
        }))();
    },
    getFreshMtConfig: function() {
        var e = this;
        return n(t.default.mark(function n() {
            var r;
            return t.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.next = 2, (0, a.getMtConfig)();

                  case 2:
                    return r = t.sent, e.globalData.mtConfig = r, t.abrupt("return", r);

                  case 5:
                  case "end":
                    return t.stop();
                }
            }, n);
        }))();
    },
    getFreshUserInfo: function() {
        var e = this;
        return n(t.default.mark(function n() {
            var r;
            return t.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.next = 2, (0, i.getUserInfo)().catch(function() {
                        return null;
                    });

                  case 2:
                    return r = t.sent, e.globalData.userInfo = r, t.abrupt("return", r);

                  case 5:
                  case "end":
                    return t.stop();
                }
            }, n);
        }))();
    },
    autoUpdate: function() {
        var e = this;
        if (wx.canIUse("getUpdateManager")) {
            var t = wx.getUpdateManager();
            t.onCheckForUpdate(function(n) {
                n.hasUpdate && wx.showModal({
                    title: "更新提示",
                    content: "检测到新版本，是否下载新版本并重启小程序？",
                    success: function(n) {
                        n.confirm ? e.downLoadAndUpdate(t) : n.cancel && wx.showModal({
                            title: "温馨提示~",
                            content: "本次版本更新涉及到新的功能添加，旧版本无法正常访问的哦~",
                            showCancel: !1,
                            confirmText: "确定更新",
                            success: function(n) {
                                n.confirm && e.downLoadAndUpdate(t);
                            }
                        });
                    }
                });
            });
        } else wx.showModal({
            title: "提示",
            content: "当前微信版本过低，无法使用该功能，请升级到最新微信版本后重试。"
        });
    },
    downLoadAndUpdate: function(e) {
        wx.showLoading({
            title: "下载新版本中"
        }), e.onUpdateReady(function() {
            wx.hideLoading(), e.applyUpdate();
        }), e.onUpdateFailed(function() {
            wx.hideLoading(), wx.showModal({
                title: "已经有新版本了哟~",
                content: "新版本已经上线啦~，请您删除当前小程序，重新搜索打开哟~"
            });
        });
    },
    goToIndexPage: function() {
        wx.navigateTo({
            url: "/pages/index/index"
        });
    },
    goToLoginPage: function() {
        "pages/index/index" !== (0, u.getCurrentPage)().route && wx.reLaunch({
            url: "/pages/index/index"
        });
    },
    recordClick: function(e, t) {
        (0, o.recordClick)(e, t);
    }
}));