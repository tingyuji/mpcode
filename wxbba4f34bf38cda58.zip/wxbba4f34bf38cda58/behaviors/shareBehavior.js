Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e, t = (e = require("../@babel/runtime/regenerator")) && e.__esModule ? e : {
    default: e
}, r = require("../@babel/runtime/helpers/asyncToGenerator");

var a = Behavior({
    data: {},
    methods: {
        onShareAppMessage: function() {
            return r(t.default.mark(function e() {
                var r, a, n, o, u, i;
                return t.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return e.next = 2, getApp().getMtConfig();

                      case 2:
                        if (e.t0 = e.sent, e.t0) {
                            e.next = 5;
                            break;
                        }
                        e.t0 = {};

                      case 5:
                        return n = e.t0, o = n.shareLinkTitle, u = n.shareLinkCover, i = null === (r = getApp().globalData.userInfo) || void 0 === r ? void 0 : r.userId, 
                        e.abrupt("return", {
                            title: o,
                            path: "/pages/index/index?".concat(i ? "inviter_uid=".concat(null === (a = getApp().globalData.userInfo) || void 0 === a ? void 0 : a.userId) : ""),
                            imageUrl: u
                        });

                      case 10:
                      case "end":
                        return e.stop();
                    }
                }, e);
            }))();
        }
    }
});

exports.default = a;