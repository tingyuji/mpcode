Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e, t = (e = require("../@babel/runtime/regenerator")) && e.__esModule ? e : {
    default: e
}, r = require("../@babel/runtime/helpers/asyncToGenerator"), n = require("../constants/index"), a = require("../service/api");

var o = Behavior({
    data: {
        hasLogined: !1,
        userInfo: null
    },
    attached: function() {
        this.forceLoginIfUnlogined();
    },
    methods: {
        checkHasLogined: function() {
            var e = !!wx.getStorageSync(n.TOKEN_KEY);
            return this.setData({
                hasLogined: e
            }), e;
        },
        checkTokenValidAndSetUserInfo: function() {
            return r(t.default.mark(function e() {
                var r;
                return t.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return e.next = 2, (0, a.getUserInfo)({
                            showErrorIfFail: !1
                        }).catch(function() {
                            return null;
                        });

                      case 2:
                        return r = e.sent, getApp().globalData.userInfo = r, e.abrupt("return", !!r);

                      case 5:
                      case "end":
                        return e.stop();
                    }
                }, e);
            }))();
        },
        checkLoginValid: function() {
            var e = this;
            return r(t.default.mark(function r() {
                return t.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        if (t.t0 = e.checkHasLogined(), !t.t0) {
                            t.next = 5;
                            break;
                        }
                        return t.next = 4, e.checkTokenValidAndSetUserInfo();

                      case 4:
                        t.t0 = t.sent;

                      case 5:
                        return t.abrupt("return", t.t0);

                      case 6:
                      case "end":
                        return t.stop();
                    }
                }, r);
            }))();
        },
        forceLoginIfUnlogined: function() {
            var e = this;
            return r(t.default.mark(function r() {
                return t.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return t.next = 2, e.checkLoginValid();

                      case 2:
                        if (t.sent) {
                            t.next = 4;
                            break;
                        }
                        getApp().goToLoginPage();

                      case 4:
                      case "end":
                        return t.stop();
                    }
                }, r);
            }))();
        }
    }
});

exports.default = o;