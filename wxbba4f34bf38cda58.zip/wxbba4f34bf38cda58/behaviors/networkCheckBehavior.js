Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e, t = (e = require("../@babel/runtime/regenerator")) && e.__esModule ? e : {
    default: e
}, r = require("../@babel/runtime/helpers/asyncToGenerator");

var n = Behavior({
    data: {
        hasNetwork: !0
    },
    created: function() {},
    attached: function() {},
    ready: function() {
        var e = this;
        return r(t.default.mark(function r() {
            var n;
            return t.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.next = 2, new Promise(function(e) {
                        wx.getNetworkType({
                            success: function(t) {
                                console.log("network: ", t), e("none" !== t.networkType);
                            },
                            fail: function() {
                                e(!1);
                            }
                        });
                    });

                  case 2:
                    n = t.sent, e.setData({
                        hasNetwork: n
                    });

                  case 4:
                  case "end":
                    return t.stop();
                }
            }, r);
        }))();
    },
    detached: function() {},
    methods: {}
});

exports.default = n;