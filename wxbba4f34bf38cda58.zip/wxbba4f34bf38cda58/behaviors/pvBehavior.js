Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = t(require("@ali/aes-tracker-miniapp")), a = t(require("@ali/aes-tracker-plugin-pv/index-miniapp"));

function t(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

var r = Behavior({
    data: {},
    created: function() {
        (0, a.default)(e.default).sendPV();
    },
    detached: function() {
        (0, a.default)(e.default).sendLeave();
    },
    methods: {}
});

exports.default = r;