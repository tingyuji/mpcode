Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.VERSION_TOO_LOW = exports.TOKEN_KEY = exports.MULTI_TEMP_FILE_PATH_KEY = exports.INVITE_CODE_ERROR_MAP = exports.BIZ_L_UN_LOGIN = exports.BIZ_L_TOKEN_EXPIRED = exports.BIZ_C_ILLEGAL_USER = exports.API_ERROR_MAP = void 0;

exports.API_ERROR_MAP = {
    ABORT: "网络已断开",
    PARSE_JSON_ERROR: "服务正在升级中，请稍后再试",
    FAIL_SYS_HSF_NOTFOUND: "服务正在升级中，请稍后再试"
};

exports.INVITE_CODE_ERROR_MAP = {
    BIZ_C_INVALID_CDKEY: "邀请码不存在",
    BIZ_C_ACTIVITY_PERIODS: "邀请码已过期",
    BIZ_C_HAS_BEEN_USED: "邀请码已被使用"
};

exports.TOKEN_KEY = "TOKEN";

exports.MULTI_TEMP_FILE_PATH_KEY = "MULTI_TEMP_FILE_PATH_KEY";

exports.BIZ_L_TOKEN_EXPIRED = "BIZ_L_TOKEN_EXPIRED";

exports.BIZ_L_UN_LOGIN = "BIZ_L_UN_LOGIN";

exports.BIZ_C_ILLEGAL_USER = "BIZ_C_ILLEGAL_USER";

exports.VERSION_TOO_LOW = "VERSION_TOO_LOW";