var e, t, r, o = require("../../@babel/runtime/helpers/typeof");

module.exports = (e = {}, r = function(t, r) {
    if (!e[t]) return require(r);
    if (!e[t].status) {
        var n = e[t].m;
        n._exports = n._tempexports;
        var u = Object.getOwnPropertyDescriptor(n, "exports");
        u && u.configurable && Object.defineProperty(n, "exports", {
            set: function(e) {
                "object" === o(e) && e !== n._exports && (n._exports.__proto__ = e.__proto__, Object.keys(e).forEach(function(t) {
                    n._exports[t] = e[t];
                })), n._tempexports = e;
            },
            get: function() {
                return n._tempexports;
            }
        }), e[t].status = 1, e[t].func(e[t].req, n, n.exports);
    }
    return e[t].m.exports;
}, (t = function(t, r, o) {
    e[t] = {
        status: 0,
        func: r,
        req: o,
        m: {
            exports: {},
            _tempexports: {}
        }
    };
})(1690338143771, function(e, t, r) {
    t.exports = e("./lib");
}, function(e) {
    return r({
        "./lib": 1690338143772
    }[e], e);
}), t(1690338143772, function(e, t, r) {
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var o = e("./parseLocation");
    Object.defineProperty(r, "default", {
        enumerable: !0,
        get: function() {
            return u(o).default;
        }
    });
    var n = e("./Location");
    function u(e) {
        return e && e.__esModule ? e : {
            default: e
        };
    }
    Object.defineProperty(r, "Location", {
        enumerable: !0,
        get: function() {
            return u(n).default;
        }
    });
}, function(e) {
    return r({
        "./parseLocation": 1690338143773,
        "./Location": 1690338143774
    }[e], e);
}), t(1690338143773, function(e, t, r) {
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), r.default = function(e) {
        return e instanceof u.default ? e : new u.default(e);
    };
    var o, n = e("./Location"), u = (o = n) && o.__esModule ? o : {
        default: o
    };
}, function(e) {
    return r({
        "./Location": 1690338143774
    }[e], e);
}), t(1690338143774, function(e, t, r) {
    Object.defineProperty(r, "__esModule", {
        value: !0
    });
    var o = function(e, t) {
        if (Array.isArray(e)) return e;
        if (Symbol.iterator in Object(e)) return function(e, t) {
            var r = [], o = !0, n = !1, u = void 0;
            try {
                for (var i, a = e[Symbol.iterator](); !(o = (i = a.next()).done) && (r.push(i.value), 
                !t || r.length !== t); o = !0) ;
            } catch (e) {
                n = !0, u = e;
            } finally {
                try {
                    !o && a.return && a.return();
                } finally {
                    if (n) throw u;
                }
            }
            return r;
        }(e, t);
        throw new TypeError("Invalid attempt to destructure non-iterable instance");
    };
    r.default = function(e) {
        var t = void 0, r = void 0, n = void 0, u = void 0, f = void 0, c = void 0, s = void 0;
        if ("string" == typeof e) {
            var l = e.match(a).slice(1), p = o(l, 6);
            s = p[0], c = p[1], t = p[2], f = p[3], u = p[4], r = p[5];
        } else {
            var d = e || {};
            s = d.protocol, c = d.hostname, s = d.protocol, f = d.pathname, u = d.search, n = d.query, 
            r = d.hash, t = d.port;
        }
        t = t || "", r = r || "", s = s || "", c = c || "", f = f || "/", u = u || (n && Object.keys(n).length ? i.default.stringify(n, !0) : ""), 
        n = n || (u ? i.default.parse(u) : {}), Object.assign(this, {
            host: t ? c + ":" + t : c,
            port: t,
            hash: r,
            search: u,
            hostname: c,
            pathname: f,
            protocol: s,
            query: n,
            href: [ s ? s + "//" : null, c, t ? ":" + t : null, f, u, r ].filter(function(e) {
                return e;
            }).join("")
        });
    };
    var n, u = e("querystringify"), i = (n = u) && n.__esModule ? n : {
        default: n
    }, a = /^(?:(https?:)\/\/)?([^:/]*)(?::([^/]*))?([^?#]*)(\?[^#]+)?(#.+)?/;
}, function(e) {
    return r({}[e], e);
}), r(1690338143771));