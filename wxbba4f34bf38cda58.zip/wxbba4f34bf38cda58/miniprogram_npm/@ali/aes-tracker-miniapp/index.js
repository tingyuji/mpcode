var n = require("../../../@babel/runtime/helpers/typeof");

module.exports = function(t) {
    var r = {};
    function e(n) {
        if (r[n]) return r[n].exports;
        var o = r[n] = {
            i: n,
            l: !1,
            exports: {}
        };
        return t[n].call(o.exports, o, o.exports, e), o.l = !0, o.exports;
    }
    return e.m = t, e.c = r, e.d = function(n, t, r) {
        e.o(n, t) || Object.defineProperty(n, t, {
            enumerable: !0,
            get: r
        });
    }, e.r = function(n) {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(n, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(n, "__esModule", {
            value: !0
        });
    }, e.t = function(t, r) {
        if (1 & r && (t = e(t)), 8 & r) return t;
        if (4 & r && "object" == n(t) && t && t.__esModule) return t;
        var o = Object.create(null);
        if (e.r(o), Object.defineProperty(o, "default", {
            enumerable: !0,
            value: t
        }), 2 & r && "string" != typeof t) for (var u in t) e.d(o, u, function(n) {
            return t[n];
        }.bind(null, u));
        return o;
    }, e.n = function(n) {
        var t = n && n.__esModule ? function() {
            return n.default;
        } : function() {
            return n;
        };
        return e.d(t, "a", t), t;
    }, e.o = function(n, t) {
        return Object.prototype.hasOwnProperty.call(n, t);
    }, e.p = "", e(e.s = 15);
}([ function(n, t) {
    n.exports = require("@ali/aes-tracker/index-miniapp");
}, function(n, t) {
    var r = n.exports = {
        version: "2.6.12"
    };
    "number" == typeof __e && (__e = r);
}, function(n, t, r) {
    n.exports = !r(5)(function() {
        return 7 != Object.defineProperty({}, "a", {
            get: function() {
                return 7;
            }
        }).a;
    });
}, function(n, t) {
    var r = n.exports = "undefined" != typeof window && window.Math == Math ? window : "undefined" != typeof self && self.Math == Math ? self : Function("return this")();
    "number" == typeof __g && (__g = r);
}, function(t, r) {
    t.exports = function(t) {
        return "object" == n(t) ? null !== t : "function" == typeof t;
    };
}, function(n, t) {
    n.exports = function(n) {
        try {
            return !!n();
        } catch (n) {
            return !0;
        }
    };
}, function(n, t, r) {
    n.exports = r(27);
}, function(n, t, r) {
    var e = r(3), o = r(1), u = r(18), i = r(20), c = r(8), f = function n(t, r, f) {
        var a, p, l, s = t & n.F, y = t & n.G, v = t & n.S, h = t & n.P, d = t & n.B, g = t & n.W, x = y ? o : o[r] || (o[r] = {}), b = x.prototype, m = y ? e : v ? e[r] : (e[r] || {}).prototype;
        for (a in y && (f = r), f) (p = !s && m && void 0 !== m[a]) && c(x, a) || (l = p ? m[a] : f[a], 
        x[a] = y && "function" != typeof m[a] ? f[a] : d && p ? u(l, e) : g && m[a] == l ? function(n) {
            var t = function(t, r, e) {
                if (this instanceof n) {
                    switch (arguments.length) {
                      case 0:
                        return new n();

                      case 1:
                        return new n(t);

                      case 2:
                        return new n(t, r);
                    }
                    return new n(t, r, e);
                }
                return n.apply(this, arguments);
            };
            return t.prototype = n.prototype, t;
        }(l) : h && "function" == typeof l ? u(Function.call, l) : l, h && ((x.virtual || (x.virtual = {}))[a] = l, 
        t & n.R && b && !b[a] && i(b, a, l)));
    };
    f.F = 1, f.G = 2, f.S = 4, f.P = 8, f.B = 16, f.W = 32, f.U = 64, f.R = 128, n.exports = f;
}, function(n, t) {
    var r = {}.hasOwnProperty;
    n.exports = function(n, t) {
        return r.call(n, t);
    };
}, function(n, t, r) {
    var e = r(10), o = r(11);
    n.exports = function(n) {
        return e(o(n));
    };
}, function(n, t, r) {
    var e = r(32);
    n.exports = Object("z").propertyIsEnumerable(0) ? Object : function(n) {
        return "String" == e(n) ? n.split("") : Object(n);
    };
}, function(n, t) {
    n.exports = function(n) {
        if (null == n) throw TypeError("Can't call method on  " + n);
        return n;
    };
}, function(n, t) {
    var r = Math.ceil, e = Math.floor;
    n.exports = function(n) {
        return isNaN(n = +n) ? 0 : (n > 0 ? e : r)(n);
    };
}, function(n, t, r) {
    n.exports = r(16);
}, function(n, t) {
    n.exports = require("@ali/aes-tracker-plugin-jserror/index-miniapp");
}, function(n, t, r) {
    r.r(t), r.d(t, "switchPage", function() {
        return y;
    }), r.d(t, "sendPV", function() {
        return v;
    });
    var e = r(13), o = r.n(e), u = r(6), i = r.n(u), c = r(0), f = r.n(c), a = r(14), p = {
        $sendPVTimmer$: null
    }, l = function() {
        clearTimeout(p.$sendPVTimmer$), p.$sendPVTimmer$ = setTimeout(function() {
            f.a.log("pv", {});
        }, 50);
    }, s = function() {
        p.appBegin = o()();
    };
    function y(n) {
        try {
            n && f.a.setConfig(n), l();
        } catch (n) {}
    }
    f.a.hookPage = function(n) {
        var t = {
            onReady: function() {
                var t = 1 === arguments.length ? [ arguments[0] ] : Array.apply(null, arguments), r = this, e = n.onReady;
                try {
                    var o = f.a.getConfig("plugin_pv") || {}, u = o.autoPV, i = void 0 === u || u;
                    i && l();
                } catch (n) {
                    console.warn("[aem] error in hookPage:pageReady", n);
                }
                if ("function" == typeof e) return e.apply(r, t);
            },
            onHide: function() {
                var t = 1 === arguments.length ? [ arguments[0] ] : Array.apply(null, arguments), r = this, e = n.onHide;
                if ("function" == typeof e) return e.apply(r, t);
            },
            onUnload: function() {
                var t = 1 === arguments.length ? [ arguments[0] ] : Array.apply(null, arguments), r = this, e = n.onUnload;
                if ("function" == typeof e) return e.apply(r, t);
            }
        };
        return i()({}, n, t);
    }, f.a.hookApp = function(n) {
        var t = {
            onLaunch: function() {
                var t = 1 === arguments.length ? [ arguments[0] ] : Array.apply(null, arguments), r = this, e = n.onLaunch;
                try {
                    s();
                } catch (n) {
                    console.warn("[aem] error in hookApp:onLaunch", n);
                }
                if ("function" == typeof e) return e.apply(r, t);
            },
            onError: function(t) {
                var r = 1 === arguments.length ? [ arguments[0] ] : Array.apply(null, arguments), e = this, o = n.onError;
                try {
                    Object(a.sendError)(t);
                } catch (t) {
                    console.warn("[aem] error in hookApp:onError", t);
                }
                if ("function" == typeof o) return o.apply(e, r);
            }
        };
        return i()({}, n, t);
    }, t.default = f.a;
    var v = l;
}, function(n, t, r) {
    r(17), n.exports = r(1).Date.now;
}, function(n, t, r) {
    var e = r(7);
    e(e.S, "Date", {
        now: function() {
            return new Date().getTime();
        }
    });
}, function(n, t, r) {
    var e = r(19);
    n.exports = function(n, t, r) {
        if (e(n), void 0 === t) return n;
        switch (r) {
          case 1:
            return function(r) {
                return n.call(t, r);
            };

          case 2:
            return function(r, e) {
                return n.call(t, r, e);
            };

          case 3:
            return function(r, e, o) {
                return n.call(t, r, e, o);
            };
        }
        return function() {
            return n.apply(t, arguments);
        };
    };
}, function(n, t) {
    n.exports = function(n) {
        if ("function" != typeof n) throw TypeError(n + " is not a function!");
        return n;
    };
}, function(n, t, r) {
    var e = r(21), o = r(26);
    n.exports = r(2) ? function(n, t, r) {
        return e.f(n, t, o(1, r));
    } : function(n, t, r) {
        return n[t] = r, n;
    };
}, function(n, t, r) {
    var e = r(22), o = r(23), u = r(25), i = Object.defineProperty;
    t.f = r(2) ? Object.defineProperty : function(n, t, r) {
        if (e(n), t = u(t, !0), e(r), o) try {
            return i(n, t, r);
        } catch (n) {}
        if ("get" in r || "set" in r) throw TypeError("Accessors not supported!");
        return "value" in r && (n[t] = r.value), n;
    };
}, function(n, t, r) {
    var e = r(4);
    n.exports = function(n) {
        if (!e(n)) throw TypeError(n + " is not an object!");
        return n;
    };
}, function(n, t, r) {
    n.exports = !r(2) && !r(5)(function() {
        return 7 != Object.defineProperty(r(24)("div"), "a", {
            get: function() {
                return 7;
            }
        }).a;
    });
}, function(n, t, r) {
    var e = r(4), o = r(3).document, u = e(o) && e(o.createElement);
    n.exports = function(n) {
        return u ? o.createElement(n) : {};
    };
}, function(n, t, r) {
    var e = r(4);
    n.exports = function(n, t) {
        if (!e(n)) return n;
        var r, o;
        if (t && "function" == typeof (r = n.toString) && !e(o = r.call(n))) return o;
        if ("function" == typeof (r = n.valueOf) && !e(o = r.call(n))) return o;
        if (!t && "function" == typeof (r = n.toString) && !e(o = r.call(n))) return o;
        throw TypeError("Can't convert object to primitive value");
    };
}, function(n, t) {
    n.exports = function(n, t) {
        return {
            enumerable: !(1 & n),
            configurable: !(2 & n),
            writable: !(4 & n),
            value: t
        };
    };
}, function(n, t, r) {
    r(28), n.exports = r(1).Object.assign;
}, function(n, t, r) {
    var e = r(7);
    e(e.S + e.F, "Object", {
        assign: r(29)
    });
}, function(n, t, r) {
    var e = r(2), o = r(30), u = r(41), i = r(42), c = r(43), f = r(10), a = Object.assign;
    n.exports = !a || r(5)(function() {
        var n = {}, t = {}, r = Symbol(), e = "abcdefghijklmnopqrst";
        return n[r] = 7, e.split("").forEach(function(n) {
            t[n] = n;
        }), 7 != a({}, n)[r] || Object.keys(a({}, t)).join("") != e;
    }) ? function(n, t) {
        for (var r = c(n), a = arguments.length, p = 1, l = u.f, s = i.f; a > p; ) for (var y, v = f(arguments[p++]), h = l ? o(v).concat(l(v)) : o(v), d = h.length, g = 0; d > g; ) y = h[g++], 
        e && !s.call(v, y) || (r[y] = v[y]);
        return r;
    } : a;
}, function(n, t, r) {
    var e = r(31), o = r(40);
    n.exports = Object.keys || function(n) {
        return e(n, o);
    };
}, function(n, t, r) {
    var e = r(8), o = r(9), u = r(33)(!1), i = r(36)("IE_PROTO");
    n.exports = function(n, t) {
        var r, c = o(n), f = 0, a = [];
        for (r in c) r != i && e(c, r) && a.push(r);
        for (;t.length > f; ) e(c, r = t[f++]) && (~u(a, r) || a.push(r));
        return a;
    };
}, function(n, t) {
    var r = {}.toString;
    n.exports = function(n) {
        return r.call(n).slice(8, -1);
    };
}, function(n, t, r) {
    var e = r(9), o = r(34), u = r(35);
    n.exports = function(n) {
        return function(t, r, i) {
            var c, f = e(t), a = o(f.length), p = u(i, a);
            if (n && r != r) {
                for (;a > p; ) if ((c = f[p++]) != c) return !0;
            } else for (;a > p; p++) if ((n || p in f) && f[p] === r) return n || p || 0;
            return !n && -1;
        };
    };
}, function(n, t, r) {
    var e = r(12), o = Math.min;
    n.exports = function(n) {
        return n > 0 ? o(e(n), 9007199254740991) : 0;
    };
}, function(n, t, r) {
    var e = r(12), o = Math.max, u = Math.min;
    n.exports = function(n, t) {
        return (n = e(n)) < 0 ? o(n + t, 0) : u(n, t);
    };
}, function(n, t, r) {
    var e = r(37)("keys"), o = r(39);
    n.exports = function(n) {
        return e[n] || (e[n] = o(n));
    };
}, function(n, t, r) {
    var e = r(1), o = r(3), u = o["__core-js_shared__"] || (o["__core-js_shared__"] = {});
    (n.exports = function(n, t) {
        return u[n] || (u[n] = void 0 !== t ? t : {});
    })("versions", []).push({
        version: e.version,
        mode: r(38) ? "pure" : "global",
        copyright: "© 2020 Denis Pushkarev (zloirock.ru)"
    });
}, function(n, t) {
    n.exports = !0;
}, function(n, t) {
    var r = 0, e = Math.random();
    n.exports = function(n) {
        return "Symbol(".concat(void 0 === n ? "" : n, ")_", (++r + e).toString(36));
    };
}, function(n, t) {
    n.exports = "constructor,hasOwnProperty,isPrototypeOf,propertyIsEnumerable,toLocaleString,toString,valueOf".split(",");
}, function(n, t) {
    t.f = Object.getOwnPropertySymbols;
}, function(n, t) {
    t.f = {}.propertyIsEnumerable;
}, function(n, t, r) {
    var e = r(11);
    n.exports = function(n) {
        return Object(e(n));
    };
} ]).default;