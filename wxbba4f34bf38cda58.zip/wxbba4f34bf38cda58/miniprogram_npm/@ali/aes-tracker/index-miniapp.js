var e = require("../../../@babel/runtime/helpers/typeof");

module.exports = function(n) {
    var t = {};
    function r(e) {
        if (t[e]) return t[e].exports;
        var o = t[e] = {
            i: e,
            l: !1,
            exports: {}
        };
        return n[e].call(o.exports, o, o.exports, r), o.l = !0, o.exports;
    }
    return r.m = n, r.c = t, r.d = function(e, n, t) {
        r.o(e, n) || Object.defineProperty(e, n, {
            enumerable: !0,
            get: t
        });
    }, r.r = function(e) {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(e, "__esModule", {
            value: !0
        });
    }, r.t = function(n, t) {
        if (1 & t && (n = r(n)), 8 & t) return n;
        if (4 & t && "object" == e(n) && n && n.__esModule) return n;
        var o = Object.create(null);
        if (r.r(o), Object.defineProperty(o, "default", {
            enumerable: !0,
            value: n
        }), 2 & t && "string" != typeof n) for (var i in n) r.d(o, i, function(e) {
            return n[e];
        }.bind(null, i));
        return o;
    }, r.n = function(e) {
        var n = e && e.__esModule ? function() {
            return e.default;
        } : function() {
            return e;
        };
        return r.d(n, "a", n), n;
    }, r.o = function(e, n) {
        return Object.prototype.hasOwnProperty.call(e, n);
    }, r.p = "", r(r.s = 4);
}([ function(e, n) {
    e.exports = require("@ali/aplus_universal");
}, function(e, n, t) {
    e.exports = t(2);
}, function(e, n, t) {
    var r = t(3), o = r.JSON || (r.JSON = {
        stringify: JSON.stringify
    });
    e.exports = function(e) {
        return o.stringify.apply(o, arguments);
    };
}, function(e, n) {
    var t = e.exports = {
        version: "2.6.12"
    };
    "number" == typeof __e && (__e = t);
}, function(e, n, t) {
    t.r(n);
    var r = t(1), o = t.n(r), i = "undefined" != typeof my && !!my && "function" == typeof my.showToast, a = "undefined" != typeof wx && !!wx && (void 0 !== wx.login || void 0 !== wx.miniProgram);
    function u(e, n) {
        "function" == typeof requestIdleCallback ? requestIdleCallback(e, {
            timeout: n || 1e3
        }) : setTimeout(e, 0);
    }
    var c = function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, n = (e.networkType || "").toUpperCase() || "UNKNOWN", t = !0;
        switch (n) {
          case "WI-FI":
            n = "WIFI";

          case "WIFI":
          case "5G":
          case "4G":
          case "3G":
          case "2G":
          case "WWAN":
            t = !0;
            break;

          case "NOTREACHABLE":
          case "NONE":
            n = "NONE", t = !1;
            break;

          case "UNKNOWN":
          default:
            n = "UNKNOWN", t = !0;
        }
        return {
            networkType: n,
            networkAvailable: "boolean" == typeof e.isConnected ? e.isConnected : t
        };
    };
    function f(e) {
        return "undefined" != typeof Promise && e instanceof Promise;
    }
    var s = {}, l = function() {
        if (!i || !a) return !1;
        try {
            var e = "";
            try {
                e = navigator ? navigator.userAgent || navigator.swuserAgent : "";
            } catch (e) {}
            if (!e) try {
                e = clientInformation ? clientInformation.appVersion : "";
            } catch (e) {}
            var n = !1;
            try {
                n = !!dd;
            } catch (e) {}
            return n || /AliApp\(AP/.test(e) || /AliApp\(DingTalk/.test(e) || /micromessenger/.test(e);
        } catch (e) {
            return !1;
        }
    }() ? 5e3 : 35e3, p = [], y = [], d = function e() {
        var n = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 20, t = arguments.length > 1 ? arguments[1] : void 0;
        return t = t || "", n ? e(--n, "0123456789ABCDEFGHIJKLMNOPQRSTUVWXTZabcdefghiklmnopqrstuvwxyz".charAt(Math.floor(60 * Math.random())) + t) : t;
    }, g = {
        sdk_version: "1.0.34",
        pv_id: d()
    };
    function v() {
        if (p.length) {
            var e = p.join("|");
            if (l = g.maxUrlLength || l, e.length < l) return p = [], void s.send(m(e));
            for (var n = ""; p.length; ) {
                var t = p[0];
                if (n && (n + "|" + t).length > l) break;
                p.shift(), n += n ? "|" + t : t;
            }
            s.send(m(n)), p.length && v();
        }
    }
    function h(e, n) {
        !1 === n ? u(function() {
            s.send(m(e));
        }) : (p.push(e), u(v));
    }
    function m(e) {
        var n = [ "msg=" + e ];
        for (var t in g) -1 === t.indexOf("plugin_") && "requiredFields" !== t && "maxUrlLength" !== t && g.hasOwnProperty(t) && (g[t] || 0 === g[t]) && n.push(t + "=" + encodeURIComponent(g[t]));
        return n.join("&");
    }
    function b() {
        return (g.requiredFields || []).concat([ "pid" ]).some(function(e) {
            return void 0 === g[e];
        });
    }
    s.setConfig = function(e, n) {
        var t = function() {
            if (void 0 !== n) g[e] = n; else for (var t in e) g[t] = e[t];
        };
        y.length ? (t(), b() || (y.forEach(function(e) {
            h.apply(null, e);
        }), y = [])) : (function() {
            if (void 0 !== n) return n !== g[e];
            for (var t in e) if (e[t] !== g[t]) return !0;
            return !1;
        }() && v(), t());
    }, s.getConfig = function(e) {
        return e ? g[e] : g;
    }, s.updatePVID = function() {
        s.setConfig("pv_id", d());
    }, s.log = function(e) {
        var n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, t = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
        if (e) {
            n.ts = n.ts || new Date().getTime(), n.type = e;
            var r = [];
            for (var i in n) {
                var a = n[i], u = Object.prototype.toString.call(a);
                "[object String]" !== u && "[object Number]" !== u && "[object Boolean]" !== u && "[object Object]" !== u && "[object Array]" !== u || ("[object Object]" !== u && "[object Array]" !== u || (a = o()(a)), 
                r.push("".concat(i, "=").concat(encodeURIComponent(a))));
            }
            n = encodeURIComponent(r.join("&")), b() ? y.push([ n, t.combo ]) : h(n, t.combo);
        }
    }, s.before = function(e, n) {
        return function() {
            var t = arguments, r = n.apply(s, t);
            f(r) ? r.then(function(n) {
                e.apply(s, n || t);
            }) : e.apply(s, r || t);
        };
    }, s.after = function(e, n) {
        return function() {
            var t = arguments;
            e.apply(s, t), n.apply(s, t);
        };
    };
    var w, N, _, O, k = s, x = t(0), C = !0, j = [], P = function() {
        C && j.length && (j.forEach(function(e) {
            u(function() {
                k.send(e);
            });
        }), j = []);
    };
    k.setConfig(function() {
        var e = {};
        if ("undefined" != typeof my && my && "function" == typeof my.getSystemInfoSync) {
            var n = my.getSystemInfoSync(), t = n.pixelRatio, r = n.windowWidth, o = n.windowHeight;
            e.dpi = t, e.sr = "".concat(r, "x").concat(o);
        }
        return e;
    }()), N = (w = {
        success: function(e) {
            k.setConfig({
                net_type: e.networkType
            }), C = e.networkAvailable, P();
        },
        fail: function(e) {
            console.warn("[aes] getNetworkType fail", e);
        }
    }).success, _ = w.fail, (O = i ? my.getNetworkType : a ? wx.getNetworkType : null) && O({
        success: function(e) {
            e && "string" == typeof e.networkType && N && N(c(e));
        },
        fail: function(e) {
            _ && _(e);
        }
    }), function(e) {
        var n = e.success, t = i ? my.onNetworkStatusChange : a ? wx.onNetworkStatusChange : null;
        t && t(function(e) {
            e && "string" == typeof e.networkType && n && n(c(e));
        });
    }({
        success: function(e) {
            k.setConfig({
                net_type: e.networkType
            }), C = e.networkAvailable, P();
        }
    }), k.log = k.before(k.log, function() {
        var e = {};
        try {
            var n = x.aplus_universal.getPageSPM(), t = n[0], r = n[1];
            "0" !== t && (e.spm_a = t), "0" !== r && (e.spm_b = r);
        } catch (e) {}
        e.url = function() {
            if ("function" == typeof getCurrentPages) try {
                var e = getCurrentPages() || [], n = e[e.length - 1];
                return n && n.route;
            } catch (e) {
                console.warn("[aes] getCurrentPage fail", e);
            }
        }(), k.setConfig(e);
    }), k.send = function(e) {
        var n = x.aplus_universal && "function" == typeof x.aplus_universal.record;
        if (C && n) try {
            var t = [ "/aes.1.1", "EXP", e, "POST" ];
            x.aplus_universal.record.apply(x.aplus_universal, t);
        } catch (e) {
            console.warn("[aes] send fail", e);
        } else j.length > 500 && j.shift(), j.push(e);
    }, n.default = k;
} ]).default;