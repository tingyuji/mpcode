var e = require("../../../../@babel/runtime/helpers/typeof");

module.exports = function(e) {
    function t(r) {
        if (a[r]) return a[r].exports;
        var n = a[r] = {
            exports: {},
            id: r,
            loaded: !1
        };
        return e[r].call(n.exports, n, n.exports, t), n.loaded = !0, n.exports;
    }
    var a = {};
    return t.m = e, t.c = a, t.p = "", t(0);
}([ function(e, t, a) {
    e.exports = a(1);
}, function(e, t, a) {
    t.aplus_universal = a(2), t.AplusWeb = a(6), t.AplusWeex = a(9), t.AplusWindmill = a(12), 
    t.AplusWindmillAlipay = a(13), t.AplusWindmillAppx = a(16);
}, function(t, a, r) {
    (function(a) {
        var n, o, i, s, p = r(3), u = r(4), c = u.isWeex, l = u.isWeb, m = u.isNode;
        try {
            n = my;
        } catch (e) {}
        try {
            o = wx;
        } catch (e) {}
        try {
            i = tt;
        } catch (e) {}
        try {
            s = swan;
        } catch (e) {}
        var g = n || o || i || s, f = !1;
        "object" == e(g) && (f = !(!g.request && !g.httpRequest || !g.getSystemInfo));
        var d, h, v = {
            AplusWeb: r(6),
            AplusWeex: r(9),
            AplusWindmill: r(12),
            AplusWindmillAlipay: r(13),
            Common: r(7)
        };
        if (c) d = "AplusWeex"; else if (f) d = p.isTB() ? "AplusWindmill" : "AplusWindmillAlipay"; else if (l) d = "AplusWeb"; else if (m) {
            d = "Common";
            try {
                a.window || (a.window = {});
            } catch (e) {}
        }
        try {
            var y = v[d = d || "Common"];
            h = p.createGoldlogInstance(y), p.isTB && (h.mpInstance = p.createGoldlogInstance(v.AplusWindmillAlipay));
        } catch (e) {
            console && console.log(e), h = {};
        }
        t.exports = h;
    }).call(a, function() {
        return this;
    }());
}, function(t, a) {
    function r(e) {
        for (var t = [], a = 0; a < e.length; a++) {
            var r = e[a][0], n = e[a][1];
            t.push(r + "=" + encodeURIComponent(n));
        }
        return t.join("&");
    }
    function n() {
        var e = function() {}, t = {
            getSystemInfo: e,
            setStorageSync: e,
            getStorage: e
        }, a = t;
        try {
            a = dd;
        } catch (e) {
            try {
                a = my;
            } catch (e) {
                try {
                    a = wx;
                } catch (e) {
                    try {
                        a = tt;
                    } catch (e) {
                        try {
                            a = swan;
                        } catch (e) {
                            a = t;
                        }
                    }
                }
            }
        }
        return a;
    }
    a.getAplusUniversalVersion = function() {
        return "4.3.3";
    }, a.paramsToObj = function(e) {
        for (var t = {}, a = (e = "string" == typeof e ? e : "").split("&"), r = 0; r < a.length; r++) {
            var n = a[r], o = n.split("="), i = o[0], s = "";
            if (2 === o.length) s = o[1]; else if (o.length > 2) {
                var p = n.indexOf("=");
                s = n.slice(p + 1);
            }
            i && (t[i] = s);
        }
        return t;
    }, a.objToParams = function(e, t) {
        var a = [];
        for (var r in e) {
            var n = t ? encodeURIComponent(e[r]) : e[r];
            a.push(r + "=" + n);
        }
        return a.join("&");
    }, a.getParamFromURL = function(e, t) {
        var a = "";
        (t || (t = "spm"), e) && (e.split("?")[1] || "").split("&").forEach(function(e) {
            0 === e.indexOf(t + "=") && (a = e.substr(t.length + 1));
        });
        return a;
    }, a.simplifyURL = function(e) {
        e || (e = "");
        var t = "_wx_tpl=";
        return e.indexOf(t) > -1 && (e = e.substring(e.indexOf(t) + t.length, e.indexOf(".js") + ".js".length)), 
        e.split("?")[0];
    }, a.getLocation = function() {
        var e;
        try {
            e = location || {};
        } catch (t) {
            e = {};
        }
        return e;
    }, a.getPVLogUrl = function(e) {
        var t = "";
        return t = /^\/\/\w+/.test(e) ? "https:" + e : "https://" + e, /\w+\.gif$/.test(e) || (t += "/vx.gif"), 
        t;
    }, a.getEtagUrl = function(e) {
        return (/^\/\/\w+/.test(e) ? "https:" + e : "https://" + e) + "/eg.js";
    }, a.getGoldlogUrl = function(e) {
        return /^\/\/\w+/.test(e) ? "https:" + e : "https://" + e;
    }, a.makeCacheNum = function() {
        return Math.floor(268435456 * Math.random()).toString(16);
    }, a.makeUrl = function(e) {
        return [ e.preParams ? r(e.preParams) : "", "&aplus&", e.endParams ? r(e.endParams) : "" ].join("");
    }, a.hostValidity = function(e) {
        return /^(\/\/){0,1}(\w+\.){1,}\w+((\/\w+){1,})?$/.test(e);
    }, a.vhostValidity = function(e) {
        return /^(\/\/){0,1}(\w+\.){1,}\w+\/\w+\.gif$/.test(e);
    }, a.getContext = n, a.isTriver = function() {
        try {
            var e = navigator ? navigator.userAgent || navigator.swuserAgent : "";
            return /Triver/g.test(e);
        } catch (e) {
            return !1;
        }
    }, a.isTB = function() {
        var e = !1;
        try {
            var t = navigator ? navigator.userAgent || navigator.swuserAgent : "";
            if (e = !!/AliApp/i.test(t), /AliApp\((AP|DingTalk|AMAP|UC|QUARK)/i.test(t) && (e = !1), 
            /AliApp\(KB/i.test(t) && (e = !!/Mist/.test(t)), e) {
                var a = n();
                "function" == typeof a.canIUse && (e = !!a.canIUse("callUserTrack"));
            }
        } catch (e) {}
        return e;
    };
    var o = {
        CLK: {
            name: "click",
            alias: "CLK",
            id: "2101"
        },
        EXP: {
            name: "expose",
            alias: "EXP",
            id: "2201"
        },
        IMPEXP: {
            name: "expose",
            alias: "IMPEXP",
            id: "2202"
        },
        OTHER: {
            name: "other",
            alias: "OTHER",
            id: "19999"
        }
    };
    a.getGmObj = function(e) {
        var t = o[e] || o.OTHER;
        if ("19999" === t.id) try {
            var a = parseInt(e);
            if (a + "" != "NaN" && a > 3e3 && a < 19999) {
                var r = e + "";
                t = {
                    name: r,
                    alias: r,
                    id: r
                };
            }
        } catch (e) {}
        return t;
    }, a.createGoldlogInstance = function(t, a) {
        var r = "object" == e(a) ? a : {};
        return t.default ? t.default.create(r) : t.create(r);
    };
}, function(t, a, r) {
    (function(r) {
        function n(t) {
            return (n = "function" == typeof Symbol && "symbol" == e(Symbol.iterator) ? function(t) {
                return e(t);
            } : function(t) {
                return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : e(t);
            })(t);
        }
        Object.defineProperty(a, "__esModule", {
            value: !0
        }), a.default = a.isReactNative = a.isWeex = a.isNode = a.isWeb = void 0;
        var o = "object" === ("undefined" == typeof navigator ? "undefined" : n(navigator)) && ("Mozilla" === navigator.appCodeName || "Gecko" === navigator.product);
        a.isWeb = o;
        var i = void 0 !== r && !(!r.versions || !r.versions.node);
        a.isNode = i;
        var s = "function" == typeof callNative || "object" === ("undefined" == typeof WXEnvironment ? "undefined" : n(WXEnvironment)) && "Web" !== WXEnvironment.platform;
        a.isWeex = s;
        var p = "undefined" != typeof __fbBatchedBridgeConfig;
        a.isReactNative = p, a.default = t.exports;
        var u = t.exports;
        a.default = u;
    }).call(a, r(5));
}, function(e) {
    function t() {
        throw new Error("setTimeout has not been defined");
    }
    function a() {
        throw new Error("clearTimeout has not been defined");
    }
    function r(e) {
        if (p === setTimeout) return setTimeout(e, 0);
        if ((p === t || !p) && setTimeout) return p = setTimeout, setTimeout(e, 0);
        try {
            return p(e, 0);
        } catch (t) {
            try {
                return p.call(null, e, 0);
            } catch (t) {
                return p.call(this, e, 0);
            }
        }
    }
    function n() {
        g && l && (g = !1, l.length ? m = l.concat(m) : f = -1, m.length && o());
    }
    function o() {
        if (!g) {
            var e = r(n);
            g = !0;
            for (var t = m.length; t; ) {
                for (l = m, m = []; ++f < t; ) l && l[f].run();
                f = -1, t = m.length;
            }
            l = null, g = !1, function(e) {
                if (u === clearTimeout) return clearTimeout(e);
                if ((u === a || !u) && clearTimeout) return u = clearTimeout, clearTimeout(e);
                try {
                    u(e);
                } catch (t) {
                    try {
                        return u.call(null, e);
                    } catch (t) {
                        return u.call(this, e);
                    }
                }
            }(e);
        }
    }
    function i(e, t) {
        this.fun = e, this.array = t;
    }
    function s() {}
    var p, u, c = e.exports = {};
    !function() {
        try {
            p = "function" == typeof setTimeout ? setTimeout : t;
        } catch (e) {
            p = t;
        }
        try {
            u = "function" == typeof clearTimeout ? clearTimeout : a;
        } catch (e) {
            u = a;
        }
    }();
    var l, m = [], g = !1, f = -1;
    c.nextTick = function(e) {
        var t = new Array(arguments.length - 1);
        if (arguments.length > 1) for (var a = 1; a < arguments.length; a++) t[a - 1] = arguments[a];
        m.push(new i(e, t)), 1 !== m.length || g || r(o);
    }, i.prototype.run = function() {
        this.fun.apply(null, this.array);
    }, c.title = "browser", c.browser = !0, c.env = {}, c.argv = [], c.version = "", 
    c.versions = {}, c.on = s, c.addListener = s, c.once = s, c.off = s, c.removeListener = s, 
    c.removeAllListeners = s, c.emit = s, c.prependListener = s, c.prependOnceListener = s, 
    c.listeners = function() {
        return [];
    }, c.binding = function() {
        throw new Error("process.binding is not supported");
    }, c.cwd = function() {
        return "/";
    }, c.chdir = function() {
        throw new Error("process.chdir is not supported");
    }, c.umask = function() {
        return 0;
    };
}, function(t, a, r) {
    var n = r(3).objToParams, o = r(7).extend({
        setPageSPM: function(e, t, a) {
            this.spmAB = [ e, t ], (window.goldlog_queue || (window.goldlog_queue = [])).push({
                action: "goldlog.setPageSPM",
                arguments: [ e, t ]
            }), "function" == typeof a && a();
        },
        getPageSPM: function() {
            return this.spmAB;
        },
        getPageSPMStr: function() {
            return this.spmAB.join(".");
        },
        record: function(e, t, a, r) {
            return a = "string" == typeof a ? a : n(a, !0), a = this.getUserInjectGokey({
                logkey: e,
                gmkey: t,
                gokey: a
            }), (window.goldlog_queue || (window.goldlog_queue = [])).push({
                action: "goldlog.record",
                arguments: [ e, t, a, r || "POST" ]
            }), !0;
        },
        enter: function(e, t) {
            e || (e = {}), t || (t = {});
            var a = {
                is_auto: !1,
                page_id: ""
            };
            return t.page_id && (a.page_id = t.page_id, delete t.page_id), (window.goldlog_queue || (window.goldlog_queue = [])).push({
                action: "goldlog.sendPV",
                arguments: [ a, t ]
            }), !0;
        },
        setMetaInfo: function(e, t, a) {
            (window.goldlog_queue || (window.goldlog_queue = [])).push({
                action: "goldlog.setMetaInfo",
                arguments: [ e, t, a ]
            });
        },
        getMetaInfo: function(e, t) {
            (window.goldlog_queue || (window.goldlog_queue = [])).push({
                action: "goldlog.aplus_pubsub.subscribe",
                arguments: [ "aplusReady", function(a) {
                    var r = window.goldlog;
                    "complete" === a && r && "function" == typeof r.getMetaInfo && "function" == typeof t && t(r.getMetaInfo(e));
                } ]
            });
        },
        updateSessionProperties: function(t) {
            "object" == e(t) && (window.goldlog_queue || (window.goldlog_queue = [])).push({
                action: "goldlog.setMetaInfo",
                arguments: [ "_session_args", t ]
            });
        }
    });
    t.exports = o;
}, function(t, a, r) {
    function n(e) {
        return "function" == typeof e;
    }
    function o(e) {
        if (!n(e)) throw new TypeError(e + " is not a function");
        return e;
    }
    var i = r(3), s = r(8), p = function() {}, u = function(e) {
        for (var t = e.length, a = new Array(t - 1), r = 1; r < t; r++) a[r - 1] = e[r];
        return a;
    }, c = s.extend({
        spmAB: [ "0", "0" ],
        spmUrl: "",
        spmPre: "",
        pageName: "",
        isPageDisAppear: !0,
        isPageAppear: !1,
        _meta_info: {},
        record: p,
        setPageSPM: p,
        getPageSPM: p,
        enter: p,
        setHandlers: function(e) {
            this.handlers = e;
        },
        subscribe: function(e, t) {
            o(t);
            var a = this, r = (a.pubs || {})[e] || [];
            if (r) for (var n = 0; n < r.length; n++) {
                var i = r[n]();
                t.apply(a, i);
            }
            var s = a.handlers || [];
            return e in s || (s[e] = []), s[e].push(t), a.setHandlers(s), a;
        },
        subscribeOnce: function(e, t) {
            o(t);
            var a, r = this;
            return this.subscribe.call(this, e, a = function() {
                r.unsubscribe.call(r, e, a);
                var n = Array.prototype.slice.call(arguments);
                t.apply(r, n);
            }), this;
        },
        unsubscribe: function(t, a) {
            o(a);
            var r = this.handlers[t];
            if (!r) return this;
            if ("object" == e(r) && r.length > 0) {
                for (var n = 0; n < r.length; n++) {
                    a.toString() === r[n].toString() && r.splice(n, 1);
                }
                this.handlers[t] = r;
            } else delete this.handlers[t];
            return this;
        },
        publish: function(e) {
            var t = u(arguments), a = this.handlers || [], r = a[e] ? a[e].length : 0;
            if (r > 0) for (var o = 0; o < r; o++) {
                var i = a[e][o];
                n(i) && i.apply(this, t);
            }
            return this;
        },
        cachePubs: function(e) {
            var t = this.pubs || {}, a = u(arguments);
            t[e] || (t[e] = []), t[e].push(function() {
                return a;
            });
        },
        updatePageProperties: function(t) {
            "object" == e(t) && this.setMetaInfo("aplus-cpvdata", t);
        },
        updateNextPageProperties: p,
        updatePageUtparam: p,
        updateNextPageUtparam: p,
        skipPage: p,
        pageAppear: p,
        pageDisappear: p,
        setExposureView: p,
        updateSessionProperties: p,
        getPageSpmUrl: p,
        getPageSpmPre: p,
        getUserInjectGokey: function(e) {
            var t = this.getMetaInfo("aplus-inject-record-gokey");
            return "function" == typeof t ? t(e) : e.gokey;
        },
        setMetaInfo: function(t, a) {
            switch (t) {
              case "aplus-rhost-v":
              case "aplus-rhost-g":
                var r = i.hostValidity(a);
                r || "aplus-rhost-v" !== t || (r = i.vhostValidity(a)), r ? this._meta_info[t] = a : this.catchException("sorry, metaValue of " + a + " is not legality!");
                break;

              case "aplus-exdata":
              case "aplus-cpvdata":
              case "aplus-request-extinfo":
                "object" == e(a) ? this._meta_info[t] = a : this.catchException("sorry, type of " + a + "  must be object!");
                break;

              case "aplus-channel":
                this._meta_info[t] = a;
                break;

              case "aplus-inject-record-gokey":
                "function" == typeof a ? this._meta_info[t] = a : this.catchException("sorry, type of " + a + "  must be function!");
                break;

              default:
                this.catchException("sorry, aplus do not support the metaKey of " + t);
            }
        },
        appendMetaInfo: function(t, a) {
            switch (t) {
              case "aplus-exdata":
              case "aplus-cpvdata":
                if ("object" == e(a)) {
                    var r = this._meta_info[t];
                    this._meta_info[t] = Object.assign(r, a);
                } else this.catchException("sorry, type of " + a + "  must be object!");
                break;

              default:
                this.setMetaInfo(t, a);
            }
        },
        getMetaInfo: function(e, t) {
            var a = this._meta_info[e];
            return "function" != typeof t ? a : void t(a);
        },
        catchException: function(e) {
            try {
                console && console.error(e);
            } catch (e) {}
        }
    });
    t.exports = c;
}, function(e) {
    function t() {}
    t.prototype.extend = function() {}, t.prototype.create = function() {}, t.extend = function(e) {
        return this.prototype.extend.call(this, e);
    }, t.prototype.create = function(e) {
        var t = new this();
        for (var a in e) t[a] = e[a];
        return t;
    }, t.prototype.extend = function(e) {
        var t = function() {};
        try {
            for (var a in "function" != typeof Object.create && (Object.create = function(e) {
                function t() {}
                return t.prototype = e, new t();
            }), t.prototype = Object.create(this.prototype), e) t.prototype[a] = e[a];
            t.prototype.constructor = t, t.extend = t.prototype.extend, t.create = t.prototype.create;
        } catch (e) {
            t = function() {};
        }
        return t;
    }, e.exports = t;
}, function(t, a, r) {
    var n = r(4).isWeex, o = r(10), i = r(11).requireModule, s = o.extend({
        getUT: function() {
            try {
                var e = this.UserTrack || {};
                "function" != typeof e.enterEvent && "function" != typeof e.commit && (e = i("userTrack") || r(!function() {
                    var e = new Error('Cannot find module "@weex-module/userTrack"');
                    throw e.code = "MODULE_NOT_FOUND", e;
                }())), this.UserTrack = e || {};
            } catch (e) {
                this.UserTrack = {};
            }
            return this.UserTrack;
        },
        create: function(t) {
            var a = new this();
            for (var r in t) a[r] = t[r];
            return a.isThirdGroupAPI = function() {
                var t = "undefined" != typeof __weex_options__ && __weex_options__.weex, a = !1;
                if (n && "object" == e(t) && "windmill" === t.config.container) try {
                    "function" == typeof i("keyboard").hideKeyboard && (a = !0);
                } catch (t) {}
                return a;
            }(), a.getUT(), a;
        },
        record: function(e, t, a) {
            a = this.getUserInjectGokey({
                logkey: e,
                gmkey: t,
                gokey: a
            });
            var r = this._getRecordParams(e, t, a), n = r.gmObj || {}, o = this.getUT();
            return this.isThirdGroupAPI ? (r.args.isThirdGroupAPI = "1", o.commitut && o.commitut({
                type: n.name,
                eventId: n.id,
                eventid: n.id,
                name: r.pageName,
                pageName: r.pageName,
                arg1: r.arg1,
                arg2: r.arg2,
                arg3: r.arg3,
                param: r.args,
                params: r.args
            })) : o.customAdvance ? o.customAdvance(r.pageName, n.id, r.arg1, r.arg2, r.arg3, r.args) : o.commitut && o.commitut(n.name, n.id, r.pageName, "", r.arg1, r.arg2, r.arg3, r.args), 
            !0;
        },
        enter: function(e, t) {
            var a = this.getUT();
            e || (e = {}), t || (t = {});
            var r = this._getEnterParams(e, t), n = r.args || {};
            return this.isThirdGroupAPI && a.commitut ? (n.isThirdGroupAPI = "1", a.commitut({
                type: "enter",
                eventId: "-1",
                eventid: "-1",
                name: r.pageName,
                pageName: r.pageName,
                comName: n.url,
                arg1: "",
                arg2: "",
                arg3: "",
                param: n,
                params: n
            })) : a.enterEvent ? a.enterEvent(r.pageName, n) : a.commit && a.commit("enter", r.pageName, n.url, n), 
            !0;
        },
        updateNextPageProperties: function(t) {
            var a = this.getUT();
            "object" == e(t) && a.commitut && (this.isThirdGroupAPI ? a.commitut({
                type: "updateNextProp",
                eventId: -1,
                eventid: -1,
                name: "",
                pageName: "",
                comName: "",
                arg1: "",
                arg2: "",
                arg3: "",
                param: t,
                params: t
            }) : a.commitut("updateNextProp", -1, "", "", "", "", "", t));
        },
        updatePageUtparam: function(t) {
            var a = this.getUT();
            "object" == e(t) && a.updatePageUtparam && (this.isThirdGroupAPI ? a.updatePageUtparam({
                utParamJson: JSON.stringify(t)
            }) : a.updatePageUtparam(JSON.stringify(t)));
        },
        updateNextPageUtparam: function(t) {
            var a = this.getUT();
            "object" == e(t) && a.updateNextPageUtparam && (this.isThirdGroupAPI ? a.updateNextPageUtparam({
                utParamJson: JSON.stringify(t)
            }) : a.updateNextPageUtparam(JSON.stringify(t)));
        },
        skipPage: function() {
            var e = this.getUT();
            e.skipPage && e.skipPage();
        },
        pageAppear: function() {
            var e = this.getUT();
            e.pageAppear && this.isPageDisAppear && (this.isPageDisAppear = !1, this.isPageAppear = !0, 
            e.pageAppear());
        },
        pageDisappear: function() {
            var e = this.getUT();
            e.pageDisAppear && this.isPageAppear && (this.isPageDisAppear = !0, this.isPageAppear = !1, 
            e.pageDisAppear());
        },
        setExposureView: function(e, t, a) {
            var r = this.getUT(), n = !1;
            return r && r.setExposureView && (r.setExposureView(e, t, a), n = !0), n;
        }
    });
    t.exports = s;
}, function(t, a, r) {
    var n = r(11).requireModule, o = r(7), i = r(3), s = i.paramsToObj, p = i.objToParams, u = i.getParamFromURL, c = i.simplifyURL, l = i.getAplusUniversalVersion, m = i.getLocation, g = o.extend({
        create: function(e) {
            var t = new this();
            for (var a in e) t[a] = e[a];
            try {
                t.UserTrack = n("userTrack");
            } catch (e) {
                t.UserTrack = {};
            }
            return t._meta_info || (t._meta_info = {}), t;
        },
        setPageSPM: function(e, t, a) {
            if (e && t) {
                var r = [];
                r.push(e), r.push(t), this.spmAB = r, this.pageName = "";
            }
            "function" == typeof a && a();
        },
        getPageSPM: function() {
            return this.spmAB;
        },
        _updateNextPageSpm: function(e) {
            e && (this.spmPre = this.spmUrl, this.spmUrl = e["spm-url"] || e.spmUrl);
        },
        getPageSPMStr: function(t, a) {
            var r = this.spmAB.join(".");
            if (!r || "0.0" === r) try {
                if (console && console.warn) {
                    var n = "object" == e(a) ? JSON.stringify(a) : "";
                    console.warn("please setPageSPM before " + t + " about " + n);
                }
            } catch (t) {}
            return r;
        },
        _getRecordParams: function(t, a, r) {
            r || (r = "");
            var n = this.getMetaInfo("aplus-exdata");
            if (n) if ("string" == typeof r) {
                var o = [];
                for (var u in n) o.push(u + "=" + n[u]);
                if (o.length > 0) r += (r ? "&" : "") + o.join("&");
            } else "object" == e(r) && (r = Object.assign({}, n, r));
            var g = m(), f = "string" == typeof r ? s(r) : r, d = f.url || g.currentpagename || g.href || "", h = i.getGmObj(a);
            this.pageName || (this.pageName = f.pageName || g.currentpagename || c(d) || "");
            var v = {
                jsver: "aplus_universal",
                lver: l(),
                weex: "1",
                functype: "ctrl",
                funcId: h.id,
                _toUT: "2",
                logkey: t,
                gokey: "string" == typeof r ? encodeURIComponent(r) : encodeURIComponent(p(r, !0)),
                gmkey: h.alias,
                urlpagename: this.pageName,
                url: d
            };
            this.spmUrl && (v["spm-url"] = this.spmUrl), this.spmPre && (v["spm-pre"] = this.spmPre);
            var y = this.getPageSPMStr("record", v);
            return y && "0.0" !== y && (v["spm-cnt"] = y + ".0.0"), {
                pageName: this.pageName,
                gmObj: h,
                arg1: t,
                arg2: "",
                arg3: "",
                args: v
            };
        },
        _getEnterParams: function(e, t) {
            e || (e = {}), t || (t = {});
            var a = this.getMetaInfo("aplus-cpvdata");
            a && (t = Object.assign({}, a, t));
            var r = {
                width: "0",
                height: "0"
            };
            try {
                r = screen;
            } catch (e) {}
            try {
                __windmill_environment__ && (r.width = __windmill_environment__.screenWidth, r.height = __windmill_environment__.screenHeight);
            } catch (e) {}
            var n = m();
            t.url = e.pageUrl || n.currentpagename || n.href || "";
            var o = (t = Object.assign(t, {
                functype: "page",
                funcId: "2001",
                isonepage: e.isonepage ? 1 : -1,
                scr: r.width + "x" + r.height,
                jsver: "aplus_universal",
                lver: l(),
                weex: "1",
                _toUT: "2"
            })).scm || u(t.url, "scm") || "";
            o && (t.scm = o);
            var i = e.pageId ? "/" + e.pageId : "", s = this.getPageSPMStr("enter", t);
            return s && "0.0" !== s && (t["spm-cnt"] = s + "" + i + ".0.0"), this.spmUrl = e.spmUrl || e["spm-url"] || u(t.url, "spm") || this.spmUrl || "", 
            this.spmUrl && (t["spm-url"] = this.spmUrl), this.spmPre = e.spmPre || e["spm-pre"] || u(e.referrer, "spm") || this.spmPre || "", 
            this.spmPre && (t["spm-pre"] = this.spmPre), this.pageName = e.pageName || n.currentpagename || c(t.url) || "", 
            {
                pageName: this.pageName,
                args: t
            };
        }
    });
    t.exports = g;
}, function(e, t) {
    function a(e) {
        return e && void 0 !== e;
    }
    t.requireModule = function(e) {
        var t;
        try {
            a(__weex_require__) && (t = __weex_require__(e));
        } catch (e) {
            t = null;
        }
        if (!t) try {
            a(weex) && "function" == typeof weex.requireModule && (t = weex.requireModule(e));
        } catch (e) {
            t = null;
        }
        if (!t) try {
            t = !function() {
                var e = new Error('Cannot find module "@weex-module"');
                throw e.code = "MODULE_NOT_FOUND", e;
            }();
        } catch (e) {
            t = null;
        }
        return t;
    };
}, function(t, a, r) {
    var n = r(3), o = r(10), i = function(e, t) {
        my && my.call && "function" == typeof t && my.call("handleLoggingAction", {
            type: "behavior",
            subType: e.subType
        }, function(a) {
            t({
                spmUrl: a[e.spmType]
            });
        });
    }, s = o.extend({
        create: function(e) {
            var t = new this();
            for (var a in e) t[a] = e[a];
            return t;
        },
        record: function(e, t, a) {
            a = this.getUserInjectGokey({
                logkey: e,
                gmkey: t,
                gokey: a
            });
            var r = this._getRecordParams(e, t, a);
            delete r.args.weex, r.args.windmill = "1";
            var n = r.gmObj || {};
            if (my) {
                var o = {
                    type: n.name,
                    eventId: n.id,
                    comName: r.arg1,
                    arg1: r.arg1,
                    arg2: r.arg2,
                    arg3: r.arg3,
                    param: r.args
                };
                r.pageName && (o.name = r.pageName, o.pageName = r.pageName), my.callUserTrack ? (console.log(454444444444444, "UT上报"), 
                my.callUserTrack("customAdvance", o)) : my.reportAnalytics && my.reportAnalytics("customAdvance", o);
            }
        },
        enter: function(e, t) {
            e || (e = {}), t || (t = {});
            var a = this._getEnterParams(e, t);
            if (delete a.args.weex, a.args.windmill = "1", my) {
                var r = {
                    type: "enter",
                    eventId: "2001",
                    eventid: "-1",
                    pageName: a.pageName,
                    name: a.pageName,
                    comName: a.args.url,
                    arg1: a.arg1,
                    arg2: a.arg2,
                    arg3: a.arg3,
                    param: a.args
                };
                my.callUserTrack ? my.callUserTrack("commitut", r) : my.reportAnalytics && my.reportAnalytics("enter", r);
            }
        },
        updatePageProperties: function(t) {
            "object" == e(t) && (n.isTriver() && my.reportAnalytics("updatePageProperties", t), 
            this.setMetaInfo("aplus-cpvdata", t));
        },
        updateNextPageProperties: function(e) {
            if (e || (e = {}), this._updateNextPageSpm(e), my) {
                var t = {
                    type: "updateNextProp",
                    eventId: -1,
                    eventid: -1,
                    name: "",
                    pageName: "",
                    comName: "",
                    arg1: "",
                    arg2: "",
                    arg3: "",
                    param: e,
                    params: e
                };
                my.callUserTrack ? my.callUserTrack("commitut", t) : my.reportAnalytics && my.reportAnalytics("enter", t);
            }
        },
        updatePageUtparam: function(e) {
            e || (e = {}), my && my.callUserTrack && my.callUserTrack("updatePageUtparam", {
                utParamJson: JSON.stringify(e)
            });
        },
        updateNextPageUtparam: function(e) {
            e || (e = {}), my && my.callUserTrack && my.callUserTrack("updateNextPageUtparam", {
                utParamJson: JSON.stringify(e)
            });
        },
        skipPage: function() {
            my && my.callUserTrack && my.callUserTrack("skipPage");
        },
        pageAppear: function() {
            my && my.callUserTrack && this.isPageDisAppear && (this.isPageDisAppear = !1, this.isPageAppear = !0, 
            my.callUserTrack("pageAppear"));
        },
        pageDisappear: function() {
            my && my.callUserTrack && this.isPageAppear && (this.isPageDisAppear = !0, this.isPageAppear = !1, 
            my.callUserTrack("pageDisappear"));
        },
        updateSessionProperties: function(e) {
            my && my.call && my.call("handleLoggingAction", {
                type: "behavior",
                subType: "updateSessionProperties",
                extData: e
            });
        },
        getPageSpmUrl: function(e) {
            i({
                subType: "getPageSpmUrl",
                spmType: "spmUrl"
            }, e);
        },
        getPageSpmPre: function(e) {
            i({
                subType: "getPageSpmPre",
                spmType: "spmPre"
            }, e);
        }
    });
    t.exports = s;
}, function(e, t, a) {
    var r = a(3), n = a(14), o = "__ETAG__CNA__ID__", i = a(15), s = "EMPTY_CNA", p = i.extend({
        aplus_queue: [],
        CNA: "",
        hasSyncCna: !1,
        syncLaunchOptions: !1,
        _syncEtag: function(e) {
            var t = this.method || "request", a = function(t) {
                var a = t && t.data ? t.data.cna : "";
                a ? e(a) : i();
            }, i = function() {
                var a = r.getEtagUrl("log.mmstat.com");
                a ? n.get(a, {
                    dataType: "text",
                    requestMethodName: t
                }, function(t) {
                    var a = "";
                    try {
                        if (!t.failure) {
                            var n = (t ? t.data : "").split(";");
                            if (n.length > 1) a = (a = n[1].split("=")[1] || "").replace(/\"/g, ""), r.getContext().setStorage({
                                key: o,
                                data: {
                                    cna: a
                                }
                            });
                        }
                    } catch (e) {}
                    a || (a = s), e(a);
                }) : e(s);
            }, p = r.getContext();
            p && p.getStorage && p.getStorage({
                key: o,
                success: function(e) {
                    a(e);
                },
                fail: function(e) {
                    a(e);
                }
            });
        },
        _addDetailParam: function(e) {
            return e.itemId ? {
                _p_typ: "pdp",
                _p_item: e.itemId,
                _p_ispdp: "1"
            } : {};
        },
        _addSellerParam: function(e) {
            return e.sellerId ? {
                _p_typ: e.itemId ? "pdp" : "slr",
                _p_slr: e.sellerId,
                _p_isdpp: "1"
            } : {};
        },
        tryAyncEtag: function() {
            var e = this;
            this.hasSyncCna && e.CNA !== s || (this.hasSyncCna = !0, this._syncEtag(function(t) {
                e.CNA = t, t && e.publish("cnaReady", t);
            }));
        },
        getLaunchOptionsSync: function() {
            var e = this;
            if (!e.syncLaunchOptions) {
                e.syncLaunchOptions = !0;
                var t = r.getContext();
                if (t && t.getLaunchOptionsSync) {
                    var a = t.getLaunchOptionsSync(), n = a && a.query || {};
                    if (n.miniappDebugId) {
                        var o = n.miniappDebugId.trim(), i = o.split("_"), s = {
                            aplus_work_no: i.length > 2 ? i[1] : o,
                            aplus_track_debug_id: o,
                            aplus_flag: "aplus_test"
                        };
                        e.setMetaInfo("aplus-exdata", s), e.setMetaInfo("aplus-cpvdata", s);
                    }
                }
            }
        },
        subscribeCna: function() {
            var e = this;
            this.subscribe("cnaReady", function(t) {
                if (t && e.aplus_queue && e.aplus_queue.length > 0) for (;e.aplus_queue.length > 0; ) {
                    e.aplus_queue.pop().call(e, t);
                }
            });
        },
        logQueue: function(e) {
            "function" == typeof e && (this.CNA ? e(this.CNA !== s ? this.CNA : "") : this.aplus_queue.push(e));
        },
        record: function(e, t, a, o, i) {
            var s = this;
            s.getLaunchOptionsSync(), a = this.getUserInjectGokey({
                logkey: e,
                gmkey: t,
                gokey: a
            });
            var p = s.method || "request", u = function(u) {
                var c = r.getGoldlogUrl(i || s._meta_info["aplus-rhost-g"]), l = s._getRecordParams(t, a, u);
                if (c && l) {
                    0 !== e.indexOf("/vx") && (e = "/vx" + e), c += /^\//.test(e) ? e : "/" + e;
                    var m = [];
                    for (var g in l) m.push(g + "=" + l[g]);
                    c = c + "?" + m.join("&"), o || (o = "GET"), "GET" === o ? n.get(c, {
                        requestMethodName: p,
                        requestMethodType: o,
                        _extInfo: s.getMetaInfo("aplus-request-extinfo")
                    }, function() {}) : n.post(c, {
                        requestMethodName: p,
                        requestMethodType: o,
                        _extInfo: s.getMetaInfo("aplus-request-extinfo")
                    }, function() {});
                }
            };
            s.tryAyncEtag(), s.logQueue(function(e) {
                u(e);
            });
        },
        enter: function(e, t, a) {
            this.getLaunchOptionsSync(), e || (e = {}), t || (t = {});
            var o = this, i = o.method || "request";
            r.getPVLogUrl(a || o._meta_info["aplus-rhost-v"]) && (o.tryAyncEtag(), o.logQueue(function(s) {
                t.cna = s, o._getEnterParams(e, t, function(e) {
                    var t = r.getPVLogUrl(a || o._meta_info["aplus-rhost-v"]);
                    t && n.get(t + "?" + r.makeUrl(e), {
                        requestMethodName: i,
                        _extInfo: o.getMetaInfo("aplus-request-extinfo")
                    }, function() {});
                });
            }));
        },
        updateNextPageProperties: function(e) {
            e || (e = {}), this._updateNextPageSpm(e);
        }
    });
    e.exports = p;
}, function(e, t, a) {
    var r = a(3), n = "httpRequest", o = "request";
    t.get = function(e, t, a) {
        var i = r.getContext() || {}, s = t.requestMethodName || o, p = i[s];
        "function" != typeof p && s !== o && (p = i[s = o]), "function" != typeof p && s !== n && (console && console.warn('方法"' + s + '"不存在!'), 
        p = i[s = n]);
        var u, c, l = t && t.dataType ? t.dataType : "base64", m = t && t.timeout ? t.timeout : 3e3, g = t && t._extInfo ? t._extInfo : null, f = t && t.requestMethodType ? t.requestMethodType : "GET";
        if ("function" == typeof p) {
            var d = {
                url: e,
                method: f,
                dataType: l,
                timeout: m,
                success: function(e) {
                    u || (u = !0, a(e));
                },
                fail: function(t) {
                    console && console.warn('aplus日志请求"' + e + '"失败，原因：' + JSON.stringify(t)), u || (u = !0, 
                    a({
                        failure: !0,
                        data: t
                    }));
                }
            };
            g && (d._extInfo = g), p(d);
        } else c = '方法"' + s + '"不存在!', console && console.warn(c), u || (u = !0, a({
            failure: !0,
            data: c
        }));
        setTimeout(function() {
            u || (u = !0, c = 'aplus日志请求"' + e + '超时", 超时时长' + m + "ms", console && console.warn(c), 
            a({
                failure: !0,
                data: c
            }));
        }, m);
    }, t.post = function(e, t, a) {
        var i = r.getContext() || {}, s = t.requestMethodName || o, p = i[s];
        "function" != typeof p && s !== o && (p = i[s = o]), "function" != typeof p && s !== n && (console && console.warn('方法"' + s + '"不存在!'), 
        p = i[s = n]);
        var u, c, l = t && t.dataType ? t.dataType : "base64", m = t && t.timeout ? t.timeout : 3e3, g = t && t._extInfo ? t._extInfo : null, f = t && t.requestMethodType ? t.requestMethodType : "GET";
        if ("function" == typeof p) {
            for (var d = e.split("?")[0], h = {}, v = e.split("?")[1].split("&"), y = 0; y < v.length; y++) {
                var P = v[y].split("=")[0], _ = v[y].split("=")[1];
                h[P] = _;
            }
            var b = {
                url: d,
                data: h,
                method: f,
                dataType: l,
                timeout: m,
                success: function(e) {
                    u || (u = !0, a(e));
                },
                fail: function(t) {
                    console && console.warn('aplus日志请求"' + e + '"失败，原因：' + JSON.stringify(t)), u || (u = !0, 
                    a({
                        failure: !0,
                        data: t
                    }));
                }
            };
            g && (b._extInfo = g), p(b);
        } else c = '方法"' + s + '"不存在!', console && console.warn(c), u || (u = !0, a({
            failure: !0,
            data: c
        }));
        setTimeout(function() {
            u || (u = !0, c = 'aplus日志请求"' + e + '超时", 超时时长' + m + "ms", console && console.warn(c), 
            a({
                failure: !0,
                data: c
            }));
        }, m);
    }, t.sendBeacon = function(e, t) {
        for (var a in t) "cna" !== a && (t[a] = encodeURIComponent(t[a]));
        return navigator.sendBeacon(e, JSON.stringify(t)), e;
    };
}, function(t, a, r) {
    function n(e) {
        var t = "";
        try {
            if (!(t = d[e ? e.app || e.appName : ""] || "")) {
                var a = !1;
                try {
                    a = !!dd;
                } catch (e) {}
                var r = !1;
                try {
                    r = !!swan;
                } catch (e) {}
                var n = !1;
                try {
                    n = !!tt;
                } catch (e) {}
                var o = !1;
                try {
                    o = !!wx;
                } catch (e) {}
                var i = "";
                try {
                    i = navigator ? navigator.userAgent || navigator.swuserAgent : "";
                } catch (e) {}
                if (!i) try {
                    i = clientInformation ? clientInformation.appVersion : "";
                } catch (e) {}
                a || /AliApp\(DingTalk/i.test(i) ? t = "dd" : r ? t = "swan" : n ? t = "tt" : o ? t = "wx" : /AliApp\(TB/i.test(i) ? t = "tb" : /AliApp\(AP/i.test(i) && (t = "my");
            }
        } catch (e) {}
        return t;
    }
    function o(e) {
        var t = "";
        return e && (t = {
            iphone: "ios",
            ipad: "ios",
            ios: "ios",
            android: "andr",
            yunos: "yun",
            wp: "wp",
            linux: "linux",
            unix: "unix",
            macos: "mac",
            windows: "win"
        }[e.toLowerCase()] || ""), t;
    }
    function i() {
        return function(e) {
            function t(e) {
                return 1 === e ? "0123456789abcdefhijklmnopqrstuvwxyzABCDEFHIJKLMNOPQRSTUVWXYZ".substr(Math.floor(60 * Math.random()), 1) : 2 === e ? "0123456789abcdefghijkmnopqrstuvwxyzABCDEFGHIJKMNOPQRSTUVWXYZ".substr(Math.floor(60 * Math.random()), 1) : "0";
            }
            for (var a, r = "", n = !1; r.length < e; ) a = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ".substr(Math.floor(62 * Math.random()), 1), 
            !n && r.length <= 2 && ("g" === a.toLowerCase() || "l" === a.toLowerCase()) && (0 === r.length && "g" === a.toLowerCase() ? Math.random() < .5 && (a = t(1), 
            n = !0) : 1 === r.length && "l" === a.toLowerCase() && "g" === r.charAt(0).toLowerCase() && (a = t(2), 
            n = !0)), r += a;
            return r;
        }(14);
    }
    var s = r(7), p = r(3), u = p.paramsToObj, c = p.objToParams, l = p.getParamFromURL, m = p.simplifyURL, g = p.getAplusUniversalVersion, f = p.getLocation, d = {
        alipay: "my",
        TB: "tb",
        Weixin: "wx",
        Dingtalk: "dd",
        Toutiao: "tt",
        SWAN: "swan"
    }, h = s.extend({
        create: function(e) {
            var t = new this();
            for (var a in e) t[a] = e[a];
            try {
                t._meta_info = Object.assign({
                    "aplus-rhost-v": "log.mmstat.com",
                    "aplus-rhost-g": "wgo.mmstat.com",
                    "aplus-channel": "GET"
                }, t._meta_info || {});
            } catch (e) {
                t._meta_info = {}, console && console.log(e);
            }
            return t.subscribeCna(), t;
        },
        subscribeCna: function() {},
        setPageSPM: function(e, t, a) {
            if (e && t) {
                var r = [];
                r.push(e), r.push(t), this.spmAB = r, this.pageName = "", this.pageId = "", this.pvid = i();
            }
            "function" == typeof a && a();
        },
        _updateNextPageSpm: function(e) {
            e && (this.spmPre = this.spmUrl, this.spmUrl = e["spm-url"] || e.spmUrl);
        },
        getPageSPM: function() {
            return this.spmAB;
        },
        getPageSPMStr: function() {
            return this.spmAB.join(".");
        },
        _getPageSpmInfo: function(t, a) {
            this.pvid || (this.pvid = i()), "enter" === t.from && (this.pageId = t.pageId ? "/" + t.pageId : "");
            var r = this.getPageSPMStr();
            if (!r || "0.0" === r) try {
                if (console && console.warn) {
                    var n = "object" == e(a) ? JSON.stringify(a) : "";
                    console.warn("please setPageSPM before " + t.from + " about " + n);
                }
            } catch (t) {}
            return r + "" + (this.pageId || "") + ".0.0." + this.pvid;
        },
        _getRecordParams: function(t, a, r) {
            var n = f(), o = this.getMetaInfo("aplus-exdata");
            if (o) if ("string" == typeof a) {
                var i = [];
                for (var s in o) i.push(s + "=" + o[s]);
                if (i.length > 0) a += (a ? "&" : "") + i.join("&");
            } else "object" == e(a) && (a = Object.assign({}, o, a));
            var m = "string" == typeof a ? u(a) : a;
            "object" == e(m) && m || (m = {}, console && console.log("typeof gokey must be object or string"));
            var d = m.url || n.currentpagename || n.href || "";
            this.spmUrl || (this.spmUrl = l(d, "spm") || ""), this.spmPre || (this.spmPre = l(m.referrer, "spm") || "");
            var h = p.getGmObj(t);
            return (m = Object.assign({}, m, {
                pc_i: m.pc_i || "",
                ps_i: m.ps_i || "",
                pu_i: m.pu_i || "",
                _p_url: m.url || n.currentpagename || n.href || "",
                _p_ref: m.pre || "",
                "spm-url": this.spmUrl,
                "spm-pre": this.spmPre,
                jsver: "aplus_universal",
                lver: g(),
                windmill: "1",
                cache: p.makeCacheNum()
            }))._g_encode || (m._g_encode = "utf-8"), m["spm-cnt"] = this._getPageSpmInfo({
                from: "record"
            }, m), {
                logtype: "2",
                cna: r,
                gokey: encodeURIComponent(c(m, !0)),
                gmkey: h.alias
            };
        },
        _addDetailParam: function(e) {
            return e.itemId ? {
                _p_typ: "pdp",
                _p_item: e.itemId,
                _p_ispdp: "1"
            } : {};
        },
        _initPageSpmParams: function(e) {
            var t = e.spmUrl || e["spm-url"] || l(e.pageUrl, "spm") || this.spmUrl || "", a = e.spmPre || e["spm-pre"] || l(e.referrer, "spm") || this.spmPre || "", r = f(), n = e.pageName || r.currentpagename || m(e.pageUrl) || "";
            this.spmUrl = t, this.spmPre = a, this.pageName = n;
            var o = {
                pageName: n,
                spmUrl: t,
                spmPre: a
            };
            return o.spmCnt = this._getPageSpmInfo({
                from: "enter",
                pageId: e.pageId
            }, o), o;
        },
        _addSellerParam: function(e) {
            return e.sellerId ? {
                _p_typ: e.itemId ? "pdp" : "slr",
                _p_slr: e.sellerId,
                _p_isdpp: "1"
            } : {};
        },
        _appendParamsIntoArray: function(e, t) {
            return e && t && Object.keys(t).forEach(function(a) {
                e.push([ a, t[a] ]);
            }), e;
        },
        _appendUserParams: function(e, t) {
            return Object.keys(t).forEach(function(a) {
                e.push([ a, t[a] ]);
            }), e;
        },
        _getSystemInfo: function(e) {
            var t = this, a = {}, r = t.SYSTEM_INFO || {};
            if (r && r.version) e(t.SYSTEM_INFO); else try {
                p.getContext().getSystemInfo({
                    complete: function(r) {
                        r && r.version ? (t.SYSTEM_INFO = r, e(r)) : e(a);
                    }
                });
            } catch (t) {
                e(a);
            }
        },
        _getEnterParams: function(t, a, r) {
            t || (t = {}), a || (a = {});
            var i = this._initPageSpmParams(t, a), s = [ [ "logtype", "1" ], [ "title", encodeURIComponent(i.pageName) ], [ "cna", a.cna || "" ] ], u = this;
            u._getSystemInfo(function(c) {
                var l = [ [ "_p_url", t.pageUrl ], [ "_p_ref", t.referrer || "" ], [ "_p_os", o(c.platform) || "" ], [ "_p_scr", c.screenWidth + "x" + c.screenHeight ], [ "_p_pf", n(c) ], [ "spm-cnt", i.spmCnt ], [ "spm-url", i.spmUrl ], [ "spm-pre", i.spmPre ] ];
                l["spm-url"] && (u.spmUrl = l["spm-url"]), l["spm-pre"] && (u.spmPre = l["spm-pre"]);
                var m = u.getMetaInfo("aplus-cpvdata");
                if (m && "object" == e(m) && (l = u._appendParamsIntoArray(l, m)), l = u._appendParamsIntoArray(l, u._addDetailParam(a)), 
                l = u._appendParamsIntoArray(l, u._addSellerParam(a)), l = u._appendUserParams(l, a), 
                l = u._appendParamsIntoArray(l, {
                    jsver: "aplus_universal",
                    lver: g(),
                    windmill: "1",
                    cache: p.makeCacheNum()
                }), "function" == typeof r) {
                    var f = {
                        pageName: i.pageName,
                        preParams: s,
                        endParams: l
                    };
                    r(f);
                }
            });
        }
    });
    t.exports = h;
}, function(t, a, r) {
    function n(e, t) {
        void 0 === e && (e = {}), _("updatePageName", {
            commonData: e,
            pageName: t
        }), d({
            type: T,
            subType: "updatePageName",
            commonData: e,
            extData: {
                pageName: t
            }
        });
    }
    function o(e, t) {
        void 0 === e && (e = {}), void 0 === t && (t = {});
        var a = t.pageUrl || t.url || e.currentPagePath;
        d({
            type: T,
            subType: "updatePageUrl",
            commonData: e,
            extData: {
                pageUrl: a
            }
        });
    }
    function i(e, t, a) {
        void 0 === e && (e = {}), void 0 === t && (t = {}), void 0 === a && (a = {});
        var r = t;
        for (var n in a) r[n] = a[n];
        r._startupParams = encodeURIComponent(JSON.stringify(h));
        var o = h.scm || "";
        return !r.scm && o && (r.scm = o), r.pageName = t.pageName || t.name || e.currentPagePath, 
        r.currentPagePath = t.pageUrl || e.currentPagePath, r.jsver || (r.jsver = b), r.lver || (r.lver = x), 
        r._lver = x, r.windmill = "2", r._p_seid = N, r.mini_app_id = e.appId, r.appxVersion = e.appxVersion || "", 
        r;
    }
    function s(e, t) {
        var a = !1;
        d({
            type: T,
            subType: "spmPre" === e ? "getPageSpmPre" : "getPageSpmUrl"
        }, function(r) {
            if (void 0 === r && (r = {}), a = !0, r && "success" === r.status) {
                var n = {
                    status: r.status
                };
                n[e] = h.spm || r[e], t(n);
            } else t(r);
        }), setTimeout(function() {
            if (!a) {
                var r = {
                    status: "timeout"
                };
                r[e] = h.spm, t(r);
            }
        }, 300);
    }
    function p(e, t, a) {
        void 0 === e && (e = {}), void 0 === t && (t = {}), void 0 === a && (a = {});
        var r = i(e, t, a);
        _("updatePageProperties", {
            updatePageProperties: r
        }), d({
            type: T,
            subType: "updatePageProperties",
            commonData: e,
            extData: r
        });
    }
    function u(e, t, a, r) {
        if (void 0 === t && (t = {}), void 0 === a && (a = {}), e && a && (a.logkey || a.arg1)) {
            var n = w[e] || "", o = a.eventId, s = n || o, p = void 0, u = 19999;
            try {
                (p = parseInt(s)) + "" == "NaN" && (p = u);
            } catch (e) {
                p = u;
            }
            -1 === [ u, 2201, 2101, 2202 ].indexOf(p) && (p < 2900 || p > u) && (s = U);
            var c = i(t, a, a.param ? a.param : null);
            d({
                type: T,
                subType: "customAdvance",
                commonData: t,
                extData: {
                    eventId: s,
                    pageName: r,
                    arg1: a.logkey || a.arg1,
                    arg2: "",
                    arg3: "",
                    args: c
                }
            });
        }
    }
    function c(e) {
        if (void 0 === e && (e = []), 0 === S.length || JSON.stringify(e) !== JSON.stringify(S)) {
            var t = [];
            e.forEach(function(e) {
                var a = A ? A.find(function(t) {
                    return t.viewId === e;
                }) : "";
                t.push(a || {
                    viewId: e
                });
            }), A = t, S = e;
        }
        return A;
    }
    function l(e) {
        void 0 === e && (e = {});
        var t = {}, a = e.param || {}, r = e.pageName || e.name || a.pageName || a.name || "", n = e.activityId || a.activityId;
        if (n && (r += "_" + n), A.length > 0) {
            if (t._spmCnt = A[A.length - 1]._appxUTSpm, 1 === A.length && I && (t._spmUrl = A[0] ? A[0]._appxUTSpmUrl : ""), 
            A.length >= 2) {
                var o = A[A.length - 2] || {};
                t._spmUrl = o._appxUTTapSpm || o._appxUTSpm || "", 2 === A.length && h.spm && (t._spmPre = h.spm);
            }
            if (A.length >= 3) {
                var i = A[A.length - 3] || {};
                t._spmPre = i._appxUTTapSpm || i._appxUTSpm || "";
            }
        }
        return t.pageName = r, t;
    }
    function m(e) {
        A[A.length - 1]._appxUTTapSpm = e;
    }
    function g(t, a, r) {
        void 0 === a && (a = {}), void 0 === r && (r = {});
        try {
            for (var n in r) M[n] = r[n];
            k = JSON.stringify(M).length;
        } catch (t) {}
        k > 1024 ? "object" == ("undefined" == typeof console ? "undefined" : e(console)) && console.log && console.log("updateSessionProperties max length is 1024!") : d({
            type: T,
            subType: t,
            commonData: a,
            extData: r
        });
    }
    function f(e) {
        void 0 === e && (e = {});
        var t = e.commonData, a = e.pageName, r = e.pluginIds;
        (void 0 === r ? [] : r).forEach(function(e) {
            if (void 0 === e && (e = ""), e) {
                var r = i(t, {
                    pluginId: e
                }, {});
                d({
                    type: T,
                    subType: "customAdvance",
                    commonData: t,
                    extData: {
                        eventId: "2201",
                        pageName: a,
                        arg1: "/miniapp_plugin_exp",
                        arg2: "",
                        arg3: "",
                        args: r
                    }
                });
            }
        });
    }
    Object.defineProperty(a, "__esModule", {
        value: !0
    }), a.AplusWindmillAppx = void 0;
    var d, h, v = r(17), y = v.default.getRandomId, P = v.default.isDebug, _ = v.default.aplusDebugLog, b = "aplus_universal", x = "appx_v1.1.4", T = "behavior", U = "19999", w = {
        exposure: "2201",
        expose: "2201",
        EXP: "2201",
        IMPEXP: "2202",
        click: "2101",
        CLK: "2101",
        other: U,
        OTHER: U
    }, N = y(16), I = !0, A = [], S = [], k = 0, M = {};
    a.AplusWindmillAppx = function(t) {
        return void 0 === t && (t = {}), d = t.callHandleLoggingAction || t.bridgeSend, 
        h = t.startupParams, function(t, a, r, i) {
            void 0 === t && (t = ""), void 0 === a && (a = {}), void 0 === r && (r = {}), void 0 === i && (i = "");
            var v = r.extData || {};
            c(r.pagesViewIds || []);
            var y = "", b = a.currentPagePath;
            b && (y = b.replace(/\//g, "_"));
            var x = v.param || {}, U = v.activityId || x.activityId;
            U && (y += "_" + U);
            var w = t;
            "commitut" === w && v && v.type && ("updateNextProp" === (w = v.type) && (w = "updateNextPageProperties"));
            var N = v["spm-cnt"] || x["spm-cnt"] || "", S = v["spm-url"] || x["spm-url"] || "", k = v["spm-pre"] || x["spm-pre"] || "", M = "MiniApp_" + a.appId + "." + y + ".0.0", j = l(v);
            [ "enter", "pageview", "updatePageProperties" ].indexOf(w) > -1 && A.length > 0 && (v.spmId = M, 
            function(t, a, r) {
                var n = A.length, o = A[n - 1]._appxUTSpm;
                try {
                    r && "string" == typeof r && (r = JSON.parse(r));
                    var i = "object" == e(r);
                    (!i || i && "YES" !== r.customSpm) && (o && 0 !== o.indexOf("MiniApp_") || (A[n - 1]._appxUTSpm = t || a));
                } catch (r) {
                    _("launchParams", {
                        errorMsg: r
                    }), o && 0 !== o.indexOf("MiniApp_") || (A[n - 1]._appxUTSpm = t || a);
                }
                var s = h.spm || "";
                I && s && (A[n - 1]._appxUTSpmUrl = s);
            }(N, M, h.launchParams || {}), j = l(v));
            var O = j._spmCnt, D = void 0 === O ? "" : O, E = j._spmUrl, C = void 0 === E ? "" : E, q = j._spmPre, L = void 0 === q ? "" : q, R = j.pageName, W = void 0 === R ? "" : R, G = N || D || "", J = S || C || "", V = k || L || "";
            switch (w) {
              case "enter":
              case "pageview":
                o(a, v);
                var B = W;
                !B && G && (B = b), B && n(a, B);
                var H = {};
                for (var X in G && (H["spm-cnt"] = G), J && (H["spm-url"] = J), V && (H["spm-pre"] = V), 
                v.param) H[X] = v.param[X];
                if (I && (H._p_entry_flag = 1, I = !1), p(a, v, H), G || J) {
                    var F = {};
                    G && (F["spm-url"] = G), J && (F["spm-pre"] = J), _("updateNextPageProperties", F), 
                    d({
                        type: T,
                        subType: "updateNextPageProperties",
                        commonData: a,
                        extData: F
                    });
                }
                var K = v.pluginId;
                K && f({
                    subType: w,
                    commonData: a,
                    pageName: W,
                    pluginIds: [ K ]
                });
                break;

              case "updatePageName":
                n(a, W);
                break;

              case "updatePageUrl":
                o(a, v);
                break;

              case "updatePageProperties":
                var Y = {};
                for (var X in G && (Y["spm-cnt"] = G), J && (Y["spm-url"] = J), V && (Y["spm-pre"] = V), 
                v.param) Y[X] = v.param[X];
                if (p(a, v, Y), G || J) {
                    var Q = {};
                    G && (Q["spm-url"] = G), J && (Q["spm-pre"] = J), d({
                        type: T,
                        subType: "updateNextPageProperties",
                        commonData: a,
                        extData: Q
                    });
                }
                break;

              case "updateNextPageProperties":
                var z = v || {};
                v && v.params && (z = v.params);
                var Z = {};
                for (var X in z) Z[X] = z[X];
                z["spm-url"] && (Z["spm-url"] = z["spm-url"], m(z["spm-url"])), d({
                    type: T,
                    subType: w,
                    commonData: a,
                    extData: Z
                });
                break;

              case "updatePageUtparam":
              case "updateNextPageUtparam":
                var $ = v || {};
                v && v.utParamJson && "string" == typeof v.utParamJson && ($ = JSON.parse(v.utParamJson)), 
                d({
                    type: T,
                    subType: w,
                    commonData: a,
                    extData: $
                });
                break;

              case "skipPage":
              case "pageAppear":
              case "pageDisappear":
                d({
                    type: T,
                    subType: w,
                    commonData: a,
                    extData: {}
                });
                break;

              case "customAdvance":
                v["spm-cnt"] = G, u(w, a, v, W);
                break;

              case "aplusDebug":
                v && P(v.isDebug);
                break;

              case "getPageSpmUrl":
                s("spmUrl", i);
                break;

              case "getPageSpmPre":
                s("spmPre", i);
                break;

              case "updateSessionProperties":
                g(w, a, v);
                break;

              case "pluginComponentView":
                var ee = v.pluginIds || [];
                ee.length > 0 && f({
                    subType: w,
                    commonData: a,
                    pageName: W,
                    pluginIds: ee
                });
                break;

              case "click":
              case "exposure":
              case "other":
              default:
                v["spm-cnt"] = G;
                var te = v.spmC || x.spmC || v.pluginId || x.pluginId || "", ae = v.spmD || x.spmD || v.pointId || x.pointId || "";
                if (G && te && ae) {
                    var re = G.split("."), ne = [ re[0], re[1], te, ae ].join(".");
                    m(ne), d({
                        type: T,
                        subType: "updateNextPageProperties",
                        commonData: a,
                        extData: {
                            "spm-url": ne
                        }
                    });
                }
                u(w, a, v, W);
            }
        };
    };
}, function(t, a) {
    function r(e) {
        void 0 === e && (e = !1), i = !!e;
    }
    function n(t, a) {
        try {
            i && "object" == ("undefined" == typeof console ? "undefined" : e(console)) && console.log && (console.log("aplusDebugLog " + t + " start --- "), 
            console.log(JSON.stringify(a)), console.log("--- end --- "));
        } catch (t) {}
    }
    function o(e) {
        function t(e) {
            return 1 == e ? "0123456789abcdefhijklmnopqrstuvwxyzABCDEFHIJKLMNOPQRSTUVWXYZ".substr(Math.floor(60 * Math.random()), 1) : 2 == e ? "0123456789abcdefghijkmnopqrstuvwxyzABCDEFGHIJKMNOPQRSTUVWXYZ".substr(Math.floor(60 * Math.random()), 1) : "0";
        }
        for (var a, r = "", n = !1; r.length < e; ) a = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ".substr(Math.floor(62 * Math.random()), 1), 
        !n && r.length <= 2 && ("g" == a.toLowerCase() || "l" == a.toLowerCase()) && (0 === r.length && "g" == a.toLowerCase() ? Math.random() < .5 && (a = t(1), 
        n = !0) : 1 == r.length && "l" == a.toLowerCase() && "g" == r.charAt(0).toLowerCase() && (a = t(2), 
        n = !0)), r += a;
        return r;
    }
    Object.defineProperty(a, "__esModule", {
        value: !0
    }), a.getRandomId = a.aplusDebugLog = a.isDebug = void 0;
    var i = !1;
    a.isDebug = r, a.aplusDebugLog = n, a.getRandomId = o, a.default = {
        isDebug: r,
        aplusDebugLog: n,
        getRandomId: o
    };
} ]);