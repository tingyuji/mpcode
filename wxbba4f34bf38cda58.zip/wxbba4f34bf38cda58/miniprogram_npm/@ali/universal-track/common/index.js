var e = require("../../../../@babel/runtime/helpers/typeof");

exports.__esModule = !0, exports.default = void 0;

var t = require("./aplus_universal");

function a() {
    return (a = Object.assign || function(e) {
        for (var t = 1; t < arguments.length; t++) {
            var a = arguments[t];
            for (var r in a) Object.prototype.hasOwnProperty.call(a, r) && (e[r] = a[r]);
        }
        return e;
    }).apply(this, arguments);
}

var r, c = {
    track: {
        globalExtraParams: {}
    }
}, n = Component, o = Page, s = function() {
    var e = !1;
    try {
        var t = navigator ? navigator.userAgent || navigator.swuserAgent : "";
        if (e = !!/AliApp/i.test(t), /AliApp\((AP|DingTalk|AMAP|UC|QUARK)/i.test(t) && (e = !1), 
        /AliApp\(KB/i.test(t) && (e = !!/Mist/.test(t)), e) {
            var a = function() {
                var e = function() {}, t = {
                    getSystemInfo: e,
                    setStorageSync: e,
                    getStorage: e
                }, a = t;
                try {
                    a = dd;
                } catch (e) {
                    try {
                        a = my;
                    } catch (e) {
                        try {
                            a = wx;
                        } catch (e) {
                            try {
                                a = tt;
                            } catch (e) {
                                try {
                                    a = swan;
                                } catch (e) {
                                    a = t;
                                }
                            }
                        }
                    }
                }
                return a;
            }();
            "function" == typeof a.canIUse && (e = !!a.canIUse("callUserTrack"));
        }
    } catch (e) {}
    return e;
}, i = function(e) {
    Array.isArray(c.track.trackConfig.metaInfo["aplus-rhost-multi"]) ? c.track.trackConfig.metaInfo["aplus-rhost-multi"].forEach(function(t, a) {
        var r = !1;
        setTimeout(function() {
            var a = t["aplus-rhost-v"] ? t["aplus-rhost-v"] : "log.mmstat.com", c = t["aplus-rhost-g"] ? t["aplus-rhost-g"] : "wgo.mmstat.com";
            "gm.mmstat.com/yt" === a && "gm.mmstat.com/yt" === c && s() && (r = !0), e(r, a, c);
        }, 200 * a);
    }) : e();
}, p = function(t) {
    var r, n = c.track.spmA + "." + c.track.spmB + "." + t.spmcd, o = t.scm || "", s = c.track.globalExtraParams;
    return t.trackinfo && (r = "object" === e(t.trackinfo) ? JSON.parse(decodeURIComponent(JSON.stringify(t.trackinfo))) : JSON.parse(decodeURIComponent(t.trackinfo))), 
    r && (s = a({}, r, s)), {
        spm: n,
        scm: o,
        exargs: {
            appkey: c.track.trackConfig.appkey,
            appid: c.track.trackConfig.appid,
            "data-spm": n,
            "data-scm": o,
            "data-trackinfo": s
        }
    };
}, k = function(e, t, a) {
    if (c.track.spmA && c.track.spmB) if ("OTHER" === e) {
        i(function(r, n, o) {
            var s = c.aplus;
            r && (s = c.aplus.mpInstance, a = "/youku_mp.expcli.youku.h5web.control"), s.setPageSPM(c.track.spmA, c.track.spmB, function() {
                t.appkey = c.track.trackConfig.appkey, t.spm = c.track.spmA + "." + c.track.spmB + ".0.0", 
                t.sceneCode = c.track.sceneCode, t.sceneName = c.track.sceneName, s.record(a, e, t, "POST", o);
            });
        });
    } else {
        var n = p(t), o = {
            expdata: JSON.stringify([ n ]),
            device: r.model,
            brand: r.brand,
            os: r.platform,
            version: r.version
        };
        i(function(t, r, n) {
            var s = c.aplus;
            t && (s = c.aplus.mpInstance, a = "/youku_mp.expcli.youku.h5web.control"), s.setPageSPM(c.track.spmA, c.track.spmB, function() {
                o.sceneCode = c.track.sceneCode, o.sceneName = c.track.sceneName, s.record(a, e, o, "POST", n);
            });
        });
    }
}, l = function() {
    var e = getCurrentPages()[getCurrentPages().length - 1];
    c.track.currentPage = e, c.track.currentPath = e.route, c.track.currentPath.startsWith("/") && (c.track.currentPath = c.track.currentPath.slice(1));
    var t = c.track.trackConfig.metaInfo.pageConfig[c.track.currentPath];
    if (c.track.currentPageConfig = t, t && t.spm) {
        var a = t.spm[0], r = t.spm[1];
        c.track.spmA = a, c.track.spmB = r, c.track.pageName = t.pageName, c.track.pageUrl = t.pageUrl;
    } else if (t && c.track.urlParams) try {
        var n = getCurrentPages()[getCurrentPages().length - 1];
        if (n) {
            var o = JSON.parse(decodeURIComponent(n.query.urlParams)).pageName;
            c.track.spmA = t[o].spmA, c.track.spmB = t[o].spmB, c.track.pageName = t[o].pageName, 
            c.track.pageUrl = t[o].pageUrl;
        }
    } catch (e) {}
}, m = function() {
    function e(e, t) {
        var a = this;
        c.track.mp = e, this.SceneJson = t, Page = function(e) {
            return a.rewritePage(e);
        }, Component = function(e) {
            return a.rewriteComponent(e);
        };
    }
    var s = e.prototype;
    return s.init = function(e) {
        if (r = e.systemInfo ? e.systemInfo : c.track.mp.getSystemInfoSync(), "undefined" != typeof swan || "undefined" != typeof wx ? setTimeout(function() {
            Object.assign(getApp(), c), c = getApp();
        }, 0) : getApp() ? (Object.assign(getApp(), c), c = getApp()) : setTimeout(function() {
            Object.assign(getApp(), c), c = getApp();
        }, 0), e) {
            if (c.track.trackConfig = e, c.track.scene = e.scene, c.aplus = t.aplus_universal, 
            c.track.recordVV = this.recordVV, c.track.recordTS = this.recordTS, c.track.recordCLK = this.recordCLK, 
            c.track.recordEXP = this.recordEXP, c.track.recordPV = this.recordPV, c.track.setMetaConfig = this.setMetaConfig, 
            c.track.getMetaConfig = this.getMetaConfig, c.track.elementClickTracker = this.elementClickTracker, 
            c.track.elementExpTracker = this.elementExpTracker, c.track.globalExtraParams = e.globalExtraParams || {}, 
            c.track.setMetaConfig("global-extra-params", c.track.globalExtraParams), e.metaInfo && !Array.isArray(e.metaInfo["aplus-rhost-multi"])) {
                var a = e.metaInfo["aplus-rhost-v"] ? e.metaInfo["aplus-rhost-v"] : "log.mmstat.com", n = e.metaInfo["aplus-rhost-g"] ? e.metaInfo["aplus-rhost-g"] : "wgo.mmstat.com";
                t.aplus_universal.setMetaInfo("aplus-rhost-v", a), t.aplus_universal.setMetaInfo("aplus-rhost-g", n);
            }
        } else console.error("请配置埋点参数");
    }, s.catchException = function(e) {
        try {
            console && console.error(e);
        } catch (e) {}
    }, s.getMetaConfig = function(e) {
        return c.track[e];
    }, s.setMetaConfig = function(e, t) {
        switch (e) {
          case "global-extra-params":
            c.track["global-extra-params"] = a({}, c.track.globalExtraParams, t);
            break;

          default:
            this.catchException("sorry, aplus do not support the metaKey of " + e);
        }
    }, s.recordPV = function(e) {
        if (void 0 === e && (e = {}), "undefined" != typeof document) {
            if (c.track.spmA && c.track.spmB) {
                i(function(t, r) {
                    var n = c.aplus;
                    t && (n = c.aplus.mpInstance), n.setPageSPM(c.track.spmA, c.track.spmB, function() {
                        n.enter({
                            pageName: c.track.pageName,
                            pageUrl: c.track.currentPath,
                            spmUrl: c.track.spmUrl
                        }, a({
                            url: c.track.currentPath,
                            appkey: c.track.trackConfig.appkey || "",
                            appid: c.track.trackConfig.appid || "",
                            sceneCode: c.track.sceneCode,
                            sceneName: c.track.sceneName
                        }, e), r);
                    });
                });
            }
        } else {
            i(function(t, r) {
                var n = c.aplus;
                t && (n = c.aplus.mpInstance), n.setPageSPM(e.spmA, e.spmB, function() {
                    var t;
                    n.enter({
                        pageName: e.pageName || (null === (t = c.track.currentPage) || void 0 === t ? void 0 : t.pageName),
                        pageUrl: e.pageUrl || c.track.currentPath,
                        spmUrl: e.spmA + "." + e.spmB + ".0.0"
                    }, a({
                        url: e.pageUrl || c.track.currentPath,
                        appkey: c.track.trackConfig.appkey || "",
                        appid: c.track.trackConfig.appid || "",
                        sceneCode: c.track.sceneCode,
                        sceneName: c.track.sceneName
                    }, e), r);
                });
            });
        }
    }, s.recordCLK = function(e, t) {
        k("CLK", e, t || c.track.trackConfig.logKey.clk);
    }, s.recordEXP = function(e, t) {
        k("EXP", e, t || c.track.trackConfig.logKey.exp);
    }, s.recordVV = function(e, t) {
        k("OTHER", e, t || c.track.trackConfig.logKey.vv);
    }, s.recordTS = function(e, t) {
        k("OTHER", e, t || c.track.trackConfig.logKey.ts);
    }, s.rewriteComponent = function(e) {
        if (e) {
            if (e.methods) {
                e.methods.elementExpTracker = this.elementExpTracker, e.methods.elementClickTracker = this.elementClickTracker, 
                e.methods.recordVV = this.recordVV, e.methods.recordTS = this.recordTS, e.methods.recordEXP = this.recordEXP, 
                e.methods.recordCLK = this.recordCLK, e.methods.recordPV = this.recordPV, e.methods.setMetaConfig = this.setMetaConfig, 
                e.methods.getMetaConfig = this.getMetaConfig;
                var t = e.methods.onShow;
                e.methods.onShow = function() {
                    c.track.expdata || (c.track.expdata = []), l();
                    var e = getCurrentPages(), r = e[e.length - 2], n = "0.0.0.0";
                    if (r) {
                        var o = c.track.trackConfig.metaInfo.pageConfig[r.route];
                        o && o.spm && (n = o.spm[0] + "." + o.spm[1] + ".0.0");
                    }
                    if ("function" == typeof t && t.call(this), c.track.spmUrl = n, c.track.currentPageConfig) {
                        i(function(e, t) {
                            var r = c.aplus;
                            e && (r = c.aplus.mpInstance), r.setPageSPM(c.track.spmA, c.track.spmB, function() {
                                r.enter({
                                    pageName: c.track.currentPage.pageName,
                                    pageUrl: c.track.currentPath,
                                    spmUrl: n
                                }, a({
                                    url: c.track.pageUrl ? c.track.pageUrl : c.track.currentPath,
                                    appkey: c.track.trackConfig.appkey || "",
                                    appid: c.track.trackConfig.appid || "",
                                    sceneCode: c.track.sceneCode,
                                    sceneName: c.track.sceneName
                                }, c.track.globalExtraParams), t);
                            });
                        });
                    }
                };
            }
            n(e);
        }
    }, s.rewritePage = function(e) {
        var t = this, n = e.onLoad;
        e.onLoad = function(e) {
            "function" == typeof n && n.call(this, e), e.urlParams && (c.track.urlParams = e.urlParams);
            try {
                if (c.track.mp.getLaunchOptionsSync) {
                    var a = c.track.mp.getLaunchOptionsSync();
                    a && a.scene && (c.track.sceneCode = a.scene, 4 === String(c.track.sceneCode).length && (c.track.sceneCode = "01" + c.track.sceneCode), 
                    c.track.sceneName = t.SceneJson[c.track.sceneCode]);
                } else c.track.sceneCode = c.track.scene, c.track.sceneName = t.SceneJson[c.track.sceneCode];
            } catch (e) {
                console.error(e);
            }
        };
        var s = e.onShow;
        e.onShow = function() {
            c.track.expdata || (c.track.expdata = []), "function" == typeof s && s.call(this), 
            setTimeout(function() {
                l();
                var e = getCurrentPages(), t = e[e.length - 2], r = "0.0.0.0";
                if (t) {
                    var n = c.track.trackConfig.metaInfo.pageConfig[t.route];
                    if (n || (n = c.track.trackConfig.metaInfo.pageConfig[t.route.slice(1)]), n) if (n.spm) r = n.spm[0] + "." + n.spm[1] + ".0.0"; else {
                        var o = getCurrentPages()[getCurrentPages().length - 2];
                        if (o) {
                            var s = JSON.parse(decodeURIComponent(o.query.urlParams)).pageName;
                            r = n[s].spmA + "." + n[s].spmB + ".0.0";
                        }
                    }
                }
                if (c.track.spmUrl = r, c.track.currentPageConfig) {
                    i(function(e, t) {
                        var n = c.aplus;
                        e && (n = c.aplus.mpInstance), n.setPageSPM(c.track.spmA, c.track.spmB, function() {
                            n.enter({
                                pageName: c.track.pageName,
                                pageUrl: c.track.pageUrl,
                                spmUrl: r
                            }, a({
                                url: c.track.pageUrl ? c.track.pageUrl : c.track.currentPath,
                                appkey: c.track.trackConfig.appkey || "",
                                appid: c.track.trackConfig.appid || "",
                                sceneCode: c.track.sceneCode,
                                sceneName: c.track.sceneName,
                                pageName: c.track.pageName,
                                pageUrl: c.track.pageUrl
                            }, c.track.globalExtraParams), t);
                        });
                    });
                }
            }, 0);
        };
        var p = e.onReady;
        e.onReady = function() {
            "function" == typeof p && p.call(this), c.track.currentPageConfig && c.track.currentPageConfig["aplus-auto-exp"] && Array.isArray(c.track.currentPageConfig["aplus-auto-exp"].selectors) && this.elementExpTracker({
                selectors: c.track.currentPageConfig["aplus-auto-exp"].selectors
            });
        };
        var k = e.onHide;
        e.onHide = function() {
            if ("function" == typeof k && k.call(this), Array.isArray(c.track.expdata) && c.track.expdata.length > 0) {
                var e = c.track.trackConfig.logKey.exp, t = {
                    expdata: JSON.stringify(c.track.expdata),
                    device: r.model,
                    brand: r.brand,
                    os: r.platform,
                    version: r.version
                };
                i(function(a, r, n) {
                    var o = c.aplus;
                    a && (o = c.aplus.mpInstance, e = "/youku_mp.expcli.youku.h5web.control"), o.setPageSPM(c.track.spmA, c.track.spmB, function() {
                        t.sceneCode = c.track.sceneCode, t.sceneName = c.track.sceneName, o.record(e, "EXP", t, "POST", n);
                    });
                }), Array.isArray(c.track.expdata) && c.track.expdata.splice(0, c.track.pkgSize);
            }
        }, e.elementExpTracker = this.elementExpTracker, e.elementClickTracker = this.elementClickTracker, 
        e.recordVV = this.recordVV, e.recordTS = this.recordTS, e.recordEXP = this.recordEXP, 
        e.recordCLK = this.recordCLK, e.recordPV = this.recordPV, e.mp = c.track.mp, e.setMetaConfig = this.setMetaConfig, 
        e.getMetaConfig = this.getMetaConfig, o(e);
    }, s.elementClickTracker = function(e) {
        var t;
        console.log("CLICK", e);
        var n = e.target.dataset.spmcd ? e.target.dataset : e.target.targetDataset && e.target.targetDataset.spmcd ? e.target.targetDataset : {}, o = n.spmcd, s = c.track.trackConfig.logKey.clk;
        if (o) {
            var k = p(n), l = {
                expdata: JSON.stringify(k),
                device: r.model,
                brand: r.brand,
                os: r.platform,
                version: r.version
            };
            i(function(e, t, a) {
                var r = c.aplus;
                e && (r = c.aplus.mpInstance, s = "/youku_mp.expcli.youku.h5web.control"), r.setPageSPM(c.track.spmA, c.track.spmB, function() {
                    l.sceneCode = c.track.sceneCode, l.sceneName = c.track.sceneName, r.record(s, "CLK", l, "POST", a);
                });
            });
        } else {
            var m = c.track.currentPageConfig["aplus-auto-clk"];
            "undefined" != typeof wx && "undefined" == typeof ks && Array.isArray(m) && m.forEach(function(r) {
                var n;
                (n = r.cssSelector, new Promise(function(e) {
                    var t = c.track.mp.createSelectorQuery();
                    t.selectAll(n).boundingClientRect(), t.selectViewport().scrollOffset(), t.exec(function(t) {
                        e({
                            boundingClientRect: t[0],
                            scrollOffset: t[1]
                        });
                    });
                })).then(function(n) {
                    try {
                        n.boundingClientRect.forEach(function(k) {
                            if (function(e, t, a) {
                                if (!t) return !1;
                                var r = e.detail.x || e.detail.clientX, c = e.detail.y || e.detail.clientY, n = t.left, o = t.right, s = t.top, i = t.height, p = a.scrollTop;
                                return n < r && r < o && p + s < c && c < p + s + i;
                            }(e, k, n.scrollOffset) && k.dataset) {
                                o = k.dataset.spmcd || r.spmcd || "0.0", t = p(a({}, k.dataset, {
                                    spmcd: o
                                }));
                                i(function(e, a, r) {
                                    var n = c.aplus;
                                    e && (n = c.aplus.mpInstance, s = "/youku_mp.expcli.youku.h5web.control"), n.setPageSPM(c.track.spmA, c.track.spmB, function() {
                                        t.sceneCode = c.track.sceneCode, t.sceneName = c.track.sceneName, n.record(s, "CLK", t, "POST", r);
                                    });
                                });
                            }
                        });
                    } catch (e) {}
                });
            });
        }
    }, s.elementExpTracker = function(e) {
        var t = this;
        setTimeout(function() {
            c.track.pkgSize = c.track.trackConfig.pkgSize || 2;
            var a = e && e.logKey ? e.logKey : c.track.trackConfig.logKey.exp;
            e && Array.isArray(e.selectors) && e.selectors.forEach(function(n, o) {
                var s;
                "undefined" != typeof ks && (s = c.track.mp.createIntersectionObserver(t, {
                    observeAll: !0,
                    thresholds: [ .3 ],
                    initialRatio: .3
                })), "undefined" != typeof swan && (s = c.track.mp.createIntersectionObserver(t, {
                    selectAll: !0,
                    dataset: !0
                })), "undefined" != typeof my && (s = c.track.mp.createIntersectionObserver({
                    selectAll: !0,
                    dataset: !0
                })), "undefined" != typeof wx && (s = t.createIntersectionObserver({
                    observeAll: !0
                })), s.relativeToViewport({
                    bottom: -1
                }).observe(n, function(t) {
                    if (0 !== t.intersectionRatio) {
                        var n = t.dataset.spmcd, s = t.dataset || {};
                        if (void 0 === n && (e.dataset = e.dataset || [], n = e.dataset[o] && e.dataset[o].spmcd, 
                        s = e.dataset[o]), console.log("dataset:", t.intersectionRatio, s), n) {
                            var k = p(s);
                            if (c.track.expdata.push(k), c.track.expdata.length >= c.track.pkgSize) {
                                var l = {
                                    expdata: JSON.stringify(c.track.expdata),
                                    device: r.model,
                                    brand: r.brand,
                                    os: r.platform,
                                    version: r.version,
                                    appkey: c.track.trackConfig.appkey
                                };
                                i(function(e, t, r) {
                                    var n = c.aplus;
                                    e && (n = c.aplus.mpInstance, a = "/youku_mp.expcli.youku.h5web.control"), n.setPageSPM(c.track.spmA, c.track.spmB, function() {
                                        l.sceneCode = c.track.sceneCode, l.sceneName = c.track.sceneName, n.record(a, "EXP", l, "POST", r);
                                    });
                                }), Array.isArray(c.track.expdata) && c.track.expdata.splice(0, c.track.pkgSize);
                            }
                        }
                    }
                });
            });
        }, 0);
    }, e;
}();

exports.default = m;