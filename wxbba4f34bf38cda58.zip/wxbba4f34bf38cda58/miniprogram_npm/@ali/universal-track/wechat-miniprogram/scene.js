exports.__esModule = !0, exports.default = void 0;

exports.default = {
    1020: "公众号 profile 页相关小程序列表",
    1035: "公众号自定义菜单",
    1036: "App 分享消息卡片",
    1037: "小程序打开小程序",
    1038: "从另一个小程序返回",
    1043: "公众号模板消息"
};