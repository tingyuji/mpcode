exports.__esModule = !0, exports.default = void 0;

var e = r(require("../common/index")), t = r(require("./scene.js"));

function r(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

var u = new e.default(wx, t.default), d = u.init.bind(u);

exports.default = d;