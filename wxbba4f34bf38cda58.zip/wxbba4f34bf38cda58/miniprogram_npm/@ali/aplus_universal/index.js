var e, t, a = require("../../../@babel/runtime/helpers/typeof");

module.exports = (e = {}, t = function(t, r) {
    if (!e[t]) return require(r);
    if (!e[t].status) {
        var n = e[t].m;
        n._exports = n._tempexports;
        var i = Object.getOwnPropertyDescriptor(n, "exports");
        i && i.configurable && Object.defineProperty(n, "exports", {
            set: function(e) {
                "object" === a(e) && e !== n._exports && (n._exports.__proto__ = e.__proto__, Object.keys(e).forEach(function(t) {
                    n._exports[t] = e[t];
                })), n._tempexports = e;
            },
            get: function() {
                return n._tempexports;
            }
        }), e[t].status = 1, e[t].func(e[t].req, n, n.exports);
    }
    return e[t].m.exports;
}, function(t, a, r) {
    e[t] = {
        status: 0,
        func: a,
        req: r,
        m: {
            exports: {},
            _tempexports: {}
        }
    };
}(1649821775194, function(e, t, r) {
    t.exports = function(e) {
        function t(r) {
            if (a[r]) return a[r].exports;
            var n = a[r] = {
                exports: {},
                id: r,
                loaded: !1
            };
            return e[r].call(n.exports, n, n.exports, t), n.loaded = !0, n.exports;
        }
        var a = {};
        return t.m = e, t.c = a, t.p = "", t(0);
    }([ function(e, t, a) {
        e.exports = a(1);
    }, function(e, t, a) {
        t.aplus_universal = a(2), t.AplusWeb = a(7), t.AplusWeex = a(10), t.AplusWindmill = a(13), 
        t.AplusWindmillAlipay = a(14), t.AplusWindmillAppx = a(17);
    }, function(e, t, r) {
        (function(t) {
            var n, i, o, s, p = r(3), u = r(4), c = u.isWeex, g = u.isWeb;
            try {
                n = my;
            } catch (e) {}
            try {
                i = wx;
            } catch (e) {}
            try {
                o = tt;
            } catch (e) {}
            try {
                s = swan;
            } catch (e) {}
            var l = n || i || o || s, m = !1;
            "object" == a(l) && (m = !(!l.request && !l.httpRequest || !l.getSystemInfo));
            var f, d = {
                AplusWeb: r(7),
                AplusWeex: r(10),
                AplusWindmill: r(13),
                AplusWindmillAlipay: r(14),
                Common: r(8)
            }, h = function() {
                if (c) return "AplusWeex";
                if (g) return "AplusWeb";
                if (m) return p.isTB() ? "AplusWindmill" : "AplusWindmillAlipay";
                try {
                    t.window || (t.window = {});
                } catch (e) {}
                return "Common";
            }();
            try {
                var v = d[h = h || "Common"];
                f = p.createGoldlogInstance(v);
            } catch (e) {
                console && console.log(e), f = {};
            }
            e.exports = f;
        }).call(t, function() {
            return this;
        }());
    }, function(e, t) {
        function r(e) {
            for (var t = [], a = 0; a < e.length; a++) {
                var r = e[a][0], n = e[a][1];
                t.push(r + "=" + encodeURIComponent(n));
            }
            return t.join("&");
        }
        function n() {
            var e = function() {}, t = {
                getSystemInfo: e,
                setStorageSync: e,
                getStorage: e
            }, a = t;
            try {
                a = dd;
            } catch (e) {
                try {
                    a = my;
                } catch (e) {
                    try {
                        a = ks;
                    } catch (e) {
                        try {
                            a = wx;
                        } catch (e) {
                            try {
                                a = tt;
                            } catch (e) {
                                try {
                                    a = swan;
                                } catch (e) {
                                    a = t;
                                }
                            }
                        }
                    }
                }
            }
            return a;
        }
        t.getAplusUniversalVersion = function() {
            return "4.7.2";
        }, t.paramsToObj = function(e) {
            for (var t = {}, a = (e = "string" == typeof e ? e : "").split("&"), r = 0; r < a.length; r++) {
                var n = a[r], i = n.split("="), o = i[0], s = "";
                if (2 === i.length) s = i[1]; else if (i.length > 2) {
                    var p = n.indexOf("=");
                    s = n.slice(p + 1);
                }
                o && (t[o] = s);
            }
            return t;
        }, t.objToParams = function(e, t) {
            var a = [];
            for (var r in e) {
                var n = r, i = t ? encodeURIComponent(e[r]) : e[r];
                a.push(n + "=" + i);
            }
            return a.join("&");
        }, t.getParamFromURL = function(e, t) {
            var a = "";
            return t || (t = "spm"), e && (e.split("?")[1] || "").split("&").forEach(function(e) {
                0 === e.indexOf(t + "=") && (a = e.substr(t.length + 1));
            }), a;
        }, t.simplifyURL = function(e) {
            e || (e = "");
            var t = "_wx_tpl=";
            return e.indexOf(t) > -1 && (e = e.substring(e.indexOf(t) + t.length, e.indexOf(".js") + ".js".length)), 
            e.split("?")[0];
        }, t.getLocation = function() {
            var e;
            try {
                e = location || {};
            } catch (t) {
                e = {};
            }
            return e;
        }, t.getCurrentPage = function() {
            var e = getCurrentPages();
            return e[e.length - 1] || {};
        }, t.getPVLogUrl = function(e) {
            var t = "";
            return t = /^\/\/\w+/.test(e) ? "https:" + e : "https://" + e, /\w+\.gif$/.test(e) || (t += "/vx.gif"), 
            t;
        }, t.getEtagUrl = function(e) {
            return (/^\/\/\w+/.test(e) ? "https:" + e : "https://" + e) + "/eg.js";
        }, t.getGoldlogUrl = function(e) {
            return /^\/\/\w+/.test(e) ? "https:" + e : "https://" + e;
        }, t.makeCacheNum = function() {
            return Math.floor(268435456 * Math.random()).toString(16);
        }, t.makeUrl = function(e) {
            return [ e.preParams ? r(e.preParams) : "", "&aplus&", e.endParams ? r(e.endParams) : "" ].join("");
        }, t.hostValidity = function(e) {
            return /^(\/\/){0,1}(\w+\.){1,}\w+((\/\w+){1,})?$/.test(e);
        }, t.vhostValidity = function(e) {
            return /^(\/\/){0,1}(\w+\.){1,}\w+\/\w+\.gif$/.test(e);
        }, t.getContext = n, t.getAppInfo = function() {
            var e = {};
            return function() {
                if (e.appId) return e;
                try {
                    var t = n();
                    if (t.getAccountInfoSync && t.canIUse("getAccountInfoSync")) {
                        var a = t.getAccountInfoSync(), r = a.miniProgram || {}, i = a.plugin || {};
                        e.appId = r.appId, e.appVersion = r.version || r.envVersion, e.pluginAppId = i.appId, 
                        e.pluginAppVersion = i.version;
                    } else if (t.getAppIdSync && t.canIUse("getAppIdSync")) {
                        var o = t.getAppIdSync() || {};
                        e.appId = o.appId || "";
                    }
                } catch (e) {}
                return e;
            };
        }(), t.isTriver = function() {
            try {
                var e = navigator ? navigator.userAgent || navigator.swuserAgent : "";
                return /Triver/g.test(e);
            } catch (e) {
                return !1;
            }
        }, t.isTB = function() {
            var e = !1;
            try {
                var t = navigator ? navigator.userAgent || navigator.swuserAgent : "";
                if (e = !!/AliApp/i.test(t), /AliApp\((AP|DingTalk|AMAP|UC|QUARK)/i.test(t) && (e = !1), 
                /AliApp\(KB/i.test(t) && (e = !!/Mist/.test(t)), e) {
                    var a = n();
                    "function" == typeof a.canIUse && (e = !!a.canIUse("callUserTrack"));
                }
            } catch (e) {}
            return e;
        };
        var i = {
            CLK: {
                name: "click",
                alias: "CLK",
                id: "2101"
            },
            EXP: {
                name: "expose",
                alias: "EXP",
                id: "2201"
            },
            IMPEXP: {
                name: "expose",
                alias: "IMPEXP",
                id: "2202"
            },
            OTHER: {
                name: "other",
                alias: "OTHER",
                id: "19999"
            }
        };
        t.getGmObj = function(e) {
            var t = i[e] || i.OTHER;
            if ("19999" === t.id) try {
                var a = parseInt(e);
                if (a + "" != "NaN" && a > 3e3 && a < 19999) {
                    var r = e + "";
                    t = {
                        name: r,
                        alias: r,
                        id: r
                    };
                }
            } catch (e) {}
            return t;
        }, t.createGoldlogInstance = function(e, t) {
            var r = "object" == a(t) ? t : {};
            return e.default ? e.default.create(r) : e.create(r);
        };
    }, function(e, t, a) {
        t.__esModule = !0;
        var r = a(5);
        Object.keys(r).forEach(function(e) {
            "default" !== e && "__esModule" !== e && (e in t && t[e] === r[e] || (t[e] = r[e]));
        });
    }, function(e, t, a) {
        (function(e, a) {
            t.__esModule = !0, t.default = t.isQuickApp = t.isWeChatMiniProgram = t.isKuaiShouMiniProgram = t.isBaiduSmartProgram = t.isByteDanceMicroApp = t.isMiniApp = t.isKraken = t.isWeex = t.isNode = t.isWeb = void 0;
            var r = "undefined" != typeof window && "onload" in window;
            t.isWeb = r;
            var n = void 0 !== e && !(!e.versions || !e.versions.node);
            t.isNode = n;
            var i = "undefined" != typeof WXEnvironment && "Web" !== WXEnvironment.platform;
            t.isWeex = i;
            var o = "undefined" != typeof __kraken__;
            t.isKraken = o;
            var s = "undefined" != typeof my && null !== my && void 0 !== my.alert;
            t.isMiniApp = s;
            var p = "undefined" != typeof tt && null !== tt && void 0 !== tt.showToast;
            t.isByteDanceMicroApp = p;
            var u = "undefined" != typeof swan && null !== swan && void 0 !== swan.showToast;
            t.isBaiduSmartProgram = u;
            var c = "undefined" != typeof ks && null !== ks && void 0 !== ks.showToast;
            t.isKuaiShouMiniProgram = c;
            var g = !p && "undefined" != typeof wx && null !== wx && (void 0 !== wx.request || void 0 !== wx.miniProgram);
            t.isWeChatMiniProgram = g;
            var l = null != a && void 0 !== a.callNative && !i;
            t.isQuickApp = l;
            var m = {
                isWeb: r,
                isNode: n,
                isWeex: i,
                isKraken: o,
                isMiniApp: s,
                isByteDanceMicroApp: p,
                isBaiduSmartProgram: u,
                isKuaiShouMiniProgram: c,
                isWeChatMiniProgram: g,
                isQuickApp: l
            };
            t.default = m;
        }).call(t, a(6), function() {
            return this;
        }());
    }, function(e, t) {
        function a() {
            throw new Error("setTimeout has not been defined");
        }
        function r() {
            throw new Error("clearTimeout has not been defined");
        }
        function n(e) {
            if (u === setTimeout) return setTimeout(e, 0);
            if ((u === a || !u) && setTimeout) return u = setTimeout, setTimeout(e, 0);
            try {
                return u(e, 0);
            } catch (t) {
                try {
                    return u.call(null, e, 0);
                } catch (t) {
                    return u.call(this, e, 0);
                }
            }
        }
        function i() {
            f && l && (f = !1, l.length ? m = l.concat(m) : d = -1, m.length && o());
        }
        function o() {
            if (!f) {
                var e = n(i);
                f = !0;
                for (var t = m.length; t; ) {
                    for (l = m, m = []; ++d < t; ) l && l[d].run();
                    d = -1, t = m.length;
                }
                l = null, f = !1, function(e) {
                    if (c === clearTimeout) return clearTimeout(e);
                    if ((c === r || !c) && clearTimeout) return c = clearTimeout, clearTimeout(e);
                    try {
                        c(e);
                    } catch (t) {
                        try {
                            return c.call(null, e);
                        } catch (t) {
                            return c.call(this, e);
                        }
                    }
                }(e);
            }
        }
        function s(e, t) {
            this.fun = e, this.array = t;
        }
        function p() {}
        var u, c, g = e.exports = {};
        !function() {
            try {
                u = "function" == typeof setTimeout ? setTimeout : a;
            } catch (e) {
                u = a;
            }
            try {
                c = "function" == typeof clearTimeout ? clearTimeout : r;
            } catch (e) {
                c = r;
            }
        }();
        var l, m = [], f = !1, d = -1;
        g.nextTick = function(e) {
            var t = new Array(arguments.length - 1);
            if (arguments.length > 1) for (var a = 1; a < arguments.length; a++) t[a - 1] = arguments[a];
            m.push(new s(e, t)), 1 !== m.length || f || n(o);
        }, s.prototype.run = function() {
            this.fun.apply(null, this.array);
        }, g.title = "browser", g.browser = !0, g.env = {}, g.argv = [], g.version = "", 
        g.versions = {}, g.on = p, g.addListener = p, g.once = p, g.off = p, g.removeListener = p, 
        g.removeAllListeners = p, g.emit = p, g.prependListener = p, g.prependOnceListener = p, 
        g.listeners = function(e) {
            return [];
        }, g.binding = function(e) {
            throw new Error("process.binding is not supported");
        }, g.cwd = function() {
            return "/";
        }, g.chdir = function(e) {
            throw new Error("process.chdir is not supported");
        }, g.umask = function() {
            return 0;
        };
    }, function(e, t, r) {
        var n = r(3).objToParams, i = r(8).extend({
            _ENV: "Web",
            setPageSPM: function(e, t, a) {
                this.spmAB = [ e, t ], (window.goldlog_queue || (window.goldlog_queue = [])).push({
                    action: "goldlog.setPageSPM",
                    arguments: [ e, t ]
                }), "function" == typeof a && a();
            },
            getPageSPM: function() {
                return this.spmAB;
            },
            getPageSPMStr: function() {
                return this.spmAB.join(".");
            },
            record: function(e, t, a, r) {
                return a = "string" == typeof a ? a : n(a, !0), a = this.getUserInjectGokey({
                    logkey: e,
                    gmkey: t,
                    gokey: a
                }), (window.goldlog_queue || (window.goldlog_queue = [])).push({
                    action: "goldlog.record",
                    arguments: [ e, t, a, r || "POST" ]
                }), !0;
            },
            enter: function(e, t) {
                e || (e = {}), t || (t = {});
                var a = {
                    is_auto: !1,
                    page_id: ""
                };
                return t.page_id && (a.page_id = t.page_id, delete t.page_id), (window.goldlog_queue || (window.goldlog_queue = [])).push({
                    action: "goldlog.sendPV",
                    arguments: [ a, t ]
                }), !0;
            },
            setMetaInfo: function(e, t, a) {
                (window.goldlog_queue || (window.goldlog_queue = [])).push({
                    action: "goldlog.setMetaInfo",
                    arguments: [ e, t, a ]
                });
            },
            getMetaInfo: function(e, t) {
                (window.goldlog_queue || (window.goldlog_queue = [])).push({
                    action: "goldlog.aplus_pubsub.subscribe",
                    arguments: [ "aplusReady", function(a) {
                        var r = window.goldlog;
                        "complete" === a && r && "function" == typeof r.getMetaInfo && "function" == typeof t && t(r.getMetaInfo(e));
                    } ]
                });
            },
            updateSessionProperties: function(e) {
                "object" == a(e) && (window.goldlog_queue || (window.goldlog_queue = [])).push({
                    action: "goldlog.setMetaInfo",
                    arguments: [ "_session_args", e ]
                });
            }
        });
        e.exports = i;
    }, function(e, t, r) {
        function n(e) {
            return "function" == typeof e;
        }
        function i(e) {
            if (!n(e)) throw new TypeError(e + " is not a function");
            return e;
        }
        var o = r(3), s = r(9), p = function() {}, u = function(e) {
            for (var t = e.length, a = new Array(t - 1), r = 1; r < t; r++) a[r - 1] = e[r];
            return a;
        }, c = s.extend({
            _ENV: "Node",
            spmAB: [ "0", "0" ],
            spmUrl: "",
            spmPre: "",
            pageName: "",
            isPageDisAppear: !0,
            isPageAppear: !1,
            _meta_info: {},
            record: p,
            setPageSPM: p,
            getPageSPM: p,
            enter: p,
            setHandlers: function(e) {
                this.handlers = e;
            },
            subscribe: function(e, t) {
                i(t);
                var a = this, r = (a.pubs || {})[e] || [];
                if (r) for (var n = 0; n < r.length; n++) {
                    var o = r[n]();
                    t.apply(a, o);
                }
                var s = a.handlers || [];
                return e in s || (s[e] = []), s[e].push(t), a.setHandlers(s), a;
            },
            subscribeOnce: function(e, t) {
                i(t);
                var a, r = this;
                return this.subscribe.call(this, e, a = function() {
                    r.unsubscribe.call(r, e, a);
                    var n = Array.prototype.slice.call(arguments);
                    t.apply(r, n);
                }), this;
            },
            unsubscribe: function(e, t) {
                i(t);
                var r = this.handlers[e];
                if (!r) return this;
                if ("object" == a(r) && r.length > 0) {
                    for (var n = 0; n < r.length; n++) t.toString() === r[n].toString() && r.splice(n, 1);
                    this.handlers[e] = r;
                } else delete this.handlers[e];
                return this;
            },
            publish: function(e) {
                var t = u(arguments), a = this.handlers || [], r = a[e] ? a[e].length : 0;
                if (r > 0) for (var i = 0; i < r; i++) {
                    var o = a[e][i];
                    n(o) && o.apply(this, t);
                }
                return this;
            },
            cachePubs: function(e) {
                var t = this.pubs || {}, a = u(arguments);
                t[e] || (t[e] = []), t[e].push(function() {
                    return a;
                });
            },
            updatePageProperties: function(e) {
                "object" == a(e) && this.setMetaInfo("aplus-cpvdata", e);
            },
            updateNextPageProperties: p,
            updatePageUtparam: p,
            updateNextPageUtparam: p,
            skipPage: p,
            pageAppear: p,
            pageDisappear: p,
            setExposureView: p,
            updateSessionProperties: p,
            getPageSpmUrl: p,
            getPageSpmPre: p,
            getUserInjectGokey: function(e) {
                var t = this.getMetaInfo("aplus-inject-record-gokey");
                return "function" == typeof t ? t(e) : e.gokey;
            },
            setMetaInfo: function(e, t) {
                switch (e) {
                  case "aplus-rhost-v":
                  case "aplus-rhost-g":
                    var r = o.hostValidity(t);
                    r || "aplus-rhost-v" !== e || (r = o.vhostValidity(t)), r ? this._meta_info[e] = t : this.catchException("sorry, metaValue of " + t + " is not legality!");
                    break;

                  case "aplus-exdata":
                  case "aplus-cpvdata":
                  case "aplus-request-extinfo":
                    "object" == a(t) ? this._meta_info[e] = t : this.catchException("sorry, type of " + t + "  must be object!");
                    break;

                  case "aplus-channel":
                    this._meta_info[e] = t;
                    break;

                  case "aplus-inject-record-gokey":
                    "function" == typeof t ? this._meta_info[e] = t : this.catchException("sorry, type of " + t + "  must be function!");
                    break;

                  default:
                    this.catchException("sorry, aplus do not support the metaKey of " + e);
                }
            },
            appendMetaInfo: function(e, t) {
                switch (e) {
                  case "aplus-exdata":
                  case "aplus-cpvdata":
                    if ("object" == a(t)) {
                        var r = this._meta_info[e];
                        this._meta_info[e] = Object.assign(r, t);
                    } else this.catchException("sorry, type of " + t + "  must be object!");
                    break;

                  default:
                    this.setMetaInfo(e, t);
                }
            },
            getMetaInfo: function(e, t) {
                var a = this._meta_info[e];
                return "function" != typeof t ? a : void t(a);
            },
            catchException: function(e) {
                try {
                    console && console.error(e);
                } catch (e) {}
            }
        });
        e.exports = c;
    }, function(e, t) {
        function a() {}
        a.prototype.extend = function() {}, a.prototype.create = function() {}, a.extend = function(e) {
            return this.prototype.extend.call(this, e);
        }, a.prototype.create = function(e) {
            var t = new this();
            for (var a in e) t[a] = e[a];
            return t;
        }, a.prototype.extend = function(e) {
            var t = function() {};
            try {
                for (var a in "function" != typeof Object.create && (Object.create = function(e) {
                    function t() {}
                    return t.prototype = e, new t();
                }), t.prototype = Object.create(this.prototype), e) t.prototype[a] = e[a];
                t.prototype.constructor = t, t.extend = t.prototype.extend, t.create = t.prototype.create;
            } catch (e) {
                t = function() {};
            }
            return t;
        }, e.exports = a;
    }, function(e, t, r) {
        var n = r(4).isWeex, i = r(11), o = r(12).requireModule, s = i.extend({
            _ENV: "weex",
            getUT: function() {
                try {
                    var e = this.UserTrack || {};
                    "function" != typeof e.enterEvent && "function" != typeof e.commit && (e = o("userTrack") || r(!function() {
                        var e = new Error('Cannot find module "@weex-module/userTrack"');
                        throw e.code = "MODULE_NOT_FOUND", e;
                    }())), this.UserTrack = e || {};
                } catch (e) {
                    this.UserTrack = {};
                }
                return this.UserTrack;
            },
            create: function(e) {
                var t = new this();
                for (var r in e) t[r] = e[r];
                return t.isThirdGroupAPI = function() {
                    var e = "undefined" != typeof __weex_options__ && __weex_options__.weex, t = !1;
                    if (n && "object" == a(e) && "windmill" === e.config.container) try {
                        "function" == typeof o("keyboard").hideKeyboard && (t = !0);
                    } catch (e) {}
                    return t;
                }(), t.getUT(), t;
            },
            record: function(e, t, a) {
                a = this.getUserInjectGokey({
                    logkey: e,
                    gmkey: t,
                    gokey: a
                });
                var r = this._getRecordParams(e, t, a), n = r.gmObj || {}, i = this.getUT();
                return this.isThirdGroupAPI ? (r.args.isThirdGroupAPI = "1", i.commitut && i.commitut({
                    type: n.name,
                    eventId: n.id,
                    eventid: n.id,
                    name: r.pageName,
                    pageName: r.pageName,
                    arg1: r.arg1,
                    arg2: r.arg2,
                    arg3: r.arg3,
                    param: r.args,
                    params: r.args
                })) : i.customAdvance ? i.customAdvance(r.pageName, n.id, r.arg1, r.arg2, r.arg3, r.args) : i.commitut && i.commitut(n.name, n.id, r.pageName, "", r.arg1, r.arg2, r.arg3, r.args), 
                !0;
            },
            enter: function(e, t) {
                var a = this.getUT();
                e || (e = {}), t || (t = {});
                var r = this._getEnterParams(e, t), n = r.args || {};
                return this.isThirdGroupAPI && a.commitut ? (n.isThirdGroupAPI = "1", a.commitut({
                    type: "enter",
                    eventId: "-1",
                    eventid: "-1",
                    name: r.pageName,
                    pageName: r.pageName,
                    comName: n.url,
                    arg1: "",
                    arg2: "",
                    arg3: "",
                    param: n,
                    params: n
                })) : a.enterEvent ? a.enterEvent(r.pageName, n) : a.commit && a.commit("enter", r.pageName, n.url, n), 
                !0;
            },
            updateNextPageProperties: function(e) {
                var t = this.getUT();
                "object" == a(e) && t.commitut && (this.isThirdGroupAPI ? t.commitut({
                    type: "updateNextProp",
                    eventId: -1,
                    eventid: -1,
                    name: "",
                    pageName: "",
                    comName: "",
                    arg1: "",
                    arg2: "",
                    arg3: "",
                    param: e,
                    params: e
                }) : t.commitut("updateNextProp", -1, "", "", "", "", "", e));
            },
            updatePageUtparam: function(e) {
                var t = this.getUT();
                "object" == a(e) && t.updatePageUtparam && (this.isThirdGroupAPI ? t.updatePageUtparam({
                    utParamJson: JSON.stringify(e)
                }) : t.updatePageUtparam(JSON.stringify(e)));
            },
            updateNextPageUtparam: function(e) {
                var t = this.getUT();
                "object" == a(e) && t.updateNextPageUtparam && (this.isThirdGroupAPI ? t.updateNextPageUtparam({
                    utParamJson: JSON.stringify(e)
                }) : t.updateNextPageUtparam(JSON.stringify(e)));
            },
            skipPage: function() {
                var e = this.getUT();
                e.skipPage && e.skipPage();
            },
            pageAppear: function() {
                var e = this.getUT();
                e.pageAppear && this.isPageDisAppear && (this.isPageDisAppear = !1, this.isPageAppear = !0, 
                e.pageAppear());
            },
            pageDisappear: function() {
                var e = this.getUT();
                e.pageDisAppear && this.isPageAppear && (this.isPageDisAppear = !0, this.isPageAppear = !1, 
                e.pageDisAppear());
            },
            setExposureView: function(e, t, a) {
                var r = this.getUT(), n = !1;
                return r && r.setExposureView && (r.setExposureView(e, t, a), n = !0), n;
            }
        });
        e.exports = s;
    }, function(e, t, r) {
        var n = r(12).requireModule, i = r(8), o = r(3), s = o.paramsToObj, p = o.objToParams, u = o.getParamFromURL, c = o.simplifyURL, g = o.getAplusUniversalVersion, l = o.getLocation, m = i.extend({
            create: function(e) {
                var t = new this();
                for (var a in e) t[a] = e[a];
                try {
                    t.UserTrack = n("userTrack");
                } catch (e) {
                    t.UserTrack = {};
                }
                return t._meta_info || (t._meta_info = {}), t;
            },
            setPageSPM: function(e, t, a) {
                if (e && t) {
                    var r = [];
                    r.push(e), r.push(t), this.spmAB = r, this.pageName = "";
                }
                "function" == typeof a && a();
            },
            getPageSPM: function() {
                return this.spmAB;
            },
            _updateNextPageSpm: function(e) {
                e && (this.spmPre = this.spmUrl, this.spmUrl = e["spm-url"] || e.spmUrl);
            },
            getPageSPMStr: function(e, t) {
                var r = this.spmAB.join(".");
                if (!r || "0.0" === r) try {
                    if (console && console.warn) {
                        var n = "object" == a(t) ? JSON.stringify(t) : "";
                        console.warn("please setPageSPM before " + e + " about " + n);
                    }
                } catch (e) {}
                return r;
            },
            _getRecordParams: function(e, t, r) {
                r || (r = "");
                var n = this.getMetaInfo("aplus-exdata");
                if (n) if ("string" == typeof r) {
                    var i = [];
                    for (var u in n) i.push(u + "=" + n[u]);
                    i.length > 0 && (r += (r ? "&" : "") + i.join("&"));
                } else "object" == a(r) && (r = Object.assign({}, n, r));
                var m = l(), f = "string" == typeof r ? s(r) : r, d = f.url || m.currentpagename || m.href || "", h = o.getGmObj(t);
                this.pageName || (this.pageName = f.pageName || m.currentpagename || c(d) || "");
                var v = {
                    jsver: "aplus_universal",
                    lver: g(),
                    weex: "1",
                    functype: "ctrl",
                    funcId: h.id,
                    _toUT: "2",
                    logkey: e,
                    gokey: "string" == typeof r ? encodeURIComponent(r) : encodeURIComponent(p(r, !0)),
                    gmkey: h.alias,
                    urlpagename: this.pageName,
                    url: d
                };
                this.spmUrl && (v["spm-url"] = this.spmUrl), this.spmPre && (v["spm-pre"] = this.spmPre);
                var y = this.getPageSPMStr("record", v);
                return y && "0.0" !== y && (v["spm-cnt"] = y + ".0.0"), {
                    pageName: this.pageName,
                    gmObj: h,
                    arg1: e,
                    arg2: "",
                    arg3: "",
                    args: v
                };
            },
            _getEnterParams: function(e, t) {
                e || (e = {}), t || (t = {});
                var a = this.getMetaInfo("aplus-cpvdata");
                a && (t = Object.assign({}, a, t));
                var r = {
                    width: "0",
                    height: "0"
                };
                try {
                    r = screen;
                } catch (e) {}
                try {
                    __windmill_environment__ && (r.width = __windmill_environment__.screenWidth, r.height = __windmill_environment__.screenHeight);
                } catch (e) {}
                var n = l();
                t.url = e.pageUrl || n.currentpagename || n.href || "";
                var i = (t = Object.assign(t, {
                    functype: "page",
                    funcId: "2001",
                    isonepage: e.isonepage ? 1 : -1,
                    scr: r.width + "x" + r.height,
                    jsver: "aplus_universal",
                    lver: g(),
                    weex: "1",
                    _toUT: "2"
                })).scm || u(t.url, "scm") || "";
                i && (t.scm = i);
                var o = e.pageId ? "/" + e.pageId : "", s = this.getPageSPMStr("enter", t);
                return s && "0.0" !== s && (t["spm-cnt"] = s + "" + o + ".0.0"), this.spmUrl = e.spmUrl || e["spm-url"] || u(t.url, "spm") || this.spmUrl || "", 
                this.spmUrl && (t["spm-url"] = this.spmUrl), this.spmPre = e.spmPre || e["spm-pre"] || u(e.referrer, "spm") || this.spmPre || "", 
                this.spmPre && (t["spm-pre"] = this.spmPre), this.pageName = e.pageName || n.currentpagename || c(t.url) || "", 
                {
                    pageName: this.pageName,
                    args: t
                };
            }
        });
        e.exports = m;
    }, function(e, t, a) {
        function r(e) {
            return e && void 0 !== e;
        }
        t.requireModule = function(e) {
            var t;
            try {
                r(__weex_require__) && (t = __weex_require__(e));
            } catch (e) {
                t = null;
            }
            if (!t) try {
                r(weex) && "function" == typeof weex.requireModule && (t = weex.requireModule(e));
            } catch (e) {
                t = null;
            }
            if (!t) try {
                t = !function() {
                    var e = new Error('Cannot find module "@weex-module"');
                    throw e.code = "MODULE_NOT_FOUND", e;
                }();
            } catch (e) {
                t = null;
            }
            return t;
        };
    }, function(e, t, r) {
        var n = r(3), i = r(11), o = function(e, t) {
            my && my.call && "function" == typeof t && my.call("handleLoggingAction", {
                type: "behavior",
                subType: e.subType
            }, function(a) {
                t({
                    spmUrl: a[e.spmType]
                });
            });
        }, s = i.extend({
            _ENV: "windmill",
            create: function(e) {
                var t = new this();
                for (var a in e) t[a] = e[a];
                return t;
            },
            record: function(e, t, a, r) {
                a = this.getUserInjectGokey({
                    logkey: e,
                    gmkey: t,
                    gokey: a
                });
                var n = this._getRecordParams(e, t, a);
                delete n.args.weex, n.args.windmill = "1";
                var i = n.gmObj || {};
                if (my) {
                    var o = {
                        type: i.name,
                        eventId: i.id,
                        comName: n.arg1,
                        arg1: n.arg1,
                        arg2: n.arg2,
                        arg3: n.arg3,
                        param: n.args
                    };
                    n.pageName && (o.name = n.pageName, o.pageName = n.pageName), my.callUserTrack ? my.callUserTrack("customAdvance", o) : my.reportAnalytics && my.reportAnalytics("customAdvance", o);
                }
            },
            enter: function(e, t) {
                e || (e = {}), t || (t = {});
                var a = this._getEnterParams(e, t);
                if (delete a.args.weex, a.args.windmill = "1", my) {
                    var r = {
                        type: "enter",
                        eventId: "2001",
                        eventid: "-1",
                        pageName: a.pageName,
                        name: a.pageName,
                        comName: a.args.url,
                        arg1: a.arg1,
                        arg2: a.arg2,
                        arg3: a.arg3,
                        param: a.args
                    };
                    my.callUserTrack ? my.callUserTrack("commitut", r) : my.reportAnalytics && my.reportAnalytics("enter", r);
                }
            },
            updatePageProperties: function(e) {
                "object" == a(e) && (n.isTriver() && my.reportAnalytics("updatePageProperties", e), 
                this.setMetaInfo("aplus-cpvdata", e));
            },
            updateNextPageProperties: function(e) {
                if (e || (e = {}), this._updateNextPageSpm(e), my) {
                    var t = {
                        type: "updateNextProp",
                        eventId: -1,
                        eventid: -1,
                        name: "",
                        pageName: "",
                        comName: "",
                        arg1: "",
                        arg2: "",
                        arg3: "",
                        param: e,
                        params: e
                    };
                    my.callUserTrack ? my.callUserTrack("commitut", t) : my.reportAnalytics && my.reportAnalytics("enter", t);
                }
            },
            updatePageUtparam: function(e) {
                e || (e = {}), my && my.callUserTrack && my.callUserTrack("updatePageUtparam", {
                    utParamJson: JSON.stringify(e)
                });
            },
            updateNextPageUtparam: function(e) {
                e || (e = {}), my && my.callUserTrack && my.callUserTrack("updateNextPageUtparam", {
                    utParamJson: JSON.stringify(e)
                });
            },
            skipPage: function() {
                my && my.callUserTrack && my.callUserTrack("skipPage");
            },
            pageAppear: function() {
                my && my.callUserTrack && this.isPageDisAppear && (this.isPageDisAppear = !1, this.isPageAppear = !0, 
                my.callUserTrack("pageAppear"));
            },
            pageDisappear: function() {
                my && my.callUserTrack && this.isPageAppear && (this.isPageDisAppear = !0, this.isPageAppear = !1, 
                my.callUserTrack("pageDisappear"));
            },
            updateSessionProperties: function(e) {
                my && my.call && my.call("handleLoggingAction", {
                    type: "behavior",
                    subType: "updateSessionProperties",
                    extData: e
                });
            },
            getPageSpmUrl: function(e) {
                o({
                    subType: "getPageSpmUrl",
                    spmType: "spmUrl"
                }, e);
            },
            getPageSpmPre: function(e) {
                o({
                    subType: "getPageSpmPre",
                    spmType: "spmPre"
                }, e);
            }
        });
        e.exports = s;
    }, function(e, t, a) {
        var r = a(3), n = a(15), i = "__ETAG__CNA__ID__", o = a(16), s = "EMPTY_CNA", p = o.extend({
            aplus_queue: [],
            CNA: "",
            hasSyncCna: !1,
            syncLaunchOptions: !1,
            _ENV: "windmill_alipay",
            _syncEtag: function(e) {
                var t = this.method || "request", a = function(t) {
                    var a = t && t.data ? t.data.cna : "";
                    a ? e(a) : o();
                }, o = function() {
                    var a = r.getEtagUrl("log.mmstat.com");
                    a ? n.get(a, {
                        dataType: "text",
                        requestMethodName: t
                    }, function(t) {
                        var a = "";
                        try {
                            if (!t.failure) {
                                var n = (t ? t.data : "").split(";");
                                n.length > 1 && (a = (a = n[1].split("=")[1] || "").replace(/\"/g, ""), r.getContext().setStorage({
                                    key: i,
                                    data: {
                                        cna: a
                                    }
                                }));
                            }
                        } catch (e) {}
                        a || (a = s), e(a);
                    }) : e(s);
                }, p = r.getContext();
                p && p.getStorage && p.getStorage({
                    key: i,
                    success: function(e) {
                        a(e);
                    },
                    fail: function(e) {
                        a(e);
                    }
                });
            },
            _addDetailParam: function(e) {
                return e.itemId ? {
                    _p_typ: "pdp",
                    _p_item: e.itemId,
                    _p_ispdp: "1"
                } : {};
            },
            _addSellerParam: function(e) {
                return e.sellerId ? {
                    _p_typ: e.itemId ? "pdp" : "slr",
                    _p_slr: e.sellerId,
                    _p_isdpp: "1"
                } : {};
            },
            tryAyncEtag: function() {
                var e = this;
                this.hasSyncCna && e.CNA !== s || (this.hasSyncCna = !0, this._syncEtag(function(t) {
                    e.CNA = t, t && e.publish("cnaReady", t);
                }));
            },
            getLaunchOptionsSync: function() {
                var e = this;
                if (!e.syncLaunchOptions) {
                    e.syncLaunchOptions = !0;
                    var t = r.getContext();
                    if (t && t.getLaunchOptionsSync) {
                        var a = t.getLaunchOptionsSync(), n = a && a.query || {};
                        if (n.miniappDebugId) {
                            var i = n.miniappDebugId.trim(), o = i.split("_"), s = {
                                aplus_work_no: o.length > 2 ? o[1] : i,
                                aplus_track_debug_id: i,
                                aplus_flag: "aplus_test"
                            };
                            e.setMetaInfo("aplus-exdata", s), e.setMetaInfo("aplus-cpvdata", s);
                        }
                    }
                }
            },
            subscribeCna: function() {
                var e = this;
                this.subscribe("cnaReady", function(t) {
                    if (t && e.aplus_queue && e.aplus_queue.length > 0) for (;e.aplus_queue.length > 0; ) e.aplus_queue.pop().call(e, t);
                });
            },
            logQueue: function(e) {
                "function" == typeof e && (this.CNA ? e(this.CNA !== s ? this.CNA : "") : this.aplus_queue.push(e));
            },
            record: function(e, t, a, i) {
                var o = this;
                o.getLaunchOptionsSync(), a = this.getUserInjectGokey({
                    logkey: e,
                    gmkey: t,
                    gokey: a
                });
                var s = o.method || "request", p = function(p) {
                    var u = r.getGoldlogUrl(o._meta_info["aplus-rhost-g"]), c = o._getRecordParams(t, a, p);
                    if (u && c) {
                        0 !== e.indexOf("/vx") && (e = "/vx" + e), u += /^\//.test(e) ? e : "/" + e;
                        var g = [];
                        for (var l in c) g.push(l + "=" + c[l]);
                        u = u + "?" + g.join("&"), n.get(u, {
                            method: i,
                            requestMethodName: s,
                            data: c,
                            _extInfo: o.getMetaInfo("aplus-request-extinfo")
                        }, function(e) {});
                    }
                };
                o.tryAyncEtag(), o.logQueue(function(e) {
                    p(e);
                });
            },
            enter: function(e, t) {
                this.getLaunchOptionsSync(), e || (e = {}), t || (t = {});
                var a = this, i = a.method || "request";
                r.getPVLogUrl(a._meta_info["aplus-rhost-v"]) && (a.tryAyncEtag(), a.logQueue(function(o) {
                    t.cna = o, a._getEnterParams(e, t, function(e) {
                        var t = r.getPVLogUrl(a._meta_info["aplus-rhost-v"]);
                        t && n.get(t + "?" + r.makeUrl(e), {
                            requestMethodName: i,
                            _extInfo: a.getMetaInfo("aplus-request-extinfo")
                        }, function(e) {});
                    });
                }));
            },
            updateNextPageProperties: function(e) {
                e || (e = {}), this._updateNextPageSpm(e);
            }
        });
        e.exports = p;
    }, function(e, t, r) {
        var n = r(3), i = "httpRequest", o = "request";
        t.get = function(e, t, r) {
            var s = n.getContext() || {}, p = t.requestMethodName || o, u = s[p];
            "function" != typeof u && p !== o && (u = s[p = o]), "function" != typeof u && p !== i && (console && console.warn('方法"' + p + '"不存在!'), 
            u = s[p = i]);
            var c, g, l = t && t.dataType ? t.dataType : "base64", m = t && t.timeout ? t.timeout : 3e3, f = t && t._extInfo ? t._extInfo : null, d = t.method || "GET";
            if ("function" == typeof u) {
                var h = {
                    url: e,
                    method: d,
                    dataType: l,
                    timeout: m,
                    success: function(e) {
                        c || (c = !0, r(e));
                    },
                    fail: function(t) {
                        console && console.warn('aplus日志请求"' + e + '"失败，原因：' + JSON.stringify(t)), c || (c = !0, 
                        r({
                            failure: !0,
                            data: t
                        }));
                    }
                };
                "POST" === d && "object" == a(t.data) && (h.url = h.url.split("?")[0], i === p ? (h.headers = {
                    "Content-Type": "application/json"
                }, h.dataType = "json", h.data = JSON.stringify(t.data)) : h.data = t.data), f && (h._extInfo = f), 
                u(h);
            } else g = '方法"' + p + '"不存在!', console && console.warn(g), c || (c = !0, r({
                failure: !0,
                data: g
            }));
            setTimeout(function() {
                c || (c = !0, g = 'aplus日志请求"' + e + '超时", 超时时长' + m + "ms", console && console.warn(g), 
                r({
                    failure: !0,
                    data: g
                }));
            }, m);
        }, t.sendBeacon = function(e, t) {
            for (var a in t) "cna" !== a && (t[a] = encodeURIComponent(t[a]));
            return navigator.sendBeacon(e, JSON.stringify(t)), e;
        };
    }, function(e, t, r) {
        function n(e) {
            var t = "";
            try {
                if (!(t = v[e ? e.app || e.appName : ""] || "")) {
                    var a = !1;
                    try {
                        a = !!dd;
                    } catch (e) {}
                    var r = !1;
                    try {
                        r = !!swan;
                    } catch (e) {}
                    var n = !1;
                    try {
                        n = !!ks;
                    } catch (e) {}
                    var i = !1;
                    try {
                        i = !!tt;
                    } catch (e) {}
                    var o = !1;
                    try {
                        o = !!wx;
                    } catch (e) {}
                    var s = "";
                    try {
                        s = navigator ? navigator.userAgent || navigator.swuserAgent : "";
                    } catch (e) {}
                    if (!s) try {
                        s = clientInformation ? clientInformation.appVersion : "";
                    } catch (e) {}
                    a || /AliApp\(DingTalk/i.test(s) ? t = "dd" : r ? t = "swan" : i ? t = "tt" : n ? t = "ks" : o ? t = "wx" : /AliApp\(TB/i.test(s) ? t = "tb" : /AliApp\(AP/i.test(s) && (t = "my");
                }
            } catch (e) {}
            return t;
        }
        function i(e) {
            var t = "";
            return e && (t = {
                iphone: "ios",
                ipad: "ios",
                ios: "ios",
                android: "andr",
                yunos: "yun",
                wp: "wp",
                linux: "linux",
                unix: "unix",
                macos: "mac",
                windows: "win"
            }[e.toLowerCase()] || ""), t;
        }
        function o() {
            return function(e) {
                function t(e) {
                    return 1 === e ? "0123456789abcdefhijklmnopqrstuvwxyzABCDEFHIJKLMNOPQRSTUVWXYZ".substr(Math.floor(60 * Math.random()), 1) : 2 === e ? "0123456789abcdefghijkmnopqrstuvwxyzABCDEFGHIJKMNOPQRSTUVWXYZ".substr(Math.floor(60 * Math.random()), 1) : "0";
                }
                for (var a, r = "", n = !1; r.length < e; ) a = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ".substr(Math.floor(62 * Math.random()), 1), 
                !n && r.length <= 2 && ("g" === a.toLowerCase() || "l" === a.toLowerCase()) && (0 === r.length && "g" === a.toLowerCase() ? Math.random() < .5 && (a = t(1), 
                n = !0) : 1 === r.length && "l" === a.toLowerCase() && "g" === r.charAt(0).toLowerCase() && (a = t(2), 
                n = !0)), r += a;
                return r;
            }(14);
        }
        var s = r(8), p = r(3), u = p.paramsToObj, c = p.objToParams, g = p.getParamFromURL, l = p.simplifyURL, m = p.getAplusUniversalVersion, f = p.getLocation, d = p.getCurrentPage, h = p.getAppInfo().appId, v = {
            alipay: "my",
            TB: "tb",
            Weixin: "wx",
            Dingtalk: "dd",
            Toutiao: "tt",
            SWAN: "swan"
        }, y = s.extend({
            create: function(e) {
                var t = new this();
                for (var a in e) t[a] = e[a];
                try {
                    t._meta_info = Object.assign({
                        "aplus-rhost-v": "log.mmstat.com",
                        "aplus-rhost-g": "wgo.mmstat.com",
                        "aplus-channel": "GET"
                    }, t._meta_info || {});
                } catch (e) {
                    t._meta_info = {}, console && console.log(e);
                }
                return t.subscribeCna(), t;
            },
            subscribeCna: function() {},
            setPageSPM: function(e, t, a) {
                if (e && t) {
                    var r = [];
                    r.push(e), r.push(t), this.spmAB = r, this.pageName = "", this.pageId = "", this.pvid = o();
                }
                "function" == typeof a && a();
            },
            _updateNextPageSpm: function(e) {
                e && (this.spmPre = this.spmUrl, this.spmUrl = e["spm-url"] || e.spmUrl);
            },
            getPageSPM: function() {
                return this.spmAB;
            },
            getPageSPMStr: function() {
                return this.spmAB.join(".");
            },
            _getPageSpmInfo: function(e, t) {
                this.pvid || (this.pvid = o()), "enter" === e.from && (this.pageId = e.pageId ? "/" + e.pageId : "");
                var r = this.getPageSPMStr();
                if (!r || "0.0" === r) try {
                    if (console && console.warn) {
                        var n = "object" == a(t) ? JSON.stringify(t) : "";
                        console.warn("please setPageSPM before " + e.from + " about " + n);
                    }
                } catch (e) {}
                return r + "" + (this.pageId || "") + ".0.0." + this.pvid;
            },
            _getRecordParams: function(e, t, r) {
                var n = f(), i = d(), o = this.getMetaInfo("aplus-exdata");
                if (o) if ("string" == typeof t) {
                    var s = [];
                    for (var l in o) s.push(l + "=" + o[l]);
                    s.length > 0 && (t += (t ? "&" : "") + s.join("&"));
                } else "object" == a(t) && (t = Object.assign({}, o, t));
                var v = "string" == typeof t ? u(t) : t;
                "object" == a(v) && v || (v = {}, console && console.log("typeof gokey must be object or string"));
                var y = v.url || n.currentpagename || n.href || "https://" + h + "_" + i.route || "";
                this.spmUrl || (this.spmUrl = g(y, "spm") || ""), this.spmPre || (this.spmPre = g(v.referrer, "spm") || "");
                var _ = p.getGmObj(e);
                return (v = Object.assign({}, v, {
                    pc_i: v.pc_i || "",
                    ps_i: v.ps_i || "",
                    pu_i: v.pu_i || "",
                    _p_url: y,
                    _p_ref: v.pre || "",
                    "spm-url": this.spmUrl,
                    "spm-pre": this.spmPre,
                    jsver: "aplus_universal",
                    lver: m(),
                    windmill: "1",
                    cache: p.makeCacheNum(),
                    mini_app_id: h
                }))._g_encode || (v._g_encode = "utf-8"), v["spm-cnt"] = this._getPageSpmInfo({
                    from: "record"
                }, v), {
                    logtype: "2",
                    cna: r,
                    gokey: encodeURIComponent(c(v, !0)),
                    gmkey: _.alias
                };
            },
            _addDetailParam: function(e) {
                return e.itemId ? {
                    _p_typ: "pdp",
                    _p_item: e.itemId,
                    _p_ispdp: "1"
                } : {};
            },
            _initPageSpmParams: function(e, t) {
                var a = e.spmUrl || e["spm-url"] || g(e.pageUrl, "spm") || this.spmUrl || "", r = e.spmPre || e["spm-pre"] || g(e.referrer, "spm") || this.spmPre || "", n = f(), i = e.pageName || n.currentpagename || l(e.pageUrl) || "", o = d(), s = e.pageUrl || "https://" + h + "_" + o.route || "";
                this.spmUrl = a, this.spmPre = r, this.pageName = i, this.pageUrl = s;
                var p = {
                    pageName: i,
                    pageUrl: s,
                    spmUrl: a,
                    spmPre: r
                };
                return p.spmCnt = this._getPageSpmInfo({
                    from: "enter",
                    pageId: e.pageId
                }, p), p;
            },
            _addSellerParam: function(e) {
                return e.sellerId ? {
                    _p_typ: e.itemId ? "pdp" : "slr",
                    _p_slr: e.sellerId,
                    _p_isdpp: "1"
                } : {};
            },
            _appendParamsIntoArray: function(e, t) {
                return e && t && Object.keys(t).forEach(function(a) {
                    e.push([ a, t[a] ]);
                }), e;
            },
            _appendUserParams: function(e, t) {
                return Object.keys(t).forEach(function(a) {
                    e.push([ a, t[a] ]);
                }), e;
            },
            _getSystemInfo: function(e) {
                var t = this, a = {}, r = t.SYSTEM_INFO || {};
                if (r && r.version) e(t.SYSTEM_INFO); else try {
                    p.getContext().getSystemInfo({
                        complete: function(r) {
                            r && r.version ? (t.SYSTEM_INFO = r, e(r)) : e(a);
                        }
                    });
                } catch (t) {
                    e(a);
                }
            },
            _getEnterParams: function(e, t, r) {
                e || (e = {}), t || (t = {});
                var o = this._initPageSpmParams(e, t), s = [ [ "logtype", "1" ], [ "title", encodeURIComponent(o.pageName) ], [ "cna", t.cna || "" ] ], u = this;
                u._getSystemInfo(function(c) {
                    var g = [ [ "_p_url", o.pageUrl ], [ "_p_ref", e.referrer || "" ], [ "_p_os", i(c.platform) || "" ], [ "_p_scr", c.screenWidth + "x" + c.screenHeight ], [ "_p_pf", n(c) ], [ "spm-cnt", o.spmCnt ], [ "spm-url", o.spmUrl ], [ "spm-pre", o.spmPre ], [ "mini_app_id", h ] ];
                    g["spm-url"] && (u.spmUrl = g["spm-url"]), g["spm-pre"] && (u.spmPre = g["spm-pre"]);
                    var l = u.getMetaInfo("aplus-cpvdata");
                    if (l && "object" == a(l) && (g = u._appendParamsIntoArray(g, l)), g = u._appendParamsIntoArray(g, u._addDetailParam(t)), 
                    g = u._appendParamsIntoArray(g, u._addSellerParam(t)), g = u._appendUserParams(g, t), 
                    g = u._appendParamsIntoArray(g, {
                        jsver: "aplus_universal",
                        lver: m(),
                        windmill: "1",
                        cache: p.makeCacheNum()
                    }), "function" == typeof r) {
                        var f = {
                            pageName: o.pageName,
                            preParams: s,
                            endParams: g
                        };
                        r(f);
                    }
                });
            }
        });
        e.exports = y;
    }, function(e, t, r) {
        function n(e, t) {
            void 0 === e && (e = {}), P("updatePageName", {
                commonData: e,
                pageName: t
            }), d({
                type: w,
                subType: "updatePageName",
                commonData: e,
                extData: {
                    pageName: t
                }
            });
        }
        function i(e, t, a) {
            void 0 === e && (e = {}), void 0 === t && (t = {}), void 0 === a && (a = {});
            var r = {
                developerVersion: h.developerVersion,
                miniappVtDebugId: h.miniappVtDebugId,
                miniappVtEnv: h.miniappVtEnv,
                miniappVtWsToken: h.miniappVtWsToken,
                miniappVtAppId: h.miniappVtAppId,
                hostAppName: h.hostAppName,
                appVersion: h.appVersion,
                appxUtdid: h.appxUtdid,
                sourceType: h.sourceType
            }, n = f(f({}, r), t);
            for (var i in a) n[i] = a[i];
            var o = h.scm || "";
            return !n.scm && o && (n.scm = o), n.pageName = t.pageName || t.name || e.appId + "_" + e.currentPagePath, 
            n.currentPagePath = t.pageUrl || e.currentPagePath, n.jsver || (n.jsver = x), n.lver || (n.lver = b), 
            n._lver = b, n.windmill = "2", n._p_seid = I, n.mini_app_id = e.appId, n.appxVersion = e.appxVersion || "", 
            n;
        }
        function o(e, t) {
            var a = !1;
            d({
                type: w,
                subType: "spmPre" === e ? "getPageSpmPre" : "getPageSpmUrl"
            }, function(r) {
                if (void 0 === r && (r = {}), a = !0, r && "success" === r.status) {
                    var n = {
                        status: r.status
                    };
                    n[e] = h.spm || r[e], t(n);
                } else t(r);
            }), setTimeout(function() {
                if (!a) {
                    var r = {
                        status: "timeout"
                    };
                    r[e] = h.spm, t(r);
                }
            }, 300);
        }
        function s(e, t, a) {
            void 0 === e && (e = {}), void 0 === t && (t = {}), void 0 === a && (a = {});
            var r = i(e, t, a);
            P("updatePageProperties", {
                updatePageProperties: r
            }), d({
                type: w,
                subType: "updatePageProperties",
                commonData: e,
                extData: r
            });
        }
        function p(e, t, a, r) {
            if (void 0 === t && (t = {}), void 0 === a && (a = {}), e && a && (a.logkey || a.arg1)) {
                var n = U[e] || "", o = a.eventId, s = n || o, p = void 0, u = 19999;
                try {
                    (p = parseInt(s)) + "" == "NaN" && (p = u);
                } catch (e) {
                    p = u;
                }
                -1 === [ u, 2201, 2101, 2202 ].indexOf(p) && (p < 2900 || p > u) && (s = A);
                var c = i(t, a, a.param ? a.param : null);
                d({
                    type: w,
                    subType: "customAdvance",
                    commonData: t,
                    extData: {
                        eventId: s,
                        pageName: r,
                        arg1: a.logkey || a.arg1,
                        arg2: "",
                        arg3: "",
                        args: c
                    }
                });
            }
        }
        function u(e) {
            if (void 0 === e && (e = []), 0 === k.length || JSON.stringify(e) !== JSON.stringify(k)) {
                var t = [];
                e.forEach(function(e) {
                    var a = S ? S.find(function(t) {
                        return t.viewId === e;
                    }) : "";
                    t.push(a || {
                        viewId: e
                    });
                }), S = t, k = e;
            }
            return S;
        }
        function c(e) {
            void 0 === e && (e = {});
            var t = {}, a = e.param || {}, r = e.pageName || e.name || a.pageName || a.name || "", n = e.activityId || a.activityId;
            if (n && (r += "_" + n), S.length > 0) {
                if (t._spmCnt = S[S.length - 1]._appxUTSpm, 1 === S.length && N && (t._spmUrl = S[0] ? S[0]._appxUTSpmUrl : ""), 
                S.length >= 2) {
                    var i = S[S.length - 2] || {};
                    t._spmUrl = i._appxUTTapSpm || i._appxUTSpm || "", 2 === S.length && h.spm && (t._spmPre = h.spm);
                }
                if (S.length >= 3) {
                    var o = S[S.length - 3] || {};
                    t._spmPre = o._appxUTTapSpm || o._appxUTSpm || "";
                }
            }
            return t.pageName = r, t;
        }
        function g(e) {
            S[S.length - 1]._appxUTTapSpm = e;
        }
        function l(e, t, r) {
            void 0 === t && (t = {}), void 0 === r && (r = {});
            try {
                for (var n in r) j[n] = r[n];
                M = JSON.stringify(j).length;
            } catch (e) {}
            M > 1024 ? "object" == ("undefined" == typeof console ? "undefined" : a(console)) && console.log && console.log("updateSessionProperties max length is 1024!") : d({
                type: w,
                subType: e,
                commonData: t,
                extData: r
            });
        }
        function m(e) {
            void 0 === e && (e = {});
            var t = e.commonData, a = e.pageName, r = e.pluginIds;
            (void 0 === r ? [] : r).forEach(function(e) {
                if (void 0 === e && (e = ""), e) {
                    var r = i(t, {
                        pluginId: e
                    }, {});
                    d({
                        type: w,
                        subType: "customAdvance",
                        commonData: t,
                        extData: {
                            eventId: "2201",
                            pageName: a,
                            arg1: "/miniapp_plugin_exp",
                            arg2: "",
                            arg3: "",
                            args: r
                        }
                    });
                }
            });
        }
        var f = this && this.__assign || function() {
            return (f = Object.assign || function(e) {
                for (var t, a = 1, r = arguments.length; a < r; a++) for (var n in t = arguments[a]) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n]);
                return e;
            }).apply(this, arguments);
        };
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.AplusWindmillAppx = void 0;
        var d, h, v = r(18), y = v.default.getRandomId, _ = v.default.isDebug, P = v.default.aplusDebugLog, x = "aplus_universal", b = "appx_v1.1.5", w = "behavior", A = "19999", U = {
            exposure: "2201",
            expose: "2201",
            EXP: "2201",
            IMPEXP: "2202",
            click: "2101",
            CLK: "2101",
            other: A,
            OTHER: A
        }, I = y(16), T = 1, N = !0, S = [], k = [], M = 0, j = {};
        t.AplusWindmillAppx = function(e) {
            return void 0 === e && (e = {}), d = e.callHandleLoggingAction || e.bridgeSend, 
            h = e.startupParams, function(e, t, r, i) {
                void 0 === e && (e = ""), void 0 === t && (t = {}), void 0 === r && (r = {}), void 0 === i && (i = "");
                var f = r.extData || {};
                u(r.pagesViewIds || []);
                var v = "", y = t.currentPagePath;
                y && (v = y.replace(/\//g, "_"));
                var x = f.param || {}, b = f.activityId || x.activityId;
                b && (v += "_" + b);
                var A = e;
                "commitut" === A && f && f.type && "updateNextProp" === (A = f.type) && (A = "updateNextPageProperties");
                var U = f["spm-cnt"] || x["spm-cnt"] || "", I = f["spm-url"] || x["spm-url"] || "", k = f["spm-pre"] || x["spm-pre"] || "", M = "MiniApp_" + t.appId + "." + v + ".0.0", j = c(f), O = h.launchParams || {};
                [ "enter", "pageview", "updatePageProperties" ].indexOf(A) > -1 && S.length > 0 && (f.spmId = M, 
                function(e, t, r) {
                    var n = S.length, i = S[n - 1]._appxUTSpm;
                    try {
                        r && "string" == typeof r && (r = JSON.parse(r));
                        var o = "object" == a(r);
                        (!o || o && "YES" !== r.customSpm) && (i && 0 !== i.indexOf("MiniApp_") || (S[n - 1]._appxUTSpm = e || t));
                    } catch (r) {
                        P("launchParams", {
                            errorMsg: r
                        }), i && 0 !== i.indexOf("MiniApp_") || (S[n - 1]._appxUTSpm = e || t);
                    }
                    var s = h.spm || "";
                    N && s && (S[n - 1]._appxUTSpmUrl = s);
                }(U, M, O), j = c(f));
                var D = j._spmCnt, E = void 0 === D ? "" : D, C = j._spmUrl, L = void 0 === C ? "" : C, q = j._spmPre, V = void 0 === q ? "" : q, W = j.pageName, R = void 0 === W ? "" : W, J = U || E || "", B = I || L || "", G = k || V || "";
                switch (A) {
                  case "enter":
                  case "pageview":
                    if ("pageview" === A && "YES" === O.customSpm) return;
                    var K = R;
                    !K && J && (K = t.appId + "_" + y), K && n(t, K);
                    var H = {};
                    for (var F in J && (H["spm-cnt"] = J), B && (H["spm-url"] = B), G && (H["spm-pre"] = G), 
                    f.param) H[F] = f.param[F];
                    if (N && (H._p_entry_flag = T, N = !1), s(t, f, H), J || B) {
                        var X = {};
                        J && (X["spm-url"] = J), B && (X["spm-pre"] = B), P("updateNextPageProperties", X), 
                        d({
                            type: w,
                            subType: "updateNextPageProperties",
                            commonData: t,
                            extData: X
                        });
                    }
                    var Q = f.pluginId;
                    Q && m({
                        subType: A,
                        commonData: t,
                        pageName: R,
                        pluginIds: [ Q ]
                    });
                    break;

                  case "updatePageName":
                    n(t, R);
                    break;

                  case "updatePageUrl":
                    !function(e, t) {
                        void 0 === e && (e = {}), void 0 === t && (t = {});
                        var a = t.pageUrl || t.url || e.currentPagePath;
                        d({
                            type: w,
                            subType: "updatePageUrl",
                            commonData: e,
                            extData: {
                                pageUrl: a
                            }
                        });
                    }(t, f);
                    break;

                  case "updatePageProperties":
                    var Y = {};
                    for (var F in J && (Y["spm-cnt"] = J), B && (Y["spm-url"] = B), G && (Y["spm-pre"] = G), 
                    f.param) Y[F] = f.param[F];
                    if (s(t, f, Y), J || B) {
                        var z = {};
                        J && (z["spm-url"] = J), B && (z["spm-pre"] = B), d({
                            type: w,
                            subType: "updateNextPageProperties",
                            commonData: t,
                            extData: z
                        });
                    }
                    break;

                  case "updateNextPageProperties":
                    var Z = f || {};
                    f && f.params && (Z = f.params);
                    var $ = {};
                    for (var F in Z) $[F] = Z[F];
                    Z["spm-url"] && ($["spm-url"] = Z["spm-url"], g(Z["spm-url"])), d({
                        type: w,
                        subType: A,
                        commonData: t,
                        extData: $
                    });
                    break;

                  case "updatePageUtparam":
                  case "updateNextPageUtparam":
                    var ee = f || {};
                    f && f.utParamJson && "string" == typeof f.utParamJson && (ee = JSON.parse(f.utParamJson)), 
                    d({
                        type: w,
                        subType: A,
                        commonData: t,
                        extData: ee
                    });
                    break;

                  case "skipPage":
                  case "pageAppear":
                  case "pageDisappear":
                    d({
                        type: w,
                        subType: A,
                        commonData: t,
                        extData: {}
                    });
                    break;

                  case "customAdvance":
                    f["spm-cnt"] = J, p(A, t, f, R);
                    break;

                  case "aplusDebug":
                    f && _(f.isDebug);
                    break;

                  case "getPageSpmUrl":
                    o("spmUrl", i);
                    break;

                  case "getPageSpmPre":
                    o("spmPre", i);
                    break;

                  case "getPageAllProperties":
                    !function(e) {
                        var t = !1;
                        d({
                            type: w,
                            subType: "getPageAllProperties"
                        }, function(a) {
                            void 0 === a && (a = {}), !t && e(a), t = !0;
                        }), setTimeout(function() {
                            t || (t = !0, e({
                                status: "timeout"
                            }));
                        }, 300);
                    }(i);
                    break;

                  case "updateSessionProperties":
                    l(A, t, f);
                    break;

                  case "pluginComponentView":
                    var te = f.pluginIds || [];
                    te.length > 0 && m({
                        subType: A,
                        commonData: t,
                        pageName: R,
                        pluginIds: te
                    });
                    break;

                  case "click":
                  case "exposure":
                  case "other":
                  default:
                    f["spm-cnt"] = J;
                    var ae = f.spmC || x.spmC || f.pluginId || x.pluginId || "", re = f.spmD || x.spmD || f.pointId || x.pointId || "";
                    if (J && ae && re) {
                        var ne = J.split("."), ie = [ ne[0], ne[1], ae, re ].join(".");
                        g(ie), d({
                            type: w,
                            subType: "updateNextPageProperties",
                            commonData: t,
                            extData: {
                                "spm-url": ie
                            }
                        });
                    }
                    p(A, t, f, R);
                }
            };
        };
    }, function(e, t) {
        function r(e) {
            void 0 === e && (e = !1), o = !!e;
        }
        function n(e, t) {
            try {
                o && "object" == ("undefined" == typeof console ? "undefined" : a(console)) && console.log && (console.log("aplusDebugLog " + e + " start --- "), 
                console.log(JSON.stringify(t)), console.log("--- end --- "));
            } catch (e) {}
        }
        function i(e) {
            function t(e) {
                return 1 == e ? "0123456789abcdefhijklmnopqrstuvwxyzABCDEFHIJKLMNOPQRSTUVWXYZ".substr(Math.floor(60 * Math.random()), 1) : 2 == e ? "0123456789abcdefghijkmnopqrstuvwxyzABCDEFGHIJKMNOPQRSTUVWXYZ".substr(Math.floor(60 * Math.random()), 1) : "0";
            }
            for (var a, r = "", n = !1; r.length < e; ) a = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ".substr(Math.floor(62 * Math.random()), 1), 
            !n && r.length <= 2 && ("g" == a.toLowerCase() || "l" == a.toLowerCase()) && (0 === r.length && "g" == a.toLowerCase() ? Math.random() < .5 && (a = t(1), 
            n = !0) : 1 == r.length && "l" == a.toLowerCase() && "g" == r.charAt(0).toLowerCase() && (a = t(2), 
            n = !0)), r += a;
            return r;
        }
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.getRandomId = t.aplusDebugLog = t.isDebug = void 0;
        var o = !1;
        t.isDebug = r, t.aplusDebugLog = n, t.getRandomId = i, t.default = {
            isDebug: r,
            aplusDebugLog: n,
            getRandomId: i
        };
    } ]);
}, function(e) {
    return t({}[e], e);
}), t(1649821775194));