require("../../../@babel/runtime/helpers/Arrayincludes");

var e, t, n, r, o = (e = require("../../../@babel/runtime/regenerator")) && e.__esModule ? e : {
    default: e
}, a = require("../../../@babel/runtime/helpers/typeof");

module.exports = (t = {}, r = function(e, n) {
    if (!t[e]) return require(n);
    if (!t[e].status) {
        var r = t[e].m;
        r._exports = r._tempexports;
        var o = Object.getOwnPropertyDescriptor(r, "exports");
        o && o.configurable && Object.defineProperty(r, "exports", {
            set: function(e) {
                "object" === a(e) && e !== r._exports && (r._exports.__proto__ = e.__proto__, Object.keys(e).forEach(function(t) {
                    r._exports[t] = e[t];
                })), r._tempexports = e;
            },
            get: function() {
                return r._tempexports;
            }
        }), t[e].status = 1, t[e].func(t[e].req, r, r.exports);
    }
    return t[e].m.exports;
}, (n = function(e, n, r) {
    t[e] = {
        status: 0,
        func: n,
        req: r,
        m: {
            exports: {},
            _tempexports: {}
        }
    };
})(1684229349923, function(e, t, n) {
    Object.defineProperty(n, "__esModule", {
        value: !0
    }), n.default = void 0;
    var r, o = e("universal-env"), a = {
        appKey: "24679788",
        prefix: "acs",
        subDomain: "",
        mainDomain: "youku.com",
        dataType: "json",
        v: "1.0",
        SV: "2.0",
        ykH5Request: !1
    };
    o.isWeb || o.isWeex || (r = e("./mtop/mtop.js").default || e("./mtop/mtop.js"));
    var i = {
        request: function(t) {
            var n = Object.assign({}, a, t);
            if (o.isWeb || o.isWeex) return (e("./h5/index").default || e("./h5/index"))(t);
            if (r.mtop.config.prefix = n.prefix, r.mtop.config.subDomain = n.subDomain, r.mtop.config.mainDomain = n.mainDomain, 
            !n.api) throw new Error("mtop请求异常，缺少api参数");
            return r.mtop.request({
                appKey: n.appKey,
                dataType: n.dataType,
                api: n.api,
                data: n.data,
                v: n.v,
                SV: n.SV,
                ykH5Request: n.ykH5Request,
                headers: n.headers || {}
            });
        },
        loginClient: function(e) {
            r.mtop.config.$loginClient = {
                getSession: function(t) {
                    t(e);
                }
            };
        },
        check_mtop_login_status: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = String(e.ret[0]).split("::")[0];
            return "-103" != t && "FAIL_SYS_SESSION_EXPIRED" !== t;
        }
    };
    n.default = i;
}, function(e) {
    return r({
        "./mtop/mtop.js": 1684229349924,
        "./h5/index": 1684229349928
    }[e], e);
}), n(1684229349924, function(e, t, n) {
    var r = u(e("./../adapter/api")), o = u(e("../npm/md5")), i = e("../utils/utils"), s = e("@ali/mini-util");
    function u(e) {
        return e && e.__esModule ? e : {
            default: e
        };
    }
    !function(e, n, r) {
        var u = (Promise || {
            resolve: function() {}
        }).resolve();
        function p() {
            var e = {}, t = new Promise(function(t, n) {
                e.resolve = t, e.reject = n;
            });
            return e.promise = t, e;
        }
        function c(e, t) {
            for (var n in t) void 0 === e[n] && (e[n] = t[n]);
            return e;
        }
        function f(e) {
            var t = [];
            for (var n in e) t.push(n + "=" + encodeURIComponent(e[n]));
            return t.join("&");
        }
        String.prototype.trim || (String.prototype.trim = function() {
            return this.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, "");
        });
        var m = {};
        function l(e) {
            return "wx" == r.p_pf ? r && r.platform && r.platform.getStorageSync(e) : m[e];
        }
        var d = {
            useJsonpResultType: !1,
            safariGoLogin: !0,
            useAlipayJSBridge: !1
        }, y = [], g = {
            ERROR: -1,
            SUCCESS: 0,
            TOKEN_EXPIRED: 1,
            SESSION_EXPIRED: 2
        };
        d.mainDomain = "taobao.com", d.subDomain = "m", d.prefix = "h5api";
        var _ = 0;
        function v(e) {
            this.id = ++_, this.params = c(e || {}, {
                v: "*",
                data: {},
                type: "get",
                dataType: "json"
            }), this.params.type = this.params.type.toLowerCase(), "object" === a(this.params.data) && (this.params.data = JSON.stringify(this.params.data)), 
            this.middlewares = y.slice(0);
        }
        v.prototype.use = function(e) {
            if (!e) throw new Error("middleware is undefined");
            return this.middlewares.push(e), this;
        }, v.prototype.__processRequestMethod = function(e) {
            var t = this.params, n = this.options;
            "get" === t.type && "json" === t.dataType ? n.getJSON = !0 : "post" === t.type && (n.postJSON = !0), 
            e();
        }, v.prototype.__processRequestType = function(e) {
            if (this.params, this.options.H5Request = !0, e) return e();
        }, v.prototype.__getTokenFromCookie = function() {
            this.params;
            var e = this.options;
            return e.token = (l("_m_h5_c2") || "").split(";")[0], e.token && (e.token = e.token.split("_")[0]), 
            Promise.resolve();
        }, v.prototype.__waitWKWebViewCookie = function(t) {
            var n = this.options;
            n.waitWKWebViewCookieFn && n.H5Request && e.webkit && e.webkit.messageHandlers ? n.waitWKWebViewCookieFn(t) : t();
        }, v.prototype.__processToken = function(e) {
            var t = this, n = this.params, r = this.options;
            return r.token && delete r.token, u.then(function() {
                return t.__getTokenFromCookie();
            }).then(e).then(function() {
                var e = r.retJson, o = e.ret;
                if ((0, s.isArray)(o) && (o = o.join(",")), o.indexOf("TOKEN_EMPTY") > -1 || !0 === r.CDR && o.indexOf("ILLEGAL_ACCESS") > -1 || "2.0" === n.SV && o.indexOf("TOKEN_ILLEGAL") > -1 || o.indexOf("TOKEN_EXOIRED") > -1) {
                    if (r.maxRetryTimes = r.maxRetryTimes || 5, r.failTimes = r.failTimes || 0, r.H5Request && ++r.failTimes < r.maxRetryTimes) return t.__sequence([ t.__waitWKWebViewCookie, t.__processToken, t.__processRequestUrl, t.middlewares, t.__processRequest ]);
                    e.retType = g.TOKEN_EXPIRED;
                }
            });
        }, v.prototype.__ykH5Request = function(e, t) {
            var n = t.querystring;
            if (t.sign) switch (sign) {
              case "md5":
                var r = (0, i.createSign)(e.data, "411081201906011200");
                e.headers = {
                    source: (0, i.getEnv)().env || "",
                    timestamp: "411081201906011200",
                    sign: r,
                    "Content-Type": "application/json"
                };
                break;

              case "proxy":
                n.sign = (0, i.aesEncrypt)(n);
            }
        }, v.prototype.__processRequestUrl = function(t) {
            var n = this.params, a = this.options;
            if (a.hostSetting && a.hostSetting[e.location.hostname]) {
                var i = a.hostSetting[e.location.hostname];
                i.prefix && (a.prefix = i.prefix), i.subDomain && (a.subDomain = i.subDomain), i.mainDomain && (a.mainDomain = i.mainDomain);
            }
            if (n.ykH5Request && (a.path = n.api), !0 === a.H5Request && !n.ykH5Request) {
                var s = "https://" + (a.prefix ? a.prefix + "." : "") + (a.subDomain ? a.subDomain + "." : "") + a.mainDomain + "/h5/" + n.api.toLowerCase() + "/" + n.v.toLowerCase() + "/", u = n.appKey || ("waptest" === a.subDomain ? "4272" : "12574478"), p = new Date().getTime(), c = {
                    jsv: "2.4.12",
                    appKey: u,
                    t: p
                }, f = {
                    data: n.data,
                    ua: n.ua
                };
                "2.0" === n.SV && (s += "2.0/", c.sign = (0, o.default)(a.token + "&" + p + "&" + u + "&" + n.data), 
                c.c = l("_m_h5_c2")), "3.0" === n.SV && (s += "3.0/"), Object.keys(n).forEach(function(e) {
                    void 0 === c[e] && void 0 === f[e] && "headers" !== e && "ext_headers" !== e && "ext_querys" !== e && (c[e] = n[e]);
                }), n.ext_querys && Object.keys(n.ext_querys).forEach(function(e) {
                    c[e] = n.ext_querys[e];
                }), a.getJSONP ? c.type = "jsonp" : a.getOriginalJSONP ? c.type = "originaljsonp" : (a.getJSON || a.postJSON) && (c.type = "originaljson"), 
                void 0 !== n.valueType && ("original" === n.valueType ? a.getJSONP || a.getOriginalJSONP ? c.type = "originaljsonp" : (a.getJSON || a.postJSON) && (c.type = "originaljson") : "string" === n.valueType && (a.getJSONP || a.getOriginalJSONP ? c.type = "jsonp" : (a.getJSON || a.postJSON) && (c.type = "json"))), 
                !0 === a.useJsonpResultType && "originaljson" === c.type && delete c.type, a.dangerouslySetProtocol && (s = a.dangerouslySetProtocol + ":" + s), 
                c.SV && delete c.SV, a.querystring = c, a.postdata = f, a.path = s;
            }
            a.$loginClient ? a.$loginClient.getSession(function(e) {
                if ("wx" == r.p_pf || "my" == r.p_pf) {
                    if (e.ptoken) {
                        var o = JSON.stringify(e);
                        n.ext_headers ? n.ext_headers["x-smallstc"] = o : n.headers ? n.headers["x-smallstc"] = o : n.ext_headers = {
                            "x-smallstc": o
                        }, n.ykH5Request && (n.data = JSON.stringify(Object.assign(JSON.parse(n.data || ""), e)));
                    }
                    t();
                } else {
                    if (e.cookie2) {
                        var a = JSON.stringify(e);
                        n.ext_headers ? n.ext_headers["x-smallstc"] = a : n.headers ? n.headers["x-smallstc"] = a : n.ext_headers = {
                            "x-smallstc": a
                        };
                    }
                    t();
                }
            }) : t();
        }, v.prototype.__processUnitPrefix = function(e) {
            e();
        }, v.prototype.__requestJSON = function(e) {
            var t, n, o = p(), a = this.params, i = this.options, s = i.path + "?" + f(i.querystring);
            if (a.ykH5Request) if (this.__ykH5Request(a, i), a.type && "GET" == a.type.toUpperCase()) {
                t = "GET";
                var u = s.endsWith("?") ? "" : "&";
                s += u + f(JSON.parse(a.data));
            } else a.type && "POST" == a.type.toUpperCase() && (t = "POST", n = f(JSON.parse(a.data)));
            if (i.getJSON && !a.ykH5Request ? (t = "GET", s += "&" + f(i.postdata)) : i.postJSON && (t = "POST", 
            n = f(i.postdata)), "3.0" === a.SV && i.$signClient) {
                var c = i.$signClient.getSign(f(i.querystring), n);
                s += "&sign=" + encodeURIComponent(c);
            }
            return r && "my" == r.p_pf ? my.httpRequest({
                url: s,
                method: t,
                data: n || {},
                headers: Object.assign({
                    Accept: "application/json",
                    "x-tap": "ap",
                    "Content-type": "application/x-www-form-urlencoded"
                }, a.ext_headers || a.headers || {}),
                success: function(t) {
                    var n = t;
                    try {
                        n = t.data, i.results = [ n ], o.resolve();
                    } catch (n) {
                        "200" !== t.statusCode ? e(i.abortErrMsg || "ABORT::接口异常退出") : e("PARSE_JSON_ERROR::解析JSON失败");
                    }
                },
                fail: function(t) {
                    e(i.abortErrMsg || "ABORT::接口异常退出");
                }
            }) : r.platform.request({
                url: s,
                method: t,
                data: n || {},
                header: Object.assign({
                    Accept: "application/json",
                    "x-tap": r.p_pf,
                    "Content-type": "application/x-www-form-urlencoded"
                }, a.ext_headers || a.headers || {}),
                success: function(t) {
                    var n = t, r = t.header || "";
                    try {
                        (n = t.data).responseHeaders = r, i.results = [ n ], o.resolve();
                    } catch (t) {
                        e("PARSE_JSON_ERROR::解析JSON失败");
                    }
                },
                fail: function(t) {
                    e(i.abortErrMsg || "ABORT::接口异常退出");
                }
            }), o.promise;
        }, v.prototype.__processRequest = function(e, t) {
            var n = this;
            return u.then(function() {
                return n.options, n.__requestJSON(t);
            }).then(e).then(function() {
                var e = n.options, t = n.params, o = e.results[0], a = t.ykH5Request && o.success ? "SUCCESS" : o && o.ret || [];
                o.ret = a, (0, s.isArray)(a) && (a = a.join(","));
                var i, u, p = o.c;
                "2.0" === t.SV && p && (i = "_m_h5_c2", u = p, e.pageDomain, "wx" == r.p_pf ? r && r.platform && r.platform.setStorageSync(i, u) : m[i] = u), 
                a.indexOf("SUCCESS") > -1 ? o.retType = g.SUCCESS : o.retType = g.ERROR, e.retJson = o;
            });
        }, v.prototype.__sequence = function(e) {
            var t = this, n = [], r = [];
            e.forEach(function e(o) {
                if ((0, s.isArray)(o)) o.forEach(e); else {
                    var a, i = p(), u = p();
                    n.push(function() {
                        return i = p(), (a = o.call(t, function(e) {
                            return i.resolve(e), u.promise;
                        }, function(e) {
                            return i.reject(e), u.promise;
                        })) && (a = a.catch(function(e) {
                            i.reject(e);
                        })), i.promise;
                    }), r.push(function(e) {
                        return u.resolve(e), a;
                    });
                }
            });
            for (var o, a = u; o = n.shift(); ) a = a.then(o);
            for (;o = r.pop(); ) a = a.then(o);
            return a;
        };
        var h = function(e) {
            e();
        }, b = function(e) {
            e();
        };
        v.prototype.request = function(e) {
            var t = this;
            this.options = c(e || {}, d);
            var n = Promise.resolve([ h, b ]).then(function(e) {
                var n = e[0], r = e[1];
                return t.__sequence([ n, t.__processRequestMethod, t.__processRequestType, t.__processToken, t.__processRequestUrl, t.middlewares, t.__processRequest, r ]);
            }).then(function() {
                var e = t.options.retJson;
                return e.retType !== g.SUCCESS ? Promise.reject(e) : t.options.successCallback ? void t.options.successCallback(e) : Promise.resolve(e);
            }).catch(function(e) {
                var n;
                if (e instanceof Error ? (console.error(e.stack), n = {
                    ret: [ e.message ],
                    stack: [ e.stack ],
                    retJson: g.ERROR
                }) : n = "string" == typeof e ? {
                    ret: [ e ],
                    retJson: g.ERROR
                } : void 0 !== e ? e : t.options.retJson, !t.options.failureCallback) return Promise.reject(n);
                t.options.failureCallback(n);
            });
            return this.__processRequestType(), t.options.H5Request && (t.constructor.__firstProcessor || (t.constructor.__firstProcessor = n), 
            h = function(e) {
                t.constructor.__firstProcessor.then(e).catch(e);
            }), n;
        }, n.mtop = function(e) {
            return new v(e);
        }, n.mtop.request = function(e, t, n) {
            var r = {
                H5Request: e.H5Request,
                successCallback: t,
                failureCallback: n || t
            };
            return new v(e).request(r);
        }, n.mtop.middlewares = y, n.mtop.config = d, n.mtop.RESPONSE_TYPE = g, n.mtop.CLASS = v, 
        t && (t.exports = {
            mtop: n.mtop
        });
    }(window || (window = {}), window.lib || (window.lib = {}), r.default);
}, function(e) {
    return r({
        "./../adapter/api": 1684229349925,
        "../npm/md5": 1684229349927,
        "../utils/utils": 1684229349926
    }[e], e);
}), n(1684229349925, function(e, t, n) {
    Object.defineProperty(n, "__esModule", {
        value: !0
    }), n.default = void 0;
    var r = e("../utils/utils"), o = (0, r.getPlatform)(), a = (0, r.getPlatformType)(), i = "alipay_mini_program" === a || "dingtalk_mini_program" === a || "taobao_mini_program" === a;
    function s(e) {
        var t = "";
        switch (e) {
          case "weixin_mini_program":
            t = "wx";
            break;

          case "baidu_mini_program":
            t = "bd";
            break;

          case "toutiao_mini_program":
            t = "tt";
            break;

          case "douyin_mini_program":
            t = "dy";
            break;

          case "alipay_mini_program":
            t = "my";
            break;

          case "taobao_mini_program":
            t = "tb";
            break;

          case "dingtalk_mini_program":
            t = "dd";
        }
        return t;
    }
    s(a);
    var u = {
        platform: o,
        platformType: a,
        p_pf: s(a),
        fetch: function(e) {
            return new Promise(function(t, n) {
                if (e.url) {
                    e.method ? e.method = e.method.toUpperCase() : e.method = "GET", /^post|put$/i.test(e.method.toLocaleLowerCase()) && (e.headers = Object.assign({}, {
                        "Content-Type": "application/x-www-form-urlencoded"
                    }, e.headers));
                    var r = e.success, o = e.fail;
                    e.success = function(n) {
                        n = Object.assign({
                            requestConfig: e
                        }, n), "function" == typeof r && r.call(this, n), t(n);
                    }, e.fail = function(t) {
                        t = Object.assign({
                            requestConfig: e
                        }, t), "function" == typeof o && o.call(this, t), n(t);
                    };
                    var a, i = {
                        weixin_mini_program: function() {
                            wx.request(e);
                        },
                        alipay_mini_program: function() {
                            e.headers = {
                                "Content-Type": "application/json"
                            }, e.data = JSON.stringify(e.data), my.canIUse("request") ? my.request(e) : my.httpRequest(e);
                        },
                        taobao_mini_program: function() {
                            e.data = JSON.stringify(e.data), e.headers = {
                                "Content-Type": "application/json"
                            }, my.canIUse("request") ? my.request(e) : my.httpRequest(e);
                        },
                        dingtalk_mini_program: function() {
                            my.httpRequest(e);
                        },
                        baidu_mini_program: function() {
                            swan.request(e);
                        },
                        toutiao_mini_program: function() {
                            tt.request(e);
                        },
                        douyin_mini_program: function() {
                            tt.request(e);
                        }
                    };
                    if ("undefined" != typeof my && "function" == typeof my.getAuthCode) {
                        var s = navigator && (navigator.userAgent || navigator.swuserAgent);
                        s.match(/AliApp.(TB)/) ? a = "taobao_mini_program" : s.match(/AliApp.(AP)/) && (a = "alipay_mini_program");
                    }
                    return i[a] || console.error("no available request adapter for current platform"), 
                    i[a]();
                }
                n(new Error("no url"));
            });
        },
        setStorageSync: function(e, t) {
            i ? o.setStorageSync({
                key: e,
                data: t
            }) : o.setStorageSync(e, t);
        },
        getStorageSync: function(e) {
            return i ? o.getStorageSync({
                key: e
            }).data : o.getStorageSync(e);
        },
        removeStorageSync: function(e) {
            i ? o.removeStorageSync({
                key: e
            }) : o.removeStorageSync(e);
        },
        toast: function(e) {
            i ? o.showToast({
                content: e
            }) : o.showToast({
                title: e,
                icon: "none"
            });
        },
        navigateTo: function(e) {
            o.navigateTo({
                url: e
            });
        }
    };
    n.default = u;
}, function(e) {
    return r({
        "../utils/utils": 1684229349926
    }[e], e);
}), n(1684229349926, function(e, t, n) {
    Object.defineProperty(n, "__esModule", {
        value: !0
    }), n.getPlatform = function() {
        return "undefined" != typeof tt && "function" == typeof tt.login ? tt : "undefined" != typeof wx && "function" == typeof wx.login ? wx : "undefined" != typeof swan && "function" == typeof swan.login ? swan : "undefined" != typeof my && "function" == typeof my.getAuthCode ? my : "undefined" != typeof dd && "function" == typeof dd.getAuthCode ? dd : (console.error("no available for current platform"), 
        null);
    }, n.getPlatformType = a, n.getEnv = s, n.aesEncrypt = function(e) {
        var t = o.enc.Utf8.parse("zCqR#q4PxCv4xGzY"), n = Object.keys(e).sort() || [], r = {};
        n.length > 0 && n.forEach(function(t) {
            r[t] = e[t];
        });
        var a = o.AES.encrypt(JSON.stringify(e), t, {
            mode: o.mode.ECB,
            padding: o.pad.Pkcs7,
            iv: ""
        });
        return encodeURIComponent(a.toString());
    }, n.createSign = function(e, t) {
        var n = s(), o = e;
        return n.env ? ("[object,object]" === {}.toString.call(e) && (o = JSON.stringify(e)), 
        (0, r.default)("".concat(o + t).concat(n.key))) : null;
    };
    var r = function(e) {
        return e && e.__esModule ? e : {
            default: e
        };
    }(e("../npm/md5")), o = e("crypto-js");
    function a() {
        if ("undefined" != typeof my && "function" == typeof my.getAuthCode) {
            var e = navigator && (navigator.userAgent || navigator.swuserAgent);
            if (e.match(/AliApp.(TB)/)) return "taobao_mini_program";
            if (e.match(/AliApp.(AP)/)) return "alipay_mini_program";
        }
        if ("undefined" != typeof tt && "function" == typeof tt.login) return tt.getSystemInfoSync && "douyin" === tt.getSystemInfoSync.appName ? "douyin_mini_program" : "toutiao_mini_program";
        if ("undefined" != typeof wx && "function" == typeof wx.login) return "weixin_mini_program";
        if ("undefined" != typeof swan && "function" == typeof swan.login) return "baidu_mini_program";
        if ("undefined" != typeof dd && "function" == typeof dd.getAuthCode) return "dingtalk_mini_program";
        if ("undefined" != typeof my && "function" == typeof my.getAuthCode) {
            var t = my.getSystemInfoSync();
            return "alipay" == (t.app || t.appName) ? "alipay_mini_program" : "taobao_mini_program";
        }
    }
    var i = function(e, t, n) {
        return t in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e;
    }({
        alipay_mini_program: {
            env: "zhifubao",
            key: "YOUKUWEIXINXIAOCHENGXU"
        },
        taobao_mini_program: {
            env: "taobao",
            key: "YOUKUQINGYINGYONG"
        },
        weixin_mini_program: {
            env: "weixin",
            key: ""
        },
        toutiao_mini_program: {
            env: "toutiao",
            key: ""
        },
        douyin_mini_program: {
            env: " douyin",
            key: ""
        },
        baidu_mini_program: {
            env: " baidu",
            key: ""
        }
    }, "baidu_mini_program", {
        env: " baidu",
        key: ""
    });
    function s() {
        return i[a()] || {};
    }
}, function(e) {
    return r({
        "../npm/md5": 1684229349927
    }[e], e);
}), n(1684229349927, function(e, t, n) {
    Object.defineProperty(n, "__esModule", {
        value: !0
    }), n.default = void 0;
    var r = function(e) {
        function t(e, t) {
            return e << t | e >>> 32 - t;
        }
        function n(e, t) {
            var n, r, o, a, i;
            return o = 2147483648 & e, a = 2147483648 & t, i = (1073741823 & e) + (1073741823 & t), 
            (n = 1073741824 & e) & (r = 1073741824 & t) ? 2147483648 ^ i ^ o ^ a : n | r ? 1073741824 & i ? 3221225472 ^ i ^ o ^ a : 1073741824 ^ i ^ o ^ a : i ^ o ^ a;
        }
        function r(e, r, o, a, i, s, u) {
            return e = n(e, n(n(function(e, t, n) {
                return e & t | ~e & n;
            }(r, o, a), i), u)), n(t(e, s), r);
        }
        function o(e, r, o, a, i, s, u) {
            return e = n(e, n(n(function(e, t, n) {
                return e & n | t & ~n;
            }(r, o, a), i), u)), n(t(e, s), r);
        }
        function a(e, r, o, a, i, s, u) {
            return e = n(e, n(n(function(e, t, n) {
                return e ^ t ^ n;
            }(r, o, a), i), u)), n(t(e, s), r);
        }
        function i(e, r, o, a, i, s, u) {
            return e = n(e, n(n(function(e, t, n) {
                return t ^ (e | ~n);
            }(r, o, a), i), u)), n(t(e, s), r);
        }
        function s(e) {
            var t, n = "", r = "";
            for (t = 0; t <= 3; t++) n += (r = "0" + (e >>> 8 * t & 255).toString(16)).substr(r.length - 2, 2);
            return n;
        }
        var u, p, c, f, m, l, d, y, g, _;
        for (u = function(e) {
            for (var t, n = e.length, r = n + 8, o = 16 * ((r - r % 64) / 64 + 1), a = new Array(o - 1), i = 0, s = 0; s < n; ) i = s % 4 * 8, 
            a[t = (s - s % 4) / 4] = a[t] | e.charCodeAt(s) << i, s++;
            return i = s % 4 * 8, a[t = (s - s % 4) / 4] = a[t] | 128 << i, a[o - 2] = n << 3, 
            a[o - 1] = n >>> 29, a;
        }(e = function(e) {
            e = e.replace(/\r\n/g, "\n");
            for (var t = "", n = 0; n < e.length; n++) {
                var r = e.charCodeAt(n);
                r < 128 ? t += String.fromCharCode(r) : r > 127 && r < 2048 ? (t += String.fromCharCode(r >> 6 | 192), 
                t += String.fromCharCode(63 & r | 128)) : (t += String.fromCharCode(r >> 12 | 224), 
                t += String.fromCharCode(r >> 6 & 63 | 128), t += String.fromCharCode(63 & r | 128));
            }
            return t;
        }(e)), d = 1732584193, y = 4023233417, g = 2562383102, _ = 271733878, p = 0; p < u.length; p += 16) c = d, 
        f = y, m = g, l = _, d = r(d, y, g, _, u[p + 0], 7, 3614090360), _ = r(_, d, y, g, u[p + 1], 12, 3905402710), 
        g = r(g, _, d, y, u[p + 2], 17, 606105819), y = r(y, g, _, d, u[p + 3], 22, 3250441966), 
        d = r(d, y, g, _, u[p + 4], 7, 4118548399), _ = r(_, d, y, g, u[p + 5], 12, 1200080426), 
        g = r(g, _, d, y, u[p + 6], 17, 2821735955), y = r(y, g, _, d, u[p + 7], 22, 4249261313), 
        d = r(d, y, g, _, u[p + 8], 7, 1770035416), _ = r(_, d, y, g, u[p + 9], 12, 2336552879), 
        g = r(g, _, d, y, u[p + 10], 17, 4294925233), y = r(y, g, _, d, u[p + 11], 22, 2304563134), 
        d = r(d, y, g, _, u[p + 12], 7, 1804603682), _ = r(_, d, y, g, u[p + 13], 12, 4254626195), 
        g = r(g, _, d, y, u[p + 14], 17, 2792965006), d = o(d, y = r(y, g, _, d, u[p + 15], 22, 1236535329), g, _, u[p + 1], 5, 4129170786), 
        _ = o(_, d, y, g, u[p + 6], 9, 3225465664), g = o(g, _, d, y, u[p + 11], 14, 643717713), 
        y = o(y, g, _, d, u[p + 0], 20, 3921069994), d = o(d, y, g, _, u[p + 5], 5, 3593408605), 
        _ = o(_, d, y, g, u[p + 10], 9, 38016083), g = o(g, _, d, y, u[p + 15], 14, 3634488961), 
        y = o(y, g, _, d, u[p + 4], 20, 3889429448), d = o(d, y, g, _, u[p + 9], 5, 568446438), 
        _ = o(_, d, y, g, u[p + 14], 9, 3275163606), g = o(g, _, d, y, u[p + 3], 14, 4107603335), 
        y = o(y, g, _, d, u[p + 8], 20, 1163531501), d = o(d, y, g, _, u[p + 13], 5, 2850285829), 
        _ = o(_, d, y, g, u[p + 2], 9, 4243563512), g = o(g, _, d, y, u[p + 7], 14, 1735328473), 
        d = a(d, y = o(y, g, _, d, u[p + 12], 20, 2368359562), g, _, u[p + 5], 4, 4294588738), 
        _ = a(_, d, y, g, u[p + 8], 11, 2272392833), g = a(g, _, d, y, u[p + 11], 16, 1839030562), 
        y = a(y, g, _, d, u[p + 14], 23, 4259657740), d = a(d, y, g, _, u[p + 1], 4, 2763975236), 
        _ = a(_, d, y, g, u[p + 4], 11, 1272893353), g = a(g, _, d, y, u[p + 7], 16, 4139469664), 
        y = a(y, g, _, d, u[p + 10], 23, 3200236656), d = a(d, y, g, _, u[p + 13], 4, 681279174), 
        _ = a(_, d, y, g, u[p + 0], 11, 3936430074), g = a(g, _, d, y, u[p + 3], 16, 3572445317), 
        y = a(y, g, _, d, u[p + 6], 23, 76029189), d = a(d, y, g, _, u[p + 9], 4, 3654602809), 
        _ = a(_, d, y, g, u[p + 12], 11, 3873151461), g = a(g, _, d, y, u[p + 15], 16, 530742520), 
        d = i(d, y = a(y, g, _, d, u[p + 2], 23, 3299628645), g, _, u[p + 0], 6, 4096336452), 
        _ = i(_, d, y, g, u[p + 7], 10, 1126891415), g = i(g, _, d, y, u[p + 14], 15, 2878612391), 
        y = i(y, g, _, d, u[p + 5], 21, 4237533241), d = i(d, y, g, _, u[p + 12], 6, 1700485571), 
        _ = i(_, d, y, g, u[p + 3], 10, 2399980690), g = i(g, _, d, y, u[p + 10], 15, 4293915773), 
        y = i(y, g, _, d, u[p + 1], 21, 2240044497), d = i(d, y, g, _, u[p + 8], 6, 1873313359), 
        _ = i(_, d, y, g, u[p + 15], 10, 4264355552), g = i(g, _, d, y, u[p + 6], 15, 2734768916), 
        y = i(y, g, _, d, u[p + 13], 21, 1309151649), d = i(d, y, g, _, u[p + 4], 6, 4149444226), 
        _ = i(_, d, y, g, u[p + 11], 10, 3174756917), g = i(g, _, d, y, u[p + 2], 15, 718787259), 
        y = i(y, g, _, d, u[p + 9], 21, 3951481745), d = n(d, c), y = n(y, f), g = n(g, m), 
        _ = n(_, l);
        return (s(d) + s(y) + s(g) + s(_)).toLowerCase();
    };
    n.default = r;
}, function(e) {
    return r({}[e], e);
}), n(1684229349928, function(e, t, n) {
    Object.defineProperty(n, "__esModule", {
        value: !0
    }), n.default = void 0;
    var r = c(e("@ali/universal-mtop")), i = c(e("./getBuName")), s = e("@ali/mini-util"), u = function(e, t) {
        if (!t && e && e.__esModule) return e;
        if (null === e || "object" !== a(e) && "function" != typeof e) return {
            default: e
        };
        var n = p(t);
        if (n && n.has(e)) return n.get(e);
        var r = {}, o = Object.defineProperty && Object.getOwnPropertyDescriptor;
        for (var i in e) if ("default" !== i && Object.prototype.hasOwnProperty.call(e, i)) {
            var s = o ? Object.getOwnPropertyDescriptor(e, i) : null;
            s && (s.get || s.set) ? Object.defineProperty(r, i, s) : r[i] = e[i];
        }
        return r.default = e, n && n.set(e, r), r;
    }(e("./hsf"));
    function p(e) {
        if ("function" != typeof WeakMap) return null;
        var t = new WeakMap(), n = new WeakMap();
        return (p = function(e) {
            return e ? n : t;
        })(e);
    }
    function c(e) {
        return e && e.__esModule ? e : {
            default: e
        };
    }
    function f(e, t, n, r, o, a, i) {
        try {
            var s = e[a](i), u = s.value;
        } catch (e) {
            return void n(e);
        }
        s.done ? t(u) : Promise.resolve(u).then(r, o);
    }
    function m(e) {
        return function() {
            var t = this, n = arguments;
            return new Promise(function(r, o) {
                var a = e.apply(t, n);
                function i(e) {
                    f(a, r, o, i, s, "next", e);
                }
                function s(e) {
                    f(a, r, o, i, s, "throw", e);
                }
                i(void 0);
            });
        };
    }
    var l = (0, s.parseUrlParam)(window.location.href), d = {
        daily: 4272,
        pre: 24679788,
        release: 24679788
    }, y = {
        daily: "daily-acs",
        pre: "pre-acs",
        release: "acs"
    }, g = {
        "mtop.youku.hollywood.api.page.get.v2": "youku"
    };
    function _(e, t) {
        if ("damai" === e) {
            var n = {
                waptest: {
                    sub: "mtop",
                    main: "damai.test"
                },
                wapa: {
                    sub: "pre-mtop",
                    main: "damai.cn"
                },
                m: {
                    sub: "mtop",
                    main: "damai.cn"
                }
            };
            if (!location.host.includes("taobao")) {
                var o = (p = "m", "waptest" === t || -1 !== location.host.indexOf("waptest") ? p = "waptest" : "wapa" !== t && -1 === location.host.indexOf("wapa") || (p = "wapa"), 
                n[p]);
                r.default.config("subDomain", o.sub), r.default.config("mainDomain", o.main), r.default.config("prefix", ""), 
                location.host.indexOf("damai.cn") >= 0 && r.default.config("pageDomain", o.main);
            }
        } else if ("taopiaopiao" === e || "bendishenghuo" === e) {
            var a = window.location.host, i = a.search(/\btaopiaopiao\.com\b/i) > -1, s = "waptest" === t || a.search(/\.waptest\./i) > -1, u = "wapa" === t || a.search(/\.wapa\.|\bpre-tpp-act\b/i) > -1;
            r.default.config("mainDomain", i ? "taopiaopiao.com" : "taobao.com"), r.default.config("subDomain", s ? "waptest" : u ? "wapa" : "m"), 
            r.default.config("prefix", y[t] || y.release);
        } else r.default.config("subDomain", ""), r.default.config("mainDomain", "youku.com"), 
        r.default.config("prefix", y[t] || y.release);
        var p;
    }
    var v = function() {
        var e, t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, n = arguments.length > 1 ? arguments[1] : void 0;
        if (window.isServer) return console.log("调用requestHsf方法!"), new Promise((e = m(o.default.mark(function e(r, a) {
            var i, s;
            return o.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.prev = 0, e.next = 3, (0, u.default)(t, n);

                  case 3:
                    i = e.sent, s = (0, u.processResult)(i), r(s), e.next = 11;
                    break;

                  case 8:
                    e.prev = 8, e.t0 = e.catch(0), a(e.t0);

                  case 11:
                  case "end":
                    return e.stop();
                }
            }, e, null, [ [ 0, 8 ] ]);
        })), function(t, n) {
            return e.apply(this, arguments);
        }));
        var s = {};
        t.data ? s = t.data : t.bizType && t.bizParam ? s = {
            bizType: t.bizType,
            bizParam: "object" === a(t.bizParam) ? JSON.stringify(t.bizParam) : t.bizParam
        } : t.req && (s = {
            req: "object" === a(t.req) ? JSON.stringify(t.req) : t.req
        });
        var p = l.env;
        t.env && (p = t.env), (s.asac || t.asac) && (s.asac = s.asac || t.asac), (s.ua || t.ua) && (s.ua = s.ua || t.ua);
        var c = {
            api: t.api,
            v: t.v || "1.0",
            ecode: t.ecode || 0,
            appKey: d[p] || d.release,
            type: t.type || "GET",
            isSec: t.isSec || 0,
            dataType: t.dataType || "jsonp",
            timeout: t.timeout || 1e4,
            data: s
        };
        t.WindVaneRequest && (c.WindVaneRequest = !0), t.H5Request && (c.H5Request = !0), 
        l.waptest_project_id && (c.tb_eagleeyex_scm_project = l.waptest_project_id);
        var f = g[t.api] || (0, i.default)();
        return _(f, p), new Promise(function(e, t) {
            r.default.request(c, function(t) {
                e(t);
            }, function(e) {
                t(e);
            });
        });
    };
    n.default = v;
}, function(e) {
    return r({
        "./getBuName": 1684229349929,
        "./hsf": 1684229349930
    }[e], e);
}), n(1684229349929, function(e, t, n) {
    Object.defineProperty(n, "__esModule", {
        value: !0
    }), n.default = function() {
        var e = "", t = window.globalConfig || {}, n = {}.base, o = void 0 === n ? {} : n;
        if (o.globalConfig) try {
            t = "string" == typeof o.globalConfig ? JSON.parse(o.globalConfig) : o.globalConfig;
        } catch (e) {}
        if (r.buName) e = r.buName; else if (t.buName) e = t.buName; else {
            var a = location.host;
            a.includes("youku.com") ? e = "youku" : a.includes("damai.cn") ? e = "damai" : a.includes("taopiaopiao.com") && (e = "taopiaopiao");
        }
        return e;
    };
    var r = (0, e("@ali/mini-util").parseUrlParam)(window.location.href);
}, function(e) {
    return r({}[e], e);
}), n(1684229349930, function(e, t, n) {
    Object.defineProperty(n, "__esModule", {
        value: !0
    }), n.processResult = function(e) {
        if ("string" == typeof e) try {
            e = JSON.parse(e);
        } catch (e) {}
        if (!e.success) throw e.msgCode || e.msgInfo || "HSF ERROR";
        var t = e.model || e.res && e.res.model, n = {};
        return (0, r.isObject)(t) ? n.data = t : n.data = {
            result: t
        }, console.log("processResult res:", n), n;
    }, n.default = void 0;
    var r = e("@ali/mini-util");
    function i(e, t, n, r, o, a, i) {
        try {
            var s = e[a](i), u = s.value;
        } catch (e) {
            return void n(e);
        }
        s.done ? t(u) : Promise.resolve(u).then(r, o);
    }
    function s(e) {
        return function() {
            var t = this, n = arguments;
            return new Promise(function(r, o) {
                var a = e.apply(t, n);
                function s(e) {
                    i(a, r, o, s, u, "next", e);
                }
                function u(e) {
                    i(a, r, o, s, u, "throw", e);
                }
                s(void 0);
            });
        };
    }
    function u() {
        return (u = s(o.default.mark(function e() {
            var t, n, r, a, i, s, u, f, m, l, d, y, g, _, v, h, b, S, w, O, x, k, q, C, R, P, T = arguments;
            return o.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (t = T.length > 0 && void 0 !== T[0] ? T[0] : {}, n = T.length > 1 ? T[1] : void 0, 
                    window.isServer && n && n.hsfClient) {
                        e.next = 4;
                        break;
                    }
                    return e.abrupt("return", new Promise(function(e, t) {
                        t("The requestHsf method must be in sff runtime!");
                    }));

                  case 4:
                    if (r = c(t), a = t.v || "1.0", i = n.apiMappingList || [], s = i.find(function(e) {
                        return e.api === t.api && e.version === a;
                    })) {
                        e.next = 10;
                        break;
                    }
                    return e.abrupt("return", new Promise(function(e, t) {
                        t("mtop config not find!");
                    }));

                  case 10:
                    return u = n.userInfo, f = u.userNumbId, m = void 0 === f ? 0 : f, l = u.usernick, 
                    d = {
                        userNumbId: m,
                        usernick: void 0 === l ? "" : l
                    }, y = s.hsfConfig || {}, g = y.version, _ = void 0 === g ? {} : g, v = y.group, 
                    h = y.method, b = y.paramList, S = void 0 === b ? [] : b, w = y.isYoukuEnv, O = void 0 === w || w, 
                    x = _[n.env] || _.daily, k = "".concat(y.api, ":").concat(x), q = S.map(function(e) {
                        return e.paramType;
                    }), C = p(y, r, d), R = {
                        id: k,
                        group: v,
                        method: h,
                        parameterTypes: q,
                        args: C,
                        isYoukuEnv: O
                    }, console.log("requestHsf params:", R), e.next = 22, n.ykHsfInvoke(R);

                  case 22:
                    return P = e.sent, console.log("requestHsf res:", P), e.abrupt("return", P);

                  case 25:
                  case "end":
                    return e.stop();
                }
            }, e);
        }))).apply(this, arguments);
    }
    function p() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {}, r = Object.keys(t), o = Object.keys(n), a = e.apiParam, i = void 0 === a ? {} : a, s = e.paramList, u = void 0 === s ? [] : s, p = {};
        function c(e, a) {
            e.forEach(function(e) {
                if ("api" === e.mapType && r.includes(e.mapField)) {
                    var s = t[e.mapField];
                    if (i[e.mapField] && "Map" === i[e.mapField].paramType) try {
                        s = "string" == typeof s ? JSON.parse(s) : s;
                    } catch (e) {}
                    a[e.paramName] = s;
                } else "mtop" === e.mapType && o.includes(e.mapField) ? a[e.paramName] = n[e.mapField] : e.children && (a[e.paramName] = {}, 
                c(e.children, a[e.paramName]));
            });
        }
        c(u, p);
        var f = u.map(function(e) {
            return p[e.paramName];
        });
        return f;
    }
    function c(e) {
        var t = {};
        return e.data ? t = e.data : e.bizType && e.bizParam ? t = {
            bizType: e.bizType,
            bizParam: "object" === a(e.bizParam) ? JSON.stringify(e.bizParam) : e.bizParam
        } : e.req && (t = {
            req: "object" === a(e.req) ? JSON.stringify(e.req) : e.req
        }), t;
    }
    var f = function() {
        return u.apply(this, arguments);
    };
    n.default = f;
}, function(e) {
    return r({}[e], e);
}), r(1684229349923));