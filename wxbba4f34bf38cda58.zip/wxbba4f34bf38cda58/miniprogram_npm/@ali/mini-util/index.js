var e, t, r, n = require("../../../@babel/runtime/helpers/typeof");

module.exports = (e = {}, r = function(t, r) {
    if (!e[t]) return require(r);
    if (!e[t].status) {
        var i = e[t].m;
        i._exports = i._tempexports;
        var o = Object.getOwnPropertyDescriptor(i, "exports");
        o && o.configurable && Object.defineProperty(i, "exports", {
            set: function(e) {
                "object" === n(e) && e !== i._exports && (i._exports.__proto__ = e.__proto__, Object.keys(e).forEach(function(t) {
                    i._exports[t] = e[t];
                })), i._tempexports = e;
            },
            get: function() {
                return i._tempexports;
            }
        }), e[t].status = 1, e[t].func(e[t].req, i, i.exports);
    }
    return e[t].m.exports;
}, (t = function(t, r, n) {
    e[t] = {
        status: 0,
        func: r,
        req: n,
        m: {
            exports: {},
            _tempexports: {}
        }
    };
})(1684229350075, function(e, t, r) {
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), Object.defineProperty(r, "handleImg", {
        enumerable: !0,
        get: function() {
            return i.handleImg;
        }
    }), Object.defineProperty(r, "checkIfPlayUrl", {
        enumerable: !0,
        get: function() {
            return o.checkIfPlayUrl;
        }
    }), Object.defineProperty(r, "checkIfLiveUrl", {
        enumerable: !0,
        get: function() {
            return o.checkIfLiveUrl;
        }
    }), Object.defineProperty(r, "parsePlayUrl", {
        enumerable: !0,
        get: function() {
            return o.parsePlayUrl;
        }
    }), Object.defineProperty(r, "mergeUrlSearch", {
        enumerable: !0,
        get: function() {
            return o.mergeUrlSearch;
        }
    }), Object.defineProperty(r, "genVideoUrl", {
        enumerable: !0,
        get: function() {
            return o.genVideoUrl;
        }
    }), Object.defineProperty(r, "genShowUrl", {
        enumerable: !0,
        get: function() {
            return o.genShowUrl;
        }
    }), Object.defineProperty(r, "parseUrlParam", {
        enumerable: !0,
        get: function() {
            return o.parseUrlParam;
        }
    }), Object.defineProperty(r, "objToQueryString", {
        enumerable: !0,
        get: function() {
            return o.objToQueryString;
        }
    }), Object.defineProperty(r, "isObject", {
        enumerable: !0,
        get: function() {
            return u.isObject;
        }
    }), Object.defineProperty(r, "isString", {
        enumerable: !0,
        get: function() {
            return u.isString;
        }
    }), Object.defineProperty(r, "isDate", {
        enumerable: !0,
        get: function() {
            return u.isDate;
        }
    }), Object.defineProperty(r, "isArray", {
        enumerable: !0,
        get: function() {
            return u.isArray;
        }
    }), Object.defineProperty(r, "UA", {
        enumerable: !0,
        get: function() {
            return a.UA;
        }
    }), Object.defineProperty(r, "getTagColor", {
        enumerable: !0,
        get: function() {
            return s.getTagColor;
        }
    }), Object.defineProperty(r, "routeTransform", {
        enumerable: !0,
        get: function() {
            return c.routeTransform;
        }
    }), Object.defineProperty(r, "miniEvent", {
        enumerable: !0,
        get: function() {
            return f.default;
        }
    }), Object.defineProperty(r, "getProps", {
        enumerable: !0,
        get: function() {
            return l.getProps;
        }
    });
    var n, i = e("./imgCdn"), o = e("./url"), u = e("./type"), a = e("./ua"), s = e("./getTagColor"), c = e("./routeTransform"), f = (n = e("./event/miniEvent")) && n.__esModule ? n : {
        default: n
    }, l = e("./getProps");
}, function(e) {
    return r({
        "./imgCdn": 1684229350076,
        "./url": 1684229350077,
        "./type": 1684229350078,
        "./ua": 1684229350079,
        "./getTagColor": 1684229350080,
        "./routeTransform": 1684229350081,
        "./event/miniEvent": 1684229350082,
        "./getProps": 1684229350084
    }[e], e);
}), t(1684229350076, function(e, t, r) {
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), r.handleImg = void 0;
    var n = e("./url");
    r.handleImg = function(e, t, r) {
        if (!e) return "";
        var i = "http" == e.substring(0, 4) ? e.replace("http://", "https://") : "https:".concat(e);
        if (t && "NaN" !== parseFloat(t).toString()) {
            var o = "image/resize,m_mfit,w_".concat(t);
            (function(e) {
                var t = !0;
                return e.indexOf(".gif") > -1 && (t = !1), t;
            })(i) && !r && (o += "/format,webp");
            var u = -1 !== i.indexOf("?") ? i.indexOf("?") : i.length, a = i.substring(0, u), s = (0, 
            n.parseUrlParam)(i);
            s["x-oss-process"] = o, i = a + "?" + (0, n.objToQueryString)(s);
        }
        return i;
    };
}, function(e) {
    return r({
        "./url": 1684229350077
    }[e], e);
}), t(1684229350077, function(e, t, r) {
    function n(e, t) {
        var r = Object.keys(e);
        if (Object.getOwnPropertySymbols) {
            var n = Object.getOwnPropertySymbols(e);
            t && (n = n.filter(function(t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
            })), r.push.apply(r, n);
        }
        return r;
    }
    function i(e) {
        for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2 ? n(Object(r), !0).forEach(function(t) {
                o(e, t, r[t]);
            }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : n(Object(r)).forEach(function(t) {
                Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t));
            });
        }
        return e;
    }
    function o(e, t, r) {
        return t in e ? Object.defineProperty(e, t, {
            value: r,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = r, e;
    }
    function u(e) {
        for (var t = -1 !== e.indexOf("?") ? e.indexOf("?") : e.length, r = e ? e.substring(t + 1).split("&") : [], n = {}, i = 0; i < r.length; i++) {
            var o = r[i], u = o.indexOf("=");
            if (-1 !== u) {
                var a = o.substring(0, u), s = o.substring(u + 1);
                a && s && (n[a] = s);
            }
        }
        return n;
    }
    function a(e) {
        return /^http/.test(e);
    }
    function s(e) {
        return a(e) && /v.youku.com\/v_show|m.youku.com\/video/.test(e);
    }
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), r.checkIfHttpUrl = a, r.checkIfWeexUrl = function(e) {
        return a(e) && /wh_weex|_wx_tpl|wxbundle/.test(e);
    }, r.checkIfPureWeexUrl = function(e) {
        return a(e) && /wh_weex=true/.test(e) && !/_wx_tpl|wxbundle/.test(e);
    }, r.checkIfPlayUrl = s, r.genVideoUrl = function(e, t) {
        e = e.replace(/==|id_/gi, "");
        var r = "https://m.youku.com/video/id_".concat(e, "==.html");
        return t && (r += "?playlistId=".concat(t, "&playlist_id=").concat(t, "&f=").concat(t)), 
        r;
    }, r.genShowUrl = function(e) {
        return "https://m.youku.com/video/id_".concat(e, ".html");
    }, r.parsePlayUrl = function(e) {
        var t = {};
        if (!s(e)) return t;
        var r = u(e), n = r.playlistId || r.playlistid || r.playlist_id || r.f;
        n && (t.playlistid = n, t.playlist_id = n);
        var i = e.match(/id_(\w+)=*\.html/)[1];
        return /^X/.test(i) ? t.vid = i : t.showid = i, t;
    }, r.checkIfLiveUrl = function(e) {
        return a(e) && /vku.youku.com\/live\/ilproom/.test(e);
    }, r.parseUrlParam = u, r.mergeUrlSearch = function(e, t) {
        if (!e || !e.split) return "";
        for (var r = e.replace(/\s|[\u200B-\u200D\uFEFF\uFFFC]/g, ""), n = -1 !== r.indexOf("?") ? r.indexOf("?") : r.length, o = r.substring(0, n), u = r.substring(n + 1), a = u ? u.split("&") : [], s = {}, c = 0; c < a.length; c++) {
            var f = a[c], l = f.indexOf("=");
            if (-1 !== l) {
                var p = f.substring(0, l), d = f.substring(l + 1);
                p && d && (s[p] = d);
            }
        }
        for (var g in t) t[g] || 0 === t[g] || delete t[g];
        var b = i(i({}, s), t);
        s.from && (b.from = s.from), s.refer && (b.refer = s.refer);
        var y = Object.keys(b).map(function(e) {
            return "".concat(e, "=").concat(b[e]);
        }).join("&");
        return "".concat(o, "?").concat(y);
    }, r.objToQueryString = function(e) {
        return Object.keys(e).map(function(t) {
            return "".concat(t, "=").concat(e[t]);
        }).join("&");
    };
}, function(e) {
    return r({}[e], e);
}), t(1684229350078, function(e, t, r) {
    function n(e) {
        return function(t) {
            return {}.toString.call(t) === "[object ".concat(e, "]");
        };
    }
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), r.isType = n, r.isArray = r.isDate = r.isString = r.isObject = void 0;
    var i = n("Object");
    r.isObject = i;
    var o = n("String");
    r.isString = o;
    var u = n("Date");
    r.isDate = u;
    var a = n("Array");
    r.isArray = a;
}, function(e) {
    return r({}[e], e);
}), t(1684229350079, function(e, t, r) {
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), r.UA = void 0;
    var n = e("universal-env"), i = (navigator && (navigator.userAgent || navigator.swuserAgent) || "").toLowerCase(), o = /(aliapp)+[\s]*/.test(i), u = {
        isYouku: /youku|yk/.test(i),
        isYoukuHD: /youku_hd|youkuhd/.test(i),
        isDingding: /dingtalk/.test(i),
        isTaobao: /(aliapp)+[\s]*(\([tb]+\/[\d|\.]+\))+/.test(i),
        isTaobaoMiniApp: /aliapp\s*\S*tb|taobao/.test(i),
        isAlipay: /alipay/.test(i),
        isAlipayMiniApp: n.isMiniApp && /alipay/.test(i) && !/MiniProgram/gi.test(i),
        isAlipayMiniAppWebView: /alipay/.test(i) && /MiniProgram/gi.test(i),
        isUC: /ucbrowser/.test(i),
        isTmall: /(aliapp)+[\s]*(\([tm]+\/[\d|\.]+\))+/.test(i),
        isDamai: /(aliapp)+[\s]*(\([dm]+\/[\d|\.]+\))+/.test(i),
        isTaopiaopiao: /(aliapp)+[\s]*(\([dy]+\/[\d|\.]+\))+/.test(i),
        isXianyu: /(aliapp)+[\s]*(\([fm]+\/[\d|\.]+\))+/.test(i),
        isEleme: /(aliapp)+[\s]*(\([elmc]+\/[\d|\.]+\))+/.test(i),
        isFliggy: /(aliapp)+[\s]*(\([lx]+\/[\d|\.]+\))+/.test(i),
        isWeChatMiniProgram: n.isWeChatMiniProgram,
        isWeixin: /micromessenger/.test(i),
        isWechat: /micromessenger/.test(i),
        isQQ: /qq/.test(i),
        isQZone: /qzone/.test(i),
        isQQBrowser: /qqbrowser/.test(i),
        isToutiaoMiniApp: /ToutiaoMicroApp/gi.test(i),
        isWeibo: /weibo/.test(i),
        isAndroid: /android/.test(i),
        isIOS: /ipad|iphone/.test(i),
        isIPhone: /iphone/.test(i),
        isIPad: /ipad/.test(i),
        isWindvane: /windvane/.test(i),
        isAliApp: o
    };
    r.UA = u;
}, function(e) {
    return r({}[e], e);
}), t(1684229350080, function(e, t, r) {
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), r.getTagColor = void 0;
    var n = {
        "VIP, HDR, 会员用券,付费, 会员免费, VIP·半价, 超前点播, VIP·用券": {
            background: "linear-gradient(90deg, #FFC19F 0%, #FFF7D9 100%)",
            color: "#4E2D03"
        },
        "首播, 预约, 预告, 专题, 预告, 播单": {
            background: "linear-gradient(-45deg, #6DE7F3 0%, #4BB5FF 100%)",
            color: "#fff"
        },
        "独播, 直播, 新, 高清经典": {
            background: "linear-gradient(270deg, #FFAB9C 0%, #FF658D 100%)",
            color: "#fff"
        },
        "广告, 回看": {
            background: "rgba(0,0,0,0.60)",
            color: "#fff"
        }
    }, i = {
        background: "linear-gradient(90deg, #FFC19F 0%, #FFF7D9 100%)",
        color: "#fff"
    };
    r.getTagColor = function(e) {
        if ("无" == e) return {};
        for (var t = Object.keys(n), r = t.length, o = 0; o < r; o++) {
            var u = t[o] || "";
            if ((u && u.toString().split(", ") || []).indexOf(e) > -1) return n[u.toString()];
        }
        return i;
    };
}, function(e) {
    return r({}[e], e);
}), t(1684229350081, function(e, t, r) {
    var n = e("./type"), i = n.isObject, o = n.isArray, u = n.isString;
    function a(e) {
        var t = e || {}, r = t.bizString, n = t.action, o = {
            jumpType: "",
            jumpUrl: "",
            value: ""
        };
        if (r && u(r)) {
            var a = JSON.parse(r);
            o.jumpType = a.type, o.jumpUrl = a.extra && a.extra.jumpUrl, o.value = a.extra && a.extra.value;
        } else if (n && i(n)) {
            var s = n;
            o.jumpType = s.type, o.jumpUrl = s.jumpUrl, o.value = s.value;
        }
        return o;
    }
    r.__esModule || Object.defineProperty(r, "__esModule", {
        value: !0
    }), r.routeTransform = function(e) {
        return o(e) && e.length ? e.map(function(e) {
            return a(e);
        }) : i(e) && Object.keys(e).length ? a(e) : void 0;
    };
}, function(e) {
    return r({
        "./type": 1684229350078
    }[e], e);
}), t(1684229350082, function(e, t, r) {
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), r.default = void 0;
    var n, i = (n = e("./Event")) && n.__esModule ? n : {
        default: n
    }, o = null;
    window && (window._miniEvent_NoConflict || (window._miniEvent_NoConflict = new i.default()), 
    o = window.miniEvent = window._miniEvent_NoConflict);
    var u = o;
    r.default = u;
}, function(e) {
    return r({
        "./Event": 1684229350083
    }[e], e);
}), t(1684229350083, function(e, t, r) {
    function n(e, t) {
        for (var r = 0; r < t.length; r++) {
            var n = t[r];
            n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), 
            Object.defineProperty(e, n.key, n);
        }
    }
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), r.default = void 0;
    var i = function() {
        function e() {
            !function(e, t) {
                if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
            }(this, e), this._eventMap = {};
        }
        var t, r, i;
        return t = e, (r = [ {
            key: "on",
            value: function(e, t) {
                return "function" != typeof t || (this._eventMap[e] ? this._eventMap[e].push(t) : this._eventMap[e] = [ t ]), 
                this;
            }
        }, {
            key: "off",
            value: function(e, t) {
                if ("function" != typeof t) return this;
                var r = this._eventMap[e];
                if (r) for (var n = 0; n < r.length; n++) t === r[n] && (r.splice(n, 1), n--);
                return this;
            }
        }, {
            key: "hasEvent",
            value: function(e) {
                return !(!this._eventMap[e] || !this._eventMap[e].length);
            }
        }, {
            key: "fire",
            value: function(e, t) {
                var r = this._eventMap[e];
                if (r) for (var n = 0; n < r.length; n++) {
                    var i = r[n];
                    i && i(t);
                }
                return this;
            }
        }, {
            key: "notify",
            value: function(e, t) {
                var r = this._eventMap[e];
                if (r) for (var n = 0; n < r.length; n++) {
                    var i = r[n];
                    try {
                        i && i(t);
                    } catch (e) {
                        console.error(e);
                    }
                }
                return this;
            }
        }, {
            key: "destroyEvent",
            value: function() {
                return this._eventMap = {}, this;
            }
        }, {
            key: "destroy",
            value: function() {
                this.fire("destroy"), this.destroyEnd();
            }
        }, {
            key: "destroyEnd",
            value: function() {
                var e = this;
                setTimeout(function() {
                    e.fire("destroyEnd"), e.destroyEvent();
                }, 0);
            }
        }, {
            key: "getEventMap",
            value: function() {
                return this._eventMap;
            }
        } ]) && n(t.prototype, r), i && n(t, i), e;
    }();
    r.default = i;
}, function(e) {
    return r({}[e], e);
}), t(1684229350084, function(e, t, r) {
    function n(e, t) {
        var r = Object.keys(e);
        if (Object.getOwnPropertySymbols) {
            var n = Object.getOwnPropertySymbols(e);
            t && (n = n.filter(function(t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable;
            })), r.push.apply(r, n);
        }
        return r;
    }
    function i(e) {
        for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? arguments[t] : {};
            t % 2 ? n(Object(r), !0).forEach(function(t) {
                o(e, t, r[t]);
            }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : n(Object(r)).forEach(function(t) {
                Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t));
            });
        }
        return e;
    }
    function o(e, t, r) {
        return t in e ? Object.defineProperty(e, t, {
            value: r,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = r, e;
    }
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), r.getProps = function(e) {
        var t = e.outerProps;
        return i(i({}, function(e, t) {
            if (null == e) return {};
            var r, n, i = function(e, t) {
                if (null == e) return {};
                var r, n, i = {}, o = Object.keys(e);
                for (n = 0; n < o.length; n++) r = o[n], t.indexOf(r) >= 0 || (i[r] = e[r]);
                return i;
            }(e, t);
            if (Object.getOwnPropertySymbols) {
                var o = Object.getOwnPropertySymbols(e);
                for (n = 0; n < o.length; n++) r = o[n], t.indexOf(r) >= 0 || Object.prototype.propertyIsEnumerable.call(e, r) && (i[r] = e[r]);
            }
            return i;
        }(e, [ "outerProps" ])), t || {});
    };
}, function(e) {
    return r({}[e], e);
}), r(1684229350075));