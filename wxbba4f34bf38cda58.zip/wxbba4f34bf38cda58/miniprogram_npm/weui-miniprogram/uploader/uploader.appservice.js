$gwx_XC_20=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}var __WXML_GLOBAL__={};{
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_20 || [];
function gz$gwx_XC_20_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_20_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_20_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_20_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([a,[3,'weui-uploader '],[[7],[3,'extClass']]])
Z([3,'weui-uploader__hd'])
Z([[2,'>'],[[7],[3,'maxCount']],[1,1]])
Z([[7],[3,'tips']])
Z([3,'tips'])
Z([[2,'<'],[[6],[[7],[3,'currentFiles']],[3,'length']],[[7],[3,'maxCount']]])
Z([3,'deletePic'])
Z([3,'gallery'])
Z([[7],[3,'previewCurrent']])
Z([1,true])
Z([[7],[3,'previewImageUrls']])
Z([[7],[3,'showPreview']])
Z([[7],[3,'showDelete']])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_20_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_20_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_20=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_20=true;
var x=['./miniprogram_npm/weui-miniprogram/uploader/uploader.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_20_1()
var lUE=_n('view')
_rz(z,lUE,'class',0,e,s,gg)
var tWE=_n('view')
_rz(z,tWE,'class',1,e,s,gg)
var eXE=_v()
_(tWE,eXE)
if(_oz(z,2,e,s,gg)){eXE.wxVkey=1
}
var bYE=_v()
_(tWE,bYE)
if(_oz(z,3,e,s,gg)){bYE.wxVkey=1
}
else{bYE.wxVkey=2
var oZE=_n('slot')
_rz(z,oZE,'name',4,e,s,gg)
_(bYE,oZE)
}
eXE.wxXCkey=1
bYE.wxXCkey=1
_(lUE,tWE)
var aVE=_v()
_(lUE,aVE)
if(_oz(z,5,e,s,gg)){aVE.wxVkey=1
}
aVE.wxXCkey=1
_(r,lUE)
var x1E=_mz(z,'mp-gallery',['binddelete',6,'class',1,'current',2,'hideOnClick',3,'imgUrls',4,'show',5,'showDelete',6],[],e,s,gg)
_(r,x1E)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_20";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_20();	if (__vd_version_info__.delayedGwx) __wxAppCode__['miniprogram_npm/weui-miniprogram/uploader/uploader.wxml'] = [$gwx_XC_20, './miniprogram_npm/weui-miniprogram/uploader/uploader.wxml'];else __wxAppCode__['miniprogram_npm/weui-miniprogram/uploader/uploader.wxml'] = $gwx_XC_20( './miniprogram_npm/weui-miniprogram/uploader/uploader.wxml' );
	;__wxRoute = "miniprogram_npm/weui-miniprogram/uploader/uploader";__wxRouteBegin = true;__wxAppCurrentFile__="miniprogram_npm/weui-miniprogram/uploader/uploader.js";define("miniprogram_npm/weui-miniprogram/uploader/uploader.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";var e="function"==typeof Symbol&&"symbol"==typeof Symbol.iterator?function(e){return typeof e}:function(e){return e&&"function"==typeof Symbol&&e.constructor===Symbol&&e!==Symbol.prototype?"symbol":typeof e};module.exports=function(t){function r(e){if(a[e])return a[e].exports;var i=a[e]={i:e,l:!1,exports:{}};return t[e].call(i.exports,i,i.exports,r),i.l=!0,i.exports}var a={};return r.m=t,r.c=a,r.d=function(e,t,a){r.o(e,t)||Object.defineProperty(e,t,{enumerable:!0,get:a})},r.r=function(e){"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})},r.t=function(t,a){if(1&a&&(t=r(t)),8&a)return t;if(4&a&&"object"===(void 0===t?"undefined":e(t))&&t&&t.__esModule)return t;var i=Object.create(null);if(r.r(i),Object.defineProperty(i,"default",{enumerable:!0,value:t}),2&a&&"string"!=typeof t)for(var n in t)r.d(i,n,function(e){return t[e]}.bind(null,n));return i},r.n=function(e){var t=e&&e.__esModule?function(){return e.default}:function(){return e};return r.d(t,"a",t),t},r.o=function(e,t){return Object.prototype.hasOwnProperty.call(e,t)},r.p="",r(r.s=22)}({22:function(e,t,r){Component({options:{addGlobalClass:!0},properties:{title:{type:String,value:"图片上传"},sizeType:{type:Array,value:["original","compressed"]},sourceType:{type:Array,value:["album","camera"]},maxSize:{type:Number,value:5242880},maxCount:{type:Number,value:1},files:{type:Array,value:[],observer:function(e){this.setData({currentFiles:e})}},select:{type:null,value:function(){}},upload:{type:null,value:null},tips:{type:String,value:""},extClass:{type:String,value:""},showDelete:{type:Boolean,value:!0}},data:{currentFiles:[],showPreview:!1,previewImageUrls:[]},ready:function(){},methods:{previewImage:function(e){var t=e.currentTarget.dataset.index,r=[];this.data.files.forEach(function(e){r.push(e.url)}),this.setData({previewImageUrls:r,previewCurrent:t,showPreview:!0})},chooseImage:function(){var e=this;this.uploading||wx.chooseImage({count:this.data.maxCount-this.data.files.length,sizeType:this.data.sizeType,sourceType:this.data.sourceType,success:function(t){var r=-1;if(t.tempFiles.forEach(function(t,a){t.size>e.data.maxSize&&(r=a)}),"function"!=typeof e.data.select||!1!==e.data.select(t))if(r>=0)e.triggerEvent("fail",{type:1,errMsg:"chooseImage:fail size exceed "+e.data.maxSize,total:t.tempFilePaths.length,index:r},{});else{var a=wx.getFileSystemManager(),i=t.tempFilePaths.map(function(e){return a.readFileSync(e)}),n={tempFilePaths:t.tempFilePaths,tempFiles:t.tempFiles,contents:i};e.triggerEvent("select",n,{});var l=t.tempFilePaths.map(function(e,r){return{loading:!0,url:t.tempFilePaths[r]||"data:image/jpg;base64,"+wx.arrayBufferToBase64(i[r])}});if(l&&l.length&&"function"==typeof e.data.upload){var o=e.data.files.length,s=e.data.files.concat(l);e.setData({files:s,currentFiles:s}),e.loading=!0,e.data.upload(n).then(function(t){if(e.loading=!1,t.urls){var r=e.data.files;t.urls.forEach(function(e,t){r[o+t].url=e,r[o+t].loading=!1}),e.setData({files:r,currentFiles:s}),e.triggerEvent("success",t,{})}else e.triggerEvent("fail",{type:3,errMsg:"upload file fail, urls not found"},{})}).catch(function(r){e.loading=!1;var a=e.data.files;t.tempFilePaths.forEach(function(e,t){a[o+t].error=!0,a[o+t].loading=!1}),e.setData({files:a,currentFiles:s}),e.triggerEvent("fail",{type:3,errMsg:"upload file fail",error:r},{})})}}},fail:function(t){t.errMsg.indexOf("chooseImage:fail cancel")>=0?e.triggerEvent("cancel",{},{}):(t.type=2,e.triggerEvent("fail",t,{}))}})},deletePic:function(e){var t=e.detail.index,r=this.data.files,a=r.splice(t,1);this.setData({files:r,currentFiles:r}),this.triggerEvent("delete",{index:t,item:a[0]})}}})}});
},{isPage:false,isComponent:true,currentFile:'miniprogram_npm/weui-miniprogram/uploader/uploader.js'});require("miniprogram_npm/weui-miniprogram/uploader/uploader.js");