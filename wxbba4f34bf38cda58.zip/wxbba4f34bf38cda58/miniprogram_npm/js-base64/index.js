var t, r, e = require("../../@babel/runtime/helpers/typeof");

module.exports = (t = {}, r = function(r, n) {
    if (!t[r]) return require(n);
    if (!t[r].status) {
        var o = t[r].m;
        o._exports = o._tempexports;
        var u = Object.getOwnPropertyDescriptor(o, "exports");
        u && u.configurable && Object.defineProperty(o, "exports", {
            set: function(t) {
                "object" === e(t) && t !== o._exports && (o._exports.__proto__ = t.__proto__, Object.keys(t).forEach(function(r) {
                    o._exports[r] = t[r];
                })), o._tempexports = t;
            },
            get: function() {
                return o._tempexports;
            }
        }), t[r].status = 1, t[r].func(t[r].req, o, o.exports);
    }
    return t[r].m.exports;
}, function(r, e, n) {
    t[r] = {
        status: 0,
        func: e,
        req: n,
        m: {
            exports: {},
            _tempexports: {}
        }
    };
}(1684205641544, function(t, r, n) {
    !function(t, o) {
        var u, i;
        "object" === e(n) && void 0 !== r ? r.exports = o() : "function" == typeof define && define.amd ? define(o) : (u = t.Base64, 
        (i = o()).noConflict = function() {
            return t.Base64 = u, i;
        }, t.Meteor && (Base64 = i), t.Base64 = i);
    }("undefined" != typeof self ? self : "undefined" != typeof window ? window : "undefined" != typeof global ? global : this, function() {
        var t, r = "function" == typeof atob, e = "function" == typeof btoa, n = "function" == typeof Buffer, o = "function" == typeof TextDecoder ? new TextDecoder() : void 0, u = "function" == typeof TextEncoder ? new TextEncoder() : void 0, i = Array.prototype.slice.call("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/="), f = (t = {}, 
        i.forEach(function(r, e) {
            return t[r] = e;
        }), t), c = /^(?:[A-Za-z\d+\/]{4})*?(?:[A-Za-z\d+\/]{2}(?:==)?|[A-Za-z\d+\/]{3}=?)?$/, a = String.fromCharCode.bind(String), s = "function" == typeof Uint8Array.from ? Uint8Array.from.bind(Uint8Array) : function(t) {
            return new Uint8Array(Array.prototype.slice.call(t, 0));
        }, d = function(t) {
            return t.replace(/=/g, "").replace(/[+\/]/g, function(t) {
                return "+" == t ? "-" : "_";
            });
        }, p = function(t) {
            return t.replace(/[^A-Za-z0-9\+\/]/g, "");
        }, l = function(t) {
            for (var r, e, n, o, u = "", f = t.length % 3, c = 0; c < t.length; ) {
                if ((e = t.charCodeAt(c++)) > 255 || (n = t.charCodeAt(c++)) > 255 || (o = t.charCodeAt(c++)) > 255) throw new TypeError("invalid character found");
                u += i[(r = e << 16 | n << 8 | o) >> 18 & 63] + i[r >> 12 & 63] + i[r >> 6 & 63] + i[63 & r];
            }
            return f ? u.slice(0, f - 3) + "===".substring(f) : u;
        }, h = e ? function(t) {
            return btoa(t);
        } : n ? function(t) {
            return Buffer.from(t, "binary").toString("base64");
        } : l, y = n ? function(t) {
            return Buffer.from(t).toString("base64");
        } : function(t) {
            for (var r = [], e = 0, n = t.length; e < n; e += 4096) r.push(a.apply(null, t.subarray(e, e + 4096)));
            return h(r.join(""));
        }, b = function(t, r) {
            return void 0 === r && (r = !1), r ? d(y(t)) : y(t);
        }, A = function(t) {
            if (t.length < 2) return (r = t.charCodeAt(0)) < 128 ? t : r < 2048 ? a(192 | r >>> 6) + a(128 | 63 & r) : a(224 | r >>> 12 & 15) + a(128 | r >>> 6 & 63) + a(128 | 63 & r);
            var r = 65536 + 1024 * (t.charCodeAt(0) - 55296) + (t.charCodeAt(1) - 56320);
            return a(240 | r >>> 18 & 7) + a(128 | r >>> 12 & 63) + a(128 | r >>> 6 & 63) + a(128 | 63 & r);
        }, x = /[\uD800-\uDBFF][\uDC00-\uDFFFF]|[^\x00-\x7F]/g, g = function(t) {
            return t.replace(x, A);
        }, B = n ? function(t) {
            return Buffer.from(t, "utf8").toString("base64");
        } : u ? function(t) {
            return y(u.encode(t));
        } : function(t) {
            return h(g(t));
        }, m = function(t, r) {
            return void 0 === r && (r = !1), r ? d(B(t)) : B(t);
        }, v = function(t) {
            return m(t, !0);
        }, C = /[\xC0-\xDF][\x80-\xBF]|[\xE0-\xEF][\x80-\xBF]{2}|[\xF0-\xF7][\x80-\xBF]{3}/g, _ = function(t) {
            switch (t.length) {
              case 4:
                var r = ((7 & t.charCodeAt(0)) << 18 | (63 & t.charCodeAt(1)) << 12 | (63 & t.charCodeAt(2)) << 6 | 63 & t.charCodeAt(3)) - 65536;
                return a(55296 + (r >>> 10)) + a(56320 + (1023 & r));

              case 3:
                return a((15 & t.charCodeAt(0)) << 12 | (63 & t.charCodeAt(1)) << 6 | 63 & t.charCodeAt(2));

              default:
                return a((31 & t.charCodeAt(0)) << 6 | 63 & t.charCodeAt(1));
            }
        }, U = function(t) {
            return t.replace(C, _);
        }, w = function(t) {
            if (t = t.replace(/\s+/g, ""), !c.test(t)) throw new TypeError("malformed base64.");
            t += "==".slice(2 - (3 & t.length));
            for (var r, e, n, o = "", u = 0; u < t.length; ) r = f[t.charAt(u++)] << 18 | f[t.charAt(u++)] << 12 | (e = f[t.charAt(u++)]) << 6 | (n = f[t.charAt(u++)]), 
            o += 64 === e ? a(r >> 16 & 255) : 64 === n ? a(r >> 16 & 255, r >> 8 & 255) : a(r >> 16 & 255, r >> 8 & 255, 255 & r);
            return o;
        }, F = r ? function(t) {
            return atob(p(t));
        } : n ? function(t) {
            return Buffer.from(t, "base64").toString("binary");
        } : w, E = n ? function(t) {
            return s(Buffer.from(t, "base64"));
        } : function(t) {
            return s(F(t).split("").map(function(t) {
                return t.charCodeAt(0);
            }));
        }, S = function(t) {
            return E(D(t));
        }, j = n ? function(t) {
            return Buffer.from(t, "base64").toString("utf8");
        } : o ? function(t) {
            return o.decode(E(t));
        } : function(t) {
            return U(F(t));
        }, D = function(t) {
            return p(t.replace(/[-_]/g, function(t) {
                return "-" == t ? "+" : "/";
            }));
        }, O = function(t) {
            return j(D(t));
        }, R = function(t) {
            return {
                value: t,
                enumerable: !1,
                writable: !0,
                configurable: !0
            };
        }, z = function() {
            var t = function(t, r) {
                return Object.defineProperty(String.prototype, t, R(r));
            };
            t("fromBase64", function() {
                return O(this);
            }), t("toBase64", function(t) {
                return m(this, t);
            }), t("toBase64URI", function() {
                return m(this, !0);
            }), t("toBase64URL", function() {
                return m(this, !0);
            }), t("toUint8Array", function() {
                return S(this);
            });
        }, P = function() {
            var t = function(t, r) {
                return Object.defineProperty(Uint8Array.prototype, t, R(r));
            };
            t("toBase64", function(t) {
                return b(this, t);
            }), t("toBase64URI", function() {
                return b(this, !0);
            }), t("toBase64URL", function() {
                return b(this, !0);
            });
        }, T = {
            version: "3.7.5",
            VERSION: "3.7.5",
            atob: F,
            atobPolyfill: w,
            btoa: h,
            btoaPolyfill: l,
            fromBase64: O,
            toBase64: m,
            encode: m,
            encodeURI: v,
            encodeURL: v,
            utob: g,
            btou: U,
            decode: O,
            isValid: function(t) {
                if ("string" != typeof t) return !1;
                var r = t.replace(/\s+/g, "").replace(/={0,2}$/, "");
                return !/[^\s0-9a-zA-Z\+/]/.test(r) || !/[^\s0-9a-zA-Z\-_]/.test(r);
            },
            fromUint8Array: b,
            toUint8Array: S,
            extendString: z,
            extendUint8Array: P,
            extendBuiltins: function() {
                z(), P();
            },
            Base64: {}
        };
        return Object.keys(T).forEach(function(t) {
            return T.Base64[t] = T[t];
        }), T;
    });
}, function(t) {
    return r({}[t], t);
}), r(1684205641544));