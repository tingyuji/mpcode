var e, i, n = require("../../../@babel/runtime/helpers/typeof");

module.exports = (e = {}, i = function(i, r) {
    if (!e[i]) return require(r);
    if (!e[i].status) {
        var o = e[i].m;
        o._exports = o._tempexports;
        var t = Object.getOwnPropertyDescriptor(o, "exports");
        t && t.configurable && Object.defineProperty(o, "exports", {
            set: function(e) {
                "object" === n(e) && e !== o._exports && (o._exports.__proto__ = e.__proto__, Object.keys(e).forEach(function(i) {
                    o._exports[i] = e[i];
                })), o._tempexports = e;
            },
            get: function() {
                return o._tempexports;
            }
        }), e[i].status = 1, e[i].func(e[i].req, o, o.exports);
    }
    return e[i].m.exports;
}, function(i, n, r) {
    e[i] = {
        status: 0,
        func: n,
        req: r,
        m: {
            exports: {},
            _tempexports: {}
        }
    };
}(1649821775252, function(e, i, r) {
    r.__esModule = !0, r.isWindVane = r.isWeex = r.isWeb = r.isWeChatMiniProgram = r.isQuickApp = r.isPHA = r.isNode = r.isMiniApp = r.isKuaiShouMiniProgram = r.isKraken = r.isFRM = r.isByteDanceMicroApp = r.isBaiduSmartProgram = r.default = void 0;
    var o = "undefined" != typeof window && "onload" in window;
    r.isWeb = o;
    var t = "undefined" != typeof process && !(!process.versions || !process.versions.node);
    r.isNode = t;
    var s = "undefined" != typeof WXEnvironment && "Web" !== WXEnvironment.platform;
    r.isWeex = s;
    var a = "undefined" != typeof __kraken__;
    r.isKraken = a;
    var d = "undefined" != typeof my && null !== my && void 0 !== my.alert;
    r.isMiniApp = d;
    var p = "undefined" != typeof tt && null !== tt && void 0 !== tt.showToast;
    r.isByteDanceMicroApp = p;
    var u = "undefined" != typeof swan && null !== swan && void 0 !== swan.showToast;
    r.isBaiduSmartProgram = u;
    var f = "undefined" != typeof ks && null !== ks && void 0 !== ks.showToast;
    r.isKuaiShouMiniProgram = f;
    var v = !p && "undefined" != typeof wx && null !== wx && (void 0 !== wx.request || void 0 !== wx.miniProgram);
    r.isWeChatMiniProgram = v;
    var c = "undefined" != typeof global && null !== global && void 0 !== global.callNative && !s;
    r.isQuickApp = c;
    var l = o && "object" === ("undefined" == typeof pha ? "undefined" : n(pha));
    r.isPHA = l;
    var m = d && o && my.isFRM;
    r.isFRM = m;
    var y = "object" === ("undefined" == typeof navigator ? "undefined" : n(navigator)) ? navigator.userAgent || navigator.swuserAgent : "", g = /.+AliApp\((\w+)\/((?:\d+\.)+\d+)\).* .*(WindVane)(?:\/((?:\d+\.)+\d+))?.*/.test(y) && o && "undefined" != typeof WindVane && void 0 !== WindVane.call;
    r.isWindVane = g;
    var _ = {
        isWeb: o,
        isNode: t,
        isWeex: s,
        isKraken: a,
        isMiniApp: d,
        isByteDanceMicroApp: p,
        isBaiduSmartProgram: u,
        isKuaiShouMiniProgram: f,
        isWeChatMiniProgram: v,
        isQuickApp: c,
        isPHA: l,
        isWindVane: g,
        isFRM: m
    };
    r.default = _;
}, function(e) {
    return i({}[e], e);
}), i(1649821775252));