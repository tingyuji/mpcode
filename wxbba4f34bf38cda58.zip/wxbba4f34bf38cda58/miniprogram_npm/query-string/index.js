require("../../@babel/runtime/helpers/Arrayincludes");

var r, e, t = require("../../@babel/runtime/helpers/defineProperty"), n = require("../../@babel/runtime/helpers/slicedToArray"), a = require("../../@babel/runtime/helpers/createForOfIteratorHelper"), o = require("../../@babel/runtime/helpers/toConsumableArray"), i = require("../../@babel/runtime/helpers/typeof");

module.exports = (r = {}, e = function(e, t) {
    if (!r[e]) return require(t);
    if (!r[e].status) {
        var n = r[e].m;
        n._exports = n._tempexports;
        var a = Object.getOwnPropertyDescriptor(n, "exports");
        a && a.configurable && Object.defineProperty(n, "exports", {
            set: function(r) {
                "object" === i(r) && r !== n._exports && (n._exports.__proto__ = r.__proto__, Object.keys(r).forEach(function(e) {
                    n._exports[e] = r[e];
                })), n._tempexports = r;
            },
            get: function() {
                return n._tempexports;
            }
        }), r[e].status = 1, r[e].func(r[e].req, n, n.exports);
    }
    return r[e].m.exports;
}, function(e, t, n) {
    r[e] = {
        status: 0,
        func: t,
        req: n,
        m: {
            exports: {},
            _tempexports: {}
        }
    };
}(1649821775259, function(r, e, u) {
    var c = r("strict-uri-encode"), s = r("decode-uri-component"), l = r("split-on-first"), p = r("filter-obj"), f = Symbol("encodeFragmentIdentifier");
    function m(r) {
        if ("string" != typeof r || 1 !== r.length) throw new TypeError("arrayFormatSeparator must be single character string");
    }
    function y(r, e) {
        return e.encode ? e.strict ? c(r) : encodeURIComponent(r) : r;
    }
    function d(r, e) {
        return e.decode ? s(r) : r;
    }
    function b(r) {
        var e = r.indexOf("#");
        return -1 !== e && (r = r.slice(0, e)), r;
    }
    function g(r) {
        var e = (r = b(r)).indexOf("?");
        return -1 === e ? "" : r.slice(e + 1);
    }
    function v(r, e) {
        return e.parseNumbers && !Number.isNaN(Number(r)) && "string" == typeof r && "" !== r.trim() ? r = Number(r) : !e.parseBooleans || null === r || "true" !== r.toLowerCase() && "false" !== r.toLowerCase() || (r = "true" === r.toLowerCase()), 
        r;
    }
    function j(r, e) {
        m((e = Object.assign({
            decode: !0,
            sort: !0,
            arrayFormat: "none",
            arrayFormatSeparator: ",",
            parseNumbers: !1,
            parseBooleans: !1
        }, e)).arrayFormatSeparator);
        var t = function(r) {
            var e;
            switch (r.arrayFormat) {
              case "index":
                return function(r, t, n) {
                    e = /\[(\d*)\]$/.exec(r), r = r.replace(/\[\d*\]$/, ""), e ? (void 0 === n[r] && (n[r] = {}), 
                    n[r][e[1]] = t) : n[r] = t;
                };

              case "bracket":
                return function(r, t, n) {
                    e = /(\[\])$/.exec(r), r = r.replace(/\[\]$/, ""), e ? void 0 !== n[r] ? n[r] = [].concat(n[r], t) : n[r] = [ t ] : n[r] = t;
                };

              case "colon-list-separator":
                return function(r, t, n) {
                    e = /(:list)$/.exec(r), r = r.replace(/:list$/, ""), e ? void 0 !== n[r] ? n[r] = [].concat(n[r], t) : n[r] = [ t ] : n[r] = t;
                };

              case "comma":
              case "separator":
                return function(e, t, n) {
                    var a = "string" == typeof t && t.includes(r.arrayFormatSeparator), o = "string" == typeof t && !a && d(t, r).includes(r.arrayFormatSeparator);
                    t = o ? d(t, r) : t;
                    var i = a || o ? t.split(r.arrayFormatSeparator).map(function(e) {
                        return d(e, r);
                    }) : null === t ? t : d(t, r);
                    n[e] = i;
                };

              case "bracket-separator":
                return function(e, t, n) {
                    var a = /(\[\])$/.test(e);
                    if (e = e.replace(/\[\]$/, ""), a) {
                        var o = null === t ? [] : t.split(r.arrayFormatSeparator).map(function(e) {
                            return d(e, r);
                        });
                        void 0 !== n[e] ? n[e] = [].concat(n[e], o) : n[e] = o;
                    } else n[e] = t ? d(t, r) : t;
                };

              default:
                return function(r, e, t) {
                    void 0 !== t[r] ? t[r] = [].concat(t[r], e) : t[r] = e;
                };
            }
        }(e), o = Object.create(null);
        if ("string" != typeof r) return o;
        if (!(r = r.trim().replace(/^[?#&]/, ""))) return o;
        var u, c = a(r.split("&"));
        try {
            for (c.s(); !(u = c.n()).done; ) {
                var s = u.value;
                if ("" !== s) {
                    var p = l(e.decode ? s.replace(/\+/g, " ") : s, "="), f = n(p, 2), y = f[0], b = f[1];
                    b = void 0 === b ? null : [ "comma", "separator", "bracket-separator" ].includes(e.arrayFormat) ? b : d(b, e), 
                    t(d(y, e), b, o);
                }
            }
        } catch (r) {
            c.e(r);
        } finally {
            c.f();
        }
        for (var g = 0, j = Object.keys(o); g < j.length; g++) {
            var k = j[g], x = o[k];
            if ("object" === i(x) && null !== x) for (var O = 0, F = Object.keys(x); O < F.length; O++) {
                var h = F[O];
                x[h] = v(x[h], e);
            } else o[k] = v(x, e);
        }
        return !1 === e.sort ? o : (!0 === e.sort ? Object.keys(o).sort() : Object.keys(o).sort(e.sort)).reduce(function(r, e) {
            var t = o[e];
            return Boolean(t) && "object" === i(t) && !Array.isArray(t) ? r[e] = function r(e) {
                return Array.isArray(e) ? e.sort() : "object" === i(e) ? r(Object.keys(e)).sort(function(r, e) {
                    return Number(r) - Number(e);
                }).map(function(r) {
                    return e[r];
                }) : e;
            }(t) : r[e] = t, r;
        }, Object.create(null));
    }
    u.extract = g, u.parse = j, u.stringify = function(r, e) {
        if (!r) return "";
        m((e = Object.assign({
            encode: !0,
            strict: !0,
            arrayFormat: "none",
            arrayFormatSeparator: ","
        }, e)).arrayFormatSeparator);
        for (var t = function(t) {
            return e.skipNull && null == r[t] || e.skipEmptyString && "" === r[t];
        }, n = function(r) {
            switch (r.arrayFormat) {
              case "index":
                return function(e) {
                    return function(t, n) {
                        var a = t.length;
                        return void 0 === n || r.skipNull && null === n || r.skipEmptyString && "" === n ? t : [].concat(o(t), null === n ? [ [ y(e, r), "[", a, "]" ].join("") ] : [ [ y(e, r), "[", y(a, r), "]=", y(n, r) ].join("") ]);
                    };
                };

              case "bracket":
                return function(e) {
                    return function(t, n) {
                        return void 0 === n || r.skipNull && null === n || r.skipEmptyString && "" === n ? t : [].concat(o(t), null === n ? [ [ y(e, r), "[]" ].join("") ] : [ [ y(e, r), "[]=", y(n, r) ].join("") ]);
                    };
                };

              case "colon-list-separator":
                return function(e) {
                    return function(t, n) {
                        return void 0 === n || r.skipNull && null === n || r.skipEmptyString && "" === n ? t : [].concat(o(t), null === n ? [ [ y(e, r), ":list=" ].join("") ] : [ [ y(e, r), ":list=", y(n, r) ].join("") ]);
                    };
                };

              case "comma":
              case "separator":
              case "bracket-separator":
                var e = "bracket-separator" === r.arrayFormat ? "[]=" : "=";
                return function(t) {
                    return function(n, a) {
                        return void 0 === a || r.skipNull && null === a || r.skipEmptyString && "" === a ? n : (a = null === a ? "" : a, 
                        0 === n.length ? [ [ y(t, r), e, y(a, r) ].join("") ] : [ [ n, y(a, r) ].join(r.arrayFormatSeparator) ]);
                    };
                };

              default:
                return function(e) {
                    return function(t, n) {
                        return void 0 === n || r.skipNull && null === n || r.skipEmptyString && "" === n ? t : [].concat(o(t), null === n ? [ y(e, r) ] : [ [ y(e, r), "=", y(n, r) ].join("") ]);
                    };
                };
            }
        }(e), a = {}, i = 0, u = Object.keys(r); i < u.length; i++) {
            var c = u[i];
            t(c) || (a[c] = r[c]);
        }
        var s = Object.keys(a);
        return !1 !== e.sort && s.sort(e.sort), s.map(function(t) {
            var a = r[t];
            return void 0 === a ? "" : null === a ? y(t, e) : Array.isArray(a) ? 0 === a.length && "bracket-separator" === e.arrayFormat ? y(t, e) + "[]" : a.reduce(n(t), []).join("&") : y(t, e) + "=" + y(a, e);
        }).filter(function(r) {
            return r.length > 0;
        }).join("&");
    }, u.parseUrl = function(r, e) {
        e = Object.assign({
            decode: !0
        }, e);
        var t = l(r, "#"), a = n(t, 2), o = a[0], i = a[1];
        return Object.assign({
            url: o.split("?")[0] || "",
            query: j(g(r), e)
        }, e && e.parseFragmentIdentifier && i ? {
            fragmentIdentifier: d(i, e)
        } : {});
    }, u.stringifyUrl = function(r, e) {
        e = Object.assign(t({
            encode: !0,
            strict: !0
        }, f, !0), e);
        var n = b(r.url).split("?")[0] || "", a = u.extract(r.url), o = u.parse(a, {
            sort: !1
        }), i = Object.assign(o, r.query), c = u.stringify(i, e);
        c && (c = "?".concat(c));
        var s = function(r) {
            var e = "", t = r.indexOf("#");
            return -1 !== t && (e = r.slice(t)), e;
        }(r.url);
        return r.fragmentIdentifier && (s = "#".concat(e[f] ? y(r.fragmentIdentifier, e) : r.fragmentIdentifier)), 
        "".concat(n).concat(c).concat(s);
    }, u.pick = function(r, e, n) {
        n = Object.assign(t({
            parseFragmentIdentifier: !0
        }, f, !1), n);
        var a = u.parseUrl(r, n), o = a.url, i = a.query, c = a.fragmentIdentifier;
        return u.stringifyUrl({
            url: o,
            query: p(i, e),
            fragmentIdentifier: c
        }, n);
    }, u.exclude = function(r, e, t) {
        var n = Array.isArray(e) ? function(r) {
            return !e.includes(r);
        } : function(r, t) {
            return !e(r, t);
        };
        return u.pick(r, n, t);
    };
}, function(r) {
    return e({}[r], r);
}), e(1649821775259));