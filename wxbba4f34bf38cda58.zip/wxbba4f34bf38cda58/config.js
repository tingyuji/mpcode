Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.shouldLogin = exports.sdkConfig = exports.safeOriginUrl = exports.originUrlMap = exports.originUrl = exports.minEnvVersion = exports.hostMap = exports.env = exports.drmServerHost = exports.app_id = exports.MiniEnv = exports.MTOP_FAIL_MSG = exports.AUTH_WHITELIST = exports.APP_VERSION = void 0;

var e, r = require("@babel/runtime/helpers/defineProperty");

exports.app_id = "wxbba4f34bf38cda58";

var o, p;

exports.APP_VERSION = "1.3.6", exports.MiniEnv = o, function(e) {
    e.develop = "develop", e.trial = "trial", e.release = "release";
}(o || (exports.MiniEnv = o = {})), function(e) {
    e.daily = "daily", e.pre = "pre", e.prod = "prod";
}(p || (p = {}));

var s = wx.getAccountInfoSync().miniProgram.envVersion;

exports.minEnvVersion = s;

var a = (r(e = {}, o.develop, p.pre), r(e, o.trial, p.pre), r(e, o.release, p.prod), 
e)[s];

exports.env = a, a || console.error("获取运行环境失败!");

var n = {
    daily: {
        prefix: "pre-acs"
    },
    pre: {
        prefix: "pre-acs"
    },
    prod: {
        prefix: "acs"
    }
};

exports.hostMap = n;

var i = {
    daily: "https://yunshangkanpian.taobao.net",
    pre: "https://yunshangyue.pre-abf.alibaba-inc.com",
    prod: "https://www.yunshangyue.cn"
};

exports.originUrlMap = i;

var t = i[a];

exports.originUrl = t;

var x = {
    daily: "https://yunshangyue.youku.com",
    pre: "https://yunshangyue.youku.com",
    prod: "https://www.yunshangyue.cn"
}[a];

exports.safeOriginUrl = x;

var d = {
    prefix: n[a] && n[a].prefix || "acs"
};

exports.sdkConfig = d;

var l = {
    daily: "cloud-salary-openapi.taobao.net",
    pre: "pre-cloud-product-gateway.alibaba-inc.com",
    prod: "openapi.yunshangzhipian.com"
}[a];

exports.drmServerHost = l;

exports.MTOP_FAIL_MSG = "网络异常，请稍后重试";

var u = [ "pages/login/index", "pages/share/index" ];

exports.AUTH_WHITELIST = u;

exports.shouldLogin = function(e) {
    return u.indexOf(e) < 0;
};