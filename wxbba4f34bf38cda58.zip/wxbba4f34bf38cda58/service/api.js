Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.changeDigitalApp = function(t) {
    return K.apply(this, arguments);
}, exports.checkFrontState = function(t) {
    return h.apply(this, arguments);
}, exports.checkMvpState = function(t) {
    return x.apply(this, arguments);
}, exports.chooseDigitalApp = function(t) {
    return F.apply(this, arguments);
}, exports.createOrder = function(t) {
    return V.apply(this, arguments);
}, exports.cubeautifulpic = function(t) {
    return k.apply(this, arguments);
}, exports.dealDigitalApp = function(t) {
    return g.apply(this, arguments);
}, exports.dealnewdigitalapp = function(t) {
    return E.apply(this, arguments);
}, exports.deleteAlbum = function(t) {
    return _.apply(this, arguments);
}, exports.deletePic = function(t) {
    return v.apply(this, arguments);
}, exports.downloadPic = function(t) {
    return A.apply(this, arguments);
}, exports.genShareInfo = function(t) {
    return I.apply(this, arguments);
}, exports.getAlbumInfo = function(t) {
    return m.apply(this, arguments);
}, exports.getAlbumPic = function(t) {
    return S.apply(this, arguments);
}, exports.getDigitalApp = function(t) {
    return M.apply(this, arguments);
}, exports.getDigitalAppRate = function(t) {
    return w.apply(this, arguments);
}, exports.getDownloadNum = function(t) {
    return q.apply(this, arguments);
}, exports.getLikePicture = function(t) {
    return C.apply(this, arguments);
}, exports.getOssProps = function() {
    return Z.apply(this, arguments);
}, exports.getPicGenProcess = function(t) {
    return T.apply(this, arguments);
}, exports.getPostureList = function(t) {
    return P.apply(this, arguments);
}, exports.getTemplateList = function(t) {
    return b.apply(this, arguments);
}, exports.getUserInfo = function(t) {
    return l.apply(this, arguments);
}, exports.getpicgenstate = function(t) {
    return R.apply(this, arguments);
}, exports.inviteregist = function(t, e) {
    return N.apply(this, arguments);
}, exports.likePicture = function(t) {
    return L.apply(this, arguments);
}, exports.login = function(t) {
    return f.apply(this, arguments);
}, exports.mtopReqeust = void 0, exports.queryCoinBalance = function() {
    return j.apply(this, arguments);
}, exports.queryCoinHistory = function(t) {
    return H.apply(this, arguments);
}, exports.queryOrder = function(t) {
    return U.apply(this, arguments);
}, exports.queryQueuingInfo = function(t) {
    return Y.apply(this, arguments);
}, exports.recoFrontView = function(t) {
    return d.apply(this, arguments);
}, exports.regularReset = function() {
    return J.apply(this, arguments);
}, exports.releaseReset = function() {
    return G.apply(this, arguments);
}, exports.resetappearance = function(t) {
    return O.apply(this, arguments);
}, exports.shareInvite = function(t) {
    return D.apply(this, arguments);
}, exports.startReset = function() {
    return B.apply(this, arguments);
}, exports.upMultiViewPic = function(t) {
    return y.apply(this, arguments);
};

var t = s(require("../@babel/runtime/regenerator")), e = require("../@babel/runtime/helpers/asyncToGenerator"), r = require("../@babel/runtime/helpers/slicedToArray"), n = require("../@babel/runtime/helpers/objectSpread2"), a = s(require("@ali/youku-miniapp-mtop/index")), u = require("../utils/wechat"), o = require("../utils/tracker"), p = require("../config"), i = require("../constants/index");

function s(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

var c = function(t, e, s) {
    var c = (s || {
        showErrorIfFail: !0
    }).showErrorIfFail;
    return new Promise(function(s, f) {
        var l, m, d, h = {
            prefix: p.sdkConfig.prefix,
            type: "post",
            api: t,
            data: n(n({}, e || {}), {}, {
                token: wx.getStorageSync(i.TOKEN_KEY),
                system_info: JSON.stringify({
                    version: p.APP_VERSION,
                    device: wx.getSystemInfoSync().platform,
                    cna: null === (l = getApp().aplus) || void 0 === l ? void 0 : l.CNA
                })
            })
        };
        (0, o.aemSend)("beforeRequest", {
            extra: JSON.stringify(h),
            c2: t,
            c3: null === (m = getApp().globalData) || void 0 === m || null === (d = m.userInfo) || void 0 === d ? void 0 : d.userId
        }), a.default.request(h).then(function(e) {
            var r, n;
            console.log(e), (0, o.aemSend)("requestSuccess", {
                extra: JSON.stringify(e),
                c2: t,
                c3: null === (r = getApp().globalData) || void 0 === r || null === (n = r.userInfo) || void 0 === n ? void 0 : n.userId
            }), s(null == e ? void 0 : e.data.model);
        }).catch(function(e) {
            var n, a, p, s;
            console.log("err: ", e), (0, o.aemSend)("requestFail", {
                extra: JSON.stringify(e),
                c2: t,
                c3: null === (n = getApp().globalData) || void 0 === n || null === (a = n.userInfo) || void 0 === a ? void 0 : a.userId
            });
            var l = (null == e || null === (p = e.ret) || void 0 === p || null === (s = p[0]) || void 0 === s ? void 0 : s.split("::")) || [], m = r(l, 2), d = m[0], h = m[1], y = i.API_ERROR_MAP[d] || h;
            if ([ i.BIZ_L_TOKEN_EXPIRED, i.BIZ_L_UN_LOGIN ].indexOf(d) >= 0) return wx.setStorageSync(i.TOKEN_KEY, ""), 
            wx.hideLoading(), "pages/index/index" !== (0, u.getCurrentPage)().route && wx.reLaunch({
                url: "/pages/index/index"
            }), {
                errCode: d,
                errMessage: y
            };
            c && wx.showToast({
                icon: "none",
                title: y || "请求错误"
            }), f({
                errCode: d,
                errMessage: y
            });
        });
    });
};

function f() {
    return (f = e(t.default.mark(function e(r) {
        return t.default.wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return t.abrupt("return", c("mtop.youku.miaoya.alexsmartphoto.wechat.login", r));

              case 1:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function l() {
    return (l = e(t.default.mark(function e(r) {
        return t.default.wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return t.abrupt("return", c("mtop.youku.miaoya.alexsmartphoto.appearancegen.getuserinfo", {}, r));

              case 1:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function m() {
    return (m = e(t.default.mark(function e(r) {
        return t.default.wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return t.abrupt("return", c("mtop.youku.miaoya.alexsmartphoto.appearancegen.getalbuminfo", r));

              case 1:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function d() {
    return (d = e(t.default.mark(function e(r) {
        return t.default.wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return t.abrupt("return", c("mtop.youku.miaoya.alexsmartphoto.appearancegen.recofrontview", r));

              case 1:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function h() {
    return (h = e(t.default.mark(function e(r) {
        return t.default.wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return t.abrupt("return", c("mtop.youku.miaoya.alexsmartphoto.appearancegen.fvstatecheck", r));

              case 1:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function y() {
    return (y = e(t.default.mark(function e(r) {
        return t.default.wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return t.abrupt("return", c("mtop.youku.miaoya.alexsmartphoto.appearancegen.upmultiviewpic", r));

              case 1:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function x() {
    return (x = e(t.default.mark(function e(r) {
        return t.default.wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return t.abrupt("return", c("mtop.youku.miaoya.alexsmartphoto.appearancegen.mvpcheckstate", r));

              case 1:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function g() {
    return (g = e(t.default.mark(function e(r) {
        return t.default.wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return t.abrupt("return", c("mtop.youku.miaoya.alexsmartphoto.appearancegen.dealDigitalApp", r));

              case 1:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function w() {
    return (w = e(t.default.mark(function e(r) {
        return t.default.wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return t.abrupt("return", c("mtop.youku.miaoya.alexsmartphoto.appearancegen.getDigitalAppRate", r));

              case 1:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function k() {
    return (k = e(t.default.mark(function e(r) {
        return t.default.wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return t.abrupt("return", c("mtop.youku.miaoya.alexsmartphoto.appearancegen.cubeautifulpic", r));

              case 1:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function v() {
    return (v = e(t.default.mark(function e(r) {
        return t.default.wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return t.abrupt("return", c("mtop.youku.miaoya.alexsmartphoto.appearancegen.delpic", r));

              case 1:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function b() {
    return (b = e(t.default.mark(function e(r) {
        return t.default.wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return t.abrupt("return", c("mtop.youku.miaoya.alexsmartphoto.appearancegen.getTemplateList", r));

              case 1:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function P() {
    return (P = e(t.default.mark(function e(r) {
        return t.default.wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return t.abrupt("return", c("mtop.youku.miaoya.alexsmartphoto.appearancegen.getPostureList", r));

              case 1:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function q() {
    return (q = e(t.default.mark(function e(r) {
        return t.default.wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return t.abrupt("return", c("mtop.youku.miaoya.alexsmartphoto.appearancegen.getDownloadNum", r));

              case 1:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function A() {
    return (A = e(t.default.mark(function e(r) {
        return t.default.wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return t.abrupt("return", c("mtop.youku.miaoya.alexsmartphoto.appearancegen.downloadPic", r));

              case 1:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function I() {
    return (I = e(t.default.mark(function e(r) {
        return t.default.wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return t.abrupt("return", c("mtop.youku.miaoya.alexsmartphoto.appearancegen.genShareInfo", r));

              case 1:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function S() {
    return (S = e(t.default.mark(function e(r) {
        return t.default.wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return t.abrupt("return", c("mtop.youku.miaoya.alexsmartphoto.appearancegen.getAlbumPic", r));

              case 1:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function O() {
    return (O = e(t.default.mark(function e(r) {
        return t.default.wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return t.abrupt("return", c("mtop.youku.miaoya.alexsmartphoto.appearancegen.resetappearance", r));

              case 1:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function D() {
    return (D = e(t.default.mark(function e(r) {
        return t.default.wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return t.abrupt("return", c("mtop.youku.miaoya.alexsmartphoto.share.invite", r).then(function() {
                    return !0;
                }).catch(function() {
                    return !1;
                }));

              case 1:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function R() {
    return (R = e(t.default.mark(function e(r) {
        return t.default.wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return t.abrupt("return", c("mtop.youku.miaoya.alexsmartphoto.appearancegen.getpicgenstate", r));

              case 1:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function _() {
    return (_ = e(t.default.mark(function e(r) {
        return t.default.wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return t.abrupt("return", c("mtop.youku.miaoya.alexsmartphoto.album.del", r));

              case 1:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function N() {
    return (N = e(t.default.mark(function e(r, n) {
        return t.default.wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return t.abrupt("return", c("mtop.youku.miaoya.alexsmartphoto.user.inviteregist", r, n));

              case 1:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function E() {
    return (E = e(t.default.mark(function e(r) {
        return t.default.wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return t.abrupt("return", c("mtop.youku.miaoya.alexsmartphoto.appearancegen.dealnewdigitalapp", r));

              case 1:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function L() {
    return (L = e(t.default.mark(function e(r) {
        return t.default.wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return t.abrupt("return", c("mtop.youku.miaoya.alexsmartphoto.album.likePicture", r));

              case 1:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function C() {
    return (C = e(t.default.mark(function e(r) {
        return t.default.wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return t.abrupt("return", c("mtop.youku.miaoya.alexsmartphoto.album.getLikePicture", r));

              case 1:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function T() {
    return (T = e(t.default.mark(function e(r) {
        return t.default.wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return t.abrupt("return", c("mtop.youku.miaoya.alexsmartphoto.album.getPicGenProcess", r));

              case 1:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function M() {
    return (M = e(t.default.mark(function e(r) {
        return t.default.wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return t.abrupt("return", c("mtop.youku.miaoya.alexsmartphoto.appearancegen.getDigitalApp", r));

              case 1:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function F() {
    return (F = e(t.default.mark(function e(r) {
        return t.default.wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return t.abrupt("return", c("mtop.youku.miaoya.alexsmartphoto.appearancegen.chooseDigitalApp", r));

              case 1:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function K() {
    return (K = e(t.default.mark(function e(r) {
        return t.default.wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return t.abrupt("return", c("mtop.youku.miaoya.alexsmartphoto.appearancegen.changeDigitalApp", r));

              case 1:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function B() {
    return (B = e(t.default.mark(function e() {
        return t.default.wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return t.abrupt("return", c("mtop.youku.miaoya.alexsmartphoto.appearancegen.startReset"));

              case 1:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function G() {
    return (G = e(t.default.mark(function e() {
        return t.default.wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return t.abrupt("return", c("mtop.youku.miaoya.alexsmartphoto.appearancegen.releaseReset"));

              case 1:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function J() {
    return (J = e(t.default.mark(function e() {
        return t.default.wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return t.abrupt("return", c("mtop.youku.miaoya.alexsmartphoto.appearancegen.regularReset"));

              case 1:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function V() {
    return (V = e(t.default.mark(function e(r) {
        return t.default.wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return t.abrupt("return", c("mtop.youku.miaoya.alexsmartphoto.order.createOrder", r));

              case 1:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function j() {
    return (j = e(t.default.mark(function e() {
        return t.default.wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return t.abrupt("return", c("mtop.youku.miaoya.alexsmartphoto.order.queryCoinBalance", {
                    scene: "applet"
                }));

              case 1:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function H() {
    return (H = e(t.default.mark(function e(r) {
        return t.default.wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return t.abrupt("return", c("mtop.youku.miaoya.alexsmartphoto.order.queryCoinHistory", r));

              case 1:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function U() {
    return (U = e(t.default.mark(function e(r) {
        return t.default.wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return t.abrupt("return", c("mtop.youku.miaoya.alexsmartphoto.order.query", r));

              case 1:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function Y() {
    return (Y = e(t.default.mark(function e(r) {
        return t.default.wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return t.abrupt("return", c("mtop.youku.miaoya.alexsmartphoto.appearancegen.queuingperson", r));

              case 1:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function Z() {
    return (Z = e(t.default.mark(function e() {
        return t.default.wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return t.abrupt("return", c("mtop.youku.miaoya.alexsmartphoto.user.getOssProps"));

              case 1:
              case "end":
                return t.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

exports.mtopReqeust = c;