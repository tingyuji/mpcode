var e, t = (e = require("../../@babel/runtime/regenerator")) && e.__esModule ? e : {
    default: e
}, n = require("../../@babel/runtime/helpers/asyncToGenerator"), a = require("../../service/api");

Component({
    properties: {
        showInviteDialog: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        inviteCode: "",
        inviteCodeHasValided: !1,
        inviteCodePassed: !1,
        inviteCodeWrongReason: ""
    },
    methods: {
        handleApplyCodeTap: function() {
            wx.openEmbeddedMiniProgram({
                appId: "wxd947200f82267e58",
                path: "pages/wjxqList/wjxqList?activityId=mCUPDdB"
            });
        },
        handleTapInviteMask: function() {
            this.setData({
                showInviteDialog: !1
            });
        },
        handleInviteOkTap: function(e) {
            var i = this;
            return n(t.default.mark(function e() {
                var n, r;
                return t.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (n = i.data.inviteCode) {
                            e.next = 4;
                            break;
                        }
                        return wx.showToast({
                            icon: "none",
                            title: "请输入邀请码"
                        }), e.abrupt("return");

                      case 4:
                        if (/^[a-zA-Z0-9]+$/.test(n)) {
                            e.next = 7;
                            break;
                        }
                        return i.setData({
                            inviteCodePassed: !1,
                            inviteCodeWrongReason: "邀请码不存在",
                            inviteCodeHasValided: !0
                        }), e.abrupt("return");

                      case 7:
                        return e.next = 9, (0, a.inviteregist)({
                            invite_code: n
                        }, {
                            showErrorIfFail: !1
                        }).catch(function(e) {
                            return Object.keys(INVITE_CODE_ERROR_MAP).indexOf(e.errCode) >= 0 ? i.setData({
                                inviteCodePassed: !1,
                                inviteCodeWrongReason: INVITE_CODE_ERROR_MAP[e.errCode]
                            }) : wx.showToast({
                                icon: "none",
                                title: e.errMessage || "请求错误"
                            }), null;
                        });

                      case 9:
                        r = e.sent, i.setData({
                            inviteCodeHasValided: !0
                        }), r && (i.setData({
                            inviteCodePassed: !0,
                            inviteCodeWrongReason: "",
                            showInviteDialog: !1,
                            inviteFlag: !0
                        }), i.handleTapGenerateBtn());

                      case 12:
                      case "end":
                        return e.stop();
                    }
                }, e);
            }))();
        },
        handleInviteCancelTap: function() {
            var e = this;
            return n(t.default.mark(function n() {
                return t.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        e.clearInviteCodeResult(), e.setData({
                            showInviteDialog: !1
                        });

                      case 2:
                      case "end":
                        return t.stop();
                    }
                }, n);
            }))();
        }
    }
});