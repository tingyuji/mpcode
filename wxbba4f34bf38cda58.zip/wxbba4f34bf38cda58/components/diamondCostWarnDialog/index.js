var e, t = (e = require("../../@babel/runtime/regenerator")) && e.__esModule ? e : {
    default: e
}, r = require("../../@babel/runtime/helpers/asyncToGenerator"), n = require("../../service/api");

Component({
    properties: {
        actionCode: {
            type: String
        },
        actionName: {
            type: String
        },
        actionCost: {
            type: Number
        }
    },
    data: {
        balance: 0,
        noReminder: !1
    },
    attached: function() {
        var e = this;
        return r(t.default.mark(function r() {
            var a;
            return t.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (!wx.getStorageSync(e.getNoReminderStoreKey())) {
                        t.next = 4;
                        break;
                    }
                    return e.triggerEvent("ok"), t.abrupt("return");

                  case 4:
                    return t.next = 6, (0, n.queryCoinBalance)();

                  case 6:
                    a = t.sent, e.setData({
                        balance: a
                    });

                  case 8:
                  case "end":
                    return t.stop();
                }
            }, r);
        }))();
    },
    methods: {
        getNoReminderStoreKey: function() {
            var e = this.properties.actionCode;
            return "".concat("NO_REMIND_KEY").concat(e);
        },
        handleOk: function() {
            this.triggerEvent("ok");
        },
        handleCancel: function() {
            this.triggerEvent("cancel");
        },
        handleNoReminderRadioTap: function() {
            var e = !this.data.noReminder;
            this.setData({
                noReminder: e
            });
            var t = this.getNoReminderStoreKey();
            e ? wx.setStorageSync(t, e) : wx.removeStorageSync(t);
        }
    }
});