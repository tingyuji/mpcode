var e = {
    "primary.big": "/image/primary-btn-bg.png",
    "primary.middle": "/image/primary-middle-btn-bg.png",
    "default.big": "/image/default-btn-bg.png",
    "default.middle": "/image/default-middle-btn-bg.png",
    "default.small": "/image/default-small-btn-bg.png"
};

Component({
    properties: {
        type: {
            type: String,
            value: "default"
        },
        size: {
            type: String,
            value: "big"
        },
        disabled: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        bgImg: ""
    },
    attached: function() {
        var t = this.properties, a = t.type, i = t.size;
        t.disabled;
        this.setData({
            bgImg: e["".concat(a, ".").concat(i)]
        });
    },
    methods: {}
});