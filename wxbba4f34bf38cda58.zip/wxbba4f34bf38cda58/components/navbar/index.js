getApp();

Component({
    properties: {
        title: {
            type: String
        },
        backText: {
            type: String
        },
        occupySpace: {
            type: Boolean,
            value: !1
        },
        customNavBack: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        navTop: void 0,
        navHeight: void 0,
        menuButtonObject: void 0,
        menuButtonObjectHeight: void 0,
        showBackBtn: !1
    },
    attached: function() {
        var t = this;
        wx.getSystemInfo({
            success: function(e) {
                var n = wx.getMenuButtonBoundingClientRect(), a = e.statusBarHeight, o = n.top, i = a + n.height + 2 * (n.top - a);
                t.setData({
                    navTop: o,
                    navHeight: i,
                    menuButtonObject: n,
                    menuButtonObjectHeight: n.height,
                    sideWidth: e.screenWidth - n.left
                });
            }
        });
        var e = getCurrentPages();
        this.setData({
            showBackBtn: e.length > 1
        });
    },
    methods: {
        handleTapBackBtn: function() {
            this.properties.customNavBack ? this.triggerEvent("navBack") : wx.navigateBack();
        },
        handleTapLogo: function() {
            wx.reLaunch({
                url: "/pages/index/index"
            });
        }
    }
});