Component({
    properties: {
        tip: {
            type: String
        }
    },
    data: {},
    methods: {}
});