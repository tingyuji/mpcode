var e, t = (e = require("../../@babel/runtime/regenerator")) && e.__esModule ? e : {
    default: e
}, r = require("../../@babel/runtime/helpers/defineProperty"), i = require("../../@babel/runtime/helpers/objectSpread2"), n = require("../../@babel/runtime/helpers/asyncToGenerator"), a = require("../../utils/mt"), o = require("../../utils/dataUtils"), s = require("../../utils/pay");

Component({
    properties: {},
    data: {
        sending: !1,
        digitalGoodInfo: null,
        benefitList: [],
        selectedIndex: 0
    },
    attached: function() {
        var e = this;
        return n(t.default.mark(function n() {
            var s, d, u;
            return t.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return e.recordPV({
                        spmA: "tixiang_wx",
                        spmB: "imgpay"
                    }), t.next = 3, (0, a.getGoodsMtConfig)();

                  case 3:
                    d = t.sent, u = null == d || null === (s = d.digital_goods) || void 0 === s ? void 0 : s[0], 
                    e.setData(r({
                        digitalGoodInfo: u,
                        benefitList: null == u ? void 0 : u.benefit
                    }, "digitalGoodInfo", i(i({}, u || {}), {}, {
                        goodsPriceStr: (0, o.getPriceStr)(null == u ? void 0 : u.goods_price),
                        originPriceStr: (0, o.getPriceStr)(null == u ? void 0 : u.origin_price)
                    })));

                  case 6:
                  case "end":
                    return t.stop();
                }
            }, n);
        }))();
    },
    methods: {
        handleTapClose: function() {
            this.triggerEvent("close");
        },
        handleTapQuestion: function() {
            wx.navigateTo({
                url: "/pages/alimeService/index"
            });
        },
        handleTapItem: function(e) {
            var t = e.currentTarget.dataset.index;
            this.setData({
                selectedIndex: t
            });
        },
        handleTapPay: function() {
            var e = this;
            return n(t.default.mark(function r() {
                var i, n;
                return t.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        if (getApp().recordClick("tixiang_wx.page_imgpay.action.confirmpayment"), i = e.data.digitalGoodInfo, 
                        !e.data.sending) {
                            t.next = 4;
                            break;
                        }
                        return t.abrupt("return");

                      case 4:
                        return e.setData({
                            sending: !0
                        }), t.next = 7, (0, s.buyGood)({
                            goodId: "digital_0",
                            goodPrice: i.goods_price
                        });

                      case 7:
                        n = t.sent, e.setData({
                            sending: !1
                        }), n && e.triggerEvent("success");

                      case 10:
                      case "end":
                        return t.stop();
                    }
                }, r);
            }))();
        }
    }
});