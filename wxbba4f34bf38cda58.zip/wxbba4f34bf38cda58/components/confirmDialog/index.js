Component({
    options: {
        multipleSlots: !0
    },
    properties: {
        show: {
            type: Boolean
        },
        extClass: {
            type: String
        },
        title: {
            type: String
        },
        content: {
            type: String
        },
        contents: {
            type: Array
        },
        maskClosable: {
            type: Boolean,
            value: !0
        },
        mask: {
            type: Boolean,
            value: !0
        },
        okText: {
            type: String,
            value: "确定"
        },
        cancelText: {
            type: String,
            value: "取消"
        },
        okType: {
            type: String,
            value: "primary"
        },
        showBtns: {
            type: Boolean,
            value: !0
        }
    },
    data: {},
    methods: {
        handleCancelTap: function() {
            this.triggerEvent("cancel");
        },
        handleOkTap: function() {
            this.triggerEvent("ok");
        }
    }
});