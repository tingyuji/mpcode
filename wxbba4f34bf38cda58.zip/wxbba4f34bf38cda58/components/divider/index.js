Component({
    properties: {
        text: {
            type: String
        }
    },
    data: {},
    methods: {}
});