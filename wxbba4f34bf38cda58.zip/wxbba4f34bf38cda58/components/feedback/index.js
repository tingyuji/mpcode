Component({
    properties: {},
    data: {
        show: !1
    },
    methods: {
        handleEntryTap: function() {
            this.setData({
                show: !0
            });
        },
        handleCancelTap: function() {
            this.setData({
                show: !1
            });
        }
    }
});