var e, t = (e = require("../../@babel/runtime/regenerator")) && e.__esModule ? e : {
    default: e
}, r = require("../../@babel/runtime/helpers/objectSpread2"), a = require("../../@babel/runtime/helpers/asyncToGenerator"), n = require("../../utils/mt"), i = require("../../utils/dataUtils");

Component({
    properties: {},
    data: {
        platform: "",
        digitalGoodInfo: null,
        selectedIndex: 0
    },
    attached: function() {
        var e = this;
        return a(t.default.mark(function a() {
            var o, l, u;
            return t.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return e.setData({
                        platform: getApp().globalData.platform
                    }), t.next = 3, (0, n.getGoodsMtConfig)();

                  case 3:
                    l = t.sent, u = null == l || null === (o = l.digital_goods) || void 0 === o ? void 0 : o[0], 
                    e.setData({
                        digitalGoodInfo: r(r({}, u || {}), {}, {
                            goodsPriceStr: (0, i.getPriceStr)(null == u ? void 0 : u.goods_price),
                            originPriceStr: (0, i.getPriceStr)(null == u ? void 0 : u.origin_price)
                        })
                    });

                  case 6:
                  case "end":
                    return t.stop();
                }
            }, a);
        }))();
    },
    methods: {
        handleTapClose: function() {
            this.triggerEvent("close");
        },
        handleTapReset: function() {
            var e = this;
            return a(t.default.mark(function r() {
                return t.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        e.triggerEvent("ok");

                      case 1:
                      case "end":
                        return t.stop();
                    }
                }, r);
            }))();
        },
        handleTapQuestion: function() {
            wx.navigateTo({
                url: "/pages/alimeService/index"
            });
        }
    }
});