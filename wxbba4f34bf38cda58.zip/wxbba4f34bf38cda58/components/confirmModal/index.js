var t = require("../../@babel/runtime/helpers/objectDestructuringEmpty");

Component({
    properties: {},
    data: {
        show: !1,
        title: "",
        content: "",
        okText: "确定",
        cancelText: "取消",
        success: function(s) {
            t(s);
        },
        fail: function() {}
    },
    methods: {
        showModal: function(t) {
            this.setData({
                show: !0
            }), this.setData(t);
        },
        handleOk: function() {
            var t, s;
            this.setData({
                show: !1
            }), null === (t = (s = this.data).success) || void 0 === t || t.call(s, {
                confirm: !0
            });
        },
        handleCancel: function() {
            var t, s;
            this.setData({
                show: !1
            }), null === (t = (s = this.data).success) || void 0 === t || t.call(s, {
                cancel: !0
            });
        }
    }
});