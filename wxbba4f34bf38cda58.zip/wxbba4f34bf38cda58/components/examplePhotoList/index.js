Component({
    properties: {
        exampleList: {
            type: Array
        },
        columnNum: {
            type: Number
        }
    },
    data: {},
    methods: {}
});