var e, t = (e = require("../../@babel/runtime/regenerator")) && e.__esModule ? e : {
    default: e
}, n = require("../../@babel/runtime/helpers/asyncToGenerator"), a = require("../../service/api");

Component({
    properties: {
        actionName: {
            type: String
        },
        actionCost: {
            type: Number
        }
    },
    data: {
        balance: 0,
        platform: "",
        mtConfig: {},
        appGuideChargeContents: []
    },
    attached: function() {
        var e = this;
        return n(t.default.mark(function n() {
            var r, i, o, s;
            return t.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.next = 2, (0, a.queryCoinBalance)();

                  case 2:
                    return i = t.sent, t.next = 5, getApp().getFreshMtConfig();

                  case 5:
                    o = t.sent, s = null == o || null === (r = o.appGuideChargeContent) || void 0 === r ? void 0 : r.split("\\n"), 
                    e.setData({
                        mtConfig: o,
                        appGuideChargeContents: s
                    }), e.setData({
                        balance: i,
                        platform: getApp().globalData.platform
                    });

                  case 9:
                  case "end":
                    return t.stop();
                }
            }, n);
        }))();
    },
    methods: {
        handleOk: function() {
            this.triggerEvent("ok");
        },
        handleCancel: function() {
            this.triggerEvent("cancel");
        }
    }
});