Component({
    properties: {
        text: {
            type: String,
            value: "暂无数据"
        }
    },
    data: {},
    methods: {}
});