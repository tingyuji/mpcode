var e = require("query-string"), r = require("../../utils/wechat");

Component({
    properties: {},
    data: {},
    methods: {
        handleTapRefresh: function() {
            var t = (0, r.getCurrentPage)(), n = t.route, a = t.options;
            wx.reLaunch({
                url: "/".concat(n, "?").concat((0, e.stringify)(a, {
                    encode: !1
                }))
            });
        }
    }
});