var e, t = (e = require("../../@babel/runtime/regenerator")) && e.__esModule ? e : {
    default: e
}, n = require("../../@babel/runtime/helpers/asyncToGenerator");

Component({
    properties: {},
    data: {
        mtConfig: {},
        contents: []
    },
    attached: function() {
        var e = this;
        return n(t.default.mark(function n() {
            var r, a, i;
            return t.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.next = 2, getApp().getMtConfig();

                  case 2:
                    a = t.sent, i = null == a || null === (r = a.appGuideResetContent) || void 0 === r ? void 0 : r.split("\\n"), 
                    e.setData({
                        mtConfig: a,
                        contents: i
                    });

                  case 5:
                  case "end":
                    return t.stop();
                }
            }, n);
        }))();
    },
    methods: {
        handleOk: function() {
            this.triggerEvent("ok");
        },
        handleCancel: function() {
            this.triggerEvent("cancel");
        }
    }
});