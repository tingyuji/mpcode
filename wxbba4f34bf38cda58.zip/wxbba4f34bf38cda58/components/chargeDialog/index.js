var e, t = (e = require("../../@babel/runtime/regenerator")) && e.__esModule ? e : {
    default: e
}, n = require("../../@babel/runtime/helpers/objectSpread2"), r = require("../../@babel/runtime/helpers/asyncToGenerator"), a = require("../../utils/mt"), i = require("../../utils/dataUtils"), o = require("../../utils/pay"), s = require("../../service/api");

Component({
    properties: {},
    data: {
        sending: !1,
        balance: 0,
        coinGoodsList: [],
        selectedIndex: 0
    },
    attached: function() {
        var e = this;
        return r(t.default.mark(function r() {
            return t.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return e.recordPV({
                        spmA: "tixiang_wx",
                        spmB: "topup"
                    }), (0, s.queryCoinBalance)().then(function(t) {
                        e.setData({
                            balance: t
                        });
                    }), t.next = 4, (0, a.getGoodsMtConfig)().then(function(t) {
                        var r;
                        null != t && t.coin_goods && e.setData({
                            coinGoodsList: null == t || null === (r = t.coin_goods) || void 0 === r ? void 0 : r.map(function(e) {
                                return n(n({}, e), {}, {
                                    goodsPriceStr: (0, i.getPriceStr)(e.goods_price)
                                });
                            })
                        });
                    });

                  case 4:
                  case "end":
                    return t.stop();
                }
            }, r);
        }))();
    },
    methods: {
        handleTapClose: function() {
            this.triggerEvent("close");
        },
        handleTapItem: function(e) {
            var t = e.currentTarget.dataset.index;
            this.setData({
                selectedIndex: t
            });
        },
        handleTapCharge: function() {
            var e = this;
            return r(t.default.mark(function n() {
                var r, a, i, s, u;
                return t.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        if (getApp().recordClick("tixiang_wx.page_topup.action.confirmtopupbtn"), r = e.data, 
                        a = r.coinGoodsList, i = r.selectedIndex, s = a[i]) {
                            t.next = 5;
                            break;
                        }
                        return t.abrupt("return");

                      case 5:
                        if (!e.data.sending) {
                            t.next = 7;
                            break;
                        }
                        return t.abrupt("return");

                      case 7:
                        return e.setData({
                            sending: !0
                        }), t.next = 10, (0, o.buyGood)({
                            goodId: "coin_".concat(i),
                            goodPrice: s.goods_price
                        });

                      case 10:
                        u = t.sent, e.setData({
                            sending: !1
                        }), u && e.triggerEvent("success");

                      case 13:
                      case "end":
                        return t.stop();
                    }
                }, n);
            }))();
        },
        handleTapQuestion: function() {
            wx.navigateTo({
                url: "/pages/alimeService/index"
            });
        }
    }
});