Component({
    properties: {
        show: {
            type: Boolean
        },
        title: {
            type: String
        },
        terms: {
            type: Array
        },
        showButtons: {
            type: Boolean,
            value: !0
        }
    },
    data: {},
    methods: {
        handleOkTap: function() {
            this.triggerEvent("ok");
        },
        handleCancelTap: function() {
            this.triggerEvent("cancel");
        }
    }
});