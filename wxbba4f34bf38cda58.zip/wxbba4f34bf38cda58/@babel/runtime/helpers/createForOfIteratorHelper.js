var r = require("./unsupportedIterableToArray");

module.exports = function(n, e) {
    var t;
    if ("undefined" == typeof Symbol || null == n[Symbol.iterator]) {
        if (Array.isArray(n) || (t = r(n)) || e && n && "number" == typeof n.length) {
            t && (n = t);
            var o = 0, a = function() {};
            return {
                s: a,
                n: function() {
                    return o >= n.length ? {
                        done: !0
                    } : {
                        done: !1,
                        value: n[o++]
                    };
                },
                e: function(r) {
                    throw r;
                },
                f: a
            };
        }
        throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
    }
    var u, i = !0, l = !1;
    return {
        s: function() {
            t = n[Symbol.iterator]();
        },
        n: function() {
            var r = t.next();
            return i = r.done, r;
        },
        e: function(r) {
            l = !0, u = r;
        },
        f: function() {
            try {
                i || null == t.return || t.return();
            } finally {
                if (l) throw u;
            }
        }
    };
};