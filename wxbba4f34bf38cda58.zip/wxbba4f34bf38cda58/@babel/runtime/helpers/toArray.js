var r = require("./arrayWithHoles"), e = require("./iterableToArray"), t = require("./unsupportedIterableToArray"), u = require("./nonIterableRest");

module.exports = function(a) {
    return r(a) || e(a) || t(a) || u();
};