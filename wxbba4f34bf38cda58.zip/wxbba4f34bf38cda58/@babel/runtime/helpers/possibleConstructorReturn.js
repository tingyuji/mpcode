var e = require("./typeof"), r = require("./assertThisInitialized");

module.exports = function(t, i) {
    return !i || "object" !== e(i) && "function" != typeof i ? r(t) : i;
};