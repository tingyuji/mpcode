var e = require("./setPrototypeOf"), t = require("./isNativeReflectConstruct");

function r(o, u, n) {
    return t() ? module.exports = r = Reflect.construct : module.exports = r = function(t, r, o) {
        var u = [ null ];
        u.push.apply(u, r);
        var n = new (Function.bind.apply(t, u))();
        return o && e(n, o.prototype), n;
    }, r.apply(null, arguments);
}

module.exports = r;