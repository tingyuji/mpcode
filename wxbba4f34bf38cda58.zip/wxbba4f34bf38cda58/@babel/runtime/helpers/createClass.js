function e(e, r) {
    for (var n = 0; n < r.length; n++) {
        var t = r[n];
        t.enumerable = t.enumerable || !1, t.configurable = !0, "value" in t && (t.writable = !0), 
        Object.defineProperty(e, t.key, t);
    }
}

module.exports = function(r, n, t) {
    return n && e(r.prototype, n), t && e(r, t), r;
};