var e = require("./setPrototypeOf");

module.exports = function(r, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
    r.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: r,
            writable: !0,
            configurable: !0
        }
    }), t && e(r, t);
};