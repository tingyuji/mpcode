module.exports = function(e) {
    if (null == e) throw new TypeError("Cannot destructure undefined");
};