Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.formatDuration = void 0, exports.getSemanticTime = function(e) {
    var t = "";
    "number" == typeof e && (t = e > 6e4 ? "".concat(r(e, !0), "前") : "刚刚");
    return t;
};

var e = require("../@babel/runtime/helpers/slicedToArray");

require("../@babel/runtime/helpers/Objectentries");

var r = function(r) {
    var t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
    r < 0 && (r = -r);
    var o = {
        "天": Math.floor(r / 864e5),
        "小时": Math.floor(r / 36e5) % 24,
        "分钟": Math.floor(r / 6e4) % 60,
        "秒": Math.floor(r / 1e3) % 60
    }, n = Object.entries(o).filter(function(e) {
        return 0 !== e[1];
    }).map(function(r) {
        var t = e(r, 2), o = t[0], n = t[1];
        return "".concat(n).concat(o);
    });
    return t ? n[0] : n.join("");
};

exports.formatDuration = r;