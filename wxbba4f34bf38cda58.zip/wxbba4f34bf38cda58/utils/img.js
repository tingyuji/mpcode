Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.addListShowParam = function(t) {
    if (!t || 0 === t.length) return t;
    return t.forEach(function(t) {
        t.url && (t.showUrl = l(t.url));
    }), t;
}, exports.addRotateParamIfRotated = function(t, r) {
    return s.apply(this, arguments);
}, exports.addShowParam = l, exports.checkPhotoRotated = function(t) {
    return i.apply(this, arguments);
}, exports.convertPicInfoRotateParam = p, exports.convertPicListRotateParam = function(t) {
    if (!t) return [];
    return t.forEach(function(t) {
        p(t);
    }), t;
}, exports.convertPicRotateParam = f, exports.getOssRotateParamStr = function(t) {
    return u.apply(this, arguments);
}, exports.getWatermarkUrl = function(t) {
    var r = (0, e.default)(t), a = r.protocol, o = r.hostname, c = r.pathname, u = r.query;
    return u["x-oss-process"] = "image/watermark,text_5aaZ6bit55u45py6,color_FFFFFF,size_24,fill_1,padx_80,pady_80,t_8,rotate_345", 
    "".concat(a, "//").concat(o).concat(c, "?").concat((0, n.stringify)(u, {
        encode: !1
    }));
};

var t = o(require("../@babel/runtime/regenerator")), r = require("../@babel/runtime/helpers/asyncToGenerator"), e = o(require("parse-location")), n = require("query-string"), a = require("./util");

function o(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

function c(t) {
    return {
        up: 0,
        "up-mirrored": 0,
        down: 180,
        "down-mirrored": 180,
        left: 90,
        "left-mirrored": 90,
        right: 270,
        "right-mirrored": 270
    }[t];
}

function u() {
    return (u = r(t.default.mark(function r(e) {
        var n;
        return t.default.wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return t.next = 2, (0, a.promisify)(wx.getImageInfo)({
                    src: e
                }).catch(function() {
                    return null;
                });

              case 2:
                if ((n = t.sent) && 0 !== c(n.orientation)) {
                    t.next = 5;
                    break;
                }
                return t.abrupt("return", "");

              case 5:
                return t.abrupt("return", "x-oss-process=image/rotate,".concat(c(n.orientation)));

              case 6:
              case "end":
                return t.stop();
            }
        }, r);
    }))).apply(this, arguments);
}

function i() {
    return (i = r(t.default.mark(function r(e) {
        var n;
        return t.default.wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return t.next = 2, (0, a.promisify)(wx.getImageInfo)({
                    src: e
                }).catch(function() {
                    return null;
                });

              case 2:
                if (n = t.sent) {
                    t.next = 5;
                    break;
                }
                return t.abrupt("return", !1);

              case 5:
                return t.abrupt("return", 0 !== c(n.orientation));

              case 6:
              case "end":
                return t.stop();
            }
        }, r);
    }))).apply(this, arguments);
}

function s() {
    return (s = r(t.default.mark(function r(e, n) {
        var o, u, i;
        return t.default.wrap(function(r) {
            for (;;) switch (r.prev = r.next) {
              case 0:
                if (e && 0 !== e.length) {
                    r.next = 2;
                    break;
                }
                return r.abrupt("return", []);

              case 2:
                o = [], u = t.default.mark(function r(u) {
                    var i, s, f, p, l;
                    return t.default.wrap(function(t) {
                        for (;;) switch (t.prev = t.next) {
                          case 0:
                            return i = e[u], s = n.get(i), f = i, p = [], l = (0, a.promisify)(wx.getImageInfo)({
                                src: s
                            }).catch(function(t) {
                                console.log("err ", i, t);
                            }), p.push(l), t.next = 8, Promise.all(p);

                          case 8:
                            t.sent.filter(function(t) {
                                return t;
                            }).forEach(function(t) {
                                if (t) {
                                    console.log("imageinfo res: ", t);
                                    var r = c(t.orientation);
                                    r && (f = "".concat(i, "?rotate=").concat(r));
                                }
                                o.push(f);
                            });

                          case 10:
                          case "end":
                            return t.stop();
                        }
                    }, r);
                }), i = 0;

              case 5:
                if (!(i < e.length)) {
                    r.next = 10;
                    break;
                }
                return r.delegateYield(u(i), "t0", 7);

              case 7:
                i++, r.next = 5;
                break;

              case 10:
                return r.abrupt("return", o);

              case 11:
              case "end":
                return r.stop();
            }
        }, r);
    }))).apply(this, arguments);
}

function f(t) {
    var r = (0, e.default)(t), a = r.protocol, o = r.hostname, c = r.pathname, u = r.query;
    return u.rotate ? (u["x-oss-process"] = "image/rotate,".concat(u.rotate, "/format,jpg/interlace,1/quality,q_50"), 
    delete u.rotate) : u["x-oss-process"] = "image/format,jpg/interlace,1/quality,q_50", 
    "".concat(a, "//").concat(o).concat(c, "?").concat((0, n.stringify)(u, {
        encode: !1
    }));
}

function p(t) {
    return t.picUrl = f(t.picUrl), t;
}

function l(t) {
    if (!t) return "";
    var r = (0, e.default)(t), a = r.protocol, o = r.hostname, c = r.pathname, u = r.query;
    return u["x-oss-process"] = "image/format,jpg/interlace,1/quality,q_50", "".concat(a, "//").concat(o).concat(c, "?").concat((0, 
    n.stringify)(u, {
        encode: !1
    }));
}