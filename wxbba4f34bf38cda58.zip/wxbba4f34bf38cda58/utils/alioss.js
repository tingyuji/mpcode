Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getOssFilePath = i, exports.uploadFilesToOss = function(e, t) {
    return l.apply(this, arguments);
};

var e = o(require("../@babel/runtime/regenerator")), t = require("../@babel/runtime/helpers/asyncToGenerator"), r = o(require("crypto-js")), n = require("js-base64"), s = require("../service/api"), a = o(require("./random"));

function o(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

var u = "https://alex-photo-generate.oss-cn-shanghai.aliyuncs.com";

function c(e, t) {
    return r.default.enc.Base64.stringify(r.default.HmacSHA1(t, e));
}

function i(e) {
    var t, r = e.substring(e.lastIndexOf("."));
    return "".concat("photos", "/").concat((null === (t = getApp().globalData.userInfo) || void 0 === t ? void 0 : t.userId) || "default", "/").concat(+new Date(), "-").concat(a.default.rand(8)).concat(r);
}

function l() {
    return (l = t(e.default.mark(function t(r, a) {
        var o, l, p, f, h, d, g, y, x, b, m, v, P, w;
        return e.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                if (r && 0 !== r.length) {
                    e.next = 2;
                    break;
                }
                return e.abrupt("return", Promise.resolve({
                    successPaths: [],
                    pathMap: new Map()
                }));

              case 2:
                return e.next = 4, (0, s.getOssProps)().catch(function() {
                    return null;
                });

              case 4:
                if (o = e.sent) {
                    e.next = 7;
                    break;
                }
                return e.abrupt("return", Promise.resolve({
                    successPaths: [],
                    pathMap: new Map()
                }));

              case 7:
                for (l = o.accessKeyId, p = o.accessKeySecret, f = o.securityToken, (h = new Date()).setHours(h.getHours() + 1), 
                d = {
                    expiration: h.toISOString(),
                    conditions: [ [ "content-length-range", 0, 1073741824 ] ]
                }, g = n.Base64.encode(JSON.stringify(d)), y = c(p, g), x = [], b = [], m = [], 
                v = new Map(), P = function(e) {
                    var t = r[e], n = a || i(t), s = new Promise(function(e, r) {
                        wx.uploadFile({
                            url: u,
                            filePath: t,
                            name: "file",
                            formData: {
                                key: n,
                                policy: g,
                                OSSAccessKeyId: l,
                                signature: y,
                                "x-oss-security-token": f
                            },
                            success: function(r) {
                                console.log("res", r), 204 === r.statusCode && (console.log("上传成功"), x.push(n), 
                                v.set(n, t), e(n));
                            },
                            fail: function(t) {
                                console.log(t), b.push(n), e(!1);
                            }
                        });
                    });
                    m.push(s);
                }, w = 0; w < r.length; w++) P(w);
                return e.next = 21, Promise.all(m).catch(function() {
                    wx.showToast({
                        icon: "error",
                        title: "上传失败"
                    });
                });

              case 21:
                return e.abrupt("return", {
                    successPaths: x,
                    errorPaths: b,
                    pathMap: v
                });

              case 22:
              case "end":
                return e.stop();
            }
        }, t);
    }))).apply(this, arguments);
}