Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getCurrentPage = function() {
    var e = getCurrentPages();
    return e[e.length - 1];
}, exports.getWxLoginCode = function() {
    return o.apply(this, arguments);
}, exports.navigateToPage = function(e) {
    for (var r = e.url, t = getCurrentPages(), n = -1, o = 0; o < t.length; o++) {
        var u = t[o], a = u.route, i = u.options, c = "/" + a + (Object.keys(i).length > 0 ? "?".concat((0, 
        s.stringify)(i, {
            encode: !1
        })) : "");
        if (r == c) {
            n = t.length - o - 1;
            break;
        }
    }
    -1 === n ? wx.navigateTo({
        url: r
    }) : wx.navigateBack({
        delta: n
    });
}, exports.requestSubscribeMessage = function(e) {
    var r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {
        successText: "订阅成功"
    }, t = r.successText;
    wx.requestSubscribeMessage({
        tmplIds: [ e ],
        success: function(r) {
            console.log("subscrible success res: ", r), "requestSubscribeMessage:ok" === r.errMsg && ("accept" === r[e] ? wx.showToast({
                icon: "none",
                title: t
            }) : "reject" === r[e] && wx.showToast({
                icon: "none",
                title: "您已关闭通知，请到右上角设置->订阅消息中打开接收通知"
            }));
        },
        fail: function(e) {
            console.log("subscrible fail res: ", e);
        }
    });
};

var e, r = (e = require("../@babel/runtime/regenerator")) && e.__esModule ? e : {
    default: e
}, t = require("../@babel/runtime/helpers/asyncToGenerator"), s = require("query-string"), n = require("./util");

function o() {
    return (o = t(r.default.mark(function e() {
        var t;
        return r.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return e.next = 2, (0, n.promisify)(wx.login)();

              case 2:
                return t = e.sent, e.abrupt("return", null == t ? void 0 : t.code);

              case 4:
              case "end":
                return e.stop();
            }
        }, e);
    }))).apply(this, arguments);
}