Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getMtConfig = exports.getGoodsMtConfig = exports.default = void 0;

var e, t = (e = require("../@babel/runtime/regenerator")) && e.__esModule ? e : {
    default: e
}, r = require("../@babel/runtime/helpers/objectSpread2"), a = require("../@babel/runtime/helpers/asyncToGenerator"), n = require("../@babel/runtime/helpers/classCallCheck"), i = require("../@babel/runtime/helpers/createClass"), o = require("../config");

var s = function() {
    function e(t) {
        var r = t.id, a = t.preId, i = t.isPre;
        n(this, e), this.isPre = !1, this.wapaUrl = "", this.publicUrl = "", this.wapaUrl = this.getWapaUrl(a), 
        this.publicUrl = this.getPublishUrl(r), this.isPre = i;
    }
    var o;
    return i(e, [ {
        key: "getWapaUrl",
        value: function(e) {
            return "https://mt2.alibaba-inc.com/core/data/dataEntityMock.do?id=".concat(e, "&t=").concat(+new Date(), "&.js");
        }
    }, {
        key: "getPublishUrl",
        value: function(e) {
            return "https://hudong.alicdn.com/api/data/v2/".concat(e, ".js?t=").concat(+new Date(), "&.js");
        }
    }, {
        key: "fetch",
        value: (o = a(t.default.mark(function e(a, n) {
            var i, o, s, u;
            return t.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return i = this.isPre, o = this.wapaUrl, s = this.publicUrl, a && (i = "pre" === a), 
                    u = i ? o : s, e.abrupt("return", new Promise(function(e, t) {
                        wx.request(r({
                            url: u,
                            method: "GET",
                            header: {
                                "content-type": "application/json"
                            },
                            dataType: "json",
                            success: function(t) {
                                e({
                                    loadedData: t.data,
                                    __res: t
                                });
                            },
                            fail: function(e) {
                                console.log("mt fail: ", e), t({
                                    loadedData: void 0,
                                    __res: e
                                });
                            }
                        }, n));
                    }));

                  case 4:
                  case "end":
                    return e.stop();
                }
            }, e, this);
        })), function(e, t) {
            return o.apply(this, arguments);
        })
    } ]), e;
}();

exports.default = s;

exports.getMtConfig = function(e) {
    var t = new s({
        id: "ceef6b453c184192b27490b501cfa2ea",
        preId: "262302"
    }), r = e || (o.minEnvVersion === o.MiniEnv.release ? "pub" : "pre");
    return t.fetch(r).then(function(e) {
        return e.loadedData;
    });
};

exports.getGoodsMtConfig = function() {
    var e = o.minEnvVersion === o.MiniEnv.release ? "pub" : "pre";
    return new s({
        id: "pre" === e ? "f27016802ce44062bbe2fa94db12c26e" : "f95c350fa8394fce98c15930b0f3c3f4"
    }).fetch("pub").then(function(e) {
        return e.loadedData;
    });
};