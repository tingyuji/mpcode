Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.fieldNameDimMap = exports.aemSend = void 0, exports.initUniTrack = function() {
    (0, t.default)({
        pkgSize: 2,
        appkey: "YOUKU_MIAOYA_WX_MINI_APP",
        logKey: {
            exp: "/youku.h5web.control",
            clk: "/youku.h5web.control",
            vv: "/youkuminiapp.player.vv",
            ts: "/youkuminiapp.player.ts"
        },
        metaInfo: {
            "aplus-rhost-multi": [ {
                "aplus-rhost-v": "gm.mmstat.com/yt",
                "aplus-rhost-g": "gm.mmstat.com/yt"
            }, {
                "aplus-rhost-v": "log.mmstat.com",
                "aplus-rhost-g": "wgo.mmstat.com"
            } ],
            pageConfig: {}
        }
    });
}, exports.recordClick = function(e, t) {
    var a = {
        expdata: JSON.stringify([ {
            spm: e,
            scm: "",
            exargs: {
                appkey: "YOUKU_MIAOYA_WX_MINI_APP",
                "data-spm": e,
                "data-trackinfo": t
            }
        } ]),
        appkey: "YOUKU_MIAOYA_WX_MINI_APP"
    };
    getApp().aplus.record("/youku.h5web.control", "CLK", a, "POST", "wgo.mmstat.com/yt");
};

var e = require("../@babel/runtime/helpers/objectSpread2"), t = r(require("@ali/universal-track/wechat-miniprogram")), a = r(require("@ali/aes-tracker-miniapp")), i = r(require("@ali/aes-tracker-plugin-event/index-miniapp"));

function r(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

getApp();

a.default.setConfig({
    pid: "miaoyaxiangji",
    user_type: 101
}), a.default.log = a.default.before(a.default.log, function(e, t) {
    var i, r;
    wx.getStorageSync("USER_INFO");
    return a.default.setConfig({
        uid: (null === (i = getApp().globalData) || void 0 === i || null === (r = i.userInfo) || void 0 === r ? void 0 : r.userId) || "--",
        username: ""
    }), [ e, t ];
});

var o = {
    userId: "dim1"
};

exports.fieldNameDimMap = o;

var u = {
    extra: "c1"
}, n = function(e, t) {
    if (!e) return {};
    var a = {};
    return Object.keys(e).forEach(function(i) {
        var r = t[i];
        r && (a[r] = e[i]);
    }), a;
};

exports.aemSend = function(t, r, p) {
    r && a.default.setConfig(n(r, o));
    var s = p && !a.default.getConfig().uid;
    s && a.default.setConfig({
        uid: ""
    }), (0, i.default)(t, e(e({
        et: "OTHER"
    }, r), n(r, u))), r && a.default.setConfig({
        dim1: "",
        dim2: "",
        dim3: "",
        dim4: "",
        dim5: "",
        dim6: "",
        dim7: ""
    }), s && a.default.setConfig({
        uid: void 0
    });
};