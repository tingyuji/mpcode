Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.SeriesWaterfallHook = void 0, exports.clearMySetInterval = function(t) {
    clearTimeout(t.timeoutId);
}, exports.formatTime = void 0, exports.formatVideoTime = function(t) {
    var e = Math.floor(t / 3600), r = Math.floor(t % 3600 / 60), n = Math.round(t % 60);
    return [ e, r > 9 ? r : "0" + r || "00", n > 9 ? n : "0" + n ].filter(Boolean).join(":");
}, exports.getFormatedSize = exports.formatVideoTimePro = void 0, exports.getStrLen = function(t) {
    if (!t) return 0;
    return t.replace(/[\u0391-\uFFE5]/g, "ab").length;
}, exports.mySetInterval = function(t, e) {
    var r = arguments.length > 2 && void 0 !== arguments[2] && arguments[2], n = {
        timeoutId: 0
    };
    function o(t, e) {
        var i = r && 0 === n.timeoutId ? 0 : e;
        return setTimeout(function() {
            t(), n.timeoutId = o(t, e);
        }, i);
    }
    return n.timeoutId = o(t, e), n;
}, exports.promisify = void 0, exports.spArr = function(t, e) {
    for (var r = [], n = 0; n < t.length; ) r.push(t.slice(n, n += e));
    return r;
}, exports.splitString = function(t, e) {
    for (var r = [], n = 0; n < t.length; ) {
        for (var o = [], i = 0; i < e; ) o.push(t[n]), /[^\x00-\xff]/.test(t[n]) ? i += 2 : i++, 
        n++;
        r.push(o.join(""));
    }
    return r;
}, exports.throttle = function(t, e) {
    null != e && null != e || (e = 1500);
    var r = null;
    return function() {
        var n = +new Date();
        (n - r > e || !r) && (t.apply(this, arguments), r = n);
    };
};

var t, e = (t = require("../@babel/runtime/regenerator")) && t.__esModule ? t : {
    default: t
}, r = require("../@babel/runtime/helpers/asyncToGenerator"), n = require("../@babel/runtime/helpers/toArray"), o = require("../@babel/runtime/helpers/toConsumableArray"), i = require("../@babel/runtime/helpers/classCallCheck"), a = require("../@babel/runtime/helpers/createClass");

exports.formatTime = function(t) {
    var e = t.getFullYear(), r = t.getMonth() + 1, n = t.getDate(), o = t.getHours(), i = t.getMinutes(), a = t.getSeconds();
    return [ e, r, n ].map(u).join("/") + " " + [ o, i, a ].map(u).join(":");
};

var u = function(t) {
    var e = t.toString();
    return e[1] ? e : "0" + e;
};

exports.promisify = function(t) {
    return function(e) {
        return new Promise(function(r, n) {
            var o = Object.assign({}, e, {
                success: r,
                fail: n
            });
            t(o);
        });
    };
};

exports.getFormatedSize = function(t) {
    var e = "";
    e = t < 1024 ? "".concat(t.toFixed(2), "B") : t < 1048576 ? "".concat((t / 1024).toFixed(2), "KB") : t < 1073741824 ? "".concat((t / 1048576).toFixed(2), "MB") : "".concat((t / 1073741824).toFixed(2), "GB");
    var r = "".concat(e), n = r.indexOf(".");
    return "00" == r.substr(n + 1, 2) ? r.substring(0, n) + r.substr(n + 3, 2) : e;
};

exports.formatVideoTimePro = function(t, e) {
    return function(r) {
        var n = (r % 60 || 0).toFixed(3).split("."), o = "";
        "TIME_CODE" === t ? o = ".".concat(n[1]) : "FPS" === t && (e || console.error("format方法需要传入FPS"), 
        o = ":".concat(Math.floor(Number(n[1]) * e / 1e3)));
        for (var i = [ "".concat(n[0].padStart(2, "0")).concat(o) ], a = Math.floor(r / 60) || 0; i.length < 3; ) i.unshift("".concat(i.length < 2 ? a % 60 : a).padStart(2, "0")), 
        a = Math.floor(a / 60);
        return i.join(":");
    };
};

var s = function() {
    function t(e) {
        i(this, t), this.ctx = e, this.tasks = [];
    }
    return a(t, [ {
        key: "compose",
        value: function(t) {
            return this.tasks = [].concat(o(this.tasks), o(t)), this;
        }
    }, {
        key: "add",
        value: function(t) {
            return this.tasks.push(t), this;
        }
    }, {
        key: "call",
        value: function() {
            for (var o = this, i = arguments.length, a = new Array(i), u = 0; u < i; u++) a[u] = arguments[u];
            var s = n(this.tasks), c = s[0], l = s.slice(1), f = [];
            return c = c.bind(this.ctx), new Promise(function(n) {
                var i = function(t, e) {
                    e.splice(t, e.length - t), n(null);
                };
                l.reduce(function() {
                    var u = r(e.default.mark(function r(u, s, c, l) {
                        var p;
                        return e.default.wrap(function(e) {
                            for (;;) switch (e.prev = e.next) {
                              case 0:
                                if (s = s.bind(o.ctx), "[object Promise]" !== Object.prototype.toString.call(u)) {
                                    e.next = 5;
                                    break;
                                }
                                return e.abrupt("return", u.then(function(e) {
                                    if (f.push(e), e === t.INTERRUPT_HANDLER) i(c, l); else {
                                        if (c !== l.length - 1) return e ? s(e) : s.apply(void 0, a);
                                        var r = e ? s(e) : s.apply(void 0, a);
                                        "[object Promise]" === Object.prototype.toString.call(s) ? r.then(function(t) {
                                            n(t);
                                        }) : n(r);
                                    }
                                }).catch(function(t) {
                                    console.log("Errors occur in pipline", t), i(c, l);
                                }));

                              case 5:
                                if (f.push(u), u !== t.INTERRUPT_HANDLER) {
                                    e.next = 10;
                                    break;
                                }
                                i(c, l), e.next = 12;
                                break;

                              case 10:
                                return c === l.length - 1 && (p = u ? s(u) : s.apply(void 0, a), "[object Promise]" === Object.prototype.toString.call(s) ? p.then(function(t) {
                                    n(t);
                                }) : n(p)), e.abrupt("return", s(u));

                              case 12:
                              case "end":
                                return e.stop();
                            }
                        }, r);
                    }));
                    return function(t, e, r, n) {
                        return u.apply(this, arguments);
                    };
                }(), c.apply(void 0, a));
            });
        }
    } ]), t;
}();

exports.SeriesWaterfallHook = s, s.INTERRUPT_HANDLER = "INTTERRUPT";