Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.buyGood = void 0;

var e, r = (e = require("../@babel/runtime/regenerator")) && e.__esModule ? e : {
    default: e
}, t = require("../@babel/runtime/helpers/asyncToGenerator"), n = require("../@babel/runtime/helpers/objectSpread2"), a = require("../@babel/runtime/helpers/objectWithoutProperties"), o = require("../service/api"), u = require("../config"), c = [ "packageStr", "tradeOrderId" ];

var i = function(e) {
    var u = e.packageStr, i = e.tradeOrderId, s = a(e, c);
    return new Promise(function(e, a) {
        var c;
        wx.requestPayment(n(n({
            signType: "RSA"
        }, s), {}, {
            package: u,
            success: (c = t(r.default.mark(function n(a) {
                var u;
                return r.default.wrap(function(n) {
                    for (;;) switch (n.prev = n.next) {
                      case 0:
                        console.log("resres", a), (u = function() {
                            var n = t(r.default.mark(function t() {
                                var n, a;
                                return r.default.wrap(function(r) {
                                    for (;;) switch (r.prev = r.next) {
                                      case 0:
                                        return r.next = 2, (0, o.queryOrder)({
                                            order_id: i,
                                            scene: "applet"
                                        }).catch(function() {
                                            return null;
                                        });

                                      case 2:
                                        n = r.sent, console.log("order info", n), n.orderId, "success" === (a = n.orderState) ? e(!0) : "notpay" === a ? setTimeout(function() {
                                            u();
                                        }, 1e3) : (wx.showToast({
                                            icon: "none",
                                            title: "支付失败，请重新支付",
                                            duration: 3e3
                                        }), e(!1));

                                      case 6:
                                      case "end":
                                        return r.stop();
                                    }
                                }, t);
                            }));
                            return function() {
                                return n.apply(this, arguments);
                            };
                        }())();

                      case 3:
                      case "end":
                        return n.stop();
                    }
                }, n);
            })), function(e) {
                return c.apply(this, arguments);
            }),
            fail: function(r) {
                console.log("pay fail", r), wx.showToast({
                    icon: "none",
                    title: "支付失败，请重新支付",
                    duration: 3e3
                }), e(!1);
            }
        }));
    });
}, s = function() {
    var e = t(r.default.mark(function e(t) {
        var n, a, c, s, d, p;
        return r.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return e.next = 2, (0, o.createOrder)({
                    appId: u.app_id,
                    goodsId: t.goodId,
                    orderScene: "applet",
                    platform: "wechat",
                    deviceType: "android",
                    goodsPrice: t.goodPrice
                }).catch(function() {
                    return !1;
                });

              case 2:
                if (!(n = e.sent)) {
                    e.next = 8;
                    break;
                }
                return a = n.timeStamp, c = n.nonceStr, s = n.packageStr, d = n.paySign, p = n.tradeOrderId, 
                e.next = 7, i({
                    timeStamp: a,
                    nonceStr: c,
                    packageStr: s,
                    paySign: d,
                    tradeOrderId: p
                });

              case 7:
                return e.abrupt("return", e.sent);

              case 8:
                return e.abrupt("return", Promise.resolve(!1));

              case 9:
              case "end":
                return e.stop();
            }
        }, e);
    }));
    return function(r) {
        return e.apply(this, arguments);
    };
}();

exports.buyGood = s;