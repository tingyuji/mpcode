Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getLastChar = function(r) {
    if (!r) return r;
    return r.substr(r.length - 1);
}, exports.getLastTwoChars = function(r) {
    if (!r) return r;
    return r.substr(r.length - 2);
}, exports.getPriceStr = function(r) {
    if (null == r) return "--";
    return "".concat(r / 100);
}, exports.getRandomNum = void 0, exports.isNumber = function(r) {
    return null !== r && "" !== r && !isNaN(Number(r));
}, exports.safeParseJSONString = function(r) {
    var t, e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
    if (!r) return e;
    try {
        t = JSON.parse(r);
    } catch (r) {
        t = e;
    }
    t || (t = e);
    return t;
};

exports.getRandomNum = function(r, t, e) {
    var n = [];
    if (e < 1) return [];
    var u = e;
    for (t - r < e && (u = t - r + 1); ;) {
        var o = Math.floor(Math.random() * (t - r) + r);
        if (n.indexOf(o) <= 0 && n.push(o), n.length >= u) break;
    }
    return n;
};