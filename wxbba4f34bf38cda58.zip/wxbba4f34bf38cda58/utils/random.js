Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var e = {
    rand: function(e, r) {
        var t, o = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz".split(""), a = [], n = 0;
        if (r = r || o.length, e) for (n = 0; n < e; n++) a[n] = o[0 | Math.random() * r]; else for (a[8] = a[13] = a[18] = a[23] = "-", 
        a[14] = "4", n = 0; n < 36; n++) a[n] || (t = 0 | 16 * Math.random(), a[n] = o[19 === n ? 3 & t | 8 : t]);
        return a.join("");
    }
};

exports.default = e;