var e = a(require("../../@babel/runtime/regenerator")), t = require("../../@babel/runtime/helpers/asyncToGenerator"), r = a(require("../../behaviors/pvBehavior")), n = a(require("../../behaviors/shareBehavior"));

function a(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

Page({
    behaviors: [ r.default, n.default ],
    data: {
        albumInfo: null,
        photoList: []
    },
    onLoad: function(r) {
        var n = this;
        return t(e.default.mark(function t() {
            var a, o, i, u;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return o = r.code, e.next = 3, getApp().getMtConfig();

                  case 3:
                    i = e.sent, u = null === (a = i.styleGifs) || void 0 === a ? void 0 : a.find(function(e) {
                        return e.code === o;
                    }), n.setData({
                        albumInfo: u,
                        photoList: null == u ? void 0 : u.photos
                    }), wx.setNavigationBarTitle({
                        title: null == u ? void 0 : u.title
                    });

                  case 7:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    onUnload: function() {},
    handleTapGenBtn: function() {
        wx.reLaunch({
            url: "/pages/index/index?autoShowLoginDialog=1"
        });
    },
    handleToPreview: function(e) {
        var t = e.currentTarget.dataset.item, r = this.data.photoList;
        wx.previewImage({
            current: t.url,
            urls: r.map(function(e) {
                return e.url;
            }),
            showmenu: !1
        });
    }
});