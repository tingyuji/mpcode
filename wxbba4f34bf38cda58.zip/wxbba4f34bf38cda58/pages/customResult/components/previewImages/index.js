var e, t = (e = require("../../../../@babel/runtime/regenerator")) && e.__esModule ? e : {
    default: e
}, r = require("../../../../@babel/runtime/helpers/asyncToGenerator"), n = require("../../../../service/api");

Component({
    properties: {
        currentIndex: Number,
        albumId: Number,
        dataSource: {
            type: Array,
            default: [],
            observer: function(e, t) {
                this.setData({
                    imagesList: e
                });
            }
        },
        showPrecisionButton: {
            type: Boolean,
            value: !0
        }
    },
    data: {
        imagesList: [],
        indicatorDots: !1,
        vertical: !1,
        autoplay: !1,
        interval: 2e3,
        duration: 500,
        swiperCurrent: -1,
        downloadCount: ""
    },
    lifetimes: {
        attached: function() {
            var e = wx.getStorageSync("aigcTermsAgreed");
            e && this.setData({
                aigcTermsAgreed: e
            }), this.init();
        },
        detached: function() {}
    },
    methods: {
        init: function() {
            var e = this;
            return r(t.default.mark(function r() {
                var a;
                return t.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return t.next = 2, (0, n.getDownloadNum)({});

                      case 2:
                        a = t.sent, e.setData({
                            downloadCount: a,
                            swiperCurrent: e.properties.currentIndex
                        });

                      case 4:
                      case "end":
                        return t.stop();
                    }
                }, r);
            }))();
        },
        swiperChange: function(e) {
            this.setData({
                swiperCurrent: e.detail.current
            });
        },
        handleClosePreview: function(e) {
            this.triggerEvent("handleToPreview", !1);
        },
        handleDownloadImage: function(e) {
            var a = this;
            return r(t.default.mark(function r() {
                var i, o;
                return t.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return getApp().recordClick("tixiang_wx.fullpicresult.actions.downloadbtn"), i = e.currentTarget.dataset.item, 
                        o = i[a.data.swiperCurrent], console.log("下载原图", i, o), t.next = 6, (0, n.getDownloadNum)({});

                      case 6:
                        t.sent > 0 ? (console.log("已获取授权，可以保存图片到相册"), a.wxApiDownload(o.url, o.id)) : wx.showToast({
                            title: "下载次数不足",
                            icon: "error",
                            duration: 2e3
                        });

                      case 8:
                      case "end":
                        return t.stop();
                    }
                }, r);
            }))();
        },
        wxApiDownload: function(e, a) {
            var i, o = this;
            wx.downloadFile({
                url: e,
                success: (i = r(t.default.mark(function e(i) {
                    return t.default.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            wx.saveImageToPhotosAlbum({
                                filePath: i.tempFilePath,
                                success: function() {
                                    var e = r(t.default.mark(function e() {
                                        var r;
                                        return t.default.wrap(function(e) {
                                            for (;;) switch (e.prev = e.next) {
                                              case 0:
                                                return e.next = 2, (0, n.downloadPic)({
                                                    picture_id: a
                                                });

                                              case 2:
                                                return wx.showToast({
                                                    title: "保存成功",
                                                    icon: "success",
                                                    duration: 2e3
                                                }), e.next = 5, (0, n.getDownloadNum)({});

                                              case 5:
                                                r = e.sent, o.setData({
                                                    downloadCount: r
                                                });

                                              case 7:
                                              case "end":
                                                return e.stop();
                                            }
                                        }, e);
                                    }));
                                    return function() {
                                        return e.apply(this, arguments);
                                    };
                                }(),
                                fail: function(e) {
                                    console.log("error: ", e), wx.showToast({
                                        title: "保存失败",
                                        icon: "error",
                                        duration: 2e3
                                    });
                                }
                            });

                          case 1:
                          case "end":
                            return e.stop();
                        }
                    }, e);
                })), function(e) {
                    return i.apply(this, arguments);
                }),
                fail: function(e) {
                    console.log("error: ", e), wx.showToast({
                        title: "下载失败",
                        icon: "none",
                        duration: 2e3
                    });
                }
            });
        },
        handleShareImage: function(e) {
            var a = this;
            return r(t.default.mark(function r() {
                var i, o, u;
                return t.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return getApp().recordClick("tixiang_wx.fullpicresult.actions.momentsharebtn"), 
                        wx.showLoading(), i = e.currentTarget.dataset.item, o = i[a.data.swiperCurrent], 
                        t.next = 6, (0, n.genShareInfo)({
                            source_pic_oss_url: o.url,
                            album_id: a.properties.albumId,
                            album_pic_id: o.id
                        });

                      case 6:
                        u = t.sent, console.log("合成带二维码的url图片", u), wx.downloadFile({
                            url: null == u ? void 0 : u.picOssUrl,
                            success: function(e) {
                                console.log(e), wx.hideLoading(), wx.showShareImageMenu({
                                    path: e.tempFilePath,
                                    success: function(e) {}
                                });
                            },
                            fail: function(e) {
                                console.log(e);
                            }
                        });

                      case 9:
                      case "end":
                        return t.stop();
                    }
                }, r);
            }))();
        },
        handlePrecisionTap: function() {
            var e = this.data, t = e.imagesList, r = e.currentIndex;
            this.triggerEvent("precisionTap", t[r]);
        },
        handleToggleFavorite: function(e) {
            var a = this;
            return r(t.default.mark(function r() {
                var i, o;
                return t.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return i = e.currentTarget.dataset.item, o = i[a.data.swiperCurrent], t.next = 4, 
                        (0, n.likePicture)({
                            like_deal_type: 1 === o.likeFlag ? 0 : 1,
                            picture_id: o.id
                        });

                      case 4:
                        a.triggerEvent("likeSuccess", o);

                      case 5:
                      case "end":
                        return t.stop();
                    }
                }, r);
            }))();
        },
        handleHdTap: function() {
            cubeautifulpic({
                template_id: template_id,
                posture_pic_url: posture_pic_url,
                album_pic_id: curPic.id
            });
        }
    }
});