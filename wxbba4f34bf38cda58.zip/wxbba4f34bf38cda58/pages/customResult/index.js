var e = l(require("../../@babel/runtime/regenerator")), t = require("../../@babel/runtime/helpers/asyncToGenerator"), a = l(require("../../behaviors/pvBehavior")), n = l(require("../../behaviors/userInfoBehavior")), r = l(require("../../behaviors/shareBehavior")), i = require("../../service/api"), u = require("../../utils/time"), o = require("../../utils/wechat"), s = require("../../utils/img"), c = require("../../typings/generate");

function l(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

Page({
    behaviors: [ a.default, n.default, r.default ],
    data: {
        pageActive: !0,
        taskState: c.TaskState.UNPROCESSED,
        photoAlbum: {},
        photoVOListTemp: new Array(4).fill({
            url: "/image/img-placeholder.png"
        }),
        photoVOList: [],
        safePhotoVOList: [],
        styleTemplateId: void 0,
        styleTemplateName: "",
        curTemplate: null,
        navbarData: {
            showCapsule: 1,
            title: ""
        },
        showPreview: !1,
        albumId: "",
        currentIndex: 0,
        template_id: 0,
        posture_pic_url: "",
        estimatedQueueTimeSeconds: void 0,
        generateLoading: !1
    },
    onLoad: function(e) {
        this.recordPV({
            spmA: "tixiang_wx",
            spmB: "picsgenerateresult"
        }), this.setData({
            albumId: e.albumId,
            template_id: e.template_id,
            posture_pic_url: e.posture_pic_url
        }), this.loadData();
    },
    onUnload: function() {
        this.setData({
            pageActive: !1
        });
    },
    onShow: function() {
        this.setData({
            pageActive: !0
        }), this.loadData();
    },
    onHide: function() {
        this.setData({
            pageActive: !1
        });
    },
    loadData: function() {
        var a = this;
        return t(e.default.mark(function t() {
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return a.checkStateInterval(), e.next = 3, a.loadAlbumPic();

                  case 3:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    loadAlbumPic: function() {
        var a = this;
        return t(e.default.mark(function t() {
            var n, r;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return n = a.data.albumId, e.next = 3, (0, i.getAlbumPic)({
                        album_id: Number(n)
                    });

                  case 3:
                    r = e.sent, console.log(r), a.setData({
                        styleTemplateId: r.styleTemplateId,
                        styleTemplateName: r.styleTemplateName
                    });

                  case 6:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    checkStateInterval: function() {
        var a = this;
        return t(e.default.mark(function n() {
            var r;
            return e.default.wrap(function(n) {
                for (;;) switch (n.prev = n.next) {
                  case 0:
                    (r = function() {
                        var n = t(e.default.mark(function t() {
                            var n;
                            return e.default.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                  case 0:
                                    if (a.data.pageActive) {
                                        e.next = 3;
                                        break;
                                    }
                                    return e.abrupt("return");

                                  case 3:
                                    return e.next = 5, (0, i.getpicgenstate)({
                                        album_id: a.data.albumId
                                    }).catch(function(e) {
                                        return setTimeout(r, 1e3), null;
                                    });

                                  case 5:
                                    (null == (n = e.sent) ? void 0 : n.state) === c.TaskState.PROCESSING || (null == n ? void 0 : n.state) === c.TaskState.UNPROCESSED ? setTimeout(r, 1e3) : (null == n || n.state, 
                                    c.TaskState.PROCESSED), a.setData({
                                        photoVOList: (0, s.addListShowParam)(n.pics),
                                        photoAlbum: n,
                                        taskState: null == n ? void 0 : n.state,
                                        template_id: n.templateId,
                                        posture_pic_url: n.postureUrl,
                                        estimatedQueueTimeSeconds: n.estimatedQueueTimeSeconds,
                                        estimatedQueueTimeSecondsStr: "number" == typeof n.estimatedQueueTimeSeconds && n.estimatedQueueTimeSeconds > 0 ? (0, 
                                        u.formatDuration)(1e3 * n.estimatedQueueTimeSeconds) : "--"
                                    });

                                  case 8:
                                  case "end":
                                    return e.stop();
                                }
                            }, t);
                        }));
                        return function() {
                            return n.apply(this, arguments);
                        };
                    }())();

                  case 2:
                  case "end":
                    return n.stop();
                }
            }, n);
        }))();
    },
    handleChangeAction: function() {
        var e = this.data, t = e.styleTemplateId, a = e.styleTemplateName;
        (0, o.navigateToPage)({
            url: "/pages/customPose/index?template_id=".concat(t, "&template_name=").concat(a)
        });
    },
    handleChangeModel: function() {
        getCurrentPages();
        (0, o.navigateToPage)({
            url: "/pages/custom/index"
        });
    },
    handleOnceMoreCreate: function() {
        var a = this;
        return t(e.default.mark(function t() {
            var n, r;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return getApp().recordClick("tixiang_wx.picsgenerateresult.actions.regeneratebtn"), 
                    n = {
                        template_id: a.data.template_id,
                        posture_pic_url: a.data.posture_pic_url
                    }, e.next = 4, (0, i.cubeautifulpic)(n);

                  case 4:
                    (r = e.sent) && a.setData({
                        albumId: r
                    }, function() {
                        a.checkStateInterval();
                    }), console.log("再次生成--handleOnceMoreCreate", a.data);

                  case 7:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    handleToPreview: function(e) {
        var t, a = this.data, n = (a.taskState, a.photoVOList), r = a.albumId;
        console.log("预览--需要预览的图片http链接列表", e);
        var i = e.currentTarget.dataset.item, u = e.currentTarget.dataset.index;
        console.log("预览", i, u), 0 !== (null === (t = n[u]) || void 0 === t ? void 0 : t.safety) && wx.navigateTo({
            url: "/pages/previewImages/index?albumId=".concat(r, "&picId=").concat(i.id)
        });
    },
    handleToDownLoad: function(a) {
        var n = this;
        return t(e.default.mark(function t() {
            var r, u;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return r = a.currentTarget.dataset.item, e.next = 3, (0, i.getDownloadNum)({});

                  case 3:
                    u = e.sent, console.log("下载原图&下载次数", r, u), u > 0 ? n.handleDownloadImage(r) : (wx.showToast({
                        title: "下载次数不足",
                        icon: "none"
                    }), n.setData({
                        showPreview: !0
                    }));

                  case 6:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    handleDownloadImage: function(a) {
        var n = this;
        return t(e.default.mark(function t() {
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.next = 2, (0, i.downloadPic)({
                        picture_id: a.id
                    });

                  case 2:
                    n.wxApiDownload(a.url);

                  case 3:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    wxApiDownload: function(e) {
        wx.downloadFile({
            url: e,
            success: function(e) {
                wx.saveImageToPhotosAlbum({
                    filePath: e.tempFilePath,
                    success: function() {
                        wx.showToast({
                            title: "保存成功",
                            icon: "success",
                            duration: 2e3
                        });
                    },
                    fail: function() {
                        wx.showToast({
                            title: "保存失败",
                            icon: "error",
                            duration: 2e3
                        });
                    }
                });
            },
            fail: function() {
                wx.showToast({
                    title: "下载失败",
                    icon: "none",
                    duration: 2e3
                });
            }
        });
    },
    handleTapSubscribeBtn: function() {
        (0, o.requestSubscribeMessage)("MxycMrG1OPDUFI_GLvcnUh3iJNuCx0D_87U6hUGQpYI");
    }
});