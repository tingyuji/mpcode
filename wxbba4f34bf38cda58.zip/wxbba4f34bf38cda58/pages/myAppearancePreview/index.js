var e = require("../../@babel/runtime/helpers/objectSpread2"), t = c(require("../../@babel/runtime/regenerator")), a = require("../../@babel/runtime/helpers/asyncToGenerator"), n = c(require("../../behaviors/pvBehavior")), r = c(require("../../behaviors/userInfoBehavior")), o = c(require("../../behaviors/shareBehavior")), i = require("../../service/api"), s = require("../../utils/mt"), u = require("../../utils/img");

function c(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

Page({
    hdGenerating: !1,
    requesting: !1,
    gettingShareImg: !1,
    likeSending: !1,
    behaviors: [ n.default, r.default, o.default ],
    data: {
        appearanceId: void 0,
        taskId: void 0,
        imagesList: [],
        indicatorDots: !1,
        vertical: !1,
        autoplay: !1,
        interval: 2e3,
        duration: 500,
        swiperCurrent: -1,
        downloadCount: "",
        showShareTip: !0,
        showHdLoading: !1,
        hdState: void 0,
        downloading: !1,
        goodsConfig: null,
        showDownloadAnimation: !1,
        showDiamondCostDialog: !1,
        showDiamondShortageDialog: !1,
        showChargeDialog: !1,
        curActionCode: "",
        curActionName: "",
        curActionCost: 0
    },
    onLoad: function(e) {
        this.recordPV({
            spmA: "tixiang_wx",
            spmB: "profilephoto"
        }), this.init();
    },
    onUnload: function() {},
    init: function() {
        var e = this;
        return a(t.default.mark(function a() {
            var n, r, o;
            return t.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return (0, s.getGoodsMtConfig)().then(function(t) {
                        e.setData({
                            goodsConfig: t
                        });
                    }), t.next = 3, e.loadData();

                  case 3:
                    r = e.data.appearance, o = (o = null === (n = e.data.imagesList) || void 0 === n ? void 0 : n.findIndex(function(e) {
                        return e.url == (null == r ? void 0 : r.imageUrl);
                    })) < 0 ? 0 : o, e.setData({
                        swiperCurrent: o
                    });

                  case 7:
                  case "end":
                    return t.stop();
                }
            }, a);
        }))();
    },
    loadData: function() {
        var n = this;
        return a(t.default.mark(function a() {
            var r, o, s, c, l, d;
            return t.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.next = 2, getApp().getFreshUserInfo();

                  case 2:
                    if (s = t.sent, c = null == s || null === (r = s.appearance) || void 0 === r ? void 0 : r.id, 
                    n.setData({
                        userInfo: s,
                        appearance: null == s ? void 0 : s.appearance,
                        appearanceId: c,
                        taskId: null == s || null === (o = s.task) || void 0 === o ? void 0 : o.taskId
                    }), c) {
                        t.next = 7;
                        break;
                    }
                    return t.abrupt("return");

                  case 7:
                    return t.next = 9, (0, i.getDigitalApp)({
                        digital_app_id: c
                    });

                  case 9:
                    l = t.sent, d = l.digitalAppearance, n.setData({
                        imagesList: null == d ? void 0 : d.map(function(t) {
                            var a;
                            return e(e({}, t), {}, {
                                urlWithWater: (0, u.getWatermarkUrl)(t.url),
                                currentAppear: t.url === (null == s || null === (a = s.appearance) || void 0 === a ? void 0 : a.imageUrl)
                            });
                        })
                    });

                  case 12:
                  case "end":
                    return t.stop();
                }
            }, a);
        }))();
    },
    swiperChange: function(e) {
        this.setData({
            swiperCurrent: e.detail.current
        });
    },
    handleDownloadImage: function(e) {
        var n = this;
        return a(t.default.mark(function e() {
            var a, r, o, s;
            return t.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return a = n.data, r = a.goodsConfig, o = a.imagesList, s = a.swiperCurrent, o[s], 
                    getApp().recordClick("tixiang_wx.page_profilephoto.action.downloadbtn"), e.next = 5, 
                    (0, i.queryCoinBalance)();

                  case 5:
                    e.sent - r.download_coin >= 0 ? n.setData({
                        showDiamondCostDialog: !0,
                        curActionCode: "download",
                        curActionName: "下载",
                        curActionCost: r.download_coin
                    }) : n.setData({
                        showDiamondShortageDialog: !0,
                        curActionCode: "download",
                        curActionName: "下载",
                        curActionCost: r.download_coin
                    });

                  case 7:
                  case "end":
                    return e.stop();
                }
            }, e);
        }))();
    },
    wxApiDownload: function(e, n) {
        var r = this;
        return a(t.default.mark(function o() {
            return t.default.wrap(function(o) {
                for (;;) switch (o.prev = o.next) {
                  case 0:
                    if (!r.data.downloading) {
                        o.next = 2;
                        break;
                    }
                    return o.abrupt("return");

                  case 2:
                    r.setData({
                        downloading: !0
                    }), wx.showLoading({
                        title: ""
                    }), wx.getSetting().then(function() {
                        var o = a(t.default.mark(function o(i) {
                            return t.default.wrap(function(o) {
                                for (;;) switch (o.prev = o.next) {
                                  case 0:
                                    if (i.authSetting["scope.writePhotosAlbum"]) {
                                        o.next = 5;
                                        break;
                                    }
                                    console.log("没有相册权限"), wx.authorize({
                                        scope: "scope.writePhotosAlbum"
                                    }).then(function() {
                                        var o = a(t.default.mark(function a(o) {
                                            return t.default.wrap(function(t) {
                                                for (;;) switch (t.prev = t.next) {
                                                  case 0:
                                                    return t.next = 2, r._wxApiDownload(e, n);

                                                  case 2:
                                                    t.sent ? wx.showToast({
                                                        title: "已保存到相册",
                                                        icon: "success"
                                                    }) : wx.showToast({
                                                        title: "下载失败",
                                                        icon: "none"
                                                    }), r.setData({
                                                        downloading: !1
                                                    });

                                                  case 5:
                                                  case "end":
                                                    return t.stop();
                                                }
                                            }, a);
                                        }));
                                        return function(e) {
                                            return o.apply(this, arguments);
                                        };
                                    }(), function(e) {
                                        console.log("没有相册权限", e), wx.showModal({
                                            title: "提示",
                                            content: "您已拒绝保存相册，请打开右上角”设置“->“添加到相册”",
                                            success: function(e) {}
                                        });
                                    }), o.next = 10;
                                    break;

                                  case 5:
                                    return o.next = 7, r._wxApiDownload(e, n);

                                  case 7:
                                    o.sent ? wx.showToast({
                                        title: "已保存到相册",
                                        icon: "success"
                                    }) : wx.showToast({
                                        title: "下载失败",
                                        icon: "none"
                                    }), r.setData({
                                        downloading: !1
                                    });

                                  case 10:
                                  case "end":
                                    return o.stop();
                                }
                            }, o);
                        }));
                        return function(e) {
                            return o.apply(this, arguments);
                        };
                    }());

                  case 5:
                  case "end":
                    return o.stop();
                }
            }, o);
        }))();
    },
    _wxApiDownload: function(e, n) {
        var r = this, o = this.data.appearanceId;
        return new Promise(function(s) {
            var u;
            wx.downloadFile({
                url: e,
                success: (u = a(t.default.mark(function e(u) {
                    return t.default.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            wx.saveImageToPhotosAlbum({
                                filePath: u.tempFilePath,
                                success: function() {
                                    var e = a(t.default.mark(function e() {
                                        return t.default.wrap(function(e) {
                                            for (;;) switch (e.prev = e.next) {
                                              case 0:
                                                return e.next = 2, (0, i.downloadPic)({
                                                    picType: "appear",
                                                    albumId: o,
                                                    picture_id: n
                                                }).catch(function() {
                                                    return !1;
                                                });

                                              case 2:
                                                if (e.sent) {
                                                    e.next = 6;
                                                    break;
                                                }
                                                return s(!1), e.abrupt("return");

                                              case 6:
                                                r.setData({
                                                    showDownloadAnimation: !0
                                                }), setTimeout(function() {
                                                    r.setData({
                                                        showDownloadAnimation: !1
                                                    });
                                                }, 2e3), s(!0);

                                              case 9:
                                              case "end":
                                                return e.stop();
                                            }
                                        }, e);
                                    }));
                                    return function() {
                                        return e.apply(this, arguments);
                                    };
                                }(),
                                fail: function(e) {
                                    console.log("error: ", e), s(!1);
                                }
                            });

                          case 1:
                          case "end":
                            return e.stop();
                        }
                    }, e);
                })), function(e) {
                    return u.apply(this, arguments);
                }),
                fail: function(e) {
                    console.log("error: ", e), s(!1);
                }
            });
        });
    },
    handleShareImage: function(e) {
        var n = this;
        return a(t.default.mark(function a() {
            var r, o, s;
            return t.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (getApp().recordClick("tixiang_wx.page_profilephoto.action.sharebtn"), !n.gettingShareImg) {
                        t.next = 3;
                        break;
                    }
                    return t.abrupt("return");

                  case 3:
                    return n.gettingShareImg = !0, wx.showLoading(), r = e.currentTarget.dataset.item, 
                    o = r[n.data.swiperCurrent], t.next = 9, (0, i.genShareInfo)({
                        picType: "appear",
                        source_pic_oss_url: o.url,
                        album_id: n.data.appearanceId,
                        album_pic_id: o.id
                    }).catch(function() {
                        return null;
                    });

                  case 9:
                    if (s = t.sent) {
                        t.next = 13;
                        break;
                    }
                    return n.gettingShareImg = !1, t.abrupt("return");

                  case 13:
                    console.log("合成带二维码的url图片", s), wx.downloadFile({
                        url: null == s ? void 0 : s.picOssUrl,
                        success: function(e) {
                            console.log(e), n.gettingShareImg = !1, wx.hideLoading(), wx.showShareImageMenu({
                                path: e.tempFilePath,
                                success: function(e) {}
                            });
                        },
                        fail: function(e) {
                            n.gettingShareImg = !1, wx.hideLoading(), console.log(e);
                        }
                    });

                  case 15:
                  case "end":
                    return t.stop();
                }
            }, a);
        }))();
    },
    handleChangeTap: function() {
        var e = this;
        return a(t.default.mark(function a() {
            var n, r, o, s, u, c;
            return t.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (getApp().recordClick("page_profilephoto.action.changebtn"), n = e.data, r = n.appearanceId, 
                    o = n.taskId, s = n.imagesList, u = n.swiperCurrent, c = s[u], console.log("curPic: ", c), 
                    !c.currentAppear) {
                        t.next = 6;
                        break;
                    }
                    return t.abrupt("return");

                  case 6:
                    if (!e.requesting) {
                        t.next = 8;
                        break;
                    }
                    return t.abrupt("return");

                  case 8:
                    return getApp().recordClick("tixiang_wx.page_profilephoto.action.changebt"), e.requesting = !0, 
                    t.next = 12, (0, i.changeDigitalApp)({
                        digital_app_pic_id: c.id,
                        digital_app_id: r,
                        task_id: o
                    }).catch(function() {
                        return null;
                    });

                  case 12:
                    if (!t.sent) {
                        t.next = 17;
                        break;
                    }
                    return wx.showToast({
                        icon: "success",
                        title: "切换成功"
                    }), t.next = 17, e.loadData();

                  case 17:
                    e.requesting = !1;

                  case 18:
                  case "end":
                    return t.stop();
                }
            }, a);
        }))();
    },
    handleTapItem: function(e) {
        var n = this;
        return a(t.default.mark(function e() {
            var a, r, o;
            return t.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    a = n.data, r = a.imagesList, o = a.swiperCurrent, wx.previewImage({
                        current: r[o].urlWithWater,
                        urls: r.map(function(e) {
                            return e.urlWithWater;
                        }),
                        showmenu: !1
                    });

                  case 2:
                  case "end":
                    return e.stop();
                }
            }, e);
        }))();
    },
    handleChargeOk: function() {
        "ios" === getApp().globalData.platform ? wx.navigateTo({
            url: "/pages/payByWxOfficialAccount/index"
        }) : this.setData({
            showChargeDialog: !0
        }), this.setData({
            showDiamondShortageDialog: !1
        });
    },
    handleChargeCancel: function() {
        this.setData({
            showDiamondShortageDialog: !1
        });
    },
    handleCloseChargeDialog: function() {
        this.setData({
            showChargeDialog: !1
        });
    },
    handleCostOk: function() {
        var e = this.data, t = e.curActionCode, a = e.imagesList[e.swiperCurrent];
        this.setData({
            showDiamondCostDialog: !1
        }), "download" === t ? this.wxApiDownload(a.url, a.id) : "hd" === t && this.doHd();
    },
    handleCostCancel: function() {
        this.setData({
            showDiamondCostDialog: !1
        });
    },
    onShareAppMessage: function() {
        var e = this;
        return a(t.default.mark(function a() {
            var n, r, o, i, s, u, c;
            return t.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return r = e.data, o = r.imagesList, i = r.swiperCurrent, getApp().recordClick("tixiang_wx.page_profilephoto.actions.momentshareupbtn"), 
                    s = o[i], t.next = 5, getApp().getMtConfig();

                  case 5:
                    if (t.t0 = t.sent, t.t0) {
                        t.next = 8;
                        break;
                    }
                    t.t0 = {};

                  case 8:
                    return u = t.t0, c = u.shareLinkTitle, t.abrupt("return", {
                        title: c,
                        path: "/pages/index/index?inviter_uid=".concat(null === (n = getApp().globalData.userInfo) || void 0 === n ? void 0 : n.userId),
                        imageUrl: s.url
                    });

                  case 11:
                  case "end":
                    return t.stop();
                }
            }, a);
        }))();
    }
});