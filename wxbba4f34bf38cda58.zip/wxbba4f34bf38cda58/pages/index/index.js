var e = v(require("../../@babel/runtime/regenerator")), t = require("../../@babel/runtime/helpers/objectWithoutProperties"), a = require("../../@babel/runtime/helpers/asyncToGenerator"), n = require("../../@babel/runtime/helpers/objectSpread2"), r = require("../../@babel/runtime/helpers/toConsumableArray"), i = v(require("dayjs")), s = v(require("../../behaviors/pvBehavior")), u = v(require("../../behaviors/shareBehavior")), o = v(require("../../behaviors/networkCheckBehavior")), c = require("../../service/api"), l = require("../../utils/util"), d = require("../../utils/time"), f = require("../../utils/img"), p = require("../../constants/index"), g = require("../../typings/generate"), h = require("../../typings/user"), m = [ "autoShowLoginDialog" ];

function v(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

var w = getApp();

function x(e) {
    return null == e ? void 0 : e.map(function(e) {
        var t = (0, f.addListShowParam)(e.albumPicList);
        return t ? t.length < 4 && (t = [].concat(r(t), [ new Array(4 - t.length).fill({}) ])) : t = new Array(4).fill({}), 
        n(n({}, e), {}, {
            albumPicList: t,
            albumGenerateTimeDifferenceStr: (0, d.getSemanticTime)(e.albumGenerateTimeDifference)
        });
    });
}

Page({
    _firstLoading: !1,
    _favoriteRefreshing: !1,
    _userGenAlbumRefreshing: !1,
    topVideoContext: void 0,
    behaviors: [ s.default, u.default, o.default ],
    data: {
        platform: "",
        mtConfig: null,
        logined: !1,
        logining: !1,
        inviterId: "",
        swiperCurrent: 0,
        videoPlayed: !1,
        userTermsAgreed: !1,
        showLoginDialog: !1,
        autoShowLoginDialog: !1,
        userInfo: null,
        hasAppearance: !1,
        pageDataLoading: !0,
        inviteFlag: !1,
        inviteCode: "",
        inviteCodeHasValided: !1,
        inviteCodePassed: !1,
        inviteCodeWrongReason: "",
        needChooseAppearance: !1,
        freeResetNum: 0,
        showChooseAppearDialog: !1,
        task: null,
        canAdjustAppear: !1,
        appearProcessing: !1,
        styleGifs: [],
        templateList: [],
        systemGenerateAlbumList: [],
        userGenerateAlbumList: [],
        userGenerateAlbumListHasMore: !0,
        userHasGenAlbum: !1,
        nextUserAlbumPageNum: 1,
        userGenLoading: !1,
        albumListRefreshTriggered: !0,
        favoriteList: [],
        favoriteListRefreshTriggered: !1,
        favoriteListHasMore: !0,
        nextFavoriteListPageNum: 1,
        favoriteListLoading: !1,
        hasNewLike: !1,
        showInviteDialog: !1,
        inviteDialogButtons: [ {
            type: "default",
            className: "",
            text: "取消",
            value: "cancel"
        }, {
            type: "primary",
            className: "",
            text: "确定",
            value: "ok"
        } ],
        tabs: [ {
            title: "我的收藏"
        }, {
            title: "生成历史"
        } ],
        activeTab: 0,
        showUserAlbumActionsheet: !1,
        curAlbum: null,
        userAlbumActions: [ {
            text: "删除",
            type: "warn",
            value: "delete"
        } ],
        pageActive: !0,
        showChargeDialog: !1,
        coinBalance: "",
        showResetConfirmDialog: !1,
        showAppGuideModal: !1
    },
    onLoad: function(n) {
        var r = this;
        return a(e.default.mark(function a() {
            var i, s;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return i = n.autoShowLoginDialog, t(n, m), s = n.inviter_uid, s = decodeURIComponent(s), 
                    i && r.setData({
                        autoShowLoginDialog: !0
                    }), s && r.setData({
                        inviterId: s
                    }), r.setData({
                        platform: getApp().globalData.platform
                    }), r._firstLoading = !0, e.next = 9, r.loadData();

                  case 9:
                    r._firstLoading = !1;

                  case 10:
                  case "end":
                    return e.stop();
                }
            }, a);
        }))();
    },
    loadData: function(t) {
        var n = this;
        return a(e.default.mark(function a() {
            var r, s, u, o, l, d, h, m, v, x, b, A, L, k, D, C;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (s = (r = t || {}).autoNavigateToGeneratePage, u = void 0 === s || s, o = r.showLoading, 
                    (void 0 === o || o) && wx.showLoading({
                        title: "加载中"
                    }), n.setData({
                        pageDataLoading: !0
                    }), w.getMtConfig().then(function(e) {
                        n.setData({
                            mtConfig: e
                        });
                    }), wx.getStorageSync(p.TOKEN_KEY)) {
                        e.next = 11;
                        break;
                    }
                    return wx.hideLoading(), n.setData({
                        pageDataLoading: !1
                    }), n.recordPV({
                        spmA: "tixiang_wx",
                        spmB: "homepage"
                    }), n.data.autoShowLoginDialog && n.setData({
                        showLoginDialog: !0
                    }), e.abrupt("return");

                  case 11:
                    return e.next = 13, (0, c.getUserInfo)().catch(function() {
                        return null;
                    });

                  case 13:
                    if (l = e.sent) {
                        e.next = 19;
                        break;
                    }
                    return wx.hideLoading(), n.setData({
                        pageDataLoading: !1
                    }), n.recordPV({
                        spmA: "tixiang_wx",
                        spmB: "homepage"
                    }), e.abrupt("return");

                  case 19:
                    if (console.log("userInfo:", l), getApp().globalData.userInfo = l, d = l.appearanceState, 
                    h = l.appearance, m = l.task, v = l.canAdjustAppear, x = l.inviteFlag, b = l.needChooseAppearance, 
                    A = l.resetFlag, L = l.freeResetNum, n.setData({
                        logined: !0,
                        userInfo: l,
                        hasAppearance: !!h,
                        appearanceShowImageUrl: (0, f.addShowParam)(null == h ? void 0 : h.imageUrl),
                        inviteFlag: x,
                        needChooseAppearance: b,
                        freeResetNum: L,
                        task: m,
                        canAdjustAppear: v,
                        resetFlag: A,
                        digitalAppearanceGenerateTimeStr: null != h && h.digitalAppearanceGenerateTime ? (0, 
                        i.default)(h.digitalAppearanceGenerateTime).format("YYYY-MM-DD HH:mm") : "--"
                    }), n.data.inviteFlag) {
                        e.next = 29;
                        break;
                    }
                    return n.setData({
                        showInviteDialog: !0
                    }), wx.hideLoading(), n.setData({
                        pageDataLoading: !1
                    }), n.recordPV({
                        spmA: "tixiang_wx",
                        spmB: "homepage"
                    }), e.abrupt("return");

                  case 29:
                    if (n.data.hasAppearance ? n.recordPV({
                        spmA: "tixiang_wx",
                        spmB: "profilepage"
                    }) : n.recordPV({
                        spmA: "tixiang_wx",
                        spmB: "homepage"
                    }), k = d === g.TaskState.PROCESSING && m || A, n.setData({
                        appearProcessing: k
                    }), !u || !k) {
                        e.next = 38;
                        break;
                    }
                    if ((null == m ? void 0 : m.taskState) !== g.TaskState.PROCESSING && (null == m ? void 0 : m.taskState) !== g.TaskState.PROCESSED && !A) {
                        e.next = 38;
                        break;
                    }
                    return wx.hideLoading(), n.setData({
                        pageDataLoading: !1
                    }), n.navigateToGeneratePage(), e.abrupt("return");

                  case 38:
                    if (d !== g.TaskState.PROCESSED) {
                        e.next = 56;
                        break;
                    }
                    if (n.getCoinBanlance(), (null == (D = n.data.favoriteList) ? void 0 : D.length) > 0 ? n.refreshCurFavoriteList() : n.loadFavoriteList(!0), 
                    !((null == (C = n.data.userGenerateAlbumList) ? void 0 : C.length) > 0)) {
                        e.next = 49;
                        break;
                    }
                    return e.next = 46, n.refreshCurUserGenAlbumList();

                  case 46:
                    n.checkStateInterval(), e.next = 51;
                    break;

                  case 49:
                    return e.next = 51, n.loadUserGenAlbumList(!0);

                  case 51:
                    if (n.data.userHasGenAlbum) {
                        e.next = 54;
                        break;
                    }
                    return e.next = 54, n.loadSysGenAlbumList();

                  case 54:
                    e.next = 57;
                    break;

                  case 56:
                    n.setData({
                        nextUserAlbumPageNum: 1,
                        userGenerateAlbumList: [],
                        userGenerateAlbumListHasMore: !0,
                        systemGenerateAlbumList: [],
                        favoriteList: [],
                        favoriteListHasMore: !0,
                        nextFavoriteListPageNum: 1,
                        userHasGenAlbum: !1,
                        hasNewLike: !1
                    });

                  case 57:
                    n.judgeActiveTab(), wx.setStorageSync("HISTORY_LAST_SHOW_TS_KEY", Date.now()), wx.hideLoading(), 
                    n.setData({
                        pageDataLoading: !1
                    });

                  case 61:
                  case "end":
                    return e.stop();
                }
            }, a);
        }))();
    },
    onReady: function() {
        this.topVideoContext = wx.createVideoContext("topVideo");
    },
    onUnload: function() {
        this.setData({
            pageActive: !1
        });
    },
    onShow: function() {
        var t = this;
        return a(e.default.mark(function a() {
            var n;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (null === (n = t.topVideoContext) || void 0 === n || n.play(), t.setData({
                        pageActive: !0
                    }), !t._firstLoading) {
                        e.next = 4;
                        break;
                    }
                    return e.abrupt("return");

                  case 4:
                    return e.next = 6, t.loadData({
                        autoNavigateToGeneratePage: !1,
                        showLoading: !1
                    });

                  case 6:
                  case "end":
                    return e.stop();
                }
            }, a);
        }))();
    },
    onHide: function() {
        var e, t;
        null === (e = this.topVideoContext) || void 0 === e || e.pause(), null === (t = this.topVideoContext) || void 0 === t || t.seek(0), 
        this.setData({
            pageActive: !1,
            videoPlayed: !1
        });
    },
    onPullDownRefresh: function() {
        var t = this;
        return a(e.default.mark(function a() {
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.next = 2, t.loadData({
                        autoNavigateToGeneratePage: !1
                    });

                  case 2:
                    wx.stopPullDownRefresh();

                  case 3:
                  case "end":
                    return e.stop();
                }
            }, a);
        }))();
    },
    getCoinBanlance: function() {
        var t = this;
        return a(e.default.mark(function a() {
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.next = 2, (0, c.queryCoinBalance)().then(function(e) {
                        t.setData({
                            coinBalance: e
                        });
                    });

                  case 2:
                  case "end":
                    return e.stop();
                }
            }, a);
        }))();
    },
    judgeActiveTab: function() {
        var e, t = this.data, a = t.userGenerateAlbumList, n = t.favoriteList;
        if (n && 0 !== n.length) {
            var r = null == a || null === (e = a.find(function(e) {
                return "userGenerate" === e.sourceType;
            })) || void 0 === e ? void 0 : e.createTime;
            if (r) {
                var s = wx.getStorageSync("HISTORY_LAST_SHOW_TS_KEY");
                s && (0, i.default)(r).isAfter(s) && this.setData({
                    activeTab: 1
                });
            }
        } else this.setData({
            activeTab: 1
        });
    },
    loadSysGenAlbumList: function() {
        var t = this;
        return a(e.default.mark(function a() {
            var r, i;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.next = 2, (0, c.getAlbumInfo)({
                        default_generate: !0
                    }).catch(function() {
                        return {
                            albumList: []
                        };
                    });

                  case 2:
                    r = e.sent, i = r.albumList, t.setData({
                        systemGenerateAlbumList: null == i ? void 0 : i.map(function(e) {
                            var t = (0, f.addListShowParam)(e.albumPicList);
                            return n(n({}, e), {}, {
                                albumPicList: t,
                                albumGenerateTimeDifferenceStr: (0, d.getSemanticTime)(e.albumGenerateTimeDifference)
                            });
                        })
                    });

                  case 5:
                  case "end":
                    return e.stop();
                }
            }, a);
        }))();
    },
    loadUserGenAlbumList: function() {
        var t = arguments, n = this;
        return a(e.default.mark(function a() {
            var i, s, u, o, l, d, f, p, g, h, m;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if ((i = t.length > 0 && void 0 !== t[0] && t[0]) && n.setData({
                        nextUserAlbumPageNum: 1,
                        userGenerateAlbumListHasMore: !0
                    }), s = n.data, u = s.nextUserAlbumPageNum, o = s.userGenerateAlbumList, l = s.userGenerateAlbumListHasMore, 
                    i || l) {
                        e.next = 5;
                        break;
                    }
                    return e.abrupt("return");

                  case 5:
                    return n.setData({
                        userGenLoading: !0
                    }), e.next = 8, (0, c.getAlbumInfo)({
                        default_generate: !1,
                        page_num: u,
                        page_size: 10
                    }).catch(function() {
                        return {
                            albumList: [],
                            hasMore: !1
                        };
                    });

                  case 8:
                    d = e.sent, f = d.albumList, p = void 0 === f ? [] : f, g = d.hasMore, h = d.userHasGenAlbum, 
                    n.setData({
                        userGenLoading: !1
                    }), m = x(p), n.setData({
                        userGenerateAlbumList: i ? m : [].concat(r(o), r(m || [])),
                        userGenerateAlbumListHasMore: g,
                        nextUserAlbumPageNum: u + 1
                    }), 1 === u && (n.setData({
                        userHasGenAlbum: h
                    }), n.checkStateInterval());

                  case 17:
                  case "end":
                    return e.stop();
                }
            }, a);
        }))();
    },
    checkStateInterval: function() {
        var t = this;
        return a(e.default.mark(function a() {
            var n, r, i;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (n = t.data, r = n.userGenerateAlbumList, i = n.pageActive, r && i) {
                        e.next = 3;
                        break;
                    }
                    return e.abrupt("return");

                  case 3:
                    if (0 !== r.filter(function(e) {
                        return "processing" === e.state || !e.coverPic;
                    }).length) {
                        e.next = 6;
                        break;
                    }
                    return e.abrupt("return");

                  case 6:
                    return e.next = 8, t.refreshCurUserGenAlbumList();

                  case 8:
                    setTimeout(t.checkStateInterval, 1e4);

                  case 9:
                  case "end":
                    return e.stop();
                }
            }, a);
        }))();
    },
    refreshCurUserGenAlbumList: function() {
        var t = this;
        return a(e.default.mark(function a() {
            var n, r, i, s, u, o, l;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (n = t.data.userGenerateAlbumList) {
                        e.next = 3;
                        break;
                    }
                    return e.abrupt("return");

                  case 3:
                    return e.next = 5, (0, c.getAlbumInfo)({
                        default_generate: !1,
                        page_num: 1,
                        page_size: n.length < 10 ? 10 : n.length
                    }).catch(function() {
                        return null;
                    });

                  case 5:
                    if (r = e.sent) {
                        e.next = 8;
                        break;
                    }
                    return e.abrupt("return", null);

                  case 8:
                    return i = r.albumList, s = void 0 === i ? [] : i, u = r.hasMore, o = r.userHasGenAlbum, 
                    l = x(s), t.setData({
                        userGenerateAlbumList: l,
                        userGenerateAlbumListHasMore: u,
                        userHasGenAlbum: o
                    }), e.abrupt("return", s);

                  case 12:
                  case "end":
                    return e.stop();
                }
            }, a);
        }))();
    },
    loadFavoriteList: function() {
        var t = arguments, n = this;
        return a(e.default.mark(function a() {
            var i, s, u, o, l, d, p, g, h, m, v;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if ((i = t.length > 0 && void 0 !== t[0] && t[0]) && n.setData({
                        nextFavoriteListPageNum: 1,
                        favoriteListHasMore: !0
                    }), s = n.data, u = s.nextFavoriteListPageNum, o = s.favoriteList, l = s.favoriteListHasMore, 
                    i || l) {
                        e.next = 5;
                        break;
                    }
                    return e.abrupt("return");

                  case 5:
                    return n.setData({
                        favoriteListLoading: !0
                    }), e.next = 8, (0, c.getLikePicture)({
                        page_num: u,
                        page_size: 10
                    }).catch(function() {
                        return {
                            albumPicVOS: [],
                            hasMore: !1
                        };
                    });

                  case 8:
                    d = e.sent, g = (p = d || {}).albumPicVOS, h = void 0 === g ? [] : g, m = p.hasMore, 
                    v = p.hasNewLike, n.setData({
                        favoriteListLoading: !1
                    }), n.setData({
                        favoriteList: (0, f.addListShowParam)(i ? h : [].concat(r(o), r(h))),
                        favoriteListHasMore: m,
                        nextFavoriteListPageNum: u + 1,
                        hasNewLike: v
                    });

                  case 12:
                  case "end":
                    return e.stop();
                }
            }, a);
        }))();
    },
    refreshCurFavoriteList: function() {
        var t = this;
        return a(e.default.mark(function a() {
            var n, r, i, s, u, o;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (n = t.data.favoriteList) {
                        e.next = 3;
                        break;
                    }
                    return e.abrupt("return");

                  case 3:
                    return e.next = 5, (0, c.getLikePicture)({
                        page_num: 1,
                        page_size: n.length < 10 ? 10 : n.length
                    }).catch(function() {
                        return null;
                    });

                  case 5:
                    if (r = e.sent) {
                        e.next = 8;
                        break;
                    }
                    return e.abrupt("return", null);

                  case 8:
                    return i = r.albumPicVOS, s = void 0 === i ? [] : i, u = r.hasMore, o = r.hasNewLike, 
                    t.setData({
                        favoriteList: (0, f.addListShowParam)(s),
                        favoriteListHasMore: u,
                        hasNewLike: o
                    }), e.abrupt("return", s);

                  case 11:
                  case "end":
                    return e.stop();
                }
            }, a);
        }))();
    },
    navigateToGeneratePage: function() {
        var t = this;
        return a(e.default.mark(function a() {
            var n, r, i, s, u, o;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (n = t.data, r = n.platform, i = n.mtConfig, s = n.userInfo, u = !(s.freeResetNum >= 1), 
                    o = !s.task || s.task.taskStage === h.AppearTaskStage.FrontViewRecognize || s.task.taskStage === h.AppearTaskStage.MultiViewRecognize, 
                    !("ios" === r && null != i && i.enableAppGuide && u && o)) {
                        e.next = 6;
                        break;
                    }
                    return t.setData({
                        showAppGuideModal: !0
                    }), e.abrupt("return");

                  case 6:
                    wx.navigateTo({
                        url: "/pages/generate/index"
                    });

                  case 7:
                  case "end":
                    return e.stop();
                }
            }, a);
        }))();
    },
    handleGetPhoneNumber: function(t) {
        var n = this;
        return a(e.default.mark(function a() {
            var r, i, s;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (console.log("login: ", t), t.detail.iv) {
                        e.next = 3;
                        break;
                    }
                    return e.abrupt("return");

                  case 3:
                    if (!n.data.logining) {
                        e.next = 5;
                        break;
                    }
                    return e.abrupt("return");

                  case 5:
                    return e.next = 7, (0, l.promisify)(wx.login)();

                  case 7:
                    if (null != (r = e.sent) && r.code) {
                        e.next = 11;
                        break;
                    }
                    return wx.showToast({
                        title: "获取登录信息失败"
                    }), e.abrupt("return");

                  case 11:
                    return wx.showLoading({
                        title: "登录中"
                    }), n.setData({
                        logining: !0
                    }), e.next = 15, (0, c.login)({
                        code: null == r ? void 0 : r.code,
                        inviter_uid: n.data.inviterId,
                        client_info: JSON.stringify(t.detail)
                    }).catch(function() {
                        return wx.hideLoading(), n.setData({
                            logining: !1
                        }), null;
                    });

                  case 15:
                    if (i = e.sent) {
                        e.next = 18;
                        break;
                    }
                    return e.abrupt("return");

                  case 18:
                    return s = i.token, wx.setStorageSync(p.TOKEN_KEY, s), wx.hideLoading(), n.setData({
                        logining: !1,
                        showLoginDialog: !1
                    }), e.next = 24, n.loadData({
                        autoNavigateToGeneratePage: !1
                    });

                  case 24:
                    n.handleTapGenerateBtn({
                        jumpCustomPage: !1,
                        warnSeedQueueCrowd: !0
                    });

                  case 25:
                  case "end":
                    return e.stop();
                }
            }, a);
        }))();
    },
    handleTapGenerateBtn: function(t) {
        var n = this;
        return a(e.default.mark(function a() {
            var r, i, s, u, o, l, d, f;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (i = (r = t || {}).jumpCustomPage, s = void 0 === i || i, u = r.warnSeedQueueCrowd, 
                    o = void 0 !== u && u, l = n.data, l.platform, l.mtConfig, !wx.getStorageSync(p.TOKEN_KEY)) {
                        e.next = 7;
                        break;
                    }
                    return e.next = 5, (0, c.getUserInfo)().catch(function(e) {
                        if (e.errCode === p.BIZ_L_TOKEN_EXPIRED || e.errCode === p.BIZ_C_ILLEGAL_USER) return null;
                        throw new Error("未获取到用户信息，阻止程序继续往下走");
                    });

                  case 5:
                    d = e.sent, getApp().globalData.userInfo = d;

                  case 7:
                    if (d) {
                        e.next = 10;
                        break;
                    }
                    return n.setData({
                        showLoginDialog: !0
                    }), e.abrupt("return");

                  case 10:
                    if (d.inviteFlag) {
                        e.next = 13;
                        break;
                    }
                    return n.setData({
                        showInviteDialog: !0
                    }), e.abrupt("return");

                  case 13:
                    if (!d.appearance) {
                        e.next = 18;
                        break;
                    }
                    return s && wx.navigateTo({
                        url: "/pages/custom/index"
                    }), e.abrupt("return");

                  case 18:
                    if (f = !d.task || d.task.taskStage === h.AppearTaskStage.FrontViewRecognize || d.task.taskStage === h.AppearTaskStage.MultiViewRecognize, 
                    !o || !f) {
                        e.next = 26;
                        break;
                    }
                    return e.next = 22, n.waitConfirmIfSeedQueueCrowd();

                  case 22:
                    e.sent && n.navigateToGeneratePage(), e.next = 27;
                    break;

                  case 26:
                    n.navigateToGeneratePage();

                  case 27:
                  case "end":
                    return e.stop();
                }
            }, a);
        }))();
    },
    waitConfirmIfSeedQueueCrowd: function() {
        var t = this;
        return a(e.default.mark(function n() {
            return e.default.wrap(function(n) {
                for (;;) switch (n.prev = n.next) {
                  case 0:
                    return n.abrupt("return", new Promise(function() {
                        var n = a(e.default.mark(function a(n) {
                            var r, i, s;
                            return e.default.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                  case 0:
                                    return e.next = 2, (0, c.queryQueuingInfo)({
                                        type: "digitalAppearGen"
                                    });

                                  case 2:
                                    (r = e.sent) && (null == r ? void 0 : r.queuingHour) >= 24 ? (i = r.queuingHour, 
                                    r.queuingPerson, s = [ "前方排队爆满，预计等待超".concat(i >= 48 ? "48" : i >= 36 && i < 48 ? "36" : i >= 24 && i < 36 ? "24" : "", "小时，"), "是否继续制作？" ], 
                                    t.selectComponent("#myConfirmModal").showModal({
                                        titles: s,
                                        okText: "排队制作",
                                        cancelText: "我先等等",
                                        success: function(e) {
                                            e.confirm ? n(!0) : n(!1);
                                        }
                                    })) : n(!0);

                                  case 4:
                                  case "end":
                                    return e.stop();
                                }
                            }, a);
                        }));
                        return function(e) {
                            return n.apply(this, arguments);
                        };
                    }()));

                  case 1:
                  case "end":
                    return n.stop();
                }
            }, n);
        }))();
    },
    handleTapResetSeed: function() {
        var t = this;
        return a(e.default.mark(function a() {
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (getApp().recordClick("tixiang_wx.page_profilepage.img.imgresetbtn"), t.data.task) {
                        e.next = 4;
                        break;
                    }
                    return e.abrupt("return");

                  case 4:
                    return e.next = 6, t.waitConfirmIfSeedQueueCrowd();

                  case 6:
                    if (!e.sent) {
                        e.next = 15;
                        break;
                    }
                    return e.t0 = t, e.next = 11, getApp().getFreshMtConfig();

                  case 11:
                    e.t1 = e.sent, e.t2 = {
                        mtConfig: e.t1
                    }, e.t0.setData.call(e.t0, e.t2), t.setData({
                        showResetConfirmDialog: !0
                    });

                  case 15:
                  case "end":
                    return e.stop();
                }
            }, a);
        }))();
    },
    handleResetOk: function() {
        var t = this;
        return a(e.default.mark(function a() {
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.next = 2, (0, c.startReset)();

                  case 2:
                    e.sent && wx.navigateTo({
                        url: "/pages/generate/index"
                    }), t.setData({
                        showResetConfirmDialog: !1
                    });

                  case 5:
                  case "end":
                    return e.stop();
                }
            }, a);
        }))();
    },
    handleResetCancel: function() {
        this.setData({
            showResetConfirmDialog: !1
        });
    },
    handleTapCustomBtn: function() {
        wx.navigateTo({
            url: "/pages/custom/index"
        });
    },
    handleUserTermsTap: function() {
        wx.navigateTo({
            url: "/pages/userTerms/index"
        });
    },
    handlePrivacyPolicyTap: function() {
        wx.navigateTo({
            url: "/pages/privacyPolicy/index"
        });
    },
    handleUserTermsRadioTap: function() {
        this.setData({
            userTermsAgreed: !this.data.userTermsAgreed
        });
    },
    handleOuterLoginTap: function() {
        this.data.userTermsAgreed || wx.showToast({
            title: "请阅读并同意协议",
            icon: "none"
        });
    },
    handleTapJustifySeed: function() {
        var e = this.data.task;
        e && wx.navigateTo({
            url: "/pages/justifySeed/index?task_id=".concat(e.taskId)
        });
    },
    handleTapAlbumItem: function(e) {
        var t = e.currentTarget.dataset.item;
        wx.navigateTo({
            url: "/pages/customResult/index?albumId=".concat(t.id)
        });
    },
    handleVideoPlay: function(e) {
        e.detail.currentTime > .01 && !this.data.videoPlayed && this.data.pageActive && this.setData({
            videoPlayed: !0
        });
    },
    handleInviteCodeInput: function(e) {
        var t = e.detail.value;
        this.setData({
            inviteCode: t
        }), t || this.clearInviteCodeResult();
    },
    handleInviteCodeFocus: function(e) {},
    handleInviteCodeBlur: function() {},
    clearInviteCodeResult: function() {
        this.setData({
            inviteCode: "",
            inviteCodeHasValided: !1,
            inviteCodePassed: !1,
            inviteCodeWrongReason: ""
        });
    },
    handleApplyCodeTap: function() {
        wx.openEmbeddedMiniProgram({
            appId: "wxd947200f82267e58",
            path: "pages/wjxqList/wjxqList?activityId=mCUPDdB"
        });
    },
    handleTapInviteMask: function() {
        this.setData({
            showInviteDialog: !1
        });
    },
    handleInviteOkTap: function(t) {
        var n = this;
        return a(e.default.mark(function t() {
            var a, r;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (a = n.data.inviteCode) {
                        e.next = 4;
                        break;
                    }
                    return wx.showToast({
                        icon: "none",
                        title: "请输入邀请码"
                    }), e.abrupt("return");

                  case 4:
                    if (/^[a-zA-Z0-9]+$/.test(a)) {
                        e.next = 7;
                        break;
                    }
                    return n.setData({
                        inviteCodePassed: !1,
                        inviteCodeWrongReason: "邀请码不存在",
                        inviteCodeHasValided: !0
                    }), e.abrupt("return");

                  case 7:
                    return e.next = 9, (0, c.inviteregist)({
                        invite_code: a
                    }, {
                        showErrorIfFail: !1
                    }).catch(function(e) {
                        return Object.keys(p.INVITE_CODE_ERROR_MAP).indexOf(e.errCode) >= 0 ? n.setData({
                            inviteCodePassed: !1,
                            inviteCodeWrongReason: p.INVITE_CODE_ERROR_MAP[e.errCode]
                        }) : wx.showToast({
                            icon: "none",
                            title: e.errMessage || "请求错误"
                        }), null;
                    });

                  case 9:
                    r = e.sent, n.setData({
                        inviteCodeHasValided: !0
                    }), r && (n.setData({
                        inviteCodePassed: !0,
                        inviteCodeWrongReason: "",
                        showInviteDialog: !1,
                        inviteFlag: !0
                    }), n.handleTapGenerateBtn());

                  case 12:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    handleInviteCancelTap: function() {
        var t = this;
        return a(e.default.mark(function a() {
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    t.clearInviteCodeResult(), t.setData({
                        showInviteDialog: !1
                    });

                  case 2:
                  case "end":
                    return e.stop();
                }
            }, a);
        }))();
    },
    handleUseNewAppear: function() {
        var t = this;
        return a(e.default.mark(function a() {
            var n;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (n = t.data.task) {
                        e.next = 3;
                        break;
                    }
                    return e.abrupt("return");

                  case 3:
                    return e.next = 5, (0, c.dealnewdigitalapp)({
                        task_id: n.taskId,
                        operate_type: "useNewDigital"
                    });

                  case 5:
                    wx.reLaunch({
                        url: "/pages/index/index"
                    });

                  case 6:
                  case "end":
                    return e.stop();
                }
            }, a);
        }))();
    },
    handleUseOriAppear: function() {
        var t = this;
        return a(e.default.mark(function a() {
            var n;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (n = t.data.task) {
                        e.next = 3;
                        break;
                    }
                    return e.abrupt("return");

                  case 3:
                    return e.next = 5, (0, c.dealnewdigitalapp)({
                        task_id: n.taskId,
                        operate_type: "giveUpNewDigital"
                    });

                  case 5:
                    wx.reLaunch({
                        url: "/pages/index/index"
                    });

                  case 6:
                  case "end":
                    return e.stop();
                }
            }, a);
        }))();
    },
    handlePicItemTap: function(e) {
        var t = e.currentTarget.dataset.picItem, a = e.currentTarget.dataset.albumItem;
        wx.navigateTo({
            url: "/pages/previewImages/index?albumId=".concat(a.id, "&picId=").concat(t.id)
        });
    },
    handleFavoriteListRefresh: function() {
        var t = this;
        return a(e.default.mark(function a() {
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (!t._favoriteRefreshing) {
                        e.next = 2;
                        break;
                    }
                    return e.abrupt("return");

                  case 2:
                    return t._favoriteRefreshing = !0, e.next = 5, t.loadFavoriteList(!0);

                  case 5:
                    t._favoriteRefreshing = !1, t.setData({
                        favoriteListRefreshTriggered: !1
                    });

                  case 7:
                  case "end":
                    return e.stop();
                }
            }, a);
        }))();
    },
    handleFavoriteListLoadMore: function() {
        var t = this;
        return a(e.default.mark(function a() {
            var n;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    (null == (n = t.data.favoriteList) ? void 0 : n.length) > 1 && t.loadFavoriteList();

                  case 2:
                  case "end":
                    return e.stop();
                }
            }, a);
        }))();
    },
    handleUserGenAlbumListRefresh: function() {
        var t = this;
        return a(e.default.mark(function a() {
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (!t._userGenAlbumRefreshing) {
                        e.next = 2;
                        break;
                    }
                    return e.abrupt("return");

                  case 2:
                    return t._userGenAlbumRefreshing = !0, e.next = 5, t.loadUserGenAlbumList(!0);

                  case 5:
                    t._userGenAlbumRefreshing = !1, t.setData({
                        albumListRefreshTriggered: !1
                    });

                  case 7:
                  case "end":
                    return e.stop();
                }
            }, a);
        }))();
    },
    handleUserGenAlbumListLoadMore: function() {
        var t = this;
        return a(e.default.mark(function a() {
            var n, r, i;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    n = t.data, r = n.userHasGenAlbum, i = n.userGenerateAlbumList, r && (null == i ? void 0 : i.length) > 1 && t.loadUserGenAlbumList();

                  case 2:
                  case "end":
                    return e.stop();
                }
            }, a);
        }))();
    },
    handleTapMoreBtn: function(e) {
        var t = e.detail;
        this.openUserAlbumActionsheet(t);
    },
    openUserAlbumActionsheet: function(e) {
        this.setData({
            showUserAlbumActionsheet: !0,
            curAlbum: e
        });
    },
    closeUserAlbumActionsheet: function() {
        this.setData({
            showUserAlbumActionsheet: !1,
            curAlbum: null
        });
    },
    handleUserAlbumActionTap: function(t) {
        var n = this;
        return a(e.default.mark(function r() {
            var i, s, u;
            return e.default.wrap(function(r) {
                for (;;) switch (r.prev = r.next) {
                  case 0:
                    if (i = t.detail, s = i.value, i.index, u = n.data.curAlbum) {
                        r.next = 4;
                        break;
                    }
                    return r.abrupt("return");

                  case 4:
                    "delete" === s && wx.showModal({
                        title: "确定删除照片？",
                        success: function() {
                            var t = a(e.default.mark(function t(a) {
                                return e.default.wrap(function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                      case 0:
                                        if (!a.confirm) {
                                            e.next = 5;
                                            break;
                                        }
                                        return e.next = 3, (0, c.deleteAlbum)({
                                            album_id: u.id
                                        });

                                      case 3:
                                        e.sent && (wx.showToast({
                                            icon: "success",
                                            title: "删除成功"
                                        }), n.refreshCurUserGenAlbumList(), n.loadSysGenAlbumList());

                                      case 5:
                                      case "end":
                                        return e.stop();
                                    }
                                }, t);
                            }));
                            return function(e) {
                                return t.apply(this, arguments);
                            };
                        }()
                    }), n.setData({
                        showUserAlbumActionsheet: !1,
                        curAlbum: null
                    });

                  case 6:
                  case "end":
                    return r.stop();
                }
            }, r);
        }))();
    },
    handleTapNoLoginBtn: function() {
        this.setData({
            showLoginDialog: !1
        });
    },
    handleTapGifItem: function(e) {
        var t = e.currentTarget.dataset.item;
        wx.navigateTo({
            url: "/pages/customResultView/index?code=".concat(t.code)
        });
    },
    handleSeedImgTap: function() {
        getApp().recordClick("tixiang_wx.page_profilepage.img.profilephoto"), wx.navigateTo({
            url: "/pages/myAppearancePreview/index"
        });
    },
    handleManualEntryTap: function() {
        getApp().recordClick("tixiang_wx.page_homepage.action.introduction"), wx.navigateTo({
            url: "/pages/manual/index"
        });
    },
    handleTapCoinBalance: function() {
        getApp().recordClick("tixiang_wx.page_profilepage.img.diamonds"), wx.navigateTo({
            url: "/pages/myDiamond/index"
        });
    },
    handleTapCharge: function() {
        getApp().recordClick("tixiang_wx.page_profilepage.img.topupbtn"), "ios" === this.data.platform ? wx.navigateTo({
            url: "/pages/payByWxOfficialAccount/index"
        }) : this.setData({
            showChargeDialog: !0
        });
    },
    handleCloseChargeDialog: function() {
        this.setData({
            showChargeDialog: !1
        });
    },
    handleChargeSuccess: function() {
        this.getCoinBanlance(), this.setData({
            showChargeDialog: !1
        });
    },
    showConfirmModal: function() {
        this.setData({
            showConfirmModal: !0
        });
    },
    handleConfirmModalOk: function() {
        this.setData({
            showConfirmModal: !1
        });
    },
    handleConfirmModalCancel: function() {
        this.setData({
            showConfirmModal: !1
        });
    },
    handleCloseAppGuideModal: function() {
        this.setData({
            showAppGuideModal: !1
        });
    }
});