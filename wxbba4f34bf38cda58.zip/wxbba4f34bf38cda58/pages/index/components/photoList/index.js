Component({
    properties: {
        photoList: {
            type: Array
        },
        loading: {
            type: Boolean,
            value: !1
        },
        scrollable: {
            type: Boolean,
            value: !1
        },
        refreshTriggered: {
            type: Boolean
        }
    },
    data: {},
    methods: {
        handleTapPhotoItem: function(e) {
            var t = e.currentTarget.dataset.item;
            wx.navigateTo({
                url: "/pages/previewImages/index?albumId=".concat(t.albumId, "&picId=").concat(t.id)
            });
        },
        handleScrollBottom: function() {
            this.triggerEvent("loadMore");
        },
        handleRefresh: function() {
            this.triggerEvent("refresh");
        }
    }
});