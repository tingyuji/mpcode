Object.defineProperty(exports, "__esModule", {
    value: !0
});

var e = require("../../../../@babel/runtime/helpers/toConsumableArray");

Component({
    properties: {
        albumList: {
            type: Array,
            observer: function(t) {
                null == t || t.forEach(function(t) {
                    t.albumPicList ? t.albumPicList.length < 4 && (t.albumPicList = [].concat(e(t.albumPicList), e(new Array(4 - t.albumPicList.length).fill({})))) : t.albumPicList = new Array(4).fill({});
                }), this.setData({
                    albumListInner: t
                });
            }
        },
        loading: {
            type: Boolean,
            value: !1
        },
        scrollable: {
            type: Boolean,
            value: !1
        },
        refreshTriggered: {
            type: Boolean
        }
    },
    data: {
        albumListInner: []
    },
    methods: {
        handleTapAlbumItem: function(e) {
            var t = e.currentTarget.dataset.albumitem;
            wx.navigateTo({
                url: "/pages/customResult/index?albumId=".concat(t.id)
            });
        },
        handleTapPicItem: function(e) {
            var t = e.currentTarget.dataset.picitem, a = e.currentTarget.dataset.albumitem;
            null != t && t.id && wx.navigateTo({
                url: "/pages/previewImages/index?albumId=".concat(a.id, "&picId=").concat(t.id)
            });
        },
        handleScrollBottom: function() {
            this.triggerEvent("loadMore");
        },
        handleRefresh: function() {
            this.triggerEvent("refresh");
        },
        handleTapMoreBtn: function(e) {
            var t = e.currentTarget.dataset.albumitem;
            this.triggerEvent("tapMore", t);
        }
    }
});