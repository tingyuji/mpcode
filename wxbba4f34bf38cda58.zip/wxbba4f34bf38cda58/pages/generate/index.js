var e, t = require("../../@babel/runtime/helpers/defineProperty"), a = p(require("../../@babel/runtime/regenerator")), r = require("../../@babel/runtime/helpers/asyncToGenerator"), n = p(require("../../behaviors/pvBehavior")), s = p(require("../../behaviors/userInfoBehavior")), i = p(require("../../behaviors/shareBehavior")), u = require("../../service/api"), o = require("../../utils/wechat"), c = require("../../typings/user"), l = require("../../typings/generate");

function p(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

Page((t(e = {
    _firstLoading: !1,
    behaviors: [ n.default, s.default, i.default ],
    data: {
        platform: "",
        mtConfig: {},
        showAigcTermsDialog: !1,
        steps: [ {
            id: "front",
            title: "上传正面照片",
            desc: "1张五官清晰的正面照片",
            status: "active",
            stepNumActiveImg: "/image/one-active.png",
            stepNumImg: "/image/one.png"
        }, {
            id: "multi",
            title: "补充至少 20 张照片 ",
            desc: "上传半身照效果最佳",
            stepNumActiveImg: "/image/two-active.png",
            stepNumImg: "/image/two.png"
        } ],
        curTaskId: void 0,
        curStepIdx: -1,
        showResetBackConfirm: !1,
        showBackConfirm: !1,
        resetFlag: !1,
        stepsEnterable: [ !1, !1 ],
        digitalGoodInfo: null,
        showBuyDialog: !1,
        showMaleTip: !1
    },
    onLoad: function() {
        var e = this;
        return r(a.default.mark(function t() {
            var r;
            return a.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return e._firstLoading = !0, r = getApp().globalData.platform, t.t0 = e, t.t1 = r, 
                    t.next = 6, getApp().getMtConfig();

                  case 6:
                    return t.t2 = t.sent, t.t3 = {
                        platform: t.t1,
                        mtConfig: t.t2
                    }, t.t0.setData.call(t.t0, t.t3), t.next = 11, e.goStep();

                  case 11:
                    e._firstLoading = !1;

                  case 12:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    },
    onShow: function() {
        var e = this;
        return r(a.default.mark(function t() {
            var r, n, s;
            return a.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (n = e.data, s = n.curStepIdx, n.platform, !e._firstLoading) {
                        t.next = 3;
                        break;
                    }
                    return t.abrupt("return");

                  case 3:
                    1 === s && (null === (r = e.getMultiStateResult()) || void 0 === r ? void 0 : r.state) === l.TaskState.PROCESSED && e.goStep();

                  case 4:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    },
    goStep: function() {
        var e = this;
        return r(a.default.mark(function t() {
            var r, n, s, i, u;
            return a.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.next = 2, getApp().getFreshUserInfo();

                  case 2:
                    if (r = t.sent) {
                        t.next = 5;
                        break;
                    }
                    return t.abrupt("return");

                  case 5:
                    n = r.task, s = r.resetFlag, i = null == n ? void 0 : n.taskId, u = null == n ? void 0 : n.taskStage, 
                    e.setData({
                        curTaskId: i ? Number(i) : void 0,
                        resetFlag: s
                    }), u === c.AppearTaskStage.FrontViewRecognize ? e.setData({
                        curStepIdx: 0
                    }) : u === c.AppearTaskStage.MultiViewRecognize ? e.setData({
                        curStepIdx: 1
                    }) : u === c.AppearTaskStage.ModelDeploy ? e.setData({
                        curStepIdx: 2
                    }) : u === c.AppearTaskStage.DigitalModelChoose ? e.setData({
                        curStepIdx: 3
                    }) : e.setData({
                        curStepIdx: 0
                    });

                  case 10:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    },
    handleCurTaskIdChange: function(e) {
        this.setData({
            curTaskId: e.detail
        });
    },
    handleFronViewPhotoUploadTap: function() {
        this.setData({
            showAigcTermsDialog: !0
        });
    },
    handleAigcPolicyOkTap: function() {
        this.setData({
            showAigcTermsDialog: !1
        }), this.selectComponent("#frontViewUploadGenerator").choosePhotos();
    },
    handleAigcPolicyCancelTap: function() {
        this.setData({
            showAigcTermsDialog: !1
        });
    },
    handleForwardNext: function() {
        console.log("1"), this.setData({
            curStepIdx: 1
        });
    },
    subscribeGenSucMsg: function() {
        (0, o.requestSubscribeMessage)("ek5jmP6uiBQ5N2d7dQxJ7T-FghnA6YTz4Ul-ZS7_Blg", {
            successText: "你已开启消息通知，数字分身制作好后会通知你哦"
        });
    },
    generateAppearance: function() {
        var e = this;
        return r(a.default.mark(function t() {
            var r;
            return a.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return r = e.data.curTaskId, t.next = 3, (0, u.dealDigitalApp)({
                        task_id: r,
                        task_type: 1
                    });

                  case 3:
                    return t.abrupt("return", t.sent);

                  case 4:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    },
    handleBuySuccess: function() {
        var e = this;
        return r(a.default.mark(function t() {
            return a.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    e.doGenAppear(), e.setData({
                        showBuyDialog: !1
                    });

                  case 2:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    },
    handleCloseBuyDialog: function() {
        this.setData({
            showBuyDialog: !1
        });
    },
    handleMultiNext: function(e) {
        var t = this;
        return r(a.default.mark(function r() {
            var n, s, i, u;
            return a.default.wrap(function(a) {
                for (;;) switch (a.prev = a.next) {
                  case 0:
                    return n = t.data.platform, t.setData({
                        digitalGoodInfo: e.detail
                    }), a.next = 4, getApp().getFreshUserInfo();

                  case 4:
                    s = a.sent, i = s.resetFlag, u = s.freeResetNum, i && u > 0 ? t.doGenAppear() : "ios" === n ? wx.navigateTo({
                        url: "/pages/payByWxOfficialAccount/index"
                    }) : t.setData({
                        showBuyDialog: !0
                    });

                  case 7:
                  case "end":
                    return a.stop();
                }
            }, r);
        }))();
    },
    doGenAppear: function() {
        var e = this;
        return r(a.default.mark(function t() {
            var r, n, s;
            return a.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.next = 2, getApp().getFreshUserInfo();

                  case 2:
                    if (r = t.sent, n = r.task, !r.resetFlag) {
                        t.next = 8;
                        break;
                    }
                    return t.next = 7, (0, u.regularReset)().catch(function() {
                        return null;
                    });

                  case 7:
                    e.setData({
                        resetFlag: !1
                    });

                  case 8:
                    if ((null == n ? void 0 : n.taskStage) !== c.AppearTaskStage.ModelDeploy) {
                        t.next = 12;
                        break;
                    }
                    s = !0, t.next = 16;
                    break;

                  case 12:
                    return t.next = 14, e.generateAppearance().catch(function() {
                        return !1;
                    });

                  case 14:
                    (s = t.sent) || wx.showToast({
                        icon: "error",
                        title: "生成失败"
                    });

                  case 16:
                    s && (e.setData({
                        curStepIdx: 2
                    }), e.subscribeGenSucMsg());

                  case 17:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    },
    handleGenAppearanceNext: function() {
        this.setData({
            curStepIdx: 3
        });
    },
    handleSubscribeTap: function() {
        this.subscribeGenSucMsg();
    }
}, "generateAppearance", function() {
    var e = this;
    return r(a.default.mark(function t() {
        var r;
        return a.default.wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return r = e.data.curTaskId, t.next = 3, (0, u.dealDigitalApp)({
                    task_id: r,
                    task_type: 1
                });

              case 3:
                return t.abrupt("return", t.sent);

              case 4:
              case "end":
                return t.stop();
            }
        }, t);
    }))();
}), t(e, "handleStateChange", function() {
    var e = this.getFrontStateResult(), t = this.getMultiStateResult(), a = (null == t ? void 0 : t.state) !== l.TaskState.PROCESSING, r = (null == e ? void 0 : e.state) === l.TaskState.PROCESSED && (null == e ? void 0 : e.hasPass);
    this.setData({
        stepsEnterable: [ a, r ]
    });
}), t(e, "setStepEnterable", function() {
    var e;
    this.setData({
        stepsEnterable: [ !0, (null === (e = this.getFrontStateResult()) || void 0 === e ? void 0 : e.state) === l.TaskState.PROCESSED ]
    });
}), t(e, "getFrontStateResult", function() {
    var e;
    return null === (e = this.selectComponent("#frontViewUploadGenerator")) || void 0 === e ? void 0 : e.getStateResult();
}), t(e, "getMultiStateResult", function() {
    var e;
    return null === (e = this.selectComponent("#multiAngleUpload")) || void 0 === e ? void 0 : e.getStateResult();
}), t(e, "handleStepTap", function(e) {
    var t = e.currentTarget.dataset.index, a = this.data;
    a.curStepIdx;
    a.stepsEnterable[t] && this.setData({
        curStepIdx: t
    });
}), t(e, "handleNavBack", function() {
    var e = this;
    return r(a.default.mark(function t() {
        var r;
        return a.default.wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return e.data.curStepIdx, t.next = 3, getApp().getFreshUserInfo();

              case 3:
                null != (r = t.sent) && r.resetFlag ? e.setData({
                    showResetBackConfirm: !0
                }) : wx.navigateBack();

              case 5:
              case "end":
                return t.stop();
            }
        }, t);
    }))();
}), t(e, "handleTapBackOk", function() {
    wx.navigateBack(), this.setData({
        showBackConfirm: !1
    });
}), t(e, "handleTapBackCancel", function() {
    this.setData({
        showBackConfirm: !1
    });
}), t(e, "handleQuitResetOk", function() {
    var e = this;
    return r(a.default.mark(function t() {
        return a.default.wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return t.next = 2, (0, u.releaseReset)();

              case 2:
                t.sent && (e.setData({
                    showResetBackConfirm: !1
                }), wx.navigateBack());

              case 4:
              case "end":
                return t.stop();
            }
        }, t);
    }))();
}), t(e, "handleQuitResetCancel", function() {
    this.setData({
        showResetBackConfirm: !1
    });
}), t(e, "hanldeRecognizeMale", function() {
    this.setData({
        showMaleTip: !0
    });
}), t(e, "handleCloseMaleTip", function() {
    this.setData({
        showMaleTip: !1
    });
}), e));