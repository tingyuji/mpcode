var e, t = (e = require("../../../../@babel/runtime/regenerator")) && e.__esModule ? e : {
    default: e
}, a = require("../../../../@babel/runtime/helpers/asyncToGenerator"), r = require("../../../../service/api");

Component({
    properties: {
        curTaskId: Number
    },
    data: {
        appearanceList: [],
        oriDigitalAppearance: null,
        hasOrigin: !1,
        selectedItem: null,
        showConfirmDialog: !1
    },
    lifetimes: {
        attached: function() {
            var e = this;
            return a(t.default.mark(function a() {
                var i, n, s, o, c, d;
                return t.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return i = e.properties.curTaskId, e.recordPV({
                            spmA: "tixiang_wx",
                            spmB: "imgresultpage"
                        }), t.next = 4, (0, r.getDigitalApp)({
                            task_id: i
                        });

                      case 4:
                        n = t.sent, o = (s = n || {}).digitalAppearance, c = s.oriDigitalAppearance, d = s.taskState, 
                        e.setData({
                            appearanceList: o,
                            oriDigitalAppearance: c,
                            hasOrigin: !(null == c || !c.id),
                            selectedItem: null == o ? void 0 : o[0]
                        }), "pending" === d && wx.navigateTo({
                            url: "/pages/justifySeed/index?task_id=".concat(i)
                        });

                      case 8:
                      case "end":
                        return t.stop();
                    }
                }, a);
            }))();
        },
        detached: function() {}
    },
    methods: {
        handleTapItem: function(e) {
            var t, a = e.currentTarget.dataset.item;
            a.id === (null === (t = this.data.selectedItem) || void 0 === t ? void 0 : t.id) ? this.setData({
                selectedItem: null
            }) : this.setData({
                selectedItem: a
            });
        },
        handleTapGoBtn: function() {
            var e = this.data, t = e.hasOrigin;
            e.selectedItem && (t ? this.setData({
                showConfirmDialog: !0
            }) : this.chooseCurSelectedAppear());
        },
        chooseCurSelectedAppear: function() {
            var e = this;
            return a(t.default.mark(function a() {
                var i, n;
                return t.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return i = e.properties.curTaskId, n = e.data.selectedItem, t.next = 4, (0, r.chooseDigitalApp)({
                            task_id: i,
                            digital_model_id: n.id
                        });

                      case 4:
                        t.sent && wx.reLaunch({
                            url: "/pages/index/index"
                        });

                      case 6:
                      case "end":
                        return t.stop();
                    }
                }, a);
            }))();
        },
        handleTapRedoBtn: function() {
            var e = this;
            return a(t.default.mark(function a() {
                var i;
                return t.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return i = e.properties.curTaskId, t.next = 3, (0, r.chooseDigitalApp)({
                            task_id: i
                        });

                      case 3:
                        t.sent && wx.navigateTo({
                            url: "/pages/justifySeed/index?task_id=".concat(i)
                        });

                      case 5:
                      case "end":
                        return t.stop();
                    }
                }, a);
            }))();
        },
        handleConfirmOk: function() {
            this.setData({
                showConfirmDialog: !1
            }), this.chooseCurSelectedAppear();
        },
        handleConfirmCancel: function() {
            this.setData({
                showConfirmDialog: !1
            });
        }
    }
});