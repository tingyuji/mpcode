var e, t = (e = require("../../../../@babel/runtime/regenerator")) && e.__esModule ? e : {
    default: e
}, a = require("../../../../@babel/runtime/helpers/objectSpread2"), n = require("../../../../@babel/runtime/helpers/asyncToGenerator"), i = require("../../../../@babel/runtime/helpers/toConsumableArray"), r = require("../../../../utils/alioss"), s = require("../../../../typings/generate"), o = require("../../../../service/api"), c = require("../../../../utils/img"), u = require("../../../../utils/mt"), l = require("../../../../utils/dataUtils");

function d(e) {
    return e && 0 !== e.length ? e.length >= 20 ? e : [].concat(i(e), i(new Array(20 - e.length).fill(""))) : new Array(20).fill("");
}

Component({
    properties: {
        curTaskId: Number
    },
    data: {
        qualifiedMinNum: 20,
        tempFilePaths: new Array(20).fill(""),
        delPicIds: [],
        canGenerate: !1,
        checkResult: null,
        recogniseState: s.TaskState.NULL,
        recogniseScore: 0,
        recogniseResultPicInfos: [],
        recogniseResultShowPicInfos: [],
        recogniseResultQualifiedPicInfos: [],
        recogniseResultQualifiedFilteredPicInfos: [],
        recogniseResultQualifiedShowPicInfos: [],
        recogniseResultUnqualifiedPicInfos: [],
        timer: {
            timeoutId: 0
        },
        selectedFailItem: null,
        platform: "",
        digitalGoodInfo: null,
        resetFlag: !1,
        freeResetNum: 0,
        uploading: !1
    },
    observers: {
        checkResult: function() {
            this.triggerEvent("stateResultChange");
        }
    },
    lifetimes: {
        attached: function() {
            var e = this;
            return n(t.default.mark(function n() {
                var i, r, o;
                return t.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        if (i = e.properties.curTaskId, r = getApp().globalData.platform, e.setData({
                            platform: r
                        }), "ios" !== r && (0, u.getGoodsMtConfig)().then(function(t) {
                            var n, i = null == t || null === (n = t.digital_goods) || void 0 === n ? void 0 : n[0];
                            i && e.setData({
                                digitalGoodInfo: a(a({}, i), {}, {
                                    goodsPriceStr: (0, l.getPriceStr)(i.goods_price),
                                    originPriceStr: (0, l.getPriceStr)(i.origin_price)
                                })
                            });
                        }), !i) {
                            t.next = 13;
                            break;
                        }
                        return t.next = 7, e.checkStateInterval(i, !1);

                      case 7:
                        if (e.data.recogniseState !== s.TaskState.NULL) {
                            t.next = 13;
                            break;
                        }
                        return t.next = 10, getApp().getFreshUserInfo();

                      case 10:
                        o = t.sent, o.task.hasUploadMultiViewPic && e.recognisePhotos([], s.RecogniseType.AutoRecognize);

                      case 13:
                        return t.t0 = e, t.next = 16, getApp().getMtConfig();

                      case 16:
                        t.t1 = t.sent, t.t2 = {
                            mtConfig: t.t1
                        }, t.t0.setData.call(t.t0, t.t2);

                      case 19:
                      case "end":
                        return t.stop();
                    }
                }, n);
            }))();
        },
        detached: function() {
            this.data.timer.timeoutId > 0 && clearTimeout(this.data.timer.timeoutId);
        }
    },
    methods: {
        getStateResult: function() {
            return this.data.checkResult;
        },
        handleUploadBtnTap: function() {
            this.choosePhotos(s.RecogniseType.First);
        },
        choosePhotos: function(e) {
            var a, i = this;
            wx.chooseMedia({
                count: 20,
                mediaType: [ "image" ],
                sourceType: [ "album" ],
                camera: "front",
                success: (a = n(t.default.mark(function a(n) {
                    var r, s, o, u, l, f, p;
                    return t.default.wrap(function(t) {
                        for (;;) switch (t.prev = t.next) {
                          case 0:
                            return s = n.tempFiles, console.log("photos res: ", n), o = s.map(function(e) {
                                return e.tempFilePath;
                            }), i.setData({
                                tempFilePaths: d(o)
                            }), wx.showLoading({
                                title: "上传中"
                            }), i.setData({
                                uploading: !0
                            }), t.next = 8, i.uploadPhotos(o);

                          case 8:
                            if (u = t.sent, l = u.successPaths, f = u.pathMap, p = !1, (null === (r = l) || void 0 === r ? void 0 : r.length) === o.length) {
                                t.next = 22;
                                break;
                            }
                            if (l && 0 !== l.length) {
                                t.next = 21;
                                break;
                            }
                            return wx.showToast({
                                icon: "error",
                                title: "照片上传失败"
                            }), i.setData({
                                tempFilePaths: d([])
                            }), i.setData({
                                uploading: !1
                            }), t.abrupt("return");

                          case 21:
                            p = !0;

                          case 22:
                            return t.next = 24, (0, c.addRotateParamIfRotated)(l, f);

                          case 24:
                            return l = t.sent, console.log("add rotate param photoUrls ", l), t.next = 28, i.recognisePhotos(l, e);

                          case 28:
                            p ? wx.showToast({
                                icon: "error",
                                title: "部分照片上传失败"
                            }) : wx.showToast({
                                icon: "success",
                                title: "上传成功"
                            }), i.setData({
                                uploading: !1
                            });

                          case 30:
                          case "end":
                            return t.stop();
                        }
                    }, a);
                })), function(e) {
                    return a.apply(this, arguments);
                })
            });
        },
        uploadPhotos: function(e) {
            return n(t.default.mark(function a() {
                return t.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return t.abrupt("return", (0, r.uploadFilesToOss)(e));

                      case 1:
                      case "end":
                        return t.stop();
                    }
                }, a);
            }))();
        },
        recognisePhotos: function(e, a) {
            var i = this;
            return n(t.default.mark(function n() {
                var r, s;
                return t.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return r = i.properties.curTaskId, s = i.data.delPicIds, t.next = 4, (0, o.upMultiViewPic)({
                            task_id: r,
                            pic_list: JSON.stringify(e),
                            del_pic_ids: JSON.stringify(s),
                            type: a
                        }).catch(function() {
                            return null;
                        });

                      case 4:
                        if (t.sent) {
                            t.next = 8;
                            break;
                        }
                        return wx.showToast({
                            icon: "error",
                            title: "识别失败"
                        }), t.abrupt("return");

                      case 8:
                        return i.setData({
                            delPicIds: []
                        }), t.next = 11, i.checkStateInterval(r);

                      case 11:
                      case "end":
                        return t.stop();
                    }
                }, n);
            }))();
        },
        checkStateInterval: function(e) {
            var a = arguments, r = this;
            return n(t.default.mark(function u() {
                var l;
                return t.default.wrap(function(u) {
                    for (;;) switch (u.prev = u.next) {
                      case 0:
                        return !(a.length > 1 && void 0 !== a[1]) || a[1], l = function() {
                            var a = n(t.default.mark(function a() {
                                var n, u, d, f, p, h, g, m, P, I, w, x, v, R, k, S, T;
                                return t.default.wrap(function(t) {
                                    for (;;) switch (t.prev = t.next) {
                                      case 0:
                                        return t.next = 2, (0, o.checkMvpState)({
                                            task_id: e
                                        }).catch(function() {
                                            return r.data.timer.timeoutId = setTimeout(l, 1e3), null;
                                        });

                                      case 2:
                                        if (n = t.sent) {
                                            t.next = 7;
                                            break;
                                        }
                                        return r.setData({
                                            recogniseState: s.TaskState.NULL
                                        }), r.recordPV({
                                            spmA: "tixiang_wx",
                                            spmB: "multypicsupload"
                                        }), t.abrupt("return");

                                      case 7:
                                        if (u = n.canGenerate, d = n.state, f = n.score, p = n.canNotGenerateReason, h = n.picInfos, 
                                        h = (0, c.convertPicListRotateParam)(h), g = h.filter(function(e) {
                                            return e.qualified;
                                        }), m = h.filter(function(e) {
                                            return !e.qualified;
                                        }), r.setData({
                                            checkResult: n,
                                            recogniseState: d,
                                            recogniseScore: f,
                                            recogniseResultPicInfos: h,
                                            recogniseResultShowPicInfos: h.length % 5 == 0 ? h : [].concat(i(h), i(new Array(5 - h.length % 5).fill({}))),
                                            recogniseResultQualifiedPicInfos: g,
                                            recogniseResultUnqualifiedPicInfos: m,
                                            recogniseResultUnqualifiedShowPicInfos: m.length % 5 == 0 ? m : [].concat(i(m), i(new Array(5 - m.length % 5).fill({})))
                                        }), r.setShowQualifiedPicInfos(), d !== s.TaskState.PROCESSING && d !== s.TaskState.UNPROCESSED) {
                                            t.next = 18;
                                            break;
                                        }
                                        r.data.timer.timeoutId = setTimeout(l, 1e3), t.next = 31;
                                        break;

                                      case 18:
                                        if (d !== s.TaskState.PROCESSED) {
                                            t.next = 31;
                                            break;
                                        }
                                        if (console.log("canGenerate: ", u), r.setData({
                                            canGenerate: u
                                        }), u) {
                                            t.next = 26;
                                            break;
                                        }
                                        I = (P = p || {}).picCountIsEnough, w = P.hasMultiView, x = void 0 === w || w, v = P.hasMultiExpression, 
                                        R = void 0 === v || v, k = P.samePerson, S = void 0 === k || k, r.setData({
                                            canNotGenerateReason: p,
                                            picCountIsEnough: I,
                                            allReasonQualified: x && R && S,
                                            suggestTip: x || R ? x ? R ? "" : "人脸表情不够丰富" : "人脸角度不够丰富" : "人脸角度和表情不够丰富"
                                        }), t.next = 30;
                                        break;

                                      case 26:
                                        return t.next = 28, getApp().getFreshUserInfo();

                                      case 28:
                                        T = t.sent, r.setData({
                                            resetFlag: T.resetFlag,
                                            freeResetNum: T.freeResetNum
                                        });

                                      case 30:
                                        r.recordPV({
                                            spmA: "tixiang_wx",
                                            spmB: "picscanresult"
                                        });

                                      case 31:
                                      case "end":
                                        return t.stop();
                                    }
                                }, a);
                            }));
                            return function() {
                                return a.apply(this, arguments);
                            };
                        }(), u.abrupt("return", l());

                      case 3:
                      case "end":
                        return u.stop();
                    }
                }, u);
            }))();
        },
        setShowQualifiedPicInfos: function() {
            var e = this.data, t = e.recogniseResultQualifiedPicInfos, a = e.delPicIds, n = t;
            if (a.length > 0 && (n = t.filter(function(e) {
                return a.indexOf(e.id) < 0;
            })), this.setData({
                recogniseResultQualifiedFilteredPicInfos: n
            }), n.length >= 20 && n.length % 5 == 0) this.setData({
                recogniseResultQualifiedShowPicInfos: n
            }); else {
                var r = n.length >= 20 ? 5 - n.length % 5 : 20 - n.length;
                this.setData({
                    recogniseResultQualifiedShowPicInfos: [].concat(i(n), i(new Array(r).fill({})))
                });
            }
        },
        handleTapReuploadForwardBtn: function() {
            getApp().recordClick("tixiang_wx.page_picscanresult.action.reuploadbtn"), this.choosePhotos(s.RecogniseType.Append);
        },
        handleTapUploadMultiAngleBtn: function() {
            this.choosePhotos(s.RecogniseType.Append);
        },
        handleTapReComputeBtn: function() {
            var e = this;
            return n(t.default.mark(function a() {
                return t.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return t.next = 2, e.recognisePhotos([], s.RecogniseType.Append);

                      case 2:
                      case "end":
                        return t.stop();
                    }
                }, a);
            }))();
        },
        handleTapGenerateBtn: function() {
            getApp().recordClick("tixiang_wx.page_picscanresult.action.trainingbtn"), this.triggerEvent("next", this.data.digitalGoodInfo);
        },
        handleTapDeletePhoto: function(e) {
            var t = e.currentTarget.dataset.item;
            this.setData({
                delPicIds: [].concat(i(this.data.delPicIds), [ t.id ])
            }), this.setShowQualifiedPicInfos();
        },
        handleTapFailItem: function(e) {
            var t = e.currentTarget.dataset.item;
            if (this.data.selectedFailItem) {
                if (t.id === this.data.selectedFailItem.id) return void this.setData({
                    selectedFailItem: null
                });
                this.setData({
                    selectedFailItem: t
                });
            } else this.setData({
                selectedFailItem: t
            });
        }
    }
});