var e, t = require("../../../../@babel/runtime/helpers/objectSpread2"), a = (e = require("../../../../@babel/runtime/regenerator")) && e.__esModule ? e : {
    default: e
}, n = require("../../../../@babel/runtime/helpers/asyncToGenerator"), r = require("../../../../utils/time"), i = require("../../../../utils/img"), o = require("../../../../service/api"), m = require("../../../../typings/generate");

var u = [ {
    top: "0",
    left: "130rpx",
    animationName: "fadeInZoomOut",
    animationDelay: "0.1s"
}, {
    top: "0",
    left: "390rpx",
    animationName: "fadeInZoomOut",
    animationDelay: "1.15s"
}, {
    top: "152rpx",
    left: "0",
    animationName: "fadeInZoomOut",
    animationDelay: 0
}, {
    top: "148rpx",
    left: "204rpx",
    animationName: "fadeInZoomOut",
    animationDelay: "0.18s"
}, {
    top: "150rpx",
    left: "350rpx",
    animationName: "fadeInZoomOut",
    animationDelay: "1.22s"
}, {
    top: "150rpx",
    left: "540rpx",
    animationName: "fadeInZoomOut",
    animationDelay: 0
}, {
    top: "311rpx",
    left: "7rpx",
    animationName: "fadeInZoomOut",
    animationDelay: "1s"
}, {
    top: "282rpx",
    left: "180rpx",
    animationName: "fadeInZoomOut",
    animationDelay: "0.06s"
}, {
    top: "287rpx",
    left: "361rpx",
    animationName: "fadeInZoomOut",
    animationDelay: "0.05s"
}, {
    top: "330rpx",
    left: "521rpx",
    animationName: "fadeInZoomOut",
    animationDelay: 0
}, {
    top: "494rpx",
    left: "0",
    animationName: "fadeInZoomIn",
    animationDelay: "1.12s"
}, {
    top: "415rpx",
    left: "137rpx",
    animationName: "fadeInZoomOut",
    animationDelay: 0
}, {
    top: "440rpx",
    left: "280rpx",
    animationName: "fadeInZoomOut",
    animationDelay: "0.06s"
}, {
    top: "458rpx",
    left: "438rpx",
    animationName: "fadeInZoomOut",
    animationDelay: "0.09s"
}, {
    top: "677rpx",
    left: "9rpx",
    animationName: "fadeInZoomOut",
    animationDelay: "0.13s"
}, {
    top: "580rpx",
    left: "174rpx",
    animationName: "fadeInZoomIn",
    animationDelay: "1s"
}, {
    top: "627rpx",
    left: "347rpx",
    animationName: "fadeInZoomOut",
    animationDelay: "0.18s"
}, {
    top: "593rpx",
    left: "503rpx",
    animationName: "fadeInZoomIn",
    animationDelay: "1.26s"
}, {
    top: "730rpx",
    left: "170rpx",
    animationName: "fadeInZoomIn",
    animationDelay: "1.03s"
}, {
    top: "723rpx",
    left: "551rpx",
    animationName: "fadeInZoomOut",
    animationDelay: "0.19s"
} ];

Component({
    properties: {
        curTaskId: Number
    },
    data: {
        remainTime: void 0,
        state: "",
        picMaterials: [],
        timer: {
            timeoutId: 0
        }
    },
    lifetimes: {
        attached: function() {
            var e = this;
            return n(a.default.mark(function t() {
                var n;
                return a.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        if (e.recordPV({
                            spmA: "tixiang_wx",
                            spmB: "imggenerating"
                        }), n = e.properties.curTaskId) {
                            t.next = 4;
                            break;
                        }
                        return t.abrupt("return");

                      case 4:
                        return t.next = 6, e.checkStateInterval(n, !1);

                      case 6:
                      case "end":
                        return t.stop();
                    }
                }, t);
            }))();
        },
        detached: function() {
            this.data.timer.timeoutId > 0 && clearTimeout(this.data.timer.timeoutId);
        }
    },
    methods: {
        checkStateInterval: function(e) {
            var t = arguments, i = this;
            return n(a.default.mark(function u() {
                var s, p;
                return a.default.wrap(function(u) {
                    for (;;) switch (u.prev = u.next) {
                      case 0:
                        !(t.length > 1 && void 0 !== t[1]) || t[1], s = !(t.length > 2 && void 0 !== t[2]) || t[2], 
                        (p = function() {
                            var t = n(a.default.mark(function t() {
                                var n, u, l, f, c, d;
                                return a.default.wrap(function(t) {
                                    for (;;) switch (t.prev = t.next) {
                                      case 0:
                                        return t.next = 2, (0, o.getDigitalAppRate)({
                                            task_id: e
                                        }).catch(function() {
                                            return i.data.timer.timeoutId = setTimeout(p, 1e3), null;
                                        });

                                      case 2:
                                        if (n = t.sent) {
                                            t.next = 5;
                                            break;
                                        }
                                        return t.abrupt("return");

                                      case 5:
                                        u = n.remainTime, l = n.queueLengthPerson, f = n.state, c = n.picMaterials, i.setData({
                                            remainTime: u,
                                            remainTimeStr: "number" == typeof u && u >= 0 ? (0, r.formatDuration)(1e3 * u) : "--",
                                            queueLengthPerson: l,
                                            state: f,
                                            picMaterials: c
                                        }), i.setAllQualifiedShowPhotos(c), f === m.TaskState.PROCESSING || f === m.TaskState.UNPROCESSED ? (d = 0 === i.data.timer.timeoutId && s, 
                                        i.data.timer.timeoutId = setTimeout(p, d ? 0 : 1e3)) : f === m.TaskState.PROCESSED && (wx.showToast({
                                            icon: "success",
                                            title: "种子形象生成成功"
                                        }), i.triggerEvent("next"));

                                      case 9:
                                      case "end":
                                        return t.stop();
                                    }
                                }, t);
                            }));
                            return function() {
                                return t.apply(this, arguments);
                            };
                        }())();

                      case 4:
                      case "end":
                        return u.stop();
                    }
                }, u);
            }))();
        },
        setAllQualifiedShowPhotos: function(e) {
            var r = this;
            return n(a.default.mark(function n() {
                return a.default.wrap(function(a) {
                    for (;;) switch (a.prev = a.next) {
                      case 0:
                        if (e && 0 !== e.length) {
                            a.next = 2;
                            break;
                        }
                        return a.abrupt("return");

                      case 2:
                        r.setData({
                            qualifiedShowPhotos: u.map(function(a, n) {
                                var r;
                                return t(t({}, a), {}, {
                                    picUrl: (0, i.convertPicRotateParam)(null === (r = e[n]) || void 0 === r ? void 0 : r.picUrl)
                                });
                            })
                        });

                      case 3:
                      case "end":
                        return a.stop();
                    }
                }, n);
            }))();
        },
        handleTapSubscribeBtn: function() {
            this.triggerEvent("subscribeTap");
        },
        handleTapReGenBtn: function() {
            var e = this;
            return n(a.default.mark(function t() {
                var n;
                return a.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return n = e.properties.curTaskId, t.next = 3, (0, o.dealDigitalApp)({
                            task_id: n,
                            task_type: 1
                        });

                      case 3:
                        if (!t.sent) {
                            t.next = 7;
                            break;
                        }
                        return t.next = 7, e.checkStateInterval(n, !1);

                      case 7:
                      case "end":
                        return t.stop();
                    }
                }, t);
            }))();
        }
    }
});