var e, t = (e = require("../../../../@babel/runtime/regenerator")) && e.__esModule ? e : {
    default: e
}, r = require("../../../../@babel/runtime/helpers/asyncToGenerator"), n = require("../../../../utils/alioss"), a = require("../../../../typings/generate"), s = require("../../../../service/api");

Component({
    properties: {
        curTaskId: Number
    },
    data: {
        uploadedForwardPhoto: "",
        checkResult: null,
        frontRecogniseState: a.TaskState.UNPROCESSED,
        frontRecognisePassed: !1,
        frontRecogniseResult: null,
        recogniseResultPicInfo: null,
        aigcTermsAgreed: !1,
        showAigcTermsDialog: !1,
        showStarWarning: !1,
        timer: {
            timeoutId: 0
        }
    },
    observers: {
        checkResult: function() {
            this.triggerEvent("stateResultChange");
        }
    },
    lifetimes: {
        attached: function() {
            var e = this;
            return r(t.default.mark(function r() {
                var n;
                return t.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return (n = e.properties.curTaskId) ? e.checkStateInterval(n, !1, !1, !1) : e.recordPV({
                            spmA: "tixiang_wx",
                            spmB: "onepicupload"
                        }), t.t0 = e, t.next = 5, getApp().getMtConfig();

                      case 5:
                        t.t1 = t.sent, t.t2 = {
                            mtConfig: t.t1
                        }, t.t0.setData.call(t.t0, t.t2);

                      case 8:
                      case "end":
                        return t.stop();
                    }
                }, r);
            }))();
        },
        detached: function() {
            this.data.timer.timeoutId > 0 && clearTimeout(this.data.timer.timeoutId);
        }
    },
    methods: {
        getStateResult: function() {
            return this.data.checkResult;
        },
        handleUploadBtnTap: function() {
            this.triggerEvent("frontViewPhotoUploadTap");
        },
        choosePhotos: function() {
            var e, n = this;
            wx.chooseMedia({
                count: 1,
                mediaType: [ "image" ],
                sourceType: [ "album", "camera" ],
                camera: "front",
                success: (e = r(t.default.mark(function e(a) {
                    var s, o, i;
                    return t.default.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            if (s = a.tempFiles, console.log(a), o = null == s ? void 0 : s[0]) {
                                e.next = 5;
                                break;
                            }
                            return e.abrupt("return");

                          case 5:
                            i = o.tempFilePath, wx.cropImage({
                                src: i,
                                cropScale: "3:4",
                                success: function() {
                                    var e = r(t.default.mark(function e(r) {
                                        var a, s;
                                        return t.default.wrap(function(e) {
                                            for (;;) switch (e.prev = e.next) {
                                              case 0:
                                                return a = r.tempFilePath, console.log("crop res: ", r), n.setData({
                                                    uploadedForwardPhoto: a
                                                }), e.next = 5, n.uploadPhoto(a);

                                              case 5:
                                                if (!(s = e.sent)) {
                                                    e.next = 9;
                                                    break;
                                                }
                                                return e.next = 9, n.recognisePhoto(s);

                                              case 9:
                                              case "end":
                                                return e.stop();
                                            }
                                        }, e);
                                    }));
                                    return function(t) {
                                        return e.apply(this, arguments);
                                    };
                                }(),
                                fail: function(e) {
                                    console.log("crop fail", e);
                                }
                            });

                          case 7:
                          case "end":
                            return e.stop();
                        }
                    }, e);
                })), function(t) {
                    return e.apply(this, arguments);
                })
            });
        },
        uploadPhoto: function(e) {
            return r(t.default.mark(function r() {
                var a, s;
                return t.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return wx.showLoading({
                            title: "上传中"
                        }), t.next = 3, (0, n.uploadFilesToOss)([ e ]);

                      case 3:
                        if (a = t.sent, s = a.successPaths, wx.hideLoading(), 1 !== s.length) {
                            t.next = 9;
                            break;
                        }
                        return wx.showToast({
                            icon: "success",
                            title: "上传成功"
                        }), t.abrupt("return", s[0]);

                      case 9:
                        return t.abrupt("return", "");

                      case 10:
                      case "end":
                        return t.stop();
                    }
                }, r);
            }))();
        },
        recognisePhoto: function(e) {
            var n = this;
            return r(t.default.mark(function r() {
                var a, o;
                return t.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return a = n.properties.curTaskId, t.next = 3, (0, s.recoFrontView)({
                            task_id: a || void 0,
                            pic_url: e
                        });

                      case 3:
                        if (o = t.sent) {
                            t.next = 7;
                            break;
                        }
                        return wx.showToast({
                            icon: "error",
                            title: "识别失败"
                        }), t.abrupt("return");

                      case 7:
                        n.triggerEvent("curTaskIdChange", o), n.checkStateInterval(o);

                      case 9:
                      case "end":
                        return t.stop();
                    }
                }, r);
            }))();
        },
        checkStateInterval: function(e) {
            var n = arguments, o = this;
            return r(t.default.mark(function i() {
                var c, u, l, d;
                return t.default.wrap(function(i) {
                    for (;;) switch (i.prev = i.next) {
                      case 0:
                        c = !(n.length > 1 && void 0 !== n[1]) || n[1], u = !(n.length > 2 && void 0 !== n[2]) || n[2], 
                        l = !(n.length > 3 && void 0 !== n[3]) || n[3], (d = function() {
                            var n = r(t.default.mark(function r() {
                                var n, i, f;
                                return t.default.wrap(function(t) {
                                    for (;;) switch (t.prev = t.next) {
                                      case 0:
                                        return t.next = 2, (0, s.checkFrontState)({
                                            task_id: e
                                        }).catch(function() {
                                            return o.data.timer.timeoutId = setTimeout(d, 1e3), null;
                                        });

                                      case 2:
                                        if (n = t.sent) {
                                            t.next = 6;
                                            break;
                                        }
                                        return o.recordPV({
                                            spmA: "tixiang_wx",
                                            spmB: "onepicupload"
                                        }), t.abrupt("return");

                                      case 6:
                                        if (o.setData({
                                            checkResult: n,
                                            frontRecogniseState: n.state,
                                            frontRecognisePassed: n.hasPass,
                                            frontRecogniseResult: n.recognizeResult,
                                            frontRrecogniseResultPicInfo: n.picInfo
                                        }), n.state !== a.TaskState.PROCESSING && n.state !== a.TaskState.UNPROCESSED) {
                                            t.next = 12;
                                            break;
                                        }
                                        o.data.timer.timeoutId = setTimeout(d, 1e3), o.recordPV({
                                            spmA: "tixiang_wx",
                                            spmB: "onepicscan"
                                        }), t.next = 23;
                                        break;

                                      case 12:
                                        if (n.state !== a.TaskState.PROCESSED) {
                                            t.next = 23;
                                            break;
                                        }
                                        if (!n.hasPass) {
                                            t.next = 22;
                                            break;
                                        }
                                        if ("male" === (null === (i = n.recognizeResult) || void 0 === i ? void 0 : i.sex) && l && o.triggerEvent("recognizeMale"), 
                                        null === (f = n.recognizeResult) || void 0 === f || !f.star) {
                                            t.next = 18;
                                            break;
                                        }
                                        return o.setData({
                                            showStarWarning: !0
                                        }), t.abrupt("return");

                                      case 18:
                                        c && wx.showToast({
                                            icon: "success",
                                            title: "识别成功"
                                        }), u && o.triggerEvent("next"), t.next = 23;
                                        break;

                                      case 22:
                                        wx.showToast({
                                            icon: "error",
                                            title: "识别失败"
                                        });

                                      case 23:
                                      case "end":
                                        return t.stop();
                                    }
                                }, r);
                            }));
                            return function() {
                                return n.apply(this, arguments);
                            };
                        }())();

                      case 5:
                      case "end":
                        return i.stop();
                    }
                }, i);
            }))();
        },
        handleTapReuploadForwardBtn: function() {
            this.choosePhotos();
        },
        handleTapUploadMultiAngleBtn: function() {
            this.triggerEvent("next");
        }
    }
});