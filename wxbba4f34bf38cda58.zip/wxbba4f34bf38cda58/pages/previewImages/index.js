var e = require("../../@babel/runtime/helpers/objectSpread2"), t = c(require("../../@babel/runtime/regenerator")), n = require("../../@babel/runtime/helpers/asyncToGenerator"), a = c(require("../../behaviors/pvBehavior")), r = c(require("../../behaviors/userInfoBehavior")), i = c(require("../../behaviors/shareBehavior")), o = require("../../service/api"), s = require("../../utils/img"), u = require("../../utils/mt");

function c(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

Page({
    timer: {
        timeoutId: 0
    },
    hdGenerating: !1,
    precising: !1,
    gettingShareImg: !1,
    likeSending: !1,
    behaviors: [ a.default, r.default, i.default ],
    data: {
        albumId: void 0,
        picId: void 0,
        imagesList: [],
        indicatorDots: !1,
        vertical: !1,
        autoplay: !1,
        interval: 2e3,
        duration: 500,
        swiperCurrent: -1,
        downloadCount: "",
        showHdLoading: !1,
        hdState: void 0,
        downloading: !1,
        goodsConfig: null,
        showDownloadAnimation: !1,
        showHdAnimation: !1,
        showDiamondCostDialog: !1,
        showDiamondShortageDialog: !1,
        showChargeDialog: !1,
        curActionCode: "",
        curActionName: "",
        curActionCost: 0
    },
    onLoad: function(e) {
        var t = this, n = e.albumId, a = e.picId;
        this.recordPV({
            spmA: "tixiang_wx",
            spmB: "fullpicresult"
        }), n && a && (this.setData({
            albumId: n,
            picId: a
        }), (0, u.getGoodsMtConfig)().then(function(e) {
            t.setData({
                goodsConfig: e
            });
        }), this.init());
    },
    onUnload: function() {
        clearTimeout(this.timer.timeoutId);
    },
    init: function() {
        var e = this;
        return n(t.default.mark(function n() {
            var a, r, i;
            return t.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return r = e.data, r.albumId, i = r.picId, t.next = 3, e.loadPhotoList();

                  case 3:
                    e.setData({
                        swiperCurrent: null === (a = e.data.imagesList) || void 0 === a ? void 0 : a.findIndex(function(e) {
                            return e.id == i;
                        })
                    });

                  case 4:
                  case "end":
                    return t.stop();
                }
            }, n);
        }))();
    },
    loadPhotoList: function() {
        var a = this;
        return n(t.default.mark(function n() {
            var r, i, u;
            return t.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return i = a.data.albumId, t.next = 3, (0, o.getAlbumPic)({
                        album_id: i
                    });

                  case 3:
                    u = t.sent, a.setData({
                        imagesList: null === (r = u.photoVOList) || void 0 === r ? void 0 : r.map(function(t) {
                            return e(e({}, t), {}, {
                                urlWithWater: (0, s.getWatermarkUrl)(t.url)
                            });
                        })
                    });

                  case 5:
                  case "end":
                    return t.stop();
                }
            }, n);
        }))();
    },
    swiperChange: function(e) {
        this.setData({
            swiperCurrent: e.detail.current
        });
    },
    handleDownloadImage: function(e) {
        var a = this;
        return n(t.default.mark(function e() {
            var n, r, i, s, u;
            return t.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return n = a.data, r = n.goodsConfig, i = n.imagesList, s = n.swiperCurrent, u = i[s], 
                    getApp().recordClick("tixiang_wx.page_fullpicresult.actions.downloadbtn", u), e.next = 5, 
                    (0, o.queryCoinBalance)();

                  case 5:
                    e.sent - r.download_coin >= 0 ? a.setData({
                        showDiamondCostDialog: !0,
                        curActionCode: "download",
                        curActionName: "下载",
                        curActionCost: r.download_coin
                    }) : a.setData({
                        showDiamondShortageDialog: !0,
                        curActionCode: "download",
                        curActionName: "下载",
                        curActionCost: r.download_coin
                    });

                  case 7:
                  case "end":
                    return e.stop();
                }
            }, e);
        }))();
    },
    wxApiDownload: function(e, a) {
        var r = this;
        return n(t.default.mark(function i() {
            return t.default.wrap(function(i) {
                for (;;) switch (i.prev = i.next) {
                  case 0:
                    if (!r.data.downloading) {
                        i.next = 2;
                        break;
                    }
                    return i.abrupt("return");

                  case 2:
                    r.setData({
                        downloading: !0
                    }), wx.showLoading({
                        title: ""
                    }), wx.getSetting().then(function() {
                        var i = n(t.default.mark(function i(o) {
                            return t.default.wrap(function(i) {
                                for (;;) switch (i.prev = i.next) {
                                  case 0:
                                    if (o.authSetting["scope.writePhotosAlbum"]) {
                                        i.next = 5;
                                        break;
                                    }
                                    console.log("没有相册权限"), wx.authorize({
                                        scope: "scope.writePhotosAlbum"
                                    }).then(function() {
                                        var i = n(t.default.mark(function n(i) {
                                            return t.default.wrap(function(t) {
                                                for (;;) switch (t.prev = t.next) {
                                                  case 0:
                                                    return t.next = 2, r._wxApiDownload(e, a);

                                                  case 2:
                                                    t.sent ? wx.showToast({
                                                        title: "已保存到相册",
                                                        icon: "success"
                                                    }) : wx.showToast({
                                                        title: "下载失败",
                                                        icon: "none"
                                                    }), r.setData({
                                                        downloading: !1
                                                    });

                                                  case 5:
                                                  case "end":
                                                    return t.stop();
                                                }
                                            }, n);
                                        }));
                                        return function(e) {
                                            return i.apply(this, arguments);
                                        };
                                    }(), function(e) {
                                        console.log("没有相册权限", e), wx.showModal({
                                            title: "提示",
                                            content: "您已拒绝保存相册，请打开右上角”设置“->“添加到相册”",
                                            success: function(e) {
                                                this.setData({
                                                    downloading: !1
                                                }), wx.hideLoading();
                                            }
                                        });
                                    }), i.next = 10;
                                    break;

                                  case 5:
                                    return i.next = 7, r._wxApiDownload(e, a);

                                  case 7:
                                    i.sent ? wx.showToast({
                                        title: "已保存到相册",
                                        icon: "success"
                                    }) : wx.showToast({
                                        title: "下载失败",
                                        icon: "none"
                                    }), r.setData({
                                        downloading: !1
                                    });

                                  case 10:
                                  case "end":
                                    return i.stop();
                                }
                            }, i);
                        }));
                        return function(e) {
                            return i.apply(this, arguments);
                        };
                    }());

                  case 5:
                  case "end":
                    return i.stop();
                }
            }, i);
        }))();
    },
    _wxApiDownload: function(e, a) {
        var r = this;
        return new Promise(function(i) {
            var s;
            wx.downloadFile({
                url: e,
                success: (s = n(t.default.mark(function e(s) {
                    return t.default.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            wx.saveImageToPhotosAlbum({
                                filePath: s.tempFilePath,
                                success: function() {
                                    var e = n(t.default.mark(function e() {
                                        return t.default.wrap(function(e) {
                                            for (;;) switch (e.prev = e.next) {
                                              case 0:
                                                return e.next = 2, (0, o.downloadPic)({
                                                    picture_id: a
                                                }).catch(function() {
                                                    return !1;
                                                });

                                              case 2:
                                                if (e.sent) {
                                                    e.next = 6;
                                                    break;
                                                }
                                                return i(!1), e.abrupt("return");

                                              case 6:
                                                r.setData({
                                                    showDownloadAnimation: !0
                                                }), setTimeout(function() {
                                                    r.setData({
                                                        showDownloadAnimation: !1
                                                    });
                                                }, 2e3), i(!0);

                                              case 9:
                                              case "end":
                                                return e.stop();
                                            }
                                        }, e);
                                    }));
                                    return function() {
                                        return e.apply(this, arguments);
                                    };
                                }(),
                                fail: function(e) {
                                    console.log("error: ", e), i(!1);
                                }
                            });

                          case 1:
                          case "end":
                            return e.stop();
                        }
                    }, e);
                })), function(e) {
                    return s.apply(this, arguments);
                }),
                fail: function(e) {
                    console.log("error: ", e), i(!1);
                }
            });
        });
    },
    handleShareImage: function(e) {
        var a = this;
        return n(t.default.mark(function n() {
            var r, i, s;
            return t.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (r = e.currentTarget.dataset.item, i = r[a.data.swiperCurrent], getApp().recordClick("tixiang_wx.page_fullpicresult.actions.momentsharebtn", i), 
                    !a.gettingShareImg) {
                        t.next = 5;
                        break;
                    }
                    return t.abrupt("return");

                  case 5:
                    return a.gettingShareImg = !0, wx.showLoading(), t.next = 9, (0, o.genShareInfo)({
                        source_pic_oss_url: i.url,
                        album_id: a.properties.albumId,
                        album_pic_id: i.id
                    }).catch(function() {
                        return null;
                    });

                  case 9:
                    if (s = t.sent) {
                        t.next = 13;
                        break;
                    }
                    return a.gettingShareImg = !1, t.abrupt("return");

                  case 13:
                    console.log("合成带二维码的url图片", s), wx.downloadFile({
                        url: null == s ? void 0 : s.picOssUrl,
                        success: function(e) {
                            console.log(e), a.gettingShareImg = !1, wx.hideLoading(), wx.showShareImageMenu({
                                path: e.tempFilePath,
                                success: function(e) {}
                            });
                        },
                        fail: function(e) {
                            a.gettingShareImg = !1, wx.hideLoading(), console.log(e);
                        }
                    });

                  case 15:
                  case "end":
                    return t.stop();
                }
            }, n);
        }))();
    },
    handlePrecisionTap: function() {
        var e = this;
        return n(t.default.mark(function n() {
            var a, r, i, s, u, c;
            return t.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (a = e.data, r = a.imagesList, i = a.swiperCurrent, s = r[i], console.log("curPic: ", s), 
                    getApp().recordClick("tixiang_wx.page_fullpicresult.actions.likemebtn"), !e.precising) {
                        t.next = 6;
                        break;
                    }
                    return t.abrupt("return");

                  case 6:
                    return e.precising = !0, u = {
                        album_pic_id: s.id,
                        create_album_type: "albumFineTuning"
                    }, t.next = 10, (0, o.cubeautifulpic)(u).catch(function() {
                        return null;
                    });

                  case 10:
                    c = t.sent, console.log(c, u), c && wx.redirectTo({
                        url: "/pages/customResult/index?albumId=".concat(c)
                    }), e.precising = !1;

                  case 14:
                  case "end":
                    return t.stop();
                }
            }, n);
        }))();
    },
    handleToggleFavorite: function(e) {
        var a = this;
        return n(t.default.mark(function n() {
            var r, i, s;
            return t.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (r = e.currentTarget.dataset.item, i = r[a.data.swiperCurrent], getApp().recordClick("tixiang_wx.page_fullpicresult.actions.favoritebtn", i), 
                    !a.likeSending) {
                        t.next = 5;
                        break;
                    }
                    return t.abrupt("return");

                  case 5:
                    return a.likeSending = !0, t.next = 8, (0, o.likePicture)({
                        like_deal_type: 1 === i.likeFlag ? 0 : 1,
                        picture_id: i.id
                    }).catch(function() {
                        return null;
                    });

                  case 8:
                    if (s = t.sent, a.likeSending = !1, !s) {
                        t.next = 13;
                        break;
                    }
                    return t.next = 13, a.loadPhotoList();

                  case 13:
                  case "end":
                    return t.stop();
                }
            }, n);
        }))();
    },
    handleTapItem: function(e) {
        var a = this;
        return n(t.default.mark(function e() {
            var n, r, i;
            return t.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    n = a.data, r = n.imagesList, i = n.swiperCurrent, wx.previewImage({
                        current: r[i].urlWithWater,
                        urls: r.map(function(e) {
                            return e.urlWithWater;
                        }),
                        showmenu: !1
                    });

                  case 2:
                  case "end":
                    return e.stop();
                }
            }, e);
        }))();
    },
    handleHdTap: function() {
        var e = this;
        return n(t.default.mark(function n() {
            var a;
            return t.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return getApp().recordClick("tixiang_wx.page_fullpicresult.actions.hdbtn"), a = e.data.goodsConfig, 
                    t.next = 4, (0, o.queryCoinBalance)();

                  case 4:
                    t.sent - a.high_definition_coin >= 0 ? e.setData({
                        showDiamondCostDialog: !0,
                        curActionCode: "hd",
                        curActionName: "高清化",
                        curActionCost: a.high_definition_coin
                    }) : e.setData({
                        showDiamondShortageDialog: !0,
                        curActionCode: "hd",
                        curActionName: "高清化",
                        curActionCost: a.high_definition_coin
                    });

                  case 6:
                  case "end":
                    return t.stop();
                }
            }, n);
        }))();
    },
    doHd: function() {
        var e = this;
        return n(t.default.mark(function a() {
            var r, i, s, u, c, d;
            return t.default.wrap(function(a) {
                for (;;) switch (a.prev = a.next) {
                  case 0:
                    if (r = e.data, i = r.imagesList, s = r.swiperCurrent, u = i[s], !e.hdGenerating) {
                        a.next = 4;
                        break;
                    }
                    return a.abrupt("return");

                  case 4:
                    return e.hdGenerating = !0, a.next = 7, (0, o.cubeautifulpic)({
                        create_album_type: "albumPicHighDefinitionMagnify",
                        album_pic_id: u.id
                    }).catch(function() {
                        return !1;
                    });

                  case 7:
                    c = a.sent, e.hdGenerating = !1, c && (e.setData({
                        showHdLoading: !0
                    }), (d = function() {
                        var a = n(t.default.mark(function n() {
                            var a, r;
                            return t.default.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    return t.next = 2, (0, o.getPicGenProcess)({
                                        album_pic_id: u.id
                                    });

                                  case 2:
                                    if (a = t.sent, "processing" !== (null == (r = a.albumPicVO) ? void 0 : r.highDefinitionState)) {
                                        t.next = 9;
                                        break;
                                    }
                                    e.setData({
                                        hdState: "processing"
                                    }), setTimeout(function() {
                                        d();
                                    }, 1e3), t.next = 16;
                                    break;

                                  case 9:
                                    if ("processed" !== (null == r ? void 0 : r.highDefinitionState)) {
                                        t.next = 16;
                                        break;
                                    }
                                    return e.setData({
                                        hdState: "processed"
                                    }), setTimeout(function() {
                                        e.setData({
                                            hdState: void 0,
                                            showHdLoading: !1
                                        });
                                    }, 3e3), e.setData({
                                        showHdAnimation: !0
                                    }), setTimeout(function() {
                                        e.setData({
                                            showHdAnimation: !1
                                        });
                                    }, 2e3), t.next = 16, e.loadPhotoList();

                                  case 16:
                                  case "end":
                                    return t.stop();
                                }
                            }, n);
                        }));
                        return function() {
                            return a.apply(this, arguments);
                        };
                    }())());

                  case 10:
                  case "end":
                    return a.stop();
                }
            }, a);
        }))();
    },
    handleChargeOk: function() {
        "ios" === getApp().globalData.platform ? wx.navigateTo({
            url: "/pages/payByWxOfficialAccount/index"
        }) : this.setData({
            showChargeDialog: !0
        }), this.setData({
            showDiamondShortageDialog: !1
        });
    },
    handleChargeCancel: function() {
        this.setData({
            showDiamondShortageDialog: !1
        });
    },
    handleCloseChargeDialog: function() {
        this.setData({
            showChargeDialog: !1
        });
    },
    handleCostOk: function() {
        var e = this.data, t = e.curActionCode, n = e.imagesList[e.swiperCurrent];
        this.setData({
            showDiamondCostDialog: !1
        }), "download" === t ? this.wxApiDownload(n.url, n.id) : "hd" === t && this.doHd();
    },
    handleCostCancel: function() {
        this.setData({
            showDiamondCostDialog: !1
        });
    },
    onShareAppMessage: function() {
        var e = this;
        return n(t.default.mark(function n() {
            var a, r, i, o, s, u, c;
            return t.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return r = e.data, i = r.imagesList, o = r.swiperCurrent, getApp().recordClick("tixiang_wx.page_fullpicresult.actions.momentshareupbtn"), 
                    s = i[o], t.next = 5, getApp().getMtConfig();

                  case 5:
                    if (t.t0 = t.sent, t.t0) {
                        t.next = 8;
                        break;
                    }
                    t.t0 = {};

                  case 8:
                    return u = t.t0, c = u.shareLinkTitle, t.abrupt("return", {
                        title: c,
                        path: "/pages/index/index?inviter_uid=".concat(null === (a = getApp().globalData.userInfo) || void 0 === a ? void 0 : a.userId),
                        imageUrl: s.url
                    });

                  case 11:
                  case "end":
                    return t.stop();
                }
            }, n);
        }))();
    }
});