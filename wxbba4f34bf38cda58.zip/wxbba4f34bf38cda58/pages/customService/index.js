var e, n = (e = require("../../@babel/runtime/regenerator")) && e.__esModule ? e : {
    default: e
}, t = require("../../@babel/runtime/helpers/asyncToGenerator"), o = require("../../utils/mt");

Page({
    data: {
        questionList: []
    },
    onLoad: function() {
        var e = this;
        return t(n.default.mark(function t() {
            var r;
            return n.default.wrap(function(n) {
                for (;;) switch (n.prev = n.next) {
                  case 0:
                    return e.recordPV({
                        spmA: "tixiang_wx",
                        spmB: "paymentconsult"
                    }), n.next = 3, (0, o.getGoodsMtConfig)();

                  case 3:
                    r = n.sent, console.log("configconfig", r), e.setData({
                        questionList: null == r ? void 0 : r.questionService
                    });

                  case 6:
                  case "end":
                    return n.stop();
                }
            }, t);
        }))();
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    handleTapConsult: function() {
        getApp().recordClick("tixiang_wx.page_paymentconsult.action.consultbtn");
    }
});