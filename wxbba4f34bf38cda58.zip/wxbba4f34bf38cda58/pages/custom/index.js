var e = i(require("../../behaviors/pvBehavior")), t = i(require("../../behaviors/userInfoBehavior")), a = i(require("../../behaviors/shareBehavior")), o = require("../../service/api");

function i(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

Page({
    behaviors: [ e.default, t.default, a.default ],
    data: {
        templateList: [],
        pageNo: 1,
        pageSize: 10,
        hasMore: !0
    },
    onLoad: function() {
        this.recordPV({
            spmA: "tixiang_wx",
            spmB: "stylelist"
        }), getApp().track.spmA = "tixiang_wx", getApp().track.spmB = "stylelist", this.requestDataLiast();
    },
    requestDataLiast: function() {
        var e = this, t = this.data, a = t.pageNo, i = t.pageSize, s = t.templateList;
        (0, o.getTemplateList)({
            page_num: a,
            page_size: i
        }).then(function(t) {
            console.log(t), t ? e.setData({
                templateList: s.concat(t.templateInfoVOS),
                hasMore: t.hasMore
            }, function() {
                e.elementExpTracker({
                    selectors: [ ".template-item" ]
                });
            }) : wx.showToast({
                title: "网络异常稍后重试"
            });
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {
        var e = this;
        console.log("onPullDownRefresh"), this.setData({
            pageNo: 1,
            templateList: []
        }, function() {
            e.requestDataLiast();
        });
    },
    onReachBottom: function() {
        var e = this;
        console.log("onReachBottom"), this.data.hasMore && this.setData({
            pageNo: this.data.pageNo + 1
        }, function() {
            e.requestDataLiast();
        });
    },
    handleTapTemplateItem: function(e) {
        var t = e.currentTarget.dataset.item;
        getApp().recordClick("tixiang_wx.page_stylelist.action.clickstylecover", t), wx.navigateTo({
            url: "/pages/customPose/index?template_id=".concat(t.id, "&template_name=").concat(t.name)
        });
    }
});