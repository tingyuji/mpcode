var e = a(require("../../@babel/runtime/regenerator")), r = require("../../@babel/runtime/helpers/asyncToGenerator"), t = a(require("../../behaviors/pvBehavior"));

function a(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

Page({
    behaviors: [ t.default ],
    data: {
        originUrl: ""
    },
    onLoad: function() {
        var t = this;
        return r(e.default.mark(function r() {
            var a;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.next = 2, getApp().getMtConfig();

                  case 2:
                    a = e.sent, t.setData({
                        originUrl: "".concat(a.privacyProtocolUrl, "?t=").concat(+new Date())
                    });

                  case 4:
                  case "end":
                    return e.stop();
                }
            }, r);
        }))();
    }
});