var e = require("../../@babel/runtime/helpers/toConsumableArray"), t = require("../../@babel/runtime/helpers/objectSpread2"), r = c(require("../../@babel/runtime/regenerator")), a = require("../../@babel/runtime/helpers/asyncToGenerator"), s = c(require("../../behaviors/pvBehavior")), o = c(require("../../behaviors/userInfoBehavior")), n = c(require("../../behaviors/shareBehavior")), i = require("../../utils/alioss"), u = require("../../service/api");

function c(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

Page({
    _genLoading: !1,
    behaviors: [ s.default, o.default, n.default ],
    data: {
        coverUrl: "",
        showPoseList: [],
        template_id: "",
        posture_pic_url: "https://gw.alicdn.com/imgextra/i2/O1CN01Quq5Go1GFBJRfjFS1_!!6000000000592-0-tps-674-894.jpg"
    },
    onLoad: function(e) {
        var t = e.template_id, r = e.template_name;
        this.setData({
            showPoseList: this.data.poseList,
            template_id: t
        }), wx.setNavigationBarTitle({
            title: r
        }), this.init(e), console.log("options", e), this.recordPV({
            spmA: "tixiang_wx",
            spmB: "poselist"
        });
    },
    onShow: function() {},
    init: function(e) {
        var t = this;
        return a(r.default.mark(function a() {
            var s, o;
            return r.default.wrap(function(r) {
                for (;;) switch (r.prev = r.next) {
                  case 0:
                    return r.next = 2, (0, u.getPostureList)({
                        template_id: e.template_id
                    });

                  case 2:
                    s = r.sent, o = s.templateInfoVOS.filter(function(e) {
                        return "posture" === e.subType;
                    }), console.log("姿势postureList", o), t.setData({
                        coverUrl: o[0].pic,
                        posture_pic_url: o[0].pic,
                        showPoseList: o.map(function(e, t) {
                            return 0 === t && (e.selected = !0), e;
                        })
                    });

                  case 6:
                  case "end":
                    return r.stop();
                }
            }, a);
        }))();
    },
    choosePhotos: function() {
        var e, t = this;
        wx.chooseMedia({
            count: 1,
            mediaType: [ "image" ],
            sourceType: [ "album", "camera" ],
            camera: "front",
            success: (e = a(r.default.mark(function e(a) {
                var s, o;
                return r.default.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if ((s = a.tempFiles) && 0 !== s.length) {
                            e.next = 3;
                            break;
                        }
                        return e.abrupt("return");

                      case 3:
                        o = s[0].tempFilePath, t.handleCropImage(o);

                      case 5:
                      case "end":
                        return e.stop();
                    }
                }, e);
            })), function(t) {
                return e.apply(this, arguments);
            })
        });
    },
    handleCropImage: function(s) {
        var o, n = this;
        wx.cropImage({
            src: s,
            cropScale: "3:4",
            success: (o = a(r.default.mark(function a(s) {
                var o, u, c, p, l;
                return r.default.wrap(function(r) {
                    for (;;) switch (r.prev = r.next) {
                      case 0:
                        return o = s.tempFilePath, r.next = 3, (0, i.uploadFilesToOss)([ o ]);

                      case 3:
                        u = r.sent, c = u.successPaths, console.log("alioss", c), p = n.data.showPoseList, 
                        l = p.map(function(e) {
                            return t(t({}, e), {}, {
                                selected: !1
                            });
                        }), n.setData({
                            showPoseList: [ {
                                posture_pic_url: c[0],
                                pic: o,
                                selected: !0
                            } ].concat(e(l)),
                            coverUrl: o,
                            posture_pic_url: c[0]
                        }), n.doGenerate();

                      case 10:
                      case "end":
                        return r.stop();
                    }
                }, a);
            })), function(e) {
                return o.apply(this, arguments);
            }),
            fail: function(e) {
                console.log("crop123fail---", e);
            }
        });
    },
    handleTapCustomUpload: function() {
        getApp().recordClick("tixiang_wx.page_poselist.actions.selfdefined"), this.choosePhotos();
    },
    handleTogglePoseItem: function(e) {
        var t = e.currentTarget.dataset.item;
        this.setData({
            coverUrl: t.pic,
            posture_pic_url: t.posture_pic_url ? t.posture_pic_url : t.pic,
            showPoseList: this.data.showPoseList.map(function(e, r) {
                return e.pic === t.pic ? e.selected = !0 : e.selected = !1, e;
            })
        }), console.log("用户选择的姿势URL地址posture_pic_url::", this.data.posture_pic_url);
    },
    handleTapGenerateBtn: function() {
        var e = this;
        return a(r.default.mark(function t() {
            return r.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    getApp().recordClick("tixiang_wx.page_poselist.actions.generate"), e.doGenerate();

                  case 2:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    },
    doGenerate: function() {
        var e = this;
        return a(r.default.mark(function t() {
            var a, s, o, n, i;
            return r.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (!e._genLoading) {
                        t.next = 2;
                        break;
                    }
                    return t.abrupt("return");

                  case 2:
                    return a = e.data, s = a.template_id, o = a.posture_pic_url, n = {
                        template_id: s,
                        posture_pic_url: o
                    }, e._genLoading = !0, t.next = 7, (0, u.cubeautifulpic)(n).catch(function() {});

                  case 7:
                    i = t.sent, console.log(i, n), e._genLoading = !1, i && wx.navigateTo({
                        url: "/pages/customResult/index?albumId=".concat(i, "&template_id=").concat(s, "&posture_pic_url=").concat(o)
                    });

                  case 11:
                  case "end":
                    return t.stop();
                }
            }, t);
        }))();
    }
});