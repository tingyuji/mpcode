var e = require("../../@babel/runtime/helpers/toConsumableArray"), t = u(require("../../@babel/runtime/regenerator")), a = require("../../@babel/runtime/helpers/asyncToGenerator"), o = u(require("../../behaviors/pvBehavior")), n = u(require("../../behaviors/userInfoBehavior")), r = u(require("../../behaviors/shareBehavior")), s = require("../../service/api"), i = require("../../utils/alioss");

function u(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

Page({
    behaviors: [ o.default, n.default, r.default ],
    data: {
        qualifiedMinNum: 20,
        uploadedPhotos: new Array(20).fill(""),
        uploadedPhotoList: [],
        initialUploadedPhotoList: [],
        uploadedFilteredPhotoList: [],
        showUploadedPhotoList: [],
        hasChanged: !1,
        isShowHalfScreen: !1,
        changeEditStatus: !0,
        pageData: {},
        ossPhotoUrls: [],
        del_pic_ids: []
    },
    onLoad: function(e) {
        this.recordPV({
            spmA: "tixiang_wx",
            spmB: "imgupdate"
        }), this.init(e);
    },
    init: function(e) {
        var o = this;
        return a(t.default.mark(function a() {
            var n;
            return t.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.next = 2, (0, s.checkMvpState)({
                        task_id: Number(e.task_id)
                    });

                  case 2:
                    n = t.sent, console.log("picInfos", n.picInfos), o.setData({
                        pageData: n,
                        initialUploadedPhotoList: n.picInfos,
                        uploadedPhotoList: n.picInfos,
                        taskId: Number(e.task_id)
                    }), o.setShowUploadedPhotoList();

                  case 6:
                  case "end":
                    return t.stop();
                }
            }, a);
        }))();
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    handleContinueToAdjust: function(e) {
        this.setData({
            changeEditStatus: !0
        });
    },
    handleSubmitImages: function() {
        var e = this;
        return a(t.default.mark(function a() {
            var o, n, r, s;
            return t.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (o = e.data, n = o.ossPhotoUrls, r = o.uploadedPhotoList, s = o.hasChanged, !(r.length < 20)) {
                        t.next = 4;
                        break;
                    }
                    return wx.showToast({
                        title: "照片已不足20张",
                        icon: "error"
                    }), t.abrupt("return");

                  case 4:
                    if (s) {
                        t.next = 6;
                        break;
                    }
                    return t.abrupt("return");

                  case 6:
                    return t.next = 8, e.recognisePhotos(n, !1);

                  case 8:
                    t.sent && wx.redirectTo({
                        url: "/pages/generate/index"
                    });

                  case 10:
                  case "end":
                    return t.stop();
                }
            }, a);
        }))();
    },
    handleRemoveTap: function(e) {
        var o = this;
        return a(t.default.mark(function a() {
            var n, r, s, i, u;
            return t.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    n = e.currentTarget.dataset.item, r = o.data, s = r.uploadedPhotoList, i = r.del_pic_ids, 
                    r.initialUploadedPhotoList, i.push(n.id), console.log("删除id", n.id, i), u = s.filter(function(e) {
                        return e.id !== n.id;
                    }), o.setData({
                        uploadedPhotoList: u,
                        hasChanged: !0,
                        del_pic_ids: i
                    }), o.setShowUploadedPhotoList();

                  case 7:
                  case "end":
                    return t.stop();
                }
            }, a);
        }))();
    },
    handleTapCustomUpload: function() {
        getApp().recordClick("tixiang_wx.page_imgupdate.action.uploadbtn"), this.choosePhotos();
    },
    choosePhotos: function() {
        var o, n = this;
        wx.chooseMedia({
            count: 20,
            mediaType: [ "image" ],
            sourceType: [ "album", "camera" ],
            camera: "front",
            success: (o = a(t.default.mark(function a(o) {
                var r, s, i;
                return t.default.wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return r = o.tempFiles, s = r.map(function(e) {
                            return e.tempFilePath;
                        }), t.next = 4, n.uploadPhotos(s);

                      case 4:
                        i = t.sent, console.log("photos res: ", o, s), n.setData({
                            uploadedPhotoList: [].concat(e(n.data.uploadedPhotoList), e(s.map(function(e, t) {
                                return {
                                    id: t,
                                    picUrl: e
                                };
                            }))),
                            hasChanged: !0,
                            ossPhotoUrls: i
                        }), n.setShowUploadedPhotoList();

                      case 8:
                      case "end":
                        return t.stop();
                    }
                }, a);
            })), function(e) {
                return o.apply(this, arguments);
            })
        });
    },
    setShowUploadedPhotoList: function() {
        var t = this.data, a = t.uploadedPhotoList, o = t.del_pic_ids, n = a;
        if (o.length > 0 && (n = a.filter(function(e) {
            return o.indexOf(e.id) < 0;
        })), this.setData({
            uploadedFilteredPhotoList: n
        }), n.length >= 20 && n.length % 5 == 0) this.setData({
            showUploadedPhotoList: n
        }); else {
            var r = n.length >= 20 ? 5 - n.length % 5 : 20 - n.length;
            this.setData({
                showUploadedPhotoList: [].concat(e(n), e(new Array(r).fill({})))
            });
        }
    },
    uploadPhotos: function(e) {
        return a(t.default.mark(function a() {
            var o, n, r;
            return t.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return wx.showLoading({
                        title: "上传中"
                    }), t.next = 3, (0, i.uploadFilesToOss)(e);

                  case 3:
                    if (o = t.sent, n = o.successPaths, r = o.errorPaths, wx.hideLoading(), !(r && (null == r ? void 0 : r.length) > 0)) {
                        t.next = 10;
                        break;
                    }
                    return wx.showToast({
                        icon: "error",
                        title: "上传失败"
                    }), t.abrupt("return", Promise.resolve([]));

                  case 10:
                    return wx.showToast({
                        icon: "success",
                        title: "上传成功"
                    }), t.abrupt("return", n);

                  case 12:
                  case "end":
                    return t.stop();
                }
            }, a);
        }))();
    },
    recognisePhotos: function(e, o) {
        var n = this;
        return a(t.default.mark(function a() {
            var o, r, i, u;
            return t.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return o = n.data, r = o.taskId, i = o.del_pic_ids, t.next = 3, (0, s.upMultiViewPic)({
                        task_id: r,
                        pic_list: JSON.stringify(e),
                        del_pic_ids: JSON.stringify(i),
                        type: "adjust"
                    });

                  case 3:
                    if (u = t.sent, console.log(u, "append", e), u) {
                        t.next = 10;
                        break;
                    }
                    return wx.showToast({
                        icon: "error",
                        title: "识别失败"
                    }), t.abrupt("return");

                  case 10:
                    return t.abrupt("return", u);

                  case 11:
                  case "end":
                    return t.stop();
                }
            }, a);
        }))();
    },
    handleResetSeedModal: function() {
        this.setData({
            isShowHalfScreen: !0
        });
    },
    handleCancelReset: function() {
        this.setData({
            isShowHalfScreen: !1
        });
    },
    handleResetSeedImage: function() {
        var e = this;
        return a(t.default.mark(function a() {
            var o;
            return t.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.next = 2, (0, s.resetappearance)({
                        task_id: e.data.taskId
                    });

                  case 2:
                    o = t.sent, console.log("重置形象", o), o && wx.redirectTo({
                        url: "/pages/generate/index"
                    });

                  case 5:
                  case "end":
                    return t.stop();
                }
            }, a);
        }))();
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {}
});