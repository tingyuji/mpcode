var e = require("../../@babel/runtime/helpers/toConsumableArray"), t = s(require("../../@babel/runtime/regenerator")), a = require("../../@babel/runtime/helpers/asyncToGenerator"), r = s(require("../../behaviors/pvBehavior")), n = s(require("../../behaviors/userInfoBehavior")), o = s(require("../../behaviors/shareBehavior")), i = require("../../service/api");

function s(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

Page({
    behaviors: [ r.default, n.default, o.default ],
    data: {
        coinBalance: "",
        hasMore: !1,
        historyList: [],
        pageNum: 1,
        nextPageNum: 1,
        showChargeDialog: !1,
        platform: "",
        mtConfig: {},
        appGuideChargeContents: []
    },
    onLoad: function() {
        var e = this;
        return a(t.default.mark(function a() {
            var r, n, o;
            return t.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return e.recordPV({
                        spmA: "tixiang_wx",
                        spmB: "diamondscenter"
                    }), e.setData({
                        platform: getApp().globalData.platform
                    }), t.next = 4, getApp().getFreshMtConfig();

                  case 4:
                    return n = t.sent, o = null == n || null === (r = n.appGuideChargeContent) || void 0 === r ? void 0 : r.split("\\n"), 
                    e.setData({
                        mtConfig: n,
                        appGuideChargeContents: o
                    }), t.t0 = e, t.next = 10, getApp().getFreshMtConfig();

                  case 10:
                    t.t1 = t.sent, t.t2 = {
                        mtConfig: t.t1
                    }, t.t0.setData.call(t.t0, t.t2), e.loadData(!0);

                  case 14:
                  case "end":
                    return t.stop();
                }
            }, a);
        }))();
    },
    onReady: function() {},
    onShow: function() {
        this.loadData(!0);
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {
        var e = this;
        return a(t.default.mark(function a() {
            return t.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.next = 2, e.loadData(!0);

                  case 2:
                    wx.stopPullDownRefresh();

                  case 3:
                  case "end":
                    return t.stop();
                }
            }, a);
        }))();
    },
    onReachBottom: function() {
        console.log("page reachbottom");
        var e = this.data.historyList;
        (null == e ? void 0 : e.length) > 1 && this.loadData(!1);
    },
    loadData: function() {
        var r = arguments, n = this;
        return a(t.default.mark(function a() {
            var o, s, u, l, c, h, f, p, d;
            return t.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if ((o = r.length > 0 && void 0 !== r[0] && r[0]) && n.setData({
                        nextPageNum: 1
                    }), s = n.data, u = s.historyList, l = s.nextPageNum, c = s.hasMore, o || c) {
                        t.next = 5;
                        break;
                    }
                    return t.abrupt("return");

                  case 5:
                    return t.next = 7, (0, i.queryCoinHistory)({
                        pageNum: l,
                        pageSize: 20
                    });

                  case 7:
                    h = t.sent, f = h.balance, p = h.hasMore, d = h.list, n.setData({
                        coinBalance: f,
                        hasMore: p,
                        historyList: o ? d : [].concat(e(u), e(d || [])),
                        nextPageNum: l + 1
                    });

                  case 10:
                  case "end":
                    return t.stop();
                }
            }, a);
        }))();
    },
    handleChargeTap: function() {
        getApp().recordClick("page_diamondscenter.action.topupbtn"), "ios" === getApp().globalData.platform ? wx.navigateTo({
            url: "/pages/payByWxOfficialAccount/index"
        }) : this.setData({
            showChargeDialog: !0
        });
    },
    handleCloseChargeDialog: function() {
        this.setData({
            showChargeDialog: !1
        });
    },
    handleChargeSuccess: function() {
        var e = this;
        return a(t.default.mark(function a() {
            return t.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return e.setData({
                        showChargeDialog: !1
                    }), t.next = 3, e.loadData(!0);

                  case 3:
                  case "end":
                    return t.stop();
                }
            }, a);
        }))();
    }
});