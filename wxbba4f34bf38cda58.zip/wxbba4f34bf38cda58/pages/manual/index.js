Page({
    data: {
        platform: ""
    },
    onLoad: function() {
        this.setData({
            platform: getApp().globalData.platform
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});