var e = u(require("../../@babel/runtime/regenerator")), r = require("../../@babel/runtime/helpers/slicedToArray"), t = require("../../@babel/runtime/helpers/asyncToGenerator"), a = u(require("../../behaviors/pvBehavior")), n = u(require("../../behaviors/shareBehavior")), i = require("../../service/api");

function u(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

Page({
    behaviors: [ a.default, n.default ],
    data: {
        curTemplate: {},
        shareImgUrl: "/image/img-placeholder.png",
        inviterId: ""
    },
    onLoad: function(a) {
        var n = this;
        return t(e.default.mark(function t() {
            var i, u, o, s, l, c, d;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (u = a.scene) {
                        e.next = 3;
                        break;
                    }
                    return e.abrupt("return");

                  case 3:
                    o = (null === (i = decodeURIComponent(decodeURIComponent(u))) || void 0 === i ? void 0 : i.split("_")) || [], 
                    s = r(o, 3), l = s[0], c = s[1], d = s[2], console.log("inviterId, albumId, albumPicId: ", l, c, d), 
                    l && n.setData({
                        inviterId: l
                    }), n.getUserCoverUrl(l, c, d);

                  case 7:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    getUserCoverUrl: function(r, a, n) {
        var u = this;
        return t(e.default.mark(function t() {
            var o, s, l;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (r && a && n) {
                        e.next = 2;
                        break;
                    }
                    return e.abrupt("return");

                  case 2:
                    return s = {
                        invite_user_id: r,
                        album_id: a,
                        album_pic_id: n,
                        cover: !0
                    }, e.next = 5, (0, i.getAlbumPic)(s);

                  case 5:
                    l = e.sent, u.setData({
                        shareImgUrl: null == l || null === (o = l.photoVOList[0]) || void 0 === o ? void 0 : o.url
                    });

                  case 7:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    handleTapGenerateBtn: function() {
        var e = this.data.inviterId;
        wx.reLaunch({
            url: "/pages/index/index?inviter_uid=".concat(e)
        });
    },
    onShow: function() {}
});