function e(e, n, t) {
    return n in e ? Object.defineProperty(e, n, {
        value: t,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[n] = t, e;
}

function n(e, n) {
    if (!(e instanceof n)) throw new TypeError("Cannot call a class as a function");
}

function t(e, n) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !n || "object" != typeof n && "function" != typeof n ? e : n;
}

function r(e, n) {
    if ("function" != typeof n && null !== n) throw new TypeError("Super expression must either be null or a function, not " + typeof n);
    e.prototype = Object.create(n && n.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), n && (Object.setPrototypeOf ? Object.setPrototypeOf(e, n) : e.__proto__ = n);
}

function o(e, n) {
    return u(e) || a(e, n) || c(e, n) || i();
}

function i() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}

function a(e, n) {
    var t = null == e ? null : "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
    if (null != t) {
        var r, o, i = [], a = !0, u = !1;
        try {
            for (t = t.call(e); !(a = (r = t.next()).done) && (i.push(r.value), !n || i.length !== n); a = !0) ;
        } catch (e) {
            u = !0, o = e;
        } finally {
            try {
                a || null == t.return || t.return();
            } finally {
                if (u) throw o;
            }
        }
        return i;
    }
}

function u(e) {
    if (Array.isArray(e)) return e;
}

function s(e, n) {
    var t = "undefined" != typeof Symbol && e[Symbol.iterator] || e["@@iterator"];
    if (t) return (t = t.call(e)).next.bind(t);
    if (Array.isArray(e) || (t = c(e)) || n && e && "number" == typeof e.length) {
        t && (e = t);
        var r = 0;
        return function() {
            return r >= e.length ? {
                done: !0
            } : {
                done: !1,
                value: e[r++]
            };
        };
    }
    throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}

function c(e, n) {
    if (e) {
        if ("string" == typeof e) return l(e, n);
        var t = Object.prototype.toString.call(e).slice(8, -1);
        return "Object" === t && e.constructor && (t = e.constructor.name), "Map" === t || "Set" === t ? Array.from(e) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? l(e, n) : void 0;
    }
}

function l(e, n) {
    (null == n || n > e.length) && (n = e.length);
    for (var t = 0, r = new Array(n); t < n; t++) r[t] = e[t];
    return r;
}

var f = function() {
    function e(e, n) {
        for (var t = 0; t < n.length; t++) {
            var r = n[t];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), 
            Object.defineProperty(e, r.key, r);
        }
    }
    return function(n, t, r) {
        return t && e(n.prototype, t), r && e(n, r), n;
    };
}(), p = require("../../npm/regenerator-runtime/runtime.js"), d = require("../../npm/@mtfe/weapp-privacy-api/index.js").default;

!function(e, n) {
    for (var t in n) e[t] = n[t];
    n.__esModule && Object.defineProperty(e, "__esModule", {
        value: !0
    });
}(exports, function() {
    function i(e) {
        if (u[e]) return u[e].exports;
        var n = u[e] = {
            exports: {}
        };
        return a[e](n, n.exports, i), n.exports;
    }
    var a = {
        948: function(i, a, u) {
            function c() {}
            function l(e) {
                return null != e.error;
            }
            function g(e) {
                return (null === e || void 0 === e ? void 0 : e.openid) && (null === e || void 0 === e ? void 0 : e.unionid) && (null === e || void 0 === e ? void 0 : e.openidCipher);
            }
            function b(e) {
                var n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 5e3;
                return p.async(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return t.prev = 0, t.next = 3, p.awrap(mn(e, Object.assign({}, n <= 0 ? {} : {
                            timeout: n
                        })));

                      case 3:
                        return On(!0), t.abrupt("return", !0);

                      case 7:
                        if (t.prev = 7, t.t0 = t.catch(0), !(t.t0 instanceof N && 401 === t.t0.code)) {
                            t.next = 12;
                            break;
                        }
                        return On(!0), t.abrupt("return", !1);

                      case 12:
                        return t.abrupt("return", null);

                      case 13:
                      case "end":
                        return t.stop();
                    }
                }, null, null, [ [ 0, 7 ] ], Promise);
            }
            function h(e) {
                var n, t = e.username, r = e.mobile, o = e.avatar;
                return p.async(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return n = new Promise(function(e, n) {
                            Qn = e, Zn = n;
                        }), e.next = 3, p.awrap(me(K.phoneRoute + "?" + (0, C.stringify)({
                            name: t,
                            mobile: r,
                            avatar: o
                        })));

                      case 3:
                        return e.abrupt("return", n);

                      case 4:
                      case "end":
                        return e.stop();
                    }
                }, null, null, null, Promise);
            }
            function v(e) {
                var n, t, r, o, i, a, u = e.requestCode;
                return p.async(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return n = "" + K.waitYodaRoute, t = "" + K.waitYodaRoute, r = new Promise(function(e, n) {
                            tt = e, rt = n;
                        }), o = Ce() || "prod", i = getApp().globalData, i.YodaSuccess = n, i.YodaFail = t, 
                        e.next = 9, p.awrap(De());

                      case 9:
                        return a = e.sent, e.next = 12, p.awrap(me(K.smsVerifyRoute + "?requestCode=" + u + "&env=" + o + "&appletsfp=" + a));

                      case 12:
                        return e.abrupt("return", r);

                      case 13:
                      case "end":
                        return e.stop();
                    }
                }, null, null, null, Promise);
            }
            function w(e) {
                var n;
                return p.async(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return n = new Promise(function(e, n) {
                            at = e, ut = n;
                        }), t.next = 3, p.awrap(me(K.yodaRoute + "?" + (0, C.stringify)({
                            reqCode: e
                        })));

                      case 3:
                        return t.abrupt("return", n);

                      case 4:
                      case "end":
                        return t.stop();
                    }
                }, null, null, null, Promise);
            }
            function y(e) {
                var n = e.mobile, t = F.version_name, r = F.risk_app, o = F.risk_partner, i = F.risk_platform, a = d.getSystemInfoSync().platform, u = F.appId, s = a.toLowerCase();
                return gn().then(function(e) {
                    var a = e.openId, c = e.unionId;
                    return Object.assign(Object.assign({
                        openid: a,
                        unionid: c,
                        loginSdkVersion: "3.13.0",
                        toMiniUrl: K.activateOkRoute,
                        countrycode: 86
                    }, n && {
                        content: "{params:{username:'" + n + "'}}"
                    }), {
                        appid: u,
                        utm_medium: s,
                        isApp: !1,
                        version_name: t,
                        risk_app: r,
                        risk_partner: o,
                        risk_platform: i
                    });
                });
            }
            function m(e) {
                var n = e.mobile, t = e.noCfrm, r = void 0 !== t && t;
                return Promise.resolve(!r && be("由于您的账号存在异常操作，为确保账号安全，已将账号锁定", {
                    showCancel: !0,
                    cancelText: "取消",
                    confirmText: "去解锁"
                }).then(function(e) {
                    return !e && Promise.reject(new A("用户选择取消账号解锁/解冻", void 0, 5124));
                })).then(function() {
                    return y({
                        mobile: n
                    });
                }).then(function(e) {
                    return new Promise(function(n, t) {
                        yt = n, mt = t, me(K.activateRoute + "?" + (0, C.stringify)(Object.assign({}, e))).catch(t);
                    });
                });
            }
            function x(e) {
                return (null === e || void 0 === e ? void 0 : e.openid) && (null === e || void 0 === e ? void 0 : e.openidCipher) && (null === e || void 0 === e ? void 0 : e.unionid);
            }
            function k() {
                var e, n;
                return p.async(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return t.next = 2, p.awrap(vn());

                      case 2:
                        if (e = t.sent, !x(e)) {
                            t.next = 9;
                            break;
                        }
                        if (n = Date.now(), !F.wxInfoKey) {
                            t.next = 8;
                            break;
                        }
                        return t.next = 8, p.awrap(pe(F.wxInfoKey, Object.assign(Object.assign({}, e), {
                            fetchTime: n
                        })).catch(c));

                      case 8:
                        return t.abrupt("return", Object.assign(Object.assign({}, e), {
                            fetchTime: n
                        }));

                      case 9:
                        throw new A("getWxAppData返回的数据格式不对: " + JSON.stringify(e), void 0, 124);

                      case 10:
                      case "end":
                        return t.stop();
                    }
                }, null, null, null, Promise);
            }
            function O(e) {
                var n, t;
                return p.async(function(r) {
                    for (;;) switch (r.prev = r.next) {
                      case 0:
                        return r.next = 2, p.awrap(mn(e));

                      case 2:
                        if (n = r.sent, !I(n)) {
                            r.next = 9;
                            break;
                        }
                        if (t = Date.now(), !F.mtInfoKey) {
                            r.next = 8;
                            break;
                        }
                        return r.next = 8, p.awrap(pe(F.mtInfoKey, Object.assign(Object.assign({}, n), {
                            fetchTime: t
                        })).catch(c));

                      case 8:
                        return r.abrupt("return", Object.assign(Object.assign({}, n), {
                            fetchTime: t
                        }));

                      case 9:
                        throw new A("getMtUserInfo返回的数据格式不对: " + JSON.stringify(n), void 0, 116);

                      case 10:
                      case "end":
                        return r.stop();
                    }
                }, null, null, null, Promise);
            }
            function I(e) {
                return (null === e || void 0 === e ? void 0 : e.username) && (null === e || void 0 === e ? void 0 : e.id);
            }
            u.r(a), u.d(a, {
                API_TYPE: function() {
                    return W;
                },
                CardComponent: function() {
                    return Yn;
                },
                EntryPage: function() {
                    return Vn;
                },
                SDKError: function() {
                    return A;
                },
                SessionEvent: function() {
                    return We;
                },
                SessionState: function() {
                    return Ee;
                },
                WxAPIError: function() {
                    return R;
                },
                WxRequestError: function() {
                    return L;
                },
                _internal_API_TYPE: function() {
                    return W;
                },
                _internal_MtAPIError: function() {
                    return N;
                },
                _internal_SDKError: function() {
                    return A;
                },
                _internal_SessionEvent: function() {
                    return We;
                },
                _internal__getAuthInfo: function() {
                    return jn;
                },
                _internal_actGetRej: function() {
                    return kt;
                },
                _internal_actGetRes: function() {
                    return xt;
                },
                _internal_activate: function() {
                    return m;
                },
                _internal_appConfig: function() {
                    return F;
                },
                _internal_authState: function() {
                    return Xe;
                },
                _internal_bindPageOption: function() {
                    return $;
                },
                _internal_changeBindPageOption: function() {
                    return X;
                },
                _internal_changeBindPhoneState: function() {
                    return Ge;
                },
                _internal_checkSession: function() {
                    return ve;
                },
                _internal_clearVerifyState: function() {
                    return He;
                },
                _internal_composedErrorHandler: function() {
                    return Pn;
                },
                _internal_customLoginCheck: function() {
                    return Un;
                },
                _internal_destroySession: function() {
                    return ze;
                },
                _internal_getCfrmPageRej: function() {
                    return nt;
                },
                _internal_getCfrmPageRes: function() {
                    return et;
                },
                _internal_getEnv: function() {
                    return Ce;
                },
                _internal_getExtInfo: function() {
                    return Ft;
                },
                _internal_getFinger: function() {
                    return De;
                },
                _internal_getLoginCode: function() {
                    return le;
                },
                _internal_getNewCode: function() {
                    return qt;
                },
                _internal_getPageData: function() {
                    return Dt;
                },
                _internal_getStorage: function() {
                    return fe;
                },
                _internal_getUUID: function() {
                    return Ue;
                },
                _internal_getVerifyInfo: function() {
                    return Kt;
                },
                _internal_getWaitYodaRej: function() {
                    return it;
                },
                _internal_getWaitYodaRes: function() {
                    return ot;
                },
                _internal_gotoPhoneConfirm: function() {
                    return h;
                },
                _internal_mobileLogin: function() {
                    return Wn;
                },
                _internal_mobileLoginApply: function() {
                    return bn;
                },
                _internal_mobileLoginV3: function() {
                    return hn;
                },
                _internal_navBack: function() {
                    return ge;
                },
                _internal_navBackAll: function() {
                    return Nn;
                },
                _internal_navigate: function() {
                    return me;
                },
                _internal_onPageErr: function() {
                    return Ln;
                },
                _internal_parse: function() {
                    return Mt.parse;
                },
                _internal_processProtocolConfig: function() {
                    return Dn;
                },
                _internal_protocolConfig: function() {
                    return ie;
                },
                _internal_routeConfig: function() {
                    return K;
                },
                _internal_saveAuthInfoAndGoBack: function() {
                    return An;
                },
                _internal_setAuthInfo: function() {
                    return Cn;
                },
                _internal_showTip: function() {
                    return be;
                },
                _internal_showToast: function() {
                    return he;
                },
                _internal_smartCheck: function() {
                    return Wt;
                },
                _internal_stringify: function() {
                    return C.stringify;
                },
                _internal_ticketLogin: function() {
                    return rn;
                },
                _internal_tips: function() {
                    return te;
                },
                _internal_verifyNewPhone: function() {
                    return Vt;
                },
                _internal_verifyState: function() {
                    return Je;
                },
                _internal_verifylogin: function() {
                    return tn;
                },
                _internal_version: function() {
                    return Oe;
                },
                _internal_wxMobileBindApplyV2: function() {
                    return cn;
                },
                _internal_wxMobileBindLoginV2: function() {
                    return ln;
                },
                _internal_wxTicketLoginV2: function() {
                    return fn;
                },
                _internal_yodaVfyRej: function() {
                    return ct;
                },
                _internal_yodaVfyRes: function() {
                    return st;
                },
                activate: function() {
                    return m;
                },
                authInfoIsChecked: function() {
                    return In;
                },
                authState: function() {
                    return Xe;
                },
                changeBindPhone: function() {
                    return dt;
                },
                cleanLogin: function() {
                    return $n;
                },
                cleanLoginSP: function() {
                    return wt;
                },
                config: function() {
                    return D;
                },
                destroySession: function() {
                    return ze;
                },
                getAuthInfo: function() {
                    return Tn;
                },
                getAuthInfoSync: function() {
                    return Sn;
                },
                getEnv: function() {
                    return Ce;
                },
                getMtInfo: function() {
                    return Ut;
                },
                getMtInfoSync: function() {
                    return At;
                },
                getRej: function() {
                    return kt;
                },
                getRes: function() {
                    return xt;
                },
                getSdkEnv: function() {
                    return _e;
                },
                getWxIds: function() {
                    return gn;
                },
                getWxIdsSync: function() {
                    return dn;
                },
                getWxInfo: function() {
                    return Rt;
                },
                getWxInfoSync: function() {
                    return Et;
                },
                getWxUserInfo: function() {
                    return Ht;
                },
                isLogout: function() {
                    return bt;
                },
                login: function() {
                    return zn;
                },
                loginSP: function() {
                    return vt;
                },
                logout: function() {
                    return gt;
                },
                mobileLogin: function() {
                    return Wn;
                },
                removeAuthInfo: function() {
                    return En;
                },
                routeConfig: function() {
                    return K;
                },
                setAppConfig: function() {
                    return J;
                },
                setAuthRoute: function() {
                    return q;
                },
                setAuthrizePageOption: function() {
                    return ee;
                },
                setBindPageOption: function() {
                    return Q;
                },
                setChangeBindPageOption: function() {
                    return z;
                },
                setEnv: function() {
                    return Pe;
                },
                setLoginCheck: function() {
                    return ne;
                },
                setLoginPageOption: function() {
                    return Y;
                },
                setSdkRoute: function() {
                    return G;
                },
                setYodaRoute: function() {
                    return V;
                },
                unlockAccount: function() {
                    return ht;
                },
                updateMtInfo: function() {
                    return Bt;
                },
                updateWxInfo: function() {
                    return Lt;
                },
                updateWxUserInfo: function() {
                    return Gt;
                },
                utils: function() {
                    return Fn;
                },
                version: function() {
                    return Oe;
                },
                webViewPage: function() {
                    return Ot;
                },
                wxLogin: function() {
                    return pt;
                },
                wxMobileLogin: function() {
                    return lt;
                },
                yodaConfig: function() {
                    return _;
                }
            });
            var _ = {};
            u.r(_), u.d(_, {
                baseUrl: function() {
                    return _t;
                },
                getInfoUrl: function() {
                    return St;
                },
                getPageDataUrl: function() {
                    return Ct;
                },
                getVerifyUrl: function() {
                    return jt;
                },
                getYodaBaseUrl: function() {
                    return Pt;
                }
            }), u(778);
            var P, C = require("../../npm/@mtfe/mt-weapp-url/stringify.js");
            !function(e) {
                e.WXAPIError = "WXAPIError", e.WXRequestError = "WXRequestError", e.MTAPIError = "MTAPIError", 
                e.SDKError = "SDKError", e.UnExpected = "Unexpected";
            }(P || (P = {}));
            var S = function(e) {
                return e.errType === P.WXAPIError;
            }, j = function(e) {
                return e.errType === P.WXRequestError;
            }, T = function(e) {
                return e.errType === P.MTAPIError;
            }, E = function(e) {
                return e.errType === P.SDKError;
            }, R = function(e) {
                function o(e, r) {
                    n(this, o);
                    var i = "Wechat API " + e + " get error result: [msg]: " + r, a = t(this, (o.__proto__ || Object.getPrototypeOf(o)).call(this, i));
                    return a.errType = P.WXAPIError, a.api = e, a.desc = i, a.msg = "内部错误，请重试", Object.setPrototypeOf(a, o.prototype), 
                    a;
                }
                return r(o, Error), o;
            }(), L = function(e) {
                function o(e, r) {
                    n(this, o);
                    var i = "Request " + r + " failed: " + e, a = t(this, (o.__proto__ || Object.getPrototypeOf(o)).call(this, i));
                    return a.errType = P.WXRequestError, a.desc = i, a.msg = "网络故障，请稍后再试", Object.setPrototypeOf(a, o.prototype), 
                    a;
                }
                return r(o, Error), o;
            }(), N = function(e) {
                function o(e) {
                    var r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {
                        code: -2,
                        message: "未知错误"
                    }, i = arguments[2];
                    n(this, o);
                    var a = r.code, u = r.message, s = "API " + e + " return code: " + a + " with message: " + u, c = t(this, (o.__proto__ || Object.getPrototypeOf(o)).call(this, s));
                    return c.code = a, c.errType = P.MTAPIError, c.desc = s, c.tip = u, c.msg = u || "服务器出错，请稍后重试", 
                    c.trace = i, Object.setPrototypeOf(c, o.prototype), c;
                }
                return r(o, Error), o;
            }(), A = function(e) {
                function o(e, r, i) {
                    var a = arguments.length > 3 && void 0 !== arguments[3] && arguments[3];
                    n(this, o);
                    var u = "登陆无法完成: " + e, s = t(this, (o.__proto__ || Object.getPrototypeOf(o)).call(this, u));
                    return s.errType = P.SDKError, s.desc = u, s.tip = e, s.trace = r, s.errCode = i, 
                    s.show = a, Object.setPrototypeOf(s, o.prototype), s;
                }
                return r(o, Error), o;
            }(), U = u(769), B = u.n(U)() || {}, D = B, F = D.appConfig, K = {
                loginRoute: "",
                waitYodaRoute: "",
                bindRoute: "",
                smsVerifyRoute: "",
                authRoute: "",
                changeBindPhoneRoute: "",
                webviewRoute: "",
                phoneRoute: "",
                activateRoute: "",
                activateOkRoute: "",
                yodaRoute: "",
                _route: "",
                set sdkRoute(e) {
                    this._route = e, this.loginRoute = e + "/entry/index", this.bindRoute = e + "/bind/index", 
                    this.changeBindPhoneRoute = e + "/change-bind-phone/index", this.webviewRoute = e + "/webview/index", 
                    this.yodaRoute = e + "/yoda-verify/index", this.phoneRoute = e + "/confirm-phone/index", 
                    this.waitYodaRoute = e + "/wait-yoda/index", this.activateRoute = e + "/activate/index", 
                    this.activateOkRoute = e + "/activate-ok/index";
                },
                get sdkRoute() {
                    return this._route;
                }
            };
            K.sdkRoute = D.route, K.authRoute = D.authRoute;
            var M, W, q = function(e) {
                K.authRoute = e;
            }, V = function(e) {
                K.smsVerifyRoute = e;
            }, J = function(e) {
                Object.assign(F, e);
            }, G = function(e) {
                e.startsWith("/") || (e = "/" + e), K.sdkRoute = e;
            }, H = D.entryPageOption, Y = function(e) {
                Object.assign(H, e);
            }, X = D.changeBindPageOption, z = function(e) {
                Object.assign(X, e);
            }, $ = D.bindPageOption, Q = function(e) {
                Object.assign($, e);
            }, Z = D.authrizePageOption, ee = function(e) {
                Object.assign(Z, e);
            }, ne = function(e) {
                M = e;
            }, te = D.tips, re = D.showModal;
            !function(e) {
                e.WX_MOBILE = "wxMobileLogin", e.WXV2 = "wxLogin", e.MOBILE = "mobileLogin", e.LOGIN = "login", 
                e.CHANGE_BIND = "changeBind";
            }(W || (W = {}));
            var oe;
            !function(e) {
                e.create = "createSession";
            }(oe || (oe = {}));
            var ie = D.protocolConfig, ae = function(e, n) {
                var t = {};
                for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && n.indexOf(r) < 0 && (t[r] = e[r]);
                if (null != e && "function" == typeof Object.getOwnPropertySymbols) for (var o = 0, r = Object.getOwnPropertySymbols(e); o < r.length; o++) n.indexOf(r[o]) < 0 && Object.prototype.propertyIsEnumerable.call(e, r[o]) && (t[r[o]] = e[r[o]]);
                return t;
            }, ue = function(e) {
                var n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                return new Promise(function(t, r) {
                    var o = n.header, i = void 0 === o ? {} : o, a = n.query, u = void 0 === a ? {} : a, c = n.type, l = (n.success, 
                    n.fail, n.complete, ae(n, [ "header", "query", "type", "success", "fail", "complete" ]));
                    "form" === c && (i["content-type"] = "application/x-www-form-urlencoded");
                    var f = void 0;
                    if (u) {
                        f = {};
                        for (var p, g = s(Object.getOwnPropertyNames(u)); !(p = g()).done; ) {
                            var b = p.value;
                            null != u[b] && (f[b] = u[b]);
                        }
                    }
                    f && (e += (e.includes("?") ? "&" : "?") + (0, C.stringify)(f));
                    var h = Object.assign({
                        url: e,
                        header: i,
                        unforced: !0,
                        success: function(n) {
                            n && n.data ? t(n.data) : r(new L("No data in response: " + JSON.stringify(n), e));
                        },
                        fail: function(n) {
                            r(new L("fail to request: " + JSON.stringify(n), e));
                        }
                    }, l), v = F.wxReq || d.request;
                    F.finger ? F.finger.then(function(e) {
                        v(e.sign(h));
                    }) : v(h);
                });
            }, se = function() {
                return new Promise(function(e, n) {
                    d.login({
                        success: function(t) {
                            t && t.code ? e(t.code) : n(new R("wx.login", "null login result: " + JSON.stringify(t)));
                        },
                        fail: function(e) {
                            n(new R("wx.login", JSON.stringify(e)));
                        }
                    });
                });
            }, ce = void 0, le = function(e) {
                return p.async(function(n) {
                    for (;;) switch (n.prev = n.next) {
                      case 0:
                        if (null != e) {
                            n.next = 5;
                            break;
                        }
                        return console.log("loginSDK: new loginCode requested!!"), n.next = 4, p.awrap(se());

                      case 4:
                        return n.abrupt("return", ce = n.sent);

                      case 5:
                        return n.abrupt("return", ce = e);

                      case 6:
                      case "end":
                        return n.stop();
                    }
                }, null, null, null, Promise);
            }, fe = function(e) {
                return new Promise(function(n, t) {
                    d.getStorage({
                        key: e,
                        success: function(e) {
                            e && e.data ? n(e.data) : t(new R("getStorage", "null result: " + JSON.stringify(e)));
                        },
                        fail: function(e) {
                            t(new R("getStorage", JSON.stringify(e)));
                        }
                    });
                });
            }, pe = function(e, n) {
                return new Promise(function(t, r) {
                    d.setStorage({
                        key: e,
                        data: n,
                        success: function() {
                            t();
                        },
                        fail: function(e) {
                            r(new R("setStorage", JSON.stringify(e)));
                        }
                    });
                });
            }, de = function(e) {
                return new Promise(function(n, t) {
                    d.removeStorage({
                        key: e,
                        success: function() {
                            n();
                        },
                        fail: function(e) {
                            t(new R("removeStorage", JSON.stringify(e)));
                        }
                    });
                });
            }, ge = function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1;
                return new Promise(function(n) {
                    d.navigateBack({
                        delta: e,
                        success: function() {
                            n();
                        },
                        fail: function(e) {
                            console.error("wx.navigateBack失败: " + JSON.stringify(e)), n();
                        }
                    });
                });
            }, be = function(e) {
                var n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, t = n.title, r = void 0 === t ? "提示" : t, o = n.showCancel, i = void 0 !== o && o, a = n.cancelText, u = void 0 === a ? "取消" : a, s = n.confirmText, c = void 0 === s ? re.confirmText || "确定" : s;
                return new Promise(function(n, t) {
                    d.showModal(Object.assign(Object.assign({
                        title: r,
                        content: e || "",
                        showCancel: i
                    }, i && {
                        cancelText: u
                    }), {
                        confirmText: c,
                        success: function(e) {
                            n(!i || e && e.confirm);
                        },
                        fail: function(e) {
                            t(new R("wx.showModal", JSON.stringify(e)));
                        }
                    }));
                });
            }, he = function(e) {
                var n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "success", t = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 2e3;
                return p.async(function(r) {
                    for (;;) switch (r.prev = r.next) {
                      case 0:
                        if (!e || !e.length) {
                            r.next = 2;
                            break;
                        }
                        return r.abrupt("return", new Promise(function(r) {
                            d.showToast({
                                title: e,
                                mask: !0,
                                icon: n,
                                duration: t,
                                success: function() {
                                    r();
                                },
                                fail: function(e) {
                                    console.error("showToast error: " + JSON.stringify(e)), r();
                                }
                            });
                        }));

                      case 2:
                      case "end":
                        return r.stop();
                    }
                }, null, null, null, Promise);
            }, ve = function() {
                return new Promise(function(e) {
                    d.checkSession({
                        success: function() {
                            e(!0);
                        },
                        fail: function() {
                            e(!1);
                        }
                    });
                });
            }, we = !1, ye = function() {
                we = !0, setTimeout(function() {
                    we = !1;
                }, 200);
            }, me = function(e) {
                arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : e.replace(/^\/|\?.*$/g, "");
                var n = arguments.length > 2 && void 0 !== arguments[2] && arguments[2], t = arguments.length > 3 && void 0 !== arguments[3] && arguments[3];
                return p.async(function(r) {
                    for (;;) switch (r.prev = r.next) {
                      case 0:
                        if (we) {
                            r.next = 2;
                            break;
                        }
                        return r.abrupt("return", new Promise(function(r, o) {
                            ye();
                            var i = "navigateTo";
                            d[i = t ? "reLaunch" : n ? "redirectTo" : "navigateTo"]({
                                url: e,
                                success: r,
                                fail: function(e) {
                                    o(new R("wx." + i, JSON.stringify(e)));
                                }
                            });
                        }));

                      case 2:
                      case "end":
                        return r.stop();
                    }
                }, null, null, null, Promise);
            }, xe = function() {
                return new Promise(function(e) {
                    d.getSetting({
                        success: function(n) {
                            e(n);
                        },
                        fail: function(n) {
                            console.error(" wx.getSetting fail cb", n), e({});
                        }
                    });
                });
            }, ke = function() {
                return Promise.resolve({});
            }, Oe = "3.13.0", Ie = {
                env: B ? B.env : ""
            }, _e = function() {
                return Ie.env;
            }, Pe = function(e) {
                Ie.env = e;
            }, Ce = _e, Se = "https://portal-portm.meituan.com/weapp/loginsdk/api/", je = function() {
                return Se + (_e() ? _e() + "/" : "");
            };
            je(), je();
            var Te, Ee, Re = function(e) {
                return "portm" === B.api ? Se + "uuid" : "https://i.meituan.com/uuid/register?f=" + e;
            }, Le = function(e) {
                return e && "string" == typeof e && e.length >= 40 && e.length <= 80;
            }, Ne = function e(n) {
                var t;
                return p.async(function(r) {
                    for (;;) switch (r.prev = r.next) {
                      case 0:
                        return r.next = 2, p.awrap(Ke(Re()).catch(function(e) {
                            return console.log(e);
                        }));

                      case 2:
                        if (t = r.sent, Le(t)) {
                            r.next = 8;
                            break;
                        }
                        if (!(n > 0)) {
                            r.next = 8;
                            break;
                        }
                        return r.next = 7, p.awrap(e(n - 1));

                      case 7:
                        return r.abrupt("return", r.sent);

                      case 8:
                        return r.abrupt("return", t || "");

                      case 9:
                      case "end":
                        return r.stop();
                    }
                }, null, null, null, Promise);
            }, Ae = function() {
                return p.async(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (!F.persistKey) {
                            e.next = 2;
                            break;
                        }
                        return e.abrupt("return", fe(F.persistKey).then(function(e) {
                            return e && e.uuid;
                        }).catch(function() {
                            return "";
                        }));

                      case 2:
                        return e.abrupt("return", "");

                      case 3:
                      case "end":
                        return e.stop();
                    }
                }, null, null, null, Promise);
            }, Ue = function(e) {
                var n, t, r, o, i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1;
                return p.async(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (n = F.uuid, t = void 0 === n ? "" : n, !Le(t)) {
                            e.next = 3;
                            break;
                        }
                        return e.abrupt("return", t);

                      case 3:
                        if (!Le(Te)) {
                            e.next = 5;
                            break;
                        }
                        return e.abrupt("return", Te);

                      case 5:
                        return e.next = 7, p.awrap(Ae());

                      case 7:
                        if (r = e.sent, !Le(r)) {
                            e.next = 10;
                            break;
                        }
                        return e.abrupt("return", Te = r);

                      case 10:
                        return e.next = 12, p.awrap(Ne(i));

                      case 12:
                        return o = e.sent, e.abrupt("return", Te = o);

                      case 14:
                      case "end":
                        return e.stop();
                    }
                }, null, null, null, Promise);
            }, Be = void 0, De = function() {
                return p.async(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (!Be) {
                            e.next = 2;
                            break;
                        }
                        return e.abrupt("return", Be);

                      case 2:
                        return e.abrupt("return", new Promise(function(e, n) {
                            F.finger.then(function(n) {
                                return n.finger.g(e);
                            }, n);
                        }).then(function(e) {
                            return Be = e, e;
                        }).catch(function(e) {
                            throw be("请先接入guard"), new A("获取指纹信息失败：" + (e && e.message), void 0, 127);
                        }));

                      case 3:
                      case "end":
                        return e.stop();
                    }
                }, null, null, null, Promise);
            }, Fe = function(e, n) {
                var t = {};
                for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && n.indexOf(r) < 0 && (t[r] = e[r]);
                if (null != e && "function" == typeof Object.getOwnPropertySymbols) for (var o = 0, r = Object.getOwnPropertySymbols(e); o < r.length; o++) n.indexOf(r[o]) < 0 && Object.prototype.propertyIsEnumerable.call(e, r[o]) && (t[r[o]] = e[r[o]]);
                return t;
            }, Ke = function(e) {
                var n, t, r, o, i, a, u, s, c, l, f, g, b, h, v, w, y, m, x, k, O, I, _, P, C, S, j, T, E, R = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                return p.async(function(L) {
                    for (;;) switch (L.prev = L.next) {
                      case 0:
                        if (n = R.query, t = R.data, r = R.bypass, o = void 0 !== r && r, i = Fe(R, [ "query", "data", "bypass" ]), 
                        !o) {
                            L.next = 5;
                            break;
                        }
                        return L.next = 4, p.awrap(ue(e, Object.assign(Object.assign({}, i), {
                            data: t,
                            query: n
                        })));

                      case 4:
                        return L.abrupt("return", L.sent);

                      case 5:
                        return a = F.passThroughData, u = F.appName, s = void 0 === u ? "" : u, c = F.risk_app, 
                        l = void 0 === c ? "" : c, f = F.risk_partner, g = void 0 === f ? "" : f, b = F.risk_platform, 
                        h = void 0 === b ? "" : b, v = F.risk_smsPrefixId, w = void 0 === v ? "" : v, y = F.risk_smsTemplateId, 
                        m = void 0 === y ? "" : y, x = F.version_name, k = void 0 === x ? "" : x, O = F.token_id, 
                        I = void 0 === O ? "" : O, _ = F.joinkey, P = void 0 === _ ? "" : _, C = d.getSystemInfoSync(), 
                        S = C.platform, j = C.version, T = C.model, E = void 0 === T ? "" : T, S = "ios" === S.toLowerCase() ? "iphone" : S.toLowerCase(), 
                        L.next = 10, p.awrap(ue(e, Object.assign(Object.assign({}, i), {
                            query: Object.assign(Object.assign(Object.assign(Object.assign(Object.assign({}, n), {
                                sdkVersion: j,
                                utm_medium: S
                            }), P && {
                                joinkey: P
                            }), {
                                sdkType: "wxmp",
                                login_sdk_version: "3.13.0"
                            }), {
                                appName: s,
                                risk_app: l,
                                risk_partner: g,
                                risk_platform: h,
                                risk_smsPrefixId: w,
                                risk_smsTemplateId: m,
                                version_name: k,
                                token_id: I
                            }),
                            data: Object.assign(Object.assign(Object.assign({}, t), a && {
                                passThroughData: "string" == typeof a ? a : JSON.stringify(a)
                            }), {
                                device_type: E,
                                device_os: "微信小程序"
                            })
                        })));

                      case 10:
                        return L.abrupt("return", L.sent);

                      case 11:
                      case "end":
                        return L.stop();
                    }
                }, null, null, null, Promise);
            }, Me = function(e) {
                var n, t, r, i, a, u, s, c, l, f, g, b, h, v, w, y, m, x, k, O, I, _, P, S, j, T, E, R, N, A, U, B, D, K, M, W;
                return p.async(function(q) {
                    for (;;) switch (q.prev = q.next) {
                      case 0:
                        if (n = e.url, t = e.success, r = e.fail, i = e.filePath, a = e.formData, u = e.method, 
                        s = e.header, c = e.complete, l = Fe(e, [ "url", "success", "fail", "filePath", "formData", "method", "header", "complete" ]), 
                        i) {
                            q.next = 5;
                            break;
                        }
                        return q.next = 4, p.awrap(Ke(n, Object.assign({
                            data: a,
                            type: "form",
                            method: "POST"
                        }, l)));

                      case 4:
                        return q.abrupt("return", q.sent);

                      case 5:
                        return f = F.passThroughData, g = F.appName, b = void 0 === g ? "" : g, h = F.risk_app, 
                        v = void 0 === h ? "" : h, w = F.risk_partner, y = void 0 === w ? "" : w, m = F.risk_platform, 
                        x = void 0 === m ? "" : m, k = F.risk_smsPrefixId, O = void 0 === k ? "" : k, I = F.risk_smsTemplateId, 
                        _ = void 0 === I ? "" : I, P = F.version_name, S = void 0 === P ? "" : P, j = F.token_id, 
                        T = void 0 === j ? "" : j, E = d.getSystemInfoSync(), R = E.platform, N = E.version, 
                        A = E.model, U = void 0 === A ? "" : A, R = "ios" === R.toLowerCase() ? "iphone" : R.toLowerCase(), 
                        q.next = 10, p.awrap(Promise.all([ Ue(), De() ]));

                      case 10:
                        return B = q.sent, D = o(B, 2), K = D[0], M = D[1], (W = Object.assign({
                            sdkVersion: N,
                            utm_medium: R,
                            sdkType: "wxmp",
                            login_sdk_version: "3.13.0"
                        }, {
                            appName: b,
                            risk_app: v,
                            risk_partner: y,
                            risk_platform: x,
                            risk_smsPrefixId: O,
                            risk_smsTemplateId: _,
                            version_name: S,
                            token_id: T
                        })) && (n += (~n.indexOf("?") ? "&" : "?") + (0, C.stringify)(W)), q.abrupt("return", new Promise(function(e, t) {
                            return (F.wxUploadFile || d.uploadFile)(Object.assign({
                                url: n,
                                success: function(r) {
                                    r && r.data && e(JSON.parse(r.data)), t(new L("wx.uploadFile 返回的data为null：" + JSON.stringify(r), n));
                                },
                                name: "newAvatar",
                                filePath: i,
                                fail: function(e) {
                                    t(new L("wx.uploadFile crash: " + JSON.stringify(e), n));
                                },
                                header: s,
                                formData: Object.assign(Object.assign(Object.assign({}, a), {
                                    uuid: K,
                                    wechatFingerprint: M,
                                    device_type: U,
                                    device_os: "微信小程序"
                                }), f && {
                                    passThroughData: "string" == typeof f ? f : JSON.stringify(f)
                                })
                            }, l));
                        }));

                      case 17:
                      case "end":
                        return q.stop();
                    }
                }, null, null, null, Promise);
            };
            !function(e) {
                e.AUTH = "auth", e.BINDING = "bind", e.DESTORY = "destory", e.ABORT = "abort";
            }(Ee || (Ee = {}));
            var We;
            !function(e) {
                e.CLICK = "click", e.SMSCLICK = "smsclick", e.LOGINCLICK = "loginclick", e.BINDPAGEONSHOW = "bindpageonshow", 
                e.NAVIBACK = "naviback", e.CLOSECARD = "closecard", e.ENTRYPAGEONSHOW = "entrypageonshow", 
                e.CHANGEPHONEPAGEONSHOW = "changebindpageonshow", e.ALLOWPHONE = "allowphone", e.REFUSEPHONE = "refusephone", 
                e.CHANGEPHONEGETNEWCODE = "changephonegetnewcode", e.CHANGEPHONECHNAGEBTN = "changephonechnagebtn", 
                e.AUTHPAGEONSHOW = "authpageonshow", e.ALLOWUSERINFO = "allowuserinfo", e.REFUSEUSERINFO = "refuseuserinfo", 
                e.USERINFOCLICK = "userinfoclick", e.ENTRYPAGEREFUSEUSERINFO = "entrypagerefuseuserinfo", 
                e.ENTRYPAGEALLOWUSERINFO = "entrypageallowuserinfo";
            }(We || (We = {}));
            var qe, Ve = function() {
                function e(t) {
                    var r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : Ee.AUTH, o = arguments[2];
                    n(this, e), this._callbacks = {}, this.type = t, this.state = r, o && (this.expire = new Date().getTime() + o);
                }
                return f(e, [ {
                    key: "_state",
                    value: function(e, n) {
                        this.state = e, n && (this.data = n), this._emit(e, n);
                    }
                }, {
                    key: "_emit",
                    value: function(e, n) {
                        var t = this, r = this._callbacks[e];
                        r && r.forEach(function(e) {
                            e.call(t, n), t.destroyAfterCb && ze();
                        });
                    }
                }, {
                    key: "on",
                    value: function(e, n) {
                        (this._callbacks[e] = this._callbacks[e] || []).push(n);
                    }
                }, {
                    key: "clean",
                    value: function() {
                        this._callbacks = {}, this.resolve = null, this.sF = void 0;
                    }
                }, {
                    key: "abort",
                    value: function() {
                        this._state(Ee.ABORT);
                    }
                }, {
                    key: "expired",
                    get: function() {
                        return !!this.expire && this.expire < new Date().getTime();
                    }
                } ]), e;
            }(), Je = {}, Ge = {}, He = function() {
                Je.userTicket = "", Je.mobile = "", Je.baseInfo = null;
            }, Ye = void 0, Xe = {
                get session() {
                    return Ye;
                },
                set session(e) {
                    Ye && Ye._state(Ee.DESTORY), Ye = e;
                }
            }, ze = function() {
                Xe.session = null;
            }, $e = u(0), Qe = u.n($e), Ze = function(e) {
                return Qe()[_e() || "prod"][e];
            }, en = function(e, n) {
                var t = {};
                for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && n.indexOf(r) < 0 && (t[r] = e[r]);
                if (null != e && "function" == typeof Object.getOwnPropertySymbols) for (var o = 0, r = Object.getOwnPropertySymbols(e); o < r.length; o++) n.indexOf(r[o]) < 0 && Object.prototype.propertyIsEnumerable.call(e, r[o]) && (t[r[o]] = e[r[o]]);
                return t;
            }, nn = function(e, n) {
                var t, r, i, a, u, s, c, l, f, d, g, b, h = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {}, v = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : {};
                return p.async(function(n) {
                    for (;;) switch (n.prev = n.next) {
                      case 0:
                        return t = h.loginCode, r = h.noCode, i = void 0 !== r && r, a = h.useUserInfo, 
                        u = void 0 === a || a, s = h.userInfo, c = en(h, [ "loginCode", "noCode", "useUserInfo", "userInfo" ]), 
                        n.next = 3, p.awrap(Promise.all([ Ue(), i ? "" : le(t), De() ]));

                      case 3:
                        return l = n.sent, f = o(l, 3), d = f[0], g = f[1], b = f[2], (i || s) && (u = !1), 
                        n.next = 11, p.awrap(Ke(e, {
                            method: "POST",
                            query: c,
                            type: "form",
                            data: Object.assign(Object.assign(Object.assign(Object.assign(Object.assign({}, (u || s) && {
                                bind: !0
                            }), v), {
                                uuid: d
                            }), g && {
                                code: g
                            }), {
                                wechatFingerprint: b
                            })
                        }));

                      case 11:
                        return n.t0 = n.sent, n.t1 = d, n.t2 = g, n.abrupt("return", {
                            resp: n.t0,
                            uuid: n.t1,
                            code: n.t2,
                            userInfo: null
                        });

                      case 15:
                      case "end":
                        return n.stop();
                    }
                }, null, null, null, Promise);
            }, tn = function(e) {
                var n, t, r;
                return p.async(function(o) {
                    for (;;) switch (o.prev = o.next) {
                      case 0:
                        return o.next = 2, p.awrap(nn(Ze("verifylogin"), "", Object.assign(Object.assign({}, e), {
                            useUserInfo: !1,
                            noCode: !0
                        })));

                      case 2:
                        if (n = o.sent, t = n.resp, r = n.uuid, !l(t)) {
                            o.next = 7;
                            break;
                        }
                        return o.abrupt("return", {
                            isErr: !0,
                            error: t.error,
                            uuid: r
                        });

                      case 7:
                        return o.abrupt("return", {
                            isErr: !1,
                            uuid: r,
                            user: Object.assign(Object.assign({}, t.user), {
                                userId: t.user.id
                            })
                        });

                      case 8:
                      case "end":
                        return o.stop();
                    }
                }, null, null, null, Promise);
            }, rn = function(e) {
                var n, t, r;
                return p.async(function(o) {
                    for (;;) switch (o.prev = o.next) {
                      case 0:
                        return o.next = 2, p.awrap(nn(Ze("ticketlogin"), "", Object.assign(Object.assign({}, e), {
                            noCode: !0,
                            useUserInfo: !1
                        })));

                      case 2:
                        if (n = o.sent, t = n.resp, r = n.uuid, !l(t)) {
                            o.next = 7;
                            break;
                        }
                        return o.abrupt("return", {
                            isErr: !0,
                            error: t.error,
                            uuid: r
                        });

                      case 7:
                        return o.abrupt("return", {
                            isErr: !1,
                            uuid: r,
                            user: Object.assign(Object.assign({}, t.user), {
                                userId: t.user.id
                            })
                        });

                      case 8:
                      case "end":
                        return o.stop();
                    }
                }, null, null, null, Promise);
            }, on = function(e, n) {
                var t = {};
                for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && n.indexOf(r) < 0 && (t[r] = e[r]);
                if (null != e && "function" == typeof Object.getOwnPropertySymbols) for (var o = 0, r = Object.getOwnPropertySymbols(e); o < r.length; o++) n.indexOf(r[o]) < 0 && Object.prototype.propertyIsEnumerable.call(e, r[o]) && (t[r[o]] = e[r[o]]);
                return t;
            }, an = function(e) {
                var n, t, r, o, i, a, u, s, c, f;
                return p.async(function(d) {
                    for (;;) switch (d.prev = d.next) {
                      case 0:
                        return n = e.encryptedData, t = e.verify, r = e.checkMobile, o = e.iv, i = on(e, [ "encryptedData", "verify", "checkMobile", "iv" ]), 
                        d.next = 3, p.awrap(nn(Ze("wxmobilelogin"), "", Object.assign(Object.assign(Object.assign({}, t), r), i), {
                            encryptedData: n,
                            iv: o
                        }));

                      case 3:
                        if (a = d.sent, u = a.resp, s = a.code, c = a.uuid, f = a.userInfo, !l(u)) {
                            d.next = 10;
                            break;
                        }
                        return d.abrupt("return", {
                            isErr: !0,
                            error: u.error,
                            code: s,
                            uuid: c,
                            userInfo: f
                        });

                      case 10:
                        return d.abrupt("return", {
                            isErr: !1,
                            loginInfo: u.data,
                            uuid: c,
                            code: s,
                            userInfo: f
                        });

                      case 11:
                      case "end":
                        return d.stop();
                    }
                }, null, null, null, Promise);
            }, un = function(e) {
                var n, t, r, o, i;
                return p.async(function(a) {
                    for (;;) switch (a.prev = a.next) {
                      case 0:
                        return a.next = 2, p.awrap(nn(Ze("wxlogin"), "", e, {
                            admitLogout: !0
                        }));

                      case 2:
                        if (n = a.sent, t = n.resp, r = n.uuid, o = n.code, i = n.userInfo, !l(t)) {
                            a.next = 9;
                            break;
                        }
                        return a.abrupt("return", {
                            isErr: !0,
                            uuid: r,
                            code: o,
                            userInfo: i,
                            error: Object.assign(Object.assign({}, t.error), {
                                openId: t.openId,
                                unionId: t.unionId,
                                openIdCipher: t.openIdCipher
                            })
                        });

                      case 9:
                        return a.abrupt("return", {
                            isErr: !1,
                            loginInfo: Object.assign(Object.assign({}, t.data), {
                                openId: t.openId,
                                openIdCipher: t.openIdCipher,
                                unionId: t.unionId
                            }),
                            userInfo: i,
                            code: o,
                            uuid: r
                        });

                      case 10:
                      case "end":
                        return a.stop();
                    }
                }, null, null, null, Promise);
            }, sn = function(e) {
                var n, t, r, o;
                return p.async(function(i) {
                    for (;;) switch (i.prev = i.next) {
                      case 0:
                        return i.next = 2, p.awrap(nn(Ze("wxslientlogin"), "", Object.assign(Object.assign({}, e), {
                            useUserInfo: !1
                        })));

                      case 2:
                        if (n = i.sent, t = n.resp, r = n.uuid, o = n.code, !l(t)) {
                            i.next = 8;
                            break;
                        }
                        return i.abrupt("return", {
                            isErr: !0,
                            uuid: r,
                            code: o,
                            error: Object.assign(Object.assign({}, t.error), {
                                openId: t.openId,
                                unionId: t.unionId,
                                openIdCipher: t.openIdCipher
                            })
                        });

                      case 8:
                        return i.abrupt("return", {
                            isErr: !1,
                            loginInfo: Object.assign(Object.assign({}, t.data), {
                                openId: t.openId,
                                openIdCipher: t.openIdCipher,
                                unionId: t.unionId
                            }),
                            code: o,
                            uuid: r
                        });

                      case 9:
                      case "end":
                        return i.stop();
                    }
                }, null, null, null, Promise);
            }, cn = function(e) {
                var n, t, r, o, i;
                return p.async(function(a) {
                    for (;;) switch (a.prev = a.next) {
                      case 0:
                        return n = e.mobile, t = e.openId, r = on(e, [ "mobile", "openId" ]), a.next = 3, 
                        p.awrap(nn(Ze("wxbindapply"), "", Object.assign(Object.assign({}, r), {
                            useUserInfo: !1
                        }), {
                            openId: t,
                            mobile: n
                        }));

                      case 3:
                        if (o = a.sent, i = o.resp, !l(i)) {
                            a.next = 7;
                            break;
                        }
                        throw new N(Ze("wxbindapply"), i.error);

                      case 7:
                        if (!i.data) {
                            a.next = 9;
                            break;
                        }
                        return a.abrupt("return", i.data.requestCode);

                      case 9:
                        throw new N(Ze("wxbindapply"), void 0, JSON.stringify(i));

                      case 10:
                      case "end":
                        return a.stop();
                    }
                }, null, null, null, Promise);
            }, ln = function(e) {
                var n, t, r, o, i, a, u, s, c;
                return p.async(function(f) {
                    for (;;) switch (f.prev = f.next) {
                      case 0:
                        return n = e.checkMobile, t = e.loginCode, r = on(e, [ "checkMobile", "loginCode" ]), 
                        o = Object.assign({
                            loginCode: t
                        }, n), f.next = 4, p.awrap(nn(Ze("wxbind"), "", Object.assign(Object.assign({}, o), {
                            useUserInfo: !1
                        }), r));

                      case 4:
                        if (i = f.sent, a = i.resp, u = i.uuid, s = i.code, c = i.userInfo, !l(a)) {
                            f.next = 11;
                            break;
                        }
                        return f.abrupt("return", {
                            isErr: !0,
                            error: a.error,
                            userInfo: c,
                            uuid: u,
                            code: s
                        });

                      case 11:
                        return f.abrupt("return", {
                            isErr: !1,
                            loginInfo: a.data,
                            userInfo: c,
                            code: s,
                            uuid: u
                        });

                      case 12:
                      case "end":
                        return f.stop();
                    }
                }, null, null, null, Promise);
            }, fn = function(e) {
                var n, t;
                return p.async(function(r) {
                    for (;;) switch (r.prev = r.next) {
                      case 0:
                        return r.next = 2, p.awrap(nn(Ze("wxticketlogin"), "", Object.assign(Object.assign({}, e), {
                            noCode: !0
                        })));

                      case 2:
                        if (n = r.sent, t = n.resp, !l(t)) {
                            r.next = 6;
                            break;
                        }
                        return r.abrupt("return", {
                            isErr: !0,
                            error: t.error
                        });

                      case 6:
                        if (!t.data) {
                            r.next = 8;
                            break;
                        }
                        return r.abrupt("return", t.data);

                      case 8:
                        throw new N(Ze("wxticketlogin"));

                      case 9:
                      case "end":
                        return r.stop();
                    }
                }, null, null, null, Promise);
            }, pn = void 0, dn = function() {
                try {
                    return pn || F.wxIdsKey && d.getStorageSync(F.wxIdsKey) || null;
                } catch (e) {
                    return console.error(e), null;
                }
            }, gn = function() {
                var e, n;
                return p.async(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        if (!pn) {
                            t.next = 2;
                            break;
                        }
                        return t.abrupt("return", pn);

                      case 2:
                        if (!F.wxIdsKey) {
                            t.next = 8;
                            break;
                        }
                        return t.next = 5, p.awrap(fe(F.wxIdsKey).catch(c));

                      case 5:
                        if (!(e = t.sent)) {
                            t.next = 8;
                            break;
                        }
                        return t.abrupt("return", pn = e);

                      case 8:
                        return t.next = 10, p.awrap(vn());

                      case 10:
                        if (n = t.sent, !g(n)) {
                            t.next = 16;
                            break;
                        }
                        if (!F.wxIdsKey) {
                            t.next = 15;
                            break;
                        }
                        return t.next = 15, p.awrap(pe(F.wxIdsKey, {
                            openId: n.openid,
                            unionId: n.unionid,
                            openIdCipher: n.openidCipher
                        }).catch(c));

                      case 15:
                        return t.abrupt("return", pn = {
                            openId: n.openid,
                            unionId: n.unionid,
                            openIdCipher: n.openidCipher
                        });

                      case 16:
                        throw new A("getwxIds 返回的数据格式不对: " + JSON.stringify(n), void 0, 120);

                      case 17:
                      case "end":
                        return t.stop();
                    }
                }, null, null, null, Promise);
            }, bn = function(e) {
                var n, t, r, o, i, a, u, s, c, l, f;
                return p.async(function(d) {
                    for (;;) switch (d.prev = d.next) {
                      case 0:
                        return n = e.mobile, t = e.verifyLevel, r = void 0 === t ? 2 : t, o = e.specialRiskCode, 
                        i = void 0 === o ? 0 : o, d.next = 3, p.awrap(gn());

                      case 3:
                        return a = d.sent, u = a.openId, s = a.unionId, c = {
                            mobile: n,
                            verifyLevel: r,
                            specialRiskCode: i,
                            weixinappid: F.appId,
                            weixinopenid: u,
                            weixinunionid: s
                        }, d.next = 9, p.awrap(nn(Ze("mobileloginapply"), "", {
                            noCode: !0
                        }, c));

                      case 9:
                        if (l = d.sent, !(f = l.resp).error || !f.error.data) {
                            d.next = 13;
                            break;
                        }
                        return d.abrupt("return", f.error.data.requestCode);

                      case 13:
                        throw new N(Ze("mobileloginapply"), f.error, JSON.stringify(f));

                      case 14:
                      case "end":
                        return d.stop();
                    }
                }, null, null, null, Promise);
            }, hn = function(e, n) {
                var t, r, o, i, a, u;
                return p.async(function(s) {
                    for (;;) switch (s.prev = s.next) {
                      case 0:
                        return s.next = 2, p.awrap(gn());

                      case 2:
                        return t = s.sent, r = t.openId, o = t.unionId, Object.assign(n, {
                            weixinappid: F.appId,
                            weixinopenid: r,
                            weixinunionid: o
                        }), s.next = 8, p.awrap(nn(Ze("mobilelogin"), "", Object.assign({
                            useUserInfo: !1,
                            noCode: !0
                        }, e), n));

                      case 8:
                        if (i = s.sent, a = i.resp, u = i.uuid, !l(a)) {
                            s.next = 13;
                            break;
                        }
                        return s.abrupt("return", {
                            isErr: !0,
                            error: a.error,
                            uuid: u
                        });

                      case 13:
                        return s.abrupt("return", {
                            isErr: !1,
                            uuid: u,
                            loginInfo: a.user
                        });

                      case 14:
                      case "end":
                        return s.stop();
                    }
                }, null, null, null, Promise);
            }, vn = function() {
                var e, n;
                return p.async(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return t.next = 2, p.awrap(le());

                      case 2:
                        return e = t.sent, t.next = 5, p.awrap(Ke(Ze("getwxinfo"), {
                            method: "POST",
                            type: "form",
                            data: {
                                code: e
                            }
                        }));

                      case 5:
                        if (!(n = t.sent).code) {
                            t.next = 8;
                            break;
                        }
                        throw new N(Ze("getwxinfo"), n);

                      case 8:
                        return t.abrupt("return", n);

                      case 9:
                      case "end":
                        return t.stop();
                    }
                }, null, null, null, Promise);
            }, wn = function(e) {
                var n, t;
                return p.async(function(r) {
                    for (;;) switch (r.prev = r.next) {
                      case 0:
                        return r.next = 2, p.awrap(le());

                      case 2:
                        return n = r.sent, r.next = 5, p.awrap(Ke(Ze("updatewxinfo"), {
                            method: "POST",
                            type: "form",
                            data: {
                                code: n,
                                userinfo: JSON.stringify(e)
                            }
                        }));

                      case 5:
                        if (!(t = r.sent).code) {
                            r.next = 8;
                            break;
                        }
                        throw new N(Ze("updatewxuserinfo"), t);

                      case 8:
                        return r.abrupt("return", t);

                      case 9:
                      case "end":
                        return r.stop();
                    }
                }, null, null, null, Promise);
            }, yn = [ "id", "username", "avatartype", "avatarurl", "nickname", "email", "city", "cityid", "mobile", "isBindedMobile" ], mn = function(e, n) {
                var t;
                return p.async(function(r) {
                    for (;;) switch (r.prev = r.next) {
                      case 0:
                        if (e) {
                            r.next = 2;
                            break;
                        }
                        throw new A("getMtInfo 必须传token", void 0, 103);

                      case 2:
                        return r.next = 4, p.awrap(Ke(Ze("getmtuserinfo"), Object.assign({
                            query: {
                                fields: yn.join(","),
                                token: e
                            }
                        }, n)));

                      case 4:
                        if (!(t = r.sent).error) {
                            r.next = 7;
                            break;
                        }
                        throw new N("getMtInfo: " + Ze("getmtuserinfo"), t.error);

                      case 7:
                        return r.abrupt("return", t.user);

                      case 8:
                      case "end":
                        return r.stop();
                    }
                }, null, null, null, Promise);
            }, xn = function(e, n) {
                var t, r, o;
                return p.async(function(i) {
                    for (;;) switch (i.prev = i.next) {
                      case 0:
                        return t = n.username, r = n.avatar, i.next = 3, p.awrap(Me({
                            url: Ze("updatemtuserinfo") + "/" + e,
                            timeout: 5e3,
                            filePath: r,
                            formData: Object.assign(Object.assign({}, t ? {
                                username: t
                            } : {}), r ? {
                                avatartype: 255
                            } : {})
                        }));

                      case 3:
                        if (!(o = i.sent).error) {
                            i.next = 6;
                            break;
                        }
                        throw new N(Ze("updatemtuserinfo"), o.error);

                      case 6:
                        return i.abrupt("return", o.user);

                      case 7:
                      case "end":
                        return i.stop();
                    }
                }, null, null, null, Promise);
            }, kn = !1, On = function(e) {
                return kn = e;
            }, In = function() {
                return kn;
            }, _n = [ function(e) {
                var n = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
                return p.async(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        if (!T(e)) {
                            t.next = 2;
                            break;
                        }
                        return t.abrupt("return", n ? e : be(e.msg));

                      case 2:
                      case "end":
                        return t.stop();
                    }
                }, null, null, null, Promise);
            }, function(e) {
                var n = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
                if (j(e)) return n ? e : be(e.msg);
            }, function(e) {
                var n = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
                if (S(e)) return n ? e : be(e.msg);
            }, function(e) {
                arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
                if (E(e)) return !0;
            } ], Pn = function(e) {
                var n, t, r, o = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
                return p.async(function(i) {
                    for (;;) switch (i.prev = i.next) {
                      case 0:
                        if (d.hideToast(), e) {
                            i.next = 3;
                            break;
                        }
                        return i.abrupt("return");

                      case 3:
                        !F.errorReport && console.error(e), n = s(_n);

                      case 5:
                        if ((t = n()).done) {
                            i.next = 13;
                            break;
                        }
                        return r = t.value, i.next = 9, p.awrap(r(e, o));

                      case 9:
                        if (!i.sent) {
                            i.next = 11;
                            break;
                        }
                        return i.abrupt("return", F.errorReport ? e : void 0);

                      case 11:
                        i.next = 5;
                        break;

                      case 13:
                        return i.abrupt("return", F.errorReport ? (e.errType = P.UnExpected, e._message = e.message, 
                        e._stack = e.stack, e) : void 0);

                      case 14:
                      case "end":
                        return i.stop();
                    }
                }, null, null, null, Promise);
            }, Cn = function(e) {
                return p.async(function(n) {
                    for (;;) switch (n.prev = n.next) {
                      case 0:
                        if (!(e && e.token && e.userId)) {
                            n.next = 12;
                            break;
                        }
                        if (Xe.authInfo = e, e.creatTime = Date.now() - 6e4, On(!0), !F.persistKey) {
                            n.next = 7;
                            break;
                        }
                        return n.next = 7, p.awrap(pe(F.persistKey, e).catch(function(e) {
                            console.error(e);
                        }));

                      case 7:
                        return n.next = 9, p.awrap(Rn());

                      case 9:
                        return n.abrupt("return", e);

                      case 12:
                        throw new A(te.illegalAuthInfo, "setAuthInfo出错：" + JSON.stringify(e), 113);

                      case 13:
                      case "end":
                        return n.stop();
                    }
                }, null, null, null, Promise);
            }, Sn = function() {
                try {
                    var e = Xe.authInfo || F.persistKey && d.getStorageSync(F.persistKey) || null;
                    return !e && On(!0), e;
                } catch (e) {
                    return null;
                }
            }, jn = function() {
                var e, n;
                return p.async(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        if (!(e = Xe.authInfo)) {
                            t.next = 3;
                            break;
                        }
                        return t.abrupt("return", {
                            authInfo: e,
                            fromStorage: !1
                        });

                      case 3:
                        if (!F.persistKey) {
                            t.next = 8;
                            break;
                        }
                        return t.next = 6, p.awrap(fe(F.persistKey).catch(function() {
                            return null;
                        }));

                      case 6:
                        return n = t.sent, t.abrupt("return", {
                            authInfo: n,
                            fromStorage: !0
                        });

                      case 8:
                        return t.abrupt("return", {
                            authInfo: null,
                            fromStorage: !1
                        });

                      case 9:
                      case "end":
                        return t.stop();
                    }
                }, null, null, null, Promise);
            }, Tn = function() {
                var e, n, t, r, o = arguments.length > 0 && void 0 !== arguments[0] && arguments[0], i = arguments.length > 1 && void 0 !== arguments[1] && arguments[1], a = arguments[2];
                return p.async(function(u) {
                    for (;;) switch (u.prev = u.next) {
                      case 0:
                        return u.next = 2, p.awrap(jn());

                      case 2:
                        if (e = u.sent, n = e.authInfo, e.fromStorage, n) {
                            u.next = 7;
                            break;
                        }
                        return u.abrupt("return", n);

                      case 7:
                        if (!o) {
                            u.next = 11;
                            break;
                        }
                        if ((t = n.creatTime) && !(Date.now() - t > 15552e6)) {
                            u.next = 11;
                            break;
                        }
                        return u.abrupt("return", null);

                      case 11:
                        if (!i) {
                            u.next = 22;
                            break;
                        }
                        return u.next = 14, p.awrap(b(n.token, null === a || void 0 === a ? void 0 : a.timeout));

                      case 14:
                        if (r = u.sent) {
                            u.next = 21;
                            break;
                        }
                        if (u.t0 = !1 === r, !u.t0) {
                            u.next = 20;
                            break;
                        }
                        return u.next = 20, p.awrap(En());

                      case 20:
                        return u.abrupt("return", null);

                      case 21:
                        Xe.authInfo || (Xe.authInfo = n);

                      case 22:
                        return u.abrupt("return", n);

                      case 23:
                      case "end":
                        return u.stop();
                    }
                }, null, null, null, Promise);
            }, En = function() {
                return p.async(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (On(!0), Xe.authInfo = null, !F.persistKey) {
                            e.next = 5;
                            break;
                        }
                        return e.next = 5, p.awrap(de(F.persistKey).catch(c));

                      case 5:
                      case "end":
                        return e.stop();
                    }
                }, null, null, null, Promise);
            }, Rn = function(e) {
                var n, t, r, o, i;
                return p.async(function(a) {
                    for (;;) switch (a.prev = a.next) {
                      case 0:
                        if (!(n = Xe.session)) {
                            a.next = 12;
                            break;
                        }
                        if (t = n.resolve, r = n.redirectUrl, o = n.waitBack, (i = n.sF) && i(!1), Xe.session = null, 
                        !o) {
                            a.next = 10;
                            break;
                        }
                        return a.next = 8, p.awrap(Nn(r));

                      case 8:
                        a.next = 11;
                        break;

                      case 10:
                        Nn(r);

                      case 11:
                        "function" == typeof t && t(e || Tn());

                      case 12:
                      case "end":
                        return a.stop();
                    }
                }, null, null, null, Promise);
            }, Ln = function(e, n, t) {
                if (F.onPageErr) try {
                    F.onPageErr(e, n, t);
                } catch (e) {
                    console.error(e);
                }
            }, Nn = function(e, n) {
                var t, r, o, i, a;
                return p.async(function(u) {
                    for (;;) switch (u.prev = u.next) {
                      case 0:
                        if (t = getCurrentPages(), r = (n || K.sdkRoute).replace(/^\//, ""), o = t && t[0] && t[0].route ? "route" : "__route__", 
                        i = t.findIndex(function(e) {
                            return e && e[o].startsWith(r);
                        }), !e) {
                            u.next = 8;
                            break;
                        }
                        if (!(i > 0 && i === t.length - 1)) {
                            u.next = 7;
                            break;
                        }
                        return u.abrupt("return", me(e, "", !0));

                      case 7:
                        return u.abrupt("return", me(e));

                      case 8:
                        if (-1 !== i) {
                            u.next = 10;
                            break;
                        }
                        return u.abrupt("return");

                      case 10:
                        if (!((a = i > 0 ? t.length - i : t.length - i - 1) > 0)) {
                            u.next = 13;
                            break;
                        }
                        return u.abrupt("return", new Promise(function(e) {
                            d.navigateBack({
                                delta: a
                            });
                            var n = t.length - a;
                            !function t() {
                                setTimeout(function() {
                                    getCurrentPages().length === n ? e() : t();
                                }, 100);
                            }();
                        }));

                      case 13:
                      case "end":
                        return u.stop();
                    }
                }, null, null, null, Promise);
            }, An = function(e, n) {
                var t;
                return p.async(function(r) {
                    for (;;) switch (r.prev = r.next) {
                      case 0:
                        return r.next = 2, p.awrap(Cn(Object.assign(e, n)));

                      case 2:
                        return t = r.sent, he(te.loginSuccess), r.abrupt("return", t);

                      case 5:
                      case "end":
                        return r.stop();
                    }
                }, null, null, null, Promise);
            }, Un = function(e, n) {
                var t;
                return p.async(function(r) {
                    for (;;) switch (r.prev = r.next) {
                      case 0:
                        if (!M) {
                            r.next = 6;
                            break;
                        }
                        return r.next = 3, p.awrap(M(e, n));

                      case 3:
                        if (t = r.sent) {
                            r.next = 6;
                            break;
                        }
                        throw new A("loginCheck failed", void 0, 114);

                      case 6:
                      case "end":
                        return r.stop();
                    }
                }, null, null, null, Promise);
            }, Bn = function(e, n) {
                var t = Xe.session;
                return t && !t.expired ? (t.clean(), t) : Xe.session = new Ve(e, Ee.AUTH, n);
            }, Dn = function(e) {
                return e && e.protocolList && e.protocolList.map(function(e) {
                    e.encodedUrl || (e.encodedUrl = encodeURIComponent(e.url));
                }), e;
            }, Fn = {
                getLoginCode: le,
                getUserProfile: function() {
                    return Promise.resolve({});
                },
                getUserInfo: function() {
                    arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
                    return p.async(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            return e.abrupt("return", Promise.resolve({}));

                          case 1:
                          case "end":
                            return e.stop();
                        }
                    }, null, null, null, Promise);
                },
                getUUID: Ue,
                getStorage: fe,
                setStorage: pe,
                showTip: be,
                showToast: he,
                request: Ke,
                stringify: C.stringify,
                navigate: me
            };
            !function(e) {
                e.navigateTo = "navigateTo", e.redirectTo = "redirectTo", e.reLaunch = "reLaunch";
            }(qe || (qe = {}));
            var Kn = function(e, n) {
                var t = {};
                for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && n.indexOf(r) < 0 && (t[r] = e[r]);
                if (null != e && "function" == typeof Object.getOwnPropertySymbols) for (var o = 0, r = Object.getOwnPropertySymbols(e); o < r.length; o++) n.indexOf(r[o]) < 0 && Object.prototype.propertyIsEnumerable.call(e, r[o]) && (t[r[o]] = e[r[o]]);
                return t;
            }, Mn = function(e, n, t) {
                var r, o, i, a;
                return p.async(function(u) {
                    for (;;) switch (u.prev = u.next) {
                      case 0:
                        return r = e || Wn[oe.create](), o = "" + K.bindRoute, i = n === qe.redirectTo, 
                        a = n === qe.reLaunch, t && (o = o + "?" + (0, C.stringify)(t)), u.next = 7, p.awrap(me(o, K.bindRoute.substr(1), i, a));

                      case 7:
                        return u.abrupt("return", r);

                      case 8:
                      case "end":
                        return u.stop();
                    }
                }, null, null, null, Promise);
            }, Wn = function() {
                var e, n, t, r, o = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                return p.async(function(i) {
                    for (;;) switch (i.prev = i.next) {
                      case 0:
                        return e = o.session, n = o.navType, t = Kn(o, [ "session", "navType" ]), i.next = 3, 
                        p.awrap(Mn(e, n, t));

                      case 3:
                        return r = i.sent, i.next = 6, p.awrap(new Promise(function(e, n) {
                            r.resolve = e, r.reject = n;
                        }));

                      case 6:
                        return i.abrupt("return", i.sent);

                      case 7:
                      case "end":
                        return i.stop();
                    }
                }, null, null, null, Promise);
            };
            Wn[oe.create] = function() {
                return Bn(W.MOBILE);
            };
            var qn, Vn = function() {
                function e() {
                    var t = this;
                    n(this, e), this.data = function() {
                        var e = H.title, n = H.wxLoginText, t = H.mobileLoginText, r = H.imageSrc, o = H.imageMode, i = H.imageStyle, a = H.wxLoginStyle, u = H.mobileLoginStyle, s = H.titleBarTextColor, c = H.titleBarBkgColor;
                        return {
                            API_TYPE: W,
                            type: W.MOBILE,
                            title: e,
                            wxLoginText: n,
                            mobileLoginText: t,
                            wxLoginStyle: a,
                            mobileLoginStyle: u,
                            radioChecked: !1,
                            titleBarBkgColor: c,
                            titleBarTextColor: s,
                            image: {
                                src: r,
                                mode: o,
                                style: i
                            },
                            protocolConfig: Dn(ie)
                        };
                    }();
                    var r = e.prototype;
                    Object.getOwnPropertyNames(r).filter(function(e) {
                        return "constructor" !== e;
                    }).forEach(function(e) {
                        Object.defineProperty(t, e, {
                            writable: !0,
                            configurable: !0,
                            enumerable: !0,
                            value: r[e]
                        });
                    });
                }
                return f(e, [ {
                    key: "onLoad",
                    value: function(e) {
                        var n = this;
                        return function() {
                            var t, r;
                            return p.async(function(o) {
                                for (;;) switch (o.prev = o.next) {
                                  case 0:
                                    if (n.setData({
                                        radioChecked: !1
                                    }), e.type && n.setData({
                                        type: e.type
                                    }), n.hasAuthUserInfo = !1, n.specialRiskCode = e.specialRiskCode || 0, n.poiid = e.poiid || "", 
                                    o.t0 = e.code, o.t0) {
                                        o.next = 10;
                                        break;
                                    }
                                    return o.next = 9, p.awrap(le());

                                  case 9:
                                    o.t0 = o.sent;

                                  case 10:
                                    if (n.loginCode = o.t0, n.bind = "false" !== e.bind, n.redirectUrl = e.redirectUrl, 
                                    n.willRedirectToBindPage = "1" === e.willRedirectToBindPage, d.getUserProfile) {
                                        o.next = 20;
                                        break;
                                    }
                                    return o.next = 17, p.awrap(xe());

                                  case 17:
                                    t = o.sent, (r = t.authSetting) && r["scope.userInfo"] && (n.hasAuthUserInfo = !0);

                                  case 20:
                                  case "end":
                                    return o.stop();
                                }
                            }, null, null, null, Promise);
                        }();
                    }
                }, {
                    key: "onReady",
                    value: function() {
                        d.setNavigationBarColor({
                            frontColor: this.data.titleBarTextColor,
                            backgroundColor: this.data.titleBarBkgColor
                        }), d.setNavigationBarTitle({
                            title: this.data.title
                        });
                    }
                }, {
                    key: "onShow",
                    value: function() {
                        Xe.session && Xe.session._emit(We.ENTRYPAGEONSHOW, Xe.session), this.goToBindPage = !1;
                    }
                }, {
                    key: "onClickRadio",
                    value: function() {
                        var e = !this.data.radioChecked;
                        this.setData({
                            radioChecked: e
                        }), e && this.setData({
                            showNote: !1
                        });
                    }
                }, {
                    key: "onUnload",
                    value: function() {
                        var e, n;
                        !Xe.session || this.goToBindPage || this.disErrRpt || (F.errorReport && (Nn(), null === (n = null === (e = null === Xe || void 0 === Xe ? void 0 : Xe.session) || void 0 === e ? void 0 : e.reject) || void 0 === n || n.call(e, new A("用户从登陆入口页回退", void 0, 112))), 
                        Xe.session._emit(We.NAVIBACK, Xe.session));
                    }
                }, {
                    key: "lockClick",
                    value: function(e, n) {
                        var t = this, r = null;
                        1 === e ? (this.wxMobileLock = !0, r = setTimeout(function() {
                            t.wxMobileLock = !1, clearTimeout(r), r = null;
                        }, n || 2e3)) : (this.mobileLock = !0, r = setTimeout(function() {
                            t.mobileLock = !1, clearTimeout(r), r = null;
                        }, n || 2e3));
                    }
                }, {
                    key: "getLoginCode",
                    value: function() {
                        var e = this;
                        return function() {
                            var n;
                            return p.async(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    if (e.data.radioChecked) {
                                        t.next = 3;
                                        break;
                                    }
                                    return e.setData({
                                        showNote: !0
                                    }), t.abrupt("return");

                                  case 3:
                                    if (!e.wxMobileLock) {
                                        t.next = 5;
                                        break;
                                    }
                                    return t.abrupt("return");

                                  case 5:
                                    return (n = Xe.session) && n._emit(We.CLICK, W.WX_MOBILE), e.lockClick(2), t.next = 10, 
                                    p.awrap(le());

                                  case 10:
                                    e.loginCode = t.sent;

                                  case 11:
                                  case "end":
                                    return t.stop();
                                }
                            }, null, null, null, Promise);
                        }();
                    }
                }, {
                    key: "wxMobileLoginClick",
                    value: function(e) {
                        var n = this;
                        return function() {
                            var t, r, o, i;
                            return p.async(function(a) {
                                for (;;) switch (a.prev = a.next) {
                                  case 0:
                                    if (a.prev = 0, !n.wxMobileLock) {
                                        a.next = 3;
                                        break;
                                    }
                                    return a.abrupt("return");

                                  case 3:
                                    if (n.lockClick(2), t = Xe.session, null != (r = e.detail).iv) {
                                        a.next = 11;
                                        break;
                                    }
                                    return t && t._emit(We.REFUSEPHONE, t), a.next = 10, p.awrap(be(te.refusePhoneNumberAuth));

                                  case 10:
                                    return a.abrupt("return");

                                  case 11:
                                    return t && t._emit(We.ALLOWPHONE, t), a.next = 14, p.awrap(Un("wechat").catch(c));

                                  case 14:
                                    return he(te.logining, "loading", 60010), o = null, t && t.data && (o = t.data.wxUserInfoData), 
                                    a.next = 19, p.awrap(lt(r, n.loginCode, n.bind, o, t));

                                  case 19:
                                    i = a.sent, d.hideToast(), i && he(te.loginSuccess), a.next = 29;
                                    break;

                                  case 24:
                                    if (a.prev = 24, a.t0 = a.catch(0), F.errorReport) {
                                        a.next = 28;
                                        break;
                                    }
                                    throw a.t0;

                                  case 28:
                                    Ln(a.t0, "entry", "wxMobile");

                                  case 29:
                                  case "end":
                                    return a.stop();
                                }
                            }, null, null, [ [ 0, 24 ] ], Promise);
                        }();
                    }
                }, {
                    key: "mobileLoginClick",
                    value: function() {
                        var e = this;
                        return function() {
                            var n, t;
                            return p.async(function(r) {
                                for (;;) switch (r.prev = r.next) {
                                  case 0:
                                    if (e.data.radioChecked) {
                                        r.next = 3;
                                        break;
                                    }
                                    return e.setData({
                                        showNote: !0
                                    }), r.abrupt("return");

                                  case 3:
                                    if (!e.mobileLock) {
                                        r.next = 5;
                                        break;
                                    }
                                    return r.abrupt("return");

                                  case 5:
                                    return e.lockClick(1), n = e.redirectUrl || e.willRedirectToBindPage ? qe.redirectTo : qe.navigateTo, 
                                    t = {
                                        fromEntry: !0,
                                        specialRiskCode: e.specialRiskCode,
                                        cfrm: !0
                                    }, e.poiid && (t.poiid = e.poiid), e.goToBindPage = !0, r.next = 12, p.awrap(Mn(Xe.session, n, t).catch(function(e) {
                                        if (!F.errorReport) throw e;
                                        Ln(e, "entry", "onGoToMobile");
                                    }));

                                  case 12:
                                  case "end":
                                    return r.stop();
                                }
                            }, null, null, null, Promise);
                        }();
                    }
                }, {
                    key: "onWxLoginTap",
                    value: function() {
                        var e = this;
                        this.data.radioChecked ? (Xe.session && Xe.session._emit(We.CLICK, Xe.session.type), 
                        d.getUserProfile && (this.bind ? d.getUserProfile && d.getUserProfile({
                            desc: "请授权用户信息",
                            success: function(n) {
                                n && n.userInfo && e.wxLoginClick({
                                    userInfo: n.userInfo
                                }).catch(function(e) {
                                    if (!F.errorReport) throw e;
                                    Ln(e, "entry", "wxLoginUserProfile");
                                });
                            },
                            fail: function() {
                                be(te.refuseUserInfoAuth).then(function() {
                                    Xe.session && Xe.session._emit(We.ENTRYPAGEREFUSEUSERINFO, Xe.session.type);
                                });
                            }
                        }) : this.wxLoginClick({}).catch(function(e) {
                            if (!F.errorReport) throw e;
                            Ln(e, "entry", "wxLoginNoBind");
                        }))) : this.setData({
                            showNote: !0
                        });
                    }
                }, {
                    key: "onGetUserInfo",
                    value: function(e) {
                        if (!d.getUserProfile) {
                            var n = e.detail;
                            n.iv ? this.wxLoginClick({
                                userInfo: n.userInfo
                            }).catch(function(e) {
                                if (F.errorReport) throw e;
                                Ln(e, "entry", "wxLoginUserInfo");
                            }) : be(te.refuseUserInfoAuth).then(function() {
                                Xe.session && Xe.session._emit(We.ENTRYPAGEREFUSEUSERINFO, Xe.session.type);
                            });
                        }
                    }
                }, {
                    key: "wxLoginClick",
                    value: function(e) {
                        var n = this;
                        return function() {
                            var t, r, o, i, a, u, s;
                            return p.async(function(c) {
                                for (;;) switch (c.prev = c.next) {
                                  case 0:
                                    if (!n.mobileLock) {
                                        c.next = 2;
                                        break;
                                    }
                                    return c.abrupt("return");

                                  case 2:
                                    if (n.lockClick(1), t = e.userInfo, r = void 0 === t ? {} : t, n.hasAuthUserInfo || d.getUserProfile || Xe.session && Xe.session._emit(We.ENTRYPAGEALLOWUSERINFO, Xe.session.type), 
                                    n.goToBindPage = !0, (o = Xe.session) || (i = Bn(W.WXV2), o = i && i.type === W.WXV2 ? i : new Ve(W.WXV2, Ee.AUTH, 6e5)), 
                                    a = o.resolve) {
                                        c.next = 14;
                                        break;
                                    }
                                    return c.next = 12, p.awrap(be("登陆异常，请退出该页面后重新尝试"));

                                  case 12:
                                    return n.disErrRpt = !0, c.abrupt("return");

                                  case 14:
                                    return u = n.redirectUrl || n.willRedirectToBindPage ? qe.redirectTo : qe.navigateTo, 
                                    s = Object.assign(Object.assign({
                                        session: o,
                                        slient: !1,
                                        redirectUrl: n.redirectUrl,
                                        navType: u,
                                        fromEntry: !0,
                                        cfrm: !0
                                    }, n.bind ? {
                                        userInfo: r
                                    } : {
                                        useUserInfo: !1
                                    }), {
                                        specialRiskCode: n.specialRiskCode
                                    }), n.poiid && (s.poiid = n.poiid), c.t0 = a, c.next = 20, p.awrap(pt(s));

                                  case 20:
                                    c.t1 = c.sent, (0, c.t0)(c.t1);

                                  case 22:
                                  case "end":
                                    return c.stop();
                                }
                            }, null, null, null, Promise);
                        }();
                    }
                } ]), e;
            }();
            !function(e) {
                e.Entry = "entry", e.Bind = "bind";
            }(qn || (qn = {}));
            var Jn = void 0, Gn = void 0, Hn = new Vn(), Yn = {
                methods: Object.assign(Object.assign({}, Hn), {
                    closeCard: function() {
                        var e, n = Xe.session;
                        n && n.sF && n.sF(!1), F.errorReport && (null === (e = null === n || void 0 === n ? void 0 : n.reject) || void 0 === e || e.call(n, new A("用户从弹窗登陆页面退出", void 0, 108))), 
                        n && n._emit(We.CLOSECARD, n);
                    },
                    mobileLoginClick: function() {
                        Xe.session && Xe.session._emit(We.CLICK, Xe.session.type), Hn.mobileLoginClick.call(this);
                    }
                }),
                data: Object.assign(Object.assign({}, Hn.data), {
                    webviewDir: "",
                    showCard: !1
                }),
                lifetimes: {
                    created: function() {
                        var e = this;
                        Gn = this, Jn = function(n, t) {
                            return e.setData({
                                showCard: n
                            }, t);
                        };
                    },
                    attached: function() {
                        var e = this;
                        return p.async(function(n) {
                            for (;;) switch (n.prev = n.next) {
                              case 0:
                                e.setData({
                                    protocolConfig: Dn(ie),
                                    webviewDir: K.webviewRoute
                                });

                              case 1:
                              case "end":
                                return n.stop();
                            }
                        }, null, null, null, Promise);
                    }
                },
                pageLifetimes: {
                    show: function() {
                        var e = this;
                        Gn = this, Jn = function(n, t) {
                            return e.setData({
                                showCard: n
                            }, t);
                        }, this.data.showCard && Hn.onShow.call(this);
                    }
                }
            }, Xn = function(n, t, r) {
                var i;
                return p.async(function(a) {
                    for (;;) switch (a.prev = a.next) {
                      case 0:
                        return i = n.slice(n.indexOf("?") + 1).split("&").reduce(function(n, t) {
                            var r = o(t.split("="), 2), i = r[0], a = r[1];
                            return Object.assign(n, e({}, i, a));
                        }, {}), a.abrupt("return", new Promise(function(e, n) {
                            try {
                                t(r && r.call(Gn, i)), e(!0);
                            } catch (e) {
                                n(new A("弹窗登陆失败：swtchFunc 失败：" + JSON.stringify(e), void 0, 109));
                            }
                        }));

                      case 2:
                      case "end":
                        return a.stop();
                    }
                }, null, null, null, Promise);
            }, zn = function e() {
                var n, t, r, o, i, a, u, s = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, c = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
                return p.async(function(l) {
                    for (;;) switch (l.prev = l.next) {
                      case 0:
                        if (t = !0, r = s.navType === qe.redirectTo, o = s.navType === qe.reLaunch, i = !(!r && !o), 
                        s instanceof Ve ? n = s : (n = s.session || e[oe.create](), !1 === s.bind && (t = !1)), 
                        n.data || (n.data = {}), n.redirectUrl = s.redirectUrl, n.waitBack = s.waitBack, 
                        n.data.wxUserInfoData = s.wxUserInfoData, c && (n.sF = Jn), a = K.loginRoute, u = n.type === W.LOGIN ? a + "?bind=" + t + "&redirectUrl=" + (n.redirectUrl || "") + "&willRedirectToBindPage=" + i : a + "?type=" + n.type + "&bind=" + t + "&redirectUrl=" + (n.redirectUrl || "") + "&willRedirectToBindPage=" + i, 
                        s.code && n.data.wxUserInfoData && (u = u + "&code=" + s.code), s.poiid && (u = u + "&poiid=" + s.poiid), 
                        u = u + "&specialRiskCode=" + (s.specialRiskCode || 0), !c || n.sF) {
                            l.next = 17;
                            break;
                        }
                        throw new A("switchFunc is null", void 0, 104);

                      case 17:
                        return l.next = 19, p.awrap(c ? Xn(u, function(e) {
                            return n.sF(!0, e);
                        }, function() {
                            for (var e, n, t = arguments.length, r = Array(t), o = 0; o < t; o++) r[o] = arguments[o];
                            (e = Vn.prototype.onLoad).call.apply(e, [ this ].concat(r)), (n = Vn.prototype.onShow).call.apply(n, [ this ].concat(r));
                        }) : me(u, a.substr(1), r, o));

                      case 19:
                        return l.next = 21, p.awrap(new Promise(function(e, t) {
                            n.resolve = e, n.reject = t;
                        }));

                      case 21:
                        return l.abrupt("return", l.sent);

                      case 22:
                      case "end":
                        return l.stop();
                    }
                }, null, null, null, Promise);
            };
            zn[oe.create] = function() {
                return Bn(W.LOGIN);
            };
            var $n = function(e) {
                return En().then(function() {
                    return zn(e);
                });
            }, Qn = void 0, Zn = void 0, et = function() {
                return Qn;
            }, nt = function() {
                return Zn;
            }, tt = void 0, rt = void 0, ot = function() {
                return tt;
            }, it = function() {
                return rt;
            }, at = void 0, ut = void 0, st = function() {
                return at;
            }, ct = function() {
                return ut;
            }, lt = function e(n, t) {
                var r, o, i, a, u, s, c, l, f, d, g, b, y, x, k, O, I, _, P, C, S, j, T, E = n.iv, R = n.encryptedData, L = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2], A = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : null, U = arguments[4];
                return p.async(function(n) {
                    for (;;) switch (n.prev = n.next) {
                      case 0:
                        return n.prev = 0, o = {
                            iv: E,
                            encryptedData: R,
                            loginCode: t,
                            useUserInfo: L
                        }, n.next = 4, p.awrap(an(o));

                      case 4:
                        i = n.sent, a = {
                            type: W.WX_MOBILE,
                            code: i.code,
                            uuid: i.uuid,
                            wxUserInfo: i.userInfo
                        }, u = "wxMobileLoginV2";

                      case 7:
                        if (!i.isErr) {
                            n.next = 53;
                            break;
                        }
                        c = (s = i).error, n.t0 = c.code, n.next = 101190 === n.t0 ? 12 : 101159 === n.t0 ? 21 : 101157 === n.t0 ? 39 : 50;
                        break;

                      case 12:
                        return n.next = 14, p.awrap(w(null === (r = c.data) || void 0 === r ? void 0 : r.requestCode));

                      case 14:
                        return l = n.sent, f = l.requestCode, d = l.responseCode, u = "wxMobileLoginV2", 
                        n.next = 19, p.awrap(an(Object.assign(Object.assign({}, o), {
                            useUserInfo: !1,
                            verify: {
                                responseCode: d,
                                requestCode: f,
                                loginAfterFirstVerify: !0
                            },
                            loginCode: a.code
                        })));

                      case 19:
                        return i = n.sent, n.abrupt("break", 51);

                      case 21:
                        return g = c.data, b = g.username, y = g.mobile, x = g.avatar, k = g.userTicket, 
                        n.next = 24, p.awrap(h({
                            username: b,
                            mobile: y,
                            avatar: x
                        }));

                      case 24:
                        if (O = n.sent, "isMine" !== (I = O.action)) {
                            n.next = 33;
                            break;
                        }
                        return u = "wxMobileLoginV2", n.next = 30, p.awrap(an(Object.assign(Object.assign({}, o), {
                            useUserInfo: !1,
                            checkMobile: {
                                userTicket: k,
                                loginAfterSecondaryMobile: !0
                            },
                            loginCode: a.code
                        })));

                      case 30:
                        i = n.sent, n.next = 38;
                        break;

                      case 33:
                        return u = "ticketLogin", n.next = 36, p.awrap(rn({
                            userTicket: k
                        }));

                      case 36:
                        _ = n.sent, i = Object.assign(Object.assign({}, _), {
                            loginInfo: _.user
                        });

                      case 38:
                        return n.abrupt("break", 51);

                      case 39:
                        return P = i.error.data, f = P.requestCode, k = P.userTicket, n.next = 42, p.awrap(v({
                            requestCode: f
                        }));

                      case 42:
                        return C = n.sent, d = C.responseCode, u = "verifyLogin", n.next = 47, p.awrap(tn(Object.assign(Object.assign({}, o), {
                            requestCode: f,
                            responseCode: d,
                            userTicket: k
                        })));

                      case 47:
                        return _ = n.sent, i = Object.assign(Object.assign({}, _), {
                            loginInfo: _.user
                        }), n.abrupt("break", 51);

                      case 50:
                        throw new N("wxMobileLogin error", c, JSON.stringify({
                            mobileLoginOption: o,
                            lastCalled: u,
                            tempInfo: a,
                            result: i
                        }));

                      case 51:
                        n.next = 7;
                        break;

                      case 53:
                        return S = i, j = S.loginInfo, (T = Object.assign(Object.assign({}, a), j)).openIdCipher || (T.openIdCipher = "test"), 
                        n.next = 58, p.awrap(Cn(T));

                      case 58:
                        return n.abrupt("return", n.sent);

                      case 61:
                        if (n.prev = 61, n.t1 = n.catch(0), 403 !== n.t1.code) {
                            n.next = 65;
                            break;
                        }
                        return n.abrupt("return", m({}).then(function() {
                            return e({
                                iv: E,
                                encryptedData: R
                            }, t, L, A, U);
                        }));

                      case 65:
                        if (!F.errorReport) {
                            n.next = 71;
                            break;
                        }
                        return n.next = 68, p.awrap(Pn(n.t1));

                      case 68:
                        throw n.sent;

                      case 71:
                        return n.abrupt("return", Pn(n.t1));

                      case 72:
                      case "end":
                        return n.stop();
                    }
                }, null, null, [ [ 0, 61 ] ], Promise);
            }, ft = function(e, n) {
                var t = {};
                for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && n.indexOf(r) < 0 && (t[r] = e[r]);
                if (null != e && "function" == typeof Object.getOwnPropertySymbols) for (var o = 0, r = Object.getOwnPropertySymbols(e); o < r.length; o++) n.indexOf(r[o]) < 0 && Object.prototype.propertyIsEnumerable.call(e, r[o]) && (t[r[o]] = e[r[o]]);
                return t;
            }, pt = function e() {
                var n, t, r, o, i, a, u, s, c, l, f, g, b, h, v, w, y, m, x, k, O, I, _, P, S = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                return p.async(function(j) {
                    for (;;) switch (j.prev = j.next) {
                      case 0:
                        return n = S.bind, t = void 0 === n || n, r = S.navType, o = S.slient, i = void 0 === o || o, 
                        a = S.session, u = void 0 === a ? e[oe.create]() : a, s = S.redirectUrl, c = S.waitBack, 
                        l = ft(S, [ "bind", "navType", "slient", "session", "redirectUrl", "waitBack" ]), 
                        null == S.slient && null != S.silent && console.warn("静默登陆接收的参数是slient（错误拼写），不要传入silent（正确拼写）"), 
                        f = !1, g = !1, u.redirectUrl = s, u.waitBack = c, t && (f = r === qe.redirectTo, 
                        g = r === qe.reLaunch), i || he(U.tips.logining, "loading", 60010), j.prev = 8, 
                        j.next = 11, p.awrap((i ? sn : un)(l));

                      case 11:
                        if (b = j.sent, h = b.isErr, v = b.code, w = b.uuid, y = b.userInfo, m = h ? b.error : b.loginInfo, 
                        x = m.openId, k = m.openIdCipher, O = void 0 === k ? "test" : k, I = m.unionId, 
                        _ = {
                            code: v,
                            uuid: w,
                            openId: x,
                            openIdCipher: O,
                            unionId: I,
                            wxUserInfo: y
                        }, u.data = Object.assign(Object.assign({}, b), {
                            loginInfo: m
                        }), !h) {
                            j.next = 29;
                            break;
                        }
                        if (u._state(Ee.BINDING, u.data), !i && d.hideToast(), t) {
                            j.next = 22;
                            break;
                        }
                        return j.abrupt("return", Object.assign(Object.assign({}, _), {
                            error: b.error
                        }));

                      case 22:
                        return P = Object.assign(Object.assign({
                            openId: x
                        }, y && {
                            userInfo: y
                        }), l), j.next = 25, p.awrap(me(K.bindRoute + "?" + (0, C.stringify)(P), K.bindRoute.substr(1), f, g));

                      case 25:
                        return d.hideToast(), j.next = 28, p.awrap(new Promise(function(e, n) {
                            u.resolve = e, u.reject = n;
                        }));

                      case 28:
                        return j.abrupt("return", j.sent);

                      case 29:
                        return d.hideToast(), j.next = 32, p.awrap(Cn(Object.assign(Object.assign({}, _), m)));

                      case 32:
                        return j.abrupt("return", j.sent);

                      case 35:
                        if (j.prev = 35, j.t0 = j.catch(8), !F.errorReport) {
                            j.next = 43;
                            break;
                        }
                        return j.next = 40, p.awrap(Pn(j.t0, i));

                      case 40:
                        throw j.sent;

                      case 43:
                        Pn(j.t0, i);

                      case 44:
                      case "end":
                        return j.stop();
                    }
                }, null, null, [ [ 8, 35 ] ], Promise);
            };
            pt[oe.create] = function() {
                var e = Bn(W.WXV2);
                return e.type === W.WXV2 ? e : Xe.session = new Ve(W.WXV2, Ee.AUTH, 6e5);
            };
            var dt = function e() {
                var n, t, r, o, i = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                return p.async(function(a) {
                    for (;;) switch (a.prev = a.next) {
                      case 0:
                        if (n = i.token) {
                            a.next = 4;
                            break;
                        }
                        return console.error("changeBindPhone方法中token参数是必须的"), a.abrupt("return");

                      case 4:
                        return t = i.uuid, r = i.session || e[oe.create](), r.waitBack = !0, o = K.changeBindPhoneRoute + "?token=" + n + "&uuid=" + t, 
                        a.next = 10, p.awrap(me(o));

                      case 10:
                        return a.next = 12, p.awrap(new Promise(function(e, n) {
                            r.resolve = e, r.reject = n;
                        }));

                      case 12:
                        return a.abrupt("return", a.sent);

                      case 13:
                      case "end":
                        return a.stop();
                    }
                }, null, null, null, Promise);
            };
            dt[oe.create] = function() {
                return ze(), Bn(W.CHANGE_BIND);
            };
            var gt = function(e) {
                var n, t, r, o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : F.appName, i = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
                return p.async(function(a) {
                    for (;;) switch (a.prev = a.next) {
                      case 0:
                        if (e) {
                            a.next = 16;
                            break;
                        }
                        return a.next = 3, p.awrap(Tn(!1, !1));

                      case 3:
                        if (a.t0 = a.sent, a.t0) {
                            a.next = 6;
                            break;
                        }
                        a.t0 = {};

                      case 6:
                        if (t = a.t0, r = t.token) {
                            a.next = 13;
                            break;
                        }
                        return On(!0), a.abrupt("return", !0);

                      case 13:
                        n = r;

                      case 14:
                        a.next = 17;
                        break;

                      case 16:
                        n = e;

                      case 17:
                        return a.next = 19, p.awrap(Ke(Ze("logout"), {
                            bypass: !0,
                            method: "POST",
                            type: "form",
                            data: {
                                token: n,
                                appName: o,
                                unbind_openid: i
                            }
                        }).then(function(e) {
                            return En().catch(c).then(function() {
                                return e.result;
                            });
                        }).catch(function(e) {
                            return console.log(e), En().catch(c).then(function() {
                                return !1;
                            });
                        }));

                      case 19:
                        return a.abrupt("return", a.sent);

                      case 20:
                      case "end":
                        return a.stop();
                    }
                }, null, null, null, Promise);
            }, bt = function(e) {
                var n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : F.appName;
                return Ke(Ze("islogout"), {
                    bypass: !0,
                    method: "POST",
                    type: "form",
                    data: {
                        userId: e,
                        appName: n
                    }
                }).then(function(e) {
                    if (e.error) throw new N(Ze("islogout"), e.error);
                    return e.result;
                }).catch(function(e) {
                    console.log(e);
                });
            }, ht = function() {
                return p.async(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (!F.persistKey) {
                            e.next = 3;
                            break;
                        }
                        return e.next = 3, p.awrap(de(F.persistKey).catch(c));

                      case 3:
                        return e.next = 5, p.awrap(be(te.unlockAccount));

                      case 5:
                      case "end":
                        return e.stop();
                    }
                }, null, null, null, Promise);
            }, vt = function(e) {
                return p.async(function(n) {
                    for (;;) switch (n.prev = n.next) {
                      case 0:
                        return n.next = 2, p.awrap(zn(e, !0));

                      case 2:
                        return n.abrupt("return", n.sent);

                      case 3:
                      case "end":
                        return n.stop();
                    }
                }, null, null, null, Promise);
            };
            vt[oe.create] = function() {
                return Bn(W.LOGIN);
            };
            var wt = function(e) {
                return En().then(function() {
                    return vt(e);
                });
            }, yt = null, mt = null, xt = function() {
                return yt;
            }, kt = function() {
                return mt;
            }, Ot = {
                data: {
                    webViewSrc: ""
                },
                onLoad: function(e) {
                    var n = this;
                    return function() {
                        var t;
                        return p.async(function(r) {
                            for (;;) switch (r.prev = r.next) {
                              case 0:
                                console.log("options", e), t = "";
                                try {
                                    t = decodeURIComponent(e.src);
                                } catch (e) {
                                    console.log(e), t = ie.protocolList[0].url;
                                }
                                n.setData({
                                    webViewSrc: t
                                });

                              case 4:
                              case "end":
                                return r.stop();
                            }
                        }, null, null, null, Promise);
                    }();
                },
                onShow: function() {},
                onUnload: function() {}
            }, It = "https://verify.meituan.com", _t = "dev" === B.env ? "http://verify.inf.dev.meituan.com" : It, Pt = function() {
                return "dev" === Ce() ? "http://verify.inf.dev.meituan.com" : "test" === Ce() ? "http://verify.inf.test.meituan.com" : "staging" === Ce() ? "https://verify-test.meituan.com" : It;
            }, Ct = function() {
                return Pt() + "/v2/ext_api/page_data";
            }, St = function(e) {
                return Pt() + "/v2/ext_api/" + e + "/info";
            }, jt = function(e) {
                return Pt() + "/v2/ext_api/" + e + "/verify";
            }, Tt = void 0, Et = function() {
                try {
                    return Tt || F.wxInfoKey && d.getStorageSync(F.wxInfoKey) || null;
                } catch (e) {
                    return console.error(e), null;
                }
            }, Rt = function() {
                var e, n = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0];
                return p.async(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        if (!("number" == typeof n && n <= 0)) {
                            t.next = 2;
                            break;
                        }
                        throw new A("getWxInfo 的参数check必须大于0", void 0, 121);

                      case 2:
                        if (!Tt) {
                            t.next = 4;
                            break;
                        }
                        return t.abrupt("return", Tt);

                      case 4:
                        if (!F.wxInfoKey) {
                            t.next = 11;
                            break;
                        }
                        return t.next = 7, p.awrap(fe(F.wxInfoKey).catch(c));

                      case 7:
                        if (!(e = t.sent)) {
                            t.next = 11;
                            break;
                        }
                        if (!(!1 === n || "number" == typeof n && 24 * n * 3600 * 1e3 >= Date.now() - e.fetchTime)) {
                            t.next = 11;
                            break;
                        }
                        return t.abrupt("return", e);

                      case 11:
                        return t.next = 13, p.awrap(k());

                      case 13:
                        return t.abrupt("return", Tt = t.sent);

                      case 14:
                      case "end":
                        return t.stop();
                    }
                }, null, null, null, Promise);
            }, Lt = function(e) {
                var n, t;
                return p.async(function(r) {
                    for (;;) switch (r.prev = r.next) {
                      case 0:
                        if (e.avatarUrl || e.nickName) {
                            r.next = 2;
                            break;
                        }
                        throw new A("updateWxInfo 传入的参数不对: " + JSON.stringify(e), void 0, 122);

                      case 2:
                        return r.next = 4, p.awrap(wn(e));

                      case 4:
                        if (n = r.sent, !x(n)) {
                            r.next = 11;
                            break;
                        }
                        if (t = Date.now(), !F.wxInfoKey) {
                            r.next = 10;
                            break;
                        }
                        return r.next = 10, p.awrap(pe(F.wxInfoKey, Object.assign(Object.assign({}, n), {
                            fetchTime: t
                        })).catch(c));

                      case 10:
                        return r.abrupt("return", Tt = Object.assign(Object.assign({}, n), {
                            fetchTime: t
                        }));

                      case 11:
                        throw new A("updateWxAppData返回的数据格式不对：" + JSON.stringify(n), void 0, 123);

                      case 12:
                      case "end":
                        return r.stop();
                    }
                }, null, null, null, Promise);
            }, Nt = void 0, At = function() {
                try {
                    return Nt || F.mtInfoKey && d.getStorageSync(F.mtInfoKey) || null;
                } catch (e) {
                    return console.error(e), null;
                }
            }, Ut = function(e) {
                var n, t = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
                return p.async(function(r) {
                    for (;;) switch (r.prev = r.next) {
                      case 0:
                        if (!Nt || !1 !== t) {
                            r.next = 2;
                            break;
                        }
                        return r.abrupt("return", Nt);

                      case 2:
                        if (!F.mtInfoKey) {
                            r.next = 18;
                            break;
                        }
                        return r.next = 5, p.awrap(fe(F.mtInfoKey).catch(c));

                      case 5:
                        if (!(n = r.sent)) {
                            r.next = 18;
                            break;
                        }
                        if (!(!1 === t || "number" == typeof t && 24 * t * 3600 * 1e3 > Date.now() - n.fetchTime)) {
                            r.next = 11;
                            break;
                        }
                        return r.abrupt("return", n);

                      case 11:
                        if ("number" != typeof t || void 0 !== e) {
                            r.next = 13;
                            break;
                        }
                        return r.abrupt("return", null);

                      case 13:
                        if (e) {
                            r.next = 15;
                            break;
                        }
                        throw new A("getMtInfo 将要从后端获取数据，但token未传", void 0, 115);

                      case 15:
                        return r.next = 17, p.awrap(O(e));

                      case 17:
                        return r.abrupt("return", Nt = r.sent);

                      case 18:
                        if (void 0 !== e) {
                            r.next = 22;
                            break;
                        }
                        r.t0 = null, r.next = 25;
                        break;

                      case 22:
                        return r.next = 24, p.awrap(O(e));

                      case 24:
                        r.t0 = Nt = r.sent;

                      case 25:
                        return r.abrupt("return", r.t0);

                      case 26:
                      case "end":
                        return r.stop();
                    }
                }, null, null, null, Promise);
            }, Bt = function(e, n) {
                var t, r, o, i;
                return p.async(function(a) {
                    for (;;) switch (a.prev = a.next) {
                      case 0:
                        if (t = n.username, r = n.avatar, e && (t || r)) {
                            a.next = 3;
                            break;
                        }
                        throw new A("updateMtInfo 参数传递错误", void 0, 117);

                      case 3:
                        return a.next = 5, p.awrap(xn(e, {
                            username: t,
                            avatar: r
                        }));

                      case 5:
                        if (o = a.sent, !I(o)) {
                            a.next = 12;
                            break;
                        }
                        if (i = Date.now(), !F.mtInfoKey) {
                            a.next = 11;
                            break;
                        }
                        return a.next = 11, p.awrap(pe(F.mtInfoKey, Object.assign(Object.assign({}, o), {
                            fetchTime: i
                        })).catch(c));

                      case 11:
                        return a.abrupt("return", Nt = Object.assign(Object.assign({}, o), {
                            fetchTime: i
                        }));

                      case 12:
                        throw new A("updateMtUserInfo 返回的数据格式不对: " + JSON.stringify(o) + " ", void 0, 118);

                      case 13:
                      case "end":
                        return a.stop();
                    }
                }, null, null, null, Promise);
            }, Dt = function(e) {
                return Ke(Ct(), {
                    method: "POST",
                    data: {
                        requestCode: e
                    },
                    type: "form"
                }).then(function(n) {
                    var t = n.status, r = n.error;
                    if (0 === t && r) throw new N(Ct(), r, JSON.stringify({
                        requestCode: e
                    }));
                    return n;
                });
            }, Ft = function(e, n) {
                var t = Object.assign(n, {});
                return 4 === t.id && (t.moduleEnable = !0), Ke(St(e), {
                    method: "POST",
                    data: t,
                    type: "form"
                });
            }, Kt = function(e, n) {
                if (40 === n.id) {
                    n.voicecode = n.smscode;
                    try {
                        delete n.smscode;
                    } catch (e) {
                        console.log(e);
                    }
                }
                var t = Object.assign(n, {}), r = jt(e);
                return Ke(r, {
                    method: "POST",
                    data: t,
                    type: "form"
                }).then(function(e) {
                    var n = e.status, o = e.error;
                    if (0 === n && o) throw new N(r, o, JSON.stringify(t));
                    return e;
                });
            }, Mt = require("../../npm/@mtfe/mt-weapp-url/parse.js"), Wt = function(e) {
                var n, t, r, o, i, a, u, s, c;
                return p.async(function(l) {
                    for (;;) switch (l.prev = l.next) {
                      case 0:
                        return n = e.risk_platform, t = e.risk_partner, r = e.risk_app, o = e.token, i = e.uuid, 
                        a = e.sdkVersion, u = e.version_name, s = {
                            risk_platform: n,
                            risk_partner: t,
                            risk_app: r,
                            version_name: u,
                            sdkVersion: a
                        }, l.t0 = o, l.next = 5, p.awrap(Ue(i));

                      case 5:
                        return l.t1 = l.sent, l.next = 8, p.awrap(De());

                      case 8:
                        return l.t2 = l.sent, c = {
                            token: l.t0,
                            uuid: l.t1,
                            wechatFingerprint: l.t2
                        }, l.abrupt("return", Ke(Ze("smartcheck"), {
                            method: "post",
                            type: "form",
                            query: s,
                            data: c
                        }).then(function(e) {
                            var n = e.error;
                            if (n.data) return n.data;
                            throw new N(Ze("smartcheck"), n, JSON.stringify({
                                query: s,
                                data: c
                            }));
                        }));

                      case 11:
                      case "end":
                        return l.stop();
                    }
                }, null, null, null, Promise);
            }, qt = function(e) {
                var n, t, r, o, i, a, u, s, c, l, f, d;
                return p.async(function(g) {
                    for (;;) switch (g.prev = g.next) {
                      case 0:
                        return n = e.mobile, t = e.countryCode, r = void 0 === t ? 86 : t, o = e.token, 
                        i = e.confirm, a = void 0 === i ? 0 : i, u = e.requestCode, s = e.ticket, c = e.responseCode, 
                        l = e.uuid, g.next = 3, p.awrap(Ue(l));

                      case 3:
                        return g.t0 = g.sent, f = {
                            uuid: g.t0
                        }, d = {
                            mobile: n,
                            countryCode: r,
                            token: o,
                            confirm: a,
                            ticket: s
                        }, u && (d.requestCode = u), u && (d.responseCode = c), g.abrupt("return", Ke(Ze("sendnewcode"), {
                            method: "post",
                            type: "form",
                            query: f,
                            data: d
                        }).then(function(e) {
                            console.log("res===>", e);
                            var n = e.error;
                            if (n.data) return n.data;
                            throw new N(Ze("sendnewcode"), n, JSON.stringify({
                                query: f,
                                data: d
                            }));
                        }));

                      case 9:
                      case "end":
                        return g.stop();
                    }
                }, null, null, null, Promise);
            }, Vt = function(e) {
                var n, t, r, o, i, a, u, s, c, l, f, d, g, b, h, v, w;
                return p.async(function(y) {
                    for (;;) switch (y.prev = y.next) {
                      case 0:
                        return n = e.mobile, t = e.token, r = e.requestCode, o = e.responseCode, i = e.ticket, 
                        a = e.risk_platform, u = e.risk_partner, s = e.risk_app, c = e.version_name, l = e.sdkVersion, 
                        f = e.uuid, d = e.token_id, g = void 0 === d ? "" : d, b = e.device_type, h = e.device_os, 
                        y.next = 3, p.awrap(Ue(f));

                      case 3:
                        return y.t0 = y.sent, y.t1 = a, y.t2 = u, y.t3 = s, y.t4 = c, y.t5 = l, y.t6 = g, 
                        v = {
                            uuid: y.t0,
                            risk_platform: y.t1,
                            risk_partner: y.t2,
                            risk_app: y.t3,
                            version_name: y.t4,
                            sdkVersion: y.t5,
                            token_id: y.t6
                        }, y.t7 = n, y.t8 = r, y.t9 = t, y.t10 = i, y.next = 17, p.awrap(De());

                      case 17:
                        return y.t11 = y.sent, y.t12 = b, y.t13 = h, w = {
                            mobile: y.t7,
                            requestCode: y.t8,
                            token: y.t9,
                            ticket: y.t10,
                            wechatFingerprint: y.t11,
                            device_type: y.t12,
                            device_os: y.t13
                        }, o && (w.responseCode = o), y.abrupt("return", Ke(Ze("verifynew"), {
                            method: "post",
                            type: "form",
                            query: v,
                            data: w
                        }).then(function(e) {
                            console.log("res===>", e);
                            var n = e.data, t = e.error;
                            if (n) return n;
                            throw new N(Ze("sendnewcode"), t, JSON.stringify({
                                query: v,
                                data: w
                            }));
                        }));

                      case 23:
                      case "end":
                        return y.stop();
                    }
                }, null, null, null, Promise);
            }, Jt = function(e, n) {
                var t, r, o, i, a, u, s, c;
                return p.async(function(l) {
                    for (;;) switch (l.prev = l.next) {
                      case 0:
                        return t = n.code, l.next = 3, p.awrap(le(t));

                      case 3:
                        return r = l.sent, l.next = 6, p.awrap(ke());

                      case 6:
                        return o = l.sent, i = o.rawData, a = o.signature, u = o.iv, s = o.encryptedData, 
                        l.next = 13, p.awrap(Ke(Ze("updatewxuserinfo"), {
                            method: "POST",
                            type: "form",
                            data: {
                                appName: e,
                                code: r,
                                iv: u,
                                encryptedData: s,
                                rawData: i,
                                signature: a
                            }
                        }));

                      case 13:
                        if (!(c = l.sent).uniqueid) {
                            l.next = 16;
                            break;
                        }
                        return l.abrupt("return", c);

                      case 16:
                        throw new N(Ze("updatewxuserinfo"), c.error);

                      case 17:
                      case "end":
                        return l.stop();
                    }
                }, null, null, null, Promise);
            }, Gt = function(e) {
                return Jt(F.appName, e || {});
            }, Ht = function(e) {
                var n;
                return p.async(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return t.next = 2, p.awrap(Ke(Ze("getwxuserinfo"), {
                            method: "GET",
                            data: Object.assign(Object.assign({}, e), {
                                thirdType: "weixin"
                            })
                        }));

                      case 2:
                        if (!(n = t.sent).uniqueid) {
                            t.next = 5;
                            break;
                        }
                        return t.abrupt("return", n);

                      case 5:
                        throw new N(Ze("getwxuserinfo"), n.error);

                      case 6:
                      case "end":
                        return t.stop();
                    }
                }, null, null, null, Promise);
            };
        },
        769: function(e) {
            e.exports = {
                route: "/login",
                env: "",
                api: "",
                promise: null,
                showModal: {
                    confirmColor: "#3cc51f",
                    confirmText: "确定"
                },
                appConfig: {
                    appName: "group",
                    appId: "",
                    risk_app: -1,
                    risk_platform: 0,
                    risk_partner: 0,
                    risk_smsTemplateId: 0,
                    risk_smsPrefixId: 0,
                    persistKey: "logindata",
                    version_name: "",
                    joinkey: "",
                    _errorReport: !1,
                    onPageErr: null,
                    get errorReport() {
                        return this._errorReport;
                    },
                    set errorReport(e) {
                        this._errorReport = e;
                    },
                    get wxIdsKey() {
                        return this.persistKey && "loginsdk-" + this.persistKey + "-wxIds";
                    },
                    set wxIdsKey(e) {},
                    get wxInfoKey() {
                        return this.persistKey && "loginsdk-" + this.persistKey + "-wxInfo";
                    },
                    set wxInfoKey(e) {},
                    get mtInfoKey() {
                        return this.persistKey && "loginsdk-" + this.persistKey + "-mtInfo";
                    },
                    set mtInfoKey(e) {}
                },
                entryPageOption: {
                    title: "登录",
                    imageSrc: "https://p0.meituan.net/travelcube/da6c05c03bf81aaf5bc026b4b4fe9ce112319.png",
                    imageMode: "aspectFit",
                    wxLoginText: "微信用户一键登录",
                    wxLoginStyle: "background-image: -webkit-linear-gradient(left top, #FFD100, #FFD100); color: black;border:none",
                    mobileLoginText: "手机号登录/注册",
                    mobileLoginStyle: "",
                    titleBarTextColor: "#000000",
                    titleBarBkgColor: "#ffffff"
                },
                bindPageOption: {
                    title: "绑定手机",
                    imgSrc: "https://p0.meituan.net/travelcube/da6c05c03bf81aaf5bc026b4b4fe9ce112319.png",
                    imgMode: "aspectFit",
                    sendCodeActiveStyle: "",
                    loginActiveStyle: "background-image: -webkit-linear-gradient(left top, #FFD100, #FFD100); color: rgba(0,0,0)",
                    loginText: "登录",
                    voiceTipText: "账号风险提示：我们检测到您的账户有风险，会向您发送语音验证码，请在接听后将验证码输入完成账号验证",
                    voiceTipStyle: "color: red",
                    titleBarTextColor: "#000000",
                    titleBarBkgColor: "#ffffff"
                },
                authrizePageOption: {
                    tipText: "请完成微信授权以继续使用",
                    btn: {
                        style: "background-image: -webkit-linear-gradient(left top, #FFD000, #FFBD00); color: #222;border:none",
                        text: "授权微信用户信息"
                    },
                    imageSrc: "https://p0.meituan.net/travelcube/d8ebb44535845a44e183929eaba1cb0724896.png",
                    imageMode: "aspectFit"
                },
                changeBindPageOption: {
                    getNewCodeBtnText: "获取验证码",
                    getNewCodeBtnStyle: "background-image: -webkit-linear-gradient(left top, #FFD000, #FFBD00); color: #222;border:none",
                    sendCodeBtnText: "获取验证码",
                    sendCodeBtnStyle: "color: #FE8C00",
                    changeBtnText: "立即更换",
                    changeBtnStyle: "background-image: -webkit-linear-gradient(left top, #FFD000, #FFBD00); color: #222;border:none"
                },
                tips: {
                    smsCodeSent: "验证码已发送",
                    logining: "登录中...",
                    loginSuccess: "登录成功",
                    loginParamLoss: "验证信息丢失，请重新发送验证码！",
                    relogin: "您已登录，是否重新登录？",
                    refuseUserInfoAuth: "您已拒绝授权用户信息，请重新点击并授权！",
                    refusePhoneNumberAuth: "您已拒绝授权，请重新点击并授权！",
                    verifyFailed: "验证失败",
                    networkTimeout: "网络连接超时，请重试",
                    illegalVerifyType: "验证方式id不合法，请重试或联系客服",
                    illegalPhoneNumber: "手机号输入不正确，请重新输入",
                    illegalSmsCode: "请输入正确的6位验证码",
                    illegalAuthInfo: "获取的授权信息不正确，请重试",
                    twiceVerifyFail: "二次验证失败，",
                    changeBindFail: "换绑失败，请稍后重试",
                    changeBindSucc: "换绑成功！",
                    noConfirm: "请阅读并勾选底部协议",
                    unlockAccount: "由于您的账号近期存在异常操作，为确保账号安全，已将账号锁定，请去美团app解锁"
                },
                protocolConfig: {
                    show: !0,
                    style: "color: #999",
                    preText: "登录代表您已同意",
                    separator: "、",
                    protocolList: [ {
                        id: "userprotocol",
                        url: "https://rules-center.meituan.com/m/detail/guize/4",
                        text: "美团用户协议",
                        style: "color: #FE8C00; display: inline-block"
                    }, {
                        id: "privacy",
                        url: "https://rules-center.meituan.com/m/detail/2",
                        text: "隐私协议",
                        style: "color: #FE8C00; display: inline-block"
                    } ]
                }
            };
        },
        0: function(e) {
            var n = function(e) {
                var n = {};
                return [ {
                    paths: {
                        updatewxuserinfo: "/user/thirdinfo/updateweappuserinfo",
                        getmtuserinfo: "/user/v1/info",
                        getwxinfo: "/user/thirdinfo/getweappuserinfo",
                        updatewxinfo: "/user/thirdinfo/updateweappuserinfo",
                        getwxuserinfo: "/user/thirdinfo/getwechatuserinfo",
                        updatemtuserinfo: "/user/settings",
                        wxmobilelogin: "/user/v2/weappgetmobilelogin",
                        wxlogin: "/user/v2/weapplogin",
                        wxbindapply: "/user/v2/weappbindmobileloginapply",
                        wxbind: "/user/v2/weappbindmobilelogin",
                        wxticketlogin: "/user/v2/weappticketlogin",
                        wxslientlogin: "/user/v1/weappsilentlogin",
                        smartcheck: "/user/v3/riskcheck",
                        sendnewcode: "/user/v3/sendnew",
                        verifynew: "/user/v4/verifynew",
                        logout: "/thirdlogin/wechatapplogout",
                        islogout: "/thirdlogin/isWechatAppLogout"
                    },
                    domain: {
                        prod: "open.meituan.com",
                        staging: "open.wpt.st.sankuai.com",
                        dev: "open.wpt.dev.sankuai.com",
                        test: "open.wpt.test.sankuai.com"
                    }
                }, {
                    paths: {
                        mobileloginapply: "/api/v3/account/mobileloginapply",
                        mobilelogin: "/api/v3/account/mobilelogin",
                        verifylogin: "/api/v1/account/verifylogin",
                        ticketlogin: "/api/v1/account/ticketlogin"
                    },
                    domain: {
                        prod: "passport.meituan.com",
                        staging: "passport.wpt.st.sankuai.com",
                        dev: "passport.wpt.dev.sankuai.com",
                        test: "passport.wpt.test.sankuai.com"
                    }
                } ].forEach(function(e) {
                    Object.keys(e.domain).forEach(function(t) {
                        Object.keys(e.paths).forEach(function(r) {
                            var o;
                            null !== (o = n[t]) && void 0 !== o || (n[t] = {}), n[t][r] = ("prod" === t ? "https://" : "http://") + e.domain[t] + e.paths[r];
                        });
                    });
                }), n;
            }();
            console.log("urls:", n), e.exports = n;
        },
        778: function() {
            String.prototype.startsWith || (String.prototype.startsWith = function(e, n) {
                return this.substr(!n || n < 0 ? 0 : +n, e.length) === e;
            });
        }
    }, u = {};
    return i.n = function(e) {
        var n = e && e.__esModule ? function() {
            return e.default;
        } : function() {
            return e;
        };
        return i.d(n, {
            a: n
        }), n;
    }, i.d = function(e, n) {
        for (var t in n) i.o(n, t) && !i.o(e, t) && Object.defineProperty(e, t, {
            enumerable: !0,
            get: n[t]
        });
    }, i.o = function(e, n) {
        return Object.prototype.hasOwnProperty.call(e, n);
    }, i.r = function(e) {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(e, "__esModule", {
            value: !0
        });
    }, i(948);
}());