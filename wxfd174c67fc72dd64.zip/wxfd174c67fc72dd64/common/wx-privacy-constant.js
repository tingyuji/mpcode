Object.defineProperty(exports, "__esModule", {
    value: !0
});

var d = exports.WX_SCENETOKENS = void 0;

!function(d) {
    d.GETLOCATION_HOME = "dd-b2645346254a78b0", d.GETLOCATION_DETAIL = "dd-e33d5be8bc93b0fe", 
    d.GETLOCATION_FEEDS = "dd-8b6f3b6ba23ad4bd", d.GETLOCATION_SHOPLIST = "dd-4863aaed3faa98b2", 
    d.CHOOSEIMAGE_TALENT = "dd-b6b182c537eb2b15", d.CHOOSEIMAGE_AVATAR = "dd-784c8c6c65005ec8", 
    d.PREVIEWIMAGE = "dd-646048ff6362531b", d.SAVEIMAGETOPHOTOSALBUM_PUBLISH = "dd-b9a457871ceedfbe", 
    d.SETCLIPBOARD_CONTACT = "dd-116e5952da72469f", d.SETCLIPBOARD_ASSISTANT = "dd-6cec12cc0f3512db", 
    d.SETCLIPBOARD_SHARELINK = "dd-e61a2ad31b748920";
}(d || (exports.WX_SCENETOKENS = d = {})), exports.default = {};