var e = require("../npm/@analytics/wechat-sdk/lib/index.js"), t = require("../npm/@mtfe/mt-weapp-url/url.js").stringify;

!function() {
    var r = e.pageView;
    e.pageView = function(i) {
        var o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, s = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
        try {
            o.custom = o.custom || {};
            var a = (getCurrentPages() || []).pop() || {}, n = (a.route || "") + "?" + t(a.options || {});
            Object.assign(o.custom, {
                url: n
            }), r.call(e, i, o, s);
        } catch (t) {
            r.call(e, i, o, s), console.error(t);
        }
    };
}(), module.exports = e;