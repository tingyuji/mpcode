function t() {
    var t = function(t) {
        return getApp().addError(function(r, e) {
            return {
                msg: t,
                type: r.RESOURCE_ERROR,
                level: e.WARN
            };
        });
    };
    return (0, n.getGeoByIp)().then(function(t) {
        var r = t.openCity;
        return Object.assign(r, {
            id: r.mtId
        });
    }).catch(function() {
        return t("小程序IP定位失败"), getApp().getCityInfo().then(function(t) {
            if (t && (t.id || 0 === t.id)) return t;
            throw Error();
        }).catch(function() {
            return t("小程序getCityInfo 定位失败"), i();
        });
    });
}

function r() {
    return getApp().getAllCities().then(function(t) {
        var r = t.alphabet2CityVO;
        return Object.entries(r || {}).reduce(function(t, r) {
            var n = e(r, 2), i = (n[0], n[1]);
            return t.concat(i);
        }, []);
    }).catch(function() {
        return [];
    });
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getDefaultCity = void 0;

var e = function() {
    function t(t, r) {
        var e = [], n = !0, i = !1, o = void 0;
        try {
            for (var u, c = t[Symbol.iterator](); !(n = (u = c.next()).done) && (e.push(u.value), 
            !r || e.length !== r); n = !0) ;
        } catch (t) {
            i = !0, o = t;
        } finally {
            try {
                !n && c.return && c.return();
            } finally {
                if (i) throw o;
            }
        }
        return e;
    }
    return function(r, e) {
        if (Array.isArray(r)) return r;
        if (Symbol.iterator in Object(r)) return t(r, e);
        throw new TypeError("Invalid attempt to destructure non-iterable instance");
    };
}();

exports.getUserLocCity = t, exports.getAllCityList = r, exports.getUserInitCity = function() {
    return Promise.all([ r(), t() ]).then(function(t) {
        var r = e(t, 2), n = r[0], o = r[1], u = o.id;
        if (!(u && Array.isArray(n) && n.length)) throw Error();
        return {
            city: n.find(function(t) {
                return t.cityId === u;
            }) || i(),
            locCity: o
        };
    }).catch(i);
};

var n = require("../npm/@mtfe/mt-weapp-city/index.js"), i = exports.getDefaultCity = function() {
    return {
        cityId: 10,
        id: 10,
        cityName: "上海",
        city: "上海"
    };
};

exports.default = {};