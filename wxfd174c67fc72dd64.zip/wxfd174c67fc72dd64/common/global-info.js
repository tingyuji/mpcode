function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getGlobalInfo = void 0, exports.getVersionControl = function() {
    return u().then(function(e) {
        return e.versionVO;
    });
}, exports.updateVersion = function(e) {
    var t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
    o.getStorage({
        key: r.DEBUG_STORE_KEYS.UPDATE_TIPS_VERSION
    }).then(function(e) {
        if ("0.8.2" !== e.data) throw new Error();
    }).catch(function() {
        o.showModal({
            title: "本期功能更新",
            showCancel: !t,
            content: e,
            success: function(e) {
                if (e.confirm) {
                    var t = o.getUpdateManager();
                    t.onUpdateReady(function() {
                        t.applyUpdate();
                    });
                }
            }
        }), o.setStorage({
            key: r.DEBUG_STORE_KEYS.UPDATE_TIPS_VERSION,
            data: "0.8.2"
        });
    });
};

var t = e(require("login")), n = e(require("../api/index")), r = require("./storage-constants"), o = require("../npm/@mtfe/weapp-privacy-api/index.js").default, u = exports.getGlobalInfo = function() {
    var e = null, r = null;
    return function() {
        return e ? Promise.resolve(e) : r || (r = t.default.getWxIds().then(function(o) {
            var u = o.openId;
            return t.default.mtDefaultLogin({
                isBind: !1
            }).then(function() {
                return n.default.getGlobalInfo({
                    openid: u
                }).then(function(t) {
                    return e = t, t;
                });
            }).catch(function() {
                return r = null, null;
            });
        }));
    };
}();