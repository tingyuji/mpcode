(0, require("../npm/@mtfe/weapp-privacy-api/index.js").initPrivacySdk)({
    app: "playgroup_wxapp",
    devMode: !1,
    errorReport: function(r) {
        var e = r.apiName, a = (r.err, r.enablePrivacyAPI), p = r.args;
        getApp().addError(function(r, i) {
            return {
                category: r.JS_ERROR,
                level: i.ERROR,
                msg: "隐私API调用失败",
                custom: {
                    apiName: e,
                    args: p,
                    enablePrivacyAPI: a
                }
            };
        });
    }
});