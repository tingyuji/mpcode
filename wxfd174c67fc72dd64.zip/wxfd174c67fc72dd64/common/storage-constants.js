Object.defineProperty(exports, "__esModule", {
    value: !0
});

exports.DEBUG_STORE_KEYS = {
    SWIMLANE: "__debug-swimlane",
    API: "API",
    LX: "__debug-lx-debug-code",
    HEADERS: "__debug-request-header",
    PANEL: "__debug_panel",
    UPDATE_TIPS_VERSION: "__update_tips_version"
};

exports.default = {};