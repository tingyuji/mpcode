module.exports = Behavior({
    methods: {
        getRect: function(e) {
            var t = this;
            return new Promise(function(n, r) {
                t.createSelectorQuery().select(e).boundingClientRect(function(t) {
                    t ? n(t) : r(new Error("can not find selector: " + e));
                }).exec();
            });
        },
        getAllRects: function(e) {
            var t = this;
            return new Promise(function(n, r) {
                t.createSelectorQuery().selectAll(e).boundingClientRect(function(t) {
                    t && t.lenght > 0 ? n(t) : r(new Error("can not find selector: " + e));
                }).exec();
            });
        }
    }
});