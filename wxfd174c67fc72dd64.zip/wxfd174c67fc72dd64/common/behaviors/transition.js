Object.defineProperty(exports, "__esModule", {
    value: !0
});

var t = function(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}(require("../../utils/raf")), e = function(t) {
    return {
        enter: t + "-enter",
        "enter-active": t + "-enter-active",
        leave: t + "-leave-active",
        "leave-to": t + "-leave-to"
    };
};

exports.default = Behavior({
    properties: {
        show: {
            type: Boolean,
            value: !1,
            observer: "observeShow"
        }
    },
    _status: null,
    _transitionEnd: !1,
    data: {
        display: !1,
        className: ""
    },
    methods: {
        observeShow: function(t, e) {
            if (t !== e) return t ? this.onEnter() : this.onLeave();
        },
        onEnter: function() {
            var a = this, s = this.properties.transition, n = e(s);
            this._status = "enter", (0, t.default)(function() {
                "enter" === a._status && (a.setData({
                    display: !0,
                    className: n.enter
                }), (0, t.default)(function() {
                    "enter" === a._status && (a._transitionEnd = !1, a.setData({
                        className: n["enter-active"]
                    }));
                }));
            });
        },
        onLeave: function() {
            var a = this;
            if (this.data.display) {
                var s = this.properties, n = s.transition, i = s.duration, r = e(n);
                this._status = "leave", (0, t.default)(function() {
                    "leave" === a._status && (a.setData({
                        className: r.leave
                    }), (0, t.default)(function() {
                        "leave" === a._status && (a._transitionEnded = !1, setTimeout(function() {
                            return a.onTransitionEnd();
                        }, i), a.setData({
                            className: r["leave-to"]
                        }));
                    }));
                });
            }
        },
        onTransitionEnd: function() {
            this._transitionEnded || (this._transitionEnded = !0, this.setData({
                display: !1
            }));
        }
    },
    lifetimes: {
        ready: function() {
            !0 === this.properties.show && this.observeShow(!0, !1);
        }
    }
});