Object.defineProperty(exports, "__esModule", {
    value: !0
});

exports.GLOBAL_CITY_SELECTED_CHANGE = "GLOBAL_CITY_SELECTED_CHANGE", exports.LOCAL_CITY_SELECTED_CHANGE = "LOCAL_CITY_SELECTED_CHANGE";

exports.default = {};