function n(n) {
    return n && n.__esModule ? n : {
        default: n
    };
}

function o(n) {
    var o = getApp();
    o && (o.globalData.userInfo = n);
}

function e(n) {
    var e = a.login.createSession();
    e.on(a.SessionEvent.ENTRYPAGEONSHOW, function() {
        console.log("登录入口页 onshow");
    }), e.on(a.SessionEvent.CLICK, function(n) {
        switch (n) {
          case a.API_TYPE.WX_MOBILE:
            console.log("点击微信一键登录");
            break;

          default:
            console.log("点击手机号码登录/注册");
        }
    }), e.on(a.SessionEvent.ALLOWPHONE, function() {
        console.log("用户在登录入口页授权了手机号");
    }), e.on(a.SessionEvent.REFUSEPHONE, function() {
        console.log("用户在登录入口页拒绝授权手机号");
    }), e.on(a.SessionEvent.BINDPAGEONSHOW, function() {
        console.log("绑定手机页/手机登录页 onshow");
    }), e.on(a.SessionEvent.SMSCLICK, function() {
        console.log("<有效点击>发送验证码");
    }), e.on(a.SessionEvent.LOGINCLICK, function() {
        console.log("<有效点击>登录");
    }), e.on(a.SessionEvent.NAVIBACK, function() {
        console.log("用户在登录页面没有登录，回退回来了"), f.emit(g.LOGIN_NAVIBACK);
    });
    var t = (n || {}).bind;
    return new Promise(function(n) {
        a.login({
            session: e,
            bind: void 0 === t || t
        }).then(function(e) {
            e ? (o(e), n(e)) : n("登录失败");
        }).catch(function(n) {
            console.log("mtwxLogin", n);
        });
    });
}

function t(n) {
    return new Promise(function(e) {
        l.mtGetUserInfo({
            success: function(n) {
                n.token = n.userInfo.token, n.userId = n.userInfo.userId, o(n), e(n);
            },
            fail: function() {
                n.isBind ? l.mtLogin({
                    forceNav: !1,
                    success: function() {
                        l.mtGetUserInfo({
                            success: function(n) {
                                n.token = n.userInfo.token, n.userId = n.userInfo.userId, o(n), console.log("MMP强制登陆成功", n), 
                                e(n);
                            },
                            fail: function(n) {
                                console.log("MMP强制登陆失败", n.errMsg), e(n);
                            }
                        });
                    },
                    fail: function(n) {
                        console.log("用户取消登录或其他登录错误", n.errMsg), e(n);
                    }
                }) : (console.log("美团非强制登陆"), e(""));
            }
        });
    });
}

function i(n) {
    return new Promise(function(e) {
        l.getUserInfo({
            success: function(t) {
                0 === Object.keys(t.userInfo).length ? n.isBind ? l.mtLogin({
                    forceNav: !1,
                    success: function() {
                        l.getUserInfo({
                            success: function(n) {
                                n.token = n.userInfo.token, n.userId = n.userInfo.userID || n.userInfo.userId || "", 
                                o(n), console.log("点评MMP强制登陆成功", n), e(n);
                            },
                            fail: function(n) {
                                console.log("点评MMP强制登陆失败", n.errMsg), e(n);
                            }
                        });
                    },
                    fail: function(n) {
                        console.log("点评用户取消登录或其他登录错误", n.errMsg), e(n);
                    }
                }) : (console.log("点评非强制登陆"), e("")) : (t.token = t.userInfo.token, t.userId = t.userInfo.userID || t.userInfo.userId || "", 
                o(t), e(t));
            },
            fail: function() {
                n.isBind ? l.mtLogin({
                    forceNav: !1,
                    success: function() {
                        l.getUserInfo({
                            success: function(n) {
                                n.token = n.userInfo.token, n.userId = n.userInfo.userID || n.userInfo.userId || "", 
                                o(n), console.log("点评MMP强制登陆成功", n), e(n);
                            },
                            fail: function(n) {
                                console.log("点评MMP强制登陆失败", n.errMsg), e(n);
                            }
                        });
                    },
                    fail: function(n) {
                        console.log("点评用户取消登录或其他登录错误", n.errMsg), e(n);
                    }
                }) : (console.log("点评非强制登陆"), e(""));
            }
        });
    });
}

var s = n(require("../npm/@mtfe/wx-jsguard/dist/jsguard.js")), r = n(require("../utils/index")), c = n(require("./config")), u = n(require("./lx")), l = require("../npm/@mtfe/weapp-privacy-api/index.js").default, f = r.default.Event, g = r.default.EVENT_TYPE, a = require("../login/login/login.js");

a.setSdkRoute("/login/login-pages/subpages"), a.config.api = "", a.config.protocolConfig.protocolList = [ {
    id: "userprotocol",
    url: "https://rules-center.meituan.com/m/detail/guize/4",
    text: "美团用户协议",
    style: "display: inline-block; color: #FE8C00"
}, {
    id: "privacy",
    url: "https://rules-center.meituan.com/m/detail/2",
    text: "隐私协议",
    style: "display: inline-block; color: #FE8C00"
} ], a.setYodaRoute("/npm/@mtfe/yoda-static-weapp/yoda_modules/modules/index/index");

var d = s.default.init({
    appid: "wxfd174c67fc72dd64",
    mchid: "250332984"
});

a.setAppConfig({
    appId: "wxfd174c67fc72dd64",
    appName: "play",
    finger: d,
    risk_app: 228,
    risk_platform: 13,
    risk_partner: 715,
    persistKey: "logindata",
    version_name: "15.15.15",
    uuid: u.default.get("lxcuid"),
    token_id: "yBARed0g-D0hZG4UbNn01w"
}), a.setLoginPageOption({
    title: "登录",
    imageSrc: "https://p0.meituan.net/travelcube/da6c05c03bf81aaf5bc026b4b4fe9ce112319.png@660w_525h_80q",
    imageMode: "aspectFit",
    wxLoginText: "微信用户快捷登录",
    wxLoginStyle: "background-image: -webkit-linear-gradient(left top, #FFD000, #FFBD00); color: #222;border:none",
    mobileLoginText: "手机号码登录/注册"
}), "test" === c.default.env ? a.setEnv("test") : a.setEnv(""), module.exports = {
    mtDefaultLogin: function(n) {
        var s = n || {}, r = s.isBind, u = s.bind;
        return new Promise(function(s) {
            "wx" === c.default.platform ? a.getAuthInfo(!0, !0).then(function(n) {
                n ? (o(n), s(n)) : a.wxLogin({
                    slient: !0,
                    bind: !1
                }).then(function(n) {
                    n.error ? (r ? (console.log("用户未登录,即将登陆", n), s(e({
                        bind: void 0 === u || u
                    }))) : s(""), getApp().addError(function(o, e) {
                        if (n.error && 101155 !== n.error.code) return {
                            category: o.BUSINESS_ERROR,
                            level: e.ERROR,
                            msg: n.error.message || "用户登陆失败",
                            custom: {
                                details: n.error
                            }
                        };
                    })) : (console.log("用户已经静默登录成功", n), o(n), s(n));
                });
            }).catch(function(n) {
                console.log("getAuthInfo", n), getApp().addError(function(o, e) {
                    return {
                        category: o.BUSINESS_ERROR,
                        level: e.ERROR,
                        msg: "微信登录SDK失败",
                        custom: {
                            error: n.message
                        }
                    };
                });
            }) : s("mt" === c.default.platform ? t(n) : i(n));
        }).then(function(n) {
            return "[object Object]" === toString.call(n) && n.token && f.emit(g.USER_LOGIN, n), 
            n;
        });
    },
    getWxUserInfo: function() {
        return new Promise(function(n) {
            a.utils.getUserInfo().then(function(o) {
                n(o);
            }).catch(function(n) {
                console.log("getWxUserInfo", n);
            });
        });
    },
    loginout: function() {
        return new Promise(function(n) {
            a.logout().then(function(o) {
                n(o);
            }).catch(function(n) {
                console.log("loginout", n);
            });
        });
    },
    getWxInfo: function() {
        return new Promise(function(n) {
            a.getWxInfo().then(function(o) {
                n(o);
            }).catch(function(n) {
                console.log("getWxInfo", n);
            });
        });
    },
    getWxIds: function() {
        return new Promise(function(n) {
            a.getWxIds().then(function(o) {
                n(o);
            }).catch(function(n) {
                console.log("getWxIds", n);
            });
        });
    },
    getMtUserInfo: function(n) {
        return new Promise(function(o) {
            a.getMtInfo(n).then(function(n) {
                o(n);
            }).catch(function(n) {
                console.log("getMtUserInfo", n);
            });
        });
    },
    loginPersistKey: "logindata"
};