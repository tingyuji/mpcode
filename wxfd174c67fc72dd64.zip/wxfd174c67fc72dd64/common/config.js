function t() {
    return new Promise(function(t) {
        i.getLocation({
            type: "wgs84",
            _mt: {
                sceneToken: r.GETLOCATION_HOME
            },
            success: function(n) {
                t(n);
            },
            fail: function(n) {
                t(n.errMsg);
            }
        });
    });
}

function n() {
    return new Promise(function(t) {
        i.getUserInfo({
            success: function(n) {
                var e = n.userInfo && n.userInfo.cityID || "";
                t(e);
            },
            fail: function(n) {
                console.log(n.errMsg, "获取用户信息失败"), t(n);
            }
        });
    });
}

var e = function() {
    function t(t, n) {
        var e = [], i = !0, o = !1, r = void 0;
        try {
            for (var c, a = t[Symbol.iterator](); !(i = (c = a.next()).done) && (e.push(c.value), 
            !n || e.length !== n); i = !0) ;
        } catch (t) {
            o = !0, r = t;
        } finally {
            try {
                !i && a.return && a.return();
            } finally {
                if (o) throw r;
            }
        }
        return e;
    }
    return function(n, e) {
        if (Array.isArray(n)) return n;
        if (Symbol.iterator in Object(n)) return t(n, e);
        throw new TypeError("Invalid attempt to destructure non-iterable instance");
    };
}(), i = require("../npm/@mtfe/weapp-privacy-api/index.js").default, o = require("./storage-constants").DEBUG_STORE_KEYS, r = require("./wx-privacy-constant").WX_SCENETOKENS, c = "production", a = "wx";

"undefined" != typeof mmp && (a = "group" === i.getSystemInfoSync().app ? "mt" : "dp");

var u = "release";

if ("wx" === a) {
    var s = i.getStorageSync(o.API);
    "develop" === (u = i.getAccountInfoSync().miniProgram.envVersion) && (c = s || "production");
}

var m = "dp" === a ? 1 : 2, p = "dp" === a ? 30 : 2, d = 205;

"dp" === a && (d = 100), "mt" === a && (d = 200);

var l = "test" === c ? "https://m.51ping.com" : "https://m.dianping.com", f = "test" === c ? "https://test.i.meituan.com" : "https://i.meituan.com", g = "test" === c ? "https://mapi.51ping.com" : "https://mapi.dianping.com", y = "test" === c ? "https://beta.mapi.meituan.com" : "https://mapi.meituan.com", I = "test" === c ? "https://test.i.meituan.com" : "https://gpower.meituan.com", v = i.getStorageSync(o.SWIMLANE), h = [ "dp", "mt" ].includes(a);

module.exports = {
    env: c,
    isProduction: "production" === c,
    platform: a,
    platformCode: m,
    getMtCityInfo: function() {
        return new Promise(function(t) {
            mmp.getSelectedCityInfo({
                success: function(n) {
                    n.lat = n.latitude, n.lng = n.longitude, n.cityId = n.id, console.log("美团获取位置信息", n), 
                    t(n);
                },
                fail: function(n) {
                    console.log("美团获取位置信息失败", n.errMsg), t(n);
                }
            });
        });
    },
    getDpCityInfo: function() {
        var i = {}, o = {
            id: 1,
            cityId: 1,
            lat: "",
            lng: ""
        }, r = function() {
            return Promise.all([ n(), t() ]).then(function(t) {
                var n = e(t, 2), r = n[0], c = n[1];
                return i.id = isNaN(r) ? o.cityId : r, i.cityId = isNaN(r) ? o.cityId : r, i.lat = c && c.latitude || "", 
                i.lng = c && c.longitude || "", i;
            }).catch(function() {
                return o;
            });
        };
        return new Promise(function(t) {
            try {
                mmp.getSelectedCityInfo({
                    success: function(n) {
                        n.lat = n.latitude, n.lng = n.longitude, n.cityId = n.id, console.log("点评获取选择城市信息", n), 
                        t(n);
                    },
                    fail: function() {
                        t(r());
                    }
                });
            } catch (t) {
                return console.log("点评 getSelectedCityInfo 获取选择城市信息", t), r();
            }
        });
    },
    uaCode: d,
    dp_domain: l,
    mt_domain: f,
    gpower_domain: I,
    dp_mapi_domain: g,
    mt_mapi_domain: y,
    swimlane: v,
    catId: p,
    location: t,
    miniProgramEnvVersion: u,
    privacySceneToken: "dd-2af4800b91017d20",
    clipboardSceneToken: "dd-0ea38c2b2645878f",
    requestProxyUrlPrefix: "https://yapi.sankuai.com/mock/22114",
    isMMP: h,
    isWX: !h
};