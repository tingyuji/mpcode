function e(e, r) {
    if (!(e instanceof r)) throw new TypeError("Cannot call a class as a function");
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var r = function() {
    function e(e, r) {
        for (var n = 0; n < r.length; n++) {
            var t = r[n];
            t.enumerable = t.enumerable || !1, t.configurable = !0, "value" in t && (t.writable = !0), 
            Object.defineProperty(e, t.key, t);
        }
    }
    return function(r, n, t) {
        return n && e(r.prototype, n), t && e(r, t), r;
    };
}(), n = require("../config"), t = require("./common"), o = require("../../npm/@mtfe/mt-weapp-url/url.js"), a = require("../../npm/regenerator-runtime/runtime.js"), u = function() {
    function u(r) {
        var n = this;
        e(this, u);
        try {
            !function() {
                var e;
                a.async(function(n) {
                    for (;;) switch (n.prev = n.next) {
                      case 0:
                        return n.next = 2, a.awrap(r.call(r, t.Category, t.Level));

                      case 2:
                        (e = n.sent) && this.owlReport(e);

                      case 4:
                      case "end":
                        return n.stop();
                    }
                }, null, n, null, Promise);
            }();
        } catch (e) {
            console.log("addError错误:", e, r);
        }
    }
    return r(u, null, [ {
        key: "createInstance",
        value: function(e) {
            return new u(e);
        }
    } ]), r(u, [ {
        key: "owlReport",
        value: function(e) {
            var r = getApp().owl.error, a = (getApp().globalData || {}).userInfo || {}, u = a.token, c = a.openId, i = e.category, l = void 0 === i ? t.Category.JS_ERROR : i, s = e.level, p = void 0 === s ? t.Level.ERROR : s, f = e.msg, g = e.custom, y = getCurrentPages().map(function(e) {
                return (e.route + "?" + (0, o.stringify)(e.options)).replace(/\?$/, "");
            });
            r.pushError({
                sec_category: "[" + n.platform.toLocaleUpperCase() + "┃" + l + "]:" + f,
                category: l === t.Category.BUSINESS_ERROR ? "customError" : l,
                level: p,
                content: (g ? JSON.stringify(g) + "\n\n" : "") + "用户信息：" + JSON.stringify({
                    openId: c,
                    token: u
                }) + "\n\n页面堆栈: [" + y.join(" ⇨ ") + "]",
                pageUrl: y.pop()
            }, !0);
        }
    } ]), u;
}();

exports.default = u;