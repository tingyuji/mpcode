Object.defineProperty(exports, "__esModule", {
    value: !0
});

var r = exports.Category = void 0;

!function(r) {
    r.AJAX_ERROR = "ajaxError", r.JS_ERROR = "jsError", r.BUSINESS_ERROR = "businessError", 
    r.RESOURCE_ERROR = "resourceError";
}(r || (exports.Category = r = {}));

var e = exports.Level = void 0;

!function(r) {
    r.ERROR = "error", r.WARN = "warn", r.INFO = "info", r.DEBUG = "debug";
}(e || (exports.Level = e = {}));