function t(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.jsGuardInitSync = exports.jsGuardInit = exports.getWxNavigatorBarHeight = exports.parseShortTicketAndRedirect = void 0;

var e = function() {
    function t(t, e) {
        var r = [], n = !0, a = !1, i = void 0;
        try {
            for (var o, u = t[Symbol.iterator](); !(n = (o = u.next()).done) && (r.push(o.value), 
            !e || r.length !== e); n = !0) ;
        } catch (t) {
            a = !0, i = t;
        } finally {
            try {
                !n && u.return && u.return();
            } finally {
                if (a) throw i;
            }
        }
        return r;
    }
    return function(e, r) {
        if (Array.isArray(e)) return e;
        if (Symbol.iterator in Object(e)) return t(e, r);
        throw new TypeError("Invalid attempt to destructure non-iterable instance");
    };
}();

exports.getAllCities = function() {
    return s || (s = a.getCities());
};

var r = require("../npm/@mtfe/mt-weapp-url/url.js"), n = t(require("../npm/@mtfe/wx-jsguard/dist/jsguard.js")), a = function(t) {
    if (t && t.__esModule) return t;
    var e = {};
    if (null != t) for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (e[r] = t[r]);
    return e.default = t, e;
}(require("../api/index")), i = t(require("../custom-tab-bar/config")), o = t(require("./login")), u = require("../npm/@mtfe/weapp-privacy-api/index.js").default, s = null;

exports.parseShortTicketAndRedirect = function() {
    var t = ((arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}) || {}).query, n = null;
    try {
        (n = t.ticket) || (n = (0, r.parse)(decodeURIComponent(t.scene)).ticket);
    } catch (t) {
        console.log(t);
    }
    n && a.parseShortTicket(n).then(function(t) {
        var n = t.page;
        try {
            var a = n.split("?"), o = e(a, 2), s = o[0], l = o[1], c = (0, r.parse)(l) || {}, d = getApp();
            d.setLxUTM({
                query: c
            }), d.globalData.shortLink = {
                options: c,
                route: s
            };
        } catch (t) {
            console.log("error:", t);
        }
        u[i.default.every(function(t) {
            return -1 === n.indexOf(t);
        }) ? "navigateTo" : "switchTab"]({
            url: n
        });
    }).catch(function() {});
}, exports.getWxNavigatorBarHeight = function() {
    var t = u.getSystemInfoSync().statusBarHeight, e = u.getMenuButtonBoundingClientRect(), r = e.top;
    return e.height + t + 2 * (r - t);
}, exports.jsGuardInit = function() {
    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : getApp();
    return t.globalData.jsGuardInstance ? Promise.resolve(t.globalData.jsGuardInstance) : o.default.mtDefaultLogin().then(function(e) {
        return n.default.init({
            appid: t.globalData.appid,
            openid: e.openId,
            unionid: e.unionId,
            mchid: "250332984",
            userinfo: e.wxUserInfo
        }).then(function(e) {
            return t.globalData.jsGuardInstance = e, e;
        });
    });
}, exports.jsGuardInitSync = function() {
    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : getApp(), e = (t.globalData || {}).jsGuardInstance;
    return e || (e = n.default.initSync({
        appid: t.globalData.appid,
        mchid: "250332984"
    }), o.default.mtDefaultLogin().then(function(r) {
        var n = r.openId, a = r.unionId, i = r.wxUserInfo;
        e.finger.o(n), e.finger.u(a), e.finger.su(i), t.globalData.jsGuardInstance = e;
    }), e);
};

exports.default = {};