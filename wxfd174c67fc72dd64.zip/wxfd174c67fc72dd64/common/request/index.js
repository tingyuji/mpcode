function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function r(e) {
    try {
        var r = (m || p.getStorageSync(l.DEBUG_STORE_KEYS.PANEL)).papiMock || {}, t = r.token, a = r.expire;
        if (t && a > Date.now()) {
            var n = (0, o.urlParse)(e.url).host;
            return {
                header: {
                    "papi-user": t,
                    "papi-target": n
                },
                url: e.url.replace(n, "a.sankuai.com")
            };
        }
        return {};
    } catch (e) {
        return {};
    }
}

function t(e, r) {
    try {
        var t = r || {}, a = t.statusCode, n = t.data;
        if (200 == +a) {
            var i = e.header, u = e.data, o = e.dataType, s = e.url, l = (n || {}).code;
            if (200 !== l && (l = 10001), 200 === l && null === n.msg && (l = 10002), 200 !== l) return {
                code: l,
                ignoreAjaxError: !1,
                name: e.url,
                log: {
                    header: i,
                    data: u,
                    dataType: o,
                    url: s
                }
            };
        }
    } catch (e) {}
}

function a() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    try {
        var a = e, o = a.url, l = a._JOY_OWL_FLAG_;
        if (!d && !l && (e = u.default.deepMerge(e, r(e))), !l && !_.every(function(e) {
            return !e.test(o);
        })) {
            e._JOY_OWL_FLAG_ = 1, e.isRequest = !0, e.data = e.data || {};
            var p = ((getApp().globalData || {}).userInfo || {}).token;
            if (e.data.token || !p || f.API_GPOWER_LASTED.test(o) || (e.data.token = p), e.header = Object.assign({}, e.header || {}, {
                "Miniprogram-Version": "0.8.2"
            }, e.header && e.header.token || !p ? {} : {
                token: p
            }, !s.isProduction && s.swimlane ? {
                swimlane: s.swimlane
            } : {}), e.reportError = e.reportError || t.bind(null, e), (f.API_GPOWER_LASTED.test(o) || f.API_GPOWER.test(o)) && "wx" === s.platform) {
                var m = (0, i.jsGuardInitSync)();
                return n.request.call(this, m.sign(e));
            }
            return n.request.call(this, e);
        }
        return c.call(this, e);
    } catch (r) {
        return c.call(this, e);
    }
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.overrideWxRequest = void 0;

var n = require("../../npm/@dp/owl-wxapp/es6/index.js"), i = require("../index"), u = e(require("../../utils/index")), o = require("../../npm/@mtfe/mt-weapp-url/url.js"), s = require("../config"), l = (e(s), 
require("../storage-constants")), p = require("../../npm/@mtfe/weapp-privacy-api/index.js").default, d = !0, c = p.request, f = {
    API_GPOWER: /(ping|sankuai|meituan)\.com\/api\/joy\/sharerelation/,
    API_GPOWER_LASTED: /(ping|sankuai|meituan)\.com\/api\/gpower/,
    API_CONTENT: /ping\.com\/beauty\//
}, _ = Object.keys(f).map(function(e) {
    return f[e];
}), m = null;

exports.overrideWxRequest = function() {
    Object.defineProperty(p, "request", {
        configurable: !0,
        enumerable: !1,
        writable: !0,
        value: a
    });
};