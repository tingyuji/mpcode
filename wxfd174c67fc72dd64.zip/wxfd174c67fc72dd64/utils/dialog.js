function e() {
    var e = getCurrentPages();
    return e[e.length - 1];
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var t = Object.assign || function(e) {
    for (var t = 1; t < arguments.length; t++) {
        var n = arguments[t];
        for (var o in n) Object.prototype.hasOwnProperty.call(n, o) && (e[o] = n[o]);
    }
    return e;
}, n = require("../npm/@mtfe/weapp-privacy-api/index.js").default, o = [], r = {
    show: !1,
    title: "",
    width: null,
    message: "",
    zIndex: 9999999,
    overlay: !0,
    selector: "#mtgroup-dialog",
    asyncClose: !1,
    beforeClose: null,
    transition: "scale",
    customStyle: "",
    messageAlign: "",
    overlayStyle: "",
    confirmButtonText: "确认",
    cancelButtonText: "取消",
    showConfirmButton: !0,
    showCancelButton: !1,
    closeOnClickOverlay: !1,
    confirmButtonOpenType: ""
}, c = t({}, r), s = function() {
    var r = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, s = t({}, c, r);
    return new Promise(function(r, c) {
        var l = (s.context || e()).selectComponent(s.selector);
        delete s.context, delete s.selector, l ? (l.setData(t({
            callback: function(e, t) {
                return "confirm" === e ? r(t) : c(t);
            }
        }, s)), n.nextTick(function() {
            l.setData({
                show: !0
            });
        }), o.push(l)) : console.warn("未找到 mtgroup-dialog 节点，请确认 selector 及 context 是否正确");
    });
};

s.confirm = function(e) {
    return s(t({
        showCancelButton: !0
    }, e));
}, s.close = function() {
    o.forEach(function(e) {
        e.close();
    }), o.splice(0, 1 / 0);
}, s.defaultOptions = r, s.currentOptions = c, s.setDefaultOptions = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    Object.keys(e).forEach(function(t) {
        c[t] = e[t];
    });
}, s.resetDefaultOptions = function() {
    Object.keys(c).forEach(function(e) {
        delete c[e];
    }), Object.keys(r).forEach(function(e) {
        c[e] = r[e];
    });
}, s.resetDefaultOptions(), exports.default = s;