function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function r(e) {
    var r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : Page, t = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : Object.assign;
    return function(n) {
        var a = t(n, e);
        return r.call(null, a);
    };
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.pageShareExtend = exports.createExtendPage = void 0;

var t = e(require("../common/config")), n = require("../npm/@mtfe/mt-weapp-url/url.js"), a = (e(require("./index")), 
require("../npm/regenerator-runtime/runtime.js"));

exports.createExtendPage = r, exports.pageShareExtend = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : Page;
    try {
        return r(null, e, function(e) {
            var r = e.onShareAppMessage;
            if (void 0 === r) return e;
            var u = function(e) {
                if ("wx" === t.default.platform) {
                    var r = (((getApp() || {}).globalData || {}).userInfo || {}).openId;
                    return e.includes("?") ? e + (e.endsWith("&") ? "" : "&") + "openid=" + r : e + "?openid=" + r;
                }
                return e;
            };
            return e.onShareAppMessage = function() {
                var e, t;
                return a.async(function(o) {
                    for (;;) switch (o.prev = o.next) {
                      case 0:
                        return e = getCurrentPages().pop() || {}, o.next = 3, a.awrap(Promise.resolve(r.call(e)));

                      case 3:
                        if (o.t0 = o.sent, o.t0) {
                            o.next = 6;
                            break;
                        }
                        o.t0 = {};

                      case 6:
                        return (t = o.t0).path || (t.path = "/" + e.route + "?" + (0, n.stringify)(e.options)), 
                        t.path = u(t.path), o.abrupt("return", t);

                      case 10:
                      case "end":
                        return o.stop();
                    }
                }, null, null, null, Promise);
            }, e;
        });
    } catch (r) {
        return console.error(r), e;
    }
}, exports.default = {};