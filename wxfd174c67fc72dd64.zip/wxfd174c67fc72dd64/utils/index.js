function e(e) {
    if (Array.isArray(e)) {
        for (var t = 0, n = Array(e.length); t < e.length; t++) n[t] = e[t];
        return n;
    }
    return Array.from(e);
}

function t(e, t, n) {
    return t in e ? Object.defineProperty(e, t, {
        value: n,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = n, e;
}

function n(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function r(e, t) {
    var n = Object.keys(e);
    if (Object.getOwnPropertySymbols) {
        var r = Object.getOwnPropertySymbols(e);
        t && (r = r.filter(function(t) {
            return Object.getOwnPropertyDescriptor(e, t).enumerable;
        })), n.push.apply(n, r);
    }
    return n;
}

function i(e) {
    for (var t = 1; t < arguments.length; t++) {
        var n = null != arguments[t] ? arguments[t] : {};
        t % 2 ? r(Object(n), !0).forEach(function(t) {
            o(e, t, n[t]);
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : r(Object(n)).forEach(function(t) {
            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
        });
    }
    return e;
}

function o(e, t, n) {
    return t in e ? Object.defineProperty(e, t, {
        value: n,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = n, e;
}

function u(e) {
    return toString.call(e).slice(8, -1);
}

function a(t) {
    for (var n = function(e) {
        return "Object" === u(e);
    }, r = arguments.length, o = Array(r > 1 ? r - 1 : 0), c = 1; c < r; c++) o[c - 1] = arguments[c];
    return o.reduce(function(t, r) {
        return Object.entries(r).forEach(function(r) {
            var i = s(r, 2), o = i[0], u = i[1], c = t[o];
            Array.isArray(c) && Array.isArray(u) ? t[o] = c.concat.apply(c, e(u)) : n(c) && n(u) ? t[o] = a(c, u) : t[o] = u;
        }), t;
    }, i({}, t));
}

function c(e, t, n) {
    var r = Array.isArray(t) ? t : t.split(".");
    return e && r.length ? c(e[r.shift()], r, n) : void 0 === e ? n : e;
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var s = function() {
    function e(e, t) {
        var n = [], r = !0, i = !1, o = void 0;
        try {
            for (var u, a = e[Symbol.iterator](); !(r = (u = a.next()).done) && (n.push(u.value), 
            !t || n.length !== t); r = !0) ;
        } catch (e) {
            i = !0, o = e;
        } finally {
            try {
                !r && a.return && a.return();
            } finally {
                if (i) throw o;
            }
        }
        return n;
    }
    return function(t, n) {
        if (Array.isArray(t)) return t;
        if (Symbol.iterator in Object(t)) return e(t, n);
        throw new TypeError("Invalid attempt to destructure non-iterable instance");
    };
}(), E = function() {
    function e(e, t) {
        for (var n = 0; n < t.length; n++) {
            var r = t[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), 
            Object.defineProperty(e, r.key, r);
        }
    }
    return function(t, n, r) {
        return n && e(t.prototype, n), r && e(t, r), t;
    };
}(), f = function(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}(require("../npm/@dzfe/wx-api-promisify/dist/index.js")), l = require("../npm/regenerator-runtime/runtime.js"), A = require("../npm/@mtfe/weapp-privacy-api/index.js").default, _ = 0, p = function e(t, r) {
    var i = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
    n(this, e), this.fn = t, this.context = r, this.once = i;
}, T = function() {
    function e() {
        n(this, e), this.map = {}, this.listenerCount = 0;
    }
    return E(e, [ {
        key: "_addListener",
        value: function(e, t, n, r) {
            if ("function" != typeof t) throw Error("callback must be a function!");
            var i = new p(t, n || this, r);
            return this.map[e] && Array.isArray(this.map[e]) ? this.map[e].push(i) : this.map[e] = [ i ], 
            this.listenerCount++, this;
        }
    }, {
        key: "on",
        value: function(e, t, n) {
            return this._addListener(e, t, n);
        }
    }, {
        key: "once",
        value: function(e, t, n) {
            return this._addListener(e, t, n, !0);
        }
    }, {
        key: "off",
        value: function(e, t, n) {
            var r = arguments.length > 3 && void 0 !== arguments[3] && arguments[3];
            if (!this.map[e]) return !1;
            for (var i = 0; i < this.map[e].length; i++) {
                var o = this.map[e][i];
                if (o.fn === t && o.context === n && o.once === r) return this.map[e].splice(i, 1), 
                this.listenerCount--, !0;
            }
            return !1;
        }
    }, {
        key: "emit",
        value: function(e) {
            if (this.map[e]) {
                for (var t = arguments.length, n = Array(t > 1 ? t - 1 : 0), r = 1; r < t; r++) n[r - 1] = arguments[r];
                for (var i = 0; i < this.map[e].length; i++) {
                    var o = this.map[e][i], u = o.fn, a = o.context, c = o.once;
                    u.call.apply(u, [ a ].concat(n)), c && this.off(e, u, a, c) && i--;
                }
            }
        }
    }, {
        key: "addEventListener",
        value: function() {
            return this._addListener.apply(this, arguments);
        }
    }, {
        key: "removeEventListener",
        value: function() {
            return this.off.apply(this, arguments);
        }
    }, {
        key: "removeAllEventListener",
        value: function() {
            this.map = {}, this.listenerCount = 0;
        }
    }, {
        key: "count",
        get: function() {
            return this.listenerCount;
        }
    } ]), e;
}(), S = {
    PIKE_START: "onStart",
    PIKE_ROUTE: "onRoute",
    PIKE_OPEN: "onOpen",
    PIKE_OPEN_FAIL: "onOpenFail",
    PIKE_LOGIN: "onLogin",
    PIKE_LOGIN_FAIL: "onLoginFail",
    PIKE_CONNECT: "onConnect",
    PIKE_CONNECT_FAIL: "onConnectFail",
    PIKE_READY: "onReady",
    PIKE_READY_EXIT: "onReadyExit",
    PIKE_DISCONNECT: "onDisconnect",
    PIKE_RECONNECT: "onReconnect",
    PIKE_MESSAGE: "onMessage",
    PIKE_H5_READ_MESSAGE: "readMessage",
    WEBVIEW_POSTMESSAGE: "WEBVIEW_POSTMESSAGE",
    REDIRECT_TO_MESSAGE_PAGE: "REDIRECT_TO_MESSAGE_PAGE",
    BACK_TO_MESSAGE_PAGE: "BACK_TO_MESSAGE_PAGE",
    UNREAD_MESSAGES_CHANGED: "UNREAD_MESSAGES_CHANGED",
    TABBAR_CHANGED: "TABBAR_CHANGED",
    USER_LOGIN: "LOGIN",
    USER_LOGOUT: "LOGOUT",
    MESSAG_PAGE_INIT: "MESSAG_PAGE_INIT",
    TABBAR_MESSAGES_CHANGE: "TABBAR_MESSAGES_CHANGE",
    CONTENT_COLLECTION: "CONTENT_COLLECTION",
    HOME_CITYCHANGE: "HOME_CITYCHANGE",
    DETAIL_CONTACT_TAP: "DETAIL_CONTACT_TAP",
    DETAIL_ACTION_SHEET_TAP: "DETAIL_ACTION_SHEET_TAP",
    DETAIL_ACTION_SHEET_CANCEL: "DETAIL_ACTION_SHEET_CANCEL",
    PRIVACY_SETTING_CHANGE: "PRIVACY_SETTING_CHANGE",
    TALENT_LOCATION_SELECT: "TALENT_LOCATION_SELECT",
    AVATAR_MODIFY_SUCCESS: "AVATAR_MODIFY_SUCCESS",
    TALENT_ACTIVITY_PUBLISH_SUCCESS: "TALENT_ACTIVITY_PUBLISH_SUCCESS",
    REALNAME_VERIFY_RESULT: "REALNAME_VERIFY_RESULT",
    EMPTY_GROUP_LIST: "EMPTY_GROUP_LIST",
    SHOP_CERTIFICATION_CALLBACK: "SHOP_CERTIFICATION_CALLBACK",
    LOGIN_NAVIBACK: "LOGIN_NAVIBACK"
};

exports.default = {
    debounce: function(e, t) {
        var n = void 0;
        return function() {
            clearTimeout(n);
            var r = this, i = arguments;
            n = setTimeout(function() {
                e.call(r, i);
            }, t || 1e3);
        };
    },
    throttle: function(e, t) {
        var n = 0;
        return function() {
            var r = this, i = new Date();
            i - n > (t || 300) && (e.call(r, arguments), n = i);
        };
    },
    judgeScene: function(e) {
        return -1 !== [ 1007, 1008, 1036, 1096 ].indexOf(e);
    },
    EventEmitter: T,
    Event: new T(),
    EVENT_TYPE: S,
    isIOS: function() {
        var e;
        return l.async(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return t.prev = 0, t.next = 3, l.awrap(f.default.getSystemInfo());

              case 3:
                return e = t.sent, t.abrupt("return", e && e.system.toLocaleLowerCase().indexOf("ios") > -1);

              case 7:
                return t.prev = 7, t.t0 = t.catch(0), t.abrupt("return", !1);

              case 10:
              case "end":
                return t.stop();
            }
        }, null, null, [ [ 0, 7 ] ], Promise);
    },
    getNode: function(e, t) {
        return new Promise(function(n) {
            t ? A.createSelectorQuery().in(t).select(e).node(function(e) {
                return n(e);
            }).exec() : A.createSelectorQuery().select(e).node(function(e) {
                return n(e);
            }).exec();
        });
    },
    getNodeRect: function(e, t) {
        return new Promise(function(n) {
            t ? A.createSelectorQuery().in(t).select(e).boundingClientRect(function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                n(e);
            }).exec() : A.createSelectorQuery().select(e).boundingClientRect(function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                n(e);
            }).exec();
        });
    },
    nextTick: function(e) {
        A.canIUse("nextTick") ? A.nextTick(e) : setTimeout(e, 16);
    },
    rpx2px: function(e) {
        return _ = _ || A.getSystemInfoSync().windowWidth, e / 750 * _;
    },
    px2rpx: function(e) {
        return _ = _ || A.getSystemInfoSync().windowWidth, e / _ * 750;
    },
    transformNum: function(e) {
        return e >= 1e4 ? (e / 1e4).toFixed(1) + "W" : e > 0 ? e : 0;
    },
    getType: u,
    getPropetiesFromObj: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [], n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        if (![ "String", "Array" ].includes(u(e))) throw TypeError("propeties参数不合法");
        if ("Object" !== u(n)) throw TypeError("原始值 Object 参数不合法");
        var r = e;
        "string" == typeof e && (r = [ e ]);
        var i = Object.assign;
        return r.reduce(function(e, r) {
            return i({}, e, void 0 !== n[r] ? t({}, r, n[r]) : {});
        }, {});
    },
    deepMerge: a,
    safeGetPropByPath: c,
    compareVersion: function(e, t) {
        for (var n = e.split("."), r = t.split("."), i = Math.max(n.length, r.length); n.length < i; ) n.push("0");
        for (;r.length < i; ) r.push("0");
        for (var o = 0; o < i; o++) {
            var u = parseInt(n[o]), a = parseInt(r[o]);
            if (u > a) return 1;
            if (u < a) return -1;
        }
        return 0;
    },
    removeUrlSliceAffix: function(e) {
        return e ? e.indexOf("meituan.net") > 0 ? decodeURIComponent(e).replace(/@.+$/, "") : e : "";
    },
    imgResizer: function(e, t, n, r) {
        return e && "string" == typeof e ? (n = n || t, e.indexOf("meituan.net") > 0 || e.indexOf(".test.sankuai.com") > 0 ? e = decodeURIComponent(e).replace(/@.+$/, "") + "@" + t + "w_" + n + "h_1e_1c_1l" + (r ? "_" + r + "q" : "") : e) : "";
    },
    tabbarPage: function(e) {
        for (var t = [ "/pages/home/index", "/pages/feeds/index", "/pages/shop-list/index", "/pages/user-profile/index/index", "/pages/message/index" ], n = 0; n < t.length; n++) if (e.startsWith(t[n])) return !0;
        return !1;
    },
    isShareCardScene: function(e) {
        return [ 1007, 1008, 1036, 1044, 1065, 1073, 1074, 1091 ].includes(e);
    }
};