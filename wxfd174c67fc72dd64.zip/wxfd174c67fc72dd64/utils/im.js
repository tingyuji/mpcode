function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function n(e, n) {
    if (!(e instanceof n)) throw new TypeError("Cannot call a class as a function");
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.initIM = exports.IM = void 0;

var t = function() {
    function e(e, n) {
        for (var t = 0; t < n.length; t++) {
            var r = n[t];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), 
            Object.defineProperty(e, r.key, r);
        }
    }
    return function(n, t, r) {
        return t && e(n.prototype, t), r && e(n, r), n;
    };
}(), r = e(require("../npm/@dp/pike-message-mini/dist/index.js")), i = require("../common/config"), o = function(e) {
    if (e && e.__esModule) return e;
    var n = {};
    if (null != e) for (var t in e) Object.prototype.hasOwnProperty.call(e, t) && (n[t] = e[t]);
    return n.default = e, n;
}(require("../common/login")), a = e(require("./index")), s = require("../npm/regenerator-runtime/runtime.js"), u = a.default.Event, c = a.default.EVENT_TYPE, l = "dzu_general_pin_im_pike", f = {
    alias: "",
    autoConnect: !1,
    extra: {
        token: ""
    },
    env: i.env.includes("product") ? "product" : [ "dev", "test", "ppe", "stage" ].includes(i.env) ? i.env : "test",
    isDebug: "product" !== i.env,
    isOfficeNetwork: !1,
    keepAlive: !0,
    query: {},
    swimlane: i.swimlane || "",
    tags: null,
    timeout: 6e3,
    loglevel: "error",
    Owl: null,
    Logan: null,
    alwaysClearBeforeReady: !1
}, p = exports.IM = function() {
    function e() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        n(this, e), this.pikeInstance = null, this.pikeInfo = {}, this.eventBus = u;
        try {
            var i = Object.assign(f, t);
            this.pikeInstance = new r.default(l, i), this.pikeInfo.token = i.extra.token, this.pikeInfo.alias = i.alias;
        } catch (e) {
            throw console.log(e), e;
        }
        this.registerEvent();
    }
    return t(e, [ {
        key: "registerEvent",
        value: function() {
            var e = this, n = this.pikeInstance, t = function() {
                var n;
                (n = e.eventBus).emit.apply(n, arguments);
            };
            n.onStart(function() {
                for (var e = arguments.length, n = Array(e), r = 0; r < e; r++) n[r] = arguments[r];
                t.apply(void 0, [ c.PIKE_START ].concat(n));
            }), n.onRoute(function() {
                for (var e = arguments.length, n = Array(e), r = 0; r < e; r++) n[r] = arguments[r];
                t.apply(void 0, [ c.PIKE_ROUTE ].concat(n));
            }), n.onOpen(function(e) {
                t(c.PIKE_OPEN, e);
            }), n.onOpenFail(function(e, n) {
                var r = n.entryPoint, i = n.network;
                t(c.PIKE_OPEN_FAIL, e, {
                    entryPoint: r,
                    network: i
                });
            }), n.onLogin(function(e, n) {
                e.deviceId, e.extra, e.serverTime, e.sessionId, e.status, e.token;
                t(c.PIKE_LOGIN, e, n);
            }), n.onLoginFail(function(e, n) {
                var r = n.extra;
                e instanceof Error && 403 === e.code && console.log("拒绝的原因是:", e.data), t(c.PIKE_LOGIN_FAIL, e, {
                    extra: r
                });
            }), n.onConnect(function(e) {
                t(c.PIKE_CONNECT, e);
            }), n.onConnectFail(function() {
                for (var e = arguments.length, n = Array(e), r = 0; r < e; r++) n[r] = arguments[r];
                t.apply(void 0, [ c.PIKE_CONNECT_FAIL ].concat(n));
            }), n.onReady(function() {
                for (var e = arguments.length, n = Array(e), r = 0; r < e; r++) n[r] = arguments[r];
                t.apply(void 0, [ c.PIKE_READY ].concat(n));
            }), n.onReadyExit(function(e) {
                t(c.PIKE_READY_EXIT, e);
            }), n.onDisconnect(function(e, n) {
                t(c.PIKE_DISCONNECT, e, n);
            }), n.onReconnect(function() {
                for (var e = arguments.length, n = Array(e), r = 0; r < e; r++) n[r] = arguments[r];
                t.apply(void 0, [ c.PIKE_RECONNECT ].concat(n));
            }), n.onMessage(function(e, n) {
                t(c.PIKE_MESSAGE, e, n);
            });
        }
    }, {
        key: "start",
        value: function() {
            var e = this;
            return s.async(function(n) {
                for (;;) switch (n.prev = n.next) {
                  case 0:
                    return n.abrupt("return", new Promise(function(n) {
                        e.pikeInstance.start(), e.eventBus.once("onReady", n, e);
                    }).catch(function(e) {
                        console.error("注册alias失败", e);
                    }));

                  case 1:
                  case "end":
                    return n.stop();
                }
            }, null, null, null, Promise);
        }
    }, {
        key: "exit",
        value: function() {
            this.isRunning && (this.stop(), this.pikeInstance = void 0, this.eventBus = void 0);
        }
    }, {
        key: "stop",
        value: function() {
            this.pikeInstance.stop();
        }
    }, {
        key: "restart",
        value: function() {
            this.pikeInstance.restart();
        }
    }, {
        key: "isRunning",
        get: function() {
            return this.pikeInstance && this.pikeInstance.isRunning();
        }
    }, {
        key: "isReady",
        get: function() {
            return this.pikeInstance && this.pikeInstance.isReady();
        }
    } ]), e;
}();

exports.initIM = function() {
    var e, n, t, r, i, a, u = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
    return s.async(function(c) {
        for (;;) switch (c.prev = c.next) {
          case 0:
            if (e = getApp()) {
                c.next = 3;
                break;
            }
            return c.abrupt("return");

          case 3:
            if (n = e.globalData, t = "", r = "", n && n.userInfo && (t = n.userInfo.userId || "", 
            r = n.userInfo.token || ""), t && r) {
                c.next = 14;
                break;
            }
            return c.next = 9, s.awrap(o.mtDefaultLogin({
                isBind: u
            }));

          case 9:
            if (i = c.sent) {
                c.next = 12;
                break;
            }
            return c.abrupt("return");

          case 12:
            t = i.userId || "", r = i.token || i.userInfo && i.userInfo.token || "";

          case 14:
            return a = new p({
                alias: t,
                extra: {
                    token: r
                }
            }), n.im = a, c.next = 18, s.awrap(a.start());

          case 18:
            return c.abrupt("return", r);

          case 19:
          case "end":
            return c.stop();
        }
    }, null, null, null, Promise);
};