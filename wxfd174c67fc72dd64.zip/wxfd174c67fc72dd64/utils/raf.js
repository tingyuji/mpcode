Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = function() {
    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : function() {};
    return "devtools" === e.getSystemInfoSync().platform ? setTimeout(function() {
        t();
    }, 16) : e.createSelectorQuery().selectViewport().boundingClientRect().exec(function() {
        t();
    });
};

var e = require("../npm/@mtfe/weapp-privacy-api/index.js").default;