Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getDateList = function(e) {
    for (var t = e || {}, r = t.currentDate, a = (void 0 === r && new Date(), t.dateRange), n = void 0 === a ? 30 : a, o = t.minStep, s = void 0 === o ? 15 : o, i = t.minMax, u = void 0 === i ? 45 : i, p = [], d = [], h = [], v = [], D = 0; D <= 23; D++) {
        var m = D < 10 ? "0" + D : "" + D;
        p.push({
            hourText: m + "点",
            hourStr: m,
            hourTimespanStr: m
        });
    }
    for (var f = 0; f <= u; f += s) {
        var g = f < 10 ? "0" + f : "" + f, x = {
            minText: g + "分",
            minStr: g,
            minTimespanStr: g
        };
        f >= 1 && h.push(x), d.push(x);
    }
    for (var M = new Date(), S = [ "日", "一", "二", "三", "四", "五", "六" ], c = 0; c < n; c++) {
        var T = M.getFullYear(), l = M.getMonth() + 1, w = M.getDate(), y = M.getDay(), L = l < 10 ? "0" + l : "" + l, O = w < 10 ? "0" + w : "" + w, _ = "", b = L + "月" + O + "日 " + (_ = 0 === c ? "今天" : 1 === c ? "明天" : "周" + S[y]), j = T + "." + L + "." + O + _;
        v.push({
            dateText: b,
            dateStr: j,
            dateTimespanStr: T + "/" + L + "/" + O
        }), M.setDate(w + 1);
    }
    return {
        dates: v,
        hours: p,
        mins: d,
        curHourMins: h
    };
}, exports.isLastDayOfMonth = function(e) {
    return new Date(e).getMonth() !== new Date(e + 864e5).getMonth();
}, exports.default = {};