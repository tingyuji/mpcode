function e() {
    var e = getCurrentPages();
    return e[e.length - 1];
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var t = Object.assign || function(e) {
    for (var t = 1; t < arguments.length; t++) {
        var n = arguments[t];
        for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r]);
    }
    return e;
}, n = function(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}(require("./index")).default.nextTick, r = {
    show: !0,
    duration: 1e3,
    message: "",
    zIndex: 9999999,
    selector: "#mtgroup-toast"
}, o = function() {
    var o = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, s = Object.assign({}, r, o), a = (s.context || e()).selectComponent(s.selector);
    return new Promise(function(e) {
        a || console.warn("未找到 mtgroup-toast 节点，请确认 selector 及 context 是否正确"), a.setData(t({}, s, {
            onClose: e
        })), n(function() {
            a.setData({
                show: !0
            });
        });
    });
};

o.message = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
    return o({
        message: e
    });
}, exports.default = o;