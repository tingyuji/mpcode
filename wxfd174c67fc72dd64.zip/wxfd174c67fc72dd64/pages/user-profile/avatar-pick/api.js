Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = function(e) {
    return new Promise(function(n, t) {
        r.request({
            url: o.UPLOAD_IMG,
            data: e,
            method: "POST",
            header: {},
            success: function(e) {
                n(e);
            },
            fail: function(e) {
                t(e);
            }
        });
    }).then(function(e) {
        var r = e.data;
        if (200 === r.code && r.msg) return r.msg;
        throw console.error(e), new Error("请求数据失败");
    }).catch(function(e) {
        return console.error("uploadImg", e), null;
    });
}, exports.appendPhotoToAlbum = function(e) {
    return new Promise(function(n, t) {
        r.request({
            url: o.APPEND_ALBUM,
            data: e,
            method: "POST",
            header: {},
            success: function(e) {
                n(e);
            },
            fail: function(e) {
                t(e);
            }
        });
    }).then(function(e) {
        var r = e.data;
        if (200 === r.code && r.msg) return r.msg;
        throw new Error("请求数据失败");
    }).catch(function(e) {
        return console.error("appendPhotoToAlbum", e), null;
    });
};

var e = function(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}(require("../../../common/config")), r = require("../../../npm/@mtfe/weapp-privacy-api/index.js").default, o = {
    UPLOAD_IMG: e.default.gpower_domain + "/api/gpower/picture/upload",
    APPEND_ALBUM: e.default.dp_domain + "/api/joy/sharerelation/profile/photo/append"
};