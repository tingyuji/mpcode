function t(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

function e(t, e) {
    if (null == t) return {};
    var i, n, r = a(t, e);
    if (Object.getOwnPropertySymbols) {
        var o = Object.getOwnPropertySymbols(t);
        for (n = 0; n < o.length; n++) i = o[n], e.indexOf(i) >= 0 || Object.prototype.propertyIsEnumerable.call(t, i) && (r[i] = t[i]);
    }
    return r;
}

function a(t, e) {
    if (null == t) return {};
    var a, i, n = {}, r = Object.keys(t);
    for (i = 0; i < r.length; i++) a = r[i], e.indexOf(a) >= 0 || (n[a] = t[a]);
    return n;
}

var i = t(require("../../../common/login")), n = t(require("../../../common/config")), r = require("../../../common/wx-privacy-constant"), o = require("./api"), s = t(o), u = t(require("../../../utils/index")), c = require("../../../npm/regenerator-runtime/runtime.js"), l = require("../../../npm/@mtfe/weapp-privacy-api/index.js").default, d = [ "updated" ], h = u.default.rpx2px, p = u.default.Event, f = u.default.EVENT_TYPE, g = (getApp(), 
h(674));

Page({
    data: {
        uploading: !1,
        src: "",
        width: g,
        height: g,
        max_width: g,
        max_height: g,
        disable_rotate: !0,
        disable_ratio: !0,
        limit_move: !0,
        isChanged: !1
    },
    options: {},
    onLoad: function(t) {
        t.avatarUrl && this.setData({
            src: decodeURIComponent(t.avatarUrl)
        }), this.options = t, this.cropper = this.selectComponent("#image-cropper");
    },
    cropperload: function() {},
    loadimage: function() {
        l.hideLoading(), this.cropper.imgReset();
    },
    clickcut: function(t) {
        l.previewImage({
            current: t.detail.url,
            urls: [ t.detail.url ],
            _mt: {
                sceneToken: r.WX_SCENETOKENS.PREVIEWIMAGE
            }
        });
    },
    cancel: function() {
        this.goBack();
    },
    reset: function() {
        this.cropper.reset(), this.setData({
            isChanged: !1
        });
    },
    onChange: function() {
        this.data.isChanged || this.setData({
            isChanged: !0
        });
    },
    setWidth: function(t) {
        this.setData({
            width: t.detail.value < 10 ? 10 : t.detail.value
        }), this.setData({
            cut_left: this.cropper.data.cut_left
        });
    },
    setHeight: function(t) {
        this.setData({
            height: t.detail.value < 10 ? 10 : t.detail.value
        }), this.setData({
            cut_top: this.cropper.data.cut_top
        });
    },
    switchChangeDisableRatio: function(t) {
        this.setData({
            disable_ratio: t.detail.value
        });
    },
    setCutTop: function(t) {
        this.setData({
            cut_top: t.detail.value
        }), this.setData({
            cut_top: this.cropper.data.cut_top
        });
    },
    setCutLeft: function(t) {
        this.setData({
            cut_left: t.detail.value
        }), this.setData({
            cut_left: this.cropper.data.cut_left
        });
    },
    switchChangeDisableRotate: function(t) {
        t.detail.value ? this.setData({
            disable_rotate: t.detail.value
        }) : this.setData({
            limit_move: !1,
            disable_rotate: t.detail.value
        });
    },
    switchChangeLimitMove: function(t) {
        t.detail.value && this.setData({
            disable_rotate: !0
        }), this.cropper.setLimitMove(t.detail.value);
    },
    switchChangeDisableWidth: function(t) {
        this.setData({
            disable_width: t.detail.value
        });
    },
    switchChangeDisableHeight: function(t) {
        this.setData({
            disable_height: t.detail.value
        });
    },
    submit: u.default.throttle(function() {
        var t = this;
        this.data.uploading || (this.data.uploading = !0, this.cropper.getImg(function(e) {
            l.getFileSystemManager().readFile({
                filePath: e.url,
                encoding: "base64",
                fail: function() {
                    t.data.uploading = !1;
                },
                success: function(e) {
                    (0, s.default)({
                        pictureContent: e.data
                    }).then(function(e) {
                        var a;
                        return c.async(function(t) {
                            for (var i = this; ;) switch (t.prev = t.next) {
                              case 0:
                                if (!e || !e.isSuccess) {
                                    t.next = 9;
                                    break;
                                }
                                if (a = this.options.from, 1 !== parseInt(a)) {
                                    t.next = 5;
                                    break;
                                }
                                return t.next = 5, c.awrap(this.appendAlbum(e.pictureUrl));

                              case 5:
                                p.emit(f.AVATAR_MODIFY_SUCCESS, {
                                    url: e.pictureUrl
                                }), this.goBack({
                                    updated: 1,
                                    url: e.pictureUrl
                                }), t.next = 10;
                                break;

                              case 9:
                                l.showToast({
                                    title: "图片上传失败",
                                    icon: "none",
                                    image: "",
                                    duration: 1500
                                });

                              case 10:
                                setTimeout(function() {
                                    i.data.uploading = !1;
                                }, 1500);

                              case 11:
                              case "end":
                                return t.stop();
                            }
                        }, null, t, null, Promise);
                    });
                }
            });
        }));
    }),
    appendAlbum: function(t) {
        return i.default.mtDefaultLogin({
            isBind: !0
        }).then(function(e) {
            if (e && e.token) return (0, o.appendPhotoToAlbum)({
                platform: n.default.platformCode,
                photourl: t,
                token: e.token
            });
            throw Error("appendAlbum faild");
        });
    },
    goBack: function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, a = t.updated, i = e(t, d), n = getCurrentPages();
        if (n && n.length > 1) {
            var r = n[n.length - 2];
            l.navigateBack({
                delta: 1,
                success: function() {
                    a && setTimeout(function() {
                        r.onUploadSuccess && r.onUploadSuccess(i);
                    }, 1e3);
                }
            });
        }
    },
    rotate: function() {
        this.cropper.setAngle(this.cropper.data.angle -= 90);
    },
    top: function() {
        var t = this;
        this.data.top = setInterval(function() {
            t.cropper.setTransform({
                y: -3
            });
        }, 1e3 / 60);
    },
    bottom: function() {
        var t = this;
        this.data.bottom = setInterval(function() {
            t.cropper.setTransform({
                y: 3
            });
        }, 1e3 / 60);
    },
    left: function() {
        var t = this;
        this.data.left = setInterval(function() {
            t.cropper.setTransform({
                x: -3
            });
        }, 1e3 / 60);
    },
    right: function() {
        var t = this;
        this.data.right = setInterval(function() {
            t.cropper.setTransform({
                x: 3
            });
        }, 1e3 / 60);
    },
    narrow: function() {
        var t = this;
        this.data.narrow = setInterval(function() {
            t.cropper.setTransform({
                scale: -.02
            });
        }, 1e3 / 60);
    },
    enlarge: function() {
        var t = this;
        this.data.enlarge = setInterval(function() {
            t.cropper.setTransform({
                scale: .02
            });
        }, 1e3 / 60);
    },
    end: function(t) {
        clearInterval(this.data[t.currentTarget.dataset.type]);
    }
});