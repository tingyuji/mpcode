Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.fechUserInfo = function(e) {
    return new Promise(function(o, t) {
        r.request({
            url: n.GET_USER_INFO,
            data: e,
            header: {},
            success: function(e) {
                o(e);
            },
            fail: function(e) {
                t(e);
            }
        });
    }).then(function(e) {
        var r = e.data;
        if (200 === r.code && r.msg) return r.msg;
        throw new Error("请求数据失败");
    }).catch(function(e) {
        return console.error("fechUserInfo", e), null;
    });
}, exports.saveUserInfo = function(e) {
    return new Promise(function(o, t) {
        r.request({
            url: n.SAVE_USER_INFO,
            data: e,
            method: "POST",
            header: {},
            success: function(e) {
                o(e);
            },
            fail: function(e) {
                t(e);
            }
        });
    }).then(function(e) {
        var r = e.data;
        return 200 === r.code && r.msg ? r.msg : {
            errorMessage: r.errorMessage
        };
    });
};

var e = function(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}(require("../../../common/config")), r = require("../../../npm/@mtfe/weapp-privacy-api/index.js").default, n = {
    GET_USER_INFO: e.default.dp_domain + "/api/joy/sharerelation/profile/user/info",
    SAVE_USER_INFO: e.default.gpower_domain + "/api/gpower/profile/user/save"
};