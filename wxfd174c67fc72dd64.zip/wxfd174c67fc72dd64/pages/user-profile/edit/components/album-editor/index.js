var t = Object.assign || function(t) {
    for (var e = 1; e < arguments.length; e++) {
        var a = arguments[e];
        for (var r in a) Object.prototype.hasOwnProperty.call(a, r) && (t[r] = a[r]);
    }
    return t;
};

Component({
    properties: {
        album: {
            type: Array,
            value: [],
            observer: function(e) {
                var a = e.length, r = e.map(function(e) {
                    return t({
                        type: "avatar",
                        className: []
                    }, e);
                });
                r.length < 9 && r.push({
                    type: "button",
                    className: []
                });
                for (var i = r.length, s = 0; s < i; s++) r[s].id = s, s % 3 == 2 && r[s].className.push("right-corner");
                if (i % 3) for (var n = 0; n < i % 3; n++) r[i - 1 - n].className.push("bottom-row"); else r.slice(-3).forEach(function(t) {
                    return t.className.push("bottom-row");
                });
                this.data._list = r, this.setData({
                    list: [ r.slice(0, 3), r.slice(3, 6), r.slice(6, 9) ],
                    avatarCount: a
                });
            }
        }
    },
    data: {
        sliceOption: {
            width: 208,
            height: 208
        },
        _list: [],
        list: [ [], [], [] ],
        avatarCount: 0
    },
    methods: {
        removeCurrent: function(t) {
            var e = this.data._list, a = t.target.dataset.index;
            this.triggerEvent("removeAvatar", {
                index: a,
                item: e[a]
            });
        },
        unshiftCurrent: function(t) {
            var e = this.data._list, a = t.target.dataset.index;
            e[a] && 1 === e[a].status || this.triggerEvent("unshiftAvatar", {
                index: a,
                item: e[a]
            });
        },
        onPreview: function(t) {
            var e = this.data._list, a = t.target.dataset.index;
            this.triggerEvent("onPreview", {
                index: a,
                item: e[a]
            });
        },
        onUpload: function() {
            this.triggerEvent("onUpload");
        }
    }
});