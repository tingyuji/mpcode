Component({
    properties: {
        show: {
            type: Boolean,
            value: !1
        },
        duration: {
            type: Number,
            value: 300
        },
        initValue: {
            type: String,
            value: "奶"
        }
    },
    data: {
        overlayStyle: "background-color: rgba(0, 0, 0, 0.7)",
        customStyle: "height: 50%",
        tags: [ "坦", "奶", "无" ],
        tag: "奶",
        value: [ 1 ]
    },
    attached: function() {
        var t = this.data.tags.indexOf(this.properties.initValue);
        t < 0 && (t = 1), this.setData({
            value: [ t ]
        });
    },
    methods: {
        bindChange: function(t) {
            var a = t.detail.value;
            this.setData({
                value: [ a ]
            }), this.data.tag = this.data.tags[a];
        },
        handleConfirm: function() {
            this.triggerEvent("backroomTagChange", {
                tag: this.data.tag
            });
        },
        handleClose: function() {
            this.triggerEvent("closeSelector");
        }
    }
});