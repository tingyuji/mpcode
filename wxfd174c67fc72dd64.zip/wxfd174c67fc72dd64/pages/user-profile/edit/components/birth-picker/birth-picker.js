for (var t = new Date(), a = [], e = [], i = [], s = 1900; s <= t.getFullYear(); s++) a.push("" + s);

for (var n = 1; n <= 12; n++) e.push(n < 10 ? "0" + n : "" + n);

for (var h = 1; h <= 31; h++) i.push(h < 10 ? "0" + h : "" + h);

Component({
    properties: {
        show: {
            type: Boolean,
            value: !1
        },
        duration: {
            type: Number,
            value: 300
        },
        initValue: {
            type: String,
            value: ""
        }
    },
    data: {
        overlayStyle: "background-color: rgba(0, 0, 0, 0.7)",
        customStyle: "height: 50%",
        years: a,
        year: t.getFullYear(),
        months: e,
        month: t.getMonth() + 1,
        days: i,
        day: t.getDate(),
        value: [ 9999, t.getMonth(), t.getDate() - 1 ]
    },
    attached: function() {
        if (this.properties.initValue) {
            var s = this.properties.initValue.split("-"), n = a.indexOf(s[0]), h = e.indexOf(s[1]), r = i.indexOf(s[2]);
            this.setData({
                value: [ n, h, r ]
            });
        } else this.setData({
            value: [ a.indexOf(t.getFullYear().toString()), t.getMonth(), t.getDate() - 1 ]
        });
    },
    methods: {
        bindChange: function(t) {
            var a = t.detail.value;
            if (this.data.month[a[1]] !== this.data.month) {
                var e = new Date(this.data.years[a[0]], this.data.months[a[1]], 0).getDate();
                this.setData({
                    days: new Array(e).fill(0).map(function(t, a) {
                        var e = a + 1;
                        return e < 10 ? "0" + e : "" + e;
                    })
                });
            }
            this.setData({
                value: a,
                year: this.data.years[a[0]],
                month: this.data.months[a[1]],
                day: this.data.days[a[2]] ? this.data.days[a[2]] : this.data.days[this.data.days.length - 1]
            });
        },
        handleConfirm: function() {
            this.triggerEvent("birthChange", {
                birth: this.data.year + "-" + this.data.month + "-" + this.data.day
            });
        },
        handleClose: function() {
            this.triggerEvent("closeSelector");
        }
    }
});