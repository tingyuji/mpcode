Component({
    properties: {
        show: {
            type: Boolean,
            value: !1
        },
        duration: {
            type: Number,
            value: 300
        },
        initValue: {
            type: String,
            value: "女"
        }
    },
    data: {
        overlayStyle: "background-color: rgba(0, 0, 0, 0.7)",
        customStyle: "height: 50%",
        genders: [ "男", "女" ],
        gender: "女",
        value: [ 1 ]
    },
    attached: function() {
        var e = this.data.genders.indexOf(this.properties.initValue);
        e < 0 && (e = 1), this.setData({
            value: [ e ]
        });
    },
    methods: {
        bindChange: function(e) {
            var t = e.detail.value;
            this.setData({
                value: [ t ]
            }), this.data.gender = this.data.genders[t];
        },
        handleConfirm: function() {
            this.triggerEvent("genderChange", {
                gender: this.data.gender
            });
        },
        handleClose: function() {
            this.triggerEvent("closeSelector");
        }
    }
});