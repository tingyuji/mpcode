function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function t(e) {
    if (Array.isArray(e)) {
        for (var t = 0, a = Array(e.length); t < e.length; t++) a[t] = e[t];
        return a;
    }
    return Array.from(e);
}

function a(e, t) {
    var a = Object.keys(e);
    if (Object.getOwnPropertySymbols) {
        var n = Object.getOwnPropertySymbols(e);
        t && (n = n.filter(function(t) {
            return Object.getOwnPropertyDescriptor(e, t).enumerable;
        })), a.push.apply(a, n);
    }
    return a;
}

function n(e) {
    for (var t = 1; t < arguments.length; t++) {
        var n = null != arguments[t] ? arguments[t] : {};
        t % 2 ? a(Object(n), !0).forEach(function(t) {
            r(e, t, n[t]);
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : a(Object(n)).forEach(function(t) {
            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
        });
    }
    return e;
}

function r(e, t, a) {
    return t in e ? Object.defineProperty(e, t, {
        value: a,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = a, e;
}

function o(e) {
    switch (e) {
      case "男":
        return 1;

      case "女":
        return 2;

      case "跨性别":
        return 3;

      default:
        return 0;
    }
}

function i(e) {
    switch (e) {
      case 1:
        return "男";

      case 2:
        return "女";

      case 3:
        return "跨性别";

      default:
        return "";
    }
}

var c = e(require("../../../utils/dialog")), s = e(require("../../../utils/toast")), u = e(require("../../../npm/@dzfe/wx-api-promisify/dist/index.js")), l = require("../../../common/wx-privacy-constant"), d = e(require("../../../common/config")), f = e(require("../../../common/login")), h = e(require("../../../common/lx")), p = function(e) {
    if (e && e.__esModule) return e;
    var t = {};
    if (null != e) for (var a in e) Object.prototype.hasOwnProperty.call(e, a) && (t[a] = e[a]);
    return t.default = e, t;
}(require("./api")), g = e(require("../../../utils/index")), m = require("../../../npm/regenerator-runtime/runtime.js"), v = require("../../../npm/@mtfe/weapp-privacy-api/index.js").default, b = g.default.removeUrlSliceAffix;

g.default.EVENT_TYPE, g.default.Event;

Page({
    data: {
        infoScoreDescription: "",
        avatarUrl: "",
        emptyAvatarUrl: "https://p1.meituan.net/travelcube/c39e3030eee608fea176bd9178ade8125292.png",
        nickName: "",
        gender: "",
        genderText: "",
        birth: "",
        region: "",
        industry: "",
        intro: "",
        backroomTag: "",
        photos: [],
        birthSelect: !1,
        genderSelect: !1,
        backroomTagSelect: !1,
        userInfo: null,
        token: "",
        isFirstLoad: !0
    },
    navigateToProfilePage: function() {
        setTimeout(function() {
            v.switchTab({
                url: "/pages/user-profile/index/index"
            });
        }, 500);
    },
    onLoad: function() {
        var e = this;
        f.default.mtDefaultLogin({
            isBind: !0
        }).then(function(t) {
            e.data.userInfo = t, e.data.token = t.token || t.userInfo && t.userInfo.token || "", 
            e.getUserInfo();
        });
    },
    onShow: function() {
        h.default.pageView("c_gc_02was8u9", {
            cat_id: d.default.catId
        }), this.data.isFirstLoad ? this.data.isFirstLoad = !1 : this.data.token || this.navigateToProfilePage();
    },
    onHide: function() {},
    onUnload: function() {},
    getUserInfo: function() {
        var e = this;
        return p.fechUserInfo({
            platform: d.default.platformCode,
            token: this.data.token
        }).then(function(t) {
            if (t) {
                var a = t.userInfo || {}, r = (t.photos || []).map(function(e) {
                    return n({}, e, {
                        pictureUrl: b(e.pictureUrl)
                    });
                });
                e.setData({
                    infoScoreDescription: t.infoScoreDescription,
                    nickName: t.nickName,
                    avatarUrl: t.avatar,
                    gender: a.gender,
                    genderText: i(a.gender),
                    birth: a.birthday,
                    region: a.area,
                    industry: a.industry,
                    intro: t.introduction,
                    backroomTag: a.backroomTag || "",
                    photos: r
                });
            }
        });
    },
    handleBirthSelect: function() {
        h.default.moduleClick("b_gc_0jluhk0g_mc"), this.setData({
            birthSelect: !0
        });
    },
    handleBirthChange: function(e) {
        this.setData({
            birth: e.detail.birth,
            birthSelect: !1
        });
    },
    handleGenderSelect: function() {
        h.default.moduleClick("b_gc_ql88gpml_mc"), this.setData({
            genderSelect: !0
        });
    },
    handleGenderChange: function(e) {
        var t = e.detail.gender, a = o(t);
        this.setData({
            gender: a,
            genderText: t,
            genderSelect: !1
        });
    },
    handleBackroomTagSelect: function() {
        this.setData({
            backroomTagSelect: !0
        });
    },
    handleBackroomTagChange: function(e) {
        this.setData({
            backroomTag: e.detail.tag,
            backroomTagSelect: !1
        });
    },
    handleCloseBackroomTag: function() {
        this.setData({
            backroomTagSelect: !1
        });
    },
    handleCloseGender: function() {
        this.setData({
            genderSelect: !1
        });
    },
    handleCloseBirth: function() {
        this.setData({
            birthSelect: !1
        });
    },
    handleNickName: function(e) {
        this.setData({
            nickName: e.detail.value
        });
    },
    handleNickNameLX: function() {
        h.default.moduleClick("b_gc_869l2mnz_mc");
    },
    handleRegion: function(e) {
        this.setData({
            region: e.detail.value
        });
    },
    handleRegionLX: function() {
        h.default.moduleClick("b_gc_6zww9g77_mc");
    },
    handleIndustry: function(e) {
        this.setData({
            industry: e.detail.value
        });
    },
    handleIndustryLX: function() {
        h.default.moduleClick("b_gc_m0xfxuq8_mc");
    },
    handleIntro: function(e) {
        this.setData({
            intro: e.detail.value
        });
    },
    handleIntroLX: function() {
        h.default.moduleClick("b_gc_bfmja0k6_mc");
    },
    handleSave: g.default.throttle(function() {
        var e = this;
        h.default.moduleClick("b_gc_vk04rej1_mc");
        var t = {
            token: this.data.token,
            platform: d.default.platformCode,
            weChatOpenId: this.data.userInfo && this.data.userInfo.openId || "",
            gender: this.data.gender,
            nickname: this.data.nickName,
            avatar: this.data.avatarUrl,
            birthday: this.data.birth,
            area: this.data.region,
            industry: this.data.industry,
            introduction: this.data.intro,
            backroomTag: this.data.backroomTag,
            ageTag: "",
            photos: this.data.photos.map(function(e) {
                return e.pictureUrl;
            })
        };
        return p.saveUserInfo(t).then(function(t) {
            if (t) if (t.isSuccess || !t.errorMessage) {
                if (t.isSuccess) {
                    v.showToast({
                        title: e.hasUploadNewAvatar() ? "头像审核中，审核通过后会自动更新" : t.errorMessage || "保存成功",
                        icon: "none",
                        duration: 2e3
                    });
                    var a = getCurrentPages();
                    if (a && a.length > 1) {
                        var n = a[a.length - 2];
                        setTimeout(function() {
                            v.navigateBack({
                                delta: 1,
                                success: function() {
                                    return n.initPage();
                                }
                            });
                        }, 500);
                    }
                }
            } else v.showToast({
                title: t.errorMessage,
                icon: "none",
                duration: 1e3
            }); else v.showToast({
                title: "保存失败",
                icon: "none",
                duration: 2e3
            });
        });
    }),
    hasUploadNewAvatar: function() {
        return this.data.photos.some(function(e) {
            return null === e.status;
        });
    },
    removeAvatar: function(e) {
        var t = this;
        return function() {
            var a, n;
            return m.async(function(r) {
                for (;;) switch (r.prev = r.next) {
                  case 0:
                    return a = e.detail.index, n = t.data.photos, r.prev = 2, r.next = 5, m.awrap(c.default.confirm({
                        message: "确定要删除这张头像吗？",
                        confirmButtonText: "确定删除",
                        cancelButtonText: "取消"
                    }));

                  case 5:
                    n.splice(a, 1), t.setData({
                        photos: n
                    }), (0, s.default)({
                        message: "已删除"
                    }), r.next = 13;
                    break;

                  case 10:
                    r.prev = 10, r.t0 = r.catch(2), console.error(r.t0);

                  case 13:
                  case "end":
                    return r.stop();
                }
            }, null, null, [ [ 2, 10 ] ], Promise);
        }();
    },
    unshiftAvatar: function(e) {
        var a = e.detail.index, n = this.data.photos;
        n.unshift.apply(n, t(n.splice(a, 1))), this.setData({
            photos: n
        });
    },
    onUpload: function() {
        return function() {
            var e, t;
            return m.async(function(a) {
                for (;;) switch (a.prev = a.next) {
                  case 0:
                    return a.prev = 0, a.next = 3, m.awrap(u.default.chooseImage({
                        _mt: {
                            sceneToken: l.WX_SCENETOKENS.CHOOSEIMAGE_AVATAR
                        },
                        count: 1,
                        sizeType: [ "original", "compressed" ],
                        sourceType: [ "album", "camera" ]
                    }));

                  case 3:
                    e = a.sent, (t = e.tempFilePaths) && t[0] && v.navigateTo({
                        url: "/pages/user-profile/avatar-pick/index?from=2&avatarUrl=" + encodeURIComponent(t[0])
                    }), a.next = 11;
                    break;

                  case 8:
                    a.prev = 8, a.t0 = a.catch(0), console.error(a.t0);

                  case 11:
                  case "end":
                    return a.stop();
                }
            }, null, null, [ [ 0, 8 ] ], Promise);
        }();
    },
    onPreview: function(e) {
        var t = this.data.photos, a = e.detail.item;
        v.previewImage({
            current: a.pictureUrl,
            urls: t.map(function(e) {
                return e.pictureUrl;
            }),
            _mt: {
                sceneToken: l.WX_SCENETOKENS.PREVIEWIMAGE
            }
        });
    },
    onUploadSuccess: function(e) {
        var t = e.url, a = this.data.photos;
        a.push({
            pictureUrl: t,
            status: null
        }), this.setData({
            photos: a
        });
    }
});