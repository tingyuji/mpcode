function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

var n = e(require("../../../utils/index")), t = e(require("../../../common/login")), a = e(require("../../../common/lx")), o = e(require("../../../common/config")), r = function(e) {
    if (e && e.__esModule) return e;
    var n = {};
    if (null != e) for (var t in e) Object.prototype.hasOwnProperty.call(e, t) && (n[t] = e[t]);
    return n.default = e, n;
}(require("../index/api")), c = require("../../../npm/regenerator-runtime/runtime.js"), s = require("../../../npm/@mtfe/weapp-privacy-api/index.js").default, u = n.default.Event, i = n.default.EVENT_TYPE, l = {
    POST: 1,
    CONTENT: 2,
    COLLECT: 3
};

Page({
    data: {
        token: "",
        postShow: 1,
        contentShow: 1,
        collectShow: 1
    },
    hasChanged: !1,
    initLogin: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0], n = this;
        return function() {
            var a;
            return c.async(function(o) {
                for (;;) switch (o.prev = o.next) {
                  case 0:
                    return o.next = 2, c.awrap(t.default.mtDefaultLogin({
                        isBind: e
                    }));

                  case 2:
                    if (a = o.sent) {
                        o.next = 5;
                        break;
                    }
                    return o.abrupt("return");

                  case 5:
                    n.data.token = a.token || a.userInfo && a.userInfo.token || "";

                  case 6:
                  case "end":
                    return o.stop();
                }
            }, null, null, null, Promise);
        }();
    },
    onChangePost: function(e) {
        var n = this;
        return function() {
            var t, o;
            return c.async(function(u) {
                for (;;) switch (u.prev = u.next) {
                  case 0:
                    return t = e.detail, a.default.moduleClick("b_gc_yvv1s171_mc", {
                        select_status_change: 1 === t ? 1 : 0
                    }), u.next = 4, c.awrap(r.setUserPrivacy({
                        token: n.data.token,
                        privacytype: l.POST,
                        showtype: t
                    }));

                  case 4:
                    (o = u.sent).isSuccess && (n.setData({
                        postShow: t
                    }), n.hasChanged = !0, s.showToast({
                        icon: "none",
                        title: "设置修改成功",
                        duration: 1e3
                    }));

                  case 6:
                  case "end":
                    return u.stop();
                }
            }, null, null, null, Promise);
        }();
    },
    onChangeContent: function(e) {
        var n = this;
        return function() {
            var t, o;
            return c.async(function(u) {
                for (;;) switch (u.prev = u.next) {
                  case 0:
                    return t = e.detail, a.default.moduleClick("b_gc_x7aztpkc_mc", {
                        select_status_change: 1 === t ? 1 : 0
                    }), u.next = 4, c.awrap(r.setUserPrivacy({
                        token: n.data.token,
                        privacytype: l.CONTENT,
                        showtype: t
                    }));

                  case 4:
                    (o = u.sent).isSuccess && (n.setData({
                        contentShow: t
                    }), n.hasChanged = !0, s.showToast({
                        icon: "none",
                        title: "设置修改成功",
                        duration: 1e3
                    }));

                  case 6:
                  case "end":
                    return u.stop();
                }
            }, null, null, null, Promise);
        }();
    },
    onChangeCollect: function(e) {
        var n = this;
        return function() {
            var t, o;
            return c.async(function(u) {
                for (;;) switch (u.prev = u.next) {
                  case 0:
                    return t = e.detail, a.default.moduleClick("b_gc_k285nu44_mc", {
                        select_status_change: 1 === t ? 1 : 0
                    }), u.next = 4, c.awrap(r.setUserPrivacy({
                        token: n.data.token,
                        privacytype: l.COLLECT,
                        showtype: t
                    }));

                  case 4:
                    (o = u.sent).isSuccess && (n.setData({
                        collectShow: t
                    }), n.hasChanged = !0, s.showToast({
                        icon: "none",
                        title: "设置修改成功",
                        duration: 1e3
                    }));

                  case 6:
                  case "end":
                    return u.stop();
                }
            }, null, null, null, Promise);
        }();
    },
    onLoad: function() {
        var e = this;
        return function() {
            var n;
            return c.async(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.prev = 0, t.next = 3, c.awrap(e.initLogin(!0));

                  case 3:
                    return t.next = 5, c.awrap(r.fetchUserPrivacy({
                        token: e.data.token
                    }));

                  case 5:
                    (n = t.sent) && e.setData({
                        postShow: n.postShow || 1,
                        contentShow: n.contentShow || 1,
                        collectShow: n.collectShow || 1
                    }), t.next = 12;
                    break;

                  case 9:
                    t.prev = 9, t.t0 = t.catch(0), console.error(t.t0);

                  case 12:
                  case "end":
                    return t.stop();
                }
            }, null, null, [ [ 0, 9 ] ], Promise);
        }();
    },
    onReady: function() {},
    onShow: function() {
        a.default.pageView("c_gc_promo82z", {
            cat_id: o.default.catId
        });
    },
    onHide: function() {},
    onUnload: function() {
        this.hasChanged && u.emit(i.PRIVACY_SETTING_CHANGE);
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});