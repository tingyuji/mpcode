function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

var n = e(require("../../../npm/@dzfe/wx-api-promisify/dist/index.js")), t = e(require("../../../common/login")), o = e(require("../../../common/config")), a = e(require("../../../common/lx")), i = e(require("../../../utils/index")), u = require("../../../npm/@mtfe/weapp-privacy-api/index.js").default, l = i.default.EVENT_TYPE, c = i.default.Event, r = getApp();

Page({
    data: {
        showDebugButton: !1,
        miniProgramVersion: "0.8.2"
    },
    handlePrivacySetting: function() {
        a.default.moduleClick("b_gc_rh4w3lq0_mc"), n.default.navigateTo({
            url: "/pages/user-profile/privacy/index"
        });
    },
    handleContact: function() {
        a.default.moduleClick("b_gc_ulmf7a70_mc"), u.navigateTo({
            url: "/pages/user-profile/contact/index"
        });
    },
    handleFeedbackLX: function() {
        a.default.moduleClick("b_gc_6tkei25p_mc");
    },
    handleLogout: function() {
        t.default.loginout().then(function() {
            a.default.moduleClick("b_gc_alhg0y9k_mc"), u.showToast({
                title: "退出成功",
                icon: "none",
                duration: 1e3
            }), c.emit(l.USER_LOGOUT), r.globalData && (r.globalData.userInfo = null);
            var e = getCurrentPages();
            e && e.length > 1 && (e[e.length - 2].pageReset(), u.switchTab({
                url: "/pages/user-profile/index/index"
            }));
        });
    },
    onLoad: function() {
        this.handleShowDebugBtn();
    },
    onReady: function() {},
    onShow: function() {
        a.default.pageView("c_gc_bx7r5qal", {
            cat_id: o.default.catId
        });
    },
    handleShowDebugBtn: function() {
        "wx" === o.default.platform && "develop" === u.getAccountInfoSync().miniProgram.envVersion && this.setData({
            showDebugButton: !0
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});