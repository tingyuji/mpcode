function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.saveWxDetail = function(e) {
    return new Promise(function(r, t) {
        n.request({
            url: o.SAVE_WX_DETAIL,
            data: e,
            method: "post",
            success: function(e) {
                r(e);
            },
            fail: function(e) {
                t(e);
            }
        });
    }).then(function(e) {
        var r = e.data;
        if (200 === r.code && r.msg) return r.msg;
        throw new Error("请求数据失败");
    }).catch(function(e) {
        return console.error("saveWxDetail", e), null;
    });
}, exports.fechUserInfo = function(e) {
    return new Promise(function(r, t) {
        n.request({
            url: o.USER_INFO,
            data: e,
            header: {},
            success: function(e) {
                r(e);
            },
            fail: function(e) {
                t(e);
            }
        });
    }).then(function(e) {
        var r = e.data;
        if (200 === r.code && r.msg) return r.msg;
        throw new Error("请求数据失败");
    }).catch(function(e) {
        return console.error("fechUserInfo", e), null;
    });
}, exports.fetchPostList = function(e) {
    return new Promise(function(r, t) {
        n.request({
            url: o.POST_LIST,
            data: e,
            header: {},
            success: function(e) {
                r(e);
            },
            fail: function(e) {
                t(e);
            }
        });
    }).then(function(e) {
        var r = e.data;
        if (200 === r.code && r.msg) return r.msg;
        throw new Error("请求数据失败");
    }).catch(function(e) {
        return console.error("fetchPostList", e), null;
    });
}, exports.fetchShareInfo = function(e) {
    return new Promise(function(r, t) {
        n.request({
            url: o.FETCH_SHARE_INFO,
            data: e,
            method: "POST",
            success: function(e) {
                r(e);
            },
            fail: function(e) {
                t(e);
            }
        });
    }).then(function(e) {
        var r = e.data;
        if (200 === r.code && r.msg) return r.msg;
        throw new Error("请求数据失败");
    }).catch(function(e) {
        return console.error("fetchPostList", e), null;
    });
}, exports.fetchUserPrivacy = function(e) {
    return new Promise(function(r, t) {
        n.request({
            url: o.FETCH_USER_PRIVACY,
            data: e,
            header: {},
            success: function(e) {
                r(e);
            },
            fail: function(e) {
                t(e);
            }
        });
    }).then(function(e) {
        var r = e.data;
        if (200 === r.code && r.msg) return r.msg;
        throw new Error("请求数据失败");
    }).catch(function(e) {
        return console.error("fetchUserPrivacy", e), null;
    });
}, exports.setUserPrivacy = function(e) {
    return new Promise(function(r, t) {
        n.request({
            url: o.SET_USER_PRIVACY,
            data: e,
            header: {},
            success: function(e) {
                r(e);
            },
            fail: function(e) {
                t(e);
            }
        });
    }).then(function(e) {
        var r = e.data;
        if (200 === r.code && r.msg) return r.msg;
        throw new Error("请求数据失败");
    }).catch(function(e) {
        return console.error("setUserPrivacy", e), null;
    });
}, exports.getTabCountInfo = function(e) {
    return new Promise(function(r, t) {
        n.request({
            url: o.TAB_COUNT_INFO,
            data: e,
            header: {},
            success: function(e) {
                r(e);
            },
            fail: function(e) {
                t(e);
            }
        });
    }).then(function(e) {
        var r = e.data;
        if (200 === r.code && r.msg) return r.msg;
        throw new Error("请求数据失败");
    }).catch(function(e) {
        return console.error("getTabCountInfo", e), null;
    });
}, exports.fetchContentList = function(e) {
    return new Promise(function(r, t) {
        n.request({
            url: o.CONTENT_LIST,
            data: e,
            header: {},
            success: function(e) {
                r(e);
            },
            fail: function(e) {
                t(e);
            }
        });
    }).then(function(e) {
        var r = e.data;
        if (200 === r.code && r.msg) return r.msg;
        throw new Error("请求数据失败");
    }).catch(function(e) {
        return console.error("fetchContentList", e), null;
    });
}, exports.fetchCollectionList = function(e) {
    return new Promise(function(r, t) {
        n.request({
            url: o.COLLECTION_LIST,
            data: e,
            header: {},
            success: function(e) {
                r(e);
            },
            fail: function(e) {
                t(e);
            }
        });
    }).then(function(e) {
        var r = e.data;
        if (200 === r.code && r.msg) return r.msg;
        throw new Error("请求数据失败");
    }).catch(function(e) {
        return console.error("fetchCollectionList", e), null;
    });
}, exports.removeMasterPost = function(e) {
    return new Promise(function(r, t) {
        n.request({
            url: o.MASTER_POST_REMOVE,
            data: e,
            header: {},
            success: function(e) {
                r(e);
            },
            fail: function(e) {
                t(e);
            }
        });
    }).then(function(e) {
        var r = e.data;
        if (200 === r.code && r.msg) return r.msg;
        throw new Error("请求数据失败");
    }).catch(function(e) {
        return console.error("removeMasterPost", e), null;
    });
}, exports.removeGuestPost = function(e) {
    return r.default.request({
        url: o.GUEST_POST_REMOVE,
        data: e,
        header: {}
    }).then(function(e) {
        var r = e.data;
        if (200 === r.code && r.msg) return r.msg;
        throw new Error("请求数据失败");
    }).catch(function(e) {
        return console.error("removeGuestPost", e), null;
    });
}, exports.feedCollect = function(e) {
    return new Promise(function(r, t) {
        n.request({
            url: o.FEEDS_COLLECT,
            data: e,
            method: "POST",
            header: {},
            success: function(e) {
                r(e);
            },
            fail: function(e) {
                t(e);
            }
        });
    }).then(function(e) {
        var r = e.data;
        if (200 === r.code && r.msg) return r.msg;
        throw new Error("请求数据失败");
    }).catch(function(e) {
        return console.error("feedCollect", e), null;
    });
}, exports.acceptCoupon = function(e) {
    return r.default.request({
        url: o.ACCEPT_COUPON,
        data: e,
        header: {}
    }).then(function(e) {
        var r = e.data;
        if (200 === r.code && r.msg) return r.msg;
        throw new Error("请求数据失败");
    }).catch(function(e) {
        return console.error("acceptCoupon", e), null;
    });
}, exports.tipLog = function(e) {
    return new Promise(function(r, t) {
        n.request({
            url: o.EDIT_TIP_LOG,
            data: e,
            method: "GET",
            header: {},
            success: function(e) {
                r(e);
            },
            fail: function(e) {
                t(e);
            }
        });
    }).then(function(e) {
        var r = e.data;
        if (200 === r.code && r.msg) return r.msg;
        throw new Error("请求数据失败");
    }).catch(function(e) {
        return console.error("tipLog", e), null;
    });
}, exports.toggleMasterPostPrivacy = function(e) {
    return r.default.request({
        url: o.TOGGLE_MASTER_POST_PRIVACY,
        data: e,
        header: {}
    }).then(function(e) {
        var r = e.data;
        if (200 === r.code && r.msg) return r.msg;
        throw new Error("请求数据失败");
    }).catch(function(e) {
        return console.error("toggleMasterPostPrivacy", e), null;
    });
}, exports.toggleGuestPostPrivacy = function(e) {
    return r.default.request({
        url: o.TOGGLE_GUEST_POST_PRIVACY,
        data: e,
        header: {}
    }).then(function(e) {
        var r = e.data;
        if (200 === r.code && r.msg) return r.msg;
        throw new Error("请求数据失败");
    }).catch(function(e) {
        return console.error("toggleGuestPostPrivacy", e), null;
    });
}, exports.getWalletPath = function(e) {
    return r.default.request({
        url: o.WALLET_PATH,
        data: e
    }).then(function(e) {
        var r = e.data;
        if (200 === r.code && r.msg) return r.msg;
        throw new Error("请求数据失败");
    }).catch(function(e) {
        return console.error("getWalletPath", e), null;
    });
};

var r = e(require("../../../npm/@dzfe/wx-api-promisify/dist/index.js")), t = e(require("../../../common/config")), n = require("../../../npm/@mtfe/weapp-privacy-api/index.js").default, o = {
    USER_INFO: t.default.gpower_domain + "/api/gpower/profile/user/tags",
    FETCH_USER_PRIVACY: t.default.dp_domain + "/api/joy/sharerelation/settings/privacy",
    SET_USER_PRIVACY: t.default.dp_domain + "/api/joy/sharerelation/settings/privacy/set",
    POST_LIST: t.default.dp_domain + "/api/joy/sharerelation/profile/post/list",
    FETCH_SHARE_INFO: t.default.gpower_domain + "/api/gpower/post/load",
    CONTENT_LIST: t.default.dp_domain + "/api/joy/sharerelation/profile/content/publishment",
    COLLECTION_LIST: t.default.dp_domain + "/api/joy/sharerelation/profile/content/collection",
    FEEDS_COLLECT: t.default.dp_domain + "/api/joy/sharerelation/content/collect",
    MASTER_POST_REMOVE: t.default.dp_domain + "/api/joy/sharerelation/profile/post/master/block",
    GUEST_POST_REMOVE: t.default.dp_domain + "/api/joy/sharerelation/profile/post/guest/block",
    TAB_COUNT_INFO: t.default.dp_domain + "/api/joy/sharerelation/profile/count",
    EDIT_TIP_LOG: t.default.dp_domain + "/api/joy/sharerelation/global/userset/log",
    ACCEPT_COUPON: t.default.dp_domain + "/api/joy/sharerelation/market/coupon/receive",
    SAVE_WX_DETAIL: t.default.gpower_domain + "/api/gpower/wechat/save",
    TOGGLE_MASTER_POST_PRIVACY: t.default.dp_domain + "/api/joy/sharerelation/profile/post/master/private",
    TOGGLE_GUEST_POST_PRIVACY: t.default.dp_domain + "/api/joy/sharerelation/profile/post/guest/private",
    WALLET_PATH: t.default.gpower_domain + "/api/gpower/order/wallet/path"
};