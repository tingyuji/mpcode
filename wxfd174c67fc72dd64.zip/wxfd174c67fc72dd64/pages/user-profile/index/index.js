function t(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

function e(t) {
    if (Array.isArray(t)) {
        for (var e = 0, n = Array(t.length); e < t.length; e++) n[e] = t[e];
        return n;
    }
    return Array.from(t);
}

function n(t, e, n) {
    return e in t ? Object.defineProperty(t, e, {
        value: n,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : t[e] = n, t;
}

function a(t, e) {
    return u(t) || s(t, e) || i(t, e) || r();
}

function r() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}

function i(t, e) {
    if (t) {
        if ("string" == typeof t) return o(t, e);
        var n = Object.prototype.toString.call(t).slice(8, -1);
        return "Object" === n && t.constructor && (n = t.constructor.name), "Map" === n || "Set" === n ? Array.from(t) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? o(t, e) : void 0;
    }
}

function o(t, e) {
    (null == e || e > t.length) && (e = t.length);
    for (var n = 0, a = new Array(e); n < e; n++) a[n] = t[n];
    return a;
}

function s(t, e) {
    var n = null == t ? null : "undefined" != typeof Symbol && t[Symbol.iterator] || t["@@iterator"];
    if (null != n) {
        var a, r, i = [], o = !0, s = !1;
        try {
            for (n = n.call(t); !(o = (a = n.next()).done) && (i.push(a.value), !e || i.length !== e); o = !0) ;
        } catch (t) {
            s = !0, r = t;
        } finally {
            try {
                o || null == n.return || n.return();
            } finally {
                if (s) throw r;
            }
        }
        return i;
    }
}

function u(t) {
    if (Array.isArray(t)) return t;
}

var l = t(require("../../../npm/@dzfe/wx-api-promisify/dist/index.js")), c = require("../../../common/wx-privacy-constant"), f = function(t) {
    if (t && t.__esModule) return t;
    var e = {};
    if (null != t) for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n]);
    return e.default = t, e;
}(require("./api")), d = t(require("../../../common/config")), p = t(require("../../../common/login")), h = t(require("../../../common/lx")), m = t(require("../../../utils/index")), b = t(require("../../../utils/dialog")), g = t(require("../../../utils/toast")), v = require("../../../npm/regenerator-runtime/runtime.js"), x = require("../../../npm/@mtfe/weapp-privacy-api/index.js").default, T = m.default.getNodeRect, w = m.default.transformNum, k = m.default.nextTick, P = m.default.rpx2px, y = m.default.removeUrlSliceAffix, C = m.default.Event, _ = m.default.EVENT_TYPE, I = getApp();

Page({
    data: {
        initStatusOver: !1,
        userInfo: null,
        navbarHeight: 88,
        headerHeight: 157,
        tabs: [ {
            label: "拼场",
            num: 0,
            value: 0,
            show: !0,
            lock: !1,
            children: [ {
                label: "我发起的",
                value: 0,
                num: 0
            }, {
                label: "我报名的",
                value: 1,
                num: 0
            } ]
        }, {
            label: "内容",
            value: 1,
            num: 0,
            show: !0,
            lock: !1,
            children: [ {
                label: "笔记",
                value: 300,
                num: 0
            }, {
                label: "评价",
                value: 400,
                num: 0
            } ]
        }, {
            label: "收藏",
            value: 2,
            num: 0,
            show: !0,
            lock: !1,
            children: [ {
                label: "笔记",
                value: 300,
                num: 0
            }, {
                label: "评价",
                value: 400,
                num: 0
            } ]
        } ],
        currentTab: 0,
        subCurrentTabList: [ 0, 0, 0 ],
        headHeight: 0,
        isFixed: !1,
        showPlayer: !1,
        curPlayers: [],
        titleDes: "",
        emptyDes: "",
        postMaskId: "",
        token: "",
        cityInfo: {},
        lat: "",
        lng: "",
        listPageNum: [ 1, 1, 1 ],
        listHasNext: [ !0, !0, !0 ],
        listLoading: [ !1, !1, !1 ],
        listHasInitialized: [ !1, !1, !1 ],
        lock: [ !1, !1, !1 ],
        listData: [ [], [], [] ],
        showOperationPopup: !1,
        currentPost: null,
        changeIndex: 0,
        scrollTop: 0,
        navBackgroundOpacity: 0,
        showContentTip: !0,
        tipStyle: "",
        showSubscribe: !1,
        isPostPrivate: !1,
        isTalentPublishSuccess: !1,
        merchantEntrance: null
    },
    isFirstLoad: !0,
    currentPostIndex: null,
    onLoad: function(t) {
        var e = this;
        return v.async(function(n) {
            for (;;) switch (n.prev = n.next) {
              case 0:
                return C.on(_.PRIVACY_SETTING_CHANGE, e.onPrivacyChange, e), C.on(_.TALENT_ACTIVITY_PUBLISH_SUCCESS, e.onTalentPublishSuccess, e), 
                n.next = 4, v.awrap(e.getNavbarHeight());

              case 4:
                e.initPage(t);

              case 5:
              case "end":
                return n.stop();
            }
        }, null, null, null, Promise);
    },
    onReady: function() {},
    onShow: function() {
        var t = this, e = this.data, n = e.tabs, a = e.currentTab;
        e.listData;
        if (h.default.pageView("c_gc_xmpyzhph", {
            cat_id: d.default.catId
        }), n.filter(function(t) {
            return !!t.show;
        }).forEach(function(t, e) {
            h.default.moduleView("b_gc_ptxhx6uo_mv", {
                index: e,
                title: t.label
            });
        }), n[a].children.forEach(function(t, e) {
            h.default.moduleView("b_gc_j8mk117e_mv", {
                index: e,
                title: t.label
            });
        }), "function" == typeof this.getTabBar && this.getTabBar()) {
            var r = this.getTabBar();
            r.refreshSelectedTab && r.refreshSelectedTab();
        }
        this.isFirstLoad ? this.isFirstLoad = !1 : p.default.mtDefaultLogin({
            isBind: !1
        }).then(function(e) {
            (e.token || e.userInfo && e.userInfo.token || "") !== t.data.token && t.initPage(), 
            t.initContentTip();
        });
    },
    closeNotice: function() {
        h.default.moduleClick("b_gc_shtv94yo_mc"), this.setData({
            showSubscribe: !1
        });
    },
    subscribe: function() {
        h.default.moduleClick("b_gc_6t2ybtxj_mc");
        var t = "/pages/webview/webview/index?weburl=" + encodeURIComponent(this.data.userInfo.floatingTips.subscribeWeChatJumpUrl);
        x.navigateTo({
            url: t
        });
    },
    onHide: function() {
        this.setData({
            showSubscribe: !1
        });
    },
    onUnload: function() {
        C.off(_.PRIVACY_SETTING_CHANGE, this.onPrivacyChange, this), C.off(_.TALENT_ACTIVITY_PUBLISH_SUCCESS, this.onTalentPublishSuccess, this);
    },
    onPullDownRefresh: function() {
        this.onRefresh(), x.stopPullDownRefresh();
    },
    onReachBottom: function() {
        this.loadListData();
    },
    onShareAppMessage: function() {
        var t = this;
        return function() {
            var e, n, a, r, i, o;
            return v.async(function(s) {
                for (;;) switch (s.prev = s.next) {
                  case 0:
                    return e = function() {
                        return new Promise(function(t) {
                            setTimeout(function() {
                                t();
                            }, 100);
                        });
                    }, s.next = 3, v.awrap(e());

                  case 3:
                    return s.next = 5, v.awrap(t.getPostShareInfo());

                  case 5:
                    return n = s.sent, a = n || {}, r = a.title, i = a.path, o = a.image, s.abrupt("return", {
                        title: r,
                        path: i,
                        imageUrl: o
                    });

                  case 8:
                  case "end":
                    return s.stop();
                }
            }, null, null, null, Promise);
        }();
    },
    onRedirectToFollowPage: function(t) {
        var e = this.data.userInfo, n = t.detail;
        e && x.navigateTo({
            url: "/pages/individual/follow/index?type=" + n + "&name=" + encodeURIComponent(e.nickName) + "&from=2"
        });
    },
    updateScrollViewPosition: function() {
        var t = this;
        return v.async(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                k(function() {
                    var e = t.data, n = e.headerHeight, a = e.isFixed;
                    t.setData({
                        scrollTop: a ? n + 15 : 0
                    });
                });

              case 1:
              case "end":
                return e.stop();
            }
        }, null, null, null, Promise);
    },
    toggleTabbar: function(t) {
        "function" == typeof this.getTabBar && this.getTabBar() && this.getTabBar().setData({
            show: t
        });
    },
    onClosePopup: function() {
        var t = this;
        this.setData({
            showOperationPopup: !1
        }), this.currentPostIndex = null, this.toggleTabbar(!0), setTimeout(function() {
            t.setData({
                currentPost: null
            });
        }, 200);
    },
    onOpenPopup: function(t) {
        var e = this.data, n = e.currentTab, a = e.listData, r = e.subCurrentTabList, i = e.tabs, o = t.target.dataset.index;
        this.currentPostIndex = o, this.setData({
            showOperationPopup: !0,
            currentPost: a[n][o]
        }), this.toggleTabbar(!1), h.default.moduleView("b_gc_tmhi9tj3_mv", {}), h.default.moduleClick("b_gc_ujo4m2gu_mc", {
            index: o,
            is_owner: 0 === r[0] ? "1" : "0",
            select_index: r[n],
            select_name: i[n].children[r[n]].label
        });
    },
    onTapVisible: function() {
        var t = this;
        return function() {
            var e, a, r, i, o, s, u, l, c, d, p, m;
            return v.async(function(b) {
                for (;;) switch (b.prev = b.next) {
                  case 0:
                    if (e = t.data, a = e.currentPost, r = e.token, i = e.currentTab, o = e.subCurrentTabList, 
                    s = e.isPostPrivate, u = t.currentPostIndex, a && r && 0 === i) {
                        b.next = 4;
                        break;
                    }
                    return b.abrupt("return");

                  case 4:
                    if (t.onClosePopup(), l = "", 0 !== o[0] || 3 === a.status) {
                        b.next = 10;
                        break;
                    }
                    l = "想更改可见状态请先结束拼场", b.next = 21;
                    break;

                  case 10:
                    if (!s) {
                        b.next = 14;
                        break;
                    }
                    l = "请前往设置页进行修改", b.next = 21;
                    break;

                  case 14:
                    return c = a.postMaskId, d = a.isPrivate, h.default.moduleClick(d ? "b_gc_7kk5kx22_mc" : "b_gc_16rz1ggv_mc", {}), 
                    p = 0 === o[0] ? f.toggleMasterPostPrivacy : f.toggleGuestPostPrivacy, b.next = 19, 
                    v.awrap(p({
                        token: r,
                        postmaskid: c,
                        isprivate: 1 - d
                    }));

                  case 19:
                    (m = b.sent) && m.errorMessage ? l = m.errorMessage : (l = "设置成功", setTimeout(function() {
                        t.setData(n({}, "listData[0][" + u + "].isPrivate", 1 - d));
                    }, 200));

                  case 21:
                    l && (0, g.default)({
                        message: l,
                        selector: "#mtgroup-toast-no-icon"
                    });

                  case 22:
                  case "end":
                    return b.stop();
                }
            }, null, null, null, Promise);
        }();
    },
    onTapDelete: function() {
        var t = this;
        return function() {
            var e, n, a, r, i, o;
            return v.async(function(s) {
                for (;;) switch (s.prev = s.next) {
                  case 0:
                    if (e = t.data, n = e.currentPost, a = e.token, r = e.subCurrentTabList, n && a) {
                        s.next = 3;
                        break;
                    }
                    return s.abrupt("return");

                  case 3:
                    if (3 === n.status) {
                        s.next = 7;
                        break;
                    }
                    return (0, g.default)({
                        message: "想删除帖子请先结束/退出拼场",
                        selector: "#mtgroup-toast-no-icon"
                    }), t.onClosePopup(), s.abrupt("return");

                  case 7:
                    return s.prev = 7, t.onClosePopup(), h.default.moduleView("b_gc_odfxv970_mv"), s.next = 12, 
                    v.awrap(b.default.confirm({
                        selector: "#mtgroup-dialog-delete",
                        title: "确定删除此拼场？",
                        message: "后续无法恢复",
                        confirmButtonText: "确定",
                        cancelButtonText: "取消"
                    }));

                  case 12:
                    return h.default.moduleClick("b_gc_f4ktupat_mc"), i = 0 === r[0] ? f.removeMasterPost : f.removeGuestPost, 
                    s.next = 16, v.awrap(i({
                        token: a,
                        postmaskid: n.postMaskId
                    }));

                  case 16:
                    if (!(o = s.sent) || o.errorMessage) {
                        s.next = 26;
                        break;
                    }
                    return t.initTab(!1), t.resetListStatus(), s.next = 22, v.awrap(t.resetListData());

                  case 22:
                    (0, g.default)({
                        message: "已删除此拼场",
                        selector: "#mtgroup-toast-no-icon"
                    }), t.updateScrollViewPosition(), s.next = 27;
                    break;

                  case 26:
                    (0, g.default)({
                        message: o && o.errorMessage || "操作失败",
                        selector: "#mtgroup-toast-no-icon"
                    });

                  case 27:
                    s.next = 32;
                    break;

                  case 29:
                    s.prev = 29, s.t0 = s.catch(7), console.log(s.t0);

                  case 32:
                  case "end":
                    return s.stop();
                }
            }, null, null, [ [ 7, 29 ] ], Promise);
        }();
    },
    feedClick: function(t) {
        x.navigateTo({
            url: t.detail.feed.contentDetailUrl
        });
    },
    collectClick: function(t) {
        var e = this;
        return function() {
            var n, a, r, i, o, s, u;
            return v.async(function(l) {
                for (;;) switch (l.prev = l.next) {
                  case 0:
                    if (n = t.detail.item, a = n.isCollected, r = 1 === a ? 0 : 1, i = n.contentType, 
                    o = n.contentId, s = {
                        contentid: o,
                        contenttype: i,
                        token: e.data.token,
                        actiontype: r
                    }, l.prev = 5, 0 !== r) {
                        l.next = 9;
                        break;
                    }
                    return l.next = 9, v.awrap(b.default.confirm({
                        message: "确定要取消收藏吗？",
                        confirmButtonText: "确定",
                        cancelButtonText: "取消"
                    }));

                  case 9:
                    return l.next = 11, v.awrap(f.feedCollect(s));

                  case 11:
                    if (!(u = l.sent) || !u.isSuccess) {
                        l.next = 20;
                        break;
                    }
                    return e.resetListStatus(), l.next = 16, v.awrap(e.resetListData(!0));

                  case 16:
                    (0, g.default)({
                        message: u && u.resultMsg || "操作成功",
                        selector: "#mtgroup-toast-no-icon"
                    }), e.updateScrollViewPosition(), l.next = 21;
                    break;

                  case 20:
                    (0, g.default)({
                        message: u && u.resultMsg || "操作失败",
                        selector: "#mtgroup-toast-no-icon"
                    });

                  case 21:
                    return l.next = 23, v.awrap(e.initTab(!1));

                  case 23:
                    l.next = 28;
                    break;

                  case 25:
                    l.prev = 25, l.t0 = l.catch(5), console.log(l.t0);

                  case 28:
                  case "end":
                    return l.stop();
                }
            }, null, null, [ [ 5, 25 ] ], Promise);
        }();
    },
    initPage: function() {
        var t = this;
        this.data.listPageNum = [ 1, 1, 1 ], this.data.listHasNext = [ !0, !0, !0 ], this.data.listLoading = [ !1, !1, !1 ], 
        this.setData({
            listData: [ [], [], [] ]
        }), p.default.mtDefaultLogin({
            isBind: !1
        }).then(function(e) {
            t.data.token = e.token || e.userInfo && e.userInfo.token || "", t.data.token ? t.getUserInfo().then(function() {
                t.data.userInfo && (t.saveWxInfo(), I.getCityInfo().then(function(e) {
                    t.data.cityInfo = e, t.data.lat = e.lat, t.data.lng = e.lng;
                }).then(function() {
                    return t.initTab();
                }).then(function() {
                    return t.resetListData();
                }).then(function() {
                    return t.setProfileTipStyle(), t.initContentTip();
                }));
            }) : t.setData({
                userInfo: null
            });
        });
    },
    initContentTip: function() {
        var t = this;
        return function() {
            var e, n, a, r, i;
            return v.async(function(o) {
                for (;;) switch (o.prev = o.next) {
                  case 0:
                    if (e = t.data, n = e.currentTab, a = e.userInfo, r = e.token, a && r) {
                        o.next = 3;
                        break;
                    }
                    return o.abrupt("return");

                  case 3:
                    i = x.getStorageSync("PROFILE_CONTENT_TIP"), 1 !== n || i ? t.setData({
                        showContentTip: !1
                    }) : t.setData({
                        showContentTip: !0
                    }, function() {
                        x.setStorageSync("PROFILE_CONTENT_TIP", "1");
                    });

                  case 5:
                  case "end":
                    return o.stop();
                }
            }, null, null, null, Promise);
        }();
    },
    initTab: function() {
        var t = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0], e = this;
        return function() {
            var a, r, i, o, s, u, l, c, d, p, h, m, b, g, x, T, k;
            return v.async(function(P) {
                for (var y; ;) switch (P.prev = P.next) {
                  case 0:
                    return P.next = 2, v.awrap(f.fetchUserPrivacy({
                        token: e.data.token
                    }));

                  case 2:
                    if (a = P.sent) {
                        var C;
                        r = a.postShow, i = a.contentShow, o = a.collectShow, e.setData((C = {}, n(C, "tabs[0].lock", 2 === r), 
                        n(C, "tabs[1].lock", 2 === i), n(C, "tabs[2].lock", 2 === o), n(C, "isPostPrivate", 2 === r), 
                        C));
                    }
                    return P.next = 6, v.awrap(f.getTabCountInfo({
                        token: e.data.token
                    }));

                  case 6:
                    if (s = P.sent) {
                        P.next = 9;
                        break;
                    }
                    return P.abrupt("return");

                  case 9:
                    if (u = s.postPublishNum, l = void 0 === u ? 0 : u, c = s.postJoinNum, d = void 0 === c ? 0 : c, 
                    p = s.contentNoteNum, h = void 0 === p ? 0 : p, m = s.contentReviewNum, b = void 0 === m ? 0 : m, 
                    g = s.collectionNoteNum, x = void 0 === g ? 0 : g, T = s.collectionReviewNum, k = void 0 === T ? 0 : T, 
                    e.setData((y = {}, n(y, "tabs[0].num", w(l + d)), n(y, "tabs[0].children[0].num", w(l)), 
                    n(y, "tabs[0].children[1].num", w(d)), n(y, "tabs[1].num", w(h + b)), n(y, "tabs[1].children[0].num", w(h)), 
                    n(y, "tabs[1].children[1].num", w(b)), n(y, "tabs[2].num", w(x + k)), n(y, "tabs[2].children[0].num", w(x)), 
                    n(y, "tabs[2].children[1].num", w(k)), y)), t) if (l > 0 || d > 0) {
                        var _;
                        e.setData((_ = {
                            currentTab: 0
                        }, n(_, "subCurrentTabList[0]", l > 0 ? 0 : 1), n(_, "listHasInitialized[0]", !0), 
                        _));
                    } else if (h + b > 0) {
                        var I;
                        e.setData((I = {
                            currentTab: 1
                        }, n(I, "subCurrentTabList[1]", h > 0 ? 0 : 1), n(I, "listHasInitialized[1]", !0), 
                        I));
                    } else e.setData(n({}, "listHasInitialized[0]", !0));

                  case 12:
                  case "end":
                    return P.stop();
                }
            }, null, null, null, Promise);
        }();
    },
    saveWxInfo: function() {
        var t = I.globalData.userInfo, e = t.wxUserInfo, n = {
            platform: d.default.platformCode,
            token: this.data.token,
            weChatId: "",
            weChatNickname: e && e.nickName,
            weChatAvatar: e && e.avatarUrl,
            weChatMobile: "",
            weChatArea: e && e.country + "," + e.province + "," + e.city,
            weChatGender: e && e.gender,
            weChatOpenId: t.openId,
            weChatUnionId: t.unionId
        };
        return f.saveWxDetail(n).then(function(t) {
            t && t.isSuccess || console.error("保存微信信息", t);
        });
    },
    getUserInfo: function() {
        var t = this;
        return f.fechUserInfo({
            cityid: I.globalData.ci || 10,
            platform: d.default.platformCode,
            token: this.data.token
        }).then(function(e) {
            e && e.photos && e.photos.forEach(function(t) {
                t.pictureUrl = y(t.pictureUrl);
            }), t.setData({
                userInfo: e,
                merchantEntrance: e && e.merchantEntrance,
                showSubscribe: e.floatingTips && e.floatingTips.subscribeWeChatJumpUrl,
                initStatusOver: !0
            }, function() {
                t.getHeadHeight(), t.data.showSubscribe && h.default.moduleView("b_gc_kyt1q50h_mv");
                var n = e && e.floatingTips;
                n && n.editFloatingText && t.recordTiplog(202), n && n.subscribeWeChatJumpUrl && t.recordTiplog(203);
            });
        });
    },
    recordTiplog: function(t) {
        f.tipLog({
            token: this.data.token,
            type: t
        }).then(function(e) {
            e && e.isSuccess || console.error("全局用户红点记录接口失败" + t, e);
        });
    },
    getUserPostList: function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] && arguments[0], n = this;
        return function() {
            var a, r, i, o, s, u, l, c, p;
            return v.async(function(h) {
                for (;;) switch (h.prev = h.next) {
                  case 0:
                    if (a = n.data, r = a.listData, i = a.listLoading, o = a.listPageNum, s = a.listHasNext, 
                    u = a.userInfo, l = a.tabs, c = a.subCurrentTabList, u) {
                        h.next = 3;
                        break;
                    }
                    return h.abrupt("return");

                  case 3:
                    if (s[0] && !i[0]) {
                        h.next = 5;
                        break;
                    }
                    return h.abrupt("return");

                  case 5:
                    return p = l[0].children[c[0]], i[0] = !0, h.abrupt("return", f.fetchPostList({
                        type: p.value,
                        platform: d.default.platformCode,
                        token: n.data.token,
                        lat: n.data.lat,
                        lng: n.data.lng,
                        pagenum: n.data.listPageNum[0]
                    }).then(function(a) {
                        if (a) {
                            var u = a.posts || [];
                            o[0] += 1, s[0] = a.hasNext, r[0] && !t || (r[0] = []), r[0] = [].concat(e(r[0]), e(u)), 
                            n.setData({
                                listData: r,
                                listHasNext: s
                            });
                        }
                        setTimeout(function() {
                            i[0] = !1;
                        }, 100);
                    }));

                  case 8:
                  case "end":
                    return h.stop();
                }
            }, null, null, null, Promise);
        }();
    },
    getUserContentList: function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] && arguments[0], n = this;
        return function() {
            var a, r, i, o, s, u, l, c, d, p;
            return v.async(function(h) {
                for (;;) switch (h.prev = h.next) {
                  case 0:
                    if (a = n.data, r = a.listData, i = a.listLoading, o = a.listPageNum, s = a.listHasNext, 
                    u = a.token, l = a.userInfo, c = a.tabs, d = a.subCurrentTabList, l) {
                        h.next = 3;
                        break;
                    }
                    return h.abrupt("return");

                  case 3:
                    if (s[1] && !i[1]) {
                        h.next = 5;
                        break;
                    }
                    return h.abrupt("return");

                  case 5:
                    return p = c[1].children[d[1]], i[1] = !0, h.abrupt("return", f.fetchContentList({
                        pagenum: o[1],
                        contenttype: p.value,
                        token: u,
                        width: 343
                    }).then(function(a) {
                        if (a) {
                            var u = a.contentList || [];
                            s[1] = a.hasNext, r[1] && !t || (r[1] = []), r[1] = [].concat(e(r[1]), e(u)), o[1] += 1, 
                            n.setData({
                                listData: r,
                                listHasNext: s
                            });
                        }
                        setTimeout(function() {
                            i[1] = !1;
                        }, 100);
                    }));

                  case 8:
                  case "end":
                    return h.stop();
                }
            }, null, null, null, Promise);
        }();
    },
    getUserCollectionList: function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] && arguments[0], n = this;
        return function() {
            var a, r, i, o, s, u, l, c, d, p;
            return v.async(function(h) {
                for (;;) switch (h.prev = h.next) {
                  case 0:
                    if (a = n.data, r = a.listData, i = a.listLoading, o = a.listPageNum, s = a.listHasNext, 
                    u = a.token, l = a.userInfo, c = a.tabs, d = a.subCurrentTabList, l) {
                        h.next = 3;
                        break;
                    }
                    return h.abrupt("return");

                  case 3:
                    if (s[2] && !i[2]) {
                        h.next = 5;
                        break;
                    }
                    return h.abrupt("return");

                  case 5:
                    return p = c[2].children[d[2]], i[2] = !0, h.abrupt("return", f.fetchCollectionList({
                        pagenum: o[2],
                        contenttype: p.value,
                        token: u,
                        width: 343
                    }).then(function(a) {
                        if (a) {
                            var u = a.contentList || [];
                            s[2] = a.hasNext, r[2] && !t || (r[2] = []), r[2] = [].concat(e(r[2]), e(u)), o[2] += 1, 
                            n.setData({
                                listData: r,
                                listHasNext: s
                            });
                        }
                        setTimeout(function() {
                            i[2] = !1;
                        }, 100);
                    }));

                  case 8:
                  case "end":
                    return h.stop();
                }
            }, null, null, null, Promise);
        }();
    },
    getPostShareInfo: function() {
        var t = this;
        return function() {
            var e, n, a, r, i, o;
            return v.async(function(s) {
                for (;;) switch (s.prev = s.next) {
                  case 0:
                    return e = t.data.cityInfo, n = I.globalData.userInfo, a = n.openId, r = n.openIdCipher, 
                    i = n.uuid, s.next = 4, v.awrap(I.finger());

                  case 4:
                    return o = s.sent, s.abrupt("return", f.fetchShareInfo({
                        postmaskid: t.data.postMaskId,
                        platform: d.default.platformCode,
                        uacode: d.default.uaCode,
                        cityid: e.id,
                        fp: o,
                        uuid: i,
                        openid: a,
                        expoid: r
                    }));

                  case 6:
                  case "end":
                    return s.stop();
                }
            }, null, null, null, Promise);
        }();
    },
    handleLeftTap: function() {
        return v.async(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                h.default.moduleClick("b_gc_z4ssgawa_mc"), x.navigateTo({
                    url: "/pages/user-profile/setting/index"
                });

              case 2:
              case "end":
                return t.stop();
            }
        }, null, null, null, Promise);
    },
    onTabChange: function(t) {
        var e = this;
        return function() {
            var n, a, r, i, o;
            return v.async(function(s) {
                for (;;) switch (s.prev = s.next) {
                  case 0:
                    if (n = e.data, a = n.currentTab, r = n.listHasInitialized, i = n.tabs, o = t.detail.index, 
                    h.default.moduleClick("b_gc_ptxhx6uo_mc", {
                        index: o,
                        title: i[o].label
                    }), a !== t.detail.index) {
                        s.next = 5;
                        break;
                    }
                    return s.abrupt("return");

                  case 5:
                    if (e.setData({
                        currentTab: o
                    }), i[o].children && i[o].children.length && i[o].children.forEach(function(t, e) {
                        h.default.moduleView("b_gc_j8mk117e_mv", {
                            index: e,
                            title: t.label
                        });
                    }), r[o]) {
                        s.next = 11;
                        break;
                    }
                    return s.next = 10, v.awrap(e.resetListData());

                  case 10:
                    r[o] = !0;

                  case 11:
                    x.pageScrollTo({
                        scrollTop: 0
                    }), e.initContentTip();

                  case 13:
                  case "end":
                    return s.stop();
                }
            }, null, null, null, Promise);
        }();
    },
    onSubTabChange: function(t) {
        var e = this;
        return function() {
            var a, r, i, o, s, u;
            return v.async(function(l) {
                for (;;) switch (l.prev = l.next) {
                  case 0:
                    if (a = e.data, r = a.currentTab, i = a.subCurrentTabList, o = a.tabs, s = t.detail.index, 
                    u = i[r], h.default.moduleClick("b_gc_j8mk117e_mc", {
                        index: s,
                        title: o[r].children[u].label
                    }), u !== t.detail.index) {
                        l.next = 6;
                        break;
                    }
                    return l.abrupt("return");

                  case 6:
                    return e.setData(n({}, "subCurrentTabList[" + r + "]", s)), e.resetListStatus(), 
                    l.next = 10, v.awrap(e.resetListData());

                  case 10:
                    e.updateScrollViewPosition();

                  case 11:
                  case "end":
                    return l.stop();
                }
            }, null, null, null, Promise);
        }();
    },
    resetListStatus: function() {
        var t = this.data, e = t.currentTab, n = t.listHasNext, a = t.listPageNum, r = t.listLoading;
        n[e] = !0, r[e] = !1, a[e] = 1;
    },
    resetListData: function() {
        return this.loadListData(!0);
    },
    loadListData: function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] && arguments[0], e = this.data.currentTab;
        return 0 === e ? this.getUserPostList(t) : 1 === e ? this.getUserContentList(t) : 2 === e ? this.getUserCollectionList(t) : void 0;
    },
    handleLogin: function() {
        var t = this;
        p.default.mtDefaultLogin({
            isBind: !0
        }).then(function() {
            t.initPage();
        });
    },
    handleEdit: function() {
        h.default.moduleClick("b_gc_vwx96f29_mc"), this.closeProfileTip(), x.navigateTo({
            url: "/pages/user-profile/edit/index"
        });
    },
    onUserInfoTap: function() {
        h.default.moduleClick("b_gc_1cw3r7kd_mc");
    },
    handleToLower: function() {
        this.loadListData();
    },
    onOpenPlayers: function(t) {
        var e = t.detail;
        e.detailJumpUrl && x.navigateTo({
            url: e.detailJumpUrl
        });
    },
    onClosePlayers: function() {
        this.setData({
            showPlayer: !1,
            canScroll: !0
        }), this.toggleTabbar(!0);
    },
    onGoToBuy: function(t) {
        var e = this;
        return function() {
            var n, a, r, i, o, s, u, l, c, p, h;
            return v.async(function(m) {
                for (;;) switch (m.prev = m.next) {
                  case 0:
                    if (n = e.data, a = n.token, r = n.cityInfo, i = t.detail) {
                        m.next = 4;
                        break;
                    }
                    return m.abrupt("return");

                  case 4:
                    if (o = i || {}, s = o.buyJumpUrl, u = o.payButtonVO, l = o.payCouponVO, c = o.topicType, 
                    p = o.postMaskId, !l || 1 !== l.couponStatus) {
                        m.next = 13;
                        break;
                    }
                    return m.next = 8, v.awrap(f.acceptCoupon({
                        token: a,
                        platform: d.default.platformCode,
                        topictype: c,
                        mtcityid: r.id,
                        activitytype: u.activityType,
                        postmaskid: p
                    }));

                  case 8:
                    if (!(h = m.sent) || !h.isSuccess) {
                        m.next = 13;
                        break;
                    }
                    return (0, g.default)({
                        selector: "#auto-accept-succeed",
                        context: e,
                        duration: 1500
                    }), m.next = 13, v.awrap(new Promise(function(t) {
                        return setTimeout(t, 1200);
                    }));

                  case 13:
                    s && x.navigateTo({
                        url: s
                    });

                  case 14:
                  case "end":
                    return m.stop();
                }
            }, null, null, null, Promise);
        }();
    },
    onEditBtnTap: function(t) {
        var e = t.detail;
        x.navigateTo({
            url: e
        });
    },
    onGoToDetail: function(t) {
        var e = t.detail;
        e.detailJumpUrl && x.navigateTo({
            url: e.detailJumpUrl
        });
    },
    onAvatarTap: function() {
        this.handleAvatarLX();
    },
    onShare: function(t) {
        var e = t.detail;
        this.data.postMaskId = e.postMaskId;
    },
    onGoToOrder: function(t) {
        var e = t.detail;
        e.orderJumpUrl && (1 == e.orderPlatform && x.navigateToMiniProgram({
            appId: "wx734c1ad7b3562129",
            path: e.orderJumpUrl
        }), 2 == e.orderPlatform && x.navigateTo({
            url: e.orderJumpUrl
        }));
    },
    onGoToIM: function(t) {
        var e = t.detail.sharePostGroupChatVO;
        if (e.jumpUrl) {
            var n = function() {
                x.navigateTo({
                    url: e.jumpUrl,
                    fail: function() {
                        console.log("加入群聊跳转失败");
                    }
                });
            };
            1 === e.type ? x.requestSubscribeMessage({
                tmplIds: [ "r10jYbLvPA0Z64tc0mTRrvHZxBgt1uoORq3m-XVRSEM" ],
                complete: function() {
                    n();
                }
            }) : 2 === e.type && n();
        }
    },
    onPageScroll: function(t) {
        var e = t.scrollTop > this.data.headerHeight;
        this.data.isFixed !== e && this.setData({
            isFixed: e,
            navBackgroundOpacity: e ? 1 : 0
        });
    },
    onEmptyPostTap: function() {
        var t = this.data;
        0 === t.subCurrentTabList[t.currentTab] ? x.navigateTo({
            url: "/pages/publish/index/index"
        }) : x.switchTab({
            url: "/pages/home/index"
        });
    },
    pageReset: function() {
        this.setData({
            tabs: [ {
                label: "拼场",
                num: 0,
                value: 0,
                show: !0,
                lock: !1,
                children: [ {
                    label: "我发起的",
                    value: 0,
                    num: 0
                }, {
                    label: "我报名的",
                    value: 1,
                    num: 0
                } ]
            }, {
                label: "内容",
                value: 1,
                num: 0,
                show: !0,
                lock: !1,
                children: [ {
                    label: "笔记",
                    value: 300,
                    num: 0
                }, {
                    label: "评价",
                    value: 400,
                    num: 0
                } ]
            }, {
                label: "收藏",
                value: 2,
                num: 0,
                show: !0,
                lock: !1,
                children: [ {
                    label: "笔记",
                    value: 300,
                    num: 0
                }, {
                    label: "评价",
                    value: 400,
                    num: 0
                } ]
            } ],
            listPageNum: [ 1, 1, 1 ],
            listHasNext: [ !0, !0, !0 ],
            listLoading: [ !1, !1, !1 ],
            listHasInitialized: [ !1, !1, !1 ],
            lock: [ !1, !1, !1 ],
            listData: [ [], [], [] ],
            userInfo: null,
            token: null
        });
    },
    onRefresh: function() {
        var t = this;
        return v.async(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                if (!t._freshing) {
                    e.next = 2;
                    break;
                }
                return e.abrupt("return");

              case 2:
                if (t._freshing = !0, t.data.token) {
                    e.next = 6;
                    break;
                }
                return t._freshing = !1, e.abrupt("return");

              case 6:
                t.getUserInfo(), t.initTab(!1), t.resetListStatus(), t.resetListData().then(function() {
                    t._freshing = !1, x.showToast({
                        title: "数据更新成功",
                        icon: "none",
                        duration: 1e3
                    });
                }, function() {
                    t._freshing = !1;
                });

              case 10:
              case "end":
                return e.stop();
            }
        }, null, null, null, Promise);
    },
    getHeadHeight: function() {
        var t = this;
        return function() {
            var e, n, r, i;
            return v.async(function(o) {
                for (;;) switch (o.prev = o.next) {
                  case 0:
                    return o.next = 2, v.awrap(Promise.all([ T("#user-album"), T("#user-basic-info") ]));

                  case 2:
                    e = o.sent, n = a(e, 2), r = n[0].height, i = n[1].height, t.setData({
                        headerHeight: r + i - t.data.navbarHeight - P(48)
                    });

                  case 7:
                  case "end":
                    return o.stop();
                }
            }, null, null, null, Promise);
        }();
    },
    getNavbarHeight: function() {
        var t = this;
        return function() {
            var e, n, a;
            return v.async(function(r) {
                for (;;) switch (r.prev = r.next) {
                  case 0:
                    return r.next = 2, v.awrap(l.default.getSystemInfo());

                  case 2:
                    e = r.sent, n = e.statusBarHeight, a = e.system, t.setData({
                        navbarHeight: n + (a.toLowerCase().indexOf("ios") > -1 ? 44 : 48)
                    });

                  case 6:
                  case "end":
                    return r.stop();
                }
            }, null, null, null, Promise);
        }();
    },
    onImagePreview: function() {
        h.default.moduleClick("b_gc_qype9nwp_mc");
    },
    onIndicatorTap: function() {
        h.default.moduleClick("b_gc_6oikp3mh_mc");
    },
    onUpload: function() {
        return function() {
            var t, e;
            return v.async(function(n) {
                for (;;) switch (n.prev = n.next) {
                  case 0:
                    return h.default.moduleClick("b_gc_lqw8ekj9_mc"), n.prev = 1, n.next = 4, v.awrap(l.default.chooseImage({
                        count: 1,
                        sizeType: [ "original", "compressed" ],
                        sourceType: [ "album", "camera" ],
                        _mt: {
                            sceneToken: c.WX_SCENETOKENS.CHOOSEIMAGE_AVATAR
                        }
                    }));

                  case 4:
                    t = n.sent, (e = t.tempFilePaths) && e[0] && x.navigateTo({
                        url: "/pages/user-profile/avatar-pick/index?from=1&avatarUrl=" + encodeURIComponent(e[0])
                    }), n.next = 12;
                    break;

                  case 9:
                    n.prev = 9, n.t0 = n.catch(1), console.error(n.t0);

                  case 12:
                  case "end":
                    return n.stop();
                }
            }, null, null, [ [ 1, 9 ] ], Promise);
        }();
    },
    onUploadSuccess: function() {
        (0, g.default)({
            selector: "#mtgroup-toast-no-icon",
            message: "头像审核中，审核通过后会自动更新",
            duration: 2e3
        }), this.getUserInfo();
    },
    setProfileTipStyle: function() {
        var t = this;
        return function() {
            var e, n, a, r, i, o, s;
            return v.async(function(u) {
                for (;;) switch (u.prev = u.next) {
                  case 0:
                    return u.next = 2, v.awrap(l.default.getSystemInfo());

                  case 2:
                    return e = u.sent, n = e.windowWidth, u.next = 6, v.awrap(T("#edit-button"));

                  case 6:
                    a = u.sent, r = a.top, i = a.left, o = a.height, s = a.width, t.setData({
                        tipStyle: "top: " + (r - o) + "px;right: " + (n - i - s) + "px;"
                    });

                  case 12:
                  case "end":
                    return u.stop();
                }
            }, null, null, null, Promise);
        }();
    },
    closeProfileTip: function() {
        var t = this;
        return v.async(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                t.tipComponent || (t.tipComponent = t.selectComponent("#profile-tips")), t.tipComponent && t.tipComponent.close && t.tipComponent.close();

              case 2:
              case "end":
                return e.stop();
            }
        }, null, null, null, Promise);
    },
    onPrivacyChange: function() {
        var t = this;
        return v.async(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return t.resetListStatus(), e.next = 3, v.awrap(t.initTab(!1));

              case 3:
                return e.next = 5, v.awrap(t.resetListData(!0));

              case 5:
              case "end":
                return e.stop();
            }
        }, null, null, null, Promise);
    },
    onTalentPublishSuccess: function() {
        this.onTabChange({
            detail: {
                index: 0
            }
        }), this.onSubTabChange({
            detail: {
                index: 0
            }
        });
    }
});