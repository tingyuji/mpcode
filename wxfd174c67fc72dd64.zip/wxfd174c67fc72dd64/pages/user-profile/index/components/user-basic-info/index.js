function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

var t = e(require("../../../../../npm/@dp/util-emoji/index.js")), r = e(require("../../../../../common/lx")), n = function(e) {
    if (e && e.__esModule) return e;
    var t = {};
    if (null != e) for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && (t[r] = e[r]);
    return t.default = e, t;
}(require("../../api")), i = require("../../../../../npm/regenerator-runtime/runtime.js"), a = require("../../../../../npm/@mtfe/weapp-privacy-api/index.js").default;

Component({
    options: {
        multipleSlots: !0
    },
    properties: {
        isProfilePage: {
            type: Boolean,
            value: !0
        },
        userInfo: {
            type: Object,
            value: null,
            observer: function(e) {
                this.init(e);
            }
        },
        merchantEntrance: {
            type: Object,
            value: null
        }
    },
    data: {
        desc: "",
        showRules: !1,
        walletUrl: ""
    },
    methods: {
        init: function(e) {
            if (e.introduction && this.setData({
                desc: t.default.formatText(e.introduction)
            }), e.certifyEntrance.jumpUrl || 2 === e.symbolType) {
                var n = void 0;
                n = this.properties.isProfilePage ? e.certifyEntrance.title : 2 === e.symbolType ? "玩乐达人" : "", 
                r.default.moduleView("b_gc_6mal1cqf_mv", {
                    is_owner: this.properties.isProfilePage ? 1 : 0,
                    status: n
                });
            }
        },
        onFollowInfoTap: function(e) {
            var t = e.currentTarget.dataset.type;
            this.triggerEvent("onRedirectToFollowPage", t);
        },
        onUserInfoTap: function() {
            this.triggerEvent("onUserInfoTap");
        },
        getWalletPath: function() {
            var e = this;
            return n.getWalletPath().then(function(t) {
                e.data.walletUrl = t.url;
            });
        },
        toCertifyPage: function() {
            var e = this.properties.isProfilePage ? "b_gc_6mal1cqf_mc" : "b_gc_4euf46mg_mc", t = this.properties.isProfilePage ? {
                is_owner: 1,
                status: this.properties.userInfo.certifyEntrance.title
            } : {};
            r.default.moduleClick(e, t), a.navigateTo({
                url: this.properties.userInfo.certifyEntrance && this.properties.userInfo.certifyEntrance.jumpUrl
            });
        },
        openPop: function() {
            r.default.moduleClick("b_gc_6mal1cqf_mc", {
                is_owner: 0,
                status: "玩乐达人"
            }), r.default.moduleView("b_gc_dahh3111_mv"), r.default.moduleView("b_gc_4euf46mg_mv"), 
            this.setData({
                showRules: !0
            });
        },
        closePopup: function() {
            this.setData({
                showRules: !1
            });
        },
        toMyshop: function() {
            a.navigateTo({
                url: this.properties.merchantEntrance.jumpUrl
            });
        },
        toOrder: function() {
            a.navigateTo({
                url: "/pages/talent/order-list/index"
            });
        },
        toWallet: function() {
            var e = this;
            return i.async(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.next = 2, i.awrap(e.getWalletPath());

                  case 2:
                    e.data.walletUrl && a.navigateTo({
                        url: e.data.walletUrl
                    });

                  case 3:
                  case "end":
                    return t.stop();
                }
            }, null, null, null, Promise);
        }
    }
});