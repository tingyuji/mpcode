Component({
    properties: {},
    data: {
        sliceOption: {
            width: 180,
            height: 180
        }
    },
    methods: {
        onLogin: function() {
            this.triggerEvent("onLogin");
        }
    }
});