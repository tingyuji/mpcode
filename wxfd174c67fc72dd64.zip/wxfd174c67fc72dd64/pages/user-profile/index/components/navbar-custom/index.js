var t = require("../../../../../npm/@mtfe/weapp-privacy-api/index.js").default;

Component({
    externalClasses: [ "custom-nav" ],
    options: {
        multipleSlots: !0
    },
    properties: {
        src: {
            type: String,
            value: ""
        },
        title: {
            type: String,
            value: ""
        },
        background: {
            type: String,
            value: ""
        },
        navPageNum: {
            type: Number,
            value: 0
        }
    },
    data: {
        statusBarHeight: 0,
        navbarHeight: 0
    },
    methods: {
        handleTap: function() {
            this.triggerEvent("leftTap");
        },
        getNavbarPos: function() {
            var e = this;
            t.getSystemInfo({
                success: function(t) {
                    e.setData({
                        statusBarHeight: t.statusBarHeight,
                        navbarHeight: t.system.toLowerCase().indexOf("ios") > -1 ? 44 : 48
                    });
                }
            });
        }
    },
    lifetimes: {
        attached: function() {
            this.getNavbarPos();
        }
    }
});