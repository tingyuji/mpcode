var t = function(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}(require("../../../../../utils/index")).default.nextTick;

Component({
    externalClasses: [ "custom-class" ],
    options: {
        multipleSlots: !0
    },
    properties: {
        duration: Number,
        style: String,
        closeType: {
            type: String,
            value: "fade"
        }
    },
    data: {
        show: !1,
        className: ""
    },
    methods: {
        close: function() {
            var e = this, s = this.properties.closeType;
            this.data.show && s && t(function() {
                e.setData({
                    className: "style--" + s
                }), setTimeout(function() {
                    e.setData({
                        show: !1
                    }), clearTimeout(e.timer);
                }, 200);
            });
        }
    },
    lifetimes: {
        attached: function() {
            var t = this, e = this.properties.duration;
            this.setData({
                show: !0
            }), "number" == typeof e && e > 0 && (this.timer = setTimeout(function() {
                t.close();
            }, e));
        },
        detached: function() {
            this.close();
        }
    }
});