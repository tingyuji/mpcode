var e = require("../../../../../npm/@mtfe/weapp-privacy-api/index.js").default;

Component({
    properties: {
        show: {
            type: Boolean,
            value: !1
        },
        duration: {
            type: Number,
            value: 300
        },
        players: {
            type: Array,
            value: []
        },
        titleDes: {
            type: String,
            value: ""
        },
        emptyDes: {
            type: String,
            value: ""
        }
    },
    data: {
        overlayStyle: "background-color: rgba(0, 0, 0, 0.7);",
        customStyle: "height: 60%"
    },
    methods: {
        handleClose: function() {
            this.triggerEvent("closePlayers");
        },
        handleCopyWechat: function(t) {
            console.log(t), e.setClipboardData({
                data: t.currentTarget.dataset.contact
            });
        }
    }
});