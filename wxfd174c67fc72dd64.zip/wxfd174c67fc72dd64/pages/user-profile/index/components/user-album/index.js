function e(e) {
    if (Array.isArray(e)) {
        for (var t = 0, r = Array(e.length); t < e.length; t++) r[t] = e[t];
        return r;
    }
    return Array.from(e);
}

var t = function(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}(require("../../../../../common/lx")), r = require("../../../../../common/wx-privacy-constant"), i = require("../../../../../npm/@mtfe/weapp-privacy-api/index.js").default;

Component({
    properties: {
        images: {
            type: Array,
            value: [],
            observer: function() {
                this.init();
            }
        },
        previewMenu: {
            type: Boolean,
            value: !1
        },
        showUploadBotton: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        current: 0,
        autoplay: !1,
        sliceOption: {
            main: {
                width: 750,
                height: 500
            },
            small: {
                width: 64,
                height: 64
            }
        }
    },
    timer: null,
    methods: {
        onImagePreview: function(t) {
            var a = this.properties, n = a.images, o = a.previewMenu, u = t.target.dataset.index;
            i.previewImage({
                current: n[u].pictureUrl,
                urls: [].concat(e(n)).map(function(e) {
                    return e.pictureUrl;
                }),
                showmenu: !!o,
                _mt: {
                    sceneToken: r.WX_SCENETOKENS.PREVIEWIMAGE
                }
            }), this.triggerEvent("onImagePreview");
        },
        onIndicatorTap: function(e) {
            var t = this, r = e.target.dataset.index;
            clearTimeout(this.timer), this.setData({
                current: Number(r),
                autoplay: !1
            }), this.timer = setTimeout(function() {
                t.setData({
                    autoplay: !0
                });
            }, 1500), this.triggerEvent("onIndicatorTap");
        },
        onCurrentImageChange: function(e) {
            var t = e.detail.current;
            this.setData({
                current: t
            });
        },
        onUpload: function() {
            this.triggerEvent("onUpload");
        },
        init: function() {
            clearTimeout(this.timer), this.setData({
                current: 0,
                autoplay: !0
            });
        }
    },
    lifetimes: {
        detached: function() {
            clearTimeout(this.timer);
        }
    },
    pageLifetimes: {
        show: function() {
            var e = this.properties, r = e.showUploadBotton, i = e.images;
            this.setData({
                autoplay: !0
            }), r && i.length < 9 && t.default.moduleView("b_gc_lqw8ekj9_mv", {});
        },
        hide: function() {}
    }
});