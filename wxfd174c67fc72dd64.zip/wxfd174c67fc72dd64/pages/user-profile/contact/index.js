function n(n) {
    return n && n.__esModule ? n : {
        default: n
    };
}

var o = n(require("../../../common/config")), e = n(require("../../../common/lx")), t = require("../../../npm/@mtfe/weapp-privacy-api/index.js").default;

Page({
    data: {
        showPhoneList: !1,
        actions: [ {
            text: "10100011",
            type: "call"
        } ]
    },
    onCancel: function() {
        this.setData({
            showPhoneList: !1
        });
    },
    onTellActionItemTap: function(n) {
        var o = n.detail.index;
        "call" === this.data.actions[o].type && (e.default.moduleClick("b_gc_ugo6ocdn_mc"), 
        t.makePhoneCall({
            phoneNumber: "10100011"
        })), this.onCancel();
    },
    handleCall: function() {
        this.setData({
            showPhoneList: !0
        });
    },
    onLoad: function() {},
    onReady: function() {},
    onShow: function() {
        e.default.pageView("c_gc_m36x6oib", {
            cat_id: o.default.catId
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});