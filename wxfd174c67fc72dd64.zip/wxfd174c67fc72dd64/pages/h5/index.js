function e(e, n) {
    var t = {};
    for (var r in e) n.indexOf(r) >= 0 || Object.prototype.hasOwnProperty.call(e, r) && (t[r] = e[r]);
    return t;
}

var n = Object.assign || function(e) {
    for (var n = 1; n < arguments.length; n++) {
        var t = arguments[n];
        for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (e[r] = t[r]);
    }
    return e;
}, t = require("../../npm/@mtfe/mt-weapp-url/url.js"), r = function(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}(require("../../common/login")), o = require("../../npm/@mtfe/weapp-privacy-api/index.js").default, i = (require("../../npm/@mtfe/mt-weapp-city/index.js").getLocation, 
getApp()), u = {
    required: "1",
    optional: "0"
}, a = function(e) {
    return "" + e === u.required;
};

Page({
    data: {
        url: "",
        showWebview: !0
    },
    onLoad: function(e) {
        e = Object.keys(e).reduce(function(n, t) {
            return n[t] = decodeURIComponent(e[t]), n;
        }, {}), this.options = e, this.updateConfig(e);
    },
    updateConfig: function(e) {
        var n = this, t = e.forceLogin;
        return (void 0 !== t && t ? i.login() : Promise.resolve()).then(function() {
            return n.parseConfig(e);
        }).then(function(e) {
            return console.log({
                url: e
            }), n.setData({
                url: e
            }), e;
        });
    },
    mtlogin: function() {
        return new Promise(function(e, n) {
            r.default.mtDefaultLogin({
                isBind: !0,
                isWxInfo: !1
            }).then(function(n) {
                var t = n.openId, r = n.token, o = n.userId, u = n.uuid;
                Object.assign(i.globalData, {
                    openId: t,
                    token: r,
                    userId: o,
                    uuid: u
                }), e(n);
            }).catch(function() {
                n("");
            });
        });
    },
    parseConfig: function(r) {
        var u = this, s = r.title, d = (r.share, r.weburl), l = r.f_token, c = r.f_openId, f = r.f_userId, p = e(r, [ "title", "share", "weburl", "f_token", "f_openId", "f_userId" ]);
        s && (this.title = s, o.setNavigationBarTitle({
            title: s
        }));
        var h = d && -1 === d.indexOf("https://") ? decodeURIComponent(d) : d, m = (0, t.urlParse)(h), g = i.globalData, I = [], v = {};
        m.query.uuid || (v.uuid = g.openId, v.uuid || I.push(new Promise(function(e, n) {
            u.mtlogin().then(function(n) {
                v.uuid = n.openId, e();
            }, n);
        }))), m.query.token || a(l) && (v.token = g.token, v.token || I.push(new Promise(function(e, n) {
            u.mtlogin().then(function(n) {
                v.token = n.token, e();
            }, n);
        }))), m.query.userId || a(f) && (v.userId = g.userId, v.userid = g.userId, v.userId || I.push(new Promise(function(e, n) {
            u.mtlogin().then(function(n) {
                v.userId = n.userId, e();
            }, n);
        }))), m.query.openId || a(c) && (v.openId = g.openId, v.openId || I.push(new Promise(function(e, n) {
            u.mtlogin().then(function(n) {
                v.openId = n.openId, e();
            }, n);
        })));
        try {
            var y = JSON.parse(m.query.utm_content || "{}");
            !y.helpCode && g.helpCode && (v.utm_content = JSON.stringify(n({}, y, {
                helpCode: g.helpCode
            })));
        } catch (e) {
            console.log(e);
        }
        return v.mina_name = "mtgroup-wxapp", Promise.all(I).then(function() {
            Object.assign(v, p), Object.assign(m.query, v);
            var e = m.format();
            return console.log("打开h5页：" + e), e;
        });
    },
    onShareAppMessage: function() {
        var e = this.data;
        e.activityId, e.ad_source, e.title;
        if (this.shareParam) return this.shareParam;
    },
    getMessage: function(e) {
        var n = e.detail.data;
        console.log(n);
        var t = !0, r = !1, o = void 0;
        try {
            for (var i, u = n[Symbol.iterator](); !(t = (i = u.next()).done); t = !0) {
                var a = i.value;
                "share" === a.type && (this.shareParam = a.data);
            }
        } catch (e) {
            r = !0, o = e;
        } finally {
            try {
                !t && u.return && u.return();
            } finally {
                if (r) throw o;
            }
        }
    }
});