function t(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

function e(t) {
    if (Array.isArray(t)) {
        for (var e = 0, n = Array(t.length); e < t.length; e++) n[e] = t[e];
        return n;
    }
    return Array.from(t);
}

function n(t, e, n) {
    return e in t ? Object.defineProperty(t, e, {
        value: n,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : t[e] = n, t;
}

function r(t, e) {
    var n = Object.keys(t);
    if (Object.getOwnPropertySymbols) {
        var r = Object.getOwnPropertySymbols(t);
        e && (r = r.filter(function(e) {
            return Object.getOwnPropertyDescriptor(t, e).enumerable;
        })), n.push.apply(n, r);
    }
    return n;
}

function a(t) {
    for (var e = 1; e < arguments.length; e++) {
        var n = null != arguments[e] ? arguments[e] : {};
        e % 2 ? r(Object(n), !0).forEach(function(e) {
            i(t, e, n[e]);
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : r(Object(n)).forEach(function(e) {
            Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e));
        });
    }
    return t;
}

function i(t, e, n) {
    return e in t ? Object.defineProperty(t, e, {
        value: n,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : t[e] = n, t;
}

function s(t, e) {
    return f(t) || c(t, e) || o(t, e) || u();
}

function u() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}

function o(t, e) {
    if (t) {
        if ("string" == typeof t) return l(t, e);
        var n = Object.prototype.toString.call(t).slice(8, -1);
        return "Object" === n && t.constructor && (n = t.constructor.name), "Map" === n || "Set" === n ? Array.from(t) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? l(t, e) : void 0;
    }
}

function l(t, e) {
    (null == e || e > t.length) && (e = t.length);
    for (var n = 0, r = new Array(e); n < e; n++) r[n] = t[n];
    return r;
}

function c(t, e) {
    var n = null == t ? null : "undefined" != typeof Symbol && t[Symbol.iterator] || t["@@iterator"];
    if (null != n) {
        var r, a, i = [], s = !0, u = !1;
        try {
            for (n = n.call(t); !(s = (r = n.next()).done) && (i.push(r.value), !e || i.length !== e); s = !0) ;
        } catch (t) {
            u = !0, a = t;
        } finally {
            try {
                s || null == n.return || n.return();
            } finally {
                if (u) throw a;
            }
        }
        return i;
    }
}

function f(t) {
    if (Array.isArray(t)) return t;
}

var d = t(require("../../../npm/@dzfe/wx-api-promisify/dist/index.js")), p = require("../../../npm/@mtfe/mt-weapp-url/url.js"), m = function(t) {
    if (t && t.__esModule) return t;
    var e = {};
    if (null != t) for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n]);
    return e.default = t, e;
}(require("../api/index")), g = t(require("../../../common/login")), b = t(require("../../../utils/dialog")), h = t(require("../../../utils/toast")), v = t(require("../../../utils/index")), k = t(require("../../../common/config")), x = t(require("../../../common/lx")), w = require("../../../npm/regenerator-runtime/runtime.js"), y = require("../../../npm/@mtfe/weapp-privacy-api/index.js").default, L = v.default.getNodeRect, T = v.default.nextTick, P = (v.default.getNode, 
v.default.rpx2px), _ = v.default.removeUrlSliceAffix, D = getApp();

Page({
    data: {
        query: {},
        headerHeight: 157,
        navHeight: 88,
        token: "",
        lat: "",
        lng: "",
        userInfo: null,
        tabs: [ {
            label: "拼场",
            value: 0,
            show: !0,
            lock: !1,
            exposed: !1,
            children: [ {
                label: "ta发起的",
                value: 0,
                num: 0
            }, {
                label: "ta参与的",
                value: 1,
                num: 0
            } ]
        }, {
            label: "内容",
            value: 1,
            show: !0,
            lock: !1,
            exposed: !1,
            children: [ {
                label: "笔记",
                value: 300
            }, {
                label: "评价",
                value: 400
            } ]
        }, {
            label: "收藏",
            value: 2,
            show: !0,
            lock: !1,
            exposed: !1,
            children: [ {
                label: "笔记",
                value: 300
            }, {
                label: "评价",
                value: 400
            } ]
        } ],
        listPageNum: [ 1, 1, 1 ],
        listHasNext: [ !0, !0, !0 ],
        listLoading: [ !1, !1, !1 ],
        listHasInitialized: [ !1, !1, !1 ],
        listData: [ [], [], [] ],
        currentTab: 0,
        subCurrentTabList: [ 0, 0, 0 ],
        isFixed: !1,
        scrollTop: 0,
        navBackgroundOpacity: 0,
        title: "",
        navPageNum: 0
    },
    _freshing: !1,
    hasLogin: function() {
        return !!this.data.token;
    },
    initLogin: function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] && arguments[0], e = this;
        return function() {
            var n;
            return w.async(function(r) {
                for (;;) switch (r.prev = r.next) {
                  case 0:
                    return r.next = 2, w.awrap(g.default.mtDefaultLogin({
                        isBind: t
                    }));

                  case 2:
                    if (n = r.sent) {
                        r.next = 5;
                        break;
                    }
                    return r.abrupt("return");

                  case 5:
                    e.data.token = n.token || n.userInfo && n.userInfo.token || "";

                  case 6:
                  case "end":
                    return r.stop();
                }
            }, null, null, null, Promise);
        }();
    },
    onGoToDetail: function(t) {
        var e = t.detail;
        e.detailJumpUrl && y.navigateTo({
            url: e.detailJumpUrl
        });
    },
    onJoin: function(t) {
        var e = t.detail;
        e.detailJumpUrl && y.navigateTo({
            url: e.detailJumpUrl
        });
    },
    onAvatarTap: function() {
        x.default.moduleClick("b_gc_2n6nt58z_mc");
    },
    onUserInfoTap: function() {
        x.default.moduleClick("b_gc_urm4k87v_mc");
    },
    onPageScroll: function(t) {
        var e = t.scrollTop, n = this.data.userInfo, r = e > this.data.headerHeight;
        this.data.isFixed !== r && this.setData({
            isFixed: r,
            navBackgroundOpacity: r ? 1 : 0,
            title: r && n && n.nickName || ""
        });
    },
    onLeftTap: function() {
        1 === this.data.navPageNum ? y.switchTab({
            url: "/pages/home/index"
        }) : d.default.navigateBack();
    },
    onFollow: function() {
        var t = this;
        return function() {
            var e, r, a, i, s, u;
            return w.async(function(o) {
                for (;;) switch (o.prev = o.next) {
                  case 0:
                    if (e = t.data.query, r = e.usermaskid, 1 !== (a = e.platform)) {
                        o.next = 3;
                        break;
                    }
                    return o.abrupt("return");

                  case 3:
                    if (o.prev = 3, t.hasLogin()) {
                        o.next = 14;
                        break;
                    }
                    return o.next = 7, w.awrap(t.initLogin(!0));

                  case 7:
                    return o.next = 9, w.awrap(m.getIndividualTags({
                        usermaskid: r,
                        platform: a,
                        token: t.data.token
                    }));

                  case 9:
                    if (!(i = o.sent).isOneSelf) {
                        o.next = 13;
                        break;
                    }
                    return setTimeout(function() {
                        y.switchTab({
                            url: "/pages/user-profile/index/index"
                        });
                    }, 500), o.abrupt("return");

                  case 13:
                    t.setData({
                        userInfo: i
                    });

                  case 14:
                    if (s = t.data.userInfo.hasFollow, 0 !== (u = 1 - s)) {
                        o.next = 21;
                        break;
                    }
                    return x.default.moduleView("b_gc_ysvt9wuj_mv"), o.next = 20, w.awrap(b.default.confirm({
                        message: "确定要取消关注吗？",
                        confirmButtonText: "确定取消",
                        cancelButtonText: "继续关注"
                    }));

                  case 20:
                    x.default.moduleClick("b_gc_5tla21zo_mc");

                  case 21:
                    m.followOperation({
                        usermaskid: r,
                        token: t.data.token,
                        type: u,
                        platform: a
                    }).then(function(e) {
                        e && !e.errorMessage ? (t.setData(n({}, "userInfo.hasFollow", u)), u ? (0, h.default)() : (0, 
                        h.default)({
                            message: "已取消关注",
                            selector: "#mtgroup-toast-no-icon"
                        })) : (0, h.default)({
                            message: e && e.errorMessage ? e.errorMessage : "操作失败",
                            selector: "#mtgroup-toast-no-icon"
                        });
                    }, function() {
                        d.default.showToast({
                            icon: "none",
                            title: "操作失败",
                            duration: 1e3
                        });
                    }), o.next = 27;
                    break;

                  case 24:
                    o.prev = 24, o.t0 = o.catch(3), console.error(o.t0);

                  case 27:
                  case "end":
                    return o.stop();
                }
            }, null, null, [ [ 3, 24 ] ], Promise);
        }();
    },
    onRedirectToFollowPage: function(t) {
        var e = this.data, n = e.userInfo, r = e.query, a = t.detail;
        n && d.default.navigateTo({
            url: "/pages/individual/follow/index?type=" + a + "&userMaskId=" + r.usermaskid + "&platform=" + r.platform + "&name=" + encodeURIComponent(n.nickName) + "&from=1"
        });
    },
    getNavbarHeight: function() {
        return new Promise(function(t) {
            y.getSystemInfo({
                success: function(e) {
                    t(e.statusBarHeight + (e.system.toLowerCase().indexOf("ios") > -1 ? 44 : 48));
                }
            });
        });
    },
    setHeaderHeight: function() {
        var t = this;
        return function() {
            var e, n, r, a, i;
            return w.async(function(u) {
                for (;;) switch (u.prev = u.next) {
                  case 0:
                    return u.next = 2, w.awrap(Promise.all([ L("#user-album"), L("#user-basic-info"), t.getNavbarHeight() ]));

                  case 2:
                    e = u.sent, n = s(e, 3), r = n[0].height, a = n[1].height, i = n[2], t.setData({
                        headerHeight: r + a - i - P(48),
                        navHeight: i
                    });

                  case 8:
                  case "end":
                    return u.stop();
                }
            }, null, null, null, Promise);
        }();
    },
    initPage: function() {
        var t = this;
        return w.async(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return t.data.listPageNum = [ 1, 1, 1 ], t.data.listHasNext = [ !0, !0, !0 ], t.data.listLoading = [ !1, !1, !1 ], 
                t.setData({
                    listData: [ [], [], [] ]
                }), e.next = 6, w.awrap(t.initLogin());

              case 6:
                return e.next = 8, w.awrap(t.getUserInfo());

              case 8:
                t.data.userInfo && D.getCityInfo().then(function(e) {
                    t.data.lat = e.lat, t.data.lng = e.lng;
                }).then(function() {
                    return t.initTab();
                }).then(function() {
                    if (!t.isDpUser()) return t.initListData(!0);
                }).then(function() {
                    return t.onShowTracking();
                });

              case 9:
              case "end":
                return e.stop();
            }
        }, null, null, null, Promise);
    },
    onShowTracking: function() {
        var t = this;
        return function() {
            var e, n, r, a;
            return w.async(function(i) {
                for (;;) switch (i.prev = i.next) {
                  case 0:
                    e = t.data, n = e.currentTab, r = e.subCurrentTabList, a = e.tabs, 0 !== n || a[0].lock || a[0].children.forEach(function(t, e) {
                        x.default.moduleView("b_gc_kmraz4mj_mv", {
                            index: e,
                            title: t.label
                        });
                    });

                  case 2:
                  case "end":
                    return i.stop();
                }
            }, null, null, null, Promise);
        }();
    },
    initTab: function() {
        var t = this;
        return function() {
            var e, r, a, i, s, u, o, l;
            return w.async(function(c) {
                for (var f; ;) switch (c.prev = c.next) {
                  case 0:
                    return e = t.data, r = e.query, a = e.token, c.next = 3, w.awrap(m.getIndividualTabConfig({
                        usermaskid: r.usermaskid,
                        platform: r.platform,
                        token: a
                    }));

                  case 3:
                    i = c.sent, s = i.postShow, u = i.contentShow, o = i.collectShow, n(f = {}, "tabs[0].lock", 2 === s), 
                    n(f, "tabs[1].lock", 2 === u), n(f, "tabs[2].lock", 2 === o), l = f, 2 === s && (l["tabs[0].children"] = []), 
                    t.setData(l), t.data.tabs.forEach(function(e, n) {
                        x.default.moduleView("b_gc_i3i3sjvn_mv", {
                            index: n,
                            title: t.data.tabs[n].label
                        });
                    });

                  case 11:
                  case "end":
                    return c.stop();
                }
            }, null, null, null, Promise);
        }();
    },
    initListData: function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] && arguments[0], e = this;
        return function() {
            var r, i, u, o, l, c, f, d, p, g, b, h, v, k, x, y, L, T;
            return w.async(function(P) {
                for (;;) switch (P.prev = P.next) {
                  case 0:
                    if (r = e.data, i = r.tabs, u = r.listHasInitialized, o = r.token, l = r.query, 
                    !(i[0].lock && i[1].lock && i[2].lock)) {
                        P.next = 3;
                        break;
                    }
                    return P.abrupt("return");

                  case 3:
                    if (i[0].lock) {
                        P.next = 23;
                        break;
                    }
                    return c = {
                        usermaskid: l.usermaskid,
                        platform: l.platform,
                        token: e.data.token,
                        lat: e.data.lat,
                        lng: e.data.lng,
                        pagenum: e.data.listPageNum[0],
                        type: 0
                    }, P.next = 7, w.awrap(Promise.all([ m.getIndividualPostList(a({}, c)), m.getIndividualPostList(a({}, c, {
                        type: 1
                    })) ]));

                  case 7:
                    if (f = P.sent, d = s(f, 2), p = d[0], g = d[1], !(p && p.posts && p.posts.length)) {
                        P.next = 17;
                        break;
                    }
                    return u[0] = !0, e.setData(n({
                        currentTab: 0
                    }, "subCurrentTabList[0]", 0)), P.next = 16, w.awrap(e.getUserPostList(t));

                  case 16:
                    return P.abrupt("return");

                  case 17:
                    if (!(g && g.posts && g.posts.length)) {
                        P.next = 23;
                        break;
                    }
                    return u[0] = !0, e.setData(n({
                        currentTab: 0
                    }, "subCurrentTabList[0]", 1)), P.next = 22, w.awrap(e.getUserPostList(t));

                  case 22:
                    return P.abrupt("return");

                  case 23:
                    if (i[1].lock) {
                        P.next = 41;
                        break;
                    }
                    return c = {
                        token: o,
                        usermaskid: l.usermaskid,
                        platform: l.platform,
                        contenttype: 300,
                        pagenum: 1,
                        width: 343
                    }, P.next = 27, w.awrap(Promise.all([ m.getIndividualContentList(a({}, c)), m.getIndividualContentList(a({}, c, {
                        contenttype: 400
                    })) ]));

                  case 27:
                    if (b = P.sent, h = s(b, 2), v = h[0], k = h[1], !(v && v.contentList && v.contentList.length)) {
                        P.next = 36;
                        break;
                    }
                    return e.setData(n({
                        currentTab: 1
                    }, "subCurrentTabList[1]", 0)), P.next = 35, w.awrap(e.getUserContentList(t));

                  case 35:
                    return P.abrupt("return");

                  case 36:
                    if (!(k && k.contentList && k.contentList.length)) {
                        P.next = 41;
                        break;
                    }
                    return e.setData(n({
                        currentTab: 1
                    }, "subCurrentTabList[1]", 1)), P.next = 40, w.awrap(e.getUserContentList(t));

                  case 40:
                    return P.abrupt("return");

                  case 41:
                    if (i[2].lock) {
                        P.next = 59;
                        break;
                    }
                    return c = {
                        token: o,
                        usermaskid: l.usermaskid,
                        platform: l.platform,
                        contenttype: 300,
                        pagenum: 1,
                        width: 343
                    }, P.next = 45, w.awrap(Promise.all([ m.getIndividualCollectionList(a({}, c)), m.getIndividualCollectionList(a({}, c, {
                        contenttype: 400
                    })) ]));

                  case 45:
                    if (x = P.sent, y = s(x, 2), v = y[0], k = y[1], !(v && v.contentList && v.contentList.length)) {
                        P.next = 54;
                        break;
                    }
                    return e.setData(n({
                        currentTab: 2
                    }, "subCurrentTabList[2]", 0)), P.next = 53, w.awrap(e.getUserCollectionList(t));

                  case 53:
                    return P.abrupt("return");

                  case 54:
                    if (!(k && k.contentList && k.contentList.length)) {
                        P.next = 59;
                        break;
                    }
                    return e.setData(n({
                        currentTab: 2
                    }, "subCurrentTabList[2]", 1)), P.next = 58, w.awrap(e.getUserCollectionList(t));

                  case 58:
                    return P.abrupt("return");

                  case 59:
                    L = 0, T = 0;

                  case 61:
                    if (!(T < i.length)) {
                        P.next = 68;
                        break;
                    }
                    if (i[T].lock) {
                        P.next = 65;
                        break;
                    }
                    return L = T, P.abrupt("break", 68);

                  case 65:
                    T++, P.next = 61;
                    break;

                  case 68:
                    e.setData({
                        currentTab: L
                    });

                  case 69:
                  case "end":
                    return P.stop();
                }
            }, null, null, null, Promise);
        }();
    },
    getUserInfo: function() {
        var t = this;
        return function() {
            var e, n, r;
            return w.async(function(a) {
                for (;;) switch (a.prev = a.next) {
                  case 0:
                    return e = t.data, n = e.query, r = e.token, a.abrupt("return", m.getIndividualTags({
                        usermaskid: n.usermaskid,
                        platform: n.platform,
                        token: r
                    }).then(function(e) {
                        e.photos && e.photos.forEach(function(t) {
                            t.pictureUrl = _(t.pictureUrl);
                        }), t.setData({
                            userInfo: e
                        }, t.setHeaderHeight);
                    }));

                  case 2:
                  case "end":
                    return a.stop();
                }
            }, null, null, null, Promise);
        }();
    },
    onTabChange: function(t) {
        var e = this;
        return function() {
            var n, r, a, i, s;
            return w.async(function(u) {
                for (;;) switch (u.prev = u.next) {
                  case 0:
                    if (n = e.data, r = n.currentTab, a = n.listHasInitialized, i = n.tabs, r !== t.detail) {
                        u.next = 3;
                        break;
                    }
                    return u.abrupt("return");

                  case 3:
                    if (s = t.detail.index, e.setData({
                        currentTab: s
                    }), a[s]) {
                        u.next = 9;
                        break;
                    }
                    return u.next = 8, w.awrap(e.resetListData());

                  case 8:
                    a[s] = !0;

                  case 9:
                    x.default.moduleClick("b_gc_i3i3sjvn_mc", {
                        index: s,
                        title: i[s].label
                    }), y.pageScrollTo({
                        scrollTop: 0
                    });

                  case 11:
                  case "end":
                    return u.stop();
                }
            }, null, null, null, Promise);
        }();
    },
    onSubTabChange: function(t) {
        var e = this;
        return function() {
            var r, a, i, s, u, o;
            return w.async(function(l) {
                for (;;) switch (l.prev = l.next) {
                  case 0:
                    if (r = e.data, a = r.currentTab, i = r.subCurrentTabList, s = r.tabs, (u = i[a]) !== t.detail) {
                        l.next = 4;
                        break;
                    }
                    return l.abrupt("return");

                  case 4:
                    return o = t.detail.index, e.setData(n({}, "subCurrentTabList[" + a + "]", o)), 
                    e.resetListStatus(), l.next = 9, w.awrap(e.resetListData());

                  case 9:
                    e.updateScrollViewPosition(), 0 === a && x.default.moduleClick("b_gc_kmraz4mj_mc", {
                        index: o,
                        title: s[0].children[o].label
                    });

                  case 11:
                  case "end":
                    return l.stop();
                }
            }, null, null, null, Promise);
        }();
    },
    resetListStatus: function() {
        var t = this.data, e = t.currentTab, n = t.listHasNext, r = t.listPageNum, a = t.listLoading;
        n[e] = !0, a[e] = !1, r[e] = 1;
    },
    resetListData: function() {
        var t = this;
        return w.async(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return e.abrupt("return", t.loadListData(!0));

              case 1:
              case "end":
                return e.stop();
            }
        }, null, null, null, Promise);
    },
    loadListData: function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] && arguments[0], e = this;
        return function() {
            var n;
            return w.async(function(r) {
                for (;;) switch (r.prev = r.next) {
                  case 0:
                    if (0 !== (n = e.data.currentTab)) {
                        r.next = 5;
                        break;
                    }
                    return r.abrupt("return", e.getUserPostList(t));

                  case 5:
                    if (1 !== n) {
                        r.next = 9;
                        break;
                    }
                    return r.abrupt("return", e.getUserContentList(t));

                  case 9:
                    if (2 !== n) {
                        r.next = 11;
                        break;
                    }
                    return r.abrupt("return", e.getUserCollectionList(t));

                  case 11:
                  case "end":
                    return r.stop();
                }
            }, null, null, null, Promise);
        }();
    },
    getUserPostList: function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] && arguments[0], n = this;
        return function() {
            var r, a, i, s, u, o, l, c, f, d;
            return w.async(function(p) {
                for (;;) switch (p.prev = p.next) {
                  case 0:
                    if (r = n.data, a = r.listData, i = r.listLoading, s = r.listPageNum, u = r.listHasNext, 
                    o = r.userInfo, l = r.tabs, c = r.subCurrentTabList, f = r.query, o) {
                        p.next = 3;
                        break;
                    }
                    return p.abrupt("return");

                  case 3:
                    if (u[0] && !i[0] && !l[0].lock) {
                        p.next = 5;
                        break;
                    }
                    return p.abrupt("return");

                  case 5:
                    return d = l[0].children[c[0]], i[0] = !0, p.abrupt("return", m.getIndividualPostList({
                        usermaskid: f.usermaskid,
                        platform: f.platform,
                        token: n.data.token,
                        lat: n.data.lat,
                        lng: n.data.lng,
                        pagenum: n.data.listPageNum[0],
                        type: d.value
                    }).then(function(r) {
                        if (r) {
                            var o = r.posts || [];
                            s[0] += 1, u[0] = !!r.hasNext, a[0] && !t || (a[0] = []), a[0] = [].concat(e(a[0]), e(o)), 
                            n.setData({
                                listData: a,
                                listHasNext: u
                            });
                        }
                        x.default.moduleView("b_gc_pfop834t_mv", {
                            status: n.data.listData[0].length > 0
                        }), setTimeout(function() {
                            i[0] = !1;
                        }, 100);
                    }));

                  case 8:
                  case "end":
                    return p.stop();
                }
            }, null, null, null, Promise);
        }();
    },
    getUserContentList: function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] && arguments[0], n = this;
        return function() {
            var r, a, i, s, u, o, l, c, f, d, p;
            return w.async(function(g) {
                for (;;) switch (g.prev = g.next) {
                  case 0:
                    if (r = n.data, a = r.listData, i = r.listLoading, s = r.listPageNum, u = r.listHasNext, 
                    o = r.token, l = r.userInfo, c = r.tabs, f = r.subCurrentTabList, d = r.query, l) {
                        g.next = 3;
                        break;
                    }
                    return g.abrupt("return");

                  case 3:
                    if (u[1] && !i[1] && !c[1].lock) {
                        g.next = 5;
                        break;
                    }
                    return g.abrupt("return");

                  case 5:
                    return p = c[1].children[f[1]], i[1] = !0, g.abrupt("return", m.getIndividualContentList({
                        token: o,
                        platform: d.platform,
                        contenttype: p.value,
                        usermaskid: d.usermaskid,
                        pagenum: s[1],
                        width: 343
                    }).then(function(r) {
                        if (r) {
                            var o = r.contentList || [];
                            u[1] = !!r.hasNext, a[1] && !t || (a[1] = []), a[1] = [].concat(e(a[1]), e(o)), 
                            s[1] += 1, n.setData({
                                listData: a,
                                listHasNext: u
                            });
                        }
                        x.default.moduleView("b_gc_wm3tu0cg_mv", {
                            status: n.data.listData[1].length > 0
                        }), setTimeout(function() {
                            i[1] = !1;
                        }, 100);
                    }));

                  case 8:
                  case "end":
                    return g.stop();
                }
            }, null, null, null, Promise);
        }();
    },
    getUserCollectionList: function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] && arguments[0], n = this;
        return function() {
            var r, a, i, s, u, o, l, c, f, d, p;
            return w.async(function(g) {
                for (;;) switch (g.prev = g.next) {
                  case 0:
                    if (r = n.data, a = r.listData, i = r.listLoading, s = r.listPageNum, u = r.listHasNext, 
                    o = r.token, l = r.userInfo, c = r.tabs, f = r.subCurrentTabList, d = r.query, l) {
                        g.next = 3;
                        break;
                    }
                    return g.abrupt("return");

                  case 3:
                    if (u[2] && !i[2] && !c[2].lock) {
                        g.next = 5;
                        break;
                    }
                    return g.abrupt("return");

                  case 5:
                    return p = c[2].children[f[2]], i[2] = !0, g.abrupt("return", m.getIndividualCollectionList({
                        token: o,
                        usermaskid: d.usermaskid,
                        platform: d.platform,
                        contenttype: p.value,
                        pagenum: s[2],
                        width: 343
                    }).then(function(r) {
                        if (r) {
                            var o = r.contentList || [];
                            u[2] = !!r.hasNext, a[2] && !t || (a[2] = []), a[2] = [].concat(e(a[2]), e(o)), 
                            n.setData({
                                listData: a,
                                listHasNext: u
                            });
                        }
                        x.default.moduleView("b_gc_1pd4k3o9_mv", {
                            status: n.data.listData[2].length > 0
                        }), s[2] += 1, setTimeout(function() {
                            i[2] = !1;
                        }, 100);
                    }));

                  case 8:
                  case "end":
                    return g.stop();
                }
            }, null, null, null, Promise);
        }();
    },
    feedClick: function(t) {
        y.navigateTo({
            url: t.detail.feed.contentDetailUrl
        });
    },
    collectClick: function(t) {
        var e = this;
        return function() {
            var n, r, a, i, s, u, o, l;
            return w.async(function(c) {
                for (;;) switch (c.prev = c.next) {
                  case 0:
                    if (n = t.detail.item, r = n.isCollected, a = 1 === r ? 0 : 1, i = n.contentType, 
                    s = n.contentId, u = n.collectionCount, o = {
                        contentid: s,
                        contenttype: i,
                        token: e.data.token,
                        actiontype: a
                    }, c.prev = 5, 0 !== a) {
                        c.next = 9;
                        break;
                    }
                    return c.next = 9, w.awrap(b.default.confirm({
                        message: "确定要取消收藏吗？",
                        confirmButtonText: "确定",
                        cancelButtonText: "取消"
                    }));

                  case 9:
                    return c.next = 11, w.awrap(m.feedCollect(o));

                  case 11:
                    (l = c.sent) && l.isSuccess ? (e.resetListStatus(), e.resetListData(!0), y.showToast({
                        title: l.resultMsg,
                        icon: "none",
                        duration: 1e3
                    })) : y.showToast({
                        title: l.resultMsg,
                        icon: "none",
                        duration: 1e3
                    }), c.next = 18;
                    break;

                  case 15:
                    c.prev = 15, c.t0 = c.catch(5), console.log(c.t0);

                  case 18:
                  case "end":
                    return c.stop();
                }
            }, null, null, [ [ 5, 15 ] ], Promise);
        }();
    },
    updateScrollViewPosition: function() {
        var t = this;
        return w.async(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                T(function() {
                    var e = t.data, n = e.headerHeight, r = e.isFixed;
                    t.setData({
                        scrollTop: r ? n + 15 : 0
                    });
                });

              case 1:
              case "end":
                return e.stop();
            }
        }, null, null, null, Promise);
    },
    onImagePreview: function() {
        x.default.moduleClick("b_gc_mis8cerc_mc");
    },
    onIndicatorTap: function() {
        x.default.moduleClick("b_gc_jqok0n7f_mc");
    },
    onLoad: function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, e = this;
        return w.async(function(n) {
            for (;;) switch (n.prev = n.next) {
              case 0:
                t.platform && (t.platform = parseInt(t.platform)), e.setData({
                    query: t,
                    navPageNum: getCurrentPages().length
                });
                try {
                    1154 === getApp().globalData.sceneValue && e.getUserInfo().then(e.getUserPostList);
                } catch (t) {}
                return n.next = 5, w.awrap(e.initPage());

              case 5:
              case "end":
                return n.stop();
            }
        }, null, null, null, Promise);
    },
    onReady: function() {},
    onShow: function() {
        var t = this.data, e = t.listData, n = t.currentTab;
        x.default.pageView("c_gc_m3s8sevb", {
            cat_id: k.default.catId,
            custom: {
                user_id: decodeURIComponent(this.options.usermaskid || ""),
                platform: this.options.platform
            }
        }), x.default.moduleView({
            _POST: "b_gc_pfop834t_mv",
            _CONTENT: "b_gc_wm3tu0cg_mv",
            _COLLECTION: "b_gc_1pd4k3o9_mv"
        }[n], {
            status: e[n].length > 0
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPulling: function(t) {
        if (t && t.detail) {
            var e = t.detail.dy;
            this.setData({
                bgImageScale: 1 + e / 200
            });
        }
    },
    isDpUser: function() {
        return this.data.query && 1 === this.data.query.platform;
    },
    onRefresh: function() {
        var t = this;
        this._freshing || (this._freshing = !0, this.resetListStatus(), this.getUserInfo(), 
        this.initTab(), this.isDpUser() ? this._freshing = !1 : this.resetListData().then(function() {
            t._freshing = !1, y.showToast({
                title: "数据更新成功",
                icon: "none",
                duration: 1e3
            });
        }, function() {
            t._freshing = !1;
        }));
    },
    onPullDownRefresh: function() {
        this.onRefresh(), y.stopPullDownRefresh();
    },
    onReachBottom: function() {
        var t = this;
        return w.async(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                t.loadListData();

              case 1:
              case "end":
                return e.stop();
            }
        }, null, null, null, Promise);
    },
    onShareAppMessage: function() {
        return {
            title: "快来看看 " + (this.data.userInfo || {}).nickName + " 的美团拼场主页",
            path: "/" + this.route + "?" + (0, p.stringify)(a({}, this.options, {
                usermaskid: decodeURIComponent(this.options.usermaskid)
            }))
        };
    },
    onShareTimeline: function() {
        var t = this.data.userInfo || {}, e = t.avatar, n = t.nickName;
        return {
            imageUrl: v.default.imgResizer(e || "", 200),
            title: "快来看看 " + n + " 的美团拼场主页"
        };
    }
});