Object.defineProperty(exports, "__esModule", {
    value: !0
});

exports.LIST_TYPE = {
    FOLLOW: 1,
    FANS: 2
};