function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function t(e) {
    if (Array.isArray(e)) {
        for (var t = 0, r = Array(e.length); t < e.length; t++) r[t] = e[t];
        return r;
    }
    return Array.from(e);
}

function r(e, t, r) {
    return t in e ? Object.defineProperty(e, t, {
        value: r,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = r, e;
}

var a, n, u, o, s, i = function(e) {
    if (e && e.__esModule) return e;
    var t = {};
    if (null != e) for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && (t[r] = e[r]);
    return t.default = e, t;
}(require("../api/index")), l = e(require("../../../common/login")), c = e(require("../../../common/config")), f = require("./config/index"), d = e(require("../../../utils/index")), p = e(require("../../../utils/dialog")), L = e(require("../../../utils/toast")), m = e(require("../../../common/lx")), T = require("../../../npm/regenerator-runtime/runtime.js"), g = require("../../../npm/@mtfe/weapp-privacy-api/index.js").default, h = d.default.throttle, _ = d.default.transformNum;

Page({
    data: {
        query: {},
        isProfilePage: !1,
        token: "",
        tabs: [ {
            label: "关注",
            value: f.LIST_TYPE.FOLLOW,
            num: 0,
            show: !0
        }, {
            label: "粉丝",
            value: f.LIST_TYPE.FANS,
            num: 0,
            show: !0
        } ],
        currentTab: 0,
        list: (a = {}, r(a, f.LIST_TYPE.FOLLOW, []), r(a, f.LIST_TYPE.FANS, []), a),
        pageNum: (n = {}, r(n, f.LIST_TYPE.FOLLOW, 1), r(n, f.LIST_TYPE.FANS, 1), n),
        hasNext: (u = {}, r(u, f.LIST_TYPE.FOLLOW, !0), r(u, f.LIST_TYPE.FANS, !0), u),
        loading: (o = {}, r(o, f.LIST_TYPE.FOLLOW, !1), r(o, f.LIST_TYPE.FANS, !1), o)
    },
    userIdSet: (s = {}, r(s, f.LIST_TYPE.FOLLOW, new Set()), r(s, f.LIST_TYPE.FANS, new Set()), 
    s),
    getListType: function() {
        return 0 === this.data.currentTab ? f.LIST_TYPE.FOLLOW : f.LIST_TYPE.FANS;
    },
    onTabChange: function(e) {
        var t = this.data.tabs, r = e.detail.index;
        this.setData({
            currentTab: r
        }), m.default.moduleClick("b_gc_k89dhueq_mc", {
            index: r + 1,
            title: t[r].label
        }), this.resetListStatus(), this.updateList(this.getListType(), !0);
    },
    onScrollToLower: h(function() {
        this.updateList(this.getListType());
    }, 300),
    getFollowOrFansList: function(e) {
        var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1, r = this;
        return function() {
            var a, n, u, o, s, l;
            return T.async(function(c) {
                for (;;) switch (c.prev = c.next) {
                  case 0:
                    if (a = r.data, n = a.query, u = a.token, o = n.userMaskId, s = n.platform, "1" !== (l = n.from)) {
                        c.next = 6;
                        break;
                    }
                    return c.abrupt("return", i.individualFollowList({
                        usermaskid: o,
                        platform: s,
                        type: e,
                        pagenum: t,
                        token: u
                    }));

                  case 6:
                    if ("2" !== l) {
                        c.next = 8;
                        break;
                    }
                    return c.abrupt("return", i.profileFollowList({
                        type: e,
                        pagenum: t,
                        token: u
                    }));

                  case 8:
                  case "end":
                    return c.stop();
                }
            }, null, null, null, Promise);
        }();
    },
    filterUserList: function(e, t) {
        var r = this.userIdSet[e], a = t.filter(function(e) {
            return !r.has(e.userMaskId);
        });
        return t.forEach(function(e) {
            return r.add(e.userMaskId);
        }), a;
    },
    resetListStatus: function() {
        var e, t = this.getListType();
        this.setData((e = {}, r(e, "pageNum." + t, 1), r(e, "hasNext." + t, !0), r(e, "loading." + t, !1), 
        e)), this.userIdSet[t].clear();
    },
    updateList: function(e) {
        var a = arguments.length > 1 && void 0 !== arguments[1] && arguments[1], n = this;
        return function() {
            var u, o, s, i, l, c, d, p;
            return T.async(function(L) {
                for (;;) switch (L.prev = L.next) {
                  case 0:
                    if (u = n.data, o = u.loading, s = u.pageNum, i = u.hasNext, l = u.list, !o[e] && i[e]) {
                        L.next = 3;
                        break;
                    }
                    return L.abrupt("return");

                  case 3:
                    return o[e] = !0, L.prev = 4, L.next = 7, T.awrap(n.getFollowOrFansList(e, s[e]));

                  case 7:
                    if (c = L.sent) {
                        var g;
                        d = n.filterUserList(e, c.users || []), p = a ? d : [].concat(t(l[e]), t(d)), n.setData((g = {}, 
                        r(g, "list." + e, p), r(g, "tabs[" + (e === f.LIST_TYPE.FOLLOW ? 0 : 1) + "].num", _(c.totalCount || 0)), 
                        r(g, "hasNext." + e, !!c.hasNext), g)), s[e] += 1;
                    }
                    o[e] = !1, m.default.moduleView(n.getListType() === f.LIST_TYPE.FOLLOW ? "b_gc_1rdjr9b1_mv" : "b_gc_6ld5y4wd_mv", {
                        status: c && c.users && c.users.length ? 1 : 0
                    }), L.next = 16;
                    break;

                  case 13:
                    L.prev = 13, L.t0 = L.catch(4), o[e] = !1;

                  case 16:
                  case "end":
                    return L.stop();
                }
            }, null, null, [ [ 4, 13 ] ], Promise);
        }();
    },
    onFollowChange: function(e) {
        var t = this;
        return function() {
            var a, n, u, o, s, f, d, h, _, S, I, b, v;
            return T.async(function(k) {
                for (;;) switch (k.prev = k.next) {
                  case 0:
                    if (a = t.data, n = a.query, u = a.token, o = e.detail, s = o.hasFollow, f = o.index, 
                    d = o.userMaskId, h = t.getListType(), u) {
                        k.next = 17;
                        break;
                    }
                    return k.next = 6, T.awrap(l.default.mtDefaultLogin({
                        isBind: !0
                    }));

                  case 6:
                    return _ = k.sent, t.data.token = _.token || _.userInfo && _.userInfo.token || "", 
                    k.next = 10, T.awrap(i.getIndividualTags({
                        token: t.data.token,
                        usermaskid: n.userMaskId,
                        platform: n.platform || c.default.platformCode
                    }));

                  case 10:
                    if (!(S = k.sent) || !S.isOneSelf) {
                        k.next = 14;
                        break;
                    }
                    return setTimeout(function() {
                        g.switchTab({
                            url: "/pages/user-profile/index/index"
                        });
                    }, 500), k.abrupt("return");

                  case 14:
                    return t.resetListStatus(), t.updateList(h, !0), k.abrupt("return");

                  case 17:
                    if (k.prev = 17, 0 === s) {
                        k.next = 23;
                        break;
                    }
                    return m.default.moduleView("b_gc_k5fp7hag_mv"), k.next = 22, T.awrap(p.default.confirm({
                        message: "确定要取消关注吗？",
                        cancelButtonText: "继续关注",
                        confirmButtonText: "确定取消"
                    }));

                  case 22:
                    m.default.moduleClick("b_gc_6a8fe7kk_mc");

                  case 23:
                    return I = 0 === s ? 1 : 0, b = {
                        type: I,
                        token: u,
                        usermaskid: d,
                        platform: n.platform || c.default.platformCode
                    }, k.next = 27, T.awrap(i.followOperation(b));

                  case 27:
                    (v = k.sent) && !v.errorMessage ? (t.setData(r({}, "list." + h + ".[" + f + "].hasFollow", I)), 
                    I ? (0, L.default)() : (0, L.default)({
                        message: "已取消关注",
                        selector: "#mtgroup-toast-no-icon"
                    })) : (0, L.default)({
                        message: v.errorMessage || "操作失败",
                        selector: "#mtgroup-toast-no-icon"
                    }), k.next = 34;
                    break;

                  case 31:
                    k.prev = 31, k.t0 = k.catch(17), console.error(k.t0);

                  case 34:
                  case "end":
                    return k.stop();
                }
            }, null, null, [ [ 17, 31 ] ], Promise);
        }();
    },
    onLoad: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = this;
        return function() {
            var r, a;
            return T.async(function(n) {
                for (;;) switch (n.prev = n.next) {
                  case 0:
                    return e.platform && (e.platform = parseInt(e.platform)), t.setData({
                        query: e
                    }), "2" === e.from && t.setData({
                        isProfilePage: !0
                    }), g.setNavigationBarTitle({
                        title: decodeURIComponent(e.name) || ""
                    }), n.next = 6, T.awrap(l.default.mtDefaultLogin({
                        isBind: !1
                    }));

                  case 6:
                    if (r = n.sent, t.data.token = r.token || r.userInfo && r.userInfo.token || "", 
                    t.data.pageNum[f.LIST_TYPE.FOLLOW] = 1, t.data.pageNum[f.LIST_TYPE.FANS] = 1, t.data.loading[f.LIST_TYPE.FOLLOW] = !1, 
                    t.data.loading[f.LIST_TYPE.FANS] = !1, t.data.hasNext[f.LIST_TYPE.FOLLOW] = !0, 
                    t.data.hasNext[f.LIST_TYPE.FANS] = !0, a = e.type && parseInt(e.type) || f.LIST_TYPE.FOLLOW, 
                    t.setData({
                        currentTab: a === f.LIST_TYPE.FANS ? 1 : 0
                    }), 1 !== e.platform) {
                        n.next = 18;
                        break;
                    }
                    return n.abrupt("return");

                  case 18:
                    t.updateList(f.LIST_TYPE.FOLLOW, !0), t.updateList(f.LIST_TYPE.FANS, !0);

                  case 20:
                  case "end":
                    return n.stop();
                }
            }, null, null, null, Promise);
        }();
    },
    onReady: function() {},
    onShow: function() {
        var e = this.data, t = e.query, r = e.tabs;
        m.default.pageView("c_gc_qo45ti86", {
            cat_id: c.default.catId,
            custom: {
                source: t && "1" === t.from ? "个人主页" : "个人中心"
            }
        }), r.forEach(function(e, t) {
            m.default.moduleView("b_gc_k89dhueq_mv", {
                index: t + 1,
                title: e.label
            });
        }), g.setNavigationBarColor({
            backgroundColor: "#111111",
            frontColor: "#ffffff"
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});