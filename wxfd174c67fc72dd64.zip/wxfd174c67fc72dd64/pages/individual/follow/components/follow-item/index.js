var e = Object.assign || function(e) {
    for (var t = 1; t < arguments.length; t++) {
        var a = arguments[t];
        for (var i in a) Object.prototype.hasOwnProperty.call(a, i) && (e[i] = a[i]);
    }
    return e;
}, t = function(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}(require("../../../../../common/lx")), a = require("../../../../../npm/@mtfe/weapp-privacy-api/index.js").default;

Component({
    externalClasses: [ "custom-follow-item" ],
    properties: {
        user: {
            type: Object,
            value: {}
        },
        index: Number,
        tabIndex: Number,
        tabName: String
    },
    data: {
        FOLLOW_STATUS_MAP: {
            0: "关注",
            1: "已关注",
            2: "互相关注"
        }
    },
    methods: {
        navigateToUserPage: function() {
            var e = this.properties.user, t = e.jumpUrl, i = e.isMe;
            t && (i ? a.switchTab({
                url: t
            }) : a.navigateTo({
                url: t
            }));
        },
        onAvatarTap: function() {
            var t = this.properties, a = t.user, i = t.index;
            this.navigateToUserPage(), this.triggerEvent("onAvatarTap", e({}, a, {
                index: i
            })), this.clickUserTrack();
        },
        onUserInfoTap: function() {
            this.navigateToUserPage(), this.clickUserTrack();
        },
        clickUserTrack: function() {
            var e = this.properties, a = e.user, i = e.index, r = e.tabIndex, n = e.tabName, s = this.data.FOLLOW_STATUS_MAP;
            t.default.moduleClick("b_gc_y5beifi5_mc", {
                button_name: a.isMe ? "" : s[a.hasFollow],
                index: i,
                tab_index: r,
                tab_name: n
            });
        },
        onActionTab: function() {
            var a = this.properties, i = a.user, r = a.index, n = a.tabIndex, s = a.tabName, o = this.data.FOLLOW_STATUS_MAP;
            i.isMe || (this.triggerEvent("followChange", e({}, i, {
                index: r
            })), t.default.moduleClick("b_gc_exdnxe4x_mc", {
                button_name: o[i.hasFollow],
                index: r,
                tab_index: n,
                tab_name: s
            }));
        }
    }
});