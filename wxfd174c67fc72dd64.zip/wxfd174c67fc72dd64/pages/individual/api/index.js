Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.profileFollowList = exports.individualFollowList = exports.followOperation = exports.getIndividualCollectionList = exports.getIndividualContentList = exports.getIndividualPostList = exports.getIndividualTabConfig = exports.getIndividualTags = void 0, 
exports.feedCollect = function(n) {
    return new Promise(function(t, o) {
        e.request({
            url: c,
            data: n,
            method: "POST",
            header: {},
            success: function(n) {
                t(n);
            },
            fail: function(n) {
                o(n);
            }
        });
    }).then(function(n) {
        var e = n.data;
        if (200 === e.code && e.msg) return e.msg;
        throw new Error("请求数据失败");
    }).catch(function(n) {
        return console.error("feedCollect", n), null;
    });
};

var n = function(n) {
    return n && n.__esModule ? n : {
        default: n
    };
}(require("../../../common/config")), e = require("../../../npm/@mtfe/weapp-privacy-api/index.js").default, t = n.default.gpower_domain + "/api/gpower/individual/user/tags", o = n.default.gpower_domain + "/api/gpower/individual/settings/privacy", r = n.default.gpower_domain + "/api/gpower/individual/post/list", i = n.default.gpower_domain + "/api/gpower/individual/content/publishment", u = n.default.gpower_domain + "/api/gpower/individual/content/collect", a = n.default.dp_domain + "/api/joy/sharerelation/follow/operation", l = n.default.gpower_domain + "/api/gpower/individual/follow/list", s = n.default.dp_domain + "/api/joy/sharerelation/profile/follow/list", c = n.default.dp_domain + "/api/joy/sharerelation/content/collect";

exports.getIndividualTags = function(n) {
    return new Promise(function(o, r) {
        e.request({
            url: t,
            data: n,
            header: {},
            success: function(n) {
                o(n);
            },
            fail: function(n) {
                r(n);
            }
        });
    }).then(function(n) {
        var e = n.data;
        if (200 === e.code && e.msg) return e.msg;
        throw new Error("请求数据失败");
    }).catch(function(n) {
        return console.error("getIndividualTags", n), null;
    });
}, exports.getIndividualTabConfig = function(n) {
    return new Promise(function(t, r) {
        e.request({
            url: o,
            data: n,
            header: {},
            success: function(n) {
                t(n);
            },
            fail: function(n) {
                r(n);
            }
        });
    }).then(function(n) {
        var e = n.data;
        if (200 === e.code && e.msg) return e.msg;
        throw new Error("请求数据失败");
    }).catch(function(n) {
        return console.error("getIndividualTabConfig", n), null;
    });
}, exports.getIndividualPostList = function(n) {
    return new Promise(function(t, o) {
        e.request({
            url: r,
            data: n,
            header: {},
            success: function(n) {
                t(n);
            },
            fail: function(n) {
                o(n);
            }
        });
    }).then(function(n) {
        var e = n.data;
        if (200 === e.code && e.msg) return e.msg;
        throw new Error("请求数据失败");
    }).catch(function(n) {
        return console.error("getIndividualPostList", n), null;
    });
}, exports.getIndividualContentList = function(n) {
    return new Promise(function(t, o) {
        e.request({
            url: i,
            data: n,
            header: {},
            success: function(n) {
                t(n);
            },
            fail: function(n) {
                o(n);
            }
        });
    }).then(function(n) {
        var e = n.data;
        if (200 === e.code && e.msg) return e.msg;
        throw new Error("请求数据失败");
    }).catch(function(n) {
        return console.error("getIndividualContentList", n), null;
    });
}, exports.getIndividualCollectionList = function(n) {
    return new Promise(function(t, o) {
        e.request({
            url: u,
            data: n,
            header: {},
            success: function(n) {
                t(n);
            },
            fail: function(n) {
                o(n);
            }
        });
    }).then(function(n) {
        var e = n.data;
        if (200 === e.code && e.msg) return e.msg;
        throw new Error("请求数据失败");
    }).catch(function(n) {
        return console.error("getIndividualCollectionList", n), null;
    });
}, exports.followOperation = function(n) {
    return new Promise(function(t, o) {
        e.request({
            url: a,
            method: "POST",
            data: n,
            header: {},
            success: function(n) {
                t(n);
            },
            fail: function(n) {
                o(n);
            }
        });
    }).then(function(n) {
        var e = n.data;
        if (200 === e.code && e.msg) return e.msg;
        throw new Error("请求数据失败");
    }).catch(function(n) {
        return console.error("followOperation", n), null;
    });
}, exports.individualFollowList = function(n) {
    return new Promise(function(t, o) {
        e.request({
            url: l,
            data: n,
            header: {},
            success: function(n) {
                t(n);
            },
            fail: function(n) {
                o(n);
            }
        });
    }).then(function(n) {
        var e = n.data;
        if (200 === e.code && e.msg) return e.msg;
        throw new Error("请求数据失败");
    }).catch(function(n) {
        return console.error("individualFollowList", n), null;
    });
}, exports.profileFollowList = function(n) {
    return new Promise(function(t, o) {
        e.request({
            url: s,
            data: n,
            header: {},
            success: function(n) {
                t(n);
            },
            fail: function(n) {
                o(n);
            }
        });
    }).then(function(n) {
        var e = n.data;
        if (200 === e.code && e.msg) return e.msg;
        throw new Error("请求数据失败");
    }).catch(function(n) {
        return console.error("individualFollowList", n), null;
    });
};