var e = Object.assign || function(e) {
    for (var t = 1; t < arguments.length; t++) {
        var s = arguments[t];
        for (var i in s) Object.prototype.hasOwnProperty.call(s, i) && (e[i] = s[i]);
    }
    return e;
}, t = function(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}(require("../../../../common/lx"));

Component({
    externalClasses: [ "custon-action-class" ],
    options: {
        multipleSlots: !0
    },
    properties: {
        isProfilePage: {
            type: Boolean,
            value: !0
        },
        isSelfView: {
            type: Boolean,
            value: !1
        },
        isPostPrivate: {
            type: Boolean,
            value: !1
        },
        postInfo: {
            type: Object
        },
        tab: {
            type: Object,
            value: {}
        },
        tabIndex: Number,
        subTab: {
            type: Object,
            value: {}
        },
        subTabIndex: Number,
        labelKey: {
            type: String,
            value: "label"
        },
        index: Number
    },
    data: {
        memberList: [],
        isProductTypes: !1
    },
    observers: {
        "postInfo.users": function(e) {
            this.updateMemberList(e);
        },
        "postInfo.topicType": function(e) {
            this.setData({
                isProductTypes: [ 1, 3 ].includes(e)
            });
        }
    },
    methods: {
        updateMemberList: function(e) {
            this.setData({
                memberList: (e || []).slice(0, 4)
            });
        },
        onPostItemTap: function() {
            var s = this.properties, i = s.postInfo, o = s.index, n = s.isSelfView, a = s.subTabIndex, r = s.subTab, l = s.isProfilePage, u = l ? "b_gc_pb5uf44z_mc" : "b_gc_kamehrf5_mc", p = l ? {
                index: o,
                is_owner: n ? "1" : "0",
                select_index: a,
                select_name: r ? r.label : ""
            } : {
                index: o,
                group_id: i.postMaskId || "",
                select_index: a,
                select_name: r ? r.label : ""
            };
            t.default.moduleClick(u, e({}, p)), this.triggerEvent("onPostItemTap", i);
        },
        onRestPeopleTap: function() {
            var e = this.properties, s = e.postInfo, i = e.isSelfView, o = e.index, n = e.subTab, a = e.subTabIndex;
            !s.isChatPost && i ? (t.default.moduleClick("b_gc_9ehypzc9_mc", {
                index: o,
                is_owner: i ? "1" : "0",
                select_index: a,
                select_name: n ? n.label : ""
            }), this.triggerEvent("onRestPeopleTap", s)) : this.onPostItemTap();
        },
        onShare: function() {
            var e = this.properties, s = e.postInfo, i = e.isSelfView, o = e.index, n = e.subTab, a = e.subTabIndex;
            t.default.moduleClick("b_gc_pih6sucb_mc", {
                index: o,
                is_owner: i ? "1" : "0",
                select_index: a,
                select_name: n ? n.label : "",
                discount_status: s.helpActivityVO ? 1 : 0
            }), this.triggerEvent("onShare", s);
        },
        onEditBtnTap: function(e) {
            var s = e.currentTarget.dataset.url, i = this.properties, o = i.isSelfView, n = i.index, a = i.subTab, r = i.subTabIndex;
            t.default.moduleClick("b_gc_5dt6vldb_mc", {
                index: n,
                is_owner: o ? 1 : 0,
                select_index: r,
                select_name: a && a.label ? a.label : ""
            }), this.triggerEvent("onEditBtnTap", s);
        },
        goToBuy: function() {
            var e = this.properties, s = e.postInfo, i = e.isSelfView, o = e.index, n = e.subTab, a = e.subTabIndex;
            t.default.moduleClick("b_gc_qzt8zvbg_mc", {
                index: o,
                discount_status: s.payCouponVO && s.payCouponVO.hasCouponBonus ? "1" : "0",
                is_owner: i ? "1" : "0",
                select_index: a,
                select_name: n ? n.label : ""
            }), this.triggerEvent("goToBuy", s);
        },
        goToIM: function() {
            var e = this.properties.postInfo;
            this.triggerEvent("goToIM", e);
        },
        goToOrder: function() {
            var e = this.properties.postInfo;
            this.triggerEvent("goToOrder", e);
        },
        onJoin: function() {
            var e = this.properties, s = e.postInfo, i = e.index, o = e.subTab, n = e.subTabIndex;
            t.default.moduleClick("b_gc_n6pjaqzj_mc", {
                index: i,
                group_id: s && s.postMaskId,
                select_index: n,
                select_name: o ? o.label : ""
            }), this.triggerEvent("onJoin", s);
        }
    },
    lifetimes: {
        attached: function() {
            var e = this.properties.postInfo.users;
            this.updateMemberList(e);
        }
    }
});