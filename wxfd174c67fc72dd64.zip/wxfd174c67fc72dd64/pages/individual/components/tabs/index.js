var t = function(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}(require("../../../../utils/index")).default.getNodeRect;

Component({
    externalClasses: [ "custom-container", "custom-tabs", "custom-tab-panel", "custom-tab", "custom-sub-tabs", "custom-indicator", "custom-tab-content-item" ],
    options: {
        multipleSlots: !0
    },
    properties: {
        isSelfView: {
            type: Boolean,
            value: !1
        },
        tabs: {
            type: Array,
            valueL: [],
            observer: function(t) {
                var e = t.filter(function(t) {
                    return !!t.show;
                });
                e.length && this.setData({
                    indicatorWidth: 100 / e.length
                });
            }
        },
        labelKey: {
            type: String,
            value: "label"
        },
        current: {
            type: Number,
            value: 0
        },
        subCurrent: {
            type: Number,
            value: 0
        },
        isFixed: Boolean,
        offsetTop: String
    },
    data: {
        indicatorWidth: 0,
        indicatorOffset: 0,
        tabHeightNoChildren: 0,
        tabHeightHasChildren: 0
    },
    observers: {
        current: function(e) {
            for (var n = this, i = this.properties.tabs, a = i.filter(function(t) {
                return !!t.show;
            }), r = e, s = 0; s < e; s++) i[s].show || r--;
            a.length && "number" == typeof e && this.setData({
                indicatorOffset: 100 / a.length * r
            }), i[r].children && !this.data.tabHeightHasChildren && t("#header-container", this).then(function(t) {
                n.setData({
                    tabHeightHasChildren: t.height
                });
            }), i[r].children || this.data.tabHeightNoChildren || t("#header-container", this).then(function(t) {
                n.setData({
                    tabHeightNoChildren: t.height
                });
            });
        }
    },
    methods: {
        onTabChange: function(t) {
            var e = t.target.dataset.index;
            this.triggerEvent("tabChange", {
                index: e
            });
        },
        onSubTabChange: function(t) {
            var e = t.target.dataset.index;
            this.triggerEvent("subTabChange", {
                index: e
            });
        }
    },
    lifetimes: {
        attached: function() {
            for (var t = this.properties, e = t.tabs, n = t.current, i = e.filter(function(t) {
                return !!t.show;
            }), a = n, r = 0; r < n; r++) e[r].show && a--;
            i.length && "number" == typeof val && this.setData({
                indicatorOffset: 100 / i.length * a
            });
        }
    }
});