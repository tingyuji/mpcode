function t(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

var e = require("../../../../common/wx-privacy-constant"), n = t(require("../../../../npm/@dzfe/wx-api-promisify/dist/index.js"));

t(require("../../../../common/lx"));

Component({
    externalClasses: [ "custom-action-button" ],
    options: {
        multipleSlots: !0
    },
    properties: {
        userInfo: Object
    },
    data: {},
    methods: {
        onLogin: function() {
            this.triggerEvent("onLogin");
        },
        handleAvatarLX: function() {
            this.triggerEvent("onAvatarTap");
        },
        onAvatarPreview: function() {
            var t = this.properties.userInfo;
            t && t.avatar && n.default.previewImage({
                current: t.avatar,
                urls: [ t.avatar ],
                _mt: {
                    sceneToken: e.WX_SCENETOKENS.PREVIEWIMAGE
                }
            }), this.triggerEvent("onAvatarTap");
        },
        onUserInfoTap: function() {
            this.triggerEvent("onUserInfoTap");
        },
        onRedirectToFollowPage: function(t) {
            var e = t.currentTarget.dataset.type;
            this.triggerEvent("onRedirectToFollowPage", e);
        }
    }
});