function t(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

function e(t, e, n) {
    return e in t ? Object.defineProperty(t, e, {
        value: n,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : t[e] = n, t;
}

var n = require("../../common/city"), i = function(t) {
    if (t && t.__esModule) return t;
    var e = {};
    if (null != t) for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n]);
    return e.default = t, e;
}(require("./api")), a = t(require("../../common/login")), s = t(require("../../utils/index")), o = t(require("../../common/config")), r = t(require("../../common/lx")), d = require("../../npm/regenerator-runtime/runtime.js"), c = require("../../npm/@mtfe/weapp-privacy-api/index.js").default, l = s.default.EVENT_TYPE, f = s.default.Event, u = getApp();

Page({
    data: {
        hasNext: !0,
        feedsList: [],
        tagData: [],
        tabactivity: 0,
        tagactivity: 0,
        cityInfo: {},
        openid: "",
        scene: 0,
        sort: 0,
        pagenum: 1,
        token: "",
        changeIndex: 0,
        feedlxExtend: "",
        homeCity: (getApp().globalData || {}).ci || (0, n.getDefaultCity)().id,
        refreshEnable: !0,
        triggered: !1,
        parternsActivated: !1,
        tabs: {
            show: !1,
            data: [],
            index: 0,
            currentIsPartersTab: !1
        }
    },
    onLoad: function() {
        this.initData(), this.monitor(), r.default.pageView("c_gc_arm3pefg", {
            cat_id: o.default.catId
        });
    },
    onShow: function() {
        if ("function" == typeof this.getTabBar && this.getTabBar()) {
            var t = this.getTabBar();
            t.refreshSelectedTab && t.refreshSelectedTab();
        }
        this.cityRefresh();
    },
    initData: function() {
        var t = this;
        return d.async(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return e.next = 2, d.awrap(t.getCityInfo());

              case 2:
                return e.next = 4, d.awrap(t.getUserInfo());

              case 4:
                return e.next = 6, d.awrap(t.feedsTab().then(t.feedsList));

              case 6:
              case "end":
                return e.stop();
            }
        }, null, null, null, Promise);
    },
    monitor: function() {
        f.on(l.CONTENT_COLLECTION, this.listenCollect), f.on(l.HOME_CITYCHANGE, this.listenCity);
    },
    listenCity: function(t) {
        this.data.homeCity = t.cityid;
    },
    cityRefresh: function() {
        var t = this;
        return d.async(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                t.data.cityInfo.id && t.data.cityInfo.id !== t.data.homeCity && (t.data.cityInfo.id = t.data.homeCity, 
                t.setData({
                    "tabs.index": 0,
                    "tabs.currentIsPartersTab": !1,
                    "tabs.show": !1,
                    parternsActivated: !1,
                    homeCity: t.data.homeCity,
                    feedsList: [],
                    pagenum: 1,
                    changeIndex: 0
                }), t.feedsTab().then(t.feedsList));

              case 1:
              case "end":
                return e.stop();
            }
        }, null, null, null, Promise);
    },
    listenCollect: function(t) {
        this.updateCollect(t, "listen");
    },
    getUserInfo: function() {
        var t = this;
        return u.globalData.userInfo ? (this.data.openid = u.globalData.userInfo.openId, 
        this.data.token = u.globalData.userInfo.token, "") : a.default.getWxIds().then(function(e) {
            t.data.openid = e.openId;
        });
    },
    getCityInfo: function() {
        var t = this;
        return u.getCityInfo().then(function(e) {
            t.data.cityInfo.id = t.data.homeCity || 10, t.data.cityInfo.lat = e.lat, t.data.cityInfo.lng = e.lng;
        });
    },
    feedsTab: function() {
        var t = this, e = {
            cityid: (getApp().globalData || {}).ci || this.data.cityInfo.id,
            openid: this.data.openid,
            sceneid: this.options.sceneid || 0
        };
        return i.getFeedsTab(e).then(function(e) {
            var n = e.filters;
            if (n && n.length) {
                var i = n[0] || {}, a = !1, s = 0, o = !1, r = n.map(function(t, e) {
                    var n = t.selected, i = t.id, r = t.name;
                    return n && (s = e), 101 === i && (a = !0, n && (o = !0)), {
                        id: i,
                        name: r
                    };
                }), d = {
                    show: a,
                    index: s,
                    currentIsPartersTab: o,
                    parternsActivated: o,
                    data: r
                };
                t.setData({
                    tagData: i.children || [],
                    tabs: d,
                    tagactivity: 0
                }), t.data.scene = i.id, t.data.sort = (i.children[0] || {}).id;
            }
        });
    },
    feedsList: function() {
        var t = this, e = {
            openid: this.data.openid,
            cityid: (getApp().globalData || {}).ci || this.data.cityInfo.id,
            lat: this.data.cityInfo.lat,
            lng: this.data.cityInfo.lng,
            pagenum: this.data.pagenum,
            token: this.data.token,
            scene: this.data.scene || 0,
            width: 343,
            sort: this.data.sort,
            contentid: this.options.contentid || "",
            contenttype: this.options.contenttype || ""
        };
        return i.getFeedsList(e).then(function(e) {
            var n = e.contentList, i = e.hasNext, a = 1 === t.data.pagenum ? [] : t.data.feedsList;
            a = a && a.length ? a.concat(n) : n, t.setData({
                feedsList: a,
                hasNext: i
            });
        });
    },
    onPulling: function() {},
    onRefresh: function() {
        var t = this;
        this.resetData(), this.feedsList().then(function() {
            t.setData({
                triggered: !1
            });
        });
    },
    bindtransition: function(t) {
        this.data.refreshEnable && t.detail.dx && this.setData({
            refreshEnable: !1,
            triggered: !1
        }), t.detail.dx || this.setData({
            refreshEnable: !0,
            triggered: !1
        });
    },
    animationFinish: function(t) {
        this.setData({
            tabactivity: t.detail.current,
            refreshEnable: !0,
            triggered: !1
        });
    },
    loadMore: function() {
        this.data.pagenum = this.data.pagenum + 1, this.data.hasNext && this.feedsList();
    },
    resetData: function() {
        this.setData({
            feedsList: [],
            pagenum: 1,
            changeIndex: 0
        });
    },
    tabChange: function(t) {
        var e = t.detail.current, n = 1 == +e, i = {
            "tabs.index": +e,
            "tabs.currentIsPartersTab": n
        };
        !this.data.parternsActivated && n && (i.parternsActivated = !0), this.setData(i);
    },
    tagClick: function(t) {
        this.data.sort = t.detail.item.id, this.setData({
            tagactivity: t.detail.current
        }), this.resetData(), this.feedsList(), this.getFeedLxExtend(t.detail.item, t.detail.current, "tag");
    },
    feedClick: function(t) {
        c.navigateTo({
            url: t.detail.feed.contentDetailUrl
        });
    },
    getFeedLxExtend: function(t, e, n) {
        "tag" === n && (this.selectName = t.name, this.selectIndex = e), this.setData({
            feedlxExtend: "tab_name=" + this.tabName + "&tab_index=" + this.tabIndex + "&select_name=" + this.selectName + "&select_index=" + this.selectIndex
        });
    },
    collectClick: function(t) {
        var e = this;
        r.default.moduleClick("b_gc_s3envnib_mc", {
            index: t.detail.item.waterfallIndex,
            item_id: t.detail.item.contentId,
            item_type: t.detail.item.feedsItemType,
            select_status_change: 1 === t.detail.item.isCollected ? 0 : 1
        }), this.forceLogin().then(function() {
            e.feedCollect(t);
        });
    },
    forceLogin: function() {
        var t = this;
        return a.default.mtDefaultLogin({
            isBind: !0
        }).then(function(e) {
            t.data.token = e.token;
        });
    },
    feedCollect: function(t) {
        var e = this, n = t.detail.item, a = 1 === n.isCollected ? 0 : 1, s = n.contentType, o = {
            contentid: n.contentId,
            contenttype: s,
            token: this.data.token,
            actiontype: a
        };
        i.feedCollect(o).then(function(t) {
            t.isSuccess ? (e.updateCollect(n, "click"), c.showToast({
                title: t.resultMsg,
                icon: "none",
                duration: 1e3
            })) : c.showToast({
                title: t.resultMsg,
                icon: "none",
                duration: 1e3
            });
        });
    },
    updateCollect: function(t, n) {
        var i = t.isCollected, a = t.collectionCount, s = t.contentType, o = t.contentId, r = "click" === n, d = 1 === i ? 0 : 1, c = 1 === i ? a - 1 : a + 1, l = (this.data.feedsList || []).findIndex(function(t) {
            return t.contentId === +o && t.contentType === +s;
        });
        if (l >= 0) {
            var f;
            this.setData((f = {}, e(f, "feedsList[" + l + "].isCollected", r ? d : i), e(f, "feedsList[" + l + "].collectionCount", r ? c : a), 
            e(f, "changeIndex", l), f));
        }
    },
    onReady: function() {},
    onHide: function() {},
    onUnload: function() {
        f.off(l.CONTENT_COLLECTION, this.listenCollect), f.off(l.HOME_CITYCHANGE, this.listenCity);
    },
    onPullDownRefresh: function() {},
    onShareAppMessage: function() {
        return {
            title: "时下最潮的年轻人们都在玩什么？"
        };
    }
});