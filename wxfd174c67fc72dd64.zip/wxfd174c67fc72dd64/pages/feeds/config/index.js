Object.defineProperty(exports, "__esModule", {
    value: !0
});

var e = exports.CARD_TYPE = void 0;

!function(e) {
    e.PARTNER = "partner", e.MATERIAL = "material";
}(e || (exports.CARD_TYPE = e = {}));

exports.getDefaultPartners = function() {
    return {
        list: [],
        movingRatio: 0,
        remainCount: -1,
        canBack: !1,
        hasNext: !0,
        loading: !1,
        pagenum: 1,
        guide: 0,
        initialized: !1,
        redDot: !1,
        CARD_TYPE: e
    };
}, exports.getDefaultCardsHistory = function() {
    return {
        list: [],
        hasNext: !1,
        pageNum: 1,
        loading: !1
    };
};