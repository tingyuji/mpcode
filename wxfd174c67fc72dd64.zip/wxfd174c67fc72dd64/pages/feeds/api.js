function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.authorFollow = exports.exposureToReport = void 0, exports.getFeedsTab = function(e) {
    return r.default.request({
        url: o.FEEDS_TAB,
        data: e
    }).then(function(e) {
        var r = e.data;
        if (200 === r.code && r.msg) return r.msg;
        throw new Error("请求数据失败");
    }).catch(function(e) {
        return console.error("getFeedsTab", e), null;
    });
}, exports.getFeedsList = function(e) {
    return r.default.request({
        url: o.FEEDS_LIST,
        method: "POST",
        data: e
    }).then(function(e) {
        var r = e.data;
        if (200 === r.code && r.msg) return r.msg;
        throw new Error("请求数据失败");
    }).catch(function(e) {
        return console.error("getFeedsList", e), null;
    });
}, exports.feedCollect = function(e) {
    return r.default.request({
        url: o.FEEDS_COLLECT,
        data: e,
        method: "POST"
    }).then(function(e) {
        var r = e.data;
        if (200 === r.code && r.msg) return r.msg;
        throw new Error("请求数据失败");
    }).catch(function(e) {
        return console.error("feedCollect", e), null;
    });
}, exports.getPartners = function(e) {
    return r.default.request({
        url: o.PARTNER_LIST,
        data: e
    }).then(function(r) {
        var t = r.data, n = t.code, a = t.msg;
        if (200 === n && a) return getApp().addError(function(r) {
            if (1 === e.type && !(a.cardList || []).length && a.hasNext) return {
                category: r.AJAX_ERROR,
                msg: "拼场找人：数据为空且hasNext为true",
                custom: {
                    url: o.PARTNER_LIST,
                    data: e
                }
            };
        }), a;
        throw Error("请求数据失败");
    }).catch(function(e) {
        console.error("getPartners", e);
    });
}, exports.partnerVisitedReport = function(e) {
    return r.default.request({
        url: o.PARTNER_VISITED,
        data: e
    }).then(function(e) {
        var r = e.data, t = r.code, o = r.msg;
        if (200 === t && o) return o;
        throw Error("请求数据失败");
    }).catch(function(r) {
        console.error("getPartners", r), getApp().addError(function(r) {
            return {
                msg: "拼场找人卡片爆光接口失败",
                category: r.AJAX_ERROR,
                custom: {
                    url: o.PARTNER_VISITED,
                    params: e
                }
            };
        });
    });
};

var r = e(require("../../npm/@dzfe/wx-api-promisify/dist/index.js")), t = e(require("../../common/config")), o = {
    FEEDS_TAB: t.default.gpower_domain + "/api/gpower/content/feeds/tab",
    FEEDS_LIST: t.default.gpower_domain + "/api/gpower/content/feeds",
    FEEDS_COLLECT: t.default.dp_domain + "/api/joy/sharerelation/content/collect",
    PARTNER_LIST: t.default.gpower_domain + "/api/gpower/partner/list",
    PARTNER_VISITED: t.default.gpower_domain + "/api/gpower/partner/visit",
    AUTHOR_FOLLOW: t.default.dp_domain + "/api/joy/sharerelation/follow/operation",
    EXPOSURE_REPORT: t.default.gpower_domain + "/api/gpower/partner/card/exposure"
};

exports.exposureToReport = function(e) {
    return r.default.request({
        url: o.EXPOSURE_REPORT,
        data: e
    }).then(function(e) {
        return e.data;
    });
}, exports.authorFollow = function(e) {
    return r.default.request({
        url: o.AUTHOR_FOLLOW,
        data: e,
        method: "POST"
    });
};