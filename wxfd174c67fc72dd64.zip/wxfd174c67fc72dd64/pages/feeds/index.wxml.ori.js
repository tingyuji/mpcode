function(e,s,r,gg){
var z=gz$gwx_67()
var cI0=_mz(z,'view',['class',0,'style',1],[],e,s,gg)
var oJ0=_v()
_(cI0,oJ0)
if(_oz(z,2,e,s,gg)){oJ0.wxVkey=1
var aL0=_mz(z,'tab-comp',['activityType',3,'bind:itemChange',1,'clickBid',2,'isSticky',3,'itemType',4,'options',5,'tabOuterclass',6,'tabData',7,'viewBid',8],[],e,s,gg)
_(oJ0,aL0)
}
var lK0=_v()
_(cI0,lK0)
if(_oz(z,12,e,s,gg)){lK0.wxVkey=1
var tM0=_mz(z,'tab-comp',['activityType',13,'bind:itemClick',1,'clickBid',2,'isSticky',3,'itemType',4,'options',5,'tabOuterclass',6,'tabData',7,'top',8,'viewBid',9],[],e,s,gg)
_(lK0,tM0)
}
oJ0.wxXCkey=1
oJ0.wxXCkey=3
lK0.wxXCkey=1
lK0.wxXCkey=3
_(r,cI0)
var oH0=_v()
_(r,oH0)
if(_oz(z,23,e,s,gg)){oH0.wxVkey=1
var eN0=_mz(z,'scroll-view',['bindrefresherpulling',24,'bindrefresherrefresh',1,'bindscrolltolower',2,'class',3,'hidden',4,'lowerThreshold',5,'refresherEnabled',6,'refresherThreshold',7,'refresherTriggered',8,'scrollY',9],[],e,s,gg)
var bO0=_mz(z,'waterfall-comp',['bind:collect',34,'bind:itemClick',1,'changeIndex',2,'column',3,'gap',4,'itemViewBid',6,'listData',7,'lxExtend',8,'outerClass',9,'shopClickBid',10,'shopViewBid',11,'viewBid',12],['wx-waterfall-item',5],e,s,gg)
_(eN0,bO0)
_(oH0,eN0)
}
var oP0=_n('view')
_rz(z,oP0,'hidden',47,e,s,gg)
var xQ0=_v()
_(oP0,xQ0)
if(_oz(z,48,e,s,gg)){xQ0.wxVkey=1
var oR0=_n('Partner-Cards')
_rz(z,oR0,'cityId',49,e,s,gg)
_(xQ0,oR0)
}
xQ0.wxXCkey=1
xQ0.wxXCkey=3
_(r,oP0)
oH0.wxXCkey=1
oH0.wxXCkey=3
return r
}