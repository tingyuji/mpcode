function e(e, t, i) {
    return t in e ? Object.defineProperty(e, t, {
        value: i,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = i, e;
}

var t = Object.assign || function(e) {
    for (var t = 1; t < arguments.length; t++) {
        var i = arguments[t];
        for (var n in i) Object.prototype.hasOwnProperty.call(i, n) && (e[n] = i[n]);
    }
    return e;
}, i = require("../../../../common/lx");

Component({
    properties: {
        feeds: {
            type: Array,
            value: []
        },
        columnIndex: {
            type: Number,
            value: 0
        },
        itemClickBid: {
            type: String,
            value: ""
        },
        itemViewBid: {
            type: String,
            value: ""
        },
        shopViewBid: {
            type: String,
            value: ""
        },
        shopClickBid: {
            type: String,
            value: ""
        },
        changedItem: {
            type: Object,
            value: null
        }
    },
    lifetimes: {
        attached: function() {}
    },
    data: {
        clickType: ""
    },
    observers: {
        changedItem: function(t) {
            var i = t || {}, n = i.column, r = i.index, c = i.data;
            n === this.properties.columnIndex && this.setData(e({}, "feeds[" + r + "]", c));
        }
    },
    methods: {
        itemClick: function(e) {
            this.triggerEvent("itemClick", e.currentTarget.dataset);
        },
        collect: function(e) {
            var i = t({
                columnIndex: this.properties.columnIndex
            }, e.target.dataset);
            this.triggerEvent("collect", i);
        },
        clickPic: function(e) {
            var t = this.properties.feeds[e.currentTarget.dataset.index];
            i.moduleClick("b_gc_59iarnpn_mc", {
                click_type: "图片",
                index: t && t.waterfallIndex,
                item_id: t && t.contentId,
                item_type: t && t.feedsItemType
            });
        },
        clickAvatar: function(e) {
            var t = this.properties.feeds[e.currentTarget.dataset.index];
            i.moduleClick("b_gc_59iarnpn_mc", {
                click_type: "发布者头像",
                index: t && t.waterfallIndex,
                item_id: t && t.contentId,
                item_type: t && t.feedsItemType
            });
        },
        clickReason: function(e) {
            var t = this.properties.feeds[e.currentTarget.dataset.index];
            i.moduleClick("b_gc_59iarnpn_mc", {
                click_type: "文字",
                index: t && t.waterfallIndex,
                item_id: t && t.contentId,
                item_type: t && t.feedsItemType
            });
        }
    }
});