function t(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

function r(t) {
    if (Array.isArray(t)) {
        for (var r = 0, e = Array(t.length); r < t.length; r++) e[r] = t[r];
        return e;
    }
    return Array.from(t);
}

function e(t, r) {
    return c(t) || n(t, r) || s(t, r) || i();
}

function n(t, r) {
    var e = null == t ? null : "undefined" != typeof Symbol && t[Symbol.iterator] || t["@@iterator"];
    if (null != e) {
        var n, a, i = [], s = !0, o = !1;
        try {
            for (e = e.call(t); !(s = (n = e.next()).done) && (i.push(n.value), !r || i.length !== r); s = !0) ;
        } catch (t) {
            o = !0, a = t;
        } finally {
            try {
                s || null == e.return || e.return();
            } finally {
                if (o) throw a;
            }
        }
        return i;
    }
}

function a(t) {
    return c(t) || u(t) || s(t) || i();
}

function i() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}

function s(t, r) {
    if (t) {
        if ("string" == typeof t) return o(t, r);
        var e = Object.prototype.toString.call(t).slice(8, -1);
        return "Object" === e && t.constructor && (e = t.constructor.name), "Map" === e || "Set" === e ? Array.from(t) : "Arguments" === e || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(e) ? o(t, r) : void 0;
    }
}

function o(t, r) {
    (null == r || r > t.length) && (r = t.length);
    for (var e = 0, n = new Array(r); e < r; e++) n[e] = t[e];
    return n;
}

function u(t) {
    if ("undefined" != typeof Symbol && null != t[Symbol.iterator] || null != t["@@iterator"]) return Array.from(t);
}

function c(t) {
    if (Array.isArray(t)) return t;
}

function l(t, r) {
    if (null == t) return {};
    var e, n, a = p(t, r);
    if (Object.getOwnPropertySymbols) {
        var i = Object.getOwnPropertySymbols(t);
        for (n = 0; n < i.length; n++) e = i[n], r.indexOf(e) >= 0 || Object.prototype.propertyIsEnumerable.call(t, e) && (a[e] = t[e]);
    }
    return a;
}

function p(t, r) {
    if (null == t) return {};
    var e, n, a = {}, i = Object.keys(t);
    for (n = 0; n < i.length; n++) e = i[n], r.indexOf(e) >= 0 || (a[e] = t[e]);
    return a;
}

function d(t, r) {
    var e = Object.keys(t);
    if (Object.getOwnPropertySymbols) {
        var n = Object.getOwnPropertySymbols(t);
        r && (n = n.filter(function(r) {
            return Object.getOwnPropertyDescriptor(t, r).enumerable;
        })), e.push.apply(e, n);
    }
    return e;
}

function f(t) {
    for (var r = 1; r < arguments.length; r++) {
        var e = null != arguments[r] ? arguments[r] : {};
        r % 2 ? d(Object(e), !0).forEach(function(r) {
            m(t, r, e[r]);
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(e)) : d(Object(e)).forEach(function(r) {
            Object.defineProperty(t, r, Object.getOwnPropertyDescriptor(e, r));
        });
    }
    return t;
}

function m(t, r, e) {
    return r in t ? Object.defineProperty(t, r, {
        value: e,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : t[r] = e, t;
}

var h = function() {
    function t(t, r) {
        var e = [], n = !0, a = !1, i = void 0;
        try {
            for (var s, o = t[Symbol.iterator](); !(n = (s = o.next()).done) && (e.push(s.value), 
            !r || e.length !== r); n = !0) ;
        } catch (t) {
            a = !0, i = t;
        } finally {
            try {
                !n && o.return && o.return();
            } finally {
                if (a) throw i;
            }
        }
        return e;
    }
    return function(r, e) {
        if (Array.isArray(r)) return r;
        if (Symbol.iterator in Object(r)) return t(r, e);
        throw new TypeError("Invalid attempt to destructure non-iterable instance");
    };
}(), g = require("../../config/index"), y = t(require("../../../../common/login")), _ = require("../../../../common/city"), v = t(require("../../../../utils/index")), b = t(require("../../../../common/lx")), P = t(require("../../../../npm/@dp/util-emoji/index.js")), w = t(require("../../../../utils/dialog")), k = (t(require("../../../../utils/toast")), 
t(require("../../../../common/config"))), O = function(t) {
    if (t && t.__esModule) return t;
    var r = {};
    if (null != t) for (var e in t) Object.prototype.hasOwnProperty.call(t, e) && (r[e] = t[e]);
    return r.default = t, r;
}(require("../../api")), x = require("../../../../npm/regenerator-runtime/runtime.js"), j = require("../../../../npm/@mtfe/weapp-privacy-api/index.js").default, I = [ "posts" ];

Component({
    properties: {
        cityId: {
            value: (0, _.getDefaultCity)().id,
            type: Number
        }
    },
    data: {
        partners: (0, g.getDefaultPartners)()
    },
    lifetimes: {
        ready: function() {},
        attached: function() {
            this.onCardBackTap = v.default.throttle(this.onCardBackTap, 500), this.reset(), 
            this.initPartners();
        }
    },
    methods: {
        initPartners: function() {
            var t = this, r = this.getPartners().then(function(r) {
                if (t.setData({
                    "partners.list": r,
                    "partners.initialized": !0
                }), r.length) {
                    var e = r[0].type;
                    e === g.CARD_TYPE.PARTNER && t.partersVisitedReport(r[0]), e === g.CARD_TYPE.MATERIAL && t.cardReport({
                        type: 2
                    }, r[0]), t.setPartnerGuide();
                }
                return r || [];
            }).catch(function() {
                return [];
            });
            this.getHistoryPartners().then(function(e) {
                e.length && (t.setData({
                    "partners.canBack": !0
                }), r.then(function(r) {
                    !r.length && t.setData({
                        "partners.list": [ t.__cardsHistory.list.pop() ],
                        "partners.canBack": e.length > 1
                    });
                }).catch(console.log));
            });
        },
        getPartners: function() {
            var t = this;
            return function() {
                var r, e, n, a;
                return x.async(function(i) {
                    for (;;) switch (i.prev = i.next) {
                      case 0:
                        if (r = t.data.partners, e = r.pagenum, !(n = r.loading)) {
                            i.next = 3;
                            break;
                        }
                        return i.abrupt("return", Promise.resolve([]));

                      case 3:
                        return t.setData({
                            "partners.loading": !0
                        }), i.next = 6, x.awrap(t.getPartersParams());

                      case 6:
                        return a = i.sent, i.abrupt("return", O.getPartners(Object.assign(a, {
                            pagenum: e,
                            type: 1
                        })).then(function(r) {
                            var n = r.cardList, a = r.hasNext, i = r.restCount, s = Object.assign({
                                "partners.hasNext": a && n.length,
                                "partners.remainCount": i,
                                "partners.pagenum": e + 1,
                                "partners.loading": !1
                            });
                            t.setData(s);
                            var o = n.map(function(r) {
                                var e = r.type, n = r.cardId, a = r.partner, i = r.materialHint, s = {};
                                return e === g.CARD_TYPE.PARTNER ? s = t.processPartner(a, {
                                    type: e
                                }) : e === g.CARD_TYPE.MATERIAL && (s = i), Object.assign(s, {
                                    id: n,
                                    type: e
                                });
                            });
                            return t._partnerOriginalList = 1 === e ? o : t._partnerOriginalList.concat(o.filter(function(t) {
                                return t.type === g.CARD_TYPE.PARTNER;
                            })), o.filter(function(r) {
                                var e = r.id;
                                return !t._cardReportedIdMaps[e];
                            });
                        }).catch(function() {
                            return t.setData({
                                "partners.loading": !1
                            }), [];
                        }));

                      case 8:
                      case "end":
                        return i.stop();
                    }
                }, null, null, null, Promise);
            }();
        },
        getPartersParams: function() {
            var t = this;
            return function() {
                var r, e;
                return x.async(function(n) {
                    for (;;) switch (n.prev = n.next) {
                      case 0:
                        if (r = t.properties.cityId || (0, _.getDefaultCity)().id, !t.__parterParams) {
                            n.next = 3;
                            break;
                        }
                        return n.abrupt("return", Object.assign({}, t.__parterParams, {
                            cityid: r
                        }));

                      case 3:
                        return e = {
                            openid: "",
                            cityid: r,
                            lng: "",
                            lat: ""
                        }, n.abrupt("return", Promise.all([ y.default.getWxIds(), getApp().getCityInfo() ]).then(function(e) {
                            var n = h(e, 2), a = n[0].openId, i = n[1], s = i.lat, o = i.lng;
                            return t.__parterParams = {
                                cityid: r || (0, _.getDefaultCity)().id,
                                openid: a,
                                lat: s,
                                lng: o
                            }, t.__parterParams;
                        }).catch(function() {
                            return e;
                        }));

                      case 5:
                      case "end":
                        return n.stop();
                    }
                }, null, null, null, Promise);
            }();
        },
        onCardBackTap: function() {
            var t = this;
            return function() {
                var e, n, a, i, s;
                return x.async(function(o) {
                    for (var u; ;) switch (o.prev = o.next) {
                      case 0:
                        if (e = (t.__cardsHistory.list || []).pop(), n = t.data.partners.list || [], e || !t.data.partners.canBack) {
                            o.next = 11;
                            break;
                        }
                        return a = n[0], i = {}, a && a.traceBack && (i = a), o.next = 8, x.awrap(t.getHistoryPartners(i));

                      case 8:
                        s = o.sent, e = (s || []).pop(), (u = t.__cardsHistory.list).push.apply(u, r(s));

                      case 11:
                        n.unshift(f({}, e, {
                            _fromBack: !0
                        })), t.setData({
                            "partners.list": n,
                            "partners.canBack": t.__cardsHistory.list.length > 0 || t.__cardsHistory.hasNext
                        });

                      case 13:
                      case "end":
                        return o.stop();
                    }
                }, null, null, null, Promise);
            }();
        },
        getHistoryPartners: function(t) {
            var r = this;
            return function() {
                var e, n, a, i, s, o;
                return x.async(function(u) {
                    for (;;) switch (u.prev = u.next) {
                      case 0:
                        if (e = r.__cardsHistory.pageNum, n = {}, (t || {}).userMaskId && (a = t.postMaskId, 
                        i = t.userMaskId, s = t.platform, n = {
                            postmaskid: a,
                            usermaskid: i,
                            userplatform: s
                        }), !r.__cardsHistory.loading) {
                            u.next = 5;
                            break;
                        }
                        return u.abrupt("return");

                      case 5:
                        return r.__cardsHistory.loading = !0, u.next = 8, x.awrap(r.getPartersParams());

                      case 8:
                        return o = u.sent, u.abrupt("return", O.getPartners(Object.assign(o, {
                            pagenum: e,
                            type: 2
                        }, n)).then(function(t) {
                            var n = t.hasNext, a = t.cardList;
                            r.__cardsHistory.loading = !1;
                            var i = (a || []).map(function(t) {
                                var e = t.type, n = t.partner, a = t.cardId;
                                return Object.assign(r.processPartner(n, {
                                    type: e
                                }), {
                                    traceBack: !0,
                                    id: a
                                });
                            }).reverse();
                            if (Object.assign(r.__cardsHistory, {
                                pageNum: e + 1,
                                hasNext: n
                            }), 1 === e) r.__cardsHistory.list = i; else {
                                var s = r.__cardsHistory.list.map(function(t) {
                                    return t.id;
                                });
                                i = i.filter(function(t) {
                                    return !s.includes(t.id);
                                });
                            }
                            return i;
                        }).catch(function() {
                            return r.__cardsHistory.loading = !1, [];
                        }));

                      case 10:
                      case "end":
                        return u.stop();
                    }
                }, null, null, null, Promise);
            }();
        },
        onPartnerTap: function(t) {
            var r = this, e = t.detail, n = (e.index, e.dataset || {}), a = n.taptype, i = n.lxType;
            try {
                var s = this.data.partners.list[0], o = s.post.info, u = o.jumpUrl, c = o.followed, l = s.id, p = s.userMaskId, d = s.platform;
                if ("follow" === a) return this.confirmFollow(), b.default.moduleClick("b_gc_ke2higsg_mc", {
                    index: (this._partnerOriginalList || []).findIndex(function(t) {
                        return t.id === l;
                    }),
                    select_status_change: ~~!c
                });
                j.navigateTo({
                    url: u
                }), !this.cardReported && this.cardReport({
                    userMaskId: p,
                    platform: d,
                    type: 1
                }).then(function() {
                    r.__cardReported = !0;
                }), i && b.default.moduleClick("b_gc_yaxesvn8_mc", {
                    status: ~~c,
                    index: (this._partnerOriginalList || []).findIndex(function(t) {
                        return t.id === l;
                    }),
                    click_type: i
                });
            } catch (t) {
                console.log(t);
            }
        },
        cardReport: function(t, r) {
            return r && b.default.moduleView("b_gc_umtllt2t_mv", {
                status: r.followUser ? 1 : 0
            }), O.exposureToReport(f({
                openid: this.data.openid
            }, t));
        },
        _cardReportedIdMaps: {},
        partersVisitedReport: function(t) {
            var r = this;
            return function() {
                var e, n, a, i, s;
                return x.async(function(o) {
                    for (;;) switch (o.prev = o.next) {
                      case 0:
                        if (t) {
                            o.next = 2;
                            break;
                        }
                        return o.abrupt("return");

                      case 2:
                        if (e = t.id, n = t.userMaskId, a = t.postMaskId, i = t.platform, s = t.info.followed, 
                        !r._cardReportedIdMaps[e]) {
                            o.next = 5;
                            break;
                        }
                        return o.abrupt("return");

                      case 5:
                        return r._cardReportedIdMaps[e] = {
                            usermaskid: n,
                            platform: i,
                            postmaskid: a
                        }, b.default.moduleView("b_gc_yaxesvn8_mv", {
                            index: Object.keys(r._cardReportedIdMaps).length - 1,
                            status: ~~s
                        }), o.abrupt("return", O.partnerVisitedReport({
                            usermaskid: n,
                            postmaskid: a,
                            userplatform: i,
                            openid: r.__parterParams.openid,
                            cityid: r.properties.cityId
                        }).catch(function() {
                            return console.log;
                        }));

                      case 8:
                      case "end":
                        return o.stop();
                    }
                }, null, null, null, Promise);
            }();
        },
        processPartner: function(t, r) {
            var e = r.type, n = t.posts, a = l(t, I), i = v.default.getPropetiesFromObj([ "age", "gender", "age", "industry", "avatar", "name", "introduction", "mtUserMaskId" ], a), s = {
                info: Object.assign(i, f({
                    _fromBack: !1
                }, -1 !== a.followStatus ? {
                    followed: [ 1, 2 ].includes(a.followStatus)
                } : {})),
                type: e,
                userMaskId: a.userMaskId,
                platform: a.platform
            };
            if ((n || []).length) {
                var o = this.processPostData(n[0]);
                Object.assign(s, {
                    post: o,
                    postMaskId: o.postMaskId
                });
            }
            return s;
        },
        processPostData: function(t, r) {
            var e = t || {}, n = e.users, a = e.sharePostCardVO, i = e.mtShopId, s = e.postMaskId, o = Object.assign;
            return (a.roundList || []).forEach(function(t) {
                t.msg = P.default.formatText(t.msg);
            }), {
                index: r,
                postMaskId: s,
                users: o((n || []).slice(0, 4).map(function(t) {
                    return v.default.getPropetiesFromObj([ "name", "avatar", "isCaptain", "industry", "symbolType" ], t);
                })),
                info: v.default.getPropetiesFromObj([ "time", "declaration", "categoryName", "fullPeople", "currentPeople", "jumpUrl", "payCouponVO", "isFastSpell", "topicType", "sharePostPeopleNumVO", "openStatus" ], t),
                shop: o({
                    mtShopId: i
                }, v.default.getPropetiesFromObj([ "name", "distance", "headPic", "roundList" ], a))
            };
        },
        cardMoveRatioChanged: function(t) {
            var r = t.detail.ratio;
            this.setData({
                "partners.movingRatio": r
            });
        },
        cardChanged: function(t) {
            var n = this;
            t.detail.index;
            try {
                var i = this.data.partners, s = i.list, o = i.hasNext, u = a(s), c = u[0], l = u.slice(1), p = e(l, 1)[0];
                try {
                    var d = p.type;
                    d === g.CARD_TYPE.PARTNER && p && !p.traceBack && this.partersVisitedReport(p), 
                    d === g.CARD_TYPE.MATERIAL && this.cardReport({
                        type: 2
                    }, p);
                } catch (t) {}
                if (this.__getNewListPromise) return;
                this.__getNewListPromise = o && l.length <= 1 ? this.getPartners() : Promise.resolve([]), 
                c.type === g.CARD_TYPE.PARTNER && this.__cardsHistory.list.push(c), setTimeout(function() {
                    n.setData({
                        "partners.list": l.map(function(t) {
                            return Object.assign(t, {
                                _fromBack: !1
                            });
                        }),
                        "partners.movingRatio": 0,
                        "partners.canBack": !0
                    }), n.__getNewListPromise.then(function(t) {
                        n.__getNewListPromise = null;
                        var e = (n._partnerOriginalList || []).slice(0, -t.length).map(function(t) {
                            return t.id;
                        });
                        t.length && n.setData({
                            "partners.list": l.concat.apply(l, r(t.filter(function(t) {
                                return !e.includes(t.id);
                            })))
                        });
                    });
                }, 260);
            } catch (t) {
                console.log(t);
            }
            2 === this._partnerGuide_ && this.setPartnerGuide(3);
        },
        confirmFollow: function() {
            var t = this.data.partners.list[0], r = (t.id, t.info), e = r.followed, n = r.mtUserMaskId;
            return e ? w.default.confirm({
                message: "确定要取消关注吗？",
                cancelButtonText: "继续关注",
                confirmButtonText: "确定取消",
                context: this
            }).then(this.authorFollow.bind(this, e, n)).then(function() {
                return b.default.moduleClick("b_gc_4aqp2zvw_mc");
            }) : this.authorFollow(e, n);
        },
        authorFollow: function(t, r) {
            var e = this;
            return x.async(function(n) {
                for (;;) switch (n.prev = n.next) {
                  case 0:
                    if (!e._following) {
                        n.next = 2;
                        break;
                    }
                    return n.abrupt("return");

                  case 2:
                    y.default.mtDefaultLogin({
                        isBind: !0
                    }).then(function(n) {
                        var a = n.token;
                        e._following = !0, O.authorFollow({
                            token: a,
                            type: ~~!t,
                            usermaskid: r,
                            platform: k.default.platformCode
                        }).then(function(r) {
                            var n = r.errorMessage;
                            e._following = !1, n ? e.showToast(n) : (e.setData({
                                "partners.list[0].info.followed": ~~!t
                            }), j.showToast({
                                title: (t ? "已取消" : "已") + "关注",
                                icon: "none"
                            }));
                        }).catch(function() {
                            e._following = !1, j.showToast({
                                title: (t ? "取消" : "") + "关注出现错误，请稍后再试~",
                                icon: "none"
                            });
                        });
                    });

                  case 3:
                  case "end":
                    return n.stop();
                }
            }, null, null, null, Promise);
        },
        setPartnerGuide: function() {
            var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1, r = this;
            return function() {
                var e, n;
                return x.async(function(a) {
                    for (;;) switch (a.prev = a.next) {
                      case 0:
                        if (e = "__partners__guide", n = function(t) {
                            r.setData({
                                "partners.guide": t
                            }, j.setStorage.bind(null, {
                                key: e,
                                data: t > 1 ? 0 : t
                            }));
                        }, r._partnerGuide_) {
                            a.next = 7;
                            break;
                        }
                        return a.next = 5, x.awrap(j.getStorage({
                            key: e
                        }).then(function(t) {
                            r._partnerGuide_ = t.data;
                        }).catch(function() {
                            r._partnerGuide_ = t, n(t);
                        }));

                      case 5:
                        a.next = 9;
                        break;

                      case 7:
                        r._partnerGuide_ = t, n(t);

                      case 9:
                      case "end":
                        return a.stop();
                    }
                }, null, null, null, Promise);
            }();
        },
        onGuideTap: function() {
            1 === this.data.partners.guide ? this.setPartnerGuide(2) : this.setData({
                "partners.guide": 0
            });
        },
        onGoUserProfileEditBtnTap: function(t) {
            var r = t.detail;
            (r || {}).jumpUrl && j.navigateTo({
                url: r.jumpUrl
            }), b.default.moduleClick("b_gc_umtllt2t_mc", {
                status: r.followUser ? 1 : 0
            });
        },
        reset: function() {
            this.__cardsHistory = (0, g.getDefaultCardsHistory)(), this._cardReportedIdMaps = {}, 
            this.__parterParams = null, this._partnerOriginalList = [], this.data.partners.initialized && this.setData({
                partners: (0, g.getDefaultPartners)()
            });
        }
    }
});