Component({
    externalClasses: [ "my-class" ],
    properties: {
        info: Object,
        index: Number,
        movingRatio: Number,
        isLast: {
            type: Boolean,
            value: !1
        },
        fromBack: {
            type: Boolean,
            value: !1
        }
    },
    data: {},
    methods: {},
    created: function() {},
    attached: function() {},
    ready: function() {},
    moved: function() {},
    detached: function() {}
});