Component({
    properties: {
        material: Object
    },
    data: {},
    methods: {
        onGoEditBtnTap: function() {
            this.triggerEvent("onGoEditBtnTap", this.data.material);
        }
    }
});