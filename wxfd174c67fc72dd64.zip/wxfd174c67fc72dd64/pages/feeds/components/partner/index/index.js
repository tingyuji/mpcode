Component({
    properties: {
        info: Object,
        post: Object,
        index: Number,
        showRank: {
            type: Boolean,
            value: !1,
            observer: function(t, e) {
                var a = this;
                t !== e && (!t && this.setData({
                    __showRank: t
                }), t && setTimeout(function() {
                    a.setData({
                        __showRank: t
                    });
                }, 500));
            }
        }
    },
    data: {
        __showRank: !1
    },
    methods: {
        onPartnerTap: function(t) {
            var e = t.currentTarget.dataset;
            this.triggerEvent("onPartnerTap", {
                index: this.data.index,
                dataset: e
            });
        }
    }
});