function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function n(e, n) {
    var t = {};
    for (var o in e) n.indexOf(o) >= 0 || Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
    return t;
}

var t = function() {
    function e(e, n) {
        var t = [], o = !0, r = !1, i = void 0;
        try {
            for (var a, s = e[Symbol.iterator](); !(o = (a = s.next()).done) && (t.push(a.value), 
            !n || t.length !== n); o = !0) ;
        } catch (e) {
            r = !0, i = e;
        } finally {
            try {
                !o && s.return && s.return();
            } finally {
                if (r) throw i;
            }
        }
        return t;
    }
    return function(n, t) {
        if (Array.isArray(n)) return n;
        if (Symbol.iterator in Object(n)) return e(n, t);
        throw new TypeError("Invalid attempt to destructure non-iterable instance");
    };
}(), o = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
}, r = Object.assign || function(e) {
    for (var n = 1; n < arguments.length; n++) {
        var t = arguments[n];
        for (var o in t) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
    }
    return e;
}, i = require("../../../npm/@mtfe/mt-weapp-url/url.js"), a = require("../../../common/config"), s = e(require("../../../common/login")), u = e(require("../../../common/lx")), f = e(require("../../../utils/index")), c = require("../../../common/storage-constants"), d = require("../../../npm/@mtfe/weapp-privacy-api/index.js").default, l = f.default.Event, p = f.default.EVENT_TYPE, h = getApp(), m = {
    required: "1",
    optional: "0"
}, y = function(e) {
    return "" + e === m.required;
}, _ = function() {
    return new Promise(function(e, n) {
        d.getSystemInfo({
            success: e,
            fail: n
        });
    });
};

Page({
    data: {
        url: "",
        showWebview: !0
    },
    setGlobalData: function(e, n) {
        h && (h.globalData[e] = n);
    },
    parseOptions: function() {
        var e = this, f = this.options, c = f.weburl, l = f.share, p = f.title, m = f.f_userInfo, g = f.f_wxUserInfo, I = f.f_userId, v = (f.f_openId, 
        f.f_openIdCipher, f.f_unionid, f.f_uniqueid, f.f_pos), b = f.f_token, w = f.f_code, E = f.f_utm, S = f.f_ci, P = f.f_fingerprint, O = (f.f_brand, 
        f.f_model, f.f_system, f.f_safeArea, f.openId, f.openIdCipher, f.unionid, f.uniqueid, 
        f.token), x = f.code, j = n(f, [ "weburl", "share", "title", "f_userInfo", "f_wxUserInfo", "f_userId", "f_openId", "f_openIdCipher", "f_unionid", "f_uniqueid", "f_pos", "f_token", "f_code", "f_utm", "f_ci", "f_fingerprint", "f_brand", "f_model", "f_system", "f_safeArea", "openId", "openIdCipher", "unionid", "uniqueid", "token", "code" ]), D = h.globalData;
        "0" === l ? d.hideShareMenu() : ("1" === l || "2" === l && D.userInfo && D.userInfo.token) && d.showShareMenu(), 
        void 0 !== p && (this.title = p);
        var q = c && -1 === c.indexOf("https://") ? decodeURIComponent(c) : c;
        if (!q) return Promise.reject(Error("url is undefined"));
        var A = (0, i.urlParse)(q), k = [], C = {}, R = {};
        return I && k.push(s.default.mtDefaultLogin({
            isBind: y(I)
        }).then(function(e) {
            if (e) {
                console.log("获取到用户信息", e);
                var n = e.userId || e.userInfo && e.userInfo.userId || "";
                Object.assign(C, {
                    userId: n
                });
            }
        })), (m || g) && k.push(s.default.mtDefaultLogin({
            isBind: y(m) || y(g)
        }).then(function(e) {
            if (e) {
                console.log("获取到用户信息", e);
                var t = e.userInfo, o = void 0 === t ? {} : t, i = e.wxUserInfo, a = void 0 === i ? {} : i, s = n(e, [ "userInfo", "wxUserInfo" ]);
                Object.assign(C, r({}, o, a, s));
            }
        })), [ "openId", "openIdCipher", "unionid", "uniqueid" ].forEach(function(n) {
            f[n] ? R[n] = f[n] : f["f_" + n] && (D.wxIds && D.wxIds[n] ? C[n] = D.wxIds[n] : y(f["f_" + n]) && k.push(s.default.getWxIds().then(function(t) {
                t && (C[n] = t[n], e.setGlobalData("wxIds", t));
            })));
        }), [ "brand", "model", "system", "safeArea" ].forEach(function(n) {
            f["f_" + n] && (D.systemInfo && D.systemInfo[n] ? C[n] = D.systemInfo[n] : y(f["f_" + n]) && k.push(_().then(function(t) {
                Object.keys(t).forEach(function(e) {
                    "object" === o(t[e]) ? t[e] = JSON.stringify(t[e]) : t[e] = t[e];
                }), C[n] = t[n], e.setGlobalData("systemInfo", t);
            })));
        }), v && (D.pos && D.pos.lat && D.pos.lng ? Object.assign(C, D.pos) : y(v) && k.push(h.getCityInfo().then(function(n) {
            if (n) {
                var t = {
                    lng: n.lng,
                    lat: n.lat
                };
                Object.assign(C, t), e.setGlobalData("pos", t);
            }
        }))), O ? R.token = O : b && k.push(s.default.mtDefaultLogin({
            isBind: y(b)
        }).then(function(e) {
            e && (C.token = e.token || e.userInfo && e.userInfo.token || "");
        })), x ? R.code = x : w && k.push(s.default.mtDefaultLogin({
            isBind: y(w)
        }).then(function(e) {
            e && (C.code = e.code || e.userInfo && e.userInfo.code || "");
        })), E && (C.utmSource = D.utmSource), S && (C.ci = D.ci || 10), y(P) && k.push(h.finger().then(function(e) {
            Object.assign(C, {
                finger: e || ""
            });
        })), a.swimlane && (C._swimlane_ = a.swimlane), this.addRCHeader(C), ("__lxsdk_params=" + (decodeURIComponent(u.default.setURLEnv({
            withEnvKeys: [ "ch", "net" ],
            mmpNativeFirstKeys: [ "sn", "cityid" ]
        })) || "")).split("&").reduce(function(e, n) {
            var o = n.split("="), r = t(o, 2), i = r[0], a = r[1], s = void 0 === a ? "" : a;
            return e[i] = s, e;
        }, C), C.cuid = u.default.get("lxcuid"), Promise.all(k).then(function() {
            Object.assign(A.query, C, R, j, {
                wxsource: "generalpin"
            });
            var e = A.format();
            return console.log({
                h5Url: e
            }), e;
        });
    },
    addRCHeader: function(e) {
        var n = d.getStorageSync(c.DEBUG_STORE_KEYS.HEADERS);
        return Array.isArray(n) && n.length && n.forEach(function(n) {
            e[n.key] = n.value;
        }), e;
    },
    getCurrentPagePath: function() {
        var e = this;
        return Object.keys(this.options).reduce(function(n, t) {
            return "" + n + t + "=" + ("weburl" === t ? encodeURIComponent(e.options[t]) : e.options[t]) + "&";
        }, "/pages/webview/webview/index?");
    },
    onLoad: function(e) {
        var n = this;
        this.options = Object.keys(e).reduce(function(n, t) {
            return n[t] = decodeURIComponent(e[t]), n;
        }, {}), this.parseOptions().then(function(e) {
            n.setData({
                url: e
            });
        }, function(e) {
            console.error(e);
        });
    },
    onReady: function() {},
    onShow: function() {
        void 0 !== this.title && d.setNavigationBarTitle({
            title: this.title
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        var e = this.data;
        e.activityId, e.ad_source, e.title;
        if (this.shareParam) return this.shareParam.path = this.getCurrentPagePath(), console.log("webview share message", this.shareParam), 
        this.shareParam;
        console.log("no share param");
    },
    getMessage: function(e) {
        var n = this, t = e.detail.data;
        console.log(t), l.emit(p.WEBVIEW_POSTMESSAGE, t), t.forEach(function(e) {
            "share" === e.type && (n.shareParam = e.data), e.type === p.PIKE_H5_READ_MESSAGE && l.emit(p.PIKE_H5_READ_MESSAGE, e.data);
        }), (t || []).filter(function(e) {
            return "share" === e.type;
        }).forEach(function(e) {
            e.data.priority && (!n.shareParam.priority || e.data.priority >= n.shareParam.priority) && (n.shareParam = e.data);
        });
    }
});