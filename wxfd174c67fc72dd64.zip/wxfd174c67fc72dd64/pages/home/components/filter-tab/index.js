function t(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

function e(t, e, i) {
    return e in t ? Object.defineProperty(t, e, {
        value: i,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : t[e] = i, t;
}

var i, r = function() {
    function t(t, e) {
        var i = [], r = !0, a = !1, n = void 0;
        try {
            for (var s, l = t[Symbol.iterator](); !(r = (s = l.next()).done) && (i.push(s.value), 
            !e || i.length !== e); r = !0) ;
        } catch (t) {
            a = !0, n = t;
        } finally {
            try {
                !r && l.return && l.return();
            } finally {
                if (a) throw n;
            }
        }
        return i;
    }
    return function(e, i) {
        if (Array.isArray(e)) return e;
        if (Symbol.iterator in Object(e)) return t(e, i);
        throw new TypeError("Invalid attempt to destructure non-iterable instance");
    };
}(), a = Object.assign || function(t) {
    for (var e = 1; e < arguments.length; e++) {
        var i = arguments[e];
        for (var r in i) Object.prototype.hasOwnProperty.call(i, r) && (t[r] = i[r]);
    }
    return t;
}, n = t(require("../../../../utils/index")), s = t(require("../../../../common/lx")), l = require("../../config/index"), o = function() {
    return ((arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : []) || []).map(function(t) {
        return a({}, t, {
            checked: !1
        });
    });
};

Component({
    properties: {
        filterListObj: {
            type: Object,
            value: {}
        },
        isFilterFixed: {
            type: Boolean,
            value: !1
        },
        isDateTabFixed: {
            type: Boolean,
            value: !1
        },
        tabactivity: {
            type: Number,
            value: 0
        },
        currentCityId: {
            type: Number,
            value: 0
        },
        curIndex: {
            type: Number,
            value: -1
        }
    },
    data: {
        options: {
            labelKey: "categoryName"
        },
        filtered: (0, l.getDefaultFilter)(),
        isFixed: !1,
        isDateFixed: !1,
        navHeight: l.HEIGHT.NAVHEIGHT,
        tabHeight: l.HEIGHT.NAVHEIGHT + l.HEIGHT.TABHEIGHT - 2,
        filterPopupTop: {
            top: n.default.px2rpx(l.HEIGHT.NAVHEIGHT + l.HEIGHT.FILTERHEIGHT - 2) + "rpx"
        },
        FILTER_TYPES: l.FILTER_TYPES,
        activeKey: "",
        filterList: null,
        CATEGORY_NAME: l.CATEGORY_NAME,
        __filterLXNameMap: (i = {}, e(i, l.FILTER_TYPES.DISTRICTS, "附近"), e(i, l.FILTER_TYPES.RULE, "极速拼成"), 
        e(i, l.FILTER_TYPES.SORT, "排序"), e(i, l.FILTER_TYPES.TIMESLOT, "时间段"), i),
        __filterLXtype: ""
    },
    methods: {
        categoryChange: function(t) {
            var e = t.detail.item ? [ t.detail.item ] : [];
            this.setData({
                "filtered.categories": e,
                "filtered.expandType": ""
            }), this.triggerEvent("confirmFilterd", {
                type: l.FILTER_TYPES.CATEGORIES,
                filtered: this.data.filtered
            }), this.triggerEvent("onCategoryItemClick", t.detail);
        },
        getDatefilterTop: function(t) {
            var e = t.detail;
            this.triggerEvent("getDatefilterTop", e + l.HEIGHT.NAVHEIGHT + l.HEIGHT.TABHEIGHT);
        },
        onFilterItemTap: function(t) {
            var i = t.currentTarget.dataset.raw, n = r(i, 2), s = n[0], o = n[1];
            if (s === l.FILTER_TYPES.SORT) return this.setData({
                "filterList.sort": this.data.filterList.sort.map(function(t, e) {
                    return a({}, t, {
                        checked: e === o
                    });
                })
            }), void this.confirmFilterd();
            this.setData(e({}, "filterList." + s + "[" + o + "].checked", !this.data.filterList[s][o].checked)), 
            s !== l.FILTER_TYPES.DATES && s !== l.FILTER_TYPES.RULE || this.confirmFilterd();
        },
        onFilterBtnTap: function(t) {
            var e = t.currentTarget.dataset.filter || t.target.dataset.filter, i = this.data.filtered.expandType;
            if (this.data.__filterLXtype = e, i === e) return this.closeFilterPopup();
            if (i) this.setData({
                "filtered.expandType": e
            }); else {
                var r = this.data, n = r.filtered, l = r.filterList, o = n.timeslot.map(function(t) {
                    return t.type;
                });
                this.__isFixed = this.data.isFixed, this.__isDateFixed = this.data.isDateFixed, 
                this.setData({
                    activeKey: this.data.activeKey,
                    "filtered.expandType": e,
                    "filterList.timeslot": l.timeslot.map(function(t) {
                        return a({}, t, {
                            checked: !!~o.indexOf(t.type)
                        });
                    }),
                    isFixed: !0,
                    isDateFixed: !0
                });
            }
            s.default.moduleView("b_gc_afdzahw4_mv", {
                item_type: this.data.__filterLXNameMap[e]
            }), this.triggerEvent("onFilterBtnTap");
        },
        secondColumnClick: function(t) {
            var e = t.detail.second, i = t.detail.first;
            this.data.activeKey = i.id + "_" + e.id, this.setData({
                "filtered.districts": [ {
                    regionid: e.id,
                    regiontype: e.type,
                    name: e.name
                } ]
            }), this.confirmFilterd();
        },
        closeFilterPopup: function() {
            this.setData({
                "filtered.expandType": "",
                isFixed: this.__isFixed || !1,
                isDateFixed: this.__isDateFixed || !1
            }), this.triggerEvent("closeFilterPopup", {
                isFixed: this.__isFixed
            });
        },
        getFilterListChecked: function() {
            var t = this.data.filterList, e = t.dates, i = t.sort, r = t.timeslot, a = function(t) {
                return t.checked;
            };
            return {
                rules: t.rules.filter(a),
                sort: i.filter(a),
                timeslot: r.filter(a),
                dates: e.filter(a)
            };
        },
        confirmFilterd: function() {
            this.closeFilterPopup();
            var t = Object.assign(this.data.filtered, this.getFilterListChecked());
            this.setData({
                filtered: t
            }), this.triggerEvent("confirmFilterd", {
                type: this.data.__filterLXtype,
                filtered: t
            }), this.confirmBtnLXMC(this.data.__filterLXtype, t);
        },
        confirmBtnLXMC: function(t, e) {
            if (t !== l.FILTER_TYPES.DATES && t !== l.FILTER_TYPES.RULE) {
                var i = (e[t] || []).concat([]).map(function(t) {
                    return t.name;
                }).join(",");
                s.default.moduleClick("b_gc_xdsnvu54_mc", {
                    item_type: this.data.__filterLXNameMap[t],
                    title: i
                });
            }
        },
        onFiltersResetBtnTap: function() {
            this.setData({
                "filterList.timeslot": o(this.data.filterList.timeslot)
            }), s.default.moduleClick("b_gc_94s29kxc_mc", {
                item_type: this.data.__filterLXNameMap[this.data.__filterLXtype]
            });
        },
        getRoleplayData: function(t) {
            this._roleplaydata = t.detail;
        },
        getBackroomData: function(t) {
            this._backroomdata = t.detail;
        }
    },
    observers: {
        isFilterFixed: function(t) {
            this.setData({
                isFixed: t
            });
        },
        isDateTabFixed: function(t) {
            this.setData({
                isDateFixed: t
            });
        },
        filterListObj: function(t) {
            this.setData({
                filterList: t,
                filtered: (0, l.getDefaultFilter)(),
                activeKey: ""
            });
        }
    }
});