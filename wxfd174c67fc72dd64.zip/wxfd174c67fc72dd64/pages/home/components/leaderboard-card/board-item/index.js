Component({
    properties: {
        boardInfo: {
            type: Object,
            default: {}
        }
    },
    data: {
        name: ""
    },
    observers: {
        boardInfo: function(e) {
            var t = e.name;
            t.length > 8 && (t = t.slice(0, 8) + "…"), this.setData({
                name: t
            });
        }
    }
});