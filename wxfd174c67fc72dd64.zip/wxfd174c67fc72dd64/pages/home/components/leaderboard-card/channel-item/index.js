Component({
    properties: {
        channelInfo: {
            type: Object,
            default: {}
        }
    },
    data: {
        name: ""
    },
    observers: {
        channelInfo: function(e) {
            var n = e.name;
            n.length > 4 && (n = n.slice(0, 4) + "…"), this.setData({
                name: n
            });
        }
    }
});