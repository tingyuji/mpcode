function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function t(e) {
    if (Array.isArray(e)) {
        for (var t = 0, r = Array(e.length); t < e.length; t++) r[t] = e[t];
        return r;
    }
    return Array.from(e);
}

function r(e, t) {
    var r = Object.keys(e);
    if (Object.getOwnPropertySymbols) {
        var a = Object.getOwnPropertySymbols(e);
        t && (a = a.filter(function(t) {
            return Object.getOwnPropertyDescriptor(e, t).enumerable;
        })), r.push.apply(r, a);
    }
    return r;
}

function a(e) {
    for (var t = 1; t < arguments.length; t++) {
        var a = null != arguments[t] ? arguments[t] : {};
        t % 2 ? r(Object(a), !0).forEach(function(t) {
            n(e, t, a[t]);
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(a)) : r(Object(a)).forEach(function(t) {
            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(a, t));
        });
    }
    return e;
}

function n(e, t, r) {
    return t in e ? Object.defineProperty(e, t, {
        value: r,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = r, e;
}

var o = e(require("../../../../common/login")), c = e(require("../../../../common/lx")), i = function(e) {
    if (e && e.__esModule) return e;
    var t = {};
    if (null != e) for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && (t[r] = e[r]);
    return t.default = e, t;
}(require("./api")), s = require("../../config/index"), u = require("../../../../npm/regenerator-runtime/runtime.js"), l = require("../../../../npm/@mtfe/weapp-privacy-api/index.js").default, d = getApp();

Component({
    properties: {
        categoryName: {
            type: String,
            default: ""
        },
        currentCityId: {
            type: Number,
            default: 0
        }
    },
    data: {
        rankCard: [],
        spuCard: {},
        cityInfo: {},
        currentSwiper: 0,
        roleplayData: {},
        backroomData: {},
        isShow: !1,
        categoryId: -1,
        abtest: -9999
    },
    methods: {
        getCityInfo: function() {
            var e = this;
            return d.getCityInfo().then(function(t) {
                e.setData({
                    cityInfo: {
                        lat: t.lat,
                        lng: t.lng
                    }
                });
            });
        },
        getLeaderBoardHeigt: function(e, t) {
            var r = 0;
            return e && e.length && t && t.members && t.members.length ? r = s.HEIGHT.RANKCARDHEIGHT : t && t.members && t.members.length && (r = s.HEIGHT.SPUCARDHEGIHT), 
            r;
        },
        getOpenId: function() {
            var e = this;
            return u.async(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (!(d.globalData && d.globalData.userInfo && d.globalData.userInfo.openId)) {
                        t.next = 2;
                        break;
                    }
                    return t.abrupt("return", d.globalData.userInfo.openId);

                  case 2:
                    if (!e._openIdPromise) {
                        t.next = 4;
                        break;
                    }
                    return t.abrupt("return", e._openIdPromise);

                  case 4:
                    return e._openIdPromise = o.default.getWxIds({
                        isBind: !1
                    }).then(function(e) {
                        return e.openId;
                    }).catch(function() {
                        return "";
                    }), t.abrupt("return", e._openIdPromise);

                  case 6:
                  case "end":
                    return t.stop();
                }
            }, null, null, null, Promise);
        },
        setParams: function() {
            var e = this;
            return function() {
                var t;
                return u.async(function(r) {
                    for (;;) switch (r.prev = r.next) {
                      case 0:
                        return t = {
                            openid: "",
                            lng: e.data.cityInfo.lng,
                            lat: e.data.cityInfo.lat,
                            cityid: e.data.currentCityId
                        }, r.next = 3, u.awrap(e.getOpenId());

                      case 3:
                        return t.openid = r.sent, r.abrupt("return", t);

                      case 5:
                      case "end":
                        return r.stop();
                    }
                }, null, null, null, Promise);
            }();
        },
        getRoleplayBoard: function() {
            var e = this;
            return function() {
                var t;
                return u.async(function(r) {
                    for (;;) switch (r.prev = r.next) {
                      case 0:
                        return r.next = 2, u.awrap(e.setParams());

                      case 2:
                        return t = r.sent, r.abrupt("return", i.getRoleplayBoard(t).then(function(t) {
                            e.triggerEvent("getRoleplayData", t), e.data.roleplayData = t;
                        }));

                      case 4:
                      case "end":
                        return r.stop();
                    }
                }, null, null, null, Promise);
            }();
        },
        getBackroomBoard: function() {
            var e = this;
            return function() {
                var t;
                return u.async(function(r) {
                    for (;;) switch (r.prev = r.next) {
                      case 0:
                        return r.next = 2, u.awrap(e.setParams());

                      case 2:
                        return t = r.sent, r.abrupt("return", i.getBackroomBoard(t).then(function(t) {
                            e.triggerEvent("getBackroomData", t), e.data.backroomData = t, e.setData({
                                abtest: (t || {}).testAB - 1
                            });
                        }));

                      case 4:
                      case "end":
                        return r.stop();
                    }
                }, null, null, null, Promise);
            }();
        },
        handleBoardData: function() {
            var e = d.globalData.homeParams;
            if (e) {
                var r = e.categories;
                this.data.categoryId = r;
            }
            var n = this.data, o = n.categoryName, c = n.categoryId, i = [], u = {}, l = 0;
            if (o === s.CATEGORY_NAME.ROLEPLAY || "" === o && c === s.CATEGORY_ID.ROLEPLAY) {
                var f = this.data.roleplayData || {};
                i = f.rolePlayRankCards, u = f.rolePlaySpuCard, l = this.getLeaderBoardHeigt(i || [], u || {});
            } else if (o === s.CATEGORY_NAME.BACKROOM || "" === o && c === s.CATEGORY_ID.BACKROOM) {
                var p = this.data.backroomData || {};
                i = p.backroomRankCards, u = p.backroomThemeCard, l = this.getLeaderBoardHeigt(i || [], u || {});
            }
            this.triggerEvent("getDatefilterTop", l);
            var g = i && i.length ? [].concat(t(i)) : [], m = g.length ? 4 : 5, h = ((u || {}).members || []).slice(0, m);
            this.setData({
                rankCard: [].concat(t(g)),
                spuCard: Object.assign(a({}, u), {
                    members: h
                }),
                isShow: u && u.members && 0 !== u.members.length && (o === s.CATEGORY_NAME.BACKROOM || o === s.CATEGORY_NAME.ROLEPLAY || c === s.CATEGORY_ID.ROLEPLAY || c === s.CATEGORY_ID.BACKROOM)
            }), this._cityChanged = !1;
        },
        onEntry: function(e) {
            var t = e.currentTarget.dataset, r = t.jumpurl, a = t.title, n = t.type, o = {
                "rankcard-header": "b_gc_9z27v6mq_mc",
                "rankcard-body": "b_gc_q05r44qt_mc",
                "channel-header": "b_gc_k3qcowks_mc",
                "channel-body": "b_gc_i6yapbek_mc"
            }[n], i = {
                abtest: this.data.abtest,
                tab_name: this.data.categoryName,
                title: a
            };
            n.includes("channel") && delete i.title, c.default.moduleClick(o, i), console.log("jumpurl: ", r), 
            r && r.length && l.navigateTo({
                url: "" + r
            });
        },
        onAnimationfinish: function(e) {
            var t = e.detail.current;
            this.setData({
                currentSwiper: t
            });
        },
        resolveAfterSeconds: function() {
            return new Promise(function(e) {
                setTimeout(function() {
                    e();
                }, 1e3);
            });
        }
    },
    lifetimes: {
        attached: function() {
            var e = this;
            return u.async(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.next = 2, u.awrap(e.getCityInfo());

                  case 2:
                    return t.next = 4, u.awrap(e.getRoleplayBoard());

                  case 4:
                    return t.next = 6, u.awrap(e.getBackroomBoard());

                  case 6:
                    e._hasAttached = !0, e.handleBoardData();

                  case 8:
                  case "end":
                    return t.stop();
                }
            }, null, null, null, Promise);
        }
    },
    observers: {
        categoryName: function(e) {
            var t = this;
            return u.async(function(r) {
                for (;;) switch (r.prev = r.next) {
                  case 0:
                    if (t._hasAttached || e !== s.CATEGORY_NAME.ROLEPLAY && e !== s.CATEGORY_NAME.BACKROOM) {
                        r.next = 3;
                        break;
                    }
                    return r.next = 3, u.awrap(t.resolveAfterSeconds());

                  case 3:
                    t.handleBoardData(), t.data.isShow && t.setData({
                        isShow: e === s.CATEGORY_NAME.ROLEPLAY || e === s.CATEGORY_NAME.BACKROOM
                    });

                  case 5:
                  case "end":
                    return r.stop();
                }
            }, null, null, null, Promise);
        },
        currentCityId: function() {
            var e = this;
            return u.async(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (e._hasAttached) {
                        t.next = 2;
                        break;
                    }
                    return t.abrupt("return");

                  case 2:
                    return t.next = 4, u.awrap(e.getRoleplayBoard());

                  case 4:
                    return t.next = 6, u.awrap(e.getBackroomBoard());

                  case 6:
                    e._cityChanged = !0;

                  case 7:
                  case "end":
                    return t.stop();
                }
            }, null, null, null, Promise);
        }
    }
});