Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getRoleplayBoard = function(e) {
    return new Promise(function(t, n) {
        r.request({
            url: o.ROLEPLAY_BOARD,
            data: e,
            success: t,
            fail: n
        });
    }).then(function(e) {
        var r = e.data, o = r.code, t = r.msg;
        if (200 === o && t) return t;
        throw Error("请求数据失败");
    }).catch(function(e) {
        console.error("getRoleplayBoard", e);
    });
}, exports.getBackroomBoard = function(e) {
    return new Promise(function(t, n) {
        r.request({
            url: o.BACKROOM_BOARD,
            data: e,
            success: t,
            fail: n
        });
    }).then(function(e) {
        var r = e.data, o = r.code, t = r.msg;
        if (200 === o && t) return t;
        throw Error("请求数据失败");
    }).catch(function(e) {
        console.error("getBackroomBoard", e);
    });
};

var e = function(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}(require("../../../../common/config")), r = require("../../../../npm/@mtfe/weapp-privacy-api/index.js").default, o = {
    ROLEPLAY_BOARD: e.default.gpower_domain + "/api/gpower/home/channel/roleplay",
    BACKROOM_BOARD: e.default.gpower_domain + "/api/gpower/home/channel/backroom"
};