Component({
    externalClasses: [ "ext-class" ],
    options: {
        multipleSlots: !0
    },
    properties: {
        postItem: {
            type: Object,
            value: {}
        },
        detailCard: {
            type: Object,
            value: {}
        },
        usersData: {
            type: Array,
            value: []
        }
    },
    data: {
        users: []
    },
    lifetimes: {},
    methods: {
        stopSwiperTouch: function() {
            return !1;
        },
        onTaps: function() {
            var t = this.properties.postItem;
            this.triggerEvent("onTaps", {
                post: t
            });
        }
    },
    observers: {
        usersData: function(t) {
            var e = t.slice(0, 3);
            this.setData({
                users: e
            });
        }
    }
});