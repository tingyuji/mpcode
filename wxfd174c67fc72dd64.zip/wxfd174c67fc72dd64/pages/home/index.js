function t(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

function e(t, e, i) {
    return e in t ? Object.defineProperty(t, e, {
        value: i,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : t[e] = i, t;
}

var i = function() {
    function t(t, e) {
        var i = [], a = !0, n = !1, r = void 0;
        try {
            for (var o, s = t[Symbol.iterator](); !(a = (o = s.next()).done) && (i.push(o.value), 
            !e || i.length !== e); a = !0) ;
        } catch (t) {
            n = !0, r = t;
        } finally {
            try {
                !a && s.return && s.return();
            } finally {
                if (n) throw r;
            }
        }
        return i;
    }
    return function(e, i) {
        if (Array.isArray(e)) return e;
        if (Symbol.iterator in Object(e)) return t(e, i);
        throw new TypeError("Invalid attempt to destructure non-iterable instance");
    };
}(), a = Object.assign || function(t) {
    for (var e = 1; e < arguments.length; e++) {
        var i = arguments[e];
        for (var a in i) Object.prototype.hasOwnProperty.call(i, a) && (t[a] = i[a]);
    }
    return t;
}, n = require("../../npm/@mtfe/mt-weapp-url/url.js"), r = require("../../common/city"), o = t(require("../../common/config")), s = t(require("../../utils/index")), d = require("../../common/event-constant"), u = require("../../npm/@dp/owl-wxapp/es6/index.js"), c = require("../../npm/@mtfe/perf-mp/dist/cjs/index.js"), l = t(require("../../common/lx")), p = t(require("../../common/login")), f = function(t) {
    if (t && t.__esModule) return t;
    var e = {};
    if (null != t) for (var i in t) Object.prototype.hasOwnProperty.call(t, i) && (e[i] = t[i]);
    return e.default = t, e;
}(require("./api")), h = require("./config/index"), g = require("../../npm/@mtfe/weapp-privacy-api/index.js").default, m = function() {
    return ((arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : []) || []).map(function(t) {
        return a({}, t, {
            checked: !1
        });
    });
}, y = getApp(), T = s.default.EVENT_TYPE, b = s.default.Event;

(0, c.Page)({
    data: {
        city: (0, r.getDefaultCity)(),
        position: {},
        swiperData: [],
        titleBarOpacity: 0,
        filterListObj: {
            districts: [],
            categories: [],
            dates: [],
            sort: m((0, h.getSortTypeArr)()),
            timeslot: m((0, h.getTimeSlotArr)()),
            rules: []
        },
        isFilterFixed: !1,
        isDateTabFixed: !1,
        filterTabInitTop: 0,
        datefilterTabInitTop: 0,
        postList: [],
        pagenum: 1,
        unionid: "",
        openid: "",
        abCardTest: "",
        hasNext: !0,
        fiteredParams: {},
        resetFilterOpt: {},
        loading: !1,
        navHeight: h.HEIGHT.NAVHEIGHT,
        postsInitialized: !1,
        tabactivity: 0,
        categoryIds: "",
        skeleton: {
            showPost: !0
        },
        selectedCategoryTitle: "全部",
        showMinHeight: !1,
        cityHasChanged: !1,
        curIndex: -1
    },
    _cityInit: !1,
    onLoad: function(t) {
        var e = (getApp().globalData || {}).shortLink || {}, i = e.route, a = void 0 === i ? "" : i, n = e.options;
        a.includes(this.route) && n && (this.options = Object.assign({}, t, n));
        var r = getApp().globalData.homeParams;
        r && (this.options = Object.assign(this.options, r)), this.getWxIds(), this.initCity();
    },
    onShow: function() {
        if ("function" == typeof this.getTabBar && this.getTabBar()) {
            var t = this.getTabBar();
            t.refreshSelectedTab && t.refreshSelectedTab();
        }
        b.once(T.HOME_CITYCHANGE, function() {
            return l.default.pageView("c_gc_ehpi86si", {
                cat_id: o.default.catId
            });
        });
    },
    onReady: function() {},
    getWxIds: function() {
        var t = this;
        if (y.globalData.userInfo) {
            var e = y.globalData.userInfo, i = e.openId, a = e.unionId;
            return this.data.openid = i, void (this.data.unionid = a);
        }
        p.default.getWxIds().then(function(e) {
            t.data.openid = e.openId, t.data.unionid = e.unionId;
        });
    },
    initCity: function() {
        var t = this;
        (0, r.getUserInitCity)().then(function(e) {
            var i = e.city;
            t.setCity(i);
        }), b.on(d.GLOBAL_CITY_SELECTED_CHANGE, this.setCity);
    },
    setCity: function(t) {
        this.setData({
            city: t,
            showMinHeight: !1
        }), this.onCityChange(t.cityId);
    },
    onCityChange: function(t) {
        var e = this;
        this._cityInit ? (this.data.categoryIds = "", this.resetFiltered(), this.resetPage()) : (this._cityInit = !0, 
        this.data.categoryIds = this.options.categories && decodeURIComponent(this.options.categories)), 
        this.data.cityHasChanged = !0, y.globalData.ci = t, b.emit(T.HOME_CITYCHANGE, {
            cityid: t
        }), this.getUserLocation().then(function() {
            e.getHeaderData(), Number(e.data.categoryIds);
        }).then(function() {
            e.setData({
                "skeleton.showPost": !1
            });
        });
    },
    getUserLocation: function() {
        var t = this;
        return y.getCityInfo().then(function(e) {
            var i = {
                latitude: e.lat,
                longitude: e.lng
            };
            return t.setData({
                position: i
            }), i;
        }).catch(function() {
            return {};
        });
    },
    getHeaderData: function() {
        var t = this, e = {
            cityid: this.data.city.cityId,
            platform: o.default.platformCode,
            openid: this.data.openid,
            lat: this.data.position.latitude,
            lng: this.data.position.longitude
        };
        return f.getHomeCategory(e).then(function(e) {
            var i = (e.categories || []).findIndex(function(e) {
                return e.categoryId === Number(t.data.categoryIds);
            });
            t.setData({
                swiperData: e.activities,
                "filterListObj.categories": e.categories,
                "filterListObj.districts": e.districts,
                "filterListObj.dates": m(e.dates),
                "filterListObj.rules": m(e.filterRules),
                tabactivity: i >= 0 ? i : 0,
                curIndex: -1
            }, function() {
                return t.initFilterTabTop();
            });
        }).catch(function() {
            t.setData({
                swiperData: []
            });
        });
    },
    initFilterTabTop: function() {
        var t = this;
        0 === this.data.filterTabInitTop && t.createSelectorQuery().select("#filter-tab").boundingClientRect(function(e) {
            e && e.top > 0 && (t.data.filterTabInitTop = parseInt(e.top));
        }).exec();
    },
    getPostListParams: function() {
        var t = this.data.fiteredParams, n = t.categories, r = t.dates, o = t.districts, s = t.rules, d = t.sort, u = t.timeslot;
        return Object.entries({
            sorttype: (d || []).map(function(t) {
                return t.type;
            }).join(","),
            categoryids: (n || []).map(function(t) {
                return t.categoryId;
            }).join(","),
            selectdates: (r || []).map(function(t) {
                return t.time;
            }).join(","),
            timespans: (u || []).map(function(t) {
                return t.type;
            }).join(","),
            regionid: (o || []).map(function(t) {
                return t.regionid;
            }).join(","),
            regiontype: (o || []).map(function(t) {
                return t.regiontype;
            }).join(","),
            fastspell: (s || []).map(function(t) {
                return "fastSpell" === t.filterRule;
            }).length ? 1 : 0
        }).reduce(function(t, n) {
            var r = i(n, 2), o = r[0], s = r[1];
            return a({}, t, s ? e({}, o, s) : {});
        }, {});
    },
    getHomePostList: function() {
        var t = this;
        this.setData({
            loading: !0
        });
        var e = a({
            cityid: this.data.city.cityId,
            platform: o.default.platformCode,
            lat: this.data.position.latitude,
            lng: this.data.position.longitude,
            pagenum: this.data.pagenum,
            unionid: this.data.unionid,
            openid: this.data.openid
        }, this.getPostListParams());
        return f.getHomePostList(e).then(function(e) {
            var i = (e.dataList || []).map(function(t) {
                return {
                    detailCard: t.detailCard,
                    postItem: s.default.getPropetiesFromObj([ "postMaskId", "beginTime", "postTag", "declaration", "fullPeople", "currentPeople", "detailJumpUrl", "payCouponVO", "isFastSpell", "openStatus", "topicType", "sharePostPeopleNumVO" ], t),
                    users: (t.users || []).slice(0, 4)
                };
            }), a = t.data.postList.concat(i);
            t.setData({
                postList: a,
                abCardTest: Number(e.abTest),
                hasNext: e.hasNext,
                loading: !1,
                postsInitialized: !0
            });
        }).catch(function() {
            t.setData({
                loading: !1,
                hasNext: !1
            });
        });
    },
    bannerChange: function(t) {
        var e = t.detail.current;
        l.default.moduleView("b_gc_zb8pfksk_mv", {
            current: e,
            title: this.data.swiperData.length ? this.data.swiperData[e].name : ""
        });
    },
    onClickBanner: function(t) {
        var e = t.currentTarget.dataset, i = e.index, a = e.item;
        g.navigateTo({
            url: a.jumpUrl
        }), l.default.moduleClick("b_gc_zb8pfksk_mc", {
            index: i,
            title: (a || {}).name
        });
    },
    closeFilterPopup: function(t) {
        var e = t.detail.isFixed;
        this.setData({
            titleBarOpacity: e ? 1 : 0
        });
    },
    onConfirmFilterd: function(t) {
        var e = t.detail, i = e.type, a = e.filtered;
        this.data.fiteredParams = a;
        var n = this.data.fiteredParams.categories, r = void 0;
        n && n.length && (r = n[0].categoryName), this.setData({
            titleBarOpacity: i !== h.FILTER_TYPES.CATEGORIES || this.data.cityHasChanged ? 0 : 1,
            selectedCategoryTitle: r,
            showMinHeight: i === h.FILTER_TYPES.CATEGORIES
        }), this.resetPage(), this.getHomePostList(), this.data.cityHasChanged = !1;
    },
    onPostItemTap: function(t) {
        var e = function(t) {
            return y.addError(function(e) {
                return {
                    msg: "首页-拼场广场帖子无法跳转",
                    category: e.JS_ERROR,
                    custom: {
                        error: t
                    }
                };
            });
        }, i = t.currentTarget.dataset.lxextend;
        try {
            var a = t.detail.post.detailJumpUrl;
            g.navigateTo({
                url: a,
                fail: e
            }), l.default.moduleClick("b_gc_kkbesw34_mc", JSON.parse(i));
        } catch (t) {
            e(t);
        }
    },
    onCategoryItemClick: function() {
        var t = this.data.filterTabInitTop - h.HEIGHT.NAVHEIGHT;
        g.pageScrollTo({
            scrollTop: t,
            duration: 300
        });
    },
    openCityPage: function() {
        g.navigateTo({
            url: "/pages/city/index"
        });
    },
    onPullDownRefresh: function() {
        this.resetPage(), this.getHomePostList(), g.stopPullDownRefresh();
    },
    resetPage: function() {
        this.setData({
            pagenum: 1,
            postList: [],
            isFilterFixed: !1,
            isDateTabFixed: !1
        });
    },
    resetFiltered: function() {
        this.data.fiteredParams = {}, this.setData({
            titleBarOpacity: 0
        });
    },
    onReachBottom: function() {
        this.data.pagenum = this.data.pagenum + 1, this.data.hasNext && !this.data.loading && this.getHomePostList();
    },
    onFilterBtnTap: function() {
        this.setData({
            titleBarOpacity: 1
        });
    },
    getDatefilterTop: function(t) {
        this.data.datefilterTabInitTop = t.detail;
    },
    onPageScroll: function(t) {
        var e = t.scrollTop, i = (((this.data.fiteredParams || {}).categories || [ {} ])[0] || {}).categoryName, a = e / h.HEIGHT.NAVHEIGHT;
        this.data.titleBarOpacity >= 1 && a >= 1 || this.setData({
            titleBarOpacity: a
        });
        var n = this.data, r = n.filterTabInitTop, o = n.datefilterTabInitTop, s = r - h.HEIGHT.NAVHEIGHT, d = i === h.CATEGORY_NAME.BACKROOM || i === h.CATEGORY_NAME.ROLEPLAY ? o : s;
        e < s && this.data.isFilterFixed && this.setData({
            isFilterFixed: !1
        }), e >= s && !this.data.isFilterFixed && this.setData({
            isFilterFixed: !0
        }), e < d && this.data.isDateTabFixed && this.setData({
            isDateTabFixed: !1
        }), e >= d && !this.data.isDateTabFixed && this.setData({
            isDateTabFixed: !0
        });
    },
    onShareAppMessage: function() {
        return {
            title: "超多好玩的线下活动，邀你一起来玩乐拼场！",
            path: "/" + this.route + "?" + (0, n.stringify)(a({}, this.options, {
                utm_source: "onsite_play_gwxapp_home_pageshare"
            }))
        };
    },
    onShareTimeline: function() {
        return {
            title: "超多好玩的线下活动，邀你一起来玩乐拼场！",
            query: a({}, this.options, {
                utm_source: "onsite_play_gwxapp_home_pageshare"
            })
        };
    },
    onHide: function() {
        l.default.pageDisappear();
    },
    onUnload: function() {
        l.default.pageDisappear();
    }
}, u.page);