function e(e, t, T) {
    return t in e ? Object.defineProperty(e, t, {
        value: T,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = T, e;
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getDefaultFilter = exports.getTimeSlotArr = exports.getSortTypeArr = exports.CATEGORY_ID = exports.CATEGORY_NAME = exports.FILTER_TYPES = exports.HEIGHT = exports.TIME_SLOT = exports.SORT_TYPE = void 0;

var t = require("../../../common/index"), T = exports.SORT_TYPE = void 0;

!function(e) {
    e[e.DEFAULT = 0] = "DEFAULT", e[e.SMART = 1] = "SMART", e[e.DISTANCE = 2] = "DISTANCE", 
    e[e.RECENT_TIME = 3] = "RECENT_TIME", e[e.MORE_PLAYER = 4] = "MORE_PLAYER", e[e.LESS_PLAYER = 5] = "LESS_PLAYER";
}(T || (exports.SORT_TYPE = T = {}));

var E = exports.TIME_SLOT = void 0;

!function(e) {
    e.DEFAULT = "", e.AM = "tsam", e.PM = "tspm", e.NIGHT = "tsnight";
}(E || (exports.TIME_SLOT = E = {}));

var r = (0, t.getWxNavigatorBarHeight)() - 8, o = 200 - r + 16, R = exports.HEIGHT = void 0;

!function(e) {
    e[e.NAVHEIGHT = r] = "NAVHEIGHT", e[e.TABHEIGHT = 48] = "TABHEIGHT", e[e.FILTERHEIGHT = 156] = "FILTERHEIGHT", 
    e[e.SCROLLHEIGHT = o] = "SCROLLHEIGHT", e[e.RANKCARDHEIGHT = 371] = "RANKCARDHEIGHT", 
    e[e.SPUCARDHEGIHT = 240] = "SPUCARDHEGIHT";
}(R || (exports.HEIGHT = R = {}));

var A = exports.FILTER_TYPES = void 0;

!function(e) {
    e.DISTRICTS = "districts", e.CATEGORIES = "categories", e.SORT = "sort", e.DATES = "dates", 
    e.TIMESLOT = "timeslot", e.RULE = "rules";
}(A || (exports.FILTER_TYPES = A = {}));

var n = exports.CATEGORY_NAME = void 0;

!function(e) {
    e.ROLEPLAY = "剧本杀", e.BACKROOM = "密室";
}(n || (exports.CATEGORY_NAME = n = {}));

var I = exports.CATEGORY_ID = void 0;

!function(e) {
    e[e.ROLEPLAY = 50035] = "ROLEPLAY", e[e.BACKROOM = 2754] = "BACKROOM";
}(I || (exports.CATEGORY_ID = I = {}));

exports.getSortTypeArr = function() {
    return [ {
        type: T.SMART,
        name: "智能排序"
    }, {
        type: T.DISTANCE,
        name: "距离优先"
    }, {
        type: T.RECENT_TIME,
        name: "最近开场时间"
    }, {
        type: T.MORE_PLAYER,
        name: "拼场空位少"
    }, {
        type: T.LESS_PLAYER,
        name: "拼场空位多"
    } ];
}, exports.getTimeSlotArr = function() {
    return [ {
        name: "上午场",
        type: E.AM,
        desc: "06:00-12:00"
    }, {
        name: "下午场",
        type: E.PM,
        desc: "12:00-18:00"
    }, {
        name: "夜间场",
        type: E.NIGHT,
        desc: "18:00-次日06:00"
    } ];
}, exports.getDefaultFilter = function() {
    var t;
    arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
    return t = {}, e(t, A.DISTRICTS, []), e(t, A.CATEGORIES, []), e(t, A.SORT, []), 
    e(t, A.DATES, []), e(t, A.TIMESLOT, []), e(t, A.RULE, []), e(t, "expandType", ""), 
    t;
};