function r(r) {
    return r && r.__esModule ? r : {
        default: r
    };
}

function e(r, e, t) {
    return e in r ? Object.defineProperty(r, e, {
        value: t,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : r[e] = t, r;
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var t = Object.assign || function(r) {
    for (var e = 1; e < arguments.length; e++) {
        var t = arguments[e];
        for (var o in t) Object.prototype.hasOwnProperty.call(t, o) && (r[o] = t[o]);
    }
    return r;
};

exports.getHomeCategory = function(r) {
    return n.default.request({
        url: a.HOME_CATEGORY,
        data: r
    }).then(function(o) {
        var n = o.data;
        if (200 === n.code && n.msg) return getApp().addError(function(o) {
            var u = [ "districts", "dates", "categories" ];
            if (!u.every(function(r) {
                return (n.msg[r] || []).length;
            })) return {
                category: o.AJAX_ERROR,
                msg: "首页类目接口错误，" + u.join("|") + "返回存在空数组",
                custom: u.reduce(function(r, o) {
                    return t({}, r, (n.msg[o] || []).length ? {} : e({}, o, []));
                }, {
                    url: a.HOME_CATEGORY,
                    params: r
                })
            };
        }), n.msg;
        throw new Error("请求数据失败");
    }).catch(function(r) {
        return console.error("getHomeCategory", r), null;
    });
}, exports.getHomePostList = function(r) {
    return n.default.request({
        url: a.POST_LIST,
        data: r
    }).then(function(e) {
        var t = e.data;
        if (200 === t.code && t.msg) {
            if (!((t.msg || {}).dataList || []).length && u !== r.cityid) throw new Error("posts列表为空数组");
            return u = r.cityid, t.msg;
        }
        throw new Error("请求数据失败");
    }).catch(function(e) {
        return getApp().addError(function(t, o) {
            return {
                category: t.AJAX_ERROR,
                level: o.WARN,
                msg: "首页拼场广场请求数据失败",
                custom: {
                    url: a.POST_LIST,
                    params: r,
                    error: e.message
                }
            };
        }), null;
    });
};

var o = r(require("../../common/config")), n = r(require("../../npm/@dzfe/wx-api-promisify/dist/index.js")), a = {
    HOME_CATEGORY: o.default.gpower_domain + "/api/gpower/home/category",
    POST_LIST: o.default.gpower_domain + "/api/gpower/home/post/list"
}, u = 0;