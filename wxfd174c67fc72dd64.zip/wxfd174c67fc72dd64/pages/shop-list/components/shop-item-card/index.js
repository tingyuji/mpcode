var t = require("../../../../npm/@mtfe/weapp-privacy-api/index.js").default;

Component({
    properties: {
        detailCard: {
            type: Object,
            default: null
        },
        idx: {
            type: Number,
            default: 0
        }
    },
    data: {
        scrollContentItemList: [],
        scrollBullet: !1,
        score: null,
        rankIcon: "https://p0.meituan.net/ingee/bcf00cf65af1861a2352611f775b971517117.png",
        swiperAutoPlay: !1
    },
    attached: function() {
        this.setBulletList(), this.handleScore(), this.handleSwiperAutoPlay();
    },
    methods: {
        setBulletList: function() {
            var t = this.properties.detailCard;
            if (t) {
                var e = t.rank, r = t.recommend, a = [ e ? {
                    icon: this.data.rankIcon,
                    msg: e,
                    rank: !0
                } : null, r ? {
                    icon: "",
                    msg: r
                } : null ].filter(Boolean);
                this.setData({
                    scrollContentItemList: a,
                    scrollBullet: a && a.length > 1
                });
            }
        },
        handleScore: function() {
            var t = this.properties.detailCard;
            t && t.starStr && !Number.isNaN(+t.starStr) && this.setData({
                score: 10 * +t.starStr
            });
        },
        onPageJump: function() {
            var e = this.properties.detailCard, r = e && e.jumpUrl;
            r && t.navigateTo({
                url: r
            });
        },
        stopSwiperTouch: function() {
            return !1;
        },
        handleSwiperAutoPlay: function() {
            var t = this, e = this.properties.idx;
            this.evenNumber(e) ? this.setData({
                swiperAutoPlay: !0
            }) : setTimeout(function() {
                t.setData({
                    swiperAutoPlay: !0
                });
            }, 1500);
        },
        evenNumber: function(t) {
            return t % 2 == 0;
        }
    }
});