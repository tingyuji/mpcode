Component({
    properties: {},
    observers: {},
    data: {},
    methods: {
        handleShopSearch: function() {
            this.triggerEvent("handleShopSearch");
        }
    },
    attached: function() {},
    ready: function() {}
});