var e = function(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}(require("../../../../common/lx"));

Component({
    properties: {},
    observers: {},
    data: {},
    methods: {
        onCloseBar: function() {
            this.triggerEvent("closeProcessBar");
        },
        showTip: function() {
            this.triggerEvent("onShowPublishProcessTip");
        },
        handleClickProcessBar: function() {
            e.default.moduleClick("b_gc_3yy8w0y1_mc");
        }
    },
    attached: function() {}
});