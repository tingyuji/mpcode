Component({
    options: {},
    properties: {
        quickSort: {
            type: Array,
            value: []
        },
        expandType: {
            type: String,
            value: ""
        },
        selectedDistrict: {
            type: Object,
            default: null
        },
        selectedSort: {
            type: Object,
            default: null
        },
        selectedQuickSort: {
            type: Object,
            default: null
        }
    },
    data: {
        filterTypes: {
            district: "district",
            sort: "sort"
        }
    },
    attached: function() {},
    methods: {
        onFilterBtnTap: function(t) {
            var e = t.currentTarget.dataset.filter || t.target.dataset.filter;
            this.triggerEvent("onFilterBtnTap", {
                type: e
            });
        },
        onQuickSortBtnTap: function(t) {
            var e = t.currentTarget.dataset.filter;
            this.triggerEvent("onQuickSortBtnTap", {
                quickSortItem: e
            });
        }
    }
});