Component({
    options: {},
    properties: {
        categories: {
            type: Array,
            value: []
        },
        selectedItem: {
            type: Object,
            default: null
        }
    },
    data: {},
    attached: function() {},
    methods: {
        onFilterItemTap: function(t) {
            var e = t.currentTarget;
            if (e) {
                var a = e.dataset && e.dataset.raw;
                this.triggerEvent("onCategoriesItemTab", {
                    item: a
                });
            }
        }
    }
});