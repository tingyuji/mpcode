function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

var r = e(require("../../npm/@dzfe/wx-api-promisify/dist/index.js")), t = e(require("../../common/config")), o = t.default.gpower_domain + "/api/gpower/shop/category", n = t.default.gpower_domain + "/api/gpower/shop/list";

module.exports = {
    getCategories: function(e) {
        return r.default.request({
            url: o,
            method: "GET",
            data: e
        }).then(function(e) {
            var r = e.data;
            if (200 === r.code && r.msg) return r.msg;
            throw new Error("请求数据失败");
        }).catch(function(e) {
            return console.error("getCategories", e), null;
        });
    },
    getShopList: function(e) {
        return r.default.request({
            url: n,
            method: "GET",
            data: e
        }).then(function(e) {
            var r = e.data;
            if (200 === r.code && r.msg) return r.msg;
            throw new Error("请求数据失败");
        }).catch(function(e) {
            return console.error("getShopList", e), null;
        });
    }
};