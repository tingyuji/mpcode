function t(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

function e(t) {
    if (Array.isArray(t)) {
        for (var e = 0, a = Array(t.length); e < t.length; e++) a[e] = t[e];
        return a;
    }
    return Array.from(t);
}

function a(t, e) {
    return o(t) || n(t, e) || r(t, e) || i();
}

function i() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}

function r(t, e) {
    if (t) {
        if ("string" == typeof t) return s(t, e);
        var a = Object.prototype.toString.call(t).slice(8, -1);
        return "Object" === a && t.constructor && (a = t.constructor.name), "Map" === a || "Set" === a ? Array.from(t) : "Arguments" === a || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(a) ? s(t, e) : void 0;
    }
}

function s(t, e) {
    (null == e || e > t.length) && (e = t.length);
    for (var a = 0, i = new Array(e); a < e; a++) i[a] = t[a];
    return i;
}

function n(t, e) {
    var a = null == t ? null : "undefined" != typeof Symbol && t[Symbol.iterator] || t["@@iterator"];
    if (null != a) {
        var i, r, s = [], n = !0, o = !1;
        try {
            for (a = a.call(t); !(n = (i = a.next()).done) && (s.push(i.value), !e || s.length !== e); n = !0) ;
        } catch (t) {
            o = !0, r = t;
        } finally {
            try {
                n || null == a.return || a.return();
            } finally {
                if (o) throw r;
            }
        }
        return s;
    }
}

function o(t) {
    if (Array.isArray(t)) return t;
}

function l(t, e) {
    var a = Object.keys(t);
    if (Object.getOwnPropertySymbols) {
        var i = Object.getOwnPropertySymbols(t);
        e && (i = i.filter(function(e) {
            return Object.getOwnPropertyDescriptor(t, e).enumerable;
        })), a.push.apply(a, i);
    }
    return a;
}

function c(t) {
    for (var e = 1; e < arguments.length; e++) {
        var a = null != arguments[e] ? arguments[e] : {};
        e % 2 ? l(Object(a), !0).forEach(function(e) {
            u(t, e, a[e]);
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(a)) : l(Object(a)).forEach(function(e) {
            Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(a, e));
        });
    }
    return t;
}

function u(t, e, a) {
    return e in t ? Object.defineProperty(t, e, {
        value: a,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : t[e] = a, t;
}

var d = t(require("../../npm/@dzfe/wx-api-promisify/dist/index.js")), f = t(require("../../common/lx")), p = t(require("../../common/config")), h = t(require("./api")), g = t(require("../../utils/index")), y = require("../../npm/regenerator-runtime/runtime.js"), m = require("../../npm/@mtfe/weapp-privacy-api/index.js").default, b = getApp();

Page({
    data: {
        processBarShow: !1,
        tabBarStickyHeight: 0,
        filterPopupTop: g.default.rpx2px(208),
        publishProcessTipTop: g.default.rpx2px(291),
        showPublishProcessTip: !1,
        cityInfo: {},
        categoriesId: null,
        selectedRegionItem: null,
        selectedOrdertype: null,
        defaultCateId: "",
        listReqParams: {
            categories: "",
            subcategories: "",
            regionid: "",
            regiontype: "",
            ordertype: ""
        },
        pagenum: 1,
        filterList: {
            district: [],
            category: [],
            sort: [],
            quickSort: []
        },
        filtered: {
            district: {
                first: null,
                second: null
            },
            category: null,
            expandType: "",
            sort: null,
            quickSort: null
        },
        distActiveKeys: "",
        pageScrollTop: 0,
        shopList: [],
        hasNext: !0,
        listLoading: !1,
        isIOS: !1,
        pinProcessBarKey: "pinProcessBarKey",
        shopListBarType: 0
    },
    onLoad: function() {
        var t = this;
        d.default.getSystemInfo().then(function(e) {
            var a = e.system;
            return t.setData({
                isIOS: a.toLowerCase().indexOf("ios") > -1
            });
        });
        var e = getApp().globalData.shopListCateId || -1;
        this.data.shopListBarType = getApp().globalData.shopListBarType || 0, this.data.defaultCateId = Number(e), 
        this.initData(), this.handlePublishProcessBarShow();
    },
    onShow: function() {
        if ("function" == typeof this.getTabBar && this.getTabBar()) {
            var t = this.getTabBar();
            t.refreshSelectedTab && t.refreshSelectedTab();
        }
        this.handleCityChange(), f.default.pageView("c_gc_konu0u7d", {
            cat_id: p.default.catId,
            custom: {
                abtest: this.data.shopListBarType
            }
        });
    },
    handleCityChange: function() {
        var t = getApp().globalData.ci, e = this.data.cityInfo.cityid;
        t && e && !Number.isNaN(+t) && t !== e && (this.data.cityInfo.cityid = t, this.resetData(), 
        this.getFilters(), this.initShopList());
    },
    initData: function() {
        var t = this;
        return y.async(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return e.next = 2, y.awrap(t.getCityInfo());

              case 2:
                t.getFilters(), t.initShopList();

              case 4:
              case "end":
                return e.stop();
            }
        }, null, null, null, Promise);
    },
    initShopList: function() {
        var t = this;
        return y.async(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return t.data.listReqParams.categories = t.data.defaultCateId, t.data.pagenum = 1, 
                e.next = 4, y.awrap(t.getShopList());

              case 4:
              case "end":
                return e.stop();
            }
        }, null, null, null, Promise);
    },
    resetData: function() {
        var t = this.data;
        t.filterList = {
            district: [],
            category: [],
            sort: [],
            quickSort: []
        }, t.filtered = {
            district: {
                first: null,
                second: null
            },
            category: null,
            expandType: "",
            sort: null,
            quickSort: null
        }, t.listReqParams = {
            categories: "",
            subcategories: "",
            regionid: "",
            regiontype: "",
            ordertype: ""
        }, t.distActiveKeys = "";
    },
    getCityInfo: function() {
        var t = this;
        return function() {
            var e, a;
            return y.async(function(i) {
                for (;;) switch (i.prev = i.next) {
                  case 0:
                    return e = getApp().globalData.ci, i.next = 3, y.awrap(b.getCityInfo());

                  case 3:
                    a = i.sent, Number.isNaN(+e) && (e = a.id), t.data.cityInfo.cityid = e, t.data.cityInfo.lat = a.lat, 
                    t.data.cityInfo.lng = a.lng;

                  case 8:
                  case "end":
                    return i.stop();
                }
            }, null, null, null, Promise);
        }();
    },
    getFilters: function() {
        var t = this;
        return function() {
            var e, a, i, r, s;
            return y.async(function(n) {
                for (;;) switch (n.prev = n.next) {
                  case 0:
                    return e = c({}, t.data.cityInfo), n.next = 3, y.awrap(h.default.getCategories(e));

                  case 3:
                    if (a = n.sent) {
                        n.next = 6;
                        break;
                    }
                    return n.abrupt("return");

                  case 6:
                    i = a.districts, r = a.categories, s = a.orderTypes, i && i.length && (t.data.filterList.district = i), 
                    r && r.length && (t.setQuickSort(r, t.data.defaultCateId), t.data.filterList.category = r), 
                    s && s.length && (t.data.filterList.sort = s), t.setData({
                        filterList: t.data.filterList
                    }), t.initFiltered();

                  case 12:
                  case "end":
                    return n.stop();
                }
            }, null, null, null, Promise);
        }();
    },
    setQuickSort: function(t, e) {
        var a = t.findIndex(function(t) {
            return Number(t.id) === e;
        }), i = t[a = a < 0 ? 0 : a];
        i.children && i.children.length && this.setData({
            filterList: c({}, this.data.filterList, {
                quickSort: i.children
            })
        });
    },
    initFiltered: function() {
        var t = this, e = this.data.filterList.category, a = e.findIndex(function(e) {
            return Number(e.id) === t.data.defaultCateId;
        });
        a = a < 0 ? 0 : a, this.setData({
            filtered: c({}, this.data.filtered, {
                category: e[a]
            })
        });
    },
    setListReqParams: function() {
        var t = this.data.filtered, e = t.category.id, a = "", i = "", r = "", s = "", n = t.district, o = n.first, l = n.second;
        o && l && (i = l.id, r = l.type), s = t.sort && t.sort.id || "", a = t.quickSort && t.quickSort.id || "", 
        this.data.listReqParams = c({}, this.data.listReqParams, {
            categories: e,
            subcategories: a,
            regionid: i,
            regiontype: r,
            ordertype: s
        });
    },
    getShopList: function() {
        var t = this;
        return function() {
            var e, a;
            return y.async(function(i) {
                for (;;) switch (i.prev = i.next) {
                  case 0:
                    return e = c({}, t.data.cityInfo, {}, t.data.listReqParams, {
                        pagenum: t.data.pagenum
                    }), t.setData({
                        listLoading: !0,
                        shopList: []
                    }), i.next = 4, y.awrap(h.default.getShopList(e));

                  case 4:
                    a = i.sent, t.setData({
                        shopList: a && a.dataList || [],
                        hasNext: a && a.hasNext,
                        listLoading: !1
                    });

                  case 6:
                  case "end":
                    return i.stop();
                }
            }, null, null, null, Promise);
        }();
    },
    closeProcessBar: function() {
        f.default.moduleClick("b_gc_fd4zpam8_mc", {}), this.setData({
            processBarShow: !1
        }), m.setStorage({
            key: this.data.pinProcessBarKey,
            data: !0
        });
    },
    onShowPublishProcessTip: function() {
        this.setData({
            showPublishProcessTip: !0
        });
    },
    closePublishProcessTip: function() {
        this.setData({
            showPublishProcessTip: !1
        });
    },
    onCategoriesItemTab: function(t) {
        this.data.filtered.category = t.detail.item, this.data.filtered.quickSort = null, 
        this.data.filterList.quickSort = t.detail.item.children || [], this.setData({
            filtered: this.data.filtered,
            filterList: this.data.filterList
        }), this.setListReqParams(), this.data.pagenum = 1, this.getShopList(), this.closeFilterPopup();
    },
    onDictFilterItemTap: function(t) {
        var e = t.detail, a = e.first, i = e.second;
        this.data.filtered.district = {
            first: a,
            second: i
        }, this.setData({
            distActiveKeys: a.id + "_" + i.id,
            filtered: this.data.filtered
        }), this.setListReqParams(), this.setData({
            pagenum: 1
        }), this.getShopList(), this.closeFilterPopup(), f.default.moduleClick("b_gc_qrlkl1e6_mc", {
            title: i && i.name || ""
        });
    },
    onSortFilterItemTap: function(t) {
        var e = t.currentTarget.dataset.raw, i = t.target.dataset.rawdata || e;
        if (Array.isArray(i)) {
            var r = a(i, 3), s = (r[0], r[1], r[2]);
            this.data.filtered.sort = s, this.setData({
                filtered: this.data.filtered
            }), this.setListReqParams(), this.data.pagenum = 1, this.getShopList(), this.closeFilterPopup(), 
            f.default.moduleClick("b_gc_6c0syz3a_mc", {
                title: s && s.name || ""
            });
        }
    },
    onFilterBtnTap: function(t) {
        var e = t.detail.type, a = this.data.filtered.expandType;
        if (a === e) return this.closeFilterPopup();
        a ? this.setData({
            "filtered.expandType": ""
        }, this.setData.bind(this, {
            "filtered.expandType": e
        })) : this.setData({
            "filtered.expandType": e
        });
    },
    closeFilterPopup: function() {
        this.setData({
            "filtered.expandType": ""
        });
    },
    loadMore: function() {
        var t = this;
        return function() {
            var a, i;
            return y.async(function(r) {
                for (;;) switch (r.prev = r.next) {
                  case 0:
                    if (t.data.hasNext) {
                        r.next = 2;
                        break;
                    }
                    return r.abrupt("return");

                  case 2:
                    return t.setData({
                        pagenum: t.data.pagenum + 1
                    }), t.setListReqParams(), a = c({}, t.data.cityInfo, {}, t.data.listReqParams, {
                        pagenum: t.data.pagenum
                    }), t.setData({
                        listLoading: !0
                    }), r.next = 8, y.awrap(h.default.getShopList(a));

                  case 8:
                    i = r.sent, t.setData({
                        shopList: [].concat(e(t.data.shopList || []), e(i && i.dataList || [])),
                        hasNext: i && i.hasNext,
                        listLoading: !1
                    });

                  case 10:
                  case "end":
                    return r.stop();
                }
            }, null, null, null, Promise);
        }();
    },
    onQuickSortBtnTap: function(t) {
        var e = t.detail.quickSortItem;
        (this.data.filtered.quickSort && this.data.filtered.quickSort.id) === e.id ? this.setData({
            filtered: c({}, this.data.filtered, {
                quickSort: null
            })
        }) : this.setData({
            filtered: c({}, this.data.filtered, {
                quickSort: e
            })
        }), this.setListReqParams(), this.data.pagenum = 1, this.getShopList(), this.closeFilterPopup();
    },
    handleShopSearch: function() {
        m.navigateTo({
            url: "/pages/shop/search/index"
        });
    },
    handlePublishProcessBarShow: function() {
        var t = this;
        m.getStorage({
            key: this.data.pinProcessBarKey,
            success: function(e) {
                e && e.data && t.setData({
                    processBarShow: !1
                });
            },
            fail: function() {
                console.log("resss fail"), t.setData({
                    processBarShow: !0
                });
            }
        });
    },
    onShareAppMessage: function() {}
});