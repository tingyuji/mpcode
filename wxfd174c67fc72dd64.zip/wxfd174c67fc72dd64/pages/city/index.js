var t = function() {
    function t(t, n) {
        var e = [], i = !0, r = !1, a = void 0;
        try {
            for (var o, u = t[Symbol.iterator](); !(i = (o = u.next()).done) && (e.push(o.value), 
            !n || e.length !== n); i = !0) ;
        } catch (t) {
            r = !0, a = t;
        } finally {
            try {
                !i && u.return && u.return();
            } finally {
                if (r) throw a;
            }
        }
        return e;
    }
    return function(n, e) {
        if (Array.isArray(n)) return n;
        if (Symbol.iterator in Object(n)) return t(n, e);
        throw new TypeError("Invalid attempt to destructure non-iterable instance");
    };
}(), n = require("../../common/event-constant"), e = function(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}(require("../../utils/index")), i = require("../../npm/@mtfe/weapp-privacy-api/index.js").default;

Page({
    data: {
        cities: [],
        indexList: [],
        isLocal: !1
    },
    onLoad: function(t) {
        this.data.isLocal = !!t.isLocal, this.processingCity();
    },
    onReady: function() {},
    onShow: function() {},
    processingCity: function() {
        var n = this;
        getApp().getAllCities().then(function(e) {
            var i = e.alphabet2CityVO, r = [], a = Object.entries(i).map(function(n) {
                var e = t(n, 2), i = e[0], a = e[1];
                return r.push(i), {
                    index: i,
                    list: a
                };
            });
            n.setData({
                cities: a,
                indexList: r
            });
        });
    },
    onCityTap: function(t) {
        var r = t.currentTarget.dataset.city;
        this.data.isLocal ? e.default.Event.emit(n.LOCAL_CITY_SELECTED_CHANGE, r) : e.default.Event.emit(n.GLOBAL_CITY_SELECTED_CHANGE, r), 
        i.navigateBack();
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});