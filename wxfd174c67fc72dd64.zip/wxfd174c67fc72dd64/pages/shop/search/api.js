function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getShopSearchResult = function(e) {
    return r.default.request({
        url: t.SHOP_SEARCH,
        data: e
    }).then(function(e) {
        var r = e.data;
        if (200 === r.code) return r;
        throw new Error("商户搜索请求失败");
    }).catch(function(e) {
        return console.error("getShopSearchResult", e), null;
    });
};

var r = e(require("../../../npm/@dzfe/wx-api-promisify/dist/index.js")), t = {
    SHOP_SEARCH: e(require("../../../common/config")).default.gpower_domain + "/api/gpower/shop/search"
};

exports.default = {};