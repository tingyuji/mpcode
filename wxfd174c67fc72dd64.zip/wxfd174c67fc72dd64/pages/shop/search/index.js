function t(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

var e = t(require("../../../utils/index")), n = t(require("../../../common/login")), a = t(require("../../../common/config")), r = t(require("../../../common/lx")), o = t(require("../../../utils/toast")), i = function(t) {
    if (t && t.__esModule) return t;
    var e = {};
    if (null != t) for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n]);
    return e.default = t, e;
}(require("./api")), s = require("../../../npm/regenerator-runtime/runtime.js"), u = require("../../../npm/@mtfe/weapp-privacy-api/index.js").default, c = e.default.debounce, l = getApp();

Page({
    data: {
        token: "",
        openId: "",
        cityid: 10,
        lat: "",
        lng: "",
        keyword: "",
        pageNum: 0,
        hasNext: !0,
        searchResult: [],
        options: {},
        isFocus: !1,
        activityPublishBottom: "calc(env(safe-area-inset-bottom) + 24rpx"
    },
    shopIdList: [],
    loading: !1,
    getSearchResult: function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] && arguments[0], e = this;
        return function() {
            var n, a, r, u, c, l, d, p, h, f, g, m, v, x, y, w;
            return s.async(function(I) {
                for (;;) switch (I.prev = I.next) {
                  case 0:
                    if (n = e.shopIdList, a = e.data, r = a.pageNum, u = a.hasNext, c = a.keyword, l = a.lat, 
                    d = a.lng, p = a.token, h = a.openId, f = a.cityid, g = a.searchResult, !e.loading && u) {
                        I.next = 4;
                        break;
                    }
                    return I.abrupt("return");

                  case 4:
                    return e.loading = !0, I.prev = 5, I.next = 8, s.awrap(i.getShopSearchResult({
                        lat: l,
                        lng: d,
                        token: p,
                        cityid: f,
                        words: c,
                        pagenum: r + 1,
                        openid: h
                    }));

                  case 8:
                    m = I.sent, v = m.errorMessage, x = m.msg, v ? (0, o.default)({
                        message: v
                    }) : x && (y = [], (x.dataList || []).forEach(function(t) {
                        n.includes(t.shopId) || (n.push(t.shopId), y.push(t));
                    }), w = {
                        hasNext: x.hasNext,
                        pageNum: r + 1,
                        searchResult: t ? y : g.concat(y)
                    }, e.setData(w)), e.loading = !1, I.next = 19;
                    break;

                  case 15:
                    I.prev = 15, I.t0 = I.catch(5), e.loading = !1, console.error(I.t0);

                  case 19:
                  case "end":
                    return I.stop();
                }
            }, null, null, [ [ 5, 15 ] ], Promise);
        }();
    },
    onInput: c(function(t) {
        var e = t[0].detail.value;
        e && e === this.data.keyword || (this.shopIdList.length = 0, this.setData({
            keyword: e,
            hasNext: !0,
            pageNum: 0,
            searchResult: []
        }), 0 !== e.length && this.getSearchResult(!0));
    }, 200),
    onSearchResultTap: function(t) {
        var e = t.currentTarget.dataset.url;
        e && u.navigateTo({
            url: e
        });
    },
    onFocus: function(t) {
        var e = t.detail.height;
        this.setData({
            activityPublishBottom: e + "px",
            isFocus: !0
        });
    },
    onBlur: function() {
        this.setData({
            activityPublishBottom: "calc(env(safe-area-inset-bottom) + 24rpx)",
            isFocus: !1
        });
    },
    setLocation: function() {
        var t = this;
        return function() {
            var e, n, a, r, o;
            return s.async(function(i) {
                for (;;) switch (i.prev = i.next) {
                  case 0:
                    return i.next = 2, s.awrap(l.getCityInfo());

                  case 2:
                    if (i.t0 = i.sent, i.t0) {
                        i.next = 5;
                        break;
                    }
                    i.t0 = {};

                  case 5:
                    e = i.t0, n = e.lat, a = e.lng, r = e.id, o = l.globalData && l.globalData.ci || r, 
                    t.setData({
                        lat: n,
                        lng: a,
                        cityid: o
                    });

                  case 11:
                  case "end":
                    return i.stop();
                }
            }, null, null, null, Promise);
        }();
    },
    forceLogin: function() {
        var t = this;
        return s.async(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return e.abrupt("return", n.default.mtDefaultLogin({
                    isBind: !0
                }).then(function(e) {
                    t.data.token = e.token || e.userInfo && e.userInfo.token || "", t.data.openId = e.openId || e.userInfo && e.userInfo.openId || "";
                }));

              case 1:
              case "end":
                return e.stop();
            }
        }, null, null, null, Promise);
    },
    init: function() {
        var t = this;
        return s.async(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return e.next = 2, s.awrap(Promise.all([ t.setLocation(), t.forceLogin() ]));

              case 2:
              case "end":
                return e.stop();
            }
        }, null, null, null, Promise);
    },
    onLoad: function(t) {
        var e = this;
        return s.async(function(n) {
            for (;;) switch (n.prev = n.next) {
              case 0:
                return e.data.options = t, n.next = 3, s.awrap(e.init());

              case 3:
              case "end":
                return n.stop();
            }
        }, null, null, null, Promise);
    },
    onReady: function() {},
    onShow: function() {
        var t = this.data.options.shopid;
        r.default.pageView("c_gc_dahhtinu", {
            poi_id: t || -9999,
            cat_id: a.default.catId
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onReachBottom: function() {
        this.getSearchResult();
    },
    onShareAppMessage: function() {}
});