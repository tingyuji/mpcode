var t = function(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}(require("../../../common/config")), e = void 0;

e = "test" === t.default.env ? "dp" === t.default.platform ? "https://g.51ping.com" : "http://test-g.meituan.com" : "dp" === t.default.platform ? "https://g.dianping.com" : "https://g.meituan.com", 
Page({
    data: {
        isReady: !1,
        url: "",
        urlPath: "/csr/biz-common-gpower/play-group-new-edit/index.html",
        urlDomain: e
    },
    onLoad: function(e) {
        var a = e.weburl;
        if (a) {
            delete e.weburl;
            var d = "";
            Object.keys(e).forEach(function(t) {
                d += t + "=" + e[t] + "&";
            });
            var i = t.default.swimlane || "3792-rwtjd";
            d += "_swimlane_=" + i;
            var o = a + "?" + decodeURIComponent(d);
            this.setData({
                url: o,
                isReady: !0
            });
        }
    },
    acceptWebviewMsg: function(t) {
        if (t.detail) {
            var e = getCurrentPages();
            if (e.length > 1) {
                var a = e[e.length - 2], d = {
                    productid: t.detail.data[0].productId || "",
                    productitemid: t.detail.data[0].itemId || "",
                    skudate: t.detail.data[0].skuDate || ""
                };
                a.getProductInfo(d);
            }
        }
        console.log(t.detail, "webview-page");
    }
});