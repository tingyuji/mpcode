function t(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

function e(t, e) {
    var o = Object.keys(t);
    if (Object.getOwnPropertySymbols) {
        var a = Object.getOwnPropertySymbols(t);
        e && (a = a.filter(function(e) {
            return Object.getOwnPropertyDescriptor(t, e).enumerable;
        })), o.push.apply(o, a);
    }
    return o;
}

function o(t) {
    for (var o = 1; o < arguments.length; o++) {
        var r = null != arguments[o] ? arguments[o] : {};
        o % 2 ? e(Object(r), !0).forEach(function(e) {
            a(t, e, r[e]);
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(r)) : e(Object(r)).forEach(function(e) {
            Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(r, e));
        });
    }
    return t;
}

function a(t, e, o) {
    return e in t ? Object.defineProperty(t, e, {
        value: o,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : t[e] = o, t;
}

function r(t) {
    var e = !1, o = !1;
    return t <= v && (e = !0), t >= b && (o = !0), {
        disableRomve: e,
        disableAdd: o
    };
}

var n = require("../../../npm/@mtfe/mt-weapp-url/url.js"), i = require("../../../common/global-info"), s = require("./api"), u = require("../../../common/config"), c = t(u), d = t(require("../../../common/login")), l = t(require("../../../common/lx")), p = t(require("../../../api/index")), f = t(require("../../../utils/index")), h = require("../../../npm/regenerator-runtime/runtime.js"), g = require("../../../npm/@mtfe/weapp-privacy-api/index.js").default, m = getApp(), b = 10, v = 2;

Page({
    data: {
        cityId: 10,
        lat: "",
        lng: "",
        platform: c.default.platform,
        shopId: "",
        gourpInvitation: "",
        wxName: "",
        shopInfo: {},
        topicType: 0,
        productPreviewUrl: "",
        groupLocation: {},
        groupTime: {
            timespan: null
        },
        groupProduct: {},
        isFromOrder: !1,
        defaultDeclaration: "请填写您的拼场邀请语",
        groupDeclaration: "",
        groupDeclarationLen: 0,
        groupHeadCount: 2,
        disableAddGroupHead: !1,
        disableRemoveGroupHead: !0,
        showicon: !1,
        groupGender: "男女不限",
        isUserAllow: !1,
        isSuccess: 0,
        wxContact: "",
        showDatePicker: !1,
        genderList: [ "男女不限", "偏好男生", "偏好女生" ],
        fetchLocEnd: !1,
        removeIconImg: "wx" === c.default.platform ? "./assets/remove-wx.png" : "./assets/remove.png",
        addIconImg: "wx" === c.default.platform ? "./assets/add-wx.png" : "./assets/add.png",
        protocolSeletedIconImg: "wx" === c.default.platform ? "./assets/selected.png" : "dp" === c.default.platform ? "./assets/selected-dp.png" : "./assets/selected-mt.png",
        versionControl: {},
        token: "",
        couponText: "",
        cornerMark: ""
    },
    onLoad: function(t) {
        var e = this, o = {};
        t.shopid && (t.productinfo && (o = JSON.parse(decodeURIComponent(t.productinfo)) || {}), 
        this.fetchPublishPatter({
            shopid: t.shopid,
            platform: c.default.platformCode,
            uacode: c.default.uaCode
        }), this.getProductInfo({
            productid: t.productid || o.productId || "",
            productitemid: t.productitemid || o.itemId || "",
            skudate: t.skudate || o.skuDate || ""
        })), t.cityid ? (this.data.fetchLocEnd = !0, this.data.cityId = t.cityid, this.data.lat = t.lat, 
        this.data.lng = t.lng, this.getCornerMark()) : m.getCityInfo().then(function(t) {
            e.data.fetchLocEnd = !0, e.data.cityId = t.id, e.data.lat = t.lat, e.data.lng = t.lng, 
            e.getCornerMark();
        }), this.setData({
            shopId: t.shopid,
            isFromOrder: !(!t.origin || "orderdetail" !== t.origin),
            groupProduct: o
        }), l.default.pageView("c_gc_u1pcxwc9", {
            poi_id: this.data.shopId || "-9999",
            cat_id: c.default.catId
        }), (0, i.getVersionControl)().then(function(t) {
            e.setData({
                versionControl: t
            });
        }), "dp" === u.platform && g.hideShareMenu();
    },
    onReady: function() {
        console.log("当前小程序版本号为：", "0.8.2");
    },
    onShow: function() {
        this.data.shopId || l.default.moduleView("b_gc_latcgmt3_mv"), "wx" === c.default.platform && this.getDiversionIcon(), 
        this.getUserInfo();
    },
    onHide: function() {},
    onUnload: function() {},
    clearData: function() {
        this.setData({
            groupTime: "",
            groupProduct: {},
            couponText: ""
        });
    },
    getUserInfo: function() {
        var t = this;
        d.default.mtDefaultLogin({
            isBind: !1
        }).then(function(e) {
            var o = e.token || e.userInfo && e.userInfo.token || "", a = {
                platform: "dp" === t.data.platform ? 1 : 2,
                token: o,
                dealtype: 1
            };
            t.getDealStatus(a);
        });
    },
    getDealStatus: function(t) {
        var e = this;
        p.default.searchDeal(t).then(function(t) {
            e.setData({
                isUserAllow: 0 !== t.showDealHook
            });
        }).catch(function(t) {
            console.log(t, "dealFail");
        });
    },
    logDealStatus: function(t) {
        var e = this, o = {
            platform: "dp" === this.data.platform ? 1 : 2,
            token: t,
            dealtype: 1
        };
        p.default.recordLog(o).then(function(t) {
            e.setData({
                isSuccess: t.isSuccess
            });
        }).catch(function(t) {
            console.log(t, "LogFail");
        });
    },
    getProductInfo: function(t) {
        var e = this;
        return (0, s.getProductInfo)(t).then(function(t) {
            t && e.setData({
                groupProduct: t,
                couponText: t.attrs && t.attrs.couponText || ""
            });
        });
    },
    fetchPublishPatter: function(t) {
        var e = this, o = t;
        return this.clearData(), o || (o = {
            shopid: this.data.groupLocation.shopId,
            platform: c.default.platformCode,
            uacode: c.default.uaCode
        }), (0, s.getPublishPatter)(o).then(function(t) {
            t && (e.setData({
                shopInfo: t.shopInfo,
                topicType: t.topicType,
                productPreviewUrl: t.jumpUrl,
                defaultDeclaration: t.defaultDeclaration
            }), 1 === t.topictype ? l.default.moduleView("b_gc_avbjv1wn_mv") : 3 === t.topicType ? l.default.moduleView("b_gc_avbjv1wn_mv") : (l.default.moduleView("b_gc_1bjprhup_mv"), 
            l.default.moduleView("b_gc_s27p1d42_mv")));
        });
    },
    selectGroupLocation: function() {
        var t = this.data, e = t.cityId, o = t.lat, a = t.lng;
        l.default.moduleClick("b_gc_latcgmt3_mc"), g.navigateTo({
            url: "/pages/publish/shop-search/index?cityid=" + e + "&lat=" + o + "&lng=" + a,
            success: function() {
                console.log("open success: /pages/publish/shop-search/index");
            },
            fail: function(t) {
                getApp().addError(function() {
                    return {
                        msg: "选择地点跳转失败",
                        custom: {
                            error: t
                        }
                    };
                });
            },
            complete: function() {}
        });
    },
    selectGroupProduct: function() {
        this.data.isFromOrder || (1 === c.default.platformCode ? this.data.shopInfo.dpShopId : this.data.shopInfo.mtShopId, 
        l.default.moduleClick("b_gc_avbjv1wn_mc"), g.navigateTo({
            url: this.data.productPreviewUrl,
            success: function() {
                console.log("open success: /pages/publish/product-webview/index");
            }
        }));
    },
    openDatePicker: function() {
        l.default.moduleClick("b_gc_1bjprhup_mc"), this.setData({
            showDatePicker: !0
        });
    },
    closeDatePicker: function() {
        this.setData({
            showDatePicker: !1
        });
    },
    selectTime: function(t) {
        var e = t.detail;
        this.setData({
            showDatePicker: !1,
            groupTime: e || this.data.groupTime
        });
    },
    reportDeclarationLxClick: function() {
        l.default.moduleClick("b_gc_pjf78213_mc");
    },
    bindDeclaration: function(t) {
        var e = t.detail.value;
        this.setData({
            groupDeclarationLen: e.length,
            groupDeclaration: e
        });
    },
    reportGroupCountLxClick: function() {
        l.default.moduleClick("b_gc_s27p1d42_mc");
    },
    removeGroupHeadCount: function() {
        var t = this.data.groupHeadCount - 1, e = r(t), o = e.disableRomve, a = e.disableAdd;
        this.setData({
            groupHeadCount: o ? v : t,
            disableRemoveGroupHead: o,
            disableAddGroupHead: a
        });
    },
    addGroupHeadCount: function() {
        var t = this.data.groupHeadCount + 1, e = r(t), o = e.disableRomve, a = e.disableAdd;
        this.setData({
            groupHeadCount: a ? b : t,
            disableRemoveGroupHead: o,
            disableAddGroupHead: a
        });
    },
    validateGroupHeadCount: function(t) {
        var e = Number(t.detail.value.replace(/\D/g, "")), o = e, a = "";
        e > b && (o = b, a = "活动最大人数包含发起人为" + b + "人"), e < v && (o = v, a = "活动最低人数包含发起人为" + v + "人"), 
        a && g.showToast({
            title: a,
            icon: "none"
        });
        var n = r(o), i = n.disableRomve, s = n.disableAdd;
        this.setData({
            groupHeadCount: o,
            disableRemoveGroupHead: i,
            disableAddGroupHead: s
        });
    },
    changeGender: function(t) {
        l.default.moduleClick("b_gc_tayk9zi8_mc");
        var e = t.currentTarget.dataset.gender;
        this.setData({
            groupGender: e
        });
    },
    reportContactLxClick: function() {
        l.default.moduleClick("b_gc_5meau9ry_mc");
    },
    bindWxContact: function(t) {
        var e = t.detail.value;
        e.length && e.length > 20 && (e = e.slice(0, 20)), this.setData({
            wxContact: e
        });
    },
    createPublish: f.default.throttle(function() {
        var t = this;
        if (this.data.isUserAllow) {
            var e = 1 === c.default.platformCode ? this.data.shopInfo.dpShopId : this.data.shopInfo.mtShopId;
            l.default.moduleClick("b_gc_v3c1z2mf_mc", {
                poi_id: e
            });
            var o = {
                platform: c.default.platformCode,
                uacode: c.default.uaCode,
                topictype: this.data.topicType,
                dpshopid: this.data.shopInfo.dpShopId,
                mtshopid: this.data.shopInfo.mtShopId,
                declaration: this.data.groupDeclaration,
                headcount: this.data.groupHeadCount,
                genderlimit: this.data.groupGender,
                wechatid: this.data.wxContact,
                token: ""
            };
            2 === this.data.topicType && (o.postbegintime = this.data.groupTime.timespan), 2 !== this.data.topicType && (o.productid = this.data.groupProduct.productId, 
            o.productitemid = this.data.groupProduct.itemId, o.postbegintime = this.data.groupProduct.arriveTime, 
            o.postendtime = this.data.groupProduct.endTime, o.headcount = this.data.groupProduct.expectNum), 
            d.default.mtDefaultLogin({
                isBind: !0
            }).then(function(e) {
                var a, r, n;
                return h.async(function(t) {
                    for (var i = this; ;) switch (t.prev = t.next) {
                      case 0:
                        if (!(a = e.token || e.userInfo && e.userInfo.token || "")) {
                            t.next = 27;
                            break;
                        }
                        return this.data.token = a, r = e.uuid, t.next = 6, h.awrap(m.finger());

                      case 6:
                        if (n = t.sent, r || (r = this.getUUID()), this.data.fetchLocEnd) {
                            t.next = 21;
                            break;
                        }
                        if ("dp" !== c.default.platform) {
                            t.next = 14;
                            break;
                        }
                        this.data.cityId = e.userInfo && e.userInfo.cityID, console.log("[DP]get cityid by user.userInfo.cityID"), 
                        t.next = 21;
                        break;

                      case 14:
                        return t.next = 16, h.awrap(m.getCityInfo());

                      case 16:
                        if (t.t0 = t.sent, t.t0) {
                            t.next = 19;
                            break;
                        }
                        t.t0 = {};

                      case 19:
                        this.data.cityId = t.t0.id, console.log("request loc info in create api", this.data.cityId);

                      case 21:
                        o.token = a || o.token, o.uuid = r, o.fp = n, o.price = this.data.groupProduct.price, 
                        o.cityid = this.data.cityId, (0, s.createPublishShare)(o).then(function(t) {
                            var e;
                            return h.async(function(r) {
                                for (;;) switch (r.prev = r.next) {
                                  case 0:
                                    if (!t.errorMessage) {
                                        r.next = 4;
                                        break;
                                    }
                                    return g.showToast({
                                        title: t.errorMessage,
                                        icon: "none",
                                        duration: 2e3
                                    }), t.code && [ 401, 500 ].includes(t.code) && getApp().addError(function(e, a) {
                                        return {
                                            category: e.AJAX_ERROR,
                                            level: a.ERROR,
                                            msg: "创建拼场接口请求失败",
                                            custom: {
                                                params: o,
                                                errorMessage: t.errorMessage
                                            }
                                        };
                                    }), r.abrupt("return");

                                  case 4:
                                    if (200 !== t.code || !t.msg) {
                                        r.next = 10;
                                        break;
                                    }
                                    if (e = t.msg, this.logDealStatus(a), "dp" !== c.default.platform || this.checkDpVersionSupportMMP()) {
                                        r.next = 9;
                                        break;
                                    }
                                    return r.abrupt("return", g.openLink({
                                        url: e.jumpUrl,
                                        success: function() {}
                                    }));

                                  case 9:
                                    setTimeout(function() {
                                        var t = e || {}, o = t.jumpUrl, a = t.mmpJumpUrl;
                                        g.redirectTo({
                                            url: "dp" !== c.default.platform ? o : a,
                                            success: function() {
                                                console.log("open share page: " + o);
                                            },
                                            fail: function(t) {
                                                getApp().addError(function() {
                                                    return {
                                                        msg: "发布成功后跳转分享引导页失败",
                                                        custom: {
                                                            error: t,
                                                            url: "dp" !== c.default.platform ? o : a
                                                        }
                                                    };
                                                });
                                            }
                                        });
                                    }, 300);

                                  case 10:
                                  case "end":
                                    return r.stop();
                                }
                            }, null, i, null, Promise);
                        }).catch(function(t) {
                            getApp().addError(function() {
                                return {
                                    msg: "发布拼场失败",
                                    custom: {
                                        error: t.message,
                                        params: o
                                    }
                                };
                            });
                        });

                      case 27:
                      case "end":
                        return t.stop();
                    }
                }, null, t, null, Promise);
            });
        }
    }, 2500),
    checkDpVersionSupportMMP: function() {
        var t = g.getSystemInfoSync().appVersion;
        return f.default.compareVersion(t, "10.54.0") >= 0;
    },
    getUUID: function() {
        return "wx" === c.default.platform ? l.default.get("lxcuid") : (g.getSystemInfoSync() || {}).uuid;
    },
    changeProtocolStatus: function() {
        this.setData({
            isUserAllow: !this.data.isUserAllow
        });
    },
    goToUserProtocol: function() {
        g.navigateTo({
            url: "/pages/protocol/index",
            success: function() {
                console.log("open success: /pages/protocol/index");
            },
            fail: function() {},
            complete: function() {}
        });
    },
    getDiversionIcon: function() {
        f.default.judgeScene(m.globalData.sceneValue) && !m.globalData.isShowIcon && (this.setData({
            showicon: !0
        }), m.globalData.isShowIcon = !0);
    },
    onShareAppMessage: function() {
        return {
            title: "超多好玩的线下活动，邀你一起来玩乐拼场！",
            path: "/" + this.route + "?" + (0, n.stringify)(o({}, this.options, {
                utm_source: "onsite_play_gwxapp_publish_pageshare"
            })),
            type: 1,
            appId: "gh_c509e170d6df"
        };
    },
    getCornerMark: function() {
        var t = this, e = "dp" === this.data.platform;
        return (0, s.getCornerMark)({
            platform: e ? 1 : 2,
            cityid: this.data.cityId || (e ? 10 : 1)
        }).then(function(e) {
            return t.setData({
                cornerMark: e
            });
        });
    }
});