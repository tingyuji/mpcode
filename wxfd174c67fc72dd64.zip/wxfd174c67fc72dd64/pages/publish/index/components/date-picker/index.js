var t = Object.assign || function(t) {
    for (var e = 1; e < arguments.length; e++) {
        var r = arguments[e];
        for (var a in r) Object.prototype.hasOwnProperty.call(r, a) && (t[a] = r[a]);
    }
    return t;
}, e = function() {
    function t(t, e) {
        var r = [], a = !0, n = !1, i = void 0;
        try {
            for (var s, u = t[Symbol.iterator](); !(a = (s = u.next()).done) && (r.push(s.value), 
            !e || r.length !== e); a = !0) ;
        } catch (t) {
            n = !0, i = t;
        } finally {
            try {
                !a && u.return && u.return();
            } finally {
                if (n) throw i;
            }
        }
        return r;
    }
    return function(e, r) {
        if (Array.isArray(e)) return e;
        if (Symbol.iterator in Object(e)) return t(e, r);
        throw new TypeError("Invalid attempt to destructure non-iterable instance");
    };
}(), r = require("../../../../../utils/date"), a = function(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}(require("../../../../../common/config")), n = (0, r.getDateList)(), i = n.dates, s = n.hours, u = n.mins, o = {
    data: {}
};

Component({
    properties: {
        value: {
            optionalTypes: [ null, Number ],
            type: null
        }
    },
    data: {
        platform: a.default.platform,
        dates: i,
        currentDayRestHours: s,
        currentHourRestMins: u,
        curHours: s,
        curMins: u,
        initValue: [ 0, 0, 0 ],
        values: [ 0, 0, 0 ]
    },
    selectResult: {},
    methods: {
        onChange: function(t) {
            var e = this, r = this.data, a = r.values, n = r.currentDayRestHours, i = r.currentHourRestMins, o = t.detail.value, l = {}, c = !1;
            a[0] === o[0] || 0 !== o[0] && 0 !== a[0] || (0 === o[0] ? (c = !0, l.curHours = n, 
            o[1] = a[1] - s.length + n.length, o[1] < 0 && (o[1] = 0), this.setData({
                initValue: o
            })) : 0 === a[0] && (l.curHours = s, o[1] = a[1] - n.length + s.length)), a[0] === o[0] && a[1] === o[1] || (0 === o[0] && 0 === o[1] ? (c = !0, 
            l.curMins = i, o[2] = a[2] - u.length + i.length, o[2] < 0 && (o[2] = 0), this.setData({
                initValue: o
            })) : 0 === a[0] && 0 === a[1] && (l.curMins = u, o[2] = a[2] - i.length + u.length)), 
            c || setTimeout(function() {
                e.setData({
                    initValue: o
                });
            }, 50), l.values = o, this.setData(l), this.setValue();
        },
        onClose: function() {
            this.triggerEvent("close");
        },
        onConfirm: function() {
            var t = this;
            this.setValue(), setTimeout(function() {
                t.triggerEvent("selected", t.selectResult);
            }, 100);
        },
        setValue: function() {
            var t = this.data.values || this.properties.value, r = this.data, a = r.curHours, n = r.curMins, s = e(t, 3), u = s[0], l = s[1], c = s[2], h = i[u].dateTimespanStr + " " + a[l].hourTimespanStr + ":" + n[c].minTimespanStr + ":00", d = new Date(h).getTime(), f = i[u].dateStr + " " + a[l].hourStr + ":" + n[c].minStr;
            this.selectResult = {
                timespan: d,
                timeText: f,
                selectedValues: t
            }, o.initValue = t;
        }
    },
    lifetimes: {
        attached: function() {
            var t = this.properties.value, e = void 0 === t || null === t;
            if (e) {
                var a = new Date(e ? Date.now() : t), n = a.getFullYear(), l = a.getMonth() + 1, c = a.getDate(), h = a.getHours(), d = a.getMinutes();
                console.log(n, l, c, h, d);
                var f = function() {
                    (0, r.isLastDayOfMonth)(t) ? (c = 1, l >= 12 ? (l = 1, n++) : l++) : c++;
                }, g = function() {
                    h >= 23 ? (h = 0, f()) : h++;
                };
                e && function() {
                    var t = d + 15;
                    60 == (d = t % 15 >= 8 ? 15 * (Math.floor(t % 60 / 15) + 1) : 15 * Math.floor(t % 60 / 15)) && (d = 0, 
                    g()), t >= 60 && g();
                }(), this.data.currentDayRestHours = s.slice(s.findIndex(function(t) {
                    return t.hourStr === h.toString().padStart(2, "0");
                })), this.data.currentHourRestMins = u.slice(u.findIndex(function(t) {
                    return t.minStr === d.toString().padStart(2, "0");
                })), this.setData({
                    curHours: this.data.currentDayRestHours,
                    curMins: this.data.currentHourRestMins
                });
                for (var p = n + "/" + l.toString().padStart(2, "0") + "/" + c.toString().padStart(2, "0"), v = ("" + h).padStart(2, "0"), m = ("" + d).padStart(2, "0"), S = [], y = 0; y < i.length; y++) p === i[y].dateTimespanStr && (S[0] = y);
                for (var D = 0; D < this.data.curHours.length; D++) v === this.data.curHours[D].hourTimespanStr && (S[1] = D);
                for (var M = 0; M < this.data.curMins.length; M++) m === this.data.curMins[M].minTimespanStr && (S[2] = M);
                console.log(p, v, m), this.setData({
                    values: S,
                    initValue: S
                }), this.setValue();
            } else this.setData(o.data);
        },
        detached: function() {
            o.data = t({}, this.data);
        }
    }
});