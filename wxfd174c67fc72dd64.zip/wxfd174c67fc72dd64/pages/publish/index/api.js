function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getCornerMark = void 0, exports.getPublishPatter = function(e) {
    return new Promise(function(r, t) {
        n.request({
            url: o.PUBLISH_PATTER,
            data: e,
            success: function(e) {
                r(e);
            },
            fail: function(e) {
                t(e);
            }
        });
    }).then(function(e) {
        var r = e.data;
        if (200 === r.code && r.msg) return r.msg;
        throw new Error("请求数据失败");
    }).catch(function(r) {
        return console.error("getPublishPatter", r), getApp().addError(function(r, t) {
            return {
                category: r.AJAX_ERROR,
                level: t.ERROR,
                msg: "模式识别接口请求失败",
                custom: {
                    url: o.PUBLISH_PATTER,
                    params: e
                }
            };
        }), null;
    });
}, exports.getProductInfo = function(e) {
    return new Promise(function(r, t) {
        n.request({
            url: o.PRODUCT_INFO,
            data: e,
            success: function(e) {
                r(e);
            },
            fail: function(e) {
                t(e);
            }
        });
    }).then(function(e) {
        var r = e.data;
        if (200 === r.code && r.msg) return r.msg;
        throw new Error("请求数据失败");
    }).catch(function(e) {
        return console.error("getProductInfo", e), null;
    });
}, exports.createPublishShare = function(e) {
    return new Promise(function(r, t) {
        n.request({
            url: o.CREATE_PUBLISH,
            data: e,
            method: "POST",
            success: function(e) {
                r(e);
            },
            fail: function(e) {
                t(e);
            }
        });
    }).then(function(e) {
        return e.data;
    }).catch(function(r) {
        return console.error("createPublishShare", r), getApp().addError(function(r, t) {
            return {
                category: r.AJAX_ERROR,
                level: t.ERROR,
                msg: "创建拼场接口请求失败",
                custom: {
                    url: o.CREATE_PUBLISH,
                    params: e
                }
            };
        }), null;
    });
};

var r = e(require("../../../npm/@dzfe/wx-api-promisify/dist/index.js")), t = e(require("../../../common/config")), n = require("../../../npm/@mtfe/weapp-privacy-api/index.js").default, o = {
    PUBLISH_PATTER: t.default.dp_domain + "/api/joy/sharerelation/pattern/recognition",
    CREATE_PUBLISH: t.default.gpower_domain + "/api/gpower/post/create",
    PRODUCT_INFO: t.default.dp_domain + "/api/joy/sharerelation/publish/poolinfo",
    CORNER_MARK: t.default.gpower_domain + "/api/gpower/helpactivity/corner/mark"
};

exports.getCornerMark = function(e) {
    return r.default.request({
        url: o.CORNER_MARK,
        data: e
    }).then(function(e) {
        var r = e.data, t = r.success, n = r.msg;
        return t ? n || "" : "";
    }).catch(function() {
        return "";
    });
};