Component({
    properties: {
        shopList: {
            type: Array,
            default: []
        },
        keyword: {
            type: String,
            default: ""
        }
    },
    data: {},
    methods: {
        clickShop: function(t) {
            var e = t.currentTarget.dataset.info;
            this.triggerEvent("selectedshop", e);
        }
    }
});