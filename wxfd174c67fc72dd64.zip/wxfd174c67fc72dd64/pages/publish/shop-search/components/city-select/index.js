Component({
    properties: {
        naviBars: {
            type: Object,
            value: []
        }
    },
    data: {
        activeIndex: -1
    },
    methods: {
        selectCity: function(t) {
            this.setData({
                activeIndex: t.currentTarget.dataset.index
            }), this.triggerEvent("closeSelectCity", {
                show: !1,
                data: t.currentTarget.dataset.info
            });
        },
        closeSelect: function() {
            this.triggerEvent("closeSelectCity", {
                show: !1,
                data: null
            });
        }
    }
});