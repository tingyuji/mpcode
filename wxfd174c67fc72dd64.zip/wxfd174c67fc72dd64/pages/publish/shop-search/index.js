function t(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

var a = t(require("./api.js")), i = t(require("../../../common/lx")), e = t(require("../../../utils/index")), s = t(require("../../../common/config")), n = require("../../../npm/@mtfe/weapp-privacy-api/index.js").default, o = getApp();

Page({
    data: {
        cityId: 10,
        cityInfo: {},
        lat: "",
        lng: "",
        cityParams: {},
        shopParams: {},
        cityName: "上海",
        naviBars: [],
        showCity: !1,
        shopList: null,
        isLastPage: !1,
        shopId: "",
        keyword: "",
        showEmpty: !1
    },
    bindKeyInput: e.default.debounce(function(t) {
        if (t[0].detail.value) {
            var a = t[0].detail.value;
            this.setData({
                shopParams: {
                    cityId: this.data.cityId,
                    platformType: 1,
                    pageno: 0,
                    limit: 20,
                    lng: this.data.lng,
                    lat: this.data.lat,
                    source: 14,
                    sort: 1,
                    screening: a
                },
                keyword: a,
                shopList: null,
                showEmpty: !0
            }), this.getShopInfo(this.data.shopParams);
        } else this.setData({
            shopList: null
        });
    }, 500),
    initParam: function(t) {
        var a = this;
        return t.cityid && t.lat && t.lng ? new Promise(function(i) {
            a.setData({
                lat: t.lat,
                lng: t.lng,
                cityParams: {
                    cityId: t.cityid,
                    platformType: 1,
                    source: 14
                },
                shopId: t.shopId || "-9999"
            }), i();
        }) : o.getCityInfo().then(function(i) {
            a.setData({
                lat: i.lat,
                lng: i.lng,
                cityParams: {
                    cityId: i.id,
                    platformType: 1,
                    source: 14
                },
                shopId: t.shopId || "-9999"
            });
        });
    },
    onLoad: function(t) {
        var i = this;
        this.initParam(t).then(function() {
            a.default.getCityInfo(i.data.cityParams).then(function(t) {
                i.setData({
                    naviBars: t.naviBars
                });
            });
        });
    },
    selectShop: function(t) {
        if (t.detail) {
            var a = getCurrentPages();
            if (a.length > 1) {
                var i = a[a.length - 2];
                i.setData({
                    groupLocation: t.detail
                }, function() {
                    i.fetchPublishPatter();
                });
            }
            n.navigateBack({});
        }
    },
    getShopInfo: function(t) {
        var i = this;
        a.default.getShopInfo(t).then(function(t) {
            var a = t.shopItemList || [];
            i.setData({
                shopList: i.data.shopList ? i.data.shopList.concat(a) : a,
                isLastPage: t.isLastPage
            });
        });
    },
    openCitySelect: function() {
        this.setData({
            showCity: !0
        });
    },
    handleClose: function(t) {
        var a = t.detail.data ? t.detail.data.name : this.data.cityName, i = t.detail.data ? t.detail.data.id : this.data.cityId;
        this.setData({
            showCity: t.detail.show,
            cityName: a,
            cityId: i,
            shopList: null
        });
    },
    onReady: function() {},
    onShow: function() {
        i.default.pageView("c_gc_dahhtinu", {
            poi_id: this.data.shopId,
            cat_id: s.default.catId
        });
    },
    onReachBottom: function() {
        if (!this.data.isLastPage) {
            var t = this.data.shopParams.pageno;
            this.setData({
                "shopParams.pageno": t + 1
            }), this.getShopInfo(this.data.shopParams);
        }
    },
    onHide: function() {
        i.default.pageDisappear();
    },
    onUnload: function() {
        i.default.pageDisappear();
    }
});