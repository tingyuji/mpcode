var e = function(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}(require("../../../common/config")), t = require("../../../npm/@mtfe/weapp-privacy-api/index.js").default, a = e.default.dp_mapi_domain + "/dzshoplist/scene/searchfilteritem.bin", i = e.default.dp_mapi_domain + "/dzshoplist/scene/searchshopitemlist.bin", n = e.default.swimlane || "3792-rwtjd";

module.exports = {
    getCityInfo: function(e) {
        return new Promise(function(i, s) {
            t.request({
                url: a,
                data: {
                    cityId: e.cityId,
                    platformType: e.platformType,
                    source: e.source
                },
                method: "POST",
                header: {
                    swimlane: n
                },
                success: function(e) {
                    200 === e.data.code ? i(e.data.result) : s({
                        msg: e.data.msg
                    });
                },
                fail: function(e) {
                    s(e);
                }
            });
        });
    },
    getShopInfo: function(e) {
        return new Promise(function(a, s) {
            t.request({
                url: i,
                data: {
                    cityId: e.cityId,
                    platformType: e.platformType,
                    pageno: e.pageno,
                    limit: e.limit,
                    lng: e.lng,
                    lat: e.lat,
                    source: e.source,
                    sort: e.sort,
                    screening: e.screening
                },
                method: "POST",
                header: {
                    swimlane: n
                },
                success: function(e) {
                    200 === e.data.code ? a(e.data.result) : s({
                        msg: e.data.msg
                    });
                },
                fail: function(e) {
                    s(e);
                }
            });
        });
    }
};