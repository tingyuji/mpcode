function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

var t = e(require("../../../npm/@dzfe/wx-api-promisify/dist/index.js")), n = e(require("../../../common/config")), r = require("../../../npm/@mtfe/weapp-privacy-api/index.js").default, a = n.default.gpower_domain + "/api/gpower/picture/generate", u = n.default.gpower_domain + "/api/gpower/picture/query", o = n.default.dp_domain + "/api/joy/sharerelation/social/group/check", i = n.default.gpower_domain + "/api/gpower/user/popup/show", c = n.default.dp_domain + "/api/joy/sharerelation/post/userdetail/save";

module.exports = {
    generatePic: function(e) {
        return new Promise(function(t, n) {
            r.request({
                url: a,
                data: e,
                success: function(e) {
                    200 === e.data.code ? t(e.data.msg) : n({
                        msg: e.data.msg
                    });
                },
                fail: function(e) {
                    n(e);
                }
            });
        });
    },
    queryPic: function(e) {
        return new Promise(function(t, n) {
            r.request({
                url: u,
                data: e,
                success: function(e) {
                    200 === e.data.code ? t(e.data.msg) : n({
                        msg: e.data.msg
                    });
                },
                fail: function(e) {
                    n(e);
                }
            });
        });
    },
    checkGroup: function(e) {
        return new Promise(function(t, n) {
            r.request({
                url: o,
                data: e,
                success: function(e) {
                    t(e);
                },
                fail: function(e) {
                    n(e);
                }
            });
        }).then(function(e) {
            var t = e.data;
            if (200 === t.code && t.msg) return t.msg;
            throw new Error("请求数据失败");
        }).catch(function(e) {
            return console.error("checkGroup", e), null;
        });
    },
    fetchFillinUserContent: function(e) {
        return t.default.request({
            url: i,
            data: e
        }).then(function(e) {
            var t = e.data, n = t.code, r = t.msg;
            if (200 === n) return r;
        });
    },
    saveUserFillInInfo: function(e) {
        return t.default.request({
            url: c,
            data: e,
            method: "post"
        }).then(function(e) {
            var t = e.data, n = t.code, r = t.msg;
            if (200 === n) return r;
        });
    }
};