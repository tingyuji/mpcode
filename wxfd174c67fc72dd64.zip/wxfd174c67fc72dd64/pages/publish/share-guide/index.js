function t(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

function e(t, e) {
    var a = Object.keys(t);
    if (Object.getOwnPropertySymbols) {
        var n = Object.getOwnPropertySymbols(t);
        e && (n = n.filter(function(e) {
            return Object.getOwnPropertyDescriptor(t, e).enumerable;
        })), a.push.apply(a, n);
    }
    return a;
}

function a(t) {
    for (var a = 1; a < arguments.length; a++) {
        var o = null != arguments[a] ? arguments[a] : {};
        a % 2 ? e(Object(o), !0).forEach(function(e) {
            n(t, e, o[e]);
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(o)) : e(Object(o)).forEach(function(e) {
            Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(o, e));
        });
    }
    return t;
}

function n(t, e, a) {
    return e in t ? Object.defineProperty(t, e, {
        value: a,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : t[e] = a, t;
}

var o = t(require("../../../utils/index")), i = require("../../../common/config"), r = t(i), s = require("../../../common/index.js"), u = require("../../../common/wx-privacy-constant"), c = t(require("./api.js")), l = function(t) {
    if (t && t.__esModule) return t;
    var e = {};
    if (null != t) for (var a in t) Object.prototype.hasOwnProperty.call(t, a) && (e[a] = t[a]);
    return e.default = t, e;
}(require("../../../api/index")), p = t(require("../../../common/lx")), d = t(require("../../../common/login")), f = require("./components/group-alert/api"), h = require("../../../npm/regenerator-runtime/runtime.js"), g = require("../../../npm/@mtfe/weapp-privacy-api/index.js").default, m = null, w = getApp();

Page({
    data: {
        pollingCount: 1,
        params: {},
        isSuccess: 0,
        circlePictureUrl: "",
        shareInfo: null,
        dpShareInfo: null,
        mtShareInfo: null,
        platform: "",
        groupMiniIndexPath: "",
        guidancePopPath1: "",
        guidancePopPath2: "",
        guidancePopPath3: "",
        invitation: "",
        showCard: !1,
        token: "",
        couponText: "",
        communityIcon: {
            wx: "https://p0.meituan.net/scarlett/ab092308308576a1bd243e5fc0340ab82370.png",
            dp: "https://p0.meituan.net/scarlett/ab092308308576a1bd243e5fc0340ab82370.png",
            mt: "https://p0.meituan.net/scarlett/ab092308308576a1bd243e5fc0340ab82370.png"
        }[r.default.platform],
        group: {
            show: !1,
            isWx: "wx" === r.default.platform,
            url: null,
            detailUrl: null
        },
        shareSuccess: !1,
        fillInUserInfoModal: {
            show: !1,
            showAgeTag: !1,
            showBackroomTag: !1,
            showGender: !1,
            showIndustry: !1
        },
        userAvatarDialogVisible: !1,
        isWx: "wx" === r.default.platform,
        navigatorHeight: (0, s.getWxNavigatorBarHeight)(),
        showExitTips: !1,
        copyLinkText: "",
        popVO: {}
    },
    onLoad: function(t) {
        var e = this;
        this.setData({
            params: {
                postmaskid: t.postmaskid
            },
            platform: r.default.platform
        }), this.init(), this.getSharePic(this.data.params).then(function() {
            e.pollingResult();
        }).then(function() {
            return p.default.moduleView(e.data.isWx ? "b_gc_nwmkbdw5_mv" : "b_gc_khuuaqf3_mv", e.getLxDiscountStatus());
        }), p.default.pageView("c_gc_vutz21wn", {
            cat_id: r.default.catId,
            poi_id: t.shopid,
            custom: {
                group_id: t.postmaskid
            }
        }), this.initExitTips(), !this.data.isWx && g.hideShareMenu({
            menus: [ "shareAppMessage" ]
        });
    },
    onShow: function() {},
    init: function() {
        var t = this;
        return h.async(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                if ("wx" !== t.data.platform) {
                    e.next = 7;
                    break;
                }
                if (!w.globalData.userInfo) {
                    e.next = 5;
                    break;
                }
                t.data.token = w.globalData.userInfo.token, e.next = 7;
                break;

              case 5:
                return e.next = 7, h.awrap(t.forceLogin());

              case 7:
                g.showLoading({
                    title: "分享图片生成中"
                }), t.initUserInfoModal();

              case 9:
              case "end":
                return e.stop();
            }
        }, null, null, null, Promise);
    },
    initExitTips: function() {
        var t = this, e = "_publish-guide_exitTips-date";
        this.data.isWx || g.getStorage({
            key: e,
            success: function(a) {
                a.data || (t.setData({
                    showExitTips: !0
                }), setTimeout(function() {
                    t.setData({
                        showExitTips: !1
                    }), g.setStorage({
                        key: e,
                        data: Date.now()
                    });
                }, 3500));
            }
        });
    },
    initUserInfoModal: function() {
        var t = this;
        return h.async(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                if (t.data.isWx) {
                    e.next = 2;
                    break;
                }
                return e.abrupt("return");

              case 2:
                return e.next = 4, h.awrap(t.forceLogin());

              case 4:
                c.default.fetchFillinUserContent({
                    platform: r.default.platformCode,
                    postmaskid: t.options.postmaskid,
                    token: t.data.token,
                    source: "wx" === r.default.platform ? 0 : r.default.platformCode
                }).then(function(e) {
                    var a = e.showAgeTag, n = e.showBackroomTag, o = e.showGender, i = e.showIndustry;
                    e.showAvatar ? t.setData({
                        userAvatarDialogVisible: !0
                    }) : t.setData({
                        fillInUserInfoModal: {
                            show: a || n || o || i,
                            showAgeTag: a,
                            showBackroomTag: n,
                            showGender: o,
                            showIndustry: i
                        }
                    });
                });

              case 5:
              case "end":
                return e.stop();
            }
        }, null, null, null, Promise);
    },
    forceLogin: function() {
        var t = this;
        return d.default.mtDefaultLogin({
            isBind: !0
        }).then(function(e) {
            t.data.token = e.token || e.userInfo && e.userInfo.token || "";
        });
    },
    sharetimeline: function() {
        var t = this;
        p.default.moduleClick("b_gc_du0dqx9s_mc", {
            group_id: this.options.postmaskid
        }), g.mtShare({
            type: 2,
            imageUrl: this.data.circlePictureUrl,
            title: "",
            channel: "WXTimeline",
            success: function() {
                t.setShowGroup(), console.log("分享朋友圈成功");
            },
            fail: function(t) {
                console.log("分享朋友圈失败", t);
            }
        });
    },
    copyShare: function() {
        var t = this;
        g.setClipboardData({
            data: this.data.copyLinkText,
            _mt: {
                sceneToken: i.isWX ? u.WX_SCENETOKENS.SETCLIPBOARD_SHARELINK : r.default.clipboardSceneToken
            },
            success: function() {
                !t.data.isWx && g.showToast({
                    title: "复制成功",
                    icon: "success"
                });
            }
        }), p.default.moduleClick("b_gc_ilenospn_mc", this.getLxDiscountStatus());
    },
    getLxDiscountStatus: function() {
        return {
            discount_status: this.data.couponText ? 1 : 0
        };
    },
    savePic: function() {
        p.default.moduleClick("b_gc_a0kkq9ia_mc", this.getLxDiscountStatus()), this.setShowGroup(), 
        g.downloadFile({
            url: this.data.circlePictureUrl,
            success: function(t) {
                200 === t.statusCode && g.saveImageToPhotosAlbum({
                    filePath: t.tempFilePath,
                    _mt: {
                        sceneToken: i.isWX ? u.WX_SCENETOKENS.SAVEIMAGETOPHOTOSALBUM_PUBLISH : r.default.privacySceneToken
                    },
                    success: function() {
                        g.showToast({
                            title: "保存成功",
                            icon: "success",
                            duration: 2e3
                        });
                    },
                    fail: function() {
                        g.showToast({
                            title: "保存失败,请重新授权",
                            icon: "none",
                            duration: 2e3
                        });
                    }
                });
            },
            fail: function() {
                g.showToast({
                    title: "保存失败",
                    icon: "none",
                    duration: 2e3
                });
            }
        });
    },
    getSharePic: function(t) {
        var e = this;
        return c.default.generatePic(t).then(function(t) {
            e.setData({
                isSuccess: t.isSuccess
            });
        });
    },
    pollingResult: function() {
        var t = this;
        1 === this.data.isSuccess && this.data.pollingCount < 15 ? m = setTimeout(function() {
            t.queryPic(t.data.params).then(t.groupQuery), t.data.pollingCount++;
        }, 1e3) : (g.showToast({
            title: "拼场已发布成功",
            icon: "none",
            duration: 2e3
        }), this.jump());
    },
    queryPic: function(t) {
        var e = this;
        return c.default.queryPic(t).then(function(t) {
            if (t && t.circlePictureUrl) {
                clearTimeout(m), m = null;
                try {
                    t.headPictureUrl = o.default.imgResizer(t.headPictureUrl, 100);
                } catch (t) {
                    console.log(t);
                }
                e.setData({
                    showCard: !0,
                    circlePictureUrl: t.circlePictureUrl,
                    mtShareInfo: {
                        type: 1,
                        title: t.declaration,
                        path: t.path,
                        imageUrl: t.sharePictureUrl,
                        appId: "gh_c509e170d6df"
                    },
                    shareInfo: {
                        title: t.declaration,
                        path: t.path,
                        imageUrl: t.sharePictureUrl
                    },
                    dpShareInfo: {
                        type: 0,
                        title: t.title,
                        content: t.declaration,
                        imageUrl: t.headPictureUrl,
                        url: t.path || "weixin://dl/business/?t=kBlUbGbUhDl",
                        channel: "WXSceneSession"
                    },
                    groupMiniIndexPath: t.groupMiniIndexPath || "/pages/home/index",
                    guidancePopPath1: t.guidancePopPath1,
                    guidancePopPath2: t.guidancePopPath2,
                    guidancePopPath3: t.guidancePopPath3,
                    couponText: t.couponText || "",
                    groupBanner: t.bannerVO,
                    invitation: t.title,
                    copyLinkText: t.copyLinkText
                }), g.hideLoading();
            } else e.setData({
                groupMiniIndexPath: t.groupMiniIndexPath,
                guidancePopPath1: t.guidancePopPath1,
                guidancePopPath2: t.guidancePopPath2,
                guidancePopPath3: t.guidancePopPath3,
                couponText: t && t.couponText || ""
            }), e.pollingResult();
        });
    },
    jump: function() {
        var t = this;
        "wx" === this.data.platform ? setTimeout(function() {
            g.switchTab({
                url: t.data.groupMiniIndexPath
            });
        }, 3e3) : setTimeout(function() {
            t.data.guidancePopPath2 && g.openLink({
                url: t.data.guidancePopPath2
            });
        }, 3e3);
    },
    cancelShare: function() {
        p.default.moduleClick(this.data.isWx ? "b_gc_nwmkbdw5_mc" : "b_gc_khuuaqf3_mc", this.getLxDiscountStatus()), 
        "wx" === r.default.platform ? g.switchTab({
            url: this.data.groupMiniIndexPath
        }) : mmp.navigateBackNative();
    },
    groupQuery: function() {
        var t = this, e = this.data.circlePictureUrl, n = this.data.groupBanner || {}, o = n.bannerShowType, i = n.bannerJumpUrl;
        getApp().addError(function(a, n) {
            if (e && !i) return {
                category: a.BUSINESS_ERROR,
                level: n.ERROR,
                msg: "分享引导页社群跳链缺失",
                custom: {
                    params: {
                        postmaskid: t.options.postmaskid,
                        shopid: t.options.shopid
                    }
                }
            };
        });
        var r = this.checkCanShowGroup(o);
        this.setData({
            group: Object.assign({}, this.data.group, {
                url: i,
                show: r
            })
        }), r && p.default.moduleView("b_gc_k63fnof6_mv", a({
            abtest: o,
            type: 1
        }, this.getLxDiscountStatus()));
    },
    checkCanShowGroup: function(t) {
        var e = r.default.platform, a = "mt" === e, n = "dp" === e;
        if (a || n) {
            var i = g.getSystemInfoSync().appVersion;
            return !!i && (!(a && o.default.compareVersion(i, "11.9.400") < 0 || n && o.default.compareVersion(i, "10.54.0") < 0) && 1 === t);
        }
        return 1 === t;
    },
    joinCommunity: function(t) {
        var e = t.currentTarget.dataset, n = this.data.groupBanner || {}, o = n.bannerJumpUrl, i = n.bannerShowType;
        if (o) if ([ "mt", "dp" ].includes(r.default.platform)) {
            if (g.navigateToMiniProgram({
                platform: "wx",
                appId: "gh_c509e170d6df",
                path: o,
                extraData: {},
                envVersion: "release",
                success: console.log,
                fail: function() {
                    getApp().addError(function(t, e) {
                        return {
                            category: t.BUSINESS_ERROR,
                            level: e.ERROR,
                            msg: "分享引导页社群跳转失败",
                            custom: {
                                url: o
                            }
                        };
                    });
                }
            }), "popup" === (e || {}).from) return (0, f.postGroupJoin)({
                postmaskid: this.options.postmaskid
            }), void p.default.moduleClick("b_gc_nxzdkiov_mc");
        } else g.navigateTo({
            url: o,
            success: console.log,
            fail: function() {
                getApp().addError(function(t, e) {
                    return {
                        category: t.BUSINESS_ERROR,
                        level: e.ERROR,
                        msg: "分享引导页社群跳转失败",
                        custom: {
                            url: o
                        }
                    };
                });
            }
        });
        p.default.moduleClick("b_gc_k63fnof6_mc", a({
            abtest: i,
            type: 1
        }, this.getLxDiscountStatus()));
    },
    setShowGroup: function() {
        var t = (this.data.groupBanner || {}).bannerShowType;
        2 === t && this.checkCanShowGroup(1) && (this.setData({
            "group.show": !0
        }), p.default.moduleView("b_gc_k63fnof6_mv", a({
            abtest: t
        }, this.getLxDiscountStatus())));
    },
    fetchShareInfo: function() {
        var t = this;
        return function() {
            var e, a, n, o, i, s, u, c, p, d;
            return h.async(function(f) {
                for (;;) switch (f.prev = f.next) {
                  case 0:
                    return e = w.globalData.userInfo, a = e.openId, n = e.openIdCipher, o = e.uuid, 
                    f.next = 3, h.awrap(w.finger());

                  case 3:
                    return i = f.sent, f.next = 6, h.awrap(l.getShareInfo({
                        platform: r.default.platformCode,
                        postmaskid: t.options.postmaskid,
                        uacode: r.default.uaCode,
                        cityid: w.globalData.ci,
                        fp: i,
                        uuid: o,
                        openid: a,
                        expoid: n
                    }));

                  case 6:
                    return s = f.sent, u = s.title, c = s.subTitle, p = s.path, d = s.image, t.setData({
                        popVO: s && s.popVO
                    }), f.abrupt("return", {
                        title: u,
                        subTitle: c,
                        path: p,
                        image: d
                    });

                  case 10:
                  case "end":
                    return f.stop();
                }
            }, null, null, null, Promise);
        }();
    },
    onShareAppMessage: function() {
        var t = this;
        return function() {
            var e, n, i, s, u, c, l, d, f, g, m;
            return h.async(function(w) {
                for (;;) switch (w.prev = w.next) {
                  case 0:
                    return p.default.moduleClick("b_gc_hf68fxcm_mc", a({
                        group_id: t.options.postmaskid
                    }, t.getLxDiscountStatus())), t.setShowGroup(), w.next = 4, h.awrap(t.fetchShareInfo());

                  case 4:
                    return e = w.sent, n = t.data, i = n.dpShareInfo, s = n.mtShareInfo, u = n.shareInfo, 
                    c = e.title, l = e.subTitle, d = e.path, f = e.image, g = r.default.platform, m = function(t) {
                        switch (g) {
                          case "mt":
                            return a({}, s, {
                                path: d,
                                title: c,
                                imageUrl: f
                            });

                          case "dp":
                            return a({}, i, {
                                url: d,
                                title: c,
                                content: l,
                                imageUrl: o.default.imgResizer(f, 100)
                            });

                          default:
                            return a({}, u, {
                                path: d,
                                title: c,
                                imageUrl: f
                            });
                        }
                    }(), setTimeout(t.setData.bind(t, {
                        shareSuccess: !0
                    }), 3e3), w.abrupt("return", a({}, m, {
                        success: function() {
                            this.setData({
                                shareSuccess: !0
                            });
                        }
                    }));

                  case 11:
                  case "end":
                    return w.stop();
                }
            }, null, null, null, Promise);
        }();
    },
    copyInvitation: function() {
        g.setClipboardData({
            data: this.data.invitation,
            _mt: {
                sceneToken: i.isWX ? u.WX_SCENETOKENS.SETCLIPBOARD_CONTACT : r.default.clipboardSceneToken
            }
        });
    },
    closeUserInfoModal: function() {
        this.setData({
            "fillInUserInfoModal.show": !1
        });
    },
    handleUserInfoModalSubmit: function(t) {
        var e = this, a = t.detail, n = a.genderCurrentTag, o = a.ageCurrentTag, i = a.roleCurrentTag, s = a.industry;
        c.default.saveUserFillInInfo({
            platform: r.default.platformCode,
            ageTag: o,
            backroomTag: i,
            gender: n,
            nickname: "",
            avatar: "",
            birthday: "",
            weChatOpenId: "",
            area: "",
            industry: s,
            introduction: ""
        }).then(function(t) {
            t.errorMessage ? g.showToast({
                title: t.errorMessage,
                icon: "none"
            }) : e.closeUserInfoModal();
        });
    },
    closeAvatarUploadDialog: function() {
        this.setData({
            userAvatarDialogVisible: !1
        });
    },
    onHide: function() {},
    onUnload: function() {}
});