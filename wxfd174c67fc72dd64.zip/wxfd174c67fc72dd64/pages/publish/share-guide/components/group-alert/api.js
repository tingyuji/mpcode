Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getGroupQuery = function(r) {
    return new Promise(function(o, t) {
        e.request({
            url: n.GROUP_QUERY,
            data: r,
            success: function(r) {
                o(r);
            },
            fail: function(r) {
                t(r);
            }
        });
    }).then(function(r) {
        var e = r.data;
        if (200 === e.code && e.msg) return e.msg;
        throw new Error("请求数据失败");
    }).catch(function() {
        return getApp().addError(function(e, o) {
            return {
                category: e.AJAX_ERROR,
                level: o.ERROR,
                msg: "分享引导页查询社群弹窗请求数据失败",
                custom: {
                    url: n.GROUP_QUERY,
                    params: r
                }
            };
        }), null;
    });
}, exports.postGroupJoin = function(r) {
    return new Promise(function(o, t) {
        e.request({
            url: n.GROUP_JOIN,
            data: r,
            success: function(r) {
                o(r);
            },
            fail: function(r) {
                t(r);
            }
        });
    }).then(function(r) {
        var e = r.data;
        if (200 === e.code && e.msg) return e.msg;
        throw new Error("请求数据失败");
    }).catch(function(r) {
        return console.error("postGroupJoin", r), null;
    });
};

var r = function(r) {
    return r && r.__esModule ? r : {
        default: r
    };
}(require("../../../../../common/config")), e = require("../../../../../npm/@mtfe/weapp-privacy-api/index.js").default, n = {
    GROUP_QUERY: r.default.gpower_domain + "/api/gpower/social/group/query",
    GROUP_JOIN: r.default.gpower_domain + "/api/gpower/social/group/join"
};