function t(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

var e = function(t) {
    if (t && t.__esModule) return t;
    var e = {};
    if (null != t) for (var o in t) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
    return e.default = t, e;
}(require("./api")), o = t(require("../../../../../common/login")), i = t(require("../../../../../common/lx")), r = require("../../../../../npm/@mtfe/weapp-privacy-api/index.js").default, n = getApp();

Component({
    options: {
        multipleSlots: !0
    },
    properties: {
        postMaskId: {
            type: String,
            value: ""
        },
        title: {
            type: String,
            value: "加入拼场玩乐群"
        },
        customBtn: {
            type: Boolean,
            value: !1
        },
        shopId: Number
    },
    lifetimes: {
        ready: function() {
            this.queryGroupUrl(), 1107 !== n.globalData.sceneValue && 1014 !== n.globalData.sceneValue || (i.default.moduleView("b_gc_m8018t4i_mv", {
                group_id: this.properties.postMaskId
            }), this.setData({
                showToDetail: !0
            })), i.default.moduleView("b_gc_nz4mtk51_mv");
        }
    },
    data: {
        groupUrl: "",
        token: "",
        showToDetail: !1,
        detailUrl: ""
    },
    methods: {
        queryGroupUrl: function() {
            var t = this, o = {
                postmaskid: this.properties.postMaskId,
                shopid: this.properties.shopId || 0
            };
            return e.getGroupQuery(o).then(function(e) {
                t.setData({
                    groupUrl: e.groupUrl,
                    detailUrl: e.postDetailUrl
                });
            });
        },
        completemessage: function() {},
        forceLogin: function() {
            var t = this;
            return o.default.mtDefaultLogin({
                isBind: !0
            }).then(function(e) {
                t.data.token = e.token;
            });
        },
        joinGroup: function() {
            var t = this;
            i.default.moduleClick("b_gc_nxzdkiov_mc"), this.forceLogin().then(function() {
                t.recordJoinGroup();
            });
        },
        toDetail: function() {
            i.default.moduleClick("b_gc_m8018t4i_mc", {
                group_id: this.properties.postMaskId
            }), r.navigateTo({
                url: this.data.detailUrl
            });
        },
        close: function() {
            i.default.moduleClick("b_gc_744q1xfd_mc"), this.triggerEvent("close");
        },
        recordJoinGroup: function() {
            var t = this, o = {
                postmaskid: this.properties.postMaskId,
                token: this.data.token
            };
            return e.postGroupJoin(o).then(function(e) {
                t.setData({
                    isSuccess: e.isSuccess
                });
            });
        }
    }
});