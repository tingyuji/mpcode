Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getChatList = function(e) {
    return new Promise(function(a, i) {
        t.request({
            url: r.CHAT_LIST,
            data: e,
            header: n,
            success: function(e) {
                a(e);
            },
            fail: function(e) {
                i(e);
            }
        });
    }).then(function(e) {
        var t = e.data;
        if (200 === t.code && t.msg) return t.msg;
        throw new Error("请求群聊列表数据失败");
    }).catch(function(e) {
        return console.error("getChatList", e), null;
    });
};

var e = function(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}(require("../../common/config")), t = require("../../npm/@mtfe/weapp-privacy-api/index.js").default, r = {
    MESSAGE_DOT: e.default.dp_domain + " /api/joy/sharerelation/im/reddot",
    CHAT_LIST: e.default.dp_domain + "/api/joy/sharerelation/im/chatlist"
}, n = {
    swimlane: e.default.swimlane || "3792-rwtjd"
};