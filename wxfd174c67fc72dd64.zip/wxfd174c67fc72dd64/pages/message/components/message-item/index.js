function t(t) {
    if (Array.isArray(t)) {
        for (var e = 0, i = Array(t.length); e < t.length; e++) i[e] = t[e];
        return i;
    }
    return Array.from(t);
}

function e(t) {
    return t.toDateString() === new Date().toDateString();
}

var i = {
    MINI: "mini",
    SMALL: "small"
};

Component({
    properties: {
        chatData: {
            type: Object
        },
        index: {
            type: Number
        }
    },
    observers: {
        chatData: function() {
            this.init();
        }
    },
    data: {
        timeLabel: "",
        row1: [],
        row2: [],
        row3: [],
        avatarSize: i.SMALL
    },
    methods: {
        setAvatarConfig: function() {
            var e = this.properties.chatData.urls, a = e.length, n = [], r = [], s = [], o = i.SMALL;
            a > 6 ? (s.push.apply(s, t(e.slice(-3))), r.push.apply(r, t(e.slice(-6, -3))), n.push.apply(n, t(e.slice(-9, -6)))) : a > 4 ? (r.push.apply(r, t(e.slice(-3))), 
            n.push.apply(n, t(e.slice(0, -3)))) : a > 2 ? (r.push.apply(r, t(e.slice(-2))), 
            n.push.apply(n, t(e.slice(0, -2))), o = i.MINI) : (n.push.apply(n, t(e.slice(0))), 
            o = i.MINI), this.setData({
                row1: n,
                row2: r,
                row3: s,
                avatarSize: o
            });
        },
        setTimeLabel: function() {
            var t = this.properties.chatData.lt, i = new Date(t), a = function(t) {
                return t.toString().padStart(2, "0");
            }, n = "";
            n = e(i) ? a(i.getHours()) + ":" + a(i.getMinutes()) : i.getFullYear() + "/" + a(i.getMonth() + 1) + "/" + a(i.getDate()), 
            this.setData({
                timeLabel: n
            });
        },
        onClick: function() {
            this.triggerEvent("messageClick", this.properties.chatData);
        },
        init: function() {
            this.setAvatarConfig(), this.setTimeLabel();
        }
    },
    lifetimes: {
        attached: function() {
            this.init();
        },
        moved: function() {},
        detached: function() {}
    },
    attached: function() {},
    ready: function() {},
    pageLifetimes: {
        show: function() {},
        hide: function() {},
        resize: function() {}
    }
});