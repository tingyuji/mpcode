function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function t(e, t, a) {
    return t in e ? Object.defineProperty(e, t, {
        value: a,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = a, e;
}

var a = function(e) {
    if (e && e.__esModule) return e;
    var t = {};
    if (null != e) for (var a in e) Object.prototype.hasOwnProperty.call(e, a) && (t[a] = e[a]);
    return t.default = e, t;
}(require("./api")), s = (e(require("../../common/config")), e(require("../../common/login"))), n = e(require("../../common/lx")), r = require("../../utils/im"), i = e(require("../../utils/index")), o = require("../../npm/regenerator-runtime/runtime.js"), u = require("../../npm/@mtfe/weapp-privacy-api/index.js").default, c = i.default.EVENT_TYPE, h = i.default.Event, l = getApp();

Page({
    data: {
        token: "",
        page: 0,
        hasNext: !0,
        loading: !1,
        currentGroupChat: null,
        chatList: [],
        scrollTop: 0
    },
    isFirstLoad: !0,
    shouldUpdate: !1,
    hasListener: !1,
    messageTimer: null,
    messagePool: [],
    cache: new Map(),
    transformGroupMessage: function(e) {
        var t = e.groupId, a = e.name, s = e.groupChatUrl, n = e.avatarUrls, r = e.latestMessage, i = e.latestMessageTimestamp, o = e.readTimestamp;
        return {
            id: t,
            name: a,
            target: s,
            urls: n.slice(0, 9),
            msg: r,
            lt: i,
            rt: o
        };
    },
    formatMessageFromPike: function(e) {
        var t = e.group, a = e.message, s = e.timestamp;
        return {
            id: t.id,
            name: t.name,
            target: t.groupChatUrl,
            urls: t.members.slice(0, 9).map(function(e) {
                return e.avatarUrl;
            }),
            msg: a.text,
            lt: s,
            rt: 0
        };
    },
    handleScrollToLower: function() {
        this.data.hasNext && !this.data.loading && this.updateMessageList();
    },
    mergeMessageListFromNextPage: function(e) {
        for (var t = this.data.chatList, a = this.cache, s = 0; s < e.length; s++) {
            var n = e[s];
            a.has(n.id) && a.get(n.id).lt >= n.lt || t.push(n);
        }
        var r = t.sort(function(e, t) {
            return t.lt - e.lt;
        });
        return this.updateGroupIdCache(r), r;
    },
    updateMessageList: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0], t = this;
        return function() {
            var s;
            return o.async(function(n) {
                for (;;) switch (n.prev = n.next) {
                  case 0:
                    if (n.prev = 0, t.setData({
                        loading: !0
                    }), t.data.token) {
                        n.next = 5;
                        break;
                    }
                    return n.next = 5, o.awrap(t.getToken());

                  case 5:
                    return n.next = 7, o.awrap(a.getChatList({
                        token: t.data.token,
                        pagenum: t.data.page + 1
                    }));

                  case 7:
                    s = n.sent, e && (t.data.chatList.length = 0, t.cache.clear(), t.setData({
                        scrollTop: 0
                    })), t.setData({
                        chatList: t.mergeMessageListFromNextPage(s.chatList.map(t.transformGroupMessage)),
                        hasNext: s.hasNext,
                        page: t.data.page + 1,
                        loading: !1
                    }), n.next = 16;
                    break;

                  case 12:
                    n.prev = 12, n.t0 = n.catch(0), t.setData({
                        loading: !1
                    }), console.log(n.t0);

                  case 16:
                  case "end":
                    return n.stop();
                }
            }, null, null, [ [ 0, 12 ] ], Promise);
        }();
    },
    initMessageList: function() {
        var e = this;
        return o.async(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return e.setData({
                    page: 0,
                    hasNext: !0
                }), t.next = 3, o.awrap(e.updateMessageList(!0));

              case 3:
                h.emit(c.MESSAG_PAGE_INIT);

              case 4:
              case "end":
                return t.stop();
            }
        }, null, null, null, Promise);
    },
    updateCurrentGroupChat: function(e) {
        if (e) {
            this.forceUpdate();
            var a = this.cache, s = a.get(e), n = Date.now();
            this.shouldSubtractMessage(e) && h.emit(c.UNREAD_MESSAGES_CHANGED, -1), s && void 0 !== s.index && (this.setData(t({}, "chatList[" + s.index + "].rt", s.lt)), 
            a.set(e, Object.assign({}, s, {
                rt: n
            })));
        }
    },
    handleMessageClick: function(e) {
        var t = e.detail, a = t.id, s = t.target;
        this.setData({
            currentGroupChat: a
        }), u.navigateTo({
            url: s
        });
    },
    shouldAddMessage: function(e) {
        this.data.currentGroupChat;
        var t = this.cache, a = !1;
        if (t.has(e.id)) {
            var s = t.get(e.id), n = s.lt, r = s.rt;
            a = r >= n && e.lt > n && e.lt > r;
        } else a = !0;
        return a;
    },
    shouldSubtractMessage: function(e) {
        var t = this.cache.get(e);
        return t.lt > t.rt;
    },
    onMessage: function(e) {
        var t = this.cache;
        try {
            var a = JSON.parse(e), s = this.formatMessageFromPike(a);
            this.shouldAddMessage(s) && h.emit(c.UNREAD_MESSAGES_CHANGED, 1);
            var n = s.id, r = s.lt, i = t.get(n), o = i && i.rt || 0;
            t.set(n, Object.assign({}, i, {
                lt: r,
                rt: o,
                isNew: i ? 0 : 1
            })), s.rt = o, this.messagePool.push(s);
        } catch (e) {
            console.error(e);
        }
    },
    onDisconnect: function() {
        u.showToast({
            title: "连接已断开",
            icon: "none"
        });
    },
    onReconnect: function() {
        this.showLoading("正在重新连接");
    },
    onPikeReady: function() {
        u.hideLoading();
    },
    updateGroupIdCache: function(e) {
        var t = this.cache;
        t.clear(), e.forEach(function(e, a) {
            var s = e.id, n = e.lt, r = e.rt;
            t.set(s, {
                id: s,
                lt: n,
                rt: r,
                index: a
            });
        });
    },
    batchMessageUpdate: function() {
        var e = this.messagePool, t = this.shouldUpdate, a = this.cache, s = this.data.chatList;
        if (e.length && t) {
            for (var n = 0; n < e.length; n++) {
                var r = e[n], i = a.get(r.id), o = i.index, u = i.lt;
                i.isNew ? (s.push(r), a.set(r.id, Object.assign({}, a.get(r.id), {
                    isNew: 0
                }))) : r.lt >= u && (s[o] = r);
            }
            var c = s.sort(function(e, t) {
                return t.lt - e.lt;
            });
            this.updateGroupIdCache(c), this.setData({
                chatList: c
            }), e.length = 0;
        }
    },
    forceUpdate: function() {
        this.batchMessageUpdate();
    },
    getToken: function() {
        var e = this;
        return s.default.mtDefaultLogin({
            isBind: !0
        }).then(function(t) {
            e.setData({
                token: t.token || t.userInfo && t.userInfo.token || ""
            });
        });
    },
    isPikeServiceReady: function() {
        var e = l.globalData;
        return e.im && e.im.isReady;
    },
    onRedirectToMessagePage: function() {
        var e = this;
        return o.async(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                if (e.shouldUpdate = !0, e.isPikeServiceReady() || !e.isFirstLoad) {
                    t.next = 3;
                    break;
                }
                return t.abrupt("return");

              case 3:
                e.initMessageList(), e.isPikeServiceReady() || e.showLoading();

              case 5:
              case "end":
                return t.stop();
            }
        }, null, null, null, Promise);
    },
    onUserLogin: function() {
        var e = this;
        return function() {
            var t, a, s;
            return o.async(function(n) {
                for (;;) switch (n.prev = n.next) {
                  case 0:
                    if ((t = getCurrentPages())[t.length - 1] === e) {
                        n.next = 3;
                        break;
                    }
                    return n.abrupt("return");

                  case 3:
                    if (a = l.globalData, s = "", a && a.userInfo && (s = a.userInfo.token || ""), s) {
                        n.next = 9;
                        break;
                    }
                    return console.error("user login but got empty token"), n.abrupt("return");

                  case 9:
                    return e.hasListener || (e.addListener(), e.hasListener = !0), clearInterval(e.messageTimer), 
                    e.messageTimer = setInterval(e.batchMessageUpdate, 1e3), e.setData({
                        token: s
                    }), n.next = 15, o.awrap(e.initMessageList());

                  case 15:
                    h.emit(c.MESSAG_PAGE_INIT);

                  case 16:
                  case "end":
                    return n.stop();
                }
            }, null, null, null, Promise);
        }();
    },
    onUserLogout: function() {
        var e = l.globalData;
        e && e.im && (e.im.exit(), e.im = void 0), this.shouldUpdate = !1, this.cache.clear(), 
        this.messagePool.length = 0, this.setData({
            token: "",
            page: 0,
            hasNext: !0,
            loading: !1,
            currentGroupChat: null,
            chatList: []
        }), clearInterval(this.messageTimer);
    },
    onReadMessage: function(e) {
        var t = e.groupId;
        t && (t = parseInt(t), this.updateCurrentGroupChat(t));
    },
    addListener: function() {
        h.on(c.PIKE_MESSAGE, this.onMessage, this), h.on(c.PIKE_DISCONNECT, this.onDisconnect, this), 
        h.on(c.PIKE_RECONNECT, this.onReconnect, this), h.on(c.PIKE_READY, this.onPikeReady, this), 
        h.on(c.USER_LOGOUT, this.onUserLogout, this), h.on(c.PIKE_H5_READ_MESSAGE, this.onReadMessage, this);
    },
    removerListener: function() {
        h.off(c.PIKE_MESSAGE, this.onMessage, this), h.off(c.PIKE_DISCONNECT, this.onDisconnect, this), 
        h.off(c.PIKE_RECONNECT, this.onReconnect, this), h.off(c.PIKE_READY, this.onPikeReady, this), 
        h.off(c.USER_LOGOUT, this.onUserLogout, this), h.off(c.USER_LOGIN, this.onUserLogin, this), 
        h.off(c.PIKE_H5_READ_MESSAGE, this.onReadMessage, this), h.off(c.REDIRECT_TO_MESSAGE_PAGE, this.onRedirectToMessagePage, this);
    },
    mount: function() {
        var e = this;
        return function() {
            var t;
            return o.async(function(a) {
                for (;;) switch (a.prev = a.next) {
                  case 0:
                    if (t = "", !e.isPikeServiceReady()) {
                        a.next = 5;
                        break;
                    }
                    t = l.globalData.im.pikeInfo.token, a.next = 8;
                    break;

                  case 5:
                    return a.next = 7, o.awrap((0, r.initIM)(!0));

                  case 7:
                    t = a.sent;

                  case 8:
                    if (t) {
                        a.next = 10;
                        break;
                    }
                    return a.abrupt("return");

                  case 10:
                    return e.hasListener || (e.addListener(), e.hasListener = !0), clearInterval(e.messageTimer), 
                    e.messageTimer = setInterval(e.batchMessageUpdate, 1e3), e.setData({
                        token: t
                    }), a.next = 16, o.awrap(e.initMessageList());

                  case 16:
                    e.isFirstLoad = !1, h.emit(c.MESSAG_PAGE_INIT);

                  case 18:
                  case "end":
                    return a.stop();
                }
            }, null, null, null, Promise);
        }();
    },
    showLoading: function() {
        arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
    },
    onLoad: function() {
        h.on(c.REDIRECT_TO_MESSAGE_PAGE, this.onRedirectToMessagePage, this), h.on(c.USER_LOGIN, this.onUserLogin, this), 
        this.mount(), l.globalData.c = this.cache;
    },
    onReady: function() {},
    onShow: function() {
        if ("function" == typeof this.getTabBar && this.getTabBar()) {
            var e = this.getTabBar();
            e.refreshSelectedTab && e.refreshSelectedTab();
        }
        this.shouldUpdate = !0, n.default.pageView("c_gc_lbbqyiyv");
        var t = this.data.currentGroupChat;
        this.isPikeServiceReady() && t && this.setData({
            currentGroupChat: null
        });
    },
    onHide: function() {
        n.default.pageDisappear(), u.hideLoading(), this.data.currentGroupChat || (this.shouldUpdate = !1), 
        this.isFirstLoad = !1;
    },
    onUnload: function() {
        n.default.pageDisappear(), this.shouldUpdate = !1, this.removerListener(), clearInterval(this.messageTimer);
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});