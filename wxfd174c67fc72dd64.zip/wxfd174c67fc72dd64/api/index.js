function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

var t = function() {
    function e(e, t) {
        var r = [], n = !0, a = !1, o = void 0;
        try {
            for (var u, i = e[Symbol.iterator](); !(n = (u = i.next()).done) && (r.push(u.value), 
            !t || r.length !== t); n = !0) ;
        } catch (e) {
            a = !0, o = e;
        } finally {
            try {
                !n && i.return && i.return();
            } finally {
                if (a) throw o;
            }
        }
        return r;
    }
    return function(t, r) {
        if (Array.isArray(t)) return t;
        if (Symbol.iterator in Object(t)) return e(t, r);
        throw new TypeError("Invalid attempt to destructure non-iterable instance");
    };
}(), r = e(require("../npm/@dzfe/wx-api-promisify/dist/index.js")), n = e(require("../common/config")), a = require("../npm/@mtfe/weapp-privacy-api/index.js").default, o = {
    SEARCHE_DEAL: n.default.dp_domain + "/api/joy/sharerelation/post/deal/show",
    LOG_DEAL: n.default.dp_domain + "/api/joy/sharerelation/post/deal/log",
    GUIDE_INFO: n.default.gpower_domain + "/api/gpower/guide/info",
    TICKET_2_PARAMS: n.default.dp_domain + "/api/joy/sharerelation/ticket/query",
    GET_GLOBAL_INFO: n.default.gpower_domain + "/api/gpower/global/info",
    GET_CITIES: n.default.gpower_domain + "/api/gpower/home/city",
    POST_LOAD: n.default.gpower_domain + "/api/gpower/post/load",
    YODA_SEND: n.default.gpower_domain + "/api/gpower/captcha/send"
}, u = n.default.swimlane;

module.exports = {
    searchDeal: function(e) {
        return new Promise(function(t, r) {
            a.request({
                url: o.SEARCHE_DEAL,
                data: e,
                header: {
                    swimlane: u
                },
                success: function(e) {
                    200 === e.data.code ? t(e.data.msg) : r(new Error(e.data.msg));
                },
                fail: function(e) {
                    r(e);
                }
            });
        });
    },
    recordLog: function(e) {
        return new Promise(function(t, r) {
            a.request({
                url: o.LOG_DEAL,
                data: e,
                header: {
                    swimlane: u
                },
                success: function(e) {
                    200 === e.data.code ? t(e.data.msg) : r(new Error(e.data.msg));
                },
                fail: function(e) {
                    r(e);
                }
            });
        });
    },
    getGuideInfo: function(e) {
        return new Promise(function(t, r) {
            a.request({
                url: o.GUIDE_INFO,
                data: e,
                header: {
                    swimlane: u
                },
                success: function(e) {
                    200 === e.data.code ? t(e.data.msg) : r(new Error(e.data.msg));
                },
                fail: function(e) {
                    r(e);
                }
            });
        });
    },
    parseShortTicket: function(e) {
        return new Promise(function(t, r) {
            a.request({
                url: o.TICKET_2_PARAMS,
                data: {
                    ticket: e
                },
                success: function(e) {
                    var n = e.data, a = n.code, o = n.msg;
                    200 !== a && r(new Error(o)), t(o || {});
                },
                fail: r
            });
        });
    },
    getGlobalInfo: function(e) {
        return r.default.request({
            url: o.GET_GLOBAL_INFO,
            data: e
        }).then(function(e) {
            var t = e.data, r = t.code, n = t.msg;
            if (200 !== r || !n || !Object.keys(n || {}).length) throw Error();
            return n;
        }).catch(function() {
            return null;
        });
    },
    getCities: function(e) {
        return r.default.request({
            url: o.GET_CITIES,
            data: e
        }).then(function(e) {
            var r = e.data, n = r.code, a = r.msg;
            if (200 !== n) throw Error();
            return getApp().addError(function(e) {
                if (!Object.entries(a.alphabet2CityVO || {}).reduce(function(e, r) {
                    var n = t(r, 2), a = (n[0], n[1]);
                    return e.concat(a);
                }, []).length) return {
                    msg: "开城城市接口为空",
                    category: e.AJAX_ERROR
                };
            }), a;
        }).catch(function() {
            return null;
        });
    },
    getShareInfo: function(e) {
        return r.default.request({
            url: o.POST_LOAD,
            data: e,
            method: "POST"
        }).then(function(e) {
            var t = e.data;
            if (200 === t.code && t.msg) return t.msg;
            throw new Error("请求数据失败");
        }).catch(function() {
            return null;
        });
    },
    getYodaCode: function(e) {
        return r.default.request({
            url: o.YODA_SEND,
            data: e,
            method: "POST"
        }).then(function(e) {
            return e.data;
        }).catch(function() {
            return null;
        });
    }
};