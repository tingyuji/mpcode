function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function t() {
    var e = null, t = (getCurrentPages() || [])[0];
    return t && "function" == typeof t.getTabBar && (e = t.getTabBar()), e;
}

function s() {
    h.emit(f.TABBAR_MESSAGES_CHANGE);
}

var a = require("../common/global-info"), i = e(require("../common/lx")), o = e(require("./config")), n = e(require("./api/index")), c = e(require("../utils/index")), r = require("../utils/im"), l = require("../npm/regenerator-runtime/runtime.js"), u = require("../npm/@mtfe/weapp-privacy-api/index.js").default, h = c.default.Event, f = c.default.EVENT_TYPE, g = {
    CREATED: !1,
    NEW_MESSAGE_NUM: 0,
    IS_LOGGEDIN: !1,
    token: null,
    bottomBarRequested: !1,
    feedsRedDot: !1,
    userProfileDot: !1
}, p = "https://p1.meituan.net/travelcube/3d8d83dd2151f9494f81990d06ec0b2410982.png", d = [ f.PIKE_MESSAGE, function() {
    g.NEW_MESSAGE_NUM = 1, s();
}, Object.create(null) ];

h.on.apply(h, d), h.on(f.UNREAD_MESSAGES_CHANGED, function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0;
    g.NEW_MESSAGE_NUM += e, g.NEW_MESSAGE_NUM < 0 && (g.NEW_MESSAGE_NUM = 0), s(g.NEW_MESSAGE_NUM);
}), h.on(f.MESSAG_PAGE_INIT, function() {
    var e = t();
    e && e.getMessages(g.token), h.off.apply(h, d);
}), h.on(f.USER_LOGIN, function(e) {
    var s = (e || {}).token;
    if (!g.IS_LOGGEDIN && s) {
        g.IS_LOGGEDIN = !0, g.token = s;
        var a = t();
        a && a.getMessages(s), (0, r.initIM)();
    }
}), h.on(f.USER_LOGOUT, function() {
    g.IS_LOGGEDIN = !1, g.NEW_MESSAGE_NUM = 0, s();
    var e = getApp().globalData;
    e.im && e.im.exit();
}), Component({
    data: {
        show: !1,
        selected: 0,
        showSubAlert: !0,
        color: "#999",
        selectedColor: "#FFD100",
        borderStyle: "white",
        list: [],
        feedsRedDot: !1,
        userProfileDot: !1,
        profileFloatingText: "",
        showTalentPublishModal: !1,
        accessableShopFloatingText: "查看可拼场的门店，快速发起想玩的项目",
        showAccessableShopTips: !1
    },
    ready: function() {
        var e = getCurrentPages() || [], t = (e[e.length - 1] || {}).route;
        o.default.find(function(e) {
            return e === t;
        }) ? this.setData({
            show: !0
        }) : this.setData({
            show: !1
        }), !g.bottomBarRequested && this.getBottomBarInfo(), this.setData({
            feedsRedDot: g.feedsRedDot,
            userProfileDot: g.userProfileDot
        });
    },
    show: function() {},
    load: function() {},
    onLoad: function() {},
    onShow: function() {},
    attached: function() {
        var e = this;
        this.initTabBar(), this.triggerAccessableShopTips(), this.setData({
            newMessageNum: g.NEW_MESSAGE_NUM || 0
        }), h.on(f.TABBAR_MESSAGES_CHANGE, function() {
            return e.setData({
                newMessageNum: g.NEW_MESSAGE_NUM || 0
            });
        }), h.on(f.TABBAR_CHANGED, function(t) {
            var s = t.profileFloatingText, a = t.contentRedDot, i = t.userProfileDot, o = t.shopListCateId, n = t.shopListBarType, c = {};
            void 0 !== a && (c.feedsRedDot = a, g.feedsRedDot = a), void 0 === s || e.data.showAccessableShopTips || (c.profileFloatingText = s, 
            g.profileFloatingText = s, s && setTimeout(function() {
                h.emit(f.TABBAR_CHANGED, {
                    profileFloatingText: ""
                });
            }, 5e3)), (void 0 !== i || s) && (c.userProfileDot = i || !!s, g.userProfileDot = i || !!s), 
            o && (getApp().globalData.shopListCateId = o), n && (getApp().globalData.shopListBarType = n), 
            e.setData(c);
        });
    },
    methods: {
        onClosePublishModal: function() {
            this.toggleTalentPublishModal(!1);
        },
        toggleTalentPublishModal: function(e) {
            this.setData({
                showTalentPublishModal: !!e
            });
        },
        talentPublish: function(e) {
            try {
                var t = this;
                u.getSetting({
                    withSubscriptions: !0,
                    success: function(e) {
                        e.subscriptionsSetting.itemSettings && t.setData({
                            showSubAlert: !1
                        });
                    }
                });
                var s = [ "Tf0XliBiG8mUjU39IHFj9sNeo6kosfhUvh4-JZWqMa4", "sJ2c8-bkXGKnzSUD5cB7L-nyigN_BjbTaAlfNB6kXbk", "6IYuGNFeXdz1GtNMyqCapsR0VaWaLN9hSOE9m2pdSys" ];
                u.requestSubscribeMessage({
                    tmplIds: s,
                    success: function(e) {
                        t.data.showSubAlert && [ e[s[0]], e[s[1]], e[s[2]] ].every(function(e) {
                            return "reject" === e;
                        });
                    },
                    fail: function(e) {
                        console.log("user sub fail", e);
                    },
                    complete: function() {
                        t.data.showSubAlert, u.getSetting({
                            withSubscriptions: !0,
                            success: function(e) {
                                t.data.showSubAlert && e.subscriptionsSetting.itemSettings && t.setData({
                                    showSubAlert: !1
                                });
                            }
                        }), u.navigateTo({
                            url: e
                        });
                    }
                });
            } catch (e) {
                console.warn(e);
            }
        },
        groupPublish: function(e) {
            var t = this;
            u.getSetting({
                withSubscriptions: !0,
                success: function(e) {
                    e.subscriptionsSetting.itemSettings && t.setData({
                        showSubAlert: !1
                    });
                }
            });
            var s = [ "yUU1DnDTXPSkN66l0wWAiEsHl7w45NagjMTopr_YVPY", "0odmNMWn8Jofi1dVWfqH_qA9_FaFeIH01f6-KX9OnJ4", "9qfXevoeMubnglnbAfsrtpoBNk5B8X5x2AZFHKjg7dg" ];
            u.requestSubscribeMessage({
                tmplIds: s,
                success: function(e) {
                    if (t.data.showSubAlert) {
                        var a = [ e[s[0]], e[s[1]], e[s[2]] ].every(function(e) {
                            return "reject" === e;
                        });
                        i.default.moduleClick(a ? "b_gc_s40id2db_mc" : "b_gc_w3oapmkw_mc", "", {
                            cid: "c_gc_ehpi86si"
                        });
                    }
                },
                fail: function(e) {
                    console.log("user sub fail", e);
                },
                complete: function() {
                    t.data.showSubAlert && i.default.moduleView("b_gc_lkqzukvj_mv", "", {
                        cid: "c_gc_ehpi86si"
                    }), u.getSetting({
                        withSubscriptions: !0,
                        success: function(e) {
                            t.data.showSubAlert && e.subscriptionsSetting.itemSettings && (t.setData({
                                showSubAlert: !1
                            }), i.default.moduleClick("b_gc_2b14uqfz_mc", "", {
                                cid: "c_gc_ehpi86si"
                            }));
                        }
                    }), u.navigateTo({
                        url: e
                    });
                }
            });
        },
        switchTabToShopListPage: function(e) {
            return function() {
                var t;
                return l.async(function(s) {
                    for (;;) switch (s.prev = s.next) {
                      case 0:
                        if (getApp().globalData.shopListCateId) {
                            s.next = 8;
                            break;
                        }
                        return s.next = 3, l.awrap((0, a.getGlobalInfo)());

                      case 3:
                        (t = s.sent) && t.bottomBarVO && h.emit(f.TABBAR_CHANGED, {
                            shopListCateId: t.bottomBarVO.shopListCateId,
                            shopListBarType: t.bottomBarVO.shopListBarType
                        }), u.switchTab({
                            url: e
                        }), s.next = 9;
                        break;

                      case 8:
                        u.switchTab({
                            url: e
                        });

                      case 9:
                      case "end":
                        return s.stop();
                    }
                }, null, null, null, Promise);
            }();
        },
        switchTab: function(e) {
            var t = e.currentTarget.dataset, s = t.path;
            try {
                -1 !== s.indexOf("shop-list") ? this.switchTabToShopListPage(s) : -1 !== s.indexOf("publish") ? this.groupPublish(s) : (-1 !== s.indexOf("feeds") ? h.emit(f.TABBAR_CHANGED, {
                    contentRedDot: !1
                }) : -1 !== s.indexOf("user-profile") && (this.data.userProfileDot && n.default.viewUserProfileReport({
                    type: 201
                }), h.emit(f.TABBAR_CHANGED, {
                    userProfileDot: !1,
                    profileFloatingText: ""
                })), u.switchTab({
                    url: s,
                    success: function() {
                        s.includes("message") && setTimeout(function() {
                            h.emit(f.REDIRECT_TO_MESSAGE_PAGE);
                        }, 500);
                    }
                }));
            } catch (e) {
                console.warn(e);
            }
            var a = ((getApp().globalData || {}).userInfo || {}).userIdentify;
            i.default.moduleClick("b_gc_9r75xdr3_mc", {
                title: t.title,
                status: void 0 === a ? -9999 : a ? 1 : 0
            });
        },
        getMessages: function(e) {
            n.default.getMessageNum({
                token: e
            }).then(function(e) {
                var t = (e || {}).redDotNum;
                g.NEW_MESSAGE_NUM = t || 0, s();
            });
        },
        getBottomBarInfo: function() {
            (0, a.getGlobalInfo)().then(function(e) {
                e && (g.bottomBarRequested = !0, h.emit(f.TABBAR_CHANGED, e.bottomBarVO));
            }).catch(console.log);
        },
        initTabBar: function() {
            var e = this, t = this.getDefaultTabList();
            !this.data.list.length && (0, a.getGlobalInfo)().then(function(s) {
                var a = s.versionVO.hitGroupVersion, i = (s.bottomBarVO || {}).shopListBarIcon;
                t.forEach(function(e) {
                    -1 !== e.pagePath.indexOf("shop-list") && (e.iconPath = i || p, e.selectedIconPath = i || p);
                }), !1 === a && t.splice(3, 1), e.setData({
                    list: t
                });
            }).catch(function() {
                e.setData({
                    list: t
                });
            }).then(function() {
                e.data.list.forEach(function(e) {
                    i.default.moduleView("b_gc_9r75xdr3_mv", {
                        title: e.title,
                        status: -9999
                    });
                });
            });
        },
        getDefaultTabList: function() {
            return [ {
                pagePath: "/pages/home/index",
                text: "首页",
                title: "首页",
                iconPath: "images/tab_icon_home_normal.png",
                selectedIconPath: "images/tab_icon_home_selected.png",
                className: "home",
                name: "home"
            }, {
                pagePath: "/pages/feeds/index",
                text: "发现",
                title: "发现",
                iconPath: "images/tab_icon_feeds_normal.png",
                selectedIconPath: "images/tab_icon_feeds_selected.png",
                className: "feeds",
                name: "feeds"
            }, {
                pagePath: "/pages/shop-list/index",
                title: "可拼门店",
                iconPath: "images/tab_icon_accessable_shop.png",
                selectedIconPath: "images/tab_icon_accessable_shop.png",
                className: "publish",
                name: "accessableShop"
            }, {
                pagePath: "/pages/message/index",
                text: "消息",
                title: "消息中心",
                iconPath: "images/tab_icon_message_normal.png",
                selectedIconPath: "images/tab_icon_message_selected.png",
                className: "message",
                name: "message"
            }, {
                pagePath: "/pages/user-profile/index/index",
                text: "我的",
                title: "我的",
                iconPath: "images/tab_icon_personal_normal.png",
                selectedIconPath: "images/tab_icon_personal_selected.png",
                className: "personal",
                name: "personal"
            } ];
        },
        refreshSelectedTab: function() {
            var e = this;
            if (clearTimeout(this._refreshTimer), this.data.list.length) {
                var t = getCurrentPages();
                if (t && t.length) for (var s = t[t.length - 1].route, a = 0; a < this.data.list.length; a++) if (("/" + s).includes(this.data.list[a].pagePath)) return void this.setData({
                    selected: a
                });
            } else this._refreshTimer = setTimeout(function() {
                return e.refreshSelectedTab();
            }, 100);
        },
        triggerAccessableShopTips: function() {
            var e = this, t = "pin_accessable_shop_tips_show";
            u.getStorage({
                key: t
            }).catch(function() {
                u.setStorage({
                    key: t,
                    data: !0
                }), e.setData({
                    showAccessableShopTips: !0
                }), setTimeout(function() {
                    e.setData({
                        showAccessableShopTips: !1
                    });
                }, 6e3);
            });
        },
        onClickAccessableShopTip: function() {
            this.setData({
                showAccessableShopTips: !1
            });
        }
    }
});