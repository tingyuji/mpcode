function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var r = e(require("../../npm/@dzfe/wx-api-promisify/dist/index.js")), t = e(require("../../common/config")), a = require("../../npm/@mtfe/weapp-privacy-api/index.js").default, i = {
    GET_MESSAGE_NUM: t.default.dp_domain + "/api/joy/sharerelation/im/reddot",
    VIEW_USER_PROFILE_REPORT: t.default.dp_domain + "/api/joy/sharerelation/global/userset/log"
};

exports.default = {
    getMessageNum: function(e) {
        return new Promise(function(r, t) {
            a.request({
                url: i.GET_MESSAGE_NUM,
                data: e,
                success: function(e) {
                    var t = e.data, a = t.code, i = t.msg;
                    200 === a && r(i);
                },
                fail: t
            });
        });
    },
    viewUserProfileReport: function(e) {
        return r.default.request({
            url: i.VIEW_USER_PROFILE_REPORT,
            data: e
        });
    }
};