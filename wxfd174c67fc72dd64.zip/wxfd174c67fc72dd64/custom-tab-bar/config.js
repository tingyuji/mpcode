Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = [ "pages/home/index", "pages/feeds/index", "pages/message/index", "pages/user-profile/index/index", "pages/shop-list/index" ];