var t = require("../../../../weapp-privacy-api/index.js").default;

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var e = new (function(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}(require("../../utils/api")).default)(), a = {
    data: {
        lbsInfo: {}
    },
    initLbsSDK: function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, e = t.data, a = t.success, o = t.fail;
        this.callBackSuccess = a, this.callBackFail = o, this.setData({
            lbsInfo: {
                data: e,
                show: !0,
                opacity: .5,
                verifyDisa: !0,
                geolocation: [],
                verifyButText: e.verifyButText || "验证",
                changeText: e.changeText || "换一换"
            }
        }), this.getLbsInfo();
    },
    getLbsInfo: function() {
        var t = this, a = this.data, o = a.lbsInfo, i = a.lbsInfo.data, n = i.request_code, s = i.action, r = i.type, c = i.options;
        e.sendInfo({
            request_code: n,
            type: r,
            action: s
        }).then(function(e) {
            var a = e.status, i = e.data, n = e.error;
            if (1 === a) {
                var s = i.prompt, r = s.customHint, c = s.geolocation.items, l = !0, f = !1, d = void 0;
                try {
                    for (var h, u = c[Symbol.iterator](); !(l = (h = u.next()).done); l = !0) h.value.checked = !1;
                } catch (t) {
                    f = !0, d = t;
                } finally {
                    try {
                        !l && u.return && u.return();
                    } finally {
                        if (f) throw d;
                    }
                }
                o.items = c, o.hint = r.operationHint || "哪一个地址与您有关？（单选）", o.opacity = .5, o.verifyDisa = !0, 
                t.setData({
                    lbsInfo: o
                });
            } else t.showAlert(n.message), t.handleLbsError(n);
        }).catch(function() {
            t.showAlert("获取验证数据异常"), e.catchCallback("获取数据异常", 0, "请求获取数据出异常了", c, t);
        });
    },
    bindChange: function() {
        this.getLbsInfo();
    },
    bindVerify: function() {
        var a = this, o = this.data, i = o.lbsInfo, n = o.lbsInfo, s = n.geolocation, r = n.data, c = r.action, l = r.request_code, f = r.type, d = r.options, h = r.listIndex;
        this.data.lbsInfo.verifyDisa = !0, this.setData(this.data), t.showLoading({
            title: "验证中...",
            content: "验证中...",
            mask: !0
        }), e.verify({
            request_code: l,
            type: f,
            action: c,
            options: {
                geolocation: JSON.stringify(s),
                listIndex: h
            }
        }).then(function(o) {
            t.hideLoading(), a.data.lbsInfo.verifyDisa = !1, a.setData(a.data);
            var n = o.status, s = o.data, r = o.error;
            if (1 === n) {
                if (i.show = !1, e.nextVerify(h, s.nextVerifyMethodId)) return;
                a.setData({
                    lbsInfo: i
                }), e.successCallback(s.request_code, s.response_code, d, a);
            } else a.showAlert(r.message), a.handleLbsError(r);
        }).catch(function() {
            a.showAlert("验证异常"), e.catchCallback("验证异常", 0, "请求验证异常了", d, a);
        });
    },
    bindRadioChange: function(t) {
        var e = t.detail.value, a = this.data.lbsInfo;
        a.geolocation[0] = e, a.opacity = 1, a.verifyDisa = !1;
        var o = !0, i = !1, n = void 0;
        try {
            for (var s, r = a.items[Symbol.iterator](); !(o = (s = r.next()).done); o = !0) {
                var c = s.value;
                c.geohash === e ? c.checked = !0 : c.checked = !1;
            }
        } catch (t) {
            i = !0, n = t;
        } finally {
            try {
                !o && r.return && r.return();
            } finally {
                if (i) throw n;
            }
        }
        this.setData({
            lbsInfo: a
        });
    },
    handleLbsError: function(t) {
        var a = this.data.lbsInfo.data.options;
        e.errorCallback(t, a, this.getLbsInfo, this);
    },
    changeVerify: function() {
        var t = this.data.lbsInfo.data;
        e.changeVerify(t);
    },
    onPullDownRefresh: function() {
        t.stopPullDownRefresh();
    }
};

exports.default = a;