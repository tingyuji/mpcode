var t = require("../../../../weapp-privacy-api/index.js").default;

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var a = function(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}(require("../../utils/api")), e = new a.default(), i = {
    data: {
        idcardInfo: {}
    },
    initIdcardSDK: function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, a = t.data, e = void 0 === a ? {} : a, i = t.success, d = t.fail;
        this.callBackSuccess = i, this.callBackFail = d, this.setData({
            idcardInfo: {
                data: e,
                idcardName: "用户",
                show: !0,
                mainTitle: e.mainTitle || "身份验证",
                subTitle: e.subTitle || "为了您的账号安全"
            }
        }), this.getIdcardInfo();
    },
    getIdcardInfo: function() {
        var t = this, a = this.data, i = a.idcardInfo, d = a.idcardInfo.data, r = d.request_code, n = d.action, o = d.type, c = d.options;
        i.idcardInput = "";
        var s = this;
        e.sendInfo({
            request_code: r,
            type: o,
            action: n
        }).then(function(a) {
            var e = a.status, d = a.data, r = a.error;
            if (1 === e) {
                i.idcardName = d.prompt.name;
                var n = d.prompt.customHint || {};
                n && n.operationHint && (i.subTitle = n.operationHint);
            } else t.showAlert(r.message), t.handleError(r);
            s.setData({
                idcardInfo: i
            });
        }).catch(function() {
            t.showAlert("获取验证数据异常"), e.catchCallback("获取数据异常", 0, "请求生日验证信息出异常了", c, t);
        });
    },
    bindIdcardSwitch: function() {
        var i = this, d = this.data, r = d.idcardInfo, n = void 0 === r ? {} : r, o = d.idcardInfo, c = o.idcardInput, s = o.data, l = s.action, u = s.request_code, f = s.type, h = s.options, I = s.listIndex, p = this.data;
        p.idcardInfo.disabled = !0, this.setData(p), t.showLoading({
            title: "验证中...",
            mask: !0
        }), e.verify({
            request_code: u,
            type: f,
            action: l,
            options: {
                identity: a.default.encrypt(u, c),
                listIndex: I
            }
        }).then(function(a) {
            t.hideLoading();
            var d = a.status, r = a.error, o = a.data;
            if (1 === d) {
                if (n.disabled = !1, n.show = !1, e.nextVerify(I, o.nextVerifyMethodId)) return;
                i.setData({
                    idcardInfo: n
                }), e.successCallback(o.request_code, o.response_code, h, i);
            } else i.showAlert(r.message), i.handleError(r);
        }).catch(function() {
            i.showAlert("验证异常"), e.catchCallback("验证异常", 0, "请求验证异常了", h, i);
        });
    },
    handleError: function(t) {
        var a = this.data.idcardInfo.data.options;
        e.errorCallback(t, a, this.getIdcardInfo, this);
    },
    bindidcardInput: function(t) {
        var a = this.data.idcardInfo;
        a.idcardInput = t.detail.value, 6 === t.detail.value.length && this.bindIdcardSwitch(), 
        this.setData({
            idcardInfo: a
        });
    },
    changeVerify: function() {
        var t = this.data.idcardInfo.data;
        e.changeVerify(t);
    }
};

exports.default = i;