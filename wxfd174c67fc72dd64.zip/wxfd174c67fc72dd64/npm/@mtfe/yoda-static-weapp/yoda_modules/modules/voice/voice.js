var e = require("../../../../weapp-privacy-api/index.js").default;

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var t = new (function(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}(require("../../utils/api")).default)(), o = {
    data: {
        voiceInfo: {}
    },
    initVoiceSDK: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = e.data, o = e.success, i = e.fail;
        this.callBackSuccess = o, this.callBackFail = i;
        var a = t.riskLevel.split("|"), n = t.mobile, s = "";
        n && (s = n.substring(0, 3).split("").join(",") + ",五个星," + n.substring(8, 11).split("").join(",")), 
        this.setData({
            voiceInfo: {
                data: t,
                isMobile: n,
                isSend: !1,
                show: !0,
                voicecode: "",
                opacity: .5,
                mobileAria: s,
                sendVoiceDisa: !n,
                verifyDisa: !0,
                switchText: a.length > 1,
                mobileLable: t.mobileLable || "手机号",
                verifyCodeLable: t.verifyCodeLable || "验证码",
                smscode: "",
                sendSmsDisa: !n,
                buttonValue: t.buttonValue || "验证"
            }
        });
    },
    tapSeedVoice: function() {
        var o = this, i = this, a = this.data, n = a.voiceInfo, s = a.voiceInfo, c = s.isMobile, r = s.data, l = r.action, d = r.request_code, f = r.type, u = r.options, v = n.mobile;
        c && (v = "");
        var h = {
            title: "提示",
            content: "您现在方便接电话么",
            cancelText: "不方便",
            cancelButtonText: "不方便",
            cancelColor: "#333",
            confirmText: "方便",
            confirmButtonText: "方便",
            confirmColor: "#000",
            success: function(e) {
                e.confirm && t.sendInfo({
                    request_code: d,
                    type: f,
                    action: l,
                    options: {
                        mobile: v,
                        moduleEnable: !0
                    }
                }).then(function(e) {
                    var t = e.status, a = e.error;
                    1 === t ? (i.showWaitModal(), n.isSend = !0) : (o.showAlert(a.message), i.handleError(a)), 
                    i.setData({
                        voiceInfo: n
                    });
                }).catch(function() {
                    o.showAlert("请求打电话异常"), t.catchCallback("打电话异常了", 0, "请求打电话异常", u, o);
                });
            }
        };
        this.showAlert("您现在方便接电话么"), e.showModal ? e.showModal(h) : e.confirm && e.confirm(h);
    },
    bindVerify: function() {
        var o = this, i = this, a = this.data, n = a.voiceInfo, s = a.voiceInfo, c = s.isMobile, r = s.voicecode, l = s.data, d = l.action, f = l.request_code, u = l.type, v = l.options, h = l.listIndex, b = n.mobile;
        c && (b = ""), e.showLoading({
            title: "验证中...",
            content: "验证中...",
            mask: !0
        }), t.verify({
            request_code: f,
            type: u,
            action: d,
            options: {
                voicecode: r,
                mobile: b,
                listIndex: h
            }
        }).then(function(a) {
            e.hideLoading();
            var n = a.status, s = a.data, c = a.error;
            if (1 === n) {
                if (t.nextVerify(h, s.nextVerifyMethodId)) return;
                t.successCallback(s.request_code, s.response_code, v, o);
            } else i.handleError(c), o.showAlert(c.message);
        }).catch(function() {
            o.showAlert("验证异常"), t.catchCallback("验证异常", 0, "请求验证异常", v, o);
        });
    },
    handleError: function(e) {
        var o = this.data.voiceInfo.data.options;
        t.errorCallback(e, o, this.errorExit, this);
    },
    errorExit: function() {
        var e = this.data.voiceInfo;
        e.voicecode = "", e.opacity = .5, e.verifyDisa = !0, this.setData({
            voiceInfo: e
        });
    },
    showWaitModal: function() {
        var e = this, t = 0, o = e.data.voiceInfo, i = o.codeButText, a = o.sendVoiceDisa, n = setInterval(function() {
            var o = e.data.voiceInfo;
            i = 60 - (t += 1) + "s后请重试", a = !0, o.sendVoiceDisa = a, o.codeButText = i, e.setData({
                voiceInfo: o
            }), 60 === t && (o.codeButText = "发送验证码", o.sendVoiceDisa = !1, e.setData({
                voiceInfo: o
            }), clearInterval(n));
        }, 1e3);
    },
    bindMobileInput: function(e) {
        var t = e.detail.value, o = this.data.voiceInfo;
        o.mobile = t, o.sendVoiceDisa = 11 !== t.length, this.setData({
            voiceInfo: o
        });
    },
    bindVoiceCodeInput: function(e) {
        var t = e.detail.value, o = this.data.voiceInfo;
        o.voicecode = t, o.opacity = t.length > 1 && o.isSend ? 1 : .5, this.setData({
            voiceInfo: o
        });
    },
    yodaEvent: function(e) {
        var o = e.detail, i = o.status, a = o.code, n = o.msg;
        if (1 === i) this.tapSeedVoice(); else {
            var s = this.data.voiceInfo.data.options;
            t.errorCallback({
                code: a,
                message: n
            }, s, this.errorExit, this);
        }
    },
    changeVerify: function() {
        var e = this.data.voiceInfo.data;
        t.changeVerify(e);
    }
};

exports.default = o;