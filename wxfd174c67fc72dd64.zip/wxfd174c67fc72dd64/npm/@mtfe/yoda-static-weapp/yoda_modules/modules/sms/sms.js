var t = require("../../../../weapp-privacy-api/index.js").default;

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var s = new (function(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}(require("../../utils/api")).default)(), e = {
    data: {
        smsInfo: {}
    },
    initSmsSDK: function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, s = t.data, e = t.success, a = t.fail;
        this.callBackSuccess = e, this.callBackFail = a;
        var i = s.mobile, o = "";
        i && (o = i.substring(0, 3).split("").join(",") + ",五个星," + i.substring(8, 11).split("").join(",")), 
        this.setData({
            smsInfo: {
                data: s,
                isMobile: i,
                isSend: !1,
                show: !0,
                mobileLable: s.mobileLable || "手机号",
                verifyCodeLable: s.verifyCodeLable || "验证码",
                mobileAria: o,
                smscode: "",
                opacity: .5,
                sendSmsDisa: !s.mobile,
                verifyDisa: !0,
                buttonValue: s.buttonValue || "验证"
            }
        }), "true" === s.autoSend && this.tapSeedSmS();
    },
    tapSeedSmS: function() {
        var e = this, a = this, i = this.data, o = i.smsInfo, n = i.smsInfo, r = n.isMobile, d = n.data, l = d.action, c = d.request_code, f = d.type, m = d.options, u = o.mobile;
        !!t.mtShare && t.getRiskControlFingerprint({
            success: function(t) {
                var s = t.fingerprint;
                o.fp = s, e.setData({
                    smsInfo: o
                });
            }
        }), r && (u = ""), t.showLoading({
            title: "发送中...",
            content: "发送中...",
            mask: !0
        }), s.sendInfo({
            request_code: c,
            type: f,
            action: l,
            options: {
                mobile: u,
                moduleEnable: !0
            }
        }).then(function(s) {
            t.hideLoading();
            var i = s.status, n = s.error;
            1 === i ? (t.showToast({
                title: "已发送短信",
                content: "已发送短信"
            }), e.showAlert("已发送短信"), a.showWaitModal(), o.isSend = !0) : (e.showAlert(n.message), 
            a.smsHandleError(n)), a.setData({
                smsInfo: o
            });
        }).catch(function() {
            e.showAlert("发送短信异常"), s.catchCallback("发送短信异常", 0, "请求发送短信异常", m, e);
        });
    },
    bindSmsVerify: function() {
        var e = this, a = this, i = this.data, o = i.smsInfo, n = i.smsInfo, r = n.isMobile, d = n.isSend, l = n.smscode, c = n.opacity, f = n.fp, m = n.data, u = m.action, h = m.request_code, p = m.type, b = m.options, v = m.listIndex, I = r ? "" : o.mobile;
        d && 1 === c && (t.showLoading({
            title: "验证中...",
            content: "验证中...",
            mask: !0
        }), s.verify({
            request_code: h,
            type: p,
            action: u,
            options: {
                smscode: l,
                mobile: I,
                listIndex: v,
                fingerprint: f
            }
        }).then(function(i) {
            t.hideLoading();
            var n = i.status, r = i.data, d = i.error;
            if (1 === n) {
                if (o.show = !1, s.nextVerify(v, i.data && i.data.nextVerifyMethodId)) return;
                s.successCallback(r.request_code, r && r.response_code, b, e);
            } else e.showAlert(d.message), a.smsHandleError(d);
        }).catch(function() {
            e.showAlert("验证异常"), s.catchCallback("验证异常", 0, "请求验证异常", b, e);
        }));
    },
    smsHandleError: function(t) {
        var e = this.data.smsInfo.data.options;
        s.errorCallback(t, e, this.errorExit, this);
    },
    errorExit: function() {
        var t = this.data.smsInfo;
        t.smscode = "", t.opacity = .5, t.verifyDisa = !0, this.setData({
            smsInfo: t
        });
    },
    showWaitModal: function() {
        var t = this, s = 0, e = t.data.smsInfo, a = e.codeButText, i = e.sendSmsDisa, o = setInterval(function() {
            var e = t.data.smsInfo;
            a = 60 - (s += 1) + "s后请重试", i = !0, e.sendSmsDisa = i, e.codeButText = a, t.setData({
                smsInfo: e
            }), 60 === s && (e.sendSmsDisa = !1, e.codeButText = "发送验证码", t.setData({
                smsInfo: e
            }), clearInterval(o));
        }, 1e3);
    },
    yodaEvent: function(t) {
        var e = t.detail, a = e.status, i = e.code, o = e.msg;
        if (1 === a) this.tapSeedSmS(); else {
            var n = this.data.smsInfo.data.options;
            s.errorCallback({
                code: i,
                message: o
            }, n, this.errorExit, this);
        }
    },
    bindMobileInput: function(t) {
        var s = t.detail.value.trim(), e = this.data.smsInfo;
        e.mobile = s, e.sendSmsDisa = 11 !== s.length, this.setData({
            smsInfo: e
        });
    },
    bindSmsCodeInput: function(t) {
        var s = t.detail.value, e = this.data.smsInfo;
        e.smscode = s, e.opacity = s.length > 1 && e.isSend ? 1 : .5, this.setData({
            smsInfo: e
        });
    },
    changeVerify: function() {
        var t = this.data.smsInfo.data;
        s.changeVerify(t);
    }
};

exports.default = e;