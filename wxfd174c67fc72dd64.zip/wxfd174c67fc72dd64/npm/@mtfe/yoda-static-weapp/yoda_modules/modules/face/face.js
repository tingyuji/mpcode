var e = require("../../../../weapp-privacy-api/index.js").default;

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var a = require("./../../utils/union"), t = new (function(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}(require("./../../utils/api")).default)(), n = {
    data: {},
    initFaceSDK: function() {
        var a = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = a.data, n = a.success, o = a.fail, s = this;
        this.callBackSuccess = n, this.callBackFail = o;
        var c = {
            data: t,
            show: !0,
            isYodaCamera: !1,
            isWxCamera: !0,
            step: 1,
            faceAction: [],
            faceCameraIndex: -1,
            faceUrl: "https://s3plus.meituan.net/v1/mss_f231eb419c414559a1837748d11d4312/yoda-resources/face/(0,0,0).png",
            s3: {},
            countDown: 3,
            faceUploadList: [],
            faceUploadPromise: [],
            responseData: {},
            provision: "<<人脸识别服务通用规则>>",
            isCheck: !1,
            isShowProvision: !1,
            isShowProvisionTip: !1,
            resultButton: "继续",
            canResultButton: !0,
            retryList: [ 121079, 121084, 121008, 121100, 121101, 121102, 130003 ],
            s3plusFaceUrl: "https://s3plus.meituan.net/v1/mss_f231eb419c414559a1837748d11d4312/yoda-resources/face/"
        };
        s.setData({
            faceInfo: c
        }), !!e.mtShare && e.getRiskControlFingerprint({
            success: function(e) {
                var a = e.fingerprint;
                c.fp = a, s.setData({
                    faceInfo: c
                });
            }
        }), this.setCamareOpen(!0);
    },
    setCamareOpen: function(a) {
        var t = this, n = this.data.faceInfo;
        e.getSetting({
            success: function(o) {
                o.authSetting["scope.camera"] ? (n.isYodaCamera = !0, n.isWxCamera = !1, n.ctx = e.createCameraContext({
                    _mt: {
                        sceneToken: "jcyf-620357e5220a4373"
                    }
                }), t.setData({
                    faceInfo: n
                }), a || t.getFaceInfo()) : e.authorize({
                    _mt: {
                        sceneToken: "jcyf-620357e5220a4373"
                    },
                    scope: "scope.camera",
                    fail: function() {
                        e.showModal({
                            title: "提示",
                            content: "若点击不授权，将无法完成人脸验证",
                            cancelText: "不授权",
                            cancelColor: "#999",
                            confirmText: "授权",
                            confirmColor: "#f94218",
                            success: function(a) {
                                a.confirm ? e.openSetting() : (n.step = 4, n.resultButton = "我知道了", n.responseData = {
                                    status: 0,
                                    error: {
                                        message: "获取摄像头权限失败",
                                        code: 122001
                                    }
                                }, t.setData({
                                    faceInfo: n
                                }));
                            }
                        });
                    }
                });
            }
        });
    },
    cameraSuccess: function() {
        var e = this.data.faceInfo;
        e.isWxCamera = !0, this.setData({
            faceInfo: e
        });
    },
    cameraError: function(e) {
        console.log("cameraError ====> ", e);
    },
    readGuideHandler: function(e) {
        var a = this.data.faceInfo;
        e.detail.value.length > 0 ? a.isCheck = !0 : a.isCheck = !1, this.setData({
            faceInfo: a
        });
    },
    showProvision: function() {
        var e = this.data.faceInfo;
        e.isShowProvision = !0, this.setData({
            faceInfo: e
        });
    },
    hideProvision: function() {
        var e = this.data.faceInfo;
        e.isShowProvision = !1, this.setData({
            faceInfo: e
        });
    },
    onImageSuccess: function(e) {
        console.log("imageSuccess:", e.detail);
    },
    onJumpProvision: function() {
        e.navigateTo({
            url: "./public?type=face"
        });
    },
    getFaceInfo: function() {
        var n = this, o = this.data, s = o.faceInfo, c = o.faceInfo, i = c.data, r = i.request_code, f = i.action, u = i.type, l = i.options, d = i.needReadLegalProvision, h = c.retryList, p = c.isYodaCamera;
        if (!c.isCheck && d) return s.isShowProvisionTip = !0, setTimeout(function() {
            s.isShowProvisionTip = !1, n.setData({
                faceInfo: s
            });
        }, 3e3), void this.setData({
            faceInfo: s
        });
        var m = this;
        if (p) {
            e.showLoading({
                title: "信息获取...",
                mask: !0
            });
            var I = {
                request_code: r,
                type: u,
                action: f
            };
            d && (I.options = {
                readLegalProvision: 1
            }), t.sendInfo(I).then(function(t) {
                e.hideLoading({
                    fail: function() {}
                });
                var n = t.status, o = t.data, c = t.error;
                1 === n ? (s.canResultButton = !0, s.faceAction = o.prompt.faceAction, s.faceAction.unshift({
                    color: "(0,0,0)"
                }), s.s3 = JSON.parse(a.common.otiak(o.prompt.s3, r)), s.step = 2, m.setData({
                    faceInfo: s
                }), m.faceCameraTimeOut()) : (s.step = 4, s.canResultButton = !0, s.resultButton = -1 !== h.indexOf(c.code) ? "再试一次" : "我知道了", 
                s.responseData = {
                    status: 0,
                    error: c
                }, m.setData({
                    faceInfo: s
                }));
            }).catch(function() {
                t.catchCallback("获取数据异常", 0, "请求光线人脸信息出错了", l, n);
            });
        } else m.setCamareOpen();
    },
    faceCameraTimeOut: function() {
        var a = this, t = this.data.faceInfo, n = setInterval(function() {
            var e = t.countDown;
            t.countDown = e - 1, a.setData({
                faceInfo: t
            }), t.countDown <= 0 && clearInterval(n);
        }, 700);
        setTimeout(function() {
            e.getScreenBrightness({
                success: function(t) {
                    e.setScreenBrightness({
                        value: 1
                    }), a.faceCameraStart(t.value);
                }
            });
        }, 3e3);
    },
    faceCameraStart: function(a) {
        var t = this, n = this.data.faceInfo, o = n.faceCameraIndex;
        n.faceCameraIndex = o + 1, n.faceAction[n.faceCameraIndex] && n.faceAction[n.faceCameraIndex].color ? n.faceUrl = "" + n.s3plusFaceUrl + n.faceAction[o + 1].color + ".png" : n.faceUrl = n.s3plusFaceUrl + "(0,0,0).png", 
        this.setData({
            faceInfo: n
        }), n.faceCameraIndex < n.faceAction.length ? setTimeout(function() {
            t.faceTackCamera(a);
        }, 500) : (e.setScreenBrightness({
            value: a
        }), this.faceLoading());
    },
    faceTackCamera: function(t) {
        var n = this, o = n.data, s = o.faceInfo, c = o.faceInfo.data.request_code;
        s.ctx.takePhoto({
            _mt: {
                sceneToken: "jcyf-620357e5220a4373"
            },
            quality: "high",
            success: function(o) {
                var s = e.getFileSystemManager({
                    _mt: {
                        sceneToken: "jcyf-d07c5c9a426edd09"
                    }
                }).readFileSync(o.tempImagePath, "base64"), i = a.common.kaito(s, c);
                n.faceCameraUpload(i, t);
            },
            fail: function() {
                s.step = 1, s.faceCameraIndex = -1, s.faceCameraNumber = 4, n.setData({
                    faceInfo: s
                });
            }
        });
    },
    faceCameraUpload: function(a, t) {
        var n = this, o = this.data, s = o.faceInfo, c = o.faceInfo, i = c.s3, r = c.faceUploadList, f = this.getFileName();
        if (f) {
            var u = {
                AWSAccessKeyId: i.accessid,
                policy: i.policy,
                signature: i.signature,
                key: i.dir + f
            }, l = e.getFileSystemManager({
                _mt: {
                    sceneToken: "jcyf-d07c5c9a426edd09"
                }
            }), d = e.env.USER_DATA_PATH + "/tmp_base64src.facePicture";
            l.writeFile({
                _mt: {
                    sceneToken: "jcyf-d07c5c9a426edd09"
                },
                filePath: d,
                data: a,
                encoding: "utf8",
                success: function() {
                    r.push(f), s.faceUploadPromise.push(n.uploadPromise(i.url, d, u)), n.faceCameraStart(t), 
                    n.setData({
                        faceInfo: s
                    });
                },
                fail: function() {
                    s.step = 4, s.resultButton = "我知道了", s.responseData = {
                        status: 0,
                        error: {
                            message: "文件操作失败",
                            code: 99999
                        }
                    }, n.setData({
                        faceInfo: s
                    });
                }
            });
        }
    },
    uploadPromise: function(a, t, n) {
        return new Promise(function(o, s) {
            e.uploadFile({
                url: a,
                filePath: t,
                name: "file",
                formData: n,
                success: function(e) {
                    e.statusCode < 300 ? o() : s();
                },
                fail: function() {
                    s();
                }
            });
        }).catch(function(e) {
            throw console.log("new Promise ===> ", e), e;
        });
    },
    faceLoading: function() {
        var e = this, a = this.data.faceInfo, t = this;
        a.step = 3, this.setData({
            faceInfo: a
        }), setTimeout(function() {
            3 === a.step && (a.step = 4, a.resultButton = "我知道了", a.responseData = {
                status: 0,
                error: {
                    message: "未知异常",
                    code: 99999
                }
            }, t.setData({
                faceInfo: a
            }));
        }, 3e4), Promise.all(a.faceUploadPromise).then(function() {
            e.bindVerify();
        }).catch(function() {
            a.step = 4, a.resultButton = "再试一次", a.responseData = {
                status: 0,
                error: {
                    message: "数据上传失败",
                    code: 130003
                }
            }, a.faceUploadPromise.splice(0), t.setData({
                faceInfo: a
            });
        });
    },
    bindVerify: function() {
        var e = this, n = this, o = this.data, s = o.faceInfo, c = o.faceInfo, i = c.faceUploadList, r = c.fp, f = c.data, u = f.action, l = f.request_code, d = f.type, h = f.listIndex, p = c.retryList;
        s.step = 4;
        var m = a.common.kaito(JSON.stringify(i), l);
        t.verify({
            request_code: l,
            type: d,
            action: u,
            options: {
                face: m,
                fingerprint: r,
                listIndex: h
            }
        }).then(function(a) {
            var n = a.status, o = a.error, c = a.data;
            if (s.responseData = a, 1 !== n) s.resultButton = -1 !== p.indexOf(o.code) ? "再试一次" : "我知道了"; else {
                if (t.nextVerify(h, c.nextVerifyMethodId)) return;
                s.resultButton = "继续";
            }
            s.faceUploadPromise.splice(0), e.setData({
                faceInfo: s
            });
        }).catch(function() {
            s.responseData = {
                status: 0,
                error: {
                    message: "验证请求异常",
                    code: 99999
                }
            }, n.setData({
                faceInfo: s
            });
        });
    },
    getFileName: function() {
        var e = this.data.faceInfo, a = e.faceAction, t = e.faceCameraIndex, n = Date.parse(new Date()) / 1e3;
        if (a[t] && a[t].color) {
            var o = a[t].color.slice(1, -1).split(",");
            return "v_1_hw_1024_768_cv_" + o[0] + "_" + o[1] + "_" + o[2] + "_ts_" + n + "_tp_jpg";
        }
        return null;
    },
    resultButtonHandler: function() {
        var e = this.data, a = e.faceInfo, n = e.faceInfo, o = n.responseData, s = n.data, c = s.options, i = s.listIndex, r = o;
        if (1 === o.status) {
            if (a.show = !1, t.nextVerify(i, r.nextVerifyMethodId)) return;
            this.setData({
                faceInfo: a
            }), t.successCallback(r.data.request_code, r.data.response_code, c);
        } else this.handleError(r.error);
    },
    changeVerify: function() {
        var e = this.data.faceInfo.data;
        t.changeVerify(e);
    },
    handleError: function(e) {
        var a = this.data, n = a.faceInfo, o = a.faceInfo, s = o.data.options, c = o.retryList;
        o.canResultButton && (n.canResultButton = !1, -1 !== c.indexOf(e.code) && (n.faceAction = [], 
        n.faceCameraIndex = -1, n.faceUploadList = [], n.countDown = 3), this.setData({
            faceInfo: n
        }), t.errorCallback(e, s, this.getFaceInfo, this, "face"));
    },
    onPullDownRefresh: function() {
        e.stopPullDownRefresh();
    }
};

exports.default = n;