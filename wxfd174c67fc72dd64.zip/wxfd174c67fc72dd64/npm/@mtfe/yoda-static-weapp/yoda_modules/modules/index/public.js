Page({
    data: {
        url: ""
    },
    onUnload: function() {
        this.getOpenerEventChannel().emit("backEvent", {});
    },
    onLoad: function(e) {
        if (e.responseCode && console.log("这是验证成功回调了", e), "help" === e.type) console.log("publish query ===>", e), 
        this.setData({
            url: "https://verify.meituan.com/feedback/manmachine/#/?requestCode=" + e.requestCode
        }); else if ("face" === e.type) this.setData({
            url: "https://rules-center.meituan.com/m/detail/guize/2"
        }); else if (e.requestCode) {
            var t = e.env || "", n = [ "requestCode=" + e.requestCode, "succCallbackKNBFun=mp_call", "env=" + t, "listIndex=" + (e.listIndex || 0) ];
            n = n.join("&");
            var s = ({
                staging: "https://verify.inf.st.meituan.com",
                dev: "https://verify.inf.dev.meituan.com",
                test: "https://verify.inf.test.meituan.com"
            }[t] || "https://verify.meituan.com") + "/v2/app/general_page?" + n;
            this.setData({
                url: s
            });
        }
    },
    onmessage: function(e) {
        var t = e.detail.data, n = t[t.length - 1];
        console.log("postamessage", n), this.getOpenerEventChannel().emit("someEvent", n);
    }
});