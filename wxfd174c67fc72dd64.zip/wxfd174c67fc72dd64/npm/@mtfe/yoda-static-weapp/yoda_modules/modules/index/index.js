function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

var t = require("../../../../weapp-privacy-api/index.js").default;

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.yodaUrl = void 0;

var a = e(require("./../sms/sms")), i = e(require("./../voice/voice")), s = e(require("./../lbs/lbs")), n = e(require("./../buying/buying")), o = e(require("./../group/group")), d = e(require("./../names/names")), c = e(require("./../birthday/birthday")), r = e(require("./../idcard/idcard")), u = e(require("./../password/password")), l = e(require("./../face/face")), f = e(require("../../utils/api")), p = require("../../utils/config"), b = new f.default(), g = exports.yodaUrl = function(e) {
    var t = "https://verify.meituan.com";
    switch (e) {
      case "staging":
        t = "https://verify.inf.st.meituan.com";
        break;

      case "test":
        t = "https://verify.inf.test.meituan.com";
        break;

      case "dev":
        t = "https://verify.inf.dev.meituan.com";
    }
    return getApp().globalData || (getApp().globalData = {}), getApp().globalData.yodaUrl = t, 
    t;
}, y = {
    data: {
        show: 0,
        bgcolor: "#FFFFFF",
        isOpenAccessibility: !1,
        isAlert: !1,
        alertText: ""
    },
    onReady: function() {
        var e = this;
        console.log("modules/index/index onReady"), "function" == typeof t.checkIsOpenAccessibility && t.checkIsOpenAccessibility({
            success: function(a) {
                var i = t.getDeviceInfo();
                e.setData({
                    isOpenAccessibility: a.open && "iPhone" === i.brand
                });
            },
            fail: function() {}
        });
    },
    yodaRef: function(e) {
        this.Yoda = e;
    },
    onLoad: function(e) {
        var a = this, i = e.requestCode, s = e.navigate, n = e.delta, o = e.env, d = e.appletsfp;
        o && g(o);
        var c = !!t.mtShare;
        if (this.setData({
            isMMP: c
        }), i) b.getPageData(i, 1).then(function(e) {
            var i = e.status, c = e.data;
            if (0 === i) {
                var r = e.error;
                t.showToast({
                    icon: "none",
                    title: "系统状态异常",
                    content: "系统状态异常",
                    complete: function() {
                        b.failCallback(r.code, r.message, {});
                    }
                });
            } else {
                var u = [];
                c.riskLevel.split("|").forEach(function(e) {
                    u.push(e.split(","));
                }), 1 === u.length ? c.type = u[0][0] : u.length > 1 && (c.type = -1), c.listIndex = c.listIndex || 0, 
                "GROUP" !== c.category && "MULTIPLE" !== c.category || (c.riskNameGroup = JSON.parse(c.riskLevelInfo), 
                u[0].forEach(function(e) {
                    p.modules[e] || (c.type = -2);
                })), c.riskGroup = u, a.setData({
                    show: Number(c.type)
                }), c.env = o, c.appletsfp = d, c.options = {
                    navigate: s,
                    delta: n
                }, a.setPageStore(c);
            }
        }).catch(function() {
            t.showToast({
                title: "pageData请求异常",
                content: "pageData请求异常",
                icon: "none",
                duration: 3e3
            });
        }); else {
            var r = getApp().globalData.yodaPageData;
            r && (r.listIndex = r.listIndex || 0, "GROUP" !== r.category && "MULTIPLE" !== r.category || r.riskGroup[0].forEach(function(e) {
                p.modules[e] || (r.type = -2);
            }), a.setData({
                show: Number(r.type)
            }), a.setPageStore(r));
        }
    },
    onUnload: function(e) {
        "function" == typeof getApp().globalData.YodaUnload && getApp().globalData.YodaUnload(e);
    },
    showAlert: function(e) {
        var t = this;
        setTimeout(function() {
            t.setData({
                isAlert: !0,
                alertText: e
            });
        }, 500), setTimeout(function() {
            t.setData({
                isAlert: !1,
                alertText: ""
            });
        }, 3e3);
    },
    setPageStore: function(e) {
        getApp().globalData.yodaPageData = e, this.gotoYodaPage(Number(e.type), {
            data: e
        });
    },
    gotoYodaPage: function(e, t) {
        var f = this, p = t.data.request_code, g = t.data.env, y = t.data.appletsfp || "";
        switch (!this.Yoda && this.selectComponent && (f.Yoda = this.selectComponent("#yoda")), 
        e) {
          case -1:
            Object.keys(o.default).forEach(function(e) {
                "data" === e ? Object.assign(f.data, o.default.data) : f[e] = o.default[e];
            }), f.initGroupSDK(t);
            break;

          case 4:
            Object.keys(a.default).forEach(function(e) {
                "data" === e ? Object.assign(f.data, a.default.data) : f[e] = a.default[e];
            }), f.initSmsSDK(t);
            break;

          case 18:
            Object.keys(u.default).forEach(function(e) {
                "data" === e ? Object.assign(f.data, u.default.data) : f[e] = u.default[e];
            }), f.initPasswordSDK(t);
            break;

          case 40:
            Object.keys(i.default).forEach(function(e) {
                "data" === e ? Object.assign(f.data, i.default.data) : f[e] = i.default[e];
            }), f.initVoiceSDK(t);
            break;

          case 69:
            Object.keys(n.default).forEach(function(e) {
                "data" === e ? Object.assign(f.data, n.default.data) : f[e] = n.default[e];
            }), f.initBuyingSDK(t);
            break;

          case 79:
            Object.keys(s.default).forEach(function(e) {
                "data" === e ? Object.assign(f.data, s.default.data) : f[e] = s.default[e];
            }), f.initLbsSDK(t);
            break;

          case 89:
            Object.keys(c.default).forEach(function(e) {
                "data" === e ? Object.assign(f.data, c.default.data) : f[e] = c.default[e];
            }), f.initBirthdaySDK(t);
            break;

          case 100:
            Object.keys(d.default).forEach(function(e) {
                "data" === e ? Object.assign(f.data, d.default.data) : f[e] = d.default[e];
            }), f.initNamesSDK(t);
            break;

          case 110:
            Object.keys(r.default).forEach(function(e) {
                "data" === e ? Object.assign(f.data, r.default.data) : f[e] = r.default[e];
            }), f.initIdcardSDK(t);
            break;

          case 117:
            Object.keys(l.default).forEach(function(e) {
                "data" === e ? Object.assign(f.data, l.default.data) : f[e] = l.default[e];
            }), f.initFaceSDK(t);
            break;

          case 1:
          case 71:
            f.Yoda.init({
                requestCode: p,
                env: g,
                appletsfp: y,
                isPage: !0
            });
            break;

          case 130:
            f.setData({
                bgcolor: "#efefef"
            }), f.Yoda.init({
                requestCode: p,
                env: g,
                appletsfp: y,
                isPage: !0
            });
            break;

          default:
            b.toWebView({
                requestCode: p,
                env: g,
                listIndex: t.data.listIndex
            });
        }
    },
    yodaEvent: function(e) {
        var t = e;
        e.detail && (t = e.detail);
        var a = t, i = a.status, s = a.responseCode, n = a.requestCode, o = a.code, d = a.msg;
        b.callWebViewAndComponent({
            status: i,
            requestCode: n,
            responseCode: s,
            code: o,
            msg: d
        }), this.setData({
            bgcolor: "#FFFFFF"
        });
    },
    bindNamesInput: function() {},
    bindbirthdayInput: function() {},
    bindMobileInput: function() {},
    bindSmsCodeInput: function() {},
    bindVoiceCodeInput: function() {}
};

Page(y);