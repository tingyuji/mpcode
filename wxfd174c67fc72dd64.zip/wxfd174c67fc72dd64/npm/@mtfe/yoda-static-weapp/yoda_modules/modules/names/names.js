var e = require("../../../../weapp-privacy-api/index.js").default;

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var t = function(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}(require("../../utils/api")), a = new t.default(), n = {
    data: {
        namesInfo: {}
    },
    initNamesSDK: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = e.data, a = e.success, n = e.fail;
        this.callBackSuccess = a, this.callBackFail = n, this.setData({
            namesInfo: {
                disabled: !0,
                data: t,
                show: !0,
                opacity: .5,
                isSend: !1,
                namesInput: "",
                mobilePlaceholder: t.mobilePlaceholder || "手机号",
                codePlaceholder: t.codePlaceholder || "验证码",
                mainTitle: t.mainTitle || "为了您的账号安全",
                subTitle: t.subTitle || "请补全以下信息完成验证",
                buttonValue: t.buttonValue || "验证"
            }
        }), this.getNamesInfo();
    },
    getNamesInfo: function() {
        var e = this, t = this.data, n = t.namesInfo, s = t.namesInfo.data, i = s.request_code, o = s.action, r = s.type, l = s.options, d = this;
        n.namesInput = "", a.sendInfo({
            request_code: i,
            type: r,
            action: o
        }).then(function(t) {
            var a = t.status, s = t.data, i = t.error;
            if (1 === a) {
                var o = s.prompt.name, r = "*" !== o[0], l = o.replace(/\*/g, "").length, c = r ? 0 : o.length - l, f = r ? l : o.length;
                n.namesClear = o.substring(c, f), n.namesEncryptLen = o.length - l, n.isNamesFirst = r, 
                n.namesMessage = s.prompt.message, n.isSend = !0, n.fontSize = o.length <= 10 ? 50 : 40, 
                n.fontSize = o.length > 15 ? 32 : n.fontSize, n.opacity = .5;
                var h = s.prompt.customHint || {};
                h && h.operationHint && (n.mainTitle = h.operationHint), h && h.infoHint && (n.subTitle = h.infoHint);
            } else e.showAlert(i.message), e.handleError(i);
            d.setData({
                namesInfo: n
            });
        }).catch(function() {
            e.showAlert("获取验证信息异常"), a.catchCallback("获取数据异常", 0, "请求姓名验证信息出异常了", l, e);
        });
    },
    bindNamesSwitch: function() {
        var n = this, s = this.data, i = s.namesInfo, o = void 0 === i ? {} : i, r = s.namesInfo, l = r.isNamesFirst, d = r.namesClear, c = r.namesInput, f = r.isSend, h = r.opacity, u = r.data, m = u.action, p = u.request_code, I = u.type, g = u.options, b = u.listIndex, v = l ? d + c : c + d;
        if (f && 1 === h) {
            var y = this.data;
            y.namesInfo.disabled = !0, this.setData(y), e.showLoading({
                title: "验证中...",
                mask: !0
            }), a.verify({
                request_code: p,
                type: I,
                action: m,
                options: {
                    filledName: t.default.encrypt(p, v),
                    listIndex: b
                }
            }).then(function(t) {
                (y = n.data).namesInfo.disabled = !1, n.setData(y), e.hideLoading();
                var s = t.status, i = t.error, r = t.data;
                if (1 === s) {
                    if (o.show = !1, a.nextVerify(b, r.nextVerifyMethodId)) return;
                    n.setData({
                        namesInfo: o
                    }), a.successCallback(r.request_code, r.response_code, g, n);
                } else n.showAlert(i.message), n.handleError(i);
            }).catch(function() {
                n.showAlert("验证异常"), a.catchCallback("验证异常", 0, "请求验证异常了", g, n);
            });
        }
    },
    handleError: function(e) {
        var t = this.data.namesInfo.data.options;
        a.errorCallback(e, t, this.getNamesInfo, this);
    },
    bindNamesInput: function(e) {
        var t = this.data.namesInfo, a = e.detail.value, n = .5, s = !0;
        a.length === t.namesEncryptLen && (n = 1, s = !1), t.namesInput = a, t.opacity = n, 
        t.disabled = s, this.setData({
            namesInfo: t
        });
    },
    changeVerify: function() {
        var e = this.data.namesInfo.data;
        a.changeVerify(e);
    }
};

exports.default = n;