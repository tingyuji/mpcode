var t = require("../../../../weapp-privacy-api/index.js").default;

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var a = function(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}(require("../../utils/api")), i = new a.default(), e = {
    data: {
        birthdayInfo: {}
    },
    initBirthdaySDK: function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, a = t.data, i = void 0 === a ? {} : a, e = t.success, n = t.fail;
        this.callBackSuccess = e, this.callBackFail = n, this.setData({
            birthdayInfo: {
                data: i,
                disabled: !0,
                show: !0,
                opacity: .5,
                isSend: !1,
                mainTitle: i.mainTitle || "请在下方填写您",
                subTitle: i.subTitle || "身份证上8位生日号码",
                inputPlaceholder: i.inputPlaceholder || "例如：19891020",
                buttonValue: i.buttonValue || "验证"
            }
        }), this.getBirthdayInfo();
    },
    getBirthdayInfo: function() {
        var t = this, a = this.data, e = a.birthdayInfo, n = a.birthdayInfo.data, r = n.request_code, o = n.action, d = n.type, s = n.options;
        e.birthdayInput = "";
        var h = this;
        i.sendInfo({
            request_code: r,
            type: d,
            action: o
        }).then(function(a) {
            var i = a.status, n = a.data, r = a.error;
            if (1 === i) {
                e.isSend = !0, e.opacity = .5;
                var o = n.prompt;
                o && o.customHint && o.customHint.operationHint && (e.mainTitle = o.customHint.operationHint);
            } else t.showAlert(r.message), t.handleError(r);
            h.setData({
                birthdayInfo: e
            });
        }).catch(function() {
            t.showAlert("获取验证数据异常"), i.catchCallback("获取数据异常", 0, "请求生日验证信息出异常了", s, t);
        });
    },
    bindBirthdaySwitch: function() {
        var e = this, n = this.data, r = n.birthdayInfo, o = n.birthdayInfo, d = o.isSend, s = o.birthdayInput, h = o.opacity, c = o.data, l = c.action, u = c.request_code, f = c.type, y = c.options, b = c.listIndex;
        if (d && 1 === h) {
            r.disabled = !0, this.setData({
                birthdayInfo: r
            }), t.showLoading({
                title: "验证中...",
                mask: !0
            });
            var p = a.default.encrypt(u, s);
            i.verify({
                request_code: u,
                type: f,
                action: l,
                options: {
                    birthday: p,
                    listIndex: b
                }
            }).then(function(a) {
                t.hideLoading();
                var n = a.status, o = a.error, d = a.data;
                if (1 === n) {
                    if (r.disabled = !1, r.show = !1, i.nextVerify(b, d.nextVerifyMethodId)) return;
                    e.setData({
                        birthdayInfo: r
                    }), i.successCallback(d.request_code, d.response_code, y, e);
                } else e.showAlert(o.message), e.handleError(o);
            }).catch(function() {
                e.showAlert("验证异常"), i.catchCallback("验证异常", 0, "请求验证异常了", y, e);
            });
        }
    },
    handleError: function(t) {
        var a = this.data.birthdayInfo.data.options;
        i.errorCallback(t, a, this.getBirthdayInfo, this);
    },
    bindbirthdayInput: function(t) {
        var a = this.data.birthdayInfo, i = t.detail.value;
        a.birthdayInput = i;
        var e = .5, n = !0;
        8 === i.length && (e = 1, n = !1), a.opacity = e, a.disabled = n, this.setData({
            birthdayInfo: a
        });
    },
    changeVerify: function() {
        var t = this.data.birthdayInfo.data;
        i.changeVerify(t);
    }
};

exports.default = e;