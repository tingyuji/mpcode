var t = require("../../../../weapp-privacy-api/index.js").default;

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var e = new (function(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}(require("../../utils/api")).default)(), a = {
    data: {
        buyingInfo: {}
    },
    initBuyingSDK: function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, e = t.data, a = t.success, i = t.fail;
        this.callBackSuccess = a, this.callBackFail = i, this.setData({
            buyingInfo: {
                data: e,
                show: !0,
                opacity: .5,
                verifyDisa: !0,
                purchaseddeal: [],
                verifyButText: e.verifyButText || "验证"
            }
        }), this.getBuyInfo();
    },
    getBuyInfo: function() {
        var t = this, a = this.data, i = a.buyingInfo, n = a.buyingInfo.data, o = n.request_code, r = n.action, s = n.type, u = n.options;
        e.sendInfo({
            request_code: o,
            type: s,
            action: r
        }).then(function(e) {
            var a = e.status, n = e.data, o = e.error;
            if (1 === a) {
                var r = n.prompt, s = r.customHint, u = r.purchaseddeal.items, c = !0, d = !1, f = void 0;
                try {
                    for (var l, h = u[Symbol.iterator](); !(c = (l = h.next()).done); c = !0) {
                        var y = l.value;
                        y.couponTitle = y.couponTitle.length > 25 ? y.couponTitle.substring(0, 24) + "..." : y.couponTitle, 
                        y.checked = !1;
                    }
                } catch (t) {
                    d = !0, f = t;
                } finally {
                    try {
                        !c && h.return && h.return();
                    } finally {
                        if (d) throw f;
                    }
                }
                i.items = u, i.hint = s.operationHint || "请在下方选出您购买过的项目（单选）", i.opacity = .5, i.verifyDisa = !0, 
                t.setData({
                    buyingInfo: i
                });
            } else t.showAlert(o.message), t.handleError(o);
        }).catch(function() {
            t.showAlert("获取验证数据异常"), e.catchCallback("获取数据异常", 0, "请求历史购买信息出异常了", u, t);
        });
    },
    bindChange: function() {
        this.getBuyInfo();
    },
    bindVerify: function() {
        var a = this, i = this.data, n = i.buyingInfo, o = i.buyingInfo, r = o.purchaseddeal, s = o.data, u = s.action, c = s.request_code, d = s.type, f = s.options, l = s.listIndex;
        this.data.buyingInfo.verifyDisa = !0, this.setData(this.data), t.showLoading({
            title: "验证中...",
            mask: !0
        }), e.verify({
            request_code: c,
            type: d,
            action: u,
            options: {
                purchaseddeal: JSON.stringify(r),
                listIndex: l
            }
        }).then(function(i) {
            t.hideLoading(), a.data.buyingInfo.verifyDisa = !1, a.setData(a.data);
            var o = i.status, r = i.data, s = i.error;
            if (1 === o) {
                if (n.show = !1, e.nextVerify(l, r.nextVerifyMethodId)) return;
                a.setData({
                    buyingInfo: n
                }), e.successCallback(r.request_code, r.response_code, f, a);
            } else a.showAlert(s.message), a.handleError(s);
        }).catch(function() {
            a.showAlert("验证异常"), e.catchCallback("验证异常", 0, "请求验证异常了", f, a);
        });
    },
    bindRadioChange: function(t) {
        var e = t.detail.value, a = this.data.buyingInfo;
        a.purchaseddeal[0] = e, a.opacity = 1, a.verifyDisa = !1;
        var i = !0, n = !1, o = void 0;
        try {
            for (var r, s = a.items[Symbol.iterator](); !(i = (r = s.next()).done); i = !0) {
                var u = r.value;
                u.dealid === Number(e) ? u.checked = !0 : u.checked = !1;
            }
        } catch (t) {
            n = !0, o = t;
        } finally {
            try {
                !i && s.return && s.return();
            } finally {
                if (n) throw o;
            }
        }
        this.setData({
            buyingInfo: a
        });
    },
    handleError: function(t) {
        var a = this.data.buyingInfo.data.options;
        e.errorCallback(t, a, this.getBuyInfo, this);
    },
    changeVerify: function() {
        var t = this.data.buyingInfo.data;
        e.changeVerify(t);
    },
    onPullDownRefresh: function() {
        t.stopPullDownRefresh();
    }
};

exports.default = a;