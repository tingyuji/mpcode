var t = require("../../../../weapp-privacy-api/index.js").default;

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var a = function(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}(require("../../utils/api")), s = new a.default(), e = {
    data: {
        passwordInfo: {}
    },
    initPasswordSDK: function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, a = t.data, s = void 0 === a ? {} : a, e = t.success, o = t.fail;
        this.callBackSuccess = e, this.callBackFail = o, this.setData({
            passwordInfo: {
                data: s,
                disabled: !0,
                show: !0,
                opacity: .5,
                isSend: !1,
                mainTitle: s.mainTitle || "为了您的账户安全,请先完成以下验证",
                subTitle: s.subTitle || "请输入你当前美团账户的支付密码",
                inputPlaceholder: s.inputPlaceholder || "请输入6位支付密码",
                buttonValue: s.buttonValue || "验证"
            }
        }), this.getPasswordInfo();
    },
    getPasswordInfo: function() {
        var t = this, a = this.data, e = a.passwordInfo, o = a.passwordInfo.data, i = o.request_code, n = o.action, r = o.type, d = o.options;
        e.passwordInput = "";
        var c = this;
        s.sendInfo({
            request_code: i,
            type: r,
            action: n
        }).then(function(a) {
            var s = a.status, o = a.data, i = a.error;
            if (1 === s) {
                e.subTitle = o.prompt.message, e.isSend = !0, e.opacity = .5;
                var n = o.prompt.customHint || {};
                n && n.operationHint && (e.mainTitle = n.operationHint), n && n.infoHint && (e.subTitle = n.infoHint);
            } else t.showAlert(i.message), t.handleError(i);
            c.setData({
                passwordInfo: e
            });
        }).catch(function() {
            t.showAlert("验证异常"), s.catchCallback("获取数据异常", 0, "请求支付密码信息出异常了", d, t);
        });
    },
    bindPasswordSwitch: function() {
        var e = this, o = this.data, i = o.passwordInfo, n = void 0 === i ? {} : i, r = o.passwordInfo, d = r.isSend, c = r.passwordInput, l = r.opacity, p = r.data, u = p.action, f = p.request_code, h = p.type, w = p.options, I = p.listIndex;
        if (d && 1 === l) {
            var v = this.data;
            v.passwordInfo.disabled = !0, this.setData(v), t.showLoading({
                title: "验证中...",
                mask: !0
            }), s.verify({
                request_code: f,
                type: h,
                action: u,
                options: {
                    payhash: a.default.encrypt(f, c),
                    listIndex: I
                }
            }).then(function(a) {
                (v = e.data).passwordInfo.disabled = !1, e.setData(v), t.hideLoading();
                var o = a.status, i = a.error, r = a.data;
                if (1 === o) {
                    if (n.show = !1, s.nextVerify(I, r.nextVerifyMethodId)) return;
                    e.setData({
                        passwordInfo: n
                    }), s.successCallback(r.request_code, r.response_code, w, e);
                } else e.showAlert(i.message), e.handleError(i);
            }).catch(function() {
                e.showAlert("验证异常"), s.catchCallback("验证异常", 0, "请求验证异常了", w, e);
            });
        }
    },
    handleError: function(t) {
        var a = this.data.passwordInfo.data.options;
        s.errorCallback(t, a, this.getPasswordInfo, this);
    },
    bindpasswordInput: function(t) {
        var a = this.data.passwordInfo, s = t.detail.value;
        a.passwordInput = s;
        var e = .5, o = !0;
        6 === s.length && (e = 1, o = !1), a.opacity = e, a.disabled = o, this.setData({
            passwordInfo: a
        });
    },
    changeVerify: function() {
        var t = this.data.passwordInfo.data;
        s.changeVerify(t);
    }
};

exports.default = e;