Object.defineProperty(exports, "__esModule", {
    value: !0
});

var e = function(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}(require("../../utils/api")), t = require("../../utils/config"), r = new e.default(), i = {
    data: {
        groupInfo: {}
    },
    initGroupSDK: function() {
        var e = (arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}).data, t = {};
        Object.keys(e.riskNameGroup).forEach(function(r) {
            t[r] = JSON.parse(e.riskNameGroup[r]);
        }), this.setData({
            groupInfo: {
                data: e,
                show: !0,
                modules: t
            }
        });
    },
    groupHandle: function(e) {
        var i = this.data.groupInfo.data;
        i.listIndex = e.target.dataset.index;
        var o = i.riskGroup[i.listIndex || 0][0];
        i.riskGroup[i.listIndex].forEach(function(e) {
            t.modules[e] || (o = -2);
        }), -2 === o ? this.toPageVerify({
            requestCode: i.request_code,
            env: i.env,
            listIndex: i.listIndex
        }) : r.nextVerify(i.listIndex, o);
    },
    toPageVerify: function(e) {
        var t = e.requestCode, i = e.env, o = e.listIndex;
        r.toWebView({
            requestCode: t,
            env: i,
            listIndex: o
        });
    }
};

exports.default = i;