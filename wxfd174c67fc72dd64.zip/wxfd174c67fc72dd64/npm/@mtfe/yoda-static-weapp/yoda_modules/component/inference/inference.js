function e(e, t, n) {
    return t in e ? Object.defineProperty(e, t, {
        value: n,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = n, e;
}

var t = require("../../../../weapp-privacy-api/index.js").default, n = function(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}(require("./inferenceSDK")), s = require("./../../utils/union"), a = new n.default(), i = {
    options: {},
    properties: {
        style: {
            type: String
        }
    },
    props: {
        onInferenceevent: function(e) {
            console.log(e);
        }
    },
    data: {
        isShow: "none",
        isShowHelp: "none",
        requestCode: "xxxx",
        type: "",
        action: "login",
        imgurl: "",
        titleUrl: "",
        cn: 0,
        msgType: 3,
        helpIcon: "https://s3plus.meituan.net/v1/mss_f231eb419c414559a1837748d11d4312/yoda-resources/mp_help.png",
        refreshIcon: "https://s3plus.meituan.net/v1/mss_f231eb419c414559a1837748d11d4312/yoda-resources/inference/refresh.png",
        closeIcon: "https://s3plus.meituan.net/v1/mss_f231eb419c414559a1837748d11d4312/yoda-resources/inference/close.png",
        sendStatus: 0,
        ids: [],
        max: 10,
        styleBag: {},
        textSeq: Array.from({
            length: 9
        }).map(function(e, t) {
            return t + 1;
        }),
        timestamp: 0
    },
    externalClasses: [ "inference-wrapper" ],
    methods: {
        init: function() {
            var e = [], n = [];
            ("undefined" != typeof my ? my.createSelectorQuery() : this.createSelectorQuery()).select("#yoda-inference").boundingClientRect().select("#yoda-inference >>> #yoda-img").boundingClientRect().exec(function(s) {
                var i = t.getSystemInfoSync(), o = i.screenWidth > i.screenHeight ? "v" : "h";
                e.push([ s[0].width, s[0].height ]), n.push([ Number(s[0].left.toFixed(3)), Number(s[0].top.toFixed(3)) ]), 
                e.push([ s[1].width, s[1].height ]), n.push([ Number(s[1].left.toFixed(3)), Number(s[1].top.toFixed(3)) ]), 
                a.initSDK(e, n, o);
            });
        },
        onwxstap: function(t) {
            var n = this;
            ("undefined" != typeof my ? my.createSelectorQuery() : this.createSelectorQuery()).select("#yoda-inference >>> .content-wrap").boundingClientRect().exec(function(s) {
                var a = s[0], i = n.data, o = i.ids, r = i.max, c = t.touches[0] || t.changedTouches[0], u = c.pageX, l = c.pageY, d = u - 10 - a.left, f = l - 10 - a.top, p = o.length + 1;
                p <= r && (n.setData(e({}, "styleBag." + p, "left:" + d + "px;top:" + f + "px;display:block;")), 
                o.push(p), n.setData({
                    ids: o
                }));
            });
        },
        onwxscancel: function(t) {
            for (var n = this.data.ids, s = t.currentTarget.dataset.id, a = s - 1, i = n.length - a, o = s; o <= n.length; o++) this.setData(e({}, "styleBag." + o, "display:none;"));
            n.splice(a, i), this.setData({
                ids: n
            });
        },
        propObserver: function() {
            for (var t = this.data.ids, n = 1; n <= t.length; n++) this.setData(e({}, "styleBag." + n, "display:none;"));
            t.splice(0), this.setData({
                ids: t
            });
        },
        showInference: function() {
            var e = this, n = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, i = n.requestCode, o = n.appletsfp, r = n.isPage, c = n.helpUrl;
            s.fenvp.e();
            var u = this;
            this.yodaUrl = getApp().globalData.yodaUrl || "https://verify.meituan.com";
            var l = !!t.mtShare, d = t.getSystemInfoSync().SDKVersion;
            if ("undefined" != typeof mmp || l || "undefined" != typeof my || d && u.compareVersion(d, "2.11.0") >= 0) {
                a.firstInit(), u.setData({
                    imgurl: "",
                    msgType: 3,
                    isShow: "block"
                });
                var f = getApp().globalData.yoda_component_data;
                u.initData({
                    requestCode: i,
                    appletsfp: o,
                    data: f,
                    isPage: r,
                    helpUrl: c
                }), ("undefined" != typeof mmp || l) && t.getRiskControlFingerprint({
                    success: function(t) {
                        var n = t.fingerprint;
                        e.setData({
                            fp: n
                        });
                    }
                });
            } else t.showModal({
                title: "提示",
                content: "当前微信版本过低，无法使用该功能，请升级到最新微信版本后重试。"
            });
        },
        initData: function(e) {
            var t = e.requestCode, n = e.appletsfp, s = e.data, a = e.isPage, i = e.helpUrl;
            this.setData({
                category: s.category,
                action: s.action,
                type: s.type,
                listIndex: s.listIndex,
                timestamp: s.timestamp,
                requestCode: t,
                appletsfp: n,
                isPage: a,
                helpUrl: i
            }), this.info();
        },
        info: function() {
            var e = this;
            t.showLoading({
                title: "加载中...",
                content: "加载中..."
            });
            var n = this;
            setTimeout(function() {
                e.propObserver();
            }, 0), a.info(this.data).then(function(s) {
                var i = s.status, o = s.error, r = s.data;
                if (1 === i) {
                    var c = r.prompt, u = c.items[1] || "", l = c.cn, d = c.items[0], f = c.hint, p = c.message;
                    a.resetPoint(0);
                    var h = 3;
                    u && (h = -1, n.base64ToImage(u, function(t) {
                        e.setData({
                            titleUrl: t
                        });
                    })), e.setData({
                        message: p,
                        cn: l,
                        msgType: h,
                        rotateClass: "",
                        sendStatus: 0
                    }), n.exectuCanvas(d, f, e.data.requestCode), n.init();
                } else {
                    var g = o.code, m = o.message, v = 0;
                    121038 === g && (v = 2), n.setData({
                        errorMsg: m,
                        msgType: v,
                        rotateClass: "",
                        sendStatus: 0
                    }), setTimeout(function() {
                        n.verifyFail(o);
                    }, 2e3);
                }
                t.hideLoading();
            }).catch(function(e) {
                console.log(e), t.hideLoading(), n.setData({
                    errorMsg: "您的网络状况不好",
                    msgType: 0,
                    rotateClass: ""
                }), setTimeout(function() {
                    n.verifyFail({
                        code: "00102",
                        message: "您的网络状况不好"
                    });
                }, 2e3);
            });
        },
        verify: function() {
            var e = this, n = this.isPage, i = this.helpUrl;
            t.showLoading({
                title: "验证中...",
                content: "验证中..."
            });
            var o = s.common.encrypt(s.fenvp.c(), this.data.requestCode);
            a.verify(this.data, o).then(function(a) {
                var o = a.status, r = a.data, c = a.error;
                if (t.hideLoading(), 1 === o) e.setData({
                    msgType: 1
                }), setTimeout(function() {
                    e.propObserver(), e.verifySuccess(r);
                }, 1e3); else {
                    var u = c.code, l = c.message;
                    setTimeout(function() {
                        e.setData({
                            errorMsg: l,
                            msgType: 0,
                            sendStatus: 1
                        });
                    }, 0), 121056 === u && (n || i) || 121079 === u ? (s.fenvp.e(), e.setData({
                        isShowHelp: n || i ? "block" : "none"
                    }), setTimeout(function() {
                        e.info();
                    }, 1e3)) : setTimeout(function() {
                        e.propObserver(), e.verifyFail(c);
                    }, 2e3);
                }
            }).catch(function() {
                t.hideLoading(), e.setData({
                    errorMsg: "您的网络状况不好",
                    msgType: 0
                }), setTimeout(function() {
                    e.propObserver(), e.verifyFail({
                        code: "00102",
                        message: "您的网络状况不好"
                    });
                }, 2e3);
            });
        },
        verifySuccess: function(e) {
            var n = this, s = e ? e.response_code : "", a = e ? e.nextVerifyMethodId : "", i = e && e.origin_request_code ? e.origin_request_code : n.data.requestCode;
            t.showToast({
                title: "验证成功",
                content: "验证成功",
                complete: function() {
                    var e = {
                        status: 1,
                        requestCode: i,
                        responseCode: s,
                        nextVerifyMethodId: a
                    };
                    n.triggerEvent ? n.triggerEvent("inferenceevent", e, {
                        bubbles: !0,
                        composed: !0
                    }) : n.props.onInferenceevent(e), n.setData({
                        isShow: "none"
                    });
                }
            });
        },
        verifyFail: function(e) {
            this.setData({
                isShow: "none"
            });
            var t = {
                status: 0,
                code: e.code,
                msg: e.message,
                requestCode: e.request_code
            };
            this.triggerEvent ? this.triggerEvent("inferenceevent", t, {
                bubbles: !0,
                composed: !0
            }) : this.props.onInferenceevent(t);
        },
        onHelp: function() {
            var e = this.data, n = e.requestCode, s = e.helpUrl, a = "../../modules/index/public?type=help&requestCode=" + n;
            s && (a = s + "?type=help&requestCode=" + n), t.navigateTo({
                url: a
            });
        },
        onrefresh: function() {
            0 === this.data.sendStatus && (this.setData({
                sendStatus: 1
            }), this.setData({
                rotateClass: "animation-rotate"
            }), this.info());
        },
        onclose: function() {
            this.propObserver(), this.verifyFail({
                code: "000333",
                message: "主动关闭验证流程"
            });
        },
        oncancel: function(e) {
            var t = e.currentTarget.dataset.id;
            a.resetPoint(t - 1);
        },
        nextSubmit: function() {
            var e = this, t = e.data.requestCode;
            setTimeout(function() {
                var n = a.getbv(t);
                e.setData({
                    bv: n
                }), e.verify();
            }, 10);
        },
        ontouchstart: function(e) {
            a.canvasTouchstart(e);
        },
        ontouchend: function(e) {
            var t = this, n = t.data.cn;
            setTimeout(function() {
                a.canvasTouchend(e, n, t.nextSubmit.bind(t));
            }, 50);
        },
        onGlobaTouchstart: function(e) {
            a.globaTouchstart(e);
        },
        onGlobaTouchend: function(e) {
            a.globaTouchend(e);
        },
        exectuCanvas: function(e, n, s) {
            var i = this;
            ("undefined" != typeof my ? my.createSelectorQuery() : this.createSelectorQuery()).select("#yoda-inference >>> #canvas").fields({
                node: !0,
                size: !0
            }).exec(function(o) {
                o[0] && i.base64ToImage(e, function(e) {
                    a.draw(o[0], e, n, s, function(n) {
                        var s = !!t.mtShare;
                        if ("undefined" != typeof mmp || s) t.canvasToTempFilePath({
                            destWidth: 536,
                            destHeight: 357,
                            canvas: o[0].node,
                            success: function(e) {
                                var t = e.tempFilePath;
                                i.setData({
                                    imgurl: t
                                });
                            },
                            fail: function(e) {
                                console.log("err", e);
                            }
                        }); else {
                            var a = n.toDataURL("image/png", 1);
                            i.setData({
                                imgurl: a
                            });
                        }
                        t.getFileSystemManager({
                            _mt: {
                                sceneToken: "jcyf-d07c5c9a426edd09"
                            }
                        }).unlink({
                            filePath: e,
                            fail: function(e) {
                                console.log("unlink image file error:", e);
                            }
                        });
                    });
                });
            });
        },
        base64ToImage: function(e, n) {
            var s = t.getFileSystemManager({
                _mt: {
                    sceneToken: "jcyf-d07c5c9a426edd09"
                }
            }), a = Math.random().toString(36).substring(2), i = t.env.USER_DATA_PATH + "/tmpbase64src" + a;
            s.writeFile({
                filePath: i,
                data: e,
                encoding: "base64",
                success: function() {
                    n(i);
                },
                fail: function(e) {
                    console.log("write file fail:", e);
                }
            });
        },
        compareVersion: function(e, t) {
            for (var n = e.split("."), s = t.split("."), a = Math.max(n.length, s.length); n.length < a; ) n.push("0");
            for (;s.length < a; ) s.push("0");
            for (var i = 0; i < a; i++) {
                var o = parseInt(n[i], 10), r = parseInt(s[i], 10);
                if (o > r) return 1;
                if (o < r) return -1;
            }
            return 0;
        },
        changeVerify: function() {
            a.changeVerify();
        }
    }
};

Component(i);