function t(t, e) {
    if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function");
}

var e = require("../../../../weapp-privacy-api/index.js").default;

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var i = require("./../../utils/union"), n = new (function(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}(require("./../../utils/api")).default)(), o = Date.now();

exports.default = function s() {
    var a = this;
    t(this, s), this.firstInit = function() {
        a.env.count = 0, a.env.Timestamp.splice(0), a.env.Timestamp.push(Date.now()), a.initEventTime = 0;
    }, this.initSDK = function(t, e, i) {
        a.env.zone = t, a.env.client = e, a.env.vector.orientation = i, a.point1.splice(0), 
        a.point2.splice(0), a.x = 0, a.y = 0, a.st = 0, a.et = 0;
    }, this.resetPoint = function(t) {
        var e = a.point1.length - t;
        a.point1.splice(t, e);
    }, this.computeTime = function(t, e, i) {
        return t - (i - e);
    }, this.canvasTouchstart = function(t) {
        if (1 === a.env.Timestamp.length) {
            var e = Date.now();
            a.env.Timestamp.push(e), a.initEventTime = a.computeTime(t.timeStamp, a.env.Timestamp[0], e);
        }
        var i = t.touches[0], n = a.env.client[1], o = i.clientX - n[0], s = i.clientY - n[1];
        a.x = Number(o.toFixed(3)), a.y = Number(s.toFixed(3)), a.st = t.timeStamp - a.initEventTime;
    }, this.canvasTouchend = function(t, e, i) {
        var n = t.timeStamp - a.initEventTime;
        a.point1.push([ a.x, a.y, Number(a.st.toFixed(0)), Number(n.toFixed(0)), 0 ]), a.point1.length === e && i();
    }, this.globaTouchstart = function(t) {
        if (a.env.count += 1, 1 === a.env.Timestamp.length) {
            var e = Date.now();
            a.env.Timestamp.push(e), a.initEventTime = a.computeTime(t.timeStamp, a.env.Timestamp[0], e);
        }
        var i = t.touches[0], n = a.env.client[1], o = i.clientX - n[0], s = i.clientY - n[1], r = t.timeStamp - a.initEventTime;
        a.point2.push([ Number(o.toFixed(3)), Number(s.toFixed(3)), Number(r.toFixed(0)) ]);
    }, this.globaTouchend = function(t) {
        var e = t.timeStamp - a.initEventTime;
        a.point2[a.point2.length - 1].push(Number(e.toFixed(0))), a.point2[a.point2.length - 1].push(0);
    }, this.trajectory = function() {
        return {
            point1: a.point1,
            point2: a.point2
        };
    }, this.getbv = function(t) {
        a.env.Timestamp[2] = Date.now();
        var e = {
            env: a.env,
            trajectory: a.trajectory()
        };
        return i.common.encrypt(e, t);
    }, this.info = function(t) {
        var o = t.requestCode, s = t.type, a = t.action, r = t.fp, p = t.timestamp, m = {}, u = !!e.mtShare;
        ("undefined" != typeof mmp || u) && (m.fingerprint = r);
        var c = i.common.sign(s, o, p, m);
        return n.sendInfo({
            request_code: o,
            type: s,
            action: a,
            options: m,
            timestamp: p,
            authencation: c
        });
    }, this.verify = function(t, o) {
        var s = t.requestCode, a = t.type, r = t.action, p = t.bv, m = t.fp, u = t.appletsfp, c = t.listIndex, v = t.timestamp, h = {
            bv: p
        }, f = !!e.mtShare;
        ("undefined" != typeof mmp || f) && (h.fingerprint = m), u && (h.appletsfp = u), 
        (c || 0 === c) && (h.listIndex = c), o && (h.d = o);
        var l = i.common.sign(a, s, v, h);
        return n.verify({
            request_code: s,
            type: a,
            action: r,
            options: h,
            timestamp: v,
            authencation: l
        });
    }, this.changeVerify = function() {
        n.changeVerify();
    }, this.draw = function(t, e, n, o, s) {
        return i.common.draw(t, e, n, o, s);
    }, this.env = {
        zone: [],
        client: [],
        Timestamp: [ o ],
        count: 0,
        vector: {}
    }, this.point1 = [], this.point2 = [], this.initEventTime = 0, this.x = 0, this.y = 0, 
    this.st = 0, this.et = 0;
};