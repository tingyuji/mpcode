function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

var t = require("../../../../weapp-privacy-api/index.js").default, i = e(require("./sliderSDK")), a = require("./../../utils/union"), s = new (e(require("./../../utils/api")).default)();

Component({
    properties: {
        title: {
            type: String,
            value: "滑块验证"
        },
        imgTitle: {
            type: String,
            value: "请输入图片中的内容"
        },
        imgButton: {
            type: String,
            value: "验证"
        }
    },
    props: {
        title: "滑块验证",
        imgTitle: "请输入图片中的内容",
        imgButton: "验证",
        onSliderevent: function(e) {
            console.log(e);
        }
    },
    data: {
        isShow: "none",
        isShowHelp: "none"
    },
    methods: {
        showSlider: function(e) {
            var i = this, s = e.requestCode, n = e.appletsfp, o = e.isPage, d = e.helpUrl;
            a.fenvp.e();
            var r = this, l = getApp().globalData.yoda_component_data;
            r.initData({
                requestCode: s,
                appletsfp: n,
                data: l,
                isPage: o,
                helpUrl: d
            }), getApp().$yodaSliderPage = this, !!t.mtShare && t.getRiskControlFingerprint({
                success: function(e) {
                    var t = e.fingerprint;
                    i.setData({
                        fp: t
                    });
                }
            });
            var p = t.createAnimation({
                transformOrigin: "50% 50%",
                duration: 500,
                timingFunction: "ease",
                delay: 0
            });
            this.animation = p;
        },
        initData: function(e) {
            var t = e.requestCode, a = e.appletsfp, s = e.data, n = e.isPage, o = e.helpUrl, d = new i.default({
                requestCode: t,
                pageData: {
                    data: s
                },
                appletsfp: a
            });
            this.setData({
                sdk: d,
                isPage: n,
                helpUrl: o,
                moveWidth: 0,
                codeImage: "",
                requestCode: t,
                sliderCode: "",
                isShow: "block",
                validStep: "slider",
                slideStatusClass: "",
                animationData: {},
                appletsfp: a,
                pageData: {
                    data: s
                }
            });
        },
        sliderTouchStart: function(e) {
            this.data.sdk.sliderTouchStart(e);
        },
        sliderTouchMove: function(e) {
            var t = this.data.sdk.sliderTouchMove(e), i = t.deltaX, a = "";
            t.isDone && (a = "slider-boxLoading"), this.setData({
                moveWidth: i,
                slideStatusClass: a
            });
        },
        sliderTouchEnd: function() {
            var e = this.data, i = e.sdk, s = e.requestCode, n = i.isDone;
            if (i.sliderTouchEnd(), n) {
                t.showLoading({
                    title: "验证中...",
                    content: "验证中..."
                });
                var o = a.common.encrypt(a.fenvp.c(), s);
                this.setData({
                    fc: o,
                    slideStatusClass: "slider-boxLoading"
                }), i.slidEnd();
            } else this.setData({
                moveWidth: 0
            });
        },
        sliderClose: function() {
            this.setData({
                isShow: "none"
            }), this.triggerEvent ? this.triggerEvent("sliderevent", {
                status: 0,
                code: 33333,
                msg: "主动关闭验证"
            }, {
                bubbles: !0,
                composed: !0
            }) : this.props.onSliderevent({
                status: 0,
                code: 33333,
                msg: "主动关闭验证"
            });
        },
        sliderHelp: function() {
            var e = this.data, i = e.requestCode, a = e.helpUrl, s = "../../modules/index/public?type=help&requestCode=" + i;
            a && (s = a + "?type=help&requestCode=" + i), t.navigateTo({
                url: s
            });
        },
        sliderValideCode: function() {
            var e = this.data, t = e.sliderCode, s = e.pageData, n = e.fp, o = e.appletsfp, d = e.sdk.requestCode, r = a.common.encrypt(a.fenvp.c(), d);
            i.default.verifyCode({
                captchacode: t,
                action: s.data.action,
                id: 1,
                requestCode: d,
                fingerprint: n,
                appletsfp: o,
                listIndex: s.data.listIndex,
                d: r,
                timesTamp: s.data.timestamp
            });
        },
        sliderValideCodeInput: function(e) {
            this.setData({
                sliderCode: e.detail.value
            });
        },
        bindSliderInputFocus: function() {
            this.animation.top(200).step();
            var e = this.animation.export();
            this.setData({
                animationData: e
            });
        },
        bingSliderInputBlur: function(e) {
            this.animation.top(300).step();
            var t = this.animation.export();
            this.setData({
                animationData: t,
                sliderCode: e.detail.value
            });
        },
        changeVerify: function() {
            s.changeVerify({});
        }
    }
});