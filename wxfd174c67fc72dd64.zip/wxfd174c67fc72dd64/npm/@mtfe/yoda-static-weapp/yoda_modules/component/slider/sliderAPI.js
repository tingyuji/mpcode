function e(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

var t = require("../../../../weapp-privacy-api/index.js").default;

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var n = function() {
    function e(e, t) {
        for (var n = 0; n < t.length; n++) {
            var r = t[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), 
            Object.defineProperty(e, r.key, r);
        }
    }
    return function(t, n, r) {
        return n && e(t.prototype, n), r && e(t, r), t;
    };
}(), r = require("./../../utils/union"), a = function() {
    function a() {
        e(this, a), this.yodaUrl = getApp().globalData.yodaUrl || "https://verify.meituan.com";
    }
    return n(a, [ {
        key: "changeImage",
        value: function(e, t, n) {
            var r = this.yodaUrl + "/v2/captcha?request_code=" + t + "&action=" + n + "&captchaHash=" + Number(new Date());
            e.setData({
                codeImage: r
            });
        }
    }, {
        key: "verifyCode",
        value: function(e) {
            var t = e.action, n = e.id, r = e.requestCode, a = e.fingerprint, i = e.captchacode, o = e.appletsfp, c = e.listIndex, u = e.d, s = e.timesTamp;
            return this.verifySlide({
                action: t,
                id: n,
                requestCode: r,
                fingerprint: a,
                captchacode: i,
                appletsfp: o,
                listIndex: c,
                d: u,
                timesTamp: s
            });
        }
    }, {
        key: "verifySlide",
        value: function(e) {
            var t = e.action, n = e.id, a = e.requestCode, i = e.behavior, o = e.fingerprint, c = e.captchacode, u = e.appletsfp, s = e.listIndex, d = e.d, f = e.timesTamp, l = {
                request_code: a
            };
            i && (l.behavior = r.common.encrypt(i, a)), c && (l.captchacode = c), o && (l.fingerprint = o), 
            u && (l.appletsfp = u), (s || 0 === s) && (l.listIndex = s), d && (l.d = d);
            var p = r.common.sign(n, a, f, l);
            return this.sendVerify(t, n, f, p, l);
        }
    }, {
        key: "sendVerify",
        value: function(e, n, r, a, i) {
            var o = this;
            return new Promise(function(c, u) {
                t.request({
                    url: o.yodaUrl + "/v2/ext_api/" + e + "/verify?id=" + n,
                    method: "POST",
                    header: {
                        "content-type": "application/x-www-form-urlencoded",
                        TimesTamp: r,
                        Authencation: a
                    },
                    data: i,
                    timeout: 5e3,
                    success: function(e) {
                        var n = getApp().$yodaSliderPage.data.pageData, r = e.data, a = r.data, u = r.status, s = r.error;
                        if (1 === u && a && (a.request_code = a.origin_request_code ? a.origin_request_code : i.request_code), 
                        1 === u && n.notifyUrl) {
                            var d = n.notifyUrl;
                            o.getNotifyUrl(d, n.request_code, a.response_code).then(function() {
                                c({
                                    status: u,
                                    error: s,
                                    data: a
                                });
                            }).catch(function() {
                                t.showToast({
                                    title: "获取notifyurl失败",
                                    content: "获取notifyurl失败"
                                });
                            });
                        } else c({
                            status: u,
                            error: s,
                            data: a
                        });
                    },
                    fail: function(e) {
                        u(e);
                    }
                });
            }).catch(function() {
                t.showToast({
                    title: "获取verify失败",
                    content: "获取verify失败"
                });
            });
        }
    } ], [ {
        key: "getSystemInfo",
        value: function() {
            return t.getSystemInfoSync();
        }
    }, {
        key: "getNotifyUrl",
        value: function(e, n, r) {
            var a = -1 === e.indexOf("?") ? "?" : "&";
            return new Promise(function(i) {
                t.request({
                    url: "" + e + a + "request_code=" + n + "&response_code=" + r,
                    header: {
                        "content-type": "application/x-www-form-urlencoded"
                    },
                    success: function() {
                        i();
                    },
                    fail: function() {
                        i();
                    }
                });
            });
        }
    } ]), a;
}();

exports.default = a;