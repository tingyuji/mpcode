var e = require("../../../../weapp-privacy-api/index.js").default, t = require("./../../utils/config"), a = require("./../../utils/union"), s = new (function(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}(require("./../../utils/api")).default)();

Component({
    properties: {},
    props: {
        onYodaevent: function(e) {
            console.log(e);
        }
    },
    data: {
        isShow: !1,
        isPage: !1,
        showWebview: !1,
        url: "",
        marginTop: 100,
        marginLeft: 50,
        env: "",
        yodaCanvas: "",
        yodawebGl: ""
    },
    ready: function() {
        var t = this;
        this.triggerEvent("yodaready");
        var s = !!e.mtShare;
        setTimeout(function() {
            t.createSelectorQuery().select("#yoda_canvas").fields({
                node: !0,
                size: !0
            }).exec(function(e) {
                e[0] && !s && a.fenvp.d(e);
            });
        }, 0), setTimeout(function() {
            t.createSelectorQuery().select("#yoda_webgl").fields({
                node: !0,
                size: !0
            }).exec(function(e) {
                e[0] && !s && a.fenvp.b(e);
            });
        }, 0);
    },
    methods: {
        imageRef: function(e) {
            this.Image = e;
        },
        sliderRef: function(e) {
            this.Slider = e;
        },
        inferenceRef: function(e) {
            this.Inference = e;
        },
        init: function(t) {
            var s = this, n = t.requestCode, i = t.appletsfp, o = t.env, r = t.isPage, p = t.helpUrl;
            a.fenvp.a(), this.setData({
                isShow: !0,
                isPage: r,
                requestCode: n,
                appletsfp: i,
                env: o,
                helpUrl: p
            }, function() {
                switch (!s.Image && s.selectComponent && (s.Image = s.selectComponent("#image")), 
                !s.Slider && s.selectComponent && (s.Slider = s.selectComponent("#slider")), !s.Inference && s.selectComponent && (s.Inference = s.selectComponent("#inference"), 
                e.getSystemInfo({
                    success: function(e) {
                        var t = e.windowWidth, a = e.windowHeight;
                        s.setData({
                            marginLeft: (t - 284) / 2,
                            marginTop: (a - 250) / 2
                        });
                    }
                })), s.yodaUrl = "https://verify.meituan.com", o) {
                  case "staging":
                    s.yodaUrl = "https://verify.inf.st.meituan.com";
                    break;

                  case "test":
                    s.yodaUrl = "https://verify.inf.test.meituan.com";
                    break;

                  case "dev":
                    s.yodaUrl = "https://verify.inf.dev.meituan.com";
                }
                if (getApp().globalData || (getApp().globalData = {}), getApp().globalData.yodaUrl = s.yodaUrl, 
                r) {
                    var t = getApp().globalData.yodaPageData;
                    t.isPage = !0, s.setStorage({
                        data: t,
                        requestCode: n,
                        appletsfp: i,
                        env: o
                    });
                } else s.fetchPageData(n, i, o);
            });
        },
        fetchPageData: function(e, t, a) {
            var n = this;
            s.getPageData(e, 2).then(function(s) {
                var i = s.status, o = s.error, r = s.data;
                0 === i ? n.failBack(o.code, o.msg) : (r.isPage = !1, r.requestCode = e, n.setStorage({
                    data: r,
                    requestCode: e,
                    appletsfp: t,
                    env: a
                }));
            }).catch(function(e) {
                n.failBack(999014, "接口异常:" + e.message);
            });
        },
        setStorage: function(e) {
            var t = e.data, a = e.requestCode, s = e.appletsfp, n = e.env, i = this;
            if (i.setData({
                isPage: t.isPage,
                listIndex: t.listIndex || 0
            }), getApp().globalData.yoda_component_data = t, this.setData({
                type: Number(t.type),
                requestCode: a,
                appletsfp: s
            }), t.type) i.loadComponent({
                type: Number(t.type),
                requestCode: a,
                appletsfp: s,
                env: n
            }); else {
                var o = [];
                t.riskLevel.split("|").forEach(function(e) {
                    o.push(e.split(","));
                }), t.type = o[t.defaultIndex || 0][0], t.riskGroup = o, t.listIndex = t.defaultIndex || 0, 
                i.loadComponent({
                    type: Number(t.type),
                    requestCode: a,
                    appletsfp: s,
                    env: n
                });
            }
        },
        loadComponent: function(e) {
            var t = e.type, a = e.requestCode, s = e.appletsfp, n = e.env, i = this.data.helpUrl, o = this.data.isPage;
            switch (t) {
              case 1:
                this.Image.showImage({
                    requestCode: a,
                    appletsfp: s,
                    isPage: o,
                    helpUrl: i
                });
                break;

              case 71:
                this.Slider.showSlider({
                    requestCode: a,
                    appletsfp: s,
                    isPage: o,
                    helpUrl: i
                });
                break;

              case 130:
                this.Inference.showInference({
                    requestCode: a,
                    appletsfp: s,
                    isPage: o,
                    helpUrl: i
                });
                break;

              default:
                this.toHtml(a, n);
            }
        },
        toHtml: function(e, t) {
            var a = [ "requestCode=" + e, "succCallbackKNBFun=mp_call", "env=" + t ];
            a = a.join("&");
            var s = ({
                staging: "https://verify.inf.st.meituan.com",
                dev: "https://verify.inf.dev.meituan.com",
                test: "https://verify.inf.test.meituan.com"
            }[t] || "https://verify.meituan.com") + "/v2/app/general_page?" + a;
            this.setData({
                showWebview: !0,
                url: s
            });
        },
        onPostMessage: function(e) {
            var t = e.detail.data, a = t[t.length - 1];
            if (a.requestCode && a.responseCode) this.successBack(a.requestCode, a.responseCode); else {
                var s = a.code || "101303", n = a.msg || "小程序验证调用H5页面验证失败";
                this.failBack(s, n);
            }
        },
        failBack: function(a, s) {
            var n = this;
            e.showToast({
                icon: "none",
                title: s,
                content: s,
                complete: function() {
                    n.triggerEvent ? n.triggerEvent("yodaevent", {
                        status: t.callStatus.FAIL,
                        code: a,
                        msg: s
                    }, {
                        bubbles: !0,
                        composed: !0
                    }) : n.props.onYodaevent({
                        status: t.callStatus.FAIL,
                        code: a,
                        msg: s
                    });
                }
            });
        },
        successBack: function(e, a) {
            this.triggerEvent ? this.triggerEvent("yodaevent", {
                status: t.callStatus.SUCCESS,
                requestCode: e,
                responseCode: a
            }, {
                bubbles: !0,
                composed: !0
            }) : this.props.onYodaevent({
                status: t.callStatus.SUCCESS,
                requestCode: e,
                responseCode: a
            });
        },
        yodaCallEvent: function(e) {
            var t = e.detail || e, a = t.status;
            1 === a && this.verifyOk(t), 0 === a && this.verifyFail(t);
        },
        verifyOk: function(e) {
            var t = e.nextVerifyMethodId;
            if (t) this.nextVerify(t); else {
                var a = e.requestCode, s = e.responseCode;
                this.successBack(a, s);
            }
        },
        verifyFail: function(e) {
            var t = e.code, a = e.msg, s = e.requestCode;
            s ? this.nextPage(s) : this.failBack(t, a);
        },
        nextPage: function(e) {
            var t = this.data, a = t.appletsfp, n = t.isPage, i = t.env;
            n ? s.nextPMVerify(e) : this.fetchPageData(e, a, i);
        },
        nextVerify: function(e) {
            var t = this.data, a = t.requestCode, n = t.appletsfp, i = t.isPage, o = t.listIndex, r = t.env;
            i ? s.nextVerify(o, e) : this.loadComponent({
                type: Number(e),
                requestCode: a,
                appletsfp: n,
                env: r
            });
        }
    }
});