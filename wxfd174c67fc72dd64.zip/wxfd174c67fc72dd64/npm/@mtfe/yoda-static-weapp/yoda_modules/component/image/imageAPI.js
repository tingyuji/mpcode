function e(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

var t = require("../../../../weapp-privacy-api/index.js").default;

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var a = function() {
    function e(e, t) {
        for (var a = 0; a < t.length; a++) {
            var n = t[a];
            n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), 
            Object.defineProperty(e, n.key, n);
        }
    }
    return function(t, a, n) {
        return a && e(t.prototype, a), n && e(t, n), t;
    };
}(), n = function(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}(require("./../../utils/api")), o = require("./../../utils/union"), i = new n.default(), r = function() {
    function n() {
        e(this, n), this.yodaUrl = getApp().globalData.yodaUrl || "https://verify.meituan.com";
    }
    return a(n, [ {
        key: "bindImgVerify",
        value: function(e, a) {
            var n = this, r = e.value, c = e.data, s = c.action, u = c.request_code, l = c.type, d = c.listIndex, p = c.timestamp, f = e.opacity, v = e.fp, g = e.appletsfp, y = e.isPage, h = e.helpUrl;
            if (1 === f) {
                var m = {
                    captchacode: r
                };
                (d || 0 === d) && (m.listIndex = d), v && (m.fingerprint = v), g && (m.appletsfp = g), 
                t.showLoading({
                    title: "验证中...",
                    content: "验证中...",
                    mask: !0
                });
                var b = o.common.encrypt(o.fenvp.c(), u);
                b && (m.d = b);
                var _ = o.common.sign(l, u, p, m);
                i.verify({
                    request_code: u,
                    type: l,
                    action: s,
                    options: m,
                    authencation: _,
                    timestamp: p
                }).then(function(e) {
                    t.hideLoading();
                    var i = e.status, r = e.data, c = e.error;
                    if (1 === i) {
                        var s = {
                            status: 1,
                            requestCode: r && r.origin_request_code ? r.origin_request_code : u,
                            responseCode: r ? r.response_code || "" : "",
                            nextVerifyMethodId: r ? r.nextVerifyMethodId || "" : ""
                        };
                        n.callback(s, a);
                    } else {
                        var l = c.code;
                        if (121056 === l && (y || h) || 121020 === l) {
                            o.fenvp.e(), t.showToast({
                                title: "验证码错误",
                                content: "验证码错误",
                                mask: !0,
                                icon: "none",
                                complete: a.bingUpdateImg()
                            });
                            var d = y || h ? "block" : "none";
                            a.setData({
                                value: "",
                                opacity: .5,
                                isShowHelp: d
                            });
                        } else {
                            var p = {
                                status: 0,
                                code: c.code,
                                msg: c.message,
                                requestCode: c.request_code
                            };
                            n.callback(p, a);
                        }
                    }
                }).catch(function() {
                    t.hideLoading(), n.callback({
                        status: 0,
                        code: 99999,
                        msg: "verify请求异常"
                    }, a);
                });
            }
        }
    }, {
        key: "callback",
        value: function(e, t) {
            t.setData({
                value: "",
                opacity: .5,
                isShow: "none"
            }), t.triggerEvent ? t.triggerEvent("imageevent", e, {
                bubbles: !0,
                composed: !0
            }) : t.props.imageevent(e);
        }
    }, {
        key: "changeImage",
        value: function(e) {
            var t = e.data.data, a = this.yodaUrl + "/v2/captcha?request_code=" + t.request_code + "&action=" + t.action + "&captchaHash=" + Number(new Date());
            e.setData({
                imgsrc: a
            });
        }
    }, {
        key: "bindImgCodeInput",
        value: function(e, t) {
            var a = t.data.opacity;
            a = e && e.length > 1 ? 1 : .5, t.setData({
                value: e,
                opacity: a
            });
        }
    }, {
        key: "changeVerify",
        value: function() {
            i.changeVerify({});
        }
    } ]), n;
}();

exports.default = r;