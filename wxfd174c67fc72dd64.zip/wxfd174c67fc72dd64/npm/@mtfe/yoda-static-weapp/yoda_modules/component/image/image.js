var e = require("../../../../weapp-privacy-api/index.js").default, t = function(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}(require("./imageAPI")), a = require("./../../utils/union"), i = void 0;

Component({
    options: {
        multipleSlots: !1
    },
    properties: {
        title: {
            type: String,
            value: "请输入图片中的内容"
        },
        placeholder: {
            type: String,
            value: "请输入验证码"
        },
        verifyText: {
            type: String,
            value: "验证"
        }
    },
    props: {
        title: "请输入图片中的内容",
        placeholder: "请输入验证码",
        verifyText: "验证",
        imageevent: function(e) {
            console.log(e);
        }
    },
    externalClasses: [ "yoda-class-bg", "yoda-class-input", "yoda-class-btn" ],
    data: {
        isShow: "none",
        isShowHelp: "none",
        imgsrc: "",
        placeholder: "",
        value: "",
        fp: "",
        timestamp: 0
    },
    methods: {
        hideImage: function() {
            this.setData({
                isShow: "none"
            });
        },
        showImage: function(n) {
            var s = this, o = n.requestCode, p = n.appletsfp, r = n.isPage, l = n.helpUrl;
            a.fenvp.e(), i = new t.default(), p && this.setData({
                appletsfp: p
            });
            var u = this, d = getApp().globalData.yoda_component_data;
            u.initData({
                requestCode: o,
                appletsfp: p,
                data: d,
                isPage: r,
                helpUrl: l
            });
            var g = !!e.mtShare;
            ("undefined" != typeof mmp || g) && e.getRiskControlFingerprint({
                success: function(e) {
                    var t = e.fingerprint;
                    s.setData({
                        fp: t
                    });
                }
            });
        },
        initData: function(e) {
            var t = e.requestCode, a = e.appletsfp, i = e.data, n = e.isPage, s = e.helpUrl;
            this.setData({
                data: i,
                requestCode: t,
                imgsrc: getApp().globalData.yodaUrl + "/v2/captcha?request_code=" + t + "&action=" + i.action + "&captchaHash=" + Number(new Date()),
                opacity: .5,
                plain: !0,
                isShow: "block",
                timestamp: i.timestamp,
                appletsfp: a,
                isPage: n,
                helpUrl: s
            });
        },
        bindImgVerify: function() {
            i.bindImgVerify(this.data, this);
        },
        bingUpdateImg: function() {
            i.changeImage(this);
        },
        bindImgCodeInput: function(e) {
            var t = e.detail.value;
            i.bindImgCodeInput(t, this);
        },
        bindblurCode: function(e) {
            this.bindImgCodeInput(e);
        },
        bingimgClose: function() {
            this.setData({
                isShow: "none",
                value: ""
            }), this.triggerEvent ? this.triggerEvent("imageevent", {
                status: 0,
                code: 33333,
                msg: "主动关闭图片验证"
            }, {
                bubbles: !0,
                composed: !0
            }) : this.props.imageevent({
                status: 0,
                code: 33333,
                msg: "主动关闭图片验证"
            });
        },
        bindimgHelp: function() {
            var t = this.data, a = t.requestCode, i = t.helpUrl, n = "../../modules/index/public?type=help&requestCode=" + a;
            i && (n = i + "?type=help&requestCode=" + a), e.navigateTo({
                url: n
            });
        },
        changeVerify: function() {
            i.changeVerify();
        }
    }
});