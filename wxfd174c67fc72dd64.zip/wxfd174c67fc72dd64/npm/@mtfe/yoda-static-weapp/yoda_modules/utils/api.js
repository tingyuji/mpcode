function e(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

var t = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
}, o = require("../../../weapp-privacy-api/index.js").default;

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var a = "function" == typeof Symbol && "symbol" == t(Symbol.iterator) ? function(e) {
    return void 0 === e ? "undefined" : t(e);
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : void 0 === e ? "undefined" : t(e);
}, n = function() {
    function e(e, t) {
        for (var o = 0; o < t.length; o++) {
            var a = t[o];
            a.enumerable = a.enumerable || !1, a.configurable = !0, "value" in a && (a.writable = !0), 
            Object.defineProperty(e, a.key, a);
        }
    }
    return function(t, o, a) {
        return o && e(t.prototype, o), a && e(t, a), t;
    };
}(), r = require("./config"), c = require("./union"), i = function() {
    function t() {
        e(this, t);
    }
    return n(t, [ {
        key: "getPageData",
        value: function(e, t) {
            var a = {
                requestCode: e,
                feVersion: "2.4.3",
                source: r.source,
                layer: t
            };
            return new Promise(function(e, t) {
                var n = r.YodaServer.getYodaServer().getServer() + "/v2/ext_api/page_data";
                o.request({
                    method: "POST",
                    url: n,
                    data: a,
                    timeout: 5e3,
                    header: {
                        "Content-Type": "application/x-www-form-urlencoded"
                    },
                    success: function(o) {
                        var a = o.data, n = a.status, r = a.data, c = a.error;
                        200 === o.statusCode || 200 === o.status ? e({
                            status: n,
                            data: r,
                            error: c
                        }) : t(o);
                    },
                    fail: function(e) {
                        t(e);
                    }
                });
            }).catch(function(e) {
                o.showToast({
                    icon: "none",
                    title: e.message,
                    content: e.message,
                    duration: 3e3
                });
            });
        }
    }, {
        key: "sendInfo",
        value: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = e.request_code, n = e.type, c = e.action, i = void 0 === c ? "" : c, s = e.options, u = void 0 === s ? null : s, l = e.timestamp, d = e.authencation, p = {
                request_code: t
            };
            u && "object" === (void 0 === u ? "undefined" : a(u)) && Object.keys(u).forEach(function(e) {
                Object.prototype.hasOwnProperty.call(u, e) && (p[e] = u[e]);
            });
            var f = {
                "Content-Type": "application/x-www-form-urlencoded"
            };
            return l && (f.timesTamp = l), d && (f.authencation = d), new Promise(function(e, t) {
                o.request({
                    url: r.YodaServer.getYodaServer().getServer() + "/v2/ext_api/" + i + "/info?id=" + n,
                    method: "POST",
                    data: p,
                    timeout: 5e3,
                    header: f,
                    success: function(o) {
                        var a = o.data, n = a.status, r = a.data, c = a.error;
                        200 === o.statusCode || 200 === o.status ? e({
                            status: n,
                            data: r,
                            error: c
                        }) : t("");
                    },
                    fail: function(e) {
                        t(e);
                    }
                });
            }).catch(function() {
                o.showToast({
                    icon: "none",
                    title: "获取sendInfo失败",
                    content: "获取sendInfo失败",
                    duration: 3e3
                });
            });
        }
    }, {
        key: "verify",
        value: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = e.request_code, n = e.type, c = e.action, i = void 0 === c ? "" : c, s = e.options, u = e.authencation, l = e.timestamp, d = {
                request_code: t
            };
            s && "object" === (void 0 === s ? "undefined" : a(s)) && Object.keys(s).forEach(function(e) {
                Object.prototype.hasOwnProperty.call(s, e) && (d[e] = s[e]);
            });
            var p = {
                "Content-Type": "application/x-www-form-urlencoded"
            };
            return l && (p.timesTamp = l), u && (p.authencation = u), new Promise(function(e, t) {
                o.request({
                    url: r.YodaServer.getYodaServer().getServer() + "/v2/ext_api/" + i + "/verify?id=" + n,
                    method: "POST",
                    data: d,
                    timeout: 5e3,
                    header: p,
                    success: function(o) {
                        if (200 === o.statusCode || 200 === o.status) {
                            var a = o.data, n = a.status, r = a.data, c = a.error;
                            1 === n && r && (r.request_code = r.origin_request_code ? r.origin_request_code : d.request_code), 
                            e({
                                status: n,
                                data: r,
                                error: c
                            });
                        } else t();
                    },
                    fail: function(e) {
                        t(e);
                    }
                });
            }).catch(function() {
                o.showToast({
                    icon: "none",
                    title: "获取verify失败",
                    content: "获取verify失败",
                    duration: 3e3
                });
            });
        }
    }, {
        key: "nextVerify",
        value: function(e, t) {
            if (t && (e || 0 === e)) {
                var a = getApp().globalData.yodaPageData || {};
                return a.type = t, a.listIndex = e, "GROUP" !== a.category && "MULTIPLE" !== a.category || !e && 0 !== e || (getApp().globalData.yodaPageData = a, 
                o.redirectTo({
                    url: "./../../modules/index/index"
                })), !0;
            }
            return !1;
        }
    }, {
        key: "nextPMVerify",
        value: function(e) {
            var t = getApp().globalData.yodaPageData || {}, a = t.env, n = t.appletsfp, r = t.options, c = r.navigate, i = r.delta;
            o.redirectTo({
                url: "./../../modules/index/index?requestCode=" + e + "&env=" + a + "&appletsfp=" + n + "&navigate=" + c + "&delta=" + i
            });
        }
    }, {
        key: "navigate",
        value: function(e) {
            var t = e.options, a = e.url;
            if (o.removeStorage({
                key: "yodaPageData",
                success: function() {
                    return 0;
                }
            }), t && "back" === t.navigate) {
                var n = a.split("?")[1].split("&"), r = Object.create(null);
                n.forEach(function(e) {
                    var t = e.split("=");
                    r[t[0]] = t[1];
                }), "function" == typeof getApp().globalData.YodaBackFunc && getApp().globalData.YodaBackFunc(r);
                var c = t.delta || 1;
                c = Number(c), o.navigateBack({
                    delta: c
                });
            } else o.redirectTo({
                url: a
            });
        }
    }, {
        key: "successCallback",
        value: function(e, t, o) {
            var a = getApp().globalData.YodaSuccess || "";
            if ("function" == typeof a) a({
                status: 1,
                requestCode: e,
                responseCode: t
            }); else {
                var n = "status=1&requestCode=" + e + "&responseCode=" + t;
                n = a.includes("?") ? "&" + n : "?" + n, this.navigate({
                    options: o,
                    url: a + n
                });
            }
        }
    }, {
        key: "failCallback",
        value: function(e, t, o) {
            var a = getApp().globalData.YodaFail || "";
            if ("function" == typeof a) a({
                status: 0,
                code: e,
                msg: t
            }); else {
                var n = "status=0&code=" + e + "&msg=" + t;
                n = a.includes("?") ? "&" + n : "?" + n, this.navigate({
                    options: o,
                    url: a + n
                });
            }
        }
    }, {
        key: "catchCallback",
        value: function(e, t, a, n, r, c) {
            var i = this;
            "face" !== c ? o.showToast({
                title: e,
                content: e,
                icon: "none",
                mask: !0,
                duration: 3e3,
                complete: function() {
                    i.failCallback(t, a, n);
                }
            }) : this.failCallback(t, a, n);
        }
    }, {
        key: "toComponent",
        value: function(e, t) {
            var o = getApp().globalData.yodaPageData || {}, a = {
                requestCode: t,
                env: o.env,
                appletsfp: o.appletsfp
            };
            !e.Yoda && e.selectComponent ? e.selectComponent("#yoda").init(a) : e.Yoda.init(a);
        }
    }, {
        key: "errorCallback",
        value: function(e, t, a, n, c) {
            var i = e.code || 0, s = e.message || "验证异常";
            switch (Object.keys(r.closeStatus).forEach(function(e) {
                Number(r.closeStatus[e]) === i && (i = "jump");
            }), i) {
              case 121008:
                o.showToast({
                    icon: "none",
                    title: "验证错误",
                    content: "验证错误",
                    complete: a.bind(n)
                });
                break;

              case 121068:
                o.showToast({
                    icon: "none",
                    title: "输入错误",
                    content: "输入错误",
                    complete: a.bind(n)
                });
                break;

              case 121038:
                o.showToast({
                    icon: "none",
                    title: "操作过于频繁",
                    content: "操作过于频繁"
                });
                break;

              case 121044:
                this.catchCallback("授权码过期", e.code, s, t, n);
                break;

              case 121048:
              case 121060:
                this.toComponent(n, e.request_code);
                break;

              case 121117:
                this.nextPMVerify(e.request_code);
                break;

              case 121047:
              case 121054:
                o.showToast({
                    icon: "none",
                    title: "请重新发送验证",
                    content: "请重新发送验证",
                    complete: a.bind(n)
                });
                break;

              case 121079:
              case 121095:
                o.showToast({
                    icon: "none",
                    title: "请重新操作",
                    content: "请重新操作",
                    complete: a.bind(n)
                });
                break;

              case 121084:
              case 121101:
                o.showToast({
                    icon: "none",
                    title: "人脸比对未通过",
                    content: "人脸比对未通过",
                    complete: a.bind(n)
                });
                break;

              case 121100:
                o.showToast({
                    icon: "none",
                    title: "人脸多于一个,请核实后重试",
                    content: "人脸多于一个,请核实后重试",
                    complete: a.bind(n)
                });
                break;

              case 121102:
                o.showToast({
                    icon: "none",
                    title: "人脸对比失败,请重试",
                    content: "人脸对比失败,请重试",
                    complete: a.bind(n)
                });
                break;

              case 130003:
                o.showToast({
                    icon: "none",
                    title: "数据上传失败,请重试",
                    content: "数据上传失败,请重试",
                    complete: a.bind(n)
                });
                break;

              case 121063:
                o.showToast({
                    icon: "none",
                    title: "密码错误",
                    content: "密码错误",
                    complete: a.bind(n)
                });
                break;

              case "jump":
              default:
                this.catchCallback(s, e.code, s, t, n, c);
            }
        }
    }, {
        key: "callWebViewAndComponent",
        value: function(e) {
            var t = e.status, o = e.requestCode, a = e.responseCode, n = e.code, c = e.msg, i = getApp().globalData.yodaPageData || {};
            t === r.callStatus.SUCCESS || a ? this.successCallback(o, a, i.options) : this.failCallback(n, c, i.options);
        }
    }, {
        key: "changeVerify",
        value: function() {
            var e = getApp().globalData.yodaPageData || {};
            e.type = -1, "GROUP" === e.category && (getApp().globalData.yodaPageData = e, o.redirectTo({
                url: "./../../modules/index/index"
            }));
        }
    }, {
        key: "toWebView",
        value: function(e) {
            var t = e.requestCode, a = e.env, n = e.listIndex, r = !0, c = this;
            o.navigateTo({
                url: "./public?requestCode=" + t + "&env=" + a + "&listIndex=" + n,
                events: {
                    someEvent: function(e) {
                        r = !1;
                        var o = {
                            status: e.code ? 0 : 1,
                            requestCode: t,
                            responseCode: e.responseCode,
                            code: e.code,
                            msg: e.msg
                        };
                        c.callWebViewAndComponent(o);
                    },
                    backEvent: function() {
                        if (r) {
                            var e = getCurrentPages();
                            -1 !== e[0].route.indexOf("modules/index/index") && -1 !== e[1].route.indexOf("modules/index/public") ? c.callWebViewAndComponent({
                                status: 0,
                                requestCode: t,
                                responseCode: "",
                                code: "33333",
                                msg: "主动退出验证"
                            }) : o.navigateBack();
                        }
                    }
                }
            });
        }
    } ], [ {
        key: "encrypt",
        value: function(e, t) {
            var o = c.common.crypto.utils.utf8.toBytes(e), a = new c.common.crypto.ModeOfOperationCBX(o, [ 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36 ]), n = c.common.crypto.padding.pkcs7.pad(c.common.crypto.utils.utf8.toBytes(t)), r = a.encrypt(n);
            return c.common.crypto.utils.hex.fromBytes(r);
        }
    } ]), t;
}();

exports.default = i;