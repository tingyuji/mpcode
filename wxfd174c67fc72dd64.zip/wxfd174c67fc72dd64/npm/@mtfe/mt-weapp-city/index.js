function t(t, o) {
    var e = {};
    for (var i in t) o.indexOf(i) >= 0 || Object.prototype.hasOwnProperty.call(t, i) && (e[i] = t[i]);
    return e;
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var o = Object.assign || function(t) {
    for (var o = 1; o < arguments.length; o++) {
        var e = arguments[o];
        for (var i in e) Object.prototype.hasOwnProperty.call(e, i) && (t[i] = e[i]);
    }
    return t;
}, e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
    return typeof t;
} : function(t) {
    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
}, i = require("../weapp-privacy-api/index.js").default, n = function() {}, r = void 0, a = void 0, c = void 0, u = void 0, l = void 0, s = void 0, p = void 0, d = "https://mars.meituan.com/locate/v3/sdk/loc", m = i.request, y = {
    storageName: "mt_cityInfo",
    noCache: !1,
    wxApiSuc: n,
    wxApiFail: n,
    ipApiSuc: n,
    ipApiFail: n,
    sdkGetCityInfoSuc: n,
    sdkGetCityInfoFail: n,
    sdkGetLocationSuc: n,
    sdkGetLocationFail: n,
    sdkWxLocationSuc: n,
    sdkWxLocationFail: n,
    sdkGetLocationWay: n,
    sdkGetLocationDiff: n,
    sdkGetLocationIpSuc: n,
    sdkGetLocationIpFail: n,
    publicReport: n
}, f = {
    _locProm: null,
    _locCityProm: null,
    _cityProm: null,
    _ipGeoProm: null,
    _marsProm: null,
    _marsCityProm: null,
    _marsLocCityProm: null
}, g = {
    getCityInfoDuration: null,
    getLocationDuration: null,
    wxLocationDuration: null,
    getLocationWayDuration: null,
    getLocationIpDuration: null,
    cityDiff: {
        IP: {},
        WX: {},
        res: {}
    }
}, C = "5fed16eee51b690d8c822db6b726e82f", I = {
    IP: "IP",
    WX: "WX"
}, P = {
    SUCC: "success",
    FAIL: "fail"
}, L = function(t, o, i, n) {
    if (y && y[t] && !g[o]) {
        var r = Date.now() - i;
        g[o] = r;
        var a = {
            duration: r
        };
        n && "object" === (void 0 === n ? "undefined" : e(n)) && Object.assign(a, n), y[t](a);
    }
}, R = function(t) {
    try {
        return parseFloat && "function" == typeof parseFloat && parseFloat(t) || t;
    } catch (o) {
        return t;
    }
}, D = function(t) {
    return Math.PI / 180 * t;
}, _ = function(t, o, e, i) {
    var n = 6367e3 * D(o - i) * Math.cos(D((t + e) / 2)), r = 6367e3 * D(t - e);
    return Math.sqrt(n * n + r * r) / 1e3;
}, b = function() {
    if (g.cityDiff.WX && void 0 !== g.cityDiff.WX.longitude && void 0 !== g.cityDiff.WX.latitude && void 0 !== g.cityDiff.WX.id && g.cityDiff.IP && void 0 !== g.cityDiff.IP.longitude && void 0 !== g.cityDiff.IP.latitude && void 0 !== g.cityDiff.IP.id && (!g.cityDiff.res || !0 !== g.cityDiff.res.hasReport)) {
        var t = _(g.cityDiff.WX.latitude, g.cityDiff.WX.longitude, g.cityDiff.IP.latitude, g.cityDiff.IP.longitude);
        g.cityDiff.res = {
            distance: t,
            sameId: g.cityDiff.WX.id === g.cityDiff.IP.id
        }, y.sdkGetLocationDiff && y.sdkGetLocationDiff(g.cityDiff), g.cityDiff.res.hasReport = !0;
    }
}, v = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {
        latest: !1,
        useIpGeo: !0
    }, n = e.latest, r = void 0 !== n && n, a = e.useIpGeo, c = void 0 === a || a, u = e.timeout, s = void 0 === u ? 5e3 : u, p = t(e, [ "latest", "useIpGeo", "timeout" ]);
    if (p.type && delete p.type, l && !r) return Promise.resolve(l);
    if (f._locProm) return f._locProm;
    var d = Date.now();
    return f._locProm = new Promise(function(t, e) {
        var n = G();
        s && setTimeout(function() {
            f._locProm && n.then(function(o) {
                l = o, f._locProm = null, L("sdkGetLocationSuc", "getLocationDuration", d), L("sdkGetLocationWay", "getLocationWayDuration", d, {
                    step: "ip-timeout"
                }), y && y.publicReport && y.publicReport("getLocation", P.SUCC, {
                    method: "ip-timeout"
                }), l.getLocationType = I.IP, t(l);
            }).catch(function(t) {
                f._locProm = null, L("sdkGetLocationFail", "getLocationDuration", d), y && y.publicReport && y.publicReport("getLocation", P.FAIL, {
                    method: "ip-timeout"
                }, t), e({
                    code: "103",
                    msg: "通过ip获取经纬度失败",
                    error: t
                });
            });
        }, s), i.getLocation(o({
            type: "wgs84"
        }, p, {
            success: function(o) {
                y && y.wxApiSuc && y.wxApiSuc(), L("sdkGetLocationSuc", "getLocationDuration", d), 
                L("sdkGetLocationWay", "getLocationWayDuration", d, {
                    step: "wxapi"
                }), y && y.publicReport && f._locProm && y.publicReport("getLocation", P.SUCC, {
                    method: "wxapi"
                }), L("sdkWxLocationSuc", "wxLocationDuration", d), (l = o).getLocationType = I.WX, 
                l.timeId = Date.now() || new Date().getTime(), g.cityDiff.WX = {
                    latitude: o.latitude,
                    longitude: o.longitude
                }, t(l);
            },
            fail: function(o) {
                y && y.wxApiFail && y.wxApiFail(o), L("sdkWxLocationFail", "wxLocationDuration", d), 
                c ? n.then(function(o) {
                    l = o, L("sdkGetLocationSuc", "getLocationDuration", d), L("sdkGetLocationWay", "getLocationWayDuration", d, {
                        step: "ip-wxapifail"
                    }), y && y.publicReport && f._locProm && y.publicReport("getLocation", P.SUCC, {
                        method: "ip-wxapifail"
                    }), l.getLocationType = I.IP, t(l);
                }).catch(function(t) {
                    L("sdkGetLocationFail", "getLocationDuration", d), y && y.publicReport && f._locProm && y.publicReport("getLocation", P.FAIL, {
                        method: "ip-wxapifail"
                    }, t), e({
                        code: "103",
                        msg: "通过ip获取经纬度失败",
                        error: t
                    });
                }) : (L("sdkGetLocationFail", "getLocationDuration", d), y && y.publicReport && f._locProm && y.publicReport("getLocation", P.FAIL, {
                    method: "wxapi"
                }, o), e({
                    code: "101",
                    msg: "wx获取定位信息失败",
                    error: o
                }));
            },
            complete: function() {
                f._locProm = null;
            }
        }));
    }), f._locProm;
}, h = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {
        useIpGeo: !0,
        timeout: 5e3,
        latest: !1
    }, n = e.useIpGeo, r = void 0 === n || n, a = e.timeout, c = void 0 === a ? 5e3 : a, u = e.latest, l = void 0 !== u && u, p = t(e, [ "useIpGeo", "timeout", "latest" ]);
    return s && !l ? Promise.resolve(s) : f._marsProm ? f._marsProm : (f._marsProm = new Promise(function(t, e) {
        var n = r ? new Promise(function(t, o) {
            (m || i.request)({
                unforced: !0,
                url: d,
                method: "POST",
                header: {
                    "X-Request-Source": C,
                    "X-Request-Medium": "",
                    "X-Request-ID": Date.now() || new Date().getTime(),
                    "X-Request-Agent": "",
                    "X-Request-Platform": 4,
                    "content-type": "application/json"
                },
                data: {
                    need_poi: -1,
                    need_openCity: 1,
                    coord_type: "GCJ02"
                },
                success: function(e) {
                    var i = e.data && e.data.data;
                    i && i.location && i.location.latitude && i.location.longitude ? t({
                        latitude: i.location.latitude,
                        longitude: i.location.longitude
                    }) : o(e);
                },
                fail: function(t) {
                    o(t);
                }
            });
        }) : Promise.resolve();
        setTimeout(function() {
            f._marsProm && r && n.then(function(o) {
                f._marsProm = null, s = o, y && y.publicReport && y.publicReport("getMarsLocation", P.SUCC, {
                    method: "ip-timeout"
                }), t(s);
            }).catch(function(t) {
                f._marsProm = null, y && y.publicReport && y.publicReport("getMarsLocation", P.FAIL, {
                    method: "ip-timeout"
                }, t), e({
                    code: "103",
                    msg: "通过ip获取经纬度失败",
                    error: t
                });
            });
        }, c), i.getLocation(o({}, p, {
            type: "gcj02",
            success: function(o) {
                f._marsProm = null, (s = o).timeId = Date.now() || new Date().getTime(), y && y.publicReport && f._marsProm && y.publicReport("getMarsLocation", P.SUCC, {
                    method: "wxapi"
                }), t(s);
            },
            fail: function(o) {
                r ? n.then(function(o) {
                    f._marsProm = null, s = o, y && y.publicReport && f._marsProm && y.publicReport("getMarsLocation", P.SUCC, {
                        method: "ip-wxapifail"
                    }), t(o);
                }).catch(function(t) {
                    f._marsProm = null, y && y.publicReport && f._marsProm && y.publicReport("getMarsLocation", P.FAIL, {
                        method: "ip-wxapifail"
                    }, t), e({
                        code: "103",
                        msg: "通过ip获取经纬度失败",
                        error: t
                    });
                }) : (y && y.publicReport && f._marsProm && y.publicReport("getMarsLocation", P.FAIL, {
                    method: "wxapi"
                }, o), e({
                    code: "101",
                    msg: "wx获取定位信息失败",
                    error: o
                }));
            },
            complete: function() {
                f._marsProm = null;
            }
        }));
    }), f._marsProm);
}, w = function() {
    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {
        latest: !1,
        useIpGeo: !0,
        timeout: 5e3
    }, o = t.latest, e = void 0 !== o && o;
    t.useIpGeo, t.timeout;
    return u && !e ? Promise.resolve(u) : f._marsLocCityProm ? f._marsLocCityProm : (f._marsLocCityProm = new Promise(function(o, e) {
        h(t).then(function(t) {
            var n = Date.now() || new Date().getTime();
            (m || i.request)({
                url: d,
                method: "POST",
                unforced: !0,
                header: {
                    "X-Request-Source": C,
                    "X-Request-Medium": "",
                    "X-Request-ID": n,
                    "X-Request-Agent": "",
                    "X-Request-Platform": 4,
                    "content-type": "application/json"
                },
                data: {
                    need_poi: -1,
                    need_openCity: 1,
                    location: {
                        id: t.timeId || Date.now() || new Date().getTime(),
                        longitude: R(t.longitude),
                        latitude: R(t.latitude),
                        accuracy: R(t.accuracy) || 0,
                        location: "GCJ02"
                    },
                    coord_type: "GCJ02"
                },
                success: function(i) {
                    if (i && i.data && 200 === i.data.code && i.data.data) {
                        var n = i.data.data || {};
                        n.lat = n.location && n.location.latitude, n.lng = n.location && n.location.longitude, 
                        n.detail = n.address && n.address.detail, n.city = n.address && n.address.city, 
                        n.country = n.address && n.address.country, n.district = n.address && n.address.district, 
                        n.province = n.address && n.address.province, n.openCity && n.openCity.mtId ? (n.name = n.openCity && n.openCity.name, 
                        n.id = n.openCity && n.openCity.mtId, n.cityPinyin = n.openCity && n.openCity.pinyin, 
                        n.originCityID = n.openCity && n.openCity.originCityId) : (n.name = "北京", n.id = 1, 
                        n.originCityID = 0, n.cityPinyin = "beijing", n.fakeCity = !0), (u = n).lat = t.latitude || n.lat, 
                        u.lng = t.longitude || n.lng, y && y.publicReport && y.publicReport("getMarsLocalCity", P.SUCC), 
                        o(u);
                    } else y && y.publicReport && y.publicReport("getMarsLocalCity", P.FAIL, {}, i), 
                    e({
                        code: "102",
                        msg: "获取定位城市失败",
                        error: i
                    });
                },
                fail: function(t) {
                    f._marsLocCityProm = null, y && y.publicReport && y.publicReport("getMarsLocalCity", P.FAIL, {}, t), 
                    e({
                        code: "102",
                        msg: "获取定位城市失败",
                        error: t
                    });
                }
            });
        }).catch(function(t) {
            y && y.publicReport && y.publicReport("getMarsLocalCity", P.FAIL, {}, t), f._marsLocCityProm = null, 
            e(t);
        });
    }), f._marsLocCityProm);
}, G = function() {
    if (f._ipGeoProm) return f._ipGeoProm;
    var t = Date.now() || new Date().getTime();
    return f._ipGeoProm = new Promise(function(o, e) {
        (m || i.request)({
            url: d,
            method: "POST",
            unforced: !0,
            header: {
                "X-Request-Source": C,
                "X-Request-Medium": "",
                "X-Request-ID": t,
                "X-Request-Agent": "",
                "X-Request-Platform": 4,
                "content-type": "application/json"
            },
            data: {
                need_poi: -1,
                need_openCity: 1,
                coord_type: "WGS84"
            },
            success: function(i) {
                f._ipGeoProm = null;
                var n = i.data && i.data.data, r = n && n.address, a = n && n.location, c = n && n.openCity;
                a && a.longitude && a.latitude ? (y && y.ipApiSuc && y.ipApiSuc(), g.cityDiff.IP = {
                    latitude: a.latitude,
                    longitude: a.longitude,
                    id: c && c.mtId,
                    requestId: t
                }, b(), y && y.publicReport && y.publicReport("getGeoByIp", P.SUCC), o({
                    latitude: a.latitude,
                    longitude: a.longitude,
                    address: r,
                    location: a,
                    openCity: c
                })) : (y && y.ipApiFail && y.ipApiFail(), y && y.publicReport && y.publicReport("getGeoByIp", P.FAIL, {}, i), 
                e(i));
            },
            fail: function(t) {
                y && y.ipApiFail && y.ipApiFail(), y && y.publicReport && y.publicReport("getGeoByIp", P.FAIL, {}, t), 
                f._ipGeoProm = null, e(t);
            }
        });
    }), f._ipGeoProm;
}, S = function() {
    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {
        latest: !1,
        useIpGeo: !0,
        timeout: 5e3
    }, o = t.latest, e = void 0 !== o && o;
    t.useIpGeo, t.timeout;
    if (c && !e) return Promise.resolve(c);
    if (f._locCityProm) return f._locCityProm;
    var n = Date.now();
    return f._locCityProm = new Promise(function(o, e) {
        v(t).then(function(t) {
            if (t && "IP" === t.getLocationType && t.openCity && t.openCity.mtId) return t.name = t.openCity.name, 
            t.lat = t.latitude, t.lng = t.longitude, t.id = t.openCity.mtId, t.detail = t.address && t.address.detail, 
            t.city = t.address && t.address.city, t.cityPinyin = t.openCity.pinyin, t.country = t.address && t.address.country, 
            t.district = t.address && t.address.district, t.originCityID = t.openCity.originCityId, 
            t.province = t.address && t.address.province, void o(t);
            var r = Date.now() || new Date().getTime();
            (m || i.request)({
                url: d,
                method: "POST",
                unforced: !0,
                header: {
                    "X-Request-Source": C,
                    "X-Request-Medium": "",
                    "X-Request-ID": r,
                    "X-Request-Agent": "",
                    "X-Request-Platform": 4,
                    "content-type": "application/json"
                },
                data: {
                    need_poi: -1,
                    need_openCity: 1,
                    location: {
                        id: t.timeId || Date.now() || new Date().getTime(),
                        longitude: R(t.longitude),
                        latitude: R(t.latitude),
                        accuracy: R(t.accuracy) || 0,
                        location: "WGS84"
                    },
                    coord_type: "WGS84"
                },
                success: function(i) {
                    if (i && i.data && 200 === i.data.code && i.data.data) {
                        var a = i.data.data || {};
                        a.lat = a.location && a.location.latitude, a.lng = a.location && a.location.longitude, 
                        a.detail = a.address && a.address.detail, a.city = a.address && a.address.city, 
                        a.country = a.address && a.address.country, a.district = a.address && a.address.district, 
                        a.province = a.address && a.address.province, a.openCity && a.openCity.mtId ? (a.name = a.openCity && a.openCity.name, 
                        a.id = a.openCity && a.openCity.mtId, a.cityPinyin = a.openCity && a.openCity.pinyin, 
                        a.originCityID = a.openCity && a.openCity.originCityId) : (a.name = "北京", a.id = 1, 
                        a.originCityID = 0, a.cityPinyin = "beijing", a.fakeCity = !0), (c = a).lat = t.latitude || a.lat, 
                        c.lng = t.longitude || a.lng, L("sdkGetCityInfoSuc", "getCityInfoDuration", n), 
                        g.cityDiff.WX.id = a.id, g.cityDiff.WX.requestId = r, b(), y && y.publicReport && y.publicReport("getLocalCity", P.SUCC), 
                        o(c);
                    } else L("sdkGetCityInfoFail", "getCityInfoDuration", n), y && y.publicReport && y.publicReport("getLocalCity", P.FAIL, {}, i), 
                    e({
                        code: "102",
                        msg: "获取定位城市失败",
                        error: i
                    });
                },
                fail: function(t) {
                    L("sdkGetCityInfoFail", "getCityInfoDuration", n), f._locCityProm = null, y && y.publicReport && y.publicReport("getLocalCity", P.FAIL, {}, t), 
                    e({
                        code: "102",
                        msg: "获取定位城市失败",
                        error: t
                    });
                }
            });
        }).catch(function(t) {
            y && y.publicReport && y.publicReport("getLocalCity", P.FAIL, {}, t), L("sdkGetCityInfoFail", "getCityInfoDuration", n), 
            f._locCityProm = null, e(t);
        });
    }), f._locCityProm;
}, x = function(t, o) {
    try {
        i.setStorageSync(y.storageName, {
            value: t,
            timestamp: o || new Date(new Date().toLocaleDateString()).getTime()
        });
    } catch (t) {
        console.log(t);
    }
};

exports.cityInfo = function() {
    return r;
}, exports.setRequestCfg = function(t) {
    var o = t.api, e = t.request;
    o && (d = o), e && (m = e);
}, exports.location = function() {
    return l;
}, exports.localCity = function() {
    return c;
}, exports.marsLocCity = function() {
    return u;
}, exports.getCityInfo = function() {
    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {
        latest: !1,
        useIpGeo: !0,
        timeout: 5e3
    }, o = t.latest, e = void 0 !== o && o;
    t.useIpGeo, t.timeout;
    return r && !e ? Promise.resolve(r) : f._cityProm ? f._cityProm : (f._cityProm = new Promise(function(o, e) {
        S(t).then(function(t) {
            f._cityProm = null, r = t, y && y.publicReport && y.publicReport("getCityInfo", P.SUCC), 
            o(r);
        }).catch(function(t) {
            f._cityProm = null, y && y.publicReport && y.publicReport("getCityInfo", P.FAIL, {}, t), 
            e(t);
        });
    }), f._cityProm);
}, exports.getLocalCity = S, exports.getLocation = v, exports.setCityInfo = function(t, o) {
    return t && t.id && t.name ? (r = t, y.noCache || x(t, o ? o.timestamp : null), 
    {
        code: "success",
        msg: "设置城市信息成功"
    }) : {
        code: "error",
        msg: "缺少城市信息"
    };
}, exports.setConfig = function(t) {
    return Object.assign(y, t);
}, exports.getConfig = function() {
    return y;
}, exports.getGeoByIp = G, exports.getMarsLocation = h, exports.getMarsCityInfo = function() {
    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {
        latest: !1,
        useIpGeo: !0,
        timeout: 5e3
    }, o = t.latest, e = void 0 !== o && o;
    t.useIpGeo, t.timeout;
    return a && !e ? Promise.resolve(a) : f._marsCityProm ? f._marsCityProm : (f._marsCityProm = new Promise(function(o, e) {
        w(t).then(function(t) {
            y && y.publicReport && y.publicReport("getMarsCityInfo", P.SUCC), f._marsCityProm = null, 
            o(a = t);
        }).catch(function(t) {
            y && y.publicReport && y.publicReport("getMarsCityInfo", P.FAIL, {}, t), f._marsCityProm = null, 
            e(t);
        });
    }), f._marsCityProm);
}, exports.getMarsLocalCity = w, exports.getIpCityInfo = function() {
    var t = Date.now();
    return new Promise(function(o, e) {
        G().then(function(e) {
            L("sdkGetLocationIpSuc", "getLocationIpDuration", t), y && y.publicReport && y.publicReport("getIpCityInfo", P.SUCC), 
            e && (e.getLocationType = I.IP), p = e, o(e);
        }).catch(function(o) {
            L("sdkGetLocationIpFail", "getLocationIpDuration", t), y && y.publicReport && y.publicReport("getIpCityInfo", P.FAIL, {}, o), 
            e({
                code: "103",
                msg: "通过ip获取经纬度失败-预请求",
                error: o
            });
        });
    });
}, exports.ipCityInfo = function() {
    return p;
};