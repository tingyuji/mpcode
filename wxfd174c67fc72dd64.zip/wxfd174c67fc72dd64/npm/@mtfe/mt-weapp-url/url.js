Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.urlParse = exports.parse = exports.stringify = void 0;

var r = function() {
    function r(r, t) {
        var e = [], i = !0, n = !1, s = void 0;
        try {
            for (var o, a = r[Symbol.iterator](); !(i = (o = a.next()).done) && (e.push(o.value), 
            !t || e.length !== t); i = !0) ;
        } catch (r) {
            n = !0, s = r;
        } finally {
            try {
                !i && a.return && a.return();
            } finally {
                if (n) throw s;
            }
        }
        return e;
    }
    return function(t, e) {
        if (Array.isArray(t)) return t;
        if (Symbol.iterator in Object(t)) return r(t, e);
        throw new TypeError("Invalid attempt to destructure non-iterable instance");
    };
}(), t = require("./stringify"), e = require("./parse");

exports.stringify = t.stringify, exports.parse = e.parse;

exports.urlParse = function(i) {
    var n = i.match(/^(https?:)?(\/\/)?([^/?#]+)?(\/[^?#]*)?(\?([^#]*))?#?(.*)$/);
    if (!n) throw new Error("[urlSDK]parse error: wrong url" + i);
    var s = r(n, 8), o = s[1], a = s[3], h = s[4], u = void 0 === h ? "" : h, f = s[5], p = s[6], c = s[7];
    return {
        protocol: o,
        host: a,
        hostname: a.split(":")[0],
        search: f,
        pathname: u,
        hash: c,
        href: i,
        query: (0, e.parse)(p),
        getSearch: function() {
            var r = (0, t.stringify)(this.query);
            return r && "?" + r || "";
        },
        format: function() {
            var r = this.getSearch();
            return this.href = o + "//" + this.host + u + r + (this.hash ? "#" + this.hash : ""), 
            this.href;
        }
    };
};