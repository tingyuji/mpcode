Object.defineProperty(exports, "__esModule", {
    value: !0
});

var e = require("../mt-weapp-utils/lib/parse.js");

Object.keys(e).forEach(function(t) {
    "default" !== t && "__esModule" !== t && Object.defineProperty(exports, t, {
        enumerable: !0,
        get: function() {
            return e[t];
        }
    });
});