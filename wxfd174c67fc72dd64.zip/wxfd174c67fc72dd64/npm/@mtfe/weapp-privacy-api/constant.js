function o(o, e, a) {
    return e in o ? Object.defineProperty(o, e, {
        value: a,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : o[e] = a, o;
}

var e, a = require("./scopeConstant");

module.exports = {
    authorize: (e = {}, o(e, a.SCOPE + "." + a.USER_LOCATION, [ "Locate.once" ]), o(e, a.SCOPE + "." + a.USER_FUZZY_LOCATION, [ "Locate.once" ]), 
    o(e, a.SCOPE + "." + a.USER_LOCATION_BG, [ "Locate.continuous" ]), o(e, a.SCOPE + "." + a.WERUN, [ "Motion" ]), 
    o(e, a.SCOPE + "." + a.RECORD, [ "Microphone" ]), o(e, a.SCOPE + "." + a.WRITE_PHOTOS_ALBUM, [ "Photos" ]), 
    o(e, a.SCOPE + "." + a.CAMERA, [ "Camera" ]), o(e, a.SCOPE + "." + a.BLUETOOTH, [ "BlueTooth" ]), 
    o(e, a.SCOPE + "." + a.ADD_PHONE_CONTACT, [ "Contacts.write", "Contacts" ]), o(e, a.SCOPE + "." + a.ADD_PHONE_CALENDAR, [ "Calendar.write", "Calendar" ]), 
    e),
    getLocation: [ "Locate.once" ],
    getFuzzyLocation: [ "Locate.once" ],
    startLocationUpdate: [ "Locate.continuous" ],
    choosePoi: [ "Locate.once" ],
    chooseLocation: [ "Locate.once" ],
    startLocationUpdateBackground: [ "Locate.continuous" ],
    chooseContact: [ "Contacts.read", "Contacts" ],
    addPhoneContact: [ "Contacts.write", "Contacts" ],
    chooseImage: {
        album: [ "Photos" ],
        camera: [ "Camera" ]
    },
    chooseMedia: {
        album: [ "Photos" ],
        camera: [ "Camera" ]
    },
    chooseVideo: {
        album: [ "Photos" ],
        camera: [ "Camera" ]
    },
    previewImage: [ "Photos" ],
    createCameraContext: [ "Camera" ],
    saveImageToPhotosAlbum: [ "Photos" ],
    saveVideoToPhotosAlbum: [ "Photos" ],
    startRecord: [ "Microphone" ],
    joinVoIPChat: {
        voice: [ "Microphone" ],
        video: [ "Camera" ]
    },
    getRecorderManager: [ "Microphone" ],
    addPhoneCalendar: [ "Calendar.read", "Calendar" ],
    addPhoneRepeatCalendar: [ "Calendar.write", "Calendar" ],
    getWeRunData: [ "Motion" ],
    shareToWeRun: [ "Motion" ],
    startBeaconDiscovery: [ "BlueTooth" ],
    openBluetoothAdapter: [ "BlueTooth" ],
    startBluetoothDevicesDiscovery: [ "BlueTooth" ],
    createBLEPeripheralServer: [ "BlueTooth" ],
    getClipboardData: [ "Pasteboard" ],
    setClipboardData: [ "Pasteboard" ]
};