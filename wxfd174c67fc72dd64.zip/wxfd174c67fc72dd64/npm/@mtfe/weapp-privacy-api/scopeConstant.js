module.exports = {
    SCOPE: "scope",
    USER_LOCATION: "userLocation",
    USER_FUZZY_LOCATION: "userFuzzyLocation",
    USER_LOCATION_BG: "userLocationBackground",
    WERUN: "werun",
    RECORD: "record",
    WRITE_PHOTOS_ALBUM: "writePhotosAlbum",
    CAMERA: "camera",
    BLUETOOTH: "bluetooth",
    ADD_PHONE_CONTACT: "addPhoneContact",
    ADD_PHONE_CALENDAR: "addPhoneCalendar"
};