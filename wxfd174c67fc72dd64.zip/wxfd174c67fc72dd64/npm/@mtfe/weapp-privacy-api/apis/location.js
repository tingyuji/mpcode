function e(e, r, t) {
    return r in e ? Object.defineProperty(e, r, {
        value: t,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[r] = t, e;
}

function r(e, r, t) {
    var a = s[e] && s[e][r] || {}, o = a.data, n = a.startTime;
    return o && Date.now() - n < t ? o : null;
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.GET_FUZZY_LOCATION = exports.GET_LOCATION = void 0;

var t, a = Object.assign || function(e) {
    for (var r = 1; r < arguments.length; r++) {
        var t = arguments[r];
        for (var a in t) Object.prototype.hasOwnProperty.call(t, a) && (e[a] = t[a]);
    }
    return e;
};

exports.getLocationFn = function(e, t, T) {
    var v = e;
    return v !== l && v !== i && (v = l), function() {
        for (var e = arguments.length, l = Array(e), i = 0; i < e; i++) l[i] = arguments[i];
        var f = l[0] || {}, g = f.success, m = f.complete, d = f.fail, y = f.type, h = f._mt, O = (0, 
        o.getTokenDetail)(h && h.sceneToken, n[v][0]), b = O.specialPass, P = O.detail;
        if (b) return T[v].apply(T, l);
        if (!(0, o.checkIsPrivacyApi)(v, t)) {
            if (!P || !P.enable) {
                var _ = (0, o.getErrorMsg)(v);
                (0, o.errorReport)({
                    apiName: v,
                    subPackName: t,
                    err: _,
                    enablePrivacyAPI: !1,
                    args: l
                });
            }
            return T[v].apply(T, l);
        }
        if (!P || !P.enable) {
            var w = r(v, y || "wgs84", p);
            if (console.log("cacheData", v, w), w) return setTimeout(function() {
                g && g.call(l[0], w), m && m.call(l[0], w);
            }), d || g || m ? void 0 : Promise.resolve(w);
            var E = (0, o.getErrorMsg)(v);
            return (0, o.errorReport)({
                apiName: v,
                subPackName: t,
                err: E,
                args: l
            }), setTimeout(function() {
                d && d.call(l[0], E), m && m.call(l[0], E);
            }), d || g || m ? void 0 : Promise.reject(E);
        }
        if (P.perceptionType === c || P.perceptionType === u && P.threshold > 0) {
            var A = 9e5;
            P && P.perceptionType === c && (A = P.threshold > 0 ? 1e3 * P.threshold : p), P && P.perceptionType === u && (A = 1e3 * P.threshold);
            var G = r(v, y || "wgs84", A);
            if (console.log("cacheData", v, G), G) return setTimeout(function() {
                g && g.call(l[0], G), m && m.call(l[0], G);
            }), d || g || m ? void 0 : Promise.resolve(G);
        }
        return g && (l[0].success = function(e) {
            g.call(l[0], e), s[v][y || "wgs84"] = {
                data: a({}, e),
                startTime: Date.now()
            };
        }), T[v].apply(T, l);
    };
};

var o = require("../util"), n = require("../constant"), l = exports.GET_LOCATION = "getLocation", i = exports.GET_FUZZY_LOCATION = "getFuzzyLocation", s = (t = {}, 
e(t, l, {
    gcj02: {
        data: null,
        startTime: null
    },
    wgs84: {
        data: null,
        startTime: null
    }
}), e(t, i, {
    gcj02: {
        data: null,
        startTime: null
    },
    wgs84: {
        data: null,
        startTime: null
    }
}), t), c = "AUTO_TRIGGER", u = "USER_TRIGGER", p = 864e5;