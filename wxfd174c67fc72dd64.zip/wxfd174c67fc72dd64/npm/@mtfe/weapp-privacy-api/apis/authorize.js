Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getAuthorizeFn = function(e) {
    var i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : wx;
    return function() {
        for (var a = arguments.length, t = Array(a), o = 0; o < a; o++) t[o] = arguments[o];
        var s = t[0] || {}, u = s.fail, c = s.complete, p = s.success, n = (0, r.getApiPermission)({
            apiName: "authorize",
            subPackName: e,
            params: t[0]
        });
        if (!(0, r.checkIsPrivacyApi)("authorize", e)) {
            if (n.isPrivacyApi && !n.permission) {
                var l = (0, r.getErrorMsg)("authorize");
                (0, r.errorReport)({
                    apiName: "authorize",
                    subPackName: e,
                    err: l,
                    enablePrivacyAPI: !1,
                    args: t
                });
            }
            return i.authorize.apply(i, t);
        }
        if (console.log("result", n), n.isPrivacyApi && !n.permission) {
            var m = (0, r.getErrorMsg)("authorize");
            return (0, r.errorReport)({
                apiName: "authorize",
                subPackName: e,
                err: m,
                args: t
            }), setTimeout(function() {
                u && u.call(t[0], m), c && c.call(t[0], m);
            }), u || p || c ? void 0 : Promise.reject(m);
        }
        return i.authorize.apply(i, t);
    };
};

var r = require("../util");