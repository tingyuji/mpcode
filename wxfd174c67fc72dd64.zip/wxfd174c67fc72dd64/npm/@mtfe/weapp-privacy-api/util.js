function e() {
    g && (m || (m = !0, wx.request({
        method: "POST",
        url: P.devMode ? u : p,
        data: {
            app: P.app,
            os: "wxmini",
            hash: P.defaultConfig && P.defaultConfig.hash
        },
        success: function(e) {
            e.data && 200 === e.statusCode ? l = e.data : 304 === e.statusCode ? l = P.defaultConfig : m = !1, 
            P && P.getHornConfig && "function" == typeof P.getHornConfig && P.getHornConfig({
                status: "success",
                statusCode: e.statusCode,
                data: e.data || P.defaultConfig
            });
        },
        fail: function(e) {
            m = !1, console.warn("隐私接口拉取失败", e), P && P.getHornConfig && "function" == typeof P.getHornConfig && P.getHornConfig({
                status: "fail",
                statusCode: -1,
                error: e
            });
        }
    })));
}

function r(e) {
    return "[object Object]" === Object.prototype.toString.call(e);
}

function a(e) {
    return !r(e) || 0 === Object.keys(e).length;
}

function i(e) {
    var r = e.apiName, a = e.subPackName, i = e.err, n = e.args, s = e.enablePrivacyAPI, t = void 0 === s || s;
    setTimeout(function() {
        P && P.errorReport && "function" == typeof P.errorReport && P.errorReport({
            apiName: r,
            subPackName: a,
            err: i,
            args: n,
            enablePrivacyAPI: Boolean(t)
        });
    });
}

function n(e, r) {
    return -1 !== (Array.isArray(o[r]) ? o[r] : f).indexOf(e) && (console.warn(e + "当前为被管控隐私API"), 
    !0);
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.asyncWrapApi = function(e, r) {
    var a = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : wx;
    return function() {
        for (var s = arguments.length, t = Array(s), o = 0; o < s; o++) t[o] = arguments[o];
        var c = t[0] || {}, p = c.fail, u = c.complete, f = c.success, l = A({
            apiName: e,
            subPackName: r,
            params: t[0]
        });
        if (!n(e, r)) {
            if (l.isPrivacyApi && !l.permission) {
                var P = C(e);
                i({
                    apiName: e,
                    subPackName: r,
                    err: P,
                    enablePrivacyAPI: !1,
                    args: t
                });
            }
            return a[e].apply(a, t);
        }
        if (l.isPrivacyApi && !l.permission) {
            var g = C(e);
            return i({
                apiName: e,
                subPackName: r,
                err: g,
                args: t
            }), setTimeout(function() {
                p && p.call(t[0], g), u && u.call(t[0], g);
            }), p || f || u ? void 0 : Promise.reject(g);
        }
        return a[e].apply(a, t);
    };
}, exports.syncWrapApi = function(e, r) {
    var a = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : wx;
    return function() {
        for (var s = arguments.length, t = Array(s), o = 0; o < s; o++) t[o] = arguments[o];
        var c = A({
            apiName: e,
            subPackName: r,
            params: t[0]
        });
        if (!n(e, r)) {
            if (c.isPrivacyApi && !c.permission) {
                var p = C(e);
                i({
                    apiName: e,
                    subPackName: r,
                    err: p,
                    enablePrivacyAPI: !1,
                    args: t
                });
            }
            return a[e].apply(a, t);
        }
        if (c.isPrivacyApi && !c.permission) {
            var u = C(e);
            return i({
                apiName: e,
                subPackName: r,
                err: u,
                args: t
            }), null;
        }
        return a[e].apply(a, t);
    };
}, exports.errorReport = i, exports.checkIsPrivacyApi = n, exports.getEnablePrivacyApiList = function(e) {
    return o[e];
};

var s = require("./config"), t = require("./constant"), o = require("./enablePrivacyApiConfig"), c = require("./scopeConstant"), p = "https://p.meituan.com/api/privacy/config", u = "https://p.fe.test.sankuai.com/api/privacy/config", f = Object.keys(t), l = null, P = {
    defaultConfig: s.mtweapp,
    app: "mtweapp",
    enablePrivacyApiList: f,
    errorReport: function() {},
    getHornConfig: function() {},
    devMode: !1
}, g = !1, m = !1, v = function() {
    return l || (e(), s[P.app]);
}, y = exports.getTokenDetail = function(e, r) {
    var i = v();
    return a(i) ? (console.warn("配置文件拉取失败，本次鉴权默认通过"), {
        specialPass: !0
    }) : e ? {
        detail: i.business && i.business[e] && i.business[e].permission && i.business[e].permission[r]
    } : {};
}, d = function(e) {
    var r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [], i = v();
    return a(i) ? (console.warn("配置文件拉取失败，本次鉴权默认通过"), !0) : !!e && (!(!i.features || !i.features[e]) && !!i.features[e].filter(function(e) {
        return r.indexOf(e) > -1;
    }).length);
}, A = exports.getApiPermission = function(e) {
    var r = e.apiName, a = (e.subPackName, e.params), i = a || {}, n = i.sourceType, s = i.roomType, o = a || {}, p = o._mt, u = o.scope, f = o.showmenu;
    switch (r) {
      case "authorize":
        switch (u) {
          case c.SCOPE + "." + c.USER_LOCATION:
          case c.SCOPE + "." + c.WERUN:
          case c.SCOPE + "." + c.RECORD:
          case c.SCOPE + "." + c.WRITE_PHOTOS_ALBUM:
          case c.SCOPE + "." + c.CAMERA:
          case c.SCOPE + "." + c.BLUETOOTH:
          case c.SCOPE + "." + c.USER_FUZZY_LOCATION:
          case c.SCOPE + "." + c.ADD_PHONE_CONTACT:
          case c.SCOPE + "." + c.ADD_PHONE_CALENDAR:
            return {
                isPrivacyApi: !0,
                permission: d(p && p.sceneToken, t[r][u])
            };

          case c.SCOPE + "." + c.USER_LOCATION_BG:
            var l = y(p && p.sceneToken, t[r][u][0]), P = l.specialPass, g = l.detail;
            return {
                isPrivacyApi: !0,
                permission: P || g && g.enableOnBackground
            };

          default:
            return {
                isPrivacyApi: !1
            };
        }

      case "startLocationUpdateBackground":
        var m = y(p && p.sceneToken, t[r][0]), v = m.specialPass, A = m.detail;
        return {
            isPrivacyApi: !0,
            permission: v || A && A.enableOnBackground
        };

      case "chooseImage":
      case "chooseMedia":
      case "chooseVideo":
        return n || (n = [ "album", "camera" ]), {
            isPrivacyApi: !0,
            permission: n.filter(function(e) {
                return d(p && p.sceneToken, t[r][e]);
            }).length === n.length
        };

      case "joinVoIPChat":
        return s || (s = "voice"), {
            isPrivacyApi: !0,
            permission: d(p && p.sceneToken, t[r][s])
        };

      case "makePhoneCall":
        return {
            isPrivacyApi: !0,
            permission: !0
        };

      case "previewImage":
        return !1 === f ? {
            isPrivacyApi: !0,
            permission: !0
        } : {
            isPrivacyApi: !0,
            permission: d(p && p.sceneToken, t[r])
        };

      default:
        return {
            isPrivacyApi: !0,
            permission: d(p && p.sceneToken, t[r])
        };
    }
}, C = exports.getErrorMsg = function(e) {
    return "makePhoneCall" === e ? {
        errMsg: e + ":fail forbidden"
    } : {
        errMsg: e + ":fail illegal or invalid sceneToken"
    };
};

exports.setConfig = function(e) {
    if (g = !0, !r(e) || !e.app) throw Error("隐私SDK: config非合法object!");
    e.defaultConfig && (s[e.app] = e.defaultConfig);
    var a = e.enablePrivacyApiConfig;
    if (r(a)) for (var i in a) Object.hasOwnProperty.call(a, i) && (o[i] = Array.isArray(a[i]) ? a[i] : []);
    P = e, v();
};