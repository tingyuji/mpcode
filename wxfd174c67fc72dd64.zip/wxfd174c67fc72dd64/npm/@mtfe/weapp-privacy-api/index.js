function e(e, t) {
    var r = {};
    try {
        var i = Object.getOwnPropertyDescriptor(e, t);
        Object.assign(r, {
            configurable: i.configurable,
            enumerable: i.enumerable,
            writable: i.writable
        });
    } catch (e) {
        Object.assign(r, {
            configurable: !0,
            enumerable: !0,
            writable: !1
        });
    }
    return r;
}

function t(e, t, r) {
    try {
        var i = Object.getOwnPropertyDescriptor(e, r);
        if (!i || !i.get) throw Error("getDescriptorFail");
        Object.defineProperty(t, r, i);
    } catch (i) {
        t[r] = e[r];
    }
}

function r(r, c) {
    var s = {}, u = c || wx;
    Object.setPrototypeOf(s, u);
    var p = {};
    Object.keys(a).forEach(function(e) {
        switch (e) {
          case "authorize":
            return p[e] = (0, o.getAuthorizeFn)(r, u);

          case "getLocation":
            return p[e] = (0, n.getLocationFn)(n.GET_LOCATION, r, u);

          case "getFuzzyLocation":
            return p[e] = (0, n.getLocationFn)(n.GET_FUZZY_LOCATION, r, u);

          case "createCameraContext":
          case "getRecorderManager":
            return p[e] = (0, i.syncWrapApi)(e, r, u);

          default:
            return p[e] = (0, i.asyncWrapApi)(e, r, u);
        }
    });
    var b = e(u, "canIUse");
    return Object.keys(u).forEach(function(e) {
        "function" == typeof u[e] ? Object.defineProperty(s, e, Object.assign({}, b, {
            value: p[e] || u[e]
        })) : t(u, s, e);
    }), s;
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.privacyApiList = exports.initPrivacySdk = exports.getPrivacyWx = exports.getApiPermission = exports.getEnablePrivacyApiList = void 0;

var i = require("./util");

Object.defineProperty(exports, "getEnablePrivacyApiList", {
    enumerable: !0,
    get: function() {
        return i.getEnablePrivacyApiList;
    }
}), Object.defineProperty(exports, "getApiPermission", {
    enumerable: !0,
    get: function() {
        return i.getApiPermission;
    }
});

var n = require("./apis/location"), o = require("./apis/authorize"), a = require("./constant");

Object.setPrototypeOf = Object.setPrototypeOf || function(e, t) {
    return e.__proto__ = t, e;
};

var c = {}, s = (exports.getPrivacyWx = function(e) {
    var t = e.name, i = e.context, n = void 0 === i ? wx : i, o = e.force;
    return c[t] && !o ? c[t] : c[t] = r(t, n);
})({
    name: "main"
});

exports.default = s;

exports.initPrivacySdk = function(e) {
    (0, i.setConfig)(e);
}, exports.privacyApiList = Object.keys(a);