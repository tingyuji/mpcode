function e(e, t) {
    e = e.split("."), t = t.split(".");
    for (var n = Math.max(e.length, t.length); e.length < n; ) e.push("0");
    for (;t.length < n; ) t.push("0");
    for (var r = 0; r < n; r++) {
        var u = parseInt(e[r], 10), s = parseInt(t[r], 10);
        if (u > s) return 1;
        if (u < s) return -1;
    }
    return 0;
}

function t(t) {
    return e((0, n.getSystemInfoSync)().SDKVersion, t) >= 0;
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.canIUseModel = function() {
    return t("2.9.3");
}, exports.canIUseFormFieldButton = function() {
    return t("2.10.3");
}, exports.canIUseAnimate = function() {
    return t("2.9.0");
}, exports.canIUseGroupSetData = function() {
    return t("2.4.0");
}, exports.canIUseNextTick = function() {
    return r.canIUse("nextTick");
}, exports.canIUseCanvas2d = function() {
    return t("2.9.0");
};

var n = require("./utils"), r = require("../../@mtfe/weapp-privacy-api/index.js").default;