function e(e, s, a) {
    Object.keys(a).forEach(function(t) {
        e[t] && (s[a[t]] = e[t]);
    });
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.MtdComponent = void 0;

var s = require("../mixins/basic");

exports.MtdComponent = function(a, t) {
    var o = {};
    e(a, o, Object.assign({
        data: "data",
        props: "properties",
        mixins: "behaviors",
        methods: "methods",
        beforeCreate: "created",
        created: "attached",
        mounted: "ready",
        destroyed: "detached",
        classes: "externalClasses"
    }, t || {})), o.externalClasses = o.externalClasses || [], o.externalClasses.push("custom-class"), 
    o.behaviors = o.behaviors || [], o.behaviors.push(s.basic);
    var r = a.relation;
    r && (o.relations = r.relations, o.behaviors.push(r.mixin)), a.field && o.behaviors.push("wx://form-field"), 
    o.options = {
        multipleSlots: !0,
        addGlobalClass: !0
    }, Component(o);
};