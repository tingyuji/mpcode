Object.defineProperty(exports, "__esModule", {
    value: !0
});

var e = require("../../@mtfe/weapp-privacy-api/index.js").default;

exports.basic = Behavior({
    methods: {
        $emit: function(e, t, i) {
            this.triggerEvent(e, t, i);
        },
        set: function(t) {
            return this.setData(t), new Promise(function(t) {
                return e.nextTick(t);
            });
        }
    }
});