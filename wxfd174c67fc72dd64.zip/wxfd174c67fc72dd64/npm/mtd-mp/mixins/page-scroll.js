function e(e) {
    var o = (0, r.getCurrentPage)().mtdPageScroller;
    (void 0 === o ? [] : o).forEach(function(r) {
        "function" == typeof r && r(e);
    });
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.pageScrollMixin = void 0;

var r = require("../common/utils"), o = require("../common/validator");

exports.pageScrollMixin = function(t) {
    return Behavior({
        attached: function() {
            var i = (0, r.getCurrentPage)();
            (0, o.isDef)(i) && (Array.isArray(i.mtdPageScroller) ? i.mtdPageScroller.push(t.bind(this)) : i.mtdPageScroller = "function" == typeof i.onPageScroll ? [ i.onPageScroll.bind(i), t.bind(this) ] : [ t.bind(this) ], 
            i.onPageScroll = e);
        },
        detached: function() {
            var e, i = (0, r.getCurrentPage)();
            (0, o.isDef)(i) && (i.mtdPageScroller = (null === (e = i.mtdPageScroller) || void 0 === e ? void 0 : e.filter(function(e) {
                return e !== t;
            })) || []);
        }
    });
};