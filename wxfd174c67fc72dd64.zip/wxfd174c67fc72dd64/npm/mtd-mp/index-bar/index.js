var t = require("../common/component"), e = require("../common/relation"), i = require("../mixins/page-scroll"), n = require("../common/utils"), o = require("../../@mtfe/weapp-privacy-api/index.js").default;

(0, t.MtdComponent)({
    relation: (0, e.useChildren)("index-anchor", function() {
        this.updateData();
    }),
    props: {
        sticky: {
            type: Boolean,
            value: !0
        },
        zIndex: {
            type: Number,
            value: 1
        },
        highlightColor: {
            type: String,
            value: "#1C6CDC"
        },
        stickyOffsetTop: {
            type: Number,
            value: 0
        },
        indexList: {
            type: Array,
            value: function() {
                for (var t = [], e = "A".charCodeAt(0), i = 0; i < 26; i++) t.push(String.fromCharCode(e + i));
                return t;
            }()
        }
    },
    mixins: [ (0, i.pageScrollMixin)(function(t) {
        this.scrollTop = t.scrollTop || 0, this.onScroll();
    }) ],
    data: {
        activeAnchorIndex: null,
        scrollToAnchorIndex: null,
        showSidebar: !1,
        scrollTop: 0
    },
    created: function() {
        this.scrollTop = 0;
    },
    methods: {
        updateData: function() {
            var t = this;
            o.nextTick(function() {
                null != t.timer && clearTimeout(t.timer), t.timer = setTimeout(function() {
                    t.setData({
                        showSidebar: !!t.children.length
                    }), t.setRect().then(function() {
                        t.onScroll();
                    });
                }, 0);
            });
        },
        setRect: function() {
            return Promise.all([ this.setAnchorsRect(), this.setListRect(), this.setSiderbarRect() ]);
        },
        setAnchorsRect: function() {
            var t = this;
            return Promise.all(this.children.map(function(e) {
                return (0, n.getRect)(e, ".mtd-index-anchor-wrapper").then(function(i) {
                    i && Object.assign(e, {
                        height: i.height,
                        top: i.top + t.scrollTop
                    });
                });
            }));
        },
        setListRect: function() {
            var t = this;
            return (0, n.getRect)(this, ".mtd-index-bar").then(function(e) {
                e && Object.assign(t, {
                    height: e.height,
                    top: e.top + t.scrollTop
                });
            });
        },
        setSiderbarRect: function() {
            var t = this;
            return (0, n.getRect)(this, ".mtd-index-bar__sidebar").then(function(e) {
                e && (t.sidebar = {
                    height: e.height,
                    top: e.top
                });
            });
        },
        setDiffData: function(t) {
            var e = t.target, i = t.data, n = {};
            Object.keys(i).forEach(function(t) {
                e.data[t] !== i[t] && (n[t] = i[t]);
            }), Object.keys(n).length && e.setData(n);
        },
        getActiveAnchorIndex: function() {
            for (var t = this.children, e = this.scrollTop, i = this.data, n = i.sticky, o = i.stickyOffsetTop, r = this.children.length - 1; r >= 0; r--) {
                var c = r > 0 ? t[r - 1].height : 0;
                if ((n ? c + o : 0) + e >= t[r].top) return r;
            }
            return -1;
        },
        onScroll: function() {
            var t = this, e = this.children, i = void 0 === e ? [] : e, n = this.scrollTop, o = this.data, r = o.sticky, c = o.stickyOffsetTop, a = o.zIndex, s = o.highlightColor, h = this.getActiveAnchorIndex();
            if (this.setDiffData({
                target: this,
                data: {
                    activeAnchorIndex: h
                }
            }), r) {
                var l = !1;
                -1 !== h && (l = i[h].top <= c + n), i.forEach(function(e, n) {
                    if (n === h) {
                        var o = "", r = "\n              color: " + s + ";\n            ";
                        l && (o = "\n                height: " + i[n].height + "px;\n              ", r = "\n                position: fixed;\n                top: " + c + "px;\n                z-index: " + a + ";\n                color: " + s + ";\n              "), 
                        t.setDiffData({
                            target: e,
                            data: {
                                active: !0,
                                anchorStyle: r,
                                wrapperStyle: o
                            }
                        });
                    } else if (n === h - 1) {
                        var d = i[n], u = d.top, f = (n === i.length - 1 ? t.top : i[n + 1].top) - u - d.height;
                        t.setDiffData({
                            target: e,
                            data: {
                                active: !0,
                                anchorStyle: "\n              position: relative;\n              transform: translate3d(0, " + f + "px, 0);\n              z-index: " + a + ";\n              color: " + s + ";\n            "
                            }
                        });
                    } else t.setDiffData({
                        target: e,
                        data: {
                            active: !1,
                            anchorStyle: "",
                            wrapperStyle: ""
                        }
                    });
                });
            }
        },
        onClick: function(t) {
            this.scrollToAnchor(t.currentTarget.dataset.index);
        },
        onTouchMove: function(t) {
            var e = this.children.length, i = t.touches[0], n = this.sidebar.height / e, o = Math.floor((i.clientY - this.sidebar.top) / n);
            o < 0 ? o = 0 : o > e - 1 && (o = e - 1), this.scrollToAnchor(o);
        },
        onTouchStop: function() {
            this.scrollToAnchorIndex = null;
        },
        scrollToAnchor: function(t) {
            var e = this;
            if ("number" == typeof t && this.scrollToAnchorIndex !== t) {
                this.scrollToAnchorIndex = t;
                var i = this.children.find(function(i) {
                    return i.data.index === e.data.indexList[t];
                });
                i && (i.scrollIntoView(this.scrollTop), this.$emit("select", i.data.index));
            }
        }
    }
});