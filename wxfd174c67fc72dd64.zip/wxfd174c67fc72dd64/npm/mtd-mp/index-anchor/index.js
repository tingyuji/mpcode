var e = require("../common/component"), t = require("../common/utils"), o = require("../common/relation"), r = require("../../@mtfe/weapp-privacy-api/index.js").default;

(0, e.MtdComponent)({
    relation: (0, o.useParent)("index-bar"),
    props: {
        useSlot: Boolean,
        index: null
    },
    data: {
        active: !1,
        wrapperStyle: "",
        anchorStyle: ""
    },
    methods: {
        scrollIntoView: function(e) {
            var o = this;
            (0, t.getRect)(this, ".mtd-index-anchor-wrapper").then(function(t) {
                t && r.pageScrollTo({
                    duration: 0,
                    scrollTop: e + t.top - o.parent.data.stickyOffsetTop
                });
            });
        }
    }
});