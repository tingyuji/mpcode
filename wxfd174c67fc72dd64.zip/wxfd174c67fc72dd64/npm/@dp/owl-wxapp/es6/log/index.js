function e(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var t = function() {
    function e(e, t) {
        for (var n = 0; n < t.length; n++) {
            var r = t[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), 
            Object.defineProperty(e, r.key, r);
        }
    }
    return function(t, n, r) {
        return n && e(t.prototype, n), r && e(t, r), t;
    };
}(), n = function(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}(require("../util/logan")), r = function() {
    function r(t) {
        e(this, r), this.cfgManager = t;
    }
    return t(r, [ {
        key: "addLog",
        value: function(e) {
            try {
                if ("string" != typeof e) return;
                n.default.log("[Log]: " + e);
            } catch (e) {}
        }
    } ]), r;
}();

exports.default = r;