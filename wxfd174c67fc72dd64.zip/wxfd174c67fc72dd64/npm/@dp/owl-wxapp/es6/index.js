function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function r(e, r) {
    if (!(e instanceof r)) throw new TypeError("Cannot call a class as a function");
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.OWL = exports.owl = void 0;

var t = function() {
    function e(e, r) {
        for (var t = 0; t < r.length; t++) {
            var n = r[t];
            n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), 
            Object.defineProperty(e, n.key, n);
        }
    }
    return function(r, t, n) {
        return t && e(r.prototype, t), n && e(r, n), r;
    };
}();

exports.app = function(e) {
    var r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : App;
    (0, h.default)(M, e, r);
}, exports.page = function(e) {
    var r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : Page;
    (0, v.default)(M, e, r);
}, exports.subPage = function(e) {
    var r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null, t = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : Page;
    (0, v.default)(M, e, t, r);
}, exports.request = function(e) {
    var r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : M;
    return (0, q.default)(e, r);
};

var n = e(require("./config")), i = e(require("./error/index")), a = e(require("./page/index")), o = e(require("./resource/index")), u = e(require("./pv/index")), s = e(require("./metric/index")), l = e(require("./metric/indexV2")), f = e(require("./log/index")), c = require("./env"), g = e(require("./error/model")), p = e(require("./util/logan")), d = e(require("./util/pageid")), v = e(require("./page")), h = e(require("./app")), q = e(require("./resource/request")), x = function() {
    function e(t) {
        r(this, e);
        var s = new n.default(t);
        this.error = new i.default(s), this.pageSpeed = new a.default(s), this.resource = new o.default(s, this.error), 
        this.pvManager = new u.default(s), this.metricV2 = new l.default(s), this.logManager = new f.default(s), 
        this.cfgManager = s, this.init();
    }
    return t(e, [ {
        key: "init",
        value: function() {
            var e = this;
            (0, c.getEnv)().then(function(r) {
                e.cfgManager.setExtension(r);
            });
        }
    }, {
        key: "config",
        value: function(e) {
            this.cfgManager.set(e);
        }
    }, {
        key: "setMetric",
        value: function(e, r, t) {
            this.metricV2.setMetric(e, r, t);
        }
    }, {
        key: "reportMetric",
        value: function() {
            this.metricV2.report();
        }
    }, {
        key: "newMetric",
        value: function() {
            return new s.default(this.cfgManager);
        }
    }, {
        key: "report",
        value: function() {
            this.error.report(), this.pageSpeed.report(), this.resource.report();
        }
    }, {
        key: "reportPv",
        value: function() {
            this.pvManager.report();
        }
    }, {
        key: "resetPv",
        value: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, r = {
                pageId: e && e.pageId || "owl-" + (0, d.default)()
            };
            this.cfgManager.set(r), this.pvManager.report(r);
        }
    } ]), e;
}(), M = new x();

M.OWL = x, M.errorModel = g.default, M.start = function(e) {
    if (!this.isStarted) {
        this.isStarted = !0;
        var r = this.cfgManager;
        r.set(e);
        var t = r.get("logan");
        t && t.enable && p.default.ready({
            LoganAPI: t.Logan,
            project: r.get("project"),
            loganConfig: t.config
        });
    }
}, exports.owl = M, exports.OWL = x;