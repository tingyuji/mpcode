Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = function(n, r) {
    var t = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : App, e = n.error, a = n.pageSpeed, c = n.resource, i = n.pvManager, p = n.metricV2, u = n.cfgManager, h = r.onLaunch, l = r.onShow, d = r.onHide, s = r.onError, f = r.onUnhandledRejection, g = r.onPageNotFound;
    r.onLaunch = function(o) {
        try {
            var n = Date.now();
            a.onAppLaunch(n), a.appLaunch(n, o.path);
        } catch (o) {}
        h && h.call(this, o);
    }, r.onShow = function(n) {
        try {
            var r = u.get("autoCatch");
            r && r.pv && !r.pagePv && (0, o.getEnv)().then(function(n) {
                n.pageUrl = (0, o.getPageUrl)(), i.report(n);
            });
        } catch (o) {}
        l && l.call(this, n);
    }, r.onHide = function() {
        try {
            e.report(), c.report(), p.report();
        } catch (o) {}
        d && d.call(this);
    }, r.onError = function(o) {
        try {
            o = "function" == typeof r.preError ? r.preError(o) : o, e.onError(o);
        } catch (o) {}
        s && s.call(this, o);
    }, r.onUnhandledRejection = function(o) {
        try {
            var n = u.get("autoCatch");
            n && n.promiseRejection && o && o.reason && o.reason instanceof Error && e.onPromiseRejection(o.reason);
        } catch (o) {}
        f && f.call(this, o);
    }, r.onPageNotFound = function(o) {
        try {
            o && (o = "function" == typeof r.preNotFound ? r.preNotFound(o) : o, e.addError("page not found", o.path));
        } catch (o) {}
        g && g.call(this, o);
    }, t(r);
};

var o = require("./env");