function t(t, e) {
    if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function");
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var e = function() {
    function t(t, e) {
        var i = [], n = !0, a = !1, r = void 0;
        try {
            for (var o, s = t[Symbol.iterator](); !(n = (o = s.next()).done) && (i.push(o.value), 
            !e || i.length !== e); n = !0) ;
        } catch (t) {
            a = !0, r = t;
        } finally {
            try {
                !n && s.return && s.return();
            } finally {
                if (a) throw r;
            }
        }
        return i;
    }
    return function(e, i) {
        if (Array.isArray(e)) return e;
        if (Symbol.iterator in Object(e)) return t(e, i);
        throw new TypeError("Invalid attempt to destructure non-iterable instance");
    };
}(), i = function() {
    function t(t, e) {
        for (var i = 0; i < e.length; i++) {
            var n = e[i];
            n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), 
            Object.defineProperty(t, n.key, n);
        }
    }
    return function(e, i, n) {
        return i && t(e.prototype, i), n && t(e, n), e;
    };
}(), n = require("../env"), a = require("../util/util"), r = require("../constant/context"), o = [ [ 1, "appLaunchEnd", "appLaunchStart" ], [ 2, "evaluateScriptEnd", "evaluateScriptStart" ], [ 3, "firstRenderEnd", "firstRenderStart" ], [ 7, "pageReady", "pageLoad" ], [ 8, "pageLoad", "appLaunch" ], [ 9, "pageReady", "appLaunch" ], [ 10, "pageReady", "firstRenderEnd" ], [ 11, "pageLoad", "firstRenderStart" ], [ 12, "pageReady", "appLaunchEnd" ] ], s = [ [ 3, "firstRenderEnd", "firstRenderStart" ], [ 7, "pageReady", "pageLoad" ], [ 10, "pageReady", "firstRenderEnd" ], [ 11, "pageLoad", "firstRenderStart" ] ], u = function() {
    function u(e) {
        t(this, u), this.cfgManager = e, this._init(), this.speed = {}, this.firstContentfullPaint = {}, 
        this.moduleFirstRenderTime = {};
    }
    return i(u, [ {
        key: "_init",
        value: function() {
            this.timing = {}, this.points = [], this.launchStage = !1, this.recording = !1, 
            this.uploaded = !1;
        }
    }, {
        key: "startRecording",
        value: function() {
            this.recording = !0, this.uploaded = !1;
        }
    }, {
        key: "onAppLaunch",
        value: function(t) {
            this.timing.appLaunch = t || Date.now(), this.launchStage = !0, this.startRecording(), 
            (this.cfgManager.get("autoCatch") || {}).speed && (0, a.isWX)() && (0, a.isFunc)(r.context.getPerformance) && (this.enableDefaultPoints = !0, 
            this.startPerfObserver());
        }
    }, {
        key: "startPerfObserver",
        value: function() {
            var t = this;
            if (!this.perfObserved) {
                this.perfObserved = !0;
                try {
                    r.context.getPerformance().createObserver(function(e) {
                        try {
                            var i = e.getEntries();
                            i && i.length && i.forEach(function(e) {
                                var i = e.name;
                                if (t.recording && i && "route" !== i && e.duration > 0) {
                                    var n = i + "Start", a = i + "End";
                                    t.timing[n] || t.timing[a] || (t.timing[n] = e.startTime, t.timing[a] = e.startTime + e.duration);
                                }
                            });
                        } catch (t) {}
                    }).observe({
                        entryTypes: [ "navigation", "render", "script" ]
                    });
                } catch (t) {
                    this.enableDefaultPoints = !1;
                }
            }
        }
    }, {
        key: "onPageLoad",
        value: function(t) {
            this.timing.pageLoad = t || Date.now(), this.launchStage || this.recording || this.startRecording();
        }
    }, {
        key: "onPageReady",
        value: function(t) {
            this.timing.pageReady = t || Date.now();
        }
    }, {
        key: "reportPerf",
        value: function(t, i) {
            var r = this;
            if (!this.uploaded) {
                var u = this.cfgManager, p = u.get("page").sample || .5;
                if (this.enableDefaultPoints && Math.random() < p && ((this.launchStage ? o : s).forEach(function(t) {
                    try {
                        var i = e(t, 3), n = i[0], a = i[1], o = i[2], s = r.timing[a], u = r.timing[o];
                        if ("number" == typeof n && s && u) {
                            var p = parseInt(s - u, 10) || 0;
                            r.points[n] = p < 0 ? 0 : p;
                        }
                    } catch (t) {}
                }), this.points && this.points.length)) {
                    var d = (0, n.getEnvSync)(), h = (0, a.getMpVers)(u.config), c = {
                        p: i || u.config.project,
                        pvId: u.config.pageId,
                        pageUrl: t || d.pageUrl || "",
                        mpVer: h.mpVer,
                        mpLibVer: h.mpLibVer,
                        network: d.network || "",
                        os: d.os || "",
                        unionId: u.config.unionId || "",
                        container: d.container || "",
                        ts: Date.now()
                    };
                    c.speed = this.points.join("|"), (0, a.requestQueue)({
                        url: u.getApiPath("page"),
                        method: "POST",
                        header: {
                            "Content-Type": "application/json"
                        },
                        data: JSON.stringify(c)
                    });
                }
                this._init(), this.uploaded = !0;
            }
        }
    }, {
        key: "pushSpeed",
        value: function(t, e, i) {
            var r = this, o = this.speed;
            o[t] || (o[t] = {}, o[t].customSpeed = []);
            try {
                (0, n.getEnv)().then(function(n) {
                    if (n) {
                        var s = r.cfgManager.config, u = (0, a.getMpVers)(s), p = {
                            p: s.project,
                            pvId: s.pageId,
                            unionId: s.unionId || "",
                            speed: "",
                            ts: Date.now()
                        }, d = {
                            pageUrl: t || n.pageUrl || "",
                            mpVer: u.mpVer,
                            mpLibVer: u.mpLibVer,
                            network: n.network || "",
                            os: n.os || "",
                            container: n.container || ""
                        };
                        o[t] || (o[t] = {}, o[t].customSpeed = []), Object.assign(o[t], d, p), o[t].customSpeed[e] = i;
                    }
                });
            } catch (t) {}
        }
    }, {
        key: "addPoint",
        value: function() {
            var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, e = arguments[1];
            if (!this._refresh && void 0 !== t.position) try {
                if ("app" == (e = e || (0, n.getPageUrl)() || "")) {
                    var i = t.timeStamp || Date.now();
                    this.pushSpeed(e, t.position, i - this._appStart);
                } else {
                    var a = void 0;
                    if (void 0 !== t.duration) a = t; else {
                        var r = this._start || Date.now();
                        if (void 0 !== r) {
                            var o = t.timeStamp || +Date.now();
                            a = {
                                position: t.position,
                                duration: o - r
                            };
                        }
                    }
                    a && this.pushSpeed(e, a.position, a.duration);
                }
            } catch (t) {}
        }
    }, {
        key: "appLaunch",
        value: function(t, e) {
            this._appStart = t, this._enterPage = e;
        }
    }, {
        key: "appReady",
        value: function(t, e) {
            this.cfgManager.get("autoCatch").oldSpeed && t === this._enterPage && this.addPoint({
                position: 0,
                timeStamp: e
            }, "app");
        }
    }, {
        key: "pageLoad",
        value: function(t) {
            this._start = t || Date.now(), this._refresh = !1;
        }
    }, {
        key: "pageReady",
        value: function(t) {
            this.cfgManager.get("autoCatch").oldSpeed && this.addPoint({
                position: 0,
                timeStamp: t
            }, (0, n.getPageUrl)());
        }
    }, {
        key: "pullRefresh",
        value: function() {
            this._refresh = !0;
        }
    }, {
        key: "report",
        value: function() {
            var t = this;
            try {
                var e = this.cfgManager, i = this.speed, n = this.firstContentfullPaint, r = this.moduleFirstRenderTime, o = e.get("page").sample || .5;
                Object.keys(i).map(function(s) {
                    var u = Object.assign({}, i[s]);
                    if (u.customSpeed || (u.customSpeed = []), n[s]) {
                        var p = t.firstContentfullPaint[s];
                        try {
                            for (var d in p) u.customSpeed[d] = t._getPageFirstPaint(s, d) || "";
                        } catch (t) {}
                    }
                    u.customSpeed = u.customSpeed.join("|"), i[s] && delete i[s], r[s] && delete r[s], 
                    n[s] && delete n[s], u.customSpeed && u.customSpeed.length && (Math.random() > o || (0, 
                    a.requestQueue)({
                        url: e.getApiPath("page"),
                        method: "POST",
                        header: {
                            "Content-Type": "application/json"
                        },
                        data: JSON.stringify(u)
                    }));
                });
            } catch (t) {}
        }
    }, {
        key: "createFirstContentfulPaint",
        value: function() {
            var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [ "default" ], e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1;
            if (!this._refresh) try {
                var i = (0, n.getPageUrl)();
                this.firstContentfullPaint[i] || (this.firstContentfullPaint[i] = {}), this.firstContentfullPaint[i][e] = t;
            } catch (t) {}
        }
    }, {
        key: "addFirstContentfulPaint",
        value: function() {
            var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "default", e = arguments[1];
            if (!this._refresh) try {
                var i = (0, n.getPageUrl)();
                this.firstContentfullPaint[i] || (this.firstContentfullPaint[i] = {});
                var a = e || +new Date() - this._start;
                this.moduleFirstRenderTime[i] || (this.moduleFirstRenderTime[i] = {}), this.moduleFirstRenderTime[i][t] || (this.moduleFirstRenderTime[i][t] = a);
            } catch (t) {}
        }
    }, {
        key: "_getPageFirstPaint",
        value: function(t, e) {
            var i = this;
            try {
                var n = void 0;
                this.firstContentfullPaint[t] && (n = this.firstContentfullPaint[t][e]);
                var a = 0;
                return this.moduleFirstRenderTime[t] ? (n.map(function(e) {
                    var n = i.moduleFirstRenderTime[t][e] || 0;
                    a = Math.max(n, a);
                }), a) : a;
            } catch (t) {
                return 0;
            }
        }
    }, {
        key: "start",
        value: function(t, e) {
            this["start-" + t + "-" + e] = Date.now();
        }
    }, {
        key: "end",
        value: function(t, e) {
            var i = this["start-" + t + "-" + e], n = this["start-app-0"];
            n && (delete this["start-app-0"], this.pushSpeed("app", 0, Date.now() - n)), i && this.pushSpeed(t, e, Date.now() - i);
        }
    } ]), u;
}();

exports.default = u;