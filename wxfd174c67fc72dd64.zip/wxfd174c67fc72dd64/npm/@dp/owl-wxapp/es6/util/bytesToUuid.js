Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = function(r, t) {
    var o = t || 0, s = e;
    return [ s[r[o++]], s[r[o++]], s[r[o++]], s[r[o++]], "-", s[r[o++]], s[r[o++]], "-", s[r[o++]], s[r[o++]], "-", s[r[o++]], s[r[o++]], "-", s[r[o++]], s[r[o++]], s[r[o++]], s[r[o++]], s[r[o++]], s[r[o++]] ].join("");
};

for (var e = [], r = 0; r < 256; ++r) e[r] = (r + 256).toString(16).substr(1);