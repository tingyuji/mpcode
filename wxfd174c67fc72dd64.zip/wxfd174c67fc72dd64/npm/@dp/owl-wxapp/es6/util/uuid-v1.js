function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = function(e, l, c) {
    var i = l && c || 0, a = l || [], d = (e = e || {}).node || r, v = void 0 !== e.clockseq ? e.clockseq : u;
    if (null == d || null == v) {
        var f = (0, s.default)();
        null == d && (d = r = [ 1 | f[0], f[1], f[2], f[3], f[4], f[5] ]), null == v && (v = u = 16383 & (f[6] << 8 | f[7]));
    }
    var q = void 0 !== e.msecs ? e.msecs : new Date().getTime(), m = void 0 !== e.nsecs ? e.nsecs : n + 1, _ = q - t + (m - n) / 1e4;
    if (_ < 0 && void 0 === e.clockseq && (v = v + 1 & 16383), (_ < 0 || q > t) && void 0 === e.nsecs && (m = 0), 
    m >= 1e4) throw new Error("uuid.v1(): Can't create more than 10M uuids/sec");
    t = q, n = m, u = v;
    var k = (1e4 * (268435455 & (q += 122192928e5)) + m) % 4294967296;
    a[i++] = k >>> 24 & 255, a[i++] = k >>> 16 & 255, a[i++] = k >>> 8 & 255, a[i++] = 255 & k;
    var p = q / 4294967296 * 1e4 & 268435455;
    a[i++] = p >>> 8 & 255, a[i++] = 255 & p, a[i++] = p >>> 24 & 15 | 16, a[i++] = p >>> 16 & 255, 
    a[i++] = v >>> 8 | 128, a[i++] = 255 & v;
    for (var w = 0; w < 6; ++w) a[i + w] = d[w];
    return l || (0, o.default)(a);
};

var r, u, s = e(require("./rng")), o = e(require("./bytesToUuid")), t = 0, n = 0;