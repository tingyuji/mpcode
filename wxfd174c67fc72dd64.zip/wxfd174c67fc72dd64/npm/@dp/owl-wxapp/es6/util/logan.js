Object.defineProperty(exports, "__esModule", {
    value: !0
});

var e = require("../env"), t = void 0, o = !1, r = {
    queue: [],
    ready: function() {
        var r = this, u = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        try {
            var i = u.LoganAPI, n = u.project, g = u.loganConfig;
            o = !0;
            i && (t = i, function() {
                for (g && (t = t.config(g)), t.log("[新小程序项目]：项目-> " + n + " 对应页面-> " + (0, e.getPageUrl)()); r.queue.length; ) {
                    var o = r.queue.shift();
                    t.log(o);
                }
            }());
        } catch (e) {}
    },
    log: function(e) {
        arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        if (o) try {
            t ? t.log(e, "owl") : this.queue.push(e);
        } catch (e) {}
    }
};

exports.default = r;