function r(r) {
    for (;"0" === r[0] && r.length > 1; ) r = r.slice(1);
    return r;
}

function t(r, t) {
    for (;r.length < t; ) r = "0" + r;
    return r;
}

function n(r, t) {
    if (!r) return 0;
    var n = parseInt(r, t);
    if (isNaN(n)) throw new Error("parse char '" + r + "' to number(" + t + ") failed");
    return n;
}

function e(r, t, e) {
    if (r.length > t.length) return 1;
    if (r.length < t.length) return -1;
    for (var o = 0; o < r.length; ) {
        var f = n(r[o], e), u = n(t[o], e);
        if (f > u) return 1;
        if (f < u) return -1;
        o++;
    }
    return 0;
}

function o(r, t, e) {
    for (var o, f = "", u = r.length, i = t.length, l = 0, g = 0; g < u || g < i; ) o = n(r[u - ++g], e) + n(t[i - g], e) + l, 
    l = Math.floor(o / e), f = (o % e).toString(e) + f;
    for (;l > 0; ) f = (l % e).toString(e) + f, l = Math.floor(l / e);
    return f;
}

function f(t, o, u) {
    if (e(t, o, u) < 0) return f(o, t, u);
    for (var i, l = "", g = t.length, h = o.length, a = 0, c = 0; c < g; ) (i = n(t[g - ++c], u) - n(o[h - c], u) + a) < 0 && (a = -1, 
    i += u), l = i.toString(u) + l;
    return r(l);
}

function u(r, t, e) {
    for (var o, f = "", u = 0, i = r.length; --i >= 0; ) o = n(r[i], e) * t + u, u = Math.floor(o / e), 
    f = (o % e).toString(e) + f;
    for (;u > 0; ) f = (u % e).toString(e) + f, u = Math.floor(u / e);
    return f;
}

function i(e, f, i, l) {
    e = r(e), f = f || 10, i = i || 16;
    for (var g = "0", h = "1", a = 0; a++ < e.length; ) g = o(g, u(h, n(e[e.length - a], f), i), i), 
    h = u(h, f, i);
    return l ? t(g, l) : g;
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), i.signedHexToDec = function(r) {
    var t = r.length > 15 && n(r[0], 16) >= 8, e = i(t ? f("10000000000000000", r, 16) : r, 16, 10);
    return t ? "-" + e : e;
}, exports.default = i;