function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function n(e) {
    if (e && (e.header && "zfb" === i.sign && (e.headers = e.header, delete e.header, 
    e.dataType = "text"), u.push(e)), !(u.length > 1 && e)) {
        var r = u[0], t = r.complete;
        r.complete = function(e) {
            u.shift(), u.length && n(), t && t.call(this, e);
        }, i.context.request(r);
    }
}

function r() {
    return 65535 * Math.random();
}

function t() {
    return Math.ceil(r()).toString(16);
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.requestQueue = n, exports.MSID = function() {
    var e = [], n = new Date().getTime();
    return e.push(n.toString(16)), e.push(t()), e.push(t()), e.push(t()), e.join("-");
}, exports.getVersions = function(e) {
    var n = {}, r = e.version || {};
    return n[i.channel + "AppVersion"] = r.wxAppVersion || r.appVersion || e.wxAppVersion || "Unknown", 
    n[i.channel + "LibVersion"] = r.wxLibVersion || e.wxLibVersion || "Unknown", n[i.channel + "Version"] = r.wxVersion || e.wxVersion || "Unknown", 
    n;
}, exports.getMpVers = function(e) {
    var n = e.version || {};
    return {
        mpVer: n.wxAppVersion || n.appVersion || e.wxAppVersion || "Unknown",
        mpLibVer: n.wxLibVersion || e.wxLibVersion || "Unknown"
    };
}, exports.stringify = function(e, n) {
    if (!n) return e;
    var r = [];
    for (var t in n) n.hasOwnProperty(t) && r.push(t + "=" + n[t]);
    return ~e.indexOf("?") ? e + "&" + r.join("&") : e + "?" + r.join("&");
}, exports.extend = function(e, n) {
    var r = {};
    if (e) for (var t in e) e.hasOwnProperty(t) && (r[t] = e[t]);
    if (n) for (var i in n) n.hasOwnProperty(i) && void 0 !== n[i] && (r[i] = n[i]);
    return r;
}, exports.traceid = function() {
    try {
        var e = (0, o.default)().replace(/-/g, ""), n = e.slice(0, 16), r = e.slice(16), t = Array(16).fill(0).map(function(e, t) {
            return parseInt(n[15 - t], 16) ^ parseInt(r[15 - t], 16);
        }).map(function(e) {
            return e.toString(16);
        }).join("");
        return (0, s.default.signedHexToDec)(t);
    } catch (e) {
        return "";
    }
}, exports.isWX = function() {
    return "wx" === i.sign;
}, exports.isFunc = function(e) {
    return "function" == typeof e;
};

var i = require("../constant/context"), o = e(require("./uuid-v1")), s = e(require("./int64-convert")), u = [];