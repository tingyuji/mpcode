Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = function() {
    for (var r, t = 0; t < 16; t++) 0 == (3 & t) && (r = 4294967296 * Math.random()), 
    e[t] = r >>> ((3 & t) << 3) & 255;
    return e;
};

var e = new Array(16);