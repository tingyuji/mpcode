function e(e, r) {
    if (!(e instanceof r)) throw new TypeError("Cannot call a class as a function");
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var r = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
}, t = function() {
    function e(e, r) {
        for (var t = 0; t < r.length; t++) {
            var n = r[t];
            n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), 
            Object.defineProperty(e, n.key, n);
        }
    }
    return function(r, t, n) {
        return t && e(r.prototype, t), n && e(r, n), r;
    };
}(), n = require("../env"), o = require("../util/util"), a = require("../constant/index"), i = function(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}(require("./model")), c = [], s = function() {
    function s(r) {
        e(this, s), this.cfgManager = r;
    }
    return t(s, [ {
        key: "pushError",
        value: function(e, r) {
            var t = this;
            try {
                var a = this.cfgManager.config;
                (0, n.getEnv)().then(function(n) {
                    var s = e instanceof i.default ? e : new i.default(e);
                    if ((s = t.handleErr(s, a.onErrorPush)) && s instanceof i.default) {
                        var u = (0, o.getVersions)(a);
                        s = (s = s.updateTags(u)).toJson(), e = t.parse(s);
                        var l = n.network, f = n.container, g = n.os, p = n.unionId;
                        p = a.unionId || p, e = Object.assign({
                            network: l,
                            container: f,
                            os: g,
                            unionId: p
                        }, e), c.push(e), r && t.report();
                    }
                });
            } catch (e) {
                this.reportSystemError(e);
            }
        }
    }, {
        key: "handleErr",
        value: function(e, r) {
            try {
                return r && r instanceof Function && (e = r(e)), e;
            } catch (r) {
                return e;
            }
        }
    }, {
        key: "parse",
        value: function(e) {
            return e.p = e.p || this.cfgManager.get("project"), e.pageUrl = e.pageUrl || this.cfgManager.get("pageUrl") || (0, 
            n.getPageUrl)(), e;
        }
    }, {
        key: "addError",
        value: function(e, t, n) {
            e = e || "default";
            var o = (t = t || "error").category || a.CATEGORY.SCRIPT, c = t.level || a.LEVEL.ERROR, s = t.pageUrl || "";
            try {
                t instanceof i.default || (t instanceof Error ? t = t.stack || t.message : "object" === (void 0 === t ? "undefined" : r(t)) && (t = {
                    sec_category: t.name,
                    content: t.msg
                })), this.pushError({
                    sec_category: e,
                    content: t,
                    category: o,
                    level: c,
                    pageUrl: s
                }, n);
            } catch (e) {
                this.reportSystemError(e);
            }
        }
    }, {
        key: "reportSystemError",
        value: function(e) {
            if (e) try {
                this.pushError(new i.default({
                    project: "owl",
                    pageUrl: "wxapp_version_" + a.VERSION,
                    sec_category: e.message || e.name || "",
                    content: e.stack || e.message || ""
                }), !0);
            } catch (e) {}
        }
    }, {
        key: "onError",
        value: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
            if (e) try {
                var r = void 0, t = void 0, o = "string" == typeof e ? e : e.message || e.toString() || "";
                o && "string" == typeof o && (o.indexOf("SDKScriptError") > -1 || o.indexOf("webviewScriptError") > -1 || (r = o.indexOf("MiniProgramError") > -1 ? (t = o.replace("MiniProgramError", "").split("\n")) && t[1] || "" : ((t = o.replace("thirdScriptError", "").split(";")) && t[0] || "").replace(/\t|\n/g, ""), 
                this.pushError(new i.default({
                    sec_category: r,
                    content: o,
                    pageUrl: this.cfgManager.get("pageUrl") || (0, n.getPageUrl)()
                }), !0)));
            } catch (e) {
                this.reportSystemError(e);
            }
        }
    }, {
        key: "onPromiseRejection",
        value: function(e) {
            try {
                this.pushError(new i.default({
                    sec_category: e.message ? "[unhandledrejection] " + e.message : "unhandledrejection",
                    content: e.stack || e.message || "",
                    pageUrl: this.cfgManager.get("pageUrl") || (0, n.getPageUrl)()
                }), !0);
            } catch (e) {
                this.reportSystemError(e);
            }
        }
    }, {
        key: "report",
        value: function(e, r) {
            if (c.length) try {
                var t = [].concat(c);
                c = [];
                var a = this.cfgManager, i = a.config, s = (0, n.getEnvSync)(), u = (0, o.getMpVers)(i), l = {
                    p: i.project,
                    pvId: i.pageId,
                    mpVer: u.mpVer,
                    mpLibVer: u.mpLibVer,
                    network: s.network || "",
                    os: s.os || "",
                    container: s.container || "",
                    unionId: i.unionId || "",
                    logs: t
                };
                (0, o.requestQueue)({
                    url: a.getApiPath("error"),
                    method: "POST",
                    header: {
                        "Content-Type": "application/json"
                    },
                    data: JSON.stringify(l),
                    success: function(r) {
                        t = [], e instanceof Function && e(r);
                    },
                    fail: function(e) {
                        c = t.concat(c), r instanceof Function && r(e);
                    }
                });
            } catch (e) {
                this.reportSystemError(e);
            }
        }
    } ]), s;
}();

exports.default = s;