function t(t, e) {
    if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function");
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var e = function() {
    function t(t, e) {
        for (var n = 0; n < e.length; n++) {
            var r = e[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), 
            Object.defineProperty(t, r.key, r);
        }
    }
    return function(e, n, r) {
        return n && t(e.prototype, n), r && t(e, r), e;
    };
}(), n = require("../util/util"), r = require("../constant/index"), i = [ "project", "pageUrl", "resourceUrl", "category", "sec_category", "level", "timestamp", "content", "dynamicMetric" ], a = [ "rowNum", "colNum", "tags" ].concat(i), o = {
    project: "p",
    category: "type",
    sec_category: "name",
    timestamp: "eventTs",
    dynamicMetric: "dynamicMetrics"
}, c = function() {
    function c(e) {
        if (t(this, c), e) {
            for (var n in e) e.hasOwnProperty(n) && (this[n] = e[n]);
            this.parse();
        }
    }
    return e(c, [ {
        key: "parse",
        value: function() {
            this.category = this.category || r.CATEGORY.SCRIPT, this.level = this.level || r.LEVEL.ERROR, 
            this.timestamp = this.timestamp || Date.now(), this.sec_category = this.sec_category || "Unknown error";
        }
    }, {
        key: "update",
        value: function(t) {
            for (var e in t) void 0 !== t[e] && -1 !== a.indexOf(e) && (this[e] = t[e]);
            return this;
        }
    }, {
        key: "updateTags",
        value: function(t) {
            return this.tags = (0, n.extend)(this.tags || {}, t), this;
        }
    }, {
        key: "toJson",
        value: function() {
            var t = this, e = {};
            if (i.map(function(n) {
                var r = o[n] || n;
                void 0 !== t[n] && (e[r] = t[n]);
            }), this.tags && (e.dynamicMetrics = (0, n.extend)(e.dynamicMetrics || {}, this.tags)), 
            e.content && "string" != typeof e.content) try {
                e.content = JSON.stringify(e.content);
            } catch (t) {
                e.content = "";
            }
            return e;
        }
    } ]), c;
}();

c.LEVEL = r.LEVEL, c.CATEGORY = r.CATEGORY, exports.default = c;