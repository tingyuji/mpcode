function t() {
    try {
        var t = getCurrentPages() || [], n = t[t.length - 1];
        return n && (n.route || n.__route__) || c;
    } catch (t) {
        return c;
    }
}

function n() {
    try {
        return o.context.onNetworkStatusChange && o.context.onNetworkStatusChange(function(t) {
            i.network = t && t.networkType || "";
        }), new Promise(function(t) {
            o.context.getNetworkType({
                success: function(n) {
                    t(n && n.networkType || "");
                },
                fail: function() {
                    t(c);
                }
            }), setTimeout(function() {
                t(c);
            }, 2e3);
        });
    } catch (t) {}
}

function e() {
    try {
        var t = {
            os: "",
            wxVersion: c,
            wxLibVersion: c
        };
        return new Promise(function(n) {
            o.context.getSystemInfo({
                success: function(e) {
                    e && (t.wxVersion = e.version || c, t.wxLibVersion = e.SDKVersion || c), n(t);
                },
                fail: function() {
                    n(t);
                }
            });
        });
    } catch (t) {}
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var r = function() {
    function t(t, n) {
        var e = [], r = !0, o = !1, i = void 0;
        try {
            for (var c, u = t[Symbol.iterator](); !(r = (c = u.next()).done) && (e.push(c.value), 
            !n || e.length !== n); r = !0) ;
        } catch (t) {
            o = !0, i = t;
        } finally {
            try {
                !r && u.return && u.return();
            } finally {
                if (o) throw i;
            }
        }
        return e;
    }
    return function(n, e) {
        if (Array.isArray(n)) return n;
        if (Symbol.iterator in Object(n)) return t(n, e);
        throw new TypeError("Invalid attempt to destructure non-iterable instance");
    };
}();

exports.getPageUrl = t, exports.getEnv = function() {
    try {
        var c = t();
        return new Promise(function(t) {
            Object.keys(i).length ? t(Object.assign({}, i, {
                pageUrl: c
            })) : Promise.all([ n(), e() ]).then(function(n) {
                var e = r(n, 2), u = e[0], a = e[1];
                u && a ? (i = Object.assign({}, a, {
                    network: u,
                    container: o.Container,
                    unionId: ""
                }), t(Object.assign({}, i, {
                    pageUrl: c
                }))) : t({
                    pageUrl: c
                });
            }).catch(function() {
                t({
                    pageUrl: c
                });
            });
        });
    } catch (t) {
        return {
            then: function() {}
        };
    }
}, exports.getEnvSync = function() {
    return Object.assign({}, i, {
        pageUrl: t()
    });
};

var o = require("./constant/context"), i = {}, c = "Unknown";