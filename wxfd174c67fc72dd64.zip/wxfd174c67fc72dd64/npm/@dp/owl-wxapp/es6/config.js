function e(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var t = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
}, n = function() {
    function e(e, t) {
        for (var n = 0; n < t.length; n++) {
            var i = t[n];
            i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), 
            Object.defineProperty(e, i.key, i);
        }
    }
    return function(t, n, i) {
        return n && e(t.prototype, n), i && e(t, i), t;
    };
}(), i = require("./constant/index"), o = require("./constant/context"), r = require("./util/util"), s = function(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}(require("./util/pageid")), a = [ "region", "operator", "network", "container", "os", "unionId" ], c = "https://catfront.dianping.com", u = "/mp/api/", f = function() {
    function f(t) {
        if (e(this, f), this._config = {
            project: "",
            devMode: !1,
            pageUrl: "",
            version: {},
            autoCatch: {
                pv: !0,
                pagePv: !1,
                speed: !0,
                oldSpeed: !1,
                promiseRejection: !1
            },
            page: {
                sample: .5
            },
            resource: {
                sample: .1,
                errSample: .2,
                delay: 1500,
                defaultNetworkCode: 500,
                sendTriggerThreshold: 10
            },
            enableLogTrace: !1,
            error: {
                sample: 1
            },
            metric: {
                sample: 1,
                trigger: 15,
                delay: 1500
            },
            logan: {
                enable: !1
            },
            hasRecordApp: !1,
            pageId: "owl-" + (0, s.default)()
        }, this.config = {}, this.userConfig = {}, this.url = c, t ? this.set(t) : this.config = this._config, 
        this.baseQuery = {
            v: 1,
            sdk: i.VERSION
        }, this.apiPaths = {
            error: u + "log",
            page: u + "speed",
            resource: u + "batch",
            pv: u + "pv",
            metric: "/api/metric"
        }, this.extensions = {}, !t || !t.unionId) try {
            var n = o.context.getStorageSync(i.STOREKEY + "-unionId");
            n ? this.config.unionId = n : (this.config.unionId = (0, r.MSID)(), this.cacheUnionId(this.config.unionId));
        } catch (e) {
            this.config.unionId = "";
        }
    }
    return n(f, [ {
        key: "_update",
        value: function() {
            this.config = this._config;
            try {
                for (var e in this.userConfig) {
                    var n = this.userConfig[e];
                    "object" !== (void 0 === n ? "undefined" : t(n)) || n instanceof RegExp || n instanceof Array ? this.config[e] = n : this.config[e] = (0, 
                    r.extend)(this.config[e], n);
                }
            } catch (e) {}
        }
    }, {
        key: "update",
        value: function(e, t) {
            try {
                if (!e || void 0 === t) return;
                this.config[e] = t, "unionId" === e ? this.cacheUnionId(t) : "devMode" === e && this.setApiDomain(t);
            } catch (e) {}
        }
    }, {
        key: "get",
        value: function(e) {
            return e ? this.config[e] : this.config;
        }
    }, {
        key: "set",
        value: function(e) {
            try {
                if (!e || "object" != (void 0 === e ? "undefined" : t(e))) return;
                for (var n in e) if (e.hasOwnProperty(n)) {
                    var i = e[n];
                    "devMode" === n && this.setApiDomain(i), "object" !== (void 0 === i ? "undefined" : t(i)) || i instanceof RegExp || i instanceof Array ? this.userConfig[n] = i : this.userConfig[n] = (0, 
                    r.extend)(this.userConfig[n], i);
                }
                this._update();
            } catch (e) {}
        }
    }, {
        key: "getApiPath",
        value: function(e) {
            var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1, n = Object.assign({}, this.baseQuery, {
                v: t,
                p: this.config.project
            });
            return (0, r.stringify)(this.url + this.apiPaths[e], n);
        }
    }, {
        key: "setApiDomain",
        value: function(e) {
            this.url = e ? "https://catfront.51ping.com" : c;
        }
    }, {
        key: "getExtension",
        value: function(e) {
            return e ? this.extensions[e] : this.extensions;
        }
    }, {
        key: "setExtension",
        value: function(e) {
            try {
                if (!e || "object" != (void 0 === e ? "undefined" : t(e))) return;
                for (var n in e) if (e.hasOwnProperty(n)) {
                    var i = e[n];
                    a.indexOf(n) > -1 ? this.extensions[n] = "unionId" !== n ? i : this.config.unionId : n.indexOf("Version") > -1 && (this.config.version[n] = i);
                }
            } catch (e) {}
        }
    }, {
        key: "cacheUnionId",
        value: function(e) {
            o.context.setStorage({
                key: i.STOREKEY + "-unionId",
                data: e
            });
        }
    } ]), f;
}();

exports.default = f;