function e(c, i) {
    var a = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : o.context.request;
    if (!c) return c;
    var d = Date.now(), u = c.url, s = c.path, l = c.complete, p = c.connectType, f = c.reportError, y = c.isRequest, v = u || s || "", m = i.cfgManager.config, h = (m.resource.defaultNetworkCode || 500) + "";
    p = p || (u ? "https" : s ? "cloudContainer" : "https");
    var g = void 0;
    try {
        m.project && m.enableLogTrace && (g = (0, n.traceid)()) && (c.header = c.header || {}, 
        c.header["M-TRACEID"] = g, c.header["M-APPKEY"] = ("mmp" === o.sign ? "mt" : "wx") + "mp_" + m.project);
    } catch (e) {}
    try {
        c.complete = function(o) {
            try {
                var n = {
                    resUrl: v,
                    resTime: (Date.now() - d).toString(),
                    ts: d.toString(),
                    connectType: p
                };
                if (g && (n.traceid = g), o && "object" == (void 0 === o ? "undefined" : t(o))) {
                    var c = o.statusCode, a = void 0 === c ? "" : c, u = o.errMsg, s = void 0 === u ? "request:ok" : u;
                    if (n.code = (a || h) + "|", "function" == typeof f) {
                        var y = void 0;
                        try {
                            y = f(o, e);
                        } catch (e) {}
                        var m = y || {}, b = m.code, x = void 0 === b ? "" : b, q = m.name, C = void 0 === q ? "" : q, A = m.log, S = void 0 === A ? "" : A, E = m.ignoreAjaxError, T = void 0 !== E && E;
                        (x || 0 === x) && (n.code = "" + n.code + x), T || (s.indexOf("request:fail") > -1 || s.indexOf("cloud.callContainer:fail") > -1 || C || S) && (n.firCate = r.CATEGORY.AJAX, 
                        n.secCate = C || v, n.content = S || s);
                    }
                } else n.code = h + "|";
                i.resource.pushApi(n);
            } catch (e) {
                i.error.addError("request options complete err", e);
            } finally {
                l && l.apply(this, arguments);
            }
        };
    } catch (e) {}
    return y && "https" === p && a(c), c;
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var t = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
};

exports.default = e;

var r = require("../constant/index"), o = require("../constant/context"), n = require("../util/util");