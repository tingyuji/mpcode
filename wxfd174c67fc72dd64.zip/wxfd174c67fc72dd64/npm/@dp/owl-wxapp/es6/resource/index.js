function e(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var t = function() {
    function e(e, t) {
        for (var r = 0; r < t.length; r++) {
            var n = t[r];
            n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), 
            Object.defineProperty(e, n.key, n);
        }
    }
    return function(t, r, n) {
        return r && e(t.prototype, r), n && e(t, n), t;
    };
}(), r = require("../env"), n = require("../util/util"), o = require("../constant/index"), a = function(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}(require("./model")), i = "resource", s = [], u = function() {
    function u(t, r) {
        e(this, u), this.cfgManager = t, this.errManager = r;
    }
    return t(u, [ {
        key: "pushApi",
        value: function(e, t) {
            var n = this;
            if (e) try {
                var o = this.cfgManager.get(i);
                if (Math.random() > o.sample) return;
                e.p = e.p || this.cfgManager.get("project"), e.pageUrl = e.pageUrl || this.cfgManager.get("pageUrl") || (0, 
                r.getPageUrl)(), s.push(new a.default(e)), this.timeout && (clearTimeout(this.timeout), 
                this.timeout = null), s.length >= (o.sendTriggerThreshold || 10) ? this.report(!0) : t ? this.report() : this.timeout = setTimeout(function() {
                    n.report();
                }, o.delay || 1500);
            } catch (e) {}
        }
    }, {
        key: "addApi",
        value: function(e, t) {
            try {
                if (!e || !e.name) return;
                if (void 0 !== e.networkCode && "number" != typeof e.networkCode) return;
                if (void 0 !== e.statusCode && "number" != typeof e.statusCode) return;
                var r = e.networkCode || 0 === e.networkCode ? e.networkCode : "", n = e.statusCode || 0 === e.statusCode ? e.statusCode : "", a = parseInt(e.responseTime || ""), i = {
                    resUrl: e.name,
                    pageUrl: e.pageUrl || "",
                    type: "api",
                    connectType: e.connectType,
                    code: r + "|" + n,
                    resTime: a && a.toString() || "0"
                };
                e.content && (i.firCate = o.CATEGORY.AJAX, i.secCate = e.secondCategory || e.name, 
                i.content = e.content), this.pushApi(i, t);
            } catch (e) {}
        }
    }, {
        key: "addApiError",
        value: function(e, t, r) {
            var n = this.cfgManager.get(i).errSample || .2;
            Math.random() > n || this.errManager.pushError({
                sec_category: e,
                content: t,
                category: o.CATEGORY.AJAX,
                level: o.LEVEL.WARN
            }, r);
        }
    }, {
        key: "_stringify",
        value: function(e) {
            var t = this.cfgManager, r = e ? t.get(i).sendTriggerThreshold || 10 : s.length, o = s.splice(0, r);
            if (o && o.length) try {
                for (var a = t.config, u = (0, n.getMpVers)(a), c = t.extensions, p = {
                    p: a.project,
                    pvId: a.pageId,
                    mpVer: u.mpVer,
                    mpLibVer: u.mpLibVer,
                    network: c.network || "",
                    os: c.os || "",
                    container: c.container || "",
                    unionId: a.unionId || "",
                    requests: []
                }, g = 0; g < o.length; g++) p.requests.push(o[g]);
                return p;
            } catch (e) {}
        }
    }, {
        key: "report",
        value: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
            if (s.length) try {
                var t = this._stringify(e);
                t && (0, n.requestQueue)({
                    url: this.cfgManager.getApiPath(i),
                    method: "POST",
                    header: {
                        "Content-Type": "application/json"
                    },
                    data: JSON.stringify(t)
                });
            } catch (e) {}
        }
    } ]), u;
}();

exports.default = u;