function e(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var t = function() {
    function e(e, t) {
        for (var r = 0; r < t.length; r++) {
            var n = t[r];
            n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), 
            Object.defineProperty(e, n.key, n);
        }
    }
    return function(t, r, n) {
        return r && e(t.prototype, r), n && e(t, n), t;
    };
}(), r = [ "p", "pageUrl", "resUrl", "type", "connectType", "code", "resTime", "reqByte", "resByte", "traceid", "ts", "firCate", "secCate", "content" ], n = {
    p: "project",
    resUrl: "resourceUrl",
    code: "statusCode",
    resTime: "responsetime",
    reqByte: "requestbyte",
    resByte: "responsebyte",
    ts: "timestamp",
    firCate: "firstCategory",
    secCate: "secondCategory",
    content: "logContent"
}, s = function() {
    function s(t) {
        var i = this;
        e(this, s), t && (r.forEach(function(e) {
            var r = n[e];
            i[e] = void 0 !== t[e] ? t[e] : r && void 0 !== t[r] ? t[r] : "";
        }), this.parse());
    }
    return t(s, [ {
        key: "parse",
        value: function() {
            if (this.type = this.type || "ajax", this.connectType = this.connectType || "https", 
            this.reqByte = this.reqByte || "0", this.resByte = this.resByte || "0", this.ts = this.ts || Date.now(), 
            this.content && "string" != typeof this.content) try {
                this.content = JSON.stringify(this.content);
            } catch (e) {
                this.content = "";
            }
        }
    } ]), s;
}();

exports.default = s;