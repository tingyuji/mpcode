Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.sign = exports.channel = exports.Container = exports.context = void 0;

var t = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
    return typeof t;
} : function(t) {
    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
}, e = require("../util/util"), n = require("../../../../@mtfe/weapp-privacy-api/index.js").default, o = "undefined", r = void 0, i = "", s = "wx", p = "wx";

try {
    (void 0 === n ? "undefined" : t(n)) != o && n && (0, e.isFunc)(n.getSystemInfo) && (exports.context = r = n, 
    exports.Container = i = "miniProgram", ("undefined" == typeof mmp ? "undefined" : t(mmp)) != o && (exports.Container = i = "", 
    exports.sign = p = "mmp"));
} catch (t) {}

try {
    ("undefined" == typeof swan ? "undefined" : t(swan)) != o && swan && (0, e.isFunc)(swan.getSystemInfo) && (exports.context = r = swan, 
    exports.Container = i = "BaiduContainer", exports.channel = s = "bd", exports.sign = p = "bd");
} catch (t) {}

try {
    ("undefined" == typeof tt ? "undefined" : t(tt)) != o && tt && (0, e.isFunc)(tt.getSystemInfo) && (exports.context = r = tt, 
    exports.Container = i = "ToutiaoContainer", exports.channel = s = "tt", exports.sign = p = "tt");
} catch (t) {}

try {
    ("undefined" == typeof my ? "undefined" : t(my)) != o && my && (0, e.isFunc)(my.getSystemInfo) && (exports.context = r = my, 
    exports.sign = p = "zfb");
} catch (t) {}

exports.context = r, exports.Container = i, exports.channel = s, exports.sign = p;