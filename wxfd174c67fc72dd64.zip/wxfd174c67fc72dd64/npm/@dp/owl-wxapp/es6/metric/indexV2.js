function t(t, e) {
    if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function");
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
    return typeof t;
} : function(t) {
    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
}, r = function() {
    function t(t, e) {
        for (var r = 0; r < e.length; r++) {
            var n = e[r];
            n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), 
            Object.defineProperty(t, n.key, n);
        }
    }
    return function(e, r, n) {
        return r && t(e.prototype, r), n && t(e, n), e;
    };
}(), n = require("../util/util"), o = function() {
    function o(e) {
        t(this, o), this.cfgManager = e, this.data = [];
    }
    return r(o, [ {
        key: "setMetric",
        value: function(t, r) {
            var n = this, o = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
            try {
                if (!t || "string" != typeof t || "number" != typeof r || "object" != (void 0 === o ? "undefined" : e(o))) return;
                var i = this.cfgManager.get("metric");
                if (i && "number" == typeof i.sample && Math.random() > i.sample) return;
                this.data.push({
                    key: t,
                    vs: [ r ],
                    tvs: o
                }), this.timeout && (clearTimeout(this.timeout), this.timeout = null), this.data.length >= (i.trigger || 15) ? this.report() : this.timeout = setTimeout(function() {
                    n.report();
                }, i.delay || 1500);
            } catch (t) {}
        }
    }, {
        key: "report",
        value: function() {
            try {
                if (!this.data || !this.data.length) return;
                var t = [].concat(this.data);
                this.data = [], (0, n.requestQueue)({
                    url: this.cfgManager.getApiPath("metric", 2),
                    method: "POST",
                    header: {
                        "Content-Type": "application/x-www-form-urlencoded"
                    },
                    data: "data=" + encodeURIComponent(JSON.stringify(t))
                });
            } catch (t) {}
        }
    } ]), o;
}();

exports.default = o;