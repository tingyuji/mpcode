function t(t, e) {
    if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function");
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var e = function() {
    function t(t, e) {
        for (var s = 0; s < e.length; s++) {
            var a = e[s];
            a.enumerable = a.enumerable || !1, a.configurable = !0, "value" in a && (a.writable = !0), 
            Object.defineProperty(t, a.key, a);
        }
    }
    return function(e, s, a) {
        return s && t(e.prototype, s), a && t(e, a), e;
    };
}(), s = require("../util/util"), a = function() {
    function a(e) {
        t(this, a), this.cfgManager = e, this.tags = {}, this.kvs = {};
    }
    return e(a, [ {
        key: "setTags",
        value: function(t) {
            this.tags = Object.assign(this.tags, t);
        }
    }, {
        key: "getTags",
        value: function(t) {
            return t ? this.tags[t] : this.tags;
        }
    }, {
        key: "clearTags",
        value: function() {
            this.tags = {};
        }
    }, {
        key: "setMetric",
        value: function(t, e) {
            "string" == typeof t && "number" == typeof e && (this.kvs[t] || (this.kvs[t] = []), 
            this.kvs[t].push(e));
        }
    }, {
        key: "getMetric",
        value: function(t) {
            return t ? this.kvs[t] : this.kvs;
        }
    }, {
        key: "clearMetric",
        value: function() {
            this.kvs = {};
        }
    }, {
        key: "_rollbackTags",
        value: function(t) {
            this.tags = t || {};
        }
    }, {
        key: "_rollbackMetric",
        value: function(t) {
            for (var e in t) t.hasOwnProperty(e) && (this.kvs[e] = t[e].concat(this.kvs[e] || []));
        }
    }, {
        key: "report",
        value: function() {
            var t = this;
            try {
                if (!this.kvs || 0 === Object.keys(this.kvs).length) return;
                var e = this.tags, a = {
                    kvs: this.kvs,
                    tags: this.tags,
                    ts: parseInt(+new Date() / 1e3)
                };
                this.clearTags(), this.clearMetric(), (0, s.requestQueue)({
                    url: this.cfgManager.getApiPath("metric"),
                    method: "POST",
                    header: {
                        "Content-Type": "application/x-www-form-urlencoded"
                    },
                    data: "data=" + encodeURIComponent(JSON.stringify(a)),
                    fail: function() {
                        t._rollbackTags(e);
                    }
                });
            } catch (t) {}
        }
    } ]), a;
}();

exports.default = a;