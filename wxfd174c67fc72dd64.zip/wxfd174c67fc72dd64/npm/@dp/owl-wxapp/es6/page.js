Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = function(t, a) {
    var o = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : Page, n = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : null, r = t.pageSpeed, c = t.pvManager, l = t.cfgManager, h = a.onLoad, i = a.onShow, p = a.onReady, d = a.onHide, u = a.onUnload, g = a.onPullDownRefresh, s = n && n.cfgManager && n.cfgManager.get("project") || "";
    a.onLoad = function(e) {
        try {
            var t = Date.now();
            r.onPageLoad(t), l.get("hasRecordApp") || (r.appReady(this.route, t), l.update("hasRecordApp", !0)), 
            r.pageLoad(t);
        } catch (e) {}
        h && h.call(this, e);
    }, a.onShow = function(t) {
        try {
            var a = l.get("autoCatch");
            a && a.pagePv && (0, e.getEnv)().then(function(e) {
                c.report(e);
            });
        } catch (e) {}
        i && i.call(this, t);
    }, a.onReady = function(e) {
        try {
            var t = Date.now();
            r.onPageReady(t), r.pageReady(t);
        } catch (e) {}
        p && p.call(this, e);
    }, a.onHide = function(e) {
        try {
            r.reportPerf(this.route, s), r.report();
        } catch (e) {}
        d && d.call(this, e);
    }, a.onUnload = function(e) {
        try {
            r.reportPerf(this.route, s), r.report();
        } catch (e) {}
        u && u.call(this, e);
    }, a.onPullDownRefresh = function(e) {
        try {
            r.pullRefresh();
        } catch (e) {}
        g && g.call(this, e);
    }, o(a);
};

var e = require("./env");