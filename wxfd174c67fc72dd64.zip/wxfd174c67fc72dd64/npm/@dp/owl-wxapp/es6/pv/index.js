function e(e, r) {
    if (!(e instanceof r)) throw new TypeError("Cannot call a class as a function");
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var r = function() {
    function e(e, r) {
        for (var n = 0; n < r.length; n++) {
            var t = r[n];
            t.enumerable = t.enumerable || !1, t.configurable = !0, "value" in t && (t.writable = !0), 
            Object.defineProperty(e, t.key, t);
        }
    }
    return function(r, n, t) {
        return n && e(r.prototype, n), t && e(r, t), r;
    };
}(), n = require("../env"), t = require("../util/util"), o = function() {
    function o(r) {
        e(this, o), this.cfgManager = r;
    }
    return r(o, [ {
        key: "report",
        value: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
            try {
                var r = this.cfgManager, o = r.config, a = r.extensions, i = (0, t.getMpVers)(o), u = {
                    p: o.project,
                    pageUrl: e.pageUrl || o.pageUrl || (0, n.getPageUrl)(),
                    pvId: e.pageId || o.pageId,
                    mpVer: i.mpVer,
                    mpLibVer: e.wxLibVersion || i.mpLibVer,
                    network: e.network || a.network || "",
                    os: a.os || "",
                    container: a.container || "",
                    unionId: o.unionId,
                    ts: Date.now()
                };
                (0, t.requestQueue)({
                    url: r.getApiPath("pv"),
                    method: "POST",
                    header: {
                        "Content-Type": "application/json"
                    },
                    data: JSON.stringify(u)
                });
            } catch (e) {}
        }
    } ]), o;
}();

exports.default = o;