Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.emojiArray = exports.emojiUnicodeArray = exports.emojiUnicodeMap = exports.emojiImgMap = exports.emojiTextArray = exports.removeImgTags = exports.convertEmojiToText = exports.formatText = void 0;

var e = require("./img-data/emoji-list-url"), r = [], o = {}, t = {}, i = [];

e.emojiArrayList.forEach(function(e, s) {
    r.push(e.text), o[s] = e.picUrl, e.emoji && (t[e.emoji] = s, i.push(e.emoji));
});

var s = new RegExp("\\" + r.join("|\\") + "|" + i.join("|"), "g"), a = new RegExp("" + i.join("|"), "g"), n = exports.formatText = function(e) {
    var i = e, a = "";
    e && e.length > 3e3 && (i = e.substring(0, 3e3), a = e.substring(3e3));
    try {
        i = i ? i.replace(s, function(e) {
            var i = r.indexOf(e);
            return -1 === i && (i = t[e]), '<img class="emoji-img" src="' + o[i] + '" alt="' + (r[i] || "") + '">';
        }) : i;
    } catch (e) {
        console.log(e);
    }
    try {
        a = a ? i.replace(s, function(e) {
            var i = r.indexOf(e);
            return -1 === i && (i = t[e]), '<img class="emoji-img" src="' + o[i] + '" alt="' + (r[i] || "") + '">';
        }) : a;
    } catch (e) {
        console.log(e);
    }
    return i + a;
}, m = exports.convertEmojiToText = function(e) {
    try {
        e = e ? e.replace(a, function(e) {
            var o = t[e];
            return "" + (r[o] || "");
        }) : e;
    } catch (e) {
        console.log(e);
    }
    return e;
}, c = exports.removeImgTags = function(e) {
    var r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "";
    try {
        e = e ? e.replace(/<img[^>]+(\/|>[^<]*<\/img\s*|[^>]*)[^>]*>/g, r) : e;
    } catch (e) {
        console.log(e);
    }
    return e;
};

exports.emojiTextArray = r, exports.emojiImgMap = o, exports.emojiUnicodeMap = t, 
exports.emojiUnicodeArray = i, exports.emojiArray = e.emojiArrayList, exports.default = {
    emojiArray: e.emojiArrayList,
    formatText: n,
    convertEmojiToText: m,
    removeImgTags: c
};