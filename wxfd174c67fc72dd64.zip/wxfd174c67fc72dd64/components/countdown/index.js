Component({
    externalClasses: [ "custom-class" ],
    properties: {
        initValue: {
            type: Number,
            value: 0,
            observer: function(t) {
                this.data.currentValue = t, this.setRestText(), this.init();
            }
        },
        format: {
            type: String,
            value: "DD:HH:MM:SS"
        }
    },
    data: {
        currentValue: 0,
        step: 1e3,
        rest: ""
    },
    timer: null,
    methods: {
        init: function() {
            clearTimeout(this.timer);
            var t = this.properties.initValue;
            this.data.currentValue = t, this.run();
        },
        run: function() {
            var t = this;
            this.timer = setTimeout(function() {
                if (t.data.currentValue -= 1e3, t.setRestText(), t.data.currentValue < 1e3) return t.data.currentValue = 0, 
                t.triggerEvent("end"), void t.clear();
                t.run();
            }, 1e3);
        },
        clear: function() {
            clearTimeout(this.timer);
        },
        setRestText: function() {
            var t = this.properties.format, e = this.data.currentValue;
            if ("DD:HH:MM:SS" === t) {
                var r = Math.floor(e / 864e5);
                e %= 864e5;
                var a = Math.floor(e / 36e5);
                e %= 36e5;
                var i = Math.floor(e / 6e4);
                e %= 6e4;
                var s = Math.floor(e / 1e3);
                this.setData({
                    rest: r.toString() + "天" + a.toString().padStart(2, "0") + ":" + i.toString().padStart(2, "0") + ":" + s.toString().padStart(2, "0")
                });
            } else if ("HH:MM:SS" === t) {
                var o = Math.floor(e / 36e5);
                e %= 36e5;
                var n = Math.floor(e / 6e4);
                e %= 6e4;
                var u = Math.floor(e / 1e3);
                this.setData({
                    rest: o.toString().padStart(2, "0") + ":" + n.toString().padStart(2, "0") + ":" + u.toString().padStart(2, "0")
                });
            } else "S" === t && this.setData({
                rest: "" + Math.floor(e / 1e3).toString()
            });
        }
    },
    lifetimes: {
        detached: function() {
            this.clear();
        }
    }
});