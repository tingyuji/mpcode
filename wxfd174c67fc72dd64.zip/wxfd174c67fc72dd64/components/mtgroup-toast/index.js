var t = function(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}(require("../../utils/index")).default.nextTick;

Component({
    externalClasses: [ "custom-mask", "custom-panel", "custom-content", "custom-message" ],
    options: {
        multipleSlots: !0,
        addGlobalClass: !0
    },
    properties: {
        useSlot: Boolean,
        modal: Boolean,
        zIndex: {
            type: Number,
            value: 999999
        },
        overlay: Boolean,
        selector: {
            type: String,
            value: "#mtgroup-toast"
        }
    },
    data: {
        duration: 1e3,
        message: "",
        show: !1
    },
    observers: {
        show: function(o) {
            var e = this;
            o && (this.data.onShow && "function" == typeof this.data.onShow && this.data.onShow(), 
            setTimeout(function() {
                e.setData({
                    show: !1
                }), t(function() {
                    e.data.onClose && "function" == typeof e.data.onClose && e.data.onClose();
                });
            }, this.data.duration || 1e3));
        }
    },
    methods: {}
});