Component({
    externalClasses: [ "my-class" ],
    properties: {
        show: {
            type: Boolean,
            value: !0
        },
        zIndex: {
            type: Number,
            value: 1
        },
        duration: {
            type: Number,
            value: 200
        },
        opacity: {
            type: Number,
            value: .5
        },
        styles: Object
    },
    data: {},
    methods: {
        onClick: function() {
            this.triggerEvent("click");
        },
        onTouchmove: function() {
            this.triggerEvent("overlayTouchMove");
        }
    }
});