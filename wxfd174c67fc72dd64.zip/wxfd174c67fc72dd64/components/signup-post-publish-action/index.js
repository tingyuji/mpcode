var t = function(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}(require("../../common/lx")), e = require("../../npm/@mtfe/weapp-privacy-api/index.js").default, i = "__MERCHANT_PUBLISH_TIP";

Component({
    properties: {
        urlData: {
            type: Object,
            value: {}
        },
        location: {
            type: Object,
            value: {}
        },
        enableTip: Boolean
    },
    data: {
        showSubAlert: !0,
        showTip: !1
    },
    tipTimer: null,
    methods: {
        talentPublish: function(t) {
            try {
                var i = this;
                e.getSetting({
                    withSubscriptions: !0,
                    success: function(t) {
                        t.subscriptionsSetting.itemSettings && i.setData({
                            showSubAlert: !1
                        });
                    }
                }), e.requestSubscribeMessage({
                    tmplIds: [ "Tf0XliBiG8mUjU39IHFj9sNeo6kosfhUvh4-JZWqMa4", "sJ2c8-bkXGKnzSUD5cB7L-nyigN_BjbTaAlfNB6kXbk", "6IYuGNFeXdz1GtNMyqCapsR0VaWaLN9hSOE9m2pdSys" ],
                    fail: function(t) {
                        console.log("user sub fail", t);
                    },
                    complete: function() {
                        e.getSetting({
                            withSubscriptions: !0,
                            success: function(t) {
                                i.data.showSubAlert && t.subscriptionsSetting.itemSettings && i.setData({
                                    showSubAlert: !1
                                });
                            }
                        }), e.navigateTo({
                            url: t
                        });
                    }
                });
            } catch (t) {
                console.warn(t);
            }
        },
        onCustomPublish: function() {
            var e = this.properties, i = (e.urlData, e.location);
            t.default.moduleClick("b_gc_xcngm5vh_mc", {});
            var s = "/pages/talent/publish/index?address=" + encodeURIComponent(i.address) + "&lat=" + i.lat + "&lng=" + i.lng + "&cityid=" + i.cityid;
            this.talentPublish(s), this.closeTip();
        },
        onQuicklyPublish: function() {
            t.default.moduleClick("b_gc_52sfo52g_mc", {});
            var i = this;
            e.getSetting({
                withSubscriptions: !0,
                success: function(t) {
                    t.subscriptionsSetting.itemSettings && i.setData({
                        showSubAlert: !1
                    });
                }
            });
            var s = [ "yUU1DnDTXPSkN66l0wWAiEsHl7w45NagjMTopr_YVPY", "0odmNMWn8Jofi1dVWfqH_qA9_FaFeIH01f6-KX9OnJ4", "9qfXevoeMubnglnbAfsrtpoBNk5B8X5x2AZFHKjg7dg" ];
            e.requestSubscribeMessage({
                tmplIds: s,
                success: function(e) {
                    if (i.data.showSubAlert) {
                        var n = [ e[s[0]], e[s[1]], e[s[2]] ].every(function(t) {
                            return "reject" === t;
                        });
                        t.default.moduleClick(n ? "b_gc_s40id2db_mc" : "b_gc_w3oapmkw_mc", "", {
                            cid: "c_gc_ehpi86si"
                        });
                    }
                },
                fail: function(t) {
                    console.log("user sub fail", t);
                },
                complete: function() {
                    i.data.showSubAlert && t.default.moduleView("b_gc_lkqzukvj_mv", "", {
                        cid: "c_gc_ehpi86si"
                    }), e.getSetting({
                        withSubscriptions: !0,
                        success: function(e) {
                            i.data.showSubAlert && e.subscriptionsSetting.itemSettings && (i.setData({
                                showSubAlert: !1
                            }), t.default.moduleClick("b_gc_2b14uqfz_mc", "", {
                                cid: "c_gc_ehpi86si"
                            }));
                        }
                    }), i.triggerEvent("subscribeFinish");
                }
            });
        },
        closeTip: function() {
            clearTimeout(this.tipTimer), this.setData({
                showTip: !1
            });
        }
    },
    lifetimes: {
        attached: function() {
            var t = this, s = e.getStorageSync(i);
            this.properties.enableTip && !s && (this.setData({
                showTip: !0
            }), e.setStorage({
                key: i,
                data: "1"
            }), setTimeout(function() {
                t.closeTip();
            }, 3e3));
        },
        detached: function() {
            this.closeTip();
        }
    }
});