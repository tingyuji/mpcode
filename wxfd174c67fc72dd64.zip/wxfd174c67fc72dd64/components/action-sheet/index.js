Component({
    externalClasses: [ "my-class", "my-class-mask" ],
    options: {
        multipleSlots: !0
    },
    properties: {
        visible: {
            type: Boolean,
            value: !1
        },
        maskClosable: {
            type: Boolean,
            value: !0
        },
        showCancel: {
            type: Boolean,
            value: !0
        },
        cancelText: {
            type: String,
            value: "取消"
        },
        title: {
            type: String
        },
        actions: {
            type: Array,
            value: []
        }
    },
    methods: {
        handleClickMask: function() {
            this.data.maskClosable && this.handleClickCancel();
        },
        handleClickItem: function(e) {
            var t = e.currentTarget, l = ((void 0 === t ? {} : t).dataset || {}).index;
            this.triggerEvent("onItemClick", {
                index: l
            });
        },
        handleClickCancel: function() {
            this.triggerEvent("onCancelClick");
        }
    }
});