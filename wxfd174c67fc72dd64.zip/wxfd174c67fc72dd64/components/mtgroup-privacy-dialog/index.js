Component({
    properties: {},
    data: {
        show: !1
    },
    methods: {
        handleAction: function(t) {
            var a = this.data.callback;
            a && a(t, this), this.setData({
                show: !1
            });
        }
    }
});