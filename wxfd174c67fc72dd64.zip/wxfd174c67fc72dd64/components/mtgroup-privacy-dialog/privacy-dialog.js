function e() {
    var e = getCurrentPages();
    return e[e.length - 1];
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var t = Object.assign || function(e) {
    for (var t = 1; t < arguments.length; t++) {
        var r = arguments[t];
        for (var n in r) Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
}, r = function(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}(require("../../utils/index")), n = {
    show: !1,
    selector: "#mtgroup-privacy-dialog"
};

exports.default = function() {
    var o = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, a = Object.assign({}, n, o);
    return new Promise(function(n) {
        r.default.nextTick(function() {
            var r = (a.context || e()).selectComponent(a.selector);
            r.setData(t({
                callback: n
            }, a)), r.setData({
                show: !0
            });
        });
    });
};