function r(r, e, t) {
    return e in r ? Object.defineProperty(r, e, {
        value: t,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : r[e] = t, r;
}

var e = function() {
    function r(r, e) {
        var t = [], a = !0, n = !1, o = void 0;
        try {
            for (var i, u = r[Symbol.iterator](); !(a = (i = u.next()).done) && (t.push(i.value), 
            !e || t.length !== e); a = !0) ;
        } catch (r) {
            n = !0, o = r;
        } finally {
            try {
                !a && u.return && u.return();
            } finally {
                if (n) throw o;
            }
        }
        return t;
    }
    return function(e, t) {
        if (Array.isArray(e)) return e;
        if (Symbol.iterator in Object(e)) return r(e, t);
        throw new TypeError("Invalid attempt to destructure non-iterable instance");
    };
}();

Component({
    externalClasses: [ "my-class", "my-item-class" ],
    properties: {
        starNum: {
            type: Number,
            value: 5
        },
        showScoreNumber: {
            type: Boolean,
            value: !0
        },
        score: Number
    },
    data: {
        halfStarIndex: 0,
        fullStarNumber: 0,
        scoreNumber: 0
    },
    observers: {
        score: function(r) {
            r && this.setStarData(r);
        }
    },
    methods: {
        setStarData: function(t) {
            var a = r({
                1: [ 0, 20 ],
                2: [ 20, 30 ],
                3: [ 30, 35 ],
                3.5: [ 35, 40 ],
                4: [ 40, 45 ],
                4.5: [ 45, 48 ]
            }, 5, [ 48, 50 ]), n = 0, o = 0, i = -1;
            if (t / 50 == 1) o = 5; else {
                var u = !0, l = !1, s = void 0;
                try {
                    for (var c, f = Object.keys(a)[Symbol.iterator](); !(u = (c = f.next()).done); u = !0) {
                        var y = c.value, b = e(a[y], 2), m = b[0];
                        if (t < b[1] && t >= m) {
                            n = y, o = parseInt(n), i = n % 1 ? o + 1 : -1;
                            break;
                        }
                    }
                } catch (r) {
                    l = !0, s = r;
                } finally {
                    try {
                        !u && f.return && f.return();
                    } finally {
                        if (l) throw s;
                    }
                }
            }
            this.setData({
                halfStarIndex: i,
                fullStarNumber: o,
                scoreNumber: (t / 10).toFixed(1)
            });
        }
    }
});