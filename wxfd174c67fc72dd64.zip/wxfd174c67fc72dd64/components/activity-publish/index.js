function t(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

var e = t(require("../../common/lx")), n = t(require("../../common/login")), s = require("../../npm/regenerator-runtime/runtime.js"), i = require("../../npm/@mtfe/weapp-privacy-api/index.js").default;

Component({
    externalClasses: [ "custom-class" ],
    options: {
        addGlobalClass: !0
    },
    properties: {
        style: {
            type: String,
            value: ""
        }
    },
    data: {
        showSubAlert: !0
    },
    methods: {
        talentPublish: function(t) {
            try {
                var e = this;
                i.getSetting({
                    withSubscriptions: !0,
                    success: function(t) {
                        t.subscriptionsSetting.itemSettings && e.setData({
                            showSubAlert: !1
                        });
                    }
                }), i.requestSubscribeMessage({
                    tmplIds: [ "Tf0XliBiG8mUjU39IHFj9sNeo6kosfhUvh4-JZWqMa4", "sJ2c8-bkXGKnzSUD5cB7L-nyigN_BjbTaAlfNB6kXbk", "6IYuGNFeXdz1GtNMyqCapsR0VaWaLN9hSOE9m2pdSys" ],
                    fail: function(t) {
                        console.log("user sub fail", t);
                    },
                    complete: function() {
                        i.getSetting({
                            withSubscriptions: !0,
                            success: function(t) {
                                e.data.showSubAlert && t.subscriptionsSetting.itemSettings && e.setData({
                                    showSubAlert: !1
                                });
                            }
                        }), i.navigateTo({
                            url: t
                        });
                    }
                });
            } catch (t) {
                console.warn(t);
            }
        },
        forceLogin: function() {
            var t = this;
            return n.default.mtDefaultLogin({
                isBind: !0
            }).then(function(e) {
                t.data.token = e.token || e.userInfo && e.userInfo.token || "";
            });
        },
        onActivityPublish: function() {
            var t = this;
            return function() {
                var i, r;
                return s.async(function(u) {
                    for (;;) switch (u.prev = u.next) {
                      case 0:
                        return e.default.moduleClick("b_gc_oetrgxmk_mc", {}), u.next = 3, s.awrap(n.default.mtDefaultLogin({
                            isBind: !1
                        }));

                      case 3:
                        if (i = u.sent, r = i.token || i.userInfo && i.userInfo.token || "") {
                            u.next = 9;
                            break;
                        }
                        return u.next = 8, s.awrap(n.default.mtDefaultLogin({
                            isBind: !0
                        }));

                      case 8:
                        return u.abrupt("return");

                      case 9:
                        t.talentPublish("/pages/talent/publish/index");

                      case 10:
                      case "end":
                        return u.stop();
                    }
                }, null, null, null, Promise);
            }();
        }
    }
});