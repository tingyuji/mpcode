function t(t, n) {
    return l(t) || o(t, n) || r(t, n) || e();
}

function e() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}

function r(t, e) {
    if (t) {
        if ("string" == typeof t) return n(t, e);
        var r = Object.prototype.toString.call(t).slice(8, -1);
        return "Object" === r && t.constructor && (r = t.constructor.name), "Map" === r || "Set" === r ? Array.from(t) : "Arguments" === r || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r) ? n(t, e) : void 0;
    }
}

function n(t, e) {
    (null == e || e > t.length) && (e = t.length);
    for (var r = 0, n = new Array(e); r < e; r++) n[r] = t[r];
    return n;
}

function o(t, e) {
    var r = null == t ? null : "undefined" != typeof Symbol && t[Symbol.iterator] || t["@@iterator"];
    if (null != r) {
        var n, o, l = [], i = !0, s = !1;
        try {
            for (r = r.call(t); !(i = (n = r.next()).done) && (l.push(n.value), !e || l.length !== e); i = !0) ;
        } catch (t) {
            s = !0, o = t;
        } finally {
            try {
                i || null == r.return || r.return();
            } finally {
                if (s) throw o;
            }
        }
        return l;
    }
}

function l(t) {
    if (Array.isArray(t)) return t;
}

var i = function(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}(require("../../utils/index")), s = require("../../npm/regenerator-runtime/runtime.js"), a = require("../../npm/@mtfe/weapp-privacy-api/index.js").default;

Component({
    externalClasses: [ "my-class" ],
    options: {
        multipleSlots: !0
    },
    data: {
        offsetLeft: 0,
        scrollLeft: 0
    },
    properties: {},
    lifetimes: {
        ready: function() {
            this.getBaseInfo();
        }
    },
    methods: {
        observe: function() {
            var t = this;
            a.createIntersectionObserver(this, {
                observeAll: !0
            }).relativeTo(".lateral-load-more__wrap", {
                left: 0
            }).observe(".load-more__opts", function(e) {
                e.intersectionRatio || t.getBaseInfo();
            });
        },
        getBaseInfo: function() {
            var e = this;
            return function() {
                var r, n, o, l;
                return s.async(function(a) {
                    for (;;) switch (a.prev = a.next) {
                      case 0:
                        return a.next = 2, s.awrap(Promise.all([ ".lateral-load-more__wrap", ".load-more__opts" ].map(function(t) {
                            return i.default.getNodeRect(t, e);
                        })));

                      case 2:
                        r = a.sent, n = t(r, 2), o = n[0], l = n[1], e._scrollWrapDom = o, e._loadMoreDom = l;

                      case 8:
                      case "end":
                        return a.stop();
                    }
                }, null, null, null, Promise);
            }();
        },
        bindScroll: function(t) {
            var e = this, r = t.detail, n = r.scrollLeft, o = r.scrollWidth;
            this._scroll = {
                scrollLeft: n,
                scrollWidth: o
            }, this._timer && (clearTimeout(this._timer), this._timer = null), this._timer = setTimeout(function() {
                e._scrollEndTime = Date.now(), e.scrollEnd();
            }, 100);
        },
        onDragEnd: function() {
            this._dragEndTime = Date.now(), this.scrollEnd();
        },
        scrollEnd: function() {
            if (this._dragEndTime && this._scrollEndTime) {
                var t = [ this._scrollWrapDom.width, this._loadMoreDom.left, this._loadMoreDom.width, this._scroll ], e = t[0], r = t[1], n = t[2], o = t[3], l = o.scrollLeft, i = o.scrollWidth, s = l + e;
                s > r && this.setData({
                    scrollLeft: i - n - e
                }), Date.now() - this._dragEndTime <= 100 && s > r + n / 2 && this.triggerEvent("onLoadMore"), 
                this._dragEndTime = null, this._scrollEndTime = null;
            }
        }
    }
});