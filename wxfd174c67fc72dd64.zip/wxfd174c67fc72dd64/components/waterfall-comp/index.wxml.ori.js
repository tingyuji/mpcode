function(e,s,r,gg){
var z=gz$gwx_41()
var b9W=_n('view')
_rz(z,b9W,'class',0,e,s,gg)
var o0W=_mz(z,'lx-module',['lxClickBid',1,'lxExtend',1,'lxViewBid',2],[],e,s,gg)
var xAX=_n('view')
_rz(z,xAX,'class',4,e,s,gg)
var oBX=_v()
_(xAX,oBX)
var fCX=function(hEX,cDX,oFX,gg){
var oHX=_mz(z,'view',['class',9,'style',1],[],hEX,cDX,gg)
var lIX=_mz(z,'waterfall-item',['bind:collect',11,'bind:itemClick',1,'changedItem',2,'columnIndex',3,'feeds',4,'itemClickBid',6,'itemViewBid',7,'shopClickBid',8,'shopViewBid',9],['wx-waterfall-item',5],hEX,cDX,gg)
_(oHX,lIX)
_(oFX,oHX)
return oFX
}
oBX.wxXCkey=4
_2z(z,7,fCX,e,s,gg,oBX,'feeds','columnindex','index')
_(o0W,xAX)
_(b9W,o0W)
_(r,b9W)
return r
}