function t(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

function e(t) {
    if (Array.isArray(t)) {
        for (var e = 0, i = Array(t.length); e < t.length; e++) i[e] = t[e];
        return i;
    }
    return Array.from(t);
}

var i = t(require("../../npm/@dp/util-emoji/index.js")), a = t(require("../../utils/index")), n = t(require("../../common/config")), r = require("../../npm/@mtfe/weapp-privacy-api/index.js").default;

Component({
    externalClasses: [ "outer-class" ],
    properties: {
        listData: {
            type: Array,
            value: []
        },
        changeIndex: {
            type: Number,
            value: 0
        },
        column: {
            type: Number,
            value: 2
        },
        gap: {
            type: Number,
            value: 16
        },
        clickBid: {
            type: String,
            value: ""
        },
        viewBid: {
            type: String,
            value: ""
        },
        lxExtend: {
            type: String,
            value: ""
        },
        itemViewBid: {
            type: String,
            value: ""
        },
        itemClickBid: {
            type: String,
            value: ""
        },
        shopViewBid: {
            type: String,
            value: ""
        },
        shopClickBid: {
            type: String,
            value: ""
        }
    },
    lifetimes: {
        attached: function() {}
    },
    data: {
        columnWidth: 50,
        columnHeight: [],
        columnData: [],
        oldlength: 0,
        waterfallIndex: 0,
        itemWidth: 170,
        changedItem: null
    },
    methods: {
        initData: function() {
            var t = Array(this.properties.column).fill(0), e = Array(this.properties.column).fill([]).map(function() {
                return [].fill();
            }), i = void 0;
            if ("wx" === n.default.platform) {
                var l = this;
                r.createSelectorQuery().in(this).select(".list-container").boundingClientRect(function(t) {
                    var e = l.properties.column - 1, n = l.properties.gap * e, r = a.default.px2rpx(t.width);
                    i = (r - n) / r * 100, l.data.itemWidth = a.default.rpx2px((r - n) / 2);
                    var o = Math.floor(i / l.properties.column * 100) / 100;
                    l.setData({
                        columnWidth: o
                    });
                }).exec();
            }
            this.setData({
                columnHeight: t,
                columnData: e
            });
        },
        resetData: function() {
            var t = Array(this.properties.column).fill(0), e = Array(this.properties.column).fill([]).map(function() {
                return [].fill();
            });
            this.data.columnHeight = t, this.data.columnData = e;
        },
        renderWaterfall: function() {
            this.data.columnHeight.length || this.initData();
            var t = 0;
            t = this.properties.listData.length - 0, this.resetData();
            for (var e = this.properties.listData, a = this.data.columnData, n = this.data.columnHeight, r = 0; r < t; r++) {
                var l = this.getMinIndex(n), o = a[0].length + a[1].length;
                e[0 + r].waterfallIndex = o, e[0 + r].recommendReason = i.default.formatText(e[0 + r].recommendReason), 
                a[l] && a[l].push(e[0 + r]);
                var u = e[0 + r].pictures, s = this.getPicHeight(u) + 105;
                n[l] += parseFloat(s);
            }
            this.data.oldlength = 0 + t, this.updateCollect(), this.setData({
                columnData: a
            });
        },
        getPicHeight: function(t) {
            return (t && t.length && t[0].height || 345) / (t && t.length && t[0].width || 343) * this.data.itemWidth;
        },
        updateCollect: function() {
            for (var t = this.data.columnData, e = this.properties, i = e.changeIndex, a = e.listData, n = 0; n < t.length; n++) {
                for (var r = t[n], l = !1, o = 0; o < r.length; o++) {
                    var u = r[o];
                    if (a[i] && u.contentId === a[i].contentId && u.contentType === a[i].contentType) {
                        this.data["columnData[" + n + "][" + o + "]"] = a[i], this.setData({
                            changedItem: {
                                column: n,
                                index: o,
                                data: a[i]
                            }
                        }), l = !0;
                        break;
                    }
                }
                if (l) break;
            }
        },
        getMinIndex: function(t) {
            var i = Math.min.apply(Math, e(t)), a = t.indexOf(i);
            return -1 !== a ? a : 0;
        },
        itemClick: function(t) {
            this.triggerEvent("itemClick", t.detail);
        },
        collect: function(t) {
            this.triggerEvent("collect", t.detail);
        }
    },
    observers: {
        changeIndex: function() {
            this.updateCollect();
        },
        listData: function(t) {
            var e = (t || []).length;
            e !== this._currentListLength_ && (this.renderWaterfall(), this._currentListLength_ = e);
        }
    }
});