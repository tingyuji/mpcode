Component({
    externalClasses: [ "custom-class", "action-class", "value-class" ],
    properties: {
        defaultValue: {
            type: Number,
            value: 0,
            observer: function(e) {
                this.init(e);
            }
        },
        inputVisible: {
            type: Boolean,
            value: !0
        },
        step: {
            type: Number,
            value: 1
        },
        min: {
            type: Number,
            value: Number.MIN_SAFE_INTEGER
        },
        max: {
            type: Number,
            value: Number.MAX_SAFE_INTEGER
        },
        disabled: Boolean,
        enableInput: Boolean
    },
    data: {
        value: 0,
        originValue: 0,
        increaseDisabled: !1,
        decreaseDisabled: !1
    },
    methods: {
        isDisabled: function() {
            var e = this.properties, t = e.disabled, i = e.min, a = e.max, s = this.data.value, n = Number(i), u = Number(a);
            return t || s <= n || s >= u;
        },
        setDisabled: function() {
            var e = this.properties, t = e.min, i = e.max, a = this.data.value, s = Number(t), n = Number(i);
            this.setData({
                increaseDisabled: a >= n,
                decreaseDisabled: a <= s
            });
        },
        onIncrease: function() {
            var e = this.properties, t = e.step, i = e.disabled, a = e.max, s = this.data.value;
            i || s >= Number(a) || (this.setData({
                value: s + Number(t)
            }), this.setDisabled(), this.onChange());
        },
        onDecrease: function() {
            var e = this.properties, t = e.step, i = e.disabled, a = e.min, s = this.data.value;
            i || s <= Number(a) || (this.setData({
                value: s - Number(t)
            }), this.setDisabled(), this.onChange());
        },
        onInputFocus: function() {
            this.properties.disabled || (this.data.originValue = this.data.value);
        },
        onInput: function(e) {
            this.properties.disabled || this.setData({
                value: (e.detail || {}).value
            });
        },
        onInputBlur: function(e) {
            var t = (e.detail || {}).value, i = Number(t), a = this.properties, s = a.min, n = a.max, u = a.disabled, r = Number(s), l = Number(n);
            u || void 0 === t || "" === t || Number.isNaN(i) || i > l || i < r ? this.triggerEvent("inputBlur", {
                context: this,
                inputValue: i,
                isValid: !1
            }) : (this.setData({
                value: i
            }), this.setDisabled(), this.onChange(), this.triggerEvent("inputBlur", {
                context: this,
                inputValue: i,
                isValid: !0
            }));
        },
        onChange: function() {
            this.triggerEvent("change", this.data.value);
        },
        init: function() {
            this.setData({
                value: Number(this.properties.defaultValue) || 0
            }), this.setDisabled();
        },
        onInputTap: function() {
            this.triggerEvent("inputTap");
        },
        onContainerTap: function() {
            this.triggerEvent("containerTap");
        },
        safeSetValue: function(e) {
            this.setData({
                value: e
            }), this.setDisabled(), this.onChange();
        }
    },
    lifetimes: {
        attached: function() {
            this.init();
        }
    }
});