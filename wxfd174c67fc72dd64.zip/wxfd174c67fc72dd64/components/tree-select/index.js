var t = function() {
    function t(t, e) {
        var n = [], r = !0, i = !1, a = void 0;
        try {
            for (var o, s = t[Symbol.iterator](); !(r = (o = s.next()).done) && (n.push(o.value), 
            !e || n.length !== e); r = !0) ;
        } catch (t) {
            i = !0, a = t;
        } finally {
            try {
                !r && s.return && s.return();
            } finally {
                if (i) throw a;
            }
        }
        return n;
    }
    return function(e, n) {
        if (Array.isArray(e)) return e;
        if (Symbol.iterator in Object(e)) return t(e, n);
        throw new TypeError("Invalid attempt to destructure non-iterable instance");
    };
}();

Component({
    properties: {
        treeData: {
            type: Array,
            value: []
        },
        activeKey: {
            type: [ Number, String ],
            value: ""
        }
    },
    lifetimes: {
        attached: function() {
            !this.properties.activeKey && this.initData();
        }
    },
    data: {
        firstColumnIndex: 0,
        secondColumnIndex: 0,
        secondColumnData: [],
        firstSelectData: {}
    },
    methods: {
        initData: function() {
            this.data.firstSelectData = this.properties.treeData[this.data.firstColumnIndex], 
            this.setData({
                secondColumnData: this.properties.treeData[this.data.firstColumnIndex].children
            });
        },
        firstColumnClick: function(t) {
            var e = t.currentTarget.dataset;
            this.setData({
                firstColumnIndex: e.current,
                secondColumnData: e.item.children,
                secondColumnIndex: 0
            });
        },
        secondColumnClick: function(t) {
            var e = t.currentTarget.dataset;
            this.data.firstSelectData = this.properties.treeData[this.data.firstColumnIndex], 
            this.setData({
                secondColumnIndex: e.current
            }), this.triggerEvent("secondColumnClick", {
                first: this.data.firstSelectData,
                second: e.item
            });
        },
        toActiveItem: function(e) {
            var n = this, r = e.split("_"), i = t(r, 2), a = i[0], o = i[1];
            this.properties.treeData.forEach(function(t, e) {
                t.id === Number(a) && t.children.forEach(function(r, i) {
                    r.id === Number(o) && n.setData({
                        toFirstIndex: "first" + t.id,
                        toSecondIndex: "second" + r.id,
                        firstColumnIndex: e,
                        secondColumnData: t.children,
                        secondColumnIndex: i
                    });
                });
            });
        }
    },
    observers: {
        activeKey: function(t) {
            t && this.toActiveItem(t);
        }
    }
});