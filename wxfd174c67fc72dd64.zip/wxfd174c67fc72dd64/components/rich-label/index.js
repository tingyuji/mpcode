Component({
    properties: {
        label: String,
        keyword: String,
        ignoreCase: Boolean,
        renderWithJoinedWord: Boolean,
        highlightColor: {
            type: String,
            value: "#ffd100"
        },
        baseColor: {
            type: String,
            value: "#fff"
        }
    },
    observers: {
        "label,keyword": function(e, t) {
            this.properties.renderWithJoinedWord ? this.initJoinedWord(e, t) : this.init(e, t);
        }
    },
    data: {
        text: []
    },
    methods: {
        init: function() {
            for (var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "", o = this.properties, i = o.highlightColor, n = o.baseColor, r = o.ignoreCase ? function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "";
                return e.toLowerCase().includes(t.toLowerCase());
            } : function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "";
                return e.includes(t);
            }, l = [], h = 0; h < e.length; h++) l.push({
                value: e[h],
                color: r(t, e[h]) ? i : n
            });
            this.setData({
                text: l
            });
        },
        initJoinedWord: function() {
            for (var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "", o = this.properties, i = o.highlightColor, n = o.baseColor, r = o.ignoreCase ? function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "";
                return e.toLowerCase().includes(t.toLowerCase());
            } : function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "";
                return e.includes(t);
            }, l = [], h = 0; h < e.length; h++) {
                var s = r(t, e[h]) ? i : n;
                l.length && l[l.length - 1].color === s ? l[l.length - 1].value += e[h] : l.push({
                    color: s,
                    value: e[h]
                });
            }
            this.setData({
                text: l
            });
        }
    }
});