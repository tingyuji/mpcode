var t = require("../../common/behaviors/selectQuery");

Component({
    options: {
        addGlobalClass: !0,
        pureDataPattern: /^_/,
        multipleSlots: !0
    },
    behaviors: [ t ],
    properties: {
        offsetTop: {
            type: Number,
            value: 0
        },
        zIndex: {
            type: Number,
            value: 99
        },
        disabled: {
            type: Boolean,
            value: !1
        },
        container: {
            type: null
        }
    },
    data: {
        fixed: !1,
        height: 0,
        _attached: !1,
        _containerHeight: 0
    },
    observers: {
        disabled: function(t) {
            this.data._attached && (t ? this.disconnectObserver() : this.initObserver());
        },
        container: function(t) {
            "function" == typeof t && this.data.height && this.observerContainer();
        },
        offsetTop: function(t) {
            "number" == typeof t && this.data._attached && this.initObserver();
        }
    },
    lifetimes: {
        attached: function() {
            this.data._attached = !0, this.data.disabled || this.initObserver();
        },
        detached: function() {
            this.data._attached = !1, this.disconnectObserver();
        }
    },
    methods: {
        getContainerRect: function() {
            var t = this.data.container();
            return new Promise(function(e) {
                return t.boundingClientRect(e).exec();
            });
        },
        initObserver: function() {
            var t = this;
            this.disconnectObserver(), this.getRect(".sticky").then(function(e) {
                t.setData({
                    height: e.height
                }), t.observerContent(), t.observerContainer();
            });
        },
        disconnectObserver: function(t) {
            if (t) {
                var e = this[t];
                e && e.disconnect();
            } else this.contentObserver && this.contentObserver.disconnect(), this.containerObserver && this.containerObserver.disconnect();
        },
        observerContent: function() {
            var t = this, e = this.data.offsetTop;
            this.disconnectObserver("contentObserver");
            var i = this.createIntersectionObserver({
                thresholds: [ 1 ],
                initialRatio: 1
            });
            i.relativeToViewport({
                top: -e
            }), i.observe(".sticky", function(e) {
                t.data.disabled || t.setFixed(e.boundingClientRect.top);
            }), this.contentObserver = i;
        },
        observerContainer: function() {
            var t = this, e = this.data, i = e.container, n = e.height, r = e.offsetTop;
            "function" == typeof i && (this.disconnectObserver("containerObserver"), this.getContainerRect().then(function(e) {
                t.getRect(".sticky").then(function(i) {
                    var s = i.top, o = e.top, a = e.height, c = s - o, h = t.createIntersectionObserver({
                        thresholds: [ 1 ],
                        initialRatio: 1
                    });
                    h.relativeToViewport({
                        top: a - n - r - c
                    }), h.observe(".sticky", function(e) {
                        t.data.disabled || t.setFixed(e.boundingClientRect.top);
                    }), t.data._relativeTop = c, t.data._containerHeight = a, t.containerObserver = h;
                });
            }));
        },
        setFixed: function(t) {
            var e = this.data, i = e.height, n = e._containerHeight, r = e._relativeTop, s = e.offsetTop, o = n && i ? t >= i + s + r - n && t < s : t < s;
            this.triggerEvent("scroll", {
                scrollTop: t,
                isFixed: o
            }), this.setData({
                fixed: o
            });
        }
    }
});