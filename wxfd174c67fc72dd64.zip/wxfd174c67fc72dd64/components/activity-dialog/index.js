function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

var t = e(require("../../utils/raf")), s = e(require("../../utils/index")), a = require("../../npm/@mtfe/weapp-privacy-api/index.js").default, i = s.default.px2rpx, n = a.getSystemInfoSync().screenHeight;

Component({
    externalClasses: [ "custom-mask", "custom-content", "custom-panel", "custom-close" ],
    options: {
        multipleSlots: !0
    },
    properties: {
        zIndex: {
            type: Number,
            value: 20
        },
        show: {
            type: Boolean,
            value: !1,
            observer: "visibleChange"
        },
        width: {
            type: Number,
            value: 560
        },
        height: {
            type: Number,
            value: 556,
            observer: "heightChange"
        },
        showClose: {
            type: Boolean,
            value: !0
        }
    },
    data: {
        marginBottom: "auto",
        visible: !1,
        classNames: {
            mask: "",
            content: ""
        }
    },
    methods: {
        visibleChange: function(e, s) {
            var a = this;
            e && !s && (this.setData({
                visible: !0
            }), (0, t.default)(function() {
                a.setData({
                    classNames: {
                        mask: "mask-fade-in",
                        content: "scale-in"
                    }
                });
            })), s && !e && (this.setData({
                classNames: {
                    mask: "mask-fade-out",
                    content: "scale-out"
                }
            }), setTimeout(function() {
                a.setData({
                    visible: !1
                });
            }, 120));
        },
        onClose: function() {
            this.triggerEvent("close");
        },
        heightChange: function(e) {
            e && "number" == typeof e && this.setData({
                marginBottom: (i(n) - e) / 2 + "rpx"
            });
        }
    },
    lifetimes: {
        attached: function() {
            var e = this.properties.height;
            this.heightChange(e);
        }
    }
});