function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var r = Object.assign || function(e) {
    for (var r = 1; r < arguments.length; r++) {
        var t = arguments[r];
        for (var o in t) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
    }
    return e;
};

exports.default = function(e) {
    return o.default.request({
        url: a.AUTHOR_FOLLOW,
        method: "POST",
        data: r({}, e, {
            platform: t.default.platformCode
        })
    }).then(function(e) {
        var r = e.data, t = r.code, o = r.msg, a = o.errorMessage;
        return 200 !== t || o.errorMessage ? {
            success: !1,
            msg: a
        } : {
            success: !0
        };
    }).catch(function() {
        return {
            success: !1,
            msg: "操作失败"
        };
    });
};

var t = e(require("../../common/config")), o = e(require("../../npm/@dzfe/wx-api-promisify/dist/index.js")), a = {
    AUTHOR_FOLLOW: t.default.dp_domain + "/api/joy/sharerelation/follow/operation"
};