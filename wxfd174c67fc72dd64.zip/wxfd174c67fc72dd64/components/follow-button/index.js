function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

var t = e(require("../../common/login")), n = e(require("../../utils/dialog")), i = require("../../npm/regenerator-runtime/runtime.js"), o = require("../../npm/@mtfe/weapp-privacy-api/index.js").default, s = require("./api").default;

Component({
    externalClasses: [ "my-class" ],
    properties: {
        status: {
            type: Number,
            value: 0,
            observer: function(e) {
                this.setData({
                    isFollowed: 0 !== e,
                    currentStatusNumber: e
                });
            }
        },
        followedStyles: {
            type: Object,
            default: {}
        },
        needLoading: {
            type: Boolean,
            value: !1
        },
        statusTextMap: {
            type: Object,
            value: {
                0: "关注",
                1: "已关注",
                2: "互相关注"
            }
        },
        userMaskid: {
            type: String,
            required: !0
        },
        cancelConfirmTexts: {
            type: Object,
            value: {
                title: "确定要取消关注吗？",
                confirm: "确定取消",
                cancel: "继续关注"
            }
        }
    },
    data: {
        isFollowed: !1,
        currentStatusNumber: 0
    },
    methods: {
        onBtnTap: function() {
            var e = this;
            if (this.triggerEvent("onFollowBtnTap"), !this._loading_) {
                var t = this.data, i = t.isFollowed, o = t.cancelConfirmTexts, s = o.confirm, a = o.cancel, r = o.title;
                i ? n.default.confirm({
                    selector: "#mtgroup-dialog-follow-btn",
                    message: r,
                    cancelButtonText: a,
                    confirmButtonText: s,
                    context: this
                }).then(function() {
                    return e.confirmTap();
                }, function() {
                    e.triggerEvent("cancelConfirmOparation");
                }) : this.confirmTap();
            }
        },
        confirmTap: function() {
            var e = this, n = this.data, a = n.isFollowed, r = n.userMaskid, l = n.needLoading;
            t.default.mtDefaultLogin({
                isBind: !0,
                isWxInfo: !1
            }).then(function() {
                var t, n, u;
                return i.async(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return this._loading_ = !0, l && o.showLoading({
                            title: ""
                        }), e.next = 4, i.awrap(s({
                            type: ~~!a,
                            usermaskid: r
                        }));

                      case 4:
                        t = e.sent, n = t.success, u = t.msg, this._loading_ = !1, o.hideLoading(), n ? (o.showToast({
                            title: a ? "已取消关注" : "关注成功",
                            icon: "none"
                        }), this.setData({
                            isFollowed: ~~!a,
                            currentStatusNumber: a ? 0 : 1,
                            status: a ? 0 : 1
                        }), this.triggerEvent(this.data.isFollowed ? "followSuccess" : "cancelFollowSuccess", {
                            userMaskid: r
                        })) : o.showToast({
                            title: u,
                            icon: "none"
                        });

                      case 10:
                      case "end":
                        return e.stop();
                    }
                }, null, e, null, Promise);
            });
        }
    }
});