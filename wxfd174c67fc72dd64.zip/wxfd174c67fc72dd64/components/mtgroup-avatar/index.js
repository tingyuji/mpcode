Component({
    externalClasses: [ "custom-avatar" ],
    options: {
        multipleSlots: !0
    },
    properties: {
        url: {
            type: String,
            value: ""
        },
        mode: String,
        borderRadius: {
            type: String,
            value: "0"
        },
        width: {
            type: String,
            value: "100rpx"
        },
        height: {
            type: String,
            value: "100rpx"
        },
        sliceOption: {
            type: Object,
            value: null
        }
    },
    data: {},
    methods: {
        onAvatarTap: function() {
            var t = this.properties.url;
            this.triggerEvent("onAvatarTap", {
                url: t
            });
        }
    }
});