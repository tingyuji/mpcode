function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = function(e) {
    return t.default.request({
        url: o.POST_LOAD,
        data: e,
        method: "POST"
    }).then(function(e) {
        var r = e.data;
        if (200 === r.code && r.msg) return r.msg;
        throw new Error("请求数据失败");
    }).catch(function() {
        return null;
    });
};

var r = e(require("../../common/config")), t = e(require("../../npm/@dzfe/wx-api-promisify/dist/index.js")), o = {
    POST_LOAD: r.default.gpower_domain + "/api/gpower/post/load"
};