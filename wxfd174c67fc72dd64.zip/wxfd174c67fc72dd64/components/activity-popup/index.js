function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

var t = e(require("../../common/config")), a = e(require("../../common/login")), i = e(require("../../common/lx")), o = e(require("./api")), n = require("../../npm/regenerator-runtime/runtime.js"), r = require("../../npm/@mtfe/weapp-privacy-api/index.js").default, p = getApp();

Component({
    properties: {
        popVO: {
            type: Object,
            value: null
        },
        postMaskId: {
            type: String,
            optionalTypes: [ Number ],
            value: ""
        }
    },
    data: {
        showDialog: !1,
        openid: "",
        expoid: "",
        uuid: "",
        fp: "",
        cityid: 10,
        platform: t.default.platform
    },
    lifetimes: {
        attached: function() {
            this.properties.popVO ? (this.setData({
                showDialog: !0
            }), i.default.moduleView("b_gc_m1cvnias_mv")) : this.init();
        }
    },
    methods: {
        init: function() {
            var e = this;
            return n.async(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.next = 2, n.awrap(Promise.all([ e.getCityId(), e.getUserInfo() ]));

                  case 2:
                    e.getPopVO();

                  case 3:
                  case "end":
                    return t.stop();
                }
            }, null, null, null, Promise);
        },
        getPopVO: function() {
            var e = this, a = this.data, i = a.fp, n = a.uuid, r = a.openid, p = a.expoid, u = a.cityid, s = {
                postmaskid: this.properties.postMaskId,
                platform: t.default.platformCode,
                uacode: t.default.uaCode,
                cityid: u,
                fp: i,
                uuid: n,
                openid: r,
                expoid: p
            };
            (0, o.default)(s).then(function(t) {
                e.triggerEvent("endFetchLoad", t), e.setData({
                    popVO: t && t.popVO,
                    showDialog: !0
                });
            });
        },
        getCityId: function() {
            var e = this;
            {
                if (!p.globalData || !p.globalData.ci) return p.getCityInfo().then(function(t) {
                    e.data.cityid = t.id;
                });
                this.data.cityid = p.globalData.ci;
            }
        },
        getUserInfo: function() {
            var e = this;
            return function() {
                var t, i, o, r;
                return n.async(function(u) {
                    for (;;) switch (u.prev = u.next) {
                      case 0:
                        return u.next = 2, n.awrap(p.finger());

                      case 2:
                        if (e.data.fp = u.sent, !p.globalData.userInfo) {
                            u.next = 9;
                            break;
                        }
                        return t = p.globalData.userInfo, i = t.openId, o = t.openIdCipher, r = t.uuid, 
                        e.data.openid = i, e.data.expoid = o, e.data.uuid = r, u.abrupt("return");

                      case 9:
                        return u.abrupt("return", a.default.mtDefaultLogin({
                            isBind: !0
                        }).then(function(t) {
                            var a = t.openId, i = t.openIdCipher, o = t.uuid;
                            e.data.openid = a, e.data.expoid = i, e.data.uuid = o;
                        }));

                      case 10:
                      case "end":
                        return u.stop();
                    }
                }, null, null, null, Promise);
            }();
        },
        getMyMoney: function() {
            i.default.moduleClick("b_gc_shvwn3mb_mc"), "wx" === t.default.platform ? r.navigateTo({
                url: this.properties.popVO.popJumpUrl
            }) : this.properties.popVO && r.navigateToMiniProgram({
                platform: "wx",
                appId: "gh_c509e170d6df",
                path: this.properties.popVO.popJumpUrl,
                extraData: {},
                envVersion: "release",
                success: function() {},
                fail: function() {}
            }), this.setData({
                showDialog: !1
            });
        },
        closeDialog: function() {
            i.default.moduleClick("b_gc_vc06s53a_mc"), this.setData({
                showDialog: !1
            });
        }
    }
});