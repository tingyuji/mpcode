function t(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

var e = t(require("../../utils/index")), a = t(require("../../utils/raf")), n = t(require("../../common/config")), o = t(require("../../common/login")), i = t(require("../../common/lx")), r = t(require("../../utils/toast")), s = require("./api"), u = require("../../npm/regenerator-runtime/runtime.js"), c = require("../../npm/@mtfe/weapp-privacy-api/index.js").default, l = (0, 
e.default.rpx2px)(224), d = getApp(), f = {
    SELECT_TIME: "选择拼场开始时间",
    CONFIRM_GROUP_INFO: "确认拼场信息",
    EDIT_TIME: "修改拼场开始时间"
}, p = {
    SELECT_TIME: "下一步",
    CONFIRM_GROUP_INFO: "一键发起拼场",
    EDIT_TIME: "确定"
};

Component({
    properties: {
        shopInfo: {
            type: Object,
            value: {}
        }
    },
    data: {
        statusClass: "",
        step: 0,
        title: f.SELECT_TIME,
        isTimeSelected: !1,
        confirmButtonText: p.SELECT_TIME,
        startTime: {
            timespan: null,
            timeText: "",
            selectedValues: []
        },
        policyAgree: !1,
        enablePublish: !1,
        groupFrom: {},
        token: "",
        fetchLocEnd: !1,
        cityId: "",
        lat: "",
        lng: "",
        loading: !1,
        keyboardHeight: 0,
        isFocus: !1
    },
    isGroupInfoExposed: !1,
    methods: {
        updatePublishStatus: function() {
            var t = this.data, e = t.policyAgree;
            if (0 !== t.step) {
                var a = this.data.groupFrom;
                this.setData({
                    enablePublish: e && a.groupTime && a.groupTime > Date.now() && a.groupHeadCount && a.invitation && a.invitation.length >= 5
                });
            }
        },
        onPolicyAgreeChange: function() {
            i.default.moduleClick("b_gc_y9qfudgg_mc", {
                discount_status: 0,
                select_status_change: this.data.policyAgree ? 0 : 1
            }), this.setData({
                policyAgree: !this.data.policyAgree
            }), this.updatePublishStatus();
        },
        onStartTimeTap: function() {
            this.setData({
                step: 0,
                isFocus: !1,
                title: f.EDIT_TIME,
                confirmButtonText: p.EDIT_TIME
            });
        },
        getTimeSelectResult: function() {
            var t = this.selectComponent("#time-select");
            console.log(t), this.setData({
                startTime: t.selectResult
            });
        },
        onTimeSelectConfirm: function() {
            this.getTimeSelectResult(), this.setData({
                step: 1,
                isTimeSelected: !0,
                title: f.CONFIRM_GROUP_INFO,
                confirmButtonText: p.CONFIRM_GROUP_INFO
            });
            var t = this.data, e = t.groupFrom, a = t.startTime;
            e.groupTime = a.timespan;
        },
        onGroupFormChange: function(t) {
            var e = t.detail, a = e.headcount, n = e.invitation, o = this.data.startTime;
            this.data.groupFrom = {
                groupTime: o.timespan,
                groupHeadCount: a,
                invitation: n
            }, this.updatePublishStatus();
        },
        getUUID: function() {
            return "wx" === n.default.platform ? i.default.get("lxcuid") : (c.getSystemInfoSync() || {}).uuid;
        },
        logDealStatus: function() {
            var t = {
                platform: n.default.platformCode,
                token: this.data.token,
                dealtype: 1
            };
            (0, s.recordLog)(t);
        },
        onRedirectToSecurityPage: function() {
            i.default.moduleClick("b_gc_2b0scckf_mc", {
                discount_status: 0
            }), c.navigateTo({
                url: "/pages/protocol/index"
            });
        },
        getDealStatus: function() {
            var t = this;
            o.default.mtDefaultLogin({
                isBind: !1
            }).then(function(e) {
                t.data.token = e.token || e.userInfo && e.userInfo.token || "";
                var a = {
                    platform: n.default.platformCode,
                    token: t.data.token,
                    dealtype: 1
                };
                return (0, s.searchDeal)(a).then(function(e) {
                    t.setData({
                        policyAgree: 0 !== e.showDealHook
                    });
                }).catch(function(t) {
                    console.log(t, "dealFail");
                });
            });
        },
        onGroupEditConfirm: function() {
            var t = this;
            return function() {
                var e, a, l;
                return u.async(function(f) {
                    for (;;) switch (f.prev = f.next) {
                      case 0:
                        if (i.default.moduleClick("b_gc_5n7pbhvv_mc", {}), t.getTimeSelectResult(), !t.data.loading) {
                            f.next = 4;
                            break;
                        }
                        return f.abrupt("return");

                      case 4:
                        if (!((e = t.data.groupFrom).groupTime <= Date.now())) {
                            f.next = 8;
                            break;
                        }
                        return (0, r.default)({
                            message: "拼场开始时间已过，请重新选择",
                            context: t
                        }), f.abrupt("return");

                      case 8:
                        if (!(e.invitation.length < 5)) {
                            f.next = 11;
                            break;
                        }
                        return (0, r.default)({
                            message: "拼场介绍至少要填写5个字哦",
                            context: t
                        }), f.abrupt("return");

                      case 11:
                        if (t.data.policyAgree) {
                            f.next = 14;
                            break;
                        }
                        return (0, r.default)({
                            message: "请勾选同意拼场须知",
                            context: t
                        }), f.abrupt("return");

                      case 14:
                        a = t.properties.shopInfo, l = {
                            platform: n.default.platformCode,
                            uacode: n.default.uaCode,
                            topictype: 2,
                            dpshopid: a.dpShopId,
                            mtshopid: a.mtShopId,
                            postbegintime: e.groupTime,
                            declaration: e.invitation,
                            headcount: e.groupHeadCount,
                            genderlimit: "男女不限",
                            wechatid: "",
                            token: ""
                        }, o.default.mtDefaultLogin({
                            isBind: !0
                        }).then(function(e) {
                            var a, n, o;
                            return u.async(function(i) {
                                for (;;) switch (i.prev = i.next) {
                                  case 0:
                                    if (!(a = e.token || e.userInfo && e.userInfo.token || "")) {
                                        i.next = 22;
                                        break;
                                    }
                                    return t.data.token = a, n = e.uuid, i.next = 6, u.awrap(d.finger());

                                  case 6:
                                    if (o = i.sent, n || (n = t.getUUID()), t.data.fetchLocEnd) {
                                        i.next = 16;
                                        break;
                                    }
                                    return i.next = 11, u.awrap(d.getCityInfo());

                                  case 11:
                                    if (i.t0 = i.sent, i.t0) {
                                        i.next = 14;
                                        break;
                                    }
                                    i.t0 = {};

                                  case 14:
                                    t.data.cityId = i.t0.id, console.log("request loc info in create api", t.data.cityId);

                                  case 16:
                                    l.token = a || l.token, l.uuid = n, l.fp = o, l.cityid = t.data.cityId, t.data.loading = !0, 
                                    (0, s.createPost)(l).then(function(e) {
                                        return u.async(function(n) {
                                            for (;;) switch (n.prev = n.next) {
                                              case 0:
                                                if (!e.errorMessage) {
                                                    n.next = 5;
                                                    break;
                                                }
                                                return c.showToast({
                                                    title: e.errorMessage,
                                                    icon: "none",
                                                    duration: 2e3
                                                }), t.data.loading = !1, e.code && [ 401, 500 ].includes(e.code) && getApp().addError(function(t, a) {
                                                    return {
                                                        category: t.AJAX_ERROR,
                                                        level: a.ERROR,
                                                        msg: "创建拼场接口请求失败",
                                                        custom: {
                                                            params: l,
                                                            errorMessage: e.errorMessage
                                                        }
                                                    };
                                                }), n.abrupt("return");

                                              case 5:
                                                e.msg ? (t.logDealStatus(a), t.onClose(), setTimeout(function() {
                                                    var a = e.msg.jumpUrl;
                                                    c.redirectTo({
                                                        url: a,
                                                        success: function() {
                                                            console.log("open share page: " + a);
                                                        },
                                                        fail: function(t) {
                                                            getApp().addError(function() {
                                                                return {
                                                                    msg: "发布成功后跳转分享引导页失败",
                                                                    custom: {
                                                                        error: t,
                                                                        url: a
                                                                    }
                                                                };
                                                            });
                                                        },
                                                        complete: function() {
                                                            t.data.loading = !1;
                                                        }
                                                    });
                                                }, 300)) : t.data.loading = !1;

                                              case 6:
                                              case "end":
                                                return n.stop();
                                            }
                                        }, null, null, null, Promise);
                                    }).catch(function(e) {
                                        t.data.loading = !1, getApp().addError(function() {
                                            return {
                                                msg: "发布拼场失败",
                                                custom: {
                                                    error: e.message,
                                                    params: l
                                                }
                                            };
                                        });
                                    });

                                  case 22:
                                  case "end":
                                    return i.stop();
                                }
                            }, null, null, null, Promise);
                        });

                      case 17:
                      case "end":
                        return f.stop();
                    }
                }, null, null, null, Promise);
            }();
        },
        onBack: function() {
            this.onStartTimeTap();
        },
        onClose: function() {
            var t = this;
            i.default.moduleClick("b_gc_d348bwwx_mc", {
                discount_status: 0
            }), (0, a.default)(function() {
                t.setData({
                    statusClass: "close"
                });
            }), setTimeout(function() {
                t.triggerEvent("close");
            }, 180);
        },
        onConfirm: function() {
            if (0 === this.data.step) return this.isGroupInfoExposed || (i.default.moduleView("b_gc_khdjw6ql_mv", {
                discount_status: 0
            }), this.isGroupInfoExposed = !0), this.onTimeSelectConfirm();
            this.onGroupEditConfirm();
        },
        onFocus: function(t) {
            this.setData({
                isFocus: !0,
                keyboardHeight: t.detail.height - l + "px"
            });
        },
        onBlur: function() {
            this.setData({
                isFocus: !1,
                keyboardHeight: 0
            });
        }
    },
    lifetimes: {
        attached: function() {
            var t = this;
            this.getDealStatus(), d.getCityInfo().then(function(e) {
                t.data.fetchLocEnd = !0, t.data.cityId = e.id, t.data.lat = e.lat, t.data.lng = e.lng;
            }), (0, a.default)(function() {
                t.setData({
                    statusClass: "open"
                });
            });
        }
    }
});