var t = function() {
    function t(t, e) {
        var r = [], n = !0, a = !1, i = void 0;
        try {
            for (var s, u = t[Symbol.iterator](); !(n = (s = u.next()).done) && (r.push(s.value), 
            !e || r.length !== e); n = !0) ;
        } catch (t) {
            a = !0, i = t;
        } finally {
            try {
                !n && u.return && u.return();
            } finally {
                if (a) throw i;
            }
        }
        return r;
    }
    return function(e, r) {
        if (Array.isArray(e)) return e;
        if (Symbol.iterator in Object(e)) return t(e, r);
        throw new TypeError("Invalid attempt to destructure non-iterable instance");
    };
}(), e = require("../../../../utils/date"), r = function(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}(require("../../../../common/lx")), n = (0, e.getDateList)(), a = n.dates, i = n.hours, s = n.mins;

Component({
    properties: {
        value: {
            optionalTypes: [ null, Number ],
            type: null
        }
    },
    data: {
        dates: a,
        currentDayRestHours: i,
        currentHourRestMins: s,
        curHours: i,
        curMins: s,
        initValue: [ 0, 0, 0 ],
        values: [ 0, 0, 0 ]
    },
    selectResult: {},
    methods: {
        onChange: function(t) {
            var e = this, r = this.data, n = r.values, a = r.currentDayRestHours, u = r.currentHourRestMins, o = t.detail.value, l = {}, c = !1;
            n[0] === o[0] || 0 !== o[0] && 0 !== n[0] || (0 === o[0] ? (c = !0, l.curHours = a, 
            o[1] = n[1] - i.length + a.length, o[1] < 0 && (o[1] = 0), this.setData({
                initValue: o
            })) : 0 === n[0] && (l.curHours = i, o[1] = n[1] - a.length + i.length)), n[0] === o[0] && n[1] === o[1] || (0 === o[0] && 0 === o[1] ? (c = !0, 
            l.curMins = u, o[2] = n[2] - s.length + u.length, o[2] < 0 && (o[2] = 0), this.setData({
                initValue: o
            })) : 0 === n[0] && 0 === n[1] && (l.curMins = s, o[2] = n[2] - u.length + s.length)), 
            c || setTimeout(function() {
                e.setData({
                    initValue: o
                });
            }, 50), l.values = o, this.setData(l), this.onConfirm();
        },
        onConfirm: function() {
            var e = this.data.values || this.properties.value, r = this.data, n = r.curHours, i = r.curMins, s = t(e, 3), u = s[0], o = s[1], l = s[2], c = a[u].dateTimespanStr + " " + n[o].hourTimespanStr + ":" + i[l].minTimespanStr + ":00", h = new Date(c).getTime(), d = a[u].dateStr + " " + n[o].hourStr + ":" + i[l].minStr;
            this.selectResult = {
                timespan: h,
                timeText: d,
                selectedValues: e
            };
        }
    },
    lifetimes: {
        attached: function() {
            var t = this.properties.value, n = void 0 === t || null === t, u = new Date(n ? Date.now() : t), o = u.getFullYear(), l = u.getMonth() + 1, c = u.getDate(), h = u.getHours(), d = u.getMinutes();
            console.log(o, l, c, h, d);
            var f = function() {
                (0, e.isLastDayOfMonth)(t) ? (c = 1, l >= 12 ? (l = 1, o++) : l++) : c++;
            }, m = function() {
                h >= 23 ? (h = 0, f()) : h++;
            };
            n && function() {
                var t = d + 15;
                60 == (d = t % 15 >= 8 ? 15 * (Math.floor(t % 60 / 15) + 1) : 15 * Math.floor(t % 60 / 15)) && (d = 0, 
                m()), t >= 60 && m();
            }(), this.data.currentDayRestHours = i.slice(i.findIndex(function(t) {
                return t.hourStr === h.toString().padStart(2, "0");
            })), this.data.currentHourRestMins = s.slice(s.findIndex(function(t) {
                return t.minStr === d.toString().padStart(2, "0");
            })), this.setData({
                curHours: this.data.currentDayRestHours,
                curMins: this.data.currentHourRestMins
            });
            for (var g = o + "/" + l.toString().padStart(2, "0") + "/" + c.toString().padStart(2, "0"), p = ("" + h).padStart(2, "0"), v = ("" + d).padStart(2, "0"), S = [], M = 0; M < a.length; M++) g === a[M].dateTimespanStr && (S[0] = M);
            for (var y = 0; y < this.data.curHours.length; y++) p === this.data.curHours[y].hourTimespanStr && (S[1] = y);
            for (var D = 0; D < this.data.curMins.length; D++) v === this.data.curMins[D].minTimespanStr && (S[2] = D);
            console.log(g, p, v), this.setData({
                values: S,
                initValue: S
            }), this.onConfirm(), r.default.moduleView("b_gc_1l2c18uu_mv", {});
        }
    }
});