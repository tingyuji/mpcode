function t(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

t(require("../../../../utils/toast"));

var i = t(require("../../../../common/lx"));

Component({
    properties: {
        timeText: String
    },
    data: {
        headcount: 2,
        invitation: "",
        invitationLength: 0
    },
    methods: {
        onStartTimeTap: function() {
            this.triggerEvent("startTimeTap");
        },
        emitForm: function() {
            this.triggerEvent("groupFormChange", {
                headcount: this.data.headcount,
                invitation: this.data.invitation
            });
        },
        onHeadeCountChange: function(t) {
            this.setData({
                headcount: t.detail
            }), this.emitForm();
        },
        onInput: function(t) {
            var i = t.detail.value.slice(0, 100);
            this.setData({
                invitation: i,
                invitationLength: i.length
            }), this.emitForm();
        },
        onFocus: function(t) {
            this.triggerEvent("focus", {
                height: t.detail.height
            });
        },
        onBlur: function() {
            this.triggerEvent("blur");
        },
        onInvitationTap: function() {
            i.default.moduleClick("b_gc_dcqivga1_mc", {
                discount_status: 0
            });
        },
        setForm: function(t) {
            var i = t.headcount, n = t.invitation;
            this.setData({
                headcount: i,
                invitation: n
            });
        }
    },
    lifetimes: {
        ready: function() {
            this.emitForm();
        }
    }
});