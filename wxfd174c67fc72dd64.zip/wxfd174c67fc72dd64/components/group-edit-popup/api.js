function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.createPost = function(e) {
    return r.default.request({
        url: o.CREATE,
        data: e,
        method: "POST"
    }).then(function(e) {
        var r = e.data;
        if (r) return r;
        throw Error("发布拼场失败");
    }).catch(function() {
        return getApp().addError(function(r, t) {
            return {
                category: r.AJAX_ERROR,
                level: t.ERROR,
                msg: "创建拼场接口请求失败",
                custom: {
                    url: o.CREATE,
                    params: e
                }
            };
        }), null;
    });
}, exports.recordLog = function(e) {
    return r.default.request({
        url: o.LOG_DEAL,
        data: e
    }).then(function(e) {
        var r = e.data;
        if (r && 200 === r.code && r.msg) return r.msg;
        throw Error("拼场协议状态上报失败");
    }).catch(function(e) {
        console.log(e);
    });
}, exports.searchDeal = function(e) {
    return r.default.request({
        url: o.SEARCHE_DEAL,
        data: e
    }).then(function(e) {
        var r = e.data;
        if (r && 200 === r.code && r.msg) return r.msg;
        throw Error("拼场协议状态获取失败");
    }).catch(function(e) {
        console.log(e);
    });
};

var r = e(require("../../npm/@dzfe/wx-api-promisify/dist/index.js")), t = e(require("../../common/config")), o = {
    CREATE: t.default.gpower_domain + "/api/gpower/post/create",
    LOG_DEAL: t.default.dp_domain + "/api/joy/sharerelation/post/deal/log",
    SEARCHE_DEAL: t.default.dp_domain + "/api/joy/sharerelation/post/deal/show"
};

exports.default = {};