var t = function(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}(require("../../../common/lx"));

Component({
    properties: {
        show: Boolean,
        dialogInfo: {
            type: Object,
            value: {},
            observer: "init"
        }
    },
    data: {
        hasLogin: !1,
        avatar: "",
        invitation: "",
        couponAmount: null,
        couponName: "",
        abInfo: ""
    },
    methods: {
        getLxParams: function() {
            var t = this.data, o = t.hasLogin, a = t.abInfo, e = [];
            try {
                a && e.push(JSON.parse(a));
            } catch (t) {
                console.log(t);
            }
            return {
                status: o ? 1 : 0,
                abtest: e
            };
        },
        init: function(o) {
            if (o) {
                var a = o.hasLogin, e = o.couponAmount, n = o.couponName, i = o.majorUser, s = {
                    hasLogin: a,
                    couponAmount: e,
                    couponName: n,
                    abInfo: o.abInfo
                };
                if (i) {
                    var r = i.avatar, u = i.nickname;
                    s.avatar = r, s.invitation = (u.length > 7 ? u.slice(0, 7) + "..." : u) + "邀请你助力";
                }
                this.setData(s), this.properties.show && t.default.moduleView("b_gc_ga3875nx_mv", this.getLxParams());
            }
        },
        onClose: function() {
            t.default.moduleClick("b_gc_08bs7z9o_mc", this.getLxParams()), this.triggerEvent("close");
        },
        onHelp: function() {
            t.default.moduleClick("b_gc_mjphmfxn_mc", this.getLxParams()), this.triggerEvent("help");
        }
    },
    lifetimes: {
        attached: function() {}
    }
});