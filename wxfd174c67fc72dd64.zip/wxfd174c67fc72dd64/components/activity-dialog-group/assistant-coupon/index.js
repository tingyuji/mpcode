function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

var t = e(require("../../../common/login")), n = (e(require("../../../common/config")), 
e(require("../../../common/lx"))), r = e(require("../../../utils/index")), o = e(require("../../../utils/toast")), i = function(e) {
    if (e && e.__esModule) return e;
    var t = {};
    if (null != e) for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
    return t.default = e, t;
}(require("./api")), u = require("../../../npm/regenerator-runtime/runtime.js"), a = r.default.isShareCardScene, s = getApp();

Component({
    properties: {},
    data: {
        show: !1,
        title: "",
        coupons: [],
        dialogHeight: 634,
        token: "",
        unionid: "",
        shopid: ""
    },
    methods: {
        getPageOptions: function() {
            var e = getCurrentPages().pop();
            return e && e.options;
        },
        isForceLogin: function() {
            return a(s && s.globalData && s.globalData.sceneValue);
        },
        forceLogin: function() {
            var e = this;
            return t.default.mtDefaultLogin({
                isBind: !0
            }).then(function(t) {
                e.data.token = t.token || t.userInfo && t.userInfo.token || "";
            });
        },
        init: function() {
            var e = this;
            return function() {
                var t, r, a, s, c, l, f, p, g, d, h;
                return u.async(function(m) {
                    for (;;) switch (m.prev = m.next) {
                      case 0:
                        if (t = e.getPageOptions(), r = t.wxunionid, (a = t.shopid) && r) {
                            m.next = 3;
                            break;
                        }
                        return m.abrupt("return");

                      case 3:
                        if (!e.isForceLogin()) {
                            m.next = 6;
                            break;
                        }
                        return m.next = 6, u.awrap(e.forceLogin());

                      case 6:
                        if (s = e.data.token) {
                            m.next = 9;
                            break;
                        }
                        return m.abrupt("return");

                      case 9:
                        return c = {
                            shopid: a,
                            wxunionid: r
                        }, m.next = 12, u.awrap(i.getCoupons(c));

                      case 12:
                        if (l = m.sent, f = l.msg, !(p = l.errorMessage)) {
                            m.next = 17;
                            break;
                        }
                        return (0, o.default)({
                            message: p
                        }), m.abrupt("return");

                      case 17:
                        f && f.title && f.coupons && f.coupons.length && (g = {}, d = f.title, h = f.coupons, 
                        g.show = !0, g.title = d, g.coupons = h, g.dialogHeight = 338 + 148 * (h.length <= 2 ? h.length : 2.5), 
                        n.default.moduleView("b_gc_02ku3f3x_mv", {
                            question_type: -9999,
                            status: -9999,
                            type: 2,
                            abtest: ""
                        }), e.setData(g));

                      case 18:
                      case "end":
                        return m.stop();
                    }
                }, null, null, null, Promise);
            }();
        },
        onUse: function() {
            this.setData({
                show: !1
            });
        }
    },
    lifetimes: {
        ready: function() {
            this.init();
        }
    }
});