function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getCoupons = function(e) {
    return o.default.request({
        url: r.GET_COUPONS,
        data: e
    }).then(function(e) {
        if (e && e.data && 200 === e.data.code) return e.data;
        throw Error();
    }).catch(function(e) {
        console.error(e.message || "领取红包失败");
    });
};

var o = e(require("../../../npm/@dzfe/wx-api-promisify/dist/index.js")), r = {
    GET_COUPONS: e(require("../../../common/config")).default.gpower_domain + "/api/gpower/social/group/promocode/coupon"
};

exports.default = {};