function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

var t = e(require("../../../common/lx")), i = e(require("../../../npm/@dzfe/wx-api-promisify/dist/index.js")), n = require("../../../npm/regenerator-runtime/runtime.js");

Component({
    properties: {
        show: Boolean,
        dialogInfo: {
            type: Object,
            value: {},
            observer: "init"
        }
    },
    data: {
        avatar: "",
        invitation: "",
        title: "",
        subTitle: "",
        buttonMark: "",
        coupons: [],
        dialogHeight: 818,
        abInfo: "",
        isHomePage: !1
    },
    methods: {
        subscribe: function() {
            return function() {
                var e;
                return n.async(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return t.prev = 0, e = [ "hib_kaukcczlLke0uiAiPuHsO_Lj0EO_DiK0RpytMgk" ], t.next = 4, 
                        n.awrap(i.default.requestSubscribeMessage({
                            tmplIds: e
                        }));

                      case 4:
                        t.next = 9;
                        break;

                      case 6:
                        t.prev = 6, t.t0 = t.catch(0), console.warn(t.t0);

                      case 9:
                      case "end":
                        return t.stop();
                    }
                }, null, null, [ [ 0, 6 ] ], Promise);
            }();
        },
        onClose: function() {
            this.triggerEvent("close");
        },
        onUse: function() {
            t.default.moduleClick("b_gc_4hx3sgmb_mc", this.getLxParams()), this.onClose(), this.subscribe();
        },
        onHelp: function() {
            t.default.moduleClick("b_gc_dh1g20u5_mc", this.getLxParams()), this.triggerEvent("help");
        },
        getLxParams: function() {
            var e = this.data, t = e.subTitle, i = e.coupons, n = e.abInfo, s = -9999;
            i.length && (s = "恭喜你获得助力奖励，赶快使用避免过期哦" === t ? 0 : 1);
            var a = [];
            try {
                n && a.push(JSON.parse(n));
            } catch (e) {
                console.log(e);
            }
            return {
                question_type: -9999,
                status: s,
                type: 1,
                abtest: a
            };
        },
        init: function(e) {
            if (e) {
                var i = e.majorUser, n = e.coupons, s = void 0 === n ? [] : n, a = e.title, o = e.subTitle, r = e.success, u = e.buttonMark, c = {
                    abInfo: e.abInfo || ""
                };
                if (i) {
                    var l = i.avatar, g = i.nickname;
                    c.avatar = l, c.nickname = g, c.invitation = (g.length > 7 ? g.slice(0, 7) + "..." : g) + "邀请你助力";
                }
                c.coupons = s, r && s && s.length ? c.dialogHeight = 522 + 148 * (s.length <= 2 ? s.length : 2.5) : c.dialogHeight = 551, 
                a && (c.title = a), o && (c.subTitle = o), u && (c.buttonMark = u), this.setData(c), 
                this.properties.show && t.default.moduleView("b_gc_02ku3f3x_mv", this.getLxParams());
            }
        }
    },
    lifetimes: {
        ready: function() {
            var e = getCurrentPages().pop(), t = e && e.route.includes("pages/home/index");
            this.setData({
                isHomePage: t
            });
        }
    }
});