var e = function(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}(require("../../../common/lx")), t = {
    1: 368,
    2: 368,
    3: 336,
    4: 336
};

Component({
    properties: {
        show: Boolean,
        dialogInfo: {
            type: Object,
            value: {},
            observer: "init"
        }
    },
    data: {
        title: "",
        subTitle: "",
        avatar: "",
        nickname: "",
        dialogHeight: 368,
        failType: null,
        buttonMark: "",
        abInfo: "",
        showClose: !0,
        isHomePage: !1
    },
    methods: {
        onClose: function() {
            this.triggerEvent("close");
        },
        onHelp: function() {
            e.default.moduleClick("b_gc_dh1g20u5_mc", this.getLxParams()), this.triggerEvent("help");
        },
        onFindGroup: function() {
            e.default.moduleClick("b_gc_4hx3sgmb_mc", this.getLxParams()), this.onClose();
        },
        getLxParams: function() {
            var e = this.data, t = e.failType, a = e.abInfo, i = [];
            try {
                a && i.push(JSON.parse(a));
            } catch (e) {
                console.log(e);
            }
            return {
                question_type: t,
                status: 0,
                type: 0,
                abtest: i
            };
        },
        init: function(a) {
            if (a) {
                var i = a.majorUser, o = a.failType, n = a.title, s = a.subTitle, l = a.buttonMark, r = {
                    abInfo: a.abInfo || ""
                };
                if (i) {
                    var u = i.avatar, c = i.nickname;
                    r.avatar = u, r.nickname = c, r.invitation = (c.length > 7 ? c.slice(0, 7) + "..." : c) + "邀请你助力";
                }
                l && (r.buttonMark = l), n && (r.title = n), s && (r.subTitle = s), void 0 !== o && (r.failType = o, 
                r.showClose = !(3 === o || 4 === o), r.dialogHeight = t[o]), this.setData(r), this.properties.show && e.default.moduleView("b_gc_02ku3f3x_mv", this.getLxParams());
            }
        }
    },
    lifetimes: {
        ready: function() {
            var e = getCurrentPages().pop(), t = e && e.route.includes("pages/home/index");
            this.setData({
                isHomePage: t
            });
        }
    }
});