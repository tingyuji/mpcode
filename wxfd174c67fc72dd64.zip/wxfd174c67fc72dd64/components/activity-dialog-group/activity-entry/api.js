function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getHelpPopup = function(e) {
    return t.default.request({
        url: o.POPUP,
        data: e
    }).then(function(e) {
        if (e && e.data && 200 === e.data.code) return e.data;
        throw Error();
    }).catch(function(e) {
        console.error(e.message || "助力弹窗请求失败");
    });
}, exports.getHelpAssist = function(e) {
    return t.default.request({
        method: "POST",
        url: o.ASSIST,
        data: e
    }).then(function(e) {
        if (e && e.data && 200 === e.data.code) return e.data;
        throw Error();
    }).catch(function(e) {
        console.error(e.message || "助力结果弹窗请求失败");
    });
};

var t = e(require("../../../npm/@dzfe/wx-api-promisify/dist/index.js")), r = e(require("../../../common/config")), o = {
    POPUP: r.default.gpower_domain + "/api/gpower/helpactivity/popup",
    ASSIST: r.default.gpower_domain + "/api/gpower/helpactivity/assist"
};

exports.default = {};