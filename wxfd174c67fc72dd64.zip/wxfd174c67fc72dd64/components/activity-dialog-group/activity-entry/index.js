function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function t(e, t, n) {
    return t in e ? Object.defineProperty(e, t, {
        value: n,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = n, e;
}

function n(e, t) {
    var n = Object.keys(e);
    if (Object.getOwnPropertySymbols) {
        var r = Object.getOwnPropertySymbols(e);
        t && (r = r.filter(function(t) {
            return Object.getOwnPropertyDescriptor(e, t).enumerable;
        })), n.push.apply(n, r);
    }
    return n;
}

function r(e) {
    for (var t = 1; t < arguments.length; t++) {
        var r = null != arguments[t] ? arguments[t] : {};
        t % 2 ? n(Object(r), !0).forEach(function(t) {
            a(e, t, r[t]);
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : n(Object(r)).forEach(function(t) {
            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t));
        });
    }
    return e;
}

function a(e, t, n) {
    return t in e ? Object.defineProperty(e, t, {
        value: n,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = n, e;
}

var o = e(require("../../../common/login")), i = e(require("../../../common/config")), u = e(require("../../../common/lx")), s = (e(require("../../../utils/index")), 
e(require("../../../utils/toast"))), l = (e(require("../../../npm/@dzfe/wx-api-promisify/dist/index.js")), 
function(e) {
    if (e && e.__esModule) return e;
    var t = {};
    if (null != e) for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
    return t.default = e, t;
}(require("./api"))), p = require("../../../npm/regenerator-runtime/runtime.js"), c = require("../../../npm/@mtfe/weapp-privacy-api/index.js").default, f = getApp();

Component({
    properties: {},
    data: {
        token: "",
        cityid: 10,
        fp: "",
        uuid: "",
        openId: "",
        expoId: "",
        uaCode: i.default.uaCode,
        helpCode: f.globalData.helpCode || "",
        popupDialog: {
            show: !1,
            couponName: "",
            couponAmount: "",
            abInfo: "",
            majorUser: {
                userMaskId: "",
                avatar: "",
                nickname: ""
            }
        },
        assistDialog: {
            show: !1,
            success: null,
            title: "",
            subTitle: "",
            failType: null,
            buttonMark: "",
            coupons: [],
            majorUser: {
                userMaskId: "",
                avatar: "",
                nickname: ""
            },
            abInfo: ""
        },
        enableHelp: !0
    },
    methods: {
        getUUID: function() {
            return "wx" === i.default.platform ? u.default.get("lxcuid") : (c.getSystemInfoSync() || {}).uuid;
        },
        getUserInfo: function() {
            var e = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0], t = this;
            return function() {
                var n, r, a;
                return p.async(function(i) {
                    for (;;) switch (i.prev = i.next) {
                      case 0:
                        return i.prev = 0, i.next = 3, p.awrap(o.default.mtDefaultLogin({
                            isBind: e,
                            bind: !1
                        }));

                      case 3:
                        if (n = i.sent, !(r = n.token || n.userInfo && n.userInfo.token || "")) {
                            i.next = 15;
                            break;
                        }
                        return t.data.token = r, t.data.openId = n.openId, t.data.expoId = n.openIdCipher, 
                        i.next = 11, p.awrap(f.finger());

                      case 11:
                        t.data.fp = i.sent, (a = n.uuid) || (a = t.getUUID()), t.data.uuid = a;

                      case 15:
                        i.next = 20;
                        break;

                      case 17:
                        i.prev = 17, i.t0 = i.catch(0), console.log(i.t0);

                      case 20:
                      case "end":
                        return i.stop();
                    }
                }, null, null, [ [ 0, 17 ] ], Promise);
            }();
        },
        getUserCityId: function() {
            var e = this;
            return p.async(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.abrupt("return", f.getCityInfo().then(function(t) {
                        t && t.id && (e.data.cityid = t.id);
                    }));

                  case 1:
                  case "end":
                    return t.stop();
                }
            }, null, null, null, Promise);
        },
        getHelpPopup: function() {
            var e = this;
            return function() {
                var n, r, a, o, i, u, c, f, d, g, m, b;
                return p.async(function(h) {
                    for (;;) switch (h.prev = h.next) {
                      case 0:
                        return h.next = 2, p.awrap(e.getUserInfo(!1));

                      case 2:
                        return n = e.data, r = n.cityid, a = n.token, o = n.helpCode, i = {
                            token: a,
                            cityid: r,
                            helpcode: o
                        }, h.next = 6, p.awrap(l.getHelpPopup(i));

                      case 6:
                        if (!(u = h.sent) || !u.errorMessage) {
                            h.next = 10;
                            break;
                        }
                        return (0, s.default)({
                            message: u.errorMessage
                        }), h.abrupt("return");

                      case 10:
                        if (u && u.msg && u.msg.majorUser) {
                            var v;
                            c = u.msg, f = c.majorUser, d = c.couponAmount, g = c.couponName, m = c.abInfo, 
                            t(v = {}, "popupDialog.show", !0), t(v, "popupDialog.majorUser", f), t(v, "popupDialog.abInfo", m || ""), 
                            t(v, "assistDialog.majorUser", f), (b = v)["popupDialog.hasLogin"] = !!a, d && (b["popupDialog.couponAmount"] = d), 
                            g && (b["popupDialog.couponName"] = g), e.setData(b);
                        }

                      case 11:
                      case "end":
                        return h.stop();
                    }
                }, null, null, null, Promise);
            }();
        },
        getHelpResult: function() {
            var e = this;
            return function() {
                var t, n, a, o, i, u, c, f, d, g, m, b;
                return p.async(function(h) {
                    for (;;) switch (h.prev = h.next) {
                      case 0:
                        return h.next = 2, p.awrap(e.getUserInfo());

                      case 2:
                        if (t = e.data.helpCode, n = e.data, a = n.cityid, o = n.token, i = n.assistDialog, 
                        u = n.uuid, c = n.openId, f = n.expoId, d = n.uaCode, g = n.fp, o && t && e.data.enableHelp) {
                            h.next = 6;
                            break;
                        }
                        return h.abrupt("return");

                      case 6:
                        return m = {
                            token: o,
                            helpCode: t,
                            cityId: a,
                            uuid: u,
                            fp: g,
                            openId: c,
                            expoId: f,
                            uaCode: d
                        }, e.data.enableHelp = !1, h.next = 10, p.awrap(l.getHelpAssist(m));

                      case 10:
                        if (!(b = h.sent) || !b.errorMessage) {
                            h.next = 15;
                            break;
                        }
                        return e.data.enableHelp = !0, (0, s.default)({
                            message: b.errorMessage
                        }), h.abrupt("return");

                      case 15:
                        b && b.msg && 5 !== b.msg.failType && 2 !== b.msg.failType ? e.setData({
                            assistDialog: r({}, i, {}, b.msg, {
                                show: !0
                            })
                        }) : e.data.enableHelp = !0;

                      case 16:
                      case "end":
                        return h.stop();
                    }
                }, null, null, null, Promise);
            }();
        },
        init: function() {
            this.getHelpResult();
        },
        onInviteDialogClose: function() {
            this.setData(t({}, "popupDialog.show", !1));
        },
        onInviteDialogHelp: function() {
            var e = this;
            return p.async(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (e.data.token) {
                        t.next = 3;
                        break;
                    }
                    return t.next = 3, p.awrap(e.getUserInfo());

                  case 3:
                    if (e.data.token) {
                        t.next = 5;
                        break;
                    }
                    return t.abrupt("return");

                  case 5:
                    return e.onInviteDialogClose(), t.next = 8, p.awrap(e.getHelpResult());

                  case 8:
                  case "end":
                    return t.stop();
                }
            }, null, null, null, Promise);
        },
        onHelpDialogClose: function() {
            this.setData(t({}, "assistDialog.show", !1));
        },
        onHelpDialogHelp: function() {
            var e = getCurrentPages().pop();
            e && e.route.includes("pages/home/index") && c.navigateTo({
                url: "/pages/activity/share/index"
            }), this.onHelpDialogClose();
        }
    },
    lifetimes: {
        attached: function() {
            var e = this;
            return function() {
                var t, n, r;
                return p.async(function(a) {
                    for (;;) switch (a.prev = a.next) {
                      case 0:
                        if (t = f.globalData, n = t.helpCode, r = t.isShowShareDialog, e.setData({
                            helpCode: n
                        }), n && !r) {
                            a.next = 4;
                            break;
                        }
                        return a.abrupt("return");

                      case 4:
                        return a.next = 6, p.awrap(e.getUserCityId());

                      case 6:
                        e.init(), f.globalData.isShowShareDialog = !0;

                      case 8:
                      case "end":
                        return a.stop();
                    }
                }, null, null, null, Promise);
            }();
        }
    }
});