!function(e) {
    e && e.__esModule;
}(require("../../common/lx"));

Component({
    externalClasses: [ "item-class", "item-selected-class" ],
    properties: {
        timeFilters: {
            type: Array,
            value: []
        },
        dateIndex: {
            type: Number,
            value: 0
        },
        multiSelect: {
            type: Boolean,
            value: !1
        },
        clickBid: {
            type: String,
            value: ""
        },
        viewBid: {
            type: String,
            value: ""
        }
    },
    data: {
        curIndex: 0,
        selectedIndexList: []
    },
    methods: {
        clickTimeFilter: function(e) {
            var t = this, i = e.currentTarget.dataset, s = this.properties.multiSelect, n = i.index, r = this.data.selectedIndexList || [], l = r.findIndex(function(e) {
                return e === n;
            });
            l >= 0 ? r.splice(l, 1) : r.push(n), this.setData({
                selectedIndexList: s ? r : [ n ]
            }), this.triggerEvent("clickTimeFilter", s ? r.map(function(e) {
                return t.properties.timeFilters[e];
            }) : i);
        }
    },
    observers: {
        dateIndex: function(e) {
            e > 0 && this.setData({
                selectedIndexList: [ e ]
            });
        }
    },
    lifetimes: {
        attached: function() {}
    }
});