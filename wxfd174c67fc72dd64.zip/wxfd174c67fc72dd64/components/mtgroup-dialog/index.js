function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function t(e, t, n) {
    return t in e ? Object.defineProperty(e, t, {
        value: n,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = n, e;
}

var n = e(require("../../common/behaviors/transition")), o = e(require("../../utils/index")).default.nextTick;

Component({
    externalClasses: [ "mask", "dialog", "title-class", "message-class", "confirm-button-class", "cancel-button-class" ],
    options: {
        multipleSlots: !0,
        addGlobalClass: !0
    },
    behaviors: [ n.default ],
    properties: {
        title: String,
        width: null,
        useSlot: {
            type: Boolean,
            value: !1
        },
        message: String,
        zIndex: {
            type: Number,
            value: 999999
        },
        overlay: Boolean,
        selector: {
            type: String,
            value: "#mtgroup-dialog"
        },
        beforeClose: {
            type: Function,
            value: function() {}
        },
        transition: {
            type: String,
            value: "scale"
        },
        customStyle: String,
        messageAlign: {
            type: String,
            value: "center"
        },
        overlayStyle: String,
        showTitle: {
            type: Boolean,
            value: !1
        },
        duration: {
            type: Number,
            value: 300
        },
        confirmButtonText: {
            type: String,
            value: "确认"
        },
        cancelButtonText: {
            type: String,
            value: "取消"
        },
        showConfirmButton: {
            type: Boolean,
            value: !0
        },
        showCancelButton: {
            type: Boolean,
            value: !1
        },
        closeOnClickOverlay: {
            type: Boolean,
            value: !1
        },
        confirmButtonColor: {
            type: String,
            value: ""
        },
        cancelButtonColor: {
            type: String,
            value: ""
        },
        confirmButtonOpenType: {
            type: String,
            value: ""
        },
        showCloseIcon: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        loading: {
            confirm: !1,
            cancel: !1
        },
        callback: function() {}
    },
    ready: function() {},
    methods: {
        onConfirm: function() {
            this.data.loading.confirm || this.handleAction("confirm");
        },
        onCancel: function() {
            this.data.loading.cancel || this.handleAction("cancel");
        },
        onClickOverlay: function() {
            this.closeOnClickOverlay && this.close("overlay");
        },
        close: function(e) {
            var t = this;
            this.setData({
                show: !1
            }), o(function() {
                var n = t.data.callback;
                n && n(e, t);
            });
        },
        stopLoading: function() {
            this.setData({
                loading: {
                    confirm: !1,
                    cancel: !1
                }
            });
        },
        handleAction: function(e) {
            var n = this, o = this.data.callback;
            o && o(e, this);
            var a = this.data, l = a.asyncClose, i = a.beforeClose;
            l || i ? (this.setData(t({}, "loading." + e, !0)), i && Promise.resolve(i(e)).then(function(t) {
                t ? n.close(e) : n.stopLoading();
            })) : this.close(e);
        },
        onCloseTap: function() {
            this.close();
        },
        stopEvent: function() {}
    }
});