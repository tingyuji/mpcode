var t = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
    return typeof t;
} : function(t) {
    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
};

Component({
    properties: {
        title: {
            type: String,
            value: "请选择"
        },
        theme: {
            type: String,
            value: "dark"
        },
        show: {
            type: Boolean,
            value: !1
        },
        list: {
            type: Array,
            value: [],
            observer: "init"
        },
        valueKey: {
            type: String
        },
        labelKey: {
            type: String
        },
        initValue: {
            type: String,
            observer: "init"
        },
        confirmText: {
            type: String,
            value: "确定"
        }
    },
    data: {
        overlayStyle: "background-color: rgba(0, 0, 0, 0.7)",
        customStyle: "height: 50%",
        value: [ 0 ]
    },
    lifetimes: {
        attached: function() {
            this.init();
        }
    },
    methods: {
        init: function() {
            var e = this.properties, i = e.initValue, n = e.list, o = e.valueKey, r = -1;
            r = "object" === (void 0 === i ? "undefined" : t(i)) ? n.findIndex(function(t) {
                return t[o] === i[o];
            }) : n.indexOf(i), this.setData({
                value: [ -1 === r ? 0 : r ]
            });
        },
        onChange: function(t) {
            var e = t.detail.value;
            this.setData({
                value: e
            });
        },
        onConfirm: function() {
            this.triggerEvent("onConfirm", {
                value: this.properties.list[this.data.value[0]]
            });
        },
        onClose: function() {
            this.triggerEvent("onClose");
        }
    }
});