var e = function(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}(require("../../common/lx"));

Component({
    externalClasses: [ "lx-class" ],
    properties: {
        lxViewBid: {
            type: String,
            value: ""
        },
        lxClickBid: {
            type: String,
            value: ""
        },
        lxExtend: {
            type: String,
            optionalTypes: [ Object ],
            value: "{}"
        },
        isObserver: {
            type: Boolean,
            value: !0
        },
        options: {
            type: Object,
            value: {}
        }
    },
    lifetimes: {
        ready: function() {
            this.data.lxViewBid && this.moduleView();
        }
    },
    methods: {
        moduleView: function() {
            var t = this, i = this.data, l = i.lxClickBid, o = i.lxViewBid, s = i.options;
            if (1 !== this.viewCount && o) if (this.setLxModule(), this.data.isObserver) {
                var n = this.createIntersectionObserver(this);
                n.relativeToViewport().observe("#lx-" + (l || o), function(i) {
                    i.intersectionRatio > 0 ? (t.viewCount = 1, e.default.moduleView(o, t._lxExtend, s), 
                    n.disconnect()) : console.log("组件");
                });
            } else e.default.moduleView(o, this._lxExtend, s);
        },
        setLxModule: function() {
            if (!this._lxExtend) try {
                var e = this.data.lxExtend;
                if ("[object Object]" === Object.prototype.toString.call(e)) this._lxExtend = e; else if (-1 === e.indexOf("{")) {
                    var t = e.split("&"), i = {};
                    t && t.length && t.forEach(function(e) {
                        var t = e.split("=");
                        i[t[0]] = t[1];
                    }), this._lxExtend = i;
                } else e = e.replace(/'/g, '"'), e = JSON.parse(e), this._lxExtend = e;
            } catch (e) {
                console.log("lx-module:", e);
            }
        },
        moduleClick: function() {
            var t = this.data, i = t.lxClickBid, l = t.options;
            i && (this.setLxModule(), e.default.moduleClick(i, this._lxExtend, l), this.triggerEvent("click"));
        }
    }
});