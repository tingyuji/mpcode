function t(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

var e = t(require("../../utils/index")), a = t(require("../../common/lx")), i = t(require("../../api/index")), n = t(require("../../common/login")), o = require("../../npm/regenerator-runtime/runtime.js"), r = require("../../npm/@mtfe/weapp-privacy-api/index.js").default, u = getApp();

Component({
    properties: {
        postMaskId: {
            type: String,
            value: ""
        },
        shopId: {
            type: [ Number, String ],
            value: ""
        }
    },
    data: {
        iconData: null,
        openId: ""
    },
    lifetimes: {
        ready: function() {
            this.initData(), a.default.moduleView("b_gc_46zi4fji_mv");
        }
    },
    methods: {
        initData: function() {
            var t = this;
            return o.async(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.next = 2, o.awrap(t.getOpenId());

                  case 2:
                    t.getGuide();

                  case 3:
                  case "end":
                    return e.stop();
                }
            }, null, null, null, Promise);
        },
        getOpenId: function() {
            var t = this;
            return u.globalData.userInfo ? (this.data.openId = u.globalData.userInfo.openId, 
            "") : n.default.getWxIds().then(function(e) {
                t.data.openId = e.openId;
            });
        },
        getGuide: function() {
            var t = this, e = {
                openid: this.data.openId,
                postmaskid: this.properties.postMaskId || "",
                shopid: this.properties.shopId || ""
            };
            i.default.getGuideInfo(e).then(function(e) {
                t.setData({
                    iconData: e
                });
            }).catch(function(t) {
                console.log(t, "getGuideInfo");
            });
        },
        viewMoreGroup: function() {
            a.default.moduleClick("b_gc_46zi4fji_mc"), this.data.iconData && e.default.tabbarPage(this.data.iconData.jumpUrl) ? (u.globalData.homeParams = this.data.iconData.homeParams, 
            r.switchTab({
                url: this.data.iconData.jumpUrl
            })) : r.navigateTo({
                url: this.data.iconData && this.data.iconData.jumpUrl
            });
        }
    }
});