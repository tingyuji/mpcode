var e = function(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}(require("../../common/lx"));

Component({
    externalClasses: [ "custom-class" ],
    properties: {
        zIndex: {
            type: Number,
            value: 100
        }
    },
    data: {
        token: ""
    },
    methods: {
        getTabBar: function() {
            return getCurrentPages()[0].getTabBar();
        },
        onPublishPost: function() {
            this.onClose(), this.getTabBar().groupPublish("/pages/publish/index/index"), e.default.moduleClick("b_gc_uwejn2wi_mc", {});
        },
        onPublishActivity: function() {
            this.onClose(), this.getTabBar().talentPublish("/pages/talent/publish/index"), e.default.moduleClick("b_gc_nsbql9ca_mc", {});
        },
        onClose: function() {
            this.triggerEvent("onClose"), e.default.moduleClick("b_gc_j51qpep4_mc", {});
        }
    }
});