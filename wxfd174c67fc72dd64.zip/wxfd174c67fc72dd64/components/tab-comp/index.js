Component({
    externalClasses: [ "tab-outerclass", "tablist-outerclass" ],
    properties: {
        tabData: {
            type: Array,
            value: []
        },
        options: {
            type: Object,
            value: null
        },
        itemType: {
            type: String,
            value: "tab"
        },
        activityType: {
            type: Number,
            value: -1
        },
        curIndex: {
            type: Number,
            value: -1
        },
        isSticky: {
            type: Boolean,
            value: !1
        },
        top: {
            type: Number,
            value: 0,
            observer: function(t) {
                this.setData({
                    stickyTop: "top: " + t + "rpx"
                });
            }
        },
        clickBid: {
            type: String,
            value: ""
        },
        viewBid: {
            type: String,
            value: ""
        },
        lxExtend: {
            type: String,
            value: ""
        },
        lxParam: {
            type: String,
            value: "title"
        }
    },
    lifetimes: {
        attached: function() {
            this.data.isSticky && this.setData({
                stickyTop: "top:" + this.data.top + "rpx"
            });
        }
    },
    data: {
        labelKey: "labelKey",
        stickyTop: "",
        prevDistance: "",
        _lxExtend: "",
        currentIndex: -1
    },
    methods: {
        itemClick: function(t) {
            this.setData({
                toIndex: "tab" + t.target.dataset.current,
                activityType: t.target.dataset.current
            }), this.triggerEvent("itemClick", {
                current: t.target.dataset.current,
                item: t.target.dataset.item
            });
        }
    },
    observers: {
        options: function(t) {
            this.setData({
                labelKey: t && t.labelKey || "labelKey"
            });
        },
        curIndex: function(t) {
            this.data.currentIndex = t;
        },
        activityType: function(t) {
            t !== this.data.currentIndex && (this.setData({
                toIndex: "tab" + t
            }), this.data.currentIndex = t, this.triggerEvent("itemChange", {
                current: t,
                item: this.properties.tabData[t]
            }));
        },
        lxExtend: function(t) {
            this.setData({
                _lxExtend: "&" + t
            });
        }
    }
});