Component({
    externalClasses: [ "custom-switch-panel", "custom-switch-bg", "custom-switch-label" ],
    properties: {
        disabled: {
            type: Boolean,
            value: !1
        },
        checked: {
            type: Boolean,
            value: !0
        },
        showStatusLabel: {
            type: Boolean,
            value: !1
        },
        activeLabel: {
            type: String,
            value: "开"
        },
        inactiveLabel: {
            type: String,
            value: "关"
        },
        activeValue: {
            type: Number,
            optionalTypes: [ Boolean, Number, String ],
            value: 1
        },
        inactiveValue: {
            type: Number,
            optionalTypes: [ Boolean, Number, String ],
            value: 2
        },
        activeBackgroundColor: {
            type: String,
            value: "linear-gradient(90deg, #FFD000 0%, #FFBD00 100%)"
        },
        inactiveBackgroundColor: {
            type: String,
            value: "#4C4C4C"
        },
        animation: {
            type: Boolean,
            value: !1
        }
    },
    data: {},
    methods: {
        onChange: function() {
            var e = this.properties, a = e.checked, t = e.activeValue, i = e.inactiveValue;
            e.disabled || this.triggerEvent("onChange", a ? i : t);
        }
    }
});