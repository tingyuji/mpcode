var t = require("../../npm/@mtfe/weapp-privacy-api/index.js").default;

Component({
    options: {
        multipleSlots: !0,
        addGlobalClass: !0
    },
    properties: {
        showHome: {
            type: Boolean,
            value: !1
        },
        extClass: {
            type: String,
            value: ""
        },
        title: {
            type: String,
            value: ""
        },
        background: {
            type: String,
            value: ""
        },
        color: {
            type: String,
            value: ""
        },
        back: {
            type: Boolean,
            value: !0
        },
        loading: {
            type: Boolean,
            value: !1
        },
        animated: {
            type: Boolean,
            value: !0
        },
        show: {
            type: Boolean,
            value: !0,
            observer: "_showChange"
        },
        delta: {
            type: Number,
            value: 1
        }
    },
    data: {
        displayStyle: ""
    },
    attached: function() {
        var e = this, a = !!t.getMenuButtonBoundingClientRect, i = t.getMenuButtonBoundingClientRect ? t.getMenuButtonBoundingClientRect() : null;
        t.getSystemInfo({
            success: function(t) {
                var n = !!(t.system.toLowerCase().search("ios") + 1);
                e.setData({
                    ios: n,
                    statusBarHeight: t.statusBarHeight,
                    innerWidth: a ? "width:" + i.left + "px" : "",
                    innerPaddingRight: a ? "padding-right:" + (t.windowWidth - i.left) + "px" : "",
                    leftWidth: a ? "width:" + (t.windowWidth - i.left) + "px" : ""
                });
            }
        });
    },
    methods: {
        _showChange: function(t) {
            var e = "";
            e = this.data.animated ? "opacity: " + (t ? "1" : "0") + ";-webkit-transition:opacity 0.5s;transition:opacity 0.5s;" : "display: " + (t ? "" : "none"), 
            this.setData({
                displayStyle: e
            });
        },
        back: function() {
            var e = this.data;
            e.delta && t.navigateBack({
                delta: e.delta
            }), this.triggerEvent("back", {
                delta: e.delta
            }, {});
        },
        backHome: function() {
            t.switchTab({
                url: "/pages/home/index"
            });
        }
    }
});