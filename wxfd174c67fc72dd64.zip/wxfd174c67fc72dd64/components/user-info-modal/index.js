var e = require("../../common/config"), a = function(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}(require("../../common/lx"));

Component({
    properties: {
        showagetag: {
            type: Boolean,
            value: !1
        },
        showbackroomtag: {
            type: Boolean,
            value: !1
        },
        showgender: {
            type: Boolean,
            value: !1
        },
        showindustry: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        genderArr: [ {
            name: "小哥哥",
            value: 1
        }, {
            name: "小姐姐",
            value: 2
        } ],
        ageArr: [ {
            name: "00后",
            value: "00后"
        }, {
            name: "95后",
            value: "95后"
        }, {
            name: "90后",
            value: "90后"
        }, {
            name: "80后",
            value: "80后"
        }, {
            name: "70后",
            value: "70后"
        }, {
            name: "其他",
            value: "其他"
        } ],
        roleArr: [ {
            name: "坦克",
            value: "坦克"
        }, {
            name: "奶",
            value: "奶"
        } ],
        industry: "",
        genderCurrentTag: "",
        ageCurrentTag: "",
        roleCurrentTag: "",
        platform: e.platform
    },
    methods: {
        closeModal: function() {
            a.default.moduleClick("b_gc_uhy1ip48_mc"), this.triggerEvent("cancel");
        },
        handleSubmit: function() {
            var e = this.data, t = e.genderCurrentTag, n = e.ageCurrentTag, r = e.roleCurrentTag, u = e.industry, l = 1 === t ? "小哥哥" : "小姐姐";
            a.default.moduleClick("b_gc_negy9eit_mc", {
                title: l + "，" + n + "，" + r + "，" + u + "，"
            }), this.triggerEvent("confirm", {
                genderCurrentTag: t,
                ageCurrentTag: n,
                roleCurrentTag: r,
                industry: u
            });
        },
        genderChange: function(e) {
            this.setData({
                genderCurrentTag: e.target.dataset.value
            });
        },
        ageChange: function(e) {
            this.setData({
                ageCurrentTag: e.target.dataset.value
            });
        },
        roleChange: function(e) {
            this.setData({
                roleCurrentTag: e.target.dataset.value
            });
        },
        bindInput: function(e) {
            e.detail.value && this.setData({
                industry: e.detail.value
            });
        },
        preventClick: function() {}
    }
});