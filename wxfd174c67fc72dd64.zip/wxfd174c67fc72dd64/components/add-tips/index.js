var e = require("../../common/index"), t = require("../../npm/@mtfe/weapp-privacy-api/index.js").default;

Component({
    properties: {},
    data: {
        showTips: !1,
        wxNavigatorBarHeight: (0, e.getWxNavigatorBarHeight)()
    },
    lifetimes: {
        attached: function() {
            this.recordAddTips();
        }
    },
    methods: {
        recordAddTips: function() {
            t.getStorageSync("closeTipDate") ? this.setData({
                showTips: !1
            }) : this.setData({
                showTips: !0
            });
        },
        closeTips: function() {
            var e = new Date().getTime();
            t.setStorageSync("closeTipDate", e), this.setData({
                showTips: !1
            });
        }
    }
});