function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

var t = e(require("../../npm/@dzfe/wx-api-promisify/dist/index.js")), n = e(require("../../utils/index")), r = require("../../common/config"), a = e(r), o = e(require("../../common/login")), u = require("../../common/wx-privacy-constant"), i = e(require("../../common/lx")), c = require("../../npm/regenerator-runtime/runtime.js"), s = require("../../npm/@mtfe/weapp-privacy-api/index.js").default, l = n.default.Event, d = n.default.EVENT_TYPE, f = a.default.platform, m = a.default.dp_domain + "/api/joy/sharerelation/post/userdetail/save", p = function(e) {
    return t.default.request({
        url: m,
        data: e,
        method: "POST",
        header: {}
    }).then(function(e) {
        var t = e.data;
        if (200 === t.code && t.msg) return t.msg;
        throw new Error("请求数据失败");
    }).catch(function(e) {
        return console.error("saveUserInfo", e), null;
    });
};

Component({
    properties: {
        currentPage: Number,
        zIndex: {
            type: Number,
            value: 10
        }
    },
    data: {
        token: "",
        exampleAvatar: "https://p0.meituan.net/scarlett/41508c2760ed3b1483a7c750e60c4343183502.png",
        userAvatar: null,
        platform: f
    },
    methods: {
        onAvatarModifySuccess: function(e) {
            var t = this;
            return function() {
                var n, r;
                return c.async(function(o) {
                    for (;;) switch (o.prev = o.next) {
                      case 0:
                        return n = e.url, t.data.userAvatar || i.default.moduleView("b_gc_nq652e5y_mv", {}), 
                        t.setData({
                            userAvatar: n
                        }), o.next = 5, c.awrap(t.forceLogin());

                      case 5:
                        return r = {
                            token: t.data.token,
                            platform: a.default.platformCode,
                            avatar: n
                        }, o.abrupt("return", p(r));

                      case 7:
                      case "end":
                        return o.stop();
                    }
                }, null, null, null, Promise);
            }();
        },
        onUploadAgain: function() {
            var e = this;
            return c.async(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    i.default.moduleClick("b_gc_9laln1h4_mc", {}), e.upload();

                  case 2:
                  case "end":
                    return t.stop();
                }
            }, null, null, null, Promise);
        },
        onUpload: function() {
            var e = this;
            return c.async(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    i.default.moduleClick("b_gc_eskn27yg_mc", {}), e.upload();

                  case 2:
                  case "end":
                    return t.stop();
                }
            }, null, null, null, Promise);
        },
        upload: function() {
            var e = this;
            return function() {
                var n, o, i, l;
                return c.async(function(d) {
                    for (;;) switch (d.prev = d.next) {
                      case 0:
                        return e.triggerEvent("onUpload"), n = e.properties.currentPage, d.prev = 2, o = "wx" === a.default.platform ? [ "album", "camera" ] : [ "album" ], 
                        d.next = 6, c.awrap(t.default.chooseImage({
                            count: 1,
                            sizeType: [ "original", "compressed" ],
                            sourceType: o,
                            _mt: {
                                sceneToken: r.isWX ? u.WX_SCENETOKENS.CHOOSEIMAGE_AVATAR : a.default.privacySceneToken
                            }
                        }));

                      case 6:
                        i = d.sent, (l = i.tempFilePaths) && l[0] && s.navigateTo({
                            url: "/pages/user-profile/avatar-pick/index?from=" + n + "&avatarUrl=" + encodeURIComponent(l[0])
                        }), d.next = 14;
                        break;

                      case 11:
                        d.prev = 11, d.t0 = d.catch(2), console.error(d.t0);

                      case 14:
                      case "end":
                        return d.stop();
                    }
                }, null, null, [ [ 2, 11 ] ], Promise);
            }();
        },
        onFinish: function() {
            this.triggerEvent("onFinish"), i.default.moduleClick("b_gc_vsovgy70_mc", {});
        },
        onClose: function() {
            this.triggerEvent("onClose");
            var e = this.data.userAvatar ? "b_gc_mt1a6u32_mc" : "b_gc_rnm9z8tb_mc";
            i.default.moduleClick(e, {});
        },
        forceLogin: function() {
            var e = this;
            return o.default.mtDefaultLogin({
                isBind: !0
            }).then(function(t) {
                e.data.token = t.token || t.userInfo && t.userInfo.token || "";
            });
        }
    },
    lifetimes: {
        attached: function() {
            l.on(d.AVATAR_MODIFY_SUCCESS, this.onAvatarModifySuccess, this), i.default.moduleView("b_gc_bliqi0qo_mv", {});
        },
        detached: function() {
            l.off(d.AVATAR_MODIFY_SUCCESS, this.onAvatarModifySuccess, this);
        }
    }
});