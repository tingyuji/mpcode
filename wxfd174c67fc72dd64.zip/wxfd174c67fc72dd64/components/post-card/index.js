Component({
    externalClasses: [ "my-class" ],
    properties: {
        detailCard: Object,
        users: Array,
        post: Object
    },
    data: {},
    methods: {
        onTaps: function(t) {
            var e = t.currentTarget.dataset.tapevent, a = t.target.dataset.tapevent, s = this.data.post;
            this.triggerEvent(e || a, {
                post: s
            });
        },
        stopSwiperTouch: function() {
            return !1;
        }
    }
});