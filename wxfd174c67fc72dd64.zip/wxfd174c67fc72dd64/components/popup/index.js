var t = Object.assign || function(t) {
    for (var e = 1; e < arguments.length; e++) {
        var s = arguments[e];
        for (var a in s) Object.prototype.hasOwnProperty.call(s, a) && (t[a] = s[a]);
    }
    return t;
};

Component({
    externalClasses: [ "my-class", "overlay-class" ],
    properties: {
        show: Boolean,
        overlay: {
            type: Boolean,
            value: !0
        },
        radius: {
            type: Number,
            value: 0
        },
        styles: {
            type: Object,
            value: {},
            observer: function() {
                this.initStyles();
            }
        },
        position: {
            type: String,
            value: "bottom"
        }
    },
    data: {
        customStyles: {}
    },
    lifetimes: {
        ready: function() {
            this.initStyles();
        }
    },
    methods: {
        initStyles: function() {
            var e = this.data, s = e.radius, a = e.styles, o = {};
            s && (o.borderRadius = s + "rpx " + s + "rpx 0 0"), this.setData({
                customStyles: t({}, o, a || {})
            });
        },
        onOverlayTap: function() {
            this.triggerEvent("onOverlayTap");
        },
        onPopupTap: function() {
            this.triggerEvent("onPopupTap");
        }
    }
});