function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function t(e, t) {
    var n = Object.keys(e);
    if (Object.getOwnPropertySymbols) {
        var r = Object.getOwnPropertySymbols(e);
        t && (r = r.filter(function(t) {
            return Object.getOwnPropertyDescriptor(e, t).enumerable;
        })), n.push.apply(n, r);
    }
    return n;
}

function n(e) {
    for (var n = 1; n < arguments.length; n++) {
        var i = null != arguments[n] ? arguments[n] : {};
        n % 2 ? t(Object(i), !0).forEach(function(t) {
            r(e, t, i[t]);
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(i)) : t(Object(i)).forEach(function(t) {
            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(i, t));
        });
    }
    return e;
}

function r(e, t, n) {
    return t in e ? Object.defineProperty(e, t, {
        value: n,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = n, e;
}

var i = function(e) {
    if (e && e.__esModule) return e;
    var t = {};
    if (null != e) for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
    return t.default = e, t;
}(require("npm/@mtfe/mt-weapp-city/index.js")), a = require("npm/@dp/owl-wxapp/es6/index.js"), o = require("npm/@mtfe/mt-weapp-api/dist/index.js"), u = e(require("npm/@analytics/wechat-sdk/lib/index.js")), s = require("npm/@mtfe/perf-mp/dist/cjs/index.js");

require("common/privacy");

var l = e(require("utils/index")), c = e(require("common/error-report/index")), f = require("common/global-info"), d = require("utils/page"), p = (require("common/storage-constants"), 
require("common/city")), g = require("common/wx-privacy-constant"), m = e(require("components/mtgroup-privacy-dialog/privacy-dialog")), h = e(require("./common/config")), y = e(require("./common/login")), v = require("./common/request/index"), x = require("./common/index"), b = require("npm/regenerator-runtime/runtime.js"), w = require("npm/@mtfe/weapp-privacy-api/index.js").default, _ = l.default.Event, P = l.default.EVENT_TYPE, I = l.default.isShareCardScene;

o.config.env = h.default.env;

var O = {
    playgroupWx: "playgroup_wxapp",
    mtApp: "group",
    dpApp: "dianping_nova"
};

s.perf.init({
    token: "61a5c35e1c9d4404f6a97dbb",
    enableFstPages: [ "pages/home/index" ],
    debug: "develop" === h.default.miniProgramEnvVersion,
    version: "0.8.2"
});

var D = u.default.pageLifeCycleInterceptor(), q = Page;

Page = (0, d.pageShareExtend)(function(e) {
    (0, a.page)(D(e), q);
}), (0, s.App)({
    finger: function() {
        return new Promise(function(e) {
            setTimeout(function() {
                e("");
            }, 2e3), "wx" === h.default.platform ? (0, x.jsGuardInit)().then(function(t) {
                t.finger.g(function(t) {
                    e(t);
                });
            }) : w.getRiskControlFingerprint({
                success: function(t) {
                    e(t.fingerprint);
                },
                fail: function(e) {
                    console.log(e);
                }
            });
        });
    },
    globalData: {
        userInfo: null,
        appid: "wxfd174c67fc72dd64",
        im: null,
        sceneValue: 1e3,
        isShowIcon: !1,
        isShowShareDialog: !1,
        homeParams: null,
        globalInfo: {}
    },
    getCityInfo: function(e) {
        var t = this;
        if (this.__cityInfo) return Promise.resolve(this.__cityInfo);
        if (this.__getCityPromise) return this.__getCityPromise;
        var r = this;
        return this.__getCityPromise = new Promise(function(t, a) {
            var o;
            return b.async(function(u) {
                for (;;) switch (u.prev = u.next) {
                  case 0:
                    if ("wx" !== h.default.platform) {
                        u.next = 8;
                        break;
                    }
                    return u.next = 3, b.awrap(r.wxPrivacy());

                  case 3:
                    o = {
                        _mt: {
                            sceneToken: g.WX_SCENETOKENS.GETLOCATION_HOME
                        }
                    }, "[object Object]" === Object.prototype.toString.call(e) && (o = n({}, o, {}, e)), 
                    i.getCityInfo(o).then(function(e) {
                        t(e);
                    }).catch(a), u.next = 9;
                    break;

                  case 8:
                    "mt" === h.default.platform ? h.default.getMtCityInfo(e).then(function(e) {
                        t(e);
                    }).catch(a) : h.default.getDpCityInfo(e).then(function(e) {
                        t(e);
                    }).catch(a);

                  case 9:
                  case "end":
                    return u.stop();
                }
            }, null, null, null, Promise);
        }).then(function(e) {
            return t.__cityInfo = e, e;
        }).catch(function() {
            return n({}, (0, p.getDefaultCity)(), {
                lat: "",
                lng: ""
            });
        }), this.__getCityPromise;
    },
    initLx: function() {
        var e = void 0;
        e = "wx" === h.default.platform ? O.playgroupWx : "mt" === h.default.platform ? O.mtApp : O.dpApp, 
        u.default.init("https://report.meituan.com", {
            appnm: e,
            category: "gc",
            app: "0.8.2"
        });
    },
    setLxWxIds: function() {
        return "wx" === h.default.platform ? y.default.getWxIds().then(function(e) {
            u.default.set("wxid", e.openId), u.default.set("wxunionid", e.unionId);
        }) : "";
    },
    setLxCity: function() {
        return _.on(P.HOME_CITYCHANGE, function(e) {
            var t = e.cityid;
            return u.default.set("cityid", t);
        }), this.getCityInfo().then(function(e) {
            u.default.set("locate_city_id", e.id), u.default.set("lat", e.lat), u.default.set("lng", e.lng);
        });
    },
    setLxUid: function() {
        var e = this;
        return this.__lxUidBeenListened || (_.on(P.USER_LOGIN, function() {
            !(u.default.get("uid") && u.default.get("uuid")) && e.setLxUid();
        }), this.__lxUidBeenListened = !0), new Promise(function(t) {
            if (e.globalData.userInfo && e.globalData.userInfo.userId) {
                var n = e.globalData.userInfo, r = n.userId, i = n.uuid;
                u.default.set("uid", e.globalData.userInfo.userId), "mt" === h.default.platform ? u.default.set("uuid", i) : u.default.set("uid", r), 
                t();
            } else y.default.mtDefaultLogin({
                isBind: !1,
                isWxInfo: !1
            }).then(t);
        });
    },
    setLxUTM: function(e) {
        var t = e.query && e.query.utm_source || "";
        if (!t && e.query && e.query.scene) for (var n = decodeURIComponent(e.query.scene).split("&"), r = 0; r < n.length; r++) {
            var i = n[r].split("=");
            "utm_source" === i[0] && (t = i[1]), "um" === i[0] && (t = i[1]);
        }
        this.globalData.utmSource = t, u.default.setUTM({
            utm_source: t
        });
    },
    initOwl: function() {
        a.owl.start({
            project: "com.sankuai.dzufebiz.2c.mtplaygroup",
            devMode: !1,
            autoCatch: {
                pv: !0,
                pagePv: !0
            },
            wxAppVersion: "0.8.2"
        });
    },
    listenShaking: function() {
        "wx" === h.default.platform && "develop" === h.default.miniProgramEnvVersion && w.onAccelerometerChange(function(e) {
            var t = e.x, n = e.y, r = e.z;
            (t > 2 || n > 2 || r > 2) && w.navigateTo({
                url: "/pages/debug/index"
            });
        });
    },
    getAllCities: x.getAllCities,
    onShow: function(e) {
        this.globalData.sceneValue = e.scene, this.globalData.helpCode = e.query.helpcode, 
        I(e.scene) && (this.globalData.isShowShareDialog = !1), this.globalData.isShowIcon = !1, 
        u.default.set("scene", e.scene), this.setLxUTM(e), Promise.all([ this.setLxWxIds(), this.setLxCity(), this.setLxUid() ]).then(function() {
            u.default.start();
        }), (0, x.parseShortTicketAndRedirect)(e);
    },
    onLaunch: function() {
        this.initLx(), this.initOwl(), (0, v.overrideWxRequest)(), this.globalInfo(), this.listenShaking(), 
        setTimeout(this.getAllCities, 0);
    },
    onHide: function() {
        u.default.quit(), this._privacyDialogPromise && void 0 === this._donotNeedPrivacyDialog && (this.__getCityPromise = null, 
        this._privacyDialogPromise = null);
    },
    globalInfo: function() {
        var e = this;
        return function() {
            var t, n, r, i;
            return b.async(function(a) {
                for (;;) switch (a.prev = a.next) {
                  case 0:
                    if ("wx" === h.default.platform) {
                        a.next = 2;
                        break;
                    }
                    return a.abrupt("return");

                  case 2:
                    return a.prev = 2, a.next = 5, b.awrap((0, f.getGlobalInfo)());

                  case 5:
                    if (t = a.sent, e.globalData.globalInfo = t, n = t.versionVO, r = n.forceUpdate, 
                    i = n.updateNotice) {
                        a.next = 10;
                        break;
                    }
                    return a.abrupt("return");

                  case 10:
                    (0, f.updateVersion)(i, r), a.next = 16;
                    break;

                  case 13:
                    a.prev = 13, a.t0 = a.catch(2), console.log(a.t0);

                  case 16:
                  case "end":
                    return a.stop();
                }
            }, null, null, [ [ 2, 13 ] ], Promise);
        }();
    },
    showLoading: function() {
        var e = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0], t = arguments[1];
        e ? w.showLoading(t || {
            title: "loading...",
            duration: 3e3,
            mask: !0
        }) : w.hideLoading();
    },
    owl: a.owl,
    addError: function() {
        this.globalData && 1129 !== this.globalData.sceneValue && c.default.createInstance.apply(c.default, arguments);
    },
    wxPrivacy: function() {
        var e = this;
        return function() {
            var t, n, r, i;
            return b.async(function(a) {
                for (;;) switch (a.prev = a.next) {
                  case 0:
                    if (!e._donotNeedPrivacyDialog) {
                        a.next = 2;
                        break;
                    }
                    return a.abrupt("return");

                  case 2:
                    if ([ "pages/home/index", "pages/detail/merchants/index/index", "pages/detail/theme/index", "pages/detail/drama/index" ].includes(w.getLaunchOptionsSync().path)) {
                        a.next = 5;
                        break;
                    }
                    return e._donotNeedPrivacyDialog = !0, a.abrupt("return");

                  case 5:
                    if (t = "wx_privacy_dialog_haveBeenAgreed", !(!0 === (n = w.getStorageSync(t)) || !1 !== n && w.getStorageSync(y.default.loginPersistKey))) {
                        a.next = 10;
                        break;
                    }
                    return e._donotNeedPrivacyDialog = !0, a.abrupt("return");

                  case 10:
                    return a.next = 12, b.awrap((0, f.getGlobalInfo)().catch(function() {}));

                  case 12:
                    if (r = a.sent, ((i = r.configVO) || {}).privacyPopupShow) {
                        a.next = 16;
                        break;
                    }
                    return a.abrupt("return");

                  case 16:
                    return e._privacyDialogPromise || (w.setStorage({
                        key: t,
                        data: !1
                    }), e._privacyDialogPromise = (0, m.default)().then(function() {
                        e._donotNeedPrivacyDialog = !0, w.setStorage({
                            key: t,
                            data: !0
                        });
                    }).catch(console.log)), a.abrupt("return", e._privacyDialogPromise);

                  case 18:
                  case "end":
                    return a.stop();
                }
            }, null, null, null, Promise);
        }();
    }
}, a.app);