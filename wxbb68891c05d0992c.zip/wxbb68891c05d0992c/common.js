(wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 3 ], [ , , , , function(e, t, n) {
    "use strict";
    n.d(t, "f", function() {
        return r;
    }), n.d(t, "c", function() {
        return a;
    }), n.d(t, "h", function() {
        return i;
    }), n.d(t, "d", function() {
        return u;
    }), n.d(t, "e", function() {
        return s;
    }), n.d(t, "b", function() {
        return l;
    }), n.d(t, "g", function() {
        return b;
    }), n.d(t, "a", function() {
        return O;
    });
    var c = n(5), r = {
        isSystemModal: !1
    }, a = 1154 === Object(c.getLaunchOptionsSync)().scene, i = {}, u = {
        notifyRun: null,
        notifyPatch: null,
        notifyMutate: null,
        notifyCancel: null
    }, s = {
        notifyCount: 0,
        pollingDelay: 12e4,
        resumePollingTimer: null
    }, o = {}, l = new c.Events();
    l.only = function(e, t) {
        return l.off(e), l.on(e, function() {
            o[e] = t.apply(void 0, arguments);
        }), function() {
            l.off(e);
        };
    }, l.emit = function(e) {
        for (var t = arguments.length, n = new Array(t > 1 ? t - 1 : 0), c = 1; c < t; c++) n[c - 1] = arguments[c];
        return l.trigger.apply(l, [ e ].concat(n)), o[e];
    };
    var j = {}, b = {
        set: function(e, t) {
            j[e] = t, void 0 !== t ? Object(c.setStorageSync)(e, t) : Object(c.removeStorageSync)(e);
        },
        get: function(e) {
            return j[e] || Object(c.getStorageSync)(e) || void 0;
        }
    };
    b.set("WORK_DATA", void 0), b.set("IS_V3_MASK_HIDE", void 0), b.set("IS_V3.1_MASK_HIDE", void 0), 
    b.set("IS_STORY_MASK_HIDE", void 0);
    var O = "#(".concat("[_a-zA-Z0-9]|[一-龥]", "|").concat("[\ud83c][\udf00-\udfff]|[\ud83d][\udc00-\ude4f\ude80-\udeff]|[☀-⭕]", "|").concat("[\ud83c][\udde6-\uddff]|[]", ")+?");
}, , , , function(e, t, n) {
    "use strict";
    var c = n(9), r = n(77), a = n(17), i = n(4), u = Object(a.a)().theme, s = {
        0: "DISABLED",
        1: "UN_SIGNUP",
        2: "ACTIVE"
    }, o = {}, l = Object(r.a)({
        hasLogin: void 0,
        account: {},
        setAccount: function(e) {
            var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, n = t.isCheck;
            e.statusText = s[e.status], l.account = e;
            var c = function() {
                l.hasLogin = "ACTIVE" === e.statusText;
            };
            n ? c() : setTimeout(c, 150);
        },
        itsMe: function(e) {
            var t = l.account;
            return o[e] || (o[e] = e === t.user_id), o[e];
        },
        needSignup: function() {
            var e = !l.hasLogin;
            return e && i.b.emit("OPEN_SIGNUP"), e;
        },
        theme: u,
        publishStatus: "",
        publishData: i.g.get("PUBLISH_DATA") || {},
        setPublishData: function(e) {
            var t = l.publishData, n = Object(c.a)(Object(c.a)({}, t), e);
            i.g.set("PUBLISH_DATA", n), l.publishData = n;
        },
        clearPublishData: function() {
            i.g.set("PUBLISH_DATA", {}), l.publishData = {};
        },
        notifyOnceLoading: !1,
        notifyPatchLoading: !1,
        notifyData: !1,
        userMap: {},
        postMap: {},
        taggedMap: {},
        worksMap: {},
        likesMap: {}
    });
    t.a = l;
}, , , function(e, t, n) {
    "use strict";
    n.d(t, "a", function() {
        return M;
    }), n.d(t, "b", function() {
        return m;
    }), n.d(t, "c", function() {
        return x;
    });
    var c = n(16), r = n(9), a = n(23), i = n(6), u = n(1), s = n(5), o = n(14), l = n(4), j = n(8), b = [ "forceReset" ], O = [ "noMoreMsg", "next_id" ], d = function(e) {
        return Object(o.a)(e), Promise.reject();
    }, f = function(e, t, n) {
        return Object(s.request)({
            url: "".concat("https://futake.sotake.com", "/api/wx").concat(e),
            method: t,
            data: n,
            header: {
                cookie: l.g.get("COOKIE") || ""
            },
            enableHttp2: !0,
            mode: "no-cors"
        }).then(function(t) {
            var c = t.statusCode, r = t.data, a = t.cookies;
            if (a.length > 0 && l.g.set("COOKIE", a.join(";")), c >= 200 && c < 300 || 304 === c) {
                var i, u, s = r.code, o = r.msg, b = r.data;
                return 0 === s ? b : (10100 === s && null !== (i = j.a.itsMe) && void 0 !== i && i.call(j.a, null == n ? void 0 : n.user_id) && (null === (u = j.a.setAccount) || void 0 === u || u.call(j.a, b || {
                    status: 0
                }), l.g.set("COOKIE", void 0)), d(o));
            }
            return d("".concat(e, " --- ").concat(c, " ").concat(r.message));
        });
    }, g = function(e, t) {
        var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {}, l = n.ready, g = n.manual, M = n.loadMore, m = n.initialData, p = Object(u.useRef)(n);
        p.current = n;
        var x = Object(u.useRef)(!0), I = Object(u.useRef)(!1), N = Object(u.useRef)(null), h = Object(u.useRef)([]), v = Object(u.useRef)(null), D = Object(u.useRef)(function() {
            clearTimeout(v.current);
        }), A = Object(u.useRef)([ "onceLoading", "loading", "patchLoading", "data" ]), y = Object(u.useRef)([]), T = Object(u.useState)({}), E = Object(i.a)(T, 2), C = E[0], w = E[1], S = Object(u.useRef)({
            onceLoading: !g,
            loading: !g,
            patchLoading: !1,
            data: m
        }), k = function(e) {
            var t = !1;
            A.current.forEach(function(n) {
                if (n in e) {
                    if ("onceLoading" === n) {
                        if (I.current) return void (e.onceLoading = !1);
                        !1 === e.onceLoading && (I.current = !0);
                    } else "patchLoading" === n && clearTimeout(N.current);
                    S.current[n] !== e[n] && (t = !0);
                }
            }), Object.assign(S.current, e), t && w({});
        }, L = Object(u.useRef)(function() {
            var n = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, i = n.forceReset, u = Object(a.a)(n, b), l = p.current, j = l.params, O = l.pollingInterval, I = l.pollingCanSkipRerender, D = l.formatResult, T = l.onSuccess, E = l.onError;
            x.current ? g && k(I ? {
                onceLoading: !0
            } : {
                onceLoading: !0,
                loading: !0
            }) : (N.current = setTimeout(function() {
                S.current.patchLoading = !0;
            }, 500), w({}));
            var C = u ? Object(r.a)(Object(r.a)({}, j), u) : j, _ = f(e, t, C).then(function(e) {
                var t = e;
                if (!t) {
                    if (!m) return k({
                        onceLoading: !1,
                        loading: !1
                    }), d("data: ".concat(t));
                    t = m;
                }
                if (D && (t = D(t)), x.current) {
                    var n;
                    if ("number" == typeof O && (clearTimeout(v.current), v.current = setTimeout(L.current, O), 
                    !i)) {
                        if (null != I && I(t, S.current.data)) return k({
                            onceLoading: !1
                        }), t;
                        n = !0;
                    }
                    return M && (h.current = Object(c.a)(t.list), t.list.RESET_LIST = !0), null == T || T(t), 
                    k({
                        onceLoading: !1,
                        loading: !1,
                        data: t
                    }), A.current = y.current, n && Object(s.pageScrollTo)({
                        scrollTop: 0
                    }), t;
                }
                return t.list.RESET_LIST = !1, null == T || T(t), h.current = h.current.concat(t.list), 
                t = Object(r.a)(Object(r.a)({}, t), {}, {
                    list: h.current
                }), k({
                    patchLoading: !1,
                    data: t
                }), t;
            });
            return _.catch(function(e) {
                var t = e && (e.errMsg || e.message);
                t && !t.includes("request:fail") && Object(o.a)(t), null == E || E(e), x.current ? k({
                    onceLoading: !1,
                    loading: !1
                }) : k({
                    patchLoading: !1
                });
            }), _;
        }), _ = Object(u.useRef)(function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = e.noMoreMsg, n = e.next_id, c = Object(a.a)(e, O);
            return new Promise(function(e, a) {
                var i;
                if (!x.current) return a();
                var u = null === (i = S.current.data) || void 0 === i ? void 0 : i.next_id;
                if (!u && !n) return t && Object(o.a)(t), a();
                x.current = !1;
                var s = L.current(Object(r.a)({
                    next_id: u || n
                }, c));
                return s.finally(function() {
                    x.current = !0;
                }), e(s);
            });
        }), z = Object(u.useRef)(function(e) {
            var t, n = "function" == typeof e ? e(S.current.data) : e;
            n !== S.current.data && (!n && m && (n = m), "list" in n && 1 === Object.keys(n).length && (n = Object(r.a)(Object(r.a)({}, S.current.data), n)), 
            M && (h.current = Object(c.a)(null === (t = n) || void 0 === t ? void 0 : t.list)), 
            k({
                data: n
            }));
        }), R = j.a.hasLogin;
        return Object(u.useEffect)(function() {
            g || void 0 === R || !1 === l || L.current();
        }, [ R, g, l ]), Object(u.useMemo)(function() {
            return C && {
                get onceLoading() {
                    return y.current[1] = "onceLoading", S.current.onceLoading;
                },
                get loading() {
                    return y.current[0] = "loading", S.current.loading;
                },
                get patchLoading() {
                    return y.current[2] = "patchLoading", S.current.patchLoading;
                },
                get data() {
                    return y.current[3] = "data", S.current.data;
                },
                run: L.current,
                patch: _.current,
                mutate: z.current,
                cancel: D.current
            };
        }, [ C ]);
    }, M = function(e, t) {
        return g(e, "GET", t);
    }, m = function(e, t) {
        return g(e, "POST", t);
    }, p = {
        post: 1,
        avatar: 2
    }, x = function(e) {
        var t = Object(u.useRef)([ "loading", "data" ]), n = Object(u.useRef)([]), c = Object(u.useState)({}), r = Object(i.a)(c, 2)[1], a = Object(u.useRef)({
            loading: !1,
            data: void 0
        }), j = function(e) {
            var n = !1;
            t.current.forEach(function(t) {
                t in e && a.current[t] !== e[t] && (n = !0);
            }), Object.assign(a.current, e), n && r({});
        }, b = Object(u.useRef)(e);
        return b.current = e, {
            get loading() {
                return n.current[0] = "loading", a.current.loading;
            },
            get data() {
                return n.current[1] = "data", a.current.data;
            },
            run: Object(u.useRef)(function(e) {
                var c = b.current, r = c.type, a = c.file, i = c.onSuccess, u = c.onError;
                j({
                    loading: !0
                });
                var O = Object(s.uploadFile)({
                    url: "".concat("https://futake.sotake.com", "/api/wx/misc/upload?type=").concat(p[r]),
                    filePath: e || a,
                    name: "file",
                    header: {
                        cookie: l.g.get("COOKIE")
                    }
                }).then(function(e) {
                    var c = JSON.parse(e.data), r = c.code, a = c.msg, u = c.data;
                    return 0 === r && u ? (null == i || i(u), j({
                        loading: !1,
                        data: u
                    }), t.current = n.current, u) : d(a);
                });
                return O.catch(function(e) {
                    var t = e && (e.errMsg || e.message);
                    t && Object(o.a)(t), null == u || u(e), j({
                        loading: !1
                    });
                }), O;
            }).current
        };
    };
}, function(e, t, n) {
    "use strict";
    n.d(t, "c", function() {
        return o;
    }), n.d(t, "d", function() {
        return l;
    }), n.d(t, "a", function() {
        return j;
    }), n.d(t, "b", function() {
        return b;
    }), n.d(t, "e", function() {
        return O;
    }), n.d(t, "f", function() {
        return d;
    });
    var c = n(30), r = n(16), a = n(6), i = n(9), u = n(8), s = n(50), o = function(e, t, n) {
        Object(u.a)(e, function(e) {
            return e[t] = e[t] ? Object(i.a)(Object(i.a)({}, e[t]), n) : n, Object(i.a)({}, e);
        });
    }, l = function(e, t, n) {
        Object(u.a)(e, function(e) {
            var c = t.split("."), r = Object(a.a)(c, 2), u = r[0], s = r[1];
            return n.forEach(function(t) {
                var n, c;
                s ? (n = t[u], c = t[u][s]) : c = (n = t)[u], e[c] = e[c] ? Object(i.a)(Object(i.a)({}, e[c]), n) : n;
            }), Object(i.a)({}, e);
        });
    }, j = function(e, t, n) {
        n.RESET_LIST && Object(u.a)(e, function(e) {
            return e[t] && Object(s.a)(e[t], n) ? e : (e[t] = n, Object(i.a)({}, e));
        });
    }, b = function(e, t) {
        e(function(e) {
            var n = e.list;
            return {
                list: [ t ].concat(Object(r.a)(n))
            };
        });
    }, O = function(e, t, n) {
        e(function(e) {
            var c = e.list.findIndex(function(e) {
                return e[t] === n;
            });
            return c > -1 ? (e.list.splice(c, 1), Object(i.a)(Object(i.a)({}, e), {}, {
                list: Object(r.a)(e.list)
            })) : e;
        });
    }, d = function(e, t, n) {
        Object(u.a)(e, function(e) {
            return e[t] ? (n(e[t]), Object(i.a)(Object(i.a)({}, e), {}, Object(c.a)({}, t, Object(i.a)({}, e[t])))) : e;
        });
    };
}, , function(e, t, n) {
    "use strict";
    var c = n(9), r = n(5);
    t.a = function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "error", t = arguments.length > 1 ? arguments[1] : void 0;
        Object(r.showToast)(Object(c.a)({
            title: e,
            icon: "none"
        }, t));
    };
}, function(e, t, n) {
    "use strict";
    var c, r = n(1), a = n(5), i = n(56), u = {}, s = null, o = !1;
    Object(a.onAppRoute)(function(e) {
        var t = e.path, n = e.openType;
        if (t !== s) {
            var r = s;
            c = function() {
                o = !0, u[r] && u[r].listeners.forEach(function(e) {
                    "function" == typeof e.onLeave && e.onLeave(n);
                }), setTimeout(function() {
                    u[t] && (u[t].isFirst ? u[t].isFirst = !1 : u[t].listeners.forEach(function(e) {
                        e.onLeave = e.onEnter(n);
                    }));
                }, 100);
            }, o && c(), s = t;
        }
    }), t.a = function(e) {
        Object(r.useLayoutEffect)(function() {
            var t = Object(i.a)();
            u[t] || (u[t] = {
                isFirst: !0,
                listeners: []
            });
            var n = {
                onLeave: e("appLaunch"),
                onEnter: e
            };
            return u[t].listeners.push(n), function() {
                var e = u[t].listeners.indexOf(n);
                u[t].listeners.splice(e, 1);
            };
        }, [ e ]), Object(r.useEffect)(function() {
            o || c();
        }, []);
    };
}, , function(e, t, n) {
    "use strict";
    var c = n(9), r = n(5);
    t.a = function e() {
        if (!e.cache) {
            var t = Object(r.getSystemInfoSync)(), n = Object(r.getMenuButtonBoundingClientRect)(), a = n.height + 2 * (n.top - t.statusBarHeight), i = t.statusBarHeight + a, u = {
                "--status-bar": "".concat(t.statusBarHeight, "px"),
                "--nav-bar": "".concat(a, "px"),
                "--nav-right": "".concat(t.screenWidth - n.left, "px"),
                "--top-bar": "".concat(i, "px")
            }, s = t.screenHeight - i, o = t.safeArea.bottom - i, l = s - o, j = +(t.screenHeight / t.screenWidth).toFixed(2), b = t.screenWidth / 375;
            e.cache = Object(c.a)(Object(c.a)({}, t), {}, {
                menu: n,
                topCssVar: u,
                bodyHeight: s,
                contentHeight: o,
                safeBottomHeight: l,
                screenRatio: j,
                screenScale: b
            });
        }
        return e.cache;
    };
}, function(e, t, n) {
    "use strict";
    var c = n(1), r = n(2), a = n(69), i = n.n(a), u = (n(134), n(0)), s = Object(c.memo)(function(e) {
        var t = e.className, n = void 0 === t ? "" : t, c = e.ring, a = e.spin, s = e.logo, o = e.style;
        return c ? Object(u.jsx)(r.i, {
            className: "loading ring-loading ".concat(n)
        }) : a ? Object(u.jsx)(r.i, {
            className: "loading spin-loading ".concat(n),
            children: Object(u.jsx)(r.b, {
                className: "icon",
                src: i.a
            })
        }) : s ? Object(u.jsxs)(r.i, {
            className: "loading face-loading ".concat(n),
            catchMove: !0,
            children: [ Object(u.jsx)(r.i, {
                className: "logo shine",
                children: "FUTAKE"
            }), Object(u.jsx)(r.b, {
                className: "icon",
                src: i.a
            }) ]
        }) : Object(u.jsxs)(r.i, {
            className: "loading full-loading ".concat(n),
            style: o,
            children: [ Object(u.jsx)(r.i, {
                className: "dot"
            }), Object(u.jsx)(r.i, {
                className: "dot"
            }), Object(u.jsx)(r.i, {
                className: "dot"
            }) ]
        });
    });
    t.a = s;
}, function(e, t, n) {
    "use strict";
    var c = n(2), r = n(45), a = n(91), i = n.n(a), u = (n(142), n(0));
    t.a = function(e) {
        var t = e.title, n = e.backBtn, a = Object(r.a)();
        return Object(u.jsxs)(c.i, {
            className: "nav-bar",
            children: [ n && Object(u.jsx)(c.b, {
                className: "icon btn-back",
                onTouchStart: a,
                src: i.a
            }), t && Object(u.jsx)(c.i, {
                className: "nav-title",
                children: t
            }) ]
        });
    };
}, function(e, t, n) {
    "use strict";
    var c = n(9), r = n(23), a = n(6), i = n(1), u = n(2), s = n(61), o = n(47), l = n.n(o), j = (n(145), 
    n(0)), b = [ "className", "type", "blur", "visible", "stopClose", "onClose", "title", "btnOk", "children" ], O = Object(i.memo)(Object(i.forwardRef)(function(e, t) {
        var n = e.onTouchStart, c = e.onTouchMove, r = e.onTouchEnd, s = e.children, o = Object(i.useState)(0), l = Object(a.a)(o, 2), b = l[0], O = l[1];
        return Object(i.useImperativeHandle)(t, function() {
            return {
                setBottom: O
            };
        }), Object(j.jsx)(u.i, {
            className: "wrapper",
            onTouchStart: n,
            onTouchMove: c,
            onTouchEnd: r,
            style: {
                marginBottom: "-".concat(b, "px")
            },
            children: s
        });
    }));
    t.a = function(e) {
        var t = e.className, n = void 0 === t ? "" : t, a = e.type, o = void 0 === a ? "auto" : a, d = e.blur, f = void 0 !== d && d, g = e.visible, M = e.stopClose, m = e.onClose, p = e.title, x = e.btnOk, I = e.children, N = Object(r.a)(e, b), h = Object(i.useRef)({}), v = Object(i.useRef)(0), D = Object(i.useRef)(0), A = Object(i.useRef)(0), y = function(e) {
            var t = e.pageX, n = e.pageY - D.current;
            if (n <= 0) return 0;
            var c = t - v.current, r = Object(s.a)(c, n);
            return r < 45 || r > 135 ? 0 : n;
        }, T = Object(i.useCallback)(function(e) {
            if (!M) {
                var t = e.changedTouches[0], n = t.pageX, c = t.pageY;
                v.current = n, D.current = c, A.current = Date.now();
            }
        }, [ M ]), E = Object(i.useCallback)(function(e) {
            if (!M) {
                var t = y(e.changedTouches[0]);
                t && h.current.setBottom(t);
            }
        }, [ M ]), C = Object(i.useCallback)(function(e) {
            if (!M) {
                var t = y(e.changedTouches[0]);
                if (t) return t > 200 || t > 10 && Date.now() - A.current < 200 ? (m(), void setTimeout(function() {
                    h.current.setBottom(0);
                }, 180)) : void h.current.setBottom(0);
                h.current.setBottom(0);
            }
        }, [ m, M ]);
        return Object(j.jsxs)(u.i, {
            className: "modal ".concat(n, " ").concat(o, " ").concat(f ? "blur" : "", " ").concat(g ? "show" : "hide"),
            catchMove: !0,
            children: [ Object(j.jsx)(u.i, {
                className: "mask",
                onTouchStart: m
            }), Object(j.jsxs)(O, {
                ref: h,
                onTouchStart: T,
                onTouchMove: E,
                onTouchEnd: C,
                children: [ "list" !== o && Object(j.jsxs)(u.i, {
                    className: "header ".concat("full" === o || x ? "left-close" : ""),
                    children: [ Object(j.jsx)(u.b, {
                        className: "icon close-icon",
                        src: l.a,
                        onTouchStart: m
                    }), p, x ]
                }), Object(j.jsx)(u.i, Object(c.a)(Object(c.a)({
                    className: "content"
                }, N), {}, {
                    children: I
                })) ]
            }) ]
        });
    };
}, function(e, t, n) {
    "use strict";
    var c, r = n(18), a = n(10), i = n(9), u = n(16), s = n(13), o = n(1), l = n(27), j = n.n(l), b = n(6), O = n(30), d = n(2), f = n(5), g = n(41), M = n(20), m = n(14), p = n(15), x = n(4), I = n(0), N = [ "triVfKgIdO", "3yXTcVIwdM" ], h = function(e) {
        return N.includes(e);
    }, v = "⚡️ 超级推荐", D = "✅ 一般推荐", A = "🚫 不推荐", y = (c = {}, Object(O.a)(c, v, 100), 
    Object(O.a)(c, D, 10), Object(O.a)(c, A, 0), c), T = {
        0: [ v, D ],
        10: [ v, A ],
        100: [ D, A ]
    }, E = function() {
        return x.b.emit("OPEN_ADMIN");
    }, C = function() {
        var e = Object(s.a)(Object(a.a)().mark(function e(t, n, c) {
            var r, i;
            return Object(a.a)().wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (r = x.g.get("NEXUS_COOKIE")) {
                        e.next = 5;
                        break;
                    }
                    return e.next = 4, E();

                  case 4:
                    r = e.sent.cookie;

                  case 5:
                    return (i = Object(f.request)({
                        url: "https://nexus.sotake.net/api/m68".concat(t),
                        method: n,
                        data: c,
                        header: {
                            cookie: r
                        },
                        enableHttp2: !0,
                        mode: "no-cors"
                    }).then(function(e) {
                        var r = e.data, a = r.code, i = r.msg, u = r.data;
                        return 0 === a ? u : (Object(m.a)(i), "用户未登录" !== i ? Promise.reject() : E().then(function() {
                            C(t, n, c);
                        }));
                    })).catch(function(e) {
                        var t = e && (e.errMsg || e.message);
                        t && Object(m.a)(t);
                    }), e.abrupt("return", i);

                  case 8:
                  case "end":
                    return e.stop();
                }
            }, e);
        }));
        return function(t, n, c) {
            return e.apply(this, arguments);
        };
    }(), w = function(e) {
        return C("/post/update-score", "POST", e);
    }, S = Object(o.memo)(function() {
        var e = Object(o.useState)(!1), t = Object(b.a)(e, 2), n = t[0], c = t[1], r = Object(o.useRef)();
        Object(p.a)(Object(o.useCallback)(function() {
            return x.b.only("OPEN_ADMIN", function() {
                return new Promise(function(e) {
                    r.current = e, c(!0);
                });
            });
        }, []));
        var i = Object(o.useRef)({}), u = Object(o.useRef)(""), l = Object(o.useCallback)(function(e) {
            u.current = e;
        }, []), j = function() {
            var e = Object(s.a)(Object(a.a)().mark(function e() {
                return Object(a.a)().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        x.g.set("NEXUS_COOKIE", u.current), r.current({
                            cookie: u.current
                        }), i.current.setValue(""), c(!1);

                      case 4:
                      case "end":
                        return e.stop();
                    }
                }, e);
            }));
            return function() {
                return e.apply(this, arguments);
            };
        }();
        return Object(I.jsx)(M.a, {
            className: "report",
            visible: n,
            onClose: function() {
                return c(!1);
            },
            btnOk: Object(I.jsx)(d.a, {
                onClick: j,
                children: "提交"
            }),
            children: Object(I.jsx)(g.a, {
                ref: i,
                textarea: !0,
                value: u.current,
                onChange: l,
                placeholder: "Nexus Cookie"
            })
        });
    }), k = Object(I.jsx)(S, {}), L = n(25), _ = n(52), z = n(37), R = n(46), P = n(48), U = n(12), B = n(17), Q = n(40), Y = n(22), H = n(34), Z = n(24), F = n(31), K = n(11), G = n(8), V = n(53), W = n.n(V), J = n(92), X = n.n(J), q = (n(146), 
    Object(B.a)()), $ = q.safeBottomHeight, ee = q.platform, te = "说点什么...", ne = Object(o.createContext)({}), ce = function() {
        return Object(o.useContext)(ne);
    }, re = function(e) {
        return e > 140;
    }, ae = function(e) {
        var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, n = t.plusPrev;
        return e < 4 ? 4 : e < 10 ? n ? 10 : 6 : n ? e + 10 : 10;
    }, ie = function(e) {
        Object(f.hideKeyboard)(), "devtools" === ee && e(0);
    }, ue = Object(o.memo)(function(e) {
        var t = e.rowType, n = e.rowId, c = e.item, i = e.index, l = e.setRowReplies, j = c.comment_id, O = c.user, f = c.like_count, g = c.liked, M = c.text, m = c.created_at, p = c.reply_count, x = c.replies, N = c.to_user, h = c.reply_id, v = ce(), D = v.postMetaRef, A = v.onRowReply, y = v.onRowPress, T = v.onRowLike, E = v.onAddError, C = v.setScrollToId, w = D.current.top_id;
        Object(o.useEffect)(function() {
            !D.current.hasTopActiveDone && w && (D.current.hasTopActiveDone = !0, de(!0), setTimeout(fe, 1e3));
        }, [ D, w ]);
        var S = Object(o.useRef)(x || []), k = Object(K.a)("/reply/list", {
            params: {
                top_id: w,
                comment_id: j
            },
            manual: !0,
            loadMore: !0
        }), R = k.run, P = k.patch, U = k.mutate, B = Object(o.useRef)(!1), H = function(e) {
            return B.current ? P(e) : (B.current = !0, R(e));
        }, Z = Object(o.useState)(p || 0), F = Object(b.a)(Z, 2), G = F[0], V = F[1], J = Object(o.useState)(x || []), X = Object(b.a)(J, 2), q = X[0], $ = X[1], ee = Object(o.useRef)([]), te = Object(o.useRef)(0), ne = Object(o.useMemo)(function() {
            return "REPLY" === t ? l : function(e, t) {
                e && V(e), $(function(e) {
                    var n = ee.current.length > 0 ? t(e, ee, te) : t(e);
                    return U({
                        list: n
                    }), n;
                });
            };
        }, [ l, U, t ]), re = function() {
            var e = Object(s.a)(Object(a.a)().mark(function e() {
                var t, n, c, r;
                return Object(a.a)().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (!E.current) {
                            e.next = 2;
                            break;
                        }
                        return e.abrupt("return");

                      case 2:
                        if (0 !== (null === (t = ee.current) || void 0 === t ? void 0 : t.length)) {
                            e.next = 10;
                            break;
                        }
                        return e.next = 5, H({
                            count: ae(q.length)
                        });

                      case 5:
                        c = e.sent, r = c.list, n = [].concat(Object(u.a)(S.current), Object(u.a)(r)), e.next = 12;
                        break;

                      case 10:
                        te.current = ae(te.current, {
                            plusPrev: !0
                        }), n = ee.current.slice(0, te.current);

                      case 12:
                        $(n), C(n[n.length - 1].reply_id);

                      case 14:
                      case "end":
                        return e.stop();
                    }
                }, e);
            }));
            return function() {
                return e.apply(this, arguments);
            };
        }(), ie = O.user_id, ue = O.avatar_url, se = O.nickname, le = "User?user_id=".concat(ie), je = Object(o.useState)(!1), be = Object(b.a)(je, 2), Oe = be[0], de = be[1], fe = function() {
            return de(!1);
        }, ge = function() {
            E.current || (de(!0), A({
                nickname: se,
                index: i,
                comment_id: j,
                to_reply_id: h,
                setRowReplies: ne,
                removeRowActive: fe
            }));
        };
        return Object(I.jsxs)(d.i, {
            className: "row-item",
            id: "item_".concat(n),
            children: [ Object(I.jsxs)(d.i, {
                className: "row-body ".concat(Oe ? "active" : ""),
                onLongPress: function() {
                    E.current || (de(!0), y({
                        rowType: t,
                        rowId: n,
                        index: i,
                        user_id: ie,
                        nickname: se,
                        text: M,
                        replyTotal: G,
                        topRowRepliesRef: S,
                        removeRowActive: fe,
                        setRowReplies: ne
                    }));
                },
                children: [ ue ? Object(I.jsx)(L.a, {
                    img: ue,
                    onClick: function() {
                        return Object(Y.a)(le);
                    }
                }) : Object(I.jsx)(r.a, {
                    className: "avatar",
                    spin: !0
                }), Object(I.jsxs)(d.i, {
                    className: "row-middle",
                    children: [ N ? Object(I.jsxs)(d.i, {
                        className: "reply-users",
                        children: [ Object(I.jsx)(z.a, {
                            className: "user",
                            to: le,
                            children: se
                        }), Object(I.jsx)(d.b, {
                            className: "icon right-icon",
                            src: W.a
                        }), Object(I.jsx)(z.a, {
                            className: "user",
                            to: "User?user_id=".concat(N.user_id),
                            children: N.nickname
                        }) ]
                    }) : Object(I.jsx)(z.a, {
                        className: "user",
                        to: le,
                        children: se
                    }), Object(I.jsx)(d.i, {
                        className: "content",
                        onClick: ge,
                        children: M
                    }), Object(I.jsxs)(d.i, {
                        className: "meta",
                        children: [ Object(I.jsx)(d.g, {
                            className: "time",
                            children: Object(Q.a)(m)
                        }), Object(I.jsx)(d.g, {
                            className: "btn-reply",
                            onClick: ge,
                            children: "回复"
                        }) ]
                    }) ]
                }), Object(I.jsx)(_.b, {
                    liked: g,
                    count: f,
                    onClick: function() {
                        E.current || T({
                            rowType: t,
                            rowId: n,
                            index: i,
                            liked: g,
                            like_count: f,
                            setRowReplies: ne
                        });
                    }
                }) ]
            }), G > 0 && Object(I.jsxs)(I.Fragment, {
                children: [ q.length > 0 && Object(I.jsx)(oe, {
                    rowType: "REPLY",
                    list: q,
                    setRowReplies: ne
                }), q.length < G ? Object(I.jsxs)(d.i, {
                    className: "btn-expand",
                    onClick: re,
                    children: [ "查看", 0 === q.length ? " ".concat(G, " 条") : "更多", "回复" ]
                }) : Object(I.jsx)(d.i, {
                    className: "btn-expand",
                    onClick: function() {
                        E.current || (ee.current = q, te.current = 0, $([]));
                    },
                    children: "收起"
                }) ]
            }) ]
        });
    }), se = {
        COMMENT: {
            className: "comment-list",
            key: "comment_id"
        },
        REPLY: {
            className: "reply-list",
            key: "reply_id"
        }
    }, oe = Object(o.memo)(function(e) {
        var t = e.rowType, n = e.list, c = e.setRowReplies, r = se[t], a = r.className, i = r.key;
        return Object(I.jsx)(d.i, {
            className: a,
            children: n.map(function(e, n) {
                var r = e[i];
                return Object(I.jsx)(ue, {
                    rowType: t,
                    rowId: r,
                    item: e,
                    index: n,
                    setRowReplies: c
                }, r);
            })
        });
    }), le = Object(o.memo)(Object(o.forwardRef)(function(e, t) {
        var n = e.inputRef, c = e.textRef, r = e.onHeightListen, a = e.onAddSubmit, i = Object(o.useState)(!1), u = Object(b.a)(i, 2), s = u[0], l = u[1], j = Object(o.useCallback)(function(e) {
            c.current = e, l(e.length > 0);
        }, [ c ]), O = Object(o.useState)(!1), f = Object(b.a)(O, 2), g = f[0], M = f[1], m = Object(o.useState)(te), p = Object(b.a)(m, 2), x = p[0], N = p[1];
        Object(o.useImperativeHandle)(t, function() {
            return {
                setFocus: M,
                setPlaceholder: N
            };
        });
        var h = Object(o.useState)(0), v = Object(b.a)(h, 2), D = v[0], A = v[1], y = Object(o.useRef)(0), T = Object(o.useRef)(!1), E = Object(o.useCallback)(function(e) {
            var t = e.detail.height;
            if (t !== y.current && (y.current = t, !T.current)) {
                T.current = !0;
                var n = t > 0 ? t - $ : 0;
                A(n), r(n), setTimeout(function() {
                    T.current = !1;
                }, 200);
            }
        }, [ r ]);
        return Object(I.jsxs)(I.Fragment, {
            children: [ Object(I.jsx)(d.i, {
                className: "input-mask ".concat(g ? "show" : "hide"),
                onTouchStart: function() {
                    ie(r);
                }
            }), Object(I.jsxs)(d.i, {
                className: "input-bar",
                style: {
                    bottom: "".concat(D, "px")
                },
                children: [ Object(I.jsx)(R.a, {
                    ref: n,
                    textarea: !0,
                    value: c.current,
                    onChange: j,
                    focus: g,
                    onClick: function() {
                        return M(!0);
                    },
                    onKeyboardHeightChange: E,
                    toShowCounter: re,
                    placeholder: x,
                    holdKeyboard: !0,
                    autoHeight: !0,
                    counter: !0,
                    fixed: !0
                }), Object(I.jsx)(d.a, {
                    className: "btn-dark btn-comment",
                    disabled: !s,
                    onClick: a,
                    children: Object(I.jsx)(d.b, {
                        className: "icon",
                        src: X.a
                    })
                }, "submit") ]
            }) ]
        });
    })), je = Object(o.memo)(function() {
        var e = G.a.account, t = G.a.itsMe, n = Object(o.useRef)({}), c = Object(K.a)("/comment/timeline/list", {
            manual: !0,
            loadMore: !0,
            initialData: {
                list: []
            },
            formatResult: function(e) {
                e.hot_comments && (e.list = e.hot_comments.concat(e.list));
                var t = [];
                return e.list.forEach(function(e) {
                    n.current[e.comment_id] || (n.current[e.comment_id] = !0, t.push(e));
                }), Object(i.a)(Object(i.a)({}, e), {}, {
                    list: t
                });
            }
        }), l = c.loading, j = c.data, O = c.run, f = c.patch, g = c.mutate, N = j.list, h = Object(o.useState)(0), v = Object(b.a)(h, 2), D = v[0], A = v[1], y = Object(o.useRef)({}), T = Object(o.useRef)({}), E = Object(o.useRef)(""), C = Object(o.useRef)({}), w = Object(o.useState)(!1), S = Object(b.a)(w, 2), k = S[0], L = S[1];
        Object(p.a)(Object(o.useCallback)(function() {
            return x.b.only("OPEN_COMMENT", function(e) {
                var t = e.post_id, c = e.comment_count, r = e.top_id, a = e.isMyPost;
                A(+c), L(!0);
                var i = !(+c > 0);
                i && setTimeout(function() {
                    y.current.setFocus(!0);
                });
                var u = C.current.post_id;
                t !== u && (C.current = {
                    top_id: r,
                    post_id: t,
                    isMyPost: a,
                    hasTopActiveDone: !1
                }, u && g(), i || setTimeout(function() {
                    n.current = {}, O({
                        post_id: t,
                        top_id: r
                    });
                }, 200));
            });
        }, [ g, O ]));
        var _ = Object(o.useState)(!1), z = Object(b.a)(_, 2), R = z[0], B = z[1], Q = Object(o.useRef)(!1), Y = Object(o.useRef)(!1), V = Object(o.useRef)({}), W = Object(o.useState)(0), J = Object(b.a)(W, 2), X = J[0], q = J[1], $ = Object(o.useState)(null), ee = Object(b.a)($, 2), ce = ee[0], re = ee[1], ae = Object(o.useCallback)(function(e) {
            var t = e.nickname, n = e.index, c = e.comment_id, r = e.to_reply_id, a = e.setRowReplies, i = e.removeRowActive;
            Y.current = !0;
            var u = V.current, s = u.comment_id, o = u.to_reply_id;
            c === s && r === o || (T.current.setValue(""), V.current = {
                index: n,
                comment_id: c,
                to_reply_id: r,
                setRowReplies: a,
                removeRowActive: i
            }), y.current.setFocus(!0), setTimeout(function() {
                y.current.setPlaceholder("回复 @".concat(t));
            }, 100);
        }, []), ue = Object(o.useCallback)(function() {
            var e = Object(s.a)(Object(a.a)().mark(function e(t) {
                var n, c, r, s, o, l, j, b, O, d, f;
                return Object(a.a)().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return n = t.rowType, c = t.rowId, r = t.index, s = t.liked, o = t.like_count, l = t.setRowReplies, 
                        j = {
                            type: n,
                            id: c,
                            liked: s,
                            like_count: o
                        }, e.next = 4, x.b.emit("LIKE_POST", j);

                      case 4:
                        if (b = e.sent, O = b.newLike, d = b.newCount, f = {
                            liked: O,
                            like_count: d
                        }, "COMMENT" !== n) {
                            e.next = 11;
                            break;
                        }
                        return g(function(e) {
                            var t = e.list;
                            return t[r] = Object(i.a)(Object(i.a)({}, t[r]), f), {
                                list: Object(u.a)(t)
                            };
                        }), e.abrupt("return");

                      case 11:
                        l(null, function(e, t) {
                            var n = e[r], c = Object(i.a)(Object(i.a)({}, n), f);
                            return e[r] = c, t && (t.current[r] = c), Object(u.a)(e);
                        });

                      case 12:
                      case "end":
                        return e.stop();
                    }
                }, e);
            }));
            return function(t) {
                return e.apply(this, arguments);
            };
        }(), [ g ]), se = Object(K.b)("/comment/delete", {
            manual: !0
        }).run, je = Object(K.b)("/reply/delete", {
            manual: !0
        }).run, be = function(e) {
            var t = C.current.post_id;
            A(function(t) {
                return t + e;
            }), Object(U.f)("postMap", t, function(t) {
                return t.comment_count += e;
            });
        }, Oe = Object(o.useCallback)(function() {
            var e = Object(s.a)(Object(a.a)().mark(function e(n) {
                var c, r, i, o, l, j, b, O, d, f, M, p, I, N, h;
                return Object(a.a)().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        c = n.rowType, r = n.rowId, i = n.index, o = n.user_id, l = n.nickname, j = n.text, 
                        b = n.replyTotal, O = n.topRowRepliesRef, d = n.removeRowActive, f = n.setRowReplies, 
                        Object(Z.a)(), M = C.current, p = M.top_id, I = M.isMyPost, h = t(o), N = h ? [ "复制评论", "删除" ] : I ? [ "复制评论", "举报", "删除" ] : [ "复制评论", "举报" ], 
                        x.b.emit("OPEN_MENU", {
                            list: N
                        }).then(function(e) {
                            switch (e) {
                              case "复制评论":
                                return Object(H.a)("@".concat(l, "：").concat(j)), void d();

                              case "举报":
                                return x.b.emit("OPEN_REPORT", {
                                    type: c,
                                    id: r
                                }), void d();

                              case "删除":
                                return void x.b.emit("OPEN_MENU", {
                                    title: b > 0 ? "评论下所有回复也将删除" : "",
                                    list: [ "确认删除" ]
                                }).then(Object(s.a)(Object(a.a)().mark(function e() {
                                    return Object(a.a)().wrap(function(e) {
                                        for (;;) switch (e.prev = e.next) {
                                          case 0:
                                            if (Object(m.a)("已删除"), d(), "COMMENT" !== c) {
                                                e.next = 9;
                                                break;
                                            }
                                            return e.next = 5, se({
                                                top_id: p,
                                                comment_id: r
                                            });

                                          case 5:
                                            return g(function(e) {
                                                var t = e.list;
                                                return t.splice(i, 1), {
                                                    list: Object(u.a)(t)
                                                };
                                            }), be(-(1 + b)), e.abrupt("return");

                                          case 9:
                                            return e.next = 11, je({
                                                top_id: p,
                                                reply_id: r
                                            });

                                          case 11:
                                            f(function(e) {
                                                return e - 1;
                                            }, function(e, t, n) {
                                                return e.splice(i, 1), t && (t.current.splice(i, 1), n.current--), Object(u.a)(e);
                                            }), be(-1), r === p && O.current.length > 0 && (O.current = []);

                                          case 14:
                                          case "end":
                                            return e.stop();
                                        }
                                    }, e);
                                }))).catch(d);
                            }
                        }).catch(d);

                      case 6:
                      case "end":
                        return e.stop();
                    }
                }, e);
            }));
            return function(t) {
                return e.apply(this, arguments);
            };
        }(), [ se, g, t, je ]), de = Object(o.useCallback)(function(e) {
            0 === e && y.current.setFocus(!1), Y.current && (e > 0 ? (q(e), setTimeout(function() {
                var e = V.current, t = e.to_reply_id, n = e.comment_id;
                re(t || n);
            }, 200)) : ((0, V.current.removeRowActive)(), V.current = {}, q(0), re(null), setTimeout(function() {
                y.current.setPlaceholder(te);
            }, 100), Y.current = !1));
        }, []), fe = Object(o.useRef)(null), ge = Object(K.b)("/comment/create", {
            manual: !0,
            onError: fe.current
        }).run, Me = Object(K.b)("/reply/create", {
            manual: !0,
            onError: fe.current
        }).run, me = Object(o.useCallback)(Object(s.a)(Object(a.a)().mark(function t() {
            var n, c, r, s, o, l, j, b, O, d, f, M, m, p;
            return Object(a.a)().wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (!fe.current) {
                        t.next = 2;
                        break;
                    }
                    return t.abrupt("return");

                  case 2:
                    if (!Object(F.a)(E.current, {
                        required: !0
                    })) {
                        t.next = 4;
                        break;
                    }
                    return t.abrupt("return");

                  case 4:
                    if (n = C.current, c = n.top_id, r = n.post_id, s = E.current, o = Object(i.a)(Object(i.a)({}, e), {}, {
                        nickname: "我"
                    }), Y.current) {
                        t.next = 21;
                        break;
                    }
                    return ie(de), l = {
                        post_id: r,
                        comment_id: "new_comment",
                        text: s,
                        user: o,
                        created_at: Date()
                    }, T.current.setValue(""), g(function(e) {
                        var t = e.list;
                        return {
                            list: [ l ].concat(Object(u.a)(t))
                        };
                    }), be(1), re(l.comment_id), fe.current = function() {
                        T.current.setValue(s), g(function(e) {
                            return {
                                list: e.list.slice(1)
                            };
                        }), be(-1), fe.current = null;
                    }, t.next = 17, ge({
                        top_id: c,
                        post_id: r,
                        text: s
                    });

                  case 17:
                    return j = t.sent, g(function(e) {
                        var t = e.list;
                        return {
                            list: [ j ].concat(Object(u.a)(t.slice(1)))
                        };
                    }), fe.current = null, t.abrupt("return");

                  case 21:
                    return b = V.current, O = b.index, d = b.comment_id, f = b.to_reply_id, M = b.setRowReplies, 
                    ie(de), m = {
                        post_id: r,
                        comment_id: d,
                        reply_id: "new_reply",
                        text: s,
                        user: o,
                        created_at: Date()
                    }, T.current.setValue(""), M(function(e) {
                        return e + 1;
                    }, function(e, t, n) {
                        var c = f ? O : 0;
                        return e.splice(c, 0, m), t && (t.current.splice(c, 0, m), n.current++), Object(u.a)(e);
                    }), be(1), fe.current = function() {
                        Y.current = !0, V.current = b, T.current.setValue(s), M(function(e) {
                            return e - 1;
                        }, function(e, t, n) {
                            var c = f ? O : 0;
                            return e.splice(c, 1), t && (t.current.splice(c, 1), n.current--), Object(u.a)(e);
                        }), be(-1), fe.current = null;
                    }, t.next = 31, Me({
                        top_id: c,
                        post_id: r,
                        text: s,
                        comment_id: d,
                        to_reply_id: f
                    });

                  case 31:
                    p = t.sent, M(null, function(e, t) {
                        var n = f ? O : 0;
                        return e.splice(n, 1, p), t && t.current.splice(n, 1, p), Object(u.a)(e);
                    }), fe.current = null;

                  case 34:
                  case "end":
                    return t.stop();
                }
            }, t);
        })), [ e, ge, g, de, Me ]), pe = Object(o.useMemo)(function() {
            return {
                postMetaRef: C,
                onRowReply: ae,
                onRowPress: Oe,
                onRowLike: ue,
                onAddError: fe,
                setScrollToId: re
            };
        }, [ ue, Oe, ae ]);
        return Object(I.jsxs)(M.a, {
            className: "comment",
            visible: k,
            onClose: function() {
                return L(!1);
            },
            stopClose: R,
            title: "".concat(D > 0 ? "".concat(D, " 条") : "", "评论"),
            children: [ Object(I.jsxs)(P.a, {
                style: X ? {
                    paddingBottom: X
                } : void 0,
                stopClose: R,
                setStopClose: B,
                scrollWithAnimation: !0,
                scrollIntoView: "item_".concat(ce),
                onReachBottom: function() {
                    if (R && !Q.current) {
                        Q.current = !0;
                        var e = C.current, t = e.top_id, n = e.post_id;
                        f({
                            top_id: t,
                            post_id: n
                        }).finally(function() {
                            Q.current = !1;
                        });
                    }
                },
                children: [ l && Object(I.jsx)(r.a, {}), D > 0 ? Object(I.jsx)(ne.Provider, {
                    value: pe,
                    children: Object(I.jsx)(oe, {
                        rowType: "COMMENT",
                        list: N
                    })
                }) : Object(I.jsx)(d.i, {
                    className: "empty-tip",
                    children: "添加第一条评论"
                }) ]
            }), Object(I.jsx)(le, {
                ref: y,
                inputRef: T,
                textRef: E,
                onHeightListen: de,
                onAddSubmit: me
            }) ]
        });
    }), be = Object(I.jsx)(je, {}), Oe = n(23), de = n(93), fe = n.n(de), ge = (n(147), 
    [ "icon" ]), Me = [ "放弃", "删除", "确认删除", "取消关注" ], me = {
        "分享名片给朋友": {
            openType: "share",
            icon: fe.a
        },
        "获取帮助": {
            openType: "contact"
        },
        "意见反馈": {
            openType: "feedback"
        }
    }, pe = Object(o.memo)(function() {
        var e = Object(o.useState)(!1), t = Object(b.a)(e, 2), n = t[0], c = t[1], r = Object(o.useRef)(!1), a = Object(o.useRef)(!1), u = Object(o.useRef)(function() {}), s = Object(o.useCallback)(function(e) {
            if (r.current) return a.current = !0, void (u.current = e);
            e(), c(!0);
        }, []), l = function() {
            r.current = !0, c(!1), setTimeout(function() {
                r.current = !1, a.current && (a.current = !1, u.current(), c(!0));
            }, 250);
        }, j = Object(o.useState)(""), O = Object(b.a)(j, 2), f = O[0], g = O[1], m = Object(o.useState)([]), N = Object(b.a)(m, 2), h = N[0], v = N[1], D = Object(o.useRef)(), A = Object(o.useRef)(), y = function() {
            l(), A.current();
        };
        return Object(p.a)(Object(o.useCallback)(function() {
            return x.b.only("OPEN_MENU", function(e) {
                var t = e.title, n = void 0 === t ? "" : t, c = e.list;
                return new Promise(function(e, t) {
                    D.current = e, A.current = t, s(function() {
                        g(n), v(c);
                    });
                });
            });
        }, [ s ])), Object(I.jsxs)(M.a, {
            className: "menu",
            type: "list",
            visible: n,
            onClose: y,
            children: [ Object(I.jsxs)(d.i, {
                className: "menu-list",
                children: [ "" !== f && Object(I.jsx)(d.i, {
                    className: "menu-item menu-title",
                    children: f
                }), h.map(function(e) {
                    var t = me[e] || {}, n = t.icon, c = Object(Oe.a)(t, ge);
                    return Object(I.jsxs)(d.a, Object(i.a)(Object(i.a)({
                        className: "menu-item ".concat(Me.includes(e) ? "red" : ""),
                        onClick: function() {
                            return function(e) {
                                l(), D.current(e);
                            }(e);
                        }
                    }, c), {}, {
                        children: [ n && Object(I.jsx)(d.b, {
                            src: n
                        }), e ]
                    }), e);
                }) ]
            }), Object(I.jsx)(d.a, {
                className: "menu-item menu-close",
                onClick: y,
                children: "取消"
            }) ]
        });
    }), xe = Object(I.jsx)(pe, {}), Ie = function e() {
        return x.f.isSystemModal = !0, Object(f.chooseLocation)().then(function(e) {
            return e.name ? e : Promise.reject();
        }).catch(function(t) {
            return function(e) {
                var t = e.err, n = e.scope, c = e.title, r = e.desc, a = e.success;
                if (!t || t.errMsg.includes("cancel")) return Promise.reject();
                var i = "scope.".concat(n);
                return Object(f.getSetting)().then(function(e) {
                    return e.authSetting[i] ? a() : Object(f.authorize)({
                        scope: i
                    }).then(function() {
                        return a();
                    }).catch(function() {
                        return Object(f.showModal)({
                            title: c,
                            content: r
                        }).then(function(e) {
                            return e.confirm ? Object(f.openSetting)().then(function(e) {
                                return e.authSetting[i] ? a() : (Object(m.a)("未授权"), Promise.reject());
                            }) : (Object(m.a)("未授权"), Promise.reject());
                        });
                    });
                });
            }({
                err: t,
                scope: "userLocation",
                title: "请授权位置信息",
                desc: "作品中展示",
                success: function() {
                    return e();
                }
            });
        });
    }, Ne = function() {
        return x.f.isSystemModal = !0, Object(f.chooseImage)({
            count: 1,
            sizeType: [ "compressed" ],
            sourceType: [ "album" ]
        }).then(function(e) {
            var t = e.tempFilePaths, n = Object(b.a)(t, 1)[0];
            return /\.gif$/i.test(n) ? (Object(m.a)("暂不支持 .gif"), Promise.reject()) : n;
        });
    }, he = n(59), ve = new RegExp("(\\s|^)".concat(x.a, "(?=\\s|$)"), "g"), De = function(e) {
        var t;
        return null === (t = e.match(ve)) || void 0 === t ? void 0 : t.map(function(e) {
            return e.replace(/\s?#/, "");
        });
    }, Ae = n(42), ye = n(47), Te = n.n(ye), Ee = n(94), Ce = n.n(Ee), we = n(95), Se = n.n(we), ke = n(96), Le = n.n(ke), _e = n(97), ze = n.n(_e), Re = (n(148), 
    function(e) {
        return e >= 135;
    }), Pe = Object(o.memo)(function() {
        var e, t = G.a.account, n = G.a.publishData, c = G.a.setPublishData, r = G.a.clearPublishData, u = Object(o.useState)(!1), l = Object(b.a)(u, 2), j = l[0], O = l[1], g = Object(o.useState)(!1), m = Object(b.a)(g, 2), N = m[0], h = m[1], v = function() {
            return O(!0);
        }, D = function() {
            return O(!1);
        }, A = function() {
            return h(!0);
        }, y = n.img, T = n.text, E = n.location, C = Object(o.useRef)(n);
        C.current = n, Object(p.a)(Object(o.useCallback)(function() {
            var e = x.b.only("CLICK_PUBLISH", Object(s.a)(Object(a.a)().mark(function e() {
                var t;
                return Object(a.a)().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (0 !== Object.keys(C.current).length) {
                            e.next = 5;
                            break;
                        }
                        return e.next = 3, Ne();

                      case 3:
                        t = e.sent, c({
                            img: t
                        });

                      case 5:
                        v(), setTimeout(function() {
                            A();
                        }, 250);

                      case 7:
                      case "end":
                        return e.stop();
                    }
                }, e);
            }))), t = x.b.only("PRESS_PUBLISH", v), n = x.b.only("LEAVE_PUBLISH", A);
            return function() {
                e(), t(), n();
            };
        }, [ c ]));
        var w = Object(o.useRef)({}), S = Object(o.useRef)(T);
        Object(o.useEffect)(function() {
            "string" == typeof T && S.current !== T && (S.current = T, w.current.setValue(T));
        }, [ T ]);
        var k = Object(o.useState)((null === (e = S.current) || void 0 === e ? void 0 : e.length) > 0), L = Object(b.a)(k, 2), _ = L[0], z = L[1], P = Object(o.useCallback)(function(e) {
            S.current = e, z((null == e ? void 0 : e.length) > 0);
        }, []), B = function() {
            w.current.setValue(""), r();
        }, Q = function() {
            Object(f.hideKeyboard)(), h(!1);
        }, Y = Object(o.useState)(1), H = Object(b.a)(Y, 2), V = H[0], W = H[1], J = Object(o.useState)(!1), X = Object(b.a)(J, 2), q = X[0], $ = X[1], ee = function() {
            var e = Object(s.a)(Object(a.a)().mark(function e() {
                var t;
                return Object(a.a)().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return e.next = 2, Ne();

                      case 2:
                        t = e.sent, c({
                            img: t,
                            text: S.current
                        });

                      case 4:
                      case "end":
                        return e.stop();
                    }
                }, e);
            }));
            return function() {
                return e.apply(this, arguments);
            };
        }(), te = function() {
            var e = Object(s.a)(Object(a.a)().mark(function e() {
                var t;
                return Object(a.a)().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return e.next = 2, Ie();

                      case 2:
                        t = e.sent, c({
                            location: t,
                            text: S.current
                        });

                      case 4:
                      case "end":
                        return e.stop();
                    }
                }, e);
            }));
            return function() {
                return e.apply(this, arguments);
            };
        }(), ne = function() {
            var e = Object(s.a)(Object(a.a)().mark(function e() {
                return Object(a.a)().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        Q(), D(), S.current || y || E ? S.current && c({
                            text: S.current
                        }) : B();

                      case 3:
                      case "end":
                        return e.stop();
                    }
                }, e);
            }));
            return function() {
                return e.apply(this, arguments);
            };
        }(), ce = function() {
            G.a.publishStatus = "";
        }, re = Object(K.c)({
            type: "post",
            onError: ce
        }).run, ae = Object(K.b)("/post/publish", {
            manual: !0,
            onError: ce
        }).run, ie = function() {
            var e = Object(s.a)(Object(a.a)().mark(function e() {
                var n, r, u, s;
                return Object(a.a)().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (!Object(F.a)(S.current)) {
                            e.next = 2;
                            break;
                        }
                        return e.abrupt("return");

                      case 2:
                        return Q(), D(), e.next = 6, new Promise(function(e) {
                            return setTimeout(e, 150);
                        });

                      case 6:
                        if (Object(Ae.a)("Follow"), G.a.publishStatus = "active", n = E ? {
                            location: E
                        } : {}, S.current && (c({
                            text: S.current
                        }), n.text = S.current.replace(/(\n)+/g, "$1"), (r = De(n.text)) && (n.tags = r)), 
                        !y) {
                            e.next = 15;
                            break;
                        }
                        return e.next = 13, re(y);

                      case 13:
                        u = e.sent, n.img_list = [ u ];

                      case 15:
                        return e.next = 17, ae(n);

                      case 17:
                        s = e.sent, x.g.set("LAST_PUBLISH", Object(i.a)(Object(i.a)({}, s), {}, {
                            tmpImg: y
                        })), B(), Object(U.c)("postMap", s.post_id, s), Object(U.f)("userMap", t.user_id, function(e) {
                            "number" == typeof e.post_count && e.post_count++;
                        }), x.b.trigger("ADD_MY_WORK", s), G.a.publishStatus = "success", x.b.emit("REFRESH_FOLLOW"), 
                        Object(Z.a)(), setTimeout(function() {
                            G.a.publishStatus = "";
                        }, 1e3);

                      case 27:
                      case "end":
                        return e.stop();
                    }
                }, e);
            }));
            return function() {
                return e.apply(this, arguments);
            };
        }();
        return Object(I.jsxs)(M.a, {
            className: "publish",
            type: "full",
            visible: j,
            onClose: ne,
            onClick: Q,
            stopClose: q,
            children: [ Object(I.jsxs)(d.i, {
                className: "post-box",
                style: {
                    "--ratio": "".concat(V)
                },
                catchMove: !0,
                children: [ y && Object(I.jsxs)(d.i, {
                    className: "preview-box ".concat(q ? "zoom" : "thumb"),
                    onTouchEnd: function(e) {
                        e.stopPropagation(), $(function(e) {
                            return !e;
                        });
                    },
                    children: [ Object(I.jsx)(d.i, {
                        className: "preview-img",
                        children: Object(I.jsx)(d.b, {
                            src: y,
                            onLoad: function(e) {
                                var t = e.detail, n = t.width, c = t.height, r = Object(he.a)(n, c);
                                W(r);
                            },
                            mode: "widthFix"
                        })
                    }), Object(I.jsxs)(d.i, {
                        className: "preview-footer",
                        children: [ Object(I.jsx)(d.a, {
                            className: "btn btn-del",
                            onClick: function() {
                                c({
                                    img: void 0,
                                    text: S.current
                                }), $(!1), W(1);
                            },
                            children: "删除"
                        }), Object(I.jsx)(d.a, {
                            className: "btn btn-switch",
                            onClick: ee,
                            children: "更换"
                        }) ]
                    }) ]
                }), Object(I.jsx)(R.a, {
                    textarea: !0,
                    ref: w,
                    className: "text-input",
                    value: S.current,
                    onChange: P,
                    onClick: function(e) {
                        e.stopPropagation();
                    },
                    toShowCounter: Re,
                    placeholder: "说点什么...",
                    focus: N,
                    holdKeyboard: !0,
                    autoHeight: !0,
                    counter: !0
                }) ]
            }), Object(I.jsx)(d.i, {
                className: "geo-row",
                children: (null == E ? void 0 : E.name) && Object(I.jsxs)(d.i, {
                    className: "geo-display",
                    onClick: te,
                    children: [ Object(I.jsx)(d.b, {
                        className: "icon geo-icon",
                        src: Se.a
                    }), Object(I.jsx)(d.g, {
                        children: E.name
                    }), Object(I.jsx)(d.b, {
                        className: "icon del-icon",
                        src: Te.a,
                        onClick: function(e) {
                            e.stopPropagation(), c({
                                location: void 0,
                                text: S.current
                            });
                        }
                    }) ]
                })
            }), Object(I.jsxs)(d.i, {
                className: "submit-bar",
                children: [ Object(I.jsxs)(d.i, {
                    className: "btn-picker img-picker",
                    onClick: ee,
                    children: [ Object(I.jsx)(d.b, {
                        className: "icon",
                        src: Le.a
                    }), Object(I.jsx)(d.g, {
                        children: "照片"
                    }) ]
                }), Object(I.jsxs)(d.i, {
                    className: "btn-picker geo-picker",
                    onClick: te,
                    children: [ Object(I.jsx)(d.b, {
                        className: "icon",
                        src: Ce.a
                    }), Object(I.jsx)(d.g, {
                        children: "位置"
                    }) ]
                }), Object(I.jsxs)(d.i, {
                    className: "btn-picker tag-picker",
                    onClick: function(e) {
                        e.stopPropagation();
                        var t = S.current;
                        w.current.setValue(t ? "".concat(t.trim(), " #") : "#"), A();
                    },
                    children: [ Object(I.jsx)(d.b, {
                        className: "icon",
                        src: ze.a
                    }), Object(I.jsx)(d.g, {
                        children: "标签"
                    }) ]
                }), Object(I.jsx)(d.a, {
                    className: "btn btn-lg btn-dark btn-publish",
                    disabled: 0 === (null == y ? void 0 : y.length) && !_,
                    onClick: ie,
                    children: "发送"
                }) ]
            }) ]
        });
    }), Ue = Object(I.jsx)(Pe, {}), Be = (n(149), {
        USER: [ 1, "用户" ],
        POST: [ 2, "作品" ],
        COMMENT: [ 3, "评论" ],
        REPLY: [ 4, "回复" ]
    }), Qe = Object(o.memo)(function() {
        var e = Object(o.useState)(!1), t = Object(b.a)(e, 2), n = t[0], c = t[1], r = Object(o.useState)(!1), i = Object(b.a)(r, 2), u = i[0], l = i[1], j = function() {
            c(!0);
        }, O = function() {
            c(!1), l(!1);
        }, f = Object(o.useRef)({}), N = Object(o.useState)(""), h = Object(b.a)(N, 2), v = h[0], D = h[1];
        Object(p.a)(Object(o.useCallback)(function() {
            return x.b.only("OPEN_REPORT", function(e) {
                var t = e.type, n = e.id, c = Object(b.a)(Be[t], 2), r = c[0], a = c[1];
                n !== f.current.content_id && (f.current = {
                    content_type: r,
                    content_id: n,
                    reason: ""
                }, D(a)), j(), setTimeout(function() {
                    l(!0);
                }, 100);
            });
        }, []));
        var A = Object(o.useRef)({}), y = Object(o.useState)(!1), T = Object(b.a)(y, 2), E = T[0], C = T[1], w = Object(o.useCallback)(function(e) {
            f.current.reason = e, C(e.length > 0);
        }, []), S = Object(K.b)("/report/submit", {
            manual: !0
        }), k = S.loading, L = S.run, _ = function() {
            var e = Object(s.a)(Object(a.a)().mark(function e() {
                return Object(a.a)().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (!Object(F.a)(f.current.reason, {
                            required: !0
                        })) {
                            e.next = 2;
                            break;
                        }
                        return e.abrupt("return");

                      case 2:
                        return e.next = 4, L(f.current);

                      case 4:
                        Object(m.a)("已提交"), A.current.setValue(""), O();

                      case 7:
                      case "end":
                        return e.stop();
                    }
                }, e);
            }));
            return function() {
                return e.apply(this, arguments);
            };
        }();
        return Object(I.jsx)(M.a, {
            className: "report",
            visible: n,
            onClose: O,
            title: "举报".concat(v),
            btnOk: Object(I.jsx)(d.a, {
                disabled: !E,
                loading: k,
                onClick: _,
                children: "提交"
            }),
            children: Object(I.jsx)(g.a, {
                ref: A,
                textarea: !0,
                label: "举报原因",
                value: f.current.reason,
                onChange: w,
                placeholder: "请描述举报原因",
                focus: u,
                counter: !0
            })
        });
    }), Ye = Object(I.jsx)(Qe, {}), He = n(28), Ze = n(49), Fe = {}, Ke = function(e, t) {
        var n = Object(o.useRef)();
        n.current || (n.current = "".concat(e, "\n").concat(t));
        var c = Object(o.useRef)(e), r = Object(o.useRef)(t);
        c.current = e, r.current = t, Object(o.useEffect)(function() {
            if (!(n.current in Fe)) return Fe[n.current] = !0, c.current(), function() {
                r.current();
            };
        }, []), Object(f.onAppHide)(function() {
            x.f.isSystemModal || !0 === Fe[n.current] && (Fe[n.current] = !1, setTimeout(function() {
                r.current();
            }));
        }), Object(f.onAppShow)(function() {
            x.f.isSystemModal ? x.f.isSystemModal = !1 : !1 === Fe[n.current] && (Fe[n.current] = !0, 
            setTimeout(function() {
                c.current();
            }));
        });
    }, Ge = n(45), Ve = {
        POST: 1,
        COMMENT: 2,
        REPLY: 3
    }, We = [ "discover", "follow", "post", "posts" ], Je = function(e) {
        var t = e.className, n = e.isTabBar, c = e.children, r = G.a.account, l = G.a.setPublishData, b = We.includes(t);
        Ke(function() {
            "Notify" !== Object(He.a)() && x.d.notifyRun();
        }, function() {
            clearTimeout(x.e.resumePollingTimer), x.d.notifyCancel();
        });
        var O = Object(Ge.a)(), d = h(r.user_id), f = Object(K.b)("/post/delete", {
            manual: !0
        }).run;
        Object(p.a)(Object(o.useCallback)(function() {
            return x.b.only("OPEN_MORE", function() {
                var e = Object(s.a)(Object(a.a)().mark(function e(t) {
                    var n, c, s, o, b, g, M, p, I, N, h;
                    return Object(a.a)().wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            return n = t.post_id, c = t.score, s = t.firstImg, o = t.text, b = t.location, g = t.isMyPost, 
                            M = t.isSingle, p = [ g ? "删除" : "举报" ], o && p.unshift("复制内容"), s && p.unshift("查看原图"), 
                            d && p.push.apply(p, Object(u.a)(T[c])), e.next = 7, x.b.emit("OPEN_MENU", {
                                list: p
                            });

                          case 7:
                            I = e.sent, e.t0 = I, e.next = "查看原图" === e.t0 ? 11 : "复制内容" === e.t0 ? 13 : "举报" === e.t0 ? 15 : "删除" === e.t0 ? 17 : 33;
                            break;

                          case 11:
                            return Object(Ze.a)(s), e.abrupt("return");

                          case 13:
                            return Object(H.a)(o), e.abrupt("return");

                          case 15:
                            return x.b.emit("OPEN_REPORT", {
                                type: "POST",
                                id: n
                            }), e.abrupt("return");

                          case 17:
                            return e.next = 19, x.b.emit("OPEN_MENU", {
                                title: "删除此作品",
                                list: [ "确认删除" ]
                            });

                          case 19:
                            return e.next = 21, f({
                                post_id: n
                            });

                          case 21:
                            return N = x.g.get("LAST_PUBLISH"), n === (null == N ? void 0 : N.post_id) && j()().diff(j()(N.created_at), "second") < 30 && l({
                                img: N.tmpImg,
                                text: o,
                                location: b
                            }), Object(Z.a)(), x.b.trigger("DEL_FEED_POST", n), x.b.trigger("DEL_TAGGED_POST", n), 
                            x.b.trigger("DEL_LIKED_POST", n), x.b.trigger("DEL_MY_WORK", n), x.b.trigger("DEL_MY_LIKE", n), 
                            Object(U.f)("userMap", r.user_id, function(e) {
                                "number" == typeof e.post_count && e.post_count--;
                            }), Object(G.a)("postMap", function(e) {
                                return delete e[n], Object(i.a)({}, e);
                            }), M && O(), e.abrupt("return");

                          case 33:
                            if ("number" == typeof (h = y[I])) {
                                e.next = 36;
                                break;
                            }
                            return e.abrupt("return");

                          case 36:
                            return e.next = 38, w({
                                post_id: n,
                                score: h
                            });

                          case 38:
                            return Object(m.a)(I), Object(U.f)("postMap", n, function(e) {
                                e.score = h;
                            }), e.abrupt("return");

                          case 41:
                          case "end":
                            return e.stop();
                        }
                    }, e);
                }));
                return function(t) {
                    return e.apply(this, arguments);
                };
            }());
        }, [ r.user_id, d, O, f ]));
        var g = Object(o.useRef)(!1), M = Object(K.b)("/like/set_like", {
            manual: !0
        }).run, N = Object(K.b)("/like/cancel_like", {
            manual: !0
        }).run;
        return Object(p.a)(Object(o.useCallback)(function() {
            return x.b.only("LIKE_POST", function() {
                var e = Object(s.a)(Object(a.a)().mark(function e(t) {
                    var n, c, r, i, u, s, o, l;
                    return Object(a.a)().wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            if (g.current) {
                                e.next = 10;
                                break;
                            }
                            return g.current = !0, n = t.type, c = t.id, r = t.liked, i = t.like_count, u = void 0 === i ? 0 : i, 
                            o = (s = !r) ? u + 1 : u - 1, s && Object(Z.a)(), (l = (r ? N : M)({
                                object_type: Ve[n],
                                object_id: c
                            }).then(function() {
                                return g.current = !1, "POST" === n && Object(U.f)("postMap", c, function(e) {
                                    e.is_liked = s, e.like_count = o, x.b.trigger("ADD_MY_LIKE", e);
                                }), {
                                    newLike: s,
                                    newCount: o
                                };
                            })).catch(function() {
                                g.current = !1, "POST" === n && Object(U.f)("postMap", c, function(e) {
                                    e.is_liked = r, e.like_count = u, x.b.trigger("ADD_MY_LIKE", e);
                                });
                            }), e.abrupt("return", l);

                          case 10:
                          case "end":
                            return e.stop();
                        }
                    }, e);
                }));
                return function(t) {
                    return e.apply(this, arguments);
                };
            }());
        }, [ M, N ])), Object(I.jsxs)(I.Fragment, {
            children: [ c, n && Ue, b && Object(I.jsxs)(I.Fragment, {
                children: [ be, d && k ]
            }), (b || "user" === t) && Ye, xe ]
        });
    }, Xe = n(26), qe = n(98), $e = n.n(qe), et = (n(150), Object(B.a)()).topCssVar, tt = [ "https://sotake-futake.oss-cn-beijing.aliyuncs.com/triVfKgIdO/14730f96a68708743ffc56d447fc8426.jpg", "https://sotake-futake.oss-cn-beijing.aliyuncs.com/triVfKgIdO/e0dec09a16f458696754d0fbe2c0b355.jpg", "https://sotake-futake.oss-cn-beijing.aliyuncs.com/triVfKgIdO/9a381f8da8ddc479d0715dbf38d69dfc.jpg", "https://sotake-futake.oss-cn-beijing.aliyuncs.com/triVfKgIdO/4319554486e117334b9935f41b8d0080.jpg", "https://sotake-futake.oss-cn-beijing.aliyuncs.com/triVfKgIdO/2d5c0c20ddf55575ecdd48a946db8334.jpg", "https://sotake-futake.oss-cn-beijing.aliyuncs.com/triVfKgIdO/2357dbe54176112e5524f86775584197.jpg" ], nt = function(e) {
        var t = e.className, n = void 0 === t ? "" : t, c = e.btnText, r = e.onBtnClick, a = Math.floor(Math.random() * tt.length), i = Object(Xe.b)({
            src: tt[a],
            size: 1200
        });
        return Object(I.jsxs)(d.i, {
            className: "poster ".concat(n),
            style: et,
            children: [ Object(I.jsx)(d.i, {
                className: "img-box",
                style: {
                    "--pre-img": "url(".concat(i, ")"),
                    "--unsplash-img": "url(https://source.unsplash.com/random/600x1000)"
                },
                children: Object(I.jsx)(d.b, {
                    src: $e.a,
                    mode: "aspectFill"
                })
            }), Object(I.jsx)(d.i, {
                className: "logo",
                children: "FUTAKE"
            }), Object(I.jsx)(d.i, {
                className: "desc",
                children: "定格此刻"
            }), c && Object(I.jsx)(d.a, {
                className: "btn btn-xl btn-dark",
                onClick: r,
                children: c
            }) ]
        });
    }, ct = n(62), rt = n(19), at = n(99), it = n.n(at), ut = (n(152), function(e) {
        var t = e.children, n = G.a.account, c = G.a.setAccount, r = Object(o.useState)(!1), i = Object(b.a)(r, 2), u = i[0], l = i[1];
        Object(p.a)(Object(o.useCallback)(function() {
            var e = x.b.only("CLICK_PUBLISH", function() {
                l(!0);
            }), t = x.b.only("OPEN_SIGNUP", function() {
                l(!0);
            });
            return function() {
                e(), t();
            };
        }, []));
        var O = Object(o.useRef)(!1);
        Object(o.useEffect)(function() {
            O.current || "ACTIVE" !== n.statusText || (O.current = !0, l(!1));
        }, [ n.statusText ]);
        var g = Object(o.useState)(), m = Object(b.a)(g, 2), N = m[0], h = m[1], v = Object(K.c)({
            type: "avatar"
        }).run, D = function() {
            var e = Object(s.a)(Object(a.a)().mark(function e(t) {
                var n, c;
                return Object(a.a)().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return e.next = 2, v(t.detail.avatarUrl);

                      case 2:
                        n = e.sent, c = n.url, h(c);

                      case 5:
                      case "end":
                        return e.stop();
                    }
                }, e);
            }));
            return function(t) {
                return e.apply(this, arguments);
            };
        }(), A = Object(o.useState)(), y = Object(b.a)(A, 2), T = y[0], E = y[1], C = function(e) {
            E(e.detail.value);
        }, w = Object(K.b)("/user/register", {
            manual: !0
        }), S = w.loading, k = w.run, L = function() {
            var e = Object(s.a)(Object(a.a)().mark(function e() {
                var t, n, r;
                return Object(a.a)().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return e.next = 2, Object(f.login)();

                      case 2:
                        return t = e.sent, n = t.code, e.next = 6, k({
                            code: n,
                            nickname: T,
                            avatar_url: N
                        });

                      case 6:
                        r = e.sent, c(r);

                      case 8:
                      case "end":
                        return e.stop();
                    }
                }, e);
            }));
            return function() {
                return e.apply(this, arguments);
            };
        }();
        return Object(I.jsxs)(I.Fragment, {
            children: [ Object(I.jsx)(rt.a, {
                title: Object(I.jsx)(d.i, {
                    className: "logo",
                    children: "FUTAKE"
                })
            }), t, Object(I.jsxs)(M.a, {
                className: "signup",
                type: "full",
                visible: u,
                onClose: function() {
                    return l(!1);
                },
                children: [ Object(I.jsx)(d.i, {
                    className: "logo",
                    children: "FUTAKE"
                }), Object(I.jsx)(ct.a, {}), "UN_SIGNUP" === n.statusText ? N ? Object(I.jsxs)(I.Fragment, {
                    children: [ Object(I.jsxs)(d.i, {
                        className: "intro",
                        children: [ Object(I.jsx)(d.i, {
                            children: j()().format("今天是 YYYY 年 M 月 D 日")
                        }), Object(I.jsx)(d.i, {
                            children: "开始一个新故事吧"
                        }), Object(I.jsx)(d.i, {
                            children: "⚡️"
                        }) ]
                    }), Object(I.jsx)(Xe.a, {
                        className: "input-avatar",
                        src: N,
                        size: 160,
                        children: Object(I.jsx)(d.a, {
                            openType: "chooseAvatar",
                            onChooseAvatar: D
                        })
                    }), Object(I.jsx)(d.c, {
                        className: "btn-xl input-name",
                        type: "nickname",
                        onInput: C,
                        placeholder: "输入昵称"
                    }), T && Object(I.jsx)(d.a, {
                        className: "btn btn-xl btn-dark",
                        loading: S,
                        onClick: L,
                        children: "立刻开启"
                    }) ]
                }) : Object(I.jsxs)(I.Fragment, {
                    children: [ Object(I.jsxs)(d.i, {
                        className: "intro",
                        children: [ Object(I.jsx)(d.i, {
                            children: "FUTAKE，定格此刻"
                        }), Object(I.jsx)(d.i, {
                            children: "Life is happening"
                        }), Object(I.jsx)(d.i, {
                            children: "Future, your take"
                        }) ]
                    }), Object(I.jsxs)(d.a, {
                        className: "btn btn-xl btn-dark",
                        openType: "chooseAvatar",
                        onChooseAvatar: D,
                        children: [ Object(I.jsx)(d.b, {
                            className: "icon",
                            src: it.a
                        }), "用微信登录" ]
                    }), Object(I.jsx)(d.i, {
                        className: "btn-cancel",
                        onClick: function() {
                            return l(!1);
                        },
                        children: "以后再说"
                    }) ]
                }) : "DISABLED" === n.statusText ? Object(I.jsxs)(I.Fragment, {
                    children: [ Object(I.jsx)(d.i, {
                        className: "title",
                        children: "账号被禁用 🚫"
                    }), Object(I.jsx)(d.i, {
                        className: "desc",
                        children: "如需帮助，请发送邮件至"
                    }), Object(I.jsx)(d.i, {
                        className: "desc mail",
                        onClick: function() {
                            return Object(H.a)("hi@sotake.com");
                        },
                        children: "hi@sotake.com"
                    }) ]
                }) : Object(I.jsx)(d.i, {
                    className: "title",
                    children: "😑"
                }) ]
            }), xe ]
        });
    }), st = n(61), ot = function(e) {
        var t = e.toLeft, n = e.toRight, c = e.disable, r = Object(o.useRef)(0), a = Object(o.useRef)(0), i = Object(o.useRef)(0), u = Object(o.useCallback)(function(e) {
            if (!c) {
                var t = e.changedTouches[0], n = t.pageX, u = t.pageY;
                r.current = n, a.current = u, i.current = Date.now();
            }
        }, [ c ]), s = Object(o.useCallback)(function(e, t) {
            var n = t - a.current, c = Object(st.a)(e, n);
            return Math.abs(c);
        }, []);
        return {
            onTouchStart: u,
            onTouchEnd: Object(o.useCallback)(function(e) {
                if (!c) {
                    var a = e.changedTouches[0], u = a.pageX, o = a.pageY, l = u - r.current;
                    if (l > 0) {
                        if (!n || s(l, o) > 20) return;
                        (l > 70 || l > 10 && Date.now() - i.current < 200) && n();
                    } else {
                        if (!t || s(l, o) < 160) return;
                        (l < -70 || l < -10 && Date.now() - i.current < 200) && t();
                    }
                }
            }, [ c, s, t, n ])
        };
    }, lt = Object(B.a)().topCssVar, jt = [ "post", "posts" ], bt = [ "posts", "users" ], Ot = function() {
        x.b.emit("OPEN_AUTHOR");
    }, dt = function(e) {
        var t = e.className, n = e.stopBack, c = e.children, r = G.a.hasLogin, a = Object(Ge.a)(), i = ot({
            toLeft: jt.includes(t) && Ot,
            toRight: a,
            disable: n
        }), u = i.onTouchStart, s = i.onTouchEnd;
        return Object(o.useLayoutEffect)(function() {
            !1 === r && bt.includes(t) && Object(f.switchTab)({
                url: "/pages/Discover"
            });
        }, [ t, r ]), Object(I.jsx)(d.i, {
            className: "sub-page ".concat(t),
            onTouchStart: u,
            onTouchEnd: s,
            style: lt,
            children: c
        });
    }, ft = function() {
        var e, t;
        return null === (e = Object(f.getCurrentInstance)().page) || void 0 === e || null === (t = e.getTabBar) || void 0 === t ? void 0 : t.call(e);
    }, gt = n(43), Mt = Object(B.a)().topCssVar, mt = [ "discover", "follow" ], pt = function() {
        x.b.emit("OPEN_AUTHOR");
    }, xt = function(e) {
        var t = e.className, n = e.children;
        Object(o.useMemo)(function() {
            var e = Object(He.a)();
            x.h[e] = ft(), Object(gt.a)({
                page: e
            });
        }, []);
        var c = ot({
            toLeft: pt,
            disable: !mt.includes(t)
        }), r = c.onTouchStart, a = c.onTouchEnd;
        return Object(I.jsx)(d.i, {
            className: "tab-page ".concat(t),
            onTouchStart: r,
            onTouchEnd: a,
            style: Mt,
            children: n
        });
    }, It = (n(153), [ "discover", "follow", "notify", "me" ]);
    t.a = function(e) {
        var t = e.className, n = void 0 === t ? "" : t, c = e.stopBack, a = e.children, i = G.a.hasLogin;
        if (void 0 === i) return x.c ? Object(I.jsx)(nt, {
            className: "single-page"
        }) : Object(I.jsx)(r.a, {
            logo: !0
        });
        var u = It.includes(n);
        return i ? u ? Object(I.jsx)(xt, {
            className: n,
            children: Object(I.jsx)(Je, {
                className: n,
                isTabBar: !0,
                children: a
            })
        }) : Object(I.jsx)(dt, {
            className: n,
            stopBack: c,
            children: Object(I.jsx)(Je, {
                className: n,
                children: a
            })
        }) : u ? Object(I.jsx)(xt, {
            className: n,
            children: Object(I.jsx)(ut, {
                children: "discover" === n ? a : Object(I.jsx)(nt, {
                    btnText: "立刻登录",
                    onBtnClick: function() {
                        return x.b.emit("OPEN_SIGNUP");
                    }
                })
            })
        }) : Object(I.jsx)(dt, {
            className: n,
            stopBack: c,
            children: Object(I.jsx)(ut, {
                children: a
            })
        });
    };
}, function(e, t, n) {
    "use strict";
    var c = n(5), r = n(14);
    t.a = function(e) {
        var t = "/pages/".concat(e);
        return Object(c.navigateTo)({
            url: t
        }).catch(function(e) {
            var n = e.errMsg;
            return /exceed/.test(n) ? Object(c.redirectTo)({
                url: t
            }) : (Object(r.a)(n), Promise.reject());
        });
    };
}, , function(e, t, n) {
    "use strict";
    var c = n(5);
    t.a = function() {
        Object(c.vibrateShort)({
            type: "medium"
        });
    };
}, function(e, t, n) {
    "use strict";
    var c = n(1), r = n(2), a = n(84), i = n.n(a), u = n(26), s = (n(137), n(0));
    t.a = function(e) {
        var t = e.word, n = e.img, a = e.onClick, o = Object(c.useMemo)(function() {
            if (a) return function(e) {
                e.stopPropagation(), a();
            };
        }, [ a ]);
        return t ? Object(s.jsx)(r.i, {
            className: "avatar word-avatar",
            children: t
        }) : void 0 === n ? Object(s.jsx)(r.i, {
            className: "avatar img-avatar"
        }) : Object(s.jsx)(r.i, {
            className: "avatar img-avatar ".concat(n ? "" : "empty-avatar"),
            onClick: o,
            children: n ? Object(s.jsx)(u.a, {
                src: n,
                size: 320,
                mode: "aspectFill"
            }) : Object(s.jsx)(r.b, {
                className: "icon",
                src: i.a
            })
        });
    };
}, function(e, t, n) {
    "use strict";
    n.d(t, "b", function() {
        return l;
    });
    var c = n(9), r = n(23), a = n(1), i = n(2), u = n(0), s = [ "size", "src", "suffix" ], o = /\.aliyuncs\.com\//, l = function(e) {
        var t = e.src, n = e.size, c = void 0 === n ? 100 : n, r = e.suffix, a = void 0 === r ? "" : r;
        return o.test(t) ? "".concat(t, "?x-oss-process=image/interlace,1/resize,m_lfit,w_").concat(c).concat(a) : t;
    };
    t.a = function(e) {
        var t = e.size, n = e.src, o = e.suffix, j = Object(r.a)(e, s), b = Object(a.useMemo)(function() {
            return l({
                src: n,
                size: t,
                suffix: o
            });
        }, [ t, n, o ]);
        return Object(u.jsx)(i.b, Object(c.a)({
            src: b
        }, j));
    };
}, , function(e, t, n) {
    "use strict";
    var c = n(56);
    t.a = function() {
        var e;
        return null === (e = Object(c.a)()) || void 0 === e ? void 0 : e.replace(/pages\//, "");
    };
}, function(e, t, n) {
    "use strict";
    (function(e) {
        n.d(t, "b", function() {
            return b;
        }), n.d(t, "a", function() {
            return f;
        });
        var c = n(6), r = n(1), a = n(2), i = n(5), u = n(18), s = n(24), o = (n(136), n(0)), l = function(e) {
            var t = e.dots, n = e.blurStyle;
            return Object(o.jsx)(u.a, {
                className: "blur-loading ".concat(t ? "" : "hide-dots"),
                style: n
            });
        }, j = function() {
            var t = Object(r.useState)(0), n = Object(c.a)(t, 2), a = n[0], i = n[1], u = Object(r.useState)(!1), j = Object(c.a)(u, 2), b = j[0], O = j[1], d = Object(r.useMemo)(function() {
                if (a > 40) return {
                    "--blur": "blur(".concat(Math.floor((a - 40) / 3), "px)")
                };
            }, [ a ]), f = Object(r.useCallback)(function(e) {
                i(60), O(!0), e().then(s.a).finally(function() {
                    setTimeout(function() {
                        i(0), O(!1);
                    }, 300);
                });
            }, []), g = Object(r.useRef)(0), M = Object(r.useRef)(0), m = Object(r.useRef)(!1), p = Object(r.useRef)(!1), x = Object(r.useRef)(null), I = Object(r.useCallback)(function(t, n) {
                if (!(t < 40 || t > 120)) {
                    if (g.current = t, t > M.current && (M.current = t), x.current || (x.current = n), 
                    e(function() {
                        return i(t);
                    }), !m.current && t > 100) return m.current = !0, O(!0), void Object(s.a)();
                    m.current && t < 100 && !p.current && (m.current = !1, O(!1));
                }
            }, []), N = Object(r.useCallback)(function() {
                if (x.current) {
                    if (m.current && Math.abs(g.current - M.current) < 5) return p.current = !0, void x.current().finally(function() {
                        setTimeout(function() {
                            p.current = !1, m.current = !1, O(!1), i(0), g.current = 0, M.current = 0, x.current = null;
                        }, 300);
                    });
                    setTimeout(function() {
                        i(0), g.current = 0, M.current = 0;
                    }, 200);
                }
            }, [ i, O ]);
            return {
                loadingEl: a > 0 && Object(o.jsx)(l, {
                    dots: b,
                    blurStyle: d
                }),
                startLoading: f,
                onTouchMoveChange: I,
                onTouchEnd: N
            };
        }, b = function() {
            var e = j(), t = e.loadingEl, n = e.startLoading, c = e.onTouchMoveChange, a = e.onTouchEnd;
            return {
                loadingEl: t,
                startLoading: n,
                onSwiperTransition: Object(r.useCallback)(function(e, t) {
                    var n = t.onPullDown, r = t.onPullUp;
                    if (n || r) {
                        var a = e.detail.dy;
                        c(n ? -a : a, n || r);
                    }
                }, [ c ]),
                onTouchEnd: a
            };
        }, O = function() {
            var e = j(), t = e.loadingEl, n = e.onTouchMoveChange, c = e.onTouchEnd, a = Object(r.useRef)(0), u = Object(r.useRef)(!0);
            return Object(i.usePageScroll)(function(e) {
                var t = e.scrollTop;
                u.current = t <= 0;
            }), {
                loadingEl: t,
                onTouchStart: Object(r.useCallback)(function(e) {
                    a.current = e.changedTouches[0].pageY;
                }, []),
                onTouchChange: Object(r.useCallback)(function(e, t) {
                    if (u.current) {
                        var c = a.current - e.changedTouches[0].pageY;
                        n(-c, t);
                    }
                }, [ n ]),
                onTouchEnd: c
            };
        }, d = Object(r.memo)(function(e) {
            var t = e.className, n = e.onPullDown, c = e.onTouchStart, i = e.onTouchChange, u = e.onTouchEnd, s = e.children, l = Object(r.useCallback)(function(e) {
                return i(e, n);
            }, [ n, i ]);
            return Object(o.jsx)(a.i, {
                className: "refresh-box ".concat(t),
                onTouchStart: c,
                onTouchMove: l,
                onTouchEnd: u,
                children: s
            });
        }), f = function(e) {
            var t = e.className, n = void 0 === t ? "" : t, c = e.onPullDown, r = e.children, a = O(), i = a.loadingEl, u = a.onTouchStart, s = a.onTouchChange, l = a.onTouchEnd;
            return Object(o.jsxs)(o.Fragment, {
                children: [ Object(o.jsx)(d, {
                    className: n,
                    onPullDown: c,
                    onTouchStart: u,
                    onTouchChange: s,
                    onTouchEnd: l,
                    children: r
                }), i ]
            });
        };
    }).call(this, n(7).requestAnimationFrame);
}, , function(e, t, n) {
    "use strict";
    var c = n(14);
    t.a = function(e) {
        var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {}, n = t.label, r = void 0 === n ? "" : n, a = t.required;
        return !a || e && "" !== e.trim() ? (null == e ? void 0 : e.length) > 140 && (Object(c.a)("".concat(r, "不可超过 140 字")), 
        !0) : (Object(c.a)("".concat(r || "内容", "不可为空")), !0);
    };
}, function(e, t, n) {
    "use strict";
    var c = n(10), r = n(13), a = n(9), i = n(6), u = n(1), s = n(24), o = n(4), l = n(11), j = n(8), b = function(e, t) {
        var n = [ [ j.a.account.user_id, "following_count" ], [ e, "follower_count" ] ];
        Object(j.a)("userMap", function(e) {
            var c = !1;
            return n.forEach(function(n) {
                var r = Object(i.a)(n, 2), u = r[0], s = r[1];
                e[u] && (c = !0, "number" == typeof e[u][s] && (e[u][s] += t ? 1 : -1), "follower_count" === s && (e[u].is_following = t), 
                e[u] = Object(a.a)({}, e[u]));
            }), c ? Object(a.a)({}, e) : e;
        });
    };
    t.a = function() {
        var e = Object(l.b)("/friend/create", {
            manual: !0
        }).run, t = Object(l.b)("/friend/destroy", {
            manual: !0
        }).run;
        return Object(u.useCallback)(function() {
            var n = Object(r.a)(Object(c.a)().mark(function n(r) {
                var a, i, u, l, j;
                return Object(c.a)().wrap(function(n) {
                    for (;;) switch (n.prev = n.next) {
                      case 0:
                        if (a = r.user_id, i = r.toFollow, u = r.onStart, l = r.onError, !i) {
                            n.next = 5;
                            break;
                        }
                        j = e, n.next = 8;
                        break;

                      case 5:
                        return j = t, n.next = 8, o.b.emit("OPEN_MENU", {
                            list: [ "取消关注" ]
                        });

                      case 8:
                        return null == u || u(), Object(s.a)(), b(a, i), n.abrupt("return", j({
                            user_id: a
                        }).catch(function() {
                            null == l || l(), b(a, !i);
                        }));

                      case 12:
                      case "end":
                        return n.stop();
                    }
                }, n);
            }));
            return function(e) {
                return n.apply(this, arguments);
            };
        }(), [ e, t ]);
    };
}, function(e, t, n) {
    "use strict";
    var c = n(5), r = n(89), a = n.n(r);
    t.a = function(e) {
        var t = function(t) {
            var n = t.from, c = t.target;
            return e("button" === n, null == c ? void 0 : c.dataset) || {
                title: "FUTAKE · 定格此刻 📸",
                path: "/pages/Discover",
                imageUrl: a.a
            };
        };
        Object(c.useShareAppMessage)(t), Object(c.useShareTimeline)(t);
    };
}, function(e, t, n) {
    "use strict";
    var c = n(5), r = n(14);
    t.a = function(e) {
        Object(c.setClipboardData)({
            data: e
        }).then(function() {
            Object(r.a)("已复制");
        });
    };
}, function(e, t, n) {
    "use strict";
    var c = n(5);
    t.a = function() {
        var e;
        return null === (e = Object(c.getCurrentInstance)().router) || void 0 === e ? void 0 : e.params;
    };
}, function(e, t, n) {
    "use strict";
    var c = n(10), r = n(13), a = n(6), i = n(1), u = n(2), s = n(58), o = n.n(s), l = n(83), j = n.n(l), b = n(29), O = n(5), d = n(25), f = n(52), g = n(38), M = /.+?(\u7701|\u5e02|\u533a|\u81ea\u6cbb\u5dde|\u81ea\u6cbb\u53bf|\u76df)/g, m = /\u5317\u4eac|\u4e0a\u6d77|\u5929\u6d25|\u91cd\u5e86|\u9999\u6e2f|\u6fb3\u95e8/, p = /\u5e02|\u5730\u533a|\u81ea\u6cbb\u5dde|\u81ea\u6cbb\u53bf|\u76df/, x = function e(t) {
        if (!e[t]) {
            var n = t.match(M), c = t;
            if (n) {
                var r = Object(a.a)(n, 2), i = r[0], u = void 0 === i ? "" : i, s = r[1], o = void 0 === s ? "" : s, l = u.match(m);
                c = l ? l[0] : o.replace(p, "");
            }
            e[t] = "".concat(c, " · ");
        }
        return e[t];
    }, I = n(44), N = n(40), h = n(22), v = n(24), D = n(14), A = n(32), y = n(4), T = n(8), E = n(86), C = n.n(E), w = n(87), S = n.n(w), k = n(88), L = n.n(k), _ = (n(140), 
    n(0)), z = Object(i.memo)(function(e) {
        var t = e.user_id, n = T.a.needSignup, c = Object(A.a)();
        return Object(_.jsx)(u.a, {
            className: "btn btn-sm btn-air btn-follow",
            onClick: function() {
                n() || c({
                    user_id: t,
                    toFollow: !0,
                    onStart: function() {
                        Object(D.a)("已关注"), Object(v.a)();
                    }
                });
            },
            children: "关注"
        });
    }), R = Object(i.memo)(function(e) {
        var t = e.location;
        return Object(_.jsxs)(u.g, {
            className: "location",
            onClick: function() {
                return Object(O.openLocation)(t);
            },
            children: [ x(t.address), t.name ]
        });
    }), P = Object(i.memo)(function(e) {
        var t = e.apiUrl, n = e.user_id, c = e.avatar_url, r = e.nickname, a = e.created_at, i = e.is_following, s = e.isMyPost, o = function() {
            n && Object(h.a)("User?user_id=".concat(n));
        }, l = "/feed/recommended" !== t, j = n && !i && !s;
        return Object(_.jsxs)(u.i, {
            className: "header-bar",
            children: [ Object(_.jsxs)(u.i, {
                className: "author",
                children: [ Object(_.jsx)(d.a, {
                    img: c,
                    onClick: o
                }), Object(_.jsx)(u.i, {
                    className: "name ".concat(l ? "has-time" : "", " ").concat(j ? "has-follow-btn" : ""),
                    onClick: o,
                    children: r
                }) ]
            }), l && Object(_.jsx)(u.i, {
                className: "time",
                children: Object(N.a)(a)
            }), j && Object(_.jsx)(z, {
                user_id: n
            }) ]
        });
    }), U = Object(i.memo)(function(e) {
        var t = e.status, n = e.img_list, u = e.text, s = e.liked, o = e.onLike, l = T.a.hasLogin, j = Object(i.useRef)(0), b = Object(i.useState)(!1), O = Object(a.a)(b, 2), d = O[0], M = O[1], m = Object(i.useState)(!s), p = Object(a.a)(m, 2), x = p[0], I = p[1], N = Object(i.useCallback)(function() {
            var e = Object(r.a)(Object(c.a)().mark(function e(t) {
                var n;
                return Object(c.a)().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (l) {
                            e.next = 2;
                            break;
                        }
                        return e.abrupt("return");

                      case 2:
                        if (!((n = t.timeStamp) - j.current < 300)) {
                            e.next = 9;
                            break;
                        }
                        if (!d) {
                            e.next = 6;
                            break;
                        }
                        return e.abrupt("return");

                      case 6:
                        I(!s), M(!0), o().finally(function() {
                            var e = 550 - (Date.now() - n), t = function() {
                                return M(!1);
                            };
                            e > 0 ? setTimeout(t, e) : t();
                        });

                      case 9:
                        j.current = n;

                      case 10:
                      case "end":
                        return e.stop();
                    }
                }, e);
            }));
            return function(t) {
                return e.apply(this, arguments);
            };
        }(), [ l, d, s, o ]);
        return Object(_.jsx)(g.a, {
            className: "work-bar",
            status: t,
            img_list: n,
            imgSize: 1600,
            imgWithRatio: !0,
            text: u,
            likingIcon: d && Object(_.jsx)(f.a, {
                isRed: x
            }),
            onClick: N
        });
    }), B = Object(i.memo)(function(e) {
        var t = e.top_id, n = e.post_id, c = e.text, r = e.score, a = e.liked, s = e.like_count, o = e.comment_count, l = e.location, j = e.desc, b = e.isMyPost, O = e.firstImg, d = e.isSingle, g = e.onLike, M = T.a.needSignup, m = function() {
            M() || y.b.emit("OPEN_COMMENT", {
                post_id: n,
                comment_count: o,
                top_id: t,
                isMyPost: b
            });
        }, p = Object(i.useRef)(!1), x = Object(i.useRef)(m);
        if (x.current = m, Object(i.useEffect)(function() {
            !p.current && n && t && (p.current = !0, setTimeout(x.current, 100));
        }, [ n, t ]), !n) return Object(_.jsx)(u.i, {
            className: "footer-bar",
            children: Object(_.jsxs)(u.i, {
                className: "btn-group",
                children: [ Object(_.jsx)(u.a, {}), Object(_.jsx)(u.a, {}), Object(_.jsx)(u.a, {}), Object(_.jsx)(u.a, {}) ]
            })
        });
        var N = void 0 !== (null == l ? void 0 : l.name);
        return Object(_.jsxs)(u.i, {
            className: "footer-bar",
            children: [ Object(_.jsxs)(u.i, {
                className: "btn-group",
                children: [ Object(_.jsx)(u.a, {
                    onClick: function() {
                        M() || y.b.emit("OPEN_MORE", {
                            post_id: n,
                            score: r,
                            firstImg: O,
                            text: c,
                            location: l,
                            isMyPost: b,
                            isSingle: d
                        });
                    },
                    children: Object(_.jsx)(u.b, {
                        className: "icon",
                        src: S.a
                    })
                }), Object(_.jsx)(f.b, {
                    liked: a,
                    count: s,
                    onClick: g,
                    needSignup: M
                }), Object(_.jsxs)(u.a, {
                    onClick: m,
                    children: [ Object(_.jsx)(u.b, {
                        className: "icon",
                        src: C.a
                    }), Object(_.jsx)(u.g, {
                        children: Object(I.a)(+o)
                    }) ]
                }), Object(_.jsx)(u.a, {
                    openType: "share",
                    children: Object(_.jsx)(u.b, {
                        className: "icon",
                        src: L.a
                    })
                }) ]
            }), j && Object(_.jsx)(u.i, {
                className: "desc",
                children: j
            }), N && Object(_.jsx)(R, {
                location: l
            }) ]
        });
    }), Q = function(e) {
        var t, n = e.post, c = e.top_id, r = e.apiUrl, a = e.isSingle, s = n.post_id, o = n.status, l = n.author, j = n.created_at, b = n.img_list, O = n.text, d = n.score, f = n.is_liked, M = n.like_count, m = n.comment_count, p = n.location, x = T.a.itsMe, I = T.a.userMap, N = Object(i.useMemo)(function() {
            return l ? I[l.user_id] : {};
        }, [ l, I ]), h = N.user_id, v = N.avatar_url, D = N.nickname, A = N.is_following, E = Object(i.useMemo)(function() {
            return !!h && x(h);
        }, [ x, h ]), C = null == b || null === (t = b[0]) || void 0 === t ? void 0 : t.url, w = Object(i.useMemo)(function() {
            return s && C && O ? Object(g.b)(O) : null;
        }, [ C, s, O ]), S = Object(i.useCallback)(function() {
            return y.b.emit("LIKE_POST", {
                type: "POST",
                id: s,
                liked: f,
                like_count: M
            });
        }, [ M, f, s ]);
        return Object(_.jsxs)(u.f, {
            className: "article",
            children: [ Object(_.jsx)(P, {
                apiUrl: r,
                user_id: h,
                avatar_url: v,
                nickname: D,
                created_at: j,
                is_following: A,
                isMyPost: E
            }), Object(_.jsx)(U, {
                status: o,
                img_list: b,
                text: O,
                liked: f,
                onLike: S
            }), Object(_.jsx)(B, {
                top_id: c,
                post_id: s,
                text: O,
                score: d,
                liked: f,
                like_count: M,
                comment_count: m,
                location: p,
                desc: w,
                isMyPost: E,
                firstImg: C,
                isSingle: a,
                onLike: S
            }) ]
        });
    }, Y = Object(i.memo)(function(e) {
        var t = e.post_id, n = e.top_id, c = e.apiUrl, r = T.a.postMap[t] || {};
        return Object(_.jsx)(Q, {
            post: r,
            top_id: n,
            apiUrl: c,
            isSingle: "top_id" in e
        });
    }), H = n(12), Z = n(17), F = n(60), K = n(16), G = function e(t) {
        if (!e[t]) {
            var n = (t - 1) / 2;
            if (n % 1 == 0) e[t] = [ n, n ]; else {
                var c = Math.ceil(n);
                e[t] = [ c - 1, c ];
            }
        }
        return e[t];
    }, V = function(e, t) {
        var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 5;
        return Object(i.useMemo)(function() {
            var c = e.length;
            if (c <= n) return e;
            var r = G(n), i = Object(a.a)(r, 2), u = i[0], s = i[1], o = t - u, l = t + s;
            o < 0 && (o = 0), l > c - 1 && (l = c - 1);
            for (var j = Object(K.a)(Array(c)), b = o; b <= l; b++) j[b] = e[b];
            return j;
        }, [ t, n, e ]);
    }, W = n(15), J = n(33), X = n(11), q = n(90), $ = n.n(q), ee = (n(141), Object(Z.a)()).screenHeight, te = Object(i.memo)(function() {
        return Object(_.jsxs)(u.f, {
            className: "slide-empty",
            children: [ Object(_.jsx)(u.b, {
                className: "icon empty-icon",
                src: $.a
            }), Object(_.jsx)(u.i, {
                className: "title",
                children: "还没有作品"
            }), Object(_.jsxs)(u.i, {
                className: "row",
                children: [ "点击 ", Object(_.jsx)(u.b, {
                    className: "icon",
                    src: o.a
                }), " 关注感兴趣的用户" ]
            }), Object(_.jsxs)(u.i, {
                className: "row",
                children: [ "或点击 ", Object(_.jsx)(u.b, {
                    className: "icon",
                    src: j.a
                }), " 选择照片，发布作品" ]
            }), Object(_.jsx)(u.i, {
                className: "row",
                children: "然后下拉刷新试试 🦦 ↓"
            }) ]
        });
    }), ne = Object(i.memo)(function(e) {
        var t = e.dynamicList, n = e.apiUrl;
        return t.map(function(e, t) {
            return e ? Object(_.jsx)(Y, {
                post_id: e.post_id,
                apiUrl: n
            }, t) : Object(_.jsx)(u.f, {}, t);
        });
    }), ce = Object(i.memo)(function(e) {
        var t = e.apiUrl, n = e.gridList, s = e.gridPatch, o = e.gridIndex, l = void 0 === o ? 0 : o, j = e.startLoading, b = e.onSwiperTransition, O = e.onTouchEnd, d = e.activePost, f = Object(X.a)(t, {
            manual: !t,
            loadMore: !0,
            onSuccess: function(e) {
                var t = e.list;
                Object(H.d)("postMap", "post_id", t), Object(H.d)("userMap", "author.user_id", t);
            }
        }), g = f.data, M = f.run, m = f.patch, p = f.mutate, x = Object(i.useMemo)(function() {
            return t ? [ null == g ? void 0 : g.list, m ] : [ n, s ];
        }, [ null == g ? void 0 : g.list, m, t, n, s ]), I = Object(a.a)(x, 2), N = I[0], h = void 0 === N ? [ {} ] : N, v = I[1], D = Object(i.useState)(l), A = Object(a.a)(D, 2), T = A[0], E = A[1], C = Object(i.useState)(!1), w = Object(a.a)(C, 2), S = w[0], k = w[1], L = Object(i.useRef)(h);
        L.current = h;
        var z = Object(i.useRef)(T);
        z.current = T, d.current = h[T], Object(i.useEffect)(function() {
            var e = function(e) {
                z.current === L.current.length - 1 && L.current.findIndex(function(t) {
                    return t.post_id === e;
                }) > 0 && E(function(e) {
                    return e - 1;
                }), t && Object(H.e)(p, "post_id", e);
            };
            return y.b.on("DEL_FEED_POST", e), function() {
                y.b.off("DEL_FEED_POST", e);
            };
        }, [ p, t ]);
        var R = V(h, T, 5), P = Object(i.useMemo)(function() {
            if (t) return Object(r.a)(Object(c.a)().mark(function e() {
                return Object(c.a)().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return e.next = 2, M();

                      case 2:
                        E(0), k(function(e) {
                            return !e;
                        });

                      case 4:
                      case "end":
                        return e.stop();
                    }
                }, e);
            }));
        }, [ M, t ]);
        Object(W.a)(Object(i.useCallback)(function() {
            if (t) {
                var e, n = y.b.only("RETAP_TAB", function() {
                    j(P);
                });
                return "/feed/friend" === t && (e = y.b.only("REFRESH_FOLLOW", P)), function() {
                    var t;
                    n(), null === (t = e) || void 0 === t || t();
                };
            }
        }, [ t, P, j ]));
        var U = Object(i.useRef)(l * ee), B = Object(i.useCallback)(function() {
            return v({
                noMoreMsg: "没有更多啦"
            });
        }, [ v ]), Q = Object(i.useCallback)(function(e) {
            0 !== U.current && (e.detail.dy = e.detail.dy - U.current), b(e, {
                onPullDown: 0 === z.current && P,
                onPullUp: z.current === L.current.length - 1 && B
            });
        }, [ B, P, b ]), Y = Object(i.useRef)(!1), Z = Object(i.useCallback)(function(e) {
            if (!Y.current) {
                0 !== U.current && (U.current = 0);
                var t = e.detail.current;
                3 == L.current.length - 1 - t && z.current < t && v(), E(t), Y.current = !0, setTimeout(function() {
                    Y.current = !1;
                }, 300);
            }
        }, [ v ]);
        return Object(_.jsx)(u.e, {
            className: "slides",
            current: T,
            onTransition: Q,
            onTouchEnd: O,
            onAnimationFinish: Z,
            duration: 300,
            vertical: !0,
            children: t && 0 === R.length ? Object(_.jsx)(te, {}) : Object(_.jsx)(ne, {
                dynamicList: R,
                apiUrl: t
            })
        }, S);
    }), re = Object(i.memo)(function(e) {
        var t = e.apiUrl, n = e.single, c = e.top_id, r = e.gridList, a = e.gridPatch, s = e.gridIndex, o = e.startLoading, l = e.onSwiperTransition, j = e.onTouchEnd, b = Object(i.useRef)({});
        return Object(J.a)(function(e) {
            if (e) {
                var t, c = n || b.current, r = c.post_id, a = c.author, i = c.img_list, u = c.text, s = Object(F.a)(a.nickname), o = u ? "：“".concat(u, "”") : "照片";
                return {
                    title: "".concat(s, "在 FUTAKE 上发布").concat(o),
                    path: "/pages/Post?post_id=".concat(r),
                    imageUrl: null == i || null === (t = i[0]) || void 0 === t ? void 0 : t.url
                };
            }
        }), Object(W.a)(Object(i.useCallback)(function() {
            return y.b.only("OPEN_AUTHOR", function() {
                var e = (n || b.current).author;
                null != e && e.user_id && Object(h.a)("User?user_id=".concat(e.user_id));
            });
        }, [ n ])), Object(_.jsx)(u.i, {
            className: "feed",
            children: n ? Object(_.jsx)(Y, {
                post_id: n.post_id,
                top_id: c
            }) : Object(_.jsx)(ce, {
                apiUrl: t,
                gridList: r,
                gridPatch: a,
                gridIndex: s,
                startLoading: o,
                onSwiperTransition: l,
                onTouchEnd: j,
                activePost: b
            })
        });
    }), ae = Object(i.memo)(function(e) {
        var t = e.apiUrl, n = e.single, c = e.top_id, r = e.gridList, a = e.gridPatch, i = e.gridIndex, u = Object(b.b)(), s = u.loadingEl, o = u.startLoading, l = u.onSwiperTransition, j = u.onTouchEnd;
        return Object(_.jsxs)(_.Fragment, {
            children: [ Object(_.jsx)(re, {
                apiUrl: t,
                single: n,
                top_id: c,
                gridList: r,
                gridPatch: a,
                gridIndex: i,
                startLoading: o,
                onSwiperTransition: l,
                onTouchEnd: j
            }), s ]
        });
    });
    t.a = ae;
}, function(e, t, n) {
    "use strict";
    var c = n(9), r = n(23), a = n(1), i = n(2), u = n(22), s = n(0), o = [ "className", "to" ];
    t.a = function(e) {
        var t = e.className, n = void 0 === t ? "" : t, l = e.to, j = Object(r.a)(e, o), b = Object(a.useMemo)(function() {
            if (l) return function(e) {
                e.stopPropagation(), Object(u.a)(l);
            };
        }, [ l ]);
        return Object(s.jsx)(i.i, Object(c.a)({
            className: "link ".concat(n),
            onClick: b
        }, j));
    };
}, function(e, t, n) {
    "use strict";
    n.d(t, "b", function() {
        return O;
    });
    var c = n(6), r = n(1), a = n(2), i = n(26), u = n(37), s = n(59), o = n(4), l = new RegExp("^".concat(o.a, "$")), j = function(e) {
        return l.test(e);
    }, b = (n(139), n(0)), O = function e(t) {
        if (!e[t]) {
            var n = t.split(/\n/);
            e[t] = n.map(function(e, t) {
                var n = e.split(/\s/), c = n.length - 1, a = n.map(function(e, t) {
                    return j(e) ? Object(b.jsx)(u.a, {
                        className: "tag-link",
                        to: "Tag?tag_name=".concat(e.slice(1)),
                        children: "".concat(e, " ")
                    }, t) : t === c ? e : "".concat(e, " ");
                });
                return 0 === t ? a : Object(b.jsxs)(r.Fragment, {
                    children: [ "\n", a ]
                }, t);
            });
        }
        return e[t];
    }, d = {
        1: "PENDING",
        2: "NORMAL",
        3: "REVIEW",
        4: "RISKY",
        5: "ORIGINAL_NULL",
        6: "DELETE"
    }, f = Object(r.memo)(function(e) {
        var t = e.className, n = e.firstObj, u = e.imgSize, o = e.imgWithRatio, l = e.likingIcon, j = e.onClick, O = n.url, d = n.width, f = n.height, g = Object(r.useMemo)(function() {
            if (!o) return {};
            var e = Object(s.a)(d, f);
            return {
                articleClass: e > 1.5 ? "long-article" : "short-article",
                style: {
                    "--ratio": "".concat(e)
                }
            };
        }, [ f, o, d ]), M = Object(r.useRef)();
        Object(r.useLayoutEffect)(function() {
            g.articleClass && (M.current.parentNode.className = "article ".concat(g.articleClass));
        }, [ g.articleClass ]);
        var m = Object(r.useState)(!1), p = Object(c.a)(m, 2), x = p[0], I = p[1];
        return Object(b.jsxs)(a.i, {
            ref: M,
            className: "work img-work ".concat(x ? "has-load" : "", " ").concat(t),
            style: g.style,
            onClick: j,
            children: [ Object(b.jsx)(i.a, {
                className: "sm-img",
                src: O,
                size: 4,
                suffix: "/blur,r_1,s_1",
                mode: "aspectFill"
            }), Object(b.jsx)(i.a, {
                className: "lg-img",
                src: O,
                size: u,
                mode: "aspectFill",
                onLoad: function() {
                    return I(!0);
                }
            }), l ]
        });
    }), g = Object(r.memo)(function(e) {
        var t = e.className, n = void 0 === t ? "" : t, c = e.status, i = e.img_list, u = e.imgSize, s = e.imgWithRatio, o = e.text, l = e.likingIcon, j = e.onClick, g = e.index, M = null == i ? void 0 : i[0], m = null == M ? void 0 : M.url, p = d[c], x = Object(r.useMemo)(function() {
            if (j) return function(e) {
                return j(e, g);
            };
        }, [ g, j ]);
        return "ORIGINAL_NULL" === p || "DELETE" === p ? Object(b.jsx)(a.i, {
            className: "work deleted-work ".concat(n),
            onClick: x,
            children: "作品已删除"
        }) : m || o ? m ? Object(b.jsx)(f, {
            className: n,
            firstObj: M,
            imgSize: u,
            imgWithRatio: s,
            likingIcon: l,
            onClick: x
        }) : Object(b.jsxs)(a.i, {
            className: "work text-work ".concat(n),
            onClick: x,
            children: [ O(o), l ]
        }) : Object(b.jsx)(a.i, {
            className: "work ".concat(n)
        });
    });
    t.a = g;
}, , function(e, t, n) {
    "use strict";
    var c = n(27), r = n.n(c), a = {}, i = null, u = {}, s = {}, o = function e() {
        if (!i) {
            var t = r()().startOf("day");
            !function(e) {
                a.TODAY_BEGIN = e, a.YESTERDAY_BEGIN = function(e) {
                    return e.subtract(1, "day");
                }(e), a.THIS_YEAR_BEGIN = function(e) {
                    return e.startOf("year");
                }(e);
            }(t);
            var n = t.valueOf() + 864e5 - Date.now();
            i = setTimeout(function() {
                clearTimeout(i), i = null, u = {}, s = {}, e();
            }, n);
        }
    };
    t.a = function(e) {
        if (!e) return null;
        if (o(), !s[e]) {
            u[e] || (u[e] = r()(e));
            var t = u[e];
            if (t.isAfter(a.TODAY_BEGIN)) return t.fromNow().replace(/\u51e0\u79d2./, "刚刚");
            if (t.isAfter(a.YESTERDAY_BEGIN)) s[e] = "昨天 ".concat(t.format("H:mm")); else {
                var n = t.isBefore(a.THIS_YEAR_BEGIN);
                s[e] = t.locale("en").format("".concat(n ? "YY-" : "", "M-D H:mm"));
            }
        }
        return s[e];
    };
}, function(e, t, n) {
    "use strict";
    var c = n(9), r = n(23), a = n(1), i = n(2), u = n(46), s = (n(144), n(0)), o = [ "className", "label", "textarea" ], l = Object(a.forwardRef)(function(e, t) {
        var n = e.className, a = void 0 === n ? "" : n, l = e.label, j = e.textarea, b = Object(r.a)(e, o);
        return Object(s.jsxs)(i.i, {
            className: "label-input ".concat(a),
            children: [ Object(s.jsx)(i.i, {
                className: "label",
                children: l
            }), Object(s.jsx)(u.a, Object(c.a)({
                ref: t,
                className: "field ".concat(j ? "textarea" : "input"),
                textarea: j
            }, b)) ]
        });
    });
    t.a = l;
}, function(e, t, n) {
    "use strict";
    var c = n(5), r = n(43);
    t.a = function(e, t) {
        Object(r.a)({
            page: e
        }, t), Object(c.switchTab)({
            url: "/pages/".concat(e)
        });
    };
}, function(e, t, n) {
    "use strict";
    var c, r = n(4), a = n(28);
    t.a = function(e) {
        var t, n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : Object(a.a)();
        clearTimeout(c);
        var i, u = e.page;
        e.notifyCount || ("Notify" === u && (r.e.notifyCount = 0), e.notifyCount = r.e.notifyCount), 
        null === (t = r.h[n]) || void 0 === t || t.setData(e), u ? (null === (i = r.h[u]) || void 0 === i || i.setData(e), 
        c = setTimeout(function() {
            Object.keys(r.h).forEach(function(t) {
                t !== n && t !== u && r.h[t].setData(e);
            });
        }, 200)) : c = setTimeout(function() {
            Object.keys(r.h).forEach(function(t) {
                t !== n && r.h[t].setData(e);
            });
        }, 200);
    };
}, function(e, t, n) {
    "use strict";
    t.a = function(e, t) {
        return "number" != typeof e || 0 === e ? t && e : e < 1e3 ? e : e >= 1e4 ? "".concat(+(e / 1e4).toFixed(1), "w") : "".concat(+(e / 1e3).toFixed(1), "k");
    };
}, function(e, t, n) {
    "use strict";
    var c = n(1), r = n(5), a = n(42);
    t.a = function() {
        return Object(c.useCallback)(function() {
            return Object(r.getCurrentPages)().length > 1 ? Object(r.navigateBack)() : Object(a.a)("Discover");
        }, []);
    };
}, function(e, t, n) {
    "use strict";
    var c = n(9), r = n(6), a = n(23), i = n(1), u = n(2), s = (n(143), n(0)), o = [ "value", "onInput", "maxLength", "adjustPosition", "showConfirmBar", "onChange", "formatter", "textarea", "counter", "toShowCounter", "toShowWarnColor" ], l = function() {
        return !0;
    }, j = function(e) {
        return e > 140;
    }, b = Object(i.forwardRef)(function(e, t) {
        var n = e.value, b = void 0 === n ? "" : n, O = e.onInput, d = e.maxLength, f = void 0 === d ? -1 : d, g = e.adjustPosition, M = void 0 !== g && g, m = e.showConfirmBar, p = void 0 !== m && m, x = e.onChange, I = e.formatter, N = e.textarea, h = void 0 !== N && N, v = e.counter, D = void 0 !== v && v, A = e.toShowCounter, y = void 0 === A ? l : A, T = e.toShowWarnColor, E = void 0 === T ? j : T, C = Object(a.a)(e, o), w = Object(i.useState)(b), S = Object(r.a)(w, 2), k = S[0], L = S[1], _ = Object(i.useState)(function() {
            if (D) {
                var e = (null == k ? void 0 : k.length) || 0;
                return {
                    count: e,
                    visible: y(e),
                    warn: E(e)
                };
            }
            return null;
        }), z = Object(r.a)(_, 2), R = z[0], P = z[1], U = Object(i.useCallback)(function(e) {
            var t = I ? I(e) : e;
            if (null == x || x(t), L(t), D) {
                var n = (null == t ? void 0 : t.length) || 0;
                P({
                    count: n,
                    visible: y(n),
                    warn: E(n)
                });
            }
        }, [ D, I, x, y, E ]), B = function(e) {
            null == O || O(e), U(e.detail.value);
        };
        return Object(i.useImperativeHandle)(t, function() {
            return {
                setValue: U
            };
        }), Object(s.jsxs)(s.Fragment, {
            children: [ h ? Object(s.jsx)(u.h, Object(c.a)({
                value: k,
                onInput: B,
                maxlength: f,
                adjustPosition: M,
                showConfirmBar: p
            }, C)) : Object(s.jsx)(u.c, Object(c.a)({
                value: k,
                onInput: B,
                maxlength: f,
                adjustPosition: M
            }, C)), D && Object(s.jsxs)(u.i, {
                className: "text-counter ".concat(R.visible ? "show" : "hide"),
                children: [ Object(s.jsx)(u.g, {
                    className: "count ".concat(R.warn ? "warn" : ""),
                    children: R.count
                }), Object(s.jsx)(u.g, {
                    className: "spacer",
                    children: "/"
                }), Object(s.jsx)(u.g, {
                    className: "count limit",
                    children: "140"
                }) ]
            }) ]
        });
    });
    t.a = b;
}, function(e, t) {
    e.exports = "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjMuNiAzLjYgMTYuOCAxNi44Ij48cGF0aCBkPSJNNSA1TDE5IDE5TTUgMTlMMTkgNSIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9IjIuOCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiAvPjwvc3ZnPgo=";
}, function(e, t, n) {
    "use strict";
    var c = n(9), r = n(23), a = n(1), i = n(2), u = n(0), s = [ "className", "stopClose", "setStopClose", "onScrollChange", "onReachTop", "onReachBottom", "lowerThreshold", "children" ], o = Object(a.memo)(function(e) {
        var t = e.className, n = void 0 === t ? "" : t, a = e.stopClose, o = e.setStopClose, l = e.onScrollChange, j = e.onReachTop, b = e.onReachBottom, O = e.lowerThreshold, d = void 0 === O ? 240 : O, f = e.children, g = Object(r.a)(e, s);
        return Object(u.jsx)(i.d, Object(c.a)(Object(c.a)({
            className: "scroll-box ".concat(n),
            scrollY: !0,
            scrollAnchoring: !0,
            onScroll: function(e) {
                var t = e.detail.scrollTop;
                null == o || o(t > 0), null == l || l(t);
            },
            onScrollToUpper: function() {
                o && a && o(!1), null == j || j();
            },
            onScrollToLower: function() {
                return null == b ? void 0 : b();
            },
            lowerThreshold: d
        }, g), {}, {
            children: f
        }));
    });
    t.a = o;
}, function(e, t, n) {
    "use strict";
    var c = n(5), r = n(4);
    t.a = function(e) {
        r.f.isSystemModal = !0, Object(c.previewImage)({
            urls: [ e ]
        });
    };
}, function(e, t, n) {
    "use strict";
    t.a = function(e, t) {
        return JSON.stringify(e) === JSON.stringify(t);
    };
}, , function(e, t, n) {
    "use strict";
    n.d(t, "a", function() {
        return b;
    });
    var c = n(6), r = n(1), a = n(2), i = n(44), u = n(85), s = n.n(u), o = n(70), l = n.n(o), j = (n(138), 
    n(0)), b = function(e) {
        var t = e.isRed;
        return Object(j.jsx)(a.i, {
            className: "like-icon ".concat(t ? "is-red" : "is-white"),
            children: Object(j.jsx)(a.b, {
                src: l.a
            })
        });
    };
    t.b = function(e) {
        var t = e.liked, n = e.count, u = e.onClick, o = e.needSignup, b = Object(r.useState)(t), O = Object(c.a)(b, 2), d = O[0], f = O[1], g = Object(r.useState)(n), M = Object(c.a)(g, 2), m = M[0], p = M[1], x = Object(r.useRef)(!1);
        return x.current ? x.current = !1 : d === t && m === n || (f(t), p(n)), Object(j.jsxs)(a.a, {
            className: "like-btn ".concat(d ? "has-like" : "not-like"),
            onClick: function() {
                null != o && o() || (x.current = !0, f(function(e) {
                    return !e;
                }), p(function(e) {
                    return d ? e - 1 : e + 1;
                }), u());
            },
            children: [ Object(j.jsx)(a.b, {
                className: d ? "" : "icon",
                src: d ? l.a : s.a
            }), Object(j.jsx)(a.g, {
                children: Object(i.a)(m)
            }) ]
        });
    };
}, function(e, t) {
    e.exports = "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjEuMyAxLjMgMjEuNCAyMS40Ij48cGF0aCBkPSJNMyAxMkgyMU0yMSAxMkwxNCA1TTIxIDEyTDE0IDE5IiBzdHJva2U9IiMwMDAiIHN0cm9rZS13aWR0aD0iMy4yIiBzdHJva2UtbGluZWNhcD0icm91bmQiIC8+PC9zdmc+Cg==";
}, , , function(e, t, n) {
    "use strict";
    var c = n(5);
    t.a = function() {
        var e, t, n = null === (e = Object(c.getCurrentInstance)().router) || void 0 === e ? void 0 : e.path;
        return "/" === (null === (t = n) || void 0 === t ? void 0 : t[0]) && (n = n.slice(1)), 
        n;
    };
}, , function(e, t, n) {
    e.exports = n.p + "static/discover.png";
}, function(e, t, n) {
    "use strict";
    var c = n(17), r = Object(c.a)().screenRatio;
    t.a = function(e, t) {
        var n = t / e;
        return n = n < r ? +n.toFixed(2) : r;
    };
}, function(e, t, n) {
    "use strict";
    t.a = function(e) {
        return e && /[a-zA-Z0-9]/.test(e[e.length - 1]) ? "".concat(e, " ") : e;
    };
}, function(e, t, n) {
    "use strict";
    t.a = function(e, t) {
        return Math.atan2(t, e) * (180 / Math.PI);
    };
}, function(e, t, n) {
    "use strict";
    var c = n(2), r = (n(151), n(0));
    t.a = function() {
        return Object(r.jsxs)(c.i, {
            className: "slogan",
            children: [ Object(r.jsx)(c.i, {
                children: "FUTURE"
            }), Object(r.jsx)(c.i, {
                className: "sign",
                children: "📸"
            }), Object(r.jsx)(c.i, {
                children: "YOUR"
            }), Object(r.jsx)(c.i, {
                children: "TAKE"
            }) ]
        });
    };
}, function(e, t, n) {
    "use strict";
    var c = n(6), r = n(10), a = n(13), i = n(16), u = n(1), s = n(2), o = n(5), l = n(25), j = n(29), b = n(26), O = n(18), d = (n(157), 
    n(0)), f = function e(t) {
        return e[t] || (e[t] = t.includes("svg")), e[t];
    }, g = function(e) {
        return e;
    }, M = function(e) {
        var t = e.titles, n = e.data, c = e.active, r = e.height, a = e.footer, i = e.onChange, o = e.renderTab, l = void 0 === o ? g : o, j = Object(u.useCallback)(function(e) {
            var t = e.detail, n = t.source, c = t.current;
            "touch" === n && i(c);
        }, [ i ]);
        return Object(d.jsxs)(s.i, {
            className: "tabs",
            children: [ Object(d.jsxs)(s.i, {
                className: "tabs-header",
                children: [ t.map(function(e, t) {
                    return Object(d.jsx)(s.i, {
                        className: "title",
                        onClick: function() {
                            return i(t);
                        },
                        children: f(e) ? Object(d.jsx)(s.b, {
                            className: "icon",
                            src: e
                        }) : e
                    }, e);
                }), Object(d.jsx)(s.i, {
                    className: "tab-indicator",
                    style: {
                        left: "".concat(c / t.length * 100, "%"),
                        width: "".concat(100 / t.length, "%")
                    }
                }) ]
            }), Object(d.jsx)(s.e, {
                className: "tabs-content",
                style: {
                    height: r
                },
                current: c,
                onChange: j,
                duration: 300,
                children: n.map(function(e, t) {
                    return Object(d.jsx)(s.f, {
                        children: l(e, t)
                    }, t);
                })
            }), a ]
        });
    }, m = n(64), p = n(19), x = n(20), I = n(48), N = n(62), h = n(24), v = n(15), D = n(4), A = n(102), y = (n(159), 
    Object(u.memo)(function() {
        var e = Object(u.useState)(!1), t = Object(c.a)(e, 2), n = t[0], r = t[1], a = Object(u.useState)(!1), i = Object(c.a)(a, 2), o = i[0], l = i[1];
        Object(v.a)(Object(u.useCallback)(function() {
            return D.b.only("OPEN_ABOUT", function() {
                return r(!0);
            });
        }, []));
        var j = Object(u.useState)(!1), b = Object(c.a)(j, 2), O = b[0], f = b[1];
        return Object(d.jsx)(x.a, {
            className: "about",
            type: "large",
            visible: n,
            onClose: function() {
                return r(!1);
            },
            stopClose: o,
            children: Object(d.jsx)(I.a, {
                stopClose: o,
                setStopClose: l,
                enableFlex: !0,
                children: Object(d.jsxs)(s.i, {
                    className: "box-wrapper",
                    children: [ Object(d.jsx)(s.i, {
                        className: "logo",
                        children: "FUTAKE"
                    }), Object(d.jsx)(N.a, {}), Object(d.jsxs)(s.i, {
                        className: "intro",
                        children: [ Object(d.jsx)(s.i, {
                            children: "FUTAKE，定格此刻"
                        }), Object(d.jsx)(s.i, {
                            children: "捕捉片刻闪念"
                        }), Object(d.jsx)(s.i, {
                            children: "摒弃干扰，定格灵光，清澈跃然"
                        }), Object(d.jsx)(s.i, {
                            children: "让瞬间得到最好的呈现"
                        }), Object(d.jsx)(s.i, {
                            children: "制造想法，探索新奇"
                        }), Object(d.jsx)(s.i, {
                            children: "你的每个瞬间，都足以重塑未来"
                        }), Object(d.jsx)(s.i, {
                            children: "Life is happening"
                        }), Object(d.jsx)(s.i, {
                            children: "Future your take"
                        }), Object(d.jsx)(s.i, {
                            children: "开始一个新故事吧"
                        }), Object(d.jsx)(s.i, {
                            className: "yaya ".concat(O ? "jump" : ""),
                            onClick: function() {
                                Object(h.a)(), f(!0), setTimeout(function() {
                                    f(!1);
                                }, 800);
                            },
                            children: "🐥"
                        }) ]
                    }), Object(d.jsx)(s.i, {
                        className: "version",
                        children: A.version
                    }), Object(d.jsxs)(s.i, {
                        className: "branding",
                        children: [ "A ", Object(d.jsx)(s.g, {
                            className: "company",
                            children: "SOTAKE"
                        }), " PRODUCT" ]
                    }), Object(d.jsx)(s.i, {
                        className: "website",
                        children: "sotake.com"
                    }) ]
                })
            })
        });
    })), T = Object(d.jsx)(y, {}), E = n(9), C = n(41), w = n(12), S = n(50), k = n(34), L = n(31), _ = n(11), z = n(103), R = n.n(z), P = (n(160), 
    Object(u.memo)(function(e) {
        var t = e.userData, n = Object(u.useState)(!1), i = Object(c.a)(n, 2), j = i[0], b = i[1], O = function() {
            b(!0);
        }, f = function() {
            Object(o.hideKeyboard)(), b(!1);
        }, g = Object(u.useRef)({}), M = Object(u.useState)(""), m = Object(c.a)(M, 2), p = m[0], I = m[1], N = Object(u.useRef)({}), h = Object(u.useRef)({}), A = function(e) {
            g.current = Object(E.a)({}, e);
            var t = e.avatar_url, n = e.nickname, c = e.signature;
            I(t), N.current.setValue(n), h.current.setValue(c);
        };
        Object(u.useEffect)(function() {
            Object(S.a)(g.current, t) || A(t);
        }, [ t ]);
        var y = function() {
            var e = Object(a.a)(Object(r.a)().mark(function e() {
                return Object(r.a)().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (!Object(S.a)(g.current, t)) {
                            e.next = 3;
                            break;
                        }
                        return f(), e.abrupt("return");

                      case 3:
                        return e.next = 5, D.b.emit("OPEN_MENU", {
                            title: "有未保存更改，是否放弃",
                            list: [ "放弃" ]
                        });

                      case 5:
                        f(), setTimeout(function() {
                            A(t);
                        }, 200);

                      case 7:
                      case "end":
                        return e.stop();
                    }
                }, e);
            }));
            return function() {
                return e.apply(this, arguments);
            };
        }();
        Object(v.a)(Object(u.useCallback)(function() {
            return D.b.only("OPEN_EDIT", O);
        }, []));
        var T = Object(_.c)({
            type: "avatar"
        }), z = T.loading, P = T.run, U = Object(_.b)("/user/update", {
            manual: !0
        }), B = U.loading, Q = U.run, Y = function() {
            var e = Object(a.a)(Object(r.a)().mark(function e() {
                var n, c, a, i, u, s, o, l;
                return Object(r.a)().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (n = g.current, c = n.nickname, a = n.signature, i = n.avatar_url, !Object(L.a)(c, {
                            label: "昵称",
                            required: !0
                        })) {
                            e.next = 3;
                            break;
                        }
                        return e.abrupt("return");

                      case 3:
                        if (!Object(L.a)(a, {
                            label: "个性签名"
                        })) {
                            e.next = 5;
                            break;
                        }
                        return e.abrupt("return");

                      case 5:
                        if (u = {
                            nickname: c,
                            signature: a,
                            avatar_url: i
                        }, i === t.avatar_url) {
                            e.next = 12;
                            break;
                        }
                        return e.next = 9, P(i);

                      case 9:
                        s = e.sent, o = s.url, u.avatar_url = o;

                      case 12:
                        if (l = Object(E.a)(Object(E.a)({}, t), u), Object(S.a)(l, t)) {
                            e.next = 17;
                            break;
                        }
                        return e.next = 16, Q(u);

                      case 16:
                        Object(w.f)("userMap", t.user_id, function(e) {
                            Object.keys(u).forEach(function(t) {
                                return e[t] = u[t];
                            });
                        });

                      case 17:
                        f();

                      case 18:
                      case "end":
                        return e.stop();
                    }
                }, e);
            }));
            return function() {
                return e.apply(this, arguments);
            };
        }();
        return Object(d.jsxs)(x.a, {
            className: "edit",
            type: "large",
            visible: j,
            onClose: y,
            title: "编辑个人资料",
            btnOk: Object(d.jsx)(s.a, {
                onClick: Y,
                loading: z || B,
                children: "保存"
            }),
            children: [ Object(d.jsxs)(s.a, {
                className: "avatar-box",
                openType: "chooseAvatar",
                onChooseAvatar: function(e) {
                    var t = e.detail.avatarUrl;
                    I(t), g.current.avatar_url = t;
                },
                children: [ Object(d.jsx)(l.a, {
                    img: p
                }), Object(d.jsx)(s.g, {
                    children: "更换头像"
                }) ]
            }), Object(d.jsx)(C.a, {
                ref: N,
                type: "nickname",
                className: "nickname",
                label: "昵称",
                name: "nickname",
                value: g.current.nickname,
                onChange: function(e) {
                    g.current.nickname = e;
                },
                placeholder: "请输入昵称"
            }), Object(d.jsx)(C.a, {
                ref: h,
                className: "signature",
                textarea: !0,
                label: "个性签名",
                name: "signature",
                value: g.current.signature,
                onChange: function(e) {
                    g.current.signature = e;
                },
                placeholder: "请输入个性签名"
            }), Object(d.jsxs)(s.i, {
                className: "my-id",
                onClick: function() {
                    return Object(k.a)(t.user_id);
                },
                children: [ Object(d.jsx)(s.g, {
                    children: "我的 ID"
                }), Object(d.jsx)(s.b, {
                    className: "icon copy-icon",
                    src: R.a
                }) ]
            }) ]
        });
    })), U = (n(161), Object(u.memo)(function() {
        var e = Object(u.useState)(!1), t = Object(c.a)(e, 2), n = t[0], r = t[1], a = Object(u.useState)(!1), i = Object(c.a)(a, 2), o = i[0], l = i[1];
        return Object(v.a)(Object(u.useCallback)(function() {
            return D.b.only("OPEN_FEATURE", function() {
                return r(!0);
            });
        }, [])), Object(d.jsxs)(x.a, {
            className: "feature",
            type: "full",
            blur: !0,
            visible: n,
            onClose: function() {
                return r(!1);
            },
            stopClose: o,
            children: [ Object(d.jsx)(s.i, {
                className: "title",
                children: "F☞ ⚡️ IDEAS"
            }), Object(d.jsxs)(I.a, {
                stopClose: o,
                setStopClose: l,
                children: [ Object(d.jsx)(s.i, {
                    children: "所有照片的全新归属"
                }), Object(d.jsx)(s.i, {
                    children: "清澈纯粹，大幅留白，作品至上"
                }), Object(d.jsx)(s.i, {
                    children: "Instagram UI × TikTok UX"
                }), Object(d.jsx)(s.i, {
                    children: "让每个瞬间都是完美的"
                }), Object(d.jsx)(s.i, {
                    children: "发布图片，或是只发布文字"
                }), Object(d.jsx)(s.i, {
                    children: "双击喜欢"
                }), Object(d.jsx)(s.i, {
                    children: "作品页 ← 滑查看作者"
                }), Object(d.jsx)(s.i, {
                    children: "子页面 → 滑直接返回"
                }), Object(d.jsx)(s.i, {
                    children: "关于美好，关于日常"
                }), Object(d.jsx)(s.i, {
                    class: "emoji",
                    children: "🪴"
                }) ]
            }) ]
        });
    })), B = Object(d.jsx)(U, {}), Q = n(17), Y = n(44), H = function(e) {
        return new Promise(function(t, n) {
            setTimeout(function() {
                Object(o.createSelectorQuery)().select(e).boundingClientRect(function(e) {
                    return e ? t(e) : n();
                }).exec();
            });
        });
    }, Z = n(22), F = n(49), K = n(32), G = n(33), V = n(8), W = n(104), J = n.n(W), X = n(105), q = n.n(X), $ = n(106), ee = n.n($), te = (n(162), 
    Object(Q.a)()), ne = te.screenWidth, ce = te.contentHeight, re = te.screenScale, ae = {}, ie = Math.floor(100 * ((ne - 4) / 3 + 2)) / 100, ue = [ q.a, ee.a ], se = [ "发布", "喜欢" ], oe = Object(i.a)(Array(12)).map(function() {
        return {};
    }), le = Object(u.memo)(function(e) {
        var t = e.type, n = e.count, c = e.onTap, r = "number" == typeof n;
        return Object(d.jsxs)(s.i, {
            className: "count-box",
            onClick: function() {
                r && c(t, n);
            },
            children: [ Object(d.jsx)(s.i, {
                className: "count",
                children: Object(Y.a)(n, !0)
            }), Object(d.jsx)(s.i, {
                className: "type",
                children: r && t
            }) ]
        });
    }), je = Object(u.memo)(function() {
        var e = [ "分享名片给朋友", "F☞ ⚡️ IDEAS", "获取帮助", "意见反馈", "关于" ], t = function() {
            var t = Object(a.a)(Object(r.a)().mark(function t() {
                var n;
                return Object(r.a)().wrap(function(t) {
                    for (;;) switch (t.prev = t.next) {
                      case 0:
                        return t.next = 2, D.b.emit("OPEN_MENU", {
                            list: e
                        });

                      case 2:
                        n = t.sent, t.t0 = n, t.next = "分享名片给朋友" === t.t0 ? 6 : "F☞ ⚡️ IDEAS" === t.t0 ? 7 : "获取帮助" === t.t0 ? 8 : "意见反馈" === t.t0 ? 9 : "关于" === t.t0 ? 10 : 11;
                        break;

                      case 6:
                        return t.abrupt("return");

                      case 7:
                        return t.abrupt("return", D.b.emit("OPEN_FEATURE"));

                      case 8:
                      case 9:
                        return t.abrupt("return");

                      case 10:
                        return t.abrupt("return", D.b.emit("OPEN_ABOUT"));

                      case 11:
                      case "end":
                        return t.stop();
                    }
                }, t);
            }));
            return function() {
                return t.apply(this, arguments);
            };
        }();
        return Object(d.jsxs)(s.i, {
            className: "actions",
            children: [ Object(d.jsx)(s.a, {
                className: "btn btn-sm btn-air btn-edit",
                onClick: function() {
                    D.b.emit("OPEN_EDIT");
                },
                children: "编辑资料"
            }), Object(d.jsxs)(s.a, {
                className: "btn btn-sm btn-air btn-invite",
                openType: "share",
                "data-type": "invite",
                children: [ Object(d.jsx)(s.g, {
                    className: "emoji",
                    children: "🧈"
                }), "发给朋友" ]
            }), Object(d.jsx)(s.a, {
                className: "btn btn-sm btn-air",
                onClick: t,
                children: "更多"
            }) ]
        });
    }), be = Object(u.memo)(function(e) {
        var t = e.user_id, n = e.is_following, c = e.is_follower, i = e.hasLogin, u = e.needSignup, o = Object(K.a)(), l = function(e) {
            u() || o({
                user_id: t,
                toFollow: e
            });
        }, j = function() {
            var e = Object(a.a)(Object(r.a)().mark(function e() {
                var n, c;
                return Object(r.a)().wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return n = i ? [ "分享名片给朋友", "举报" ] : [ "分享名片给朋友" ], e.next = 3, D.b.emit("OPEN_MENU", {
                            list: n
                        });

                      case 3:
                        c = e.sent, e.t0 = c, e.next = "分享名片给朋友" === e.t0 ? 7 : "举报" === e.t0 ? 8 : 10;
                        break;

                      case 7:
                        return e.abrupt("return");

                      case 8:
                        return D.b.emit("OPEN_REPORT", {
                            type: "USER",
                            id: t
                        }), e.abrupt("return");

                      case 10:
                      case "end":
                        return e.stop();
                    }
                }, e);
            }));
            return function() {
                return e.apply(this, arguments);
            };
        }();
        return Object(d.jsx)(d.Fragment, {
            children: Object(d.jsxs)(s.i, {
                className: "actions",
                children: [ void 0 === n ? Object(d.jsx)(s.a, {
                    className: "btn btn-sm btn-follow"
                }) : Object(d.jsx)(d.Fragment, {
                    children: n ? Object(d.jsxs)(s.a, {
                        className: "btn btn-sm btn-air btn-follow",
                        onClick: function() {
                            return l(!1);
                        },
                        children: [ Object(d.jsx)(s.b, {
                            className: "icon",
                            src: J.a
                        }), c ? "互相关注" : "已关注" ]
                    }) : Object(d.jsx)(s.a, {
                        className: "btn btn-sm btn-blue btn-follow",
                        onClick: function() {
                            return l(!0);
                        },
                        children: c ? "回关" : "关注"
                    })
                }), Object(d.jsx)(s.a, {
                    className: "btn btn-sm btn-air",
                    onClick: j,
                    children: "分享"
                }) ]
            })
        });
    }), Oe = Object(u.memo)(function(e) {
        var t = e.isMe, n = e.hasLogin, c = e.userData, r = e.needSignup, a = e.onViewPubs, i = c.user_id, o = c.nickname, j = c.avatar_url, O = c.post_count, f = c.following_count, g = c.follower_count, M = c.is_following, m = c.is_follower, p = c.signature, x = Object(u.useCallback)(function() {
            if (t) D.b.emit("OPEN_EDIT"); else {
                var e = /\.qlogo.cn\//.test(j) ? j.replace(/\/132$/, "/0") : Object(b.b)({
                    src: j,
                    size: 640
                });
                Object(F.a)(e);
            }
        }, [ j, t ]), I = Object(u.useCallback)(function(e, t) {
            r() || t > 0 && Object(Z.a)("Users?user_id=".concat(i, "&nickname=").concat(o, "&avatar_url=").concat(j, "&type=").concat(e, "&count=").concat(t));
        }, [ j, r, o, i ]);
        return Object(d.jsxs)(s.i, {
            className: "user-info",
            children: [ Object(d.jsx)(l.a, {
                img: j,
                onClick: x
            }), Object(d.jsxs)(s.i, {
                className: "summary",
                children: [ Object(d.jsx)(le, {
                    type: "作品",
                    count: O,
                    onTap: a
                }), Object(d.jsx)(le, {
                    type: "关注",
                    count: f,
                    onTap: I
                }), Object(d.jsx)(le, {
                    type: "粉丝",
                    count: g,
                    onTap: I
                }) ]
            }), t ? Object(d.jsx)(je, {}) : Object(d.jsx)(be, {
                user_id: i,
                is_following: M,
                is_follower: m,
                hasLogin: n,
                needSignup: r
            }), (null == p ? void 0 : p.length) > 0 && Object(d.jsx)(s.i, {
                className: "signature",
                children: p
            }) ]
        });
    }), de = Object(u.memo)(function(e) {
        var t = e.isMe, n = e.userData, r = e.hasReady, a = e.hasTabBar, i = e.setStopBack, l = e.getAllData, b = e.tabAllPatchLoading, f = e.tabAllList, g = e.tabAllMeta, p = e.tabAllDone, x = V.a.hasLogin, I = V.a.needSignup, N = n.nickname, h = Object(u.useState)(function() {
            return Math.floor(216 * re);
        }), v = Object(c.a)(h, 2), A = v[0], y = v[1], T = Object(u.useState)(function() {
            return Math.floor(ce - 40 * re - (a ? 44 * re : 0));
        }), E = Object(c.a)(T, 2), C = E[0], w = E[1], S = Object(u.useRef)(!1);
        Object(u.useEffect)(function() {
            r && !S.current && (S.current = !0, H(".user-info").then(function(e) {
                var t = e.height;
                y(t);
            }), H(".tabs-header").then(function(e) {
                var t = e.height;
                w(ce - t - (a ? 44 * re : 0));
            }));
        }, [ r, a ]);
        var k = Object(u.useState)(0), L = Object(c.a)(k, 2), _ = L[0], z = L[1], R = Object(u.useState)(0), P = Object(c.a)(R, 2), U = P[0], B = P[1], Q = Object(u.useRef)(U), Y = Object(u.useRef)(U);
        Q.current = U;
        var Z = Object(u.useCallback)(function(e) {
            Y.current = Q.current, z(e), null == i || i(0 !== e);
        }, [ i ]), F = b[_], K = f[_], G = Object(c.a)(g[_], 2), W = G[0], J = G[1];
        Object(u.useEffect)(function() {
            p.current[_] || (p.current[_] = !0, W());
        }, [ _, p, W ]), Object(o.useReachBottom)(J);
        var X = Object(u.useRef)({
            0: 0,
            1: 0
        }), q = Object(u.useRef)(0), $ = Object(u.useRef)(!1), ee = Object(u.useRef)(0);
        Object(o.usePageScroll)(function(e) {
            var t = e.scrollTop, n = t < 0 ? 0 : t;
            X.current[_] = n, q.current = n;
            var c = ee.current;
            0 === c || $.current || (ee.current = 0, B(c));
        });
        var te = Object(u.useCallback)(function() {
            var e = K.length, t = C - A;
            e > 0 && (ae[e] || (ae[e] = Math.ceil(e / 3) * ie + 2), t = Math.max(t, ae[e])), 
            q.current > 0 && t < C && t < Y.current && (t = Math.min(C, Y.current)), ee.current = t, 
            B(t);
        }, [ A, C, K.length ]);
        Object(u.useEffect)(te, [ te ]);
        var ne = Object(u.useCallback)(function() {
            var e = X.current[_];
            e = q.current < A ? q.current : Math.max(e, A), setTimeout(function() {
                Object(o.pageScrollTo)({
                    scrollTop: e,
                    duration: 0
                });
            });
        }, [ A, _ ]);
        Object(u.useEffect)(ne, [ ne ]);
        var oe = Object(u.useCallback)(function() {
            I() || (Q.current >= ce ? Object(o.pageScrollTo)({
                scrollTop: A
            }) : ($.current = !0, ee.current = Q.current, B(ce), setTimeout(function() {
                Object(o.pageScrollTo)({
                    scrollTop: A
                }), setTimeout(function() {
                    $.current = !1;
                }, 500);
            })));
        }, [ A, I ]), le = Object(u.useCallback)(function(e, t) {
            return Object(d.jsx)(m.a, {
                gridList: e,
                gridPatch: J,
                emptyTitle: N,
                emptyDesc: "还没有".concat(se[t], "作品")
            });
        }, [ N, J ]), je = Object(u.useMemo)(function() {
            return x || !N ? null : Object(d.jsx)(s.i, {
                className: "tabs-mask",
                onClick: function() {
                    return D.b.emit("OPEN_SIGNUP");
                },
                children: Object(d.jsxs)(s.i, {
                    className: "mask-content",
                    children: [ Object(d.jsxs)(s.i, {
                        className: "mask-title",
                        children: [ Object(d.jsx)(s.g, {
                            className: "name",
                            children: N
                        }), Object(d.jsx)(s.g, {
                            children: "的 FUTAKE"
                        }) ]
                    }), Object(d.jsx)(s.a, {
                        className: "btn btn-sm btn-dark",
                        children: "立刻查看"
                    }) ]
                })
            });
        }, [ x, N ]);
        return Object(d.jsxs)(j.a, {
            className: "profile",
            onPullDown: l,
            children: [ Object(d.jsx)(Oe, {
                isMe: t,
                hasLogin: x,
                userData: n,
                needSignup: I,
                onViewPubs: oe
            }), Object(d.jsx)(M, {
                titles: ue,
                data: f,
                active: _,
                height: U,
                footer: je,
                onChange: Z,
                renderTab: le
            }), F && Object(d.jsx)(O.a, {
                ring: !0
            }) ]
        });
    }), fe = Object(u.memo)(function(e) {
        var t = e.user_id, n = e.isMe, c = e.hasTabBar, r = e.setStopBack, a = V.a.userMap, s = V.a.worksMap, l = V.a.likesMap, j = Object(_.a)("/user/detail", {
            params: {
                user_id: t
            },
            onSuccess: function(e) {
                return Object(w.c)("userMap", t, e);
            }
        }), b = j.data, O = j.run, f = !(null == b || !b.user_id), g = a[t] || {}, M = g.nickname, m = g.avatar_url, x = Object(_.a)("/post/list", {
            manual: !0,
            loadMore: !0,
            params: {
                user_id: t,
                count: 18
            },
            initialData: {
                list: s[t] || oe
            },
            onSuccess: function(e) {
                var n = e.list;
                Object(w.a)("worksMap", t, n), Object(w.d)("postMap", "post_id", n), Object(w.d)("userMap", "author.user_id", n);
            }
        }), I = x.patchLoading, N = x.data, h = x.run, A = x.patch, y = x.mutate, E = Object(_.a)("/post/liked", {
            manual: !0,
            loadMore: !0,
            params: {
                user_id: t,
                count: 18
            },
            initialData: {
                list: l[t] || oe
            },
            onSuccess: function(e) {
                var n = e.list;
                Object(w.a)("likesMap", t, n), Object(w.d)("postMap", "post_id", n), Object(w.d)("userMap", "author.user_id", n);
            }
        }), C = E.patchLoading, S = E.data, k = E.run, L = E.patch, z = E.mutate, R = Object(u.useMemo)(function() {
            return [ I, C ];
        }, [ C, I ]), U = Object(u.useMemo)(function() {
            return [ N.list, S.list ];
        }, [ S.list, N.list ]), Q = Object(u.useMemo)(function() {
            return [ [ h, A ], [ k, L ] ];
        }, [ L, k, A, h ]), Y = Object(u.useRef)([]), H = Object(u.useCallback)(function() {
            return Promise.all([ O(), h(), k() ]);
        }, [ k, h, O ]);
        Object(G.a)(function(e, n) {
            return e && "invite" === n.type ? null : {
                title: "".concat(M, " · FUTAKE 照片"),
                path: "/pages/User?user_id=".concat(t),
                imageUrl: m
            };
        }), Object(u.useEffect)(function() {
            if (Y.current[1]) {
                var e = function(e) {
                    Object(w.e)(z, "post_id", e);
                };
                return D.b.on("DEL_LIKED_POST", e), function() {
                    D.b.off("DEL_LIKED_POST", e);
                };
            }
        }, [ z ]);
        var Z = Object(u.useRef)({});
        return Object(u.useEffect)(function() {
            if (n) {
                var e = function(e) {
                    return Object(w.b)(y, e);
                }, t = function(e) {
                    return Object(w.e)(y, "post_id", e);
                }, c = function(e) {
                    Z.current[e.post_id] = e;
                }, r = function(e) {
                    delete Z.current[e];
                };
                return D.b.on("ADD_MY_WORK", e), D.b.on("DEL_MY_WORK", t), D.b.on("ADD_MY_LIKE", c), 
                D.b.on("DEL_MY_LIKE", r), function() {
                    D.b.off("ADD_MY_WORK", e), D.b.off("DEL_MY_WORK", t), D.b.off("ADD_MY_LIKE", c), 
                    D.b.off("DEL_MY_LIKE", r);
                };
            }
        }, [ n, y ]), Object(v.a)(Object(u.useCallback)(function() {
            var e;
            if (c && (e = D.b.only("RETAP_TAB", function() {
                Object(o.pageScrollTo)({
                    scrollTop: 0,
                    duration: 100
                });
            })), n && Y.current[1]) {
                var t = Object.values(Z.current);
                t.length > 0 && (z(function(e) {
                    var n = e.list, c = [];
                    return t.forEach(function(e) {
                        var t = n.findIndex(function(t) {
                            return t.post_id === e.post_id;
                        });
                        -1 === t || n.splice(t, 1), e.is_liked && c.unshift(e);
                    }), {
                        list: [].concat(c, Object(i.a)(n))
                    };
                }), Z.current = {});
            }
            return function() {
                var t;
                null === (t = e) || void 0 === t || t();
            };
        }, [ c, n, z ])), Object(d.jsxs)(d.Fragment, {
            children: [ Object(d.jsx)(p.a, {
                backBtn: !c,
                title: M
            }), Object(d.jsx)(de, {
                isMe: n,
                userData: g,
                hasReady: f,
                hasTabBar: c,
                setStopBack: r,
                getAllData: H,
                tabAllPatchLoading: R,
                tabAllList: U,
                tabAllMeta: Q,
                tabAllDone: Y
            }), n && Object(d.jsxs)(d.Fragment, {
                children: [ Object(d.jsx)(P, {
                    userData: g
                }), B, T ]
            }) ]
        });
    });
    t.a = fe;
}, function(e, t, n) {
    "use strict";
    var c = n(1), r = n(2), a = n(38), i = n(10), u = n(13), s = n(5), o = n(22), l = n(14), j = function(e) {
        var t = Object(c.useRef)(null);
        return {
            navEmitTo: Object(c.useCallback)(function() {
                var n = Object(u.a)(Object(i.a)().mark(function n(c, r) {
                    var a, u;
                    return Object(i.a)().wrap(function(n) {
                        for (;;) switch (n.prev = n.next) {
                          case 0:
                            return n.next = 2, Object(o.a)(c);

                          case 2:
                            if (a = n.sent, u = a.eventChannel) {
                                n.next = 9;
                                break;
                            }
                            return Object(l.a)("打开页面过多 😦"), n.next = 8, new Promise(function(e) {
                                return setTimeout(e, 1500);
                            });

                          case 8:
                            return n.abrupt("return", Object(s.navigateBack)());

                          case 9:
                            t.current = u, u.emit(e, r);

                          case 11:
                          case "end":
                            return n.stop();
                        }
                    }, n);
                }));
                return function(e, t) {
                    return n.apply(this, arguments);
                };
            }(), [ e ]),
            updateStream: Object(c.useCallback)(function(n) {
                var c;
                null === (c = t.current) || void 0 === c || c.emit(e, n);
            }, [ e ])
        };
    }, b = (n(158), n(0)), O = Object(c.memo)(function(e) {
        var t = e.gridList, n = e.gridPatch, i = j("OPEN_POSTS"), u = i.navEmitTo, s = i.updateStream, o = Object(c.useCallback)(function(e, c) {
            return u("Posts", {
                gridList: t,
                gridPatch: n,
                gridIndex: c
            });
        }, [ u, t, n ]);
        return Object(c.useEffect)(function() {
            s({
                gridList: t
            });
        }, [ t, s ]), Object(b.jsx)(r.i, {
            className: "grids has-list",
            children: t.map(function(e, t) {
                var n = e.post_id, c = e.status, r = e.img_list, i = e.text;
                return Object(b.jsx)(a.a, {
                    status: c,
                    img_list: r,
                    imgSize: 500,
                    text: i,
                    onClick: n && o,
                    index: t
                }, n || t);
            })
        });
    }), d = Object(c.memo)(function(e) {
        var t = e.gridList, n = e.gridPatch, c = e.emptyTitle, a = void 0 === c ? "🌁" : c, i = e.emptyDesc, u = void 0 === i ? "还没有作品" : i;
        return t.length > 0 ? Object(b.jsx)(O, {
            gridList: t,
            gridPatch: n
        }) : Object(b.jsxs)(r.i, {
            className: "grids is-empty",
            children: [ Object(b.jsx)(r.i, {
                className: "title",
                children: a
            }), Object(b.jsx)(r.i, {
                className: "desc",
                children: u
            }) ]
        });
    });
    t.a = d;
}, , , , , function(e, t) {
    e.exports = "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjEuNyAxLjUgMjAuNiAyMC42Ij48cGF0aCBkPSJNIDEyIDIgQyA3LjI1MjAxODQgMiAzLjI2NzM3NyA1LjMyNTI4NDYgMi4yNTU4NTk0IDkuNzc5Mjk2OSBBIDEuMDAwMjM4OCAxLjAwMDIzODggMCAwIDAgNC4yMDcwMzEyIDEwLjIyMDcwMyBDIDUuMDE1NTEzNiA2LjY2MDcxNTUgOC4xODM5ODE2IDQgMTIgNCBDIDE1LjgxNjAxOCA0IDE4Ljk4NDQ4NiA2LjY2MDcxNTUgMTkuNzkyOTY5IDEwLjIyMDcwMyBBIDEuMDAwMjM4OSAxLjAwMDIzODkgMCAwIDAgMjEuNzQ0MTQxIDkuNzc5Mjk2OSBDIDIwLjczMjYyMyA1LjMyNTI4NDYgMTYuNzQ3OTgyIDIgMTIgMiIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9IjEiIC8+PC9zdmc+Cg==";
}, function(e, t) {
    e.exports = "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAuNyAyLjQgMjguNiAyOC42Ij48cGF0aCBkPSJNIDkuNTQ0OTIxOSAzIEMgNS4zODk1ODA3IDMgMiA2LjM4OTU4MDYgMiAxMC41NDQ5MjIgQyAyIDE0LjI4MzE1NiA0LjkwMDU0OTYgMTguMDg0NzIzIDcuNjYwMTU2MiAyMS4xMTkxNDEgQyAxMC40MTk3NjMgMjQuMTUzNTU4IDEzLjE3MTg3NSAyNi4zNjkxNDEgMTMuMTcxODc1IDI2LjM2OTE0MSBDIDEzLjY0Mjc5NyAyNi43MjUxNDggMTQuMjAxNzk0IDI2Ljk0Mzg1NyAxNC44MDg1OTQgMjYuOTg0Mzc1IEEgMS4wMDAxIDEuMDAwMSAwIDAgMCAxNS4xOTkyMTkgMjYuOTgyNDIyIEMgMTUuODAyOTE4IDI2Ljk0MDQ0OSAxNi4zNTkxNTUgMjYuNzIzNjc0IDE2LjgwMjczNCAyNi4zODg2NzIgQyAxNi44MjgxMjUgMjYuMzY5MTQxIDE5LjU4MDIzNyAyNC4xNTM1NTggMjIuMzM5ODQ0IDIxLjExOTE0MSBDIDI1LjA5OTQ1MSAxOC4wODQ3MjIgMjggMTQuMjgzMTU2IDI4IDEwLjU0NDkyMiBDIDI4IDYuMzg5NTgwNiAyNC42MTA0MTkgMyAyMC40NTUwNzggMyBDIDE3Ljg0MTA0MyAzIDE1Ljk4OTkzOSA0LjQzODU0ODcgMTUgNS40NTcwMzEyIEMgMTQuMDEwMDYxIDQuNDM4NTQ4NyAxMi4xNTg5NTcgMyA5LjU0NDkyMTkgMyB6IE0gOS41NDQ5MjE5IDUgQyAxNi4wNDk5MzggNy4yNTc1MDUyIDE3LjcxNjEzMyA1IDIwLjQ1NTA3OCA1IiBmaWxsPSIjZmQyZTNlIiAgc3Ryb2tlPSIjZmQyZTNlIiBzdHJva2Utd2lkdGg9IjAuNCIgLz48L3N2Zz4K";
}, , , function(e, t, n) {}, , , , , , , , , , function(e, t) {
    e.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAAABmJLR0QA/wD/AP+gvaeTAAADB0lEQVR4nO2dy04UQRSGP4lhHEVhYSIkvoAude/wBvgCXt7AC0HfwhgvkTXRnYr6BG5EH8DrChKNl8UwKINLcNFjYsjUQHeX53R1/19yNpVJnb/OX+lb9VSDEEIIIYQQQgghhGgKByL2NQWcB+aAU8BJ4EjE/j3ZAr4A74Hng9hwVfQPh4AbQA/YaUisAwtAK0L9SjEDvMG/IF7xGpguXcWCzABrewhsQqzhYEKLZs/83bGC8eHo5n8YROoxX6qiOZhi9An3MdChPldAkI2lAzwlPO4uMGkh5vIIEdcsBDgzT3j8Fy0ELAeSP7FIXhFca/ApkPycRfKK0GF4DT5aJN8MJJ+wSF4RJhheg828HRV5FLETsa+UiVKHsQhCRAlkgDMywJnUDUhdf7IDaAP3yB4LbwB3B22NIHQXaMntIflvGWtwq0MVDPg+JP8PYw1R6pDqfUBtNKR6DqgNMsAZGeCMDHBGBjgjA5yRAc7IAGdkgDMywBkZ4IwMcEYGOONhwGHgPtlCStH3MEMU7a9HtsCTxKJO2efgiyP68I5FwzoA9usBY0Cf6s6038BRYHsfv9V6QB2wNmAbWDLOmYcl9jf7XSl77GuTvcVQpT/1rQN3yHdoTPIcEIvaaNA5wBkZ4IwMcEYGOCMDnJEBzsgAZ2SAMzLAGRngjAxwRgY4IwOcSdWAYRvm9cxVRCBVAx4NaXtorsKJKAsRJWmTLaBvDeIB9uvMjV6Q2Z3TegKMypmrDgcjCPHEo/BRSfUcUBtkgDMywJkiBvQD7U3asuxYoP1X3o6KGPA10H62QF+pcibQ/i1vR0UMeBdov1Kgr1S5Gmh/a5H8EuGbELPtex1ZIDz+CxYCpshe5QuJWAZmqd/WxbPAM8LjNtu6GEbPgqaG6bbNLbKPF3gPuirxChgvVdECTAOrJYXXIVaBEyVrWZjjwMs9BNY5VnD8hMlfxsmufrr4F8QqusB1Ihx2Yj5CniT7hNUccJrsM1Z1uTvuA5+BD2RXQi+An66KhBBCCCGEEEIIIURy/AHzrM3HruX+PQAAAABJRU5ErkJggg==";
}, function(e, t) {
    e.exports = "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9Ii04LjUgLTguNSA0MCA0MCIgZmlsbD0ibm9uZSI+PHBhdGggZD0iTTYgMTJMOCAzSDE1LjVMMTQgOC45OTk5MUgxOEw5IDIxTDEwLjUgMTJINloiIGZpbGw9IiMwMDAiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIxLjUiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgb3BhY2l0eT0iMC40IiAvPjwvc3ZnPgo=";
}, function(e, t, n) {
    e.exports = n.p + "images/like.svg";
}, function(e, t) {
    e.exports = "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjEgMy40IDQ2IDQ2Ij48cGF0aCBkPSJNIDI0IDQgQyAxMi45NzIyOTIgNCA0IDEyLjk3MjI5MiA0IDI0IEMgNCAyNy4yNzUzMTYgNC44NjI3MDc4IDMwLjMzNDg1MyA2LjI2MTcxODggMzMuMDY0NDUzIEwgNC4wOTM3NSA0MC44MjgxMjUgQyAzLjU4ODc5NzMgNDIuNjMxNTI4IDUuMzcxOTI2MSA0NC40MTI2MSA3LjE3NTc4MTIgNDMuOTA4MjAzIEwgMTQuOTQzMzU5IDQxLjc0MDIzNCBDIDE3LjY3MTA0NiA0My4xMzczNTggMjAuNzI2OTU5IDQ0IDI0IDQ0IEMgMzUuMDI3NzA4IDQ0IDQ0IDM1LjAyNzcwOCA0NCAyNCBDIDQ0IDEyLjk3MjI5MiAzNS4wMjc3MDggNCAyNCA0IHogTSAyNCA3IEMgMzMuNDA2MjkyIDcgNDEgMTQuNTkzNzA4IDQxIDI0IEMgNDEgMzMuNDA2MjkyIDMzLjQwNjI5MiA0MSAyNCA0MSBDIDIwLjk5NzAyOSA0MSAxOC4xOTIyNTggNDAuMjE4MjgxIDE1Ljc0NDE0MSAzOC44NTM1MTYgQSAxLjUwMDE1IDEuNTAwMTUgMCAwIDAgMTQuNjA5Mzc1IDM4LjcxODc1IEwgNy4yMjI2NTYyIDQwLjc4MTI1IEwgOS4yODUxNTYyIDMzLjM5ODQzOCBBIDEuNTAwMTUgMS41MDAxNSAwIDAgMCA5LjE1MDM5MDYgMzIuMjYzNjcyIEMgNy43ODM2NTIyIDI5LjgxMzQ3NiA3IDI3LjAwNDUxOCA3IDI0IEMgNyAxNC41OTM3MDggMTQuNTkzNzA4IDcgMjQgNyB6IiBzdHJva2U9IiMwMDAiIHN0cm9rZS13aWR0aD0iMC4yIiAvPjwvc3ZnPgo=";
}, function(e, t) {
    e.exports = "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjUgNSAxNCAxNCIgZmlsbD0ibm9uZSI+PGNpcmNsZSBjeD0iNy4yIiBjeT0iMTIiIHI9IjAuOCIgZmlsbD0iIzAwMCIgLz48Y2lyY2xlIGN4PSIxMiIgY3k9IjEyIiByPSIwLjgiIGZpbGw9IiMwMDAiIC8+PGNpcmNsZSBjeD0iMTYuOCIgY3k9IjEyIiByPSIwLjgiIGZpbGw9IiMwMDAiIC8+PC9zdmc+Cg==";
}, function(e, t) {
    e.exports = "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAuNSAxIDIzIDIzIiBmaWxsPSJub25lIj48cGF0aCBkPSJNMjIgMkwyIDguNjY2NjdMMTEuNTgzMyAxMi40MTY3TTIyIDJMMTUuMzMzMyAyMkwxMS41ODMzIDEyLjQxNjdNMjIgMkwxMS41ODMzIDEyLjQxNjciIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIxLjYiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgLz48L3N2Zz4K";
}, function(e, t, n) {
    e.exports = n.p + "images/share.png";
}, function(e, t) {
    e.exports = "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjEgMSAyMiAyMiIgZmlsbD0ibm9uZSI+PHBhdGggZD0iTTQgMjFIMjBDMjEuMTA0NiAyMSAyMiAyMC4xMDQ2IDIyIDE5VjguNkMyMiA3LjQ5NTQzIDIxLjEwNDYgNi42IDIwIDYuNkwxNyA2LjZMMTQuNSAzSDkuNUw3IDYuNkw0IDYuNkMyLjg5NTQzIDYuNiAyIDcuNDk1NDMgMiA4LjZWMTlDMiAyMC4xMDQ2IDIuODk1NDMgMjEgNCAyMVoiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIxLjUiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIC8+PGNpcmNsZSBjeD0iMTIiIGN5PSIxMyIgcj0iNCIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9IjEuNSIgLz48L3N2Zz4K";
}, function(e, t) {
    e.exports = "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjIuNiAyLjYgMTguOCAxOC44IiBmaWxsPSJub25lIj48cGF0aCBkPSJNMTYgNEw4IDEyTDE2IDIwIiBzdHJva2U9IiMwMDAiIHN0cm9rZS13aWR0aD0iMi41IiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiIC8+PC9zdmc+Cg==";
}, function(e, t) {
    e.exports = "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjEuNyAxLjY3IDIwLjYgMjAuNiI+PHBhdGggZD0iTTEyIDIxVjNNMTIgM0w1IDEwTTEyIDNMMTkgMTAiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIyLjUiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgLz48L3N2Zz4K";
}, function(e, t, n) {
    e.exports = n.p + "images/wx_color.svg";
}, function(e, t, n) {
    e.exports = n.p + "images/geo.svg";
}, function(e, t) {
    e.exports = "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjEgMiAyMiAyMiI+PHBhdGggZD0iTTEyLDJDOC4xMzQsMiw1LDUuMTM0LDUsOWMwLDMuOTY2LDQuNDA0LDkuODIsNi4yMjYsMTIuMDcxYzAuNCwwLjQ5NCwxLjE0OCwwLjQ5NCwxLjU0OCwwQzE0LjU5NiwxOC44MiwxOSwxMi45NjYsMTksOSBDMTksNS4xMzQsMTUuODY2LDIsMTIsMnogTTEyLDExLjVjLTEuMzgxLDAtMi41LTEuMTE5LTIuNS0yLjVjMC0xLjM4MSwxLjExOS0yLjUsMi41LTIuNXMyLjUsMS4xMTksMi41LDIuNSBDMTQuNSwxMC4zODEsMTMuMzgxLDExLjUsMTIsMTEuNXoiIC8+PC9zdmc+Cg==";
}, function(e, t, n) {
    e.exports = n.p + "images/img.svg";
}, function(e, t) {
    e.exports = "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjIuNSAyLjUgNDMgNDMiPjxwYXRoIGQ9Ik0gMjAuNDYwOTM4IDMuOTgwNDY4OCBBIDEuNTAwMTUgMS41MDAxNSAwIDAgMCAxOS4wMjUzOTEgNS4yMjA3MDMxIEwgMTYuOTg2MzI4IDE2IEwgNy41IDE2IEEgMS41MDAxNSAxLjUwMDE1IDAgMSAwIDcuNSAxOSBMIDE2LjQxNzk2OSAxOSBMIDE0LjUyNzM0NCAyOSBMIDUuNSAyOSBBIDEuNTAwMTUgMS41MDAxNSAwIDEgMCA1LjUgMzIgTCAxMy45NTg5ODQgMzIgTCAxMi4wMjUzOTEgNDIuMjIwNzAzIEEgMS41MDA4MjU5IDEuNTAwODI1OSAwIDEgMCAxNC45NzQ2MDkgNDIuNzc5Mjk3IEwgMTcuMDEzNjcyIDMyIEwgMjcuOTU4OTg0IDMyIEwgMjYuMDI1MzkxIDQyLjIyMDcwMyBBIDEuNTAwODI1OSAxLjUwMDgyNTkgMCAwIDAgMjguOTc0NjA5IDQyLjc3OTI5NyBMIDMxLjAxMzY3MiAzMiBMIDQwLjUgMzIgQSAxLjUwMDE1IDEuNTAwMTUgMCAxIDAgNDAuNSAyOSBMIDMxLjU4MjAzMSAyOSBMIDMzLjQ3MjY1NiAxOSBMIDQyLjUgMTkgQSAxLjUwMDE1IDEuNTAwMTUgMCAxIDAgNDIuNSAxNiBMIDM0LjA0MTAxNiAxNiBMIDM1Ljk3NDYwOSA1Ljc3OTI5NjkgQSAxLjUwMDgyNTkgMS41MDA4MjU5IDAgMCAwIDMzLjAyNTM5MSA1LjIyMDcwMzEgTCAzMC45ODYzMjggMTYgTCAyMC4wNDEwMTYgMTYgTCAyMS45NzQ2MDkgNS43NzkyOTY5IEEgMS41MDAxNSAxLjUwMDE1IDAgMCAwIDIwLjQ2MDkzOCAzLjk4MDQ2ODggeiBNIDE5LjQ3MjY1NiAxOSBMIDMwLjQxNzk2OSAxOSBMIDI4LjUyNzM0NCAyOSBMIDE3LjU4MjAzMSAyOSBMIDE5LjQ3MjY1NiAxOSB6IiAvPjwvc3ZnPgo=";
}, function(e, t, n) {
    e.exports = n.p + "images/poster.jpg";
}, function(e, t) {
    e.exports = "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjIgMyAyMCAyMCI+PHBhdGggZD0iTTUuNDU3IDE4LjE4NUMzLjM1OCAxNi42NzcgMiAxNC40IDIgMTEuOTA4IDIgNy4zMjMgNi40NzUgMy42IDEyIDMuNnMxMCAzLjcyMyAxMCA4LjMwOGMwIDQuNTg0LTQuNDc1IDguMzA3LTEwIDguMzA3YTExLjM2IDExLjM2IDAgMCAxLTMuMjcyLS40NjFjLS4wOTItLjAzLS4yMTYtLjAzLS4zMDgtLjAzLS4xODUgMC0uMzcuMDYtLjUyNS4xNTNsLTIuMTkxIDEuMjYxYS40NC40NCAwIDAgMS0uMTg1LjA2Mi4zNDIuMzQyIDAgMCAxLS4zNC0uMzM4YzAtLjA5My4wMy0uMTU0LjA2Mi0uMjQ3LjAzLS4wMy4zMDgtMS4wNDYuNDYzLTEuNjYxIDAtLjA2Mi4wMy0uMTU0LjAzLS4yMTYgMC0uMjQ2LS4wOTItLjQzLS4yNzctLjU1M3ptMy4yMS03LjY3NGMuNzE3IDAgMS4yODUtLjU2OCAxLjI4NS0xLjI4NSAwLS43MTgtLjU2OC0xLjI4Ni0xLjI4NS0xLjI4Ni0uNzE4IDAtMS4yODUuNTY4LTEuMjg1IDEuMjg2IDAgLjcxNy41NjcgMS4yODUgMS4yODUgMS4yODV6bTYuNjY2IDBjLjcxOCAwIDEuMjg1LS41NjggMS4yODUtMS4yODUgMC0uNzE4LS41NjctMS4yODYtMS4yODUtMS4yODYtLjcxNyAwLTEuMjg1LjU2OC0xLjI4NSAxLjI4NiAwIC43MTcuNTY4IDEuMjg1IDEuMjg1IDEuMjg1eiIgLz48L3N2Zz4K";
}, , , function(e) {
    e.exports = JSON.parse('{"name":"m68-wx","version":"3.23.4","private":true,"templateInfo":{"name":"default","typescript":false,"css":"less"},"scripts":{"dev":"taro build --type weapp --watch","start":"API_ENV=public taro build --type weapp --watch","build":"API_ENV=public NODE_ENV=production taro build --type weapp"},"browserslist":["last 3 versions","Android >= 4.1","ios >= 8"],"dependencies":{"@babel/runtime":"^7.22.5","@tarojs/components":"^3.6.8","@tarojs/plugin-framework-react":"^3.6.8","@tarojs/plugin-platform-weapp":"^3.6.8","@tarojs/react":"^3.6.8","@tarojs/runtime":"^3.6.8","@tarojs/taro":"^3.6.8","dayjs":"^1.11.8","react":"^18.2.0","react-dom":"^18.2.0","resso":"^0.14.0"},"devDependencies":{"@babel/core":"^7.22.5","@tarojs/cli":"^3.6.8","@tarojs/mini-runner":"^3.6.8","@tarojs/webpack-runner":"^3.6.8","@trivago/prettier-plugin-sort-imports":"^4.1.1","@types/react":"^18.2.12","@types/webpack-env":"^1.18.1","babel-preset-taro":"^3.6.8","eslint":"^8.42.0","eslint-config-prettier":"^8.8.0","eslint-config-taro":"^3.6.8","eslint-plugin-import":"^2.27.5","eslint-plugin-react":"^7.32.2","eslint-plugin-react-hooks":"^4.6.0","postcss":"^8.4.24","postcss-less":"^6.0.0","prettier":"^2.8.8","stylelint":"^15.7.0","stylelint-config-one":"^2.4.0"}}');
}, function(e, t) {
    e.exports = "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjQgNCAyNCAyNCI+PHBhdGggZD0iTSA0IDQgTCA0IDI0IEwgMTEgMjQgTCAxMSAyMiBMIDYgMjIgTCA2IDYgTCAxOCA2IEwgMTggNyBMIDIwIDcgTCAyMCA0IFogTSAxMiA4IEwgMTIgMjggTCAyOCAyOCBMIDI4IDggWiBNIDE0IDEwIEwgMjYgMTAgTCAyNiAyNiBMIDE0IDI2IFoiIC8+PC9zdmc+Cgo=";
}, function(e, t) {
    e.exports = "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjIgMSA0NCA0NCI+PHBhdGggZD0iTSA0Mi45NjA5MzggOC45ODA0Njg4IEEgMi4wMDAyIDIuMDAwMiAwIDAgMCA0MS41ODU5MzggOS41ODU5Mzc1IEwgMTcgMzQuMTcxODc1IEwgNi40MTQwNjI1IDIzLjU4NTkzOCBBIDIuMDAwMiAyLjAwMDIgMCAxIDAgMy41ODU5Mzc1IDI2LjQxNDA2MiBMIDE1LjU4NTkzOCAzOC40MTQwNjIgQSAyLjAwMDIgMi4wMDAyIDAgMCAwIDE4LjQxNDA2MiAzOC40MTQwNjIgTCA0NC40MTQwNjIgMTIuNDE0MDYyIEEgMi4wMDAyIDIuMDAwMiAwIDAgMCA0Mi45NjA5MzggOC45ODA0Njg4IHoiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIyIiAvPjwvc3ZnPgo=";
}, function(e, t) {
    e.exports = "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9Ii0wLjMgLTAuMyAxNS42IDE1LjYiPjxwYXRoIGQ9Ik0gMi41IDEgQyAxLjY3NTc4MSAxIDEgMS42NzU3ODEgMSAyLjUgTCAxIDEyLjUgQyAxIDEzLjMyNDIxOSAxLjY3NTc4MSAxNCAyLjUgMTQgTCAxMi41IDE0IEMgMTMuMzI0MjE5IDE0IDE0IDEzLjMyNDIxOSAxNCAxMi41IEwgMTQgMi41IEMgMTQgMS42NzU3ODEgMTMuMzI0MjE5IDEgMTIuNSAxIFogTSAyLjUgMiBMIDUgMiBMIDUgNSBMIDIgNSBMIDIgMi41IEMgMiAyLjIxODc1IDIuMjE4NzUgMiAyLjUgMiBaIE0gNiAyIEwgOSAyIEwgOSA1IEwgNiA1IFogTSAxMCAyIEwgMTIuNSAyIEMgMTIuNzgxMjUgMiAxMyAyLjIxODc1IDEzIDIuNSBMIDEzIDUgTCAxMCA1IFogTSAyIDYgTCA1IDYgTCA1IDkgTCAyIDkgWiBNIDYgNiBMIDkgNiBMIDkgOSBMIDYgOSBaIE0gMTAgNiBMIDEzIDYgTCAxMyA5IEwgMTAgOSBaIE0gMiAxMCBMIDUgMTAgTCA1IDEzIEwgMi41IDEzIEMgMi4yMTg3NSAxMyAyIDEyLjc4MTI1IDIgMTIuNSBaIE0gNiAxMCBMIDkgMTAgTCA5IDEzIEwgNiAxMyBaIE0gMTAgMTAgTCAxMyAxMCBMIDEzIDEyLjUgQyAxMyAxMi43ODEyNSAxMi43ODEyNSAxMyAxMi41IDEzIEwgMTAgMTMgWiIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9IjAuMSIgLz48L3N2Zz4K";
}, function(e, t) {
    e.exports = "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjMuNSAzLjUgNDEgNDEiPjxwYXRoIGQ9Ik0gMTUgNyBDIDguOTQyNDQxNiA3IDQgMTEuOTQyNDQyIDQgMTggQyA0IDIyLjA5NjE1NCA3LjA4NzY0NDggMjUuOTUyODk5IDEwLjg1MTU2MiAyOS45MDgyMDMgQyAxNC42MTU0ODEgMzMuODYzNTA3IDE5LjI0ODM3OSAzNy44Njk0NzIgMjIuOTM5NDUzIDQxLjU2MDU0NyBBIDEuNTAwMTUgMS41MDAxNSAwIDAgMCAyNS4wNjA1NDcgNDEuNTYwNTQ3IEMgMjguNzUxNjIxIDM3Ljg2OTQ3MiAzMy4zODQ1MTggMzMuODYzNTA3IDM3LjE0ODQzOCAyOS45MDgyMDMgQyA0MC45MTIzNTYgMjUuOTUyODk5IDQ0IDIyLjA5NjE1NCA0NCAxOCBDIDQ0IDExLjk0MjQ0MiAzOS4wNTc1NTggNyAzMyA3IEMgMjkuNTIzNTY0IDcgMjYuNDk2ODIxIDguODY2NDg4MyAyNCAxMi4wMzcxMDkgQyAyMS41MDMxNzkgOC44NjY0ODgzIDE4LjQ3NjQzNiA3IDE1IDcgeiBNIDE1IDEwIEMgMTcuOTI4NTcxIDEwIDIwLjM2NjMgMTEuNTU4Mzk5IDIyLjczMjQyMiAxNS4zMDA3ODEgQSAxLjUwMDE1IDEuNTAwMTUgMCAwIDAgMjUuMjY3NTc4IDE1LjMwMDc4MSBDIDI3LjYzMzcgMTEuNTU4Mzk5IDMwLjA3MTQyOSAxMCAzMyAxMCBDIDM3LjQzNjQ0MiAxMCA0MSAxMy41NjM1NTggNDEgMTggQyA0MSAyMC40MDM4NDYgMzguNTg3NjQ0IDI0LjA0NzEwMSAzNC45NzY1NjIgMjcuODQxNzk3IEMgMzEuNjgzNTkgMzEuMzAyMjEgMjcuNTkwMzEyIDM0LjkxNzQ1MyAyNCAzOC40MTc5NjkgQyAyMC40MDk2ODggMzQuOTE3NDUzIDE2LjMxNjQxIDMxLjMwMjIxIDEzLjAyMzQzOCAyNy44NDE3OTcgQyA5LjQxMjM1NTIgMjQuMDQ3MTAxIDcgMjAuNDAzODQ2IDcgMTggQyA3IDEzLjU2MzU1OCAxMC41NjM1NTggMTAgMTUgMTAgeiIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9IjAuMSIgLz48L3N2Zz4K";
}, , , , , , , , , , , , , , , , , , , , , , , , , , , , function(e, t, n) {}, , function(e, t, n) {}, function(e, t, n) {}, function(e, t, n) {}, function(e, t, n) {}, function(e, t, n) {}, function(e, t, n) {}, function(e, t, n) {}, function(e, t, n) {}, function(e, t, n) {}, function(e, t, n) {}, function(e, t, n) {}, function(e, t, n) {}, function(e, t, n) {}, function(e, t, n) {}, function(e, t, n) {}, function(e, t, n) {}, function(e, t, n) {}, function(e, t, n) {}, , , , function(e, t, n) {}, function(e, t, n) {}, function(e, t, n) {}, function(e, t, n) {}, function(e, t, n) {}, function(e, t, n) {} ] ]);