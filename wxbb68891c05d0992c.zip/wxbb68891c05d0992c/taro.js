(wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 1 ], {
    107: function(t, e, n) {
        const i = n(165);
        t.exports = i.default, t.exports.default = t.exports;
    },
    119: function(t, e, n) {
        "use strict";
        var i = n(3);
        const r = new Set([ "addFileToFavorites", "addVideoToFavorites", "authPrivateMessage", "checkIsAddedToMyMiniProgram", "chooseContact", "cropImage", "disableAlertBeforeUnload", "editImage", "enableAlertBeforeUnload", "getBackgroundFetchData", "getChannelsLiveInfo", "getChannelsLiveNoticeInfo", "getFuzzyLocation", "getGroupEnterInfo", "getLocalIPAddress", "getShareInfo", "getUserProfile", "getWeRunData", "join1v1Chat", "openChannelsActivity", "openChannelsEvent", "openChannelsLive", "openChannelsUserProfile", "openCustomerServiceChat", "openVideoEditor", "saveFileToDisk", "scanItem", "setEnable1v1Chat", "setWindowSize", "sendBizRedPacket", "startFacialRecognitionVerify" ]), o = "true", s = "false", a = "", c = "0", l = {
            Progress: {
                "border-radius": c,
                "font-size": "16",
                duration: "30",
                bindActiveEnd: a
            },
            RichText: {
                space: a,
                "user-select": s
            },
            Text: {
                "user-select": s
            },
            Map: {
                polygons: "[]",
                subkey: a,
                rotate: c,
                skew: c,
                "max-scale": "20",
                "min-scale": "3",
                "enable-3D": s,
                "show-compass": s,
                "show-scale": s,
                "enable-overlooking": s,
                "enable-zoom": o,
                "enable-scroll": o,
                "enable-rotate": s,
                "enable-satellite": s,
                "enable-traffic": s,
                "enable-poi": o,
                "enable-building": o,
                setting: "[]",
                bindLabelTap: a,
                bindRegionChange: a,
                bindPoiTap: a,
                bindAnchorPointTap: a
            },
            Button: {
                lang: "en",
                "session-from": a,
                "send-message-title": a,
                "send-message-path": a,
                "send-message-img": a,
                "app-parameter": a,
                "show-message-card": s,
                "business-id": a,
                bindGetUserInfo: a,
                bindContact: a,
                bindGetPhoneNumber: a,
                bindChooseAvatar: a,
                bindError: a,
                bindOpenSetting: a,
                bindLaunchApp: a
            },
            Form: {
                "report-submit-timeout": c
            },
            Input: {
                "always-embed": s,
                "adjust-position": o,
                "hold-keyboard": s,
                "safe-password-cert-path": "",
                "safe-password-length": "",
                "safe-password-time-stamp": "",
                "safe-password-nonce": "",
                "safe-password-salt": "",
                "safe-password-custom-hash": "",
                "auto-fill": a,
                bindKeyboardHeightChange: a,
                bindNicknameReview: a
            },
            Picker: {
                "header-text": a,
                level: "region"
            },
            PickerView: {
                "immediate-change": s,
                bindPickStart: a,
                bindPickEnd: a
            },
            Slider: {
                color: "'#e9e9e9'",
                "selected-color": "'#1aad19'"
            },
            Textarea: {
                "show-confirm-bar": o,
                "adjust-position": o,
                "hold-keyboard": s,
                "disable-default-padding": s,
                "confirm-type": "'return'",
                "confirm-hold": s,
                bindKeyboardHeightChange: a
            },
            ScrollView: {
                type: "'list'",
                "event-passive": s,
                "enable-flex": s,
                "scroll-anchoring": s,
                "refresher-enabled": s,
                "refresher-threshold": "45",
                "refresher-default-style": "'black'",
                "refresher-background": "'#FFF'",
                "refresher-triggered": s,
                enhanced: s,
                bounces: o,
                "show-scrollbar": o,
                "paging-enabled": s,
                "fast-deceleration": s,
                reverse: s,
                "cache-extent": c,
                "scroll-into-view-within-extent": s,
                "scroll-into-view-alignment": "'start'",
                bindDragStart: a,
                bindDragging: a,
                bindDragEnd: a,
                bindRefresherPulling: a,
                bindRefresherRefresh: a,
                bindRefresherRestore: a,
                bindRefresherAbort: a,
                bindScrollStart: a,
                bindScrollEnd: a,
                bindRefresherWillRefresh: a
            },
            StickySection: {
                "push-pinned-header": o
            },
            GridView: {
                type: "'aligned'",
                "cross-axis-count": "2",
                "max-cross-axis-extent": c,
                "main-axis-gap": c,
                "cross-axis-gap": c
            },
            ListView: {},
            StickyHeader: {},
            Swiper: {
                "snap-to-edge": s,
                "easing-function": "'default'"
            },
            SwiperItem: {
                "skip-hidden-item-layout": s
            },
            Navigator: {
                target: "'self'",
                "app-id": a,
                path: a,
                "extra-data": a,
                version: "'version'"
            },
            Camera: {
                mode: "'normal'",
                resolution: "'medium'",
                "frame-size": "'medium'",
                bindInitDone: a,
                bindScanCode: a
            },
            Image: {
                webp: s,
                "show-menu-by-longpress": s
            },
            LivePlayer: {
                mode: "'live'",
                "sound-mode": "'speaker'",
                "auto-pause-if-navigate": o,
                "auto-pause-if-open-native": o,
                "picture-in-picture-mode": "[]",
                bindstatechange: a,
                bindfullscreenchange: a,
                bindnetstatus: a,
                bindAudioVolumeNotify: a,
                bindEnterPictureInPicture: a,
                bindLeavePictureInPicture: a
            },
            Video: {
                title: a,
                "play-btn-position": "'bottom'",
                "enable-play-gesture": s,
                "auto-pause-if-navigate": o,
                "auto-pause-if-open-native": o,
                "vslide-gesture": s,
                "vslide-gesture-in-fullscreen": o,
                "ad-unit-id": a,
                "poster-for-crawler": a,
                "show-casting-button": s,
                "picture-in-picture-mode": "[]",
                "enable-auto-rotation": s,
                "show-screen-lock-button": s,
                "show-snapshot-button": s,
                "show-background-playback-button": s,
                "background-poster": a,
                bindProgress: a,
                bindLoadedMetadata: a,
                bindControlsToggle: a,
                bindEnterPictureInPicture: a,
                bindLeavePictureInPicture: a,
                bindSeekComplete: a,
                bindAdLoad: a,
                bindAdError: a,
                bindAdClose: a,
                bindAdPlay: a
            },
            Canvas: {
                type: a
            },
            Ad: {
                "ad-type": "'banner'",
                "ad-theme": "'white'"
            },
            CoverView: {
                "marker-id": a,
                slot: a
            },
            Editor: {
                "read-only": s,
                placeholder: a,
                "show-img-size": s,
                "show-img-toolbar": s,
                "show-img-resize": s,
                focus: s,
                bindReady: a,
                bindFocus: a,
                bindBlur: a,
                bindInput: a,
                bindStatusChange: a,
                name: a
            },
            MatchMedia: {
                "min-width": a,
                "max-width": a,
                width: a,
                "min-height": a,
                "max-height": a,
                height: a,
                orientation: a
            },
            FunctionalPageNavigator: {
                version: "'release'",
                name: a,
                args: a,
                bindSuccess: a,
                bindFail: a,
                bindCancel: a
            },
            LivePusher: {
                url: a,
                mode: "'RTC'",
                autopush: s,
                muted: s,
                "enable-camera": o,
                "auto-focus": o,
                orientation: "'vertical'",
                beauty: c,
                whiteness: c,
                aspect: "'9:16'",
                "min-bitrate": "200",
                "max-bitrate": "1000",
                "audio-quality": "'high'",
                "waiting-image": a,
                "waiting-image-hash": a,
                zoom: s,
                "device-position": "'front'",
                "background-mute": s,
                mirror: s,
                "remote-mirror": s,
                "local-mirror": s,
                "audio-reverb-type": c,
                "enable-mic": o,
                "enable-agc": s,
                "enable-ans": s,
                "audio-volume-type": "'voicecall'",
                "video-width": "360",
                "video-height": "640",
                "beauty-style": "'smooth'",
                filter: "'standard'",
                animation: a,
                bindStateChange: a,
                bindNetStatus: a,
                bindBgmStart: a,
                bindBgmProgress: a,
                bindBgmComplete: a,
                bindAudioVolumeNotify: a
            },
            OfficialAccount: {
                bindLoad: a,
                bindError: a
            },
            OpenData: {
                type: a,
                "open-gid": a,
                lang: "'en'",
                "default-text": a,
                "default-avatar": a,
                bindError: a
            },
            NavigationBar: {
                title: a,
                loading: s,
                "front-color": a,
                "background-color": a,
                "color-animation-duration": c,
                "color-animation-timing-func": "'linear'"
            },
            PageMeta: {
                "background-text-style": a,
                "background-color": a,
                "background-color-top": a,
                "background-color-bottom": a,
                "scroll-top": "''",
                "scroll-duration": "300",
                "page-style": "''",
                "root-font-size": "''",
                bindResize: a,
                bindScroll: a,
                bindScrollDone: a
            },
            VoipRoom: {
                openid: a,
                mode: "'camera'",
                "device-position": "'front'",
                bindError: a
            },
            AdCustom: {
                "unit-id": a,
                "ad-intervals": a,
                bindLoad: a,
                bindError: a
            },
            PageContainer: {
                show: s,
                duration: "300",
                "z-index": "100",
                overlay: o,
                position: "'bottom'",
                round: s,
                "close-on-slide-down": s,
                "overlay-style": a,
                "custom-style": a,
                bindBeforeEnter: a,
                bindEnter: a,
                bindAfterEnter: a,
                bindBeforeLeave: a,
                bindLeave: a,
                bindAfterLeave: a,
                bindClickOverlay: a
            },
            ShareElement: {
                mapkey: a,
                transform: s,
                duration: "300",
                "easing-function": "'ease-out'"
            },
            KeyboardAccessory: {},
            RootPortal: {},
            ChannelLive: {
                feedId: a,
                finderUserName: a
            },
            ChannelVideo: {
                feedId: a,
                finderUserName: a,
                autoplay: s,
                loop: s,
                muted: s,
                objectFit: "'contain'",
                bindError: a
            }
        }, u = {
            initNativeApi: function(t) {
                Object(i.u)(t, wx, {
                    needPromiseApis: r,
                    modifyApis(t) {
                        t.delete("lanDebug");
                    },
                    transformMeta(t, e) {
                        var n;
                        return "showShareMenu" === t && (e.menus = null === (n = e.showShareItems) || void 0 === n ? void 0 : n.map(t => "wechatFriends" === t ? "shareAppMessage" : "wechatMoment" === t ? "shareTimeline" : t)), 
                        {
                            key: t,
                            options: e
                        };
                    }
                }), t.cloud = wx.cloud, t.getTabBar = function(t) {
                    var e;
                    if ("function" == typeof (null == t ? void 0 : t.getTabBar)) return null === (e = t.getTabBar()) || void 0 === e ? void 0 : e.$taroInstances;
                }, t.getRenderer = function() {
                    var e, n, i;
                    return null !== (i = null === (n = null === (e = t.getCurrentInstance()) || void 0 === e ? void 0 : e.page) || void 0 === n ? void 0 : n.renderer) && void 0 !== i ? i : "webview";
                };
            },
            getMiniLifecycle(t) {
                const e = t.page[5];
                return -1 === e.indexOf("onSaveExitState") && e.push("onSaveExitState"), t;
            }
        };
        Object(i.s)(u), Object(i.r)(l);
    },
    120: function(t, e, n) {
        "use strict";
        n.r(e), n.d(e, "default", function() {
            return k;
        });
        var i = n(55), r = n.n(i), o = n(7), s = n(3), a = n(75), c = n.n(a), l = n(67), u = n.n(l), h = n(68), d = n.n(h), p = n(66), f = n.n(p);
        function g(t) {
            return "function" == typeof t;
        }
        function m(t) {
            return void 0 === t;
        }
        function b(t) {
            return t && "object" === r()(t);
        }
        var v = function(t) {
            return !b(t);
        };
        function y(t) {
            throw new TypeError(t);
        }
        g(Object.assign) || (Object.assign = function(t) {
            null == t && y("Cannot convert undefined or null to object");
            for (var e = Object(t), n = 1; n < arguments.length; n++) {
                var i = arguments[n];
                if (null != i) for (var r in i) Object.prototype.hasOwnProperty.call(i, r) && (e[r] = i[r]);
            }
            return e;
        }), g(Object.defineProperties) || (Object.defineProperties = function(t, e) {
            function n(t) {
                function e(t, e) {
                    return Object.prototype.hasOwnProperty.call(t, e);
                }
                v(t) && y("bad desc");
                var n = {};
                if (e(t, "enumerable") && (n.enumerable = !!t.enumerable), e(t, "configurable") && (n.configurable = !!t.configurable), 
                e(t, "value") && (n.value = t.value), e(t, "writable") && (n.writable = !!t.writable), 
                e(t, "get")) {
                    var i = t.get;
                    g(i) || m(i) || y("bad get"), n.get = i;
                }
                if (e(t, "set")) {
                    var r = t.set;
                    g(r) || m(r) || y("bad set"), n.set = r;
                }
                return ("get" in n || "set" in n) && ("value" in n || "writable" in n) && y("identity-confused descriptor"), 
                n;
            }
            v(t) && y("bad obj"), e = Object(e);
            for (var i = Object.keys(e), r = [], o = 0; o < i.length; o++) r.push([ i[o], n(e[i[o]]) ]);
            for (var s = 0; s < r.length; s++) Object.defineProperty(t, r[s][0], r[s][1]);
            return t;
        });
        var w = {
            WEAPP: "WEAPP",
            SWAN: "SWAN",
            ALIPAY: "ALIPAY",
            TT: "TT",
            QQ: "QQ",
            JD: "JD",
            WEB: "WEB",
            RN: "RN",
            HARMONY: "HARMONY",
            QUICKAPP: "QUICKAPP"
        };
        Object(s.q)();
        var S = function() {
            function t(e, n, i) {
                u()(this, t), this.index = i || 0, this.requestParams = e, this.interceptors = n || [];
            }
            return d()(t, [ {
                key: "proceed",
                value: function(t) {
                    if (this.requestParams = t, this.index >= this.interceptors.length) throw new Error("chain 参数错误, 请勿直接修改 request.chain");
                    var e = this._getNextInterceptor()(this._getNextChain()), n = e.catch(function(t) {
                        return Promise.reject(t);
                    });
                    return Object.keys(e).forEach(function(t) {
                        return g(e[t]) && (n[t] = e[t]);
                    }), n;
                }
            }, {
                key: "_getNextInterceptor",
                value: function() {
                    return this.interceptors[this.index];
                }
            }, {
                key: "_getNextChain",
                value: function() {
                    return new t(this.requestParams, this.interceptors, this.index + 1);
                }
            } ]), t;
        }(), O = function() {
            function t(e) {
                u()(this, t), this.taroInterceptor = e, this.chain = new S();
            }
            return d()(t, [ {
                key: "request",
                value: function(t) {
                    var e = this.chain, n = this.taroInterceptor;
                    return e.interceptors = e.interceptors.filter(function(t) {
                        return t !== n;
                    }).concat(n), e.proceed(c()({}, t));
                }
            }, {
                key: "addInterceptor",
                value: function(t) {
                    this.chain.interceptors.push(t);
                }
            }, {
                key: "cleanInterceptors",
                value: function() {
                    this.chain = new S();
                }
            } ]), t;
        }(), E = Object.freeze({
            __proto__: null,
            timeoutInterceptor: function(t) {
                var e, n = t.requestParams, i = new Promise(function(i, r) {
                    var o = setTimeout(function() {
                        o = null, r(new Error("网络链接超时,请稍后再试！"));
                    }, n && n.timeout || 6e4);
                    (e = t.proceed(n)).then(function(t) {
                        o && (clearTimeout(o), i(t));
                    }).catch(function(t) {
                        o && clearTimeout(o), r(t);
                    });
                });
                return !m(e) && g(e.abort) && (i.abort = e.abort), i;
            },
            logInterceptor: function(t) {
                var e = t.requestParams, n = e.method, i = e.data, r = e.url;
                console.log("http ".concat(n || "GET", " --\x3e ").concat(r, " data: "), i);
                var o = t.proceed(e), s = o.then(function(t) {
                    return console.log("http <-- ".concat(r, " result:"), t), t;
                });
                return g(o.abort) && (s.abort = o.abort), s;
            }
        }), T = {
            640: 1.17,
            750: 1,
            828: .905
        };
        function C(t) {
            return function(e) {
                var n = e.designWidth, i = void 0 === n ? 750 : n, r = e.deviceRatio, o = void 0 === r ? T : r, s = e.baseFontSize, a = void 0 === s ? 20 : s, c = e.targetUnit, l = void 0 === c ? "rpx" : c, u = e.unitPrecision, h = void 0 === u ? 5 : u;
                t.config = t.config || {}, t.config.designWidth = i, t.config.deviceRatio = o, t.config.baseFontSize = a, 
                t.config.targetUnit = l, t.config.unitPrecision = h;
            };
        }
        var k = {
            Behavior: function(t) {
                return t;
            },
            getEnv: function() {
                return w.WEAPP;
            },
            ENV_TYPE: w,
            Link: O,
            interceptors: E,
            Current: o.Current,
            getCurrentInstance: o.getCurrentInstance,
            options: o.options,
            nextTick: o.nextTick,
            eventCenter: o.eventCenter,
            Events: o.Events,
            getInitPxTransform: C,
            interceptorify: function(t) {
                return new O(function(e) {
                    return t(e.requestParams);
                });
            }
        };
        k.initPxTransform = C(k), k.preload = function(t) {
            return function(e, n) {
                t.preloadData = b(e) ? e : f()({}, e, n);
            };
        }(o.Current), k.pxTransform = function(t) {
            return function(e) {
                var n = t.config || {}, i = n.deviceRatio || T, r = n.baseFontSize, o = function() {
                    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0;
                    return g(n.designWidth) ? n.designWidth(t) : n.designWidth || 750;
                }(e);
                if (!(o in i)) throw new Error("deviceRatio 配置中不存在 ".concat(o, " 的设置！"));
                var s = ~~e, a = 1 / n.deviceRatio[o];
                switch (n.targetUnit) {
                  case "rem":
                    a *= 2 * r;
                    break;

                  case "px":
                    a *= 2;
                }
                var c = s / a;
                return n.unitPrecision >= 0 && n.unitPrecision <= 100 && (c = Number(c.toFixed(n.unitPrecision))), 
                c + n.targetUnit;
            };
        }(k);
    },
    165: function(t, e, n) {
        "use strict";
        n.r(e), n.d(e, "VirtualList", function() {
            return i;
        }), n.d(e, "default", function() {
            return i;
        });
        const i = n(170).default;
    },
    170: function(t, e, n) {
        "use strict";
        function i(t, e) {
            var n = {};
            for (var i in t) Object.prototype.hasOwnProperty.call(t, i) && e.indexOf(i) < 0 && (n[i] = t[i]);
            if (null != t && "function" == typeof Object.getOwnPropertySymbols) {
                var r = 0;
                for (i = Object.getOwnPropertySymbols(t); r < i.length; r++) e.indexOf(i[r]) < 0 && Object.prototype.propertyIsEnumerable.call(t, i[r]) && (n[i[r]] = t[i[r]]);
            }
            return n;
        }
        n.r(e), n.d(e, "default", function() {
            return T;
        }), Object.create, Object.create;
        var r = n(2), o = n(1), s = n.n(o);
        function a(t) {
            if ("string" == typeof t) {
                const e = t.toLowerCase();
                if (/px$/.test(e)) return Number(e.replace(/px$/, ""));
            }
            return t;
        }
        function c(t) {
            return t || 0 === t ? "number" == typeof t ? t + "px" : t : "";
        }
        var l = n(54), u = n(7);
        function h(t) {
            Object(u.cancelAnimationFrame)(t.id);
        }
        var d = n(71), p = n(3), f = n(5);
        const g = (t, e) => t;
        function m({direction: t, layout: e}) {
            return "horizontal" === t || "horizontal" === e;
        }
        function b(t, e, n, i = 500) {
            const r = Object(f.createSelectorQuery)();
            try {
                r.select(t).boundingClientRect(t => {
                    t ? null == e || e(t) : null == n || n();
                }).exec();
            } catch (r) {
                setTimeout(() => {
                    b(t, e, n, i);
                }, i);
            }
        }
        class v {
            constructor(t, e) {
                this.props = t, this.refresh = e, this.list = [], this.defaultSize = 1, this.update(t), 
                this.props.unlimitedSize ? this.mode = "unlimited" : Object(p.k)(this.props.itemSize) ? this.mode = "function" : this.mode = "normal", 
                this.defaultSize = (Object(p.k)(this.props.itemSize) ? this.props.itemSize() : this.props.itemSize) || 1, 
                this.isNormalMode || (this.list = new Array(this.length).fill(-1));
            }
            get isNormalMode() {
                return "normal" === this.mode;
            }
            get isFunctionMode() {
                return "function" === this.mode;
            }
            get isUnlimitedMode() {
                return "unlimited" === this.mode;
            }
            get length() {
                return this.props.itemCount || 100;
            }
            get overscan() {
                return this.props.overscanCount || 0;
            }
            get wrapperSize() {
                const {height: t, width: e} = this.props;
                return m(this.props) ? e : t;
            }
            update(t) {
                if (this.props = t, this.length > this.list.length) {
                    const t = new Array(this.length - this.list.length).fill(-1);
                    this.list.push(...t);
                } else this.length < this.list.length && (this.list.length = this.length);
            }
            setSize(t = 0, e = this.defaultSize) {
                var n;
                this.list[t] = e, null === (n = this.refresh) || void 0 === n || n.call(this);
            }
            getSize(t = 0) {
                const e = this.props.itemSize, n = this.list[t];
                if (n >= 0) return n;
                if (this.isFunctionMode && Object(p.k)(e)) {
                    const n = e(t, this.props.itemData);
                    return this.setSize(t, n), n;
                }
                return this.defaultSize;
            }
            getOffsetSize(t = this.list.length) {
                return this.isNormalMode ? t * this.defaultSize : this.list.slice(0, t).reduce((t, e, n) => t + this.getSize(n), 0);
            }
            getSizeCount(t = 0) {
                if (0 === t) return 0;
                let e = 0;
                return this.list.reduce((n, i, r) => e < t ? (e += this.getSize(r), ++n) : n, 0) - 1;
            }
            getStartIndex(t = 0) {
                return Math.max(0, this.getSizeCount(t) - 1);
            }
            getStopIndex(t = 0, e = 0, n = 0) {
                return Math.max(n, Math.min(this.length - 1, this.getSizeCount(t + e)));
            }
            getRangeToRender(t, e = 0, n = !1) {
                if (0 === this.length) return [ 0, 0, 0, 0 ];
                const i = this.wrapperSize, r = this.getStartIndex(e), o = this.getStopIndex(i, e, r), s = n && "backward" !== t ? 1 : Math.max(1, this.overscan), a = n && "forward" !== t ? 1 : Math.max(1, this.overscan);
                return [ Math.max(0, r - s), Math.max(0, Math.min(this.length - 1, o + a)), r, o ];
            }
            getOffsetForIndexAndAlignment(t, e, n) {
                const i = this.wrapperSize, r = this.getSize(t), o = Math.max(0, this.getOffsetSize(this.props.itemCount) - i), s = Math.min(o, this.getOffsetSize(t)), a = Math.max(0, this.getOffsetSize(t) - i + r);
                switch ("smart" === e && (e = n >= a - i && n <= s + i ? "auto" : "center"), e) {
                  case "start":
                    return s;

                  case "end":
                    return a;

                  case "center":
                    {
                        const t = Math.round(a + (s - a) / 2);
                        return t < Math.ceil(i / 2) ? 0 : t > o + Math.floor(i / 2) ? o : t;
                    }

                  case "auto":
                  default:
                    return n >= a && n <= s ? n : n < a ? a : s;
                }
            }
            compareSize(t = 0, e = 0) {
                return !!this.isNormalMode || this.getSize(t) === e;
            }
        }
        function y(...t) {
            return t.sort((t, e) => t - e)[Math.floor(t.length / 2)];
        }
        let w = 0;
        class S {
            constructor(t, e) {
                this.props = t, this.refresh = e, this.wrapperField = {
                    scrollLeft: 0,
                    scrollTop: 0,
                    scrollHeight: 0,
                    scrollWidth: 0,
                    clientHeight: 0,
                    clientWidth: 0,
                    diffOffset: 0
                }, this.diffList = [ 0, 0, 0 ], this.getItemStyleCache = Object(l.a)((t, e, n) => ({})), 
                this.init(this.props), this.itemList = new v(t, e);
            }
            init(t) {
                this.props = t;
            }
            update(t) {
                this.props = t, this.itemList.update(t);
            }
            get id() {
                return "virtual-list-" + w++;
            }
            get isHorizontal() {
                return m(this.props);
            }
            get isRtl() {
                return function({direction: t}) {
                    return "rtl" === t;
                }(this.props);
            }
            get isRelative() {
                return "relative" === this.props.position;
            }
            get placeholderCount() {
                return this.props.placeholderCount >= 0 ? this.props.placeholderCount : this.props.overscanCount;
            }
            get outerTagName() {
                return this.props.outerElementType || this.props.outerTagName || "div";
            }
            get innerTagName() {
                return this.props.innerElementType || this.props.innerTagName || "div";
            }
            get itemTagName() {
                return this.props.itemElementType || this.props.itemTagName || "div";
            }
            get field() {
                return this.wrapperField;
            }
            set field(t) {
                Object.assign(this.wrapperField, t);
            }
            isShaking(t) {
                const e = this.diffList.slice(-3);
                return this.diffList.push(t), -1 !== e.findIndex(e => Math.abs(e) === Math.abs(t)) || function(t, e = 0) {
                    let n = 0;
                    for (let i = 0; i < t.length - 1; i++) y(t[i], e, t[i + 1]) === e && n++;
                    return n === t.length - 1;
                }(this.diffList.slice(-4));
            }
            getItemStyle(t) {
                const {direction: e, itemSize: n, layout: i, shouldResetStyleCacheOnItemSizeChange: r} = this.props, o = this.getItemStyleCache(!!r && n, !!r && i, !!r && e);
                let s;
                const a = c(this.itemList.getOffsetSize(t)), l = c(this.itemList.getSize(t)), u = this.isHorizontal, h = this.isRtl;
                if (o.hasOwnProperty(t)) s = Object.assign({}, o[t]), u ? (s.width = l, this.isRelative || (h ? s.right = a : s.left = a)) : (s.height = l, 
                this.isRelative || (s.top = a)); else if (this.isRelative) o[t] = s = {
                    height: u ? "100%" : l,
                    width: u ? l : "100%"
                }; else {
                    const e = u ? a : 0;
                    o[t] = s = {
                        position: "absolute",
                        left: h ? void 0 : e,
                        right: h ? e : void 0,
                        top: u ? 0 : a,
                        height: u ? "100%" : l,
                        width: u ? l : "100%"
                    };
                }
                for (const t in s) s.hasOwnProperty(t) && (s[t] = c(s[t]));
                return s;
            }
        }
        class O extends s.a.PureComponent {
            static getDerivedStateFromProps(t, e) {
                return null;
            }
            constructor(t) {
                super(t), this.refresh = (() => {
                    this.setState(({refreshCount: t}) => ({
                        refreshCount: ++t
                    }));
                }), this._outerRef = void 0, this._resetIsScrollingTimeoutId = null, this._callOnItemsRendered = Object(l.a)((t, e, n, i) => this.props.onItemsRendered({
                    overscanStartIndex: t,
                    overscanStopIndex: e,
                    visibleStartIndex: n,
                    visibleStopIndex: i
                })), this._callOnScroll = Object(l.a)((t, e, n, i) => this.props.onScroll({
                    scrollDirection: t,
                    scrollOffset: e,
                    scrollUpdateWasRequested: n,
                    detail: i
                })), this._getSizeUploadSync = ((t, e) => {
                    const n = `#${this.state.id}-${t}`;
                    return new Promise(i => {
                        const r = ({width: n, height: r}) => {
                            const o = e ? n : r;
                            this.itemList.compareSize(t, o) || (this.itemList.setSize(t, o), i(this.itemList.getSize(t)));
                        }, o = () => {
                            const [e, i] = this._getRangeToRender();
                            t >= e && t <= i && setTimeout(() => {
                                b(n, r, o);
                            }, 100);
                        };
                        b(n, r, o);
                    });
                }), this._onScrollHorizontal = (t => {
                    const {clientWidth: e = this.itemList.wrapperSize, scrollHeight: n, scrollWidth: i = this.itemList.getOffsetSize(), scrollTop: r, scrollLeft: o} = t.currentTarget;
                    this.preset.field = {
                        scrollHeight: n,
                        scrollWidth: this.itemList.getOffsetSize(),
                        scrollTop: r,
                        scrollLeft: o,
                        clientHeight: n,
                        clientWidth: i
                    }, this.setState(t => {
                        const n = this.preset.field.scrollLeft - o;
                        if (t.scrollOffset === o || this.preset.isShaking(n)) return null;
                        let r = o;
                        if (this.preset.isRtl) switch (Object(d.a)()) {
                          case "negative":
                            r = -o;
                            break;

                          case "positive-descending":
                            r = i - e - o;
                        }
                        return this.preset.field = {
                            scrollWidth: r
                        }, {
                            isScrolling: !0,
                            scrollDirection: t.scrollOffset < o ? "forward" : "backward",
                            scrollOffset: r,
                            scrollUpdateWasRequested: !1
                        };
                    }, this._resetIsScrollingDebounced);
                }), this._onScrollVertical = (t => {
                    const {clientHeight: e = this.itemList.wrapperSize, scrollHeight: n = this.itemList.getOffsetSize(), scrollWidth: i, scrollTop: r, scrollLeft: o} = t.currentTarget;
                    this.setState(t => {
                        const s = this.preset.field.scrollTop - r;
                        if (t.scrollOffset === r || this.preset.isShaking(s)) return null;
                        const a = Math.max(0, Math.min(r, n - e));
                        return this.preset.field = {
                            scrollHeight: this.itemList.getOffsetSize(),
                            scrollWidth: i,
                            scrollTop: a,
                            scrollLeft: o,
                            clientHeight: e,
                            clientWidth: i,
                            diffOffset: this.preset.field.scrollTop - a
                        }, {
                            isScrolling: !0,
                            scrollDirection: t.scrollOffset < a ? "forward" : "backward",
                            scrollOffset: a,
                            scrollUpdateWasRequested: !1
                        };
                    }, this._resetIsScrollingDebounced);
                }), this._outerRefSetter = (t => {
                    const {outerRef: e} = this.props;
                    this._outerRef = t, "function" == typeof e ? e(t) : null != e && "object" == typeof e && e.hasOwnProperty("current") && (e.current = t);
                }), this._resetIsScrollingDebounced = (() => {
                    null !== this._resetIsScrollingTimeoutId && h(this._resetIsScrollingTimeoutId), 
                    this._resetIsScrollingTimeoutId = function(t, e = 0) {
                        const n = Object(u.now)(), i = {
                            id: Object(u.requestAnimationFrame)(function r() {
                                Object(u.now)() - n >= e ? t.call(null) : i.id = Object(u.requestAnimationFrame)(r);
                            })
                        };
                        return i;
                    }(this._resetIsScrolling, 200);
                }), this._resetIsScrolling = (() => {
                    this._resetIsScrollingTimeoutId = null, this.setState({
                        isScrolling: !1
                    }, () => {
                        this.preset.getItemStyleCache(-1, null);
                    });
                }), this.preset = new S(t, this.refresh), this.itemList = this.preset.itemList, 
                this.state = {
                    id: this.props.id || this.preset.id,
                    instance: this,
                    isScrolling: !1,
                    scrollDirection: "forward",
                    scrollOffset: "number" == typeof this.props.initialScrollOffset ? this.props.initialScrollOffset : 0,
                    scrollUpdateWasRequested: !1,
                    refreshCount: 0
                };
            }
            _callPropsCallbacks(t = {}, e = {}) {
                if ("function" == typeof this.props.onItemsRendered && this.props.itemCount > 0 && t && t.itemCount !== this.props.itemCount) {
                    const [t, e, n, i] = this._getRangeToRender();
                    this._callOnItemsRendered(t, e, n, i);
                }
                "function" == typeof this.props.onScroll && (e && e.scrollDirection === this.state.scrollDirection && e.scrollOffset === this.state.scrollOffset && e.scrollUpdateWasRequested === this.state.scrollUpdateWasRequested || this._callOnScroll(this.state.scrollDirection, this.state.scrollOffset, this.state.scrollUpdateWasRequested, this.preset.field)), 
                setTimeout(() => {
                    const [t, e] = this._getRangeToRender(), n = this.preset.isHorizontal;
                    for (let i = t; i <= e; i++) this._getSizeUploadSync(i, n);
                }, 0);
            }
            _getRangeToRender() {
                return this.itemList.getRangeToRender(this.state.scrollDirection, this.state.scrollOffset, this.state.isScrolling);
            }
            scrollTo(t = 0) {
                const {enhanced: e} = this.props;
                if (t = Math.max(0, t), this.state.scrollOffset !== t) {
                    if (e) {
                        const e = this.preset.isHorizontal, n = {
                            animated: !0,
                            duration: 500
                        };
                        return e ? n.left = t : n.top = t, async function(t) {
                            const e = Object(f.createSelectorQuery)();
                            return new Promise(n => e.select(t).node(({node: t}) => n(t)).exec());
                        }("#" + this.state.id).then(t => t.scrollTo(n));
                    }
                    this.setState(e => e.scrollOffset === t ? null : {
                        scrollDirection: e.scrollOffset < t ? "forward" : "backward",
                        scrollOffset: t,
                        scrollUpdateWasRequested: !0
                    }, this._resetIsScrollingDebounced);
                }
            }
            scrollToItem(t, e = "auto") {
                const {itemCount: n} = this.props, {scrollOffset: i} = this.state;
                t = Math.max(0, Math.min(t, n - 1)), this.scrollTo(this.itemList.getOffsetForIndexAndAlignment(t, e, i));
            }
            componentDidMount() {
                const {initialScrollOffset: t} = this.props;
                if ("number" == typeof t && null != this._outerRef) {
                    const e = this._outerRef;
                    this.preset.isHorizontal ? e.scrollLeft = t : e.scrollTop = t;
                }
                this._callPropsCallbacks();
            }
            componentDidUpdate(t, e) {
                const {scrollOffset: n, scrollUpdateWasRequested: i} = this.state;
                if (this.preset.update(this.props), i && null != this._outerRef) {
                    const t = this._outerRef;
                    if (this.preset.isHorizontal) if (this.preset.isRtl) switch (Object(d.a)()) {
                      case "negative":
                        t.scrollLeft = -n;
                        break;

                      case "positive-ascending":
                        t.scrollLeft = n;
                        break;

                      default:
                        t.scrollLeft = t.scrollWidth - t.clientWidth - n;
                    } else t.scrollLeft = n; else t.scrollTop = n;
                }
                this._callPropsCallbacks(t, e);
            }
            componentWillUnmount() {
                null !== this._resetIsScrollingTimeoutId && h(this._resetIsScrollingTimeoutId);
            }
            render() {
                const t = function(t = {}, e = []) {
                    const n = Object.assign({}, t);
                    return e.forEach(t => {
                        delete n[t];
                    }), n;
                }(this.props, [ "innerElementType", "innerTagName", "itemElementType", "itemTagName", "outerElementType", "outerTagName", "position" ]), {className: e, direction: n, height: r, innerRef: o, item: a, itemCount: l, itemData: u, itemKey: h = g, layout: d, style: p, useIsScrolling: f, width: m, enhanced: b = !1, renderTop: v, renderBottom: y} = t, w = i(t, [ "className", "direction", "height", "innerRef", "item", "itemCount", "itemData", "itemKey", "layout", "style", "useIsScrolling", "width", "enhanced", "renderTop", "renderBottom" ]), {id: S, isScrolling: O, scrollOffset: E, scrollUpdateWasRequested: T} = this.state, C = this.preset.isHorizontal, k = this.preset.placeholderCount, x = C ? this._onScrollHorizontal : this._onScrollVertical, [j, I] = this._getRangeToRender(), P = [];
                if (l > 0) {
                    const t = j < k ? j : k;
                    P.push(new Array(t).fill(-1).map((e, n) => s.a.createElement(this.preset.itemTagName, {
                        key: h(n + j - t, u),
                        style: {
                            display: "none"
                        }
                    })));
                    for (let t = j; t <= I; t++) {
                        const e = this.preset.getItemStyle(t);
                        P.push(s.a.createElement(this.preset.itemTagName, {
                            key: h(t, u),
                            style: e
                        }, s.a.createElement(a, {
                            id: `${S}-${t}`,
                            data: u,
                            index: t,
                            isScrolling: f ? O : void 0
                        })));
                    }
                    let e = l - I;
                    e = e > 0 ? e : 0;
                    const n = e < k ? e : k;
                    P.push(new Array(n).fill(-1).map((t, e) => s.a.createElement(this.preset.itemTagName, {
                        key: h(1 + e + I, u),
                        style: {
                            display: "none"
                        }
                    })));
                }
                const L = c(this.itemList.getOffsetSize()), N = Object.assign(Object.assign({}, w), {
                    id: S,
                    className: e,
                    onScroll: x,
                    ref: this._outerRefSetter,
                    layout: d,
                    enhanced: b,
                    style: Object.assign({
                        position: "relative",
                        height: c(r),
                        width: c(m),
                        overflow: "auto",
                        WebkitOverflowScrolling: "touch",
                        willChange: "transform",
                        direction: n
                    }, p)
                });
                if (b || (C ? N.scrollLeft = T ? E : this.preset.field.scrollLeft : N.scrollTop = T ? E : this.preset.field.scrollTop), 
                this.preset.isRelative) {
                    const t = c(this.itemList.getOffsetSize(j));
                    return s.a.createElement(this.preset.outerTagName, N, v, s.a.createElement(this.preset.itemTagName, {
                        key: S + "-pre",
                        id: S + "-pre",
                        style: {
                            height: C ? "100%" : t,
                            width: C ? t : "100%"
                        }
                    }), s.a.createElement(this.preset.innerTagName, {
                        ref: o,
                        key: S + "-inner",
                        id: S + "-inner",
                        style: {
                            pointerEvents: O ? "none" : "auto",
                            position: "relative"
                        }
                    }, P), y);
                }
                return s.a.createElement(this.preset.outerTagName, N, v, s.a.createElement(this.preset.innerTagName, {
                    ref: o,
                    key: S + "-inner",
                    id: S + "-inner",
                    style: {
                        height: C ? "100%" : L,
                        pointerEvents: O ? "none" : "auto",
                        position: "relative",
                        width: C ? L : "100%"
                    }
                }, P), y);
            }
        }
        O.defaultProps = {
            direction: "ltr",
            itemData: void 0,
            layout: "vertical",
            overscanCount: 2,
            useIsScrolling: !1,
            shouldResetStyleCacheOnItemSizeChange: !0
        };
        const E = s.a.forwardRef(function(t, e) {
            const n = t, {style: o, onScroll: c, onScrollNative: l, layout: u} = n, h = i(n, [ "style", "onScroll", "onScrollNative", "layout" ]);
            return s.a.createElement(r.d, Object.assign({
                ref: e,
                style: o,
                scrollY: "vertical" === u,
                scrollX: "horizontal" === u,
                onScroll: t => {
                    c(Object.assign(Object.assign({}, t), {
                        currentTarget: Object.assign(Object.assign({}, t.detail), {
                            clientWidth: a(o.width),
                            clientHeight: a(o.height)
                        })
                    })), "function" == typeof l && l(t);
                }
            }, h));
        }), T = s.a.forwardRef(function(t, e) {
            const n = t, {direction: o = "ltr", innerElementType: a = r.i, itemElementType: c = r.i, initialScrollOffset: l = 0, overscanCount: u = 1} = n, h = i(n, [ "direction", "innerElementType", "itemElementType", "initialScrollOffset", "overscanCount" ]);
            return "children" in h && (console.warn("Taro(VirtualList): children props have been deprecated. Please use the item props instead."), 
            h.item = h.children), h.item instanceof Array && (console.warn("Taro(VirtualList): item should not be an array"), 
            h.item = h.item[0]), s.a.createElement(O, Object.assign(Object.assign({
                ref: e
            }, h), {
                itemElementType: c,
                innerElementType: a,
                outerElementType: E,
                direction: o,
                initialScrollOffset: l,
                overscanCount: u
            }));
        });
    },
    182: function(t, e, n) {
        "use strict";
        n.r(e);
        var i = n(7);
        Component(Object(i.createRecursiveComponentConfig)());
    },
    183: function(t, e, n) {
        "use strict";
        Object.defineProperty(e, "__esModule", {
            value: !0
        });
        const i = n(7);
        Component((0, i.createRecursiveComponentConfig)("custom-wrapper"));
    },
    2: function(t, e, n) {
        "use strict";
        n.d(e, "a", function() {
            return o;
        }), n.d(e, "b", function() {
            return h;
        }), n.d(e, "c", function() {
            return s;
        }), n.d(e, "d", function() {
            return c;
        }), n.d(e, "e", function() {
            return l;
        }), n.d(e, "f", function() {
            return u;
        }), n.d(e, "g", function() {
            return r;
        }), n.d(e, "h", function() {
            return a;
        }), n.d(e, "i", function() {
            return i;
        });
        const i = "view", r = "text", o = "button", s = "input", a = "textarea", c = "scroll-view", l = "swiper", u = "swiper-item", h = "image";
    },
    3: function(t, e, n) {
        "use strict";
        n.d(e, "a", function() {
            return P;
        }), n.d(e, "b", function() {
            return m;
        }), n.d(e, "c", function() {
            return _;
        }), n.d(e, "d", function() {
            return f;
        }), n.d(e, "e", function() {
            return A;
        }), n.d(e, "f", function() {
            return z;
        }), n.d(e, "g", function() {
            return I;
        }), n.d(e, "h", function() {
            return p;
        }), n.d(e, "i", function() {
            return T;
        }), n.d(e, "j", function() {
            return S;
        }), n.d(e, "k", function() {
            return O;
        }), n.d(e, "l", function() {
            return y;
        }), n.d(e, "m", function() {
            return E;
        }), n.d(e, "n", function() {
            return w;
        }), n.d(e, "o", function() {
            return b;
        }), n.d(e, "p", function() {
            return v;
        }), n.d(e, "q", function() {
            return C;
        }), n.d(e, "r", function() {
            return U;
        }), n.d(e, "s", function() {
            return F;
        }), n.d(e, "t", function() {
            return L;
        }), n.d(e, "u", function() {
            return q;
        }), n.d(e, "v", function() {
            return R;
        }), n.d(e, "w", function() {
            return N;
        }), n.d(e, "x", function() {
            return M;
        });
        const i = "[]", r = "", o = "!0", s = "!1", a = {
            bindTouchStart: r,
            bindTouchMove: r,
            bindTouchEnd: r,
            bindTouchCancel: r,
            bindLongTap: r
        }, c = {
            animation: r,
            bindAnimationStart: r,
            bindAnimationIteration: r,
            bindAnimationEnd: r,
            bindTransitionEnd: r
        };
        function l(t) {
            return `'${t}'`;
        }
        const u = Object.assign(Object.assign({
            "hover-class": l("none"),
            "hover-stop-propagation": s,
            "hover-start-time": "50",
            "hover-stay-time": "400"
        }, a), c), h = {
            type: r,
            size: "23",
            color: r
        }, d = Object.assign({
            longitude: r,
            latitude: r,
            scale: "16",
            markers: i,
            covers: r,
            polyline: i,
            circles: i,
            controls: i,
            "include-points": i,
            "show-location": r,
            "layer-style": "1",
            bindMarkerTap: r,
            bindControlTap: r,
            bindCalloutTap: r,
            bindUpdated: r
        }, a), p = {
            View: u,
            Icon: h,
            Progress: {
                percent: r,
                "stroke-width": "6",
                color: l("#09BB07"),
                activeColor: l("#09BB07"),
                backgroundColor: l("#EBEBEB"),
                active: s,
                "active-mode": l("backwards"),
                "show-info": s
            },
            RichText: {
                nodes: i
            },
            Text: {
                selectable: s,
                space: r,
                decode: s
            },
            Button: Object.assign({
                size: l("default"),
                type: r,
                plain: s,
                disabled: r,
                loading: s,
                "form-type": r,
                "open-type": r,
                "hover-class": l("button-hover"),
                "hover-stop-propagation": s,
                "hover-start-time": "20",
                "hover-stay-time": "70",
                name: r
            }, a),
            Checkbox: {
                value: r,
                disabled: r,
                checked: s,
                color: l("#09BB07"),
                name: r
            },
            CheckboxGroup: {
                bindChange: r,
                name: r
            },
            Form: {
                "report-submit": s,
                bindSubmit: r,
                bindReset: r,
                name: r
            },
            Input: {
                value: r,
                type: l(r),
                password: s,
                placeholder: r,
                "placeholder-style": r,
                "placeholder-class": l("input-placeholder"),
                disabled: r,
                maxlength: "140",
                "cursor-spacing": "0",
                focus: s,
                "confirm-type": l("done"),
                "confirm-hold": s,
                cursor: "-1",
                "selection-start": "-1",
                "selection-end": "-1",
                bindInput: r,
                bindFocus: r,
                bindBlur: r,
                bindConfirm: r,
                name: r
            },
            Label: {
                for: r,
                name: r
            },
            Picker: {
                mode: l("selector"),
                disabled: r,
                range: r,
                "range-key": r,
                value: r,
                start: r,
                end: r,
                fields: l("day"),
                "custom-item": r,
                name: r,
                bindCancel: r,
                bindChange: r,
                bindColumnChange: r
            },
            PickerView: {
                value: r,
                "indicator-style": r,
                "indicator-class": r,
                "mask-style": r,
                "mask-class": r,
                bindChange: r,
                name: r
            },
            PickerViewColumn: {
                name: r
            },
            Radio: {
                value: r,
                checked: s,
                disabled: r,
                color: l("#09BB07"),
                name: r
            },
            RadioGroup: {
                bindChange: r,
                name: r
            },
            Slider: {
                min: "0",
                max: "100",
                step: "1",
                disabled: r,
                value: "0",
                activeColor: l("#1aad19"),
                backgroundColor: l("#e9e9e9"),
                "block-size": "28",
                "block-color": l("#ffffff"),
                "show-value": s,
                bindChange: r,
                bindChanging: r,
                name: r
            },
            Switch: {
                checked: s,
                disabled: r,
                type: l("switch"),
                color: l("#04BE02"),
                bindChange: r,
                name: r
            },
            CoverImage: {
                src: r,
                bindLoad: "eh",
                bindError: "eh"
            },
            Textarea: {
                value: r,
                placeholder: r,
                "placeholder-style": r,
                "placeholder-class": l("textarea-placeholder"),
                disabled: r,
                maxlength: "140",
                "auto-focus": s,
                focus: s,
                "auto-height": s,
                fixed: s,
                "cursor-spacing": "0",
                cursor: "-1",
                "selection-start": "-1",
                "selection-end": "-1",
                bindFocus: r,
                bindBlur: r,
                bindLineChange: r,
                bindInput: r,
                bindConfirm: r,
                name: r
            },
            CoverView: Object.assign({
                "scroll-top": s
            }, a),
            MovableArea: {
                "scale-area": s
            },
            MovableView: Object.assign(Object.assign({
                direction: "none",
                inertia: s,
                "out-of-bounds": s,
                x: r,
                y: r,
                damping: "20",
                friction: "2",
                disabled: r,
                scale: s,
                "scale-min": "0.5",
                "scale-max": "10",
                "scale-value": "1",
                bindChange: r,
                bindScale: r,
                bindHTouchMove: r,
                bindVTouchMove: r,
                width: l("10px"),
                height: l("10px")
            }, a), c),
            ScrollView: Object.assign(Object.assign({
                "scroll-x": s,
                "scroll-y": s,
                "upper-threshold": "50",
                "lower-threshold": "50",
                "scroll-top": r,
                "scroll-left": r,
                "scroll-into-view": r,
                "scroll-with-animation": s,
                "enable-back-to-top": s,
                bindScrollToUpper: r,
                bindScrollToLower: r,
                bindScroll: r
            }, a), c),
            Swiper: Object.assign({
                "indicator-dots": s,
                "indicator-color": l("rgba(0, 0, 0, .3)"),
                "indicator-active-color": l("#000000"),
                autoplay: s,
                current: "0",
                interval: "5000",
                duration: "500",
                circular: s,
                vertical: s,
                "previous-margin": l("0px"),
                "next-margin": l("0px"),
                "display-multiple-items": "1",
                bindChange: r,
                bindTransition: r,
                bindAnimationFinish: r
            }, a),
            SwiperItem: {
                "item-id": r
            },
            Navigator: {
                url: r,
                "open-type": l("navigate"),
                delta: "1",
                "hover-class": l("navigator-hover"),
                "hover-stop-propagation": s,
                "hover-start-time": "50",
                "hover-stay-time": "600",
                bindSuccess: r,
                bindFail: r,
                bindComplete: r
            },
            Audio: {
                id: r,
                src: r,
                loop: s,
                controls: s,
                poster: r,
                name: r,
                author: r,
                bindError: r,
                bindPlay: r,
                bindPause: r,
                bindTimeUpdate: r,
                bindEnded: r
            },
            Camera: {
                "device-position": l("back"),
                flash: l("auto"),
                bindStop: r,
                bindError: r
            },
            Image: Object.assign({
                src: r,
                mode: l("scaleToFill"),
                "lazy-load": s,
                bindError: r,
                bindLoad: r
            }, a),
            LivePlayer: Object.assign({
                src: r,
                autoplay: s,
                muted: s,
                orientation: l("vertical"),
                "object-fit": l("contain"),
                "background-mute": s,
                "min-cache": "1",
                "max-cache": "3",
                bindStateChange: r,
                bindFullScreenChange: r,
                bindNetStatus: r
            }, c),
            Video: Object.assign({
                src: r,
                duration: r,
                controls: o,
                "danmu-list": r,
                "danmu-btn": r,
                "enable-danmu": r,
                autoplay: s,
                loop: s,
                muted: s,
                "initial-time": "0",
                "page-gesture": s,
                direction: r,
                "show-progress": o,
                "show-fullscreen-btn": o,
                "show-play-btn": o,
                "show-center-play-btn": o,
                "enable-progress-gesture": o,
                "object-fit": l("contain"),
                poster: r,
                "show-mute-btn": s,
                bindPlay: r,
                bindPause: r,
                bindEnded: r,
                bindTimeUpdate: r,
                bindFullScreenChange: r,
                bindWaiting: r,
                bindError: r
            }, c),
            Canvas: Object.assign({
                "canvas-id": r,
                "disable-scroll": s,
                bindError: r
            }, a),
            Ad: {
                "unit-id": r,
                "ad-intervals": r,
                bindLoad: r,
                bindError: r,
                bindClose: r
            },
            WebView: {
                src: r,
                bindMessage: r,
                bindLoad: r,
                bindError: r
            },
            Block: {},
            Map: d,
            Slot: {
                name: r
            },
            SlotView: {
                name: r
            },
            NativeSlot: {
                name: r
            }
        }, f = new Set([ "input", "checkbox", "picker", "picker-view", "radio", "slider", "switch", "textarea" ]);
        var g;
        new Set([ "input", "textarea" ]), new Set([ "progress", "icon", "rich-text", "input", "textarea", "slider", "switch", "audio", "ad", "official-account", "open-data", "navigation-bar" ]), 
        new Map([ [ "view", -1 ], [ "catch-view", -1 ], [ "cover-view", -1 ], [ "static-view", -1 ], [ "pure-view", -1 ], [ "block", -1 ], [ "text", -1 ], [ "static-text", 6 ], [ "slot", 8 ], [ "slot-view", 8 ], [ "label", 6 ], [ "form", 4 ], [ "scroll-view", 4 ], [ "swiper", 4 ], [ "swiper-item", 4 ] ]), 
        function(t) {
            t.MINI = "mini", t.WEB = "web", t.RN = "rn", t.HARMONY = "harmony", t.QUICK = "quickapp";
        }(g || (g = {})), g.WEB, g.HARMONY, g.MINI, g.RN, g.QUICK;
        class m {
            constructor(t) {
                var e;
                this.callbacks = null !== (e = null == t ? void 0 : t.callbacks) && void 0 !== e ? e : {};
            }
            on(t, e, n) {
                let i, r, o;
                if (!e) return this;
                o = "symbol" == typeof t ? [ t ] : t.split(m.eventSplitter), this.callbacks || (this.callbacks = {});
                const s = this.callbacks;
                for (;i = o.shift(); ) {
                    const t = s[i], o = t ? t.tail : {};
                    o.next = r = {}, o.context = n, o.callback = e, s[i] = {
                        tail: r,
                        next: t ? t.next : o
                    };
                }
                return this;
            }
            once(t, e, n) {
                const i = (...r) => {
                    e.apply(this, r), this.off(t, i, n);
                };
                return this.on(t, i, n), this;
            }
            off(t, e, n) {
                let i, r, o;
                if (!(r = this.callbacks)) return this;
                if (!(t || e || n)) return delete this.callbacks, this;
                for (o = "symbol" == typeof t ? [ t ] : t ? t.split(m.eventSplitter) : Object.keys(r); i = o.shift(); ) {
                    let t = r[i];
                    if (delete r[i], !t || !e && !n) continue;
                    const o = t.tail;
                    for (;(t = t.next) !== o; ) {
                        const r = t.callback, o = t.context;
                        (e && r !== e || n && o !== n) && this.on(i, r, o);
                    }
                }
                return this;
            }
            trigger(t, ...e) {
                let n, i, r, o;
                if (!(r = this.callbacks)) return this;
                for (o = "symbol" == typeof t ? [ t ] : t.split(m.eventSplitter); n = o.shift(); ) if (i = r[n]) {
                    const t = i.tail;
                    for (;(i = i.next) !== t; ) i.callback.apply(i.context || this, e);
                }
                return this;
            }
        }
        function b(t) {
            return "string" == typeof t;
        }
        function v(t) {
            return void 0 === t;
        }
        function y(t) {
            return null === t;
        }
        function w(t) {
            return null !== t && "object" == typeof t;
        }
        function S(t) {
            return !0 === t || !1 === t;
        }
        function O(t) {
            return "function" == typeof t;
        }
        function E(t) {
            return "number" == typeof t;
        }
        m.eventSplitter = ",";
        const T = Array.isArray, C = () => !1;
        var k;
        !function(t) {
            t[t.SINGLE = 0] = "SINGLE", t[t.MULTI = 1] = "MULTI", t[t.WATERFALL = 2] = "WATERFALL";
        }(k || (k = {}));
        const x = {
            app: [ "onLaunch", "onShow", "onHide" ],
            page: [ "onLoad", "onUnload", "onReady", "onShow", "onHide", [ "onPullDownRefresh", "onReachBottom", "onPageScroll", "onResize", "onTabItemTap", "onTitleClick", "onOptionMenuClick", "onPopMenuClick", "onPullIntercept", "onAddToFavorites" ], [ "onShareAppMessage", "onShareTimeline" ] ],
            component: [ "attached", "detached" ]
        };
        function j(t, e) {
            return {
                type: t,
                initial: e || null
            };
        }
        const I = new class extends m {
            constructor(t, e) {
                super(e), this.hooks = t;
                for (const e in t) {
                    const {initial: n} = t[e];
                    O(n) && this.on(e, n);
                }
            }
            tapOneOrMany(t, e) {
                (O(e) ? [ e ] : e).forEach(e => this.on(t, e));
            }
            tap(t, e) {
                const n = this.hooks, {type: i, initial: r} = n[t];
                i === k.SINGLE ? (this.off(t), this.on(t, O(e) ? e : e[e.length - 1])) : (r && this.off(t, r), 
                this.tapOneOrMany(t, e));
            }
            call(t, ...e) {
                var n;
                const i = this.hooks[t];
                if (!i) return;
                const {type: r} = i, o = this.callbacks;
                if (!o) return;
                const s = o[t];
                if (s) {
                    const t = s.tail;
                    let i, o = s.next, a = e;
                    for (;o !== t; ) i = null === (n = o.callback) || void 0 === n ? void 0 : n.apply(o.context || this, a), 
                    r === k.WATERFALL && (a = [ i ]), o = o.next;
                    return i;
                }
            }
            isExist(t) {
                var e;
                return Boolean(null === (e = this.callbacks) || void 0 === e ? void 0 : e[t]);
            }
        }({
            getMiniLifecycle: j(k.SINGLE, t => t),
            getMiniLifecycleImpl: j(k.SINGLE, function() {
                return this.call("getMiniLifecycle", x);
            }),
            getLifecycle: j(k.SINGLE, (t, e) => t[e]),
            getPathIndex: j(k.SINGLE, t => `[${t}]`),
            getEventCenter: j(k.SINGLE, t => new t()),
            isBubbleEvents: j(k.SINGLE, t => new Set([ "touchstart", "touchmove", "touchcancel", "touchend", "touchforcechange", "tap", "longpress", "longtap", "transitionend", "animationstart", "animationiteration", "animationend" ]).has(t)),
            getSpecialNodes: j(k.SINGLE, () => [ "view", "text", "image" ]),
            onRemoveAttribute: j(k.SINGLE),
            batchedEventUpdates: j(k.SINGLE),
            mergePageInstance: j(k.SINGLE),
            modifyPageObject: j(k.SINGLE),
            createPullDownComponent: j(k.SINGLE),
            getDOMNode: j(k.SINGLE),
            modifyHydrateData: j(k.SINGLE),
            modifySetAttrPayload: j(k.SINGLE),
            modifyRmAttrPayload: j(k.SINGLE),
            onAddEvent: j(k.SINGLE),
            proxyToRaw: j(k.SINGLE, function(t) {
                return t;
            }),
            modifyMpEvent: j(k.MULTI),
            modifyMpEventImpl: j(k.SINGLE, function(t) {
                try {
                    this.call("modifyMpEvent", t);
                } catch (t) {
                    console.warn("[Taro modifyMpEvent hook Error]: " + (null == t ? void 0 : t.message));
                }
            }),
            injectNewStyleProperties: j(k.SINGLE),
            modifyTaroEvent: j(k.MULTI),
            dispatchTaroEvent: j(k.SINGLE, (t, e) => {
                e.dispatchEvent(t);
            }),
            dispatchTaroEventFinish: j(k.MULTI),
            modifyDispatchEvent: j(k.MULTI),
            initNativeApi: j(k.MULTI),
            patchElement: j(k.MULTI)
        }), P = {}, L = (...t) => {};
        function N(t) {
            return t.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase();
        }
        function R(t) {
            let e = "", n = !1;
            for (let i = 0; i < t.length; i++) "-" !== t[i] ? (e += n ? t[i].toUpperCase() : t[i], 
            n = !1) : n = !0;
            return e;
        }
        function _(t) {
            return t.charAt(0).toUpperCase() + t.slice(1);
        }
        function A(t, e) {
            if (!t) throw new Error(e);
        }
        function M(t, e) {}
        Object.prototype.hasOwnProperty;
        let B = 1;
        const D = new Date().getTime().toString();
        function U(t) {
            return Object.keys(t).forEach(e => {
                e in p ? Object.assign(p[e], t[e]) : p[e] = t[e];
            }), p;
        }
        function z(t) {
            const e = {}, n = t.View, i = {
                "#text": {},
                StaticView: n,
                StaticImage: t.Image,
                StaticText: t.Text,
                PureView: n,
                CatchView: n
            };
            return t = Object.assign(Object.assign({}, t), i), Object.keys(t).sort((t, e) => {
                const n = /^(Static|Pure|Catch)*(View|Image|Text)$/, i = n.test(t), r = n.test(e);
                return i && r ? t > e ? 1 : -1 : i ? -1 : r || t >= e ? 1 : -1;
            }).forEach((n, i) => {
                const r = {
                    _num: String(i)
                };
                Object.keys(t[n]).filter(t => !/^bind/.test(t) && ![ "focus", "blur" ].includes(t)).sort().forEach((t, e) => {
                    r[R(t)] = "p" + e;
                }), e[N(n)] = r;
            }), e;
        }
        function F(t, e) {
            const n = e || I;
            Object.keys(t).forEach(e => {
                n.tap(e, t[e]);
            });
        }
        function W(t) {
            return function() {
                console.warn("小程序暂不支持 " + t);
            };
        }
        function $(t, e) {
            if ([ "navigateTo", "redirectTo", "reLaunch", "switchTab" ].indexOf(t) > -1) {
                const t = (e.url = e.url || "").indexOf("?") > -1, n = D + B++;
                e.url += (t ? "&" : "?") + "__key_=" + n;
            }
        }
        const V = new Set([ "addPhoneContact", "authorize", "canvasGetImageData", "canvasPutImageData", "canvasToTempFilePath", "checkSession", "chooseAddress", "chooseImage", "chooseInvoiceTitle", "chooseLocation", "chooseVideo", "clearStorage", "closeBLEConnection", "closeBluetoothAdapter", "closeSocket", "compressImage", "connectSocket", "createBLEConnection", "downloadFile", "exitMiniProgram", "getAvailableAudioSources", "getBLEDeviceCharacteristics", "getBLEDeviceServices", "getBatteryInfo", "getBeacons", "getBluetoothAdapterState", "getBluetoothDevices", "getClipboardData", "getConnectedBluetoothDevices", "getConnectedWifi", "getExtConfig", "getFileInfo", "getImageInfo", "getLocation", "getNetworkType", "getSavedFileInfo", "getSavedFileList", "getScreenBrightness", "getSetting", "getStorage", "getStorageInfo", "getSystemInfo", "getUserInfo", "getWifiList", "hideHomeButton", "hideShareMenu", "hideTabBar", "hideTabBarRedDot", "loadFontFace", "login", "makePhoneCall", "navigateBack", "navigateBackMiniProgram", "navigateTo", "navigateToBookshelf", "navigateToMiniProgram", "notifyBLECharacteristicValueChange", "hideKeyboard", "hideLoading", "hideNavigationBarLoading", "hideToast", "openBluetoothAdapter", "openDocument", "openLocation", "openSetting", "pageScrollTo", "previewImage", "queryBookshelf", "reLaunch", "readBLECharacteristicValue", "redirectTo", "removeSavedFile", "removeStorage", "removeTabBarBadge", "requestSubscribeMessage", "saveFile", "saveImageToPhotosAlbum", "saveVideoToPhotosAlbum", "scanCode", "sendSocketMessage", "setBackgroundColor", "setBackgroundTextStyle", "setClipboardData", "setEnableDebug", "setInnerAudioOption", "setKeepScreenOn", "setNavigationBarColor", "setNavigationBarTitle", "setScreenBrightness", "setStorage", "setTabBarBadge", "setTabBarItem", "setTabBarStyle", "showActionSheet", "showFavoriteGuide", "showLoading", "showModal", "showShareMenu", "showTabBar", "showTabBarRedDot", "showToast", "startBeaconDiscovery", "startBluetoothDevicesDiscovery", "startDeviceMotionListening", "startPullDownRefresh", "stopBeaconDiscovery", "stopBluetoothDevicesDiscovery", "stopCompass", "startCompass", "startAccelerometer", "stopAccelerometer", "showNavigationBarLoading", "stopDeviceMotionListening", "stopPullDownRefresh", "switchTab", "uploadFile", "vibrateLong", "vibrateShort", "writeBLECharacteristicValue" ]);
        function q(t, e, n = {}) {
            const i = n.needPromiseApis || [], r = new Set([ ...i, ...V ]), o = [ "getEnv", "interceptors", "Current", "getCurrentInstance", "options", "nextTick", "eventCenter", "Events", "preload", "webpackJsonp" ], s = new Set(n.isOnlyPromisify ? i : Object.keys(e).filter(t => -1 === o.indexOf(t)));
            n.modifyApis && n.modifyApis(s), s.forEach(i => {
                if (r.has(i)) {
                    const r = i;
                    t[r] = ((t = {}, ...i) => {
                        let o = r;
                        if ("string" == typeof t) return i.length ? e[o](t, ...i) : e[o](t);
                        if (n.transformMeta) {
                            const i = n.transformMeta(o, t);
                            if (o = i.key, t = i.options, !e.hasOwnProperty(o)) return W(o)();
                        }
                        let s = null;
                        const a = Object.assign({}, t);
                        $(o, t);
                        const c = new Promise((r, c) => {
                            a.success = (e => {
                                var i, a;
                                null === (i = n.modifyAsyncResult) || void 0 === i || i.call(n, o, e), null === (a = t.success) || void 0 === a || a.call(t, e), 
                                r("connectSocket" === o ? Promise.resolve().then(() => s ? Object.assign(s, e) : e) : e);
                            }), a.fail = (e => {
                                var n;
                                null === (n = t.fail) || void 0 === n || n.call(t, e), c(e);
                            }), a.complete = (e => {
                                var n;
                                null === (n = t.complete) || void 0 === n || n.call(t, e);
                            }), s = i.length ? e[o](a, ...i) : e[o](a);
                        });
                        return [ "uploadFile", "downloadFile" ].includes(o) && (H(s, c), c.progress = (t => (null == s || s.onProgressUpdate(t), 
                        c)), c.abort = (t => (null == t || t(), null == s || s.abort(), c))), c;
                    });
                } else {
                    let r = i;
                    if (n.transformMeta && (r = n.transformMeta(i, {}).key), !e.hasOwnProperty(r)) return void (t[i] = W(i));
                    O(e[i]) ? t[i] = ((...t) => n.handleSyncApis ? n.handleSyncApis(i, e, t) : e[r].apply(e, t)) : t[i] = e[r];
                }
            }), !n.isOnlyPromisify && function(t, e, n = {}) {
                t.canIUseWebp = function(t) {
                    return function() {
                        var e;
                        const n = null === (e = t.getSystemInfoSync) || void 0 === e ? void 0 : e.call(t);
                        if (!n) return !1;
                        const {platform: i} = n, r = i.toLowerCase();
                        return "android" === r || "devtools" === r;
                    };
                }(t), t.getCurrentPages = getCurrentPages || W("getCurrentPages"), t.getApp = getApp || W("getApp"), 
                t.env = e.env || {};
                try {
                    t.requirePlugin = requirePlugin || W("requirePlugin");
                } catch (e) {
                    t.requirePlugin = W("requirePlugin");
                }
                const i = n.request || function(t) {
                    return function(e) {
                        const n = (e = e ? b(e) ? {
                            url: e
                        } : e : {}).success, i = e.fail, r = e.complete;
                        let o;
                        const s = new Promise((s, a) => {
                            e.success = (t => {
                                n && n(t), s(t);
                            }), e.fail = (t => {
                                i && i(t), a(t);
                            }), e.complete = (t => {
                                r && r(t);
                            }), o = t.request(e);
                        });
                        return H(o, s), s.abort = (t => (t && t(), o && o.abort(), s)), s;
                    };
                }(e), r = new t.Link(function(t) {
                    return i(t.requestParams);
                });
                t.request = r.request.bind(r), t.addInterceptor = r.addInterceptor.bind(r), t.cleanInterceptors = r.cleanInterceptors.bind(r), 
                t.miniGlobal = t.options.miniGlobal = e, t.getAppInfo = function() {
                    return {
                        platform: "mini",
                        taroVersion: "3.6.8",
                        designWidth: t.config.designWidth
                    };
                };
            }(t, e, n);
        }
        function H(t, e) {
            t && e && t && [ "abort", "onHeadersReceived", "offHeadersReceived", "onProgressUpdate", "offProgressUpdate", "onChunkReceived", "offChunkReceived" ].forEach(n => {
                n in t && (e[n] = t[n].bind(t));
            });
        }
    },
    5: function(t, e, n) {
        const {hooks: i} = n(7), r = n(120).default;
        i.isExist("initNativeApi") && i.call("initNativeApi", r), t.exports = r, t.exports.default = t.exports;
    },
    7: function(t, e, n) {
        "use strict";
        n.r(e), function(t, i, r, o, s) {
            n.d(e, "Current", function() {
                return Je;
            }), n.d(e, "FormElement", function() {
                return ue;
            }), n.d(e, "History", function() {
                return Ke;
            }), n.d(e, "Location", function() {
                return un;
            }), n.d(e, "MutationObserver", function() {
                return D;
            }), n.d(e, "SVGElement", function() {
                return wn;
            }), n.d(e, "Style", function() {
                return Ct;
            }), n.d(e, "TaroElement", function() {
                return It;
            }), n.d(e, "TaroEvent", function() {
                return oe;
            }), n.d(e, "TaroNode", function() {
                return it;
            }), n.d(e, "TaroRootElement", function() {
                return pe;
            }), n.d(e, "TaroText", function() {
                return fe;
            }), n.d(e, "URL", function() {
                return Re;
            }), n.d(e, "URLSearchParams", function() {
                return ke;
            }), n.d(e, "addLeadingSlash", function() {
                return xn;
            }), n.d(e, "cancelAnimationFrame", function() {
                return mn;
            }), n.d(e, "createComponentConfig", function() {
                return An;
            }), n.d(e, "createEvent", function() {
                return se;
            }), n.d(e, "createPageConfig", function() {
                return _n;
            }), n.d(e, "createRecursiveComponentConfig", function() {
                return Mn;
            }), n.d(e, "document", function() {
                return De;
            }), n.d(e, "eventCenter", function() {
                return ze;
            }), n.d(e, "eventHandler", function() {
                return le;
            }), n.d(e, "eventSource", function() {
                return J;
            }), n.d(e, "getComputedStyle", function() {
                return Ue;
            }), n.d(e, "getCurrentInstance", function() {
                return Qe;
            }), n.d(e, "getPageInstance", function() {
                return Cn;
            }), n.d(e, "getPath", function() {
                return Pn;
            }), n.d(e, "history", function() {
                return yn;
            }), n.d(e, "hydrate", function() {
                return et;
            }), n.d(e, "incrementId", function() {
                return U;
            }), n.d(e, "injectPageInstance", function() {
                return Tn;
            }), n.d(e, "location", function() {
                return vn;
            }), n.d(e, "navigator", function() {
                return dn;
            }), n.d(e, "nextTick", function() {
                return Bn;
            }), n.d(e, "now", function() {
                return pn;
            }), n.d(e, "options", function() {
                return Pt;
            }), n.d(e, "parseUrl", function() {
                return _e;
            }), n.d(e, "removePageInstance", function() {
                return kn;
            }), n.d(e, "requestAnimationFrame", function() {
                return gn;
            }), n.d(e, "safeExecute", function() {
                return jn;
            }), n.d(e, "stringify", function() {
                return In;
            }), n.d(e, "window", function() {
                return bn;
            });
            var a = n(3);
            n.d(e, "Events", function() {
                return a.b;
            }), n.d(e, "hooks", function() {
                return a.g;
            });
            const c = "页面初始化", l = "root", u = "id", h = "class", d = "style", p = "focus", f = "view", g = "static-view", m = "pure-view", b = "value", v = "input", y = "custom-wrapper", w = "type", S = "catchMove", O = "catch-view", E = "comment", T = "onLoad", C = "onReady", k = "onShow", x = "onHide", j = "options", I = "externalClasses", P = "e_result", L = "behaviors";
            var N;
            !function(t) {
                t.INIT = "0", t.RESTORE = "1", t.RECOVER = "2", t.DESTORY = "3";
            }(N || (N = {}));
            const R = [], _ = (t, e) => !!t && t.sid === (null == e ? void 0 : e.sid), A = (t, e) => {
                const {characterData: n, characterDataOldValue: i, attributes: r, attributeOldValue: o, childList: s} = e;
                switch (t.type) {
                  case "characterData":
                    return !!n && (i || (t.oldValue = null), !0);

                  case "attributes":
                    return !!r && (o || (t.oldValue = null), !0);

                  case "childList":
                    return !!s;
                }
            };
            let M = !1;
            function B(t, e) {
                t.records.push(e), M || (M = !0, Promise.resolve().then(() => {
                    M = !1, R.forEach(t => t.callback(t.takeRecords()));
                }));
            }
            class D {
                constructor(t) {
                    this.core = {
                        observe: a.t,
                        disconnect: a.t,
                        takeRecords: a.t
                    };
                }
                observe(...t) {
                    this.core.observe(...t);
                }
                disconnect() {
                    this.core.disconnect();
                }
                takeRecords() {
                    return this.core.takeRecords();
                }
                static record(t) {
                    !function(t) {
                        R.forEach(e => {
                            const {options: n} = e;
                            for (let i = t.target; i; i = i.parentNode) {
                                if (_(e.target, i) && A(t, n)) {
                                    B(e, t);
                                    break;
                                }
                                if (!n.subtree) break;
                            }
                        });
                    }(t);
                }
            }
            const U = () => {
                const t = [];
                for (let e = 65; e <= 90; e++) t.push(e);
                for (let e = 97; e <= 122; e++) t.push(e);
                const e = t.length - 1, n = [ 0, 0 ];
                return () => {
                    const i = n.map(e => t[e]), r = String.fromCharCode(...i);
                    let o = n.length - 1;
                    for (n[o]++; n[o] > e; ) {
                        if (n[o] = 0, o -= 1, o < 0) {
                            n.push(0);
                            break;
                        }
                        n[o]++;
                    }
                    return r;
                };
            };
            function z(t) {
                return 1 === t.nodeType;
            }
            function F(t) {
                return t.nodeName === E;
            }
            function W(t) {
                const e = Object.keys(t.props).find(t => !(/^(class|style|id)$/.test(t) || t.startsWith("data-")));
                return Boolean(e);
            }
            function $(t) {
                switch (t) {
                  case d:
                    return "st";

                  case u:
                    return "uid";

                  case h:
                    return "cl";

                  default:
                    return t;
                }
            }
            const V = new Map();
            function q(t, e, n) {
                Object(a.k)(n) && (n = {
                    value: n
                }), Object.defineProperty(t.prototype, e, Object.assign({
                    configurable: !0,
                    enumerable: !0
                }, n));
            }
            let H;
            function G() {
                return H || (H = Object(a.f)(a.h)), H;
            }
            class Y {
                constructor(t, e) {
                    this.tokenList = [], this.el = e, t.trim().split(/\s+/).forEach(t => this.tokenList.push(t));
                }
                get value() {
                    return this.toString();
                }
                get length() {
                    return this.tokenList.length;
                }
                add() {
                    let t = 0, e = !1;
                    const n = arguments, i = n.length, r = this.tokenList;
                    do {
                        const i = n[t];
                        this.checkTokenIsValid(i) && !~r.indexOf(i) && (r.push(i), e = !0);
                    } while (++t < i);
                    e && this._update();
                }
                remove() {
                    let t = 0, e = !1;
                    const n = arguments, i = n.length, r = this.tokenList;
                    do {
                        const i = n[t] + "";
                        if (!this.checkTokenIsValid(i)) continue;
                        const o = r.indexOf(i);
                        ~r.indexOf(i) && (r.splice(o, 1), e = !0);
                    } while (++t < i);
                    e && this._update();
                }
                contains(t) {
                    return !!this.checkTokenIsValid(t) && !!~this.tokenList.indexOf(t);
                }
                toggle(t, e) {
                    const n = this.contains(t), i = n ? !0 !== e && "remove" : !1 !== e && "add";
                    return i && this[i](t), !0 === e || !1 === e ? e : !n;
                }
                replace(t, e) {
                    if (!this.checkTokenIsValid(t) || !this.checkTokenIsValid(e)) return;
                    const n = this.tokenList.indexOf(t);
                    ~n && (this.tokenList.splice(n, 1, e), this._update());
                }
                toString() {
                    return this.tokenList.filter(t => "" !== t).join(" ");
                }
                checkTokenIsValid(t) {
                    return "" !== t && !/\s/.test(t);
                }
                _update() {
                    this.el.className = this.value;
                }
            }
            class K extends Map {
                removeNode(t) {
                    const {sid: e, uid: n} = t;
                    this.delete(e), n !== e && n && this.delete(n);
                }
                removeNodeTree(t) {
                    this.removeNode(t);
                    const {childNodes: e} = t;
                    e.forEach(t => this.removeNodeTree(t));
                }
            }
            const J = new K(), Q = Object(a.q)(), X = {
                window: Q ? t : a.a,
                document: Q ? i : a.a
            };
            let Z, tt;
            function et(t) {
                tt || (tt = G()), Z || (Z = a.g.call("getSpecialNodes"));
                const e = t.nodeName;
                if (function(t) {
                    return 3 === t.nodeType;
                }(t)) return {
                    v: t.nodeValue,
                    nn: tt[e]._num
                };
                const n = {
                    nn: e,
                    sid: t.sid
                };
                t.uid !== t.sid && (n.uid = t.uid), !t.isAnyEventBinded() && Z.indexOf(e) > -1 && (n.nn = "static-" + e, 
                e !== f || W(t) || (n.nn = m));
                const {props: i} = t;
                for (const t in i) {
                    const r = Object(a.v)(t);
                    t.startsWith("data-") || t === h || t === d || t === u || r === S || (n[r] = i[t]), 
                    e === f && r === S && !1 !== i[t] && (n.nn = O);
                }
                let {childNodes: r} = t;
                r = r.filter(t => !F(t)), r.length > 0 ? n.cn = r.map(et) : n.cn = [], "" !== t.className && (n.cl = t.className);
                const o = t.cssText;
                "" !== o && "swiper-item" !== e && (n.st = o), a.g.call("modifyHydrateData", n);
                const s = n.nn, c = tt[s];
                if (c) {
                    n.nn = c._num;
                    for (const t in n) t in c && (n[c[t]] = n[t], delete n[t]);
                }
                return n;
            }
            const nt = U();
            class it extends class {
                constructor() {
                    this.__handlers = {};
                }
                addEventListener(t, e, n) {
                    if (t = t.toLowerCase(), a.g.call("onAddEvent", t, e, n, this), "regionchange" === t) return this.addEventListener("begin", e, n), 
                    void this.addEventListener("end", e, n);
                    let i = Boolean(n), r = !1;
                    if (Object(a.n)(n) && (i = Boolean(n.capture), r = Boolean(n.once)), r) {
                        const i = function() {
                            e.apply(this, arguments), this.removeEventListener(t, i);
                        };
                        return void this.addEventListener(t, i, Object.assign(Object.assign({}, n), {
                            once: !1
                        }));
                    }
                    const o = e;
                    (e = function() {
                        return o.apply(this, arguments);
                    }).oldHandler = o;
                    const s = this.__handlers[t];
                    Object(a.i)(s) ? s.push(e) : this.__handlers[t] = [ e ];
                }
                removeEventListener(t, e) {
                    if ("regionchange" === (t = t.toLowerCase())) return this.removeEventListener("begin", e), 
                    void this.removeEventListener("end", e);
                    if (!e) return;
                    const n = this.__handlers[t];
                    if (!Object(a.i)(n)) return;
                    const i = n.findIndex(t => {
                        if (t === e || t.oldHandler === e) return !0;
                    });
                    n.splice(i, 1);
                }
                isAnyEventBinded() {
                    const t = this.__handlers, e = Object.keys(t).find(e => t[e].length);
                    return Boolean(e);
                }
            } {
                constructor() {
                    super(), this.parentNode = null, this.childNodes = [], this.hydrate = (t => () => et(t)), 
                    this.uid = "_" + nt(), this.sid = this.uid, J.set(this.sid, this);
                }
                updateChildNodes(t) {
                    this.enqueueUpdate({
                        path: this._path + ".cn",
                        value: t ? () => [] : () => this.childNodes.filter(t => !F(t)).map(et)
                    });
                }
                get _root() {
                    var t;
                    return (null === (t = this.parentNode) || void 0 === t ? void 0 : t._root) || null;
                }
                findIndex(t) {
                    const e = this.childNodes.indexOf(t);
                    return Object(a.e)(-1 !== e, "The node to be replaced is not a child of this node."), 
                    e;
                }
                get _path() {
                    const t = this.parentNode;
                    if (t) {
                        const e = t.childNodes.filter(t => !F(t)).indexOf(this), n = a.g.call("getPathIndex", e);
                        return `${t._path}.cn.${n}`;
                    }
                    return "";
                }
                get nextSibling() {
                    const t = this.parentNode;
                    return (null == t ? void 0 : t.childNodes[t.findIndex(this) + 1]) || null;
                }
                get previousSibling() {
                    const t = this.parentNode;
                    return (null == t ? void 0 : t.childNodes[t.findIndex(this) - 1]) || null;
                }
                get parentElement() {
                    const t = this.parentNode;
                    return 1 === (null == t ? void 0 : t.nodeType) ? t : null;
                }
                get firstChild() {
                    return this.childNodes[0] || null;
                }
                get lastChild() {
                    const t = this.childNodes;
                    return t[t.length - 1] || null;
                }
                set textContent(t) {
                    const e = this.childNodes.slice(), n = [];
                    for (;this.firstChild; ) this.removeChild(this.firstChild, {
                        doUpdate: !1
                    });
                    if ("" === t) this.updateChildNodes(!0); else {
                        const e = X.document.createTextNode(t);
                        n.push(e), this.appendChild(e), this.updateChildNodes();
                    }
                    D.record({
                        type: "childList",
                        target: this,
                        removedNodes: e,
                        addedNodes: n
                    });
                }
                insertBefore(t, e, n) {
                    if ("document-fragment" === t.nodeName) return t.childNodes.reduceRight((t, e) => (this.insertBefore(e, t), 
                    e), e), t;
                    if (t.remove({
                        cleanRef: !1
                    }), t.parentNode = this, e) {
                        const n = this.findIndex(e);
                        this.childNodes.splice(n, 0, t);
                    } else this.childNodes.push(t);
                    return this._root && (e ? n ? this.enqueueUpdate({
                        path: t._path,
                        value: this.hydrate(t)
                    }) : this.updateChildNodes() : 1 === this.childNodes.length ? this.updateChildNodes() : this.enqueueUpdate({
                        path: t._path,
                        value: this.hydrate(t)
                    })), D.record({
                        type: "childList",
                        target: this,
                        addedNodes: [ t ],
                        removedNodes: n ? [ e ] : [],
                        nextSibling: n ? e.nextSibling : e || null,
                        previousSibling: t.previousSibling
                    }), t;
                }
                appendChild(t) {
                    return this.insertBefore(t);
                }
                replaceChild(t, e) {
                    if (e.parentNode === this) return this.insertBefore(t, e, !0), e.remove({
                        doUpdate: !1
                    }), e;
                }
                removeChild(t, e = {}) {
                    const {cleanRef: n, doUpdate: i} = e;
                    !1 !== n && !1 !== i && D.record({
                        type: "childList",
                        target: this,
                        removedNodes: [ t ],
                        nextSibling: t.nextSibling,
                        previousSibling: t.previousSibling
                    });
                    const r = this.findIndex(t);
                    return this.childNodes.splice(r, 1), t.parentNode = null, !1 !== n && J.removeNodeTree(t), 
                    this._root && !1 !== i && this.updateChildNodes(), t;
                }
                remove(t) {
                    var e;
                    null === (e = this.parentNode) || void 0 === e || e.removeChild(this, t);
                }
                hasChildNodes() {
                    return this.childNodes.length > 0;
                }
                enqueueUpdate(t) {
                    var e;
                    null === (e = this._root) || void 0 === e || e.enqueueUpdate(t);
                }
                get ownerDocument() {
                    return X.document;
                }
                static extend(t, e) {
                    q(it, t, e);
                }
            }
            const rt = [ "all", "appearance", "blockOverflow", "blockSize", "bottom", "clear", "contain", "content", "continue", "cursor", "direction", "display", "filter", "float", "gap", "height", "inset", "isolation", "left", "letterSpacing", "lightingColor", "markerSide", "mixBlendMode", "opacity", "order", "position", "quotes", "resize", "right", "rowGap", "tabSize", "tableLayout", "top", "userSelect", "verticalAlign", "visibility", "voiceFamily", "volume", "whiteSpace", "widows", "width", "zIndex", "pointerEvents", "aspectRatio" ];
            function ot(t, e, n) {
                !n && rt.push(t), e.forEach(e => {
                    rt.push(t + e), "webkit" === t && rt.push("Webkit" + e);
                });
            }
            const st = "Color", at = "Style", ct = "Width", lt = "Image", ut = "Size", ht = [ st, at, ct ], dt = [ "FitLength", "FitWidth", lt ], pt = [ ...dt, "Radius" ], ft = [ ...ht, ...dt ], gt = [ "EndRadius", "StartRadius" ], mt = [ "Bottom", "Left", "Right", "Top" ], bt = [ "End", "Start" ], vt = [ "Content", "Items", "Self" ], yt = [ "BlockSize", "Height", "InlineSize", ct ], wt = [ "After", "Before" ];
            function St(t) {
                D.record({
                    type: "attributes",
                    target: t._element,
                    attributeName: "style",
                    oldValue: t.cssText
                });
            }
            function Ot(t) {
                const e = t._element;
                e._root && e.enqueueUpdate({
                    path: e._path + ".st",
                    value: t.cssText
                });
            }
            function Et(t, e) {
                this[e] !== t && (!this._pending && St(this), Object(a.l)(t) || Object(a.p)(t) ? (this._usedStyleProp.delete(e), 
                delete this._value[e]) : (this._usedStyleProp.add(e), this._value[e] = t), !this._pending && Ot(this));
            }
            function Tt(t, e) {
                const n = {};
                for (let i = 0; i < e.length; i++) {
                    const r = e[i];
                    if (t[r]) return;
                    n[r] = {
                        get() {
                            const t = this._value[r];
                            return Object(a.l)(t) || Object(a.p)(t) ? "" : t;
                        },
                        set(t) {
                            Et.call(this, t, r);
                        }
                    };
                }
                Object.defineProperties(t.prototype, n);
            }
            ot("borderBlock", ht), ot("borderBlockEnd", ht), ot("borderBlockStart", ht), ot("outline", [ ...ht, "Offset" ]), 
            ot("border", [ ...ht, "Boundary", "Break", "Collapse", "Radius", "Spacing" ]), ot("borderFit", [ "Length", ct ]), 
            ot("borderInline", ht), ot("borderInlineEnd", ht), ot("borderInlineStart", ht), 
            ot("borderLeft", ft), ot("borderRight", ft), ot("borderTop", ft), ot("borderBottom", ft), 
            ot("textDecoration", [ st, at, "Line" ]), ot("textEmphasis", [ st, at, "Position" ]), 
            ot("scrollMargin", mt), ot("scrollPadding", mt), ot("padding", mt), ot("margin", [ ...mt, "Trim" ]), 
            ot("scrollMarginBlock", bt), ot("scrollMarginInline", bt), ot("scrollPaddingBlock", bt), 
            ot("scrollPaddingInline", bt), ot("gridColumn", bt), ot("gridRow", bt), ot("insetBlock", bt), 
            ot("insetInline", bt), ot("marginBlock", bt), ot("marginInline", bt), ot("paddingBlock", bt), 
            ot("paddingInline", bt), ot("pause", wt), ot("cue", wt), ot("mask", [ "Clip", "Composite", lt, "Mode", "Origin", "Position", "Repeat", ut, "Type" ]), 
            ot("borderImage", [ "Outset", "Repeat", "Slice", "Source", "Transform", ct ]), ot("maskBorder", [ "Mode", "Outset", "Repeat", "Slice", "Source", ct ]), 
            ot("font", [ "Family", "FeatureSettings", "Kerning", "LanguageOverride", "MaxSize", "MinSize", "OpticalSizing", "Palette", ut, "SizeAdjust", "Stretch", at, "Weight", "VariationSettings" ]), 
            ot("transform", [ "Box", "Origin", at ]), ot("background", [ st, lt, "Attachment", "BlendMode", "Clip", "Origin", "Position", "Repeat", ut ]), 
            ot("listStyle", [ lt, "Position", "Type" ]), ot("scrollSnap", [ "Align", "Stop", "Type" ]), 
            ot("grid", [ "Area", "AutoColumns", "AutoFlow", "AutoRows" ]), ot("gridTemplate", [ "Areas", "Columns", "Rows" ]), 
            ot("overflow", [ "Block", "Inline", "Wrap", "X", "Y" ]), ot("transition", [ "Delay", "Duration", "Property", "TimingFunction" ]), 
            ot("color", [ "Adjust", "InterpolationFilters", "Scheme" ]), ot("textAlign", [ "All", "Last" ]), 
            ot("page", [ "BreakAfter", "BreakBefore", "BreakInside" ]), ot("animation", [ "Delay", "Direction", "Duration", "FillMode", "IterationCount", "Name", "PlayState", "TimingFunction" ]), 
            ot("flex", [ "Basis", "Direction", "Flow", "Grow", "Shrink", "Wrap" ]), ot("offset", [ ...wt, ...bt, "Anchor", "Distance", "Path", "Position", "Rotate" ]), 
            ot("perspective", [ "Origin" ]), ot("clip", [ "Path", "Rule" ]), ot("flow", [ "From", "Into" ]), 
            ot("align", [ "Content", "Items", "Self" ], !0), ot("alignment", [ "Adjust", "Baseline" ], !0), 
            ot("borderStart", gt, !0), ot("borderEnd", gt, !0), ot("borderCorner", [ "Fit", lt, "ImageTransform" ], !0), 
            ot("borderTopLeft", pt, !0), ot("borderTopRight", pt, !0), ot("borderBottomLeft", pt, !0), 
            ot("borderBottomRight", pt, !0), ot("column", [ "s", "Count", "Fill", "Gap", "Rule", "RuleColor", "RuleStyle", "RuleWidth", "Span", ct ], !0), 
            ot("break", [ ...wt, "Inside" ], !0), ot("wrap", [ ...wt, "Flow", "Inside", "Through" ], !0), 
            ot("justify", vt, !0), ot("place", vt, !0), ot("max", [ ...yt, "Lines" ], !0), ot("min", yt, !0), 
            ot("line", [ "Break", "Clamp", "Grid", "Height", "Padding", "Snap" ], !0), ot("inline", [ "BoxAlign", ut, "Sizing" ], !0), 
            ot("text", [ "CombineUpright", "GroupAlign", "Height", "Indent", "Justify", "Orientation", "Overflow", "Shadow", "SpaceCollapse", "SpaceTrim", "Spacing", "Transform", "UnderlinePosition", "Wrap" ], !0), 
            ot("shape", [ "ImageThreshold", "Inside", "Margin", "Outside" ], !0), ot("word", [ "Break", "Spacing", "Wrap" ], !0), 
            ot("object", [ "Fit", "Position" ], !0), ot("box", [ "DecorationBreak", "Shadow", "Sizing", "Snap" ], !0), 
            ot("webkit", [ "LineClamp", "BoxOrient", "TextFillColor", "TextStroke", "TextStrokeColor", "TextStrokeWidth" ], !0);
            class Ct {
                constructor(t) {
                    this._element = t, this._usedStyleProp = new Set(), this._value = {};
                }
                setCssVariables(t) {
                    this.hasOwnProperty(t) || Object.defineProperty(this, t, {
                        enumerable: !0,
                        configurable: !0,
                        get: () => this._value[t] || "",
                        set: e => {
                            Et.call(this, e, t);
                        }
                    });
                }
                get cssText() {
                    if (!this._usedStyleProp.size) return "";
                    const t = [];
                    return this._usedStyleProp.forEach(e => {
                        const n = this[e];
                        if (Object(a.l)(n) || Object(a.p)(n)) return;
                        let i = function(t) {
                            return /^--/.test(t);
                        }(e) ? e : Object(a.w)(e);
                        0 !== i.indexOf("webkit") && 0 !== i.indexOf("Webkit") || (i = "-" + i), t.push(`${i}: ${n};`);
                    }), t.join(" ");
                }
                set cssText(t) {
                    if (this._pending = !0, St(this), this._usedStyleProp.forEach(t => {
                        this.removeProperty(t);
                    }), "" === t || Object(a.p)(t) || Object(a.l)(t)) return this._pending = !1, void Ot(this);
                    const e = t.split(";");
                    for (let t = 0; t < e.length; t++) {
                        const n = e[t].trim();
                        if ("" === n) continue;
                        const [i, ...r] = n.split(":"), o = r.join(":");
                        Object(a.p)(o) || this.setProperty(i.trim(), o.trim());
                    }
                    this._pending = !1, Ot(this);
                }
                setProperty(t, e) {
                    "-" === t[0] ? this.setCssVariables(t) : t = Object(a.v)(t), Object(a.l)(e) || Object(a.p)(e) ? this.removeProperty(t) : this[t] = e;
                }
                removeProperty(t) {
                    if (t = Object(a.v)(t), !this._usedStyleProp.has(t)) return "";
                    const e = this[t];
                    return this[t] = void 0, e;
                }
                getPropertyValue(t) {
                    return this[t = Object(a.v)(t)] || "";
                }
            }
            function kt() {
                return !0;
            }
            function xt(t, e) {
                const n = [], i = null != e ? e : kt;
                let r = t;
                for (;r; ) 1 === r.nodeType && i(r) && n.push(r), r = jt(r, t);
                return n;
            }
            function jt(t, e) {
                const n = t.firstChild, i = 1 === t.nodeType || 9 === t.nodeType;
                if (n && i) return n;
                let r = t;
                do {
                    if (r === e) return null;
                    const t = r.nextSibling;
                    if (t) return t;
                    r = r.parentElement;
                } while (r);
                return null;
            }
            Tt(Ct, rt), a.g.tap("injectNewStyleProperties", t => {
                if (Object(a.i)(t)) Tt(Ct, t); else {
                    if ("string" != typeof t) return;
                    Tt(Ct, [ t ]);
                }
            });
            class It extends it {
                constructor() {
                    super(), this.props = {}, this.dataset = a.a, this.nodeType = 1, this.style = new Ct(this), 
                    a.g.call("patchElement", this);
                }
                _stopPropagation(t) {
                    let e = this;
                    for (;e = e.parentNode; ) {
                        const n = e.__handlers[t.type];
                        if (Object(a.i)(n)) for (let t = n.length; t--; ) n[t]._stop = !0;
                    }
                }
                get id() {
                    return this.getAttribute(u);
                }
                set id(t) {
                    this.setAttribute(u, t);
                }
                get className() {
                    return this.getAttribute(h) || "";
                }
                set className(t) {
                    this.setAttribute(h, t);
                }
                get cssText() {
                    return this.getAttribute(d) || "";
                }
                get classList() {
                    return new Y(this.className, this);
                }
                get children() {
                    return this.childNodes.filter(z);
                }
                get attributes() {
                    const t = this.props, e = Object.keys(t), n = this.style.cssText;
                    return e.map(e => ({
                        name: e,
                        value: t[e]
                    })).concat(n ? {
                        name: d,
                        value: n
                    } : []);
                }
                get textContent() {
                    let t = "";
                    const e = this.childNodes;
                    for (let n = 0; n < e.length; n++) t += e[n].textContent;
                    return t;
                }
                set textContent(t) {
                    super.textContent = t;
                }
                hasAttribute(t) {
                    return !Object(a.p)(this.props[t]);
                }
                hasAttributes() {
                    return this.attributes.length > 0;
                }
                get focus() {
                    return function() {
                        this.setAttribute(p, !0);
                    };
                }
                set focus(t) {
                    this.setAttribute(p, t);
                }
                blur() {
                    this.setAttribute(p, !1);
                }
                setAttribute(t, e) {
                    const n = this.nodeName === f && !W(this) && !this.isAnyEventBinded();
                    switch (t !== d && D.record({
                        target: this,
                        type: "attributes",
                        attributeName: t,
                        oldValue: this.getAttribute(t)
                    }), t) {
                      case d:
                        this.style.cssText = e;
                        break;

                      case u:
                        this.uid !== this.sid && J.delete(this.uid), e = String(e), this.props[t] = this.uid = e, 
                        J.set(e, this);
                        break;

                      default:
                        this.props[t] = e, t.startsWith("data-") && (this.dataset === a.a && (this.dataset = Object.create(null)), 
                        this.dataset[Object(a.v)(t.replace(/^data-/, ""))] = e);
                    }
                    if (!this._root) return;
                    const i = G(), r = i[this.nodeName], o = i[f]._num, s = i[g]._num, c = i[O]._num, l = this._path;
                    t = $(t);
                    const h = Object(a.v)(t), p = {
                        path: `${l}.${h}`,
                        value: Object(a.k)(e) ? () => e : e
                    };
                    if (a.g.call("modifySetAttrPayload", this, t, p, i), r) {
                        const e = r[h] || t;
                        p.path = `${l}.${Object(a.v)(e)}`;
                    }
                    this.enqueueUpdate(p), this.nodeName === f && (h === S ? this.enqueueUpdate({
                        path: l + ".nn",
                        value: e ? c : this.isAnyEventBinded() ? o : s
                    }) : n && W(this) && this.enqueueUpdate({
                        path: l + ".nn",
                        value: s
                    }));
                }
                removeAttribute(t) {
                    const e = this.nodeName === f && W(this) && !this.isAnyEventBinded();
                    if (D.record({
                        target: this,
                        type: "attributes",
                        attributeName: t,
                        oldValue: this.getAttribute(t)
                    }), t === d) this.style.cssText = ""; else {
                        if (a.g.call("onRemoveAttribute", this, t)) return;
                        if (!this.props.hasOwnProperty(t)) return;
                        delete this.props[t];
                    }
                    if (!this._root) return;
                    const n = G(), i = n[this.nodeName], r = n[f]._num, o = n[g]._num, s = n[m]._num, c = this._path;
                    t = $(t);
                    const l = Object(a.v)(t), u = {
                        path: `${c}.${l}`,
                        value: ""
                    };
                    if (a.g.call("modifyRmAttrPayload", this, t, u, n), i) {
                        const e = i[l] || t;
                        u.path = `${c}.${Object(a.v)(e)}`;
                    }
                    this.enqueueUpdate(u), this.nodeName === f && (l === S ? this.enqueueUpdate({
                        path: c + ".nn",
                        value: this.isAnyEventBinded() ? r : W(this) ? o : s
                    }) : e && !W(this) && this.enqueueUpdate({
                        path: c + ".nn",
                        value: s
                    }));
                }
                getAttribute(t) {
                    const e = t === d ? this.style.cssText : this.props[t];
                    return null != e ? e : "";
                }
                getElementsByTagName(t) {
                    return xt(this, e => e.nodeName === t || "*" === t && this !== e);
                }
                getElementsByClassName(t) {
                    const e = t.trim().split(/\s+/);
                    return xt(this, t => {
                        const n = t.classList;
                        return e.every(t => n.contains(t));
                    });
                }
                dispatchEvent(t) {
                    const e = t.cancelable, n = this.__handlers[t.type];
                    if (!Object(a.i)(n)) return !1;
                    for (let i = n.length; i--; ) {
                        const r = n[i];
                        let o;
                        if (r._stop ? r._stop = !1 : (a.g.call("modifyDispatchEvent", t, this), o = r.call(this, t)), 
                        (!1 === o || t._end) && e && (t.defaultPrevented = !0), !Object(a.p)(o) && t.mpEvent && (t.mpEvent[P] = o), 
                        t._end && t._stop) break;
                    }
                    return t._stop ? this._stopPropagation(t) : t._stop = !0, null != n;
                }
                addEventListener(t, e, n) {
                    const i = this.nodeName, r = a.g.call("getSpecialNodes");
                    let o = !0;
                    if (Object(a.n)(n) && !1 === n.sideEffect && (o = !1, delete n.sideEffect), !1 !== o && !this.isAnyEventBinded() && r.indexOf(i) > -1) {
                        const t = G()[i]._num;
                        this.enqueueUpdate({
                            path: this._path + ".nn",
                            value: t
                        });
                    }
                    super.addEventListener(t, e, n);
                }
                removeEventListener(t, e, n = !0) {
                    super.removeEventListener(t, e);
                    const i = this.nodeName, r = a.g.call("getSpecialNodes");
                    if (!1 !== n && !this.isAnyEventBinded() && r.indexOf(i) > -1) {
                        const t = G()[W(this) ? "static-" + i : "pure-" + i]._num;
                        this.enqueueUpdate({
                            path: this._path + ".nn",
                            value: t
                        });
                    }
                }
                static extend(t, e) {
                    q(It, t, e);
                }
            }
            const Pt = {
                prerender: !0,
                debug: !1
            };
            function Lt(t, e, n) {
                const i = t.index, r = t.index = i + n;
                for (let n = i; n < r; n++) "\n" === e.charAt(n) ? (t.line++, t.column = 0) : t.column++;
            }
            function Nt(t, e, n) {
                return Lt(t, e, n - t.index);
            }
            function Rt(t) {
                return {
                    index: t.index,
                    line: t.line,
                    column: t.column
                };
            }
            const _t = /\s/;
            function At(t) {
                return _t.test(t);
            }
            const Mt = /=/;
            function Bt(t) {
                return Mt.test(t);
            }
            function Dt(t) {
                const e = t.toLowerCase();
                return !!Pt.html.skipElements.has(e);
            }
            const Ut = /[A-Za-z0-9]/;
            function zt(t, e, n) {
                if (!At(n.charAt(t))) return !1;
                const i = n.length;
                for (let i = t - 1; i > e; i--) {
                    const t = n.charAt(i);
                    if (!At(t)) {
                        if (Bt(t)) return !1;
                        break;
                    }
                }
                for (let e = t + 1; e < i; e++) {
                    const t = n.charAt(e);
                    if (!At(t)) return !Bt(t);
                }
            }
            class Ft {
                constructor(t) {
                    this.tokens = [], this.position = {
                        index: 0,
                        column: 0,
                        line: 0
                    }, this.html = t;
                }
                scan() {
                    const {html: t, position: e} = this, n = t.length;
                    for (;e.index < n; ) {
                        const n = e.index;
                        if (this.scanText(), e.index === n) if (t.startsWith("!--", n + 1)) this.scanComment(); else {
                            const t = this.scanTag();
                            Dt(t) && this.scanSkipTag(t);
                        }
                    }
                    return this.tokens;
                }
                scanText() {
                    const {html: t, position: e} = this;
                    let n = function(t, e) {
                        for (;;) {
                            const n = t.indexOf("<", e);
                            if (-1 === n) return n;
                            const i = t.charAt(n + 1);
                            if ("/" === i || "!" === i || Ut.test(i)) return n;
                            e = n + 1;
                        }
                    }(t, e.index);
                    if (n === e.index) return;
                    -1 === n && (n = t.length);
                    const i = Rt(e), r = t.slice(e.index, n);
                    Nt(e, t, n);
                    const o = Rt(e);
                    this.tokens.push({
                        type: "text",
                        content: r,
                        position: {
                            start: i,
                            end: o
                        }
                    });
                }
                scanComment() {
                    const {html: t, position: e} = this, n = Rt(e);
                    Lt(e, t, 4);
                    let i = t.indexOf("--\x3e", e.index), r = i + 3;
                    -1 === i && (i = r = t.length);
                    const o = t.slice(e.index, i);
                    Nt(e, t, r), this.tokens.push({
                        type: "comment",
                        content: o,
                        position: {
                            start: n,
                            end: Rt(e)
                        }
                    });
                }
                scanTag() {
                    this.scanTagStart();
                    const t = this.scanTagName();
                    return this.scanAttrs(), this.scanTagEnd(), t;
                }
                scanTagStart() {
                    const {html: t, position: e} = this, n = "/" === t.charAt(e.index + 1), i = Rt(e);
                    Lt(e, t, n ? 2 : 1), this.tokens.push({
                        type: "tag-start",
                        close: n,
                        position: {
                            start: i
                        }
                    });
                }
                scanTagEnd() {
                    const {html: t, position: e} = this, n = "/" === t.charAt(e.index);
                    Lt(e, t, n ? 2 : 1);
                    const i = Rt(e);
                    this.tokens.push({
                        type: "tag-end",
                        close: n,
                        position: {
                            end: i
                        }
                    });
                }
                scanTagName() {
                    const {html: t, position: e} = this, n = t.length;
                    let i = e.index;
                    for (;i < n; ) {
                        const e = t.charAt(i);
                        if (!At(e) && "/" !== e && ">" !== e) break;
                        i++;
                    }
                    let r = i + 1;
                    for (;r < n; ) {
                        const e = t.charAt(r);
                        if (At(e) || "/" === e || ">" === e) break;
                        r++;
                    }
                    Nt(e, t, r);
                    const o = t.slice(i, r);
                    return this.tokens.push({
                        type: "tag",
                        content: o
                    }), o;
                }
                scanAttrs() {
                    const {html: t, position: e, tokens: n} = this;
                    let i = e.index, r = null, o = i;
                    const s = [], a = t.length;
                    for (;i < a; ) {
                        const e = t.charAt(i);
                        if (r) e === r && (r = null), i++; else {
                            if ("/" === e || ">" === e) {
                                i !== o && s.push(t.slice(o, i));
                                break;
                            }
                            zt(i, o, t) ? (i !== o && s.push(t.slice(o, i)), o = i + 1, i++) : "'" === e || '"' === e ? (r = e, 
                            i++) : i++;
                        }
                    }
                    Nt(e, t, i);
                    const c = s.length, l = "attribute";
                    for (let t = 0; t < c; t++) {
                        const e = s[t];
                        if (e.includes("=")) {
                            const i = s[t + 1];
                            if (i && i.startsWith("=")) {
                                if (i.length > 1) {
                                    const r = e + i;
                                    n.push({
                                        type: l,
                                        content: r
                                    }), t += 1;
                                    continue;
                                }
                                const r = s[t + 2];
                                if (t += 1, r) {
                                    const i = e + "=" + r;
                                    n.push({
                                        type: l,
                                        content: i
                                    }), t += 1;
                                    continue;
                                }
                            }
                        }
                        if (e.endsWith("=")) {
                            const i = s[t + 1];
                            if (i && !i.includes("=")) {
                                const r = e + i;
                                n.push({
                                    type: l,
                                    content: r
                                }), t += 1;
                                continue;
                            }
                            const r = e.slice(0, -1);
                            n.push({
                                type: l,
                                content: r
                            });
                        } else n.push({
                            type: l,
                            content: e
                        });
                    }
                }
                scanSkipTag(t) {
                    const {html: e, position: n} = this, i = t.toLowerCase(), r = e.length;
                    for (;n.index < r; ) {
                        const t = e.indexOf("</", n.index);
                        if (-1 === t) {
                            this.scanText();
                            break;
                        }
                        if (Nt(n, e, t), i === this.scanTag().toLowerCase()) break;
                    }
                }
            }
            function Wt(t) {
                const e = t.charAt(0), n = t.length - 1;
                return '"' !== e && "'" !== e || e !== t.charAt(n) ? t : t.slice(1, n);
            }
            class $t {
                constructor() {
                    this.styles = [];
                }
                extractStyle(t) {
                    let e = t;
                    return e = e.replace(/<style\s?[^>]*>((.|\n|\s)+?)<\/style>/g, (t, e) => {
                        const n = e.trim();
                        return this.stringToSelector(n), "";
                    }), e.trim();
                }
                stringToSelector(t) {
                    let e = t.indexOf("{");
                    for (;e > -1; ) {
                        const n = t.indexOf("}"), i = t.slice(0, e).trim();
                        let r = t.slice(e + 1, n);
                        r = r.replace(/:(.*);/g, function(t, e) {
                            return `:${e.trim().replace(/ +/g, "+++")};`;
                        }), r = r.replace(/ /g, ""), r = r.replace(/\+\+\+/g, " "), /;$/.test(r) || (r += ";"), 
                        i.split(",").forEach(t => {
                            const e = this.parseSelector(t);
                            this.styles.push({
                                content: r,
                                selectorList: e
                            });
                        }), e = (t = t.slice(n + 1)).indexOf("{");
                    }
                }
                parseSelector(t) {
                    return t.trim().replace(/ *([>~+]) */g, " $1").replace(/ +/g, " ").replace(/\[\s*([^[\]=\s]+)\s*=\s*([^[\]=\s]+)\s*\]/g, "[$1=$2]").split(" ").map(t => {
                        const e = t.charAt(0), n = {
                            isChild: ">" === e,
                            isGeneralSibling: "~" === e,
                            isAdjacentSibling: "+" === e,
                            tag: null,
                            id: null,
                            class: [],
                            attrs: []
                        };
                        return "" !== (t = (t = (t = t.replace(/^[>~+]/, "")).replace(/\[(.+?)\]/g, function(t, e) {
                            const [i, r] = e.split("="), o = -1 === e.indexOf("="), s = {
                                all: o,
                                key: i,
                                value: o ? null : r
                            };
                            return n.attrs.push(s), "";
                        })).replace(/([.#][A-Za-z0-9-_]+)/g, function(t, e) {
                            return "#" === e[0] ? n.id = e.substr(1) : "." === e[0] && n.class.push(e.substr(1)), 
                            "";
                        })) && (n.tag = t), n;
                    });
                }
                matchStyle(t, e, n) {
                    return function(t) {
                        return t.sort((t, e) => {
                            const n = qt(t.selectorList), i = qt(e.selectorList);
                            if (n !== i) return n - i;
                            const r = Ht(t.selectorList), o = Ht(e.selectorList);
                            return r !== o ? r - o : Gt(t.selectorList) - Gt(e.selectorList);
                        });
                    }(this.styles).reduce((i, {content: r, selectorList: o}, s) => {
                        let a = n[s], c = o[a];
                        const l = o[a + 1];
                        ((null == l ? void 0 : l.isGeneralSibling) || (null == l ? void 0 : l.isAdjacentSibling)) && (c = l, 
                        a += 1, n[s] += 1);
                        let u = this.matchCurrent(t, e, c);
                        if (u && c.isGeneralSibling) {
                            let t = Vt(e);
                            for (;t; ) {
                                if (t.h5tagName && this.matchCurrent(t.h5tagName, t, o[a - 1])) {
                                    u = !0;
                                    break;
                                }
                                t = Vt(t), u = !1;
                            }
                        }
                        if (u && c.isAdjacentSibling) {
                            const t = Vt(e);
                            t && t.h5tagName && this.matchCurrent(t.h5tagName, t, o[a - 1]) || (u = !1);
                        }
                        if (u) {
                            if (a === o.length - 1) return i + r;
                            a < o.length - 1 && (n[s] += 1);
                        } else c.isChild && a > 0 && (n[s] -= 1, this.matchCurrent(t, e, o[n[s]]) && (n[s] += 1));
                        return i;
                    }, "");
                }
                matchCurrent(t, e, n) {
                    if (n.tag && n.tag !== t) return !1;
                    if (n.id && n.id !== e.id) return !1;
                    if (n.class.length) {
                        const t = e.className.split(" ");
                        for (let e = 0; e < n.class.length; e++) {
                            const i = n.class[e];
                            if (-1 === t.indexOf(i)) return !1;
                        }
                    }
                    if (n.attrs.length) for (let t = 0; t < n.attrs.length; t++) {
                        const {all: i, key: r, value: o} = n.attrs[t];
                        if (i && !e.hasAttribute(r)) return !1;
                        if (e.getAttribute(r) !== Wt(o || "")) return !1;
                    }
                    return !0;
                }
            }
            function Vt(t) {
                if (!t.parentElement) return null;
                const e = t.previousSibling;
                return e ? 1 === e.nodeType ? e : Vt(e) : null;
            }
            function qt(t) {
                return t.reduce((t, e) => t + (e.id ? 1 : 0), 0);
            }
            function Ht(t) {
                return t.reduce((t, e) => t + e.class.length + e.attrs.length, 0);
            }
            function Gt(t) {
                return t.reduce((t, e) => t + (e.tag ? 1 : 0), 0);
            }
            function Yt(t, e) {
                const n = Object.create(null), i = t.split(",");
                for (let t = 0; t < i.length; t++) n[i[t]] = !0;
                return e ? t => !!n[t.toLowerCase()] : t => !!n[t];
            }
            const Kt = {
                img: "image",
                iframe: "web-view"
            }, Jt = Yt(Object.keys(a.h).map(t => t.toLowerCase()).join(","), !0), Qt = Yt("a,i,abbr,iframe,select,acronym,slot,small,span,bdi,kbd,strong,big,map,sub,sup,br,mark,mark,meter,template,canvas,textarea,cite,object,time,code,output,u,data,picture,tt,datalist,var,dfn,del,q,em,s,embed,samp,b", !0), Xt = Yt("address,fieldset,li,article,figcaption,main,aside,figure,nav,blockquote,footer,ol,details,form,p,dialog,h1,h2,h3,h4,h5,h6,pre,dd,header,section,div,hgroup,table,dl,hr,ul,dt", !0), Zt = {
                li: [ "ul", "ol", "menu" ],
                dt: [ "dl" ],
                dd: [ "dl" ],
                tbody: [ "table" ],
                thead: [ "table" ],
                tfoot: [ "table" ],
                tr: [ "table" ],
                td: [ "table" ]
            };
            function te(t, e) {
                const n = Zt[t];
                if (n) {
                    let i = e.length - 1;
                    for (;i >= 0; ) {
                        const r = e[i].tagName;
                        if (r === t) break;
                        if (n && n.includes(r)) return !0;
                        i--;
                    }
                }
                return !1;
            }
            function ee(t) {
                const e = t.indexOf("=");
                return -1 === e ? [ t ] : [ t.slice(0, e).trim(), t.slice(e + "=".length).trim() ];
            }
            function ne(t, e, n, i) {
                return t.filter(t => "comment" !== t.type && ("text" !== t.type || "" !== t.content)).map(t => {
                    if ("text" === t.type) {
                        let n = e.createTextNode(t.content);
                        return Object(a.k)(Pt.html.transformText) && (n = Pt.html.transformText(n, t)), 
                        null == i || i.appendChild(n), n;
                    }
                    const r = e.createElement(function(t) {
                        return Pt.html.renderHTMLTag ? t : Kt[t] ? Kt[t] : Jt(t) ? t : Xt(t) ? "view" : Qt(t) ? "text" : "view";
                    }(t.tagName));
                    r.h5tagName = t.tagName, null == i || i.appendChild(r), Pt.html.renderHTMLTag || (r.className = "h5-" + t.tagName);
                    for (let e = 0; e < t.attributes.length; e++) {
                        const n = t.attributes[e], [i, o] = ee(n);
                        if ("class" === i) r.className += " " + Wt(o); else {
                            if ("o" === i[0] && "n" === i[1]) continue;
                            r.setAttribute(i, null == o || Wt(o));
                        }
                    }
                    const {styleTagParser: o, descendantList: s} = n, c = s.slice(), l = o.matchStyle(t.tagName, r, c);
                    return r.setAttribute("style", l + r.style.cssText), ne(t.children, e, {
                        styleTagParser: o,
                        descendantList: c
                    }, r), Object(a.k)(Pt.html.transformElement) ? Pt.html.transformElement(r, t) : r;
                });
            }
            function ie(t, e) {
                const n = new $t();
                t = n.extractStyle(t);
                const i = {
                    tagName: "",
                    children: [],
                    type: "element",
                    attributes: []
                };
                return function t(e) {
                    const {tokens: n, stack: i} = e;
                    let {cursor: r} = e;
                    const o = n.length;
                    let s = i[i.length - 1].children;
                    for (;r < o; ) {
                        const e = n[r];
                        if ("tag-start" !== e.type) {
                            s.push(e), r++;
                            continue;
                        }
                        const a = n[++r];
                        r++;
                        const c = a.content.toLowerCase();
                        if (e.close) {
                            let t = i.length, e = !1;
                            for (;--t > -1; ) if (i[t].tagName === c) {
                                e = !0;
                                break;
                            }
                            for (;r < o && "tag-end" === n[r].type; ) r++;
                            if (e) {
                                i.splice(t);
                                break;
                            }
                            continue;
                        }
                        let l = Pt.html.closingElements.has(c);
                        if (l && (l = !te(c, i)), l) {
                            let t = i.length - 1;
                            for (;t > 0; ) {
                                if (c === i[t].tagName) {
                                    i.splice(t), s = i[t - 1].children;
                                    break;
                                }
                                t -= 1;
                            }
                        }
                        const u = [];
                        let h;
                        for (;r < o && (h = n[r], "tag-end" !== h.type); ) u.push(h.content), r++;
                        r++;
                        const d = [], p = {
                            type: "element",
                            tagName: a.content,
                            attributes: u,
                            children: d
                        };
                        if (s.push(p), !h.close && !Pt.html.voidElements.has(c)) {
                            i.push({
                                tagName: c,
                                children: d
                            });
                            const e = {
                                tokens: n,
                                cursor: r,
                                stack: i
                            };
                            t(e), r = e.cursor;
                        }
                    }
                    e.cursor = r;
                }({
                    tokens: new Ft(t).scan(),
                    options: Pt,
                    cursor: 0,
                    stack: [ i ]
                }), ne(i.children, e, {
                    styleTagParser: n,
                    descendantList: Array(n.styles.length).fill(0)
                });
            }
            function re(t, e) {
                for (;t.firstChild; ) t.removeChild(t.firstChild);
                const n = ie(e, t.ownerDocument);
                for (let e = 0; e < n.length; e++) t.appendChild(n[e]);
            }
            Pt.html = {
                skipElements: new Set([ "style", "script" ]),
                voidElements: new Set([ "!doctype", "area", "base", "br", "col", "command", "embed", "hr", "img", "input", "keygen", "link", "meta", "param", "source", "track", "wbr" ]),
                closingElements: new Set([ "html", "head", "body", "p", "dt", "dd", "li", "option", "thead", "th", "tbody", "tr", "td", "tfoot", "colgroup" ]),
                renderHTMLTag: !1
            }, Object(a.q)() || it.extend("innerHTML", {
                set(t) {
                    re.call(this, this, t);
                },
                get: () => ""
            });
            class oe {
                constructor(t, e, n) {
                    this._stop = !1, this._end = !1, this.defaultPrevented = !1, this.button = 0, this.timeStamp = Date.now(), 
                    this.type = t.toLowerCase(), this.mpEvent = n, this.bubbles = Boolean(e && e.bubbles), 
                    this.cancelable = Boolean(e && e.cancelable);
                }
                stopPropagation() {
                    this._stop = !0;
                }
                stopImmediatePropagation() {
                    this._end = this._stop = !0;
                }
                preventDefault() {
                    this.defaultPrevented = !0;
                }
                get target() {
                    var t, e;
                    const n = this.cacheTarget;
                    if (n) return n;
                    {
                        const n = Object.create((null === (t = this.mpEvent) || void 0 === t ? void 0 : t.target) || null), i = X.document.getElementById(n.id);
                        n.dataset = null !== i ? i.dataset : a.a;
                        for (const t in null === (e = this.mpEvent) || void 0 === e ? void 0 : e.detail) n[t] = this.mpEvent.detail[t];
                        return this.cacheTarget = n, n;
                    }
                }
                get currentTarget() {
                    var t, e, n, i;
                    const r = this.cacheCurrentTarget;
                    if (r) return r;
                    {
                        const r = X.document, o = Object.create((null === (t = this.mpEvent) || void 0 === t ? void 0 : t.currentTarget) || null), s = r.getElementById(o.id), a = r.getElementById((null === (n = null === (e = this.mpEvent) || void 0 === e ? void 0 : e.target) || void 0 === n ? void 0 : n.id) || null);
                        if (null === s || s && s === a) return this.cacheCurrentTarget = this.target, this.target;
                        o.dataset = s.dataset;
                        for (const t in null === (i = this.mpEvent) || void 0 === i ? void 0 : i.detail) o[t] = this.mpEvent.detail[t];
                        return this.cacheCurrentTarget = o, o;
                    }
                }
            }
            function se(t, e) {
                if ("string" == typeof t) return new oe(t, {
                    bubbles: !0,
                    cancelable: !0
                });
                const n = new oe(t.type, {
                    bubbles: !0,
                    cancelable: !0
                }, t);
                for (const e in t) "currentTarget" !== e && "target" !== e && e !== w && "timeStamp" !== e && (n[e] = t[e]);
                return "confirm" === n.type && (null == e ? void 0 : e.nodeName) === v && (n.keyCode = 13), 
                n;
            }
            const ae = {};
            function ce(t) {
                const e = t[P];
                return Object(a.p)(e) || delete t[P], e;
            }
            function le(t) {
                var e, n;
                void 0 === t.type && Object.defineProperty(t, "type", {
                    value: t._type
                }), void 0 === t.detail && Object.defineProperty(t, "detail", {
                    value: t._detail || Object.assign({}, t)
                }), t.currentTarget = t.currentTarget || t.target || Object.assign({}, t), a.g.call("modifyMpEventImpl", t);
                const i = t.currentTarget, r = (null === (e = i.dataset) || void 0 === e ? void 0 : e.sid) || i.id || (null === (n = t.detail) || void 0 === n ? void 0 : n.id) || "", o = X.document.getElementById(r);
                if (o) {
                    const e = () => {
                        const e = se(t, o);
                        a.g.call("modifyTaroEvent", e, o), a.g.call("dispatchTaroEvent", e, o), a.g.call("dispatchTaroEventFinish", e, o);
                    };
                    if (!a.g.isExist("batchedEventUpdates")) return e(), ce(t);
                    {
                        const n = t.type;
                        if (!a.g.call("isBubbleEvents", n) || !function(t, e) {
                            var n;
                            let i = !1;
                            for (;(null == t ? void 0 : t.parentElement) && t.parentElement._path !== l; ) {
                                if (null === (n = t.parentElement.__handlers[e]) || void 0 === n ? void 0 : n.length) {
                                    i = !0;
                                    break;
                                }
                                t = t.parentElement;
                            }
                            return i;
                        }(o, n) || "touchmove" === n && o.props.catchMove) return a.g.call("batchedEventUpdates", () => {
                            ae[n] && (ae[n].forEach(t => t()), delete ae[n]), e();
                        }), ce(t);
                        (ae[n] || (ae[n] = [])).push(e);
                    }
                }
            }
            class ue extends It {
                get type() {
                    var t;
                    return null !== (t = this.props[w]) && void 0 !== t ? t : "";
                }
                set type(t) {
                    this.setAttribute(w, t);
                }
                get value() {
                    const t = this.props[b];
                    return null == t ? "" : t;
                }
                set value(t) {
                    this.setAttribute(b, t);
                }
                dispatchEvent(t) {
                    if (t.mpEvent) {
                        const e = t.mpEvent.detail.value;
                        "change" === t.type ? this.props.value = e : t.type === v && (this.value = e);
                    }
                    return super.dispatchEvent(t);
                }
            }
            const he = new class {
                constructor() {
                    this.recorder = new Map();
                }
                start(t) {
                    Pt.debug && this.recorder.set(t, Date.now());
                }
                stop(t) {
                    if (!Pt.debug) return;
                    const e = Date.now(), n = this.recorder.get(t);
                    this.recorder.delete(t);
                    const i = e - n;
                    console.log(`${t} 时长： ${i}ms`);
                }
            }();
            function de(t, e) {
                const n = e.slice(1);
                let i, r = t, o = "";
                if (n.some((t, n) => {
                    const s = t.replace(/^\[(.+)\]$/, "$1").replace(/\bcn\b/g, "childNodes");
                    if (r = r[s], Object(a.i)(r) && (r = r.filter(t => !F(t))), Object(a.p)(r)) return !0;
                    if (r.nodeName === y) {
                        const t = V.get(r.sid);
                        t && (i = t, o = e.slice(n + 2).join("."));
                    }
                }), i) return {
                    customWrapper: i,
                    splitedPath: o
                };
            }
            class pe extends It {
                constructor() {
                    super(), this.updatePayloads = [], this.updateCallbacks = [], this.pendingUpdate = !1, 
                    this.ctx = null, this.nodeName = l, this.tagName = l.toUpperCase();
                }
                get _path() {
                    return l;
                }
                get _root() {
                    return this;
                }
                enqueueUpdate(t) {
                    this.updatePayloads.push(t), !this.pendingUpdate && this.ctx && this.performUpdate();
                }
                performUpdate(t = !1, e) {
                    this.pendingUpdate = !0;
                    const n = a.g.call("proxyToRaw", this.ctx);
                    setTimeout(() => {
                        const i = "小程序 setData 开始时间戳 " + Date.now();
                        he.start(i);
                        const r = Object.create(null), o = new Set(t ? [ "root.cn.[0]", "root.cn[0]" ] : []);
                        for (;this.updatePayloads.length > 0; ) {
                            const {path: t, value: e} = this.updatePayloads.shift();
                            t.endsWith("cn") && o.add(t), r[t] = e;
                        }
                        for (const t in r) {
                            o.forEach(e => {
                                t.includes(e) && t !== e && delete r[t];
                            });
                            const e = r[t];
                            Object(a.k)(e) && (r[t] = e());
                        }
                        if (Object(a.k)(e)) return e(r);
                        this.pendingUpdate = !1;
                        let s = {};
                        const l = new Map();
                        if (t) s = r; else for (const t in r) {
                            const e = de(this, t.split("."));
                            if (e) {
                                const {customWrapper: n, splitedPath: i} = e;
                                l.set(n, Object.assign(Object.assign({}, l.get(n) || {}), {
                                    ["i." + i]: r[t]
                                }));
                            } else s[t] = r[t];
                        }
                        const u = l.size, h = Object.keys(s).length > 0, d = u + (h ? 1 : 0);
                        let p = 0;
                        const f = () => {
                            ++p === d && (he.stop(i), this.flushUpdateCallback(), t && he.stop(c));
                        };
                        u && l.forEach((t, e) => {
                            e.setData(t, f);
                        }), h && n.setData(s, f);
                    }, 0);
                }
                enqueueUpdateCallback(t, e) {
                    this.updateCallbacks.push(() => {
                        e ? t.call(e) : t();
                    });
                }
                flushUpdateCallback() {
                    const t = this.updateCallbacks;
                    if (!t.length) return;
                    const e = t.slice(0);
                    this.updateCallbacks.length = 0;
                    for (let t = 0; t < e.length; t++) e[t]();
                }
            }
            class fe extends it {
                constructor(t) {
                    super(), this.nodeType = 3, this.nodeName = "#text", this._value = t;
                }
                set textContent(t) {
                    D.record({
                        target: this,
                        type: "characterData",
                        oldValue: this._value
                    }), this._value = t, this.enqueueUpdate({
                        path: this._path + ".v",
                        value: t
                    });
                }
                get textContent() {
                    return this._value;
                }
                set nodeValue(t) {
                    this.textContent = t;
                }
                get nodeValue() {
                    return this._value;
                }
                set data(t) {
                    this.textContent = t;
                }
                get data() {
                    return this._value;
                }
            }
            function ge(t, e, n, i) {
                if ("a" === n && !i) throw new TypeError("Private accessor was defined without a getter");
                if ("function" == typeof e ? t !== e || !i : !e.has(t)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
                return "m" === n ? i : "a" === n ? i.call(t) : i ? i.value : e.get(t);
            }
            function me(t, e, n, i, r) {
                if ("m" === i) throw new TypeError("Private method is not writable");
                if ("a" === i && !r) throw new TypeError("Private accessor was defined without a setter");
                if ("function" == typeof e ? t !== e || !r : !e.has(t)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
                return "a" === i ? r.call(t, n) : r ? r.value = n : e.set(t, n), n;
            }
            var be;
            const ve = /[!'()~]|%20|%00/g, ye = /\+/g, we = {
                "!": "%21",
                "'": "%27",
                "(": "%28",
                ")": "%29",
                "~": "%7E",
                "%20": "+",
                "%00": "\0"
            };
            function Se(t) {
                return we[t];
            }
            function Oe(t, e, n) {
                const i = Object(a.i)(n) ? n.join(",") : n;
                e in t ? t[e].push(i) : t[e] = [ i ];
            }
            function Ee(t, e) {
                Oe(this, e, t);
            }
            function Te(t) {
                return decodeURIComponent(t.replace(ye, " "));
            }
            function Ce(t) {
                return encodeURIComponent(t).replace(ve, Se);
            }
            class ke {
                constructor(t) {
                    be.set(this, Object.create(null)), null != t || (t = "");
                    const e = ge(this, be, "f");
                    if ("string" == typeof t) {
                        "?" === t.charAt(0) && (t = t.slice(1));
                        for (let n = t.split("&"), i = 0, r = n.length; i < r; i++) {
                            const t = n[i], r = t.indexOf("=");
                            r > -1 ? Oe(e, Te(t.slice(0, r)), Te(t.slice(r + 1))) : t.length && Oe(e, Te(t), "");
                        }
                    } else if (Object(a.i)(t)) for (let n = 0, i = t.length; n < i; n++) {
                        const i = t[n];
                        Oe(e, i[0], i[1]);
                    } else if (t.forEach) t.forEach(Ee, e); else for (const n in t) Oe(e, n, t[n]);
                }
                append(t, e) {
                    Oe(ge(this, be, "f"), t, e);
                }
                delete(t) {
                    delete ge(this, be, "f")[t];
                }
                get(t) {
                    const e = ge(this, be, "f");
                    return t in e ? e[t][0] : null;
                }
                getAll(t) {
                    const e = ge(this, be, "f");
                    return t in e ? e[t].slice(0) : [];
                }
                has(t) {
                    return t in ge(this, be, "f");
                }
                keys() {
                    return Object.keys(ge(this, be, "f"));
                }
                set(t, e) {
                    ge(this, be, "f")[t] = [ "" + e ];
                }
                forEach(t, e) {
                    const n = ge(this, be, "f");
                    Object.getOwnPropertyNames(n).forEach(function(i) {
                        n[i].forEach(function(n) {
                            t.call(e, n, i, this);
                        }, this);
                    }, this);
                }
                toJSON() {
                    return {};
                }
                toString() {
                    const t = ge(this, be, "f"), e = [];
                    for (const n in t) {
                        const i = Ce(n);
                        for (let r = 0, o = t[n]; r < o.length; r++) e.push(i + "=" + Ce(o[r]));
                    }
                    return e.join("&");
                }
            }
            var xe, je, Ie, Pe, Le, Ne;
            be = new WeakMap();
            class Re {
                static createObjectURL() {
                    throw new Error("Oops, not support URL.createObjectURL() in miniprogram.");
                }
                static revokeObjectURL() {
                    throw new Error("Oops, not support URL.revokeObjectURL() in miniprogram.");
                }
                constructor(t, e) {
                    xe.set(this, ""), je.set(this, ""), Ie.set(this, ""), Pe.set(this, ""), Le.set(this, ""), 
                    Ne.set(this, void 0), Object(a.o)(t) || (t = String(t));
                    const n = function(t, e) {
                        const n = /^(https?:)\/\//i;
                        let i = "", r = null;
                        if (!Object(a.p)(e)) {
                            if (e = String(e).trim(), !n.test(e)) throw new TypeError("Failed to construct 'URL': Invalid base URL");
                            r = _e(e);
                        }
                        if (t = String(t).trim(), n.test(t)) i = t; else {
                            if (!r) throw new TypeError("Failed to construct 'URL': Invalid URL");
                            i = t ? t.startsWith("//") ? r.protocol + t : r.origin + (t.startsWith("/") ? t : "/" + t) : r.href;
                        }
                        return _e(i);
                    }(t, e), {hash: i, hostname: r, pathname: o, port: s, protocol: c, search: l} = n;
                    me(this, xe, i, "f"), me(this, je, r, "f"), me(this, Ie, o || "/", "f"), me(this, Pe, s, "f"), 
                    me(this, Le, c, "f"), me(this, Ne, new ke(l), "f");
                }
                get protocol() {
                    return ge(this, Le, "f");
                }
                set protocol(t) {
                    Object(a.o)(t) && me(this, Le, t.trim(), "f");
                }
                get host() {
                    return this.hostname + (this.port ? ":" + this.port : "");
                }
                set host(t) {
                    if (t && Object(a.o)(t)) {
                        t = t.trim();
                        const {hostname: e, port: n} = _e("//" + t);
                        this.hostname = e, this.port = n;
                    }
                }
                get hostname() {
                    return ge(this, je, "f");
                }
                set hostname(t) {
                    t && Object(a.o)(t) && me(this, je, t.trim(), "f");
                }
                get port() {
                    return ge(this, Pe, "f");
                }
                set port(t) {
                    Object(a.o)(t) && me(this, Pe, t.trim(), "f");
                }
                get pathname() {
                    return ge(this, Ie, "f");
                }
                set pathname(t) {
                    if (Object(a.o)(t)) {
                        const e = /^(\/|\.\/|\.\.\/)/;
                        let n = t = t.trim();
                        for (;e.test(n); ) n = n.replace(e, "");
                        me(this, Ie, n ? "/" + n : "/", "f");
                    }
                }
                get search() {
                    const t = ge(this, Ne, "f").toString();
                    return 0 === t.length || t.startsWith("?") ? t : "?" + t;
                }
                set search(t) {
                    Object(a.o)(t) && (t = t.trim(), me(this, Ne, new ke(t), "f"));
                }
                get hash() {
                    return ge(this, xe, "f");
                }
                set hash(t) {
                    Object(a.o)(t) && (t = t.trim(), me(this, xe, t ? t.startsWith("#") ? t : "#" + t : "", "f"));
                }
                get href() {
                    return `${this.protocol}//${this.host}${this.pathname}${this.search}${this.hash}`;
                }
                set href(t) {
                    if (t && Object(a.o)(t)) {
                        t = t.trim();
                        const {protocol: e, hostname: n, port: i, hash: r, search: o, pathname: s} = _e(t);
                        this.protocol = e, this.hostname = n, this.pathname = s, this.port = i, this.hash = r, 
                        this.search = o;
                    }
                }
                get origin() {
                    return `${this.protocol}//${this.host}`;
                }
                set origin(t) {
                    if (t && Object(a.o)(t)) {
                        t = t.trim();
                        const {protocol: e, hostname: n, port: i} = _e(t);
                        this.protocol = e, this.hostname = n, this.port = i;
                    }
                }
                get searchParams() {
                    return ge(this, Ne, "f");
                }
                toString() {
                    return this.href;
                }
                toJSON() {
                    return this.toString();
                }
                _toRaw() {
                    return {
                        protocol: this.protocol,
                        port: this.port,
                        host: this.host,
                        hostname: this.hostname,
                        pathname: this.pathname,
                        hash: this.hash,
                        search: this.search,
                        origin: this.origin,
                        href: this.href
                    };
                }
            }
            function _e(t = "") {
                const e = {
                    href: "",
                    origin: "",
                    protocol: "",
                    hostname: "",
                    host: "",
                    port: "",
                    pathname: "",
                    search: "",
                    hash: ""
                };
                if (!t || !Object(a.o)(t)) return e;
                const n = (t = t.trim()).match(/^(([^:/?#]+):)?\/\/(([^/?#]+):(.+)@)?([^/?#:]*)(:(\d+))?([^?#]*)(\?([^#]*))?(#(.*))?/);
                return n ? (e.protocol = n[1] || "https:", e.hostname = n[6] || "taro.com", e.port = n[8] || "", 
                e.pathname = n[9] || "/", e.search = n[10] || "", e.hash = n[12] || "", e.href = t, 
                e.origin = e.protocol + "//" + e.hostname, e.host = e.hostname + (e.port ? ":" + e.port : ""), 
                e) : e;
            }
            xe = new WeakMap(), je = new WeakMap(), Ie = new WeakMap(), Pe = new WeakMap(), 
            Le = new WeakMap(), Ne = new WeakMap();
            class Ae extends It {
                get href() {
                    var t;
                    return null !== (t = this.props.href) && void 0 !== t ? t : "";
                }
                set href(t) {
                    this.setAttribute("href", t);
                }
                get protocol() {
                    var t;
                    return null !== (t = this.props.protocol) && void 0 !== t ? t : "";
                }
                get host() {
                    var t;
                    return null !== (t = this.props.host) && void 0 !== t ? t : "";
                }
                get search() {
                    var t;
                    return null !== (t = this.props.search) && void 0 !== t ? t : "";
                }
                get hash() {
                    var t;
                    return null !== (t = this.props.hash) && void 0 !== t ? t : "";
                }
                get hostname() {
                    var t;
                    return null !== (t = this.props.hostname) && void 0 !== t ? t : "";
                }
                get port() {
                    var t;
                    return null !== (t = this.props.port) && void 0 !== t ? t : "";
                }
                get pathname() {
                    var t;
                    return null !== (t = this.props.pathname) && void 0 !== t ? t : "";
                }
                setAttribute(t, e) {
                    if ("href" === t) {
                        const t = _e(e);
                        for (const e in t) super.setAttribute(e, t[e]);
                    } else super.setAttribute(t, e);
                }
            }
            class Me extends It {}
            class Be extends It {
                constructor() {
                    super(), this.createEvent = se, this.nodeType = 9, this.nodeName = "#document";
                }
                createElement(t) {
                    const e = t.toLowerCase();
                    let n;
                    switch (!0) {
                      case e === l:
                        return n = new pe(), n;

                      case a.d.has(e):
                        n = new ue();
                        break;

                      case "a" === e:
                        n = new Ae();
                        break;

                      case e === y:
                        n = new Me();
                        break;

                      default:
                        n = new It();
                    }
                    return n.nodeName = e, n.tagName = t.toUpperCase(), n;
                }
                createElementNS(t, e) {
                    return this.createElement(e);
                }
                createTextNode(t) {
                    return new fe(t);
                }
                getElementById(t) {
                    const e = J.get(t);
                    return Object(a.p)(e) ? null : e;
                }
                querySelector(t) {
                    return /^#/.test(t) ? this.getElementById(t.slice(1)) : null;
                }
                querySelectorAll() {
                    return [];
                }
                createComment() {
                    const t = new fe("");
                    return t.nodeName = E, t;
                }
                get defaultView() {
                    return X.window;
                }
            }
            let De;
            function Ue(t) {
                return t.style;
            }
            De = Object(a.q)() ? X.document : X.document = function() {
                const t = new Be(), e = t.createElement.bind(t), n = e("html"), i = e("head"), r = e("body"), o = e("app");
                o.id = "app";
                const s = e("container");
                return t.appendChild(n), n.appendChild(i), n.appendChild(r), r.appendChild(s), s.appendChild(o), 
                t.documentElement = n, t.head = i, t.body = r, t;
            }();
            const ze = a.g.call("getEventCenter", a.b);
            class Fe {
                constructor(t) {
                    this.cache = new Map(), this.name = t;
                }
                has(t) {
                    return this.cache.has(t);
                }
                set(t, e) {
                    t && e && this.cache.set(t, e);
                }
                get(t) {
                    if (this.has(t)) return this.cache.get(t);
                }
                delete(t) {
                    this.cache.delete(t);
                }
            }
            var We, $e, Ve, qe, He, Ge;
            const Ye = new Fe("history");
            class Ke extends a.b {
                constructor(t, e) {
                    super(), We.add(this), $e.set(this, void 0), Ve.set(this, []), qe.set(this, 0), 
                    He.set(this, void 0), me(this, He, e.window, "f"), me(this, $e, t, "f"), ge(this, $e, "f").on("__record_history__", t => {
                        var e;
                        me(this, qe, (e = ge(this, qe, "f"), ++e), "f"), me(this, Ve, ge(this, Ve, "f").slice(0, ge(this, qe, "f")), "f"), 
                        ge(this, Ve, "f").push({
                            state: null,
                            title: "",
                            url: t
                        });
                    }, null), ge(this, $e, "f").on("__reset_history__", t => {
                        ge(this, We, "m", Ge).call(this, t);
                    }, null), this.on(N.INIT, () => {
                        ge(this, We, "m", Ge).call(this);
                    }, null), this.on(N.RESTORE, t => {
                        Ye.set(t, {
                            location: ge(this, $e, "f"),
                            stack: ge(this, Ve, "f").slice(),
                            cur: ge(this, qe, "f")
                        });
                    }, null), this.on(N.RECOVER, t => {
                        if (Ye.has(t)) {
                            const e = Ye.get(t);
                            me(this, $e, e.location, "f"), me(this, Ve, e.stack, "f"), me(this, qe, e.cur, "f");
                        }
                    }, null), this.on(N.DESTORY, t => {
                        Ye.delete(t);
                    }, null), ge(this, We, "m", Ge).call(this);
                }
                get length() {
                    return ge(this, Ve, "f").length;
                }
                get state() {
                    return ge(this, Ve, "f")[ge(this, qe, "f")].state;
                }
                go(t) {
                    if (!Object(a.m)(t) || isNaN(t)) return;
                    let e = ge(this, qe, "f") + t;
                    e = Math.min(Math.max(e, 0), this.length - 1), me(this, qe, e, "f"), ge(this, $e, "f").trigger("__set_href_without_history__", ge(this, Ve, "f")[ge(this, qe, "f")].url), 
                    ge(this, He, "f").trigger("popstate", ge(this, Ve, "f")[ge(this, qe, "f")]);
                }
                back() {
                    this.go(-1);
                }
                forward() {
                    this.go(1);
                }
                pushState(t, e, n) {
                    n && Object(a.o)(n) && (me(this, Ve, ge(this, Ve, "f").slice(0, ge(this, qe, "f") + 1), "f"), 
                    ge(this, Ve, "f").push({
                        state: t,
                        title: e,
                        url: n
                    }), me(this, qe, this.length - 1, "f"), ge(this, $e, "f").trigger("__set_href_without_history__", n));
                }
                replaceState(t, e, n) {
                    n && Object(a.o)(n) && (ge(this, Ve, "f")[ge(this, qe, "f")] = {
                        state: t,
                        title: e,
                        url: n
                    }, ge(this, $e, "f").trigger("__set_href_without_history__", n));
                }
                get cache() {
                    return Ye;
                }
            }
            $e = new WeakMap(), Ve = new WeakMap(), qe = new WeakMap(), He = new WeakMap(), 
            We = new WeakSet(), Ge = function(t = "") {
                me(this, Ve, [ {
                    state: null,
                    title: "",
                    url: t || ge(this, $e, "f").href
                } ], "f"), me(this, qe, 0, "f");
            };
            const Je = {
                app: null,
                router: null,
                page: null
            }, Qe = () => Je;
            var Xe, Ze, tn, en, nn, rn, on, sn, an;
            const cn = "https://taro.com", ln = new Fe("location");
            class un extends a.b {
                constructor(t) {
                    super(), Xe.add(this), Ze.set(this, new Re(cn)), tn.set(this, !1), en.set(this, void 0), 
                    me(this, en, t.window, "f"), ge(this, Xe, "m", nn).call(this), this.on("__set_href_without_history__", t => {
                        me(this, tn, !0, "f");
                        const e = ge(this, Ze, "f").hash;
                        ge(this, Ze, "f").href = function(t = "") {
                            return /^[/?#]/.test(t) ? "https://taro.com" + t : t;
                        }(t), e !== ge(this, Ze, "f").hash && ge(this, en, "f").trigger("hashchange"), me(this, tn, !1, "f");
                    }, null), this.on(N.INIT, () => {
                        ge(this, Xe, "m", nn).call(this);
                    }, null), this.on(N.RESTORE, t => {
                        ln.set(t, {
                            lastHref: this.href
                        });
                    }, null), this.on(N.RECOVER, t => {
                        if (ln.has(t)) {
                            const e = ln.get(t);
                            me(this, tn, !0, "f"), ge(this, Ze, "f").href = e.lastHref, me(this, tn, !1, "f");
                        }
                    }, null), this.on(N.DESTORY, t => {
                        ln.delete(t);
                    }, null);
                }
                get protocol() {
                    return ge(this, Ze, "f").protocol;
                }
                set protocol(t) {
                    if (!t || !Object(a.o)(t) || !/^(http|https):$/i.test(t.trim())) return;
                    t = t.trim();
                    const e = ge(this, Xe, "m", rn).call(this);
                    ge(this, Ze, "f").protocol = t, ge(this, Xe, "m", an).call(this, e) && ge(this, Xe, "m", sn).call(this);
                }
                get host() {
                    return ge(this, Ze, "f").host;
                }
                set host(t) {
                    if (!t || !Object(a.o)(t)) return;
                    t = t.trim();
                    const e = ge(this, Xe, "m", rn).call(this);
                    ge(this, Ze, "f").host = t, ge(this, Xe, "m", an).call(this, e) && ge(this, Xe, "m", sn).call(this);
                }
                get hostname() {
                    return ge(this, Ze, "f").hostname;
                }
                set hostname(t) {
                    if (!t || !Object(a.o)(t)) return;
                    t = t.trim();
                    const e = ge(this, Xe, "m", rn).call(this);
                    ge(this, Ze, "f").hostname = t, ge(this, Xe, "m", an).call(this, e) && ge(this, Xe, "m", sn).call(this);
                }
                get port() {
                    return ge(this, Ze, "f").port;
                }
                set port(t) {
                    const e = Number(t = t.trim());
                    if (!Object(a.m)(e) || e <= 0) return;
                    const n = ge(this, Xe, "m", rn).call(this);
                    ge(this, Ze, "f").port = t, ge(this, Xe, "m", an).call(this, n) && ge(this, Xe, "m", sn).call(this);
                }
                get pathname() {
                    return ge(this, Ze, "f").pathname;
                }
                set pathname(t) {
                    if (!t || !Object(a.o)(t)) return;
                    t = t.trim();
                    const e = ge(this, Xe, "m", rn).call(this);
                    ge(this, Ze, "f").pathname = t, ge(this, Xe, "m", an).call(this, e) && ge(this, Xe, "m", sn).call(this);
                }
                get search() {
                    return ge(this, Ze, "f").search;
                }
                set search(t) {
                    if (!t || !Object(a.o)(t)) return;
                    t = (t = t.trim()).startsWith("?") ? t : "?" + t;
                    const e = ge(this, Xe, "m", rn).call(this);
                    ge(this, Ze, "f").search = t, ge(this, Xe, "m", an).call(this, e) && ge(this, Xe, "m", sn).call(this);
                }
                get hash() {
                    return ge(this, Ze, "f").hash;
                }
                set hash(t) {
                    if (!t || !Object(a.o)(t)) return;
                    t = (t = t.trim()).startsWith("#") ? t : "#" + t;
                    const e = ge(this, Xe, "m", rn).call(this);
                    ge(this, Ze, "f").hash = t, ge(this, Xe, "m", an).call(this, e) && ge(this, Xe, "m", sn).call(this);
                }
                get href() {
                    return ge(this, Ze, "f").href;
                }
                set href(t) {
                    if (!t || !Object(a.o)(t) || !/^(http:|https:)?\/\/.+/.test(t = t.trim())) return;
                    const e = ge(this, Xe, "m", rn).call(this);
                    ge(this, Ze, "f").href = t, ge(this, Xe, "m", an).call(this, e) && ge(this, Xe, "m", sn).call(this);
                }
                get origin() {
                    return ge(this, Ze, "f").origin;
                }
                set origin(t) {
                    if (!t || !Object(a.o)(t) || !/^(http:|https:)?\/\/.+/.test(t = t.trim())) return;
                    const e = ge(this, Xe, "m", rn).call(this);
                    ge(this, Ze, "f").origin = t, ge(this, Xe, "m", an).call(this, e) && ge(this, Xe, "m", sn).call(this);
                }
                assign() {
                    Object(a.x)(!0, "小程序环境中调用location.assign()无效.");
                }
                reload() {
                    Object(a.x)(!0, "小程序环境中调用location.reload()无效.");
                }
                replace(t) {
                    this.trigger("__set_href_without_history__", t);
                }
                toString() {
                    return this.href;
                }
                get cache() {
                    return ln;
                }
            }
            Ze = new WeakMap(), tn = new WeakMap(), en = new WeakMap(), Xe = new WeakSet(), 
            nn = function() {
                const t = Qe().router;
                if (t) {
                    const {path: e, params: n} = t, i = Object.keys(n).map(t => `${t}=${n[t]}`), r = i.length > 0 ? "?" + i.join("&") : "", o = `${cn}${e.startsWith("/") ? e : "/" + e}${r}`;
                    me(this, Ze, new Re(o), "f"), this.trigger("__reset_history__", this.href);
                }
            }, rn = function() {
                return ge(this, Ze, "f")._toRaw();
            }, on = function(t) {
                ge(this, Ze, "f").href = t;
            }, sn = function() {
                this.trigger("__record_history__", this.href);
            }, an = function(t) {
                if (ge(this, tn, "f")) return !1;
                const {protocol: e, hostname: n, port: i, pathname: r, search: o, hash: s} = ge(this, Ze, "f")._toRaw();
                return e !== t.protocol || n !== t.hostname || i !== t.port ? (ge(this, Xe, "m", on).call(this, t.href), 
                !1) : r !== t.pathname || o !== t.search || (s !== t.hash ? (ge(this, en, "f").trigger("hashchange"), 
                !0) : (ge(this, Xe, "m", on).call(this, t.href), !1));
            };
            const hn = "(Macintosh; Intel Mac OS X 10_14_5) AppleWebKit/534.36 (KHTML, like Gecko) NodeJS/v4.1.0 Chrome/76.0.3809.132 Safari/534.36", dn = Object(a.q)() ? X.window.navigator : {
                appCodeName: "Mozilla",
                appName: "Netscape",
                appVersion: "5.0 " + hn,
                cookieEnabled: !0,
                mimeTypes: [],
                onLine: !0,
                platform: "MacIntel",
                plugins: [],
                product: "Taro",
                productSub: "20030107",
                userAgent: "Mozilla/5.0 " + hn,
                vendor: "Joyent",
                vendorSub: ""
            };
            let pn;
            !function() {
                let t;
                "undefined" != typeof performance && null !== performance && performance.now ? pn = (() => performance.now()) : Date.now ? (t = Date.now(), 
                pn = (() => Date.now() - t)) : (t = new Date().getTime(), pn = (() => new Date().getTime() - t));
            }();
            let fn = 0;
            const gn = null != r ? r : function(t) {
                const e = pn(), n = Math.max(fn + 16, e);
                return setTimeout(function() {
                    t(fn = n);
                }, n - e);
            }, mn = null != o ? o : function(t) {
                clearTimeout(t);
            };
            let bn;
            if (Object(a.q)()) bn = X.window; else {
                class t extends a.b {
                    constructor() {
                        super(), this.navigator = dn, this.requestAnimationFrame = gn, this.cancelAnimationFrame = mn, 
                        this.getComputedStyle = Ue, [ ...Object.getOwnPropertyNames(s || {}), ...Object.getOwnPropertySymbols(s || {}) ].forEach(t => {
                            if ("atob" !== t && "document" !== t && !Object.prototype.hasOwnProperty.call(this, t)) try {
                                this[t] = s[t];
                            } catch (t) {}
                        }), this.Date || (this.Date = Date), this.location = new un({
                            window: this
                        }), this.history = new Ke(this.location, {
                            window: this
                        }), this.initEvent();
                    }
                    initEvent() {
                        const t = this.location, e = this.history;
                        this.on(N.INIT, e => {
                            t.trigger(N.INIT, e);
                        }, null), this.on(N.RECOVER, n => {
                            t.trigger(N.RECOVER, n), e.trigger(N.RECOVER, n);
                        }, null), this.on(N.RESTORE, n => {
                            t.trigger(N.RESTORE, n), e.trigger(N.RESTORE, n);
                        }, null), this.on(N.DESTORY, n => {
                            t.trigger(N.DESTORY, n), e.trigger(N.DESTORY, n);
                        }, null);
                    }
                    get document() {
                        return X.document;
                    }
                    addEventListener(t, e) {
                        Object(a.o)(t) && this.on(t, e, null);
                    }
                    removeEventListener(t, e) {
                        Object(a.o)(t) && this.off(t, e, null);
                    }
                    setTimeout(...t) {
                        return setTimeout(...t);
                    }
                    clearTimeout(...t) {
                        return clearTimeout(...t);
                    }
                }
                bn = X.window = new t();
            }
            const vn = bn.location, yn = bn.history;
            class wn extends It {}
            const Sn = new Map(), On = U(), En = Object(a.q)();
            function Tn(t, e) {
                a.g.call("mergePageInstance", Sn.get(e), t), Sn.set(e, t);
            }
            function Cn(t) {
                return Sn.get(t);
            }
            function kn(t) {
                Sn.delete(t);
            }
            function xn(t) {
                return null == t ? "" : "/" === t.charAt(0) ? t : "/" + t;
            }
            function jn(t, e, ...n) {
                const i = Sn.get(t);
                if (null == i) return;
                const r = a.g.call("getLifecycle", i, e);
                return Object(a.i)(r) ? r.map(t => t.apply(i, n))[0] : Object(a.k)(r) ? r.apply(i, n) : void 0;
            }
            function In(t) {
                if (null == t) return "";
                const e = Object.keys(t).map(e => e + "=" + t[e]).join("&");
                return "" === e ? e : "?" + e;
            }
            function Pn(t, e) {
                const n = t.indexOf("?");
                return En ? `${n > -1 ? t.substring(0, n) : t}${In((null == e ? void 0 : e.stamp) ? {
                    stamp: e.stamp
                } : {})}` : `${n > -1 ? t.substring(0, n) : t}${In(e)}`;
            }
            function Ln(t) {
                return t + "." + C;
            }
            function Nn(t) {
                return t + "." + k;
            }
            function Rn(t) {
                return t + "." + x;
            }
            function _n(t, e, n, i) {
                const r = null != e ? e : "taro_page_" + On(), [o, s, l, u, h, d, p] = a.g.call("getMiniLifecycleImpl").page;
                let f, g, m = null, b = !1, v = [];
                function y(t) {
                    const e = En ? t.$taroPath : t.route || t.__route__ || t.$taroPath;
                    Je.router = {
                        params: t.$taroParams,
                        path: xn(e),
                        $taroPath: t.$taroPath,
                        onReady: Ln(r),
                        onShow: Nn(r),
                        onHide: Rn(r)
                    }, Object(a.p)(t.exitState) || (Je.router.exitState = t.exitState);
                }
                const w = {
                    [o](e = {}, n) {
                        g = new Promise(t => {
                            f = t;
                        }), he.start(c), Je.page = this, this.config = i || {};
                        const o = Object.assign({}, e, {
                            $taroTimestamp: Date.now()
                        }), s = this.$taroPath = Pn(r, o);
                        En && (w.path = s), null == this.$taroParams && (this.$taroParams = o), y(this), 
                        En || bn.trigger(N.INIT, s);
                        const l = () => {
                            Je.app.mount(t, s, () => {
                                m = X.document.getElementById(s), Object(a.e)(null !== m, "没有找到页面实例。"), jn(s, T, this.$taroParams), 
                                f(), En ? Object(a.k)(n) && n() : (m.ctx = this, m.performUpdate(!0, n));
                            });
                        };
                        b ? v.push(l) : l();
                    },
                    [s]() {
                        const t = this.$taroPath;
                        En || bn.trigger(N.DESTORY, t), jn(t, s), b = !0, Je.app.unmount(t, () => {
                            b = !1, Sn.delete(t), m && (m.ctx = null, m = null), v.length && (v.forEach(t => t()), 
                            v = []);
                        });
                    },
                    [l]() {
                        g.then(() => {
                            jn(this.$taroPath, C), gn(() => ze.trigger(Ln(r))), this.onReady.called = !0;
                        });
                    },
                    [u](t = {}) {
                        g.then(() => {
                            Je.page = this, y(this), En || bn.trigger(N.RECOVER, this.$taroPath), jn(this.$taroPath, k, t), 
                            gn(() => ze.trigger(Nn(r)));
                        });
                    },
                    [h]() {
                        En || bn.trigger(N.RESTORE, this.$taroPath), Je.page === this && (Je.page = null, 
                        Je.router = null), jn(this.$taroPath, x), ze.trigger(Rn(r));
                    }
                };
                return d.forEach(t => {
                    w[t] = function() {
                        return jn(this.$taroPath, t, ...arguments);
                    };
                }), p.forEach(e => {
                    var n;
                    (t[e] || (null === (n = t.prototype) || void 0 === n ? void 0 : n[e]) || t[e.replace(/^on/, "enable")] || (null == i ? void 0 : i[e.replace(/^on/, "enable")])) && (w[e] = function(...t) {
                        var n;
                        const i = null === (n = t[0]) || void 0 === n ? void 0 : n.target;
                        if (null == i ? void 0 : i.id) {
                            const t = i.id, e = X.document.getElementById(t);
                            e && (i.dataset = e.dataset);
                        }
                        return jn(this.$taroPath, e, ...t);
                    });
                }), w.eh = le, Object(a.p)(n) || (w.data = n), a.g.call("modifyPageObject", w), 
                w;
            }
            function An(t, e, n) {
                const i = null != e ? e : "taro_component_" + On();
                let r = null;
                const [o, s] = a.g.call("getMiniLifecycleImpl").component, l = {
                    [o]() {
                        var e;
                        he.start(c);
                        const n = Pn(i, {
                            id: (null === (e = this.getPageId) || void 0 === e ? void 0 : e.call(this)) || On()
                        });
                        Je.app.mount(t, n, () => {
                            r = X.document.getElementById(n), Object(a.e)(null !== r, "没有找到组件实例。"), this.$taroInstances = Sn.get(n), 
                            jn(n, T), En || (r.ctx = this, r.performUpdate(!0));
                        });
                    },
                    [s]() {
                        const t = Pn(i, {
                            id: this.getPageId()
                        });
                        Je.app.unmount(t, () => {
                            Sn.delete(t), r && (r.ctx = null);
                        });
                    },
                    methods: {
                        eh: le
                    }
                };
                return Object(a.p)(n) || (l.data = n), [ j, I, L ].forEach(e => {
                    var n;
                    l[e] = null !== (n = t[e]) && void 0 !== n ? n : a.a;
                }), l;
            }
            function Mn(t) {
                const e = t === y, [n, i] = a.g.call("getMiniLifecycleImpl").component, r = e ? {
                    [n]() {
                        var t, e;
                        const n = (null === (t = this.data.i) || void 0 === t ? void 0 : t.sid) || (null === (e = this.props.i) || void 0 === e ? void 0 : e.sid);
                        if (Object(a.o)(n)) {
                            V.set(n, this);
                            const t = X.document.getElementById(n);
                            t && (t.ctx = this);
                        }
                    },
                    [i]() {
                        var t, e;
                        const n = (null === (t = this.data.i) || void 0 === t ? void 0 : t.sid) || (null === (e = this.props.i) || void 0 === e ? void 0 : e.sid);
                        if (Object(a.o)(n)) {
                            V.delete(n);
                            const t = X.document.getElementById(n);
                            t && (t.ctx = null);
                        }
                    }
                } : a.a;
                return Object.assign({
                    properties: {
                        i: {
                            type: Object,
                            value: {
                                nn: Object(a.f)(a.h)[f]._num
                            }
                        },
                        l: {
                            type: String,
                            value: ""
                        }
                    },
                    options: {
                        addGlobalClass: !0,
                        virtualHost: !e
                    },
                    methods: {
                        eh: le
                    }
                }, r);
            }
            const Bn = (t, e) => {
                var n, i, r;
                const o = Je.router, s = () => {
                    setTimeout(function() {
                        e ? t.call(e) : t();
                    }, 1);
                };
                if (null !== o) {
                    let c = null;
                    const l = o.$taroPath;
                    c = X.document.getElementById(l), (null == c ? void 0 : c.pendingUpdate) ? Object(a.q)() ? null !== (r = null === (i = null === (n = c.firstChild) || void 0 === n ? void 0 : n.componentOnReady) || void 0 === i ? void 0 : i.call(n).then(() => {
                        s();
                    })) && void 0 !== r || s() : c.enqueueUpdateCallback(t, e) : s();
                } else s();
            };
        }.call(this, n(7).window, n(7).document, n(7).requestAnimationFrame, n(7).cancelAnimationFrame, n(65));
    },
    71: function(t, e, n) {
        "use strict";
        (function(t) {
            n.d(e, "a", function() {
                return r;
            });
            let i = null;
            function r(e = !1) {
                if (null === i || e) {
                    const e = t.createElement("div"), n = e.style;
                    n.width = "50px", n.height = "50px", n.overflow = "scroll", n.direction = "rtl";
                    const r = t.createElement("div"), o = r.style;
                    return o.width = "100px", o.height = "100px", e.appendChild(r), t.body.appendChild(e), 
                    e.scrollLeft > 0 ? i = "positive-descending" : (e.scrollLeft = 1, i = 0 === e.scrollLeft ? "negative" : "positive-ascending"), 
                    t.body.removeChild(e), i;
                }
                return i;
            }
        }).call(this, n(7).document);
    },
    74: function(t, e, n) {
        "use strict";
        n.d(e, "a", function() {
            return F;
        });
        var i = n(3), r = n(7);
        const o = {
            PageContext: i.a,
            R: i.a
        }, s = "taro-app";
        function a(t, e) {
            var n;
            const r = e.prototype;
            return !(null === (n = e.displayName) || void 0 === n ? void 0 : n.includes("Connect")) && (Object(i.k)(e.render) || !!(null == r ? void 0 : r.isReactComponent) || r instanceof t.Component);
        }
        function c(t) {
            return Object(i.i)(t) ? t : t ? [ t ] : [];
        }
        function l(t) {
            return t.writable = !0, t.enumerable = !0, t;
        }
        function u(t) {
            r.Current.router = Object.assign({
                params: null == t ? void 0 : t.query
            }, t);
        }
        const h = t => e => {
            const {R: n, PageContext: a} = o, c = n.useContext(a) || s, l = n.useRef(), u = n.useRef(e);
            u.current !== e && (u.current = e), n.useLayoutEffect(() => {
                let e = l.current = Object(r.getPageInstance)(c), n = !1;
                e || (n = !0, l.current = Object.create(null), e = l.current);
                const o = (...t) => u.current(...t);
                return Object(i.k)(e[t]) ? e[t] = [ e[t], o ] : e[t] = [ ...e[t] || [], o ], n && Object(r.injectPageInstance)(e, c), 
                () => {
                    const e = l.current;
                    if (!e) return;
                    const n = e[t];
                    n === o ? e[t] = void 0 : Object(i.i)(n) && (e[t] = n.filter(t => t !== o)), l.current = void 0;
                };
            }, []);
        }, d = h("componentDidHide"), p = h("componentDidShow"), f = h("onError"), g = h("onUnhandledRejection"), m = h("onLaunch"), b = h("onPageNotFound"), v = h("onLoad"), y = h("onPageScroll"), w = h("onPullDownRefresh"), S = h("onPullIntercept"), O = h("onReachBottom"), E = h("onResize"), T = h("onUnload"), C = h("onAddToFavorites"), k = h("onOptionMenuClick"), x = h("onSaveExitState"), j = h("onShareAppMessage"), I = h("onShareTimeline"), P = h("onTitleClick"), L = h("onReady"), N = h("onTabItemTap");
        var R = Object.freeze({
            __proto__: null,
            useAddToFavorites: C,
            useDidHide: d,
            useDidShow: p,
            useError: f,
            useLaunch: m,
            useLoad: v,
            useOptionMenuClick: k,
            usePageNotFound: b,
            usePageScroll: y,
            usePullDownRefresh: w,
            usePullIntercept: S,
            useReachBottom: O,
            useReady: L,
            useResize: E,
            useRouter: (t = !1) => {
                const e = o.R;
                return t ? r.Current.router : e.useMemo(() => r.Current.router, []);
            },
            useSaveExitState: x,
            useScope: () => {},
            useShareAppMessage: j,
            useShareTimeline: I,
            useTabItemTap: N,
            useTitleClick: P,
            useUnhandledRejection: g,
            useUnload: T
        });
        let _, A, M;
        const B = Object(r.incrementId)(), D = Object(i.q)();
        function U(t) {
            i.g.tap("getLifecycle", function(t, e) {
                return t[e = e.replace(/^on(Show|Hide)$/, "componentDid$1")];
            }), i.g.tap("modifyMpEvent", function(t) {
                Object.defineProperty(t, "type", {
                    value: t.type.replace(/-/g, "")
                });
            }), i.g.tap("batchedEventUpdates", function(e) {
                t.unstable_batchedUpdates(e);
            }), i.g.tap("mergePageInstance", function(t, e) {
                t && e && ("constructor" in t || Object.keys(t).forEach(n => {
                    const i = t[n], r = c(e[n]);
                    e[n] = r.concat(i);
                }));
            }), D && (i.g.tap("createPullDownComponent", (t, e, n, i) => {
                const r = a(n, t);
                return n.forwardRef((e, n) => {
                    const o = Object.assign({}, e), s = r ? {
                        ref: n
                    } : {
                        forwardedRef: n,
                        reactReduxForwardedRef: n
                    };
                    return _(i || "taro-pull-to-refresh", null, _(t, Object.assign(Object.assign({}, o), s)));
                });
            }), i.g.tap("getDOMNode", e => t.findDOMNode(e)));
        }
        function z(t, e) {
            return n => {
                const s = t => t && Object(r.injectPageInstance)(t, e), c = a(t, n) ? {
                    ref: s
                } : {
                    forwardedRef: s,
                    reactReduxForwardedRef: s
                };
                return o.PageContext === i.a && (o.PageContext = t.createContext("")), class extends t.Component {
                    constructor() {
                        super(...arguments), this.state = {
                            hasError: !1
                        };
                    }
                    static getDerivedStateFromError(t) {
                        var e, n;
                        return null === (n = null === (e = r.Current.app) || void 0 === e ? void 0 : e.onError) || void 0 === n || n.call(e, t.message + t.stack), 
                        {
                            hasError: !0
                        };
                    }
                    componentDidCatch(t, e) {}
                    render() {
                        const t = this.state.hasError ? [] : _(o.PageContext.Provider, {
                            value: e
                        }, _(n, Object.assign(Object.assign({}, this.props), c)));
                        return D ? _("div", {
                            id: e,
                            className: "taro_page"
                        }, t) : _("root", {
                            id: e
                        }, t);
                    }
                };
            };
        }
        function F(t, e, n, c) {
            o.R = e, _ = e.createElement, A = n, M = e.Fragment;
            const h = e.createRef(), d = a(e, t);
            let p, f;
            const g = new Promise(t => f = t);
            function m() {
                return h.current;
            }
            function b(t) {
                p ? t() : g.then(() => t());
            }
            function v() {
                var t, n;
                let i = "app";
                D && (i = (null == c ? void 0 : c.appId) || i);
                const o = r.document.getElementById(i);
                if ((e.version || "").startsWith("18")) {
                    const e = A.createRoot(o);
                    null === (t = e.render) || void 0 === t || t.call(e, _(y));
                } else null === (n = A.render) || void 0 === n || n.call(A, _(y), o);
            }
            U(A);
            class y extends e.Component {
                constructor(t) {
                    super(t), this.pages = [], this.elements = [], p = this, f(this);
                }
                mount(t, n, i) {
                    const r = z(e, n)(t), o = n + B();
                    this.pages.push(() => _(r, {
                        key: o,
                        tid: n
                    })), this.forceUpdate(i);
                }
                unmount(t, e) {
                    const n = this.elements, i = n.findIndex(e => e.props.tid === t);
                    n.splice(i, 1), this.forceUpdate(e);
                }
                render() {
                    const {pages: e, elements: n} = this;
                    for (;e.length > 0; ) {
                        const t = e.pop();
                        n.push(t());
                    }
                    let i = null;
                    return d && (i = {
                        ref: h
                    }), _(t, i, D ? _(null != M ? M : "div", null, n.slice()) : n.slice());
                }
            }
            D || v();
            const [w, S, O] = i.g.call("getMiniLifecycleImpl").app, E = Object.create({
                render(t) {
                    p.forceUpdate(t);
                },
                mount(t, e, n) {
                    p ? p.mount(t, e, n) : g.then(i => i.mount(t, e, n));
                },
                unmount(t, e) {
                    p.unmount(t, e);
                }
            }, {
                config: l({
                    configurable: !0,
                    value: c
                }),
                [w]: l({
                    value(t) {
                        u(t), D && v(), b(() => {
                            var e;
                            const n = m();
                            if (this.$app = n, n) {
                                if (n.taroGlobalData) {
                                    const t = n.taroGlobalData, e = Object.keys(t), i = Object.getOwnPropertyDescriptors(t);
                                    e.forEach(e => {
                                        Object.defineProperty(this, e, {
                                            configurable: !0,
                                            enumerable: !0,
                                            get: () => t[e],
                                            set(n) {
                                                t[e] = n;
                                            }
                                        });
                                    }), Object.defineProperties(this, i);
                                }
                                null === (e = n.onLaunch) || void 0 === e || e.call(n, t);
                            }
                            T("onLaunch", t);
                        });
                    }
                }),
                [S]: l({
                    value(t) {
                        u(t), b(() => {
                            var e;
                            const n = m();
                            null === (e = null == n ? void 0 : n.componentDidShow) || void 0 === e || e.call(n, t), 
                            T("onShow", t);
                        });
                    }
                }),
                [O]: l({
                    value() {
                        b(() => {
                            var t;
                            const e = m();
                            null === (t = null == e ? void 0 : e.componentDidHide) || void 0 === t || t.call(e), 
                            T("onHide");
                        });
                    }
                }),
                onError: l({
                    value(t) {
                        b(() => {
                            var e;
                            const n = m();
                            null === (e = null == n ? void 0 : n.onError) || void 0 === e || e.call(n, t), T("onError", t);
                        });
                    }
                }),
                onUnhandledRejection: l({
                    value(t) {
                        b(() => {
                            var e;
                            const n = m();
                            null === (e = null == n ? void 0 : n.onUnhandledRejection) || void 0 === e || e.call(n, t), 
                            T("onUnhandledRejection", t);
                        });
                    }
                }),
                onPageNotFound: l({
                    value(t) {
                        b(() => {
                            var e;
                            const n = m();
                            null === (e = null == n ? void 0 : n.onPageNotFound) || void 0 === e || e.call(n, t), 
                            T("onPageNotFound", t);
                        });
                    }
                })
            });
            function T(t, ...e) {
                const n = Object(r.getPageInstance)(s);
                if (n) {
                    const r = m(), o = i.g.call("getLifecycle", n, t);
                    Array.isArray(o) && o.forEach(t => t.apply(r, e));
                }
            }
            return r.Current.app = E, E;
        }
        Object(r.incrementId)(), i.g.tap("initNativeApi", function(t) {
            for (const e in R) t[e] = R[e];
        });
    },
    79: function(t, e, n) {
        "use strict";
        n.d(e, "a", function() {
            return D;
        });
        var i = n(3), r = n(7), o = n(80), s = n.n(o), a = n(81);
        const c = {
            color: !0,
            date: !0,
            datetime: !0,
            "datetime-local": !0,
            email: !0,
            month: !0,
            number: !0,
            password: !0,
            range: !0,
            search: !0,
            tel: !0,
            text: !0,
            time: !0,
            url: !0,
            week: !0
        }, l = Math.random().toString(36).slice(2), u = "__reactProps$" + l, h = "__reactFiber$" + l, d = "__reactContainer$" + l;
        function p(t, e) {
            e[h] = t;
        }
        function f(t) {
            const e = t[h] || t[d];
            return !e || 5 !== e.tag && 6 !== e.tag && 13 !== e.tag && 3 !== e.tag ? null : e;
        }
        function g(t, e) {
            t[u] = e;
        }
        function m(t) {
            return "" + t;
        }
        function b(t, e, n) {
            !function(t, e, n, i = "string") {
                null != n ? "number" === i ? (0 === n && "" === t.value || e != n) && (t.value = m(n)) : e !== m(n) && (t.value = m(n)) : "submit" !== i && "reset" !== i || t.removeAttribute("value");
            }(t, e, function(t) {
                return "function" == typeof t || "symbol" == typeof t ? "" : t;
            }(n.value), n.type);
        }
        const v = b, y = function(t, e, n) {
            const i = t;
            null == n.checked ? (b(t, e, n), function(t, e) {
                const n = e.name;
                "radio" === e.type && null != n && console.warn("radio updateNamedCousins 未实现", t, e);
            }(t, n)) : console.warn("updateCheck 未实现", i);
        };
        function w(t) {
            return t._valueTracker;
        }
        function S(t) {
            w(t) || (t._valueTracker = function(t) {
                const e = function(t) {
                    const e = t.type, n = t.nodeName;
                    return n && "input" === n.toLowerCase() && ("checkbox" === e || "radio" === e);
                }(t) ? "checked" : "value", n = Object.getOwnPropertyDescriptor(t.constructor.prototype, e);
                let i = "" + t[e];
                if (t.hasOwnProperty(e) || void 0 === n || "function" != typeof n.get || "function" != typeof n.set) return;
                const {get: r, set: o} = n;
                return Object.defineProperty(t, e, {
                    configurable: !0,
                    enumerable: n.enumerable,
                    get: function() {
                        return r.call(this);
                    },
                    set: function(t) {
                        i = "" + t, o.call(this, t);
                    }
                }), {
                    getValue: () => i,
                    setValue(t) {
                        i = "" + t;
                    },
                    stopTracking() {
                        (function(t) {
                            t._valueTracker = null;
                        })(t), delete t[e];
                    }
                };
            }(t));
        }
        const O = /aspect|acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i;
        function E(t, e, n) {
            for (let i = 0; i < n.length; i += 2) {
                const r = n[i];
                k(t, r, n[i + 1], e[r]);
            }
        }
        function T(t, e, n) {
            let i, o = null;
            for (i in e) i in n || (o = o || []).push(i, null);
            const s = t instanceof r.FormElement;
            for (i in n) (e[i] !== n[i] || s && "value" === i) && (o = o || []).push(i, n[i]);
            return o;
        }
        function C(t, e, n) {
            "-" !== e[0] ? t[e] = Object(i.m)(n) && !1 === O.test(e) ? n + "px" : null == n ? "" : n : t.setProperty(e, n.toString());
        }
        function k(t, e, n, r) {
            var o, s;
            if ("key" === (e = "className" === e ? "class" : e) || "children" === e || "ref" === e) ; else if ("style" === e) {
                const e = t.style;
                if (Object(i.o)(n)) e.cssText = n; else {
                    if (Object(i.o)(r) && (e.cssText = "", r = null), Object(i.n)(r)) for (const t in r) n && t in n || C(e, t, "");
                    if (Object(i.n)(n)) for (const t in n) r && n[t] === r[t] || C(e, t, n[t]);
                }
            } else if (function(t) {
                return "o" === t[0] && "n" === t[1];
            }(e)) !function(t, e, n, r) {
                const o = e.endsWith("Capture");
                let s = e.toLowerCase().slice(2);
                o && (s = s.slice(0, -7));
                const a = Object(i.c)(Object(i.v)(t.tagName.toLowerCase()));
                "click" === s && a in i.h && (s = "tap"), Object(i.k)(n) ? r ? (t.removeEventListener(s, r, !1), 
                t.addEventListener(s, n, {
                    isCapture: o,
                    sideEffect: !1
                })) : t.addEventListener(s, n, o) : t.removeEventListener(s, r);
            }(t, e, n, r); else if ("dangerouslySetInnerHTML" === e) {
                const e = null !== (o = null == n ? void 0 : n.__html) && void 0 !== o ? o : "", i = null !== (s = null == r ? void 0 : r.__html) && void 0 !== s ? s : "";
                (e || i) && i !== e && (t.innerHTML = e);
            } else Object(i.k)(n) || (null == n ? t.removeAttribute(e) : t.setAttribute(e, n));
        }
        const x = {
            getPublicInstance: t => t,
            getRootHostContext: () => ({}),
            getChildHostContext: t => t,
            prepareForCommit: (...t) => null,
            resetAfterCommit: i.t,
            createInstance(t, e, n, i, o) {
                const s = r.document.createElement(t);
                return p(o, s), g(s, e), s;
            },
            appendInitialChild(t, e) {
                t.appendChild(e);
            },
            finalizeInitialChildren: (t, e, n) => ((function(t, e, n) {
                const i = T(t, e, n);
                i && E(t, e, i);
            })(t, {}, n), "input" !== e && "textarea" !== e || S(t), !1),
            prepareUpdate: (t, e, n, i) => T(t, n, i),
            shouldSetTextContent: () => !1,
            createTextInstance(t, e, n, i) {
                const o = r.document.createTextNode(t);
                return p(i, o), o;
            },
            scheduleTimeout: setTimeout,
            cancelTimeout: clearTimeout,
            noTimeout: -1,
            isPrimaryRenderer: !0,
            warnsIfNotActing: !0,
            supportsMutation: !0,
            supportsPersistence: !1,
            supportsHydration: !1,
            getInstanceFromNode: () => null,
            beforeActiveInstanceBlur: i.t,
            afterActiveInstanceBlur: i.t,
            preparePortalMount: i.t,
            prepareScopeUpdate: i.t,
            getInstanceFromScope: () => null,
            getCurrentEventPriority: () => a.DefaultEventPriority,
            detachDeletedInstance: i.t,
            supportsMicrotasks: !0,
            scheduleMicrotask: Object(i.p)(Promise) ? setTimeout : t => Promise.resolve(null).then(t).catch(function(t) {
                setTimeout(() => {
                    throw t;
                });
            }),
            appendChild(t, e) {
                t.appendChild(e);
            },
            appendChildToContainer(t, e) {
                t.appendChild(e);
            },
            commitTextUpdate(t, e, n) {
                t.nodeValue = n;
            },
            commitMount: i.t,
            commitUpdate(t, e, n, i, r) {
                E(t, i, e), g(t, r);
            },
            insertBefore(t, e, n) {
                t.insertBefore(e, n);
            },
            insertInContainerBefore(t, e, n) {
                t.insertBefore(e, n);
            },
            removeChild(t, e) {
                t.removeChild(e);
            },
            removeChildFromContainer(t, e) {
                t.removeChild(e);
            },
            resetTextContent: i.t,
            hideInstance(t) {
                t.style.setProperty("display", "none");
            },
            hideTextInstance(t) {
                t.nodeValue = "";
            },
            unhideInstance(t, e) {
                const n = e.style;
                let r = (null == n ? void 0 : n.hasOwnProperty("display")) ? n.display : null;
                r = null == r || Object(i.j)(r) || "" === r ? "" : ("" + r).trim(), t.style.display = r;
            },
            unhideTextInstance(t, e) {
                t.nodeValue = e;
            },
            clearContainer(t) {
                t.childNodes.length > 0 && (t.textContent = "");
            }
        }, j = s()(x);
        let I = null;
        function P(t, e) {
            var n, i;
            const r = f(e), o = t.type;
            if (r && function(t) {
                const e = t && t.nodeName && t.nodeName.toLowerCase();
                if ("input" === e) {
                    const e = t.type;
                    return !e || !!c[e];
                }
                return "textarea" === e;
            }(e) && ("input" === o || "change" === o)) return function(t, e) {
                const n = function(t) {
                    if (5 === t.tag || 6 === t.tag) return t.stateNode;
                }(t);
                return !!n && (function(t, e) {
                    if (!t) return !1;
                    const n = w(t);
                    return !n || e !== n.getValue() && (n.setValue(e), !0);
                }(n, e) ? t : void 0);
            }(r, m(null === (i = null === (n = t.mpEvent) || void 0 === n ? void 0 : n.detail) || void 0 === i ? void 0 : i.value));
        }
        function L() {
            null !== I && (j.flushSync(), function() {
                if (!I) return;
                const t = I;
                I = null;
                for (let e = 0; e < t.length; e++) N(t[e]);
            }());
        }
        function N(t) {
            const e = f(t.target);
            if (!e) return;
            const {stateNode: n, type: i} = e;
            if (n) {
                const e = function(t) {
                    return t[u] || null;
                }(n);
                !function(t, e, n, i) {
                    switch (e) {
                      case "input":
                        y(t, n, i);
                        break;

                      case "textarea":
                        v(t, n, i);
                    }
                }(n, i, t.value, e);
            }
        }
        const R = new WeakMap();
        class _ {
            constructor(t, e, n) {
                this.renderer = t, this.initInternalRoot(t, e, n);
            }
            initInternalRoot(t, e, n) {
                const i = e;
                if (n) {
                    const e = 1, r = !1;
                    let o = !1, s = "", a = t => console.error(t), c = null;
                    !0 === n.unstable_strictMode && (o = !0), void 0 !== n.identifierPrefix && (s = n.identifierPrefix), 
                    void 0 !== n.onRecoverableError && (a = n.onRecoverableError), void 0 !== n.unstable_transitionCallbacks && (c = n.unstable_transitionCallbacks), 
                    this.internalRoot = t.createContainer(i, e, null, o, r, s, a, c);
                } else {
                    const e = 0;
                    this.internalRoot = t.createContainer(i, e, null, !1, !1, "", () => {}, null);
                }
            }
            render(t, e) {
                const {renderer: n, internalRoot: i} = this;
                return n.updateContainer(t, i, null, e), n.getPublicRootInstance(i);
            }
            unmount(t) {
                this.renderer.updateContainer(null, this.internalRoot, null, t);
            }
        }
        let A = !1;
        const M = (t, e) => {
            if (A) return t(e);
            A = !0;
            try {
                return j.batchedUpdates(t, e);
            } finally {
                A = !1, L();
            }
        }, B = Object(i.k)(Symbol) && Symbol.for ? Symbol.for("react.portal") : 60106;
        var D = {
            render: function(t, e, n) {
                const i = R.get(e);
                if (null != i) return i.render(t, n);
                const r = new _(j, e);
                return R.set(e, r), r.render(t, n);
            },
            createRoot: function(t, e = {}) {
                var n;
                const i = R.get(t);
                if (null != i) return i;
                const o = new _(j, t, e);
                return R.set(t, o), function(t, e) {
                    e[d] = t;
                }(null === (n = null == o ? void 0 : o.internalRoot) || void 0 === n ? void 0 : n.current, t), 
                r.hooks.tap("dispatchTaroEvent", (t, e) => {
                    const n = function(t) {
                        switch (t) {
                          case "cancel":
                          case "click":
                          case "close":
                          case "contextmenu":
                          case "copy":
                          case "cut":
                          case "dragend":
                          case "dragstart":
                          case "drop":
                          case "input":
                          case "paste":
                          case "pause":
                          case "play":
                          case "pointercancel":
                          case "pointerdown":
                          case "pointerup":
                          case "reset":
                          case "resize":
                          case "submit":
                          case "touchcancel":
                          case "touchend":
                          case "touchstart":
                          case "change":
                          case "blur":
                          case "focus":
                          case "select":
                          case "selectstart":
                            return 1;

                          case "drag":
                          case "dragenter":
                          case "dragexit":
                          case "dragleave":
                          case "dragover":
                          case "pointermove":
                          case "pointerout":
                          case "pointerover":
                          case "scroll":
                          case "toggle":
                          case "touchmove":
                          case "pointerenter":
                          case "pointerleave":
                            return 4;

                          default:
                            return 16;
                        }
                    }(t.type);
                    j.runWithPriority(n, () => {
                        e.dispatchEvent(t);
                    });
                }), r.hooks.tap("modifyTaroEvent", (t, e) => {
                    var n, i;
                    P(t, e) && function(t) {
                        I ? I.push(t) : I = [ t ];
                    }({
                        target: e,
                        value: null === (i = null === (n = t.mpEvent) || void 0 === n ? void 0 : n.detail) || void 0 === i ? void 0 : i.value
                    });
                }), o;
            },
            unstable_batchedUpdates: M,
            unmountComponentAtNode: function(t) {
                Object(i.e)(t && [ 1, 8, 9, 11 ].includes(t.nodeType), "unmountComponentAtNode(...): Target container is not a DOM element.");
                const e = R.get(t);
                return !!e && (M(() => {
                    e.unmount(() => {
                        R.delete(t);
                    });
                }, null), !0);
            },
            findDOMNode: function(t) {
                if (null == t) return null;
                const e = t.nodeType;
                return 1 === e || 3 === e ? t : j.findHostInstance(t);
            },
            createPortal: function(t, e, n) {
                return {
                    $$typeof: B,
                    key: null == n ? null : String(n),
                    children: t,
                    containerInfo: e,
                    implementation: null
                };
            }
        };
    }
} ]);