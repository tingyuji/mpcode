$gwx_XC_4=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}var __WXML_GLOBAL__={};{
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_4 || [];
__WXML_GLOBAL__.debuginfo_set = __WXML_GLOBAL__.debuginfo_set || {};
var debugInfo=__WXML_GLOBAL__.debuginfo_set.$gwx_XC_4 || [];
function gz$gwx_XC_4_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_4_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_4_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_4_1=[];
(function(z){var a=11;function Z(ops,debugLine){z.push(['11182016',ops,debugLine])}
Z([[7],[3,'multi']],['./miniprogram_npm/weui-miniprogram/checkbox-group/checkbox-group.wxml',1,43])
Z([3,'checkedChange'],['./miniprogram_npm/weui-miniprogram/checkbox-group/checkbox-group.wxml',1,66])
Z([[7],[3,'extClass']],['./miniprogram_npm/weui-miniprogram/checkbox-group/checkbox-group.wxml',1,22])
Z(z[1][1],['./miniprogram_npm/weui-miniprogram/checkbox-group/checkbox-group.wxml',4,54])
Z(z[2][1],['./miniprogram_npm/weui-miniprogram/checkbox-group/checkbox-group.wxml',4,20])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_4_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_4_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_4=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_4=true;
__WXML_GLOBAL__.debuginfo_set.$gwx_XC_4=debugInfo;
var x=['./miniprogram_npm/weui-miniprogram/checkbox-group/checkbox-group.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_4_1()
var eZC=_v()
_(r,eZC)
if(_oz(z,0,e,s,gg)){eZC.wxVkey=1
var b1C=_mz(z,'checkbox-group',['bindchange',1,'class',1],[],e,s,gg)
var o2C=_n('slot')
_(b1C,o2C)
_(eZC,b1C)
}
var x3C=_mz(z,'radio-group',['bindchange',3,'class',1],[],e,s,gg)
var o4C=_n('slot')
_(x3C,o4C)
_(r,x3C)
eZC.wxXCkey=1
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
window.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_4";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(window.__webview_engine_version__)!='undefined'&&window.__webview_engine_version__+1e-6>=0.02+1e-6&&window.__mergeData__)
{
env=window.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(window.__webview_engine_version__)=='undefined'|| window.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_4();		__wxAppCode__['miniprogram_npm/weui-miniprogram/checkbox-group/checkbox-group.wxss'] = setCssToHead_wxfa43a4a7041a84de([],undefined,{path:"./miniprogram_npm/weui-miniprogram/checkbox-group/checkbox-group.wxss"});
		if (__vd_version_info__.delayedGwx) __wxAppCode__['miniprogram_npm/weui-miniprogram/checkbox-group/checkbox-group.wxml'] = [ $gwx_XC_4, './miniprogram_npm/weui-miniprogram/checkbox-group/checkbox-group.wxml' ];
		else __wxAppCode__['miniprogram_npm/weui-miniprogram/checkbox-group/checkbox-group.wxml'] = $gwx_XC_4( './miniprogram_npm/weui-miniprogram/checkbox-group/checkbox-group.wxml' );
		