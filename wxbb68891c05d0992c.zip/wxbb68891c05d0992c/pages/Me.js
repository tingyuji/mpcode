(wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 16 ], {
    177: function(e, a, n) {
        "use strict";
        n.r(a);
        var s = n(7), r = n(21), c = n(63), t = n(8), i = n(0), b = function() {
            var e = t.a.account;
            return Object(i.jsx)(c.a, {
                user_id: e.user_id,
                isMe: !0,
                hasTabBar: !0
            });
        }, u = function() {
            return Object(i.jsx)(r.a, {
                className: "me",
                children: Object(i.jsx)(b, {})
            });
        };
        u.enableShareTimeline = !0, u.enableShareAppMessage = !0, Page(Object(s.createPageConfig)(u, "pages/Me", {
            root: {
                cn: []
            }
        }, {
            enableShareAppMessage: !0,
            enableShareTimeline: !0
        } || {})), a.default = u;
    }
}, [ [ 177, 0, 1, 2, 3 ] ] ]);