(wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 20 ], {
    179: function(e, a, t) {
        "use strict";
        t.r(a);
        var s = t(7), c = t(36), n = t(19), i = t(21), r = t(12), o = t(35), p = t(11), b = t(0), j = function() {
            var e = Object(o.a)(), a = e.post_id, t = e.top_id, s = Object(p.a)("/post/detail", {
                params: {
                    post_id: a
                },
                initialData: {},
                onSuccess: function(e) {
                    Object(r.c)("postMap", e.post_id, e), Object(r.c)("userMap", e.author.user_id, e.author);
                }
            }).data;
            return Object(b.jsxs)(b.Fragment, {
                children: [ Object(b.jsx)(n.a, {
                    backBtn: !0
                }), Object(b.jsx)(c.a, {
                    single: s,
                    top_id: t
                }) ]
            });
        }, u = function() {
            return Object(b.jsx)(i.a, {
                className: "post",
                children: Object(b.jsx)(j, {})
            });
        };
        u.enableShareTimeline = !0, u.enableShareAppMessage = !0, Page(Object(s.createPageConfig)(u, "pages/Post", {
            root: {
                cn: []
            }
        }, {
            enableShareAppMessage: !0,
            enableShareTimeline: !0
        } || {})), a.default = u;
    }
}, [ [ 179, 0, 1, 2, 3 ] ] ]);