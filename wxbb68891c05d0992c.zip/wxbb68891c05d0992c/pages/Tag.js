(wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 24 ], {
    163: function(e, t, a) {},
    178: function(e, t, a) {
        "use strict";
        a.r(t);
        var c = a(7), n = a(16), i = a(1), r = a(2), s = a(5), l = a(29), o = a(26), j = a(18), u = a(64), b = a(19), d = a(21), g = a(12), O = a(49), p = a(35), h = a(33), m = a(4), f = a(11), x = a(8), _ = (a(163), 
        a(0)), T = Object(n.a)(Array(18)).map(function() {
            return {};
        }), v = function() {
            var e, t, a = x.a.taggedMap, c = Object(p.a)().tag_name, n = "#".concat(c), d = Object(f.a)("/feed/tag", {
                loadMore: !0,
                params: {
                    tag_name: c,
                    count: 18
                },
                initialData: {
                    list: a[c] || T
                },
                onSuccess: function(e) {
                    var t = e.list;
                    Object(g.a)("taggedMap", c, t), Object(g.d)("postMap", "post_id", t), Object(g.d)("userMap", "author.user_id", t);
                }
            }), v = d.patchLoading, M = d.data, S = d.run, A = d.patch, D = d.mutate;
            Object(s.useReachBottom)(A);
            var E = M.list, P = E[0], w = null == P || null === (e = P.img_list) || void 0 === e || null === (t = e[0]) || void 0 === t ? void 0 : t.url;
            return Object(h.a)(function() {
                return {
                    title: "FUTAKE 上的 ".concat(n, " • 照片"),
                    path: "/pages/Tag?tag_name=".concat(c),
                    imageUrl: w
                };
            }), Object(i.useEffect)(function() {
                var e = function(e) {
                    return Object(g.e)(D, "post_id", e);
                };
                return m.b.on("DEL_TAGGED_POST", e), function() {
                    m.b.off("DEL_TAGGED_POST", e);
                };
            }, [ D ]), Object(_.jsxs)(_.Fragment, {
                children: [ Object(_.jsx)(b.a, {
                    backBtn: !0,
                    title: n
                }), Object(_.jsxs)(l.a, {
                    onPullDown: S,
                    children: [ Object(_.jsx)(r.i, {
                        className: "tag-header",
                        children: Object(_.jsx)(r.i, {
                            className: "tag-icon",
                            children: P.post_id && Object(_.jsx)(_.Fragment, {
                                children: w ? Object(_.jsx)(o.a, {
                                    src: w,
                                    size: 500,
                                    mode: "aspectFill",
                                    onClick: function() {
                                        return Object(O.a)(w);
                                    }
                                }) : Object(_.jsx)(r.g, {
                                    children: c[0]
                                })
                            })
                        })
                    }), Object(_.jsx)(r.i, {
                        className: "grids-header",
                        children: "作品"
                    }), Object(_.jsx)(u.a, {
                        gridList: E,
                        gridPatch: A,
                        emptyTitle: n
                    }), v && Object(_.jsx)(j.a, {
                        ring: !0
                    }) ]
                }) ]
            });
        }, M = function() {
            return Object(_.jsx)(d.a, {
                className: "tag",
                children: Object(_.jsx)(v, {})
            });
        };
        M.enableShareTimeline = !0, M.enableShareAppMessage = !0, Page(Object(c.createPageConfig)(M, "pages/Tag", {
            root: {
                cn: []
            }
        }, {
            enableShareAppMessage: !0,
            enableShareTimeline: !0
        } || {})), t.default = M;
    }
}, [ [ 178, 0, 1, 2, 3 ] ] ]);