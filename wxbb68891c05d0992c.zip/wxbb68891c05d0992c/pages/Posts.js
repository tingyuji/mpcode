(wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 22 ], {
    172: function(e, n, t) {
        "use strict";
        t.r(n);
        var a = t(7), c = t(36), r = t(19), s = t(21), i = t(9), u = t(6), o = t(1), b = t(5), l = function(e) {
            var n = Object(o.useMemo)(function() {
                var e = Object(b.getCurrentPages)();
                return e[e.length - 1].getOpenerEventChannel();
            }, []), t = Object(o.useState)({}), a = Object(u.a)(t, 2), c = a[0], r = a[1];
            return Object(o.useMemo)(function() {
                var t;
                null === (t = n.on) || void 0 === t || t.call(n, e, function(e) {
                    r(function(n) {
                        return Object(i.a)(Object(i.a)({}, n), e);
                    });
                });
            }, [ n, e ]), Object(o.useEffect)(function() {
                return function() {
                    var t;
                    null === (t = n.off) || void 0 === t || t.call(n, e);
                };
            }, [ n, e ]), c;
        }, j = t(0), g = function() {
            var e = l("OPEN_POSTS"), n = e.gridList, t = e.gridPatch, a = e.gridIndex;
            return Object(j.jsxs)(j.Fragment, {
                children: [ Object(j.jsx)(r.a, {
                    backBtn: !0
                }), n && Object(j.jsx)(c.a, {
                    gridList: n,
                    gridPatch: t,
                    gridIndex: a
                }) ]
            });
        }, O = function() {
            return Object(j.jsx)(s.a, {
                className: "posts",
                children: Object(j.jsx)(g, {})
            });
        };
        O.enableShareTimeline = !0, O.enableShareAppMessage = !0, Page(Object(a.createPageConfig)(O, "pages/Posts", {
            root: {
                cn: []
            }
        }, {
            enableShareAppMessage: !0,
            enableShareTimeline: !0
        } || {})), n.default = O;
    }
}, [ [ 172, 0, 1, 2, 3 ] ] ]);