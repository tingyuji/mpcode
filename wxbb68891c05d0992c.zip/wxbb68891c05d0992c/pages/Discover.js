(wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 12 ], {
    100: function(e, c) {
        e.exports = "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjEuMyAxLjMgMjEuNCAyMS40Ij48cGF0aCBkPSJNMjEgMTJIM00zIDEyTDEwIDVNMyAxMkwxMCAxOSIgc3Ryb2tlPSIjMDAwIiBzdHJva2Utd2lkdGg9IjMuMiIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiAvPjwvc3ZnPgo=";
    },
    154: function(e, c, s) {},
    174: function(e, c, s) {
        "use strict";
        s.r(c);
        var a = s(7), t = s(6), n = s(1), i = s(2), j = s(58), l = s.n(j), b = s(82), r = s.n(b), o = s(36), x = s(19), d = s(21), m = s(17), g = s(4), h = s(8), O = s(47), u = s.n(O), I = s(100), p = s.n(I), N = s(53), M = s.n(N), A = (s(154), 
        s(0)), v = Object(m.a)(), w = v.screenWidth, D = v.menu, S = D.width, f = D.height, E = D.top, k = S + 2 * (w - D.right), _ = function() {
            var e = h.a.account, c = Object(n.useState)(function() {
                return g.g.get("IS_ADD_TIP_HIDE");
            }), s = Object(t.a)(c, 2), a = s[0], j = s[1], b = Object(n.useState)(function() {
                return "ACTIVE" !== e.statusText || g.g.get("IS_GUIDE_MASK_HIDE");
            }), d = Object(t.a)(b, 2), m = d[0], O = d[1];
            return Object(A.jsxs)(A.Fragment, {
                children: [ Object(A.jsx)(x.a, {
                    title: Object(A.jsx)(i.i, {
                        className: "logo",
                        children: "FUTAKE"
                    })
                }), Object(A.jsx)(o.a, {
                    apiUrl: "/feed/recommended"
                }), !a && Object(A.jsxs)(i.i, {
                    className: "add-tip",
                    style: {
                        "--height": "".concat(f, "px"),
                        height: f,
                        top: E,
                        right: k
                    },
                    children: [ Object(A.jsx)(i.b, {
                        className: "icon",
                        src: u.a,
                        onClick: function() {
                            j(!0), g.g.set("IS_ADD_TIP_HIDE", !0);
                        }
                    }), Object(A.jsx)(i.g, {
                        children: '"添加到我的小程序"'
                    }), Object(A.jsx)(i.b, {
                        className: "icon",
                        src: M.a
                    }) ]
                }), !m && Object(A.jsxs)(i.i, {
                    className: "guide-mask",
                    catchMove: !0,
                    children: [ Object(A.jsx)(i.i, {
                        className: "mask-icon",
                        children: "👋"
                    }), Object(A.jsxs)(i.i, {
                        className: "title",
                        children: [ Object(A.jsx)(i.i, {
                            children: "欢迎来到"
                        }), Object(A.jsx)(i.i, {
                            className: "logo",
                            children: "FUTAKE"
                        }) ]
                    }), Object(A.jsxs)(i.i, {
                        className: "row-main",
                        children: [ Object(A.jsx)(i.b, {
                            className: "icon",
                            src: l.a
                        }), " 发现新用户" ]
                    }), Object(A.jsxs)(i.i, {
                        className: "row-main",
                        children: [ Object(A.jsx)(i.b, {
                            className: "icon",
                            src: r.a
                        }), " 浏览已关注" ]
                    }), Object(A.jsxs)(i.i, {
                        className: "row-sub",
                        children: [ "作品页 ", Object(A.jsx)(i.b, {
                            className: "icon",
                            src: p.a
                        }), " 滑查看作者" ]
                    }), Object(A.jsxs)(i.i, {
                        className: "row-sub",
                        children: [ "子页面 ", Object(A.jsx)(i.b, {
                            className: "icon",
                            src: M.a
                        }), " 滑直接返回" ]
                    }), Object(A.jsx)(i.a, {
                        className: "btn btn-xl btn-dark btn-know",
                        onClick: function() {
                            O(!0), g.g.set("IS_GUIDE_MASK_HIDE", !0);
                        },
                        children: "我知道啦"
                    }) ]
                }) ]
            });
        }, y = function() {
            return Object(A.jsx)(d.a, {
                className: "discover",
                children: Object(A.jsx)(_, {})
            });
        };
        y.enableShareTimeline = !0, y.enableShareAppMessage = !0, Page(Object(a.createPageConfig)(y, "pages/Discover", {
            root: {
                cn: []
            }
        }, {
            enableShareAppMessage: !0,
            enableShareTimeline: !0
        } || {})), c.default = y;
    },
    82: function(e, c, s) {
        e.exports = s.p + "static/follow.png";
    }
}, [ [ 174, 0, 1, 2, 3 ] ] ]);