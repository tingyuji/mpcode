(wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 26 ], {
    180: function(e, a, t) {
        "use strict";
        t.r(a);
        var s = t(7), c = t(6), r = t(1), n = t(21), i = t(63), p = t(35), b = t(8), o = t(0), u = function(e) {
            var a = e.setStopBack, t = b.a.itsMe, s = Object(p.a)().user_id, c = t(s);
            return Object(o.jsx)(i.a, {
                user_id: s,
                isMe: c,
                setStopBack: a
            });
        }, j = function() {
            var e = Object(r.useState)(!1), a = Object(c.a)(e, 2), t = a[0], s = a[1];
            return Object(o.jsx)(n.a, {
                className: "user",
                stopBack: t,
                children: Object(o.jsx)(u, {
                    setStopBack: s
                })
            });
        };
        j.enableShareTimeline = !0, j.enableShareAppMessage = !0, Page(Object(s.createPageConfig)(j, "pages/User", {
            root: {
                cn: []
            }
        }, {
            enableShareAppMessage: !0,
            enableShareTimeline: !0
        } || {})), a.default = j;
    }
}, [ [ 180, 0, 1, 2, 3 ] ] ]);