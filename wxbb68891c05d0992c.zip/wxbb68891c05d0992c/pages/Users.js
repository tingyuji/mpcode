(wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 28 ], {
    164: function(e, t, n) {},
    166: function(e, t, n) {},
    173: function(e, t, n) {
        "use strict";
        n.r(t);
        var r = n(7), c = n(6), a = n(1), i = n(2), s = n(25), o = n(29), l = n(107), u = n.n(l), j = n(17), b = (n(164), 
        n(0)), f = Object(j.a)().bodyHeight, d = Object(a.memo)(function(e) {
            var t = e.id, n = e.data, r = n[e.index];
            return r ? n.renderItem({
                id: t,
                item: r
            }) : null;
        }), m = Object(a.memo)(function(e) {
            var t = e.list, n = e.itemHeight, r = e.onPatch, c = e.renderItem, s = Object(a.useRef)(!1), o = t.length, l = o * n;
            t.renderItem = c;
            var j = Object(a.useCallback)(function(e) {
                var t = e.scrollDirection, n = e.scrollOffset;
                s.current || "forward" !== t || 0 === n || n > l - f - 100 && (s.current = !0, r().finally(function() {
                    s.current = !1;
                }));
            }, [ l, r ]);
            return Object(b.jsx)(u.a, {
                className: "dynamic-list",
                width: "100%",
                height: f,
                itemData: t,
                itemCount: o,
                itemSize: n,
                onScroll: j,
                renderBottom: Object(b.jsx)(i.i, {
                    className: "footer"
                }),
                item: d
            });
        }), O = n(18), h = n(19), g = n(21), p = n(12), x = n(60), _ = n(22), v = n(32), w = n(35), M = n(33), N = n(11), k = n(8), y = 64 * (n(73), 
        n(166), Object(j.a)()).screenScale, U = Object(a.memo)(function(e) {
            var t = e.user_id, n = e.is_following, r = e.is_follower, c = e.followUser, a = function(e, n) {
                e.stopPropagation(), c({
                    user_id: t,
                    toFollow: n
                });
            };
            return n ? Object(b.jsx)(i.a, {
                className: "right btn btn-sm btn-air",
                onClick: function(e) {
                    return a(e, !1);
                },
                children: r ? "互相关注" : "已关注"
            }) : Object(b.jsx)(i.a, {
                className: "right btn btn-sm btn-blue",
                onClick: function(e) {
                    return a(e, !0);
                },
                children: r ? "回关" : "关注"
            });
        }), S = Object(a.memo)(function(e) {
            var t = e.id, n = e.user_id, r = e.itsMe, c = e.followUser, a = k.a.userMap[n] || {}, o = a.avatar_url, l = a.nickname, u = a.signature, j = a.is_following, f = a.is_follower;
            return Object(b.jsxs)(i.i, {
                className: "cell cell-body",
                id: t,
                onClick: function() {
                    return Object(_.a)("User?user_id=".concat(n));
                },
                children: [ Object(b.jsx)(s.a, {
                    img: o
                }), Object(b.jsxs)(i.i, {
                    className: "middle",
                    children: [ Object(b.jsx)(i.i, {
                        className: "name",
                        children: l
                    }), Object(b.jsx)(i.i, {
                        className: "content tip",
                        children: u
                    }) ]
                }), n && !r(n) && Object(b.jsx)(U, {
                    user_id: n,
                    is_following: j,
                    is_follower: f,
                    followUser: c
                }) ]
            });
        }), C = Object(a.memo)(function(e) {
            var t = e.userId, n = e.count, r = e.listMeta, a = e.itsMe, i = Object(v.a)(), s = Object(c.a)(r, 2), l = s[0], u = s[1], j = Object(N.a)(l, {
                params: {
                    user_id: t,
                    count: 15
                },
                loadMore: !0,
                initialData: {
                    list: []
                },
                onSuccess: function(e) {
                    var r = e.list, c = e.total;
                    Object(p.d)("userMap", "user_id", r), "number" == typeof c && +n !== c && Object(p.f)("userMap", t, function(e) {
                        return e[u] = c;
                    });
                }
            }), f = j.onceLoading, d = j.patchLoading, h = j.data, g = j.run, x = j.patch;
            return Object(b.jsxs)(b.Fragment, {
                children: [ f && Object(b.jsx)(O.a, {}), Object(b.jsxs)(o.a, {
                    onPullDown: g,
                    children: [ Object(b.jsx)(m, {
                        list: h.list,
                        itemHeight: y,
                        onPatch: x,
                        renderItem: function(e) {
                            var t = e.id, n = e.item;
                            return Object(b.jsx)(S, {
                                id: t,
                                user_id: n.user_id,
                                itsMe: a,
                                followUser: i
                            });
                        }
                    }), d && Object(b.jsx)(O.a, {
                        ring: !0
                    }) ]
                }) ]
            });
        }), I = function() {
            var e = k.a.itsMe, t = Object(w.a)(), n = t.user_id, r = t.nickname, c = t.avatar_url, i = t.type, s = t.count, o = "".concat(Object(x.a)(r), "的").concat(i);
            Object(M.a)(function() {
                return {
                    title: "".concat(o, "列表 · FUTAKE"),
                    path: "/pages/Users?user_id=".concat(n, "&nickname=").concat(r, "&avatar_url=").concat(c, "&type=").concat(i, "&count=").concat(s),
                    imageUrl: c
                };
            });
            var l = Object(a.useMemo)(function() {
                return {
                    "关注": [ "/friend/follow", "following_count" ],
                    "粉丝": [ "/friend/fans", "follower_count" ]
                }[i];
            }, [ i ]);
            return Object(b.jsxs)(b.Fragment, {
                children: [ Object(b.jsx)(h.a, {
                    backBtn: !0,
                    title: o
                }), Object(b.jsx)(C, {
                    userId: n,
                    count: s,
                    listMeta: l,
                    itsMe: e
                }) ]
            });
        }, P = function() {
            return Object(b.jsx)(g.a, {
                className: "users",
                children: Object(b.jsx)(I, {})
            });
        };
        P.enableShareTimeline = !0, P.enableShareAppMessage = !0, Page(Object(r.createPageConfig)(P, "pages/Users", {
            root: {
                cn: []
            }
        }, {
            enableShareAppMessage: !0,
            enableShareTimeline: !0
        } || {})), t.default = P;
    },
    54: function(e, t, n) {
        "use strict";
        n.d(t, "a", function() {
            return i;
        });
        var r = Number.isNaN || function(e) {
            return "number" == typeof e && e != e;
        };
        function c(e, t) {
            return e === t || !(!r(e) || !r(t));
        }
        function a(e, t) {
            if (e.length !== t.length) return !1;
            for (var n = 0; n < e.length; n++) if (!c(e[n], t[n])) return !1;
            return !0;
        }
        function i(e, t) {
            void 0 === t && (t = a);
            var n = null;
            function r() {
                for (var r = [], c = 0; c < arguments.length; c++) r[c] = arguments[c];
                if (n && n.lastThis === this && t(r, n.lastArgs)) return n.lastResult;
                var a = e.apply(this, r);
                return n = {
                    lastResult: a,
                    lastArgs: r,
                    lastThis: this
                }, a;
            }
            return r.clear = function() {
                n = null;
            }, r;
        }
    }
}, [ [ 173, 0, 1, 2, 3 ] ] ]);