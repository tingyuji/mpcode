(wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 18 ], {
    101: function(e, t) {
        e.exports = "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjIgMi4yIDIwIDIwIiBmaWxsPSJub25lIj48cGF0aCBkPSJNMyA1VjIwLjc5MjlDMyAyMS4yMzgzIDMuNTM4NTcgMjEuNDYxNCAzLjg1MzU1IDIxLjE0NjRMNy43MDcxMSAxNy4yOTI5QzcuODk0NjQgMTcuMTA1NCA4LjE0OSAxNyA4LjQxNDIxIDE3SDE5QzIwLjEwNDYgMTcgMjEgMTYuMTA0NiAyMSAxNVY1QzIxIDMuODk1NDMgMjAuMTA0NiAzIDE5IDNINUMzLjg5NTQzIDMgMyAzLjg5NTQzIDMgNVoiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIxLjUiIC8+PHBhdGggZD0iTTE1IDEyQzE0LjIwMDUgMTIuNjIyNCAxMy4xNTAyIDEzIDEyIDEzQzEwLjg0OTggMTMgOS43OTk1MiAxMi42MjI0IDkgMTIiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIxLjUiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgLz48cGF0aCBkPSJNOSA4LjAxOTUzVjgiIHN0cm9rZT0iIzAwMCIgc3Ryb2tlLXdpZHRoPSIxLjUiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgLz48cGF0aCBkPSJNMTUgOC4wMTk1M1Y4IiBzdHJva2U9IiMwMDAiIHN0cm9rZS13aWR0aD0iMS41IiBzdHJva2UtbGluZWNhcD0icm91bmQiIC8+PC9zdmc+Cg==";
    },
    156: function(e, t, c) {},
    176: function(e, t, c) {
        "use strict";
        c.r(t);
        var n = c(7), i = c(10), a = c(13), s = c(30), r = c(6), o = c(1), l = c(2), j = c(5), u = c(25), b = c(29), d = c(37), O = c(18), m = c(19), f = c(21), x = c(38), N = c(12), y = c(40), g = c(22), p = c(32), M = c(15), I = c(4), h = c(11), w = c(8), T = c(101), C = c.n(T), D = (c(73), 
        c(156), c(0)), L = [ {
            text: "删除",
            type: "warn"
        } ], _ = {
            0: "REMIND",
            1: "ANNOUNCE"
        }, v = {
            0: "COMMENT",
            1: "REPLY",
            2: "LIKE",
            6: "FOLLOW"
        }, E = {
            0: "POST",
            1: "COMMENT",
            2: "REPLY"
        }, S = [ "COMMENT", "REPLY", "LIKE" ], k = Object(o.memo)(function(e) {
            var t = e.user_follow, c = e.followUser, n = w.a.userMap, i = t.user_id, a = (n[i] || t).is_following;
            Object(o.useEffect)(function() {
                n[i] || Object(N.c)("userMap", i, t);
            }, [ n, t, i ]);
            var s = function(e, t) {
                e.stopPropagation(), c({
                    user_id: i,
                    toFollow: t
                });
            };
            return a ? Object(D.jsx)(l.a, {
                className: "right btn btn-sm btn-air btn-follow",
                onClick: function(e) {
                    return s(e, !1);
                },
                children: "已关注"
            }) : Object(D.jsx)(l.a, {
                className: "right btn btn-sm btn-follow btn-blue",
                onClick: function(e) {
                    return s(e, !0);
                },
                children: "关注"
            });
        }), A = Object(o.memo)(function(e) {
            var t = e.notify, c = e.followUser, n = t.action_type, i = t.target_type, a = t.from_user, s = t.post, r = t.comment, j = t.reply, b = t.user_follow, O = t.created_at, m = v[n], f = function(e) {
                var t = e.actionType, c = e.likeType, n = e.comment, i = void 0 === n ? {} : n, a = e.reply, s = void 0 === a ? {} : a;
                if (!t) return {};
                switch (t) {
                  case "COMMENT":
                    return i.text ? {
                        remind: i.text,
                        top_id: i.comment_id
                    } : {
                        remind: Object(D.jsx)(l.g, {
                            className: "tip",
                            children: "评论已删除"
                        })
                    };

                  case "REPLY":
                    return s.text ? {
                        remind: Object(D.jsxs)(D.Fragment, {
                            children: [ Object(D.jsx)(l.g, {
                                className: "tip",
                                children: "回复："
                            }), s.text ]
                        }),
                        top_id: s.reply_id
                    } : {
                        remind: Object(D.jsx)(l.g, {
                            className: "tip",
                            children: "回复已删除"
                        })
                    };

                  case "LIKE":
                    var r, o;
                    switch (c) {
                      case "POST":
                        r = "作品";
                        break;

                      case "COMMENT":
                        r = "评论：".concat(i.text), o = i.comment_id;
                        break;

                      case "REPLY":
                        r = "回复：".concat(s.text), o = s.reply_id;
                        break;

                      default:
                        r = c;
                    }
                    return {
                        remind: Object(D.jsxs)(l.g, {
                            className: "tip",
                            children: [ "喜欢了你的", r ]
                        }),
                        top_id: o
                    };

                  case "FOLLOW":
                    return {
                        remind: Object(D.jsx)(l.g, {
                            className: "tip",
                            children: "关注了你"
                        })
                    };
                }
            }({
                actionType: m,
                likeType: E[i],
                comment: r,
                reply: j
            }), N = f.remind, p = f.top_id, M = a || {}, I = "User?user_id=".concat(M.user_id), h = function() {
                return Object(g.a)(I);
            }, w = Object(o.useCallback)(function() {
                var e = p ? "&top_id=".concat(p) : "";
                Object(g.a)("Post?post_id=".concat(s.post_id).concat(e));
            }, [ null == s ? void 0 : s.post_id, p ]);
            return Object(D.jsxs)(l.i, {
                className: "cell-body",
                onClick: function() {
                    return "FOLLOW" === m ? h() : S.includes(m) && s ? w() : void 0;
                },
                children: [ Object(D.jsx)(u.a, {
                    img: M.avatar_url,
                    onClick: h
                }), Object(D.jsxs)(l.i, {
                    className: "middle",
                    children: [ Object(D.jsx)(d.a, {
                        className: "name",
                        to: I,
                        children: M.nickname
                    }), Object(D.jsx)(l.i, {
                        className: "content",
                        children: N
                    }), Object(D.jsx)(l.i, {
                        className: "time",
                        children: Object(y.a)(O)
                    }) ]
                }), "FOLLOW" === m ? Object(D.jsx)(D.Fragment, {
                    children: b && Object(D.jsx)(k, {
                        user_follow: b,
                        followUser: c
                    })
                }) : Object(D.jsx)(D.Fragment, {
                    children: s ? Object(D.jsx)(x.a, {
                        className: "right",
                        img_list: s.img_list,
                        imgSize: 160,
                        text: s.text,
                        onClick: w
                    }) : Object(D.jsx)(D.Fragment, {
                        children: (r || j) && Object(D.jsx)(x.a, {
                            className: "right",
                            status: 6
                        })
                    })
                }) ]
            });
        }), P = Object(o.memo)(function(e) {
            var t = e.notify, c = e.hasSlide, n = e.onShow, i = e.onDel, a = e.followUser, s = t.notify_id, r = t.type, o = t.content, j = t.created_at, b = _[r];
            return Object(D.jsx)(l.i, {
                className: "cell",
                children: Object(D.jsx)("mp-slideview", {
                    buttons: L,
                    show: c,
                    onShow: function() {
                        return n(s);
                    },
                    onButtontap: function() {
                        return i({
                            notify_id: s
                        });
                    },
                    children: "REMIND" === b ? Object(D.jsx)(A, {
                        notify: t,
                        followUser: a
                    }) : Object(D.jsxs)(l.i, {
                        className: "cell-body",
                        children: [ Object(D.jsx)(u.a, {
                            word: "通知"
                        }), Object(D.jsxs)(l.i, {
                            className: "middle",
                            children: [ Object(D.jsx)(l.i, {
                                className: "name",
                                children: "FUTAKE TOAST"
                            }), Object(D.jsx)(l.i, {
                                className: "content tip",
                                children: o
                            }), Object(D.jsx)(l.i, {
                                className: "time",
                                children: Object(y.a)(j)
                            }) ]
                        }) ]
                    })
                })
            });
        }), z = Object(o.memo)(function(e) {
            var t = e.list, c = Object(o.useState)({}), n = Object(r.a)(c, 2), j = n[0], u = n[1], b = Object(o.useCallback)(function(e) {
                return u(Object(s.a)({}, e, !0));
            }, []), d = Object(h.b)("/notify/delete", {
                manual: !0
            }).run, O = Object(o.useCallback)(function() {
                var e = Object(a.a)(Object(i.a)().mark(function e(t) {
                    var c;
                    return Object(i.a)().wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            return c = t.notify_id, e.next = 3, d({
                                notify_id: c
                            });

                          case 3:
                            Object(N.e)(I.d.notifyMutate, "notify_id", c);

                          case 4:
                          case "end":
                            return e.stop();
                        }
                    }, e);
                }));
                return function(t) {
                    return e.apply(this, arguments);
                };
            }(), [ d ]), m = Object(p.a)();
            return t.map(function(e, c) {
                var n, i = e.notify_id, a = e.has_read, s = Object(D.jsx)(P, {
                    notify: e,
                    hasSlide: j[i],
                    onShow: b,
                    onDel: O,
                    followUser: m
                }, i);
                return a !== (null === (n = t[c - 1]) || void 0 === n ? void 0 : n.has_read) ? Object(D.jsxs)(o.Fragment, {
                    children: [ Object(D.jsx)(l.i, {
                        className: "title",
                        children: a ? "".concat(0 === c ? "以往" : "之前") : "新"
                    }), s ]
                }, i) : s;
            });
        }), R = function() {
            var e = w.a.notifyOnceLoading, t = w.a.notifyPatchLoading, c = w.a.notifyData, n = Object(h.b)("/notify/read_all", {
                manual: !0
            }).run, s = Object(o.useCallback)(function() {
                var e = Object(a.a)(Object(i.a)().mark(function e(t) {
                    var c, a;
                    return Object(i.a)().wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            return I.d.notifyCancel(), e.next = 3, I.d.notifyRun(t);

                          case 3:
                            if (c = e.sent, a = c.list, I.d.notifyCancel(), !a[0] || a[0].has_read) {
                                e.next = 10;
                                break;
                            }
                            return e.next = 9, n();

                          case 9:
                            I.e.notifyCount = 0;

                          case 10:
                          case "end":
                            return e.stop();
                        }
                    }, e);
                }));
                return function(t) {
                    return e.apply(this, arguments);
                };
            }(), [ n ]), r = Object(o.useCallback)(function() {
                return s({
                    forceReset: !0
                });
            }, [ s ]), u = Object(o.useRef)(0);
            return Object(M.a)(Object(o.useCallback)(function(e) {
                var t = I.b.only("RETAP_TAB", function() {
                    Object(j.pageScrollTo)({
                        scrollTop: 0
                    });
                });
                return "appLaunch" !== e && "switchTab" !== e || (clearTimeout(I.e.resumePollingTimer), 
                u.current = Date.now(), s()), function(e) {
                    if (t(), "switchTab" === e) {
                        var c = Date.now() - u.current, n = I.e.pollingDelay - c;
                        n > 0 ? I.e.resumePollingTimer = setTimeout(function() {
                            I.d.notifyRun();
                        }, n) : I.d.notifyRun();
                    }
                };
            }, [ s ])), Object(j.useReachBottom)(I.d.notifyPatch), Object(D.jsxs)(D.Fragment, {
                children: [ Object(D.jsx)(m.a, {
                    title: "消息"
                }), e ? Object(D.jsx)(O.a, {}) : Object(D.jsxs)(b.a, {
                    onPullDown: r,
                    children: [ c.list.length > 0 ? Object(D.jsx)(z, {
                        list: c.list
                    }) : Object(D.jsxs)(l.i, {
                        className: "is-empty",
                        children: [ Object(D.jsx)(l.b, {
                            className: "icon",
                            src: C.a
                        }), Object(D.jsx)(l.i, {
                            children: "还没有新消息"
                        }) ]
                    }), t && Object(D.jsx)(O.a, {
                        ring: !0
                    }) ]
                }) ]
            });
        }, U = function() {
            return Object(D.jsx)(f.a, {
                className: "notify",
                children: Object(D.jsx)(R, {})
            });
        };
        Page(Object(n.createPageConfig)(U, "pages/Notify", {
            root: {
                cn: []
            }
        }, {
            usingComponents: {
                "mp-slideview": "weui-miniprogram/slideview/slideview"
            }
        } || {})), t.default = U;
    }
}, [ [ 176, 0, 1, 2, 3 ] ] ]);