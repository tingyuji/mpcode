(wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 14 ], {
    155: function(e, a, s) {},
    175: function(e, a, s) {
        "use strict";
        s.r(a);
        var c = s(7), n = s(2), t = s(18), r = s(36), i = s(19), l = s(21), b = s(8), j = (s(155), 
        s(0)), o = {
            active: "正在发布",
            success: "已发布 ⚡️"
        }, p = function() {
            var e = b.a.publishStatus;
            return Object(j.jsxs)(j.Fragment, {
                children: [ Object(j.jsx)(i.a, {
                    title: "关注"
                }), Object(j.jsx)(r.a, {
                    apiUrl: "/feed/friend"
                }), "" !== e && Object(j.jsxs)(n.i, {
                    className: "progress-bar ".concat(e),
                    children: [ Object(j.jsx)(n.g, {
                        children: o[e]
                    }), "active" === e && Object(j.jsx)(n.i, {
                        className: "loading-box",
                        children: Object(j.jsx)(t.a, {})
                    }) ]
                }) ]
            });
        }, u = function() {
            return Object(j.jsx)(l.a, {
                className: "follow",
                children: Object(j.jsx)(p, {})
            });
        };
        u.enableShareTimeline = !0, u.enableShareAppMessage = !0, Page(Object(c.createPageConfig)(u, "pages/Follow", {
            root: {
                cn: []
            }
        }, {
            enableShareAppMessage: !0,
            enableShareTimeline: !0
        } || {})), a.default = u;
    }
}, [ [ 175, 0, 1, 2, 3 ] ] ]);