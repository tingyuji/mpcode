(wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 7 ], {
    167: function(t, e, i) {
        "use strict";
        i.r(e);
        var s = i(4);
        Component({
            data: {
                className: "",
                page: "",
                list: [ {
                    text: "发现",
                    page: "Discover",
                    icon: "/static/discover"
                }, {
                    text: "关注",
                    page: "Follow",
                    icon: "/static/follow"
                }, {
                    text: "发布",
                    page: null,
                    icon: "/static/publish"
                }, {
                    text: "消息",
                    page: "Notify",
                    icon: "/static/notify",
                    count: !0
                }, {
                    text: "我",
                    page: "Me",
                    icon: "/static/me"
                } ],
                notifyCount: 0
            },
            methods: {
                onClickTab: function(t) {
                    s.b.emit("CLICK_TAB", t.currentTarget.dataset.page);
                },
                onClickPublish: function() {
                    s.b.emit("CLICK_PUBLISH");
                },
                onPressPublish: function() {
                    this.hasPress = !0, s.b.emit("PRESS_PUBLISH");
                },
                onLeavePublish: function() {
                    this.hasPress && (this.hasPress = !1, s.b.emit("LEAVE_PUBLISH"));
                }
            }
        });
    }
}, [ [ 167, 0, 1, 2, 3 ] ] ]);