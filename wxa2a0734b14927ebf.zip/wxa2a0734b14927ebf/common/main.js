(global.webpackJsonp = global.webpackJsonp || []).push([ [ "common/main" ], {
    0: function(t, e, n) {
        "use strict";
        (function(t, e, o) {
            var r = n(4), i = n(13), u = r(n(11));
            n(26);
            var a = r(n(27)), c = r(n(34)), f = r(n(159)), p = r(n(163)), l = r(n(160)), s = r(n(164)), d = j(n(165)), O = j(n(166)), y = j(n(168)), b = j(n(167)), m = r(n(169)), g = j(n(170)), v = r(n(25));
            function h(t) {
                if ("function" != typeof WeakMap) return null;
                var e = new WeakMap(), n = new WeakMap();
                return (h = function(t) {
                    return t ? n : e;
                })(t);
            }
            function j(t, e) {
                if (!e && t && t.__esModule) return t;
                if (null === t || "object" !== i(t) && "function" != typeof t) return {
                    default: t
                };
                var n = h(e);
                if (n && n.has(t)) return n.get(t);
                var o = {}, r = Object.defineProperty && Object.getOwnPropertyDescriptor;
                for (var u in t) if ("default" !== u && Object.prototype.hasOwnProperty.call(t, u)) {
                    var a = r ? Object.getOwnPropertyDescriptor(t, u) : null;
                    a && (a.get || a.set) ? Object.defineProperty(o, u, a) : o[u] = t[u];
                }
                return o.default = t, n && n.set(t, o), o;
            }
            function E(t, e) {
                var n = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(t);
                    e && (o = o.filter(function(e) {
                        return Object.getOwnPropertyDescriptor(t, e).enumerable;
                    })), n.push.apply(n, o);
                }
                return n;
            }
            n(171), t.__webpack_require_UNI_MP_PLUGIN__ = n, v.default.use(c.default), v.default.config.productionTip = !1, 
            v.default.prototype.tim = f.default.tim, v.default.prototype.$TIM = l.default, v.default.prototype.$store = s.default, 
            v.default.prototype.$commen = p.default, v.default.mixin(m.default), v.default.prototype.$config = d, 
            v.default.prototype.$common = O, v.default.prototype.$db = y, v.default.prototype.$api = b, 
            Object.keys(g).forEach(function(t) {
                v.default.filter(t, g[t]);
            }), O.isLogin(), O.getConfig(), v.default.prototype.$go = function(t) {
                console.log("跳转到", t), e.navigateTo({
                    url: t
                });
            }, v.default.prototype.$to = function(t) {
                console.log("跳转到", t), e.reLaunch({
                    url: t
                });
            }, v.default.config.productionTip = !1, a.default.mpType = "app", o(new v.default(function(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var n = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? E(Object(n), !0).forEach(function(e) {
                        (0, u.default)(t, e, n[e]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : E(Object(n)).forEach(function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e));
                    });
                }
                return t;
            }({}, a.default))).$mount();
        }).call(this, n(1).default, n(2).default, n(2).createApp);
    },
    27: function(t, e, n) {
        "use strict";
        n.r(e);
        var o = n(28);
        for (var r in o) [ "default" ].indexOf(r) < 0 && function(t) {
            n.d(e, t, function() {
                return o[t];
            });
        }(r);
        n(31);
        var i = n(33), u = Object(i.default)(o.default, void 0, void 0, !1, null, null, null, !1, void 0, void 0);
        u.options.__file = "App.vue", e.default = u.exports;
    },
    28: function(t, e, n) {
        "use strict";
        n.r(e);
        var o = n(29), r = n.n(o);
        for (var i in o) [ "default" ].indexOf(i) < 0 && function(t) {
            n.d(e, t, function() {
                return o[t];
            });
        }(i);
        e.default = r.a;
    },
    29: function(t, e, n) {
        "use strict";
        var o = n(4);
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var r = o(n(11));
        function i(t, e) {
            var n = Object.keys(t);
            if (Object.getOwnPropertySymbols) {
                var o = Object.getOwnPropertySymbols(t);
                e && (o = o.filter(function(e) {
                    return Object.getOwnPropertyDescriptor(t, e).enumerable;
                })), n.push.apply(n, o);
            }
            return n;
        }
        var u = {
            data: function() {
                return {
                    data: null
                };
            },
            mounted: function() {
                var t = this;
                this.tim.on(this.$TIM.EVENT.SDK_READY, this.onReadyStateUpdate, this), this.tim.on(this.$TIM.EVENT.MESSAGE_RECEIVED, this.onReceiveMessage), 
                this.tim.on(this.$TIM.EVENT.CONVERSATION_LIST_UPDATED, function(e) {
                    t.$store.commit("updateConversationList", e.data);
                }), this.tim.on(this.$TIM.EVENT.FRIEND_LIST_UPDATED, function(e) {
                    t.$store.commit("updateFriendList", e.data);
                });
            },
            computed: function(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var n = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? i(Object(n), !0).forEach(function(e) {
                        (0, r.default)(t, e, n[e]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : i(Object(n)).forEach(function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e));
                    });
                }
                return t;
            }({}, (0, n(30).mapState)({
                isLogin: function(t) {
                    return t.isLogin;
                },
                isSDKReady: function(t) {
                    return t.isSDKReady;
                }
            })),
            methods: {
                onReadyStateUpdate: function(t) {
                    var e = t.name === this.$TIM.EVENT.SDK_READY;
                    this.$store.commit("toggleIsSDKReady", e);
                },
                onReceiveMessage: function(t) {
                    var e = t.data;
                    this.$store.commit("pushCurrentMessageList", e), this.imNum = this.tim.getTotalUnreadMessageCount();
                }
            },
            onLaunch: function() {
                console.log("App Launch");
            },
            onShow: function() {
                console.log("App Show");
            },
            onHide: function() {
                console.log("App Hide");
            }
        };
        e.default = u;
    },
    31: function(t, e, n) {
        "use strict";
        n.r(e);
        var o = n(32), r = n.n(o);
        for (var i in o) [ "default" ].indexOf(i) < 0 && function(t) {
            n.d(e, t, function() {
                return o[t];
            });
        }(i);
        e.default = r.a;
    },
    32: function(t, e, n) {}
}, [ [ 0, "common/runtime", "common/vendor" ] ] ]);