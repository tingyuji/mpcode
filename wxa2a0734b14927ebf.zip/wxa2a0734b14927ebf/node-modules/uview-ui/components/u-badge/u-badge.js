(global.webpackJsonp = global.webpackJsonp || []).push([ [ "node-modules/uview-ui/components/u-badge/u-badge" ], {
    1094: function(e, t, n) {
        "use strict";
        n.r(t);
        var u = n(1095), o = n(1097);
        for (var r in o) [ "default" ].indexOf(r) < 0 && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(r);
        n(1100);
        var i = n(33), a = Object(i.default)(o.default, u.render, u.staticRenderFns, !1, null, "662d25bf", null, !1, u.components, void 0);
        a.options.__file = "node_modules/uview-ui/components/u-badge/u-badge.vue", t.default = a.exports;
    },
    1095: function(e, t, n) {
        "use strict";
        n.r(t);
        var u = n(1096);
        n.d(t, "render", function() {
            return u.render;
        }), n.d(t, "staticRenderFns", function() {
            return u.staticRenderFns;
        }), n.d(t, "recyclableRender", function() {
            return u.recyclableRender;
        }), n.d(t, "components", function() {
            return u.components;
        });
    },
    1096: function(e, t, n) {
        "use strict";
        n.r(t), n.d(t, "render", function() {
            return u;
        }), n.d(t, "staticRenderFns", function() {
            return r;
        }), n.d(t, "recyclableRender", function() {
            return o;
        }), n.d(t, "components", function() {});
        var u = function() {
            var e = this, t = (e.$createElement, e._self._c, e.show && (0 !== Number(e.value) || e.showZero || e.isDot)), n = t ? e.__get_style([ e.$u.addStyle(e.customStyle), e.badgeStyle ]) : null;
            e.$mp.data = Object.assign({}, {
                $root: {
                    m0: t,
                    s0: n
                }
            });
        }, o = !1, r = [];
        u._withStripped = !0;
    },
    1097: function(e, t, n) {
        "use strict";
        n.r(t);
        var u = n(1098), o = n.n(u);
        for (var r in u) [ "default" ].indexOf(r) < 0 && function(e) {
            n.d(t, e, function() {
                return u[e];
            });
        }(r);
        t.default = o.a;
    },
    1098: function(e, t, n) {
        "use strict";
        (function(e) {
            var u = n(4);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var o = u(n(1099)), r = {
                name: "u-badge",
                mixins: [ e.$u.mpMixin, o.default, e.$u.mixin ],
                computed: {
                    boxStyle: function() {
                        return {};
                    },
                    badgeStyle: function() {
                        var t = {};
                        if (this.color && (t.color = this.color), this.bgColor && !this.inverted && (t.backgroundColor = this.bgColor), 
                        this.absolute && (t.position = "absolute", this.offset.length)) {
                            var n = this.offset[0], u = this.offset[1] || n;
                            t.top = e.$u.addUnit(n), t.right = e.$u.addUnit(u);
                        }
                        return t;
                    },
                    showValue: function() {
                        switch (this.numberType) {
                          case "overflow":
                            return Number(this.value) > Number(this.max) ? this.max + "+" : this.value;

                          case "ellipsis":
                            return Number(this.value) > Number(this.max) ? "..." : this.value;

                          case "limit":
                            return Number(this.value) > 999 ? Number(this.value) >= 9999 ? Math.floor(this.value / 1e4 * 100) / 100 + "w" : Math.floor(this.value / 1e3 * 100) / 100 + "k" : this.value;

                          default:
                            return Number(this.value);
                        }
                    }
                }
            };
            t.default = r;
        }).call(this, n(2).default);
    },
    1100: function(e, t, n) {
        "use strict";
        n.r(t);
        var u = n(1101), o = n.n(u);
        for (var r in u) [ "default" ].indexOf(r) < 0 && function(e) {
            n.d(t, e, function() {
                return u[e];
            });
        }(r);
        t.default = o.a;
    },
    1101: function(e, t, n) {}
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "node-modules/uview-ui/components/u-badge/u-badge-create-component", {
    "node-modules/uview-ui/components/u-badge/u-badge-create-component": function(e, t, n) {
        n("2").createComponent(n(1094));
    }
}, [ [ "node-modules/uview-ui/components/u-badge/u-badge-create-component" ] ] ]);