(global.webpackJsonp = global.webpackJsonp || []).push([ [ "node-modules/uview-ui/components/u-status-bar/u-status-bar" ], {
    1078: function(t, e, n) {
        "use strict";
        n.r(e);
        var u = n(1079), r = n(1081);
        for (var o in r) [ "default" ].indexOf(o) < 0 && function(t) {
            n.d(e, t, function() {
                return r[t];
            });
        }(o);
        n(1084);
        var s = n(33), a = Object(s.default)(r.default, u.render, u.staticRenderFns, !1, null, "3c8c2ae7", null, !1, u.components, void 0);
        a.options.__file = "node_modules/uview-ui/components/u-status-bar/u-status-bar.vue", 
        e.default = a.exports;
    },
    1079: function(t, e, n) {
        "use strict";
        n.r(e);
        var u = n(1080);
        n.d(e, "render", function() {
            return u.render;
        }), n.d(e, "staticRenderFns", function() {
            return u.staticRenderFns;
        }), n.d(e, "recyclableRender", function() {
            return u.recyclableRender;
        }), n.d(e, "components", function() {
            return u.components;
        });
    },
    1080: function(t, e, n) {
        "use strict";
        n.r(e), n.d(e, "render", function() {
            return u;
        }), n.d(e, "staticRenderFns", function() {
            return o;
        }), n.d(e, "recyclableRender", function() {
            return r;
        }), n.d(e, "components", function() {});
        var u = function() {
            this.$createElement;
            var t = (this._self._c, this.__get_style([ this.style ]));
            this.$mp.data = Object.assign({}, {
                $root: {
                    s0: t
                }
            });
        }, r = !1, o = [];
        u._withStripped = !0;
    },
    1081: function(t, e, n) {
        "use strict";
        n.r(e);
        var u = n(1082), r = n.n(u);
        for (var o in u) [ "default" ].indexOf(o) < 0 && function(t) {
            n.d(e, t, function() {
                return u[t];
            });
        }(o);
        e.default = r.a;
    },
    1082: function(t, e, n) {
        "use strict";
        (function(t) {
            var u = n(4);
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var r = u(n(1083)), o = {
                name: "u-status-bar",
                mixins: [ t.$u.mpMixin, t.$u.mixin, r.default ],
                data: function() {
                    return {};
                },
                computed: {
                    style: function() {
                        var e = {};
                        return e.height = t.$u.addUnit(t.$u.sys().statusBarHeight, "px"), e.backgroundColor = this.bgColor, 
                        t.$u.deepMerge(e, t.$u.addStyle(this.customStyle));
                    }
                }
            };
            e.default = o;
        }).call(this, n(2).default);
    },
    1084: function(t, e, n) {
        "use strict";
        n.r(e);
        var u = n(1085), r = n.n(u);
        for (var o in u) [ "default" ].indexOf(o) < 0 && function(t) {
            n.d(e, t, function() {
                return u[t];
            });
        }(o);
        e.default = r.a;
    },
    1085: function(t, e, n) {}
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "node-modules/uview-ui/components/u-status-bar/u-status-bar-create-component", {
    "node-modules/uview-ui/components/u-status-bar/u-status-bar-create-component": function(t, e, n) {
        n("2").createComponent(n(1078));
    }
}, [ [ "node-modules/uview-ui/components/u-status-bar/u-status-bar-create-component" ] ] ]);