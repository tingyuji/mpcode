(global.webpackJsonp = global.webpackJsonp || []).push([ [ "node-modules/uview-ui/components/u-text/u-text" ], {
    1123: function(e, n, t) {
        "use strict";
        t.r(n);
        var o = t(1124), i = t(1126);
        for (var u in i) [ "default" ].indexOf(u) < 0 && function(e) {
            t.d(n, e, function() {
                return i[e];
            });
        }(u);
        t(1129);
        var r = t(33), l = Object(r.default)(i.default, o.render, o.staticRenderFns, !1, null, "15831087", null, !1, o.components, void 0);
        l.options.__file = "node_modules/uview-ui/components/u-text/u-text.vue", n.default = l.exports;
    },
    1124: function(e, n, t) {
        "use strict";
        t.r(n);
        var o = t(1125);
        t.d(n, "render", function() {
            return o.render;
        }), t.d(n, "staticRenderFns", function() {
            return o.staticRenderFns;
        }), t.d(n, "recyclableRender", function() {
            return o.recyclableRender;
        }), t.d(n, "components", function() {
            return o.components;
        });
    },
    1125: function(e, n, t) {
        "use strict";
        var o;
        t.r(n), t.d(n, "render", function() {
            return i;
        }), t.d(n, "staticRenderFns", function() {
            return r;
        }), t.d(n, "recyclableRender", function() {
            return u;
        }), t.d(n, "components", function() {
            return o;
        });
        try {
            o = {
                uIcon: function() {
                    return Promise.all([ t.e("common/vendor"), t.e("node-modules/uview-ui/components/u-icon/u-icon") ]).then(t.bind(null, 927));
                },
                uLink: function() {
                    return Promise.all([ t.e("common/vendor"), t.e("node-modules/uview-ui/components/u-link/u-link") ]).then(t.bind(null, 1131));
                }
            };
        } catch (e) {
            if (-1 === e.message.indexOf("Cannot find module") || -1 === e.message.indexOf(".vue")) throw e;
            console.error(e.message), console.error("1. 排查组件名称拼写是否正确"), console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"), 
            console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件");
        }
        var i = function() {
            var e = this, n = (e.$createElement, e._self._c, e.show && "price" === e.mode ? e.__get_style([ e.valueStyle ]) : null), t = e.show && e.prefixIcon ? e.$u.addStyle(e.iconStyle) : null, o = e.show && "link" !== e.mode && e.openType && e.isMp ? e.__get_style([ e.valueStyle ]) : null, i = !e.show || "link" === e.mode || e.openType && e.isMp ? null : e.__get_style([ e.valueStyle ]), u = e.show && e.suffixIcon ? e.$u.addStyle(e.iconStyle) : null;
            e.$mp.data = Object.assign({}, {
                $root: {
                    s0: n,
                    g0: t,
                    s1: o,
                    s2: i,
                    g1: u
                }
            });
        }, u = !1, r = [];
        i._withStripped = !0;
    },
    1126: function(e, n, t) {
        "use strict";
        t.r(n);
        var o = t(1127), i = t.n(o);
        for (var u in o) [ "default" ].indexOf(u) < 0 && function(e) {
            t.d(n, e, function() {
                return o[e];
            });
        }(u);
        n.default = i.a;
    },
    1127: function(e, n, t) {
        "use strict";
        (function(e) {
            var o = t(4);
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var i = o(t(1128)), u = o(t(1012)), r = o(t(1013)), l = o(t(1115)), s = {
                name: "u--text",
                mixins: [ e.$u.mpMixin, e.$u.mixin, i.default, u.default, r.default, l.default ],
                computed: {
                    valueStyle: function() {
                        var n = {
                            textDecoration: this.decoration,
                            fontWeight: this.bold ? "bold" : "normal",
                            wordWrap: this.wordWrap,
                            fontSize: e.$u.addUnit(this.size)
                        };
                        return !this.type && (n.color = this.color), this.isNvue && this.lines && (n.lines = this.lines), 
                        this.lineHeight && (n.lineHeight = e.$u.addUnit(this.lineHeight)), !this.isNvue && this.block && (n.display = "block"), 
                        e.$u.deepMerge(n, e.$u.addStyle(this.customStyle));
                    },
                    isNvue: function() {
                        return !1;
                    },
                    isMp: function() {
                        return !0;
                    }
                },
                data: function() {
                    return {};
                },
                methods: {
                    clickHandler: function() {
                        this.call && "phone" === this.mode && e.makePhoneCall({
                            phoneNumber: this.text
                        }), this.$emit("click");
                    }
                }
            };
            n.default = s;
        }).call(this, t(2).default);
    },
    1129: function(e, n, t) {
        "use strict";
        t.r(n);
        var o = t(1130), i = t.n(o);
        for (var u in o) [ "default" ].indexOf(u) < 0 && function(e) {
            t.d(n, e, function() {
                return o[e];
            });
        }(u);
        n.default = i.a;
    },
    1130: function(e, n, t) {}
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "node-modules/uview-ui/components/u-text/u-text-create-component", {
    "node-modules/uview-ui/components/u-text/u-text-create-component": function(e, n, t) {
        t("2").createComponent(t(1123));
    }
}, [ [ "node-modules/uview-ui/components/u-text/u-text-create-component" ] ] ]);