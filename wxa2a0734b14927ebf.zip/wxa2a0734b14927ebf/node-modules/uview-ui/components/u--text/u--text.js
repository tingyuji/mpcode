(global.webpackJsonp = global.webpackJsonp || []).push([ [ "node-modules/uview-ui/components/u--text/u--text" ], {
    1110: function(e, n, t) {
        "use strict";
        t.r(n);
        var u = t(1111), o = t(1113);
        for (var r in o) [ "default" ].indexOf(r) < 0 && function(e) {
            t.d(n, e, function() {
                return o[e];
            });
        }(r);
        var c = t(33), i = Object(c.default)(o.default, u.render, u.staticRenderFns, !1, null, null, null, !1, u.components, void 0);
        i.options.__file = "node_modules/uview-ui/components/u--text/u--text.vue", n.default = i.exports;
    },
    1111: function(e, n, t) {
        "use strict";
        t.r(n);
        var u = t(1112);
        t.d(n, "render", function() {
            return u.render;
        }), t.d(n, "staticRenderFns", function() {
            return u.staticRenderFns;
        }), t.d(n, "recyclableRender", function() {
            return u.recyclableRender;
        }), t.d(n, "components", function() {
            return u.components;
        });
    },
    1112: function(e, n, t) {
        "use strict";
        t.r(n), t.d(n, "render", function() {
            return u;
        }), t.d(n, "staticRenderFns", function() {
            return r;
        }), t.d(n, "recyclableRender", function() {
            return o;
        }), t.d(n, "components", function() {});
        var u = function() {
            this.$createElement;
            this._self._c;
        }, o = !1, r = [];
        u._withStripped = !0;
    },
    1113: function(e, n, t) {
        "use strict";
        t.r(n);
        var u = t(1114), o = t.n(u);
        for (var r in u) [ "default" ].indexOf(r) < 0 && function(e) {
            t.d(n, e, function() {
                return u[e];
            });
        }(r);
        n.default = o.a;
    },
    1114: function(e, n, t) {
        "use strict";
        (function(e) {
            var u = t(4);
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var o = u(t(1115)), r = {
                name: "u--text",
                mixins: [ e.$u.mpMixin, o.default, e.$u.mixin ],
                components: {
                    uvText: function() {
                        Promise.all([ t.e("common/vendor"), t.e("node-modules/uview-ui/components/u-text/u-text") ]).then(function() {
                            return resolve(t(1123));
                        }.bind(null, t)).catch(t.oe);
                    }
                }
            };
            n.default = r;
        }).call(this, t(2).default);
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "node-modules/uview-ui/components/u--text/u--text-create-component", {
    "node-modules/uview-ui/components/u--text/u--text-create-component": function(e, n, t) {
        t("2").createComponent(t(1110));
    }
}, [ [ "node-modules/uview-ui/components/u--text/u--text-create-component" ] ] ]);