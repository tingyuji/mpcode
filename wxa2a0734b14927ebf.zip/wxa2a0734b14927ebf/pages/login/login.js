(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/login/login" ], {
    596: function(e, n, t) {
        "use strict";
        (function(e, n) {
            var i = t(4);
            t(26), i(t(25));
            var o = i(t(597));
            e.__webpack_require_UNI_MP_PLUGIN__ = t, n(o.default);
        }).call(this, t(1).default, t(2).createPage);
    },
    597: function(e, n, t) {
        "use strict";
        t.r(n);
        var i = t(598), o = t(600);
        for (var r in o) [ "default" ].indexOf(r) < 0 && function(e) {
            t.d(n, e, function() {
                return o[e];
            });
        }(r);
        t(602);
        var s = t(33), a = Object(s.default)(o.default, i.render, i.staticRenderFns, !1, null, null, null, !1, i.components, void 0);
        a.options.__file = "pages/login/login.vue", n.default = a.exports;
    },
    598: function(e, n, t) {
        "use strict";
        t.r(n);
        var i = t(599);
        t.d(n, "render", function() {
            return i.render;
        }), t.d(n, "staticRenderFns", function() {
            return i.staticRenderFns;
        }), t.d(n, "recyclableRender", function() {
            return i.recyclableRender;
        }), t.d(n, "components", function() {
            return i.components;
        });
    },
    599: function(e, n, t) {
        "use strict";
        t.r(n), t.d(n, "render", function() {
            return i;
        }), t.d(n, "staticRenderFns", function() {
            return r;
        }), t.d(n, "recyclableRender", function() {
            return o;
        }), t.d(n, "components", function() {});
        var i = function() {
            var e = this, n = (e.$createElement, e._self._c, 0 == e.show ? e._f("formatImgUrl")("/images/bbg.png") : null), t = 0 == e.show ? e._f("formatImgUrl")("/images/logo.png") : null, i = e.show ? e._f("formatImgUrl")("/images/bbg.png") : null, o = e.show ? e._f("formatImgUrl")("/images/logo.png") : null;
            e._isMounted || (e.e0 = function(n) {
                e.isRead = 2 == e.isRead ? 0 : 2;
            }, e.e1 = function(n) {
                e.show = !1;
            }), e.$mp.data = Object.assign({}, {
                $root: {
                    f0: n,
                    f1: t,
                    f2: i,
                    f3: o
                }
            });
        }, o = !1, r = [];
        i._withStripped = !0;
    },
    600: function(e, n, t) {
        "use strict";
        t.r(n);
        var i = t(601), o = t.n(i);
        for (var r in i) [ "default" ].indexOf(r) < 0 && function(e) {
            t.d(n, e, function() {
                return i[e];
            });
        }(r);
        n.default = o.a;
    },
    601: function(e, n, t) {
        "use strict";
        (function(e) {
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var t = {
                data: function() {
                    return {
                        isRead: !1,
                        show: !1
                    };
                },
                onLoad: function() {
                    console.log(this.$config.default.Url);
                },
                methods: {
                    goToxie: function() {
                        e.navigateTo({
                            url: "/pages/webview/webview?url=" + this.$config.default.Url + "/agreement/1000000"
                        });
                    },
                    goToxiea: function() {
                        e.navigateTo({
                            url: "/pages/webview/webview?url=" + this.$config.default.Url + "/agreement/1000001"
                        });
                    },
                    wxlogin: function() {
                        var n = this;
                        if (this.isRead) {
                            e.showLoading({
                                title: "加载中",
                                mask: !0
                            });
                            var t = this;
                            e.login({
                                provider: "weixin",
                                success: function(i) {
                                    console.log("loginRes", i), e.getUserInfo({
                                        provider: "weixin",
                                        success: function(o) {
                                            e.hideLoading(), console.log("infoRes", o), n.$api.default.request("user/wxUserInfo", {
                                                code: i.code,
                                                encryptedData: o.encryptedData,
                                                iv: o.iv
                                            }).then(function(n) {
                                                1 != n.bingd ? n.user.like_content_tags || n.user.like_writer_tags ? e.reLaunch({
                                                    url: "/pages/index/index"
                                                }) : e.reLaunch({
                                                    url: "/pages/login/hobby"
                                                }) : t.show = !0;
                                            });
                                        }
                                    });
                                }
                            });
                        } else this.isReadTip();
                    },
                    decryptPhoneNumber: function(n) {
                        this.isRead ? n.detail.errMsg.includes("getPhoneNumber:fail Error") || this.$api.default.request("user/wxPhoneLogin", n.detail).then(function(n) {
                            n.code && (n.user.like_content_tags || n.user.like_writer_tags ? e.reLaunch({
                                url: "/pages/index/index"
                            }) : e.reLaunch({
                                url: "/pages/login/hobby"
                            }));
                        }) : this.isReadTip();
                    },
                    toLogin: function() {
                        this.isRead ? this.$go("/pages/login/account") : this.isReadTip();
                    },
                    isReadTip: function() {
                        var e = this;
                        if (!this.isRead) return this.$common.errorToShow("请先同意用户协议"), this.isRead = 1, 
                        void setTimeout(function() {
                            e.isRead = 0;
                        }, 300);
                    }
                }
            };
            n.default = t;
        }).call(this, t(2).default);
    },
    602: function(e, n, t) {
        "use strict";
        t.r(n);
        var i = t(603), o = t.n(i);
        for (var r in i) [ "default" ].indexOf(r) < 0 && function(e) {
            t.d(n, e, function() {
                return i[e];
            });
        }(r);
        n.default = o.a;
    },
    603: function(e, n, t) {}
}, [ [ 596, "common/runtime", "common/vendor" ] ] ]);