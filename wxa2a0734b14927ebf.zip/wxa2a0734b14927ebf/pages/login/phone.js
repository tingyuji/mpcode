(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/login/phone" ], {
    604: function(e, n, t) {
        "use strict";
        (function(e, n) {
            var o = t(4);
            t(26), o(t(25));
            var i = o(t(605));
            e.__webpack_require_UNI_MP_PLUGIN__ = t, n(i.default);
        }).call(this, t(1).default, t(2).createPage);
    },
    605: function(e, n, t) {
        "use strict";
        t.r(n);
        var o = t(606), i = t(608);
        for (var u in i) [ "default" ].indexOf(u) < 0 && function(e) {
            t.d(n, e, function() {
                return i[e];
            });
        }(u);
        t(610);
        var r = t(33), s = Object(r.default)(i.default, o.render, o.staticRenderFns, !1, null, null, null, !1, o.components, void 0);
        s.options.__file = "pages/login/phone.vue", n.default = s.exports;
    },
    606: function(e, n, t) {
        "use strict";
        t.r(n);
        var o = t(607);
        t.d(n, "render", function() {
            return o.render;
        }), t.d(n, "staticRenderFns", function() {
            return o.staticRenderFns;
        }), t.d(n, "recyclableRender", function() {
            return o.recyclableRender;
        }), t.d(n, "components", function() {
            return o.components;
        });
    },
    607: function(e, n, t) {
        "use strict";
        var o;
        t.r(n), t.d(n, "render", function() {
            return i;
        }), t.d(n, "staticRenderFns", function() {
            return r;
        }), t.d(n, "recyclableRender", function() {
            return u;
        }), t.d(n, "components", function() {
            return o;
        });
        try {
            o = {
                "u-Input": function() {
                    return Promise.all([ t.e("common/vendor"), t.e("node-modules/uview-ui/components/u--input/u--input") ]).then(t.bind(null, 986));
                },
                uInput: function() {
                    return Promise.all([ t.e("common/vendor"), t.e("node-modules/uview-ui/components/u-input/u-input") ]).then(t.bind(null, 992));
                },
                uCode: function() {
                    return Promise.all([ t.e("common/vendor"), t.e("node-modules/uview-ui/components/u-code/u-code") ]).then(t.bind(null, 999));
                },
                uButton: function() {
                    return Promise.all([ t.e("common/vendor"), t.e("node-modules/uview-ui/components/u-button/u-button") ]).then(t.bind(null, 1007));
                }
            };
        } catch (e) {
            if (-1 === e.message.indexOf("Cannot find module") || -1 === e.message.indexOf(".vue")) throw e;
            console.error(e.message), console.error("1. 排查组件名称拼写是否正确"), console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"), 
            console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件");
        }
        var i = function() {
            var e = this, n = (e.$createElement, e._self._c, e._f("formatImgUrl")("/images/bbg.png")), t = e._f("formatImgUrl")("/images/duo.png");
            e._isMounted || (e.e0 = function(n) {
                e.isRead = 2 == e.isRead ? 0 : 2;
            }), e.$mp.data = Object.assign({}, {
                $root: {
                    f0: n,
                    f1: t
                }
            });
        }, u = !1, r = [];
        i._withStripped = !0;
    },
    608: function(e, n, t) {
        "use strict";
        t.r(n);
        var o = t(609), i = t.n(o);
        for (var u in o) [ "default" ].indexOf(u) < 0 && function(e) {
            t.d(n, e, function() {
                return o[e];
            });
        }(u);
        n.default = i.a;
    },
    609: function(e, n, t) {
        "use strict";
        (function(e) {
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var t = {
                data: function() {
                    return {
                        isRead: !1,
                        tips: "获取验证码",
                        code: "",
                        mobile: ""
                    };
                },
                onLoad: function() {},
                methods: {
                    ht: function() {
                        e.navigateBack({
                            delta: 1
                        });
                    },
                    goToxie: function() {
                        e.navigateTo({
                            url: "/pages/webview/webview?url=" + this.$config.default.Url + "/agreement/1000000"
                        });
                    },
                    goToxiea: function() {
                        e.navigateTo({
                            url: "/pages/webview/webview?url=" + this.$config.default.Url + "/agreement/1000001"
                        });
                    },
                    codeChange: function(e) {
                        this.tips = e;
                    },
                    getCode: function() {
                        var n = this;
                        this.$refs.uCode.canGetCode ? (e.showLoading({
                            title: "正在获取验证码"
                        }), this.$api.default.request("user/sendSms", {
                            mobile: this.mobile
                        }).then(function(t) {
                            t.code ? (e.hideLoading(), e.$u.toast(t.msg), n.$refs.uCode.start()) : n.$common.errorToShow(t.msg);
                        })) : e.$u.toast("倒计时结束后再发送");
                    },
                    toLogin: function() {
                        var n = this;
                        this.isRead ? this.$api.default.request("user/smsLogin", {
                            mobile: this.mobile,
                            verify_code: this.code
                        }).then(function(t) {
                            t.code ? t.user.like_content_tags || t.user.like_writer_tags ? e.reLaunch({
                                url: "/pages/index/index"
                            }) : e.reLaunch({
                                url: "/pages/login/hobby"
                            }) : n.$common.errorToShow(t.msg);
                        }) : this.isReadTip();
                    },
                    isReadTip: function() {
                        var e = this;
                        if (!this.isRead) return this.$common.errorToShow("请先同意用户协议"), this.isRead = 1, 
                        void setTimeout(function() {
                            e.isRead = 0;
                        }, 300);
                    },
                    change: function(e) {
                        console.log("change", e);
                    }
                }
            };
            n.default = t;
        }).call(this, t(2).default);
    },
    610: function(e, n, t) {
        "use strict";
        t.r(n);
        var o = t(611), i = t.n(o);
        for (var u in o) [ "default" ].indexOf(u) < 0 && function(e) {
            t.d(n, e, function() {
                return o[e];
            });
        }(u);
        n.default = i.a;
    },
    611: function(e, n, t) {}
}, [ [ 604, "common/runtime", "common/vendor" ] ] ]);