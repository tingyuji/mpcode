(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/login/hobby_w" ], {
    644: function(t, e, n) {
        "use strict";
        (function(t, e) {
            var r = n(4);
            n(26), r(n(25));
            var i = r(n(645));
            t.__webpack_require_UNI_MP_PLUGIN__ = n, e(i.default);
        }).call(this, n(1).default, n(2).createPage);
    },
    645: function(t, e, n) {
        "use strict";
        n.r(e);
        var r = n(646), i = n(648);
        for (var o in i) [ "default" ].indexOf(o) < 0 && function(t) {
            n.d(e, t, function() {
                return i[t];
            });
        }(o);
        n(650);
        var a = n(33), s = Object(a.default)(i.default, r.render, r.staticRenderFns, !1, null, null, null, !1, r.components, void 0);
        s.options.__file = "pages/login/hobby_w.vue", e.default = s.exports;
    },
    646: function(t, e, n) {
        "use strict";
        n.r(e);
        var r = n(647);
        n.d(e, "render", function() {
            return r.render;
        }), n.d(e, "staticRenderFns", function() {
            return r.staticRenderFns;
        }), n.d(e, "recyclableRender", function() {
            return r.recyclableRender;
        }), n.d(e, "components", function() {
            return r.components;
        });
    },
    647: function(t, e, n) {
        "use strict";
        n.r(e), n.d(e, "render", function() {
            return r;
        }), n.d(e, "staticRenderFns", function() {
            return o;
        }), n.d(e, "recyclableRender", function() {
            return i;
        }), n.d(e, "components", function() {});
        var r = function() {
            var t = this, e = (t.$createElement, t._self._c, t.$db.get("config")), n = e ? t.__map(t.options, function(e, n) {
                return {
                    $orig: t.__get_orig(e),
                    g1: t.writer_tags ? t.writer_tags.some(function(t) {
                        return t.id == e.id;
                    }) : null
                };
            }) : null;
            t.$mp.data = Object.assign({}, {
                $root: {
                    g0: e,
                    l0: n
                }
            });
        }, i = !1, o = [];
        r._withStripped = !0;
    },
    648: function(t, e, n) {
        "use strict";
        n.r(e);
        var r = n(649), i = n.n(r);
        for (var o in r) [ "default" ].indexOf(o) < 0 && function(t) {
            n.d(e, t, function() {
                return r[t];
            });
        }(o);
        e.default = i.a;
    },
    649: function(t, e, n) {
        "use strict";
        (function(t) {
            var r = n(4);
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var i = r(n(56)), o = r(n(58)), a = {
                data: function() {
                    return {
                        paddingBottomHeight: 0,
                        options: [],
                        neiList: [],
                        type: 0,
                        writer_tags: [],
                        content_tags: [],
                        text_str: ""
                    };
                },
                created: function() {
                    this.getUserInfoTag();
                    var e = this;
                    t.getSystemInfo({
                        success: function(t) {
                            [ "X", "XR", "XS", "11", "12", "13", "14", "15" ].forEach(function(n) {
                                -1 != t.model.indexOf(n) && -1 != t.model.indexOf("iPhone") && (e.paddingBottomHeight = 40);
                            });
                        }
                    });
                    var n = getCurrentPages();
                    this.urlPath = "/" + n[0].route;
                },
                onLoad: function(t) {
                    this.type = t.type;
                },
                onShow: function() {
                    t.getStorageSync("writer_tags_text_str") && (this.text_str = t.getStorageSync("writer_tags_text_str"));
                },
                methods: {
                    getUserInfoTag: function() {
                        t.getStorageSync("writer_tags_arr") && (this.writer_tags = t.getStorageSync("writer_tags_arr")), 
                        this.getConfig();
                    },
                    goToTags: function() {
                        for (var e = "", n = this.writer_tags, r = 0; r < n.length; r++) e += 0 == r ? n[r].name : "、" + n[r].name;
                        t.setStorageSync("writer_tags", e + "、" + this.text_str), t.setStorageSync("writer_tags_arr", n), 
                        t.setStorageSync("writer_tags_text_str", this.text_str), t.navigateBack({
                            delta: 1
                        });
                    },
                    getConfig: function() {
                        var t = this;
                        return (0, o.default)(i.default.mark(function e() {
                            return i.default.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                  case 0:
                                    return e.next = 2, t.$api.default.request("Common/getConfig").then(function(e) {
                                        1 == e.code && (t.$db.set("config", e.data), t.options = e.data.tags.Xslx);
                                    });

                                  case 2:
                                  case "end":
                                    return e.stop();
                                }
                            }, e);
                        }))();
                    },
                    toggleTag: function(t, e) {
                        var n = this[e].findIndex(function(e) {
                            return e.id == t.id;
                        });
                        -1 !== n ? this[e].splice(n, 1) : this[e].push(t);
                    },
                    goToindex: function() {
                        t.reLaunch({
                            url: "/pages/index/index"
                        });
                    }
                }
            };
            e.default = a;
        }).call(this, n(2).default);
    },
    650: function(t, e, n) {
        "use strict";
        n.r(e);
        var r = n(651), i = n.n(r);
        for (var o in r) [ "default" ].indexOf(o) < 0 && function(t) {
            n.d(e, t, function() {
                return r[t];
            });
        }(o);
        e.default = i.a;
    },
    651: function(t, e, n) {}
}, [ [ 644, "common/runtime", "common/vendor" ] ] ]);