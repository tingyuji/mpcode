(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/login/hobby_w_tag" ], {
    652: function(t, n, e) {
        "use strict";
        (function(t, n) {
            var r = e(4);
            e(26), r(e(25));
            var i = r(e(653));
            t.__webpack_require_UNI_MP_PLUGIN__ = e, n(i.default);
        }).call(this, e(1).default, e(2).createPage);
    },
    653: function(t, n, e) {
        "use strict";
        e.r(n);
        var r = e(654), i = e(656);
        for (var o in i) [ "default" ].indexOf(o) < 0 && function(t) {
            e.d(n, t, function() {
                return i[t];
            });
        }(o);
        e(658);
        var u = e(33), a = Object(u.default)(i.default, r.render, r.staticRenderFns, !1, null, null, null, !1, r.components, void 0);
        a.options.__file = "pages/login/hobby_w_tag.vue", n.default = a.exports;
    },
    654: function(t, n, e) {
        "use strict";
        e.r(n);
        var r = e(655);
        e.d(n, "render", function() {
            return r.render;
        }), e.d(n, "staticRenderFns", function() {
            return r.staticRenderFns;
        }), e.d(n, "recyclableRender", function() {
            return r.recyclableRender;
        }), e.d(n, "components", function() {
            return r.components;
        });
    },
    655: function(t, n, e) {
        "use strict";
        e.r(n), e.d(n, "render", function() {
            return r;
        }), e.d(n, "staticRenderFns", function() {
            return o;
        }), e.d(n, "recyclableRender", function() {
            return i;
        }), e.d(n, "components", function() {});
        var r = function() {
            var t = this, n = (t.$createElement, t._self._c, t.$db.get("config")), e = n ? t.__map(t.options, function(n, e) {
                return {
                    $orig: t.__get_orig(n),
                    g1: t.writer_tags ? t.writer_tags.some(function(t) {
                        return t.id == n.id;
                    }) : null
                };
            }) : null;
            t.$mp.data = Object.assign({}, {
                $root: {
                    g0: n,
                    l0: e
                }
            });
        }, i = !1, o = [];
        r._withStripped = !0;
    },
    656: function(t, n, e) {
        "use strict";
        e.r(n);
        var r = e(657), i = e.n(r);
        for (var o in r) [ "default" ].indexOf(o) < 0 && function(t) {
            e.d(n, t, function() {
                return r[t];
            });
        }(o);
        n.default = i.a;
    },
    657: function(t, n, e) {
        "use strict";
        (function(t) {
            var r = e(4);
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var i = r(e(56)), o = r(e(58)), u = {
                data: function() {
                    return {
                        paddingBottomHeight: 0,
                        options: [],
                        neiList: [],
                        type: 0,
                        writer_tags: [],
                        content_tags: [],
                        text_str: ""
                    };
                },
                created: function() {
                    this.getUserInfoTag();
                    var n = this;
                    t.getSystemInfo({
                        success: function(t) {
                            [ "X", "XR", "XS", "11", "12", "13", "14", "15" ].forEach(function(e) {
                                -1 != t.model.indexOf(e) && -1 != t.model.indexOf("iPhone") && (n.paddingBottomHeight = 40);
                            });
                        }
                    });
                    var e = getCurrentPages();
                    this.urlPath = "/" + e[0].route;
                },
                onLoad: function(t) {},
                onShow: function() {},
                methods: {
                    getUserInfoTag: function() {
                        this.getConfig();
                    },
                    goToTags: function() {
                        var t = {};
                        t.writer_diy_tags_tes = this.writer_tags;
                        var n = this;
                        this.$api.default.request("user/saveUserDiyTag", t).then(function(t) {
                            1 == t.code && n.$common.errorToShow(t.msg);
                        });
                    },
                    getConfig: function() {
                        var t = this;
                        return (0, o.default)(i.default.mark(function n() {
                            return i.default.wrap(function(n) {
                                for (;;) switch (n.prev = n.next) {
                                  case 0:
                                    return n.next = 2, t.$api.default.request("user/getWrInfoTag").then(function(n) {
                                        1 == n.code && (t.options = n.data.like_writer_tags, n.data.writer_diy_tags && (t.writer_tags = n.data.writer_diy_tags));
                                    });

                                  case 2:
                                  case "end":
                                    return n.stop();
                                }
                            }, n);
                        }))();
                    },
                    toggleTag: function(t, n) {
                        var e = this[n].findIndex(function(n) {
                            return n.id == t.id;
                        });
                        -1 !== e ? this[n].splice(e, 1) : this[n].push(t);
                    },
                    goToindex: function() {
                        t.reLaunch({
                            url: "/pages/index/index"
                        });
                    }
                }
            };
            n.default = u;
        }).call(this, e(2).default);
    },
    658: function(t, n, e) {
        "use strict";
        e.r(n);
        var r = e(659), i = e.n(r);
        for (var o in r) [ "default" ].indexOf(o) < 0 && function(t) {
            e.d(n, t, function() {
                return r[t];
            });
        }(o);
        n.default = i.a;
    },
    659: function(t, n, e) {}
}, [ [ 652, "common/runtime", "common/vendor" ] ] ]);