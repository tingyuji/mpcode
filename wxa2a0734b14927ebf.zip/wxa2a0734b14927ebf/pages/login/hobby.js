(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/login/hobby" ], {
    636: function(t, n, e) {
        "use strict";
        (function(t, n) {
            var r = e(4);
            e(26), r(e(25));
            var i = r(e(637));
            t.__webpack_require_UNI_MP_PLUGIN__ = e, n(i.default);
        }).call(this, e(1).default, e(2).createPage);
    },
    637: function(t, n, e) {
        "use strict";
        e.r(n);
        var r = e(638), i = e(640);
        for (var o in i) [ "default" ].indexOf(o) < 0 && function(t) {
            e.d(n, t, function() {
                return i[t];
            });
        }(o);
        e(642);
        var u = e(33), s = Object(u.default)(i.default, r.render, r.staticRenderFns, !1, null, null, null, !1, r.components, void 0);
        s.options.__file = "pages/login/hobby.vue", n.default = s.exports;
    },
    638: function(t, n, e) {
        "use strict";
        e.r(n);
        var r = e(639);
        e.d(n, "render", function() {
            return r.render;
        }), e.d(n, "staticRenderFns", function() {
            return r.staticRenderFns;
        }), e.d(n, "recyclableRender", function() {
            return r.recyclableRender;
        }), e.d(n, "components", function() {
            return r.components;
        });
    },
    639: function(t, n, e) {
        "use strict";
        e.r(n), e.d(n, "render", function() {
            return r;
        }), e.d(n, "staticRenderFns", function() {
            return o;
        }), e.d(n, "recyclableRender", function() {
            return i;
        }), e.d(n, "components", function() {});
        var r = function() {
            var t = this, n = (t.$createElement, t._self._c, t.$db.get("config")), e = n ? t.__map(t.options, function(n, e) {
                return {
                    $orig: t.__get_orig(n),
                    g1: t.writer_tags ? t.writer_tags.some(function(t) {
                        return t.id == n.id;
                    }) : null
                };
            }) : null, r = n ? t.__map(t.neiList, function(n, e) {
                return {
                    $orig: t.__get_orig(n),
                    g2: t.content_tags ? t.content_tags.some(function(t) {
                        return t.id == n.id;
                    }) : null
                };
            }) : null, i = n ? !t.writer_tags.length && !t.content_tags.length : null;
            t.$mp.data = Object.assign({}, {
                $root: {
                    g0: n,
                    l0: e,
                    l1: r,
                    g3: i
                }
            });
        }, i = !1, o = [];
        r._withStripped = !0;
    },
    640: function(t, n, e) {
        "use strict";
        e.r(n);
        var r = e(641), i = e.n(r);
        for (var o in r) [ "default" ].indexOf(o) < 0 && function(t) {
            e.d(n, t, function() {
                return r[t];
            });
        }(o);
        n.default = i.a;
    },
    641: function(t, n, e) {
        "use strict";
        (function(t) {
            var r = e(4);
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var i = r(e(56)), o = r(e(58)), u = {
                data: function() {
                    return {
                        paddingBottomHeight: 0,
                        options: [],
                        neiList: [],
                        type: 0,
                        writer_tags: this.$db.get("userInfo").like_writer_tags ? this.$db.get("userInfo").like_writer_tags : [],
                        content_tags: this.$db.get("userInfo").like_content_tags ? this.$db.get("userInfo").like_content_tags : []
                    };
                },
                created: function() {
                    this.getUserInfoTag();
                    var n = this;
                    t.getSystemInfo({
                        success: function(t) {
                            [ "X", "XR", "XS", "11", "12", "13", "14", "15" ].forEach(function(e) {
                                -1 != t.model.indexOf(e) && -1 != t.model.indexOf("iPhone") && (n.paddingBottomHeight = 40);
                            });
                        }
                    });
                    var e = getCurrentPages();
                    this.urlPath = "/" + e[0].route;
                },
                onLoad: function(t) {
                    this.type = t.type;
                },
                methods: {
                    getUserInfoTag: function() {
                        this.getConfig();
                    },
                    goToTags: function() {
                        var t = {};
                        t.like_writer_tags = this.writer_tags, t.like_content_tags = this.content_tags;
                        var n = this;
                        this.$api.default.request("user/saveUser", t).then(function(t) {
                            1 == t.code && (n.$db.set("userInfo", t.user), n.$common.errorToShow("操作成功"), console.log(n.type, 777777), 
                            1 == n.type || setTimeout(function() {
                                n.goToindex();
                            }, 500));
                        });
                    },
                    getConfig: function() {
                        var t = this;
                        return (0, o.default)(i.default.mark(function n() {
                            return i.default.wrap(function(n) {
                                for (;;) switch (n.prev = n.next) {
                                  case 0:
                                    return n.next = 2, t.$api.default.request("Common/getConfig").then(function(n) {
                                        1 == n.code && (t.$db.set("config", n.data), t.options = n.data.tags.Xslx, t.neiList = n.data.tags.Nrbq);
                                    });

                                  case 2:
                                  case "end":
                                    return n.stop();
                                }
                            }, n);
                        }))();
                    },
                    toggleTag: function(t, n) {
                        var e = this[n].findIndex(function(n) {
                            return n.id == t.id;
                        });
                        -1 !== e ? this[n].splice(e, 1) : this[n].push(t);
                    },
                    goToindex: function() {
                        t.reLaunch({
                            url: "/pages/index/index"
                        });
                    }
                }
            };
            n.default = u;
        }).call(this, e(2).default);
    },
    642: function(t, n, e) {
        "use strict";
        e.r(n);
        var r = e(643), i = e.n(r);
        for (var o in r) [ "default" ].indexOf(o) < 0 && function(t) {
            e.d(n, t, function() {
                return r[t];
            });
        }(o);
        n.default = i.a;
    },
    643: function(t, n, e) {}
}, [ [ 636, "common/runtime", "common/vendor" ] ] ]);