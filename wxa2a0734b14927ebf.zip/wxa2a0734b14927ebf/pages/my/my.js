(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/my/my" ], {
    220: function(e, n, t) {
        "use strict";
        (function(e, n) {
            var r = t(4);
            t(26), r(t(25));
            var i = r(t(221));
            e.__webpack_require_UNI_MP_PLUGIN__ = t, n(i.default);
        }).call(this, t(1).default, t(2).createPage);
    },
    221: function(e, n, t) {
        "use strict";
        t.r(n);
        var r = t(222), i = t(224);
        for (var o in i) [ "default" ].indexOf(o) < 0 && function(e) {
            t.d(n, e, function() {
                return i[e];
            });
        }(o);
        t(226);
        var s = t(33), u = Object(s.default)(i.default, r.render, r.staticRenderFns, !1, null, null, null, !1, r.components, void 0);
        u.options.__file = "pages/my/my.vue", n.default = u.exports;
    },
    222: function(e, n, t) {
        "use strict";
        t.r(n);
        var r = t(223);
        t.d(n, "render", function() {
            return r.render;
        }), t.d(n, "staticRenderFns", function() {
            return r.staticRenderFns;
        }), t.d(n, "recyclableRender", function() {
            return r.recyclableRender;
        }), t.d(n, "components", function() {
            return r.components;
        });
    },
    223: function(e, n, t) {
        "use strict";
        var r;
        t.r(n), t.d(n, "render", function() {
            return i;
        }), t.d(n, "staticRenderFns", function() {
            return s;
        }), t.d(n, "recyclableRender", function() {
            return o;
        }), t.d(n, "components", function() {
            return r;
        });
        try {
            r = {
                uPopup: function() {
                    return Promise.all([ t.e("common/vendor"), t.e("node-modules/uview-ui/components/u-popup/u-popup") ]).then(t.bind(null, 890));
                }
            };
        } catch (e) {
            if (-1 === e.message.indexOf("Cannot find module") || -1 === e.message.indexOf(".vue")) throw e;
            console.error(e.message), console.error("1. 排查组件名称拼写是否正确"), console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"), 
            console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件");
        }
        var i = function() {
            var e = this, n = (e.$createElement, e._self._c, Object.keys(e.userInfo).length), t = n > 0 ? e.$db.get("userInfo") : null, r = n > 0 ? e._f("formatImgUrl")(e.userInfo.bg_image) : null, i = n > 0 && 1 == e.userInfo.is_home_label && 2 == e.userInfo.home_label_type ? e._f("formatImgUrl")(e.userInfo.home_label_bg_img) : null, o = n > 0 ? e._f("formatImgUrl")(e.userInfo.pic) : null, s = n > 0 ? 0 == e.userInfo.is_fensi && e.uid != e.$db.get("userInfo").membe_id : null, u = n > 0 ? 0 == e.userInfo.is_gaunzhu && e.uid != e.$db.get("userInfo").membe_id : null, l = n > 0 && e.userInfo && e.userInfo.is_writer ? e.$options.filters.formatImgUrl(e.userInfo.writer_level.is_active ? e.userInfo.writer_level.level.image : e.userInfo.writer_level.level.hide_img) : null, a = n > 0 && e.userInfo && e.userInfo.user_level.is_active && e.userInfo.user_level.level ? e.$options.filters.formatImgUrl(e.userInfo.user_level.active_day > 0 ? e.userInfo.user_level.level.image : e.userInfo.user_level.level.hide_img) : null, f = n > 0 && e.userInfo.signature_des ? e._f("filterRichText")(e.userInfo.signature_des) : null, g = n > 0 ? e.$db.get("userInfo") : null, m = n > 0 && e.uid !== g.membe_id ? 1 == e.userInfo.is_primsg && e.uid != e.$db.get("userInfo").membe_id : null, d = n > 0 && e.uid !== g.membe_id && m ? e._f("formatImgUrl")("/images/pp.png") : null, c = n > 0 && e.uid !== g.membe_id && !m && 1 == e.userInfo.is_writer ? e._f("formatImgUrl")("/images/pp.png") : null, _ = n > 0 && e.uid !== g.membe_id && !m && 1 != e.userInfo.is_writer ? e._f("formatImgUrl")("/images/pp.png") : null, p = n > 0 ? e._f("formatImgUrl")(e.userInfo.pic) : null, h = n > 0 ? 1 == e.userInfo.is_primsg && e.uid != e.$db.get("userInfo").membe_id : null, v = n > 0 && h ? e._f("formatImgUrl")("/images/pp.png") : null, I = n > 0 && e.userInfo.is_writer && e.list.total ? e._f("formatImgUrl")("/images/ji.png") : null, w = n > 0 ? e._f("formatImgUrl")("/images/close.png") : null, b = n > 0 && !e.list.total ? e._f("formatImgUrl")("/images/empty.png") : null, $ = n > 0 ? e.__map(e.rowList, function(n, t) {
                return {
                    $orig: e.__get_orig(n),
                    f12: 1 === e.navIndex ? e._f("formatImgUrl")("/images/je.png") : null,
                    f13: 2 === e.navIndex ? e._f("formatImgUrl")(n.order_info.user.pic) : null,
                    g9: 2 === e.navIndex ? e.$options.filters.parseTime(n.order_info.create_time, "{y} 年 {m} 月 {d} 日 {h}:{i}") : null,
                    l0: 2 === e.navIndex ? e.__map(n.rank, function(n, t) {
                        return {
                            $orig: e.__get_orig(n),
                            f14: e._f("formatImgUrl")("/images/star.png")
                        };
                    }) : null,
                    f15: 2 === e.navIndex ? e._f("formatImgUrl")("/images/je.png") : null,
                    f16: 3 === e.navIndex ? e._f("formatImgUrl")("/images/bao.png") : null,
                    f17: 3 === e.navIndex ? e._f("formatImgUrl")(n.user.pic) : null,
                    g10: 3 === e.navIndex && n.user && n.user.is_writer ? e.$options.filters.formatImgUrl(n.user.writer_level.is_active ? n.user.writer_level.level.image : n.user.writer_level.level.hide_img) : null,
                    g11: 3 === e.navIndex && n.user && n.user.user_level.is_active && n.user.user_level.level ? e.$options.filters.formatImgUrl(n.user.user_level.active_day > 0 ? n.user.user_level.level.image : n.user.user_level.level.hide_img) : null,
                    g12: 3 === e.navIndex && n.hot ? e.$db.get("config") : null,
                    g13: 3 === e.navIndex && n.sift ? e.$db.get("config") : null,
                    g14: 3 === e.navIndex ? e.$options.filters.parseTime(n.create_time, "{y} 年 {m} 月 {d} 日 {h}:{i}") : null,
                    f18: 3 === e.navIndex ? e._f("filterRichText")(n.row) : null,
                    l1: 3 === e.navIndex ? e.__map(n.img, function(n, t) {
                        return {
                            $orig: e.__get_orig(n),
                            f19: e._f("formatImgUrl")(n)
                        };
                    }) : null,
                    f20: 3 === e.navIndex ? e._f("formatImgUrl")("/images/jf.png") : null,
                    f21: 3 === e.navIndex ? e._f("formatImgUrl")("/images/jg.png") : null
                };
            }) : null, U = n > 0 ? e.$db.get("userInfo") : null, y = n > 0 && e.uid === U.membe_id ? e._f("formatImgUrl")("/images/rarr.png") : null, x = n > 0 ? e.$db.get("userInfo") : null, L = n > 0 && e.uid === x.membe_id ? e._f("formatImgUrl")("/images/rarr.png") : null, T = n > 0 ? e.$db.get("userInfo") : null, O = n > 0 && e.uid !== T.membe_id ? e._f("formatImgUrl")("/images/rarr.png") : null;
            e._isMounted || (e.e0 = function(n) {
                e.show = !0;
            }, e.e1 = function(n) {
                e.show = !0;
            }, e.e2 = function(n) {
                e.show = !1;
            }, e.e3 = function(n, t) {
                var r;
                t = ((r = arguments[arguments.length - 1].currentTarget.dataset).eventParams || r["event-params"]).item, 
                n.stopPropagation(), e.aid = t.id, e.is_top = t.is_top, e.showdel = !0;
            }, e.e4 = function(n) {
                e.showdel = !1;
            }), e.$mp.data = Object.assign({}, {
                $root: {
                    g0: n,
                    g1: t,
                    f0: r,
                    f1: i,
                    f2: o,
                    g2: s,
                    g3: u,
                    g4: l,
                    g5: a,
                    f3: f,
                    g6: g,
                    g7: m,
                    f4: d,
                    f5: c,
                    f6: _,
                    f7: p,
                    g8: h,
                    f8: v,
                    f9: I,
                    f10: w,
                    f11: b,
                    l2: $,
                    g15: U,
                    f22: y,
                    g16: x,
                    f23: L,
                    g17: T,
                    f24: O
                }
            });
        }, o = !1, s = [];
        i._withStripped = !0;
    },
    224: function(e, n, t) {
        "use strict";
        t.r(n);
        var r = t(225), i = t.n(r);
        for (var o in r) [ "default" ].indexOf(o) < 0 && function(e) {
            t.d(n, e, function() {
                return r[e];
            });
        }(o);
        n.default = i.a;
    },
    225: function(e, n, t) {
        "use strict";
        (function(e) {
            var r = t(13);
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var i = function(e, n) {
                if (!n && e && e.__esModule) return e;
                if (null === e || "object" !== r(e) && "function" != typeof e) return {
                    default: e
                };
                var t = o(n);
                if (t && t.has(e)) return t.get(e);
                var i = {}, s = Object.defineProperty && Object.getOwnPropertyDescriptor;
                for (var u in e) if ("default" !== u && Object.prototype.hasOwnProperty.call(e, u)) {
                    var l = s ? Object.getOwnPropertyDescriptor(e, u) : null;
                    l && (l.get || l.set) ? Object.defineProperty(i, u, l) : i[u] = e[u];
                }
                return i.default = e, t && t.set(e, i), i;
            }(t(168));
            function o(e) {
                if ("function" != typeof WeakMap) return null;
                var n = new WeakMap(), t = new WeakMap();
                return (o = function(e) {
                    return e ? t : n;
                })(e);
            }
            var s = {
                data: function() {
                    return {
                        isguan: !0,
                        navList: [ {
                            id: 1,
                            name: "约文"
                        }, {
                            id: 2,
                            name: "评价"
                        }, {
                            id: 3,
                            name: "动态"
                        } ],
                        navIndex: 1,
                        show: !1,
                        uid: this.$db.get("userInfo").membe_id,
                        userInfo: {},
                        list: {},
                        page: 1,
                        rowList: [],
                        showdel: !1,
                        aid: 0,
                        is_top: 0
                    };
                },
                onPullDownRefresh: function() {
                    setTimeout(function() {
                        e.stopPullDownRefresh();
                    }, 800), this.getUserInfo();
                },
                onShow: function() {
                    this.getUserInfo();
                },
                onLoad: function(n) {
                    if (console.log(n.id), n.id) {
                        this.uid = n.id;
                        var t = e.getStorageSync(this.uid + "timestamp");
                        if (t) {
                            var r = new Date().getTime();
                            r - t > 3e5 && (e.setStorageSync(this.uid + "timestamp", r), this.get_look(this.uid));
                        } else t = new Date().getTime(), e.setStorageSync(this.uid + "timestamp", t), this.get_look(this.uid);
                        console.log(this.uid, t, 66666666);
                    }
                },
                onReachBottom: function() {
                    this.list.current_page < this.list.last_page && (this.page++, this.getList());
                },
                methods: {
                    get_look: function(e) {
                        this.$api.default.request("user/look_user", {
                            uid: e
                        }, "POST").then(function(e) {});
                    },
                    is_tops: function() {
                        var e = this;
                        this.$api.default.request("user/user_top", {
                            id: this.aid
                        }, "POST").then(function(n) {
                            1 == n.code && e.$common.successToShow(n.msg, function() {
                                e.page = 1, e.list = {}, e.rowList = [], e.getList(), e.showdel = !1;
                            });
                        });
                    },
                    no_gou: function() {
                        this.$common.errorToShow("该用户未开放私信");
                    },
                    delRow: function() {
                        var n = this;
                        i.get("auth") ? this.$api.default.request("Discover/delArticle", {
                            id: this.aid
                        }, "POST").then(function(e) {
                            1 == e.code && n.$common.successToShow(e.msg, function() {
                                n.page = 1, n.list = {}, n.rowList = [], n.getList(), n.showdel = !1;
                            });
                        }) : e.reLaunch({
                            url: "/pages/login/login"
                        });
                    },
                    goToreport: function() {
                        i.get("auth") ? (this.showdel = !1, e.navigateTo({
                            url: "/pages/find/report?id=" + this.aid
                        })) : e.reLaunch({
                            url: "/pages/login/login"
                        });
                    },
                    userLike: function() {
                        var n = this;
                        i.get("auth") ? this.$api.default.request("user/userLike", {
                            uid: this.uid
                        }, "POST").then(function(e) {
                            1 == e.code && n.$common.successToShow(e.msg, function() {
                                n.getUserInfo();
                            });
                        }) : e.reLaunch({
                            url: "/pages/login/login"
                        });
                    },
                    getList: function() {
                        var e = this;
                        console.log(this.page, 777777777), this.$api.default.request("user/userPageList", {
                            type: this.navIndex,
                            uid: this.uid,
                            page: this.page
                        }, "POST").then(function(n) {
                            1 == n.code && (e.list = n.data, n.data.current_page > 1 ? n.data.data.forEach(function(n) {
                                e.rowList.push(n);
                            }) : e.rowList = n.data.data);
                        });
                    },
                    editBgImg: function() {
                        var n = this;
                        i.get("auth") ? this.$common.chooseImage({}, function(e) {
                            e && n.saveUser({
                                bg_image: e
                            });
                        }) : e.reLaunch({
                            url: "/pages/login/login"
                        });
                    },
                    saveUser: function(n) {
                        var t = this;
                        i.get("auth") ? this.$api.default.request("user/saveUser", n).then(function(e) {
                            1 == e.code ? (t.userInfo = e.user, t.$common.successToShow(e.msg)) : t.$common.errorToShow(e.msg);
                        }) : e.reLaunch({
                            url: "/pages/login/login"
                        });
                    },
                    toImRoom: function() {
                        if (i.get("auth")) {
                            this.$store.commit("createConversationActive", this.userInfo.membe_id);
                            var n = "";
                            n = this.userInfo.is_writer ? "/pages/tim/room?userType=1&showbox=1&uid=" + this.userInfo.membe_id : "/pages/tim/room", 
                            e.redirectTo({
                                url: n
                            });
                        } else e.reLaunch({
                            url: "/pages/login/login"
                        });
                    },
                    getUserInfo: function() {
                        var e = this;
                        this.$api.default.request("user/userInfo", {
                            uid: this.uid
                        }).then(function(n) {
                            n.code ? (e.userInfo = n.user, n.user.is_writer || (e.navIndex = 3), e.getList()) : e.$common.errorToShow(n.msg);
                        });
                    },
                    navTap: function(e) {
                        this.list = {}, this.rowList = [], this.navIndex = e.id, this.page = 1, this.getList();
                    },
                    open: function() {},
                    close: function() {
                        this.show = !1;
                    },
                    closedel: function() {
                        this.showdel = !1;
                    }
                }
            };
            n.default = s;
        }).call(this, t(2).default);
    },
    226: function(e, n, t) {
        "use strict";
        t.r(n);
        var r = t(227), i = t.n(r);
        for (var o in r) [ "default" ].indexOf(o) < 0 && function(e) {
            t.d(n, e, function() {
                return r[e];
            });
        }(o);
        n.default = i.a;
    },
    227: function(e, n, t) {}
}, [ [ 220, "common/runtime", "common/vendor" ] ] ]);