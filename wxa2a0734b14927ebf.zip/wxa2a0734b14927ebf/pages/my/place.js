(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/my/place" ], {
    228: function(o, e, t) {
        "use strict";
        (function(o, e) {
            var i = t(4);
            t(26), i(t(25));
            var n = i(t(229));
            o.__webpack_require_UNI_MP_PLUGIN__ = t, e(n.default);
        }).call(this, t(1).default, t(2).createPage);
    },
    229: function(o, e, t) {
        "use strict";
        t.r(e);
        var i = t(230), n = t(232);
        for (var r in n) [ "default" ].indexOf(r) < 0 && function(o) {
            t.d(e, o, function() {
                return n[o];
            });
        }(r);
        t(234);
        var s = t(33), a = Object(s.default)(n.default, i.render, i.staticRenderFns, !1, null, null, null, !1, i.components, void 0);
        a.options.__file = "pages/my/place.vue", e.default = a.exports;
    },
    230: function(o, e, t) {
        "use strict";
        t.r(e);
        var i = t(231);
        t.d(e, "render", function() {
            return i.render;
        }), t.d(e, "staticRenderFns", function() {
            return i.staticRenderFns;
        }), t.d(e, "recyclableRender", function() {
            return i.recyclableRender;
        }), t.d(e, "components", function() {
            return i.components;
        });
    },
    231: function(o, e, t) {
        "use strict";
        var i;
        t.r(e), t.d(e, "render", function() {
            return n;
        }), t.d(e, "staticRenderFns", function() {
            return s;
        }), t.d(e, "recyclableRender", function() {
            return r;
        }), t.d(e, "components", function() {
            return i;
        });
        try {
            i = {
                uNumberBox: function() {
                    return Promise.all([ t.e("common/vendor"), t.e("node-modules/uview-ui/components/u-number-box/u-number-box") ]).then(t.bind(null, 912));
                },
                uPopup: function() {
                    return Promise.all([ t.e("common/vendor"), t.e("node-modules/uview-ui/components/u-popup/u-popup") ]).then(t.bind(null, 890));
                }
            };
        } catch (o) {
            if (-1 === o.message.indexOf("Cannot find module") || -1 === o.message.indexOf(".vue")) throw o;
            console.error(o.message), console.error("1. 排查组件名称拼写是否正确"), console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"), 
            console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件");
        }
        var n = function() {
            var o = this, e = (o.$createElement, o._self._c, void 0 !== o.info.id ? o._f("formatImgUrl")(o.info.user.pic) : null), t = void 0 !== o.info.id && o.userInfo && o.userInfo.is_writer ? o.$options.filters.formatImgUrl(o.userInfo.writer_level.is_active ? o.userInfo.writer_level.level.image : o.userInfo.writer_level.level.hide_img) : null, i = void 0 !== o.info.id && o.userInfo && o.userInfo.user_level.level && o.userInfo.user_level.level ? o.$options.filters.formatImgUrl(o.userInfo.user_level.is_active ? o.userInfo.user_level.level.image : o.userInfo.user_level.level.hide_img) : null, n = void 0 !== o.info.id ? o._f("formatImgUrl")("/images/jj.png") : null, r = void 0 !== o.info.id ? o.__map(o.goodList, function(e, t) {
                return {
                    $orig: o.__get_orig(e),
                    f2: t == o.navIndex ? o._f("formatImgUrl")("/images/jk.png") : null,
                    f3: t == o.navIndex ? o._f("formatImgUrl")("/images/jl.png") : null,
                    f4: o._f("formatImgUrl")("/images/je.png")
                };
            }) : null, s = void 0 !== o.info.id ? o.couponList.length : null, a = void 0 === o.info.id || s ? null : o._f("formatImgUrl")("/images/empty.png"), u = void 0 !== o.info.id ? o.__map(o.couponList, function(e, t) {
                return {
                    $orig: o.__get_orig(e),
                    f6: o._f("formatImgUrl")("/images/youbg.png")
                };
            }) : null, f = void 0 !== o.info.id ? o.__map(o.zhiList, function(e, t) {
                return {
                    $orig: o.__get_orig(e),
                    f7: t == o.zhiLiang ? o._f("formatImgUrl")("/images/jk.png") : null,
                    f8: t == o.zhiLiang ? o._f("formatImgUrl")("/images/jl.png") : null,
                    f9: o._f("formatImgUrl")("/images/jn.png")
                };
            }) : null;
            o._isMounted || (o.e0 = function(e) {
                o.show = !0;
            }, o.e1 = function(e) {
                o.quan = !0;
            }, o.e2 = function(e) {
                o.quan = !0;
            }, o.e3 = function(e) {
                o.isRead = 2 == o.isRead ? 0 : 2;
            }, o.e4 = function(e) {
                o.show = !1;
            }, o.e5 = function(e) {
                o.quan = !1;
            }), o.$mp.data = Object.assign({}, {
                $root: {
                    f0: e,
                    g0: t,
                    g1: i,
                    f1: n,
                    l0: r,
                    g2: s,
                    f5: a,
                    l1: u,
                    l2: f
                }
            });
        }, r = !1, s = [];
        n._withStripped = !0;
    },
    232: function(o, e, t) {
        "use strict";
        t.r(e);
        var i = t(233), n = t.n(i);
        for (var r in i) [ "default" ].indexOf(r) < 0 && function(o) {
            t.d(e, o, function() {
                return i[o];
            });
        }(r);
        e.default = n.a;
    },
    233: function(o, e, t) {
        "use strict";
        (function(o) {
            var i = t(13);
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var n = function(o, e) {
                if (!e && o && o.__esModule) return o;
                if (null === o || "object" !== i(o) && "function" != typeof o) return {
                    default: o
                };
                var t = r(e);
                if (t && t.has(o)) return t.get(o);
                var n = {}, s = Object.defineProperty && Object.getOwnPropertyDescriptor;
                for (var a in o) if ("default" !== a && Object.prototype.hasOwnProperty.call(o, a)) {
                    var u = s ? Object.getOwnPropertyDescriptor(o, a) : null;
                    u && (u.get || u.set) ? Object.defineProperty(n, a, u) : n[a] = o[a];
                }
                return n.default = o, t && t.set(o, n), n;
            }(t(168));
            function r(o) {
                if ("function" != typeof WeakMap) return null;
                var e = new WeakMap(), t = new WeakMap();
                return (r = function(o) {
                    return o ? t : e;
                })(o);
            }
            var s = {
                data: function() {
                    return {
                        loading: !0,
                        userInfo: this.$db.get("userInfo"),
                        isRead: !1,
                        form: {
                            order_type: 1,
                            gid: "",
                            day: 1,
                            num: 1,
                            pay_type: 1,
                            notes: "",
                            price: 0
                        },
                        paddingBottomHeight: 0,
                        show: !1,
                        navList: [],
                        navIndex: 0,
                        quan: !1,
                        zhifu: !1,
                        items: [ {
                            value: "1",
                            pic: this.$options.filters.formatImgUrl("/images/jm.png"),
                            name: "微信支付"
                        }, {
                            value: "2",
                            pic: this.$options.filters.formatImgUrl("/images/jn.png"),
                            name: "粮币支付"
                        } ],
                        current: 0,
                        bishow: !1,
                        zhiList: [],
                        zhiLiang: 0,
                        zhiput: !1,
                        id: 0,
                        info: {},
                        list: {},
                        page: 1,
                        goodList: [],
                        orderInfo: {},
                        isClick: !1,
                        couponList: [],
                        selCoupItem: {}
                    };
                },
                watch: {
                    bishow: function(o) {
                        this.form.order_type = o ? 2 : 1, this.form.pay_type = o ? 1 : 2;
                    },
                    "form.num": function(o) {
                        this.form.price = parseFloat(parseFloat(this.info.price) * parseInt(this.form.num)).toFixed(2), 
                        this.form.amount = parseFloat(parseFloat(this.info.price) * parseInt(this.form.num)).toFixed(2);
                    }
                },
                onShow: function() {
                    this.getUserInfo(), this.getChongList(), this.getCouponList();
                },
                onLoad: function(o) {
                    o.id ? (this.id = o.id, this.getInfo()) : this.$common.errorToShow("参数异常");
                },
                created: function() {
                    var e = this;
                    o.getSystemInfo({
                        success: function(o) {
                            [ "X", "XR", "XS", "11", "12", "13", "14", "15" ].forEach(function(t) {
                                -1 != o.model.indexOf(t) && -1 != o.model.indexOf("iPhone") && (e.paddingBottomHeight = 40);
                            });
                        }
                    });
                    var t = getCurrentPages();
                    this.urlPath = "/" + t[0].route;
                },
                methods: {
                    selCoupon: function(o) {
                        this.quan = !1, parseFloat(this.form.price) >= parseFloat(o.coupon.man_price) ? (this.selCoupItem = o, 
                        this.form.cv_id = o.id, this.form.price = this.form.num * this.info.price - o.coupon.price) : this.$common.errorToShow("未满足使用条件");
                    },
                    getCouponList: function() {
                        var o = this;
                        this.$api.default.request("user/getCouponList", {
                            type: 1
                        }).then(function(e) {
                            e.code && (o.couponList = e.data);
                        });
                    },
                    goToxie: function() {
                        o.navigateTo({
                            url: "/pages/webview/webview?url=" + this.$config.default.Url + "/agreement/1000002"
                        });
                    },
                    goToxiea: function() {
                        o.navigateTo({
                            url: "/pages/webview/webview?url=" + this.$config.default.Url + "/agreement/1000002"
                        });
                    },
                    getChongList: function() {
                        var o = this;
                        this.$api.default.request("user/exchangeList", {
                            type: 1
                        }).then(function(e) {
                            e.code && (o.zhiList = e.data, o.zhiList.push({
                                id: 666,
                                money: "任意数量",
                                price: "自定义金额"
                            }));
                        });
                    },
                    getUserInfo: function() {
                        var o = this;
                        this.$api.default.request("user/userInfo", {}, "POST", !1).then(function(e) {
                            e.code ? o.userInfo = e.user : o.$common.errorToShow(e.msg);
                        });
                    },
                    goPay: function() {
                        var e = n.get("auth");
                        if (console.log(e, 777777777), e) if (this.loading) this.$common.errorToShow("数据加载中，请稍后再试"); else {
                            var t = {};
                            2 == this.form.order_type ? (t.order_type = this.form.order_type, t.pay_type = this.form.pay_type, 
                            t.fid = this.zhiList[this.zhiLiang].id, t.price = this.form.price) : t = this.form, 
                            console.log(t, 156);
                            var i = this;
                            i.$api.default.request("order/createOrder", t).then(function(o) {
                                o.code && (i.orderInfo = o.data, console.log(i.form.order_type, 157), 2 == i.form.pay_type ? 2 == i.form.order_type ? i.$common.successToShow(o.msg, function() {
                                    i.getUserInfo(), i.getInfo(), console.log(1118), i.$common.errorToShow("支付成功"), 
                                    i.hidezhifu(), i.hidebi();
                                }) : i.$common.successToShow(o.msg, function() {
                                    i.getInfo(), console.log(1116), i.$common.errorToShow("支付成功"), setTimeout(function() {
                                        i.goTohave();
                                    }, 800);
                                }) : 2 == i.form.order_type ? i.$common.wxPay(o.data, function() {
                                    i.getUserInfo(), i.getInfo(), console.log(1118), i.$common.errorToShow("支付成功"), 
                                    i.hidezhifu(), i.hidebi();
                                }) : i.$common.wxPay(o.data, function() {
                                    i.getUserInfo(), i.getInfo(), console.log(1117), i.$common.errorToShow("支付成功"), 
                                    setTimeout(function() {
                                        i.goTohave();
                                    }, 800);
                                }));
                            });
                        } else o.reLaunch({
                            url: "/pages/login/login"
                        });
                    },
                    showPay: function() {
                        var e = n.get("auth");
                        console.log(e, 777777777), e ? this.isRead ? this.zhifu = !0 : this.isReadTip() : o.reLaunch({
                            url: "/pages/login/login"
                        });
                    },
                    isReadTip: function() {
                        var o = this;
                        if (!this.isRead) return this.$common.errorToShow("请先同意下单协议"), this.isRead = 1, 
                        void setTimeout(function() {
                            o.isRead = 0;
                        }, 300);
                    },
                    getInfo: function() {
                        var o = this;
                        this.$api.default.request("good/info", {
                            id: this.id
                        }).then(function(e) {
                            e.code && (o.info = e.data, o.info.start_shooting = e.data.start_shooting ? e.data.start_shooting : 1, 
                            o.form.gid = e.data.id, o.form.amount = o.info.start_shooting * o.info.price, o.getList());
                        });
                    },
                    getList: function() {
                        var o = this;
                        this.$api.default.request("good/list", {
                            uid: this.info.uid,
                            page: this.page
                        }).then(function(e) {
                            e.code && (o.list = e.data, e.data.current_page > 1 ? e.data.data.forEach(function(e) {
                                o.goodList.push(e);
                            }) : o.goodList = e.data.data, o.goodList.forEach(function(e, t) {
                                e.id == o.info.id && (o.navIndex = t, o.form.gid = e.id, o.form.num = e.start_shooting ? e.start_shooting : 1, 
                                o.form.price = parseFloat(parseFloat(e.price) * parseInt(e.start_shooting ? e.start_shooting : 1)).toFixed(2));
                            }), o.loading = !1);
                        });
                    },
                    valChange: function(o) {
                        console.log("当前值为: " + o.value);
                    },
                    twoChange: function(o) {
                        console.log("当前值为: " + o.value), this.form.price = parseFloat(parseFloat(this.info.price) * parseInt(this.form.num)).toFixed(2);
                    },
                    open: function() {},
                    close: function() {
                        this.show = !1;
                    },
                    navTap: function(o) {
                        this.navIndex = o, this.info = this.goodList[o], this.form.gid = this.info.id, this.form.num = this.info.start_shooting, 
                        this.form.price = parseFloat(parseFloat(this.info.price) * parseInt(this.form.num)).toFixed(2);
                    },
                    hidequan: function() {
                        this.quan = !1;
                    },
                    radioChange: function(o) {
                        for (var e = 0; e < this.items.length; e++) if (this.items[e].value === o.detail.value) {
                            this.current = e;
                            break;
                        }
                        this.form.pay_type = this.items[this.current].value;
                    },
                    hidezhifu: function() {
                        this.zhifu = !1;
                    },
                    zhishow: function() {
                        if (!this.isClick) {
                            console.log(this.userInfo.wallet), console.log(this.form.price), console.log(this.form.pay_type);
                            var o = this.userInfo.wallet, e = this.form.price;
                            this.zhifu = !1, 1 == this.form.pay_type ? (this.isClick = !1, this.goPay()) : parseFloat(o) >= parseFloat(e) ? (console.log(111), 
                            this.isClick = !1, this.goPay()) : (console.log(222), this.isClick = !1, this.form.price = this.zhiList[0].price, 
                            this.bishow = !0);
                        }
                    },
                    hidebi: function() {
                        this.bishow = !1;
                    },
                    zhiTab: function(o) {
                        this.zhiLiang = o, o === this.zhiList.length - 1 ? (this.zhiput = !0, this.form.price = "") : (this.zhiput = !1, 
                        this.form.price = this.zhiList[o].price);
                    },
                    goTohave: function() {
                        this.bishow = !1, o.navigateTo({
                            url: "/pages/user/orderdetail?id=" + this.orderInfo.id
                        });
                    }
                }
            };
            e.default = s;
        }).call(this, t(2).default);
    },
    234: function(o, e, t) {
        "use strict";
        t.r(e);
        var i = t(235), n = t.n(i);
        for (var r in i) [ "default" ].indexOf(r) < 0 && function(o) {
            t.d(e, o, function() {
                return i[o];
            });
        }(r);
        e.default = n.a;
    },
    235: function(o, e, t) {}
}, [ [ 228, "common/runtime", "common/vendor" ] ] ]);