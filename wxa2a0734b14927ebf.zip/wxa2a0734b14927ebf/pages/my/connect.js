(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/my/connect" ], {
    764: function(e, o, r) {
        "use strict";
        (function(e, o) {
            var n = r(4);
            r(26), n(r(25));
            var t = n(r(765));
            e.__webpack_require_UNI_MP_PLUGIN__ = r, o(t.default);
        }).call(this, r(1).default, r(2).createPage);
    },
    765: function(e, o, r) {
        "use strict";
        r.r(o);
        var n = r(766), t = r(768);
        for (var i in t) [ "default" ].indexOf(i) < 0 && function(e) {
            r.d(o, e, function() {
                return t[e];
            });
        }(i);
        r(770);
        var s = r(33), u = Object(s.default)(t.default, n.render, n.staticRenderFns, !1, null, null, null, !1, n.components, void 0);
        u.options.__file = "pages/my/connect.vue", o.default = u.exports;
    },
    766: function(e, o, r) {
        "use strict";
        r.r(o);
        var n = r(767);
        r.d(o, "render", function() {
            return n.render;
        }), r.d(o, "staticRenderFns", function() {
            return n.staticRenderFns;
        }), r.d(o, "recyclableRender", function() {
            return n.recyclableRender;
        }), r.d(o, "components", function() {
            return n.components;
        });
    },
    767: function(e, o, r) {
        "use strict";
        var n;
        r.r(o), r.d(o, "render", function() {
            return t;
        }), r.d(o, "staticRenderFns", function() {
            return s;
        }), r.d(o, "recyclableRender", function() {
            return i;
        }), r.d(o, "components", function() {
            return n;
        });
        try {
            n = {
                uSteps: function() {
                    return Promise.all([ r.e("common/vendor"), r.e("node-modules/uview-ui/components/u-steps/u-steps") ]).then(r.bind(null, 962));
                },
                uStepsItem: function() {
                    return Promise.all([ r.e("common/vendor"), r.e("node-modules/uview-ui/components/u-steps-item/u-steps-item") ]).then(r.bind(null, 970));
                },
                uPopup: function() {
                    return Promise.all([ r.e("common/vendor"), r.e("node-modules/uview-ui/components/u-popup/u-popup") ]).then(r.bind(null, 890));
                }
            };
        } catch (e) {
            if (-1 === e.message.indexOf("Cannot find module") || -1 === e.message.indexOf(".vue")) throw e;
            console.error(e.message), console.error("1. 排查组件名称拼写是否正确"), console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"), 
            console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件");
        }
        var t = function() {
            var e = this, o = (e.$createElement, e._self._c, Object.keys(e.orderInfo).length), r = o > 0 && 1 == e.orderInfo.status ? e.$db.get("userInfo") : null, n = o > 0 ? e._f("formatImgUrl")(e.orderInfo.writer.pic) : null, t = o > 0 && e.orderInfo.writer && e.orderInfo.writer.is_writer ? e.$options.filters.formatImgUrl(e.orderInfo.writer.writer_level.is_active ? e.orderInfo.writer.writer_level.level.image : e.orderInfo.writer.writer_level.level.hide_img) : null, i = o > 0 && e.orderInfo.writer && e.orderInfo.writer.user_level.is_active && e.orderInfo.writer.user_level.level ? e.$options.filters.formatImgUrl(e.orderInfo.writer.user_level.active_day > 0 ? e.orderInfo.writer.user_level.level.image : e.orderInfo.writer.user_level.level.hide_img) : null, s = o > 0 ? e._f("formatImgUrl")("/images/je.png") : null, u = o > 0 ? e.$options.filters.parseTime(e.orderInfo.create_time, "{y} / {m} / {d} {h}:{i}:{s}") : null, d = o > 0 ? e.$db.get("userInfo") : null;
            e._isMounted || (e.e0 = function(o) {
                e.show = !0;
            }, e.e1 = function(o) {
                e.show = !1;
            }), e.$mp.data = Object.assign({}, {
                $root: {
                    g0: o,
                    g1: r,
                    f0: n,
                    g2: t,
                    g3: i,
                    f1: s,
                    g4: u,
                    g5: d
                }
            });
        }, i = !1, s = [];
        t._withStripped = !0;
    },
    768: function(e, o, r) {
        "use strict";
        r.r(o);
        var n = r(769), t = r.n(n);
        for (var i in n) [ "default" ].indexOf(i) < 0 && function(e) {
            r.d(o, e, function() {
                return n[e];
            });
        }(i);
        o.default = t.a;
    },
    769: function(e, o, r) {
        "use strict";
        (function(e) {
            Object.defineProperty(o, "__esModule", {
                value: !0
            }), o.default = void 0;
            var r = {
                data: function() {
                    return {
                        paddingBottomHeight: 0,
                        show: !1,
                        orderInfo: {},
                        userInfo: {}
                    };
                },
                onLoad: function(e) {
                    e.id ? this.getOrderInfo(e.id) : this.$common.errorToShow("参数异常");
                },
                created: function() {
                    var o = this;
                    e.getSystemInfo({
                        success: function(e) {
                            [ "X", "XR", "XS", "11", "12", "13", "14", "15" ].forEach(function(r) {
                                -1 != e.model.indexOf(r) && -1 != e.model.indexOf("iPhone") && (o.paddingBottomHeight = 40);
                            });
                        }
                    });
                    var r = getCurrentPages();
                    this.urlPath = "/" + r[0].route;
                },
                methods: {
                    getUserInfo: function() {
                        var e = this;
                        this.$api.default.request("user/userInfo", {
                            uid: this.uid
                        }).then(function(o) {
                            o.code ? (e.userInfo = o.user, o.user.is_writer || (e.navIndex = 3), e.getList()) : e.$common.errorToShow(o.msg);
                        });
                    },
                    toImRoom: function() {
                        if (console.log(133333333333), this.$db.get("userInfo").membe_id == this.orderInfo.writer_uid) {
                            console.log(0x650e124ef1c7), this.$store.commit("createConversationActive", this.orderInfo.uid);
                            var o = "/pages/tim/room?userType=1&showbox=1&uid=" + this.orderInfo.writer_uid;
                        } else console.log(22222222222), this.$store.commit("createConversationActive", this.orderInfo.writer_uid), 
                        o = "/pages/tim/room?userType=1&showbox=1&uid=" + this.orderInfo.uid;
                        e.redirectTo({
                            url: o
                        });
                    },
                    goToxie: function() {
                        e.navigateTo({
                            url: "/pages/webview/webview?url=" + this.$config.default.Url + "/agreement/1000002"
                        });
                    },
                    submit: function() {
                        var o = this;
                        2 == this.orderInfo.status || 3 == this.orderInfo.status ? e.navigateTo({
                            url: "/pages/my/upload?id=" + this.orderInfo.id
                        }) : this.$api.default.request("order/confirmOrder", {
                            id: this.orderInfo.id
                        }).then(function(e) {
                            e.code ? o.$common.successToShow(e.msg, function() {
                                o.orderInfo = e.data;
                            }) : o.$common.errorToShow(e.msg);
                        });
                    },
                    getOrderInfo: function(e) {
                        var o = this;
                        this.$api.default.request("order/orderInfo", {
                            id: e
                        }).then(function(e) {
                            e.code ? o.orderInfo = e.data : o.$common.errorToShow(e.msg);
                        });
                    },
                    open: function() {},
                    close: function() {
                        this.show = !1;
                    },
                    goToindex: function() {
                        var o = this;
                        this.$api.default.request("order/closeOrder", {
                            id: this.orderInfo.id
                        }).then(function(r) {
                            r.code ? o.$common.successToShow(r.msg, function() {
                                e.navigateBack({
                                    delta: 1
                                });
                            }) : o.$common.errorToShow(r.msg);
                        });
                    }
                }
            };
            o.default = r;
        }).call(this, r(2).default);
    },
    770: function(e, o, r) {
        "use strict";
        r.r(o);
        var n = r(771), t = r.n(n);
        for (var i in n) [ "default" ].indexOf(i) < 0 && function(e) {
            r.d(o, e, function() {
                return n[e];
            });
        }(i);
        o.default = t.a;
    },
    771: function(e, o, r) {}
}, [ [ 764, "common/runtime", "common/vendor" ] ] ]);