(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/tim/userinfo" ], {
    724: function(e, n, r) {
        "use strict";
        (function(e, n) {
            var t = r(4);
            r(26), t(r(25));
            var o = t(r(725));
            e.__webpack_require_UNI_MP_PLUGIN__ = r, n(o.default);
        }).call(this, r(1).default, r(2).createPage);
    },
    725: function(e, n, r) {
        "use strict";
        r.r(n);
        var t = r(726), o = r(728);
        for (var i in o) [ "default" ].indexOf(i) < 0 && function(e) {
            r.d(n, e, function() {
                return o[e];
            });
        }(i);
        r(730);
        var u = r(33), s = Object(u.default)(o.default, t.render, t.staticRenderFns, !1, null, null, null, !1, t.components, void 0);
        s.options.__file = "pages/tim/userinfo.vue", n.default = s.exports;
    },
    726: function(e, n, r) {
        "use strict";
        r.r(n);
        var t = r(727);
        r.d(n, "render", function() {
            return t.render;
        }), r.d(n, "staticRenderFns", function() {
            return t.staticRenderFns;
        }), r.d(n, "recyclableRender", function() {
            return t.recyclableRender;
        }), r.d(n, "components", function() {
            return t.components;
        });
    },
    727: function(e, n, r) {
        "use strict";
        var t;
        r.r(n), r.d(n, "render", function() {
            return o;
        }), r.d(n, "staticRenderFns", function() {
            return u;
        }), r.d(n, "recyclableRender", function() {
            return i;
        }), r.d(n, "components", function() {
            return t;
        });
        try {
            t = {
                uSwitch: function() {
                    return Promise.all([ r.e("common/vendor"), r.e("node-modules/uview-ui/components/u-switch/u-switch") ]).then(r.bind(null, 936));
                },
                uPopup: function() {
                    return Promise.all([ r.e("common/vendor"), r.e("node-modules/uview-ui/components/u-popup/u-popup") ]).then(r.bind(null, 890));
                }
            };
        } catch (e) {
            if (-1 === e.message.indexOf("Cannot find module") || -1 === e.message.indexOf(".vue")) throw e;
            console.error(e.message), console.error("1. 排查组件名称拼写是否正确"), console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"), 
            console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件");
        }
        var o = function() {
            var e = this, n = (e.$createElement, e._self._c, Object.keys(e.userInfo).length), r = n > 0 ? e._f("formatImgUrl")(e.userInfo.pic) : null, t = n > 0 && e.userInfo.is_writer ? e.$options.filters.formatImgUrl(e.userInfo.writer_level.is_active ? e.userInfo.writer_level.level.image : e.userInfo.writer_level.level.hide_img) : null, o = n > 0 && e.userInfo.is_vip ? e.$options.filters.formatImgUrl(e.userInfo.user_level.is_active ? e.userInfo.user_level.level.image : e.userInfo.user_level.level.hide_img) : null, i = n > 0 ? e._f("formatImgUrl")("/images/rarr.png") : null, u = n > 0 ? e._f("formatImgUrl")("/images/jia1.png") : null, s = n > 0 ? e._f("formatImgUrl")("/images/rarr.png") : null, c = n > 0 ? e._f("formatImgUrl")("/images/rarr.png") : null;
            e._isMounted || (e.e0 = function(e) {
                this.show = !0;
            }, e.e1 = function(n) {
                e.show = !1;
            }), e.$mp.data = Object.assign({}, {
                $root: {
                    g0: n,
                    f0: r,
                    g1: t,
                    g2: o,
                    f1: i,
                    f2: u,
                    f3: s,
                    f4: c
                }
            });
        }, i = !1, u = [];
        o._withStripped = !0;
    },
    728: function(e, n, r) {
        "use strict";
        r.r(n);
        var t = r(729), o = r.n(t);
        for (var i in t) [ "default" ].indexOf(i) < 0 && function(e) {
            r.d(n, e, function() {
                return t[e];
            });
        }(i);
        n.default = o.a;
    },
    729: function(e, n, r) {
        "use strict";
        (function(e) {
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var r = {
                data: function() {
                    return {
                        type: 0,
                        array: this.$db.get("config").word_count_label,
                        index: 0,
                        value: !1,
                        show: !1,
                        userInfo: {},
                        uid: 0
                    };
                },
                onLoad: function(e) {
                    this.uid = e.id;
                },
                onShow: function() {
                    this.getUserInfo();
                },
                methods: {
                    del_msg: function() {
                        this.show = !1;
                        var n = this;
                        e.showModal({
                            confirmColor: "#45C4B0",
                            content: "是否确定删除该会话",
                            success: function(r) {
                                r.confirm ? n.$api.default.request("user/delmsg", {
                                    uid: n.uid
                                }).then(function(r) {
                                    r.code && (n.$common.errorToShow(r.msg), setTimeout(function() {
                                        e.reLaunch({
                                            url: "/pages/tim/record"
                                        });
                                    }, 500));
                                }) : r.cancel;
                            }
                        });
                    },
                    saveWriterUserConfig: function() {
                        var e = this;
                        e.$api.default.request("user/black_c", {
                            uid: e.uid
                        }).then(function(n) {
                            n.code && e.$common.errorToShow(n.msg);
                        });
                    },
                    setdata: function(e) {
                        this.type = e, this.show = !0;
                    },
                    setting: function() {
                        var e = this, n = {
                            username: this.userInfo.username,
                            id: this.userInfo.membe_id
                        };
                        n.username ? this.$api.default.request("user/saveUserbeizhu", n).then(function(n) {
                            1 == n.code && e.$common.successToShow(n.msg, function() {
                                e.show = !1;
                            });
                        }) : this.$common.errorToShow("请输入备注", function() {}, 1e3);
                    },
                    submit: function() {
                        e.navigateTo({
                            url: "/pages/find/report?id=" + this.userInfo.membe_id + "&type=88"
                        });
                    },
                    getUserInfo: function() {
                        var e = this;
                        this.$api.default.request("user/userInfo_friend", {
                            uid: this.uid
                        }, "POST", !1).then(function(n) {
                            n.code && (e.userInfo = n.user, e.userInfo.writer_user_config.word_count = e.userInfo.writer_user_config.word_count ? e.userInfo.writer_user_config.word_count : e.array[0], 
                            e.array.forEach(function(r, t) {
                                n.user.writer_user_config.word_count == r && (e.index = t);
                            }));
                        });
                    },
                    change: function(n) {
                        e.showLoading({
                            title: "加载中",
                            mask: !0
                        }), this.$api.default.request("user/setUserRolue", {
                            type: n
                        }).then(function(n) {
                            e.hideLoading();
                        });
                    },
                    open: function() {},
                    close: function() {
                        this.show = !1;
                    },
                    bindPickerChange: function(e) {
                        console.log("picker发送选择改变，携带值为", e.detail.value), this.index = e.detail.value, this.userInfo.writer_user_config.word_count = this.array[e.detail.value];
                    }
                }
            };
            n.default = r;
        }).call(this, r(2).default);
    },
    730: function(e, n, r) {
        "use strict";
        r.r(n);
        var t = r(731), o = r.n(t);
        for (var i in t) [ "default" ].indexOf(i) < 0 && function(e) {
            r.d(n, e, function() {
                return t[e];
            });
        }(i);
        n.default = o.a;
    },
    731: function(e, n, r) {}
}, [ [ 724, "common/runtime", "common/vendor" ] ] ]);