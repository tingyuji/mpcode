(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/tim/room" ], {
    716: function(e, i, t) {
        "use strict";
        (function(e, i) {
            var s = t(4);
            t(26), s(t(25));
            var n = s(t(717));
            e.__webpack_require_UNI_MP_PLUGIN__ = t, i(n.default);
        }).call(this, t(1).default, t(2).createPage);
    },
    717: function(e, i, t) {
        "use strict";
        t.r(i);
        var s = t(718), n = t(720);
        for (var o in n) [ "default" ].indexOf(o) < 0 && function(e) {
            t.d(i, e, function() {
                return n[e];
            });
        }(o);
        t(722);
        var r = t(33), g = Object(r.default)(n.default, s.render, s.staticRenderFns, !1, null, null, null, !1, s.components, void 0);
        g.options.__file = "pages/tim/room.vue", i.default = g.exports;
    },
    718: function(e, i, t) {
        "use strict";
        t.r(i);
        var s = t(719);
        t.d(i, "render", function() {
            return s.render;
        }), t.d(i, "staticRenderFns", function() {
            return s.staticRenderFns;
        }), t.d(i, "recyclableRender", function() {
            return s.recyclableRender;
        }), t.d(i, "components", function() {
            return s.components;
        });
    },
    719: function(e, i, t) {
        "use strict";
        var s;
        t.r(i), t.d(i, "render", function() {
            return n;
        }), t.d(i, "staticRenderFns", function() {
            return r;
        }), t.d(i, "recyclableRender", function() {
            return o;
        }), t.d(i, "components", function() {
            return s;
        });
        try {
            s = {
                uSteps: function() {
                    return Promise.all([ t.e("common/vendor"), t.e("node-modules/uview-ui/components/u-steps/u-steps") ]).then(t.bind(null, 962));
                },
                uStepsItem: function() {
                    return Promise.all([ t.e("common/vendor"), t.e("node-modules/uview-ui/components/u-steps-item/u-steps-item") ]).then(t.bind(null, 970));
                }
            };
        } catch (e) {
            if (-1 === e.message.indexOf("Cannot find module") || -1 === e.message.indexOf(".vue")) throw e;
            console.error(e.message), console.error("1. 排查组件名称拼写是否正确"), console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"), 
            console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件");
        }
        var n = function() {
            var e = this, i = (e.$createElement, e._self._c, e.orderList.length), t = "administrator" !== e.toUserId && "hudongmsg" !== e.toUserId && "pinglunmsg" !== e.toUserId && e.orderList.length, s = t ? e.__map(e.orderList, function(i, t) {
                return {
                    $orig: e.__get_orig(i),
                    f0: i.uid == e.userInfo.membe_id ? e._f("formatImgUrl")(i.writer.pic) : null,
                    f1: i.writer_uid == e.userInfo.membe_id ? e._f("formatImgUrl")(i.user.pic) : null,
                    g2: i.uid == e.userInfo.membe_id && i.writer.is_writer && i.writer.writer_level.level ? e.$options.filters.formatImgUrl(i.writer.writer_level.is_active ? i.writer.writer_level.level.image : i.writer.writer_level.level.hide_img) : null,
                    g3: i.uid == e.userInfo.membe_id && i.writer.is_vip && i.writer.user_level.is_active ? e.$options.filters.formatImgUrl(i.writer.user_level.active_day > 0 ? i.writer.user_level.level.image : i.writer.user_level.level.hide_img) : null,
                    g4: i.writer_uid == e.userInfo.membe_id && i.user.is_writer && i.user.writer_level.level ? e.$options.filters.formatImgUrl(i.user.writer_level.is_active ? i.user.writer_level.level.image : i.user.writer_level.level.hide_img) : null,
                    g5: i.writer_uid == e.userInfo.membe_id && i.user.is_vip && i.user.user_level.is_active ? e.$options.filters.formatImgUrl(i.user.user_level.active_day ? i.user.user_level.level.image : i.user.user_level.level.hide_img) : null,
                    f2: e._f("formatImgUrl")("/images/she.png")
                };
            }) : null, n = "administrator" !== e.toUserId && "hudongmsg" !== e.toUserId && "pinglunmsg" !== e.toUserId && !e.orderList.length && e.conversationActive.user.is_writer, o = n ? e._f("formatImgUrl")(e.conversationActive.user.pic) : null, r = n && e.conversationActive.user.is_writer ? e.$options.filters.formatImgUrl(e.conversationActive.user.writer_level.is_active ? e.conversationActive.user.writer_level.level.image : e.conversationActive.user.writer_level.level.hide_img) : null, g = n && e.conversationActive.user.is_vip && e.conversationActive.user.user_level.is_active ? e.$options.filters.formatImgUrl(e.conversationActive.user.user_level.active_day > 0 ? e.conversationActive.user.user_level.level.image : e.conversationActive.user.user_level.level.hide_img) : null, a = n ? e._f("formatImgUrl")("/images/she.png") : null, f = "administrator" !== e.toUserId && "hudongmsg" !== e.toUserId && "pinglunmsg" !== e.toUserId && e.conversationActive.user.is_writer && !e.orderList.length, c = e.orderList.length, l = e.__map(e.msgList, function(i, t) {
                return {
                    $orig: e.__get_orig(i),
                    m0: "out" == i.flow && i.type == e.TIM.TYPES.MSG_TEXT ? e.nodesFliter(i.payload.text) : null,
                    f5: "out" == i.flow ? e._f("formatImgUrl")(e.userInfo.pic) : null,
                    g11: "out" != i.flow && e.conversationActive.user && e.conversationActive.user.pic ? e.$options.filters.formatImgUrl(e.conversationActive.user.pic) : null,
                    m1: "out" != i.flow ? e.timeFliter(i.time) : null,
                    m2: "out" != i.flow && i.type == e.TIM.TYPES.MSG_TEXT ? e.nodesFliter(i.payload.text) : null
                };
            }), u = e.__map(e.emojiList, function(i, t) {
                return {
                    $orig: e.__get_orig(i),
                    l2: e.__map(i, function(i, t) {
                        return {
                            $orig: e.__get_orig(i),
                            f6: e._f("formatImgUrl")("/emoji/" + i.url)
                        };
                    })
                };
            });
            e._isMounted || (e.e0 = function(i, t) {
                var s;
                return t = ((s = arguments[arguments.length - 1].currentTarget.dataset).eventParams || s["event-params"]).item, 
                e.$common.previewImage(t.payload.imageInfoArray[0].url, e.msgImgList);
            }, e.e1 = function(i, t) {
                var s;
                return t = ((s = arguments[arguments.length - 1].currentTarget.dataset).eventParams || s["event-params"]).item, 
                e.$common.previewImage(t.payload.imageInfoArray[0].url, e.msgImgList);
            }), e.$mp.data = Object.assign({}, {
                $root: {
                    g0: i,
                    g1: t,
                    l0: s,
                    g6: n,
                    f3: o,
                    g7: r,
                    g8: g,
                    f4: a,
                    g9: f,
                    g10: c,
                    l1: l,
                    l3: u
                }
            });
        }, o = !1, r = [];
        n._withStripped = !0;
    },
    720: function(e, i, t) {
        "use strict";
        t.r(i);
        var s = t(721), n = t.n(s);
        for (var o in s) [ "default" ].indexOf(o) < 0 && function(e) {
            t.d(i, e, function() {
                return s[e];
            });
        }(o);
        i.default = n.a;
    },
    721: function(e, i, t) {
        "use strict";
        (function(e) {
            var s = t(4);
            Object.defineProperty(i, "__esModule", {
                value: !0
            }), i.default = void 0;
            var n = s(t(11)), o = t(30);
            function r(e, i) {
                var t = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var s = Object.getOwnPropertySymbols(e);
                    i && (s = s.filter(function(i) {
                        return Object.getOwnPropertyDescriptor(e, i).enumerable;
                    })), t.push.apply(t, s);
                }
                return t;
            }
            var g = (0, n.default)({
                data: function() {
                    return {
                        paddingBottomHeight: 0,
                        showbox: 1,
                        userType: 0,
                        isValue: !0,
                        conversationActive: {
                            user: {
                                is_writer: 0,
                                is_vip: 0
                            }
                        },
                        toUserId: "",
                        toUserInfo: null,
                        userInfo: this.$db.get("userInfo"),
                        nextReqMessageID: "",
                        count: 15,
                        isCompleted: "",
                        msgList: [],
                        TIM: null,
                        textMsg: "",
                        isHistoryLoading: !1,
                        scrollAnimation: !1,
                        scrollTop: 0,
                        scrollToView: "",
                        msgImgList: [],
                        myuid: 0,
                        RECORDER: e.getRecorderManager(),
                        isVoice: !1,
                        voiceTis: "按住 说话",
                        recordTis: "手指上滑 取消发送",
                        recording: !1,
                        willStop: !1,
                        initPoint: {
                            identifier: 0,
                            Y: 0
                        },
                        recordTimer: null,
                        recordLength: 0,
                        AUDIO: e.createInnerAudioContext(),
                        playMsgid: null,
                        VoiceTimer: null,
                        popupLayerClass: "",
                        hideMore: !0,
                        hideEmoji: !0,
                        emojiList: this.$commen.emojiList,
                        onlineEmoji: {
                            "100.gif": "AbNQgA.gif",
                            "101.gif": "AbN3ut.gif",
                            "102.gif": "AbNM3d.gif",
                            "103.gif": "AbN8DP.gif",
                            "104.gif": "AbNljI.gif",
                            "105.gif": "AbNtUS.gif",
                            "106.gif": "AbNGHf.gif",
                            "107.gif": "AbNYE8.gif",
                            "108.gif": "AbNaCQ.gif",
                            "109.gif": "AbNN4g.gif",
                            "110.gif": "AbN0vn.gif",
                            "111.gif": "AbNd3j.gif",
                            "112.gif": "AbNsbV.gif",
                            "113.gif": "AbNwgs.gif",
                            "114.gif": "AbNrD0.gif",
                            "115.gif": "AbNDuq.gif",
                            "116.gif": "AbNg5F.gif",
                            "117.gif": "AbN6ET.gif",
                            "118.gif": "AbNcUU.gif",
                            "119.gif": "AbNRC4.gif",
                            "120.gif": "AbNhvR.gif",
                            "121.gif": "AbNf29.gif",
                            "122.gif": "AbNW8J.gif",
                            "123.gif": "AbNob6.gif",
                            "124.gif": "AbN5K1.gif",
                            "125.gif": "AbNHUO.gif",
                            "126.gif": "AbNIDx.gif",
                            "127.gif": "AbN7VK.gif",
                            "128.gif": "AbNb5D.gif",
                            "129.gif": "AbNX2d.gif",
                            "130.gif": "AbNLPe.gif",
                            "131.gif": "AbNjxA.gif",
                            "132.gif": "AbNO8H.gif",
                            "133.gif": "AbNxKI.gif",
                            "134.gif": "AbNzrt.gif",
                            "135.gif": "AbU9Vf.gif",
                            "136.gif": "AbUSqP.gif",
                            "137.gif": "AbUCa8.gif",
                            "138.gif": "AbUkGQ.gif",
                            "139.gif": "AbUFPg.gif",
                            "140.gif": "AbUPIS.gif",
                            "141.gif": "AbUZMn.gif",
                            "142.gif": "AbUExs.gif",
                            "143.gif": "AbUA2j.gif",
                            "144.gif": "AbUMIU.gif",
                            "145.gif": "AbUerq.gif",
                            "146.gif": "AbUKaT.gif",
                            "147.gif": "AbUmq0.gif",
                            "148.gif": "AbUuZV.gif",
                            "149.gif": "AbUliF.gif",
                            "150.gif": "AbU1G4.gif",
                            "151.gif": "AbU8z9.gif",
                            "152.gif": "AbU3RJ.gif",
                            "153.gif": "AbUYs1.gif",
                            "154.gif": "AbUJMR.gif",
                            "155.gif": "AbUadK.gif",
                            "156.gif": "AbUtqx.gif",
                            "157.gif": "AbUUZ6.gif",
                            "158.gif": "AbUBJe.gif",
                            "159.gif": "AbUdIO.gif",
                            "160.gif": "AbU0iD.gif",
                            "161.gif": "AbUrzd.gif",
                            "162.gif": "AbUDRH.gif",
                            "163.gif": "AbUyQA.gif",
                            "164.gif": "AbUWo8.gif",
                            "165.gif": "AbU6sI.gif",
                            "166.gif": "AbU2eP.gif",
                            "167.gif": "AbUcLt.gif",
                            "168.gif": "AbU4Jg.gif",
                            "169.gif": "AbURdf.gif",
                            "170.gif": "AbUhFS.gif",
                            "171.gif": "AbU5WQ.gif",
                            "172.gif": "AbULwV.gif",
                            "173.gif": "AbUIzj.gif",
                            "174.gif": "AbUTQs.gif",
                            "175.gif": "AbU7yn.gif",
                            "176.gif": "AbUqe0.gif",
                            "177.gif": "AbUHLq.gif",
                            "178.gif": "AbUOoT.gif",
                            "179.gif": "AbUvYF.gif",
                            "180.gif": "AbUjFU.gif",
                            "181.gif": "AbaSSJ.gif",
                            "182.gif": "AbUxW4.gif",
                            "183.gif": "AbaCO1.gif",
                            "184.gif": "Abapl9.gif",
                            "185.gif": "Aba9yR.gif",
                            "186.gif": "AbaFw6.gif",
                            "187.gif": "Abaiex.gif",
                            "188.gif": "AbakTK.gif",
                            "189.gif": "AbaZfe.png",
                            "190.gif": "AbaEFO.gif",
                            "191.gif": "AbaVYD.gif",
                            "192.gif": "AbamSH.gif",
                            "193.gif": "AbaKOI.gif",
                            "194.gif": "Abanld.gif",
                            "195.gif": "Abau6A.gif",
                            "196.gif": "AbaQmt.gif",
                            "197.gif": "Abal0P.gif",
                            "198.gif": "AbatpQ.gif",
                            "199.gif": "Aba1Tf.gif",
                            "200.png": "Aba8k8.png",
                            "201.png": "AbaGtS.png",
                            "202.png": "AbaJfg.png",
                            "203.png": "AbaNlj.png",
                            "204.png": "Abawmq.png",
                            "205.png": "AbaU6s.png",
                            "206.png": "AbaaXn.png",
                            "207.png": "Aba000.png",
                            "208.png": "AbarkT.png",
                            "209.png": "AbastU.png",
                            "210.png": "AbaB7V.png",
                            "211.png": "Abafn1.png",
                            "212.png": "Abacp4.png",
                            "213.png": "AbayhF.png",
                            "214.png": "Abag1J.png",
                            "215.png": "Aba2c9.png",
                            "216.png": "AbaRXR.png",
                            "217.png": "Aba476.png",
                            "218.png": "Abah0x.png",
                            "219.png": "Abdg58.png"
                        },
                        windowsState: "",
                        redenvelopeData: {
                            rid: null,
                            from: null,
                            face: null,
                            blessing: null,
                            money: null
                        },
                        friendList: [],
                        showpica: !0,
                        showElement: !1,
                        orderInfo: {},
                        topUserInfo: {},
                        goodList: {},
                        orderList: []
                    };
                },
                computed: function(e) {
                    for (var i = 1; i < arguments.length; i++) {
                        var t = null != arguments[i] ? arguments[i] : {};
                        i % 2 ? r(Object(t), !0).forEach(function(i) {
                            (0, n.default)(e, i, t[i]);
                        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : r(Object(t)).forEach(function(i) {
                            Object.defineProperty(e, i, Object.getOwnPropertyDescriptor(t, i));
                        });
                    }
                    return e;
                }({}, (0, o.mapState)({
                    currentMessageList: function(e) {
                        return e.currentMessageList;
                    },
                    currentFriendList: function(e) {
                        return e.friendList;
                    }
                })),
                watch: {
                    currentMessageList: function(e, i) {
                        var t = this;
                        this.msgList = e, console.log("newVal", e);
                        var s = [];
                        e.forEach(function(e, i) {
                            e.type == t.TIM.TYPES.MSG_IMAGE && (console.log(i, e.payload), s.push(e.payload.imageInfoArray[0].url));
                        }), console.log("msgImgList", s), this.msgImgList = s, this.screenMsg(e, i);
                    },
                    currentFriendList: function(e, i) {
                        this.friendList = e;
                    },
                    toUserInfo: function(i, t) {
                        var s = i.nick ? i.nick : this.$options.filters.makeNickName(i.userID);
                        e.setNavigationBarTitle({
                            title: s
                        });
                    },
                    textMsg: function(e) {
                        this.showElement = !!e;
                    }
                },
                created: {},
                onLoad: function(e) {
                    var i = this;
                    this.toUserId = this.$store.state.toUserId ? this.$store.state.toUserId : this.$store.state.conversationActive.userProfile.userID, 
                    this.getUserProfile(), this.conversationActive = this.$store.state.conversationActive, 
                    "administrator" !== this.toUserId && "hudongmsg" !== this.toUserId && "pinglunmsg" !== this.toUserId && this.getUserInfo(this.toUserId), 
                    this.TIM = this.$TIM, this.getMsgList(), this.AUDIO.onEnded(function(e) {
                        i.playMsgid = null;
                    }), this.RECORDER.onStart(function(e) {
                        i.recordBegin(e);
                    }), this.RECORDER.onStop(function(e) {
                        i.recordEnd(e);
                    }), this.getOrderList(), this.getGoodList(this.toUserId);
                },
                onShow: function() {
                    this.scrollTop = 9999999, "administrator" !== this.toUserId && "hudongmsg" !== this.toUserId && "pinglunmsg" !== this.toUserId && this.getUserInfo(this.toUserId);
                },
                onUnload: function() {
                    this.tim.setMessageRead({
                        conversationID: this.conversationActive.conversationID
                    }).then(function(e) {
                        console.log("全部已读");
                    }).catch(function(e) {
                        console.warn("setMessageRead error:", e);
                    });
                },
                methods: {
                    goTomy: function() {
                        "administrator" != this.conversationActive.userProfile.userID && "hudongmsg" != this.conversationActive.userProfile.userID && "pinglunmsg" != this.conversationActive.userProfile.userID && e.navigateTo({
                            url: "/pages/tim/userinfo?id=" + this.conversationActive.user.membe_id
                        });
                    },
                    getOrderList: function() {
                        var e = this;
                        this.$api.default.request("order/getTimOrderList", {
                            uid: this.toUserId
                        }).then(function(i) {
                            i.code && (e.orderList = i.data);
                        });
                    },
                    getUserInfo: function(e) {
                        var i = this;
                        this.$api.default.request("user/userInfo_friend_info", {
                            uid: e
                        }).then(function(e) {
                            e.code && (i.conversationActive.user = e.user);
                        });
                    },
                    getGoodList: function(e) {
                        var i = this;
                        this.$api.default.request("user/userPageList", {
                            uid: e,
                            page: 1,
                            type: 1
                        }).then(function(e) {
                            e.code && (i.goodList = e.data.data);
                        });
                    },
                    getOrderInfo: function(e) {
                        var i = this;
                        this.$api.default.request("order/orderInfo", {
                            id: e
                        }).then(function(e) {
                            e.code && (i.orderInfo = e.data);
                        });
                    },
                    handleInputChange: function() {
                        this.textMsg ? (this.showElement = !0, this.showpica = !1) : (this.showElement = !1, 
                        this.showpica = !0);
                    },
                    getUserProfile: function() {
                        var e = this;
                        this.tim.getUserProfile({
                            userIDList: [ this.toUserId ]
                        }).then(function(i) {
                            console.log("用户资料", i.data[0]), e.toUserInfo = i.data[0];
                        }).catch(function(e) {
                            console.warn("getUserProfile error:", e);
                        });
                    },
                    nodesFliter: function(e) {
                        return '<div style="align-items: center;word-wrap:break-word;">' + e + "</div>";
                    },
                    timeFliter: function(e) {
                        var i = new Date(1e3 * e);
                        return this.$commen.dateTimeFliter(i);
                    },
                    screenMsg: function(e, i) {
                        var t = this;
                        console.log("newVal", e), console.log("oldVal", i), e.length && i.length ? e[0].ID != i[0].ID && e.length >= this.count ? this.$nextTick(function() {
                            t.scrollToView = i[0].ID;
                        }) : this.$nextTick(function() {
                            t.scrollToView = e[e.length - 1].ID;
                        }) : this.$nextTick(function() {
                            e.length && (t.scrollToView = e[e.length - 1].ID);
                        }), e.length && (this.nextReqMessageID = e[0].ID);
                    },
                    loadHistory: function(e) {
                        var i = this, t = this.conversationActive.conversationID;
                        this.tim.getMessageList({
                            conversationID: t,
                            nextReqMessageID: this.nextReqMessageID,
                            count: this.count
                        }).then(function(e) {
                            i.$store.commit("unshiftCurrentMessageList", e.data.messageList), i.nextReqMessageID = e.data.nextReqMessageID, 
                            i.isCompleted = e.data.isCompleted;
                        }), this.$nextTick(function() {
                            this.scrollToView = this.nextReqMessageID, this.$nextTick(function() {
                                this.scrollAnimation = !0;
                            });
                        }), this.isHistoryLoading = !1;
                    },
                    getMsgList: function() {
                        var e = this, i = this.conversationActive.conversationID;
                        this.tim.getMessageList({
                            conversationID: i,
                            count: this.count
                        }).then(function(i) {
                            e.$store.commit("pushCurrentMessageList", i.data.messageList), e.nextReqMessageID = i.data.nextReqMessageID, 
                            e.isCompleted = i.data.isCompleted, i.data.messageList.length && (e.scrollToView = i.data.messageList[i.data.messageList.length - 1].ID);
                        });
                        var t = this;
                        setTimeout(function() {
                            t.scrollTop = 9999;
                        }, 250);
                    },
                    setPicSize: function(i) {
                        var t = e.upx2px(350), s = e.upx2px(350);
                        if (i.w > t || i.h > s) {
                            var n = i.w / i.h;
                            i.w = n > 1 ? t : s * n, i.h = n > 1 ? t / n : s;
                        }
                        return i;
                    },
                    showMore: function() {
                        this.isVoice = !1, this.hideEmoji = !0, this.hideMore ? (this.hideMore = !1, this.openDrawer()) : this.hideDrawer();
                    },
                    openDrawer: function() {
                        this.popupLayerClass = "showLayer";
                    },
                    hideDrawer: function() {
                        var e = this;
                        this.popupLayerClass = "", setTimeout(function() {
                            e.hideMore = !0, e.hideEmoji = !0;
                        }, 150);
                    },
                    chooseImage: function() {
                        this.getImage("album");
                    },
                    camera: function() {
                        this.getImage("camera");
                    },
                    handRedEnvelopes: function() {
                        e.navigateTo({
                            url: "HM-hand/HM-hand"
                        }), this.hideDrawer();
                    },
                    getImage: function(i) {
                        console.log(i), this.hideDrawer();
                        var t = this;
                        e.chooseMedia({
                            sizeType: [ "original", "compressed" ],
                            sourceType: [ i ],
                            success: function(e) {
                                console.log("res", e), t.sendMsg(e, e.type);
                            }
                        });
                    },
                    chooseEmoji: function() {
                        this.hideMore = !0, this.hideEmoji ? (this.hideEmoji = !1, this.openDrawer()) : this.hideDrawer();
                    },
                    addEmoji: function(e) {
                        this.textMsg += e.alt;
                    },
                    textareaFocus: function() {
                        "showLayer" == this.popupLayerClass && 0 == this.hideMore && this.hideDrawer();
                    },
                    sendText: function() {
                        if (this.hideDrawer(), this.textMsg) {
                            var e = {
                                text: this.replaceEmoji(this.textMsg)
                            };
                            this.sendMsg(e, "text"), this.textMsg = "", this.handleInputChange();
                        }
                    },
                    replaceEmoji: function(e) {
                        var i = this;
                        return e.replace(/\[([^(\]|\[)]*)\]/g, function(e, t) {
                            console.log("item: " + e);
                            for (var s = 0; s < i.emojiList.length; s++) for (var n = i.emojiList[s], o = 0; o < n.length; o++) {
                                var r = n[o];
                                if (r.alt == e) {
                                    var g = '<img src="https://s2.ax1x.com/2019/04/12/' + i.onlineEmoji[r.url] + '">';
                                    return console.log("imgstr: " + g), g;
                                }
                            }
                        });
                    },
                    sendMsg: function(e, i) {
                        var t = this;
                        if ("text" == i) var s = this.tim.createTextMessage({
                            to: this.toUserId,
                            conversationType: "C2C",
                            payload: {
                                text: e.text
                            }
                        });
                        "image" == i && (s = this.tim.createImageMessage({
                            to: this.toUserId,
                            conversationType: "C2C",
                            payload: {
                                file: e
                            },
                            onProgress: function(e) {
                                console.log("file uploading:", e);
                            }
                        })), "video" == i && (s = this.tim.createVideoMessage({
                            to: this.toUserId,
                            conversationType: "C2C",
                            payload: {
                                file: e
                            },
                            onProgress: function(e) {
                                console.log("file uploading:", e);
                            }
                        })), this.$store.commit("pushCurrentMessageList", s), this.tim.sendMessage(s).then(function(e) {
                            t.$nextTick(function() {
                                t.scrollToView = e.data.message.ID;
                            });
                        });
                    },
                    addTextMsg: function(e) {
                        this.msgList.push(e);
                    },
                    addVoiceMsg: function(e) {
                        this.msgList.push(e);
                    },
                    addImgMsg: function(e) {
                        this.msgImgList.push(e.imageUrl);
                    },
                    addRedEnvelopeMsg: function(e) {
                        this.msgList.push(e);
                    },
                    addSystemTextMsg: function(e) {
                        this.msgList.push(e);
                    },
                    addSystemRedEnvelopeMsg: function(e) {
                        this.msgList.push(e);
                    },
                    openRedEnvelope: function(i, t) {
                        var s = this, n = i.content.rid;
                        e.showLoading({
                            title: "加载中..."
                        }), console.log("index: " + t), setTimeout(function() {
                            0 == n ? s.redenvelopeData = {
                                rid: 0,
                                from: "大黑哥",
                                face: "/static/img/im/face/face.jpg",
                                blessing: "恭喜发财，大吉大利",
                                money: "已领完"
                            } : (s.redenvelopeData = {
                                rid: 1,
                                from: "售后客服008",
                                face: "/static/img/im/face/face_2.jpg",
                                blessing: "恭喜发财",
                                money: "0.01"
                            }, i.content.isReceived || (s.sendSystemMsg({
                                text: "你领取了" + (i.userinfo.uid == s.myuid ? "自己" : i.userinfo.username) + "的红包"
                            }, "redEnvelope"), console.log("this.msgList[index]: " + JSON.stringify(s.msgList[t])), 
                            s.msgList[t].msg.content.isReceived = !0)), e.hideLoading(), s.windowsState = "show";
                        }, 200);
                    },
                    closeRedEnvelope: function() {
                        var e = this;
                        this.windowsState = "hide", setTimeout(function() {
                            e.windowsState = "";
                        }, 200);
                    },
                    sendSystemMsg: function(e, i) {
                        var t = this.msgList[this.msgList.length - 1].msg.id, s = {
                            type: "system",
                            msg: {
                                id: ++t,
                                type: i,
                                content: e
                            }
                        };
                        this.screenMsg(s);
                    },
                    toDetails: function(i) {
                        e.navigateTo({
                            url: "HM-details/HM-details?rid=" + i
                        });
                    },
                    showPic: function(i) {
                        e.previewImage({
                            indicator: "none",
                            current: i.content.url,
                            urls: this.msgImgList
                        });
                    },
                    playVoice: function(e) {
                        this.playMsgid = e.id, this.AUDIO.src = e.content.url, this.$nextTick(function() {
                            this.AUDIO.play();
                        });
                    },
                    voiceBegin: function(e) {
                        e.touches.length > 1 || (this.initPoint.Y = e.touches[0].clientY, this.initPoint.identifier = e.touches[0].identifier, 
                        this.RECORDER.start({
                            format: "mp3"
                        }));
                    },
                    recordBegin: function(e) {
                        var i = this;
                        this.recording = !0, this.voiceTis = "松开 结束", this.recordLength = 0, this.recordTimer = setInterval(function() {
                            i.recordLength++;
                        }, 1e3);
                    },
                    voiceCancel: function() {
                        this.recording = !1, this.voiceTis = "按住 说话", this.recordTis = "手指上滑 取消发送", this.willStop = !0, 
                        this.RECORDER.stop();
                    },
                    voiceIng: function(i) {
                        if (this.recording) {
                            var t = i.touches[0];
                            this.initPoint.Y - t.clientY >= e.upx2px(100) ? (this.willStop = !0, this.recordTis = "松开手指 取消发送") : (this.willStop = !1, 
                            this.recordTis = "手指上滑 取消发送");
                        }
                    },
                    voiceEnd: function(e) {
                        this.recording && (this.recording = !1, this.voiceTis = "按住 说话", this.recordTis = "手指上滑 取消发送", 
                        this.RECORDER.stop());
                    },
                    recordEnd: function(e) {
                        if (clearInterval(this.recordTimer), this.willStop) console.log("取消发送录音"); else {
                            console.log("e: " + JSON.stringify(e));
                            var i = {
                                length: 0,
                                url: e.tempFilePath
                            }, t = parseInt(this.recordLength / 60), s = this.recordLength % 60;
                            t = t < 10 ? "0" + t : t, s = s < 10 ? "0" + s : s, i.length = t + ":" + s, this.sendMsg(i, "voice");
                        }
                        this.willStop = !1;
                    },
                    switchVoice: function() {
                        this.hideDrawer(), this.isVoice = !this.isVoice;
                    },
                    discard: function() {}
                }
            }, "created", function() {
                var i = this;
                e.getSystemInfo({
                    success: function(e) {
                        [ "X", "XR", "XS", "11", "12", "13", "14", "15" ].forEach(function(t) {
                            -1 != e.model.indexOf(t) && -1 != e.model.indexOf("iPhone") && (i.paddingBottomHeight = 40);
                        });
                    }
                });
                var t = getCurrentPages();
                this.urlPath = "/" + t[0].route;
            });
            i.default = g;
        }).call(this, t(2).default);
    },
    722: function(e, i, t) {
        "use strict";
        t.r(i);
        var s = t(723), n = t.n(s);
        for (var o in s) [ "default" ].indexOf(o) < 0 && function(e) {
            t.d(i, e, function() {
                return s[e];
            });
        }(o);
        i.default = n.a;
    },
    723: function(e, i, t) {}
}, [ [ 716, "common/runtime", "common/vendor" ] ] ]);