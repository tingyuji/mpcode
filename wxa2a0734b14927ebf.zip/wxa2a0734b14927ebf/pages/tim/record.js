(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/tim/record" ], {
    708: function(e, t, r) {
        "use strict";
        (function(e, t) {
            var n = r(4);
            r(26), n(r(25));
            var i = n(r(709));
            e.__webpack_require_UNI_MP_PLUGIN__ = r, t(i.default);
        }).call(this, r(1).default, r(2).createPage);
    },
    709: function(e, t, r) {
        "use strict";
        r.r(t);
        var n = r(710), i = r(712);
        for (var s in i) [ "default" ].indexOf(s) < 0 && function(e) {
            r.d(t, e, function() {
                return i[e];
            });
        }(s);
        r(714);
        var o = r(33), a = Object(o.default)(i.default, n.render, n.staticRenderFns, !1, null, null, null, !1, n.components, void 0);
        a.options.__file = "pages/tim/record.vue", t.default = a.exports;
    },
    710: function(e, t, r) {
        "use strict";
        r.r(t);
        var n = r(711);
        r.d(t, "render", function() {
            return n.render;
        }), r.d(t, "staticRenderFns", function() {
            return n.staticRenderFns;
        }), r.d(t, "recyclableRender", function() {
            return n.recyclableRender;
        }), r.d(t, "components", function() {
            return n.components;
        });
    },
    711: function(e, t, r) {
        "use strict";
        var n;
        r.r(t), r.d(t, "render", function() {
            return i;
        }), r.d(t, "staticRenderFns", function() {
            return o;
        }), r.d(t, "recyclableRender", function() {
            return s;
        }), r.d(t, "components", function() {
            return n;
        });
        try {
            n = {
                tabbar: function() {
                    return Promise.all([ r.e("common/vendor"), r.e("components/tabbar/tabbar") ]).then(r.bind(null, 905));
                }
            };
        } catch (e) {
            if (-1 === e.message.indexOf("Cannot find module") || -1 === e.message.indexOf(".vue")) throw e;
            console.error(e.message), console.error("1. 排查组件名称拼写是否正确"), console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"), 
            console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件");
        }
        var i = function() {
            var e = this, t = (e.$createElement, e._self._c, e._f("formatImgUrl")("/images/search.png")), r = 0 == e.isActive && e.searchKey ? e.searchList.length : null, n = 0 != e.isActive || e.searchKey ? null : e.conversationList.length, i = 0 == e.isActive && (e.searchKey ? r : n) > 0 && !e.searchKey ? e.__map(e.conversationList, function(t, r) {
                return {
                    $orig: e.__get_orig(t),
                    g2: t.user && t.user.pic ? e.$options.filters.formatImgUrl(t.user.pic) : null,
                    g3: t.user && t.user.is_writer && t.user.writer_level.level ? e.$options.filters.formatImgUrl(t.user.writer_level.is_active ? t.user.writer_level.level.image : t.user.writer_level.level.hide_img) : null,
                    g4: t.user && t.user.is_vip && t.user.user_level.level ? e.$options.filters.formatImgUrl(t.user.user_level.is_active ? t.user.user_level.level.image : t.user.user_level.level.hide_img) : null,
                    m0: e.nodesFliter(t.lastMessage.messageForShow),
                    g5: e.$options.filters.parseTime(t.lastMessage.lastTime, "{m}-{d}")
                };
            }) : null, s = 0 == e.isActive && (e.searchKey ? r : n) > 0 && e.searchKey ? e.__map(e.searchList, function(t, r) {
                return {
                    $orig: e.__get_orig(t),
                    g6: t.userProfile.avatar ? e.$options.filters.formatImgUrl(t.userProfile.avatar) : null,
                    g7: t.user && t.user.is_writer && t.user.writer_level.level ? e.$options.filters.formatImgUrl(t.user.writer_level.is_active ? t.user.writer_level.level.image : t.user.writer_level.level.hide_img) : null,
                    g8: t.user && t.user.is_vip && t.user.user_level.level ? e.$options.filters.formatImgUrl(t.user.user_level.is_active ? t.user.user_level.level.image : t.user.user_level.level.hide_img) : null,
                    m1: e.nodesFliter(t.lastMessage.messageForShow),
                    g9: e.$options.filters.parseTime(t.lastMessage.lastTime, "{m}-{d}")
                };
            }) : null, o = 0 != e.isActive || (e.searchKey ? r : n) > 0 ? null : e._f("formatImgUrl")("/images/empty.png");
            e.$mp.data = Object.assign({}, {
                $root: {
                    f0: t,
                    g0: r,
                    g1: n,
                    l0: i,
                    l1: s,
                    f1: o
                }
            });
        }, s = !1, o = [];
        i._withStripped = !0;
    },
    712: function(e, t, r) {
        "use strict";
        r.r(t);
        var n = r(713), i = r.n(n);
        for (var s in n) [ "default" ].indexOf(s) < 0 && function(e) {
            r.d(t, e, function() {
                return n[e];
            });
        }(s);
        t.default = i.a;
    },
    713: function(e, t, r) {
        "use strict";
        (function(e) {
            var n = r(4);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = n(r(11));
            function s(e, t) {
                var r = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter(function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable;
                    })), r.push.apply(r, n);
                }
                return r;
            }
            var o = {
                name: "record",
                data: function() {
                    return {
                        searchKey: "",
                        searchList: [],
                        userList: [],
                        friendList: [],
                        isActive: 0,
                        userAddConversationList: []
                    };
                },
                computed: function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var r = null != arguments[t] ? arguments[t] : {};
                        t % 2 ? s(Object(r), !0).forEach(function(t) {
                            (0, i.default)(e, t, r[t]);
                        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : s(Object(r)).forEach(function(t) {
                            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(r, t));
                        });
                    }
                    return e;
                }({}, (0, r(30).mapState)({
                    isLogin: function(e) {
                        return e.isLogin;
                    },
                    isSDKReady: function(e) {
                        return e.isSDKReady;
                    },
                    conversationList: function(e) {
                        return e.conversationList;
                    }
                })),
                watch: {
                    isSDKReady: function(e) {
                        e && this.getConversationList();
                    },
                    conversationList: function(e) {
                        this.getUserInfo(e);
                    },
                    searchKey: function(e) {
                        if (console.log(e), e) {
                            var t = [];
                            this.conversationList.forEach(function(r) {
                                (r.userProfile.nick.includes(e) || r.lastMessage.messageForShow.includes(e)) && t.push(r);
                            }), this.searchList = t;
                        } else this.searchList = [];
                    }
                },
                methods: {
                    timeFliter: function(e) {
                        var t = new Date(1e3 * e);
                        return this.$commen.dateTimeFliter(t);
                    },
                    outLoginBtn: function() {
                        var t = this;
                        this.tim.logout().then(function(r) {
                            t.$store.commit("reset"), e.reLaunch({
                                url: "../index/index"
                            });
                        }).catch(function(e) {
                            console.log("退出失败");
                        });
                    },
                    nodesFliter: function(e) {
                        return '<div style="align-items: center;word-wrap:break-word;">' + e + "</div>";
                    },
                    changeTabBtn: function(e) {
                        this.isActive = e, this.isSDKReady && this.getConversationList(), 1 === e && this.getFriendList();
                    },
                    getFriendList: function() {
                        var e = this;
                        this.tim.getFriendList().then(function(t) {
                            console.log("好友列表", t);
                            var r = t.data.conversationList;
                            r.length && (e.$store.commit("updateFriendList", r), e.friendList = r);
                        }).catch(function(e) {
                            console.warn("getFriendList error:", e);
                        });
                    },
                    getConversationList: function() {
                        var e = this;
                        this.tim.getConversationList().then(function(t) {
                            var r = t.data.conversationList;
                            r.length && e.$store.commit("updateConversationList", r);
                        }).catch(function(e) {
                            console.warn("getConversationList error:", e);
                        });
                    },
                    getUserInfo: function(e) {
                        var t = this, r = [];
                        e.forEach(function(e, n) {
                            var i = {};
                            i.conversation = e, e.toAccount && "administrator" !== e.toAccount && "hudongmsg" !== e.toAccount && "pinglunmsg" !== e.toAccount && t.$api.default.request("user/userInfo_friend", {
                                uid: e.toAccount
                            }).then(function(e) {
                                e.code && (t.conversationList[n].user = e.user, i.user = e.user, r.push(JSON.parse(JSON.stringify(i))));
                            });
                        }), this.userAddConversationList = r;
                    },
                    toRoom: function(t) {
                        this.$store.commit("updateConversationActive", t), e.navigateTo({
                            url: "./room"
                        });
                    },
                    checkUserToRoom: function(t) {
                        this.$store.commit("createConversationActive", t.userId), e.navigateTo({
                            url: "./room"
                        });
                    }
                },
                onShow: function() {
                    console.log("isSDKReady:", this.isSDKReady), this.isSDKReady && (this.getConversationList(), 
                    this.getFriendList());
                },
                onLoad: function() {
                    e.getStorageSync("userInfo");
                }
            };
            t.default = o;
        }).call(this, r(2).default);
    },
    714: function(e, t, r) {
        "use strict";
        r.r(t);
        var n = r(715), i = r.n(n);
        for (var s in n) [ "default" ].indexOf(s) < 0 && function(e) {
            r.d(t, e, function() {
                return n[e];
            });
        }(s);
        t.default = i.a;
    },
    715: function(e, t, r) {}
}, [ [ 708, "common/runtime", "common/vendor" ] ] ]);