(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/find/report" ], {
    276: function(t, e, n) {
        "use strict";
        (function(t, e) {
            var o = n(4);
            n(26), o(n(25));
            var r = o(n(277));
            t.__webpack_require_UNI_MP_PLUGIN__ = n, e(r.default);
        }).call(this, n(1).default, n(2).createPage);
    },
    277: function(t, e, n) {
        "use strict";
        n.r(e);
        var o = n(278), r = n(280);
        for (var i in r) [ "default" ].indexOf(i) < 0 && function(t) {
            n.d(e, t, function() {
                return r[t];
            });
        }(i);
        n(282);
        var u = n(33), c = Object(u.default)(r.default, o.render, o.staticRenderFns, !1, null, null, null, !1, o.components, void 0);
        c.options.__file = "pages/find/report.vue", e.default = c.exports;
    },
    278: function(t, e, n) {
        "use strict";
        n.r(e);
        var o = n(279);
        n.d(e, "render", function() {
            return o.render;
        }), n.d(e, "staticRenderFns", function() {
            return o.staticRenderFns;
        }), n.d(e, "recyclableRender", function() {
            return o.recyclableRender;
        }), n.d(e, "components", function() {
            return o.components;
        });
    },
    279: function(t, e, n) {
        "use strict";
        n.r(e), n.d(e, "render", function() {
            return o;
        }), n.d(e, "staticRenderFns", function() {
            return i;
        }), n.d(e, "recyclableRender", function() {
            return r;
        }), n.d(e, "components", function() {});
        var o = function() {
            this.$createElement;
            var t = (this._self._c, this._f("formatImgUrl")("/images/rarr.png"));
            this.$mp.data = Object.assign({}, {
                $root: {
                    f0: t
                }
            });
        }, r = !1, i = [];
        o._withStripped = !0;
    },
    280: function(t, e, n) {
        "use strict";
        n.r(e);
        var o = n(281), r = n.n(o);
        for (var i in o) [ "default" ].indexOf(i) < 0 && function(t) {
            n.d(e, t, function() {
                return o[t];
            });
        }(i);
        e.default = r.a;
    },
    281: function(t, e, n) {
        "use strict";
        (function(t) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var n = {
                data: function() {
                    return {
                        form: {
                            id: 1,
                            type: 1
                        },
                        index_info: [ {
                            id: "1",
                            title: "发布不适当内容对我造成骚扰"
                        }, {
                            id: "2",
                            title: "存在欺诈骗钱行为"
                        }, {
                            id: "3",
                            title: "此账号可能被盗用了"
                        }, {
                            id: "4",
                            title: "存在侵权行为"
                        }, {
                            id: "5",
                            title: "引导私下交易"
                        }, {
                            id: "6",
                            title: "发布商业广告"
                        }, {
                            id: "7",
                            title: "团队不规范行为"
                        }, {
                            id: "8",
                            title: "其他"
                        } ],
                        userInfo: this.$db.get("userInfo")
                    };
                },
                onLoad: function(t) {
                    console.log(t.id, 77777777), this.form.id = t.id, console.log(this.form, 77777777), 
                    t.type ? this.form.type = t.type : this.form.type = 1, console.log(t);
                },
                methods: {
                    godea: function(e) {
                        console.log(this.form, 7777);
                        var n = "/pages/find/report_type?sid=" + e + "&type=" + this.form.type + "&id=" + this.form.id;
                        console.log(n, 7777), t.navigateTo({
                            url: n
                        });
                    },
                    outLogin: function() {
                        var e = this;
                        this.tim.logout().then(function(t) {
                            console.log(t.data);
                        }).catch(function(t) {
                            console.warn("logout error:", t);
                        }), this.$store.commit("reset"), this.$api.default.request("user/logout", {}, "GET", !1).then(function(n) {
                            n.code && (e.$db.clear(), e.$common.successToShow(n.msg, function() {
                                t.reLaunch({
                                    url: "/pages/login/login"
                                });
                            }));
                        });
                    },
                    getUserInfo: function() {
                        var t = this;
                        this.$api.default.request("user/userInfo", {}, "GET", !1).then(function(e) {
                            e.code ? t.userInfo = e.user : t.$common.errorToShow(e.msg);
                        });
                    }
                }
            };
            e.default = n;
        }).call(this, n(2).default);
    },
    282: function(t, e, n) {
        "use strict";
        n.r(e);
        var o = n(283), r = n.n(o);
        for (var i in o) [ "default" ].indexOf(i) < 0 && function(t) {
            n.d(e, t, function() {
                return o[t];
            });
        }(i);
        e.default = r.a;
    },
    283: function(t, e, n) {}
}, [ [ 276, "common/runtime", "common/vendor" ] ] ]);