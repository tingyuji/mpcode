(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/user/pingbilist" ], {
    668: function(e, t, n) {
        "use strict";
        (function(e, t) {
            var i = n(4);
            n(26), i(n(25));
            var r = i(n(669));
            e.__webpack_require_UNI_MP_PLUGIN__ = n, t(r.default);
        }).call(this, n(1).default, n(2).createPage);
    },
    669: function(e, t, n) {
        "use strict";
        n.r(t);
        var i = n(670), r = n(672);
        for (var s in r) [ "default" ].indexOf(s) < 0 && function(e) {
            n.d(t, e, function() {
                return r[e];
            });
        }(s);
        n(674);
        var o = n(33), a = Object(o.default)(r.default, i.render, i.staticRenderFns, !1, null, null, null, !1, i.components, void 0);
        a.options.__file = "pages/user/pingbilist.vue", t.default = a.exports;
    },
    670: function(e, t, n) {
        "use strict";
        n.r(t);
        var i = n(671);
        n.d(t, "render", function() {
            return i.render;
        }), n.d(t, "staticRenderFns", function() {
            return i.staticRenderFns;
        }), n.d(t, "recyclableRender", function() {
            return i.recyclableRender;
        }), n.d(t, "components", function() {
            return i.components;
        });
    },
    671: function(e, t, n) {
        "use strict";
        n.r(t), n.d(t, "render", function() {
            return i;
        }), n.d(t, "staticRenderFns", function() {
            return s;
        }), n.d(t, "recyclableRender", function() {
            return r;
        }), n.d(t, "components", function() {});
        var i = function() {
            var e = this, t = (e.$createElement, e._self._c, e.__map(e.list, function(t, n) {
                return {
                    $orig: e.__get_orig(t),
                    f0: t.pic ? e._f("formatImgUrl")(t.pic) : null
                };
            })), n = e.list.length, i = n <= 0 ? e._f("formatImgUrl")("/images/empty.png") : null;
            e.$mp.data = Object.assign({}, {
                $root: {
                    l0: t,
                    g0: n,
                    f1: i
                }
            });
        }, r = !1, s = [];
        i._withStripped = !0;
    },
    672: function(e, t, n) {
        "use strict";
        n.r(t);
        var i = n(673), r = n.n(i);
        for (var s in i) [ "default" ].indexOf(s) < 0 && function(e) {
            n.d(t, e, function() {
                return i[e];
            });
        }(s);
        t.default = r.a;
    },
    673: function(e, t, n) {
        "use strict";
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var n = {
                data: function() {
                    return {
                        userInfo: this.$db.get("userInfo"),
                        show: !1,
                        page: 1,
                        erList: [],
                        date: new Date().toLocaleDateString().replace(/\//g, "-"),
                        array: [ "请选择", "男", "女" ],
                        index: 0,
                        list: null,
                        type: 2
                    };
                },
                onLoad: function(e) {
                    this.type = e.type, this.getList();
                },
                onReachBottom: function() {
                    this.getList();
                },
                methods: {
                    yichu: function(e) {
                        var t = this;
                        this.$api.default.request("user/user_friend_yichu_back", {
                            id: e.id
                        }).then(function(e) {
                            1 == e.code ? (t.page = 1, t.list = null, t.getList(), t.$common.errorToShow(e.msg)) : t.$common.errorToShow(e.msg);
                        });
                    },
                    getList: function() {
                        var e = this;
                        this.$api.default.request("user/user_friend_f", {
                            page: this.page,
                            type: this.type
                        }, "POST", !1).then(function(t) {
                            t.code && t.data.data && (null != e.list ? e.list = e.list.concat(t.data.data) : e.list = t.data.data, 
                            e.page++);
                        });
                    },
                    go_auth: function() {
                        1 == this.userInfo.is_auth ? e.navigateTo({
                            url: "/pages/user/auth1"
                        }) : e.navigateTo({
                            url: "/pages/user/auth"
                        });
                    },
                    bindPickerChange: function(e) {
                        console.log("picker发送选择改变，携带值为", e.detail.value), this.index = e.detail.value, this.saveUser({
                            sex: this.index
                        });
                    },
                    getUserInfo: function() {
                        var e = this;
                        this.$api.default.request("user/userInfo").then(function(t) {
                            t.code ? (e.userInfo = t.user, e.index = t.user.sex ? t.user.sex : 0) : e.$common.errorToShow(t.msg);
                        });
                    },
                    onChooseAvatar: function(e) {
                        var t = this;
                        this.$common.uploadImg(e.detail.avatarUrl, function(e) {
                            e && t.saveUser({
                                pic: e
                            });
                        });
                    },
                    bindNick: function(e) {
                        console.log(e), e.detail.value != this.userInfo.username && (this.userInfo.username = e.detail.value, 
                        this.saveUser({
                            username: this.userInfo.username
                        }));
                    },
                    saveUser: function(e) {
                        var t = this;
                        this.$api.default.request("user/saveUser", e).then(function(e) {
                            1 == e.code ? (t.userInfo = e.user, t.$common.successToShow(e.msg)) : t.$common.errorToShow(e.msg);
                        });
                    },
                    open: function() {},
                    close: function() {
                        this.show = !1;
                    },
                    bindDateChange: function(e) {
                        this.date = e.detail.value, this.saveUser({
                            birthday: e.detail.value
                        });
                    }
                }
            };
            t.default = n;
        }).call(this, n(2).default);
    },
    674: function(e, t, n) {
        "use strict";
        n.r(t);
        var i = n(675), r = n.n(i);
        for (var s in i) [ "default" ].indexOf(s) < 0 && function(e) {
            n.d(t, e, function() {
                return i[e];
            });
        }(s);
        t.default = r.a;
    },
    675: function(e, t, n) {}
}, [ [ 668, "common/runtime", "common/vendor" ] ] ]);