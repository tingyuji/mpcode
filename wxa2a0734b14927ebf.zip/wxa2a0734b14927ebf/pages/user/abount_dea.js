(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/user/abount_dea" ], {
    476: function(n, t, e) {
        "use strict";
        (function(n, t) {
            var i = e(4);
            e(26), i(e(25));
            var r = i(e(477));
            n.__webpack_require_UNI_MP_PLUGIN__ = e, t(r.default);
        }).call(this, e(1).default, e(2).createPage);
    },
    477: function(n, t, e) {
        "use strict";
        e.r(t);
        var i = e(478), r = e(480);
        for (var o in r) [ "default" ].indexOf(o) < 0 && function(n) {
            e.d(t, n, function() {
                return r[n];
            });
        }(o);
        e(482);
        var u = e(33), c = Object(u.default)(r.default, i.render, i.staticRenderFns, !1, null, null, null, !1, i.components, void 0);
        c.options.__file = "pages/user/abount_dea.vue", t.default = c.exports;
    },
    478: function(n, t, e) {
        "use strict";
        e.r(t);
        var i = e(479);
        e.d(t, "render", function() {
            return i.render;
        }), e.d(t, "staticRenderFns", function() {
            return i.staticRenderFns;
        }), e.d(t, "recyclableRender", function() {
            return i.recyclableRender;
        }), e.d(t, "components", function() {
            return i.components;
        });
    },
    479: function(n, t, e) {
        "use strict";
        e.r(t), e.d(t, "render", function() {
            return i;
        }), e.d(t, "staticRenderFns", function() {
            return o;
        }), e.d(t, "recyclableRender", function() {
            return r;
        }), e.d(t, "components", function() {});
        var i = function() {
            this.$createElement;
            var n = (this._self._c, this._f("filterRichText")(this.content));
            this.$mp.data = Object.assign({}, {
                $root: {
                    f0: n
                }
            });
        }, r = !1, o = [];
        i._withStripped = !0;
    },
    480: function(n, t, e) {
        "use strict";
        e.r(t);
        var i = e(481), r = e.n(i);
        for (var o in i) [ "default" ].indexOf(o) < 0 && function(n) {
            e.d(t, n, function() {
                return i[n];
            });
        }(o);
        t.default = r.a;
    },
    481: function(n, t, e) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0, t.default = {
            data: function() {
                return {
                    page: 1,
                    list: {},
                    logList: [],
                    content: ""
                };
            },
            onLoad: function(n) {
                this.id = n.id;
            },
            onShow: function() {
                this.getList();
            },
            onReachBottom: function() {},
            methods: {
                getList: function() {
                    var n = this;
                    this.$api.default.request("index/getxieyi_dea", {
                        id: this.id
                    }, "POST", !1).then(function(t) {
                        t.code && (n.content = t.data);
                    });
                },
                shownei: function(n) {}
            }
        };
    },
    482: function(n, t, e) {
        "use strict";
        e.r(t);
        var i = e(483), r = e.n(i);
        for (var o in i) [ "default" ].indexOf(o) < 0 && function(n) {
            e.d(t, n, function() {
                return i[n];
            });
        }(o);
        t.default = r.a;
    },
    483: function(n, t, e) {}
}, [ [ 476, "common/runtime", "common/vendor" ] ] ]);