(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/user/collective" ], {
    404: function(n, e, t) {
        "use strict";
        (function(n, e) {
            var r = t(4);
            t(26), r(t(25));
            var i = r(t(405));
            n.__webpack_require_UNI_MP_PLUGIN__ = t, e(i.default);
        }).call(this, t(1).default, t(2).createPage);
    },
    405: function(n, e, t) {
        "use strict";
        t.r(e);
        var r = t(406), i = t(408);
        for (var o in i) [ "default" ].indexOf(o) < 0 && function(n) {
            t.d(e, n, function() {
                return i[n];
            });
        }(o);
        t(410);
        var u = t(33), c = Object(u.default)(i.default, r.render, r.staticRenderFns, !1, null, null, null, !1, r.components, void 0);
        c.options.__file = "pages/user/collective.vue", e.default = c.exports;
    },
    406: function(n, e, t) {
        "use strict";
        t.r(e);
        var r = t(407);
        t.d(e, "render", function() {
            return r.render;
        }), t.d(e, "staticRenderFns", function() {
            return r.staticRenderFns;
        }), t.d(e, "recyclableRender", function() {
            return r.recyclableRender;
        }), t.d(e, "components", function() {
            return r.components;
        });
    },
    407: function(n, e, t) {
        "use strict";
        t.r(e), t.d(e, "render", function() {
            return r;
        }), t.d(e, "staticRenderFns", function() {
            return o;
        }), t.d(e, "recyclableRender", function() {
            return i;
        }), t.d(e, "components", function() {});
        var r = function() {
            this.$createElement;
            var n = (this._self._c, this._f("formatImgUrl")("/images/qbg_02.png"));
            this.$mp.data = Object.assign({}, {
                $root: {
                    f0: n
                }
            });
        }, i = !1, o = [];
        r._withStripped = !0;
    },
    408: function(n, e, t) {
        "use strict";
        t.r(e);
        var r = t(409), i = t.n(r);
        for (var o in r) [ "default" ].indexOf(o) < 0 && function(n) {
            t.d(e, n, function() {
                return r[n];
            });
        }(o);
        e.default = i.a;
    },
    409: function(n, e, t) {
        "use strict";
        (function(n) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var t = {
                data: function() {
                    return {
                        paddingBottomHeight: 0
                    };
                },
                onLoad: function() {},
                created: function() {
                    var e = this;
                    n.getSystemInfo({
                        success: function(n) {
                            [ "X", "XR", "XS", "11", "12", "13", "14", "15" ].forEach(function(t) {
                                -1 != n.model.indexOf(t) && -1 != n.model.indexOf("iPhone") && (e.paddingBottomHeight = 40);
                            });
                        }
                    });
                    var t = getCurrentPages();
                    this.urlPath = "/" + t[0].route;
                },
                methods: {
                    goMyPage: function() {
                        n.navigateBack();
                    }
                }
            };
            e.default = t;
        }).call(this, t(2).default);
    },
    410: function(n, e, t) {
        "use strict";
        t.r(e);
        var r = t(411), i = t.n(r);
        for (var o in r) [ "default" ].indexOf(o) < 0 && function(n) {
            t.d(e, n, function() {
                return r[n];
            });
        }(o);
        e.default = i.a;
    },
    411: function(n, e, t) {}
}, [ [ 404, "common/runtime", "common/vendor" ] ] ]);