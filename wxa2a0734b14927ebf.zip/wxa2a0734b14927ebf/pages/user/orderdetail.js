(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/user/orderdetail" ], {
    372: function(e, r, o) {
        "use strict";
        (function(e, r) {
            var n = o(4);
            o(26), n(o(25));
            var t = n(o(373));
            e.__webpack_require_UNI_MP_PLUGIN__ = o, r(t.default);
        }).call(this, o(1).default, o(2).createPage);
    },
    373: function(e, r, o) {
        "use strict";
        o.r(r);
        var n = o(374), t = o(376);
        for (var i in t) [ "default" ].indexOf(i) < 0 && function(e) {
            o.d(r, e, function() {
                return t[e];
            });
        }(i);
        o(378);
        var s = o(33), u = Object(s.default)(t.default, n.render, n.staticRenderFns, !1, null, null, null, !1, n.components, void 0);
        u.options.__file = "pages/user/orderdetail.vue", r.default = u.exports;
    },
    374: function(e, r, o) {
        "use strict";
        o.r(r);
        var n = o(375);
        o.d(r, "render", function() {
            return n.render;
        }), o.d(r, "staticRenderFns", function() {
            return n.staticRenderFns;
        }), o.d(r, "recyclableRender", function() {
            return n.recyclableRender;
        }), o.d(r, "components", function() {
            return n.components;
        });
    },
    375: function(e, r, o) {
        "use strict";
        var n;
        o.r(r), o.d(r, "render", function() {
            return t;
        }), o.d(r, "staticRenderFns", function() {
            return s;
        }), o.d(r, "recyclableRender", function() {
            return i;
        }), o.d(r, "components", function() {
            return n;
        });
        try {
            n = {
                uSteps: function() {
                    return Promise.all([ o.e("common/vendor"), o.e("node-modules/uview-ui/components/u-steps/u-steps") ]).then(o.bind(null, 962));
                },
                uStepsItem: function() {
                    return Promise.all([ o.e("common/vendor"), o.e("node-modules/uview-ui/components/u-steps-item/u-steps-item") ]).then(o.bind(null, 970));
                },
                uPopup: function() {
                    return Promise.all([ o.e("common/vendor"), o.e("node-modules/uview-ui/components/u-popup/u-popup") ]).then(o.bind(null, 890));
                }
            };
        } catch (e) {
            if (-1 === e.message.indexOf("Cannot find module") || -1 === e.message.indexOf(".vue")) throw e;
            console.error(e.message), console.error("1. 排查组件名称拼写是否正确"), console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"), 
            console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件");
        }
        var t = function() {
            var e = this, r = (e.$createElement, e._self._c, Object.keys(e.orderInfo).length), o = r > 0 ? e.$db.get("userInfo") : null, n = r > 0 ? e.$db.get("userInfo") : null, t = r > 0 ? e._f("formatImgUrl")(e.orderInfo.writer.pic) : null, i = r > 0 && e.orderInfo.writer && e.orderInfo.writer.is_writer ? e.$options.filters.formatImgUrl(e.orderInfo.writer.writer_level.is_active ? e.orderInfo.writer.writer_level.level.image : e.orderInfo.writer.writer_level.level.hide_img) : null, s = r > 0 && e.orderInfo.writer && e.orderInfo.writer.user_level.is_active && e.orderInfo.writer.user_level.level ? e.$options.filters.formatImgUrl(e.orderInfo.writer.user_level.active_day > 0 ? e.orderInfo.writer.user_level.level.image : e.orderInfo.writer.user_level.level.hide_img) : null, u = r > 0 ? e._f("formatImgUrl")("/images/je.png") : null, d = r > 0 ? e.$options.filters.parseTime(e.orderInfo.create_time, "{y} / {m} / {d} {h}:{i}:{s}") : null, c = r > 0 ? e.__map(e.zhiList, function(r, o) {
                return {
                    $orig: e.__get_orig(r),
                    f2: o == e.zhiLiang ? e._f("formatImgUrl")("/images/jk.png") : null,
                    f3: o == e.zhiLiang ? e._f("formatImgUrl")("/images/jl.png") : null,
                    f4: e._f("formatImgUrl")("/images/jn.png")
                };
            }) : null;
            e._isMounted || (e.e0 = function(r) {
                e.show = !0;
            }, e.e1 = function(r) {
                e.show1 = !0;
            }, e.e2 = function(r) {
                e.show = !1;
            }), e.$mp.data = Object.assign({}, {
                $root: {
                    g0: r,
                    g1: o,
                    g2: n,
                    f0: t,
                    g3: i,
                    g4: s,
                    f1: u,
                    g5: d,
                    l0: c
                }
            });
        }, i = !1, s = [];
        t._withStripped = !0;
    },
    376: function(e, r, o) {
        "use strict";
        o.r(r);
        var n = o(377), t = o.n(n);
        for (var i in n) [ "default" ].indexOf(i) < 0 && function(e) {
            o.d(r, e, function() {
                return n[e];
            });
        }(i);
        r.default = t.a;
    },
    377: function(e, r, o) {
        "use strict";
        (function(e) {
            Object.defineProperty(r, "__esModule", {
                value: !0
            }), r.default = void 0;
            var o = {
                data: function() {
                    return {
                        orderInfo: {},
                        show: !1,
                        show1: !1,
                        zhiList: [],
                        userInfo: {}
                    };
                },
                onLoad: function(e) {
                    e.id ? this.getOrderInfo(e.id) : this.$common.errorToShow("参数异常");
                },
                methods: {
                    close1: function() {
                        this.show1 = !1;
                    },
                    getUserInfo: function() {
                        var e = this;
                        this.$api.default.request("user/userInfo", {
                            uid: this.uid
                        }).then(function(r) {
                            r.code ? (e.userInfo = r.user, r.user.is_writer || (e.navIndex = 3)) : e.$common.errorToShow(r.msg);
                        });
                    },
                    toImRoom: function() {
                        if (console.log(133333333333), this.$db.get("userInfo").membe_id == this.orderInfo.writer_uid) {
                            console.log(0x650e124ef1c7), this.$store.commit("createConversationActive", this.orderInfo.uid);
                            var r = "/pages/tim/room?userType=1&showbox=1&uid=" + this.orderInfo.writer_uid;
                        } else console.log(22222222222), this.$store.commit("createConversationActive", this.orderInfo.writer_uid), 
                        r = "/pages/tim/room?userType=1&showbox=1&uid=" + this.orderInfo.uid;
                        e.redirectTo({
                            url: r
                        });
                    },
                    goToroom: function() {
                        var e = this;
                        this.$api.default.request("order/userConfirmOrder", {
                            id: this.orderInfo.id
                        }, "POST", !1).then(function(r) {
                            r.code && e.$common.successToShow(r.msg, function() {
                                e.getOrderInfo(e.orderInfo.id), e.show1 = !1;
                            });
                        });
                    },
                    submit: function() {
                        0 == this.orderInfo.status && e.navigateTo({
                            url: "/pages/my/check?type=2&id=" + this.orderInfo.id
                        }), 3 == this.orderInfo.status && e.navigateTo({
                            url: "/pages/my/check?id=" + this.orderInfo.id
                        });
                    },
                    getOrderInfo: function(e) {
                        var r = this;
                        this.$api.default.request("order/orderInfo", {
                            id: e
                        }).then(function(e) {
                            e.code ? r.orderInfo = e.data : r.$common.errorToShow(e.msg);
                        });
                    },
                    close: function() {
                        this.show = !1;
                    },
                    goToindex: function() {
                        var r = this;
                        this.$api.default.request("order/closeOrder", {
                            id: this.orderInfo.id
                        }).then(function(o) {
                            o.code ? r.$common.successToShow(o.msg, function() {
                                e.reLaunch({
                                    url: "/pages/index/index"
                                });
                            }) : r.$common.errorToShow(o.msg);
                        });
                    }
                }
            };
            r.default = o;
        }).call(this, o(2).default);
    },
    378: function(e, r, o) {
        "use strict";
        o.r(r);
        var n = o(379), t = o.n(n);
        for (var i in n) [ "default" ].indexOf(i) < 0 && function(e) {
            o.d(r, e, function() {
                return n[e];
            });
        }(i);
        r.default = t.a;
    },
    379: function(e, r, o) {}
}, [ [ 372, "common/runtime", "common/vendor" ] ] ]);