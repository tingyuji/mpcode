(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/user/auth" ], {
    484: function(n, t, e) {
        "use strict";
        (function(n, t) {
            var r = e(4);
            e(26), r(e(25));
            var o = r(e(485));
            n.__webpack_require_UNI_MP_PLUGIN__ = e, t(o.default);
        }).call(this, e(1).default, e(2).createPage);
    },
    485: function(n, t, e) {
        "use strict";
        e.r(t);
        var r = e(486), o = e(488);
        for (var i in o) [ "default" ].indexOf(i) < 0 && function(n) {
            e.d(t, n, function() {
                return o[n];
            });
        }(i);
        e(490);
        var a = e(33), u = Object(a.default)(o.default, r.render, r.staticRenderFns, !1, null, null, null, !1, r.components, void 0);
        u.options.__file = "pages/user/auth.vue", t.default = u.exports;
    },
    486: function(n, t, e) {
        "use strict";
        e.r(t);
        var r = e(487);
        e.d(t, "render", function() {
            return r.render;
        }), e.d(t, "staticRenderFns", function() {
            return r.staticRenderFns;
        }), e.d(t, "recyclableRender", function() {
            return r.recyclableRender;
        }), e.d(t, "components", function() {
            return r.components;
        });
    },
    487: function(n, t, e) {
        "use strict";
        e.r(t), e.d(t, "render", function() {
            return r;
        }), e.d(t, "staticRenderFns", function() {
            return i;
        }), e.d(t, "recyclableRender", function() {
            return o;
        }), e.d(t, "components", function() {});
        var r = function() {
            this.$createElement;
            var n = (this._self._c, this._f("formatImgUrl")(this.front_img)), t = this._f("formatImgUrl")(this.back_img);
            this.$mp.data = Object.assign({}, {
                $root: {
                    f0: n,
                    f1: t
                }
            });
        }, o = !1, i = [];
        r._withStripped = !0;
    },
    488: function(n, t, e) {
        "use strict";
        e.r(t);
        var r = e(489), o = e.n(r);
        for (var i in r) [ "default" ].indexOf(i) < 0 && function(n) {
            e.d(t, n, function() {
                return r[n];
            });
        }(i);
        t.default = o.a;
    },
    489: function(n, t, e) {
        "use strict";
        (function(n) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var e = {
                data: function() {
                    return {
                        userInfo: this.$db.get("userInfo"),
                        front_img: "https://cdnauth.dreamyuewen.com/images/man.png",
                        back_img: "https://cdnauth.dreamyuewen.com/images/man1.png"
                    };
                },
                onShow: function() {
                    this.getUserInfo();
                },
                onLoad: function() {},
                methods: {
                    next_auth1: function() {
                        var t = this;
                        "https://cdnauth.dreamyuewen.com/images/man.png" != this.front_img ? "https://cdnauth.dreamyuewen.com/images/man1.png" != this.back_img ? this.$api.default.request("user/idcard", {
                            back_img: this.back_img,
                            front_img: this.front_img
                        }).then(function(e) {
                            e.code ? (n.setStorageSync("card_msg", e.data), setTimeout(function() {
                                n.navigateTo({
                                    url: "/pages/user/auth1"
                                });
                            }, 1e3)) : t.$common.errorToShow(e.msg);
                        }) : n.showToast({
                            title: "请上传身份证反面",
                            icon: "none",
                            mask: !0
                        }) : n.showToast({
                            title: "请上传身份证正面",
                            icon: "none",
                            mask: !0
                        });
                    },
                    onChooseImg: function(n) {
                        var t = this;
                        this.$common.chooseImage({}, function(e) {
                            e && ("front_img" == n ? t.front_img = e : t.back_img = e);
                        }, 1);
                    },
                    bindPickerChange: function(n) {
                        console.log("picker发送选择改变，携带值为", n.detail.value), this.index = n.detail.value, this.saveUser({
                            sex: this.index
                        });
                    },
                    getUserInfo: function() {
                        var n = this;
                        this.$api.default.request("user/userInfo").then(function(t) {
                            t.code ? (n.userInfo = t.user, n.index = t.user.sex ? t.user.sex : 0) : n.$common.errorToShow(t.msg);
                        });
                    }
                }
            };
            t.default = e;
        }).call(this, e(2).default);
    },
    490: function(n, t, e) {
        "use strict";
        e.r(t);
        var r = e(491), o = e.n(r);
        for (var i in r) [ "default" ].indexOf(i) < 0 && function(n) {
            e.d(t, n, function() {
                return r[n];
            });
        }(i);
        t.default = o.a;
    },
    491: function(n, t, e) {}
}, [ [ 484, "common/runtime", "common/vendor" ] ] ]);