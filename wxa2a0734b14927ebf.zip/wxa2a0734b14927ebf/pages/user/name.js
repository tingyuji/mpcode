(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/user/name" ], {
    508: function(e, n, t) {
        "use strict";
        (function(e, n) {
            var r = t(4);
            t(26), r(t(25));
            var u = r(t(509));
            e.__webpack_require_UNI_MP_PLUGIN__ = t, n(u.default);
        }).call(this, t(1).default, t(2).createPage);
    },
    509: function(e, n, t) {
        "use strict";
        t.r(n);
        var r = t(510), u = t(512);
        for (var o in u) [ "default" ].indexOf(o) < 0 && function(e) {
            t.d(n, e, function() {
                return u[e];
            });
        }(o);
        t(514);
        var i = t(33), a = Object(i.default)(u.default, r.render, r.staticRenderFns, !1, null, null, null, !1, r.components, void 0);
        a.options.__file = "pages/user/name.vue", n.default = a.exports;
    },
    510: function(e, n, t) {
        "use strict";
        t.r(n);
        var r = t(511);
        t.d(n, "render", function() {
            return r.render;
        }), t.d(n, "staticRenderFns", function() {
            return r.staticRenderFns;
        }), t.d(n, "recyclableRender", function() {
            return r.recyclableRender;
        }), t.d(n, "components", function() {
            return r.components;
        });
    },
    511: function(e, n, t) {
        "use strict";
        t.r(n), t.d(n, "render", function() {
            return r;
        }), t.d(n, "staticRenderFns", function() {
            return o;
        }), t.d(n, "recyclableRender", function() {
            return u;
        }), t.d(n, "components", function() {});
        var r = function() {
            this.$createElement;
            this._self._c;
        }, u = !1, o = [];
        r._withStripped = !0;
    },
    512: function(e, n, t) {
        "use strict";
        t.r(n);
        var r = t(513), u = t.n(r);
        for (var o in r) [ "default" ].indexOf(o) < 0 && function(e) {
            t.d(n, e, function() {
                return r[e];
            });
        }(o);
        n.default = u.a;
    },
    513: function(e, n, t) {
        "use strict";
        (function(e) {
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var t = {
                data: function() {
                    return {
                        userInfo: this.$db.get("userInfo")
                    };
                },
                onLoad: function() {},
                methods: {
                    goToxie: function() {
                        e.navigateTo({
                            url: "/pages/webview/webview?url=" + this.$config.default.Url + "/agreement/1000004"
                        });
                    },
                    bindNick: function(e) {
                        e.detail.value != this.userInfo.username && (this.userInfo.username = e.detail.value);
                    },
                    saveUser: function() {
                        var n = this, t = {
                            username: this.userInfo.username
                        };
                        this.$api.default.request("user/saveUser", t).then(function(t) {
                            1 == t.code ? (n.userInfo = t.user, n.$common.successToShow(t.msg, function() {
                                e.navigateBack();
                            })) : n.$common.errorToShow(t.msg);
                        });
                    }
                }
            };
            n.default = t;
        }).call(this, t(2).default);
    },
    514: function(e, n, t) {
        "use strict";
        t.r(n);
        var r = t(515), u = t.n(r);
        for (var o in r) [ "default" ].indexOf(o) < 0 && function(e) {
            t.d(n, e, function() {
                return r[e];
            });
        }(o);
        n.default = u.a;
    },
    515: function(e, n, t) {}
}, [ [ 508, "common/runtime", "common/vendor" ] ] ]);