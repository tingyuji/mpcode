(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/user/signature" ], {
    516: function(n, e, t) {
        "use strict";
        (function(n, e) {
            var r = t(4);
            t(26), r(t(25));
            var u = r(t(517));
            n.__webpack_require_UNI_MP_PLUGIN__ = t, e(u.default);
        }).call(this, t(1).default, t(2).createPage);
    },
    517: function(n, e, t) {
        "use strict";
        t.r(e);
        var r = t(518), u = t(520);
        for (var o in u) [ "default" ].indexOf(o) < 0 && function(n) {
            t.d(e, n, function() {
                return u[n];
            });
        }(o);
        t(522);
        var i = t(33), c = Object(i.default)(u.default, r.render, r.staticRenderFns, !1, null, null, null, !1, r.components, void 0);
        c.options.__file = "pages/user/signature.vue", e.default = c.exports;
    },
    518: function(n, e, t) {
        "use strict";
        t.r(e);
        var r = t(519);
        t.d(e, "render", function() {
            return r.render;
        }), t.d(e, "staticRenderFns", function() {
            return r.staticRenderFns;
        }), t.d(e, "recyclableRender", function() {
            return r.recyclableRender;
        }), t.d(e, "components", function() {
            return r.components;
        });
    },
    519: function(n, e, t) {
        "use strict";
        t.r(e), t.d(e, "render", function() {
            return r;
        }), t.d(e, "staticRenderFns", function() {
            return o;
        }), t.d(e, "recyclableRender", function() {
            return u;
        }), t.d(e, "components", function() {});
        var r = function() {
            this.$createElement;
            this._self._c;
        }, u = !1, o = [];
        r._withStripped = !0;
    },
    520: function(n, e, t) {
        "use strict";
        t.r(e);
        var r = t(521), u = t.n(r);
        for (var o in r) [ "default" ].indexOf(o) < 0 && function(n) {
            t.d(e, n, function() {
                return r[n];
            });
        }(o);
        e.default = u.a;
    },
    521: function(n, e, t) {
        "use strict";
        (function(n) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var t = {
                data: function() {
                    return {
                        userInfo: this.$db.get("userInfo")
                    };
                },
                onLoad: function() {},
                methods: {
                    saveUser: function() {
                        var e = this, t = {
                            signature_des: this.userInfo.signature_des
                        };
                        this.$api.default.request("user/saveUser", t).then(function(t) {
                            1 == t.code ? (e.userInfo = t.user, e.$common.successToShow(t.msg, function() {
                                n.navigateBack();
                            })) : e.$common.errorToShow(t.msg);
                        });
                    }
                }
            };
            e.default = t;
        }).call(this, t(2).default);
    },
    522: function(n, e, t) {
        "use strict";
        t.r(e);
        var r = t(523), u = t.n(r);
        for (var o in r) [ "default" ].indexOf(o) < 0 && function(n) {
            t.d(e, n, function() {
                return r[n];
            });
        }(o);
        e.default = u.a;
    },
    523: function(n, e, t) {}
}, [ [ 516, "common/runtime", "common/vendor" ] ] ]);