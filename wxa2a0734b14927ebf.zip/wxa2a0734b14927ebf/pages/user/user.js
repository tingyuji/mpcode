(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/user/user" ], {
    308: function(e, r, n) {
        "use strict";
        (function(e, r) {
            var t = n(4);
            n(26), t(n(25));
            var o = t(n(309));
            e.__webpack_require_UNI_MP_PLUGIN__ = n, r(o.default);
        }).call(this, n(1).default, n(2).createPage);
    },
    309: function(e, r, n) {
        "use strict";
        n.r(r);
        var t = n(310), o = n(312);
        for (var s in o) [ "default" ].indexOf(s) < 0 && function(e) {
            n.d(r, e, function() {
                return o[e];
            });
        }(s);
        n(314);
        var i = n(33), u = Object(i.default)(o.default, t.render, t.staticRenderFns, !1, null, null, null, !1, t.components, void 0);
        u.options.__file = "pages/user/user.vue", r.default = u.exports;
    },
    310: function(e, r, n) {
        "use strict";
        n.r(r);
        var t = n(311);
        n.d(r, "render", function() {
            return t.render;
        }), n.d(r, "staticRenderFns", function() {
            return t.staticRenderFns;
        }), n.d(r, "recyclableRender", function() {
            return t.recyclableRender;
        }), n.d(r, "components", function() {
            return t.components;
        });
    },
    311: function(e, r, n) {
        "use strict";
        var t;
        n.r(r), n.d(r, "render", function() {
            return o;
        }), n.d(r, "staticRenderFns", function() {
            return i;
        }), n.d(r, "recyclableRender", function() {
            return s;
        }), n.d(r, "components", function() {
            return t;
        });
        try {
            t = {
                uSwitch: function() {
                    return Promise.all([ n.e("common/vendor"), n.e("node-modules/uview-ui/components/u-switch/u-switch") ]).then(n.bind(null, 936));
                },
                tabbar: function() {
                    return Promise.all([ n.e("common/vendor"), n.e("components/tabbar/tabbar") ]).then(n.bind(null, 905));
                }
            };
        } catch (e) {
            if (-1 === e.message.indexOf("Cannot find module") || -1 === e.message.indexOf(".vue")) throw e;
            console.error(e.message), console.error("1. 排查组件名称拼写是否正确"), console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"), 
            console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件");
        }
        var o = function() {
            var e = this, r = (e.$createElement, e._self._c, e._f("formatImgUrl")("/images/mybei.png")), n = e.userInfo ? e._f("formatImgUrl")(e.userInfo.pic) : null, t = e.userInfo && e.userInfo.is_writer ? e.$options.filters.formatImgUrl(e.userInfo.writer_level.is_active ? e.userInfo.writer_level.level.image : e.userInfo.writer_level.level.hide_img) : null, o = e.userInfo && e.userInfo.user_level.is_active && e.userInfo.user_level.level ? e.$options.filters.formatImgUrl(e.userInfo.user_level.active_day > 0 ? e.userInfo.user_level.level.image : e.userInfo.user_level.level.hide_img) : null, s = e._f("formatImgUrl")("/images/rar.png"), i = e.userInfo && e.userInfo.is_writer ? e._f("formatImgUrl")("/images/sa.png") : null, u = e.userInfo && e.userInfo.is_writer ? e._f("formatImgUrl")("/images/sb.png") : null, a = e.userInfo && e.userInfo.is_writer ? e._f("formatImgUrl")("/images/sc.png") : null, f = e.userInfo && e.userInfo.is_writer ? e._f("formatImgUrl")("/images/sd.png") : null, l = e.userInfo && e.userInfo.is_writer ? e._f("formatImgUrl")("/images/se.png") : null, g = e.userInfo && e.userInfo.is_writer ? e._f("formatImgUrl")("/images/sf.png") : null, c = e.userInfo && e.userInfo.is_writer ? e._f("formatImgUrl")("/images/pipei.png") : null, m = e.userInfo && e.userInfo.is_writer ? e._f("formatImgUrl")("/images/sh.png") : null, d = e.userInfo && e.userInfo.is_writer && !e.list.total ? e._f("formatImgUrl")("/images/empty.png") : null, _ = e.userInfo && e.userInfo.is_writer ? e.__map(e.rowList, function(r, n) {
                var t = e.__get_orig(r), o = e._f("formatImgUrl")("/images/je.png"), s = e.$db.get("userInfo"), i = r.writer_uid == s.membe_id ? e._f("formatImgUrl")(r.user.pic) : null, u = e.$db.get("userInfo");
                return {
                    $orig: t,
                    f12: o,
                    g2: s,
                    f13: i,
                    g3: u,
                    f14: r.writer_uid != u.membe_id ? e._f("formatImgUrl")(r.writer.pic) : null
                };
            }) : null, p = e.userInfo && e.userInfo.is_writer ? null : e._f("formatImgUrl")("/images/sa.png"), h = e.userInfo && e.userInfo.is_writer ? null : e._f("formatImgUrl")("/images/sb.png"), I = e.userInfo && e.userInfo.is_writer ? null : e._f("formatImgUrl")("/images/sc.png"), v = e.userInfo && e.userInfo.is_writer ? null : e._f("formatImgUrl")("/images/si.png"), w = e.userInfo && e.userInfo.is_writer ? null : e._f("formatImgUrl")("/images/se.png"), b = e.userInfo && e.userInfo.is_writer ? null : e._f("formatImgUrl")("/images/sh.png"), U = e.userInfo && e.userInfo.is_writer || e.list.total ? null : e._f("formatImgUrl")("/images/empty.png"), $ = e.userInfo && e.userInfo.is_writer ? null : e.__map(e.rowList, function(r, n) {
                var t = e.__get_orig(r), o = e._f("formatImgUrl")("/images/je.png"), s = e.$db.get("userInfo"), i = r.writer_uid == s.membe_id ? e._f("formatImgUrl")(r.user.pic) : null, u = e.$db.get("userInfo");
                return {
                    $orig: t,
                    f22: o,
                    g4: s,
                    f23: i,
                    g5: u,
                    f24: r.writer_uid != u.membe_id ? e._f("formatImgUrl")(r.writer.pic) : null
                };
            });
            e._isMounted || (e.e0 = function(r) {
                "0" == e.userInfo.tuan_id ? e.$go("/pages/user/collective") : e.$go("/pages/user/success?id=" + e.userInfo.tuan_id);
            }, e.e1 = function(r, n) {
                var t;
                0 == (n = ((t = arguments[arguments.length - 1].currentTarget.dataset).eventParams || t["event-params"]).item).is_writer ? e.$go("/pages/user/orderdetail?id=" + n.id) : e.$go("/pages/my/connect?id=" + n.id);
            }, e.e2 = function(r, n) {
                var t;
                0 == (n = ((t = arguments[arguments.length - 1].currentTarget.dataset).eventParams || t["event-params"]).item).is_writer ? e.$go("/pages/user/orderdetail?id=" + n.id) : e.$go("/pages/my/connect?id=" + n.id);
            }), e.$mp.data = Object.assign({}, {
                $root: {
                    f0: r,
                    f1: n,
                    g0: t,
                    g1: o,
                    f2: s,
                    f3: i,
                    f4: u,
                    f5: a,
                    f6: f,
                    f7: l,
                    f8: g,
                    f9: c,
                    f10: m,
                    f11: d,
                    l0: _,
                    f15: p,
                    f16: h,
                    f17: I,
                    f18: v,
                    f19: w,
                    f20: b,
                    f21: U,
                    l1: $
                }
            });
        }, s = !1, i = [];
        o._withStripped = !0;
    },
    312: function(e, r, n) {
        "use strict";
        n.r(r);
        var t = n(313), o = n.n(t);
        for (var s in t) [ "default" ].indexOf(s) < 0 && function(e) {
            n.d(r, e, function() {
                return t[e];
            });
        }(s);
        r.default = o.a;
    },
    313: function(e, r, n) {
        "use strict";
        (function(e) {
            var t = n(13);
            Object.defineProperty(r, "__esModule", {
                value: !0
            }), r.default = void 0;
            var o = function(e, r) {
                if (!r && e && e.__esModule) return e;
                if (null === e || "object" !== t(e) && "function" != typeof e) return {
                    default: e
                };
                var n = s(r);
                if (n && n.has(e)) return n.get(e);
                var o = {}, i = Object.defineProperty && Object.getOwnPropertyDescriptor;
                for (var u in e) if ("default" !== u && Object.prototype.hasOwnProperty.call(e, u)) {
                    var a = i ? Object.getOwnPropertyDescriptor(e, u) : null;
                    a && (a.get || a.set) ? Object.defineProperty(o, u, a) : o[u] = e[u];
                }
                return o.default = e, n && n.set(e, o), o;
            }(n(168));
            function s(e) {
                if ("function" != typeof WeakMap) return null;
                var r = new WeakMap(), n = new WeakMap();
                return (s = function(e) {
                    return e ? n : r;
                })(e);
            }
            var i = {
                data: function() {
                    return {
                        personal: !1,
                        value: !1,
                        xuan: !1,
                        userInfo: this.$db.get("userInfo"),
                        page: 1,
                        list: {},
                        rowList: []
                    };
                },
                onShow: function() {
                    console.log("config11"), this.$db.get("config") && null != this.$db.get("config") && null != this.$db.get("config") || (console.log("config"), 
                    this.getConfig()), this.page = 1, this.rowList = [], this.list = [], this.getUserInfo(), 
                    this.getOrderList();
                },
                onPullDownRefresh: function() {
                    setTimeout(function() {
                        e.stopPullDownRefresh();
                    }, 800), console.log("refresh"), this.page = 1, this.rowList = [], this.list = [], 
                    this.getUserInfo(), this.getOrderList();
                },
                getConfig: function() {
                    var e = this;
                    this.$api.default.request("Common/getConfig").then(function(r) {
                        r.code && e.$db.set("config", r.data);
                    });
                },
                onLoad: function() {},
                onReachBottom: function() {
                    this.list.current_page < this.list.last_page && (this.page++, this.getOrderList());
                },
                methods: {
                    gologin: function() {
                        e.reLaunch({
                            url: "/pages/login/login"
                        });
                    },
                    no_go: function() {
                        this.$common.errorToShow("暂未开放");
                    },
                    getOrderList: function() {
                        var e = this;
                        this.$api.default.request("order/orderList_user", {
                            status: 2,
                            type: 2,
                            page: this.page
                        }, "POST", !0).then(function(r) {
                            1 == r.code && (e.list = r.data, r.data.current_page > 1 ? r.data.data.forEach(function(r) {
                                e.rowList.push(r);
                            }) : e.rowList = r.data.data);
                        });
                    },
                    saveWriterUserConfig: function() {
                        var r = this, n = o.get("auth");
                        if (console.log(n, 777777777), n) {
                            var t = this, s = {
                                order_receiving_status: this.userInfo.writer_user_config.order_receiving_status
                            };
                            this.userInfo.writer_user_config.hasOwnProperty("uid") || (s.uid = this.userInfo.writer_user_config.uid), 
                            this.userInfo.writer_user_config.word_price ? Array.isArray(this.userInfo.writer_diy_tags) && 0 === this.userInfo.writer_diy_tags.length ? this.$common.errorToShow("未设置标签") : this.$api.default.request("good/list", {
                                page: 1
                            }).then(function(e) {
                                e.code && (e.data.total ? t.$api.default.request("user/saveWriterUserConfig", s, "POST", !1).then(function(e) {
                                    1 == e.code ? console.log(e.msg) : t.$common.errorToShow(e.msg, function() {
                                        t.userInfo.writer_user_config.order_receiving_status = 0;
                                    });
                                }) : t.$common.errorToShow("请先上传橱窗商品", function() {
                                    t.userInfo.writer_user_config.order_receiving_status = 0;
                                }));
                            }) : this.$common.errorToShow("未设置价格", function() {
                                r.userInfo.writer_user_config.order_receiving_status = 0;
                            }, 1e3);
                        } else e.reLaunch({
                            url: "/pages/login/login"
                        });
                    },
                    isWriterApply: function() {
                        var r = o.get("auth");
                        console.log(r, 777777777), r ? this.userInfo.writer_apply && 2 != this.userInfo.writer_apply.status ? this.$go("/pages/user/examine") : this.$go("/pages/user/attestation") : e.reLaunch({
                            url: "/pages/login/login"
                        });
                    },
                    getUserInfo: function() {
                        var r = this;
                        this.$api.default.request("user/userInfo", {}, "POST", !1).then(function(n) {
                            if (n.code) {
                                if (r.userInfo = n.user, !n.user.membe_id || null == n.user) return void e.reLaunch({
                                    url: "/pages/login/login"
                                });
                                n.user.writer_user_config.hasOwnProperty("order_receiving_status") && (r.xuan = r.userInfo.writer_user_config.order_receiving_status);
                            } else r.$common.errorToShow(n.msg);
                        });
                    },
                    onChooseAvatar: function(e) {
                        var r = this;
                        this.$common.uploadImg(e.detail.avatarUrl, function(e) {
                            e && r.saveUser({
                                pic: e
                            });
                        });
                    },
                    bindNick: function(r) {
                        var n = o.get("auth");
                        console.log(n, 777777777), n ? r.detail.value != this.userInfo.username && (this.userInfo.username = r.detail.value ? r.detail.value : "默认昵称", 
                        this.saveUser({
                            username: this.userInfo.username
                        })) : e.reLaunch({
                            url: "/pages/login/login"
                        });
                    },
                    saveUser: function(r) {
                        var n = this, t = o.get("auth");
                        console.log(t, 777777777), t ? this.$api.default.request("user/saveUser", r).then(function(e) {
                            1 == e.code ? (n.userInfo = e.user, n.$common.successToShow(e.msg)) : n.$common.errorToShow(e.msg);
                        }) : e.reLaunch({
                            url: "/pages/login/login"
                        });
                    },
                    change: function(r) {
                        var n = o.get("auth");
                        console.log(n, 777777777), n ? (this.xuan = !this.xuan, this.saveWriterUserConfig()) : e.reLaunch({
                            url: "/pages/login/login"
                        });
                    }
                }
            };
            r.default = i;
        }).call(this, n(2).default);
    },
    314: function(e, r, n) {
        "use strict";
        n.r(r);
        var t = n(315), o = n.n(t);
        for (var s in t) [ "default" ].indexOf(s) < 0 && function(e) {
            n.d(r, e, function() {
                return t[e];
            });
        }(s);
        r.default = o.a;
    },
    315: function(e, r, n) {}
}, [ [ 308, "common/runtime", "common/vendor" ] ] ]);