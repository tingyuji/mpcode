(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/user/yuegao" ], {
    460: function(e, r, n) {
        "use strict";
        (function(e, r) {
            var t = n(4);
            n(26), t(n(25));
            var o = t(n(461));
            e.__webpack_require_UNI_MP_PLUGIN__ = n, r(o.default);
        }).call(this, n(1).default, n(2).createPage);
    },
    461: function(e, r, n) {
        "use strict";
        n.r(r);
        var t = n(462), o = n(464);
        for (var i in o) [ "default" ].indexOf(i) < 0 && function(e) {
            n.d(r, e, function() {
                return o[e];
            });
        }(i);
        n(466);
        var s = n(33), u = Object(s.default)(o.default, t.render, t.staticRenderFns, !1, null, null, null, !1, t.components, void 0);
        u.options.__file = "pages/user/yuegao.vue", r.default = u.exports;
    },
    462: function(e, r, n) {
        "use strict";
        n.r(r);
        var t = n(463);
        n.d(r, "render", function() {
            return t.render;
        }), n.d(r, "staticRenderFns", function() {
            return t.staticRenderFns;
        }), n.d(r, "recyclableRender", function() {
            return t.recyclableRender;
        }), n.d(r, "components", function() {
            return t.components;
        });
    },
    463: function(e, r, n) {
        "use strict";
        var t;
        n.r(r), n.d(r, "render", function() {
            return o;
        }), n.d(r, "staticRenderFns", function() {
            return s;
        }), n.d(r, "recyclableRender", function() {
            return i;
        }), n.d(r, "components", function() {
            return t;
        });
        try {
            t = {
                uSwitch: function() {
                    return Promise.all([ n.e("common/vendor"), n.e("node-modules/uview-ui/components/u-switch/u-switch") ]).then(n.bind(null, 936));
                }
            };
        } catch (e) {
            if (-1 === e.message.indexOf("Cannot find module") || -1 === e.message.indexOf(".vue")) throw e;
            console.error(e.message), console.error("1. 排查组件名称拼写是否正确"), console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"), 
            console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件");
        }
        var o = function() {
            this.$createElement;
            var e = (this._self._c, Object.keys(this.userInfo).length), r = e > 0 ? this._f("formatImgUrl")("/images/rarr.png") : null, n = e > 0 ? this._f("formatImgUrl")("/images/rarr.png") : null, t = e > 0 ? this._f("formatImgUrl")("/images/rarr.png") : null;
            this.$mp.data = Object.assign({}, {
                $root: {
                    g0: e,
                    f0: r,
                    f1: n,
                    f2: t
                }
            });
        }, i = !1, s = [];
        o._withStripped = !0;
    },
    464: function(e, r, n) {
        "use strict";
        n.r(r);
        var t = n(465), o = n.n(t);
        for (var i in t) [ "default" ].indexOf(i) < 0 && function(e) {
            n.d(r, e, function() {
                return t[e];
            });
        }(i);
        r.default = o.a;
    },
    465: function(e, r, n) {
        "use strict";
        Object.defineProperty(r, "__esModule", {
            value: !0
        }), r.default = void 0;
        var t = {
            data: function() {
                return {
                    type: 0,
                    array: this.$db.get("config").word_count_label,
                    index: 0,
                    value: !1,
                    show: !1,
                    userInfo: {}
                };
            },
            onLoad: function() {},
            onShow: function() {
                this.getUserInfo(), this.$db.get("config") && null != this.$db.get("config") && null != this.$db.get("config") || (console.log("config"), 
                this.getConfig());
            },
            methods: {
                saveWriterUserConfig: function() {
                    var e = this, r = this, n = {
                        order_receiving_status: this.userInfo.writer_user_config.order_receiving_status
                    };
                    this.userInfo.writer_user_config.hasOwnProperty("uid") || (n.uid = this.userInfo.writer_user_config.uid), 
                    this.userInfo.writer_user_config.word_price ? Array.isArray(this.userInfo.writer_diy_tags) && 0 === this.userInfo.writer_diy_tags.length ? this.$common.errorToShow("未设置标签") : this.$api.default.request("good/list", {
                        page: 1
                    }).then(function(e) {
                        e.code && (e.data.total ? r.$api.default.request("user/saveWriterUserConfig", n, "POST", !1).then(function(e) {
                            1 == e.code ? console.log(e.msg) : r.$common.errorToShow(e.msg, function() {
                                r.userInfo.writer_user_config.order_receiving_status = 0;
                            });
                        }) : r.$common.errorToShow("请先上传橱窗商品", function() {
                            r.userInfo.writer_user_config.order_receiving_status = 0;
                        }));
                    }) : this.$common.errorToShow("未设置价格", function() {
                        e.userInfo.writer_user_config.order_receiving_status = 0;
                    }, 1e3);
                },
                getUserInfo: function() {
                    var e = this;
                    this.$api.default.request("user/userInfo", {}, "POST", !1).then(function(r) {
                        r.code && (e.userInfo = r.user, e.userInfo.writer_user_config.word_count = e.userInfo.writer_user_config.word_count ? e.userInfo.writer_user_config.word_count : e.array[0], 
                        e.array.forEach(function(n, t) {
                            r.user.writer_user_config.word_count == n && (e.index = t);
                        }));
                    });
                }
            }
        };
        r.default = t;
    },
    466: function(e, r, n) {
        "use strict";
        n.r(r);
        var t = n(467), o = n.n(t);
        for (var i in t) [ "default" ].indexOf(i) < 0 && function(e) {
            n.d(r, e, function() {
                return t[e];
            });
        }(i);
        r.default = o.a;
    },
    467: function(e, r, n) {}
}, [ [ 460, "common/runtime", "common/vendor" ] ] ]);