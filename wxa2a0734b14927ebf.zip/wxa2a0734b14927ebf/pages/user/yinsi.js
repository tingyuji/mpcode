(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/user/yinsi" ], {
    452: function(e, n, t) {
        "use strict";
        (function(e, n) {
            var r = t(4);
            t(26), r(t(25));
            var o = r(t(453));
            e.__webpack_require_UNI_MP_PLUGIN__ = t, n(o.default);
        }).call(this, t(1).default, t(2).createPage);
    },
    453: function(e, n, t) {
        "use strict";
        t.r(n);
        var r = t(454), o = t(456);
        for (var i in o) [ "default" ].indexOf(i) < 0 && function(e) {
            t.d(n, e, function() {
                return o[e];
            });
        }(i);
        t(458);
        var s = t(33), u = Object(s.default)(o.default, r.render, r.staticRenderFns, !1, null, null, null, !1, r.components, void 0);
        u.options.__file = "pages/user/yinsi.vue", n.default = u.exports;
    },
    454: function(e, n, t) {
        "use strict";
        t.r(n);
        var r = t(455);
        t.d(n, "render", function() {
            return r.render;
        }), t.d(n, "staticRenderFns", function() {
            return r.staticRenderFns;
        }), t.d(n, "recyclableRender", function() {
            return r.recyclableRender;
        }), t.d(n, "components", function() {
            return r.components;
        });
    },
    455: function(e, n, t) {
        "use strict";
        var r;
        t.r(n), t.d(n, "render", function() {
            return o;
        }), t.d(n, "staticRenderFns", function() {
            return s;
        }), t.d(n, "recyclableRender", function() {
            return i;
        }), t.d(n, "components", function() {
            return r;
        });
        try {
            r = {
                uSwitch: function() {
                    return Promise.all([ t.e("common/vendor"), t.e("node-modules/uview-ui/components/u-switch/u-switch") ]).then(t.bind(null, 936));
                }
            };
        } catch (e) {
            if (-1 === e.message.indexOf("Cannot find module") || -1 === e.message.indexOf(".vue")) throw e;
            console.error(e.message), console.error("1. 排查组件名称拼写是否正确"), console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"), 
            console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件");
        }
        var o = function() {
            this.$createElement;
            var e = (this._self._c, Object.keys(this.userInfo).length);
            this.$mp.data = Object.assign({}, {
                $root: {
                    g0: e
                }
            });
        }, i = !1, s = [];
        o._withStripped = !0;
    },
    456: function(e, n, t) {
        "use strict";
        t.r(n);
        var r = t(457), o = t.n(r);
        for (var i in r) [ "default" ].indexOf(i) < 0 && function(e) {
            t.d(n, e, function() {
                return r[e];
            });
        }(i);
        n.default = o.a;
    },
    457: function(e, n, t) {
        "use strict";
        (function(e) {
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var t = {
                data: function() {
                    return {
                        type: 0,
                        array: this.$db.get("config").word_count_label,
                        index: 0,
                        value: !1,
                        show: !1,
                        userInfo: {}
                    };
                },
                onLoad: function() {},
                onShow: function() {
                    this.getUserInfo();
                },
                methods: {
                    setdata: function(e) {
                        this.type = e, this.show = !0;
                    },
                    setting: function() {
                        var e = this, n = this, t = {
                            word_price: this.userInfo.writer_user_config.word_price,
                            word_count: this.userInfo.writer_user_config.word_count
                        };
                        t.word_price ? this.$api.default.request("user/saveWriterUserConfig", t).then(function(e) {
                            1 == e.code && n.$common.successToShow(e.msg, function() {
                                n.show = !1;
                            });
                        }) : this.$common.errorToShow("请输入价格", function() {
                            e.userInfo.writer_user_config.order_receiving_status = 0;
                        }, 1e3);
                    },
                    submit: function() {
                        var n = arguments.length > 0 && void 0 !== arguments[0] && arguments[0], t = this, r = {
                            order_receiving_status: this.userInfo.writer_user_config.order_receiving_status
                        };
                        this.userInfo.writer_user_config.hasOwnProperty("uid") || (r.uid = this.userInfo.writer_user_config.uid), 
                        this.$api.default.request("good/list", {
                            page: 1
                        }).then(function(o) {
                            o.code && (o.data.total ? t.$api.default.request("user/saveWriterUserConfig", r).then(function(r) {
                                1 == r.code ? t.$common.successToShow(r.msg, function() {
                                    n && e.navigateBack();
                                }) : t.$common.errorToShow(r.msg, function() {
                                    t.userInfo.writer_user_config.order_receiving_status = 0;
                                });
                            }) : t.$common.errorToShow("请先上传橱窗商品", function() {
                                t.userInfo.writer_user_config.order_receiving_status = 0;
                            }));
                        });
                    },
                    getUserInfo: function() {
                        var e = this;
                        this.$api.default.request("user/userInfo", {}, "POST", !1).then(function(n) {
                            n.code && (e.userInfo = n.user, e.userInfo.writer_user_config.word_count = e.userInfo.writer_user_config.word_count ? e.userInfo.writer_user_config.word_count : e.array[0], 
                            e.array.forEach(function(t, r) {
                                n.user.writer_user_config.word_count == t && (e.index = r);
                            }));
                        });
                    },
                    change: function(n) {
                        e.showLoading({
                            title: "加载中",
                            mask: !0
                        }), this.$api.default.request("user/setUserRolue", {
                            type: n
                        }).then(function(n) {
                            e.hideLoading();
                        });
                    },
                    open: function() {},
                    close: function() {
                        this.show = !1;
                    },
                    bindPickerChange: function(e) {
                        console.log("picker发送选择改变，携带值为", e.detail.value), this.index = e.detail.value, this.userInfo.writer_user_config.word_count = this.array[e.detail.value];
                    }
                }
            };
            n.default = t;
        }).call(this, t(2).default);
    },
    458: function(e, n, t) {
        "use strict";
        t.r(n);
        var r = t(459), o = t.n(r);
        for (var i in r) [ "default" ].indexOf(i) < 0 && function(e) {
            t.d(n, e, function() {
                return r[e];
            });
        }(i);
        n.default = o.a;
    },
    459: function(e, n, t) {}
}, [ [ 452, "common/runtime", "common/vendor" ] ] ]);