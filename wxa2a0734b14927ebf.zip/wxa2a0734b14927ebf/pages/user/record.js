(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/user/record" ], {
    548: function(t, n, e) {
        "use strict";
        (function(t, n) {
            var r = e(4);
            e(26), r(e(25));
            var i = r(e(549));
            t.__webpack_require_UNI_MP_PLUGIN__ = e, n(i.default);
        }).call(this, e(1).default, e(2).createPage);
    },
    549: function(t, n, e) {
        "use strict";
        e.r(n);
        var r = e(550), i = e(552);
        for (var a in i) [ "default" ].indexOf(a) < 0 && function(t) {
            e.d(n, t, function() {
                return i[t];
            });
        }(a);
        e(554);
        var o = e(33), u = Object(o.default)(i.default, r.render, r.staticRenderFns, !1, null, null, null, !1, r.components, void 0);
        u.options.__file = "pages/user/record.vue", n.default = u.exports;
    },
    550: function(t, n, e) {
        "use strict";
        e.r(n);
        var r = e(551);
        e.d(n, "render", function() {
            return r.render;
        }), e.d(n, "staticRenderFns", function() {
            return r.staticRenderFns;
        }), e.d(n, "recyclableRender", function() {
            return r.recyclableRender;
        }), e.d(n, "components", function() {
            return r.components;
        });
    },
    551: function(t, n, e) {
        "use strict";
        e.r(n), e.d(n, "render", function() {
            return r;
        }), e.d(n, "staticRenderFns", function() {
            return a;
        }), e.d(n, "recyclableRender", function() {
            return i;
        }), e.d(n, "components", function() {});
        var r = function() {
            var t = this, n = (t.$createElement, t._self._c, t.list.total ? null : t._f("formatImgUrl")("/images/empty.png")), e = t.__map(t.recordList, function(n, e) {
                return {
                    $orig: t.__get_orig(n),
                    g0: t.$options.filters.parseTime(n.create_time, "{y} 年 {m} 月 {d} 日"),
                    f1: n.status ? t._f("formatImgUrl")("/images/rarr.png") : null,
                    l0: t.__map(n.image, function(n, e) {
                        return {
                            $orig: t.__get_orig(n),
                            f2: t._f("formatImgUrl")(n)
                        };
                    })
                };
            });
            t.$mp.data = Object.assign({}, {
                $root: {
                    f0: n,
                    l1: e
                }
            });
        }, i = !1, a = [];
        r._withStripped = !0;
    },
    552: function(t, n, e) {
        "use strict";
        e.r(n);
        var r = e(553), i = e.n(r);
        for (var a in r) [ "default" ].indexOf(a) < 0 && function(t) {
            e.d(n, t, function() {
                return r[t];
            });
        }(a);
        n.default = i.a;
    },
    553: function(t, n, e) {
        "use strict";
        (function(t) {
            var r = e(4);
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var i = r(e(165)), a = {
                data: function() {
                    return {
                        list: {},
                        recordList: [],
                        page: 1,
                        datas: null
                    };
                },
                onLoad: function() {},
                onShow: function() {
                    this.getList();
                },
                onReachBottom: function() {
                    this.list.current_page < this.list.last_page && (this.page++, this.getList());
                },
                methods: {
                    dianji: function(n) {
                        console.log(i.default.CdnUrl + n, 777);
                        var e = [];
                        e[0] = i.default.CdnUrl + n, t.previewImage({
                            current: 0,
                            urls: e
                        });
                    },
                    getList: function() {
                        var t = this;
                        this.$api.default.request("user/reportList").then(function(n) {
                            n.code && (t.list = n.data, n.data.current_page > 1 ? n.data.data.forEach(function(n) {
                                t.recordList.push(n);
                            }) : t.recordList = n.data.data);
                        });
                    },
                    shownei: function(t) {
                        this.datas = t;
                    }
                }
            };
            n.default = a;
        }).call(this, e(2).default);
    },
    554: function(t, n, e) {
        "use strict";
        e.r(n);
        var r = e(555), i = e.n(r);
        for (var a in r) [ "default" ].indexOf(a) < 0 && function(t) {
            e.d(n, t, function() {
                return r[t];
            });
        }(a);
        n.default = i.a;
    },
    555: function(t, n, e) {}
}, [ [ 548, "common/runtime", "common/vendor" ] ] ]);