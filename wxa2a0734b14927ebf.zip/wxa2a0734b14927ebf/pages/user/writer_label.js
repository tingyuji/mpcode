(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/user/writer_label" ], {
    532: function(e, n, t) {
        "use strict";
        (function(e, n) {
            var r = t(4);
            t(26), r(t(25));
            var o = r(t(533));
            e.__webpack_require_UNI_MP_PLUGIN__ = t, n(o.default);
        }).call(this, t(1).default, t(2).createPage);
    },
    533: function(e, n, t) {
        "use strict";
        t.r(n);
        var r = t(534), o = t(536);
        for (var i in o) [ "default" ].indexOf(i) < 0 && function(e) {
            t.d(n, e, function() {
                return o[e];
            });
        }(i);
        t(538);
        var s = t(33), u = Object(s.default)(o.default, r.render, r.staticRenderFns, !1, null, null, null, !1, r.components, void 0);
        u.options.__file = "pages/user/writer_label.vue", n.default = u.exports;
    },
    534: function(e, n, t) {
        "use strict";
        t.r(n);
        var r = t(535);
        t.d(n, "render", function() {
            return r.render;
        }), t.d(n, "staticRenderFns", function() {
            return r.staticRenderFns;
        }), t.d(n, "recyclableRender", function() {
            return r.recyclableRender;
        }), t.d(n, "components", function() {
            return r.components;
        });
    },
    535: function(e, n, t) {
        "use strict";
        var r;
        t.r(n), t.d(n, "render", function() {
            return o;
        }), t.d(n, "staticRenderFns", function() {
            return s;
        }), t.d(n, "recyclableRender", function() {
            return i;
        }), t.d(n, "components", function() {
            return r;
        });
        try {
            r = {
                uIcon: function() {
                    return Promise.all([ t.e("common/vendor"), t.e("node-modules/uview-ui/components/u-icon/u-icon") ]).then(t.bind(null, 927));
                }
            };
        } catch (e) {
            if (-1 === e.message.indexOf("Cannot find module") || -1 === e.message.indexOf(".vue")) throw e;
            console.error(e.message), console.error("1. 排查组件名称拼写是否正确"), console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"), 
            console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件");
        }
        var o = function() {
            this.$createElement;
            var e = (this._self._c, this.userInfo.writer_diy_tags.length);
            this.$mp.data = Object.assign({}, {
                $root: {
                    g0: e
                }
            });
        }, i = !1, s = [];
        o._withStripped = !0;
    },
    536: function(e, n, t) {
        "use strict";
        t.r(n);
        var r = t(537), o = t.n(r);
        for (var i in r) [ "default" ].indexOf(i) < 0 && function(e) {
            t.d(n, e, function() {
                return r[e];
            });
        }(i);
        n.default = o.a;
    },
    537: function(e, n, t) {
        "use strict";
        (function(e) {
            var r = t(4);
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var o = r(t(18)), i = {
                data: function() {
                    return {
                        userInfo: this.$db.get("userInfo"),
                        erList: [],
                        label: ""
                    };
                },
                onLoad: function() {},
                onShow: function() {
                    this.getUserInfo();
                },
                methods: {
                    submit: function() {
                        var e = this;
                        if (this.label) {
                            var n = this.userInfo.writer_diy_tags, t = "";
                            if (n.length) {
                                var r = !1;
                                if (n.forEach(function(n) {
                                    n == e.label && (r = !0);
                                }), r) return void this.$common.errorToShow("标签不能重复");
                                n.push(this.label), t = n.join(",");
                            } else t = this.label;
                            this.saveLabel({
                                writer_diy_tags: t
                            }, !1);
                        } else this.$common.errorToShow("请输入标签");
                    },
                    getUserInfo: function() {
                        var e = this;
                        this.$api.default.request("user/userInfo", {}, "GET", !1).then(function(n) {
                            n.code ? (e.userInfo = n.user, e.userInfo.writer_diy_tags || (e.userInfo.writer_diy_tags = [])) : e.$common.errorToShow(n.msg);
                        });
                    },
                    delUserTags: function(e) {
                        var n = (0, o.default)(this.userInfo.writer_diy_tags);
                        n.splice(e, 1), this.saveLabel({
                            writer_diy_tags: n.join(",")
                        }, !1);
                    },
                    saveLabel: function(n) {
                        var t = this, r = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
                        this.$api.default.request("user/saveUser", n, "POST", !1).then(function(n) {
                            1 == n.code ? (t.label = "", t.userInfo = n.user, t.$common.successToShow("更新成功", function() {
                                t.getUserInfo(), r && e.navigateBack();
                            })) : t.$common.errorToShow(n.msg);
                        });
                    }
                }
            };
            n.default = i;
        }).call(this, t(2).default);
    },
    538: function(e, n, t) {
        "use strict";
        t.r(n);
        var r = t(539), o = t.n(r);
        for (var i in r) [ "default" ].indexOf(i) < 0 && function(e) {
            t.d(n, e, function() {
                return r[e];
            });
        }(i);
        n.default = o.a;
    },
    539: function(e, n, t) {}
}, [ [ 532, "common/runtime", "common/vendor" ] ] ]);