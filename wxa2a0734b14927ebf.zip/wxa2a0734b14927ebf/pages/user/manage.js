(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/user/manage" ], {
    540: function(e, n, r) {
        "use strict";
        (function(e, n) {
            var t = r(4);
            r(26), t(r(25));
            var o = t(r(541));
            e.__webpack_require_UNI_MP_PLUGIN__ = r, n(o.default);
        }).call(this, r(1).default, r(2).createPage);
    },
    541: function(e, n, r) {
        "use strict";
        r.r(n);
        var t = r(542), o = r(544);
        for (var i in o) [ "default" ].indexOf(i) < 0 && function(e) {
            r.d(n, e, function() {
                return o[e];
            });
        }(i);
        r(546);
        var u = r(33), s = Object(u.default)(o.default, t.render, t.staticRenderFns, !1, null, null, null, !1, t.components, void 0);
        s.options.__file = "pages/user/manage.vue", n.default = s.exports;
    },
    542: function(e, n, r) {
        "use strict";
        r.r(n);
        var t = r(543);
        r.d(n, "render", function() {
            return t.render;
        }), r.d(n, "staticRenderFns", function() {
            return t.staticRenderFns;
        }), r.d(n, "recyclableRender", function() {
            return t.recyclableRender;
        }), r.d(n, "components", function() {
            return t.components;
        });
    },
    543: function(e, n, r) {
        "use strict";
        var t;
        r.r(n), r.d(n, "render", function() {
            return o;
        }), r.d(n, "staticRenderFns", function() {
            return u;
        }), r.d(n, "recyclableRender", function() {
            return i;
        }), r.d(n, "components", function() {
            return t;
        });
        try {
            t = {
                uPopup: function() {
                    return Promise.all([ r.e("common/vendor"), r.e("node-modules/uview-ui/components/u-popup/u-popup") ]).then(r.bind(null, 890));
                }
            };
        } catch (e) {
            if (-1 === e.message.indexOf("Cannot find module") || -1 === e.message.indexOf(".vue")) throw e;
            console.error(e.message), console.error("1. 排查组件名称拼写是否正确"), console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"), 
            console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件");
        }
        var o = function() {
            var e = this, n = (e.$createElement, e._self._c, Object.keys(e.userInfo).length), r = n > 0 ? e._f("formatImgUrl")("/images/rarr.png") : null, t = n > 0 ? e._f("formatImgUrl")("/images/rarr.png") : null, o = n > 0 ? e._f("formatImgUrl")("/images/rarr.png") : null;
            e._isMounted || (e.e0 = function(n) {
                e.show = !1;
            }), e.$mp.data = Object.assign({}, {
                $root: {
                    g0: n,
                    f0: r,
                    f1: t,
                    f2: o
                }
            });
        }, i = !1, u = [];
        o._withStripped = !0;
    },
    544: function(e, n, r) {
        "use strict";
        r.r(n);
        var t = r(545), o = r.n(t);
        for (var i in t) [ "default" ].indexOf(i) < 0 && function(e) {
            r.d(n, e, function() {
                return t[e];
            });
        }(i);
        n.default = o.a;
    },
    545: function(e, n, r) {
        "use strict";
        (function(e) {
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var r = {
                data: function() {
                    return {
                        type: 0,
                        array: this.$db.get("config").word_count_label,
                        index: 0,
                        value: !1,
                        show: !1,
                        userInfo: {}
                    };
                },
                onLoad: function() {},
                onShow: function() {
                    this.getUserInfo();
                },
                methods: {
                    setdata: function(e) {
                        this.type = e, this.show = !0;
                    },
                    setting: function() {
                        var e = this, n = this, r = {
                            word_price: this.userInfo.writer_user_config.word_price,
                            word_count: this.userInfo.writer_user_config.word_count
                        };
                        r.word_price ? this.$api.default.request("user/saveWriterUserConfig", r).then(function(e) {
                            1 == e.code && n.$common.successToShow(e.msg, function() {
                                n.show = !1;
                            });
                        }) : this.$common.errorToShow("请输入价格", function() {
                            e.userInfo.writer_user_config.order_receiving_status = 0;
                        }, 1e3);
                    },
                    submit: function() {
                        var n = arguments.length > 0 && void 0 !== arguments[0] && arguments[0], r = this, t = {
                            order_receiving_status: this.userInfo.writer_user_config.order_receiving_status
                        };
                        this.userInfo.writer_user_config.hasOwnProperty("uid") || (t.uid = this.userInfo.writer_user_config.uid), 
                        this.$api.default.request("good/list", {
                            page: 1
                        }).then(function(o) {
                            o.code && (o.data.total ? r.$api.default.request("user/saveWriterUserConfig", t).then(function(t) {
                                1 == t.code ? r.$common.successToShow(t.msg, function() {
                                    n && e.navigateBack();
                                }) : r.$common.errorToShow(t.msg, function() {
                                    r.userInfo.writer_user_config.order_receiving_status = 0;
                                });
                            }) : r.$common.errorToShow("请先上传橱窗商品", function() {
                                r.userInfo.writer_user_config.order_receiving_status = 0;
                            }));
                        });
                    },
                    getUserInfo: function() {
                        var e = this;
                        this.$api.default.request("user/userInfo", {}, "POST", !1).then(function(n) {
                            n.code && (e.userInfo = n.user, e.userInfo.writer_user_config.word_count = e.userInfo.writer_user_config.word_count ? e.userInfo.writer_user_config.word_count : e.array[0], 
                            e.array.forEach(function(r, t) {
                                n.user.writer_user_config.word_count == r && (e.index = t);
                            }));
                        });
                    },
                    change: function(e) {
                        this.xuan = !this.xuan, this.submit();
                    },
                    open: function() {},
                    close: function() {
                        this.show = !1;
                    },
                    bindPickerChange: function(e) {
                        console.log("picker发送选择改变，携带值为", e.detail.value), this.index = e.detail.value, this.userInfo.writer_user_config.word_count = this.array[e.detail.value];
                    }
                }
            };
            n.default = r;
        }).call(this, r(2).default);
    },
    546: function(e, n, r) {
        "use strict";
        r.r(n);
        var t = r(547), o = r.n(t);
        for (var i in t) [ "default" ].indexOf(i) < 0 && function(e) {
            r.d(n, e, function() {
                return t[e];
            });
        }(i);
        n.default = o.a;
    },
    547: function(e, n, r) {}
}, [ [ 540, "common/runtime", "common/vendor" ] ] ]);