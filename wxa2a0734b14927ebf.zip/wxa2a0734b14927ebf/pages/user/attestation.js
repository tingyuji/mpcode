(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/user/attestation" ], {
    564: function(e, t, n) {
        "use strict";
        (function(e, t) {
            var o = n(4);
            n(26), o(n(25));
            var i = o(n(565));
            e.__webpack_require_UNI_MP_PLUGIN__ = n, t(i.default);
        }).call(this, n(1).default, n(2).createPage);
    },
    565: function(e, t, n) {
        "use strict";
        n.r(t);
        var o = n(566), i = n(568);
        for (var r in i) [ "default" ].indexOf(r) < 0 && function(e) {
            n.d(t, e, function() {
                return i[e];
            });
        }(r);
        n(570);
        var u = n(33), s = Object(u.default)(i.default, o.render, o.staticRenderFns, !1, null, null, null, !1, o.components, void 0);
        s.options.__file = "pages/user/attestation.vue", t.default = s.exports;
    },
    566: function(e, t, n) {
        "use strict";
        n.r(t);
        var o = n(567);
        n.d(t, "render", function() {
            return o.render;
        }), n.d(t, "staticRenderFns", function() {
            return o.staticRenderFns;
        }), n.d(t, "recyclableRender", function() {
            return o.recyclableRender;
        }), n.d(t, "components", function() {
            return o.components;
        });
    },
    567: function(e, t, n) {
        "use strict";
        var o;
        n.r(t), n.d(t, "render", function() {
            return i;
        }), n.d(t, "staticRenderFns", function() {
            return u;
        }), n.d(t, "recyclableRender", function() {
            return r;
        }), n.d(t, "components", function() {
            return o;
        });
        try {
            o = {
                uPopup: function() {
                    return Promise.all([ n.e("common/vendor"), n.e("node-modules/uview-ui/components/u-popup/u-popup") ]).then(n.bind(null, 890));
                }
            };
        } catch (e) {
            if (-1 === e.message.indexOf("Cannot find module") || -1 === e.message.indexOf(".vue")) throw e;
            console.error(e.message), console.error("1. 排查组件名称拼写是否正确"), console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"), 
            console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件");
        }
        var i = function() {
            var e = this, t = (e.$createElement, e._self._c, e._f("formatImgUrl")("/images/qbg_02.png")), n = e.__map(e.form.img, function(t, n) {
                return {
                    $orig: e.__get_orig(t),
                    f1: e._f("formatImgUrl")(t)
                };
            }), o = e.form.img.length, i = o < 3 ? e._f("formatImgUrl")("/images/upp.png") : null, r = e._f("formatImgUrl")("/images/close.png");
            e._isMounted || (e.e0 = function(t) {
                e.tuishow = !0;
            }, e.e1 = function(t) {
                e.tuishow = !1;
            }), e.$mp.data = Object.assign({}, {
                $root: {
                    f0: t,
                    l0: n,
                    g0: o,
                    f2: i,
                    f3: r
                }
            });
        }, r = !1, u = [];
        i._withStripped = !0;
    },
    568: function(e, t, n) {
        "use strict";
        n.r(t);
        var o = n(569), i = n.n(o);
        for (var r in o) [ "default" ].indexOf(r) < 0 && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(r);
        t.default = i.a;
    },
    569: function(e, t, n) {
        "use strict";
        (function(e) {
            var o = n(4);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var i = {
                data: function() {
                    return {
                        form: {
                            img: [],
                            style: ""
                        },
                        paddingBottomHeight: 0,
                        fileList: [],
                        shuru: !0,
                        isRead: !1,
                        tuishow: !1,
                        biaoqian: []
                    };
                },
                onShow: function() {
                    this.form.style = e.getStorageSync("writer_tags");
                },
                onLoad: function() {},
                created: function() {
                    var t = this;
                    e.getSystemInfo({
                        success: function(e) {
                            [ "X", "XR", "XS", "11", "12", "13", "14", "15" ].forEach(function(n) {
                                -1 != e.model.indexOf(n) && -1 != e.model.indexOf("iPhone") && (t.paddingBottomHeight = 40);
                            });
                        }
                    });
                    var n = getCurrentPages();
                    this.urlPath = "/" + n[0].route;
                },
                methods: (0, o(n(11)).default)({
                    goToxie: function(t) {
                        e.navigateTo({
                            url: "/pages/user/abount_dea?id=" + t
                        }), console.log(this.$config.default.Url + "/agreement/1000006", 77);
                    },
                    taiTab: function() {
                        this.isRead = 2 == this.isRead ? 0 : 2, this.shuru = !this.shuru;
                    },
                    tuigroup: function() {
                        this.tuishow = !0;
                    },
                    tuiclose: function() {
                        this.tuishow = !1;
                    },
                    submit: function() {
                        if (this.isRead) {
                            if (!this.form.pen_age) return void this.$common.errorToShow("请输入笔龄");
                            if (!this.form.style) return void this.$common.errorToShow("请输入上传风格");
                            if (!this.form.img.length) return void this.$common.errorToShow("请上传作品图片");
                            var t = this;
                            e.requestSubscribeMessage({
                                tmplIds: [ "rw8um2woPZuyWmlZFrRYLslXmrIHd1MmcUTry7Ci3Yw" ],
                                success: function(n) {
                                    t.$api.default.request("writer/writerApply", t.form).then(function(n) {
                                        n.code ? t.$common.successToShow(n.msg, function() {
                                            e.redirectTo({
                                                url: "/pages/user/examine"
                                            });
                                        }) : setTimeout(function() {
                                            e.navigateBack();
                                        }, 1500);
                                    });
                                },
                                fail: function(n) {
                                    t.$api.default.request("writer/writerApply", t.form).then(function(n) {
                                        n.code ? t.$common.successToShow(n.msg, function() {
                                            e.redirectTo({
                                                url: "/pages/user/examine"
                                            });
                                        }) : setTimeout(function() {
                                            e.navigateBack();
                                        }, 1500);
                                    });
                                }
                            });
                        } else this.isReadTip();
                    },
                    isReadTip: function() {
                        var e = this;
                        if (!this.isRead) return this.$common.errorToShow("请先同意写手入团协议"), this.isRead = 1, 
                        void setTimeout(function() {
                            e.isRead = 0;
                        }, 300);
                    },
                    deletePic: function(e) {
                        this.form.img.splice(e, 1);
                    },
                    onChooseImg: function() {
                        var e = this;
                        this.$common.chooseImage({}, function(t) {
                            t && e.form.img.push(t);
                        }, 3);
                    },
                    open: function() {}
                }, "tuiclose", function() {
                    this.tuishow = !1;
                })
            };
            t.default = i;
        }).call(this, n(2).default);
    },
    570: function(e, t, n) {
        "use strict";
        n.r(t);
        var o = n(571), i = n.n(o);
        for (var r in o) [ "default" ].indexOf(r) < 0 && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(r);
        t.default = i.a;
    },
    571: function(e, t, n) {}
}, [ [ 564, "common/runtime", "common/vendor" ] ] ]);