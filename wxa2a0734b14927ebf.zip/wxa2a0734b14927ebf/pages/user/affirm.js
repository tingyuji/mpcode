(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/user/affirm" ], {
    420: function(e, n, t) {
        "use strict";
        (function(e, n) {
            var i = t(4);
            t(26), i(t(25));
            var r = i(t(421));
            e.__webpack_require_UNI_MP_PLUGIN__ = t, n(r.default);
        }).call(this, t(1).default, t(2).createPage);
    },
    421: function(e, n, t) {
        "use strict";
        t.r(n);
        var i = t(422), r = t(424);
        for (var o in r) [ "default" ].indexOf(o) < 0 && function(e) {
            t.d(n, e, function() {
                return r[e];
            });
        }(o);
        t(426);
        var u = t(33), a = Object(u.default)(r.default, i.render, i.staticRenderFns, !1, null, null, null, !1, i.components, void 0);
        a.options.__file = "pages/user/affirm.vue", n.default = a.exports;
    },
    422: function(e, n, t) {
        "use strict";
        t.r(n);
        var i = t(423);
        t.d(n, "render", function() {
            return i.render;
        }), t.d(n, "staticRenderFns", function() {
            return i.staticRenderFns;
        }), t.d(n, "recyclableRender", function() {
            return i.recyclableRender;
        }), t.d(n, "components", function() {
            return i.components;
        });
    },
    423: function(e, n, t) {
        "use strict";
        t.r(n), t.d(n, "render", function() {
            return i;
        }), t.d(n, "staticRenderFns", function() {
            return o;
        }), t.d(n, "recyclableRender", function() {
            return r;
        }), t.d(n, "components", function() {});
        var i = function() {
            var e = this, n = (e.$createElement, e._self._c, e._f("formatImgUrl")("/images/qbg_02.png")), t = e.info.hasOwnProperty("id") && void 0 !== e.info.id, i = t ? e._f("formatImgUrl")("/images/zhang_01.png") : null;
            e._isMounted || (e.e0 = function(n) {
                e.isRead = 2 == e.isRead ? 0 : 2;
            }), e.$mp.data = Object.assign({}, {
                $root: {
                    f0: n,
                    g0: t,
                    f1: i
                }
            });
        }, r = !1, o = [];
        i._withStripped = !0;
    },
    424: function(e, n, t) {
        "use strict";
        t.r(n);
        var i = t(425), r = t.n(i);
        for (var o in i) [ "default" ].indexOf(o) < 0 && function(e) {
            t.d(n, e, function() {
                return i[e];
            });
        }(o);
        n.default = r.a;
    },
    425: function(e, n, t) {
        "use strict";
        (function(e) {
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var t = {
                data: function() {
                    return {
                        paddingBottomHeight: 0,
                        number: "",
                        info: {},
                        isRead: !1
                    };
                },
                onLoad: function(e) {
                    e.number ? (this.number = e.number, this.getInfo()) : this.$common.errorToShow("参数异常");
                },
                created: function() {
                    var n = this;
                    e.getSystemInfo({
                        success: function(e) {
                            [ "X", "XR", "XS", "11", "12", "13", "14", "15" ].forEach(function(t) {
                                -1 != e.model.indexOf(t) && -1 != e.model.indexOf("iPhone") && (n.paddingBottomHeight = 40);
                            });
                        }
                    });
                    var t = getCurrentPages();
                    this.urlPath = "/" + t[0].route;
                },
                methods: {
                    goToxie: function() {
                        e.navigateTo({
                            url: "/pages/webview/webview?url=" + this.$config.default.Url + "/agreement/1000007"
                        });
                    },
                    getInfo: function() {
                        var e = this;
                        this.$api.default.request("user/searchTeam", {
                            num: this.number
                        }, "POST", !1).then(function(n) {
                            n.code && (e.info = n.data);
                        });
                    },
                    postApply: function() {
                        var n = this;
                        2 == this.isRead ? this.$api.default.request("user/applyTeam", {
                            id: this.info.id
                        }, "POST", !1).then(function(t) {
                            t.code && n.$common.successToShow(t.msg, function() {
                                e.reLaunch({
                                    url: "/pages/user/success?id=" + t.data.id
                                });
                            });
                        }) : this.isReadTip();
                    },
                    isReadTip: function() {
                        var e = this;
                        if (!this.isRead) return this.$common.errorToShow("请先同意用户协议"), this.isRead = 1, 
                        void setTimeout(function() {
                            e.isRead = 0;
                        }, 300);
                    }
                }
            };
            n.default = t;
        }).call(this, t(2).default);
    },
    426: function(e, n, t) {
        "use strict";
        t.r(n);
        var i = t(427), r = t.n(i);
        for (var o in i) [ "default" ].indexOf(o) < 0 && function(e) {
            t.d(n, e, function() {
                return i[e];
            });
        }(o);
        n.default = r.a;
    },
    427: function(e, n, t) {}
}, [ [ 420, "common/runtime", "common/vendor" ] ] ]);