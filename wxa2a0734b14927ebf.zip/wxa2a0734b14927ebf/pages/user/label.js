(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/user/label" ], {
    524: function(e, n, t) {
        "use strict";
        (function(e, n) {
            var o = t(4);
            t(26), o(t(25));
            var r = o(t(525));
            e.__webpack_require_UNI_MP_PLUGIN__ = t, n(r.default);
        }).call(this, t(1).default, t(2).createPage);
    },
    525: function(e, n, t) {
        "use strict";
        t.r(n);
        var o = t(526), r = t(528);
        for (var s in r) [ "default" ].indexOf(s) < 0 && function(e) {
            t.d(n, e, function() {
                return r[e];
            });
        }(s);
        t(530);
        var u = t(33), i = Object(u.default)(r.default, o.render, o.staticRenderFns, !1, null, null, null, !1, o.components, void 0);
        i.options.__file = "pages/user/label.vue", n.default = i.exports;
    },
    526: function(e, n, t) {
        "use strict";
        t.r(n);
        var o = t(527);
        t.d(n, "render", function() {
            return o.render;
        }), t.d(n, "staticRenderFns", function() {
            return o.staticRenderFns;
        }), t.d(n, "recyclableRender", function() {
            return o.recyclableRender;
        }), t.d(n, "components", function() {
            return o.components;
        });
    },
    527: function(e, n, t) {
        "use strict";
        var o;
        t.r(n), t.d(n, "render", function() {
            return r;
        }), t.d(n, "staticRenderFns", function() {
            return u;
        }), t.d(n, "recyclableRender", function() {
            return s;
        }), t.d(n, "components", function() {
            return o;
        });
        try {
            o = {
                uIcon: function() {
                    return Promise.all([ t.e("common/vendor"), t.e("node-modules/uview-ui/components/u-icon/u-icon") ]).then(t.bind(null, 927));
                }
            };
        } catch (e) {
            if (-1 === e.message.indexOf("Cannot find module") || -1 === e.message.indexOf(".vue")) throw e;
            console.error(e.message), console.error("1. 排查组件名称拼写是否正确"), console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"), 
            console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件");
        }
        var r = function() {
            this.$createElement;
            this._self._c;
        }, s = !1, u = [];
        r._withStripped = !0;
    },
    528: function(e, n, t) {
        "use strict";
        t.r(n);
        var o = t(529), r = t.n(o);
        for (var s in o) [ "default" ].indexOf(s) < 0 && function(e) {
            t.d(n, e, function() {
                return o[e];
            });
        }(s);
        n.default = r.a;
    },
    529: function(e, n, t) {
        "use strict";
        (function(e) {
            var o = t(4);
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var r = o(t(18)), s = {
                data: function() {
                    return {
                        userInfo: this.$db.get("userInfo"),
                        erList: [],
                        label: ""
                    };
                },
                onLoad: function() {},
                onShow: function() {
                    this.getUserInfo();
                },
                methods: {
                    submit: function() {
                        var e = this;
                        if (this.label) {
                            var n = this.userInfo.user_tags, t = "";
                            if (n.length) {
                                var o = !1;
                                if (n.forEach(function(n) {
                                    n == e.label && (o = !0);
                                }), o) return void this.$common.errorToShow("标签不能重复");
                                n.push(this.label), t = n.join(",");
                            } else t = this.label;
                            this.saveLabel({
                                user_tags: t
                            }, !1);
                        } else this.$common.errorToShow("请输入标签");
                    },
                    getUserInfo: function() {
                        var e = this;
                        this.$api.default.request("user/userInfo", {}, "GET", !1).then(function(n) {
                            n.code ? (e.userInfo = n.user, e.userInfo.user_tags || (e.userInfo.user_tags = [])) : e.$common.errorToShow(n.msg);
                        });
                    },
                    delUserTags: function(e) {
                        var n = (0, r.default)(this.userInfo.user_tags);
                        n.splice(e, 1), console.log(n), this.saveLabel({
                            user_tags: n.join(",")
                        }, !1);
                    },
                    saveLabel: function(n) {
                        var t = this, o = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
                        this.$api.default.request("user/saveUser", n, "POST", !1).then(function(n) {
                            1 == n.code ? (t.userInfo = n.user, t.$common.successToShow("更新成功", function() {
                                t.getUserInfo(), o && e.navigateBack(), t.label = "";
                            })) : t.$common.errorToShow(n.msg);
                        });
                    }
                }
            };
            n.default = s;
        }).call(this, t(2).default);
    },
    530: function(e, n, t) {
        "use strict";
        t.r(n);
        var o = t(531), r = t.n(o);
        for (var s in o) [ "default" ].indexOf(s) < 0 && function(e) {
            t.d(n, e, function() {
                return o[e];
            });
        }(s);
        n.default = r.a;
    },
    531: function(e, n, t) {}
}, [ [ 524, "common/runtime", "common/vendor" ] ] ]);