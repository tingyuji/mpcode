(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/user/releasedetail" ], {
    348: function(e, n, t) {
        "use strict";
        (function(e, n) {
            var r = t(4);
            t(26), r(t(25));
            var o = r(t(349));
            e.__webpack_require_UNI_MP_PLUGIN__ = t, n(o.default);
        }).call(this, t(1).default, t(2).createPage);
    },
    349: function(e, n, t) {
        "use strict";
        t.r(n);
        var r = t(350), o = t(352);
        for (var i in o) [ "default" ].indexOf(i) < 0 && function(e) {
            t.d(n, e, function() {
                return o[e];
            });
        }(i);
        t(354);
        var a = t(33), u = Object(a.default)(o.default, r.render, r.staticRenderFns, !1, null, null, null, !1, r.components, void 0);
        u.options.__file = "pages/user/releasedetail.vue", n.default = u.exports;
    },
    350: function(e, n, t) {
        "use strict";
        t.r(n);
        var r = t(351);
        t.d(n, "render", function() {
            return r.render;
        }), t.d(n, "staticRenderFns", function() {
            return r.staticRenderFns;
        }), t.d(n, "recyclableRender", function() {
            return r.recyclableRender;
        }), t.d(n, "components", function() {
            return r.components;
        });
    },
    351: function(e, n, t) {
        "use strict";
        var r;
        t.r(n), t.d(n, "render", function() {
            return o;
        }), t.d(n, "staticRenderFns", function() {
            return a;
        }), t.d(n, "recyclableRender", function() {
            return i;
        }), t.d(n, "components", function() {
            return r;
        });
        try {
            r = {
                uPopup: function() {
                    return Promise.all([ t.e("common/vendor"), t.e("node-modules/uview-ui/components/u-popup/u-popup") ]).then(t.bind(null, 890));
                }
            };
        } catch (e) {
            if (-1 === e.message.indexOf("Cannot find module") || -1 === e.message.indexOf(".vue")) throw e;
            console.error(e.message), console.error("1. 排查组件名称拼写是否正确"), console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"), 
            console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件");
        }
        var o = function() {
            var e = this, n = (e.$createElement, e._self._c, e._f("formatImgUrl")("/images/bao.png")), t = e._f("formatImgUrl")("/images/myhead.png"), r = e._f("formatImgUrl")("/images/ja.png"), o = e._f("formatImgUrl")("/images/jb.png"), i = e._f("formatImgUrl")("/images/futu.png"), a = e._f("formatImgUrl")("/images/ja.png"), u = e._f("formatImgUrl")("/images/jb.png"), s = e._f("formatImgUrl")("/images/rarr.png"), c = e._f("formatImgUrl")("/images/rarr.png");
            e._isMounted || (e.e0 = function(n) {
                e.show = !0;
            }, e.e1 = function(n) {
                e.show = !1;
            }), e.$mp.data = Object.assign({}, {
                $root: {
                    f0: n,
                    f1: t,
                    f2: r,
                    f3: o,
                    f4: i,
                    f5: a,
                    f6: u,
                    f7: s,
                    f8: c
                }
            });
        }, i = !1, a = [];
        o._withStripped = !0;
    },
    352: function(e, n, t) {
        "use strict";
        t.r(n);
        var r = t(353), o = t.n(r);
        for (var i in r) [ "default" ].indexOf(i) < 0 && function(e) {
            t.d(n, e, function() {
                return r[e];
            });
        }(i);
        n.default = o.a;
    },
    353: function(e, n, t) {
        "use strict";
        (function(e) {
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var t = {
                data: function() {
                    return {
                        show: !1,
                        paddingBottomHeight: 0,
                        erList: [ {
                            qian: "二次元"
                        }, {
                            qian: "萝莉"
                        }, {
                            qian: "漫画"
                        } ],
                        lunList: [ {
                            istrue: !1,
                            isLiked: !1,
                            head: "https://dream-yw.web.hlidc.cn/images/headd.png",
                            nickname: "赢得仓皇北顾",
                            fuwen: "吾生也有涯，而知也无涯。以有涯随无涯，殆已！已而为知者，殆而已矣！为善无近名，为恶无近刑，缘督以为经，可以保身，可以全生，可以养亲，可以尽年。",
                            hui: "共14条回复>",
                            time: "2048 - 12 - 12 22:16",
                            zan: "710"
                        }, {
                            istrue: !1,
                            isLiked: !1,
                            head: "https://dream-yw.web.hlidc.cn/images/heada.png",
                            nickname: "赢得仓皇北顾",
                            fuwen: "吾生也有涯，而知也无涯。以有涯随无涯，殆已！已而为知者，殆而已矣！为善无近名，为恶无近刑，缘督以为经，可以保身，可以全生，可以养亲，可以尽年。",
                            hui: "共14条回复>",
                            time: "2048 - 12 - 12 22:16",
                            zan: "710"
                        } ]
                    };
                },
                onLoad: function() {},
                created: function() {
                    var n = this;
                    e.getSystemInfo({
                        success: function(e) {
                            [ "X", "XR", "XS", "11", "12", "13", "14", "15" ].forEach(function(t) {
                                -1 != e.model.indexOf(t) && -1 != e.model.indexOf("iPhone") && (n.paddingBottomHeight = 40);
                            });
                        }
                    });
                    var t = getCurrentPages();
                    this.urlPath = "/" + t[0].route;
                },
                methods: {
                    toggleLike: function(e) {
                        console.log(e), this.lunList[e].isLiked = !this.lunList[e].isLiked, this.lunList[e].istrue = !this.lunList[e].istrue;
                    },
                    open: function() {},
                    close: function() {
                        this.show = !1;
                    },
                    goToreport: function() {
                        this.show = !1, e.navigateTo({
                            url: "/pages/find/report"
                        });
                    },
                    goToedit: function() {
                        this.show = !1, e.navigateTo({
                            url: "/pages/user/edit"
                        });
                    }
                }
            };
            n.default = t;
        }).call(this, t(2).default);
    },
    354: function(e, n, t) {
        "use strict";
        t.r(n);
        var r = t(355), o = t.n(r);
        for (var i in r) [ "default" ].indexOf(i) < 0 && function(e) {
            t.d(n, e, function() {
                return r[e];
            });
        }(i);
        n.default = o.a;
    },
    355: function(e, n, t) {}
}, [ [ 348, "common/runtime", "common/vendor" ] ] ]);