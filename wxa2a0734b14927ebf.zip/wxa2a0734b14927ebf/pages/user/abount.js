(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/user/abount" ], {
    468: function(t, n, e) {
        "use strict";
        (function(t, n) {
            var r = e(4);
            e(26), r(e(25));
            var i = r(e(469));
            t.__webpack_require_UNI_MP_PLUGIN__ = e, n(i.default);
        }).call(this, e(1).default, e(2).createPage);
    },
    469: function(t, n, e) {
        "use strict";
        e.r(n);
        var r = e(470), i = e(472);
        for (var u in i) [ "default" ].indexOf(u) < 0 && function(t) {
            e.d(n, t, function() {
                return i[t];
            });
        }(u);
        e(474);
        var a = e(33), o = Object(a.default)(i.default, r.render, r.staticRenderFns, !1, null, null, null, !1, r.components, void 0);
        o.options.__file = "pages/user/abount.vue", n.default = o.exports;
    },
    470: function(t, n, e) {
        "use strict";
        e.r(n);
        var r = e(471);
        e.d(n, "render", function() {
            return r.render;
        }), e.d(n, "staticRenderFns", function() {
            return r.staticRenderFns;
        }), e.d(n, "recyclableRender", function() {
            return r.recyclableRender;
        }), e.d(n, "components", function() {
            return r.components;
        });
    },
    471: function(t, n, e) {
        "use strict";
        e.r(n), e.d(n, "render", function() {
            return r;
        }), e.d(n, "staticRenderFns", function() {
            return u;
        }), e.d(n, "recyclableRender", function() {
            return i;
        }), e.d(n, "components", function() {});
        var r = function() {
            this.$createElement;
            var t = (this._self._c, this._f("formatImgUrl")("/images/rarr.png"));
            this.$mp.data = Object.assign({}, {
                $root: {
                    f0: t
                }
            });
        }, i = !1, u = [];
        r._withStripped = !0;
    },
    472: function(t, n, e) {
        "use strict";
        e.r(n);
        var r = e(473), i = e.n(r);
        for (var u in r) [ "default" ].indexOf(u) < 0 && function(t) {
            e.d(n, t, function() {
                return r[t];
            });
        }(u);
        n.default = i.a;
    },
    473: function(t, n, e) {
        "use strict";
        (function(t) {
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var e = {
                data: function() {
                    return {
                        page: 1,
                        logList: [ {
                            id: 0,
                            name: "Dream约文用户服务协议"
                        }, {
                            id: 1,
                            name: "Dream约文用户隐私政策"
                        } ],
                        selId: 0,
                        kf: ""
                    };
                },
                onLoad: function() {},
                onShow: function() {
                    this.getList();
                },
                onReachBottom: function() {
                    this.list.current_page < this.list.last_page && (this.page++, this.getGroupArticle());
                },
                methods: {
                    getList: function() {
                        var t = this;
                        this.$api.default.request("index/getxieyi", {
                            page: this.page
                        }, "POST", !1).then(function(n) {
                            n.code && (t.logList = n.data, t.kf = n.kf);
                        });
                    },
                    shownei: function(n) {
                        t.navigateTo({
                            url: "/pages/user/abount_dea?id=" + n.id
                        });
                    }
                }
            };
            n.default = e;
        }).call(this, e(2).default);
    },
    474: function(t, n, e) {
        "use strict";
        e.r(n);
        var r = e(475), i = e.n(r);
        for (var u in r) [ "default" ].indexOf(u) < 0 && function(t) {
            e.d(n, t, function() {
                return r[t];
            });
        }(u);
        n.default = i.a;
    },
    475: function(t, n, e) {}
}, [ [ 468, "common/runtime", "common/vendor" ] ] ]);