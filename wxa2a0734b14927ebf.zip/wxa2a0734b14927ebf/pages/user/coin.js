(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/user/coin" ], {
    588: function(e, t, n) {
        "use strict";
        (function(e, t) {
            var i = n(4);
            n(26), i(n(25));
            var o = i(n(589));
            e.__webpack_require_UNI_MP_PLUGIN__ = n, t(o.default);
        }).call(this, n(1).default, n(2).createPage);
    },
    589: function(e, t, n) {
        "use strict";
        n.r(t);
        var i = n(590), o = n(592);
        for (var r in o) [ "default" ].indexOf(r) < 0 && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(r);
        n(594);
        var s = n(33), u = Object(s.default)(o.default, i.render, i.staticRenderFns, !1, null, null, null, !1, i.components, void 0);
        u.options.__file = "pages/user/coin.vue", t.default = u.exports;
    },
    590: function(e, t, n) {
        "use strict";
        n.r(t);
        var i = n(591);
        n.d(t, "render", function() {
            return i.render;
        }), n.d(t, "staticRenderFns", function() {
            return i.staticRenderFns;
        }), n.d(t, "recyclableRender", function() {
            return i.recyclableRender;
        }), n.d(t, "components", function() {
            return i.components;
        });
    },
    591: function(e, t, n) {
        "use strict";
        var i;
        n.r(t), n.d(t, "render", function() {
            return o;
        }), n.d(t, "staticRenderFns", function() {
            return s;
        }), n.d(t, "recyclableRender", function() {
            return r;
        }), n.d(t, "components", function() {
            return i;
        });
        try {
            i = {
                uPopup: function() {
                    return Promise.all([ n.e("common/vendor"), n.e("node-modules/uview-ui/components/u-popup/u-popup") ]).then(n.bind(null, 890));
                }
            };
        } catch (e) {
            if (-1 === e.message.indexOf("Cannot find module") || -1 === e.message.indexOf(".vue")) throw e;
            console.error(e.message), console.error("1. 排查组件名称拼写是否正确"), console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"), 
            console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件");
        }
        var o = function() {
            var e = this, t = (e.$createElement, e._self._c, e._f("formatImgUrl")("/images/m_r.png")), n = e._f("formatImgUrl")("/images/no.png");
            e._isMounted || (e.e0 = function(t) {
                e.isRead = 2 == e.isRead ? 0 : 2;
            }, e.e1 = function(t) {
                e.show = !1;
            }), e.$mp.data = Object.assign({}, {
                $root: {
                    f0: t,
                    f1: n
                }
            });
        }, r = !1, s = [];
        o._withStripped = !0;
    },
    592: function(e, t, n) {
        "use strict";
        n.r(t);
        var i = n(593), o = n.n(i);
        for (var r in i) [ "default" ].indexOf(r) < 0 && function(e) {
            n.d(t, e, function() {
                return i[e];
            });
        }(r);
        t.default = o.a;
    },
    593: function(e, t, n) {
        "use strict";
        (function(e) {
            var i = n(4);
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var o, r = i(n(11)), s = {
                data: function() {
                    return {
                        isRead: !1,
                        userInfo: this.$db.get("userInfo"),
                        paddingBottomHeight: 0,
                        zhiList: [],
                        navIndex: 1,
                        type: 1,
                        list: [],
                        isClick: !1,
                        price: 0,
                        money: "",
                        show: !1
                    };
                },
                onLoad: function(e) {
                    e.type ? this.type = e.type : this.$common.errorToShow("参数异常");
                },
                onShow: function() {
                    this.getUserInfo(), this.getList();
                },
                created: function() {
                    var t = this;
                    e.getSystemInfo({
                        success: function(e) {
                            [ "X", "XR", "XS", "11", "12", "13", "14", "15" ].forEach(function(n) {
                                -1 != e.model.indexOf(n) && -1 != e.model.indexOf("iPhone") && (t.paddingBottomHeight = 40);
                            });
                        }
                    });
                    var n = getCurrentPages();
                    this.urlPath = "/" + n[0].route;
                },
                methods: (o = {
                    goToxie: function(t) {
                        e.navigateTo({
                            url: "/pages/user/abount_dea?id=" + t
                        }), console.log(this.$config.default.Url + "/agreement/1000006", 77);
                    },
                    setting: function() {
                        this.price = this.money, this.show = !1;
                    }
                }, (0, r.default)(o, "goToxie", function() {
                    e.navigateTo({
                        url: "/pages/webview/webview?url=" + this.$config.default.Url + "/agreement/1000003"
                    });
                }), (0, r.default)(o, "getList", function() {
                    var e = this;
                    this.$api.default.request("user/exchangeList", {
                        type: this.type
                    }).then(function(t) {
                        t.code && (e.list = t.data);
                    });
                }), (0, r.default)(o, "submit", function() {
                    var t = this;
                    if (!this.isClick) if (this.isRead) if (2 == this.type) this.$api.default.request("order/exchange", {
                        type: this.type,
                        id: this.price
                    }).then(function(n) {
                        n.code && t.$common.successToShow(n.msg, function() {
                            t.isClick = !1, e.navigateBack();
                        });
                    }); else {
                        var n = {
                            order_type: 2,
                            pay_type: 1
                        };
                        n.price = this.price, this.$api.default.request("order/createOrder", n).then(function(n) {
                            n.code && t.$common.wxPay(n.data, function() {
                                t.isClick = !1, e.navigateBack();
                            });
                        });
                    } else this.isReadTip();
                }), (0, r.default)(o, "isReadTip", function() {
                    var e = this;
                    if (!this.isRead) return this.$common.errorToShow("请先同意充值协议"), this.isRead = 1, 
                    void setTimeout(function() {
                        e.isRead = 0;
                    }, 300);
                }), (0, r.default)(o, "getUserInfo", function() {
                    var e = this;
                    this.$api.default.request("user/userInfo").then(function(t) {
                        t.code && (e.userInfo = t.user);
                    });
                }), (0, r.default)(o, "navTap", function(e) {
                    this.navIndex = e, 88888 != e ? this.price = e : this.show = !0;
                }), o)
            };
            t.default = s;
        }).call(this, n(2).default);
    },
    594: function(e, t, n) {
        "use strict";
        n.r(t);
        var i = n(595), o = n.n(i);
        for (var r in i) [ "default" ].indexOf(r) < 0 && function(e) {
            n.d(t, e, function() {
                return i[e];
            });
        }(r);
        t.default = o.a;
    },
    595: function(e, t, n) {}
}, [ [ 588, "common/runtime", "common/vendor" ] ] ]);