(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/user/withdrawal_list" ], {
    196: function(n, t, e) {
        "use strict";
        (function(n, t) {
            var r = e(4);
            e(26), r(e(25));
            var u = r(e(197));
            n.__webpack_require_UNI_MP_PLUGIN__ = e, t(u.default);
        }).call(this, e(1).default, e(2).createPage);
    },
    197: function(n, t, e) {
        "use strict";
        e.r(t);
        var r = e(198), u = e(200);
        for (var i in u) [ "default" ].indexOf(i) < 0 && function(n) {
            e.d(t, n, function() {
                return u[n];
            });
        }(i);
        e(202);
        var o = e(33), a = Object(o.default)(u.default, r.render, r.staticRenderFns, !1, null, null, null, !1, r.components, void 0);
        a.options.__file = "pages/user/withdrawal_list.vue", t.default = a.exports;
    },
    198: function(n, t, e) {
        "use strict";
        e.r(t);
        var r = e(199);
        e.d(t, "render", function() {
            return r.render;
        }), e.d(t, "staticRenderFns", function() {
            return r.staticRenderFns;
        }), e.d(t, "recyclableRender", function() {
            return r.recyclableRender;
        }), e.d(t, "components", function() {
            return r.components;
        });
    },
    199: function(n, t, e) {
        "use strict";
        e.r(t), e.d(t, "render", function() {
            return r;
        }), e.d(t, "staticRenderFns", function() {
            return i;
        }), e.d(t, "recyclableRender", function() {
            return u;
        }), e.d(t, "components", function() {});
        var r = function() {
            this.$createElement;
            var n = (this._self._c, this._f("formatImgUrl")("/images/rarr.png")), t = this._f("formatImgUrl")("/images/rarr.png"), e = this._f("formatImgUrl")("/images/rarr.png");
            this.$mp.data = Object.assign({}, {
                $root: {
                    f0: n,
                    f1: t,
                    f2: e
                }
            });
        }, u = !1, i = [];
        r._withStripped = !0;
    },
    200: function(n, t, e) {
        "use strict";
        e.r(t);
        var r = e(201), u = e.n(r);
        for (var i in r) [ "default" ].indexOf(i) < 0 && function(n) {
            e.d(t, n, function() {
                return r[n];
            });
        }(i);
        t.default = u.a;
    },
    201: function(n, t, e) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.default = void 0, t.default = {
            data: function() {
                return {
                    userInfo: {}
                };
            },
            onLoad: function() {},
            onShow: function() {
                this.getUserInfo();
            },
            methods: {
                getUserInfo: function() {
                    var n = this;
                    this.$api.default.request("user/userInfoTx", {}, "POST", !1).then(function(t) {
                        t.code && (n.userInfo = t.data);
                    });
                }
            }
        };
    },
    202: function(n, t, e) {
        "use strict";
        e.r(t);
        var r = e(203), u = e.n(r);
        for (var i in r) [ "default" ].indexOf(i) < 0 && function(n) {
            e.d(t, n, function() {
                return r[n];
            });
        }(i);
        t.default = u.a;
    },
    203: function(n, t, e) {}
}, [ [ 196, "common/runtime", "common/vendor" ] ] ]);