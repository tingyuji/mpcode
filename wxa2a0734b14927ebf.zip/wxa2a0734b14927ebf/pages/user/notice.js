(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/user/notice" ], {
    700: function(n, e, r) {
        "use strict";
        (function(n, e) {
            var t = r(4);
            r(26), t(r(25));
            var o = t(r(701));
            n.__webpack_require_UNI_MP_PLUGIN__ = r, e(o.default);
        }).call(this, r(1).default, r(2).createPage);
    },
    701: function(n, e, r) {
        "use strict";
        r.r(e);
        var t = r(702), o = r(704);
        for (var i in o) [ "default" ].indexOf(i) < 0 && function(n) {
            r.d(e, n, function() {
                return o[n];
            });
        }(i);
        r(706);
        var u = r(33), s = Object(u.default)(o.default, t.render, t.staticRenderFns, !1, null, null, null, !1, t.components, void 0);
        s.options.__file = "pages/user/notice.vue", e.default = s.exports;
    },
    702: function(n, e, r) {
        "use strict";
        r.r(e);
        var t = r(703);
        r.d(e, "render", function() {
            return t.render;
        }), r.d(e, "staticRenderFns", function() {
            return t.staticRenderFns;
        }), r.d(e, "recyclableRender", function() {
            return t.recyclableRender;
        }), r.d(e, "components", function() {
            return t.components;
        });
    },
    703: function(n, e, r) {
        "use strict";
        r.r(e), r.d(e, "render", function() {
            return t;
        }), r.d(e, "staticRenderFns", function() {
            return i;
        }), r.d(e, "recyclableRender", function() {
            return o;
        }), r.d(e, "components", function() {});
        var t = function() {
            this.$createElement;
            var n = (this._self._c, this.userInfo.hasOwnProperty("writer_user_config"));
            this.$mp.data = Object.assign({}, {
                $root: {
                    g0: n
                }
            });
        }, o = !1, i = [];
        t._withStripped = !0;
    },
    704: function(n, e, r) {
        "use strict";
        r.r(e);
        var t = r(705), o = r.n(t);
        for (var i in t) [ "default" ].indexOf(i) < 0 && function(n) {
            r.d(e, n, function() {
                return t[n];
            });
        }(i);
        e.default = o.a;
    },
    705: function(n, e, r) {
        "use strict";
        (function(n) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var r = {
                data: function() {
                    return {
                        userInfo: {}
                    };
                },
                onShow: function() {
                    this.getUserInfo();
                },
                methods: {
                    submit: function() {
                        var e = this, r = {
                            personal_note: this.userInfo.writer_user_config.personal_note,
                            communication_time: this.userInfo.writer_user_config.communication_time,
                            remuneration_details: this.userInfo.writer_user_config.remuneration_details,
                            order_notice: this.userInfo.writer_user_config.order_notice,
                            publication_works: this.userInfo.writer_user_config.publication_works,
                            additional_remarks: this.userInfo.writer_user_config.additional_remarks
                        };
                        "" !== r.personal_note && null !== r.personal_note ? "" != r.communication_time && null !== r.communication_time ? "" != r.remuneration_details && null !== r.remuneration_details ? "" != r.order_notice && null !== r.order_notice ? "" != r.publication_works && null !== r.publication_works ? "" != r.additional_remarks && null !== r.additional_remarks ? (this.userInfo.writer_user_config.hasOwnProperty("uid") || (r.uid = this.userInfo.writer_user_config.uid), 
                        this.$api.default.request("user/saveWriterUserConfig", r).then(function(r) {
                            1 == r.code && e.$common.successToShow(r.msg, function() {
                                n.navigateBack();
                            });
                        })) : this.$common.errorToShow("请输入版权归属") : this.$common.errorToShow("请输入作品公开") : this.$common.errorToShow("请输入下单须知") : this.$common.errorToShow("请输入稿酬明细") : this.$common.errorToShow("请输入沟通时间") : this.$common.errorToShow("请输入个人说明");
                    },
                    getUserInfo: function() {
                        var n = this;
                        this.$api.default.request("user/userInfo", {}, "POST", !1).then(function(e) {
                            e.code && (n.userInfo = e.user);
                        });
                    }
                }
            };
            e.default = r;
        }).call(this, r(2).default);
    },
    706: function(n, e, r) {
        "use strict";
        r.r(e);
        var t = r(707), o = r.n(t);
        for (var i in t) [ "default" ].indexOf(i) < 0 && function(n) {
            r.d(e, n, function() {
                return t[n];
            });
        }(i);
        e.default = o.a;
    },
    707: function(n, e, r) {}
}, [ [ 700, "common/runtime", "common/vendor" ] ] ]);