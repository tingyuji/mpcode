(global.webpackJsonp = global.webpackJsonp || []).push([ [ "uni_modules/custom-waterfalls-flow/components/custom-waterfalls-flow/custom-waterfalls-flow" ], {
    920: function(t, e, n) {
        "use strict";
        n.r(e);
        var a = n(921), r = n(923);
        for (var i in r) [ "default" ].indexOf(i) < 0 && function(t) {
            n.d(e, t, function() {
                return r[t];
            });
        }(i);
        n(925);
        var o = n(33), s = Object(o.default)(r.default, a.render, a.staticRenderFns, !1, null, "ddfcbb1c", null, !1, a.components, void 0);
        s.options.__file = "uni_modules/custom-waterfalls-flow/components/custom-waterfalls-flow/custom-waterfalls-flow.vue", 
        e.default = s.exports;
    },
    921: function(t, e, n) {
        "use strict";
        n.r(e);
        var a = n(922);
        n.d(e, "render", function() {
            return a.render;
        }), n.d(e, "staticRenderFns", function() {
            return a.staticRenderFns;
        }), n.d(e, "recyclableRender", function() {
            return a.recyclableRender;
        }), n.d(e, "components", function() {
            return a.components;
        });
    },
    922: function(t, e, n) {
        "use strict";
        n.r(e), n.d(e, "render", function() {
            return a;
        }), n.d(e, "staticRenderFns", function() {
            return i;
        }), n.d(e, "recyclableRender", function() {
            return r;
        }), n.d(e, "components", function() {});
        var a = function() {
            var t = this, e = (t.$createElement, t._self._c, t.__map(t.data.column, function(e, n) {
                return {
                    $orig: t.__get_orig(e),
                    s0: t.__get_style([ t.s1 ]),
                    l0: t.columnValue(n)
                };
            }));
            t._isMounted || (t.e0 = function(e, n) {
                var a;
                return n = ((a = arguments[arguments.length - 1].currentTarget.dataset).eventParams || a["event-params"]).item2, 
                e.stopPropagation(), t.wapperClick(n);
            }, t.e1 = function(e, n, a) {
                var r, i;
                return n = (i = (r = arguments[arguments.length - 1].currentTarget.dataset).eventParams || r["event-params"]).item2, 
                a = i.index, t.imgLoad(n, a + 1);
            }, t.e2 = function(e, n, a) {
                var r, i;
                return n = (i = (r = arguments[arguments.length - 1].currentTarget.dataset).eventParams || r["event-params"]).item2, 
                a = i.index, t.imgError(n, a + 1);
            }, t.e3 = function(e, n) {
                var a;
                return n = ((a = arguments[arguments.length - 1].currentTarget.dataset).eventParams || a["event-params"]).item2, 
                e.stopPropagation(), t.imageClick(n);
            }), t.$mp.data = Object.assign({}, {
                $root: {
                    l1: e
                }
            });
        }, r = !1, i = [];
        a._withStripped = !0;
    },
    923: function(t, e, n) {
        "use strict";
        n.r(e);
        var a = n(924), r = n.n(a);
        for (var i in a) [ "default" ].indexOf(i) < 0 && function(t) {
            n.d(e, t, function() {
                return a[t];
            });
        }(i);
        e.default = r.a;
    },
    924: function(t, e, n) {
        "use strict";
        (function(t) {
            var a = n(4);
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var r = a(n(56)), i = a(n(58)), o = a(n(11));
            function s(t, e) {
                var n = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var a = Object.getOwnPropertySymbols(t);
                    e && (a = a.filter(function(e) {
                        return Object.getOwnPropertyDescriptor(t, e).enumerable;
                    })), n.push.apply(n, a);
                }
                return n;
            }
            function u(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var n = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? s(Object(n), !0).forEach(function(e) {
                        (0, o.default)(t, e, n[e]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : s(Object(n)).forEach(function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e));
                    });
                }
                return t;
            }
            var c = {
                props: {
                    value: Array,
                    column: {
                        type: [ String, Number ],
                        default: 2
                    },
                    maxColumn: {
                        type: [ String, Number ],
                        default: 5
                    },
                    columnSpace: {
                        type: [ String, Number ],
                        default: 2
                    },
                    imageKey: {
                        type: [ String ],
                        default: "image"
                    },
                    hideImageKey: {
                        type: [ String ],
                        default: "hide"
                    },
                    seat: {
                        type: [ String, Number ],
                        default: 2
                    },
                    listStyle: {
                        type: Object
                    }
                },
                data: function() {
                    return {
                        data: {
                            list: this.value ? this.value : [],
                            column: this.column < 2 ? 2 : this.column,
                            columnSpace: this.columnSpace <= 5 ? this.columnSpace : 5,
                            imageKey: this.imageKey,
                            seat: this.seat
                        },
                        msg: 0,
                        listInitStyle: {
                            "border-radius": "12rpx",
                            "margin-bottom": "20rpx",
                            "background-color": "#fff"
                        },
                        adds: [],
                        isLoaded: !0,
                        curIndex: 0,
                        isRefresh: !0,
                        flag: !1,
                        refreshDatas: []
                    };
                },
                computed: {
                    w: function() {
                        return "".concat(100 / this.data.column - +this.data.columnSpace, "%");
                    },
                    m: function() {
                        return "".concat((100 - (100 / this.data.column - +this.data.columnSpace).toFixed(5) * this.data.column) / (this.data.column - 1), "%");
                    },
                    s1: function() {
                        return u(u({}, this.listInitStyle), this.listStyle);
                    }
                },
                created: function() {
                    this.refresh();
                },
                methods: {
                    loadImages: function() {
                        for (var e = this, n = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0, a = 0, r = this.data.list.filter(function(t, e) {
                            return e >= n;
                        }), i = 0; i < r.length; i++) t.getImageInfo({
                            src: "".concat(r[i][this.imageKey], ".jpg"),
                            complete: function(t) {
                                ++a == r.length && e.initValue(n);
                            }
                        });
                    },
                    refresh: function() {
                        var t = this;
                        if (!this.isLoaded) return this.refreshDatas = this.value, !1;
                        setTimeout(function() {
                            t.refreshDatas = [], t.isRefresh = !0, t.adds = [], t.data.list = t.value ? t.value : [], 
                            t.data.column = t.column < 2 ? 2 : t.column >= t.maxColumn ? t.maxColumn : t.column, 
                            t.data.columnSpace = t.columnSpace <= 5 ? t.columnSpace : 5, t.data.imageKey = t.imageKey, 
                            t.data.seat = t.seat, t.curIndex = 0;
                            for (var e = 1; e <= t.data.column; e++) t.data["column_".concat(e, "_values")] = [], 
                            t.msg++;
                            t.$nextTick(function() {
                                t.initValue(t.curIndex, "refresh==>");
                            });
                        }, 1);
                    },
                    columnValue: function(t) {
                        return this.data["column_".concat(t + 1, "_values")];
                    },
                    change: function(t) {
                        for (var e = 0; e < this.data.list.length; e++) for (var n = this.data["column_".concat(this.data.list[e].column, "_values")], a = 0; a < n.length; a++) if (t[e] && e === n[a].index) {
                            this.data["column_".concat(this.data.list[e].column, "_values")][a] = Object.assign(n[a], t[e]), 
                            this.msg++;
                            break;
                        }
                    },
                    getMin: function(t, e) {
                        for (var n = t[0][e], a = (t[0], t.length - 1); a >= 0; a--) t[a][e] < n && (n = t[a][e]);
                        return t.filter(function(t) {
                            return t[e] == n;
                        })[0];
                    },
                    getMinColumnHeight: function() {
                        var e = this;
                        return new Promise(function(n) {
                            for (var a = [], r = function(r) {
                                t.createSelectorQuery().in(e).select("#waterfalls_flow_column_".concat(r)).boundingClientRect(function(t) {
                                    a.push({
                                        column: r,
                                        height: t.height
                                    });
                                }).exec(function() {
                                    e.data.column <= a.length && n(e.getMin(a, "height"));
                                });
                            }, i = 1; i <= e.data.column; i++) r(i);
                        });
                    },
                    initValue: function(t, e) {
                        var n = this;
                        return (0, i.default)(r.default.mark(function e() {
                            var a, i;
                            return r.default.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                  case 0:
                                    if (n.isLoaded = !1, !(t >= n.data.list.length || n.refreshDatas.length)) {
                                        e.next = 5;
                                        break;
                                    }
                                    return n.msg++, n.loaded(), e.abrupt("return", !1);

                                  case 5:
                                    return e.next = 7, n.getMinColumnHeight();

                                  case 7:
                                    a = e.sent, i = n.data["column_".concat(a.column, "_values")], n.data.list[t].column = a.column, 
                                    i.push(u(u({}, n.data.list[t]), {}, {
                                        cIndex: i.length,
                                        index: t,
                                        o: 0
                                    })), n.msg++;

                                  case 12:
                                  case "end":
                                    return e.stop();
                                }
                            }, e);
                        }))();
                    },
                    imgLoad: function(t, e) {
                        var n = t.index;
                        t.o = 1, this.$set(this.data["column_".concat(e, "_values")], t.cIndex, JSON.parse(JSON.stringify(t))), 
                        this.initValue(n + 1);
                    },
                    imgError: function(t, e) {
                        var n = t.index;
                        t.o = 1, t[this.data.imageKey] = null, this.$set(this.data["column_".concat(e, "_values")], t.cIndex, JSON.parse(JSON.stringify(t))), 
                        this.initValue(n + 1);
                    },
                    loaded: function() {
                        if (this.refreshDatas.length) return this.isLoaded = !0, this.refresh(), !1;
                        this.curIndex = this.data.list.length, this.adds.length ? (this.data.list = this.adds[0], 
                        this.adds.splice(0, 1), this.initValue(this.curIndex)) : (this.data.list.length && this.$emit("loaded"), 
                        this.isLoaded = !0, this.isRefresh = !1);
                    },
                    wapperClick: function(t) {
                        this.$emit("wapperClick", t);
                    },
                    imageClick: function(t) {
                        this.$emit("imageClick", t);
                    }
                },
                watch: {
                    value: {
                        deep: !0,
                        handler: function(t, e) {
                            var n = this;
                            setTimeout(function() {
                                n.$nextTick(function() {
                                    if (n.isRefresh) return !1;
                                    if (n.isLoaded) {
                                        if (t.length <= n.curIndex) return n.change(t);
                                        n.data.list = t, n.$nextTick(function() {
                                            n.initValue(n.curIndex, "watch==>");
                                        });
                                    } else n.adds.push(t);
                                });
                            }, 10);
                        }
                    },
                    column: function(t) {
                        this.refresh();
                    }
                }
            };
            e.default = c;
        }).call(this, n(2).default);
    },
    925: function(t, e, n) {
        "use strict";
        n.r(e);
        var a = n(926), r = n.n(a);
        for (var i in a) [ "default" ].indexOf(i) < 0 && function(t) {
            n.d(e, t, function() {
                return a[t];
            });
        }(i);
        e.default = r.a;
    },
    926: function(t, e, n) {}
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "uni_modules/custom-waterfalls-flow/components/custom-waterfalls-flow/custom-waterfalls-flow-create-component", {
    "uni_modules/custom-waterfalls-flow/components/custom-waterfalls-flow/custom-waterfalls-flow-create-component": function(t, e, n) {
        n("2").createComponent(n(920));
    }
}, [ [ "uni_modules/custom-waterfalls-flow/components/custom-waterfalls-flow/custom-waterfalls-flow-create-component" ] ] ]);