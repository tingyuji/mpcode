(global.webpackJsonp = global.webpackJsonp || []).push([ [ "uni_modules/cc-multipleBtn/components/cc-multipleBtn/cc-multipleBtn" ], {
    898: function(t, e, n) {
        "use strict";
        n.r(e);
        var c = n(899), r = n(901);
        for (var i in r) [ "default" ].indexOf(i) < 0 && function(t) {
            n.d(e, t, function() {
                return r[t];
            });
        }(i);
        n(903);
        var u = n(33), o = Object(u.default)(r.default, c.render, c.staticRenderFns, !1, null, "3141f99e", null, !1, c.components, void 0);
        o.options.__file = "uni_modules/cc-multipleBtn/components/cc-multipleBtn/cc-multipleBtn.vue", 
        e.default = o.exports;
    },
    899: function(t, e, n) {
        "use strict";
        n.r(e);
        var c = n(900);
        n.d(e, "render", function() {
            return c.render;
        }), n.d(e, "staticRenderFns", function() {
            return c.staticRenderFns;
        }), n.d(e, "recyclableRender", function() {
            return c.recyclableRender;
        }), n.d(e, "components", function() {
            return c.components;
        });
    },
    900: function(t, e, n) {
        "use strict";
        n.r(e), n.d(e, "render", function() {
            return c;
        }), n.d(e, "staticRenderFns", function() {
            return i;
        }), n.d(e, "recyclableRender", function() {
            return r;
        }), n.d(e, "components", function() {});
        var c = function() {
            this.$createElement;
            this._self._c;
        }, r = !1, i = [];
        c._withStripped = !0;
    },
    901: function(t, e, n) {
        "use strict";
        n.r(e);
        var c = n(902), r = n.n(c);
        for (var i in c) [ "default" ].indexOf(i) < 0 && function(t) {
            n.d(e, t, function() {
                return c[t];
            });
        }(i);
        e.default = r.a;
    },
    902: function(t, e, n) {
        "use strict";
        var c = n(4);
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.default = void 0;
        var r = c(n(11)), i = {
            mixins: [ {
                methods: {
                    setData: function(t, e) {
                        var n = this;
                        Object.keys(t).forEach(function(e) {
                            var c, r, i, u, o, l = t[e], a = (e = e.replace(/\]/g, "").replace(/\[/g, ".")).lastIndexOf(".");
                            -1 != a ? (r = e.slice(a + 1), i = n, u = e.slice(0, a), o = r, (u = u.split(".")).forEach(function(t) {
                                null === i[t] || void 0 === i[t] ? (i[t] = /^[0-9]+$/.test(o) ? [] : {}, i = i[t]) : i = i[t];
                            }), c = i) : (r = e, c = n), c.$data && void 0 === c.$data[r] ? (Object.defineProperty(c, r, {
                                get: function() {
                                    return c.$data[r];
                                },
                                set: function(t) {
                                    c.$data[r] = t, n.$forceUpdate();
                                },
                                enumerable: !0,
                                configurable: !0
                            }), c[r] = l) : n.$set(c, r, l);
                        }), "function" == typeof e && this.$nextTick(e);
                    }
                }
            } ],
            data: function() {
                return {
                    lastIndex: 0
                };
            },
            props: {
                isSingleSel: {
                    type: Boolean
                },
                flag: {
                    type: String
                },
                colors: {
                    type: String
                },
                remarkList: {
                    type: Array,
                    default: function() {
                        return [];
                    }
                }
            },
            methods: {
                setCurrent: function(t) {
                    this.isSingleSel && this.lastIndex != t && (this.remarkList[this.lastIndex].current = !1);
                    var e = this.remarkList[t];
                    e.current = !e.current, this.lastIndex = t;
                    var n = "remarkList[" + t + "]";
                    this.setData((0, r.default)({}, n, e));
                    var c = [];
                    this.remarkList.forEach(function(t) {
                        1 == t.current && c.push(t);
                    }), this.$emit("tagClick", c, this.remarkList);
                }
            }
        };
        e.default = i;
    },
    903: function(t, e, n) {
        "use strict";
        n.r(e);
        var c = n(904), r = n.n(c);
        for (var i in c) [ "default" ].indexOf(i) < 0 && function(t) {
            n.d(e, t, function() {
                return c[t];
            });
        }(i);
        e.default = r.a;
    },
    904: function(t, e, n) {}
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "uni_modules/cc-multipleBtn/components/cc-multipleBtn/cc-multipleBtn-create-component", {
    "uni_modules/cc-multipleBtn/components/cc-multipleBtn/cc-multipleBtn-create-component": function(t, e, n) {
        n("2").createComponent(n(898));
    }
}, [ [ "uni_modules/cc-multipleBtn/components/cc-multipleBtn/cc-multipleBtn-create-component" ] ] ]);