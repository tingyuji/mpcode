(global.webpackJsonp = global.webpackJsonp || []).push([ [ "uni_modules/wly-countdown/components/wly-countdown/wly-countdown" ], {
    1040: function(t, n, e) {
        "use strict";
        e.r(n);
        var o = e(1041), i = e(1043);
        for (var s in i) [ "default" ].indexOf(s) < 0 && function(t) {
            e.d(n, t, function() {
                return i[t];
            });
        }(s);
        e(1045);
        var u = e(33), c = Object(u.default)(i.default, o.render, o.staticRenderFns, !1, null, "55369594", null, !1, o.components, void 0);
        c.options.__file = "uni_modules/wly-countdown/components/wly-countdown/wly-countdown.vue", 
        n.default = c.exports;
    },
    1041: function(t, n, e) {
        "use strict";
        e.r(n);
        var o = e(1042);
        e.d(n, "render", function() {
            return o.render;
        }), e.d(n, "staticRenderFns", function() {
            return o.staticRenderFns;
        }), e.d(n, "recyclableRender", function() {
            return o.recyclableRender;
        }), e.d(n, "components", function() {
            return o.components;
        });
    },
    1042: function(t, n, e) {
        "use strict";
        e.r(n), e.d(n, "render", function() {
            return o;
        }), e.d(n, "staticRenderFns", function() {
            return s;
        }), e.d(n, "recyclableRender", function() {
            return i;
        }), e.d(n, "components", function() {});
        var o = function() {
            var t = this;
            t.$createElement;
            t._self._c, t.$initSSP(), "augmented" === t.$scope.data.scopedSlotsCompiler && t.$setSSP("default", {
                day: t.d,
                hour: t.h,
                minute: t.i,
                second: t.s
            }), t.$callSSP();
        }, i = !1, s = [];
        o._withStripped = !0;
    },
    1043: function(t, n, e) {
        "use strict";
        e.r(n);
        var o = e(1044), i = e.n(o);
        for (var s in o) [ "default" ].indexOf(s) < 0 && function(t) {
            e.d(n, t, function() {
                return o[t];
            });
        }(s);
        n.default = i.a;
    },
    1044: function(t, n, e) {
        "use strict";
        Object.defineProperty(n, "__esModule", {
            value: !0
        }), n.default = void 0;
        var o = {
            name: "UniCountdown",
            props: {
                showDay: {
                    type: Boolean,
                    default: !0
                },
                showColon: {
                    type: Boolean,
                    default: !0
                },
                start: {
                    type: Boolean,
                    default: !0
                },
                backgroundColor: {
                    type: String,
                    default: "#FFFFFF"
                },
                borderColor: {
                    type: String,
                    default: "#000000"
                },
                color: {
                    type: String,
                    default: "#000000"
                },
                splitorColor: {
                    type: String,
                    default: "#000000"
                },
                day: {
                    type: Number,
                    default: 0
                },
                hour: {
                    type: Number,
                    default: 0
                },
                minute: {
                    type: Number,
                    default: 0
                },
                second: {
                    type: Number,
                    default: 0
                },
                timestamp: {
                    type: Number,
                    default: 0
                },
                showType: {
                    type: String,
                    default: "default"
                }
            },
            data: function() {
                return {
                    timer: null,
                    syncFlag: !1,
                    d: "00",
                    h: "00",
                    i: "00",
                    s: "00",
                    leftTime: 0,
                    seconds: 0
                };
            },
            watch: {
                day: function(t) {
                    this.changeFlag();
                },
                hour: function(t) {
                    this.changeFlag();
                },
                minute: function(t) {
                    this.changeFlag();
                },
                second: function(t) {
                    this.changeFlag();
                },
                start: {
                    immediate: !0,
                    handler: function(t, n) {
                        if (t) this.startData(); else {
                            if (!n) return;
                            clearInterval(this.timer);
                        }
                    }
                }
            },
            created: function(t) {
                this.seconds = this.toSeconds(this.timestamp, this.day, this.hour, this.minute, this.second), 
                this.countDown();
            },
            beforeDestroy: function() {
                clearInterval(this.timer);
            },
            methods: {
                toSeconds: function(t, n, e, o, i) {
                    return t ? t - parseInt(new Date().getTime() / 1e3, 10) : 60 * n * 60 * 24 + 60 * e * 60 + 60 * o + i;
                },
                timeUp: function() {
                    clearInterval(this.timer), this.$emit("timeup");
                },
                countDown: function() {
                    var t = this.seconds, n = 0, e = 0, o = 0, i = 0;
                    t > 0 ? (n = Math.floor(t / 86400), e = Math.floor(t / 3600) - 24 * n, o = Math.floor(t / 60) - 24 * n * 60 - 60 * e, 
                    i = Math.floor(t) - 24 * n * 60 * 60 - 60 * e * 60 - 60 * o) : this.timeUp(), n < 10 && (n = "0" + n), 
                    e < 10 && (e = "0" + e), o < 10 && (o = "0" + o), i < 10 && (i = "0" + i), this.d = n, 
                    this.h = e, this.i = o, this.s = i, "emit" == this.showType && this.$emit("GetTime", {
                        day: n,
                        hour: e,
                        minute: o,
                        second: i
                    });
                },
                startData: function() {
                    var t = this;
                    this.seconds = this.toSeconds(this.timestamp, this.day, this.hour, this.minute, this.second), 
                    this.seconds <= 0 || (this.countDown(), this.timer = setInterval(function() {
                        t.seconds--, t.seconds < 0 ? t.timeUp() : t.countDown();
                    }, 1e3));
                },
                changeFlag: function() {
                    this.syncFlag || (this.seconds = this.toSeconds(this.timestamp, this.day, this.hour, this.minute, this.second), 
                    this.startData(), this.syncFlag = !0);
                }
            }
        };
        n.default = o;
    },
    1045: function(t, n, e) {
        "use strict";
        e.r(n);
        var o = e(1046), i = e.n(o);
        for (var s in o) [ "default" ].indexOf(s) < 0 && function(t) {
            e.d(n, t, function() {
                return o[t];
            });
        }(s);
        n.default = i.a;
    },
    1046: function(t, n, e) {}
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "uni_modules/wly-countdown/components/wly-countdown/wly-countdown-create-component", {
    "uni_modules/wly-countdown/components/wly-countdown/wly-countdown-create-component": function(t, n, e) {
        e("2").createComponent(e(1040));
    }
}, [ [ "uni_modules/wly-countdown/components/wly-countdown/wly-countdown-create-component" ] ] ]);