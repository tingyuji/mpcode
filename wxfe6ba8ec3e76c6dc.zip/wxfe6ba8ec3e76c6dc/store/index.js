function t(t, e, n) {
    return e in t ? Object.defineProperty(t, e, {
        value: n,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : t[e] = n, t;
}

function e(t, e) {
    if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function");
}

function n(t, e) {
    if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !e || "object" != typeof e && "function" != typeof e ? t : e;
}

function o(t, e) {
    if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
    t.prototype = Object.create(e && e.prototype, {
        constructor: {
            value: t,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e);
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var a = function() {
    function t(t, e) {
        for (var n = 0; n < e.length; n++) {
            var o = e[n];
            o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), 
            Object.defineProperty(t, o.key, o);
        }
    }
    return function(e, n, o) {
        return n && t(e.prototype, n), o && t(e, o), e;
    };
}(), i = require("./observer"), r = Symbol("bindWatcher"), f = Symbol("unbindWatcher"), u = function(u) {
    function c() {
        e(this, c);
        var t = n(this, (c.__proto__ || Object.getPrototypeOf(c)).call(this));
        return t.app = null, t;
    }
    return o(c, i.Observer), a(c, [ {
        key: "createApp",
        value: function(t) {
            var e = t.onLaunch, n = this;
            return t.onLaunch = function() {
                if (n.app = this, "function" == typeof e) {
                    for (var t = arguments.length, o = Array(t), a = 0; a < t; a++) o[a] = arguments[a];
                    e.apply(this, o);
                }
            }, t;
        }
    }, {
        key: "createPage",
        value: function(t) {
            var e = t.globalData, n = void 0 === e ? [] : e, o = t.watch, a = void 0 === o ? {} : o, i = t.onLoad, u = t.onUnload, c = t.onShow, l = t.onHide, p = this, h = {}, s = {};
            return t.onLoad = function() {
                if (p[r](n, a, h, s, this), "function" == typeof i) {
                    for (var t = arguments.length, e = Array(t), o = 0; o < t; o++) e[o] = arguments[o];
                    i.apply(this, e);
                }
            }, t.onUnload = function() {
                p[f](s, h), "function" == typeof u && u.apply(this);
            }, t.onShow = function() {
                if (p[r](n, a, h, s, this), "function" == typeof c) {
                    for (var t = arguments.length, e = Array(t), o = 0; o < t; o++) e[o] = arguments[o];
                    c.apply(this, e);
                }
            }, t.onHide = function() {
                p[f](s, h), "function" == typeof l && l.apply(this);
            }, delete t.globalData, delete t.watch, t;
        }
    }, {
        key: "createComponent",
        value: function(t) {
            var e = t.globalData, n = void 0 === e ? [] : e, o = t.watch, a = void 0 === o ? {} : o, i = t.attached, u = t.detached, c = t.pageLifetimes, l = c.show, p = c.hide, h = this, s = {}, y = {};
            return t.attached = function() {
                if (h[r](n, a, s, y, this), "function" == typeof i) {
                    for (var t = arguments.length, e = Array(t), o = 0; o < t; o++) e[o] = arguments[o];
                    i.apply(this, e);
                }
            }, t.detached = function() {
                h[f](y, s), "function" == typeof u && u.apply(this);
            }, t.pageLifetimes && (t.pageLifetimes.show = function() {
                if (h[r](n, a, s, y, this), "function" == typeof l) {
                    for (var t = arguments.length, e = Array(t), o = 0; o < t; o++) e[o] = arguments[o];
                    l.apply(this, e);
                }
            }), t.pageLifetimes && (t.pageLifetimes.hide = function() {
                h[f](y, s), "function" == typeof p && p.apply(this);
            }), delete t.globalData, delete t.watch, t;
        }
    }, {
        key: "dispatch",
        value: function(t, e) {
            this.app && (this.app.globalData[t] = e), this.emit(t, e);
        }
    }, {
        key: r,
        value: function(e, n, o, a, i) {
            var r = this, f = {}, u = !0, c = !1, l = void 0;
            try {
                for (var p, h = e[Symbol.iterator](); !(u = (p = h.next()).done); u = !0) !function() {
                    var e = p.value;
                    f[e] = r.app.globalData[e], o[e] = function(n) {
                        i.setData(t({}, e, n));
                    }, r.on(e, o[e]);
                }();
            } catch (t) {
                c = !0, l = t;
            } finally {
                try {
                    !u && h.return && h.return();
                } finally {
                    if (c) throw l;
                }
            }
            for (var s in n) !function(t) {
                a[t] = function(e) {
                    n[t].call(i, e);
                }, r.on(t, a[t]);
            }(s);
            i.setData(f);
        }
    }, {
        key: f,
        value: function(t, e) {
            for (var n in t) this.clear(n);
            for (var o in e) this.clear(o);
        }
    } ]), c;
}();

exports.default = new u();