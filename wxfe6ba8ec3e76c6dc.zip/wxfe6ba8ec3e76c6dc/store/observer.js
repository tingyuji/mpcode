function e(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var t = function() {
    function e(e, t) {
        for (var n = 0; n < t.length; n++) {
            var i = t[n];
            i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), 
            Object.defineProperty(e, i.key, i);
        }
    }
    return function(t, n, i) {
        return n && e(t.prototype, n), i && e(t, i), t;
    };
}(), n = Symbol("events"), i = function() {
    function i() {
        e(this, i), this[n] = {};
    }
    return t(i, [ {
        key: "on",
        value: function(e, t) {
            this[n][e] = this[n][e] || [], this[n][e].push(t);
        }
    }, {
        key: "emit",
        value: function(e, t) {
            this[n][e] && this[n][e].forEach(function(e, n) {
                e(t);
            });
        }
    }, {
        key: "clear",
        value: function(e) {
            this[n][e] = [];
        }
    }, {
        key: "off",
        value: function(e, t) {
            var i = this;
            this[n][e] = this[n][e] || [], this[n][e].forEach(function(o, r) {
                o === t && i[n][e].splice(r, 1);
            });
        }
    }, {
        key: "one",
        value: function(e, t) {
            this[n][e] = [ t ];
        }
    } ]), i;
}(), o = new i();

exports.Observer = i, exports.observer = o;