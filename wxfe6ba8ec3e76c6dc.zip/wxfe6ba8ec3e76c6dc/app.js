var t = Object.assign || function(t) {
    for (var e = 1; e < arguments.length; e++) {
        var a = arguments[e];
        for (var o in a) Object.prototype.hasOwnProperty.call(a, o) && (t[o] = a[o]);
    }
    return t;
}, e = function(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}(require("./store/index")), a = require("./inner_modules/@xmly/xlog-xmlite/dist/index"), o = require("./utils/wxCookie"), n = "https://s1.xmcdn.com/yx/ximalaya-baidu-lite-static/last/dist";

App(e.default.createApp({
    onLaunch: function(r) {
        (0, a.start)({
            b: 98,
            p: "wx",
            e: "production"
        });
        var s = this, i = wx.getStorageSync("playerData");
        if (e.default.dispatch("playerData", t({}, i, {
            playState: "stop",
            sort: -1
        })), e.default.dispatch("imgAddress", n), wx.canIUse("getSystemInfoSync")) {
            var l = wx.getSystemInfoSync();
            -1 != (l.model || "").search("iPhone X") && (s.globalData.isIphoneX = !0), e.default.dispatch("systemInfo", l);
        }
        (0, o.setWXOpenId)();
    },
    onShow: function(t) {
        if (e.default.dispatch("scene", t.scene), this.globalData.scene = t.scene, wx.canIUse("getSystemInfoSync")) {
            var a = wx.getSystemInfoSync().platform;
            this.globalData.platform = a, e.default.dispatch("platform", a);
        }
    },
    onHide: function() {},
    globalData: {
        playerData: {
            playList: [],
            currentTrack: {},
            playState: "stop",
            sort: -1,
            pageNum: 1,
            priceInfo: {}
        },
        scene: "",
        platform: "",
        imgAddress: n
    },
    onError: function(t) {
        console.log("onError", t);
    },
    onPageNotFound: function(t) {
        console.log("onPageNotFound", t);
    }
}));