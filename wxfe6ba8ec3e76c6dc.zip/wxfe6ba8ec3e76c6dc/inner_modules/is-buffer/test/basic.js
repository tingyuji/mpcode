var e = require("../");

require("../../../inner_modules/tape")("is-buffer", function(u) {
    u.equal(e(Buffer.alloc(4)), !0, "new Buffer(4)"), u.equal(e(Buffer.allocUnsafeSlow(100)), !0, "SlowBuffer(100)"), 
    u.equal(e(void 0), !1, "undefined"), u.equal(e(null), !1, "null"), u.equal(e(""), !1, "empty string"), 
    u.equal(e(!0), !1, "true"), u.equal(e(!1), !1, "false"), u.equal(e(0), !1, "0"), 
    u.equal(e(1), !1, "1"), u.equal(e(1), !1, "1.0"), u.equal(e("string"), !1, "string"), 
    u.equal(e({}), !1, "{}"), u.equal(e([]), !1, "[]"), u.equal(e(function() {}), !1, "function foo () {}"), 
    u.equal(e({
        isBuffer: null
    }), !1, "{ isBuffer: null }"), u.equal(e({
        isBuffer: function() {
            throw new Error();
        }
    }), !1, "{ isBuffer: function () { throw new Error() } }"), u.end();
});