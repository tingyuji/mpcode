Component({
    properties: {
        placeholder: {
            type: String,
            value: "请输入手机号"
        },
        mobileMask: {
            type: String,
            value: ""
        }
    },
    data: {
        areaCode: 86,
        phoneNum: "",
        panelVisible: !1
    },
    methods: {
        onSelect: function() {
            this.data.mobileMask || this.setData({
                panelVisible: !0
            });
        },
        onSelected: function(e) {
            var t = this, a = parseInt(e.detail);
            this.setData({
                panelVisible: !1,
                areaCode: a
            }, function() {
                return t.change();
            });
        },
        onPanelClose: function() {
            this.setData({
                panelVisible: !1
            });
        },
        onInput: function(e) {
            var t = this, a = e.detail.value;
            this.setData({
                phoneNum: a
            }, function() {
                return t.change();
            });
        },
        change: function() {
            var e = this.data, t = e.areaCode, a = e.phoneNum;
            if (t && a) {
                var n = 86 === t ? a : t + "-" + a;
                this.triggerEvent("change", n);
            }
        }
    }
});