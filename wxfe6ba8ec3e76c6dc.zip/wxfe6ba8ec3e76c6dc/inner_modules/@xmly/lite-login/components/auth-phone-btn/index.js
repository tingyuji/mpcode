function t(t, e) {
    var n = {};
    for (var i in t) e.indexOf(i) >= 0 || Object.prototype.hasOwnProperty.call(t, i) && (n[i] = t[i]);
    return n;
}

var e = Object.assign || function(t) {
    for (var e = 1; e < arguments.length; e++) {
        var n = arguments[e];
        for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (t[i] = n[i]);
    }
    return t;
}, n = require("../../lib/index");

Component({
    externalClasses: [ "c-class" ],
    properties: {
        text: {
            type: String,
            value: ""
        },
        thirdpartyId: {
            type: Number,
            value: void 0
        },
        env: {
            type: String,
            value: ""
        },
        scoped: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        showPop: !1,
        RUN_ENV: (0, n.get)().RUN_ENV
    },
    attached: function() {
        var t = this.props || this.data || {};
        this.thirdpartyId = t.thirdpartyId || (0, n.get)().THIRD_PART_ID, t.env && (0, n.set)({
            XM_ENV: t.env
        });
    },
    detached: function() {
        clearTimeout(this.codeTimer);
    },
    methods: {
        isNotWx: function() {
            return "wx" !== (0, n.get)().RUN_ENV || "undefined" == typeof wx;
        },
        isNotSwan: function() {
            return "swan" !== (0, n.get)().RUN_ENV || "undefined" == typeof swan;
        },
        getCode: function() {
            var t = this;
            return new Promise(function(e, i) {
                if (t.isNotWx() && t.isNotSwan()) e(); else {
                    ("wx" === (0, n.get)().RUN_ENV ? wx.login : swan.login)({
                        success: function() {
                            var n = (arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}).code;
                            t.code = n, e(n);
                        },
                        fail: function(e) {
                            return t.codeError = e, i(e);
                        }
                    });
                }
            });
        },
        getUserInfo: function(t) {
            var e = this, i = t.detail, r = i.iv, o = i.encryptedData;
            o && this.getCode().then(function(t) {
                t && (e.code = t, new Promise(function(t, n) {
                    e.code ? t({
                        code: e.code
                    }) : n(e.codeError || "授权码获取失败");
                }).then(function(t) {
                    var n = t.code;
                    return e.onAuth({
                        code: n,
                        encryptedData: o,
                        iv: r
                    });
                }).then(e.onAuthSuccess.bind(e)).then(e.success.bind(e), e.fail.bind(e)));
            }).catch(function(t) {
                n.Toast.info("授权code获取失败:" + t.message);
            });
        },
        getPhoneNumber: function(t) {
            this.authData = t.detail, this.authData.encryptedData && (0, n.getAuthUniInfo)().then(this.onAuth.bind(this)).then(this.onAuthSuccess.bind(this)).then(this.success.bind(this), this.fail.bind(this));
        },
        success: function() {
            var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, e = t.ret, i = t.msg, r = this.props || this.data;
            if (0 !== e) throw {
                code: e,
                message: i
            };
            return r.scoped || n.onSuccess.call(t), this.triggerEvent("success", t), t;
        },
        fail: function() {
            var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, e = t.message, i = void 0 === e ? "auth error" : e;
            console.log(t, "error"), this.triggerEvent("fail", t), n.Toast.info(i);
        },
        onAuth: function(i) {
            var r = i.code, o = i.encryptedData, a = i.iv, s = this.thirdpartyId;
            return (0, n.authLogin)({
                thirdpartyId: s,
                code: r,
                encryptedData: o,
                iv: a
            }).then(function(n) {
                var i = n.key, o = t(n, [ "key" ]);
                return e({
                    key: i
                }, o, {
                    code: r
                });
            });
        },
        onAuthSuccess: function(t) {
            var e = this, n = t.bizKey, i = t.ret, r = t.mobileCipher, o = t.mobileMask, a = t.msg, s = t.loginType, c = this.thirdpartyId;
            if (console.log("onAuthSuccess", i), 0 === i) return t;
            if (20005 !== i) {
                if (20004 === i) return this.getPermit().then(function() {
                    return e.toBindPhone({
                        thirdpartyLoginKey: n
                    });
                }).catch(function(t) {
                    e.triggerEvent("bindphone", {
                        url: "/bindPhone?bizKey=" + n + "&thirdpartyId=" + c + "&loginType=" + s
                    });
                });
                throw {
                    code: i,
                    message: a
                };
            }
            this.triggerEvent("checkphone", {
                url: "/checkPhone?bizKey=" + n + "&mobileMask=" + o + "&mobileCipher=" + r + "&thirdpartyId=" + c
            });
        },
        getPermit: function() {
            var t = this;
            return new Promise(function(e) {
                "wx" === (0, n.get)().RUN_ENV || "swan" === (0, n.get)().RUN_ENV ? (t._resolver = e, 
                t.setData({
                    showPop: !0
                })) : e();
            });
        },
        onPermitBtnClick: function(t) {
            this.authData = t.detail, this.setData({
                showPop: !1
            }), this._resolver();
        },
        closePop: function() {
            this.setData({
                showPop: !1
            });
        },
        toBindPhone: function(t) {
            var e = t.thirdpartyLoginKey, i = this.authData || {}, r = i.encryptedData, o = i.iv, a = i.errMsg, s = void 0 === a ? "获取手机号失败" : a;
            if (!r) throw {
                code: 500,
                message: s
            };
            var c = this.thirdpartyId;
            return (0, n.getMyEncryptPhone)({
                encryptedData: r,
                iv: o
            }).then(function(t) {
                var i = t.encryptedData, r = t.iv;
                return (0, n.decryptPhone)({
                    encryptedData: i,
                    iv: r,
                    thirdpartyId: c
                }).then(function(t) {
                    var i = t.ret, r = t.msg, o = t.data;
                    if (0 !== i) throw {
                        code: i,
                        message: r
                    };
                    return (0, n.liteBindPhone)({
                        thirdpartyLoginKey: e,
                        mobileKey: o,
                        forceBind: !1,
                        thirdpartyId: c
                    });
                });
            });
        }
    }
});