var e = require("../../lib/index");

Component({
    methods: {
        onClick: function(t) {
            var a = (t.target.targetDataSet || t.target.dataset).type;
            "service" === a ? wx.navigateTo({
                url: (0, e.webview)() + "?url=" + encodeURIComponent("https://passport" + ("test" === (0, 
                e.get)().XM_ENV ? ".test" : "") + ".ximalaya.com/page/register_rule")
            }) : "privacy" === a && wx.navigateTo({
                url: (0, e.webview)() + "?url=" + encodeURIComponent("https://passport" + ("test" === (0, 
                e.get)().XM_ENV ? ".test" : "") + ".ximalaya.com/page/privacy_policy")
            });
        }
    }
});