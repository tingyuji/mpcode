Component({
    properties: {
        platform: {
            type: String,
            value: ""
        }
    }
});