Component({
    properties: {
        style: {
            type: String,
            value: ""
        }
    }
});