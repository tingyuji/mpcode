var e = require("../../lib/index");

Component({
    methods: {
        onClick: function(t) {
            wx.navigateTo({
                url: (0, e.webview)() + "?url=" + encodeURIComponent("https://m.ximalaya.com/marketing/activity2/90844623431/ts-1600771987741?use_lottie=false")
            });
        }
    }
});