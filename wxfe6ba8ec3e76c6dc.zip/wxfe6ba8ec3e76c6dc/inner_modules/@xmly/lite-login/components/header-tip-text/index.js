Component({
    methods: {
        test: function() {}
    }
});