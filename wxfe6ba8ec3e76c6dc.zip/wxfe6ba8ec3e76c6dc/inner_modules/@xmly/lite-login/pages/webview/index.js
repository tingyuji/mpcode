Page({
    data: {
        src: ""
    },
    onLoad: function() {
        var t = (arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}).url, o = void 0 === t ? "" : t;
        this.setData({
            src: decodeURIComponent(o)
        });
    }
});