var t = require("../../lib/index"), e = require("../../../../../inner_modules/@xmly/captcha-xmlite/dist/data");

Component({
    properties: {
        loginLinkVisible: {
            type: Boolean,
            value: !0
        },
        enterByRoot: {
            type: Boolean,
            value: !1
        },
        noTip: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        type: "password",
        env: (0, t.get)().XM_ENV
    },
    onInit: function() {
        this.initEnv();
    },
    created: function() {
        this.initEnv();
    },
    attached: function() {
        this.initEnv(), (0, t.log)(9572, "pageview", {
            currPage: "phoneLogin",
            loginType: "password"
        });
    },
    detached: function() {
        (0, t.log)(9573, "pageExit", {
            currPage: "phoneLogin",
            loginType: "password"
        });
    },
    methods: {
        initEnv: function() {
            var e = this.data.env = (0, t.get)().XM_ENV;
            this.setData({
                env: e
            });
        },
        initcap: function() {
            var i = (0, e.getInstance)();
            this.cap = i, i.once("success", function() {
                var e = (arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}).token;
                e && (t.cookies.set("fds_otp", e, {
                    expires: Date.now() + 864e5
                }), (0, t.setFdsOtp)(e));
            });
        },
        startCap: function() {
            var e = this.cap;
            return e.start(), new Promise(function(i, n) {
                e.once("success", function() {
                    var e = (arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}).token;
                    e ? i(t.cookies.set("fds_otp", e, {
                        expires: Date.now() + 864e5,
                        domain: "ximalaya.com"
                    }), (0, t.setFdsOtp)(e)) : i();
                }), e.once("error", n);
            });
        },
        onPhoneInput: function(t) {
            this.mobile = t.detail;
        },
        onPwdInput: function(t) {
            this.password = t.detail.value.trim();
        },
        changeLogin: function() {
            (0, t.log)(9575, "click", {
                currPage: "phoneLogin",
                item: "其他登录方式",
                loginType: "securityCode"
            }), (0, t.getHistory)().push("/login");
        },
        onSubmit: function() {
            var t = this.data.type;
            "email" === t ? this.submitEmailForm() : "password" === t && this.submitPwdForm();
        },
        submitPwdForm: function() {
            var e = this.mobile, i = this.password, n = this.props || this.data || {}, o = n.noTip;
            (0, t.log)(9574, "click", {
                currPage: "phoneLogin",
                item: "登录",
                loginType: "password"
            });
            var s = (0, t.getHistory)();
            if (!i) return t.Toast.info("密码不能为空");
            if (!e) return t.Toast.info("手机号不能为空");
            var a = {
                account: e,
                password: i
            };
            this.startCap().then(function() {
                return (0, t.accoutLogin)(a);
            }).then(function(e) {
                var i = e.ret, n = e.msg, a = e.bizKey, r = e.mobileMask, c = e.mobileCipher, p = e.uid, u = e.loginType, l = e.thirdpartyId, d = void 0 === l ? "" : l;
                if (0 === i) t.onSuccess.call({
                    uid: p,
                    loginType: u
                }); else if (20004 === i) s.push("/bindPhone?bizKey=" + a + "&thirdpartyId=" + d); else if (20005 === i) {
                    var h = "/checkPhone?bizKey=" + a + "&mobileMask=" + r + "&mobileCipher=" + c + "&thirdpartyId=" + d;
                    s.push(h);
                } else if (20007 === i) {
                    if (o) return t.Toast.info("密码错误");
                    (0, t.Alert)("密码错误", "试试验证码登录吧", {
                        text: "知道了"
                    }).then(function(t) {
                        t && s.push("/smscode");
                    });
                } else if (20011 === i) {
                    if (o) return t.Toast.info("登录频繁稍后再试~");
                    (0, t.Alert)("登录频繁", "请使用验证码登录", {
                        text: "知道了"
                    }).then(function(t) {
                        t && s.push("/smscode");
                    });
                } else t.Toast.info(n || "network error");
            });
        }
    }
});