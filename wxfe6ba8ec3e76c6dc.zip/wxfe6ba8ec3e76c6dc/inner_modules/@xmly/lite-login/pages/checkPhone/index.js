var i = require("../../lib/index");

Component({
    properties: {
        env: {
            type: String,
            value: "test"
        }
    },
    data: {},
    created: function() {
        this.initCmp();
    },
    attached: function() {
        this.initCmp(), (0, i.log)(9569, "pageview", {
            currPage: "safetyVerification"
        });
    },
    detached: function() {
        (0, i.log)(9570, "pageExit", {
            currPage: "safetyVerification"
        });
    },
    methods: {
        initCmp: function() {
            var e = (0, i.getHistory)().location.query, t = (e = void 0 === e ? {} : e).mobileMask, o = void 0 === t ? "139****9999" : t, n = e.mobileCipher, a = e.bizKey;
            this.setData({
                mobileMask: o,
                mobile: n
            }), this.mobile = n, this.bizKey = a;
        },
        onCodeInput: function(i) {
            this.code = i.detail;
        },
        onSubmit: function() {
            var e = this.mobile, t = this.code, o = this.bizKey;
            return t ? e ? o ? ((0, i.log)(9571, "click", {
                currPage: "safetyVerification",
                item: "提交"
            }), void (0, i.checkPhone)({
                mobile: e,
                code: t,
                bizKey: o
            }).then(function(e) {
                var t = e.ret, o = e.msg;
                e.uid, e.loginType;
                0 === t ? (0, i.onSuccess)() : i.Toast.info(o || "network error");
            }).catch(function(e) {
                var t = e.message, o = void 0 === t ? "network error" : t;
                e.code;
                i.Toast.info(o);
            })) : i.Toast.info("bizKey不能为空") : i.Toast.info("手机号不能为空") : i.Toast.info("验证码不能为空");
        }
    }
});