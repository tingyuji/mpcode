function e(e, t) {
    var o = {};
    for (var r in e) t.indexOf(r) >= 0 || Object.prototype.hasOwnProperty.call(e, r) && (o[r] = e[r]);
    return o;
}

var t = Object.assign || function(e) {
    for (var t = 1; t < arguments.length; t++) {
        var o = arguments[t];
        for (var r in o) Object.prototype.hasOwnProperty.call(o, r) && (e[r] = o[r]);
    }
    return e;
}, o = require("../../lib/index");

Component({
    properties: {
        noAuth: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        RUN_ENV: (0, o.get)().RUN_ENV,
        platform: ""
    },
    attached: function() {
        (0, o.log)(9562, "pageview", {
            currPage: "login",
            fromUrl: (0, o.get)().RUN_ENV
        }), this.getCode();
    },
    detached: function() {
        (0, o.log)(9563, "pageExit", {
            currPage: "login",
            fromUrl: (0, o.get)().RUN_ENV
        }), clearTimeout(this.codeTimer);
    },
    methods: {
        toCheckPhone: function(e) {
            var t = e.detail.url;
            (0, o.getHistory)().push(t);
        },
        getCode: function() {
            var e = this;
            if ("wx" === (0, o.get)().RUN_ENV && "undefined" != typeof wx) {
                !function t() {
                    wx.login({
                        success: function() {
                            var t = (arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}).code;
                            e.code = t;
                        },
                        fail: function(t) {
                            return e.codeError = t;
                        }
                    }), e.codeTimer = setTimeout(t, 3e5);
                }();
            }
        },
        getUserInfo: function(e) {
            var t = this, r = e.detail, i = r.iv, n = r.encryptedData;
            new Promise(function(e, o) {
                t.code ? e({
                    code: t.code
                }) : o(t.codeError || "授权码获取失败");
            }).then(function(e) {
                var o = e.code;
                return t.onAuth({
                    code: o,
                    encryptedData: n,
                    iv: i
                });
            }).then(this.onThirdPartyLogin.bind(this)).catch(this.onThirdPartyError.bind(this));
            (0, o.log)(9564, "clickButton", {
                currPage: "login",
                item: "微信账号登录"
            });
        },
        onBtnClicked: function(e) {
            var t = e.target.targetDataset || e.target.dataset, r = t.type, i = t.url, n = (0, 
            o.getHistory)(), a = "";
            if ("alipay-account" === r) a = "支付宝账号登录"; else if ("baidu-account" === r) a = "百度账号登录"; else {
                if ("wechat-account" === r) return;
                "qq-account" === r && (a = "QQ账号登录");
            }
            a && ((0, o.getAuthUniInfo)().then(this.onAuth.bind(this)).then(this.onThirdPartyLogin.bind(this)).catch(this.onThirdPartyError.bind(this)), 
            (0, o.log)(9564, "clickButton", {
                currPage: "login",
                item: a
            })), i && n.push(i);
        },
        onAuth: function(r) {
            var i = r.code, n = r.encryptedData, a = r.iv, c = (0, o.get)().THIRD_PART_ID;
            return (0, o.authLogin)({
                thirdpartyId: c,
                code: i,
                encryptedData: n,
                iv: a
            }).then(function(o) {
                var r = o.key, n = e(o, [ "key" ]);
                return t({
                    key: r
                }, n, {
                    code: i
                });
            });
        },
        onThirdPartyLogin: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = e.ret, r = e.msg, i = e.bizKey, n = e.mobileMask, a = e.mobileCipher, c = e.uid, d = e.loginType, u = e.thirdpartyId, h = void 0 === u ? "" : u, s = (0, 
            o.getHistory)();
            switch (t) {
              case 0:
                (0, o.log)("send", "event", {
                    serviceId: "login",
                    userId: c,
                    loginType: d,
                    id: 6548
                }), o.onSuccess.call({
                    uid: c,
                    loginType: d
                });
                break;

              case 20004:
                s.push("/bindPhone?bizKey=" + i + "&thirdpartyId=" + h + "&loginType=" + d);
                break;

              case 20005:
                s.push("/checkPhone?bizKey=" + i + "&mobileMask=" + n + "&mobileCipher=" + a + "&thirdpartyId=" + h);
                break;

              default:
                throw {
                    code: t,
                    message: r
                };
            }
        },
        onThirdPartyError: function() {
            var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, r = t.code, i = void 0 === r ? -1 : r, n = t.message, a = void 0 === n ? "未知异常" : n, c = e(t, [ "code", "message" ]);
            if (-2 === i) return (0, o.Alert)("系统异常提示", "请在设置中开启公开信息按钮").then(function() {
                return swan.openSetting({});
            });
            console.log(c, "error rest info"), o.Toast.info(a);
        }
    }
});