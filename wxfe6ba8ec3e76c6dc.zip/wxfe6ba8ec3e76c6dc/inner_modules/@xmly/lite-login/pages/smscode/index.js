var e = require("../../lib/index");

Component({
    data: {
        mobile: ""
    },
    properties: {
        loginLinkVisible: {
            type: Boolean,
            value: !0
        }
    },
    attached: function() {
        (0, e.log)(9572, "pageview", {
            currPage: "phoneLogin",
            loginType: "securityCode"
        });
    },
    detached: function() {
        (0, e.log)(9573, "pageExit", {
            currPage: "phoneLogin",
            loginType: "securityCode"
        });
    },
    methods: {
        onPhoneInput: function(e) {
            var o = this.mobile = e.detail;
            this.setData({
                mobile: o
            });
        },
        onCodeInput: function(e) {
            this.code = e.detail;
        },
        changeLogin: function() {
            (0, e.log)(9575, "click", {
                currPage: "phoneLogin",
                item: "其他登录方式",
                loginType: "password"
            }), (0, e.getHistory)().push("/login");
        },
        onSubmit: function() {
            var o = this.mobile, i = this.code;
            return i ? o ? ((0, e.log)(9574, "click", {
                currPage: "phoneLogin",
                item: "登录",
                loginType: "securityCode"
            }), void (0, e.SMSLogin)({
                mobile: o,
                code: i
            }).then(function(o) {
                var i = o.ret, n = o.uid, t = o.isFirst, c = {
                    uid: n,
                    loginType: o.loginType
                };
                if (0 === i) {
                    if (t) return (0, e.Alert)("注册成功", "如需使用密码登录可在app内设置", {
                        text: "知道了"
                    }).then(function() {
                        return e.onSuccess.call(c);
                    });
                    e.onSuccess.call(c);
                }
            }).catch(function() {
                var o = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, i = o.message, n = void 0 === i ? "network error" : i;
                o.code;
                e.Toast.info(n);
            })) : e.Toast.info("手机号不能为空") : e.Toast.info("验证码不能为空");
        }
    }
});