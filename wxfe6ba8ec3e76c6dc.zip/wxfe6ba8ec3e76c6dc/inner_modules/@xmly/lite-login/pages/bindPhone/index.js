function e(e, o) {
    var i = {};
    for (var n in e) o.indexOf(n) >= 0 || Object.prototype.hasOwnProperty.call(e, n) && (i[n] = e[n]);
    return i;
}

var o = require("../../lib/index");

Component({
    properties: {
        env: {
            type: String,
            value: "test"
        }
    },
    data: {},
    attached: function() {
        var e = (0, o.getHistory)().location.query, i = (e = void 0 === e ? {} : e).bizKey, n = e.loginType;
        this.bizKey = i, this._loginPage = !0, (0, o.log)(9566, "pageview", {
            currPage: "bindPhone",
            loginType: n
        });
    },
    detached: function() {
        var e = (0, o.getHistory)().location.query, i = (e = void 0 === e ? {} : e).loginType;
        (0, o.log)(9567, "pageExit", {
            currPage: "bindPhone",
            loginType: i
        });
    },
    methods: {
        onPhoneInput: function(e) {
            var o = this.mobile = e.detail;
            this.setData({
                mobile: o
            });
        },
        onCodeInput: function(e) {
            this.code = e.detail;
        },
        onSubmit: function() {
            var i = this.mobile, n = this.code, t = this.bizKey;
            return n ? i ? t ? ((0, o.log)(9568, "click", {
                currPage: "bindPhone",
                item: "绑定并登录"
            }), void (0, o.bindPhone)({
                mobile: i,
                code: n,
                bizKey: t
            }).then(function(e) {
                var i = e.ret, n = e.msg, t = e.uid, r = e.loginType;
                if (0 !== i) throw {
                    code: i,
                    message: n
                };
                (0, o.log)("send", "event", {
                    serviceId: "login",
                    userId: t,
                    loginType: r,
                    id: 6548
                }), (0, o.onSuccess)();
            }).catch(function() {
                var i = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, n = i.message, t = void 0 === n ? "network error" : n, r = i.code, a = e(i, [ "message", "code" ]);
                console.log(a, "err info"), 33009 === r && (t = t.replace("是否强制绑定？", "请更换手机号")), 
                o.Toast.info(t);
            })) : o.Toast.info("bizKey不能为空") : o.Toast.info("手机号不能为空") : o.Toast.info("验证码不能为空");
        }
    }
});