var t = require("../lib/index");

Component({
    properties: {
        env: {
            type: String,
            value: ""
        },
        thirdpartyId: {
            type: Number
        },
        url: {
            type: String,
            value: "/login"
        },
        footerVisible: {
            type: Boolean,
            value: !0
        },
        headerTipVisible: {
            type: Boolean,
            value: !1
        },
        loginLinkVisible: {
            type: Boolean,
            value: !0
        },
        noAuth: {
            type: Boolean,
            value: !1
        },
        noTip: {
            type: Boolean,
            value: !1
        },
        appkey: {
            type: String,
            value: ""
        },
        alipayScope: {
            type: String,
            value: ""
        }
    },
    data: {
        enterByRoot: !0
    },
    created: function() {
        this.initEnv(), this.initHistory(), this.initAlipayScope();
    },
    attached: function() {
        this.initEnv(), this.initAlipayScope();
        var i = (this.props || this.data || {}).url;
        "/login" !== i && this.setData({
            enterByRoot: !1
        }), (0, t.start)({
            b: 63,
            p: (0, t.get)().RUN_ENV,
            e: (0, t.get)().XM_ENV
        }), this.history || this.initHistory(), i && -1 !== i.indexOf("?") && this.history.replace(i);
    },
    detached: function() {
        this.unsubscribe(), this.unbind(), console.log("detached");
    },
    methods: {
        initHistory: function() {
            var i = this, e = (this.props || this.data || {}).url;
            this.history = (0, t.createHistory)(e), this.unsubscribe = this.history.subscribe(function(t) {
                var e = t.pathname;
                i.setData({
                    url: e
                });
            }), this.unbind = (0, t.onSuccess)(function(t) {
                i.triggerEvent("success", t);
            });
        },
        onSuccessFn: function() {
            wx.navigateBack();
        },
        initEnv: function() {
            var i = this.props || this.data || {}, e = i.env, n = i.thirdpartyId, s = i.appkey;
            t.cookies.set("impl", n + "&" + s), e && (0, t.set)("XM_ENV", e), n && (0, t.set)("THIRD_PART_ID", n);
        },
        initAlipayScope: function() {
            var i = (this.props || this.data || {}).alipayScope;
            i && (0, t.set)("ALIPAY_SCOPE", i);
        }
    }
});