var e = require("./md5.js"), n = require("../../inner_modules/assert");

describe("md5", function() {
    it("should throw an error for `undefined`", function() {
        n.throws(function() {
            e(void 0);
        });
    }), it("should throw an error for `null`", function() {
        n.throws(function() {
            e(null);
        });
    }), it('should return the expected MD5 hash for "message"', function() {
        n.equal("78e731027d8fd50ed642340b7c9a63b3", e("message"));
    }), it("should not return the same hash for random numbers twice", function() {
        var r = Math.floor(1e5 * Math.random() + 1) + new Date().getTime(), t = Math.floor(1e5 * Math.random() + 1) + new Date().getTime();
        r !== t ? n.notEqual(e(r), e(t)) : n.equal(e(r), e(r));
    }), it("should support Node.js Buffers", function() {
        var r = new Buffer("message áßäöü", "utf8");
        n.equal(e(r), e("message áßäöü"));
    }), it("should be able to use a binary encoded string", function() {
        var r = e("abc", {
            asString: !0
        }), t = (e(r + "a", {
            asString: !0,
            encoding: "binary"
        }), e(r + "a", {
            encoding: "binary"
        }));
        n.equal(t, "131f0ac52813044f5110e4aec638c169");
    });
});