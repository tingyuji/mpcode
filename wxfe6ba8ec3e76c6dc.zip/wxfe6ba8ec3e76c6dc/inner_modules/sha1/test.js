var e = require("./sha1.js"), a = require("../../inner_modules/assert");

describe("sha1", function() {
    it('should return the expected SHA-1 hash for "message"', function() {
        a.equal("6f9b9af3cd6e8b8a73c2cdced37fe9f59226e27d", e("message"));
    }), it("should not return the same hash for random numbers twice", function() {
        var t = Math.floor(1e5 * Math.random() + 1) + new Date().getTime(), r = Math.floor(1e5 * Math.random() + 1) + new Date().getTime();
        t !== r ? a.notEqual(e(t), e(r)) : a.equal(e(t), e(t));
    }), it("should node.js Buffer", function() {
        var t = new Buffer("hello, sha1", "utf8");
        a.equal(e(t), e("hello, sha1"));
    });
});