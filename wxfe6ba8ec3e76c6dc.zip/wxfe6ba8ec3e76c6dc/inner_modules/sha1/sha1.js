!function() {
    var r = require("../../inner_modules/crypt/crypt.js"), e = require("../../inner_modules/charenc/charenc.js").utf8, t = require("../../inner_modules/charenc/charenc.js").bin, n = function(t) {
        t.constructor == String ? t = e.stringToBytes(t) : "undefined" != typeof Buffer && "function" == typeof Buffer.isBuffer && Buffer.isBuffer(t) ? t = Array.prototype.slice.call(t, 0) : Array.isArray(t) || (t = t.toString());
        var n = r.bytesToWords(t), s = 8 * t.length, i = [], o = 1732584193, u = -271733879, f = -1732584194, c = 271733878, a = -1009589776;
        n[s >> 5] |= 128 << 24 - s % 32, n[15 + (s + 64 >>> 9 << 4)] = s;
        for (var y = 0; y < n.length; y += 16) {
            for (var l = o, d = u, g = f, B = c, p = a, v = 0; v < 80; v++) {
                if (v < 16) i[v] = n[y + v]; else {
                    var h = i[v - 3] ^ i[v - 8] ^ i[v - 14] ^ i[v - 16];
                    i[v] = h << 1 | h >>> 31;
                }
                var b = (o << 5 | o >>> 27) + a + (i[v] >>> 0) + (v < 20 ? 1518500249 + (u & f | ~u & c) : v < 40 ? 1859775393 + (u ^ f ^ c) : v < 60 ? (u & f | u & c | f & c) - 1894007588 : (u ^ f ^ c) - 899497514);
                a = c, c = f, f = u << 30 | u >>> 2, u = o, o = b;
            }
            o += l, u += d, f += g, c += B, a += p;
        }
        return [ o, u, f, c, a ];
    }, s = function(e, s) {
        var i = r.wordsToBytes(n(e));
        return s && s.asBytes ? i : s && s.asString ? t.bytesToString(i) : r.bytesToHex(i);
    };
    s._blocksize = 16, s._digestsize = 20, module.exports = s;
}();