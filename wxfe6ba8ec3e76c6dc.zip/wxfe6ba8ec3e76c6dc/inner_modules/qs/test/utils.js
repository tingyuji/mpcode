var e = require("../../../inner_modules/tape"), a = require("../../../inner_modules/object-inspect"), r = require("../../../inner_modules/safer-buffer").Buffer, n = require("../../../inner_modules/for-each"), o = require("../lib/utils");

e("merge()", function(e) {
    e.deepEqual(o.merge(null, !0), [ null, !0 ], "merges true into null"), e.deepEqual(o.merge(null, [ 42 ]), [ null, 42 ], "merges null into an array"), 
    e.deepEqual(o.merge({
        a: "b"
    }, {
        a: "c"
    }), {
        a: [ "b", "c" ]
    }, "merges two objects with the same key");
    var a = o.merge({
        foo: "bar"
    }, {
        foo: {
            first: "123"
        }
    });
    e.deepEqual(a, {
        foo: [ "bar", {
            first: "123"
        } ]
    }, "merges a standalone and an object into an array");
    var r = o.merge({
        foo: [ "bar", {
            first: "123"
        } ]
    }, {
        foo: {
            second: "456"
        }
    });
    e.deepEqual(r, {
        foo: {
            0: "bar",
            1: {
                first: "123"
            },
            second: "456"
        }
    }, "merges a standalone and two objects into an array");
    var n = o.merge({
        foo: [ "bar", {
            first: "123",
            second: "456"
        } ]
    }, {
        foo: "baz"
    });
    e.deepEqual(n, {
        foo: [ "bar", {
            first: "123",
            second: "456"
        }, "baz" ]
    }, "merges an object sandwiched by two standalones into an array");
    var t = o.merge({
        foo: [ "baz" ]
    }, {
        foo: [ "bar", "xyzzy" ]
    });
    e.deepEqual(t, {
        foo: [ "baz", "bar", "xyzzy" ]
    });
    var u = o.merge({
        foo: "baz"
    }, "bar");
    e.deepEqual(u, {
        foo: "baz",
        bar: !0
    }), e.test("avoids invoking array setters unnecessarily", {
        skip: "function" != typeof Object.defineProperty
    }, function(e) {
        var a = 0, r = 0, n = [];
        Object.defineProperty(n, 0, {
            get: function() {
                return r += 1, {
                    bar: "baz"
                };
            },
            set: function() {
                a += 1;
            }
        }), o.merge(n, [ null ]), e.equal(a, 0), e.equal(r, 1), n[0] = n[0], e.equal(a, 1), 
        e.equal(r, 2), e.end();
    }), e.end();
}), e("assign()", function(e) {
    var a = {
        a: 1,
        b: 2
    }, r = {
        b: 3,
        c: 4
    }, n = o.assign(a, r);
    e.equal(n, a, "returns the target"), e.deepEqual(a, {
        a: 1,
        b: 3,
        c: 4
    }, "target and source are merged"), e.deepEqual(r, {
        b: 3,
        c: 4
    }, "source is untouched"), e.end();
}), e("combine()", function(e) {
    e.test("both arrays", function(e) {
        var a = [ 1 ], r = [ 2 ], n = o.combine(a, r);
        e.deepEqual(a, [ 1 ], "a is not mutated"), e.deepEqual(r, [ 2 ], "b is not mutated"), 
        e.notEqual(a, n, "a !== combined"), e.notEqual(r, n, "b !== combined"), e.deepEqual(n, [ 1, 2 ], "combined is a + b"), 
        e.end();
    }), e.test("one array, one non-array", function(e) {
        var a = [ 1 ], r = [ 2 ], n = o.combine(1, r);
        e.deepEqual(r, [ 2 ], "b is not mutated"), e.notEqual(1, n, "aN + b !== aN"), e.notEqual(a, n, "aN + b !== a"), 
        e.notEqual(2, n, "aN + b !== bN"), e.notEqual(r, n, "aN + b !== b"), e.deepEqual([ 1, 2 ], n, "first argument is array-wrapped when not an array");
        var t = o.combine(a, 2);
        e.deepEqual(a, [ 1 ], "a is not mutated"), e.notEqual(1, t, "a + bN !== aN"), e.notEqual(a, t, "a + bN !== a"), 
        e.notEqual(2, t, "a + bN !== bN"), e.notEqual(r, t, "a + bN !== b"), e.deepEqual([ 1, 2 ], t, "second argument is array-wrapped when not an array"), 
        e.end();
    }), e.test("neither is an array", function(e) {
        var a = o.combine(1, 2);
        e.notEqual(1, a, "1 + 2 !== 1"), e.notEqual(2, a, "1 + 2 !== 2"), e.deepEqual([ 1, 2 ], a, "both arguments are array-wrapped when not an array"), 
        e.end();
    }), e.end();
}), e("isBuffer()", function(e) {
    n([ null, void 0, !0, !1, "", "abc", 42, 0, NaN, {}, [], function() {}, /a/g ], function(r) {
        e.equal(o.isBuffer(r), !1, a(r) + " is not a buffer");
    });
    var t = {
        constructor: Buffer
    };
    e.equal(o.isBuffer(t), !1, "fake buffer is not a buffer");
    var u = r.from("abc");
    e.equal(o.isBuffer(u), !0, "SaferBuffer instance is a buffer");
    var f = Buffer.from && Buffer.alloc ? Buffer.from("abc") : new Buffer("abc");
    e.equal(o.isBuffer(f), !0, "real Buffer instance is a buffer"), e.end();
});