var e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
}, a = require("../../../inner_modules/tape"), r = require("../"), t = require("../lib/utils"), o = require("../../../inner_modules/iconv-lite"), s = require("../../../inner_modules/safer-buffer").Buffer;

a("parse()", function(a) {
    a.test("parses a simple string", function(e) {
        e.deepEqual(r.parse("0=foo"), {
            0: "foo"
        }), e.deepEqual(r.parse("foo=c++"), {
            foo: "c  "
        }), e.deepEqual(r.parse("a[>=]=23"), {
            a: {
                ">=": "23"
            }
        }), e.deepEqual(r.parse("a[<=>]==23"), {
            a: {
                "<=>": "=23"
            }
        }), e.deepEqual(r.parse("a[==]=23"), {
            a: {
                "==": "23"
            }
        }), e.deepEqual(r.parse("foo", {
            strictNullHandling: !0
        }), {
            foo: null
        }), e.deepEqual(r.parse("foo"), {
            foo: ""
        }), e.deepEqual(r.parse("foo="), {
            foo: ""
        }), e.deepEqual(r.parse("foo=bar"), {
            foo: "bar"
        }), e.deepEqual(r.parse(" foo = bar = baz "), {
            " foo ": " bar = baz "
        }), e.deepEqual(r.parse("foo=bar=baz"), {
            foo: "bar=baz"
        }), e.deepEqual(r.parse("foo=bar&bar=baz"), {
            foo: "bar",
            bar: "baz"
        }), e.deepEqual(r.parse("foo2=bar2&baz2="), {
            foo2: "bar2",
            baz2: ""
        }), e.deepEqual(r.parse("foo=bar&baz", {
            strictNullHandling: !0
        }), {
            foo: "bar",
            baz: null
        }), e.deepEqual(r.parse("foo=bar&baz"), {
            foo: "bar",
            baz: ""
        }), e.deepEqual(r.parse("cht=p3&chd=t:60,40&chs=250x100&chl=Hello|World"), {
            cht: "p3",
            chd: "t:60,40",
            chs: "250x100",
            chl: "Hello|World"
        }), e.end();
    }), a.test("arrayFormat: brackets allows only explicit arrays", function(e) {
        e.deepEqual(r.parse("a[]=b&a[]=c", {
            arrayFormat: "brackets"
        }), {
            a: [ "b", "c" ]
        }), e.deepEqual(r.parse("a[0]=b&a[1]=c", {
            arrayFormat: "brackets"
        }), {
            a: [ "b", "c" ]
        }), e.deepEqual(r.parse("a=b,c", {
            arrayFormat: "brackets"
        }), {
            a: "b,c"
        }), e.deepEqual(r.parse("a=b&a=c", {
            arrayFormat: "brackets"
        }), {
            a: [ "b", "c" ]
        }), e.end();
    }), a.test("arrayFormat: indices allows only indexed arrays", function(e) {
        e.deepEqual(r.parse("a[]=b&a[]=c", {
            arrayFormat: "indices"
        }), {
            a: [ "b", "c" ]
        }), e.deepEqual(r.parse("a[0]=b&a[1]=c", {
            arrayFormat: "indices"
        }), {
            a: [ "b", "c" ]
        }), e.deepEqual(r.parse("a=b,c", {
            arrayFormat: "indices"
        }), {
            a: "b,c"
        }), e.deepEqual(r.parse("a=b&a=c", {
            arrayFormat: "indices"
        }), {
            a: [ "b", "c" ]
        }), e.end();
    }), a.test("arrayFormat: comma allows only comma-separated arrays", function(e) {
        e.deepEqual(r.parse("a[]=b&a[]=c", {
            arrayFormat: "comma"
        }), {
            a: [ "b", "c" ]
        }), e.deepEqual(r.parse("a[0]=b&a[1]=c", {
            arrayFormat: "comma"
        }), {
            a: [ "b", "c" ]
        }), e.deepEqual(r.parse("a=b,c", {
            arrayFormat: "comma"
        }), {
            a: "b,c"
        }), e.deepEqual(r.parse("a=b&a=c", {
            arrayFormat: "comma"
        }), {
            a: [ "b", "c" ]
        }), e.end();
    }), a.test("arrayFormat: repeat allows only repeated values", function(e) {
        e.deepEqual(r.parse("a[]=b&a[]=c", {
            arrayFormat: "repeat"
        }), {
            a: [ "b", "c" ]
        }), e.deepEqual(r.parse("a[0]=b&a[1]=c", {
            arrayFormat: "repeat"
        }), {
            a: [ "b", "c" ]
        }), e.deepEqual(r.parse("a=b,c", {
            arrayFormat: "repeat"
        }), {
            a: "b,c"
        }), e.deepEqual(r.parse("a=b&a=c", {
            arrayFormat: "repeat"
        }), {
            a: [ "b", "c" ]
        }), e.end();
    }), a.test("allows enabling dot notation", function(e) {
        e.deepEqual(r.parse("a.b=c"), {
            "a.b": "c"
        }), e.deepEqual(r.parse("a.b=c", {
            allowDots: !0
        }), {
            a: {
                b: "c"
            }
        }), e.end();
    }), a.deepEqual(r.parse("a[b]=c"), {
        a: {
            b: "c"
        }
    }, "parses a single nested string"), a.deepEqual(r.parse("a[b][c]=d"), {
        a: {
            b: {
                c: "d"
            }
        }
    }, "parses a double nested string"), a.deepEqual(r.parse("a[b][c][d][e][f][g][h]=i"), {
        a: {
            b: {
                c: {
                    d: {
                        e: {
                            f: {
                                "[g][h]": "i"
                            }
                        }
                    }
                }
            }
        }
    }, "defaults to a depth of 5"), a.test("only parses one level when depth = 1", function(e) {
        e.deepEqual(r.parse("a[b][c]=d", {
            depth: 1
        }), {
            a: {
                b: {
                    "[c]": "d"
                }
            }
        }), e.deepEqual(r.parse("a[b][c][d]=e", {
            depth: 1
        }), {
            a: {
                b: {
                    "[c][d]": "e"
                }
            }
        }), e.end();
    }), a.test("uses original key when depth = 0", function(e) {
        e.deepEqual(r.parse("a[0]=b&a[1]=c", {
            depth: 0
        }), {
            "a[0]": "b",
            "a[1]": "c"
        }), e.deepEqual(r.parse("a[0][0]=b&a[0][1]=c&a[1]=d&e=2", {
            depth: 0
        }), {
            "a[0][0]": "b",
            "a[0][1]": "c",
            "a[1]": "d",
            e: "2"
        }), e.end();
    }), a.test("uses original key when depth = false", function(e) {
        e.deepEqual(r.parse("a[0]=b&a[1]=c", {
            depth: !1
        }), {
            "a[0]": "b",
            "a[1]": "c"
        }), e.deepEqual(r.parse("a[0][0]=b&a[0][1]=c&a[1]=d&e=2", {
            depth: !1
        }), {
            "a[0][0]": "b",
            "a[0][1]": "c",
            "a[1]": "d",
            e: "2"
        }), e.end();
    }), a.deepEqual(r.parse("a=b&a=c"), {
        a: [ "b", "c" ]
    }, "parses a simple array"), a.test("parses an explicit array", function(e) {
        e.deepEqual(r.parse("a[]=b"), {
            a: [ "b" ]
        }), e.deepEqual(r.parse("a[]=b&a[]=c"), {
            a: [ "b", "c" ]
        }), e.deepEqual(r.parse("a[]=b&a[]=c&a[]=d"), {
            a: [ "b", "c", "d" ]
        }), e.end();
    }), a.test("parses a mix of simple and explicit arrays", function(e) {
        e.deepEqual(r.parse("a=b&a[]=c"), {
            a: [ "b", "c" ]
        }), e.deepEqual(r.parse("a[]=b&a=c"), {
            a: [ "b", "c" ]
        }), e.deepEqual(r.parse("a[0]=b&a=c"), {
            a: [ "b", "c" ]
        }), e.deepEqual(r.parse("a=b&a[0]=c"), {
            a: [ "b", "c" ]
        }), e.deepEqual(r.parse("a[1]=b&a=c", {
            arrayLimit: 20
        }), {
            a: [ "b", "c" ]
        }), e.deepEqual(r.parse("a[]=b&a=c", {
            arrayLimit: 0
        }), {
            a: [ "b", "c" ]
        }), e.deepEqual(r.parse("a[]=b&a=c"), {
            a: [ "b", "c" ]
        }), e.deepEqual(r.parse("a=b&a[1]=c", {
            arrayLimit: 20
        }), {
            a: [ "b", "c" ]
        }), e.deepEqual(r.parse("a=b&a[]=c", {
            arrayLimit: 0
        }), {
            a: [ "b", "c" ]
        }), e.deepEqual(r.parse("a=b&a[]=c"), {
            a: [ "b", "c" ]
        }), e.end();
    }), a.test("parses a nested array", function(e) {
        e.deepEqual(r.parse("a[b][]=c&a[b][]=d"), {
            a: {
                b: [ "c", "d" ]
            }
        }), e.deepEqual(r.parse("a[>=]=25"), {
            a: {
                ">=": "25"
            }
        }), e.end();
    }), a.test("allows to specify array indices", function(e) {
        e.deepEqual(r.parse("a[1]=c&a[0]=b&a[2]=d"), {
            a: [ "b", "c", "d" ]
        }), e.deepEqual(r.parse("a[1]=c&a[0]=b"), {
            a: [ "b", "c" ]
        }), e.deepEqual(r.parse("a[1]=c", {
            arrayLimit: 20
        }), {
            a: [ "c" ]
        }), e.deepEqual(r.parse("a[1]=c", {
            arrayLimit: 0
        }), {
            a: {
                1: "c"
            }
        }), e.deepEqual(r.parse("a[1]=c"), {
            a: [ "c" ]
        }), e.end();
    }), a.test("limits specific array indices to arrayLimit", function(e) {
        e.deepEqual(r.parse("a[20]=a", {
            arrayLimit: 20
        }), {
            a: [ "a" ]
        }), e.deepEqual(r.parse("a[21]=a", {
            arrayLimit: 20
        }), {
            a: {
                21: "a"
            }
        }), e.end();
    }), a.deepEqual(r.parse("a[12b]=c"), {
        a: {
            "12b": "c"
        }
    }, "supports keys that begin with a number"), a.test("supports encoded = signs", function(e) {
        e.deepEqual(r.parse("he%3Dllo=th%3Dere"), {
            "he=llo": "th=ere"
        }), e.end();
    }), a.test("is ok with url encoded strings", function(e) {
        e.deepEqual(r.parse("a[b%20c]=d"), {
            a: {
                "b c": "d"
            }
        }), e.deepEqual(r.parse("a[b]=c%20d"), {
            a: {
                b: "c d"
            }
        }), e.end();
    }), a.test("allows brackets in the value", function(e) {
        e.deepEqual(r.parse('pets=["tobi"]'), {
            pets: '["tobi"]'
        }), e.deepEqual(r.parse('operators=[">=", "<="]'), {
            operators: '[">=", "<="]'
        }), e.end();
    }), a.test("allows empty values", function(e) {
        e.deepEqual(r.parse(""), {}), e.deepEqual(r.parse(null), {}), e.deepEqual(r.parse(void 0), {}), 
        e.end();
    }), a.test("transforms arrays to objects", function(e) {
        e.deepEqual(r.parse("foo[0]=bar&foo[bad]=baz"), {
            foo: {
                0: "bar",
                bad: "baz"
            }
        }), e.deepEqual(r.parse("foo[bad]=baz&foo[0]=bar"), {
            foo: {
                bad: "baz",
                0: "bar"
            }
        }), e.deepEqual(r.parse("foo[bad]=baz&foo[]=bar"), {
            foo: {
                bad: "baz",
                0: "bar"
            }
        }), e.deepEqual(r.parse("foo[]=bar&foo[bad]=baz"), {
            foo: {
                0: "bar",
                bad: "baz"
            }
        }), e.deepEqual(r.parse("foo[bad]=baz&foo[]=bar&foo[]=foo"), {
            foo: {
                bad: "baz",
                0: "bar",
                1: "foo"
            }
        }), e.deepEqual(r.parse("foo[0][a]=a&foo[0][b]=b&foo[1][a]=aa&foo[1][b]=bb"), {
            foo: [ {
                a: "a",
                b: "b"
            }, {
                a: "aa",
                b: "bb"
            } ]
        }), e.deepEqual(r.parse("a[]=b&a[t]=u&a[hasOwnProperty]=c", {
            allowPrototypes: !1
        }), {
            a: {
                0: "b",
                t: "u"
            }
        }), e.deepEqual(r.parse("a[]=b&a[t]=u&a[hasOwnProperty]=c", {
            allowPrototypes: !0
        }), {
            a: {
                0: "b",
                t: "u",
                hasOwnProperty: "c"
            }
        }), e.deepEqual(r.parse("a[]=b&a[hasOwnProperty]=c&a[x]=y", {
            allowPrototypes: !1
        }), {
            a: {
                0: "b",
                x: "y"
            }
        }), e.deepEqual(r.parse("a[]=b&a[hasOwnProperty]=c&a[x]=y", {
            allowPrototypes: !0
        }), {
            a: {
                0: "b",
                hasOwnProperty: "c",
                x: "y"
            }
        }), e.end();
    }), a.test("transforms arrays to objects (dot notation)", function(e) {
        e.deepEqual(r.parse("foo[0].baz=bar&fool.bad=baz", {
            allowDots: !0
        }), {
            foo: [ {
                baz: "bar"
            } ],
            fool: {
                bad: "baz"
            }
        }), e.deepEqual(r.parse("foo[0].baz=bar&fool.bad.boo=baz", {
            allowDots: !0
        }), {
            foo: [ {
                baz: "bar"
            } ],
            fool: {
                bad: {
                    boo: "baz"
                }
            }
        }), e.deepEqual(r.parse("foo[0][0].baz=bar&fool.bad=baz", {
            allowDots: !0
        }), {
            foo: [ [ {
                baz: "bar"
            } ] ],
            fool: {
                bad: "baz"
            }
        }), e.deepEqual(r.parse("foo[0].baz[0]=15&foo[0].bar=2", {
            allowDots: !0
        }), {
            foo: [ {
                baz: [ "15" ],
                bar: "2"
            } ]
        }), e.deepEqual(r.parse("foo[0].baz[0]=15&foo[0].baz[1]=16&foo[0].bar=2", {
            allowDots: !0
        }), {
            foo: [ {
                baz: [ "15", "16" ],
                bar: "2"
            } ]
        }), e.deepEqual(r.parse("foo.bad=baz&foo[0]=bar", {
            allowDots: !0
        }), {
            foo: {
                bad: "baz",
                0: "bar"
            }
        }), e.deepEqual(r.parse("foo.bad=baz&foo[]=bar", {
            allowDots: !0
        }), {
            foo: {
                bad: "baz",
                0: "bar"
            }
        }), e.deepEqual(r.parse("foo[]=bar&foo.bad=baz", {
            allowDots: !0
        }), {
            foo: {
                0: "bar",
                bad: "baz"
            }
        }), e.deepEqual(r.parse("foo.bad=baz&foo[]=bar&foo[]=foo", {
            allowDots: !0
        }), {
            foo: {
                bad: "baz",
                0: "bar",
                1: "foo"
            }
        }), e.deepEqual(r.parse("foo[0].a=a&foo[0].b=b&foo[1].a=aa&foo[1].b=bb", {
            allowDots: !0
        }), {
            foo: [ {
                a: "a",
                b: "b"
            }, {
                a: "aa",
                b: "bb"
            } ]
        }), e.end();
    }), a.test("correctly prunes undefined values when converting an array to an object", function(e) {
        e.deepEqual(r.parse("a[2]=b&a[99999999]=c"), {
            a: {
                2: "b",
                99999999: "c"
            }
        }), e.end();
    }), a.test("supports malformed uri characters", function(e) {
        e.deepEqual(r.parse("{%:%}", {
            strictNullHandling: !0
        }), {
            "{%:%}": null
        }), e.deepEqual(r.parse("{%:%}="), {
            "{%:%}": ""
        }), e.deepEqual(r.parse("foo=%:%}"), {
            foo: "%:%}"
        }), e.end();
    }), a.test("doesn't produce empty keys", function(e) {
        e.deepEqual(r.parse("_r=1&"), {
            _r: "1"
        }), e.end();
    }), a.test("cannot access Object prototype", function(a) {
        r.parse("constructor[prototype][bad]=bad"), r.parse("bad[constructor][prototype][bad]=bad"), 
        a.equal(e(Object.prototype.bad), "undefined"), a.end();
    }), a.test("parses arrays of objects", function(e) {
        e.deepEqual(r.parse("a[][b]=c"), {
            a: [ {
                b: "c"
            } ]
        }), e.deepEqual(r.parse("a[0][b]=c"), {
            a: [ {
                b: "c"
            } ]
        }), e.end();
    }), a.test("allows for empty strings in arrays", function(e) {
        e.deepEqual(r.parse("a[]=b&a[]=&a[]=c"), {
            a: [ "b", "", "c" ]
        }), e.deepEqual(r.parse("a[0]=b&a[1]&a[2]=c&a[19]=", {
            strictNullHandling: !0,
            arrayLimit: 20
        }), {
            a: [ "b", null, "c", "" ]
        }, "with arrayLimit 20 + array indices: null then empty string works"), e.deepEqual(r.parse("a[]=b&a[]&a[]=c&a[]=", {
            strictNullHandling: !0,
            arrayLimit: 0
        }), {
            a: [ "b", null, "c", "" ]
        }, "with arrayLimit 0 + array brackets: null then empty string works"), e.deepEqual(r.parse("a[0]=b&a[1]=&a[2]=c&a[19]", {
            strictNullHandling: !0,
            arrayLimit: 20
        }), {
            a: [ "b", "", "c", null ]
        }, "with arrayLimit 20 + array indices: empty string then null works"), e.deepEqual(r.parse("a[]=b&a[]=&a[]=c&a[]", {
            strictNullHandling: !0,
            arrayLimit: 0
        }), {
            a: [ "b", "", "c", null ]
        }, "with arrayLimit 0 + array brackets: empty string then null works"), e.deepEqual(r.parse("a[]=&a[]=b&a[]=c"), {
            a: [ "", "b", "c" ]
        }, "array brackets: empty strings work"), e.end();
    }), a.test("compacts sparse arrays", function(e) {
        e.deepEqual(r.parse("a[10]=1&a[2]=2", {
            arrayLimit: 20
        }), {
            a: [ "2", "1" ]
        }), e.deepEqual(r.parse("a[1][b][2][c]=1", {
            arrayLimit: 20
        }), {
            a: [ {
                b: [ {
                    c: "1"
                } ]
            } ]
        }), e.deepEqual(r.parse("a[1][2][3][c]=1", {
            arrayLimit: 20
        }), {
            a: [ [ [ {
                c: "1"
            } ] ] ]
        }), e.deepEqual(r.parse("a[1][2][3][c][1]=1", {
            arrayLimit: 20
        }), {
            a: [ [ [ {
                c: [ "1" ]
            } ] ] ]
        }), e.end();
    }), a.test("parses semi-parsed strings", function(e) {
        e.deepEqual(r.parse({
            "a[b]": "c"
        }), {
            a: {
                b: "c"
            }
        }), e.deepEqual(r.parse({
            "a[b]": "c",
            "a[d]": "e"
        }), {
            a: {
                b: "c",
                d: "e"
            }
        }), e.end();
    }), a.test("parses buffers correctly", function(e) {
        var a = s.from("test");
        e.deepEqual(r.parse({
            a: a
        }), {
            a: a
        }), e.end();
    }), a.test("parses jquery-param strings", function(e) {
        var a = {
            filter: [ [ "int1", "=", "77" ], "and", [ "int2", "=", "8" ] ]
        };
        e.deepEqual(r.parse("filter%5B0%5D%5B%5D=int1&filter%5B0%5D%5B%5D=%3D&filter%5B0%5D%5B%5D=77&filter%5B%5D=and&filter%5B2%5D%5B%5D=int2&filter%5B2%5D%5B%5D=%3D&filter%5B2%5D%5B%5D=8"), a), 
        e.end();
    }), a.test("continues parsing when no parent is found", function(e) {
        e.deepEqual(r.parse("[]=&a=b"), {
            0: "",
            a: "b"
        }), e.deepEqual(r.parse("[]&a=b", {
            strictNullHandling: !0
        }), {
            0: null,
            a: "b"
        }), e.deepEqual(r.parse("[foo]=bar"), {
            foo: "bar"
        }), e.end();
    }), a.test("does not error when parsing a very long array", function(e) {
        for (var a = "a[]=a"; Buffer.byteLength(a) < 131072; ) a = a + "&" + a;
        e.doesNotThrow(function() {
            r.parse(a);
        }), e.end();
    }), a.test("should not throw when a native prototype has an enumerable property", function(e) {
        Object.prototype.crash = "", Array.prototype.crash = "", e.doesNotThrow(r.parse.bind(null, "a=b")), 
        e.deepEqual(r.parse("a=b"), {
            a: "b"
        }), e.doesNotThrow(r.parse.bind(null, "a[][b]=c")), e.deepEqual(r.parse("a[][b]=c"), {
            a: [ {
                b: "c"
            } ]
        }), delete Object.prototype.crash, delete Array.prototype.crash, e.end();
    }), a.test("parses a string with an alternative string delimiter", function(e) {
        e.deepEqual(r.parse("a=b;c=d", {
            delimiter: ";"
        }), {
            a: "b",
            c: "d"
        }), e.end();
    }), a.test("parses a string with an alternative RegExp delimiter", function(e) {
        e.deepEqual(r.parse("a=b; c=d", {
            delimiter: /[;,] */
        }), {
            a: "b",
            c: "d"
        }), e.end();
    }), a.test("does not use non-splittable objects as delimiters", function(e) {
        e.deepEqual(r.parse("a=b&c=d", {
            delimiter: !0
        }), {
            a: "b",
            c: "d"
        }), e.end();
    }), a.test("allows overriding parameter limit", function(e) {
        e.deepEqual(r.parse("a=b&c=d", {
            parameterLimit: 1
        }), {
            a: "b"
        }), e.end();
    }), a.test("allows setting the parameter limit to Infinity", function(e) {
        e.deepEqual(r.parse("a=b&c=d", {
            parameterLimit: 1 / 0
        }), {
            a: "b",
            c: "d"
        }), e.end();
    }), a.test("allows overriding array limit", function(e) {
        e.deepEqual(r.parse("a[0]=b", {
            arrayLimit: -1
        }), {
            a: {
                0: "b"
            }
        }), e.deepEqual(r.parse("a[-1]=b", {
            arrayLimit: -1
        }), {
            a: {
                "-1": "b"
            }
        }), e.deepEqual(r.parse("a[0]=b&a[1]=c", {
            arrayLimit: 0
        }), {
            a: {
                0: "b",
                1: "c"
            }
        }), e.end();
    }), a.test("allows disabling array parsing", function(e) {
        var a = r.parse("a[0]=b&a[1]=c", {
            parseArrays: !1
        });
        e.deepEqual(a, {
            a: {
                0: "b",
                1: "c"
            }
        }), e.equal(Array.isArray(a.a), !1, "parseArrays:false, indices case is not an array");
        var t = r.parse("a[]=b", {
            parseArrays: !1
        });
        e.deepEqual(t, {
            a: {
                0: "b"
            }
        }), e.equal(Array.isArray(t.a), !1, "parseArrays:false, empty brackets case is not an array"), 
        e.end();
    }), a.test("allows for query string prefix", function(e) {
        e.deepEqual(r.parse("?foo=bar", {
            ignoreQueryPrefix: !0
        }), {
            foo: "bar"
        }), e.deepEqual(r.parse("foo=bar", {
            ignoreQueryPrefix: !0
        }), {
            foo: "bar"
        }), e.deepEqual(r.parse("?foo=bar", {
            ignoreQueryPrefix: !1
        }), {
            "?foo": "bar"
        }), e.end();
    }), a.test("parses an object", function(e) {
        var a = {
            "user[name]": {
                "pop[bob]": 3
            },
            "user[email]": null
        }, t = {
            user: {
                name: {
                    "pop[bob]": 3
                },
                email: null
            }
        }, o = r.parse(a);
        e.deepEqual(o, t), e.end();
    }), a.test("parses string with comma as array divider", function(e) {
        e.deepEqual(r.parse("foo=bar,tee", {
            comma: !0
        }), {
            foo: [ "bar", "tee" ]
        }), e.deepEqual(r.parse("foo[bar]=coffee,tee", {
            comma: !0
        }), {
            foo: {
                bar: [ "coffee", "tee" ]
            }
        }), e.deepEqual(r.parse("foo=", {
            comma: !0
        }), {
            foo: ""
        }), e.deepEqual(r.parse("foo", {
            comma: !0
        }), {
            foo: ""
        }), e.deepEqual(r.parse("foo", {
            comma: !0,
            strictNullHandling: !0
        }), {
            foo: null
        }), e.end();
    }), a.test("parses values with comma as array divider", function(e) {
        e.deepEqual(r.parse({
            foo: "bar,tee"
        }, {
            comma: !1
        }), {
            foo: "bar,tee"
        }), e.deepEqual(r.parse({
            foo: "bar,tee"
        }, {
            comma: !0
        }), {
            foo: [ "bar", "tee" ]
        }), e.end();
    }), a.test("use number decoder, parses string that has one number with comma option enabled", function(e) {
        var a = function(e, a, r, t) {
            return isNaN(Number(e)) ? a(e, a, r, t) : parseFloat(e);
        };
        e.deepEqual(r.parse("foo=1", {
            comma: !0,
            decoder: a
        }), {
            foo: 1
        }), e.deepEqual(r.parse("foo=0", {
            comma: !0,
            decoder: a
        }), {
            foo: 0
        }), e.end();
    }), a.test("parses brackets holds array of arrays when having two parts of strings with comma as array divider", function(e) {
        e.deepEqual(r.parse("foo[]=1,2,3&foo[]=4,5,6", {
            comma: !0
        }), {
            foo: [ [ "1", "2", "3" ], [ "4", "5", "6" ] ]
        }), e.deepEqual(r.parse("foo[]=1,2,3&foo[]=", {
            comma: !0
        }), {
            foo: [ [ "1", "2", "3" ], "" ]
        }), e.deepEqual(r.parse("foo[]=1,2,3&foo[]=,", {
            comma: !0
        }), {
            foo: [ [ "1", "2", "3" ], [ "", "" ] ]
        }), e.deepEqual(r.parse("foo[]=1,2,3&foo[]=a", {
            comma: !0
        }), {
            foo: [ [ "1", "2", "3" ], "a" ]
        }), e.end();
    }), a.test("parses comma delimited array while having percent-encoded comma treated as normal text", function(e) {
        e.deepEqual(r.parse("foo=a%2Cb", {
            comma: !0
        }), {
            foo: "a,b"
        }), e.deepEqual(r.parse("foo=a%2C%20b,d", {
            comma: !0
        }), {
            foo: [ "a, b", "d" ]
        }), e.deepEqual(r.parse("foo=a%2C%20b,c%2C%20d", {
            comma: !0
        }), {
            foo: [ "a, b", "c, d" ]
        }), e.end();
    }), a.test("parses an object in dot notation", function(e) {
        var a = {
            "user.name": {
                "pop[bob]": 3
            },
            "user.email.": null
        }, t = {
            user: {
                name: {
                    "pop[bob]": 3
                },
                email: null
            }
        }, o = r.parse(a, {
            allowDots: !0
        });
        e.deepEqual(o, t), e.end();
    }), a.test("parses an object and not child values", function(e) {
        var a = {
            "user[name]": {
                "pop[bob]": {
                    test: 3
                }
            },
            "user[email]": null
        }, t = {
            user: {
                name: {
                    "pop[bob]": {
                        test: 3
                    }
                },
                email: null
            }
        }, o = r.parse(a);
        e.deepEqual(o, t), e.end();
    }), a.test("does not blow up when Buffer global is missing", function(e) {
        var a = global.Buffer;
        delete global.Buffer;
        var t = r.parse("a=b&c=d");
        global.Buffer = a, e.deepEqual(t, {
            a: "b",
            c: "d"
        }), e.end();
    }), a.test("does not crash when parsing circular references", function(e) {
        var a = {};
        a.b = a;
        var t;
        e.doesNotThrow(function() {
            t = r.parse({
                "foo[bar]": "baz",
                "foo[baz]": a
            });
        }), e.equal("foo" in t, !0, 'parsed has "foo" property'), e.equal("bar" in t.foo, !0), 
        e.equal("baz" in t.foo, !0), e.equal(t.foo.bar, "baz"), e.deepEqual(t.foo.baz, a), 
        e.end();
    }), a.test("does not crash when parsing deep objects", function(e) {
        for (var a, t = "foo", o = 0; o < 5e3; o++) t += "[p]";
        t += "=bar", e.doesNotThrow(function() {
            a = r.parse(t, {
                depth: 5e3
            });
        }), e.equal("foo" in a, !0, 'parsed has "foo" property');
        for (var s = 0, n = a.foo; n = n.p; ) s += 1;
        e.equal(s, 5e3, "parsed is 5000 properties deep"), e.end();
    }), a.test("parses null objects correctly", {
        skip: !Object.create
    }, function(e) {
        var a = Object.create(null);
        a.b = "c", e.deepEqual(r.parse(a), {
            b: "c"
        });
        var t = r.parse({
            a: a
        });
        e.equal("a" in t, !0, 'result has "a" property'), e.deepEqual(t.a, a), e.end();
    }), a.test("parses dates correctly", function(e) {
        var a = new Date();
        e.deepEqual(r.parse({
            a: a
        }), {
            a: a
        }), e.end();
    }), a.test("parses regular expressions correctly", function(e) {
        var a = /^test$/;
        e.deepEqual(r.parse({
            a: a
        }), {
            a: a
        }), e.end();
    }), a.test("does not allow overwriting prototype properties", function(e) {
        e.deepEqual(r.parse("a[hasOwnProperty]=b", {
            allowPrototypes: !1
        }), {}), e.deepEqual(r.parse("hasOwnProperty=b", {
            allowPrototypes: !1
        }), {}), e.deepEqual(r.parse("toString", {
            allowPrototypes: !1
        }), {}, 'bare "toString" results in {}'), e.end();
    }), a.test("can allow overwriting prototype properties", function(e) {
        e.deepEqual(r.parse("a[hasOwnProperty]=b", {
            allowPrototypes: !0
        }), {
            a: {
                hasOwnProperty: "b"
            }
        }), e.deepEqual(r.parse("hasOwnProperty=b", {
            allowPrototypes: !0
        }), {
            hasOwnProperty: "b"
        }), e.deepEqual(r.parse("toString", {
            allowPrototypes: !0
        }), {
            toString: ""
        }, 'bare "toString" results in { toString: "" }'), e.end();
    }), a.test("params starting with a closing bracket", function(e) {
        e.deepEqual(r.parse("]=toString"), {
            "]": "toString"
        }), e.deepEqual(r.parse("]]=toString"), {
            "]]": "toString"
        }), e.deepEqual(r.parse("]hello]=toString"), {
            "]hello]": "toString"
        }), e.end();
    }), a.test("params starting with a starting bracket", function(e) {
        e.deepEqual(r.parse("[=toString"), {
            "[": "toString"
        }), e.deepEqual(r.parse("[[=toString"), {
            "[[": "toString"
        }), e.deepEqual(r.parse("[hello[=toString"), {
            "[hello[": "toString"
        }), e.end();
    }), a.test("add keys to objects", function(e) {
        e.deepEqual(r.parse("a[b]=c&a=d"), {
            a: {
                b: "c",
                d: !0
            }
        }, "can add keys to objects"), e.deepEqual(r.parse("a[b]=c&a=toString"), {
            a: {
                b: "c"
            }
        }, "can not overwrite prototype"), e.deepEqual(r.parse("a[b]=c&a=toString", {
            allowPrototypes: !0
        }), {
            a: {
                b: "c",
                toString: !0
            }
        }, "can overwrite prototype with allowPrototypes true"), e.deepEqual(r.parse("a[b]=c&a=toString", {
            plainObjects: !0
        }), {
            __proto__: null,
            a: {
                __proto__: null,
                b: "c",
                toString: !0
            }
        }, "can overwrite prototype with plainObjects true"), e.end();
    }), a.test("can return null objects", {
        skip: !Object.create
    }, function(e) {
        var a = Object.create(null);
        a.a = Object.create(null), a.a.b = "c", a.a.hasOwnProperty = "d", e.deepEqual(r.parse("a[b]=c&a[hasOwnProperty]=d", {
            plainObjects: !0
        }), a), e.deepEqual(r.parse(null, {
            plainObjects: !0
        }), Object.create(null));
        var t = Object.create(null);
        t.a = Object.create(null), t.a[0] = "b", t.a.c = "d", e.deepEqual(r.parse("a[]=b&a[c]=d", {
            plainObjects: !0
        }), t), e.end();
    }), a.test("can parse with custom encoding", function(e) {
        e.deepEqual(r.parse("%8c%a7=%91%e5%8d%e3%95%7b", {
            decoder: function(e) {
                for (var a = /%([0-9A-F]{2})/gi, r = [], t = a.exec(e); t; ) r.push(parseInt(t[1], 16)), 
                t = a.exec(e);
                return String(o.decode(s.from(r), "shift_jis"));
            }
        }), {
            "県": "大阪府"
        }), e.end();
    }), a.test("receives the default decoder as a second argument", function(e) {
        e.plan(1), r.parse("a", {
            decoder: function(a, r) {
                e.equal(r, t.decode);
            }
        }), e.end();
    }), a.test("throws error with wrong decoder", function(e) {
        e.throws(function() {
            r.parse({}, {
                decoder: "string"
            });
        }, new TypeError("Decoder has to be a function.")), e.end();
    }), a.test("does not mutate the options argument", function(e) {
        var a = {};
        r.parse("a[b]=true", a), e.deepEqual(a, {}), e.end();
    }), a.test("throws if an invalid charset is specified", function(e) {
        e.throws(function() {
            r.parse("a=b", {
                charset: "foobar"
            });
        }, new TypeError("The charset option must be either utf-8, iso-8859-1, or undefined")), 
        e.end();
    }), a.test("parses an iso-8859-1 string if asked to", function(e) {
        e.deepEqual(r.parse("%A2=%BD", {
            charset: "iso-8859-1"
        }), {
            "¢": "½"
        }), e.end();
    });
    a.test("prefers an utf-8 charset specified by the utf8 sentinel to a default charset of iso-8859-1", function(e) {
        e.deepEqual(r.parse("utf8=%E2%9C%93&%C3%B8=%C3%B8", {
            charsetSentinel: !0,
            charset: "iso-8859-1"
        }), {
            "ø": "ø"
        }), e.end();
    }), a.test("prefers an iso-8859-1 charset specified by the utf8 sentinel to a default charset of utf-8", function(e) {
        e.deepEqual(r.parse("utf8=%26%2310003%3B&%C3%B8=%C3%B8", {
            charsetSentinel: !0,
            charset: "utf-8"
        }), {
            "Ã¸": "Ã¸"
        }), e.end();
    }), a.test("does not require the utf8 sentinel to be defined before the parameters whose decoding it affects", function(e) {
        e.deepEqual(r.parse("a=%C3%B8&utf8=%26%2310003%3B", {
            charsetSentinel: !0,
            charset: "utf-8"
        }), {
            a: "Ã¸"
        }), e.end();
    }), a.test("should ignore an utf8 sentinel with an unknown value", function(e) {
        e.deepEqual(r.parse("utf8=foo&%C3%B8=%C3%B8", {
            charsetSentinel: !0,
            charset: "utf-8"
        }), {
            "ø": "ø"
        }), e.end();
    }), a.test("uses the utf8 sentinel to switch to utf-8 when no default charset is given", function(e) {
        e.deepEqual(r.parse("utf8=%E2%9C%93&%C3%B8=%C3%B8", {
            charsetSentinel: !0
        }), {
            "ø": "ø"
        }), e.end();
    }), a.test("uses the utf8 sentinel to switch to iso-8859-1 when no default charset is given", function(e) {
        e.deepEqual(r.parse("utf8=%26%2310003%3B&%C3%B8=%C3%B8", {
            charsetSentinel: !0
        }), {
            "Ã¸": "Ã¸"
        }), e.end();
    }), a.test("interprets numeric entities in iso-8859-1 when `interpretNumericEntities`", function(e) {
        e.deepEqual(r.parse("foo=%26%239786%3B", {
            charset: "iso-8859-1",
            interpretNumericEntities: !0
        }), {
            foo: "☺"
        }), e.end();
    }), a.test("handles a custom decoder returning `null`, in the `iso-8859-1` charset, when `interpretNumericEntities`", function(e) {
        e.deepEqual(r.parse("foo=&bar=%26%239786%3B", {
            charset: "iso-8859-1",
            decoder: function(e, a, r) {
                return e ? a(e, a, r) : null;
            },
            interpretNumericEntities: !0
        }), {
            foo: null,
            bar: "☺"
        }), e.end();
    }), a.test("does not interpret numeric entities in iso-8859-1 when `interpretNumericEntities` is absent", function(e) {
        e.deepEqual(r.parse("foo=%26%239786%3B", {
            charset: "iso-8859-1"
        }), {
            foo: "&#9786;"
        }), e.end();
    }), a.test("does not interpret numeric entities when the charset is utf-8, even when `interpretNumericEntities`", function(e) {
        e.deepEqual(r.parse("foo=%26%239786%3B", {
            charset: "utf-8",
            interpretNumericEntities: !0
        }), {
            foo: "&#9786;"
        }), e.end();
    }), a.test("does not interpret %uXXXX syntax in iso-8859-1 mode", function(e) {
        e.deepEqual(r.parse("%u263A=%u263A", {
            charset: "iso-8859-1"
        }), {
            "%u263A": "%u263A"
        }), e.end();
    }), a.test("allows for decoding keys and values differently", function(e) {
        e.deepEqual(r.parse("KeY=vAlUe", {
            decoder: function(e, a, r, t) {
                if ("key" === t) return a(e, a, r, t).toLowerCase();
                if ("value" === t) return a(e, a, r, t).toUpperCase();
                throw "this should never happen! type: " + t;
            }
        }), {
            key: "VALUE"
        }), e.end();
    }), a.end();
});