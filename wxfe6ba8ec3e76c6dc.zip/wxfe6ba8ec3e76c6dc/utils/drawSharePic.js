function e(e, t, n, a) {
    e.beginPath(), e.arc(t, n, a, 0, 2 * Math.PI), e.setLineWidth(1), e.setStrokeStyle("rgba(245, 245, 245, 1)"), 
    e.stroke(), e.closePath(), e.save(), e.clip();
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.roundRect = e, exports.drawSharePic = function(a, o, i) {
    var r = o.cover, s = o.title, c = wx.createCanvasContext(a);
    c.draw(), t(r).then(function(t) {
        var o = t.tempFilePath;
        c.save(), c.drawImage(o, 0, 0, 500, 400), c.restore(), s && (c.setFillStyle("rgba(245, 245, 245, 1)"), 
        c.setShadow(0, 2, 4, "rgba(0, 0, 0, 0.5)"), c.font = "normal bold 26px PingFang SC", 
        c.setTextAlign("center"), c.fillText("" + s, 200, 47)), e(c, 200, 200, 110), c.restore(), 
        c.drawImage(n, 180, 180, 40, 40), c.restore(), c.draw(!0, function() {
            setTimeout(function() {
                wx.canvasToTempFilePath({
                    x: 0,
                    y: 0,
                    width: 400,
                    height: 320,
                    canvasId: a,
                    success: function(e) {
                        console.log("==share pic====", e), "function" == typeof i && i(e.tempFilePath);
                    },
                    fail: function(e) {
                        console.log("==fail fail====", e);
                    }
                });
            }, 300);
        });
    });
};

var t = function(e) {
    return new Promise(function(t, n) {
        wx.downloadFile({
            url: e,
            success: function(e) {
                t(e);
            },
            fail: function(e) {
                n(e);
            }
        });
    });
}, n = "/images/play.png";