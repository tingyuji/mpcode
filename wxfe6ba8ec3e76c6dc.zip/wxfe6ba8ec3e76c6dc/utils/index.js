function e() {
    wx.canIUse("setPageInfo") && wx.setPageInfo({
        title: c,
        keywords: u,
        description: f
    });
}

function t(e, r, o) {
    if (null == e) return "";
    var a = "", i = void 0 === e ? "undefined" : n(e);
    if ("string" == i || "number" == i || "boolean" == i) a += "&" + r + "=" + (null == o || o ? encodeURIComponent(e) : e); else for (var s in e) {
        var c = null == r ? s : r + (e instanceof Array ? "[" + s + "]" : "." + s);
        a += t(e[s], c, o);
    }
    return a;
}

var n = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
}, r = Object.assign || function(e) {
    for (var t = 1; t < arguments.length; t++) {
        var n = arguments[t];
        for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r]);
    }
    return e;
}, o = require("./xmSign"), a = require("./xmH5Log").H5Log, i = require("./xmH5Const").H5PageMap, s = require("./hostAddress").M_HOST_ADDRESS, c = "助眠音乐_助眠声音_睡眠曲_催眠钢琴曲在线听-喜马助眠解压", u = "助眠音乐,助眠钢琴曲,催眠音乐,催眠故事,睡眠曲,催眠曲,助眠音", f = "喜马拉雅提供优质催眠歌曲、助眠钢琴曲、睡眠音等。海量助眠音乐帮你克服焦虑、改善睡眠。";

module.exports = {
    debounce: function(e) {
        var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1e3, n = null;
        return function() {
            var r = this, o = arguments;
            clearTimeout(n), n = setTimeout(function() {
                e.apply(r, o);
            }, t);
        };
    },
    realEmptyRichText: function(e) {
        var t = e;
        return t = t.replace(/(<|>|\/|span|br|p)/g, "");
    },
    setPageInfo: function(t) {
        var n = t.typeName, o = t.uri, a = t.releaseDate, i = void 0 === a ? "" : a, l = t.image, p = void 0 === l ? "" : l, x = t.redirect, g = t.isStaticTDK;
        if (void 0 !== g && g) e(); else {
            var d = 0 == x ? {
                redirect: !1
            } : {};
            wx.request({
                url: s + "/revision/seo/getTdk",
                data: r({
                    typeName: n,
                    uri: o,
                    tdkType: "wap"
                }, d),
                success: function(e) {
                    if (!e.data || e.data && 200 != e.data.ret) wx.canIUse("setPageInfo") && wx.setPageInfo({
                        title: c,
                        keywords: u,
                        description: f,
                        image: p,
                        releaseDate: i
                    }); else {
                        var t = e.data.data.tdkMeta, n = t.title, r = t.keywords, o = t.description;
                        wx.canIUse("setPageInfo") && wx.setPageInfo({
                            title: n,
                            keywords: r,
                            description: o,
                            releaseDate: i,
                            image: p,
                            success: function() {
                                console.log("页面基础信息设置完成");
                            }
                        });
                    }
                },
                fail: function(e) {
                    console.log("getTdk error", e), wx.canIUse("setPageInfo") && wx.setPageInfo({
                        title: c,
                        keywords: u,
                        description: f,
                        image: p,
                        releaseDate: i
                    });
                }
            });
        }
    },
    imagev2: function(e) {
        var t = e;
        return /^^\/\/s1.xmcdn.com/.test(t) ? "https:" + t : /^http\:/.test(t) ? t.replace("http", "https") : /^https\:\/\/fdfs.xmcdn.com/.test(t) ? t : (/^\/\//.test(t) && (t = "https:" + t), 
        /^http/.test(t) || (t = "https://imagev2.xmcdn.com/" + t), /.(png|jpe?g)$/.test(t) && (t += "!strip=1&quality=7&op_type=5&upload_type=cover&name=web_large&device_type=ios"), 
        t);
    },
    xmSign: o,
    getUrl: function(e, n) {
        var r = t(e);
        return r ? n + "?" + r.slice(1) : n;
    },
    H5Log: a,
    H5PageMap: i,
    oneOfScene: function(e) {
        return (0x3d72a1d483a38 == e || 10810008 == e) && 10810014 != e;
    },
    getNetworkType: function() {
        return new Promise(function(e) {
            wx.canIUse("getNetworkType") ? wx.getNetworkType({
                success: function(t) {
                    e(t.networkType);
                },
                fail: function(t) {
                    e();
                }
            }) : e({
                networkType: "wifi"
            });
        });
    },
    getCookieId: function(e) {
        var t = "";
        try {
            var n = wx.getStorageSync("cookies") || {};
            n[e] && (t = (n[e].value || "").split("&")[0]);
        } catch (e) {}
        return t;
    },
    groupArr: function(e, t) {
        for (var n = 0, r = []; n < e.length; ) r.push(e.slice(n, n += t));
        return r;
    },
    generateUUID: function() {
        var e = new Date().getTime();
        return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(t) {
            var n = (e + 16 * Math.random()) % 16 | 0;
            return e = Math.floor(e / 16), ("x" == t ? n : 7 & n | 8).toString(16);
        });
    }
};