var e = require("./hostAddress"), r = function(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}(require("./xmRequest"));

module.exports = function() {
    var t = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
    return new Promise(function(n) {
        (0, r.default)({
            url: e.WEB_HOST_ADDRESS + "/revision/main/getCurrentUser"
        }).then(function(e) {
            var r = e.ret, u = e.data;
            n(200 != r && 0 != r ? null : t ? u : u.uid);
        }).catch(function(e) {
            n(null), console.log("getCurrentUser调用失败", e);
        });
    });
};