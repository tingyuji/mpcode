function e(e, t, a) {
    var n = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 2, i = 0, l = 0, o = !1;
    e.split("").forEach(function(e, r) {
        (i += t.measureText(e).width) < a * n - 50 * n ? l = Math.min(15, r) : o = !0;
    });
    for (var r = [], f = 0; f < e.length; f += 15) r.push(e.substring(f, Math.min(f + 15, e.length)));
    return r;
}

function t(e, t, a, n, i, l) {
    e.beginPath(), e.setFillStyle("rgba(150,156,229,0.40)"), e.arc(t + l, a + l, l, Math.PI, 1.5 * Math.PI), 
    e.moveTo(t + l, a), e.lineTo(t + n - l, a), e.lineTo(t + n, a + l), e.arc(t + n - l, a + l, l, 1.5 * Math.PI, 2 * Math.PI), 
    e.lineTo(t + n, a + i - l), e.lineTo(t + n - l, a + i), e.arc(t + n - l, a + i - l, l, 0, .5 * Math.PI), 
    e.lineTo(t + l, a + i), e.lineTo(t, a + i - l), e.arc(t + l, a + i - l, l, .5 * Math.PI, Math.PI), 
    e.lineTo(t, a + l), e.lineTo(t + l, a), e.fill(), e.closePath(), e.clip();
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.drawHealSharePic = function(l, o, r) {
    var f = new Date(), s = f.getMonth() + 1, c = (0, a.fillZero)(f.getDate()), h = (0, 
    a.fillZero)(f.getHours()), u = (0, a.fillZero)(f.getMinutes()), g = wx.createCanvasContext(l);
    g.draw(), g.save(), g.drawImage(n, 0, 0, 750, 1080), g.restore(), g.font = "normal 26px SourceHanSerifCN", 
    g.setFillStyle("#ffffff"), g.fillText(s + "/" + c + " " + h + ":" + u, 92, 340), 
    g.font = "normal 36px PingFangSC";
    var p = e(o, g, 650);
    p.forEach(function(e, t) {
        g.fillText(e, 92, 426 + 28 * t * 2);
    }), g.drawImage(i, 632, 268, 114, 112), g.draw(!0), g.save();
    var T = 74 * p.length;
    t(g, 29, 277, 681, Math.max(T + 120, 424), 52), g.draw(!0, function() {
        setTimeout(function() {
            wx.canvasToTempFilePath({
                x: 0,
                y: 0,
                width: 750,
                height: 1080,
                fileType: "jpg",
                quality: .7,
                canvasId: l,
                success: function(e) {
                    console.log("==heal share pic====", e), "function" == typeof r && r(e.tempFilePath);
                },
                fail: function(e) {
                    console.log("==fail fail====", e);
                }
            });
        }, 300);
    });
};

var a = require("./number"), n = "/images/heal_bg.png", i = "/images/star.png";