Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.fillZero = function(e) {
    return e < 10 ? "0" + e : e;
};