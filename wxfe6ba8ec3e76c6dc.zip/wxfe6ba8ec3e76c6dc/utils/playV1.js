var a = Object.assign || function(a) {
    for (var r = 1; r < arguments.length; r++) {
        var s = arguments[r];
        for (var i in s) Object.prototype.hasOwnProperty.call(s, i) && (a[i] = s[i]);
    }
    return a;
}, r = require("./hostAddress"), s = require("./xmRequest"), i = r.M_HOST_ADDRESS + "/revision/play/v1/show", t = r.M_HOST_ADDRESS + "/revision/play/v1/tracks", c = r.M_HOST_ADDRESS + "/revision/play/v1/audio", u = r.M_HOST_ADDRESS + "/revision/play/baiduMusic", e = {
    track: function(r) {
        var t = r.data, c = r.success, u = r.fail, e = void 0 === u ? function() {} : u;
        return s({
            url: i,
            data: a({
                ptype: 1
            }, t),
            success: c,
            fail: e
        });
    },
    album: function(r) {
        var t = r.data, c = r.success, u = r.fail, e = void 0 === u ? function() {} : u;
        return s({
            url: i,
            data: a({
                ptype: 0
            }, t),
            success: c,
            fail: e
        });
    },
    tracks: function(a) {
        var r = a.data, i = a.success, c = a.fail, u = void 0 === c ? function() {} : c, e = r.trackIds;
        return Array.isArray(e) && (e = e.join(",")), s({
            url: t,
            data: {
                idsStr: e
            },
            success: i,
            fail: u
        });
    },
    baiduMusic: function(a) {
        var r = a.data, i = a.success, t = a.fail, c = void 0 === t ? function() {} : t;
        return s({
            url: u,
            data: {
                trackId: r.trackId
            },
            success: i,
            fail: c
        });
    },
    play: function(a) {
        var r = a.data, i = a.success, t = a.fail;
        return s({
            url: c,
            data: r,
            success: i,
            fail: void 0 === t ? function() {} : t
        });
    }
};

module.exports = e;