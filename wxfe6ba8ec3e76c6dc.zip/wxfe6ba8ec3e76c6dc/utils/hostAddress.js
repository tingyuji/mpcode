var S = "https://m.ximalaya.com";

module.exports = {
    SCHEMA_ADDRESS: S,
    WEB_HOST_ADDRESS: S,
    M_HOST_ADDRESS: S,
    MOBILE_HOST_ADDRESS: "https://mobile.ximalaya.com",
    MP_HOST_ADDRESS: "https://mp.ximalaya.com",
    MPAY_HOST_ADDRESS: "https://mpay.ximalaya.com",
    PASSPORT_ADDRESS: "https://passport.ximalaya.com",
    isTest: !1
};