function e(e, r) {
    var n = {};
    for (var t in e) r.indexOf(t) >= 0 || Object.prototype.hasOwnProperty.call(e, t) && (n[t] = e[t]);
    return n;
}

var r = Object.assign || function(e) {
    for (var r = 1; r < arguments.length; r++) {
        var n = arguments[r];
        for (var t in n) Object.prototype.hasOwnProperty.call(n, t) && (e[t] = n[t]);
    }
    return e;
}, n = require("../inner_modules/@xmly/lite-login/lib/index"), t = require("./index").xmSign;

module.exports = function(i) {
    var o = i.url, s = i.data, a = i.success, c = i.headers, u = void 0 === c ? {} : c, l = i.fail, d = void 0 === l ? function() {} : l, f = i.method, h = e(i, [ "url", "data", "success", "headers", "fail", "method" ]), v = r({}, u);
    o.includes("/revision") && (v["xm-sign"] = t());
    return (0, n.request)(r({
        url: o,
        data: s,
        method: f,
        header: v,
        success: a,
        fail: d
    }, h)).then(function(e) {
        var r = e.ret, n = e.msg;
        return r && 0 != r && 200 != r && 401 != r && wx.showToast({
            title: n,
            icon: "none"
        }), e;
    }).catch(function(e) {
        console.log(JSON.stringify(e));
    });
};