var e = {
    explore: "homepage",
    album: "album",
    track: "track",
    trackFeed: "trackFeed",
    anchor: "anchorcurr",
    search: "search",
    searchResult: "searchResult",
    tingmain: "pgcSpecialList",
    ting: "pgcSpecial",
    category: "category",
    topics: "aiSpecial",
    mip: "QA",
    404: "notFound",
    login: "login",
    collection: "collect",
    my: "mine",
    fans: "fans",
    follow: "followedAnchor",
    comment: "commentDetail",
    tingdan: "ugcSpecial",
    settlement: "payment",
    paychannel: "paychannel",
    vipchannel: "vipCategory"
};

module.exports = {
    H5PageMap: e
};