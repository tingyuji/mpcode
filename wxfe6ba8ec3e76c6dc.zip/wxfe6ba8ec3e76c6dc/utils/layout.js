Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getStatusBarHeight = function(e) {
    if (t) return t;
    try {
        var r = e.safeArea, a = e.statusBarHeight;
        if (r) t = r && r.top || a; else {
            var u = wx.getMenuButtonLayout().top;
            t = (void 0 === u ? 50 : u) - 6;
        }
    } catch (e) {
        t = 44;
    }
    return t;
};

var t = 0;