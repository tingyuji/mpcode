var r = require("../inner_modules/md5/md5.js"), e = function(r) {
    return ~~(Math.random() * r);
};

module.exports = function() {
    var n = Date.now();
    return r("ximalaya-001") + "(" + e(100) + ")" + n + "(" + e(100) + ")" + n;
};