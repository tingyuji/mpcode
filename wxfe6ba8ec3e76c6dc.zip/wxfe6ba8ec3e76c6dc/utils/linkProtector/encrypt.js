function r(r) {
    if (!r) return "";
    var t, e, n, o, i, a = [ -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 62, -1, -1, -1, 63, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, -1, -1, -1, -1, -1, -1, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, -1, -1, -1, -1, -1, -1, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, -1, -1, -1, -1, -1 ];
    for (o = (r = r.toString()).length, n = 0, i = ""; n < o; ) {
        do {
            t = a[255 & r.charCodeAt(n++)];
        } while (n < o && -1 == t);
        if (-1 == t) break;
        do {
            e = a[255 & r.charCodeAt(n++)];
        } while (n < o && -1 == e);
        if (-1 == e) break;
        i += String.fromCharCode(t << 2 | (48 & e) >> 4);
        do {
            if (61 == (t = 255 & r.charCodeAt(n++))) return i;
            t = a[t];
        } while (n < o && -1 == t);
        if (-1 == t) break;
        i += String.fromCharCode((15 & e) << 4 | (60 & t) >> 2);
        do {
            if (61 == (e = 255 & r.charCodeAt(n++))) return i;
            e = a[e];
        } while (n < o && -1 == e);
        if (-1 == e) break;
        i += String.fromCharCode((3 & t) << 6 | e);
    }
    return i;
}

function t(r, t) {
    for (var e, n = [], o = 0, i = "", a = 0; 256 > a; a++) n[a] = a;
    for (a = 0; 256 > a; a++) o = (o + n[a] + r.charCodeAt(a % r.length)) % 256, e = n[a], 
    n[a] = n[o], n[o] = e;
    for (var h = o = a = 0; h < t.length; h++) o = (o + n[a = (a + 1) % 256]) % 256, 
    e = n[a], n[a] = n[o], n[o] = e, i += String.fromCharCode(t.charCodeAt(h) ^ n[(n[a] + n[o]) % 256]);
    return i;
}

function e(r, t) {
    for (var e = [], n = 0; n < r.length; n++) {
        for (var o = "a" <= r[n] && "z" >= r[n] ? r[n].charCodeAt() - 97 : r[n].charCodeAt() - "0".charCodeAt() + 26, i = 0; 36 > i; i++) if (t[i] == o) {
            o = i;
            break;
        }
        e[n] = 25 < o ? String.fromCharCode(o - 26 + "0".charCodeAt()) : String.fromCharCode(o + 97);
    }
    return e.join("");
}

function n(r) {
    this._randomSeed = r, this.cg_hun();
}

var o = function() {
    function r(r, t) {
        var e = [], n = !0, o = !1, i = void 0;
        try {
            for (var a, h = r[Symbol.iterator](); !(n = (a = h.next()).done) && (e.push(a.value), 
            !t || e.length !== t); n = !0) ;
        } catch (r) {
            o = !0, i = r;
        } finally {
            try {
                !n && h.return && h.return();
            } finally {
                if (o) throw i;
            }
        }
        return e;
    }
    return function(t, e) {
        if (Array.isArray(t)) return t;
        if (Symbol.iterator in Object(t)) return r(t, e);
        throw new TypeError("Invalid attempt to destructure non-iterable instance");
    };
}();

n.prototype = {
    cg_hun: function() {
        this._cgStr = "";
        var r = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ/\\:._-1234567890", t = r.length, e = 0;
        for (e = 0; e < t; e++) {
            var n = this.ran() * r.length, o = parseInt(n);
            this._cgStr += r.charAt(o), r = r.split(r.charAt(o)).join("");
        }
    },
    cg_fun: function(r) {
        var r = r.split("*"), t = "", e = 0;
        for (e = 0; e < r.length - 1; e++) t += this._cgStr.charAt(r[e]);
        return t;
    },
    ran: function() {
        return this._randomSeed = (211 * this._randomSeed + 30031) % 65536, this._randomSeed / 65536;
    },
    cg_decode: function(r) {
        var t = "", e = 0;
        for (e = 0; e < r.length; e++) {
            var n = r.charAt(e), o = this._cgStr.indexOf(n);
            -1 !== o && (t += o + "*");
        }
        return t;
    }
};

var i = t("xm", "Ä[ÜJ=Û3Áf÷N"), a = [ 19, 1, 4, 7, 30, 14, 28, 8, 24, 17, 6, 35, 34, 16, 9, 10, 13, 22, 32, 29, 31, 21, 18, 3, 2, 23, 25, 27, 11, 20, 5, 15, 12, 0, 33, 26 ];

module.exports = {
    getEncryptedFileName: function(r, t) {
        var e = new n(r).cg_fun(t);
        return "/" === e[0] ? e : "/" + e;
    },
    getEncryptedFileParams: function(n) {
        var h = t(e("d" + i + "9", a), r(n)).split("-"), f = o(h, 4), c = f[0];
        return {
            sign: f[1],
            buy_key: c,
            token: f[2],
            timestamp: f[3]
        };
    }
};