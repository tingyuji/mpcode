function e(e, n) {
    if (!(e instanceof n)) throw new TypeError("Cannot call a class as a function");
}

var n = function() {
    function e(e, n) {
        for (var r = 0; r < n.length; r++) {
            var t = n[r];
            t.enumerable = t.enumerable || !1, t.configurable = !0, "value" in t && (t.writable = !0), 
            Object.defineProperty(e, t.key, t);
        }
    }
    return function(n, r, t) {
        return r && e(n.prototype, r), t && e(n, t), n;
    };
}(), r = require("../../inner_modules/@xmly/lite-login/lib/index"), t = require("./encrypt"), o = t.getEncryptedFileName, i = t.getEncryptedFileParams, a = require("../hostAddress").MPAY_HOST_ADDRESS + "/mobile/track/pay/{soundId}", u = function() {
    function t() {
        e(this, t);
    }
    return n(t, [ {
        key: "stringfy",
        value: function(e) {
            var n = [];
            for (var r in e) if (e.hasOwnProperty(r)) {
                var t = encodeURIComponent(e[r]), o = encodeURIComponent(r);
                n.push(o + "=" + t);
            }
            return n.join("&");
        }
    }, {
        key: "queryPayTrack",
        value: function(e) {
            var n = this;
            return new Promise(function(t, u) {
                var c = a.replace("{soundId}", e);
                (0, r.request)({
                    url: c,
                    method: "GET",
                    dataType: "json",
                    header: {},
                    data: {
                        device: "pc",
                        isBackend: !1,
                        _: Date.now()
                    }
                }).then(function(e) {
                    if (0 !== e.ret) return u(e);
                    var r = e.seed, a = e.fileId, c = e.ep, d = e.duration, s = e.domain, l = e.apiVersion, f = o(r, a), p = i(c);
                    p.duration = d;
                    var y = s + "/download/" + l + f + "?" + n.stringfy(p);
                    t(y);
                }).catch(function(e) {
                    u(e);
                });
            });
        }
    } ]), t;
}();

module.exports = u;