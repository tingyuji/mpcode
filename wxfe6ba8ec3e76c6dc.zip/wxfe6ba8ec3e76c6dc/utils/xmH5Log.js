var e = Object.assign || function(e) {
    for (var r = 1; r < arguments.length; r++) {
        var n = arguments[r];
        for (var o in n) Object.prototype.hasOwnProperty.call(n, o) && (e[o] = n[o]);
    }
    return e;
}, r = require("../inner_modules/@xmly/xlog-xmlite/dist/index"), n = require("./wxCookie");

module.exports = {
    H5Log: function(o, i) {
        var t = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {}, l = getApp().globalData.scene, a = e({}, t, {
            sceneId: l,
            miniProgramType: "weixin",
            appName: "Weixin",
            userId: "",
            miniUrl: "pages/explore/explore",
            openId: (0, n.getWXOpenId)() || ""
        });
        console.log("可视化埋点", o, i, a), (0, r.event)(o, i, a);
    }
};