Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.setWXOpenId = exports.getEncrytedData = exports.getWXOpenId = void 0;

var e = require("./hostAddress"), t = function(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}(require("./xmRequest")), n = e.isTest ? "wxopenid_wxfe6ba8ec3e76c6dc_4" : "wxopenid_wxfe6ba8ec3e76c6dc_1", o = (exports.getWXOpenId = function() {
    return wx.getStorageSync(n);
}, exports.getEncrytedData = function(e) {
    wx.login({
        success: function(t) {
            t.code ? wx.getUserInfo({
                success: function(n) {
                    var o = n.encryptedData, r = n.iv;
                    e && "function" == typeof e && e({
                        encryptedData: o,
                        iv: r,
                        code: t.code
                    });
                }
            }) : console.log("登录失败！" + t.errMsg);
        }
    });
});

exports.setWXOpenId = function() {
    o(function(o) {
        (0, t.default)({
            url: e.PASSPORT_ADDRESS + "/thirdparty-h5/v1/applet/115/decrypt",
            data: o,
            method: "POST"
        }).then(function(e) {
            var t = e.data, o = JSON.parse(t).openId;
            wx.setStorageSync(n, o);
        });
    });
};