function t(t) {
    var s = !0, n = !1;
    wx.getSetting({
        withSubscriptions: !0,
        success: function(i) {
            if (i && i.subscriptionsSetting && i.subscriptionsSetting.mainSwitch ? i.subscriptionsSetting.itemSettings && (s = !1, 
            "accept" === i.subscriptionsSetting.itemSettings[e] && (n = !0), i.subscriptionsSetting.itemSettings[e]) : s = !1, 
            "function" == typeof t) {
                var c = "";
                !s && n && (c = "accept"), s && !n && (c = "query"), s || n || (c = "reject"), t(c);
            }
        }
    });
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.wxSubscribeReminder = function(t) {
    wx.requestSubscribeMessage({
        tmplIds: [ e ],
        success: function(s) {
            var n = s.errMsg, i = s[e];
            console.log("errMsg:", n), console.log("tempIdRet:", i), "function" == typeof t && t(i);
        },
        fail: function() {},
        complete: function() {}
    });
}, exports.queryWxSubStatus = t, exports.addSubCount = function() {
    t(function(t) {
        "accept" === t && addAlbumPushCount().then(function(t) {
            t && t.today_count < 10 && (console.log("订阅数+1"), wxSubscribeAlbum());
        });
    });
};

var e = "AVqhVtd6xjz_9CHWUw764QYjbsulCh40EzU9QxcBhds";