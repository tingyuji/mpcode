function t(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

var a = Object.assign || function(t) {
    for (var a = 1; a < arguments.length; a++) {
        var e = arguments[a];
        for (var i in e) Object.prototype.hasOwnProperty.call(e, i) && (t[i] = e[i]);
    }
    return t;
}, e = t(require("../../utils/index")), i = t(require("../../utils/xmRequest")), r = require("../../utils/drawSharePic"), n = require("../../utils/layout"), o = require("../../utils/subscribe"), c = t(require("../../store/index")), s = require("../../utils/hostAddress"), l = s.M_HOST_ADDRESS, u = (s.WEB_HOST_ADDRESS, 
require("../../utils/playV1")), d = wx.getBackgroundAudioManager(), h = getApp(), g = [ "不开启", "10分钟后", "20分钟后", "30分钟后", "60分钟后" ], p = [ {
    id: 6,
    title: "助眠",
    tabIcon: "iconzhumian"
}, {
    id: 3,
    title: "解压",
    tabIcon: "iconshuya"
}, {
    id: 2,
    title: "冥想",
    tabIcon: "iconmingxiang"
}, {
    id: 1,
    title: "专注",
    tabIcon: "icondanao"
} ], f = {
    PLAYING: "playing",
    PAUSED: "pause",
    STOPPED: "stop"
}, S = {
    zm: {
        currPage: "sleepy"
    }
}.zm.currPage;

Page(c.default.createPage({
    globalData: [ "playerData", "platform", "imgAddress", "reminderModalVisible" ],
    watch: {
        playerData: function(t) {}
    },
    shareAppImageUrl: "http://fdfs.xmcdn.com/storages/20a7-audiofreehighqps/9E/90/CMCoOScDiS1JAABG0gBnvoXK.jpg",
    pageNum: 1,
    pageSize: 16,
    hasMore: !0,
    timer: null,
    timerStack: [],
    data: {
        screenHeight: 500,
        scrollTop: 0,
        lastTrack: {
            playBgPic: "https://fdfs.xmcdn.com/group66/M00/4C/1F/wKgMa11jokOiwNJhAAEt1qkni5w233.jpg"
        },
        curTrack: {
            playBgPic: "https://fdfs.xmcdn.com/group66/M00/4C/1F/wKgMa11jokOiwNJhAAEt1qkni5w233.jpg"
        },
        playState: f.STOPPED,
        isUnfold: !0,
        activeTabIndex: 0,
        tabs: p,
        list: [],
        timerList: g,
        showTimeModal: !1,
        activeRadioIndex: 0,
        countDownTime: 0,
        options: [ {
            id: "001",
            name: "北京"
        }, {
            id: "002",
            name: "上海"
        }, {
            id: "003",
            name: "深圳"
        } ]
    },
    refreshPage: function() {
        this.onLoad();
    },
    onLoad: function() {
        var t = this, i = this.options, r = i.trackId, o = i.topicId;
        this.setData({
            isIphoneX: h.globalData.isIphoneX,
            statusBarHeight: (0, n.getStatusBarHeight)(h.globalData.systemInfo) || 20
        }), wx.showLoading({
            title: "正在加载...",
            mask: !1
        }), e.default.getNetworkType().then(function(a) {
            "none" != a ? o && r ? (t.init(o), t.initCurrentTrack(o, r)) : t.init() : t.setData("noNetwork", !0);
        });
        var s = this;
        d.onEnded(function(t) {
            console.log("onEnded==", t);
            var a = s.data.playerData.currentTrack;
            d.title = a.title, d.src = a.src, d.play();
        }), d.onStop(function(t) {
            s.setData({
                playState: f.STOPPED
            }), c.default.dispatch("playerData", {
                currentTrack: null,
                playState: f.STOPPED
            });
        }), d.onPause(function(t) {
            s.log_play(f.PAUSED), s.setData({
                playState: f.PAUSED
            }), c.default.dispatch("playerData", a({}, s.data.playerData, {
                playState: f.PAUSED
            }));
        }), d.onPlay(function() {
            console.log("onPlay---"), s.log_play(f.PLAYING), s.setData({
                playState: f.PLAYING
            }), c.default.dispatch("playerData", a({}, s.data.playerData, {
                playState: f.PLAYING
            }));
        });
    },
    onHide: function() {
        e.default.H5Log(26504, "pageExit", {
            currPage: S
        });
    },
    onShow: function() {
        e.default.H5Log(26503, "pageview", {
            currPage: S
        });
        var t = this.data.playerData, a = t.playState, i = t.currentTrack;
        this.setData({
            playState: a
        });
        var r = this.getStorage(), n = i && i.trackId == r.id ? r.v : this.data.countDownTime;
        this.setData({
            countDownTime: n,
            activeRadioIndex: r.r
        }), this.clearTimers(), this.beginCount(r.r, !1);
    },
    onReady: function() {
        wx.hideLoading();
    },
    initCurrentTrack: function(t, r) {
        var n = this;
        (0, i.default)({
            url: l + "/revision/sleep/topic/trackInfo",
            data: {
                topicId: t,
                trackId: r
            }
        }).then(function(t) {
            if (200 === t.ret) {
                var i = (t.data || {}).topicId, r = e.default.imagev2(t.data.cover), o = p.findIndex(function(t) {
                    return t.id == i;
                });
                n.setData({
                    curTrack: a({}, t.data, {
                        cover: r
                    }),
                    activeTabIndex: o > -1 ? o : 0
                }), n.setShareImg({
                    cover: r,
                    title: t.data.customTitle
                });
            }
        });
    },
    init: function(t) {
        var a = this.data.tabs, e = wx.getSystemInfoSync();
        e instanceof Error ? console.log("getSystemInfoSync fail", e.message) : (console.log("getSystemInfoSync success", e), 
        this.setData({
            screenHeight: e.screenHeight
        })), this.querySoundOfThemes(t || a[0].id, !0);
    },
    querySoundOfThemes: function(t, a) {
        var r = this;
        (0, i.default)({
            url: l + "/revision/sleep/topic/tracks",
            data: {
                topicId: t,
                page: this.pageNum,
                pageSize: this.pageSize
            }
        }).then(function(t) {
            var i = r.options.topicId, n = r.data, o = n.list, c = n.curTrack, s = t.data || {}, l = s.tracks, u = void 0 === l ? [] : l, d = s.totalSize, h = s.currentPage, g = s.pageSize;
            if (a) {
                var p = u.findIndex(function(t) {
                    return 207667442 === t.trackId;
                });
                if (p > -1) {
                    var f = u.splice(p, 1);
                    u.unshift(f[0]);
                }
            }
            var S = a ? u : o.concat(u);
            S.forEach(function(t) {
                return t.cover = e.default.imagev2(t.cover);
            }), i || c && c.cover || (r.setData({
                curTrack: S[0]
            }), r.setShareImg({
                cover: S[0].cover,
                title: S[0].customTitle
            })), r.setData({
                list: S
            }), r.hasMore = h * g < d, e.default.setPageInfo({
                typeName: "EXPLORE",
                uri: "/",
                image: r.data.curTrack.cover,
                isStaticTDK: !0
            });
        });
    },
    toggleFold: function() {
        this.setData({
            isUnfold: !this.data.isUnfold
        });
    },
    hideFold: function() {
        this.data.isUnfold && this.setData({
            isUnfold: !1
        });
    },
    changeTab: function(t) {
        var a = this, e = t.currentTarget.dataset.index;
        if (void 0 != e && null != e) {
            var i = this.data.tabs;
            this.setData({
                activeTabIndex: e,
                scrollTop: 0
            }, function() {
                return a.log_click_tab();
            }), this.pageNum = 1, this.querySoundOfThemes(i[e].id, !0);
        }
    },
    onScrollDown: function() {
        if (this.hasMore) {
            var t = this.data, a = t.tabs[t.activeTabIndex].id;
            this.pageNum++, this.querySoundOfThemes(a);
        }
    },
    initAudio: function(t) {
        var e = this;
        u.play({
            data: {
                ptype: 1,
                id: t.trackId
            }
        }).then(function(i) {
            var r = i.data;
            console.log("_track", r), e.setData({
                playState: f.PLAYING
            }), c.default.dispatch("playerData", {
                playState: f.STOPPED
            }), setTimeout(function() {
                c.default.dispatch("playerData", {
                    playState: f.PLAYING,
                    currentTrack: a({}, r, {
                        title: t.customTitle,
                        coverPath: t.cover
                    })
                });
            }, 0);
        });
    },
    onPlay: function() {
        this.subscribeAddCount();
        var t = this.data.playState;
        if (t === f.PLAYING) this.setData({
            playState: f.PAUSED
        }), c.default.dispatch("playerData", a({}, this.data.playerData, {
            playState: f.PAUSED
        })); else if (t === f.PAUSED) this.setData({
            playState: f.PLAYING
        }), c.default.dispatch("playerData", a({}, this.data.playerData, {
            playState: f.PLAYING
        })); else {
            var e = this.data.curTrack;
            this.setData({
                playState: f.PLAYING
            }), this.initAudio(e);
        }
    },
    onTrackClick: function(t) {
        var a = this;
        this.subscribeAddCount();
        var e = this.data.playState, i = this.data.curTrack, r = t.currentTarget.dataset.track;
        e === f.PLAYING && r.trackId === i.trackId || (this.setData({
            curTrack: r,
            lastTrack: i,
            changeImg: !0
        }), this.setShareImg({
            cover: r.cover,
            title: r.customTitle
        }), setTimeout(function() {
            return a.setData({
                changeImg: !1
            });
        }, 500), this.initAudio(r), this.log_click_track());
    },
    showModal: function() {
        this.setData({
            showTimeModal: !0
        }), this.log_click_close();
    },
    closeModal: function() {
        this.setData({
            showTimeModal: !1
        });
    },
    changeRadio: function(t) {
        var a = t.currentTarget.dataset.index;
        this.data.activeRadioIndex != a && void 0 != a && null != a && (this.log_click_radio(g[a]), 
        this.setData({
            activeRadioIndex: a
        }), this.beginCount(a, !0));
    },
    beginCount: function(t, a) {
        var e = this.data.countDownTime, i = 0;
        switch (t) {
          case 0:
            clearInterval(this.timer), this.setData({
                countDownTime: 0
            }), this.setStorage(0);
            break;

          case 1:
            i = a ? 600 : e, this.countDown(i);
            break;

          case 2:
            i = a ? 1200 : e, this.countDown(i);
            break;

          case 3:
            i = a ? 1800 : e, this.countDown(i);
            break;

          case 4:
            i = a ? 3600 : e, this.countDown(i);
        }
    },
    countDown: function(t) {
        var e = this;
        clearInterval(this.timer);
        var i = parseInt(t);
        this.timer = setInterval(function() {
            i -= 1, e.setData({
                countDownTime: i
            }), e.setStorage(i), i <= 0 && (e.clearTimers(), e.setData({
                countDownTime: 0,
                activeRadioIndex: 0,
                playState: f.STOPPED
            }), e.setStorage(0), c.default.dispatch("playerData", a({}, e.data.playerData, {
                playState: f.STOPPED
            })), d.pause());
        }, 1e3), this.timerStack.push(this.timer);
    },
    clearTimers: function() {
        clearInterval(this.timer), this.timerStack.forEach(function(t) {
            clearInterval(t);
        }), this.timerStack = [];
    },
    showReminderModal: function() {
        e.default.H5Log(27774, "click", {
            currPage: S
        }), c.default.dispatch("reminderModalVisible", !0);
    },
    log_play: function(t) {
        e.default.H5Log(26505, "click", {
            currPage: S,
            item: t === f.PLAYING ? "播放" : "暂停"
        });
    },
    log_click_close: function() {
        e.default.H5Log(26508, "click", {
            currPage: S
        });
    },
    log_click_radio: function(t) {
        e.default.H5Log(26509, "click", {
            currPage: S,
            item: t
        });
    },
    log_click_track: function() {
        var t = this.data.activeTabIndex;
        e.default.H5Log(26507, "click", {
            currPage: S,
            item: p[t].title
        });
    },
    log_click_tab: function() {
        var t = this.data.activeTabIndex;
        e.default.H5Log(26506, "click", {
            currPage: S,
            item: p[t].title
        });
    },
    log_click_share: function() {
        e.default.H5Log(27773, "click", {
            currPage: S
        });
    },
    onShareAppMessage: function() {
        return this.shareAppMessage;
    },
    setShareImg: function(t) {
        var e = this, i = this.data.curTrack;
        console.log("===setShareInfo===", i), this.shareAppMessage = {
            title: "送你专业氛围音，助你入眠、解压、冥想、专注~",
            path: "/pages/explore/explore?trackId=" + i.trackId + "&topicId=" + i.topicId
        }, (0, r.drawSharePic)("explore-share", a({}, t), function(t) {
            e.shareAppMessage.imageUrl = t, console.log("path", t);
        });
    },
    subscribeAddCount: function() {
        (0, o.queryWxSubStatus)(function(t) {
            "accept" === t && (0, o.wxSubscribeReminder)();
        });
    },
    setStorage: function(t) {
        var a = this.data, e = a.curTrack, i = a.activeRadioIndex;
        wx.setStorageSync("timer", {
            id: e.trackId,
            v: t,
            r: i
        });
    },
    getStorage: function() {
        return wx.getStorageSync("timer");
    }
}));