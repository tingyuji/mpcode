Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.queryHeaderBarSettings = void 0;

var e = function(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}(require("../utils/xmRequest")), r = require("../utils/hostAddress");

exports.queryHeaderBarSettings = function() {
    return (0, e.default)({
        url: r.M_HOST_ADDRESS + "/web-config/api/jc/queryAllData?app=web&group=wechat&key=CarouselBar"
    }).then(function(e) {
        var r = (e || {}).data;
        return void 0 === r ? [] : r;
    });
};