Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.updateSubsribeSetting = exports.addSubscribeSetting = exports.querySubsribeSetting = void 0;

var e = function(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}(require("../utils/xmRequest")), t = require("../utils/hostAddress");

require("../utils/subscribe"), exports.querySubsribeSetting = function(r) {
    return (0, e.default)({
        url: t.M_HOST_ADDRESS + "/hamster/wechat/sleepRemainder/get",
        data: {
            openid: r
        }
    }).then(function(e) {
        var t = e || {}, r = t.ret, u = t.data, n = t.msg;
        return 200 === r ? u || {} : (wx.showToast({
            title: n || "",
            icon: "none"
        }), u);
    });
}, exports.addSubscribeSetting = function(r) {
    return (0, e.default)({
        url: t.M_HOST_ADDRESS + "/hamster/wechat/sleepRemainder/add",
        data: r,
        method: "post"
    }).then(function(e) {
        var t = (e || {}).data;
        return void 0 === t ? [] : t;
    });
}, exports.updateSubsribeSetting = function(r) {
    return (0, e.default)({
        url: t.M_HOST_ADDRESS + "/hamster/wechat/sleepRemainder/update",
        data: r,
        method: "post"
    }).then(function(e) {
        var t = (e || {}).data;
        return void 0 === t ? [] : t;
    });
};