function i(i) {
    return i && i.__esModule ? i : {
        default: i
    };
}

var e = i(require("../../utils/index")), t = i(require("../../store/index")), a = require("../../utils/drawHealSharePic");

Component(t.default.createComponent({
    globalData: [ "healModalVisible" ],
    watch: {
        healModalVisible: function(i) {
            var e = i.visible, t = i.content, a = void 0 === t ? "" : t;
            this.setData({
                modalVisible: e,
                content: a
            });
        }
    },
    data: {
        modalVisible: !1,
        content: "",
        settings: {}
    },
    pageLifetimes: {
        show: function() {},
        hide: function() {}
    },
    attached: function() {
        this.init();
    },
    detached: function() {},
    methods: {
        init: function() {},
        save: function() {
            var i = this;
            if (!this.isDrawing) {
                e.default.H5Log(30327, "click", {
                    currPage: "sleepy"
                });
                var o = this.data.content;
                wx.showToast({
                    title: "图片正在保存中……",
                    icon: "none"
                }), this.isDrawing = !0, (0, a.drawHealSharePic)("heal-share", o, function(e) {
                    console.log("heal share path", e), wx.hideToast(), wx.authorize({
                        scope: "scope.writePhotosAlbum",
                        success: function() {
                            wx.saveImageToPhotosAlbum({
                                filePath: e,
                                success: function(i) {
                                    wx.showToast({
                                        title: "已保存到相册",
                                        icon: "none"
                                    });
                                },
                                fail: function(i) {
                                    console.log(i), wx.showToast({
                                        title: "您未开启【微信】访问相册的权限，请在手机设置中开启",
                                        icon: "none"
                                    });
                                },
                                complete: function() {
                                    i.isDrawing = !1, t.default.dispatch("healModalVisible", {
                                        visible: !1
                                    });
                                }
                            });
                        },
                        fail: function() {
                            i.isDrawing = !1, t.default.dispatch("authModalVisible", {
                                visible: !0,
                                type: "album"
                            }), t.default.dispatch("healModalVisible", {
                                visible: !1
                            });
                        }
                    });
                });
            }
        },
        closeModal: function() {
            t.default.dispatch("healModalVisible", {
                visible: !1
            });
        }
    }
}));