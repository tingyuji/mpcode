var t = getApp();

Component({
    properties: {},
    data: {
        imgAddress: t.globalData.imgAddress
    },
    attached: function() {},
    detached: function() {},
    methods: {}
});