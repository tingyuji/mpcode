function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

var t = e(require("../../store/index")), a = e(require("../../utils/index")), i = getApp();

Component(t.default.createComponent({
    globalData: [ "authModalVisible" ],
    watch: {
        authModalVisible: function(e) {
            var t = e.visible, i = e.type;
            t && a.default.H5Log(27776, "slipPage", {
                currPage: "sleepy"
            }), this.setData({
                modalVisible: t,
                type: i
            });
        }
    },
    attached: function() {
        var e = i.globalData.systemInfo, t = (e = void 0 === e ? {} : e).platform;
        this.setData({
            isIos: "ios" === t
        });
    },
    detached: function() {},
    pageLifetimes: {
        show: function() {},
        hide: function() {}
    },
    properties: {},
    data: {
        isIos: !1
    },
    methods: {
        closeModal: function() {
            t.default.dispatch("authModalVisible", {
                visible: !1
            });
        }
    }
}));