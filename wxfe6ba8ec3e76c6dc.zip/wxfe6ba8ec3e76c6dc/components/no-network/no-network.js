var t = getApp();

Component({
    data: {
        imgAddress: t.globalData.imgAddress
    },
    attached: function() {},
    detached: function() {},
    methods: {
        onTap: function(t) {
            this.triggerEvent("refresh");
        }
    }
});