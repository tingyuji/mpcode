var i = function(i) {
    return i && i.__esModule ? i : {
        default: i
    };
}(require("../../store/index")), e = require("../../utils/subscribe");

Component(i.default.createComponent({
    globalData: [ "subscribeTipVisible" ],
    watch: {
        subscribeTipVisible: function(i) {
            var e = i.visible, t = i.isModal;
            this.setData({
                modalVisible: e,
                isModal: t
            });
        }
    },
    attached: function() {},
    detached: function() {},
    pageLifetimes: {
        show: function() {},
        hide: function() {}
    },
    properties: {},
    data: {
        modalVisible: !1,
        isModal: !1
    },
    methods: {
        closeModal: function() {
            i.default.dispatch("subscribeTipVisible", {
                visible: !1,
                isModal: !1
            });
        },
        updateWxSubStatus: function() {
            var t = this;
            (0, e.queryWxSubStatus)(function(s) {
                "reject" === s && i.default.dispatch("authModalVisible", {
                    visible: !0,
                    type: "sub"
                }), "query" === s && (i.default.dispatch("subscribeTipVisible", {
                    visible: !0,
                    isModal: !1
                }), (0, e.wxSubscribeReminder)(function(s) {
                    i.default.dispatch("subscribeTipVisible", {
                        visible: !1,
                        isModal: !1
                    }), "accept" === s && (0, e.queryWxSubStatus)(function(i) {
                        "accept" === i && t.setData({
                            showSubTip: !1
                        });
                    });
                }));
            });
        }
    }
}));