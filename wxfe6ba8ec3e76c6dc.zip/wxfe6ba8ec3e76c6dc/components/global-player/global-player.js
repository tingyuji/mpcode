function a(a) {
    return a && a.__esModule ? a : {
        default: a
    };
}

var t = Object.assign || function(a) {
    for (var t = 1; t < arguments.length; t++) {
        var e = arguments[t];
        for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && (a[r] = e[r]);
    }
    return a;
}, e = a(require("../../store/index")), r = a(require("../../utils/index")), l = a(require("../../utils/playV1")), i = new (require("../../utils/linkProtector/index"))(), c = wx.getBackgroundAudioManager();

c.onPlay(function(a) {
    console.log("gAudio开始播放");
}), c.onError(function(a) {
    console.log("gAudio播放出错", a);
});

var n = {
    PLAYING: "playing",
    PAUSED: "pause",
    STOPPED: "stop"
}, o = null;

Component(e.default.createComponent({
    globalData: [ "playerData", "imgAddress" ],
    watch: {
        playerData: function(a) {
            if (JSON.stringify(o) != JSON.stringify(a)) {
                o = a, wx.setStorageSync("playerData", a);
                var t = a.currentTrack, e = a.playState;
                if (t) switch (e) {
                  case n.STOPPED:
                  case n.PAUSED:
                    c.pause();
                    break;

                  case n.PLAYING:
                    this._play(t);
                }
            } else console.log("val值没有变化。。。。");
        }
    },
    properties: {},
    addGlobalClass: !0,
    data: {
        firstShowModal: !0
    },
    attached: function() {
        var a = this.data.playerData ? this.data.playerData.playState : "";
        a && "playing" == a && c.play();
    },
    detached: function() {},
    pageLifetimes: {
        show: function() {
            var a = this.data.playerData ? this.data.playerData.playState : "";
            a && "playing" == a && c.play();
        },
        hide: function() {}
    },
    methods: {
        _play: function(a) {
            var o = this;
            if (a.src && a.trackId == c.trackId) return console.log("case1111111", c), c.src || (c.title = a.title, 
            c.src = a.src), void c.play();
            if (a.src || i.queryPayTrack(a.trackId).then(function(t) {
                if (t) return c.title = a.title, c.coverImgUrl = r.default.imagev2(a.coverPath), 
                c.src = t, c.trackId = a.trackId, c.albumId = a.albumId, void c.play();
            }).catch(function() {
                var a = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                726 == a.ret ? wx.showToast({
                    icon: "none",
                    title: "小程序暂不支持购买"
                }) : wx.showToast({
                    title: a.msg,
                    icon: "none"
                }), e.default.dispatch("playerData", t({}, o.data.playerData, {
                    playState: n.STOPPED
                }));
            }), a.src && a.trackId != c.trackId) {
                if (console.log("case22222", a), a.isBaiduMusic) return void l.default.baiduMusic({
                    data: {
                        trackId: a.trackId
                    }
                }).then(function(t) {
                    c.title = a.title, c.coverImgUrl = r.default.imagev2(a.coverPath), c.src = t.data.baiduMusicSrc, 
                    c.trackId = a.trackId, c.albumId = a.albumId, c.play();
                });
                c.title = a.title, c.coverImgUrl = r.default.imagev2(a.coverPath), c.src = a.src, 
                c.trackId = a.trackId, c.albumId = a.albumId, c.play();
            }
        },
        goTrack: function(a) {
            var t = this.data.playerData, e = t.currentTrack, r = t.playList, l = t.sort, i = e.albumId, c = e.trackId, n = r.findIndex(function(a) {
                return a.trackId == c;
            }), o = n > -1 ? r[n].albumUrl.split("/")[1] : "", d = "/pages/track/track?albumId=" + i + "&trackId=" + c + "&type=" + o + "&sort=" + l;
            wx.navigateTo({
                url: d
            });
        },
        onPlay: function() {
            e.default.dispatch("playerData", t({}, this.data.playerData, {
                playState: n.PLAYING
            }));
        },
        onPause: function() {
            e.default.dispatch("playerData", t({}, this.data.playerData, {
                playState: n.PAUSED
            }));
        },
        nextTrack: function() {
            var a = this, i = this.data.playerData.playList, c = this.data.playerData.currentTrack, o = i.findIndex(function(a) {
                return a.trackId == c.trackId;
            }), d = {}, s = d = o > -1 && o < i.length - 1 ? i[o + 1] : i[0], u = s.trackName, p = s.albumId, y = s.trackCoverPath;
            console.log("next", d), l.default.play({
                data: {
                    ptype: 1,
                    id: d.trackId
                }
            }).then(function(l) {
                var i = l.data;
                e.default.dispatch("playerData", t({}, a.data.playerData, {
                    currentTrack: t({}, i, {
                        title: u || d.title,
                        albumId: p,
                        coverPath: r.default.imagev2(y || d.cover)
                    }),
                    playState: n.PLAYING
                }));
            });
        }
    }
}));