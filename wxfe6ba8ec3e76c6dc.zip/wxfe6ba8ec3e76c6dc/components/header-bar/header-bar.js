function t(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

var e = require("../../api/headerBar"), a = t(require("../../store/index")), i = require("../../utils/getDataset"), n = t(require("../../utils/index")), o = {
    1: "添加引导",
    2: "反馈入口",
    3: "晚安语"
}, r = getApp();

Component(a.default.createComponent({
    globalData: [ "healModalVisible" ],
    attached: function() {
        this.init();
    },
    detached: function() {},
    pageLifetimes: {
        show: function() {},
        hide: function() {}
    },
    properties: {},
    data: {
        tips: [],
        platform: ""
    },
    methods: {
        init: function() {
            var t = this, a = r.globalData.systemInfo, i = (a = void 0 === a ? {} : a).platform;
            this.setData({
                platform: i
            }), (0, e.queryHeaderBarSettings)().then(function(e) {
                t.setData({
                    tips: e
                });
            });
        },
        openHealModal: function(t) {
            var e = (0, i.getDataset)(t), n = e.type, o = e.content;
            this.log_tap_header(t), n + "" == "3" && a.default.dispatch("healModalVisible", {
                visible: !0,
                content: o
            });
        },
        log_tap_header: function(t) {
            var e = (0, i.getDataset)(t).type;
            n.default.H5Log(27772, "click", {
                currPage: "sleepy",
                type: o[e]
            });
        }
    }
}));