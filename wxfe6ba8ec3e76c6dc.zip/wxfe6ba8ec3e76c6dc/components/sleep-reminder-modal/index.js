function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function t(e, t, i) {
    return t in e ? Object.defineProperty(e, t, {
        value: i,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = i, e;
}

for (var i = Object.assign || function(e) {
    for (var t = 1; t < arguments.length; t++) {
        var i = arguments[t];
        for (var n in i) Object.prototype.hasOwnProperty.call(i, n) && (e[n] = i[n]);
    }
    return e;
}, n = e(require("../../store/index")), s = require("../../utils/getDataset"), a = require("../../api/subscribeApi"), u = require("../../utils/subscribe"), r = require("../../utils/wxCookie"), o = require("../../utils/number"), l = e(require("../../utils/index")), d = [], c = [], f = 0; f < 24; f++) d.push({
    id: (0, o.fillZero)(f) + "",
    name: (0, o.fillZero)(f) + ""
});

for (var h = 0; h < 60; h++) c.push({
    id: (0, o.fillZero)(h) + "",
    name: (0, o.fillZero)(h) + ""
});

var p = [ {
    label: "一",
    value: "1"
}, {
    label: "二",
    value: "2"
}, {
    label: "三",
    value: "3"
}, {
    label: "四",
    value: "4"
}, {
    label: "五",
    value: "5"
}, {
    label: "六",
    value: "6"
}, {
    label: "日",
    value: "0"
} ], b = function(e, t) {
    return i({}, e, {
        isSelected: t.some(function(t) {
            return t === e.value;
        })
    });
}, m = null;

Component(n.default.createComponent({
    globalData: [ "reminderModalVisible" ],
    watch: {
        reminderModalVisible: function(e) {
            m !== e && (m = e, e ? this.init() : this.setData({
                showHours: !1,
                showMinutes: !1
            }), this.setData({
                modalVisible: e
            }));
        }
    },
    data: {
        isOff: !0,
        modalVisible: !1,
        hours: d,
        minutes: c,
        hour: [ 0 ],
        minute: [ 0 ],
        weekdays: p,
        selectedDays: [],
        settings: {},
        defultHourOption: {},
        defaultMinuteOption: {},
        showHours: !1,
        showMinutes: !1,
        showSubTip: !1
    },
    pageLifetimes: {
        show: function() {},
        hide: function() {}
    },
    attached: function() {},
    detached: function() {},
    methods: {
        init: function() {
            var e = this.data;
            e.weekdays, e.selectedDays;
            this.getInitSetting(), this.getInitSubStatus();
        },
        getInitSetting: function() {
            var e = this, t = (0, r.getWXOpenId)();
            (0, a.querySubsribeSetting)(t).then(function(t) {
                var i = t.cycleTime, n = t.remainderTime, a = t.isOpen;
                if ((0, s.isEmpty)(t)) {
                    var u = [ "1", "2", "3", "4", "5" ];
                    e.setData({
                        settings: t,
                        isOff: !0,
                        selectedDays: u,
                        weekdays: p.map(function(e) {
                            return b(e, u);
                        }),
                        defultHourOption: {
                            id: "22",
                            name: "22"
                        },
                        defaultMinuteOption: {
                            id: "00",
                            name: "00"
                        },
                        currentHour: {
                            id: "22",
                            name: "22"
                        },
                        currentMinute: {
                            id: "00",
                            name: "00"
                        },
                        currentIndex: 0
                    });
                } else {
                    var r = n.split(":")[0], o = n.split(":")[1];
                    e.setData({
                        settings: t,
                        isOff: !a,
                        selectedDays: i.split(","),
                        weekdays: p.map(function(e) {
                            return b(e, i.split(","));
                        }),
                        defaultMinuteOption: {
                            id: o,
                            name: o
                        },
                        defultHourOption: {
                            id: r,
                            name: r
                        },
                        currentHour: {
                            id: r,
                            name: r
                        },
                        currentMinute: {
                            id: o,
                            name: o
                        }
                    });
                }
            });
        },
        getInitSubStatus: function() {
            var e = this;
            (0, u.queryWxSubStatus)(function(t) {
                console.log("getInitSubStatus", t), "query" !== t && "reject" !== t || e.setData({
                    showSubTip: !0
                });
            });
        },
        hourChange: function(e) {
            var t = (0, s.getDataset)(e), i = t.id, n = t.name;
            this.onTimeChange("currentHour", {
                id: i,
                name: n
            });
        },
        minuteChange: function(e) {
            var t = (0, s.getDataset)(e), i = t.id, n = t.name;
            this.onTimeChange("currentMinute", {
                id: i,
                name: n
            });
        },
        onTimeChange: function(e, i) {
            var n, s = this;
            this.setData((n = {}, t(n, "" + e, i), t(n, "showHours", !1), t(n, "showMinutes", !1), 
            n), function() {
                s.updateOnTap();
            });
        },
        toggleOptions: function(e) {
            var t = this.data, i = t.currentHour, n = t.currentMinute, a = t.hours, u = t.minutes, r = (0, 
            s.getDataset)(e).type;
            if ("hour" === r) {
                var o = a.findIndex(function(e) {
                    return e.id === i.id;
                });
                this.setData({
                    currentIndex: o,
                    showHours: !this.data.showHours,
                    showMinutes: !1
                });
            }
            if ("minute" === r) {
                var l = u.findIndex(function(e) {
                    return e.id === n.id;
                });
                this.setData({
                    currentIndex: l,
                    showMinutes: !this.data.showMinutes,
                    showHours: !1
                });
            }
            r || this.setData({
                showMinutes: !1,
                showHours: !1
            });
        },
        updateSetting: function(e) {
            var t = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1], n = arguments[2], s = this.data, u = s.selectedDays, o = s.currentHour, l = s.currentMinute, d = {
                openid: (0, r.getWXOpenId)(),
                remainderTime: o.id + ":" + l.id,
                cycleTime: u.toString()
            };
            (t ? a.addSubscribeSetting : a.updateSubsribeSetting)(i({}, d, e)).then(function(e) {
                n && "function" == typeof n && n(e);
            });
        },
        subscribe: function() {
            var e = this, t = this.data, i = t.isOff, a = t.settings;
            l.default.H5Log(27775, "click", {
                item: i ? "开启" : "关闭",
                currPage: "sleepy"
            }), i ? (0, u.queryWxSubStatus)(function(t) {
                "reject" === t ? n.default.dispatch("authModalVisible", {
                    visible: !0,
                    type: "sub"
                }) : ("query" === t && n.default.dispatch("subscribeTipVisible", {
                    visible: !0,
                    isModal: !1
                }), (0, u.wxSubscribeReminder)(function(t) {
                    "accept" === t && e.updateSetting({
                        isOpen: i
                    }, (0, s.isEmpty)(a), function() {
                        e.setData({
                            isOff: !1
                        });
                    }), "reject" === t && (e.updateSetting({
                        isOpen: !1
                    }, (0, s.isEmpty)(a)), e.setData({
                        isOff: !0
                    })), n.default.dispatch("subscribeTipVisible", {
                        visible: !1,
                        isModal: !1
                    }), (0, u.queryWxSubStatus)(function(e) {
                        "query" === e && "accept" === t && n.default.dispatch("subscribeTipVisible", {
                            visible: !0,
                            isModal: !0
                        });
                    });
                }));
            }) : (this.updateSetting({
                isOpen: !1
            }, (0, s.isEmpty)(a)), wx.showToast({
                title: "已关闭提醒",
                icon: "none"
            }), this.setData({
                isOff: !0
            }));
        },
        updateWxSubStatus: function() {
            var e = this;
            (0, u.queryWxSubStatus)(function(t) {
                "reject" === t && n.default.dispatch("authModalVisible", {
                    visible: !0,
                    type: "sub"
                }), "query" === t && (n.default.dispatch("subscribeTipVisible", {
                    visible: !0,
                    isModal: !1
                }), (0, u.wxSubscribeReminder)(function(t) {
                    n.default.dispatch("subscribeTipVisible", {
                        visible: !1,
                        isModal: !1
                    }), "accept" === t && (0, u.queryWxSubStatus)(function(t) {
                        "accept" === t && e.setData({
                            showSubTip: !1
                        });
                    });
                }));
            });
        },
        clickDay: function(e) {
            var t = this, i = (0, s.getDataset)(e).value, n = this.data.selectedDays, a = n.findIndex(function(e) {
                return i === e;
            }), u = n.slice();
            a > -1 ? u.splice(a, 1) : u.push(i), this.setData({
                selectedDays: u,
                weekdays: p.map(function(e) {
                    return b(e, u);
                })
            }, function() {
                t.updateOnTap();
            });
        },
        updateOnTap: function() {
            (0, u.addSubCount)(), this.data.isOff || this.updateSetting({
                isOpen: !0
            }, !1, function() {
                wx.showToast({
                    title: "设置已更新",
                    icon: "none"
                });
            });
        },
        closeModal: function() {
            n.default.dispatch("reminderModalVisible", !1);
        }
    }
}));