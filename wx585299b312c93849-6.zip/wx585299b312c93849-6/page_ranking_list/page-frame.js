     var __subPageFrameStartTime__ = __subPageFrameStartTime__ || Date.now();      var __webviewId__ = __webviewId__;      var __wxAppCode__= __wxAppCode__ || {};      var __WXML_GLOBAL__= __WXML_GLOBAL__ || {entrys:{},defines:{},modules:{},ops:[],wxs_nf_init:undefined,total_ops:0};      var __vd_version_info__=__vd_version_info__||{};      
     /*v0.5vv_20211229_syb_scopedata*/window.__wcc_version__='v0.5vv_20211229_syb_scopedata';window.__wcc_version_info__={"customComponents":true,"fixZeroRpx":true,"propValueDeepCopy":false};
var $gwxc
var $gaic={}
$gwx4=function(path,global){
if(typeof global === 'undefined') global={};if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
$gwx('init', global);
function _(a,b){if(typeof(b)!='undefined')a.children.push(b);}
function _v(k){if(typeof(k)!='undefined')return {tag:'virtual','wxKey':k,children:[]};return {tag:'virtual',children:[]};}
function _n(tag){$gwxc++;if($gwxc>=16000){throw 'Dom limit exceeded, please check if there\'s any mistake you\'ve made.'};return {tag:'wx-'+tag,attr:{},children:[],n:[],raw:{},generics:{}}}
function _p(a,b){b&&a.properities.push(b);}
function _s(scope,env,key){return typeof(scope[key])!='undefined'?scope[key]:env[key]}
function _wp(m){console.warn("WXMLRT_$gwx4:"+m)}
function _wl(tname,prefix){_wp(prefix+':-1:-1:-1: Template `' + tname + '` is being called recursively, will be stop.')}
$gwn=console.warn;
$gwl=console.log;
function $gwh()
{
function x()
{
}
x.prototype = 
{
hn: function( obj, all )
{
if( typeof(obj) == 'object' )
{
var cnt=0;
var any1=false,any2=false;
for(var x in obj)
{
any1=any1|x==='__value__';
any2=any2|x==='__wxspec__';
cnt++;
if(cnt>2)break;
}
return cnt == 2 && any1 && any2 && ( all || obj.__wxspec__ !== 'm' || this.hn(obj.__value__) === 'h' ) ? "h" : "n";
}
return "n";
},
nh: function( obj, special )
{
return { __value__: obj, __wxspec__: special ? special : true }
},
rv: function( obj )
{
return this.hn(obj,true)==='n'?obj:this.rv(obj.__value__);
},
hm: function( obj )
{
if( typeof(obj) == 'object' )
{
var cnt=0;
var any1=false,any2=false;
for(var x in obj)
{
any1=any1|x==='__value__';
any2=any2|x==='__wxspec__';
cnt++;
if(cnt>2)break;
}
return cnt == 2 && any1 && any2 && (obj.__wxspec__ === 'm' || this.hm(obj.__value__) );
}
return false;
}
}
return new x;
}
wh=$gwh();
function $gstack(s){
var tmp=s.split('\n '+' '+' '+' ');
for(var i=0;i<tmp.length;++i){
if(0==i) continue;
if(")"===tmp[i][tmp[i].length-1])
tmp[i]=tmp[i].replace(/\s\(.*\)$/,"");
else
tmp[i]="at anonymous function";
}
return tmp.join('\n '+' '+' '+' ');
}
function $gwrt( should_pass_type_info )
{
function ArithmeticEv( ops, e, s, g, o )
{
var _f = false;
var rop = ops[0][1];
var _a,_b,_c,_d, _aa, _bb;
switch( rop )
{
case '?:':
_a = rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && ( wh.hn(_a) === 'h' );
_d = wh.rv( _a ) ? rev( ops[2], e, s, g, o, _f ) : rev( ops[3], e, s, g, o, _f );
_d = _c && wh.hn( _d ) === 'n' ? wh.nh( _d, 'c' ) : _d;
return _d;
break;
case '&&':
_a = rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && ( wh.hn(_a) === 'h' );
_d = wh.rv( _a ) ? rev( ops[2], e, s, g, o, _f ) : wh.rv( _a );
_d = _c && wh.hn( _d ) === 'n' ? wh.nh( _d, 'c' ) : _d;
return _d;
break;
case '||':
_a = rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && ( wh.hn(_a) === 'h' );
_d = wh.rv( _a ) ? wh.rv(_a) : rev( ops[2], e, s, g, o, _f );
_d = _c && wh.hn( _d ) === 'n' ? wh.nh( _d, 'c' ) : _d;
return _d;
break;
case '+':
case '*':
case '/':
case '%':
case '|':
case '^':
case '&':
case '===':
case '==':
case '!=':
case '!==':
case '>=':
case '<=':
case '>':
case '<':
case '<<':
case '>>':
_a = rev( ops[1], e, s, g, o, _f );
_b = rev( ops[2], e, s, g, o, _f );
_c = should_pass_type_info && (wh.hn( _a ) === 'h' || wh.hn( _b ) === 'h');
switch( rop )
{
case '+':
_d = wh.rv( _a ) + wh.rv( _b );
break;
case '*':
_d = wh.rv( _a ) * wh.rv( _b );
break;
case '/':
_d = wh.rv( _a ) / wh.rv( _b );
break;
case '%':
_d = wh.rv( _a ) % wh.rv( _b );
break;
case '|':
_d = wh.rv( _a ) | wh.rv( _b );
break;
case '^':
_d = wh.rv( _a ) ^ wh.rv( _b );
break;
case '&':
_d = wh.rv( _a ) & wh.rv( _b );
break;
case '===':
_d = wh.rv( _a ) === wh.rv( _b );
break;
case '==':
_d = wh.rv( _a ) == wh.rv( _b );
break;
case '!=':
_d = wh.rv( _a ) != wh.rv( _b );
break;
case '!==':
_d = wh.rv( _a ) !== wh.rv( _b );
break;
case '>=':
_d = wh.rv( _a ) >= wh.rv( _b );
break;
case '<=':
_d = wh.rv( _a ) <= wh.rv( _b );
break;
case '>':
_d = wh.rv( _a ) > wh.rv( _b );
break;
case '<':
_d = wh.rv( _a ) < wh.rv( _b );
break;
case '<<':
_d = wh.rv( _a ) << wh.rv( _b );
break;
case '>>':
_d = wh.rv( _a ) >> wh.rv( _b );
break;
default:
break;
}
return _c ? wh.nh( _d, "c" ) : _d;
break;
case '-':
_a = ops.length === 3 ? rev( ops[1], e, s, g, o, _f ) : 0;
_b = ops.length === 3 ? rev( ops[2], e, s, g, o, _f ) : rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && (wh.hn( _a ) === 'h' || wh.hn( _b ) === 'h');
_d = _c ? wh.rv( _a ) - wh.rv( _b ) : _a - _b;
return _c ? wh.nh( _d, "c" ) : _d;
break;
case '!':
_a = rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && (wh.hn( _a ) == 'h');
_d = !wh.rv(_a);
return _c ? wh.nh( _d, "c" ) : _d;
case '~':
_a = rev( ops[1], e, s, g, o, _f );
_c = should_pass_type_info && (wh.hn( _a ) == 'h');
_d = ~wh.rv(_a);
return _c ? wh.nh( _d, "c" ) : _d;
default:
$gwn('unrecognized op' + rop );
}
}
function rev( ops, e, s, g, o, newap )
{
var op = ops[0];
var _f = false;
if ( typeof newap !== "undefined" ) o.ap = newap;
if( typeof(op)==='object' )
{
var vop=op[0];
var _a, _aa, _b, _bb, _c, _d, _s, _e, _ta, _tb, _td;
switch(vop)
{
case 2:
return ArithmeticEv(ops,e,s,g,o);
break;
case 4: 
return rev( ops[1], e, s, g, o, _f );
break;
case 5: 
switch( ops.length )
{
case 2: 
_a = rev( ops[1],e,s,g,o,_f );
return should_pass_type_info?[_a]:[wh.rv(_a)];
return [_a];
break;
case 1: 
return [];
break;
default:
_a = rev( ops[1],e,s,g,o,_f );
_b = rev( ops[2],e,s,g,o,_f );
_a.push( 
should_pass_type_info ?
_b :
wh.rv( _b )
);
return _a;
break;
}
break;
case 6:
_a = rev(ops[1],e,s,g,o);
var ap = o.ap;
_ta = wh.hn(_a)==='h';
_aa = _ta ? wh.rv(_a) : _a;
o.is_affected |= _ta;
if( should_pass_type_info )
{
if( _aa===null || typeof(_aa) === 'undefined' )
{
return _ta ? wh.nh(undefined, 'e') : undefined;
}
_b = rev(ops[2],e,s,g,o,_f);
_tb = wh.hn(_b) === 'h';
_bb = _tb ? wh.rv(_b) : _b;
o.ap = ap;
o.is_affected |= _tb;
if( _bb===null || typeof(_bb) === 'undefined' || 
_bb === "__proto__" || _bb === "prototype" || _bb === "caller" ) 
{
return (_ta || _tb) ? wh.nh(undefined, 'e') : undefined;
}
_d = _aa[_bb];
if ( typeof _d === 'function' && !ap ) _d = undefined;
_td = wh.hn(_d)==='h';
o.is_affected |= _td;
return (_ta || _tb) ? (_td ? _d : wh.nh(_d, 'e')) : _d;
}
else
{
if( _aa===null || typeof(_aa) === 'undefined' )
{
return undefined;
}
_b = rev(ops[2],e,s,g,o,_f);
_tb = wh.hn(_b) === 'h';
_bb = _tb ? wh.rv(_b) : _b;
o.ap = ap;
o.is_affected |= _tb;
if( _bb===null || typeof(_bb) === 'undefined' || 
_bb === "__proto__" || _bb === "prototype" || _bb === "caller" ) 
{
return undefined;
}
_d = _aa[_bb];
if ( typeof _d === 'function' && !ap ) _d = undefined;
_td = wh.hn(_d)==='h';
o.is_affected |= _td;
return _td ? wh.rv(_d) : _d;
}
case 7: 
switch(ops[1][0])
{
case 11:
o.is_affected |= wh.hn(g)==='h';
return g;
case 3:
_s = wh.rv( s );
_e = wh.rv( e );
_b = ops[1][1];
if (g && g.f && g.f.hasOwnProperty(_b) )
{
_a = g.f;
o.ap = true;
}
else
{
_a = _s && _s.hasOwnProperty(_b) ? 
s : (_e && _e.hasOwnProperty(_b) ? e : undefined );
}
if( should_pass_type_info )
{
if( _a )
{
_ta = wh.hn(_a) === 'h';
_aa = _ta ? wh.rv( _a ) : _a;
_d = _aa[_b];
_td = wh.hn(_d) === 'h';
o.is_affected |= _ta || _td;
_d = _ta && !_td ? wh.nh(_d,'e') : _d;
return _d;
}
}
else
{
if( _a )
{
_ta = wh.hn(_a) === 'h';
_aa = _ta ? wh.rv( _a ) : _a;
_d = _aa[_b];
_td = wh.hn(_d) === 'h';
o.is_affected |= _ta || _td;
return wh.rv(_d);
}
}
return undefined;
}
break;
case 8: 
_a = {};
_a[ops[1]] = rev(ops[2],e,s,g,o,_f);
return _a;
break;
case 9: 
_a = rev(ops[1],e,s,g,o,_f);
_b = rev(ops[2],e,s,g,o,_f);
function merge( _a, _b, _ow )
{
var ka, _bbk;
_ta = wh.hn(_a)==='h';
_tb = wh.hn(_b)==='h';
_aa = wh.rv(_a);
_bb = wh.rv(_b);
for(var k in _bb)
{
if ( _ow || !_aa.hasOwnProperty(k) )
{
_aa[k] = should_pass_type_info ? (_tb ? wh.nh(_bb[k],'e') : _bb[k]) : wh.rv(_bb[k]);
}
}
return _a;
}
var _c = _a
var _ow = true
if ( typeof(ops[1][0]) === "object" && ops[1][0][0] === 10 ) {
_a = _b
_b = _c
_ow = false
}
if ( typeof(ops[1][0]) === "object" && ops[1][0][0] === 10 ) {
var _r = {}
return merge( merge( _r, _a, _ow ), _b, _ow );
}
else
return merge( _a, _b, _ow );
break;
case 10:
_a = rev(ops[1],e,s,g,o,_f);
_a = should_pass_type_info ? _a : wh.rv( _a );
return _a ;
break;
case 12:
var _r;
_a = rev(ops[1],e,s,g,o);
if ( !o.ap )
{
return should_pass_type_info && wh.hn(_a)==='h' ? wh.nh( _r, 'f' ) : _r;
}
var ap = o.ap;
_b = rev(ops[2],e,s,g,o,_f);
o.ap = ap;
_ta = wh.hn(_a)==='h';
_tb = _ca(_b);
_aa = wh.rv(_a);	
_bb = wh.rv(_b); snap_bb=$gdc(_bb,"nv_");
try{
_r = typeof _aa === "function" ? $gdc(_aa.apply(null, snap_bb)) : undefined;
} catch (e){
e.message = e.message.replace(/nv_/g,"");
e.stack = e.stack.substring(0,e.stack.indexOf("\n", e.stack.lastIndexOf("at nv_")));
e.stack = e.stack.replace(/\snv_/g," "); 
e.stack = $gstack(e.stack);	
if(g.debugInfo)
{
e.stack += "\n "+" "+" "+" at "+g.debugInfo[0]+":"+g.debugInfo[1]+":"+g.debugInfo[2];
console.error(e);
}
_r = undefined;
}
return should_pass_type_info && (_tb || _ta) ? wh.nh( _r, 'f' ) : _r;
}
}
else
{
if( op === 3 || op === 1) return ops[1];
else if( op === 11 ) 
{
var _a='';
for( var i = 1 ; i < ops.length ; i++ )
{
var xp = wh.rv(rev(ops[i],e,s,g,o,_f));
_a += typeof(xp) === 'undefined' ? '' : xp;
}
return _a;
}
}
}
function wrapper( ops, e, s, g, o, newap )
{
if( ops[0] == '11182016' )
{
g.debugInfo = ops[2];
return rev( ops[1], e, s, g, o, newap );
}
else
{
g.debugInfo = null;
return rev( ops, e, s, g, o, newap );
}
}
return wrapper;
}
gra=$gwrt(true); 
grb=$gwrt(false); 
function TestTest( expr, ops, e,s,g, expect_a, expect_b, expect_affected )
{
{
var o = {is_affected:false};
var a = gra( ops, e,s,g, o );
if( JSON.stringify(a) != JSON.stringify( expect_a )
|| o.is_affected != expect_affected )
{
console.warn( "A. " + expr + " get result " + JSON.stringify(a) + ", " + o.is_affected + ", but " + JSON.stringify( expect_a ) + ", " + expect_affected + " is expected" );
}
}
{
var o = {is_affected:false};
var a = grb( ops, e,s,g, o );
if( JSON.stringify(a) != JSON.stringify( expect_b )
|| o.is_affected != expect_affected )
{
console.warn( "B. " + expr + " get result " + JSON.stringify(a) + ", " + o.is_affected + ", but " + JSON.stringify( expect_b ) + ", " + expect_affected + " is expected" );
}
}
}

function wfor( to_iter, func, env, _s, global, father, itemname, indexname, keyname )
{
var _n = wh.hn( to_iter ) === 'n'; 
var scope = wh.rv( _s ); 
var has_old_item = scope.hasOwnProperty(itemname);
var has_old_index = scope.hasOwnProperty(indexname);
var old_item = scope[itemname];
var old_index = scope[indexname];
var full = Object.prototype.toString.call(wh.rv(to_iter));
var type = full[8]; 
if( type === 'N' && full[10] === 'l' ) type = 'X'; 
var _y;
if( _n )
{
if( type === 'A' ) 
{
var r_iter_item;
for( var i = 0 ; i < to_iter.length ; i++ )
{
scope[itemname] = to_iter[i];
scope[indexname] = _n ? i : wh.nh(i, 'h');
r_iter_item = wh.rv(to_iter[i]);
var key = keyname && r_iter_item ? (keyname==="*this" ? r_iter_item : wh.rv(r_iter_item[keyname])) : undefined;
_y = _v(key);
_(father,_y);
func( env, scope, _y, global );
}
}
else if( type === 'O' ) 
{
var i = 0;
var r_iter_item;
for( var k in to_iter )
{
scope[itemname] = to_iter[k];
scope[indexname] = _n ? k : wh.nh(k, 'h');
r_iter_item = wh.rv(to_iter[k]);
var key = keyname && r_iter_item ? (keyname==="*this" ? r_iter_item : wh.rv(r_iter_item[keyname])) : undefined;
_y = _v(key);
_(father,_y);
func( env,scope,_y,global );
i++;
}
}
else if( type === 'S' ) 
{
for( var i = 0 ; i < to_iter.length ; i++ )
{
scope[itemname] = to_iter[i];
scope[indexname] = _n ? i : wh.nh(i, 'h');
_y = _v( to_iter[i] + i );
_(father,_y);
func( env,scope,_y,global );
}
}
else if( type === 'N' ) 
{
for( var i = 0 ; i < to_iter ; i++ )
{
scope[itemname] = i;
scope[indexname] = _n ? i : wh.nh(i, 'h');
_y = _v( i );
_(father,_y);
func(env,scope,_y,global);
}
}
else
{
}
}
else
{
var r_to_iter = wh.rv(to_iter);
var r_iter_item, iter_item;
if( type === 'A' ) 
{
for( var i = 0 ; i < r_to_iter.length ; i++ )
{
iter_item = r_to_iter[i];
iter_item = wh.hn(iter_item)==='n' ? wh.nh(iter_item,'h') : iter_item;
r_iter_item = wh.rv( iter_item );
scope[itemname] = iter_item
scope[indexname] = _n ? i : wh.nh(i, 'h');
var key = keyname && r_iter_item ? (keyname==="*this" ? r_iter_item : wh.rv(r_iter_item[keyname])) : undefined;
_y = _v(key);
_(father,_y);
func( env, scope, _y, global );
}
}
else if( type === 'O' ) 
{
var i=0;
for( var k in r_to_iter )
{
iter_item = r_to_iter[k];
iter_item = wh.hn(iter_item)==='n'? wh.nh(iter_item,'h') : iter_item;
r_iter_item = wh.rv( iter_item );
scope[itemname] = iter_item;
scope[indexname] = _n ? k : wh.nh(k, 'h');
var key = keyname && r_iter_item ? (keyname==="*this" ? r_iter_item : wh.rv(r_iter_item[keyname])) : undefined;
_y=_v(key);
_(father,_y);
func( env, scope, _y, global );
i++
}
}
else if( type === 'S' ) 
{
for( var i = 0 ; i < r_to_iter.length ; i++ )
{
iter_item = wh.nh(r_to_iter[i],'h');
scope[itemname] = iter_item;
scope[indexname] = _n ? i : wh.nh(i, 'h');
_y = _v( to_iter[i] + i );
_(father,_y);
func( env, scope, _y, global );
}
}
else if( type === 'N' ) 
{
for( var i = 0 ; i < r_to_iter ; i++ )
{
iter_item = wh.nh(i,'h');
scope[itemname] = iter_item;
scope[indexname]= _n ? i : wh.nh(i,'h');
_y = _v( i );
_(father,_y);
func(env,scope,_y,global);
}
}
else
{
}
}
if(has_old_item)
{
scope[itemname]=old_item;
}
else
{
delete scope[itemname];
}
if(has_old_index)
{
scope[indexname]=old_index;
}
else
{
delete scope[indexname];
}
}

function _ca(o)
{ 
if ( wh.hn(o) == 'h' ) return true;
if ( typeof o !== "object" ) return false;
for(var i in o){ 
if ( o.hasOwnProperty(i) ){
if (_ca(o[i])) return true;
}
}
return false;
}
function _da( node, attrname, opindex, raw, o )
{
var isaffected = false;
var value = $gdc( raw, "", 2 );
if ( o.ap && value && value.constructor===Function ) 
{
attrname = "$wxs:" + attrname; 
node.attr["$gdc"] = $gdc;
}
if ( o.is_affected || _ca(raw) ) 
{
node.n.push( attrname );
node.raw[attrname] = raw;
}
node.attr[attrname] = value;
}
function _r( node, attrname, opindex, env, scope, global ) 
{
global.opindex=opindex;
var o = {}, _env;
var a = grb( z[opindex], env, scope, global, o );
_da( node, attrname, opindex, a, o );
}
function _rz( z, node, attrname, opindex, env, scope, global ) 
{
global.opindex=opindex;
var o = {}, _env;
var a = grb( z[opindex], env, scope, global, o );
_da( node, attrname, opindex, a, o );
}
function _o( opindex, env, scope, global )
{
global.opindex=opindex;
var nothing = {};
var r = grb( z[opindex], env, scope, global, nothing );
return (r&&r.constructor===Function) ? undefined : r;
}
function _oz( z, opindex, env, scope, global )
{
global.opindex=opindex;
var nothing = {};
var r = grb( z[opindex], env, scope, global, nothing );
return (r&&r.constructor===Function) ? undefined : r;
}
function _1( opindex, env, scope, global, o )
{
var o = o || {};
global.opindex=opindex;
return gra( z[opindex], env, scope, global, o );
}
function _1z( z, opindex, env, scope, global, o )
{
var o = o || {};
global.opindex=opindex;
return gra( z[opindex], env, scope, global, o );
}
function _2( opindex, func, env, scope, global, father, itemname, indexname, keyname )
{
var o = {};
var to_iter = _1( opindex, env, scope, global );
wfor( to_iter, func, env, scope, global, father, itemname, indexname, keyname );
}
function _2z( z, opindex, func, env, scope, global, father, itemname, indexname, keyname )
{
var o = {};
var to_iter = _1z( z, opindex, env, scope, global );
wfor( to_iter, func, env, scope, global, father, itemname, indexname, keyname );
}


function _m(tag,attrs,generics,env,scope,global)
{
var tmp=_n(tag);
var base=0;
for(var i = 0 ; i < attrs.length ; i+=2 )
{
if(base+attrs[i+1]<0)
{
tmp.attr[attrs[i]]=true;
}
else
{
_r(tmp,attrs[i],base+attrs[i+1],env,scope,global);
if(base===0)base=attrs[i+1];
}
}
for(var i=0;i<generics.length;i+=2)
{
if(base+generics[i+1]<0)
{
tmp.generics[generics[i]]="";
}
else
{
var $t=grb(z[base+generics[i+1]],env,scope,global);
if ($t!="") $t="wx-"+$t;
tmp.generics[generics[i]]=$t;
if(base===0)base=generics[i+1];
}
}
return tmp;
}
function _mz(z,tag,attrs,generics,env,scope,global)
{
var tmp=_n(tag);
var base=0;
for(var i = 0 ; i < attrs.length ; i+=2 )
{
if(base+attrs[i+1]<0)
{
tmp.attr[attrs[i]]=true;
}
else
{
_rz(z, tmp,attrs[i],base+attrs[i+1],env,scope,global);
if(base===0)base=attrs[i+1];
}
}
for(var i=0;i<generics.length;i+=2)
{
if(base+generics[i+1]<0)
{
tmp.generics[generics[i]]="";
}
else
{
var $t=grb(z[base+generics[i+1]],env,scope,global);
if ($t!="") $t="wx-"+$t;
tmp.generics[generics[i]]=$t;
if(base===0)base=generics[i+1];
}
}
return tmp;
}

var nf_init=function(){
if(typeof __WXML_GLOBAL__==="undefined"||undefined===__WXML_GLOBAL__.wxs_nf_init){
nf_init_Object();nf_init_Function();nf_init_Array();nf_init_String();nf_init_Boolean();nf_init_Number();nf_init_Math();nf_init_Date();nf_init_RegExp();
}
if(typeof __WXML_GLOBAL__!=="undefined") __WXML_GLOBAL__.wxs_nf_init=true;
};
var nf_init_Object=function(){
Object.defineProperty(Object.prototype,"nv_constructor",{writable:true,value:"Object"})
Object.defineProperty(Object.prototype,"nv_toString",{writable:true,value:function(){return "[object Object]"}})
}
var nf_init_Function=function(){
Object.defineProperty(Function.prototype,"nv_constructor",{writable:true,value:"Function"})
Object.defineProperty(Function.prototype,"nv_length",{get:function(){return this.length;},set:function(){}});
Object.defineProperty(Function.prototype,"nv_toString",{writable:true,value:function(){return "[function Function]"}})
}
var nf_init_Array=function(){
Object.defineProperty(Array.prototype,"nv_toString",{writable:true,value:function(){return this.nv_join();}})
Object.defineProperty(Array.prototype,"nv_join",{writable:true,value:function(s){
s=undefined==s?',':s;
var r="";
for(var i=0;i<this.length;++i){
if(0!=i) r+=s;
if(null==this[i]||undefined==this[i]) r+='';	
else if(typeof this[i]=='function') r+=this[i].nv_toString();
else if(typeof this[i]=='object'&&this[i].nv_constructor==="Array") r+=this[i].nv_join();
else r+=this[i].toString();
}
return r;
}})
Object.defineProperty(Array.prototype,"nv_constructor",{writable:true,value:"Array"})
Object.defineProperty(Array.prototype,"nv_concat",{writable:true,value:Array.prototype.concat})
Object.defineProperty(Array.prototype,"nv_pop",{writable:true,value:Array.prototype.pop})
Object.defineProperty(Array.prototype,"nv_push",{writable:true,value:Array.prototype.push})
Object.defineProperty(Array.prototype,"nv_reverse",{writable:true,value:Array.prototype.reverse})
Object.defineProperty(Array.prototype,"nv_shift",{writable:true,value:Array.prototype.shift})
Object.defineProperty(Array.prototype,"nv_slice",{writable:true,value:Array.prototype.slice})
Object.defineProperty(Array.prototype,"nv_sort",{writable:true,value:Array.prototype.sort})
Object.defineProperty(Array.prototype,"nv_splice",{writable:true,value:Array.prototype.splice})
Object.defineProperty(Array.prototype,"nv_unshift",{writable:true,value:Array.prototype.unshift})
Object.defineProperty(Array.prototype,"nv_indexOf",{writable:true,value:Array.prototype.indexOf})
Object.defineProperty(Array.prototype,"nv_lastIndexOf",{writable:true,value:Array.prototype.lastIndexOf})
Object.defineProperty(Array.prototype,"nv_every",{writable:true,value:Array.prototype.every})
Object.defineProperty(Array.prototype,"nv_some",{writable:true,value:Array.prototype.some})
Object.defineProperty(Array.prototype,"nv_forEach",{writable:true,value:Array.prototype.forEach})
Object.defineProperty(Array.prototype,"nv_map",{writable:true,value:Array.prototype.map})
Object.defineProperty(Array.prototype,"nv_filter",{writable:true,value:Array.prototype.filter})
Object.defineProperty(Array.prototype,"nv_reduce",{writable:true,value:Array.prototype.reduce})
Object.defineProperty(Array.prototype,"nv_reduceRight",{writable:true,value:Array.prototype.reduceRight})
Object.defineProperty(Array.prototype,"nv_length",{get:function(){return this.length;},set:function(value){this.length=value;}});
}
var nf_init_String=function(){
Object.defineProperty(String.prototype,"nv_constructor",{writable:true,value:"String"})
Object.defineProperty(String.prototype,"nv_toString",{writable:true,value:String.prototype.toString})
Object.defineProperty(String.prototype,"nv_valueOf",{writable:true,value:String.prototype.valueOf})
Object.defineProperty(String.prototype,"nv_charAt",{writable:true,value:String.prototype.charAt})
Object.defineProperty(String.prototype,"nv_charCodeAt",{writable:true,value:String.prototype.charCodeAt})
Object.defineProperty(String.prototype,"nv_concat",{writable:true,value:String.prototype.concat})
Object.defineProperty(String.prototype,"nv_indexOf",{writable:true,value:String.prototype.indexOf})
Object.defineProperty(String.prototype,"nv_lastIndexOf",{writable:true,value:String.prototype.lastIndexOf})
Object.defineProperty(String.prototype,"nv_localeCompare",{writable:true,value:String.prototype.localeCompare})
Object.defineProperty(String.prototype,"nv_match",{writable:true,value:String.prototype.match})
Object.defineProperty(String.prototype,"nv_replace",{writable:true,value:String.prototype.replace})
Object.defineProperty(String.prototype,"nv_search",{writable:true,value:String.prototype.search})
Object.defineProperty(String.prototype,"nv_slice",{writable:true,value:String.prototype.slice})
Object.defineProperty(String.prototype,"nv_split",{writable:true,value:String.prototype.split})
Object.defineProperty(String.prototype,"nv_substring",{writable:true,value:String.prototype.substring})
Object.defineProperty(String.prototype,"nv_toLowerCase",{writable:true,value:String.prototype.toLowerCase})
Object.defineProperty(String.prototype,"nv_toLocaleLowerCase",{writable:true,value:String.prototype.toLocaleLowerCase})
Object.defineProperty(String.prototype,"nv_toUpperCase",{writable:true,value:String.prototype.toUpperCase})
Object.defineProperty(String.prototype,"nv_toLocaleUpperCase",{writable:true,value:String.prototype.toLocaleUpperCase})
Object.defineProperty(String.prototype,"nv_trim",{writable:true,value:String.prototype.trim})
Object.defineProperty(String.prototype,"nv_length",{get:function(){return this.length;},set:function(value){this.length=value;}});
}
var nf_init_Boolean=function(){
Object.defineProperty(Boolean.prototype,"nv_constructor",{writable:true,value:"Boolean"})
Object.defineProperty(Boolean.prototype,"nv_toString",{writable:true,value:Boolean.prototype.toString})
Object.defineProperty(Boolean.prototype,"nv_valueOf",{writable:true,value:Boolean.prototype.valueOf})
}
var nf_init_Number=function(){
Object.defineProperty(Number,"nv_MAX_VALUE",{writable:false,value:Number.MAX_VALUE})
Object.defineProperty(Number,"nv_MIN_VALUE",{writable:false,value:Number.MIN_VALUE})
Object.defineProperty(Number,"nv_NEGATIVE_INFINITY",{writable:false,value:Number.NEGATIVE_INFINITY})
Object.defineProperty(Number,"nv_POSITIVE_INFINITY",{writable:false,value:Number.POSITIVE_INFINITY})
Object.defineProperty(Number.prototype,"nv_constructor",{writable:true,value:"Number"})
Object.defineProperty(Number.prototype,"nv_toString",{writable:true,value:Number.prototype.toString})
Object.defineProperty(Number.prototype,"nv_toLocaleString",{writable:true,value:Number.prototype.toLocaleString})
Object.defineProperty(Number.prototype,"nv_valueOf",{writable:true,value:Number.prototype.valueOf})
Object.defineProperty(Number.prototype,"nv_toFixed",{writable:true,value:Number.prototype.toFixed})
Object.defineProperty(Number.prototype,"nv_toExponential",{writable:true,value:Number.prototype.toExponential})
Object.defineProperty(Number.prototype,"nv_toPrecision",{writable:true,value:Number.prototype.toPrecision})
}
var nf_init_Math=function(){
Object.defineProperty(Math,"nv_E",{writable:false,value:Math.E})
Object.defineProperty(Math,"nv_LN10",{writable:false,value:Math.LN10})
Object.defineProperty(Math,"nv_LN2",{writable:false,value:Math.LN2})
Object.defineProperty(Math,"nv_LOG2E",{writable:false,value:Math.LOG2E})
Object.defineProperty(Math,"nv_LOG10E",{writable:false,value:Math.LOG10E})
Object.defineProperty(Math,"nv_PI",{writable:false,value:Math.PI})
Object.defineProperty(Math,"nv_SQRT1_2",{writable:false,value:Math.SQRT1_2})
Object.defineProperty(Math,"nv_SQRT2",{writable:false,value:Math.SQRT2})
Object.defineProperty(Math,"nv_abs",{writable:false,value:Math.abs})
Object.defineProperty(Math,"nv_acos",{writable:false,value:Math.acos})
Object.defineProperty(Math,"nv_asin",{writable:false,value:Math.asin})
Object.defineProperty(Math,"nv_atan",{writable:false,value:Math.atan})
Object.defineProperty(Math,"nv_atan2",{writable:false,value:Math.atan2})
Object.defineProperty(Math,"nv_ceil",{writable:false,value:Math.ceil})
Object.defineProperty(Math,"nv_cos",{writable:false,value:Math.cos})
Object.defineProperty(Math,"nv_exp",{writable:false,value:Math.exp})
Object.defineProperty(Math,"nv_floor",{writable:false,value:Math.floor})
Object.defineProperty(Math,"nv_log",{writable:false,value:Math.log})
Object.defineProperty(Math,"nv_max",{writable:false,value:Math.max})
Object.defineProperty(Math,"nv_min",{writable:false,value:Math.min})
Object.defineProperty(Math,"nv_pow",{writable:false,value:Math.pow})
Object.defineProperty(Math,"nv_random",{writable:false,value:Math.random})
Object.defineProperty(Math,"nv_round",{writable:false,value:Math.round})
Object.defineProperty(Math,"nv_sin",{writable:false,value:Math.sin})
Object.defineProperty(Math,"nv_sqrt",{writable:false,value:Math.sqrt})
Object.defineProperty(Math,"nv_tan",{writable:false,value:Math.tan})
}
var nf_init_Date=function(){
Object.defineProperty(Date.prototype,"nv_constructor",{writable:true,value:"Date"})
Object.defineProperty(Date,"nv_parse",{writable:true,value:Date.parse})
Object.defineProperty(Date,"nv_UTC",{writable:true,value:Date.UTC})
Object.defineProperty(Date,"nv_now",{writable:true,value:Date.now})
Object.defineProperty(Date.prototype,"nv_toString",{writable:true,value:Date.prototype.toString})
Object.defineProperty(Date.prototype,"nv_toDateString",{writable:true,value:Date.prototype.toDateString})
Object.defineProperty(Date.prototype,"nv_toTimeString",{writable:true,value:Date.prototype.toTimeString})
Object.defineProperty(Date.prototype,"nv_toLocaleString",{writable:true,value:Date.prototype.toLocaleString})
Object.defineProperty(Date.prototype,"nv_toLocaleDateString",{writable:true,value:Date.prototype.toLocaleDateString})
Object.defineProperty(Date.prototype,"nv_toLocaleTimeString",{writable:true,value:Date.prototype.toLocaleTimeString})
Object.defineProperty(Date.prototype,"nv_valueOf",{writable:true,value:Date.prototype.valueOf})
Object.defineProperty(Date.prototype,"nv_getTime",{writable:true,value:Date.prototype.getTime})
Object.defineProperty(Date.prototype,"nv_getFullYear",{writable:true,value:Date.prototype.getFullYear})
Object.defineProperty(Date.prototype,"nv_getUTCFullYear",{writable:true,value:Date.prototype.getUTCFullYear})
Object.defineProperty(Date.prototype,"nv_getMonth",{writable:true,value:Date.prototype.getMonth})
Object.defineProperty(Date.prototype,"nv_getUTCMonth",{writable:true,value:Date.prototype.getUTCMonth})
Object.defineProperty(Date.prototype,"nv_getDate",{writable:true,value:Date.prototype.getDate})
Object.defineProperty(Date.prototype,"nv_getUTCDate",{writable:true,value:Date.prototype.getUTCDate})
Object.defineProperty(Date.prototype,"nv_getDay",{writable:true,value:Date.prototype.getDay})
Object.defineProperty(Date.prototype,"nv_getUTCDay",{writable:true,value:Date.prototype.getUTCDay})
Object.defineProperty(Date.prototype,"nv_getHours",{writable:true,value:Date.prototype.getHours})
Object.defineProperty(Date.prototype,"nv_getUTCHours",{writable:true,value:Date.prototype.getUTCHours})
Object.defineProperty(Date.prototype,"nv_getMinutes",{writable:true,value:Date.prototype.getMinutes})
Object.defineProperty(Date.prototype,"nv_getUTCMinutes",{writable:true,value:Date.prototype.getUTCMinutes})
Object.defineProperty(Date.prototype,"nv_getSeconds",{writable:true,value:Date.prototype.getSeconds})
Object.defineProperty(Date.prototype,"nv_getUTCSeconds",{writable:true,value:Date.prototype.getUTCSeconds})
Object.defineProperty(Date.prototype,"nv_getMilliseconds",{writable:true,value:Date.prototype.getMilliseconds})
Object.defineProperty(Date.prototype,"nv_getUTCMilliseconds",{writable:true,value:Date.prototype.getUTCMilliseconds})
Object.defineProperty(Date.prototype,"nv_getTimezoneOffset",{writable:true,value:Date.prototype.getTimezoneOffset})
Object.defineProperty(Date.prototype,"nv_setTime",{writable:true,value:Date.prototype.setTime})
Object.defineProperty(Date.prototype,"nv_setMilliseconds",{writable:true,value:Date.prototype.setMilliseconds})
Object.defineProperty(Date.prototype,"nv_setUTCMilliseconds",{writable:true,value:Date.prototype.setUTCMilliseconds})
Object.defineProperty(Date.prototype,"nv_setSeconds",{writable:true,value:Date.prototype.setSeconds})
Object.defineProperty(Date.prototype,"nv_setUTCSeconds",{writable:true,value:Date.prototype.setUTCSeconds})
Object.defineProperty(Date.prototype,"nv_setMinutes",{writable:true,value:Date.prototype.setMinutes})
Object.defineProperty(Date.prototype,"nv_setUTCMinutes",{writable:true,value:Date.prototype.setUTCMinutes})
Object.defineProperty(Date.prototype,"nv_setHours",{writable:true,value:Date.prototype.setHours})
Object.defineProperty(Date.prototype,"nv_setUTCHours",{writable:true,value:Date.prototype.setUTCHours})
Object.defineProperty(Date.prototype,"nv_setDate",{writable:true,value:Date.prototype.setDate})
Object.defineProperty(Date.prototype,"nv_setUTCDate",{writable:true,value:Date.prototype.setUTCDate})
Object.defineProperty(Date.prototype,"nv_setMonth",{writable:true,value:Date.prototype.setMonth})
Object.defineProperty(Date.prototype,"nv_setUTCMonth",{writable:true,value:Date.prototype.setUTCMonth})
Object.defineProperty(Date.prototype,"nv_setFullYear",{writable:true,value:Date.prototype.setFullYear})
Object.defineProperty(Date.prototype,"nv_setUTCFullYear",{writable:true,value:Date.prototype.setUTCFullYear})
Object.defineProperty(Date.prototype,"nv_toUTCString",{writable:true,value:Date.prototype.toUTCString})
Object.defineProperty(Date.prototype,"nv_toISOString",{writable:true,value:Date.prototype.toISOString})
Object.defineProperty(Date.prototype,"nv_toJSON",{writable:true,value:Date.prototype.toJSON})
}
var nf_init_RegExp=function(){
Object.defineProperty(RegExp.prototype,"nv_constructor",{writable:true,value:"RegExp"})
Object.defineProperty(RegExp.prototype,"nv_exec",{writable:true,value:RegExp.prototype.exec})
Object.defineProperty(RegExp.prototype,"nv_test",{writable:true,value:RegExp.prototype.test})
Object.defineProperty(RegExp.prototype,"nv_toString",{writable:true,value:RegExp.prototype.toString})
Object.defineProperty(RegExp.prototype,"nv_source",{get:function(){return this.source;},set:function(){}});
Object.defineProperty(RegExp.prototype,"nv_global",{get:function(){return this.global;},set:function(){}});
Object.defineProperty(RegExp.prototype,"nv_ignoreCase",{get:function(){return this.ignoreCase;},set:function(){}});
Object.defineProperty(RegExp.prototype,"nv_multiline",{get:function(){return this.multiline;},set:function(){}});
Object.defineProperty(RegExp.prototype,"nv_lastIndex",{get:function(){return this.lastIndex;},set:function(v){this.lastIndex=v;}});
}
nf_init();
var nv_getDate=function(){var args=Array.prototype.slice.call(arguments);args.unshift(Date);return new(Function.prototype.bind.apply(Date, args));}
var nv_getRegExp=function(){var args=Array.prototype.slice.call(arguments);args.unshift(RegExp);return new(Function.prototype.bind.apply(RegExp, args));}
var nv_console={}
nv_console.nv_log=function(){var res="WXSRT:";for(var i=0;i<arguments.length;++i)res+=arguments[i]+" ";console.log(res);}
var nv_parseInt = parseInt, nv_parseFloat = parseFloat, nv_isNaN = isNaN, nv_isFinite = isFinite, nv_decodeURI = decodeURI, nv_decodeURIComponent = decodeURIComponent, nv_encodeURI = encodeURI, nv_encodeURIComponent = encodeURIComponent;
function $gdc(o,p,r) {
o=wh.rv(o);
if(o===null||o===undefined) return o;
if(typeof o==="string"||typeof o==="boolean"||typeof o==="number") return o;
if(o.constructor===Object){
var copy={};
for(var k in o)
if(Object.prototype.hasOwnProperty.call(o,k))
if(undefined===p) copy[k.substring(3)]=$gdc(o[k],p,r);
else copy[p+k]=$gdc(o[k],p,r);
return copy;
}
if(o.constructor===Array){
var copy=[];
for(var i=0;i<o.length;i++) copy.push($gdc(o[i],p,r));
return copy;
}
if(o.constructor===Date){
var copy=new Date();
copy.setTime(o.getTime());
return copy;
}
if(o.constructor===RegExp){
var f="";
if(o.global) f+="g";
if(o.ignoreCase) f+="i";
if(o.multiline) f+="m";
return (new RegExp(o.source,f));
}
if(r&&typeof o==="function"){
if ( r == 1 ) return $gdc(o(),undefined, 2);
if ( r == 2 ) return o;
}
return null;
}
var nv_JSON={}
nv_JSON.nv_stringify=function(o){
JSON.stringify(o);
return JSON.stringify($gdc(o));
}
nv_JSON.nv_parse=function(o){
if(o===undefined) return undefined;
var t=JSON.parse(o);
return $gdc(t,'nv_');
}

function _af(p, a, r, c){
p.extraAttr = {"t_action": a, "t_rawid": r };
if ( typeof(c) != 'undefined' ) p.extraAttr.t_cid = c;
}

function _gv( )
{if( typeof( window.__webview_engine_version__) == 'undefined' ) return 0.0;
return window.__webview_engine_version__;}
function _ai(i,p,e,me,r,c){var x=_grp(p,e,me);if(x)i.push(x);else{i.push('');_wp(me+':import:'+r+':'+c+': Path `'+p+'` not found from `'+me+'`.')}}
function _grp(p,e,me){if(p[0]!='/'){var mepart=me.split('/');mepart.pop();var ppart=p.split('/');for(var i=0;i<ppart.length;i++){if( ppart[i]=='..')mepart.pop();else if(!ppart[i]||ppart[i]=='.')continue;else mepart.push(ppart[i]);}p=mepart.join('/');}if(me[0]=='.'&&p[0]=='/')p='.'+p;if(e[p])return p;if(e[p+'.wxml'])return p+'.wxml';}
function _gd(p,c,e,d){if(!c)return;if(d[p][c])return d[p][c];for(var x=e[p].i.length-1;x>=0;x--){if(e[p].i[x]&&d[e[p].i[x]][c])return d[e[p].i[x]][c]};for(var x=e[p].ti.length-1;x>=0;x--){var q=_grp(e[p].ti[x],e,p);if(q&&d[q][c])return d[q][c]}var ii=_gapi(e,p);for(var x=0;x<ii.length;x++){if(ii[x]&&d[ii[x]][c])return d[ii[x]][c]}for(var k=e[p].j.length-1;k>=0;k--)if(e[p].j[k]){for(var q=e[e[p].j[k]].ti.length-1;q>=0;q--){var pp=_grp(e[e[p].j[k]].ti[q],e,p);if(pp&&d[pp][c]){return d[pp][c]}}}}
function _gapi(e,p){if(!p)return [];if($gaic[p]){return $gaic[p]};var ret=[],q=[],h=0,t=0,put={},visited={};q.push(p);visited[p]=true;t++;while(h<t){var a=q[h++];for(var i=0;i<e[a].ic.length;i++){var nd=e[a].ic[i];var np=_grp(nd,e,a);if(np&&!visited[np]){visited[np]=true;q.push(np);t++;}}for(var i=0;a!=p&&i<e[a].ti.length;i++){var ni=e[a].ti[i];var nm=_grp(ni,e,a);if(nm&&!put[nm]){put[nm]=true;ret.push(nm);}}}$gaic[p]=ret;return ret;}
var $ixc={};function _ic(p,ent,me,e,s,r,gg){var x=_grp(p,ent,me);ent[me].j.push(x);if(x){if($ixc[x]){_wp('-1:include:-1:-1: `'+p+'` is being included in a loop, will be stop.');return;}$ixc[x]=true;try{ent[x].f(e,s,r,gg)}catch(e){}$ixc[x]=false;}else{_wp(me+':include:-1:-1: Included path `'+p+'` not found from `'+me+'`.')}}
function _w(tn,f,line,c){_wp(f+':template:'+line+':'+c+': Template `'+tn+'` not found.');}function _ev(dom){var changed=false;delete dom.properities;delete dom.n;if(dom.children){do{changed=false;var newch = [];for(var i=0;i<dom.children.length;i++){var ch=dom.children[i];if( ch.tag=='virtual'){changed=true;for(var j=0;ch.children&&j<ch.children.length;j++){newch.push(ch.children[j]);}}else { newch.push(ch); } } dom.children = newch; }while(changed);for(var i=0;i<dom.children.length;i++){_ev(dom.children[i]);}} return dom; }
function _tsd( root )
{
if( root.tag == "wx-wx-scope" ) 
{
root.tag = "virtual";
root.wxCkey = "11";
root['wxScopeData'] = root.attr['wx:scope-data'];
delete root.n;
delete root.raw;
delete root.generics;
delete root.attr;
}
for( var i = 0 ; root.children && i < root.children.length ; i++ )
{
_tsd( root.children[i] );
}
return root;
}

var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx4 || [];
function gz$gwx4_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx4_1)return __WXML_GLOBAL__.ops_cached.$gwx4_1
__WXML_GLOBAL__.ops_cached.$gwx4_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'dis-flex-mian data-v-a31fafce'])
Z([3,'ranking_list dis-flex-col data-v-a31fafce'])
Z([3,'rankingBg data-v-a31fafce'])
Z([[6],[[7],[3,'image']],[3,'rankingBg']])
Z([3,'topNav data-v-a31fafce'])
Z([3,'__e'])
Z([3,'goBackLogo data-v-a31fafce'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'goHome']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([[6],[[7],[3,'image']],[3,'goBack']])
Z([[2,'+'],[[2,'+'],[1,'margin-top:'],[[2,'+'],[[7],[3,'top']],[1,'px']]],[1,';']])
Z([3,'title dis-flex data-v-a31fafce'])
Z([3,'dis-flex-col data-v-a31fafce'])
Z([[2,'+'],[1,'margin-top:60rpx;align-items:center;'],[[2,'+'],[[2,'+'],[1,'margin-top:'],[[2,'+'],[[7],[3,'top']],[1,'px']]],[1,';']]])
Z(z[5])
Z([3,'tite_btn data-v-a31fafce'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'goRanking']],[[4],[[5],[1,1]]]]]]]]]]])
Z([[2,'+'],[[2,'+'],[1,'font-weight:'],[[2,'?:'],[[2,'=='],[[7],[3,'active']],[1,1]],[1,'bold'],[1,'']]],[1,';']])
Z([3,'挑战周榜'])
Z([3,'active_box data-v-a31fafce'])
Z([[2,'+'],[[2,'+'],[1,'background-color:'],[[2,'?:'],[[2,'=='],[[7],[3,'active']],[1,1]],[1,'#FFF2E6'],[1,'']]],[1,';']])
Z(z[11])
Z(z[12])
Z(z[5])
Z(z[14])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'goRanking']],[[4],[[5],[1,2]]]]]]]]]]])
Z([[2,'+'],[[2,'+'],[1,'font-weight:'],[[2,'?:'],[[2,'=='],[[7],[3,'active']],[1,2]],[1,'bold'],[1,'']]],[1,';']])
Z([3,'挑战总榜'])
Z(z[18])
Z([[2,'+'],[[2,'+'],[1,'background-color:'],[[2,'?:'],[[2,'=='],[[7],[3,'active']],[1,2]],[1,'#FFF2E6'],[1,'']]],[1,';']])
Z([3,'ranking_top dis-flex data-v-a31fafce'])
Z([3,'ranking_top_box2 box data-v-a31fafce'])
Z([[2,'+'],[[2,'+'],[1,'visibility:'],[[2,'?:'],[[2,'=='],[[7],[3,'active']],[1,1]],[[2,'?:'],[[6],[[7],[3,'weekRankList']],[1,1]],[1,'visible '],[1,'hidden']],[[2,'?:'],[[6],[[7],[3,'totalRankList']],[1,1]],[1,'visible '],[1,'hidden']]]],[1,';']])
Z([3,'box_top data-v-a31fafce'])
Z([3,'secondHead data-v-a31fafce'])
Z([3,'secondUser data-v-a31fafce'])
Z([[2,'?:'],[[2,'=='],[[7],[3,'active']],[1,1]],[[2,'+'],[[2,'+'],[1,''],[[7],[3,'baseURl']]],[[6],[[6],[[7],[3,'weekRankList']],[1,1]],[3,'headPic']]],[[2,'+'],[[2,'+'],[1,''],[[7],[3,'baseURl']]],[[6],[[6],[[7],[3,'totalRankList']],[1,1]],[3,'headPic']]]])
Z([3,'secondLogo data-v-a31fafce'])
Z([[6],[[7],[3,'image']],[3,'secondLogo']])
Z([3,'box_bot dis-flex-col data-v-a31fafce'])
Z([3,'data-v-a31fafce'])
Z([a,[[2,'?:'],[[2,'=='],[[7],[3,'active']],[1,1]],[[6],[[6],[[7],[3,'weekRankList']],[1,1]],[3,'nick_name']],[[6],[[6],[[7],[3,'totalRankList']],[1,1]],[3,'nick_name']]]])
Z([3,'rank-info data-v-a31fafce'])
Z([3,'showLogo data-v-a31fafce'])
Z([[6],[[7],[3,'image']],[3,'showLogo']])
Z([3,'showTxt data-v-a31fafce'])
Z([a,[[2,'+'],[[2,'+'],[1,''],[[2,'?:'],[[2,'=='],[[7],[3,'active']],[1,1]],[[2,'?:'],[[6],[[6],[[7],[3,'weekRankList']],[1,1]],[3,'single_score']],[[6],[[6],[[7],[3,'weekRankList']],[1,1]],[3,'single_score']],[1,'']],[[2,'?:'],[[6],[[6],[[7],[3,'totalRankList']],[1,1]],[3,'total_score']],[[6],[[6],[[7],[3,'totalRankList']],[1,1]],[3,'total_score']],[1,'']]]],[1,'']]])
Z([3,'ranking_top_box1 box data-v-a31fafce'])
Z([[2,'+'],[[2,'+'],[1,'visibility:'],[[2,'?:'],[[2,'=='],[[7],[3,'active']],[1,1]],[[2,'?:'],[[6],[[7],[3,'weekRankList']],[1,0]],[1,'visible '],[1,'hidden']],[[2,'?:'],[[6],[[7],[3,'totalRankList']],[1,0]],[1,'visible '],[1,'hidden']]]],[1,';']])
Z(z[32])
Z([3,'firstHead data-v-a31fafce'])
Z([[6],[[7],[3,'image']],[3,'firstHead']])
Z([3,'firstUser data-v-a31fafce'])
Z([[2,'?:'],[[2,'=='],[[7],[3,'active']],[1,1]],[[2,'+'],[[2,'+'],[1,''],[[7],[3,'baseURl']]],[[6],[[6],[[7],[3,'weekRankList']],[1,0]],[3,'headPic']]],[[2,'+'],[[2,'+'],[1,''],[[7],[3,'baseURl']]],[[6],[[6],[[7],[3,'totalRankList']],[1,0]],[3,'headPic']]]])
Z([3,'firstLogo data-v-a31fafce'])
Z([[6],[[7],[3,'image']],[3,'firstLogo']])
Z(z[38])
Z(z[39])
Z([a,[[2,'?:'],[[2,'=='],[[7],[3,'active']],[1,1]],[[6],[[6],[[7],[3,'weekRankList']],[1,0]],[3,'nick_name']],[[6],[[6],[[7],[3,'totalRankList']],[1,0]],[3,'nick_name']]]])
Z(z[41])
Z(z[42])
Z(z[43])
Z(z[44])
Z([a,[[2,'+'],[[2,'+'],[1,''],[[2,'?:'],[[2,'=='],[[7],[3,'active']],[1,1]],[[2,'?:'],[[6],[[6],[[7],[3,'weekRankList']],[1,0]],[3,'single_score']],[[6],[[6],[[7],[3,'weekRankList']],[1,0]],[3,'single_score']],[1,'']],[[2,'?:'],[[6],[[6],[[7],[3,'totalRankList']],[1,0]],[3,'total_score']],[[6],[[6],[[7],[3,'totalRankList']],[1,0]],[3,'total_score']],[1,'']]]],[1,'']]])
Z([3,'ranking_top_box3 box data-v-a31fafce'])
Z([[2,'+'],[[2,'+'],[1,'visibility:'],[[2,'?:'],[[2,'=='],[[7],[3,'active']],[1,1]],[[2,'?:'],[[6],[[7],[3,'weekRankList']],[1,2]],[1,'visible '],[1,'hidden']],[[2,'?:'],[[6],[[7],[3,'totalRankList']],[1,2]],[1,'visible '],[1,'hidden']]]],[1,';']])
Z(z[32])
Z([3,'thirdHead data-v-a31fafce'])
Z([3,'thirdUser data-v-a31fafce'])
Z([[2,'?:'],[[2,'=='],[[7],[3,'active']],[1,1]],[[2,'+'],[[2,'+'],[1,''],[[7],[3,'baseURl']]],[[6],[[6],[[7],[3,'weekRankList']],[1,2]],[3,'headPic']]],[[2,'+'],[[2,'+'],[1,''],[[7],[3,'baseURl']]],[[6],[[6],[[7],[3,'totalRankList']],[1,2]],[3,'headPic']]]])
Z([3,'thirdLogo data-v-a31fafce'])
Z([[6],[[7],[3,'image']],[3,'thirdLogo']])
Z(z[38])
Z(z[39])
Z([a,[[2,'?:'],[[2,'=='],[[7],[3,'active']],[1,1]],[[6],[[6],[[7],[3,'weekRankList']],[1,2]],[3,'nick_name']],[[6],[[6],[[7],[3,'totalRankList']],[1,2]],[3,'nick_name']]]])
Z(z[41])
Z(z[42])
Z(z[43])
Z(z[44])
Z([a,[[2,'+'],[[2,'+'],[1,''],[[2,'?:'],[[2,'=='],[[7],[3,'active']],[1,1]],[[2,'?:'],[[6],[[6],[[7],[3,'weekRankList']],[1,2]],[3,'single_score']],[[6],[[6],[[7],[3,'weekRankList']],[1,2]],[3,'single_score']],[1,'']],[[2,'?:'],[[6],[[6],[[7],[3,'totalRankList']],[1,2]],[3,'total_score']],[[6],[[6],[[7],[3,'totalRankList']],[1,2]],[3,'total_score']],[1,'']]]],[1,'']]])
Z([[2,'=='],[[7],[3,'active']],[1,1]])
Z([3,'ranking_main data-v-a31fafce'])
Z([3,'index'])
Z([3,'item'])
Z([[7],[3,'weekRankList']])
Z(z[81])
Z([[2,'>'],[[7],[3,'index']],[1,2]])
Z([3,'ranking_main_box dis-flex data-v-a31fafce'])
Z([3,'dis-flex ranking_main_box_left data-v-a31fafce'])
Z([[2,'<'],[[7],[3,'index']],[1,5]])
Z([3,'ranking data-v-a31fafce'])
Z([[6],[[7],[3,'image']],[3,'ranking']])
Z([3,'rankingNum data-v-a31fafce'])
Z([[2,'+'],[[2,'+'],[[2,'+'],[1,'color:'],[[2,'?:'],[[2,'<'],[[7],[3,'index']],[1,5]],[1,'#fff'],[1,'#000']]],[1,';']],[[2,'+'],[[2,'+'],[1,'font-weight:'],[[2,'?:'],[[2,'<'],[[7],[3,'index']],[1,5]],[1,''],[1,'bold']]],[1,';']]])
Z([a,[[2,'+'],[[7],[3,'index']],[1,1]]])
Z([3,'rankingUser data-v-a31fafce'])
Z([[2,'+'],[[2,'+'],[1,''],[[7],[3,'baseURl']]],[[6],[[7],[3,'item']],[3,'headPic']]])
Z([3,'rankingName data-v-a31fafce'])
Z([a,[[6],[[7],[3,'item']],[3,'nick_name']]])
Z([3,'ranking_main_box_right dis-flex data-v-a31fafce'])
Z(z[42])
Z(z[43])
Z([3,'position:unset;'])
Z([3,'text_box data-v-a31fafce'])
Z(z[39])
Z([3,'font-weight:bold;padding:0 10rpx;'])
Z([a,[[2,'+'],[[2,'+'],[1,''],[[6],[[7],[3,'item']],[3,'single_score']]],[1,'']]])
Z(z[39])
Z([3,'题'])
Z([[2,'=='],[[7],[3,'active']],[1,2]])
Z(z[80])
Z(z[81])
Z(z[82])
Z([[7],[3,'totalRankList']])
Z(z[81])
Z(z[85])
Z(z[86])
Z(z[87])
Z(z[88])
Z(z[89])
Z(z[90])
Z(z[91])
Z(z[92])
Z([a,z[93][1]])
Z(z[94])
Z(z[95])
Z(z[96])
Z([a,z[97][1]])
Z(z[98])
Z(z[42])
Z(z[43])
Z(z[101])
Z(z[102])
Z(z[39])
Z(z[104])
Z([a,[[2,'+'],[[2,'+'],[1,''],[[6],[[7],[3,'item']],[3,'total_score']]],[1,'']]])
Z(z[39])
Z(z[107])
})(__WXML_GLOBAL__.ops_cached.$gwx4_1);return __WXML_GLOBAL__.ops_cached.$gwx4_1
}
__WXML_GLOBAL__.ops_set.$gwx4=z;
__WXML_GLOBAL__.ops_init.$gwx4=true;
var nv_require=function(){var nnm={};var nom={};return function(n){if(n[0]==='p'&&n[1]==='_'&&f_[n.slice(2)])return f_[n.slice(2)];return function(){if(!nnm[n]) return undefined;try{if(!nom[n])nom[n]=nnm[n]();return nom[n];}catch(e){e.message=e.message.replace(/nv_/g,'');var tmp = e.stack.substring(0,e.stack.lastIndexOf(n));e.stack = tmp.substring(0,tmp.lastIndexOf('\n'));e.stack = e.stack.replace(/\snv_/g,' ');e.stack = $gstack(e.stack);e.stack += '\n    at ' + n.substring(2);console.error(e);}
}}}()
var x=['./page_ranking_list/ranking_list/ranking_list.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx4_1()
var oB=_n('view')
_rz(z,oB,'class',0,e,s,gg)
var xC=_n('view')
_rz(z,xC,'class',1,e,s,gg)
var cF=_mz(z,'image',['mode',-1,'class',2,'src',1],[],e,s,gg)
_(xC,cF)
var hG=_n('view')
_rz(z,hG,'class',4,e,s,gg)
var oH=_mz(z,'image',['mode',-1,'bindtap',5,'class',1,'data-event-opts',2,'src',3,'style',4],[],e,s,gg)
_(hG,oH)
var cI=_n('view')
_rz(z,cI,'class',10,e,s,gg)
var oJ=_mz(z,'view',['class',11,'style',1],[],e,s,gg)
var lK=_mz(z,'view',['bindtap',13,'class',1,'data-event-opts',2,'style',3],[],e,s,gg)
var aL=_oz(z,17,e,s,gg)
_(lK,aL)
_(oJ,lK)
var tM=_mz(z,'view',['class',18,'style',1],[],e,s,gg)
_(oJ,tM)
_(cI,oJ)
var eN=_mz(z,'view',['class',20,'style',1],[],e,s,gg)
var bO=_mz(z,'view',['bindtap',22,'class',1,'data-event-opts',2,'style',3],[],e,s,gg)
var oP=_oz(z,26,e,s,gg)
_(bO,oP)
_(eN,bO)
var xQ=_mz(z,'view',['class',27,'style',1],[],e,s,gg)
_(eN,xQ)
_(cI,eN)
_(hG,cI)
_(xC,hG)
var oR=_n('view')
_rz(z,oR,'class',29,e,s,gg)
var fS=_mz(z,'view',['class',30,'style',1],[],e,s,gg)
var cT=_n('view')
_rz(z,cT,'class',32,e,s,gg)
var hU=_n('view')
_rz(z,hU,'class',33,e,s,gg)
_(cT,hU)
var oV=_mz(z,'image',['class',34,'src',1],[],e,s,gg)
_(cT,oV)
var cW=_mz(z,'image',['class',36,'src',1],[],e,s,gg)
_(cT,cW)
_(fS,cT)
var oX=_n('view')
_rz(z,oX,'class',38,e,s,gg)
var lY=_n('view')
_rz(z,lY,'class',39,e,s,gg)
var aZ=_oz(z,40,e,s,gg)
_(lY,aZ)
_(oX,lY)
var t1=_n('view')
_rz(z,t1,'class',41,e,s,gg)
var e2=_mz(z,'image',['mode',-1,'class',42,'src',1],[],e,s,gg)
_(t1,e2)
var b3=_n('view')
_rz(z,b3,'class',44,e,s,gg)
var o4=_oz(z,45,e,s,gg)
_(b3,o4)
_(t1,b3)
_(oX,t1)
_(fS,oX)
_(oR,fS)
var x5=_mz(z,'view',['class',46,'style',1],[],e,s,gg)
var o6=_n('view')
_rz(z,o6,'class',48,e,s,gg)
var f7=_mz(z,'image',['mode',-1,'class',49,'src',1],[],e,s,gg)
_(o6,f7)
var c8=_mz(z,'image',['class',51,'src',1],[],e,s,gg)
_(o6,c8)
var h9=_mz(z,'image',['class',53,'src',1],[],e,s,gg)
_(o6,h9)
_(x5,o6)
var o0=_n('view')
_rz(z,o0,'class',55,e,s,gg)
var cAB=_n('view')
_rz(z,cAB,'class',56,e,s,gg)
var oBB=_oz(z,57,e,s,gg)
_(cAB,oBB)
_(o0,cAB)
var lCB=_n('view')
_rz(z,lCB,'class',58,e,s,gg)
var aDB=_mz(z,'image',['mode',-1,'class',59,'src',1],[],e,s,gg)
_(lCB,aDB)
var tEB=_n('view')
_rz(z,tEB,'class',61,e,s,gg)
var eFB=_oz(z,62,e,s,gg)
_(tEB,eFB)
_(lCB,tEB)
_(o0,lCB)
_(x5,o0)
_(oR,x5)
var bGB=_mz(z,'view',['class',63,'style',1],[],e,s,gg)
var oHB=_n('view')
_rz(z,oHB,'class',65,e,s,gg)
var xIB=_n('view')
_rz(z,xIB,'class',66,e,s,gg)
_(oHB,xIB)
var oJB=_mz(z,'image',['class',67,'src',1],[],e,s,gg)
_(oHB,oJB)
var fKB=_mz(z,'image',['class',69,'src',1],[],e,s,gg)
_(oHB,fKB)
_(bGB,oHB)
var cLB=_n('view')
_rz(z,cLB,'class',71,e,s,gg)
var hMB=_n('view')
_rz(z,hMB,'class',72,e,s,gg)
var oNB=_oz(z,73,e,s,gg)
_(hMB,oNB)
_(cLB,hMB)
var cOB=_n('view')
_rz(z,cOB,'class',74,e,s,gg)
var oPB=_mz(z,'image',['mode',-1,'class',75,'src',1],[],e,s,gg)
_(cOB,oPB)
var lQB=_n('view')
_rz(z,lQB,'class',77,e,s,gg)
var aRB=_oz(z,78,e,s,gg)
_(lQB,aRB)
_(cOB,lQB)
_(cLB,cOB)
_(bGB,cLB)
_(oR,bGB)
_(xC,oR)
var oD=_v()
_(xC,oD)
if(_oz(z,79,e,s,gg)){oD.wxVkey=1
var tSB=_n('view')
_rz(z,tSB,'class',80,e,s,gg)
var eTB=_v()
_(tSB,eTB)
var bUB=function(xWB,oVB,oXB,gg){
var cZB=_v()
_(oXB,cZB)
if(_oz(z,85,xWB,oVB,gg)){cZB.wxVkey=1
var h1B=_n('view')
_rz(z,h1B,'class',86,xWB,oVB,gg)
var o2B=_n('view')
_rz(z,o2B,'class',87,xWB,oVB,gg)
var c3B=_v()
_(o2B,c3B)
if(_oz(z,88,xWB,oVB,gg)){c3B.wxVkey=1
var o4B=_mz(z,'image',['mode',-1,'class',89,'src',1],[],xWB,oVB,gg)
_(c3B,o4B)
}
var l5B=_mz(z,'view',['class',91,'style',1],[],xWB,oVB,gg)
var a6B=_oz(z,93,xWB,oVB,gg)
_(l5B,a6B)
_(o2B,l5B)
var t7B=_mz(z,'image',['mode',-1,'class',94,'src',1],[],xWB,oVB,gg)
_(o2B,t7B)
var e8B=_n('view')
_rz(z,e8B,'class',96,xWB,oVB,gg)
var b9B=_oz(z,97,xWB,oVB,gg)
_(e8B,b9B)
_(o2B,e8B)
c3B.wxXCkey=1
_(h1B,o2B)
var o0B=_n('view')
_rz(z,o0B,'class',98,xWB,oVB,gg)
var xAC=_mz(z,'image',['mode',-1,'class',99,'src',1,'style',2],[],xWB,oVB,gg)
_(o0B,xAC)
var oBC=_n('view')
_rz(z,oBC,'class',102,xWB,oVB,gg)
var fCC=_mz(z,'text',['class',103,'style',1],[],xWB,oVB,gg)
var cDC=_oz(z,105,xWB,oVB,gg)
_(fCC,cDC)
_(oBC,fCC)
_(o0B,oBC)
var hEC=_n('view')
_rz(z,hEC,'class',106,xWB,oVB,gg)
var oFC=_oz(z,107,xWB,oVB,gg)
_(hEC,oFC)
_(o0B,hEC)
_(h1B,o0B)
_(cZB,h1B)
}
cZB.wxXCkey=1
return oXB
}
eTB.wxXCkey=2
_2z(z,83,bUB,e,s,gg,eTB,'item','index','index')
_(oD,tSB)
}
var fE=_v()
_(xC,fE)
if(_oz(z,108,e,s,gg)){fE.wxVkey=1
var cGC=_n('view')
_rz(z,cGC,'class',109,e,s,gg)
var oHC=_v()
_(cGC,oHC)
var lIC=function(tKC,aJC,eLC,gg){
var oNC=_v()
_(eLC,oNC)
if(_oz(z,114,tKC,aJC,gg)){oNC.wxVkey=1
var xOC=_n('view')
_rz(z,xOC,'class',115,tKC,aJC,gg)
var oPC=_n('view')
_rz(z,oPC,'class',116,tKC,aJC,gg)
var fQC=_v()
_(oPC,fQC)
if(_oz(z,117,tKC,aJC,gg)){fQC.wxVkey=1
var cRC=_mz(z,'image',['mode',-1,'class',118,'src',1],[],tKC,aJC,gg)
_(fQC,cRC)
}
var hSC=_mz(z,'view',['class',120,'style',1],[],tKC,aJC,gg)
var oTC=_oz(z,122,tKC,aJC,gg)
_(hSC,oTC)
_(oPC,hSC)
var cUC=_mz(z,'image',['mode',-1,'class',123,'src',1],[],tKC,aJC,gg)
_(oPC,cUC)
var oVC=_n('view')
_rz(z,oVC,'class',125,tKC,aJC,gg)
var lWC=_oz(z,126,tKC,aJC,gg)
_(oVC,lWC)
_(oPC,oVC)
fQC.wxXCkey=1
_(xOC,oPC)
var aXC=_n('view')
_rz(z,aXC,'class',127,tKC,aJC,gg)
var tYC=_mz(z,'image',['mode',-1,'class',128,'src',1,'style',2],[],tKC,aJC,gg)
_(aXC,tYC)
var eZC=_n('view')
_rz(z,eZC,'class',131,tKC,aJC,gg)
var b1C=_mz(z,'text',['class',132,'style',1],[],tKC,aJC,gg)
var o2C=_oz(z,134,tKC,aJC,gg)
_(b1C,o2C)
_(eZC,b1C)
_(aXC,eZC)
var x3C=_n('view')
_rz(z,x3C,'class',135,tKC,aJC,gg)
var o4C=_oz(z,136,tKC,aJC,gg)
_(x3C,o4C)
_(aXC,x3C)
_(xOC,aXC)
_(oNC,xOC)
}
oNC.wxXCkey=1
return eLC
}
oHC.wxXCkey=2
_2z(z,112,lIC,e,s,gg,oHC,'item','index','index')
_(fE,cGC)
}
oD.wxXCkey=1
fE.wxXCkey=1
_(oB,xC)
_(r,oB)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
window.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(window.__webview_engine_version__)!='undefined'&&window.__webview_engine_version__+1e-6>=0.02+1e-6&&window.__mergeData__)
{
env=window.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(window.__webview_engine_version__)=='undefined'|| window.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
return root;
}
}
}
 
     var BASE_DEVICE_WIDTH = 750;
var isIOS=navigator.userAgent.match("iPhone");
var deviceWidth = window.screen.width || 375;
var deviceDPR = window.devicePixelRatio || 2;
var checkDeviceWidth = window.__checkDeviceWidth__ || function() {
var newDeviceWidth = window.screen.width || 375
var newDeviceDPR = window.devicePixelRatio || 2
var newDeviceHeight = window.screen.height || 375
if (window.screen.orientation && /^landscape/.test(window.screen.orientation.type || '')) newDeviceWidth = newDeviceHeight
if (newDeviceWidth !== deviceWidth || newDeviceDPR !== deviceDPR) {
deviceWidth = newDeviceWidth
deviceDPR = newDeviceDPR
}
}
checkDeviceWidth()
var eps = 1e-4;
var transformRPX = window.__transformRpx__ || function(number, newDeviceWidth) {
if ( number === 0 ) return 0;
number = number / BASE_DEVICE_WIDTH * ( newDeviceWidth || deviceWidth );
number = Math.floor(number + eps);
if (number === 0) {
if (deviceDPR === 1 || !isIOS) {
return 1;
} else {
return 0.5;
}
}
return number;
}
window.__rpxRecalculatingFuncs__ = window.__rpxRecalculatingFuncs__ || [];
var __COMMON_STYLESHEETS__ = __COMMON_STYLESHEETS__||{}

var setCssToHead = function(file, _xcInvalid, info) {
var Ca = {};
var css_id;
var info = info || {};
var _C = __COMMON_STYLESHEETS__
function makeup(file, opt) {
var _n = typeof(file) === "string";
if ( _n && Ca.hasOwnProperty(file)) return "";
if ( _n ) Ca[file] = 1;
var ex = _n ? _C[file] : file;
var res="";
for (var i = ex.length - 1; i >= 0; i--) {
var content = ex[i];
if (typeof(content) === "object")
{
var op = content[0];
if ( op == 0 )
res = transformRPX(content[1], opt.deviceWidth) + "px" + res;
else if ( op == 1)
res = opt.suffix + res;
else if ( op == 2 )
res = makeup(content[1], opt) + res;
}
else
res = content + res
}
return res;
}
var styleSheetManager = window.__styleSheetManager2__
var rewritor = function(suffix, opt, style){
opt = opt || {};
suffix = suffix || "";
opt.suffix = suffix;
if ( opt.allowIllegalSelector != undefined && _xcInvalid != undefined )
{
if ( opt.allowIllegalSelector )
console.warn( "For developer:" + _xcInvalid );
else
{
console.error( _xcInvalid );
}
}
Ca={};
css = makeup(file, opt);
if (styleSheetManager) {
var key = (info.path || Math.random()) + ':' + suffix
if (!style) {
styleSheetManager.addItem(key, info.path);
window.__rpxRecalculatingFuncs__.push(function(size){
opt.deviceWidth = size.width;
rewritor(suffix, opt, true);
});
}
styleSheetManager.setCss(key, css);
return;
}
if ( !style )
{
var head = document.head || document.getElementsByTagName('head')[0];
style = document.createElement('style');
style.type = 'text/css';
style.setAttribute( "wxss:path", info.path );
head.appendChild(style);
window.__rpxRecalculatingFuncs__.push(function(size){
opt.deviceWidth = size.width;
rewritor(suffix, opt, style);
});
}
if (style.styleSheet) {
style.styleSheet.cssText = css;
} else {
if ( style.childNodes.length == 0 )
style.appendChild(document.createTextNode(css));
else
style.childNodes[0].nodeValue = css;
}
}
return rewritor;
}
setCssToHead([])();setCssToHead([],undefined,{path:"./page_ranking_list/app.wxss"})(); 
     		__wxAppCode__['page_ranking_list/ranking_list/ranking_list.wxss'] = setCssToHead([".",[1],"dis-flex-mian.",[1],"data-v-a31fafce{align-items:center;display:flex;justify-content:center}\n.",[1],"txt-btn.",[1],"data-v-a31fafce{background:#df1f1f;border-radius:",[0,25],";color:#fff;height:",[0,50],";line-height:",[0,50],";text-align:center;width:",[0,150],"}\n.",[1],"ranking_list.",[1],"data-v-a31fafce{height:100%;position:relative;width:",[0,750],"}\n.",[1],"ranking_list .",[1],"rankingBg.",[1],"data-v-a31fafce{background-color:#fff2e6;height:",[0,718],";width:",[0,750],"}\n.",[1],"ranking_list .",[1],"topNav.",[1],"data-v-a31fafce{margin-bottom:",[0,20],";position:absolute;width:",[0,750],"}\n.",[1],"ranking_list .",[1],"topNav .",[1],"goBackLogo.",[1],"data-v-a31fafce{align-items:center;background-color:#eee;border-radius:50%;box-shadow:",[0,2]," ",[0,2]," ",[0,5]," rgba(0,0,0,.3);display:flex;font-size:",[0,46],";height:",[0,52],";justify-content:center;margin-left:",[0,47],";margin-top:",[0,70],";position:absolute;text-align:center;width:",[0,52],"}\n.",[1],"ranking_list .",[1],"topNav .",[1],"goBackLogo .",[1],"less-than.",[1],"data-v-a31fafce{border-bottom:",[0,4]," solid #000;border-left:",[0,4]," solid #000;height:",[0,16],";-webkit-transform:translate(8%,1%) rotate(45deg);transform:translate(8%,1%) rotate(45deg);width:",[0,16],"}\n.",[1],"ranking_list .",[1],"topNav .",[1],"title.",[1],"data-v-a31fafce{align-items:center;color:#fff;font-family:MicrosoftYaHei-Bold,MicrosoftYaHei;font-size:",[0,36],";height:",[0,154],";justify-content:space-between;margin:0 auto;width:",[0,340],"}\n.",[1],"ranking_list .",[1],"topNav .",[1],"title .",[1],"tite_btn.",[1],"data-v-a31fafce:active{border-radius:",[0,2],";box-shadow:",[0,2]," ",[0,6]," ",[0,40]," ",[0,-1.5]," #888383}\n.",[1],"ranking_list .",[1],"topNav .",[1],"title .",[1],"active_box.",[1],"data-v-a31fafce{border-radius:",[0,10],";height:",[0,8],";margin-top:",[0,20],";width:",[0,50],"}\n.",[1],"ranking_list .",[1],"showBg.",[1],"data-v-a31fafce{height:",[0,40],";margin-top:",[0,20],";width:",[0,135],"}\n.",[1],"ranking_list .",[1],"showLogo.",[1],"data-v-a31fafce{height:",[0,27],";margin-right:",[0,10],";width:",[0,25],"}\n.",[1],"ranking_list .",[1],"showTxt.",[1],"data-v-a31fafce{color:#ff4633;font-family:MicrosoftYaHei-Bold,MicrosoftYaHei;font-size:",[0,29],";font-weight:700}\n.",[1],"ranking_list .",[1],"ranking_top.",[1],"data-v-a31fafce{height:",[0,400],";position:absolute;top:",[0,160],";width:",[0,750],"}\n.",[1],"ranking_list .",[1],"ranking_top .",[1],"box.",[1],"data-v-a31fafce{height:",[0,300],";width:",[0,223],"}\n.",[1],"ranking_list .",[1],"ranking_top .",[1],"box_bot.",[1],"data-v-a31fafce{align-items:center;color:#fff;font-family:MicrosoftYaHei;font-size:",[0,24],";margin-top:",[0,30],"}\n.",[1],"ranking_list .",[1],"ranking_top .",[1],"box_bot .",[1],"rank-info.",[1],"data-v-a31fafce{align-items:center;background:url(https://cultural.idotang.com/static/mini_program_imgs/showBg.png);background-position:50%;background-repeat:no-repeat;background-size:contain;display:flex;height:",[0,38],";justify-content:center;margin:",[0,6]," 0 0;width:",[0,130],"}\n.",[1],"ranking_list .",[1],"ranking_top .",[1],"ranking_top_box2.",[1],"data-v-a31fafce{margin-left:7%;margin-top:18%;position:relative}\n.",[1],"ranking_list .",[1],"ranking_top .",[1],"ranking_top_box2 .",[1],"secondLogo.",[1],"data-v-a31fafce{height:",[0,82],";position:absolute;top:24%;width:",[0,223],"}\n.",[1],"ranking_list .",[1],"ranking_top .",[1],"ranking_top_box2 .",[1],"secondUser.",[1],"data-v-a31fafce{border-radius:50%;height:",[0,106],";left:27%;position:absolute;top:2%;width:",[0,106],"}\n.",[1],"ranking_list .",[1],"ranking_top .",[1],"ranking_top_box2 .",[1],"secondHead.",[1],"data-v-a31fafce{background-color:#d0e7ff;border-radius:50%;height:",[0,120],";margin:0 auto;width:",[0,120],"}\n.",[1],"ranking_list .",[1],"ranking_top .",[1],"ranking_top_box1.",[1],"data-v-a31fafce{margin-bottom:",[0,110],";position:relative}\n.",[1],"ranking_list .",[1],"ranking_top .",[1],"ranking_top_box1 .",[1],"box_bot.",[1],"data-v-a31fafce{margin-top:",[0,20],"}\n.",[1],"ranking_list .",[1],"ranking_top .",[1],"ranking_top_box1 .",[1],"firstHead.",[1],"data-v-a31fafce{height:",[0,156],";width:",[0,223],"}\n.",[1],"ranking_list .",[1],"ranking_top .",[1],"ranking_top_box1 .",[1],"firstLogo.",[1],"data-v-a31fafce{height:",[0,102],";left:-15%;position:absolute;top:32%;width:",[0,281],"}\n.",[1],"ranking_list .",[1],"ranking_top .",[1],"ranking_top_box1 .",[1],"firstUser.",[1],"data-v-a31fafce{border-radius:50%;height:",[0,132],";left:19%;position:absolute;top:4%;width:",[0,132],"}\n.",[1],"ranking_list .",[1],"ranking_top .",[1],"ranking_top_box3.",[1],"data-v-a31fafce{margin-bottom:-26%;position:relative}\n.",[1],"ranking_list .",[1],"ranking_top .",[1],"ranking_top_box3 .",[1],"thirdLogo.",[1],"data-v-a31fafce{height:",[0,82],";position:absolute;top:24%;width:",[0,223],"}\n.",[1],"ranking_list .",[1],"ranking_top .",[1],"ranking_top_box3 .",[1],"thirdUser.",[1],"data-v-a31fafce{border-radius:50%;height:",[0,106],";left:26.5%;position:absolute;top:2%;width:",[0,106],"}\n.",[1],"ranking_list .",[1],"ranking_top .",[1],"ranking_top_box3 .",[1],"thirdHead.",[1],"data-v-a31fafce{background-color:#e7b481;border-radius:50%;height:",[0,120],";margin:0 auto;width:",[0,120],"}\n.",[1],"ranking_list .",[1],"ranking_main.",[1],"data-v-a31fafce{background-color:#fff2e6;height:calc(100vh - ",[0,718],");overflow-y:scroll}\n.",[1],"ranking_list .",[1],"ranking_main .",[1],"ranking_main_box.",[1],"data-v-a31fafce{border-bottom:",[0,2]," solid #eae8eb;height:",[0,100],";justify-content:space-between;margin:0 auto;position:relative;width:",[0,600],";z-index:10}\n.",[1],"ranking_list .",[1],"ranking_main .",[1],"ranking_main_box .",[1],"ranking_main_box_left.",[1],"data-v-a31fafce{width:69%}\n.",[1],"ranking_list .",[1],"ranking_main .",[1],"ranking_main_box .",[1],"ranking_main_box_left .",[1],"ranking.",[1],"data-v-a31fafce{height:",[0,52],";left:4.5%;position:absolute;top:46.5%;-webkit-transform:translate(-50%,-50%);transform:translate(-50%,-50%);width:",[0,52],";z-index:-1}\n.",[1],"ranking_list .",[1],"ranking_main .",[1],"ranking_main_box .",[1],"ranking_main_box_left .",[1],"rankingNum.",[1],"data-v-a31fafce{height:",[0,52],";margin-right:",[0,37],";text-align:center;width:",[0,52],"}\n.",[1],"ranking_list .",[1],"ranking_main .",[1],"ranking_main_box .",[1],"ranking_main_box_left .",[1],"rankingUser.",[1],"data-v-a31fafce{border-radius:50%;height:",[0,80],";margin-right:",[0,19],";width:",[0,80],"}\n.",[1],"ranking_list .",[1],"ranking_main .",[1],"ranking_main_box .",[1],"ranking_main_box_left .",[1],"rankingName.",[1],"data-v-a31fafce{max-width:55%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n.",[1],"ranking_list .",[1],"ranking_main .",[1],"ranking_main_box .",[1],"ranking_main_box_right.",[1],"data-v-a31fafce{justify-content:space-evenly;width:30%}\n.",[1],"ranking_list .",[1],"ranking_main .",[1],"ranking_main_box .",[1],"ranking_main_box_right .",[1],"text_box.",[1],"data-v-a31fafce{max-width:67%;overflow:hidden;text-align:right;text-overflow:ellipsis;white-space:nowrap}\n",],undefined,{path:"./page_ranking_list/ranking_list/ranking_list.wxss"});
		if (__vd_version_info__.delayedGwx) __wxAppCode__['page_ranking_list/ranking_list/ranking_list.wxml'] = [ $gwx4, './page_ranking_list/ranking_list/ranking_list.wxml' ];
		else __wxAppCode__['page_ranking_list/ranking_list/ranking_list.wxml'] = $gwx4( './page_ranking_list/ranking_list/ranking_list.wxml' );
		 
     ;var __subPageFrameEndTime__ = Date.now() 	 