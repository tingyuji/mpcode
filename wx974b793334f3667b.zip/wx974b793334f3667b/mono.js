var e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
};

(wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 2 ], {
    0: function(t, r, n) {
        (function(n) {
            var o, i, a, s, u, c, l, d, p, f, h, S, _, E, y, T, R, v, g, m, O, A, I, C, D;
            !function(N) {
                function L(e, t) {
                    return e !== M && ("function" == typeof Object.create ? Object.defineProperty(e, "__esModule", {
                        value: !0
                    }) : e.__esModule = !0), function(r, n) {
                        return e[r] = t ? t(r, n) : n;
                    };
                }
                var M = "object" == (void 0 === n ? "undefined" : e(n)) ? n : "object" == ("undefined" == typeof self ? "undefined" : e(self)) ? self : "object" == e(this) ? this : {};
                void 0 === (o = function(t) {
                    !function(t) {
                        var r = Object.setPrototypeOf || {
                            __proto__: []
                        } instanceof Array && function(e, t) {
                            e.__proto__ = t;
                        } || function(e, t) {
                            for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && (e[r] = t[r]);
                        };
                        i = function(e, t) {
                            function n() {
                                this.constructor = e;
                            }
                            if ("function" != typeof t && null !== t) throw new TypeError("Class extends value " + String(t) + " is not a constructor or null");
                            r(e, t), e.prototype = null === t ? Object.create(t) : (n.prototype = t.prototype, 
                            new n());
                        }, a = Object.assign || function(e) {
                            for (var t, r = 1, n = arguments.length; r < n; r++) for (var o in t = arguments[r]) Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
                            return e;
                        }, s = function(e, t) {
                            var r = {};
                            for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && t.indexOf(n) < 0 && (r[n] = e[n]);
                            if (null != e && "function" == typeof Object.getOwnPropertySymbols) {
                                var o = 0;
                                for (n = Object.getOwnPropertySymbols(e); o < n.length; o++) t.indexOf(n[o]) < 0 && Object.prototype.propertyIsEnumerable.call(e, n[o]) && (r[n[o]] = e[n[o]]);
                            }
                            return r;
                        }, u = function(t, r, n, o) {
                            var i, a = arguments.length, s = a < 3 ? r : null === o ? o = Object.getOwnPropertyDescriptor(r, n) : o;
                            if ("object" == ("undefined" == typeof Reflect ? "undefined" : e(Reflect)) && "function" == typeof Reflect.decorate) s = Reflect.decorate(t, r, n, o); else for (var u = t.length - 1; u >= 0; u--) (i = t[u]) && (s = (a < 3 ? i(s) : a > 3 ? i(r, n, s) : i(r, n)) || s);
                            return a > 3 && s && Object.defineProperty(r, n, s), s;
                        }, c = function(e, t) {
                            return function(r, n) {
                                t(r, n, e);
                            };
                        }, l = function(t, r) {
                            if ("object" == ("undefined" == typeof Reflect ? "undefined" : e(Reflect)) && "function" == typeof Reflect.metadata) return Reflect.metadata(t, r);
                        }, d = function(e, t, r, n) {
                            return new (r || (r = Promise))(function(o, i) {
                                function a(e) {
                                    try {
                                        u(n.next(e));
                                    } catch (e) {
                                        i(e);
                                    }
                                }
                                function s(e) {
                                    try {
                                        u(n.throw(e));
                                    } catch (e) {
                                        i(e);
                                    }
                                }
                                function u(e) {
                                    var t;
                                    e.done ? o(e.value) : ((t = e.value) instanceof r ? t : new r(function(e) {
                                        e(t);
                                    })).then(a, s);
                                }
                                u((n = n.apply(e, t || [])).next());
                            });
                        }, p = function(e, t) {
                            function r(r) {
                                return function(a) {
                                    return function(r) {
                                        if (n) throw new TypeError("Generator is already executing.");
                                        for (;s; ) try {
                                            if (n = 1, o && (i = 2 & r[0] ? o.return : r[0] ? o.throw || ((i = o.return) && i.call(o), 
                                            0) : o.next) && !(i = i.call(o, r[1])).done) return i;
                                            switch (o = 0, i && (r = [ 2 & r[0], i.value ]), r[0]) {
                                              case 0:
                                              case 1:
                                                i = r;
                                                break;

                                              case 4:
                                                return s.label++, {
                                                    value: r[1],
                                                    done: !1
                                                };

                                              case 5:
                                                s.label++, o = r[1], r = [ 0 ];
                                                continue;

                                              case 7:
                                                r = s.ops.pop(), s.trys.pop();
                                                continue;

                                              default:
                                                if (i = s.trys, !((i = i.length > 0 && i[i.length - 1]) || 6 !== r[0] && 2 !== r[0])) {
                                                    s = 0;
                                                    continue;
                                                }
                                                if (3 === r[0] && (!i || r[1] > i[0] && r[1] < i[3])) {
                                                    s.label = r[1];
                                                    break;
                                                }
                                                if (6 === r[0] && s.label < i[1]) {
                                                    s.label = i[1], i = r;
                                                    break;
                                                }
                                                if (i && s.label < i[2]) {
                                                    s.label = i[2], s.ops.push(r);
                                                    break;
                                                }
                                                i[2] && s.ops.pop(), s.trys.pop();
                                                continue;
                                            }
                                            r = t.call(e, s);
                                        } catch (e) {
                                            r = [ 6, e ], o = 0;
                                        } finally {
                                            n = i = 0;
                                        }
                                        if (5 & r[0]) throw r[1];
                                        return {
                                            value: r[0] ? r[1] : void 0,
                                            done: !0
                                        };
                                    }([ r, a ]);
                                };
                            }
                            var n, o, i, a, s = {
                                label: 0,
                                sent: function() {
                                    if (1 & i[0]) throw i[1];
                                    return i[1];
                                },
                                trys: [],
                                ops: []
                            };
                            return a = {
                                next: r(0),
                                throw: r(1),
                                return: r(2)
                            }, "function" == typeof Symbol && (a[Symbol.iterator] = function() {
                                return this;
                            }), a;
                        }, f = function(e, t) {
                            for (var r in e) "default" === r || Object.prototype.hasOwnProperty.call(t, r) || D(t, e, r);
                        }, D = Object.create ? function(e, t, r, n) {
                            void 0 === n && (n = r), Object.defineProperty(e, n, {
                                enumerable: !0,
                                get: function() {
                                    return t[r];
                                }
                            });
                        } : function(e, t, r, n) {
                            void 0 === n && (n = r), e[n] = t[r];
                        }, h = function(e) {
                            var t = "function" == typeof Symbol && Symbol.iterator, r = t && e[t], n = 0;
                            if (r) return r.call(e);
                            if (e && "number" == typeof e.length) return {
                                next: function() {
                                    return e && n >= e.length && (e = void 0), {
                                        value: e && e[n++],
                                        done: !e
                                    };
                                }
                            };
                            throw new TypeError(t ? "Object is not iterable." : "Symbol.iterator is not defined.");
                        }, S = function(e, t) {
                            var r = "function" == typeof Symbol && e[Symbol.iterator];
                            if (!r) return e;
                            var n, o, i = r.call(e), a = [];
                            try {
                                for (;(void 0 === t || t-- > 0) && !(n = i.next()).done; ) a.push(n.value);
                            } catch (e) {
                                o = {
                                    error: e
                                };
                            } finally {
                                try {
                                    n && !n.done && (r = i.return) && r.call(i);
                                } finally {
                                    if (o) throw o.error;
                                }
                            }
                            return a;
                        }, _ = function() {
                            for (var e = [], t = 0; t < arguments.length; t++) e = e.concat(S(arguments[t]));
                            return e;
                        }, E = function() {
                            for (var e = 0, t = 0, r = arguments.length; t < r; t++) e += arguments[t].length;
                            var n = Array(e), o = 0;
                            for (t = 0; t < r; t++) for (var i = arguments[t], a = 0, s = i.length; a < s; a++, 
                            o++) n[o] = i[a];
                            return n;
                        }, y = function(e, t, r) {
                            if (r || 2 === arguments.length) for (var n, o = 0, i = t.length; o < i; o++) !n && o in t || (n || (n = Array.prototype.slice.call(t, 0, o)), 
                            n[o] = t[o]);
                            return e.concat(n || Array.prototype.slice.call(t));
                        }, T = function(e) {
                            return this instanceof T ? (this.v = e, this) : new T(e);
                        }, R = function(e, t, r) {
                            function n(e) {
                                c[e] && (u[e] = function(t) {
                                    return new Promise(function(r, n) {
                                        l.push([ e, t, r, n ]) > 1 || o(e, t);
                                    });
                                });
                            }
                            function o(e, t) {
                                try {
                                    (r = c[e](t)).value instanceof T ? Promise.resolve(r.value.v).then(i, a) : s(l[0][2], r);
                                } catch (e) {
                                    s(l[0][3], e);
                                }
                                var r;
                            }
                            function i(e) {
                                o("next", e);
                            }
                            function a(e) {
                                o("throw", e);
                            }
                            function s(e, t) {
                                e(t), l.shift(), l.length && o(l[0][0], l[0][1]);
                            }
                            if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
                            var u, c = r.apply(e, t || []), l = [];
                            return u = {}, n("next"), n("throw"), n("return"), u[Symbol.asyncIterator] = function() {
                                return this;
                            }, u;
                        }, v = function(e) {
                            function t(t, o) {
                                r[t] = e[t] ? function(r) {
                                    return (n = !n) ? {
                                        value: T(e[t](r)),
                                        done: "return" === t
                                    } : o ? o(r) : r;
                                } : o;
                            }
                            var r, n;
                            return r = {}, t("next"), t("throw", function(e) {
                                throw e;
                            }), t("return"), r[Symbol.iterator] = function() {
                                return this;
                            }, r;
                        }, g = function(e) {
                            function t(t) {
                                r[t] = e[t] && function(r) {
                                    return new Promise(function(n, o) {
                                        !function(e, t, r, n) {
                                            Promise.resolve(n).then(function(t) {
                                                e({
                                                    value: t,
                                                    done: r
                                                });
                                            }, t);
                                        }(n, o, (r = e[t](r)).done, r.value);
                                    });
                                };
                            }
                            if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
                            var r, n = e[Symbol.asyncIterator];
                            return n ? n.call(e) : (e = h(e), r = {}, t("next"), t("throw"), t("return"), r[Symbol.asyncIterator] = function() {
                                return this;
                            }, r);
                        }, m = function(e, t) {
                            return Object.defineProperty ? Object.defineProperty(e, "raw", {
                                value: t
                            }) : e.raw = t, e;
                        };
                        var n = Object.create ? function(e, t) {
                            Object.defineProperty(e, "default", {
                                enumerable: !0,
                                value: t
                            });
                        } : function(e, t) {
                            e.default = t;
                        };
                        O = function(e) {
                            if (e && e.__esModule) return e;
                            var t = {};
                            if (null != e) for (var r in e) "default" !== r && Object.prototype.hasOwnProperty.call(e, r) && D(t, e, r);
                            return n(t, e), t;
                        }, A = function(e) {
                            return e && e.__esModule ? e : {
                                default: e
                            };
                        }, I = function(e, t, r, n) {
                            if ("a" === r && !n) throw new TypeError("Private accessor was defined without a getter");
                            if ("function" == typeof t ? e !== t || !n : !t.has(e)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
                            return "m" === r ? n : "a" === r ? n.call(e) : n ? n.value : t.get(e);
                        }, C = function(e, t, r, n, o) {
                            if ("m" === n) throw new TypeError("Private method is not writable");
                            if ("a" === n && !o) throw new TypeError("Private accessor was defined without a setter");
                            if ("function" == typeof t ? e !== t || !o : !t.has(e)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
                            return "a" === n ? o.call(e, r) : o ? o.value = r : t.set(e, r), r;
                        }, t("__extends", i), t("__assign", a), t("__rest", s), t("__decorate", u), t("__param", c), 
                        t("__metadata", l), t("__awaiter", d), t("__generator", p), t("__exportStar", f), 
                        t("__createBinding", D), t("__values", h), t("__read", S), t("__spread", _), t("__spreadArrays", E), 
                        t("__spreadArray", y), t("__await", T), t("__asyncGenerator", R), t("__asyncDelegator", v), 
                        t("__asyncValues", g), t("__makeTemplateObject", m), t("__importStar", O), t("__importDefault", A), 
                        t("__classPrivateFieldGet", I), t("__classPrivateFieldSet", C);
                    }(L(M, L(t)));
                }.apply(r, [ r ])) || (t.exports = o);
            }();
        }).call(this, n(2));
    },
    103: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.MonoOrderAfterSalesService = void 0;
        var n = r(0), o = r(1), i = r(18), a = r(38), s = r(41), u = r(7), c = r(3), l = r(11), d = function() {
            function e(e, t) {
                this.timeService = e, this.monoUtilService = t;
            }
            return e.prototype.setApiService = function(e) {
                this.api = e;
            }, e.prototype.processAsRole = function(e, t) {
                var r = e.asRole, o = e.orderChainGhDTO;
                if (r !== a.AfterSalesRole.MIDDLEMAN_SOURCE) return e;
                var i = t === (null == o ? void 0 : o.startGhId) ? a.AfterSalesRole.MIDDLEMAN_START : t === (null == o ? void 0 : o.followGhId) ? a.AfterSalesRole.MIDDLEMAN_FOLLOW : r;
                return n.__assign(n.__assign({}, e), {
                    asRole: i
                });
            }, e.prototype.getCarriageOperations = function(e) {
                var t;
                return void 0 === e && (e = !1), (t = {}).return = e ? {
                    text: "寄回商品",
                    key: "return",
                    style: a.OrderOperationStyle.PRIMARY_LINER_BTN
                } : {}, t.PAY_CARRIAGE_DETAIL = e ? {} : {
                    text: "查看账单",
                    key: "PAY_CARRIAGE_DETAIL"
                }, t.PICK_UP_DETAIL = {
                    text: "查看取件信息",
                    key: "PICK_UP_DETAIL",
                    style: a.OrderOperationStyle.PRIMARY_LINER_BTN
                }, t.PAY_CARRIAGE = {
                    text: "支付运费",
                    key: "PAY_CARRIAGE",
                    style: e ? a.OrderOperationStyle.PRIMARY_LINER_BTN : a.OrderOperationStyle.PRIMARY_BTN
                }, t.AGENT_PAY_CARRIAGE = {
                    text: "代支付运费",
                    key: "AGENT_PAY_CARRIAGE",
                    style: a.OrderOperationStyle.PRIMARY_BTN
                }, t.CARRIAGE_DETAIL = {
                    text: "查看物流",
                    key: "CARRIAGE_DETAIL",
                    style: a.OrderOperationStyle.PRIMARY_LINER_BTN
                }, t.EDIT_CARRIAGE = {
                    text: "修改",
                    key: "EDIT_CARRIAGE",
                    style: a.OrderOperationStyle.PRIMARY_LINER_BTN
                }, t;
            }, e.prototype.getOperation = function(e) {
                var t, r, n, o, i = ((t = {}).rush = "催一催", t.reapply = "重新申请", t.withdraw = "撤销申请", 
                t.toNegotiate = "去协商", t.rejectRefund = "拒绝退款", t.refundDetail = "退款明细", t.supplementApply = "补充信息", 
                t.supplementApplyAgent = "补充信息", t.return = "寄回商品", t.returnAgent = "填写物流单号", t.confirmSuccess = "确认售后成功", 
                t.contactParentLeader = "联系团长", t.allowRefund = "同意退款", t.uploadAddr = "同意退货", t.ORDER_DETAIL = "订单详情", 
                t.contactWithSupply = "联系供货商", t.contactWithChildLeader = "联系团长", t.COPY_AFTER_SALES_ORDER = "复制信息", 
                t), u = ((r = {}).return = a.OrderOperationStyle.PRIMARY_BTN, r.returnAgent = a.OrderOperationStyle.PRIMARY_BTN, 
                r.confirmSuccess = a.OrderOperationStyle.PRIMARY_BTN, r.contactParentLeader = a.OrderOperationStyle.PRIMARY_BTN, 
                r.allowRefund = a.OrderOperationStyle.PRIMARY_BTN, r.uploadAddr = a.OrderOperationStyle.PRIMARY_BTN, 
                r.contactWithSupply = a.OrderOperationStyle.PRIMARY_BTN, r), c = ((n = {}).supplementApplyAgent = {
                    code: 1124,
                    type: s.RedDotType.UID_CUSTOM,
                    customKey: ""
                }, n), l = ((o = {}).supplementApplyAgent = "在这里补充信息或转发补充邀请", o);
                return {
                    key: e,
                    text: i[e],
                    style: u[e],
                    redDotInfo: c[e],
                    redDotTipContent: l[e]
                };
            }, e.prototype.getOperations = function(e, t) {
                var r = this, n = e.asStatus, o = e.asRole, i = e.refundStatus, s = e.asType, u = e.groupType, c = e.asReturnGoodsStatus, l = t || {}, d = l.hasUploadAsAddress, p = void 0 !== d && d, f = l.hasUploadAsCarriage, h = void 0 !== f && f, S = l.canApplyAfterSales, _ = void 0 !== S && S, E = l.isTimeout, y = void 0 !== E && E, T = l.isAgentLeader, R = void 0 !== T && T, v = l.isAgentAsOrder, g = void 0 !== v && v, m = l.isCard, O = void 0 !== m && m, A = l.isPc, I = void 0 !== A && A, C = l.isHideContactWithSupply, D = l.isHideContactWithLeader, N = l.canDisableLeaderReturnGoods, L = void 0 !== N && N, M = this.getStateJudge(n, s, i, void 0, c), b = [ 10, 70, 110 ].includes(u);
                if (o === a.AfterSalesRole.UN_KNOW) return [];
                var P = o === a.AfterSalesRole.CUSTOMER && (10 === n || M.isStatusRejectedOrWithDraw) && (M.isRefundFail || M.isStatusRejectedOrWithDraw) && _, w = o === a.AfterSalesRole.CUSTOMER && 20 === n && !M.isRefundSuccess && !M.isRefundFail, U = M.isStatusWaiting && !(M.isReturnFeeAndGoods && p) && g && !b && !w, x = o === a.AfterSalesRole.CUSTOMER, F = o === a.AfterSalesRole.CUSTOMER && M.isStatusWaitingCustomer && (M.isReturnFee || h || M.isRefundSuccess) && !M.isRefundFail, k = (o === a.AfterSalesRole.CUSTOMER || R) && M.isStatusWaiting && !M.isRefundSuccess, G = !(o !== a.AfterSalesRole.SOURCE_OF_GOODS && o !== a.AfterSalesRole.GRANT || 10 !== n || 0 !== i || g && !b), B = [ a.AfterSalesRole.SOURCE_OF_GOODS, a.AfterSalesRole.GRANT ].includes(o) && 10 === n && (M.isReturnFee || h || M.isRefundFail), H = [ a.AfterSalesRole.SOURCE_OF_GOODS, a.AfterSalesRole.GRANT, a.AfterSalesRole.MIDDLEMAN_SELLER ].includes(o) && 10 === n && (!M.isRefundSuccess && !M.isRefundFail || M.isRefundFail && !y), j = [ a.AfterSalesRole.SOURCE_OF_GOODS, a.AfterSalesRole.GRANT ].includes(o) && 10 === n && !(M.isReturnFee || h || M.isRefundFail), W = [ a.AfterSalesRole.SOURCE_OF_GOODS, a.AfterSalesRole.GRANT ].includes(o) && M.isRefundSuccess, Y = o === a.AfterSalesRole.CUSTOMER && 20 === n && M.isReturnFeeAndGoods && p && !h && !M.isRefundFail, V = (R || !L && [ 20, 105 ].includes(u)) && 20 === n && M.isReturnFeeAndGoods && p && !h && !M.isRefundFail, q = [ a.AfterSalesRole.MIDDLEMAN_SOURCE, a.AfterSalesRole.MIDDLEMAN_START, a.AfterSalesRole.MIDDLEMAN_FOLLOW, a.AfterSalesRole.MIDDLEMAN_SELLER ].includes(o) && !C, K = [ a.AfterSalesRole.SOURCE_OF_GOODS, a.AfterSalesRole.MIDDLEMAN_SOURCE ].includes(o) && !D, X = o !== a.AfterSalesRole.CUSTOMER, z = [ "allowRefund", "rejectRefund", "uploadAddr", "return" ], Q = [ "allowRefund", "rejectRefund", "refundDetail", "uploadAddr" ], J = [];
                return q && J.push({
                    key: "contactWithSupply"
                }), F && J.push({
                    key: "confirmSuccess"
                }), Y && J.push({
                    key: "return"
                }), V && J.push({
                    key: "returnAgent"
                }), x && J.push({
                    key: "contactParentLeader"
                }), j && J.push({
                    key: "uploadAddr"
                }), B && J.push({
                    key: "allowRefund"
                }), H && J.push({
                    key: "rejectRefund"
                }), K && J.push({
                    key: "contactWithChildLeader"
                }), W && J.push({
                    key: "refundDetail"
                }), w && J.push({
                    key: "supplementApply"
                }), U && J.push({
                    key: "supplementApplyAgent"
                }), G && J.push({
                    key: "toNegotiate"
                }), P && J.push({
                    key: "reapply"
                }), k && J.push({
                    key: "withdraw"
                }), X && J.push({
                    key: "COPY_AFTER_SALES_ORDER"
                }), J.filter(function(e) {
                    return !I || Q.includes(e.key);
                }).filter(function(e) {
                    return !O || z.includes(e.key);
                }).map(function(e) {
                    return r.getOperation(e.key);
                });
            }, e.prototype.getStatusTitle = function(e, t, r, n) {
                void 0 === r && (r = !1), void 0 === n && (n = 0);
                var o = this.getStatusCallOfRole(e, t), i = this.getStatusJudge(e, n), a = this.getRoleJudge(t), s = "";
                return i.isStatusWaitingGroup ? s = "待" + o + "处理" : i.isStatusWaitingCustomerSend ? s = "待" + o + "寄回商品" : i.isStatusWaitingCustomer ? s = "待" + o + (a.isCustomer ? "处理" : "确认") : i.isStatusRejected ? s = o + "拒绝售后" : i.isStatusSuccess ? s = "售后成功" : i.isStatusWithDraw && (s = "申请已撤销"), 
                r && (a.isSourceOfGoodsOrGrantSupply || a.isMiddleMan || a.isMiddleManSeller) && i.isStatusRejectedOrWithDraw && (s = ""), 
                s;
            }, e.prototype.getStatusIcon = function(e) {
                var t = this.getStatusJudge(e), r = "/ss/app/image/plus/";
                return t.isStatusWaiting ? r += "wait05" : t.isStatusSuccess ? r += "success03" : r += "delete39", 
                r + ".png";
            }, e.prototype.getStatusSubTitle = function(e, t, r, n) {
                var o = n || {}, i = o.canApplyAfterSales, a = void 0 !== i && i, s = o.isTimeout, u = void 0 !== s && s, c = this.getRoleJudge(e), l = this.getStatusJudge(t), d = this.getRefundStatusJudge(r), p = "";
                return l.isStatusWaitingGroup ? p = c.isCustomer ? d.isRefundLackMoney ? "系统处理失败，请联系团长" : "请耐心等待，若超时未处理将自动同意退款" : d.isRefundLackMoney ? u ? "系统处理失败，请充值" : "余额不足，退款失败请充值" : "若超时未处理，系统将自动同意退款" : l.isStatusWaitingCustomer ? p = "若超时未处理，系统将自动确认售后成功" : l.isStatusWithDraw && c.isCustomer ? p = a ? "若问题未解决，可在有效期内再次申请售后" : "" : l.isStatusRejected && c.isCustomer && (p = a ? "你可继续补充详情，团长会重新处理" : ""), 
                p;
            }, e.prototype.getStatusCallOfRole = function(e, t) {
                var r, n, o, i, s, u, c, l;
                return ((r = {})[a.AfterSalesRole.SOURCE_OF_GOODS] = ((n = {})[10] = a.AfterSalesRoleText.ME, 
                n[20] = a.AfterSalesRoleText.CUSTOMER, n[30] = a.AfterSalesRoleText.ME, n[40] = a.AfterSalesRoleText.MIDDLEMAN, 
                n[50] = a.AfterSalesRoleText.GRANT, n[60] = a.AfterSalesRoleText.CUSTOMER, n[61] = a.AfterSalesRoleText.MIDDLEMAN, 
                n), r[a.AfterSalesRole.GRANT] = ((o = {})[10] = a.AfterSalesRoleText.SOURCE_OF_GOODS, 
                o[20] = a.AfterSalesRoleText.CUSTOMER, o[30] = a.AfterSalesRoleText.SOURCE_OF_GOODS, 
                o[40] = a.AfterSalesRoleText.MIDDLEMAN, o[50] = a.AfterSalesRoleText.ME, o[60] = a.AfterSalesRoleText.CUSTOMER, 
                o[61] = a.AfterSalesRoleText.MIDDLEMAN, o), r[a.AfterSalesRole.MIDDLEMAN_SOURCE] = ((i = {})[10] = a.AfterSalesRoleText.SOURCE_OF_GOODS, 
                i[20] = a.AfterSalesRoleText.CUSTOMER, i[30] = a.AfterSalesRoleText.SOURCE_OF_GOODS, 
                i[40] = a.AfterSalesRoleText.MIDDLEMAN, i[50] = a.AfterSalesRoleText.SOURCE_OF_GOODS, 
                i[60] = a.AfterSalesRoleText.CUSTOMER, i[61] = a.AfterSalesRoleText.MIDDLEMAN, i), 
                r[a.AfterSalesRole.MIDDLEMAN_FOLLOW] = ((s = {})[10] = a.AfterSalesRoleText.SOURCE_OF_GOODS, 
                s[20] = a.AfterSalesRoleText.CUSTOMER, s[30] = a.AfterSalesRoleText.SOURCE_OF_GOODS, 
                s[40] = a.AfterSalesRoleText.MIDDLEMAN, s[50] = a.AfterSalesRoleText.SOURCE_OF_GOODS, 
                s[60] = a.AfterSalesRoleText.CUSTOMER, s[61] = a.AfterSalesRoleText.MIDDLEMAN, s), 
                r[a.AfterSalesRole.MIDDLEMAN_START] = ((u = {})[10] = a.AfterSalesRoleText.SOURCE_OF_GOODS, 
                u[20] = a.AfterSalesRoleText.CUSTOMER, u[30] = a.AfterSalesRoleText.SOURCE_OF_GOODS, 
                u[40] = a.AfterSalesRoleText.MIDDLEMAN, u[50] = a.AfterSalesRoleText.SOURCE_OF_GOODS, 
                u[60] = a.AfterSalesRoleText.CUSTOMER, u[61] = a.AfterSalesRoleText.MIDDLEMAN, u), 
                r[a.AfterSalesRole.MIDDLEMAN_SELLER] = ((c = {})[10] = a.AfterSalesRoleText.SOURCE_OF_GOODS, 
                c[20] = a.AfterSalesRoleText.CUSTOMER, c[30] = a.AfterSalesRoleText.SOURCE_OF_GOODS, 
                c[40] = a.AfterSalesRoleText.ME, c[50] = a.AfterSalesRoleText.SOURCE_OF_GOODS, c[60] = a.AfterSalesRoleText.CUSTOMER, 
                c[61] = a.AfterSalesRoleText.MIDDLEMAN, c), r[a.AfterSalesRole.CUSTOMER] = ((l = {})[10] = a.AfterSalesRoleText.MIDDLEMAN, 
                l[20] = a.AfterSalesRoleText.ME, l[30] = a.AfterSalesRoleText.MIDDLEMAN, l[40] = a.AfterSalesRoleText.MIDDLEMAN, 
                l[50] = a.AfterSalesRoleText.MIDDLEMAN, l[60] = a.AfterSalesRoleText.CUSTOMER, l[61] = a.AfterSalesRoleText.MIDDLEMAN, 
                l), r)[t][e];
            }, e.prototype.getLeftTimeInfo = function(e, t) {
                return void 0 === e && (e = !1), void 0 === t && (t = 0), e ? {
                    leftTimeText: "",
                    isTimeout: !1
                } : this.formatStatusLeftTime(t);
            }, e.prototype.formatStatusLeftTime = function(e) {
                try {
                    var t = this.timeService.restTimeFormat(e, !1), r = t.day, n = t.hour, o = t.minute, i = t.second, a = "";
                    return "0" !== r && (a += r + "天"), ("0" !== n || a) && (a += n + "小时"), "0" === r && "0" === n && "0" === o && "0" !== i ? a += "1分钟" : ("0" !== o || a) && (a += o + "分钟"), 
                    {
                        isTimeout: !1,
                        leftTimeText: "剩余" + a
                    };
                } catch (e) {
                    return {
                        isTimeout: !0,
                        leftTimeText: "已超时"
                    };
                }
            }, e.prototype.getRoleJudge = function(e) {
                return {
                    isSourceOfGoodsOrGrantSupply: e === a.AfterSalesRole.SOURCE_OF_GOODS || e === a.AfterSalesRole.GRANT,
                    isMiddleMan: [ a.AfterSalesRole.MIDDLEMAN_SOURCE, a.AfterSalesRole.MIDDLEMAN_FOLLOW, a.AfterSalesRole.MIDDLEMAN_START, a.AfterSalesRole.MIDDLEMAN_SELLER ].includes(e),
                    isMiddleManSeller: e === a.AfterSalesRole.MIDDLEMAN_SELLER,
                    isCustomer: e === a.AfterSalesRole.CUSTOMER,
                    isUnKnown: e === a.AfterSalesRole.UN_KNOW
                };
            }, e.prototype.getStatusJudge = function(e, t) {
                void 0 === e && (e = -1), void 0 === t && (t = 0);
                var r = 120 === e, n = [ 30, 40, 50 ].includes(e), o = [ 60, 61 ].includes(e), i = 20 === e;
                return {
                    isStatusSuccess: r,
                    isStatusRejected: n,
                    isStatusWithDraw: o,
                    isStatusRejectedOrWithDraw: n || o,
                    isStatusWaitingCustomer: i,
                    isStatusWaitingCustomerSend: i && 10 === t,
                    isStatusWaitingGroup: 10 === e,
                    isStatusWaiting: [ 10, 20 ].includes(e)
                };
            }, e.prototype.getRefundStatusJudge = function(e) {
                var t = 30 === e, r = 20 === e;
                return {
                    isRefundLackMoney: t,
                    isRefundSystemFail: r,
                    isRefundFail: t || r,
                    isRefundSuccess: 200 === e
                };
            }, e.prototype.getReturnTypeJudge = function(e) {
                return {
                    isReturnFee: 1 === e,
                    isReturnFeeAndGoods: 2 === e
                };
            }, e.prototype.getStateJudge = function(e, t, r, o, i) {
                return void 0 === i && (i = 0), n.__assign(n.__assign(n.__assign(n.__assign({}, this.getStatusJudge(e, i)), this.getReturnTypeJudge(t)), this.getRefundStatusJudge(r)), this.getRoleJudge(o || a.AfterSalesRole.UN_KNOW));
            }, e.prototype.getGoodsRenderData = function(e, t) {
                return void 0 === t && (t = !0), e.map(function(e) {
                    var r = e.goodsName, o = e.orderItemId, i = e.groupPrice, s = void 0 === i ? 0 : i, u = e.applyRefundAmount, c = void 0 === u ? 0 : u, l = e.buyQuantity, d = void 0 === l ? 0 : l, p = e.discountShareFee, f = void 0 === p ? 0 : p, h = e.applyGoodsNum, S = void 0 === h ? 0 : h, _ = e.goodsUnit, E = e.signCount, y = e.refundNum, T = e.goodsImg, R = e.refundAmount, v = void 0 === R ? 0 : R, g = e.logisticsStatus, m = void 0 === g ? a.OrderLogisticsStatus.UNSEND : g, O = S ? c / S : c;
                    return n.__assign(n.__assign(n.__assign({
                        name: r || "",
                        specStr: _ || "",
                        goodsId: o + "",
                        coverImage: T || "",
                        verificationQuantity: E || 0,
                        returnQuantity: y || 0,
                        orderQuantity: S || 0,
                        applyRefundAmount: c,
                        discountShareFee: f,
                        buyQuantity: d,
                        buyAmount: d * s,
                        goodsCharges: s ? (s / 100).toFixed(2) : "0.00",
                        price: O && t ? (O / 100).toFixed(2) : "0.00",
                        discountPrice: t && f ? ((s * d - f) / 100 / d).toFixed(2) : "",
                        oriGoodsName: e.oriGoodsName
                    }, v ? {
                        refundAmount: (v / 100).toFixed(2)
                    } : {}), v ? {
                        returnAmountNum: v
                    } : {}), {
                        logisticsStatus: m
                    });
                });
            }, e.prototype.getMainInfoRenderData = function(e, t, r) {
                var n = r || {}, o = n.isSent, i = void 0 !== o && o, s = n.isPc, u = void 0 !== s && s, c = n.hasViewSupplierRights, l = void 0 !== c && c, d = n.hasViewLeaderRights, p = void 0 !== d && d, f = n.groupType, h = n.asRole, S = n.curFollowOrderViewRole, _ = e.asType, E = e.applyAsFee, y = e.applyAsCarriageFee, T = e.actNo, R = e.carriageInfoDPList, v = void 0 === R ? [] : R, g = e.userRemark, m = e.addr, O = e.refundCarriageFee, A = void 0 === O ? 0 : O, I = e.refundTotalFee, C = e.linkMan, D = e.linkPhone, N = e.name, L = e.orderCreateTime, M = e.asCreateTime, b = e.asContent, P = e.dlvName, w = e.dlvPosition, U = e.otherOrderInfo, x = e.orderChainGhDTO, F = e.orderTotalFee, k = void 0 === F ? 0 : F, G = e.orderCarriageFee, B = void 0 === G ? 0 : G, H = e.orderRefundTotalFee, j = void 0 === H ? 0 : H, W = e.orderRefundCarriageFee, Y = void 0 === W ? 0 : W, V = E && (E / 100).toFixed(2), q = y && (y / 100).toFixed(2), K = q ? "（含运费" + q + "）" : "", X = A ? "（含运费" + q + "）" : "", z = k && (k / 100).toFixed(2), Q = B && (B / 100).toFixed(2), J = B ? "（含运费" + Q + "）" : "", $ = Y && (Y / 100).toFixed(2), Z = Y ? "（含运费" + $ + "）" : "", ee = !!P || !!w, te = [ C || "", D || "", m || "" ].filter(function(e) {
                    return "" !== e;
                }).join("，"), re = (null == x ? void 0 : x.parentGhName) || "", ne = (null == x ? void 0 : x.childGhName) || "", oe = 110 === f || 2 === S || 105 === (null == x ? void 0 : x.childGhType) ? "SUPPLY_LEADER" : "HELP_SALE_LEADER", ie = l && !!re && h !== a.AfterSalesRole.CUSTOMER, ae = p && !!ne && h !== a.AfterSalesRole.CUSTOMER;
                return u ? [ {
                    label: a.AfterSalesInfoLabel.ACT_ORDER_NUMBER,
                    value: T + ""
                }, {
                    label: a.AfterSalesInfoLabel.ORDER_TIME,
                    value: this.timeService.formatDateTime(this.timeService.newDate(L))
                }, {
                    label: a.AfterSalesInfoLabel.ORDER_NUMBER,
                    value: t
                }, {
                    label: a.AfterSalesInfoLabel.ORDER_STATUS,
                    value: (null == U ? void 0 : U.statusText) || ""
                }, {
                    label: a.AfterSalesInfoLabel.USER_NAME,
                    value: g ? g + "（" + N + "）" : N
                }, ee && {
                    label: a.AfterSalesInfoLabel.DLV_NAME,
                    value: P
                }, ee && {
                    label: a.AfterSalesInfoLabel.LINK_INFO,
                    value: te
                }, !ee && i && {
                    label: a.AfterSalesInfoLabel.CARRIAGE_INFO,
                    value: v
                }, !ee && te && {
                    label: a.AfterSalesInfoLabel.RECEIPT_INFO,
                    value: te
                }, {
                    label: a.AfterSalesInfoLabel.REMARK,
                    value: (null == U ? void 0 : U.userMark) || ""
                } ].filter(function(e) {
                    return !!e;
                }) : [ {
                    label: a.AfterSalesInfoLabel.TYPE,
                    value: 1 === _ ? "仅退款，无需退货" : "退货退款"
                }, {
                    label: a.AfterSalesInfoLabel.APPLY_REFUND_AMOUNT,
                    value: V + "元" + K
                }, I && {
                    label: a.AfterSalesInfoLabel.REAL_REFUND_AMOUNT,
                    value: (I / 100).toFixed(2) + "元" + X
                }, {
                    label: a.AfterSalesInfoLabel.APPLY_AFTER_SALES_TIME,
                    value: this.timeService.formatDateTime(this.timeService.newDate(M))
                }, b && {
                    label: a.AfterSalesInfoLabel.AFTER_SALES_REASON,
                    value: b
                }, {
                    label: a.AfterSalesInfoLabel.ACT_ORDER_NUMBER,
                    value: T + ""
                }, {
                    label: a.AfterSalesInfoLabel.ORDER_TIME,
                    value: this.timeService.formatDateTime(this.timeService.newDate(L))
                }, {
                    label: a.AfterSalesInfoLabel.ORDER_TOTAL_FEE,
                    value: z + "元" + J
                }, j && {
                    label: a.AfterSalesInfoLabel.ORDER_TOTAL_REFUND_FEE,
                    value: (j / 100).toFixed(2) + "元" + Z
                }, {
                    label: a.AfterSalesInfoLabel.ORDER_NUMBER,
                    value: t,
                    withCopy: !0
                }, ie && {
                    label: a.AfterSalesInfoLabel.SUPPLIER,
                    value: re
                }, ae && {
                    label: a.AfterSalesInfoLabel[oe],
                    value: ne
                }, {
                    label: a.AfterSalesInfoLabel.USER_NAME,
                    value: g ? g + "（" + N + "）" : N
                }, ee && {
                    label: a.AfterSalesInfoLabel.DLV_NAME,
                    value: P
                }, ee && {
                    label: a.AfterSalesInfoLabel.LINK_INFO,
                    value: te
                }, !ee && i && {
                    label: a.AfterSalesInfoLabel.CARRIAGE_INFO,
                    value: v
                }, !ee && te && {
                    label: a.AfterSalesInfoLabel.RECEIPT_INFO,
                    value: te
                } ].filter(function(e) {
                    return !!e;
                });
            }, e.prototype.getCopyMainInfoContent = function(e, t, r, n) {
                var o = "";
                t.forEach(function(e) {
                    if (e.label === a.AfterSalesInfoLabel.CARRIAGE_INFO) {
                        var t = (null == e ? void 0 : e.value).reduce(function(e, t) {
                            return e + (t.carriageCompany + " ") + t.carriageNo + "    ";
                        }, "");
                        o += "\n" + e.label + ": " + t;
                    } else o += "\n" + e.label + ": " + e.value;
                }), o += "\n商品信息:", e.forEach(function(e) {
                    o += "\n" + e.name + "(" + e.specStr + ")  +" + e.orderQuantity, e.returnQuantity && (o += "(已退" + e.returnQuantity + ")");
                });
                var i = r || {}, s = i.carriageCompany, u = i.carriageNo;
                if (s && u) {
                    var c = n && n > 0 ? " (" + a.afterSaleReturnStatusMap[n] + ")" : "";
                    o += "\n退货物流: " + s + u + c;
                }
                return o.trim();
            }, e.prototype.formatNegotiationContent = function(e, t, r, o, i, a, s, u) {
                if (!e) return {};
                var c = this.getParseContent(e), l = c.isRefund, d = c.reason || "", p = {
                    isReject: c.isReject || !1,
                    isRefund: l
                };
                switch (o) {
                  case "goods":
                    var f = this.formContent(c, l, l ? r : t), h = f.applyAsFee, S = f.goodsText, _ = f.carriageFeeText, E = f.actualReturnFeeText, y = h + "元" + _;
                    if (i || a || l) {
                        var T = "元" + _;
                        p = n.__assign(n.__assign({}, p), {
                            applyAsFee: h,
                            goodsText: S,
                            actualReturnFeeText: E,
                            afterFeeText: T,
                            withCopy: !1
                        }), i && (p = n.__assign(n.__assign({}, p), {
                            reason: this.getSystemReason(s, u),
                            applyAsFee: h
                        }));
                    } else p = n.__assign(n.__assign({}, p), {
                        goodsText: S,
                        applyAsFeeText: y,
                        withCopy: !1
                    });
                    break;

                  case "logistics":
                    var R = c.carriageCompany, v = c.carriageNo;
                    p = n.__assign(n.__assign({}, p), {
                        carriageCompany: R,
                        carriageNo: v,
                        withCopy: !0
                    });
                    break;

                  case "text":
                    c.isRefundAddr && (p = n.__assign(n.__assign({}, p), {
                        isRefundAddr: c.isRefundAddr,
                        userAddrId: c.userAddrId
                    }));
                }
                return n.__assign({
                    reason: d
                }, p);
            }, e.prototype.getLogisticsTrackInfoFromNegotiationContent = function(e, t) {
                var r = this;
                void 0 === t && (t = {});
                var n = e.filter(function(e) {
                    return r.filterValidLogisticsRecord(e, t);
                }).map(function(e) {
                    var t = e.content, r = void 0 === t ? {} : t, n = r.carriageCompany, o = void 0 === n ? "" : n, i = r.carriageNo;
                    return {
                        logisticsCompanyName: o,
                        logisticsNo: void 0 === i ? "" : i
                    };
                }, []);
                return n.length ? this.api.batchQueryLastTrackUsingPOST(n, {
                    isSkipPageMarking: !0,
                    hideErrorToast: !0
                }).pipe(c.map(function(n) {
                    var o = n.data, i = void 0 === o ? [] : o;
                    return r.assembledLogisticsTrackInfoDataToNegotiationRecord(e, i, t);
                }), c.catchError(function() {
                    return u.of(e);
                })) : u.of(e);
            }, e.prototype.assembledLogisticsTrackInfoDataToNegotiationRecord = function(e, t, r) {
                var o = this, i = e.filter(function(e) {
                    return o.filterValidLogisticsRecord(e, r);
                });
                return t.forEach(function(e) {
                    var t = e.logisticsNo, r = void 0 === t ? "" : t, o = e.logisticsCompany, a = void 0 === o ? "" : o, s = e.lastestTrack, u = (void 0 === s ? {} : s).context, c = !!r && !!a && !!(void 0 === u ? "" : u);
                    i.filter(function(e) {
                        var t = e.content, n = (void 0 === t ? {} : t).carriageNo;
                        return (void 0 === n ? "" : n) === r;
                    }).forEach(function(t) {
                        return t.content = n.__assign(n.__assign({}, t.content), {
                            lastLogisticsDTO: e,
                            isShowLogisticsTrack: c
                        });
                    });
                }), e;
            }, e.prototype.filterValidLogisticsRecord = function(e, t) {
                var r = e.commentEum, n = void 0 === r ? "" : r, o = e.content, i = (void 0 === o ? {} : o).carriageNo, a = void 0 === i ? "" : i, s = t.carriageNo, u = void 0 === s ? "" : s;
                return "logistics" === n && !!a && !!u && a === u;
            }, e.prototype.getParseContent = function(e) {
                var t = {
                    reason: ""
                };
                try {
                    var r = JSON.parse(e);
                    t = Reflect.has(r, "actualReturnFee") ? n.__assign(n.__assign({}, r), {
                        isRefund: !0
                    }) : r;
                } catch (r) {
                    t = {
                        reason: e,
                        isRefund: !1
                    };
                }
                return t;
            }, e.prototype.formContent = function(e, t, r) {
                var o = this, i = (e.applyAsFee / 100).toFixed(2), a = (e.asGoodsInfoMsgInnerList || []).map(function(e) {
                    var r, n = e.actGoodsName, i = e.applyGoodsNum, a = e.actualReturnGoodsNum;
                    return r = t ? a : i, o.monoUtilService.isUndefinedOrNull(r) ? "" : n + (r ? "（退款数量" + r + "）" : "");
                });
                return {
                    applyAsFee: i,
                    goodsText: n.__spread(a, [ r ? "运费" : "" ]).filter(function(e) {
                        return e;
                    }).join("，"),
                    carriageFeeText: r ? "（含运费" + this.monoUtilService.numberMovePoint(r, -2) + "）" : "",
                    actualReturnFeeText: "" + ((e.actualReturnFee || e.applyAsFee || 0) / 100).toFixed(2)
                };
            }, e.prototype.getSystemReason = function(e, t) {
                var r, n = e.beforeContentMap, o = void 0 === n ? {} : n, i = "";
                return Reflect.has(o, "ALL") ? i += o.ALL : i += ((r = {})[a.AfterSalesRole.CUSTOMER] = o.USER, 
                r[a.AfterSalesRole.GRANT] = o.HELP_SALE_GROUP, r[a.AfterSalesRole.MIDDLEMAN_SELLER] = o.HELP_SALE_GROUP, 
                r[a.AfterSalesRole.MIDDLEMAN_FOLLOW] = o.HELP_SALE_GROUP, r[a.AfterSalesRole.MIDDLEMAN_START] = o.HELP_SALE_GROUP, 
                r[a.AfterSalesRole.MIDDLEMAN_SOURCE] = o.HELP_SALE_GROUP, r[a.AfterSalesRole.SOURCE_OF_GOODS] = o.GROUP, 
                r)[t], i;
            }, e.prototype.getRefundInfo = function(e) {
                var t = {};
                if (!e) return t;
                var r = e.markInfoList;
                return (void 0 === r ? [] : r).forEach(function(e) {
                    var r = e.type, o = e.content;
                    switch (r) {
                      case "text":
                        t = n.__assign(n.__assign({}, t), {
                            remark: o[0].replace("#退款备注#", "")
                        });
                        break;

                      case "image":
                        t = n.__assign(n.__assign({}, t), {
                            picList: o
                        });
                        break;

                      case "video":
                        t = n.__assign(n.__assign({}, t), {
                            videoList: o
                        });
                        break;

                      case "logistics":
                        var i = o.logisticsCompany, a = o.logisticsNo;
                        t = n.__assign(n.__assign({}, t), {
                            logistics: i + "：" + a
                        });
                    }
                }), t;
            }, e.prototype.getNegotiationRecordsData = function(e, t, r, n, o, i, s) {
                var l = this;
                return e.pipe(c.map(function(e) {
                    return e.data || [];
                }), c.map(function(e) {
                    return e.map(function(e, i) {
                        var s, u = e.bizCode, c = e.extJsonDTO, d = void 0 === c ? {} : c, p = e.msgContentDTO, f = e.msgFromId, h = e.msgCreateTime, S = e.msgId, _ = e.proUserResp, E = e.postId, y = e.canUpdateFlag, T = d.writerRole, R = void 0 === T ? "" : T, v = d.system, g = void 0 !== v && v, m = d.commentEum, O = void 0 === m ? "" : m, A = R === a.AfterSalesRoleText.MIDDLEMAN || R === a.AfterSalesRoleText.SOURCE_OF_GOODS, I = R, C = l.formatNegotiationContent(p.content || "", n, o, O, g, A, d, t), D = 0 === i && C.isRefundAddr && I === a.AfterSalesRoleText.ME, N = (l.isCanShowEditNegotiationRecord(i, e, t, r), 
                        !!(null === (s = null == p ? void 0 : p.extDTO) || void 0 === s ? void 0 : s.updateFlag)), L = C.isRefundAddr && I !== a.AfterSalesRoleText.ME, M = {
                            negTitle: d.title || "",
                            negRole: I.substring(0, 2),
                            picList: p.picList || [],
                            submitTime: l.timeService.formatDateTime(l.timeService.newDate(h)),
                            styleClassName: l.getNegotiationStyle(I, t),
                            bizCode: u,
                            msgFromId: f,
                            msgId: S,
                            content: C,
                            commentEum: O,
                            showModifyAddr: D,
                            showEditNegotiationRecord: !!y,
                            withCopy: L,
                            isSystem: g,
                            isGroup: A,
                            userInfo: _,
                            postId: E,
                            isEdited: N
                        };
                        if (Reflect.has(d, "refundMark")) {
                            var b = l.getRefundInfo(d.refundMark || {}), P = b.remark, w = void 0 === P ? "" : P, U = b.picList, x = void 0 === U ? [] : U, F = b.videoList, k = void 0 === F ? [] : F;
                            M.content.remark = w, Object.assign(M, {
                                picList: x,
                                videoList: k
                            });
                        }
                        return M;
                    });
                }), c.switchMap(function(e) {
                    return l.getLogisticsTrackInfoFromNegotiationContent(e, i);
                }), c.catchError(function(e) {
                    return null == s || s(e), u.of([]);
                }));
            }, e.prototype.getNegotiationStyle = function(e, t) {
                var r, n, o = ((r = {})["顾客"] = "", r["团长"] = "leader", r["供货商"] = "supply-brand", 
                r["系统"] = "system", r), i = ((n = {})[a.AfterSalesRole.CUSTOMER] = "顾客", n[a.AfterSalesRole.GRANT] = "团长", 
                n[a.AfterSalesRole.MIDDLEMAN_SOURCE] = "团长", n[a.AfterSalesRole.MIDDLEMAN_FOLLOW] = "团长", 
                n[a.AfterSalesRole.MIDDLEMAN_START] = "团长", n[a.AfterSalesRole.MIDDLEMAN_SELLER] = "团长", 
                n[a.AfterSalesRole.SOURCE_OF_GOODS] = "供货商", n);
                return "我" === e ? o[i[t]] : o[e];
            }, e.prototype.getAsCarriageInfoObs = function(e, t) {
                var r = this, o = e.asCarriageContents, i = void 0 === o ? [] : o, s = e.orderNo, l = e.asRole, d = e.refundStatus, p = e.asStatus, f = (e.groupType, 
                e.groupId), h = t || {}, S = h.isCard, _ = void 0 !== S && S, E = h.isPc, y = void 0 !== E && E, T = h.isAgentAsOrder, R = void 0 !== T && T, v = h.isAgentLeader, g = void 0 !== v && v, m = (null == i ? void 0 : i.length) ? i[i.length - 1] : {}, O = m.carriageCompany, A = void 0 === O ? "" : O, I = m.carriageNo, C = void 0 === I ? "" : I, D = m.type, N = {
                    carriageCompany: A,
                    carriageNo: C,
                    carriageType: void 0 === D ? 0 : D
                };
                if (!N.carriageNo) return u.of({});
                if (10 !== N.carriageType || y) return u.of(n.__assign(n.__assign({}, N), {
                    isSendSelf: !0,
                    operations: n.__spread(200 === d && _ ? [] : [ this.getCarriageOperations().CARRIAGE_DETAIL ], l !== a.AfterSalesRole.CUSTOMER && ![ 20, 105 ].includes(e.groupType) || ![ 20, 10 ].includes(p) || _ || y ? [] : [ this.getCarriageOperations().EDIT_CARRIAGE ])
                }));
                var L = {
                    orderNo: s,
                    transportNo: N.carriageNo
                };
                return new u.Observable(function(e) {
                    r.api.customerSFEOrderStateUsingPOST(L, {
                        isSkipPageMarking: !0,
                        hideErrorToast: !0
                    }).pipe(c.map(function(e) {
                        return e.data || {};
                    }), c.catchError(function() {
                        return u.of(null);
                    })).subscribe(function(t) {
                        if (t) {
                            var o = t.orderStateCode, i = void 0 === o ? 0 : o, a = t.payStatus, s = void 0 === a ? 0 : a, u = t.empPhone, c = void 0 === u ? "" : u, p = t.ghCode, h = void 0 === p ? "" : p, S = r.getAsCarriageInfo(Number(i || 0), Number(s || 0), c, l, d, _, R, g, f, h), E = S.statusJudge, y = S.statusText, T = S.operations;
                            N = n.__assign(n.__assign({}, N), {
                                statusJudge: E,
                                statusText: y,
                                operations: T
                            });
                        }
                        e.next(N), e.complete();
                    });
                });
            }, e.prototype.getAsCarriageInfo = function(e, t, r, n, o, i, a, s, u, c) {
                void 0 === i && (i = !1);
                var l = this.getAsCarriageStatusJudge(e, t, r), d = this.getRefundCarriageStatusTextAndOperations(l, n, o, i, a, s, u, c);
                return {
                    statusJudge: l,
                    statusText: d.statusText,
                    operations: d.operations
                };
            }, e.prototype.getAsCarriageStatusJudge = function(e, t, r) {
                var n = 40 === t || 50 === t, o = 0 === t, i = !n && !o, a = 10 === e, s = 15 === e, u = !!r;
                return {
                    isWaitAllocate: a && !u && o,
                    isWaitPickUp: a && u && o,
                    isWaitPay: n,
                    isCancel: !a && !s,
                    isDeliver: s && i,
                    isHasPay: i
                };
            }, e.prototype.getRefundCarriageStatusTextAndOperations = function(e, t, r, n, o, i, s, u) {
                var c = e.isWaitAllocate, l = e.isWaitPickUp, d = e.isWaitPay, p = e.isCancel, f = e.isDeliver, h = this.getCarriageOperations(n), S = "", _ = [], E = t === a.AfterSalesRole.CUSTOMER;
                return E || s === u ? p ? (S = E ? "" : "待顾客寄出快递", _ = E ? [ h.return ] : []) : d ? (S = "待支付运费", 
                _ = E ? [ h.PAY_CARRIAGE ] : [ h.AGENT_PAY_CARRIAGE ]) : l ? (S = E ? "待快递员上门取件" : "待顾客寄出快递", 
                _ = [ h.PICK_UP_DETAIL ]) : c ? (S = "待分配快递员", _ = [ h.PICK_UP_DETAIL ]) : f && (_ = [ h.PAY_CARRIAGE_DETAIL, n ? {} : h.CARRIAGE_DETAIL ]) : c || l || d || p ? S = "待顾客寄出快递" : _ = [ h.CARRIAGE_DETAIL ], 
                {
                    statusText: S,
                    operations: _.filter(function(e) {
                        return !!e.key;
                    })
                };
            }, e.prototype.checkIsAgentAsOrder = function(e) {
                return 30 === e;
            }, e.prototype.checkIsAgentLeader = function(e, t, r, n) {
                return (null == e ? void 0 : e.agentOptGhId) === t && (20 !== r || !n || 0 === (null == e ? void 0 : e.ghViewType) || (null == e ? void 0 : e.ghViewType) === n);
            }, e.prototype.isCanShowEditNegotiationRecord = function(e, t, r, n) {
                var o = t.extJsonDTO, i = void 0 === o ? {} : o, s = t.msgContentDTO, u = (void 0 === s ? {} : s).extDTO, c = (void 0 === u ? {} : u).updateFlag, l = void 0 !== c && c, d = t.msgCreateTime, p = i.writerRole, f = void 0 === p ? "" : p, h = i.commentEum, S = void 0 === h ? "" : h, _ = i.title, E = void 0 === _ ? "" : _;
                return 0 === e && ![ a.AfterSalesRole.UN_KNOW, a.AfterSalesRole.CUSTOMER ].includes(r) && 20 === n && f === a.AfterSalesRoleText.ME && "text" === S && E.indexOf("回复") >= 0 && Date.now() - this.timeService.newDate(d).getTime() <= 864e5 && !l;
            }, e = n.__decorate([ o.Injectable({
                providedIn: "root"
            }), n.__metadata("design:paramtypes", [ i.TimeService, l.MonoUtilService ]) ], e);
        }();
        t.MonoOrderAfterSalesService = d;
    },
    107: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.ShareHttpClient = void 0;
        var n = r(0), o = r(1);
        n.__exportStar(r(14), t);
        var i = function() {
            function e() {}
            return e.prototype.setClient = function(e) {
                this.client = e;
            }, e.prototype.get = function(e, t, r) {
                if (!this.client) throw new Error("ShareHttpClient 还没有初始化（setClient）");
                return this.client.get(e, t, r);
            }, e.prototype.post = function(e, t, r) {
                if (!this.client) throw new Error("ShareHttpClient 还没有初始化（setClient）");
                return this.client.post(e, t, r);
            }, e.prototype.put = function(e, t, r) {
                if (!this.client) throw new Error("ShareHttpClient 还没有初始化（setClient）");
                return this.client.put(e, t, r);
            }, e.prototype.delete = function(e, t, r) {
                if (!this.client) throw new Error("ShareHttpClient 还没有初始化（setClient）");
                return this.client.delete(e, t, r);
            }, e.prototype.options = function(e, t, r) {
                if (!this.client) throw new Error("ShareHttpClient 还没有初始化（setClient）");
                return this.client.delete(e, t, r);
            }, e.prototype.head = function(e, t, r) {
                if (!this.client) throw new Error("ShareHttpClient 还没有初始化（setClient）");
                return this.client.delete(e, t, r);
            }, e.prototype.patch = function(e, t, r) {
                if (!this.client) throw new Error("ShareHttpClient 还没有初始化（setClient）");
                return this.client.delete(e, t, r);
            }, e = n.__decorate([ o.Injectable() ], e);
        }();
        t.ShareHttpClient = i;
    },
    11: function(t, r, n) {
        function o(e) {
            return e ? 1 === e.length ? e[0] : function(t) {
                return e.reduce(function(e, t) {
                    return t(e);
                }, t);
            } : s.noop;
        }
        Object.defineProperty(r, "__esModule", {
            value: !0
        }), r.MonoUtilService = r.COLOR = r.ZERO_WIDTH_SPACE = r.SERVICE_FEE_PERCENTAGE = r.COMMON_COMMISSION_MAX_WITH_SERVICE_FEE = r.MERCHANT_COMMISSION_MAX_WITH_SERVICE_FEE = r.COMMON_COMMISSION_MAX = r.ONE_POW_COMMISSION_MAX = r.ONE_POW_COMMISSION_MAX_REST = r.ONE_POW_MERCHANT_COMMISSION_MAX = r.MERCHANT_COMMISSION_MAX = r.FIVE_HOUR_TIME = r.TWO_HOUR_TIME = r.ONE_HOUR_TIME = r.SEVEN_DAY_TIME = r.THREE_DAY_TIME = r.ONE_DAY_TIME = r.INFINITY = r.pipeFromArray = void 0;
        var i = n(0), a = n(1), s = n(7), u = n(3);
        r.pipeFromArray = o, r.INFINITY = 1e8, r.ONE_DAY_TIME = 864e5, r.THREE_DAY_TIME = 2592e5, 
        r.SEVEN_DAY_TIME = 6048e5, r.ONE_HOUR_TIME = 36e5, r.TWO_HOUR_TIME = 72e5, r.FIVE_HOUR_TIME = 18e6, 
        r.MERCHANT_COMMISSION_MAX = 49, r.ONE_POW_MERCHANT_COMMISSION_MAX = 490, r.ONE_POW_COMMISSION_MAX_REST = 500, 
        r.ONE_POW_COMMISSION_MAX = 1e3, r.COMMON_COMMISSION_MAX = 99, r.MERCHANT_COMMISSION_MAX_WITH_SERVICE_FEE = 50, 
        r.COMMON_COMMISSION_MAX_WITH_SERVICE_FEE = 100, r.SERVICE_FEE_PERCENTAGE = 1, r.ZERO_WIDTH_SPACE = "​", 
        r.COLOR = {
            RED: "#FA5151",
            GREEN: "#09BA07",
            BLACK: "#000000"
        };
        var c = function() {
            function t() {
                this.EMOJI_REGEX = /(?:[\u231A\u231B\u23E9-\u23EC\u23F0\u23F3\u25FD\u25FE\u2614\u2615\u2648-\u2653\u267F\u2693\u26A1\u26AA\u26AB\u26BD\u26BE\u26C4\u26C5\u26CE\u26D4\u26EA\u26F2\u26F3\u26F5\u26FA\u26FD\u2705\u270A\u270B\u2728\u274C\u274E\u2753-\u2755\u2757\u2795-\u2797\u27B0\u27BF\u2B1B\u2B1C\u2B50\u2B55]|\uD83C[\uDC04\uDCCF\uDD8E\uDD91-\uDD9A\uDDE6-\uDDFF\uDE01\uDE1A\uDE2F\uDE32-\uDE36\uDE38-\uDE3A\uDE50\uDE51\uDF00-\uDF20\uDF2D-\uDF35\uDF37-\uDF7C\uDF7E-\uDF93\uDFA0-\uDFCA\uDFCF-\uDFD3\uDFE0-\uDFF0\uDFF4\uDFF8-\uDFFF]|\uD83D[\uDC00-\uDC3E\uDC40\uDC42-\uDCFC\uDCFF-\uDD3D\uDD4B-\uDD4E\uDD50-\uDD67\uDD7A\uDD95\uDD96\uDDA4\uDDFB-\uDE4F\uDE80-\uDEC5\uDECC\uDED0-\uDED2\uDED5-\uDED7\uDEDC-\uDEDF\uDEEB\uDEEC\uDEF4-\uDEFC\uDFE0-\uDFEB\uDFF0]|\uD83E[\uDD0C-\uDD3A\uDD3C-\uDD45\uDD47-\uDDFF\uDE70-\uDE7C\uDE80-\uDE88\uDE90-\uDEBD\uDEBF-\uDEC5\uDECE-\uDEDB\uDEE0-\uDEE8\uDEF0-\uDEF8])/, 
                this.PRICE_REGEX = "^([1-9]{1}[0-9]*)([.]{1}[0-9]{1,2})?$|^0([.]{1}[0-9]{1,2})?$", 
                this.COMMON_COMMISSION_REGEX = "^100$|^([1-9]{1}[0-9]?)([.]{1}[0-9]{1})?$|^0([.]{1}[0-9]{1})?$", 
                this.PRODUCT_COMMISSION_REGEX = "^90$|^[9]{1}([.]{1}[0-9]{1})?$|^([1-8]{1}[0-9]?)([.]{1}[0-9]{1})?$|^0([.]{1}[0-9]{1})?$", 
                this.ID_CARD_REGEX = "(^[1-9]d{5}(19|20)d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)d{3}[0-9Xx]$)|(^[1-9]d{5}d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)d{3}$)", 
                this.EMAIL_REGEX = new RegExp("^[A-Za-z0-9.一-龥_-]+@[a-zA-Z0-9一-龥_-]+(.[a-zA-Z0-9_-]+)+$"), 
                this.EXPRESS_COURSE_URL = "https://mp.weixin.qq.com/s/NUsxZPlcDj7q8gpmeu2aHw", this.CHINESE_NUMBER = {
                    0: "零",
                    1: "一",
                    2: "二",
                    3: "三",
                    4: "四",
                    5: "五",
                    6: "六",
                    7: "七",
                    8: "八",
                    9: "九",
                    10: "十"
                }, this.isUndefined = function(e) {
                    return void 0 === e;
                }, this.isObject = function(t) {
                    return t && "object" == (void 0 === t ? "undefined" : e(t));
                }, this.isEmpty = function(e) {
                    return !e && 0 !== e;
                };
            }
            return t.prototype.omit = function(t, r) {
                if ("object" != (void 0 === t ? "undefined" : e(t))) return {};
                if (!r) return t;
                var n = Object.assign({}, t);
                return [].concat(r).forEach(function(e) {
                    delete n[e];
                }), n;
            }, t.prototype.pick = function(t, r) {
                if ("object" != (void 0 === t ? "undefined" : e(t))) return {};
                if (!r) return t;
                var n = {};
                return [].concat(r).forEach(function(e) {
                    n[e] = t[e];
                }), n;
            }, t.prototype.pickObjectProperties = function(e, t) {
                var r, n, o = t.extract, a = t.exclude, s = this.jsonClone(e);
                if (a = a || [], !(o = o || []).length && !a.length) return s;
                var u = {};
                try {
                    for (var c = i.__values(Object.keys(s)), l = c.next(); !l.done; l = c.next()) {
                        var d = l.value;
                        o.length && a.length && o.includes(d) && !a.includes(d) && (u[d] = s[d]), o.length && !a.length && o.includes(d) && (u[d] = s[d]), 
                        o.length || !a.length || a.includes(d) || (u[d] = s[d]);
                    }
                } catch (e) {
                    r = {
                        error: e
                    };
                } finally {
                    try {
                        l && !l.done && (n = c.return) && n.call(c);
                    } finally {
                        if (r) throw r.error;
                    }
                }
                return u;
            }, t.prototype.deepClone = function(t) {
                var r = this;
                if (!t || "object" != (void 0 === t ? "undefined" : e(t))) return t;
                var n = Object.assign({}, t);
                return Object.keys(n).forEach(function(o) {
                    n[o] = "object" == e(t[o]) ? r.deepClone(t[o]) : t[o];
                }), t instanceof Array ? Array.from(i.__assign(i.__assign({}, n), {
                    length: t.length
                })) : n;
            }, t.prototype.jsonClone = function(e) {
                return e ? JSON.parse(JSON.stringify(e)) : e;
            }, t.prototype.queryString = function(e) {
                var t, r, n = [];
                if (e) try {
                    for (var o = i.__values(Object.entries(e)), a = o.next(); !a.done; a = o.next()) {
                        var s = i.__read(a.value, 2), u = s[0], c = s[1];
                        [ null, void 0 ].includes(c) || n.push(u + "=" + c);
                    }
                } catch (e) {
                    t = {
                        error: e
                    };
                } finally {
                    try {
                        a && !a.done && (r = o.return) && r.call(o);
                    } finally {
                        if (t) throw t.error;
                    }
                }
                return n.join("&");
            }, t.prototype.queryString2Object = function(e) {
                var t = {};
                return e ? (e.split("&").forEach(function(e) {
                    var r = i.__read(e.split("="), 2), n = r[0], o = r[1];
                    t[n] = o;
                }), t) : t;
            }, t.prototype.url2PathAndQuery = function(e) {
                var t = e.split("?"), r = {
                    path: t[0],
                    query: {}
                }, n = t[1];
                return n ? (n.split("&").forEach(function(e) {
                    var t = e.split("=");
                    r.query[t[0]] = t[1];
                }), r) : r;
            }, t.prototype.getPathList = function(e) {
                return e.split("/").filter(function(e) {
                    return !!e;
                });
            }, t.prototype.deleteProps = function(e, t) {
                this.isObject(e) && t.forEach(function(t) {
                    delete e[t];
                });
            }, t.prototype.isEmptyObject = function(e) {
                if (!this.isObject(e)) return !1;
                for (var t in e) if (e.hasOwnProperty(t)) return !1;
                return !0;
            }, t.prototype.isNumber = function(e, t) {
                if ("number" == typeof e) return !0;
                var r = void 0 === t || t.checkPositive, n = void 0 !== t && t.checkInteger;
                return new RegExp("^" + (r ? "" : "-?") + "([1-9]\\d*|0)" + (n ? "" : "(\\.\\d+)?") + "$").test(e);
            }, t.prototype.isDivisible = function(e, t) {
                var r = function(e) {
                    return (String(e).split(".")[1] || "").length;
                }, n = r(e), o = r(t), i = Math.max(n, o);
                return this.numberMovePoint(e, i, !0) % this.numberMovePoint(t, i, !0) == 0;
            }, t.prototype.isPhone = function(e) {
                return !(!e || !e.trim()) && (e = e.trim(), /^1\d{10}$/.test(e) || /^(0\d{2}-?\d{8})$|^(0\d{3}-?\d{7,8})$/.test(e) || /^400\d{7}$|^800\d{7}$/.test(e));
            }, t.prototype.isCaptcha = function(e) {
                return !(!e || !e.trim()) && (e = e.trim(), /^\d{4,6}$/.test(e));
            }, t.prototype.testNumAndCorrect = function(e, t, r) {
                if (void 0 === e && (e = ""), void 0 === t && (t = 0), void 0 === r && (r = Number.POSITIVE_INFINITY), 
                "string" != typeof e && (e = String(e)), !(e = e.replace(/[^0-9.]+/g, "")).length) return e;
                var n = e.split(".");
                if (1 === n.length) {
                    var o = Number(n[0]);
                    return o = o > r ? r : o, String(o);
                }
                var i = n[0] + (t ? "." : "") + n.filter(function(e, t) {
                    return t > 0;
                }).join("").substr(0, t);
                return Number(i) > r ? String(r) : i;
            }, t.prototype.numberMovePoint = function(e, t, r, n) {
                void 0 === e && (e = 0), void 0 === t && (t = 0);
                var o, i, a = Number(e) * Math.pow(10, t) || 0;
                return t >= 0 ? (o = Math.round(a), i = String(o)) : (i = n ? this.toFixedWithoutHalfAdjust(a, -t) : a.toFixed(-t), 
                o = Number(i)), r ? o : i;
            }, t.prototype.floatSum = function() {
                for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
                var r = e.reduce(function(e, t) {
                    var r, n = t.toString().split(".");
                    if (n.length > 2) throw new Error("不合法的浮点数 " + t);
                    var o = (null === (r = n[1]) || void 0 === r ? void 0 : r.length) || 0;
                    return o > e ? o : e;
                }, 0);
                return e.reduce(function(e, t) {
                    return e + Math.round(Number(t) * Math.pow(10, r));
                }, 0) / Math.pow(10, r);
            }, t.prototype.setDefaultValue = function(e, t) {
                return e ? t : void 0;
            }, t.prototype.getPercentMoney = function(e, t, r) {
                void 0 === r && (r = !1);
                var n = Math.round(100 * (e || 0)) * t / 1e3;
                return r ? (Math.ceil(n) / 100).toFixed(2) : (Math.floor(n) / 100).toFixed(2);
            }, t.prototype.getNumberLessThanZero = function(e, t) {
                void 0 === t && (t = !1);
                var r = Number(e || 0);
                return t ? r < 0 : r <= 0;
            }, t.prototype.isSupplyPriceMoreThanLessPrice = function(e, t, r) {
                void 0 === r && (r = !1);
                var n = r ? Number(e) : this.numberMovePoint(e, 2, !0), o = r ? this.numberMovePoint(t, 2, !0) : this.numberMovePoint(t, 4, !0);
                return this.numberMovePoint(n, 2, !0) <= o + n;
            }, t.prototype.getFileExtendName = function(e) {
                var t = /\.([^\.]+)$/.exec(e);
                return t ? t[1] : "";
            }, t.prototype.isUndefinedOrNull = function(e) {
                return null == e;
            }, t.prototype.deleteStrangeCharacters = function(e) {
                return void 0 === e && (e = ""), e.replace(/(\u2028)|(\u000a)/g, "");
            }, t.prototype.safeJSONParse = function(e, t) {
                void 0 === e && (e = ""), void 0 === t && (t = {});
                try {
                    return JSON.parse(this.deleteStrangeCharacters(e || JSON.stringify(t)));
                } catch (e) {
                    return t;
                }
            }, t.prototype.toFixed = function(e, t, r) {
                var n = r && r.keepZero || !1, o = r && r.approximation || "round", i = r && r.resultType || "string";
                if ("string" !== i && n) throw new Error("只有 string 类型可以保留末尾的 0");
                var a = Number(e);
                if (!a && 0 !== a) throw new Error(e + " 不能转换为数字");
                r && r.pow && (a = this.numberMovePoint(a, r.pow, !0));
                var s = Math.pow(10, t), u = (Math[o](a * s) / s).toFixed(t);
                return "string" === i ? n ? u : String(Number(u)) : Number(u);
            }, t.prototype.toFixedWithoutHalfAdjust = function(e, t) {
                var r = String(e), n = r.split("."), o = t || 2;
                if (1 === n.length) {
                    for (var i = 0; i < o; i++) ;
                    return r + ".0";
                }
                return n[0] + "." + n[1].slice(0, o);
            }, t.prototype.getNumberRegExp = function(e, t, r) {
                void 0 === e && (e = 9), void 0 === t && (t = 2), void 0 === r && (r = !1);
                var n = "";
                return t > 0 && (n = r ? "(.[0-9]{" + t + "})" : "(.[0-9]{1," + t + "})?"), e <= 0 ? "^0" + n + "$" : e <= 1 ? "^[0-9]" + n + "$" : r ? "^[1-9]([0-9]{" + (e - 1) + "})" + n + "$" : "^[1-9]([0-9]{1," + (e - 1) + "})?" + n + "$|^0" + n + "$";
            }, t.prototype.formatRegExpSpecialSymbol = function(e) {
                return e.replace(/[-\/\\^$*+?.()|[\]{}]/g, "\\$&");
            }, t.prototype.formatNumberUnit = function(e) {
                var t = e.num, r = e.isEnglish, n = e.isAddPlus, o = e.unit, i = void 0 === o ? "" : o, a = e.fixed, s = void 0 === a ? 0 : a, u = e.approximation, c = void 0 === u ? "round" : u, l = r ? "k" : "千", d = r ? "w" : "万", p = n ? "+" : "";
                return t < 1e3 ? t + i : t < 9999 ? this.toFixed(t / 1e3, s, {
                    approximation: c
                }) + l + p + i : this.toFixed(t / 1e4, s, {
                    approximation: c
                }) + d + p + i;
            }, t.prototype.findLast = function(e, t) {
                if (e && Array.isArray(e) && e.length) for (var r = e.length - 1; r >= 0; r--) if (t(e[r], r, e)) return e[r];
            }, t.prototype.findLastIndex = function(e, t) {
                if (!e || !Array.isArray(e) || !e.length) return -1;
                for (var r = e.length - 1; r >= 0; r--) if (t(e[r], r, e)) return r;
                return -1;
            }, t.prototype.includesOneOfArray = function(e, t) {
                return void 0 === e && (e = []), void 0 === t && (t = []), t.some(function(t) {
                    return e.includes(t);
                });
            }, t.prototype.includesEveryOfArray = function(e, t) {
                return void 0 === e && (e = []), void 0 === t && (t = []), t.every(function(t) {
                    return e.includes(t);
                });
            }, t.prototype.isSameObject = function(e, t) {
                return JSON.stringify(e) === JSON.stringify(t);
            }, t.prototype.mapObject = function(e, t) {
                var r = i.__assign({}, e);
                return Object.keys(e).forEach(function(n) {
                    r[n] = t(n, e[n]);
                }), r;
            }, t.prototype.sliceString = function(e, t, r) {
                void 0 === e && (e = ""), void 0 === t && (t = e.length), void 0 === r && (r = {});
                var n = r.isShowEllipsis, o = void 0 === n || n ? "..." : "";
                return e.length > t ? e.slice(0, t) + o : e;
            }, t.prototype.randomNumBetween = function(e, t) {
                void 0 === e && (e = 0), void 0 === t && (t = 1e5);
                for (var r = Math.floor(Math.random() * (t - e + 1)) + e; r === t + 1; ) r = Math.floor(Math.random() * (t - e + 1)) + e;
                return r;
            }, t.prototype.randomLowerCaseLetter = function() {
                var e = this.randomNumBetween(0, 25), t = "a".charCodeAt(0);
                return String.fromCharCode(t + e);
            }, t.prototype.generateId = function() {
                return 1e4 * Date.now() + Math.round(1e4 * Math.random());
            }, t.prototype.compareObjects = function(t, r) {
                var n = this, o = !0;
                return Object.keys(t).forEach(function(i) {
                    if (t[i] !== r[i]) {
                        var a = e(t[i]), s = e(r[i]);
                        if ("function" === a) throw TypeError("比较对象中暂不支持包含函数 " + i);
                        a === s && ("number" === a && isNaN(t[i]) && isNaN(r[i]) || "object" === a && null !== t[i] && null !== r[i] && n.compareObjects(t[i], r[i])) || (o = !1);
                    }
                }), o;
            }, t.prototype.pollRequest = function(e) {
                var t = this, r = e.requestObs, n = e.finishCondition, i = e.intervalTime, a = void 0 === i ? 2e3 : i, c = e.takeUntilObs, l = e.takeCount, d = e.timeoutTime, p = e.shouldEmitAllPollingRes, f = [];
                c && f.push(u.takeUntil(c)), l && f.push(u.take(l)), d && f.push(u.timeout(d));
                var h = !1;
                return new s.Observable(function(e) {
                    var i = s.interval(a).pipe(o(f), u.switchMap(function() {
                        return t.checkIsRequestObsFunc(r) ? r() : r;
                    })).subscribe({
                        next: function(t) {
                            if (n(t)) return h = !0, e.next(t), e.complete(), void i.unsubscribe();
                            p && e.next(t);
                        },
                        error: function(t) {
                            e.error({
                                errorType: t instanceof s.TimeoutError ? "timeout" : "http",
                                error: t
                            });
                        },
                        complete: function() {
                            h || (h = !0, e.error({
                                errorType: "take",
                                error: {}
                            }));
                        }
                    });
                });
            }, t.prototype.getFilterListWithKeyword = function(e, t, r, n) {
                if (!e.length) return e;
                if ("string" != typeof e[0][t]) return e;
                var o = r.replace(/ /g, "");
                if (!o) return e;
                var i = this.getKeywordSearchPattern(o, n);
                return e.filter(function(e) {
                    return i.test(e[t] || "");
                });
            }, t.prototype.getKeywordSearchPattern = function(e, t) {
                var r, n = this, o = t || {
                    regFlags: "i"
                }, i = o.isFuzzy, a = o.regFlags, s = void 0 === a ? "i" : a;
                return r = i ? "" + e.split("").map(function(e) {
                    return "(" + n.formatRegExpSpecialSymbol(e) + ")";
                }).join("(.*?)") : "(" + this.formatRegExpSpecialSymbol(e) + ")", new RegExp(r, s);
            }, t.prototype.uniqueArray = function(t, r) {
                var n = this, o = new Set(), i = [];
                return t.forEach(function(t) {
                    var a = r ? t[r] : (void 0 === t ? "undefined" : e(t)) + JSON.stringify(t);
                    !n.isUndefinedOrNull(a) && o.has(a) || (o.add(a), i.push(t));
                }), i;
            }, t.prototype.uniqueArrayKeepLast = function(t, r) {
                var n = this;
                return t.reduceRight(function(t, o) {
                    var i = r ? o[r] : (void 0 === o ? "undefined" : e(o)) + JSON.stringify(o);
                    return t.set.has(i) && !n.isUndefinedOrNull(i) || (t.set.add(i), t.newArray.push(o)), 
                    t;
                }, {
                    newArray: [],
                    set: new Set()
                }).newArray.reverse();
            }, t.prototype.sliceArrayToFixedLength = function(e, t) {
                for (var r = [], n = 0; n < e.length; ) r.push(e.slice(n, n += t));
                return r;
            }, t.prototype.mergeSort = function(e, t) {
                return this.selfMergeSoft(e, t);
            }, t.prototype.isEmojiChar = function(e) {
                return this.EMOJI_REGEX.test(e);
            }, t.prototype.clearEmojiChar = function(e) {
                return void 0 === e && (e = ""), e.replace(this.EMOJI_REGEX, "");
            }, t.prototype.selfMergeSoft = function(e, t) {
                var r = e.length;
                if (r < 2) return e;
                var n = Math.floor(r / 2);
                return this.mergeLeftAndRight(this.selfMergeSoft(e.slice(0, n), t), this.selfMergeSoft(e.slice(n), t), t);
            }, t.prototype.mergeLeftAndRight = function(e, t, r) {
                for (var n = []; e.length && t.length; ) {
                    var o = r(e[0], t[0]), a = "number" == typeof o ? o > 0 : o;
                    n.push(a ? t.shift() : e.shift());
                }
                return e.length && n.push.apply(n, i.__spread(e)), t.length && n.push.apply(n, i.__spread(t)), 
                n;
            }, t.prototype.checkIsRequestObsFunc = function(e) {
                return e instanceof Function;
            }, t = i.__decorate([ a.Injectable() ], t);
        }();
        r.MonoUtilService = c;
    },
    113: function(e, t, r) {
        var n, o, i, a;
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.SETTING_TYPE_2_MULTI_PROPERTIES = t.SETTING_TYPE_2_SINGLE_PROPERTIES = t.MULTI_POW_MAP = t.SINGLE_POW_MAP = t.DEFAULT_EMPTY_PRODUCT = t.FLAT_PRODUCT_KEY_OBJ = t.IFlatProductType = void 0, 
        function(e) {
            e.LEADER_HELP_COMMISSION = "0", e.LEADER_HELP_SUPPLY = "1", e.PROMOTERS_COMMISSION = "2", 
            e.PROMOTERS_SUPPLY = "3", e.PROMOTERS_GROUP_BUY = "4", e.START_GROUP_GRANDCHILD_COMMISSION = "5", 
            e.START_GROUP_GRANDCHILD_SUPPLY = "6", e.TOGETHER_BUY = "7", e.SUPPLY_PRICE = "8", 
            e.FOLLOW_COMMISSION = "9", e.FOLLOW_LEADER_HELP_COMMISSION = "10";
        }(a = t.IFlatProductType || (t.IFlatProductType = {})), t.FLAT_PRODUCT_KEY_OBJ = ((n = {})[a.LEADER_HELP_COMMISSION] = {
            productKey: "actCommissionPercent",
            moreUnitKey: "commissionPercent",
            placeholder: "请输入"
        }, n[a.LEADER_HELP_SUPPLY] = {
            productKey: "actCostPrice",
            moreUnitKey: "costPrice",
            placeholder: "请输入批发价"
        }, n[a.PROMOTERS_COMMISSION] = {
            productKey: "promoterCommissionPercent",
            moreUnitKey: "promoterCommissionPercent",
            placeholder: "请输入比例"
        }, n[a.PROMOTERS_SUPPLY] = {
            productKey: "promoterCommission",
            moreUnitKey: "promoterCommission",
            placeholder: "请输入佣金"
        }, n[a.PROMOTERS_GROUP_BUY] = {
            productKey: "promoterCommission",
            moreUnitKey: "promoterCommission",
            placeholder: "请输入佣金"
        }, n[a.START_GROUP_GRANDCHILD_SUPPLY] = {
            productKey: "grandSonSaleCommission",
            moreUnitKey: "grandSonSaleCommission",
            placeholder: "请输入佣金"
        }, n[a.START_GROUP_GRANDCHILD_COMMISSION] = {
            productKey: "grandSonSaleCommissionPercent",
            moreUnitKey: "grandSonSaleCommissionPercent",
            placeholder: "请输入比例"
        }, n[a.TOGETHER_BUY] = {
            productKey: "coopGroupPrice",
            moreUnitKey: "coopGroupPrice",
            placeholder: "请输入"
        }, n[a.SUPPLY_PRICE] = {
            productKey: "supplyPrice",
            moreUnitKey: "supplyPrice",
            placeholder: "请输入"
        }, n[a.FOLLOW_COMMISSION] = {
            productKey: "followCommissionPercent",
            moreUnitKey: "followCommissionPercent",
            placeholder: "请输入比例"
        }, n[a.FOLLOW_LEADER_HELP_COMMISSION] = {
            productKey: "actCommissionPercent",
            moreUnitKey: "commissionPercent",
            placeholder: "没有任何作用，不用管"
        }, n), t.DEFAULT_EMPTY_PRODUCT = {
            goodsDimensionInfoList: void 0,
            goodsId: 0,
            useStock: 0,
            goodsPicList: void 0,
            costPrice: "",
            groupBuyPrice: "",
            originalPrice: "",
            commissionPercent: "",
            totalStock: void 0,
            unitInfoList: void 0,
            realInCome: "0.00"
        }, t.SINGLE_POW_MAP = {
            promoterCommission: 2,
            promoterCommissionPercent: 1,
            grandSonSaleCommission: 2,
            grandSonSaleCommissionPercent: 1,
            coopGroupPrice: 2,
            followCommissionPercent: 1
        }, t.MULTI_POW_MAP = {
            costPrice: 2,
            commissionPercent: 1,
            promoterCommission: 2,
            promoterCommissionPercent: 1,
            grandSonSaleCommission: 2,
            grandSonSaleCommissionPercent: 1,
            coopGroupPrice: 2,
            supplyPrice: 2,
            followCommissionPercent: 1
        }, t.SETTING_TYPE_2_SINGLE_PROPERTIES = ((o = {})[1] = [ "actCostPrice", "actCommissionPercent" ], 
        o[2] = [ "promoterCommission", "promoterCommissionPercent" ], o[3] = [ "grandSonSaleCommission", "grandSonSaleCommissionPercent" ], 
        o[4] = [ "coopGroupPrice" ], o[5] = [ "supplyPrice" ], o[6] = [ "followCommissionPercent" ], 
        o), t.SETTING_TYPE_2_MULTI_PROPERTIES = ((i = {})[1] = [ "costPrice", "commissionPercent" ], 
        i[2] = [ "promoterCommission", "promoterCommissionPercent" ], i[3] = [ "grandSonSaleCommission", "grandSonSaleCommissionPercent" ], 
        i[4] = [ "coopGroupPrice" ], i[5] = [ "supplyPrice" ], i[6] = [ "followCommissionPercent" ], 
        i);
    },
    116: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.MonoRichTextService = t.defaultRichTextEmptyItem = void 0;
        var n = r(0), o = r(1), i = r(7), a = r(3), s = r(59), u = r(24), c = r(682), l = r(11), d = r(435);
        t.defaultRichTextEmptyItem = {
            mediaType: "text",
            content: ""
        };
        var p = [ "singleImg", "multiImg", "video" ], f = function(e) {
            function r(t, r, n) {
                var o = e.call(this, t) || this;
                return o.errorService = t, o.monoUtilService = r, o.monoFileService = n, o.imageInfoMap = {}, 
                o;
            }
            return n.__extends(r, e), r.prototype.correctRichTextListWhenAddProduct = function(e, t) {
                if (!t.goodsInfo) return e;
                var r = {
                    mediaType: "goodsInfo",
                    goodsInfo: {
                        goodsId: t.goodsId,
                        goodsName: t.goodsName,
                        goodsInfoDetails: JSON.parse(t.goodsInfo)
                    }
                };
                return e.length && this.checkIsFirstItemEmpty(e) ? e.splice(0, 1, r) : e.push(r), 
                e;
            }, r.prototype.correctRichTextListWhenUpdateProduct = function(e, t, r) {
                void 0 === r && (r = "goodsName");
                var n = e.find(function(e) {
                    var r;
                    return "goodsInfo" === e.mediaType && (null === (r = e.goodsInfo) || void 0 === r ? void 0 : r.goodsId) === t.goodsId;
                });
                return n && (n.goodsInfo.goodsName = String(t[r])), e;
            }, r.prototype.correctRichTextListWhenDeleteProduct = function(e, t) {
                var r = e.filter(function(e) {
                    var r;
                    return "goodsInfo" !== e.mediaType || (null === (r = e.goodsInfo) || void 0 === r ? void 0 : r.goodsId) !== t;
                });
                return r.length ? r : this.getDefaultRichTextList();
            }, r.prototype.correctRichTextListWhenDeleteProductList = function(e, t) {
                var r = e.filter(function(e) {
                    var r;
                    return "goodsInfo" !== e.mediaType || !t.includes((null === (r = e.goodsInfo) || void 0 === r ? void 0 : r.goodsId) || 0);
                });
                return r.length ? r : this.getDefaultRichTextList();
            }, r.prototype.resetGoodsIdWhenDeleteProduct = function(e, t) {
                var r = e.find(function(e) {
                    var r;
                    return "goodsInfo" === e.mediaType && (null === (r = e.goodsInfo) || void 0 === r ? void 0 : r.goodsId) === t;
                });
                return r && (r.goodsInfo = n.__assign(n.__assign({}, r.goodsInfo || {
                    goodsInfoDetails: []
                }), {
                    goodsId: +new Date(),
                    goodsName: ""
                })), e;
            }, r.prototype.getDefaultRichTextList = function() {
                return [ n.__assign({}, t.defaultRichTextEmptyItem) ];
            }, r.prototype.getRichTextListForInit = function(e, t) {
                var r, o, i, a = [];
                try {
                    for (var s = n.__values(e), u = s.next(); !u.done; u = s.next()) !function(e) {
                        if ("goodsInfo" === e.mediaType && (null === (i = e.goodsInfo) || void 0 === i ? void 0 : i.goodsId)) {
                            var r = t.find(function(t) {
                                return t.goodsId === e.goodsInfo.goodsId;
                            });
                            r && (e.goodsInfo.goodsName = r.goodsName);
                        }
                        a.push(e);
                    }(u.value);
                } catch (e) {
                    r = {
                        error: e
                    };
                } finally {
                    try {
                        u && !u.done && (o = s.return) && o.call(s);
                    } finally {
                        if (r) throw r.error;
                    }
                }
                return a;
            }, r.prototype.generateRichTextImageInfoMap = function(e) {
                var t = this, r = e.reduce(function(e, t) {
                    var r, n;
                    return "singleImg" !== t.mediaType || !t.content || (null === (r = t.qjlImageInfo) || void 0 === r ? void 0 : r.width) && (null === (n = t.qjlImageInfo) || void 0 === n ? void 0 : n.height) ? e : e.concat(t.content);
                }, []);
                i.from(r.map(function(e) {
                    return t.monoFileService.getAliYunImageInfo(e);
                })).pipe(a.concatAll()).subscribe(function(e) {
                    t.imageInfoMap[e.url] = {
                        width: e.width,
                        height: e.height
                    };
                });
            }, r.prototype.getRichTextToConfirm = function(e, t) {
                var r = this;
                return (e = this.monoUtilService.jsonClone(e)).map(function(e) {
                    var o = e.mediaType;
                    if (delete e.id, "activity" === o && t) return n.__assign(n.__assign({}, e), {
                        activityCardInfo: {
                            actId: e.activityCardInfo.actId,
                            ownerRole: e.activityCardInfo.ownerRole || r.getCardOwnerRole(t)
                        }
                    });
                    if ("nameCard" === o && t) return n.__assign(n.__assign({}, e), {
                        nameCardInfo: {
                            id: e.nameCardInfo.id,
                            ownerRole: e.nameCardInfo.ownerRole || r.getCardOwnerRole(t)
                        }
                    });
                    if ("liveCard" === o) return n.__assign(n.__assign({}, e), {
                        liveCardInfo: {
                            id: e.liveCardInfo.id
                        }
                    });
                    if ("goodsInfo" === o) return n.__assign(n.__assign({}, e), {
                        goodsInfo: {
                            goodsId: e.goodsInfo.goodsId,
                            goodsInfoDetails: e.goodsInfo.goodsInfoDetails
                        }
                    });
                    if ("singleImg" === o) {
                        var i = r.imageInfoMap[e.content] || e.qjlImageInfo;
                        return delete r.imageInfoMap[e.content], delete e.imageInfo, n.__assign(n.__assign({}, e), {
                            qjlImageInfo: i
                        });
                    }
                    return e;
                });
            }, r.prototype.getCardOwnerRole = function(e) {
                return 20 === e || 160 === e ? s.ActivityOwnerRole.CHILD : 210 === e ? s.ActivityOwnerRole.GRANDCHILD : s.ActivityOwnerRole.PARENT;
            }, r.prototype.generateRichTextId = function() {
                return this.monoUtilService.generateId();
            }, r.prototype.checkIsFirstItemEmpty = function(e) {
                var r = e[0], n = r.mediaType === t.defaultRichTextEmptyItem.mediaType && r.content === t.defaultRichTextEmptyItem.content;
                return !r || n;
            }, r.prototype.checkIsRichTextListEmpty = function(e, t) {
                return void 0 === t && (t = !1), !(null == e ? void 0 : e.length) || !t && 1 === e.length && this.checkIsFirstItemEmpty(e);
            }, r.prototype.getMaterialInfoForShow = function(e) {
                var t, r, o, i, a = {
                    firstText: "",
                    mediaList: []
                };
                if (!e.length) return a;
                try {
                    for (var s = n.__values(e), u = s.next(); !u.done; u = s.next()) {
                        var c = u.value;
                        if (a.firstText && a.mediaList.length >= 3) break;
                        if ("text" !== c.mediaType || a.firstText || (a.firstText = c.content), p.includes(c.mediaType) && a.mediaList.length < 3) {
                            var l = (null === (i = c.contentList) || void 0 === i ? void 0 : i.length) ? c.contentList.map(function(e) {
                                return e.content;
                            }) : c.content ? [ c.content ] : [];
                            (o = a.mediaList).push.apply(o, n.__spread(l));
                        }
                    }
                } catch (e) {
                    t = {
                        error: e
                    };
                } finally {
                    try {
                        u && !u.done && (r = s.return) && r.call(s);
                    } finally {
                        if (t) throw t.error;
                    }
                }
                return a.mediaList.length && (a.mediaList = a.mediaList.slice(0, 3)), a;
            }, r.prototype.setRichTextCardApi = function(e) {
                var t = this;
                return this.richTextCardApiConfig = e, function() {
                    t.richTextCardApiConfig === e && (t.richTextCardApiConfig = void 0);
                };
            }, r.prototype.getProcessedRichTextList = function(e, t) {
                var r = this;
                return void 0 === e && (e = []), e.length ? i.forkJoin(e.map(function(e) {
                    return r.updateRichTextCardFromBackEnd(e, t).pipe(a.map(function(e) {
                        return r.addRichTextId(e);
                    }));
                })).pipe(a.map(function(e) {
                    return r.correctRichTextList(e);
                }), a.map(function(e) {
                    return r.filterDeletedCard(e);
                }), a.catchError(function(t) {
                    return r.errorService.customReportError({
                        frontErrorCode: 4e3,
                        error: t
                    }), i.of(e);
                })) : i.of([]);
            }, r.prototype.updateRichTextCardFromBackEnd = function(e, t) {
                var r = this, n = e.mediaType;
                return (!(null == t ? void 0 : t.length) || t.includes(n) ? "activity" === n ? this.getActivityCardObs(e) : "nameCard" === n ? this.getNameCardObs(e) : "liveCard" === n ? this.getLiveCardObs(e) : i.of(e) : i.of(e)).pipe(a.catchError(function(t) {
                    return r.errorService.customReportError({
                        frontErrorCode: 4e3,
                        error: t
                    }), i.of(e);
                }));
            }, r.prototype.getLiveCardObs = function(e) {
                var t, r, o;
                return (null === (t = e.liveCardInfo) || void 0 === t ? void 0 : t.id) ? (null === (r = this.richTextCardApiConfig) || void 0 === r ? void 0 : r.getLiveCardApi) ? null === (o = this.richTextCardApiConfig) || void 0 === o ? void 0 : o.getLiveCardApi({
                    idList: [ e.liveCardInfo.id ]
                }).pipe(a.map(function(t) {
                    var r, o = null === (r = t.data) || void 0 === r ? void 0 : r[0];
                    return o ? n.__assign(n.__assign({}, e), {
                        liveCardInfo: {
                            id: o.id,
                            name: o.roomName || "",
                            roomNo: o.roomNumber || "",
                            groupIds: o.ghIdList || "",
                            coverUrl: o.liveCover || "",
                            bannerUrl: o.liveBanner || ""
                        }
                    }) : n.__assign(n.__assign({}, e), {
                        isDeleted: !0
                    });
                })) : (this.errorService.customReportError({
                    frontErrorCode: 4016,
                    errorMsg: "直播卡片没有设置api",
                    extraInfo: {
                        richTextItem: e
                    }
                }), i.of(e)) : (this.errorService.customReportError({
                    frontErrorCode: 4005,
                    errorMsg: "直播卡片没有id",
                    extraInfo: {
                        richTextItem: e
                    }
                }), i.of(e));
            }, r.prototype.getNameCardObs = function(e) {
                var t, r;
                return (null === (t = e.nameCardInfo) || void 0 === t ? void 0 : t.id) ? (null === (r = this.richTextCardApiConfig) || void 0 === r ? void 0 : r.getNameCardApi) ? this.richTextCardApiConfig.getNameCardApi(String(e.nameCardInfo.id)).pipe(a.map(function(t) {
                    var r = t.data;
                    if (!r) return n.__assign(n.__assign({}, e), {
                        isDeleted: !0
                    });
                    var o = 5 === r.delFlag;
                    return n.__assign(n.__assign({}, e), {
                        isDeleted: o,
                        nameCardInfo: {
                            id: r.id,
                            type: r.selectType,
                            url: r.url,
                            qrCodeUrl: r.qrCodeUrl,
                            name: r.selectName,
                            description: r.quote,
                            ownerRole: e.nameCardInfo.ownerRole,
                            isDeleted: o
                        }
                    });
                })) : (this.errorService.customReportError({
                    frontErrorCode: 4016,
                    errorMsg: "快捷加粉没有设置api",
                    extraInfo: {
                        richTextItem: e
                    }
                }), i.of(e)) : (this.errorService.customReportError({
                    frontErrorCode: 4005,
                    errorMsg: "快捷加粉没有id",
                    extraInfo: {
                        richTextItem: e
                    }
                }), i.of(e));
            }, r.prototype.getActivityCardObs = function(e) {
                var t, r;
                return (null === (t = e.activityCardInfo) || void 0 === t ? void 0 : t.actId) ? (null === (r = this.richTextCardApiConfig) || void 0 === r ? void 0 : r.getActivityCardApi) ? this.richTextCardApiConfig.getActivityCardApi({
                    actIds: [ e.activityCardInfo.actId ]
                }).pipe(a.map(function(t) {
                    var r, o = null === (r = t.data) || void 0 === r ? void 0 : r[0];
                    return o ? n.__assign(n.__assign({}, e), {
                        activityCardInfo: n.__assign({
                            ownerRole: e.activityCardInfo.ownerRole
                        }, o)
                    }) : e;
                })) : (this.errorService.customReportError({
                    frontErrorCode: 4016,
                    errorMsg: "活动卡片没有设置api",
                    extraInfo: {
                        richTextItem: e
                    }
                }), i.of(e)) : (this.errorService.customReportError({
                    frontErrorCode: 4005,
                    errorMsg: "活动卡片没有id",
                    extraInfo: {
                        richTextItem: e
                    }
                }), i.of(e));
            }, r.prototype.filterDeletedCard = function(e) {
                return e.filter(function(e) {
                    return !e.isDeleted;
                });
            }, r.prototype.addRichTextId = function(e) {
                return e.id || (e.id = this.generateRichTextId()), e;
            }, r = n.__decorate([ o.Injectable({
                providedIn: "root"
            }), n.__metadata("design:paramtypes", [ u.ErrorService, l.MonoUtilService, d.MonoFileService ]) ], r);
        }(c.MonoRichTextCorrector);
        t.MonoRichTextService = f;
    },
    1175: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.MonoProductProcessService = void 0;
        var n = r(0), o = r(1), i = r(11), a = function() {
            function e(e) {
                this.monoUtilService = e;
            }
            return e.prototype.getMultiTotalStock = function(e) {
                var t = e.mutiGoodsInfoDTO.skuGoodsPropertyDTOList;
                if (1 !== (null == t ? void 0 : t.length)) return "";
                var r = t[0];
                return this.monoUtilService.isEmpty(r.totalStock) || this.monoUtilService.isEmpty(r.useStock) ? "" : String(r.totalStock - r.useStock > 9999999 ? "不限" : r.totalStock - r.useStock);
            }, e = n.__decorate([ o.Injectable({
                providedIn: "root"
            }), n.__metadata("design:paramtypes", [ i.MonoUtilService ]) ], e);
        }();
        t.MonoProductProcessService = a;
    },
    120: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.RegionSelectorService = t.DeliveryTypeEnum = t.FreightFreeLimitType = t.FreightChargeType = t.CheckStatusEnum = t.RegionSelectorType = void 0;
        var n, o, i, a, s, u, c = r(0), l = r(1), d = r(7), p = r(3), f = r(11);
        !function(e) {
            e[e.SPECIFIC_TEMPLATE = 1] = "SPECIFIC_TEMPLATE", e[e.COMMON_NO_DELIVERY = 2] = "COMMON_NO_DELIVERY";
        }(n = t.RegionSelectorType || (t.RegionSelectorType = {})), function(e) {
            e[e.ALL = 0] = "ALL", e[e.NOT_ALL = 1] = "NOT_ALL", e[e.NONE = 2] = "NONE", e[e.DISABLED = 3] = "DISABLED", 
            e[e.HIDDEN = 4] = "HIDDEN";
        }(o = t.CheckStatusEnum || (t.CheckStatusEnum = {})), function(e) {
            e[e.CARRIAGE = 10] = "CARRIAGE", e[e.BUY_NUMBER = 20] = "BUY_NUMBER", e[e.BUY_WEIGHT = 30] = "BUY_WEIGHT";
        }(i = t.FreightChargeType || (t.FreightChargeType = {})), function(e) {
            e[e.LIMIT_PRICE = 10] = "LIMIT_PRICE", e[e.LIMIT_UNIT = 20] = "LIMIT_UNIT", e[e.LIMIT_WEIGHT = 30] = "LIMIT_WEIGHT";
        }(a = t.FreightFreeLimitType || (t.FreightFreeLimitType = {})), function(e) {
            e[e.FREE = 1] = "FREE", e[e.NO_DELIVERY = 2] = "NO_DELIVERY", e[e.SPECIAL_DELIVERY = 3] = "SPECIAL_DELIVERY";
        }(s = t.DeliveryTypeEnum || (t.DeliveryTypeEnum = {}));
        var h = {}, S = {}, _ = function() {
            function e(e) {
                this.monoUtil = e, this.INIT_AREA_LIST_OBS_ERROR = "请先 setAreaListObs", this.checkedListSubject = new d.Subject(), 
                this.checkNumberSubject = new d.Subject(), this.linealStateNotifySubject = new d.Subject(), 
                this.leafNodeTotalCount = 0, this.leafDisabledList = new Set(), this.leafCheckedList = new Set(), 
                this.leafHiddenList = new Set(), this.leafRepeatableList = new Set(), this.leafDisabledListTmp = [], 
                this.leafCheckedListTmp = [], this.leafHiddenListTmp = [], this.leafRepeatableListTmp = [], 
                this.checkedListObs = this.checkedListSubject.asObservable(), this.checkNumberObs = this.checkNumberSubject.asObservable(), 
                this.linealStateNotifyObs = this.linealStateNotifySubject.asObservable();
            }
            return e.prototype.setAreaListObs = function(e) {
                this.getRegionDataObs = e;
            }, e.prototype.presetNodeOriginalState = function(e) {
                var t = e.disabled, r = void 0 === t ? [] : t, n = e.checked, o = void 0 === n ? [] : n, i = e.hidden, a = void 0 === i ? [] : i, s = e.repeatableIds, u = void 0 === s ? [] : s, l = e.isAssignOpt, d = void 0 !== l && l, p = function(e, t) {
                    return void 0 === e && (e = []), void 0 === t && (t = []), d ? c.__spread(e, t) : t;
                };
                this.leafDisabledListTmp = p(this.leafDisabledListTmp, r), this.leafCheckedListTmp = p(this.leafCheckedListTmp, o), 
                this.leafHiddenListTmp = p(this.leafHiddenListTmp, a), this.leafRepeatableListTmp = p(this.leafRepeatableListTmp, u);
            }, e.prototype.getRegionData = function(e, t) {
                var r = this;
                return void 0 === e && (e = !1), void 0 === t && (t = !1), u && u.length && !e ? (t && this.refreshRegionStatus(), 
                d.of(u)) : this.getRegionDataObs ? this.getRegionDataObs.pipe(p.map(function(e) {
                    if (!e.data) return [];
                    r.leafNodeTotalCount = 0;
                    var t = e.data;
                    return u = r.initCustomRegionData(t), r.refreshRegionStatus(), u;
                })) : (u = [], d.of([]));
            }, e.prototype.convertCityIdsToCountyIds = function(e) {
                if (!e) return {};
                var t = e.countyIds, r = e.cityIds;
                return t || !r ? e : c.__assign(c.__assign({}, e), {
                    countyIds: this.parseCityIdsToCountyIds(r)
                });
            }, e.prototype.getLeafNodeCheckedNumber = function() {
                return this.leafCheckedList.size ? new Set(c.__spread(this.leafCheckedList, this.leafHiddenList)).size - this.leafHiddenList.size : this.leafCheckedList.size || 0;
            }, e.prototype.getLeafNodeCheckedIds = function() {
                return Array.from(this.leafCheckedList);
            }, e.prototype.isSelectAll = function() {
                return this.leafCheckedList.size + this.leafDisabledList.size + this.leafHiddenList.size >= this.leafNodeTotalCount;
            }, e.prototype.toggleNodeCheckState = function(e) {
                var t, r = (e = Object.assign({
                    isChecked: !1,
                    ignoreNotify: !1
                }, e)).areaIndex, n = e.provinceIndex, i = e.cityIndex, a = e.countyIndex, s = e.isChecked, c = e.ignoreNotify;
                if (void 0 !== a) {
                    var l = u[r].list[n].list[i].list[a], p = s || l.checkStatus === o.NONE;
                    this.setNodeStateAndUpdateChildren(l, p), this.updateLinealNodeState(r, n, i), t = l;
                } else if (void 0 !== i) {
                    var f = u[r].list[n].list[i];
                    p = s || f.checkStatus === o.NONE, this.setNodeStateAndUpdateChildren(f, p), this.updateLinealNodeState(r, n), 
                    t = f;
                } else if (void 0 !== n) {
                    var h = u[r].list[n];
                    p = s || h.checkStatus === o.NONE, this.setNodeStateAndUpdateChildren(h, p), this.updateLinealNodeState(r), 
                    t = h;
                } else {
                    if (void 0 === r) return d.of();
                    var S = u[r];
                    p = s || S.checkStatus === o.NONE, this.setNodeStateAndUpdateChildren(S, p), this.updateLinealNodeState(), 
                    t = S;
                }
                return c || this.notifyCheckedNumberChange(), d.of(t);
            }, e.prototype.notifyCheckedChange = function(e) {
                void 0 === e && (e = n.SPECIFIC_TEMPLATE), this.checkedListSubject.next({
                    ids: Array.from(this.leafCheckedList),
                    type: e
                });
            }, e.prototype.clearData = function() {
                this.leafCheckedList.clear(), this.leafDisabledList.clear(), this.leafHiddenList.clear(), 
                this.leafRepeatableList.clear(), this.leafCheckedListTmp = [], this.leafDisabledListTmp = [], 
                this.leafHiddenListTmp = [], this.leafRepeatableListTmp = [];
            }, e.prototype.convertIds2NameStr = function(e, t) {
                var r = this;
                return void 0 === t && (t = -1), e.length ? this.getRegionData(!1).pipe(p.map(function() {
                    var n = r.convertIds2NameList(e).join(", ");
                    return -1 === t || n.length <= t ? n : n.slice(0, t) + "...";
                })) : d.of("");
            }, e.prototype.map2FreightTemplateWithSpecialWeight = function(e, t) {
                var r = this;
                return void 0 === t && (t = 20), this.map2FreightTemplate(e, t, function(e) {
                    return e.chargeWays === i.BUY_WEIGHT ? "运费按照商品重量或体积重量来计算，更多详情请咨询团长（仅供计算运费使用，不严格代表商品实际重量)" : r.freightInfo2Str(e);
                });
            }, e.prototype.map2FreightTemplateWithCommonNoDelivery = function(e, t, r, n) {
                void 0 === t && (t = []), void 0 === n && (n = 20);
                var o = new Set(t);
                return this.map2FreightTemplate(e, n, void 0, function(e, n) {
                    return t.length ? n === s.NO_DELIVERY && r ? Array.from(new Set(c.__spread(e, t))) : e.filter(function(e) {
                        return !o.has(e);
                    }) : e;
                });
            }, e.prototype.map2FreightTemplate = function(e, t, r, n, o) {
                var i = this;
                void 0 === t && (t = 20);
                var a = r || function(e) {
                    return i.freightInfo2Str(e);
                }, u = n || function(e, t) {
                    return e;
                }, l = e.freeCarriageAreaDTO && (e.freeCarriageAreaDTO.countyIds || e.freeCarriageAreaDTO.cityIds) || [], f = e.nonDeliveryAreaDTO && (e.nonDeliveryAreaDTO.countyIds || e.nonDeliveryAreaDTO.cityIds) || [], h = (e.specialDeliveryDTOS || []).map(function(e) {
                    var r = e.specialDeliveryAreaDTO && (e.specialDeliveryAreaDTO.countyIds || e.specialDeliveryAreaDTO.cityIds) || [];
                    return i.convertIds2NameStr(u(r, s.SPECIAL_DELIVERY), t);
                });
                return d.zip.apply(void 0, c.__spread([ this.convertIds2NameStr(u(l, s.FREE), t), this.convertIds2NameStr(u(f, s.NO_DELIVERY), t) ], h)).pipe(p.map(function(t) {
                    var r = c.__read(t), n = r[0], i = r[1], s = r.slice(2);
                    return c.__assign(c.__assign({}, e), {
                        basicInfoStr: a(e),
                        freeCarriageRegionStr: n,
                        nonDeliveryRegionStr: i,
                        specialDeliveryList: (e.specialDeliveryDTOS || []).map(function(e, t) {
                            return s[t] ? "" + s[t] + (o || " ") + a(e) : "";
                        }).filter(function(e) {
                            return !!e;
                        })
                    });
                }));
            }, e.prototype.parseCityIdsToCountyIds = function(e) {
                return e.reduce(function(e, t) {
                    var r = h[t];
                    if (!r) return e;
                    var n = r.concat(S[t]).reduce(function(e, t) {
                        var r;
                        return null === (r = null == e ? void 0 : e[t]) || void 0 === r ? void 0 : r.list;
                    }, u);
                    if (!n) return e;
                    var o = n.map(function(e) {
                        return e.code;
                    });
                    return c.__spread(e, o);
                }, []);
            }, e.prototype.initCustomRegionData = function(e) {
                var t = this;
                return e.map(function(e, r) {
                    return t.initCustomRegionNodeData(e, 0, r).node;
                });
            }, e.prototype.initCustomRegionNodeData = function(e, t, r, n) {
                var o;
                void 0 === n && (n = []);
                var i = this.leafRepeatableList.has(e.adCode);
                if (3 === t) {
                    var a = e, s = this.initLeafNodeStatus(a);
                    o = this.processLeafNodeReturn(a.adCode, a.countyName, s, n, !0, i);
                } else if (2 === t) {
                    var u = void 0 === (a = e).countyDTOS;
                    s = this.initLeafNodeStatus(a), o = u ? this.processLeafNodeReturn(a.adCode, a.cityName, s, n, !0, i) : this.processNodeReturn(r, a.adCode, a.cityName, a.countyDTOS, 3, n, u, i);
                } else 1 === t ? (a = e, o = this.processNodeReturn(r, a.adCode, a.provinceName, a.cityDTOS, 2, n, !1, i)) : (a = e, 
                o = this.processNodeReturn(r, a.adCode, a.areaName, a.provinceDTOS, 1, n, !1, i));
                return o;
            }, e.prototype.initLeafNodeStatus = function(e) {
                return this.leafHiddenList.has(e.adCode) ? o.HIDDEN : this.leafDisabledList.has(e.adCode) ? o.DISABLED : this.leafCheckedList.has(e.adCode) ? o.ALL : o.NONE;
            }, e.prototype.processNodeReturn = function(e, t, r, n, o, i, a, s) {
                var u = this;
                void 0 === n && (n = []), void 0 === s && (s = !1), h[t] = c.__spread(i), S[t] = e, 
                i.push(e);
                var l = this.mergeCustomRegionNodeReturn(n.map(function(e, t) {
                    return u.initCustomRegionNodeData(e, o, t, c.__spread(i));
                })), d = l.list, p = l.checkStatus;
                return {
                    checkStatus: p,
                    node: {
                        list: d,
                        checkStatus: p,
                        code: t,
                        name: r,
                        isLeaf: a,
                        isRepeatable: s
                    }
                };
            }, e.prototype.processLeafNodeReturn = function(e, t, r, n, o, i) {
                return void 0 === i && (i = !1), h[e] = c.__spread(n), this.leafNodeTotalCount++, 
                {
                    checkStatus: r,
                    node: {
                        checkStatus: r,
                        code: e,
                        name: t,
                        isLeaf: o,
                        isRepeatable: i
                    }
                };
            }, e.prototype.mergeCustomRegionNodeReturn = function(e) {
                var t = e.map(function(e) {
                    return e.node;
                });
                return {
                    list: t,
                    checkStatus: this.deduceNodeCheckStatus(t)
                };
            }, e.prototype.deduceNodeCheckStatus = function(e) {
                return this.deduceNodeListInfo(e).checkStatus;
            }, e.prototype.deduceNodeListInfo = function(e) {
                var t = e.length, r = 0, n = 0, i = 0, a = 0, s = 0;
                return e.forEach(function(e) {
                    e.isRepeatable && s++, e.checkStatus === o.HIDDEN && r++, e.checkStatus === o.DISABLED && n++, 
                    e.checkStatus === o.ALL && i++, e.checkStatus === o.NOT_ALL && (i++, a++);
                }), {
                    checkStatus: this.deduceNodeListCheckStatus({
                        totalCount: t,
                        hiddenCount: r,
                        disabledCount: n,
                        checkedCount: i,
                        halfCheckedCount: a
                    }),
                    isRepeatable: s === t
                };
            }, e.prototype.deduceNodeListCheckStatus = function(e) {
                var t = e.totalCount, r = e.hiddenCount, n = e.disabledCount, i = e.checkedCount, a = e.halfCheckedCount, s = t - r;
                return t ? r === t ? o.HIDDEN : n === s ? o.DISABLED : i === s ? a ? o.NOT_ALL : o.ALL : i ? o.NOT_ALL : o.NONE : o.NONE;
            }, e.prototype.setNodeStateAndUpdateChildren = function(e, t) {
                var r = this, n = t ? o.ALL : o.NONE;
                if (e.checkStatus !== o.DISABLED && e.checkStatus !== o.HIDDEN) {
                    if (e.isLeaf || !e.list.length) return e.checkStatus = n, void this.updateLeafNodeCheckedList(e);
                    t && this.countChildrenNumberByStatus(e, o.DISABLED) && (n = o.NOT_ALL), e.checkStatus = n, 
                    e.list.length && e.list.forEach(function(e) {
                        r.setNodeStateAndUpdateChildren(e, t);
                    });
                }
            }, e.prototype.updateLeafNodeList = function(e, t) {
                var r = this;
                this.leafCheckedListTmp.includes(e) && t.forEach(function(e) {
                    return r.leafCheckedList.add(e);
                }), this.leafDisabledListTmp.includes(e) && t.forEach(function(e) {
                    return r.leafDisabledList.add(e);
                }), this.leafHiddenListTmp.includes(e) && t.forEach(function(e) {
                    return r.leafHiddenList.add(e);
                });
            }, e.prototype.updateLeafNodeCheckedList = function(e) {
                e.isLeaf && (e.checkStatus !== o.ALL || this.leafCheckedList.has(e.code) || this.leafCheckedList.add(e.code), 
                e.checkStatus === o.NONE && this.leafCheckedList.has(e.code) && this.leafCheckedList.delete(e.code));
            }, e.prototype.refreshRegionStatus = function() {
                var e = this;
                this.resetRegionStatus(), this.convertCity2County();
                var t = [];
                for (this.processRegionItemInfo(Array.from(this.leafCheckedList), t, function(e) {
                    return e.checkStatus = o.ALL;
                }), this.processRegionItemInfo(Array.from(this.leafDisabledList), t, function(e) {
                    return e.checkStatus = o.DISABLED;
                }), this.processRegionItemInfo(Array.from(this.leafHiddenList), t, function(e) {
                    return e.checkStatus = o.HIDDEN;
                }), this.processRegionItemInfo(Array.from(this.leafRepeatableList), t, function(e) {
                    return e.isRepeatable = !0;
                }); t.length; ) this.processRegionItemInfo(t, t, function(t) {
                    var r = e.deduceNodeListInfo(t.list), n = r.checkStatus, o = r.isRepeatable;
                    t.checkStatus = n, t.isRepeatable = o;
                });
                this.notifyCheckedChange();
            }, e.prototype.convertCity2County = function() {
                !this.leafCheckedList.size && this.leafCheckedListTmp.length && this.updateCity2CountyList(this.leafCheckedListTmp, this.leafCheckedList), 
                !this.leafDisabledList.size && this.leafDisabledListTmp.length && this.updateCity2CountyList(this.leafDisabledListTmp, this.leafDisabledList), 
                !this.leafHiddenList.size && this.leafHiddenListTmp.length && this.updateCity2CountyList(this.leafHiddenListTmp, this.leafHiddenList), 
                !this.leafRepeatableList.size && this.leafRepeatableListTmp.length && this.updateCity2CountyList(this.leafRepeatableListTmp, this.leafRepeatableList);
            }, e.prototype.updateCity2CountyList = function(e, t) {
                var r = this;
                e.forEach(function(e) {
                    var n = h[e];
                    if (n && !(n.length < 2)) if (2 === n.length) {
                        var o = r.getNodeByIndexAndCode(h[e], e).targetNode;
                        if (!o) return;
                        r.updateLeafNodeList(e, o.list.map(function(e) {
                            return e.code;
                        }));
                    } else t.add(e);
                });
            }, e.prototype.processRegionItemInfo = function(e, t, r) {
                for (;e.length; ) {
                    var n = e.shift(), o = h[n], i = this.getNodeByIndexAndCode(o, n), a = i.parentNode, s = i.targetNode;
                    s && r(s), a && !t.includes(a.code) && t.push(a.code);
                }
            }, e.prototype.resetRegionStatus = function() {
                var e = this;
                u && u.forEach(function(t) {
                    return e.resetNodeStatus(t);
                });
            }, e.prototype.resetNodeStatus = function(e) {
                var t = this;
                e.checkStatus = o.NONE, e.isRepeatable = !1, this.isNotLeafNode(e) && e.list.forEach(function(e) {
                    return t.resetNodeStatus(e);
                });
            }, e.prototype.isNotLeafNode = function(e) {
                return void 0 !== e.list;
            }, e.prototype.updateLinealNodeState = function(e, t, r) {
                if (void 0 !== e) {
                    var n = {}, o = u[e];
                    if (void 0 !== r) {
                        var i = o.list[t].list[r], a = this.deduceNodeCheckStatus(i.list);
                        if (i.checkStatus === a) return;
                        i.checkStatus = a, Object.assign(n, {
                            cityIndex: r,
                            cityNewState: a
                        });
                    }
                    if (void 0 !== t) {
                        var s = o.list[t], c = this.deduceNodeCheckStatus(s.list);
                        if (s.checkStatus === c && this.monoUtil.isEmptyObject(n)) return;
                        s.checkStatus !== c && (s.checkStatus = c, Object.assign(n, {
                            provinceNewState: c
                        })), Object.assign(n, {
                            provinceIndex: t
                        });
                    }
                    var l = this.deduceNodeCheckStatus(o.list);
                    o.checkStatus !== l && (o.checkStatus = l, Object.assign(n, {
                        areaNewState: l
                    })), Object.assign(n, {
                        areaIndex: e,
                        isSelectAll: this.isSelectAll()
                    }), this.notifyLinealStateChange(n);
                } else this.notifyLinealStateChange({
                    isSelectAll: this.isSelectAll()
                });
            }, e.prototype.notifyLinealStateChange = function(e) {
                this.linealStateNotifySubject.next(e);
            }, e.prototype.notifyCheckedNumberChange = function() {
                var e;
                e = u ? new Set(c.__spread(this.leafCheckedList, this.leafHiddenList)).size - this.leafHiddenList.size : new Set(c.__spread(this.leafCheckedListTmp, this.leafHiddenListTmp)).size - this.leafCheckedListTmp.length, 
                this.checkNumberSubject.next(e);
            }, e.prototype.countChildrenNumberByStatus = function(e, t) {
                var r = this, n = 0;
                return e.isLeaf || e.list.forEach(function(e) {
                    e.isLeaf && e.checkStatus === t ? n++ : e.isLeaf || (n += r.countChildrenNumberByStatus(e, t));
                }), n;
            }, e.prototype.getNodeByIndexAndCode = function(e, t) {
                var r = {};
                if (!e.length) return t && (r.targetNode = u.find(function(e) {
                    return e.code === t;
                })), r;
                for (var n = c.__read(e), o = n[0], i = n.slice(1), a = u[o]; i.length; ) a = a.list[i.shift()];
                return r.parentNode = a, a && void 0 !== t && (r.targetNode = a.list.find(function(e) {
                    return e.code === t;
                })), r;
            }, e.prototype.convertIds2NameList = function(e) {
                for (var t = this, r = new Map(), n = c.__spread(e), o = []; n.length; ) this.neatenCodeByParentIndex(n, r), 
                this.neatenCodeBySameParentIndex(r, n);
                return r.forEach(function(e, r) {
                    var n = t.convertCodeStr2List(r);
                    1 === n.length ? e.forEach(function(e) {
                        return o.push(t.combineRegionNameStr(!0, n, e));
                    }) : o.push(t.combineRegionNameStr(1 === e.length, n, e[0]));
                }), o;
            }, e.prototype.combineRegionNameStr = function(e, t, r) {
                var n = this.getNodeByIndexAndCode(t, r), o = n.parentNode, i = n.targetNode;
                return e ? 1 === t.length || 1 === o.list.length ? "" + (i.name || "") : "" + (o.name || "") + (i.name || "") : (o.name || "") + "部分地区";
            }, e.prototype.neatenCodeByParentIndex = function(e, t) {
                for (;e.length; ) {
                    var r = e.shift(), n = this.convertList2CodeStr(h[r]);
                    n && (t.has(n) ? t.set(n, c.__spread(t.get(n), [ r ])) : t.set(n, [ r ]));
                }
            }, e.prototype.neatenCodeBySameParentIndex = function(e, t) {
                var r = this;
                Array.from(e.keys()).forEach(function(n) {
                    var o = e.get(n), i = r.convertCodeStr2List(n);
                    if (!(i.length <= 1 || o.length <= 1)) {
                        var a = r.getNodeByIndexAndCode(i).parentNode;
                        void 0 !== a && o.length >= a.list.length && (t.push(a.code), e.delete(n));
                    }
                });
            }, e.prototype.convertCodeStr2List = function(e) {
                return e.split(",").map(function(e) {
                    return Number(e);
                });
            }, e.prototype.convertList2CodeStr = function(e) {
                return e && e.length ? e.toString() : "";
            }, e.prototype.freightInfo2Str = function(e) {
                var t, r, n = e.additionUnitDTO, o = void 0 === n ? {} : n, s = e.weightUnitDTO, u = void 0 === s ? {} : s, c = ((t = {})[i.CARRIAGE] = "统一运费 " + this.monoUtil.numberMovePoint(e.carriage, -2, !0) + " 元", 
                t[i.BUY_NUMBER] = this.parseChargeInfo2Str(o, "件"), t[i.BUY_WEIGHT] = this.parseChargeInfo2Str(u, "kg", -3), 
                t), l = ((r = {})[a.LIMIT_PRICE] = this.parseFreeLimitInfo2Str(e.freeLimitPrice, "元", -2), 
                r[a.LIMIT_UNIT] = this.parseFreeLimitInfo2Str(e.freeLimitUnit, "件"), r[a.LIMIT_WEIGHT] = this.parseFreeLimitInfo2Str(e.freeLimitWeight, "kg", -3), 
                r), d = c[e.chargeWays || i.CARRIAGE], p = l[e.freeCarriageThreshold || a.LIMIT_PRICE];
                return d + (p ? "; " + p : "");
            }, e.prototype.parseChargeInfo2Str = function(e, t, r) {
                void 0 === r && (r = 0);
                var n = e.limitUnit, o = e.limitUnitPrice, i = e.moreUnit, a = e.moreUnitPrice;
                return this.monoUtil.numberMovePoint(n, r, !0) + " " + t + "内商品收取 " + this.monoUtil.numberMovePoint(o, -2, !0) + " 元运费，每多 " + this.monoUtil.numberMovePoint(i, r, !0) + " " + t + "多收 " + this.monoUtil.numberMovePoint(a, -2, !0) + " 元";
            }, e.prototype.parseFreeLimitInfo2Str = function(e, t, r) {
                return void 0 === t && (t = ""), void 0 === r && (r = 0), this.monoUtil.isEmpty(e) ? "" : "满 " + this.monoUtil.numberMovePoint(e, r, !0) + " " + t + "包邮";
            }, e = c.__decorate([ l.Injectable(), c.__metadata("design:paramtypes", [ f.MonoUtilService ]) ], e);
        }();
        t.RegionSelectorService = _;
    },
    137: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.WxCloudRedDotMigrateService = void 0;
        var n = r(0), o = r(1), i = r(50), a = r(17), s = r(3), u = r(691), c = r(692), l = r(41), d = r(7), p = {}, f = function() {
            function e(e, t, r) {
                this.transformService = e, this.wxCloudApiService = t, this.grayService = r;
            }
            return e.prototype.setApiService = function(e, t) {
                this.api = e, this.wx = t;
            }, e.prototype.getRedDotList = function(e) {
                var t = this, r = this.getConfigList();
                return this.getRedDotInfoByInterface(e, r).pipe(s.map(function(r) {
                    return t.updateRedDotInStorage(), t.getQueryRedDotDataFromStorage(e, r);
                }));
            }, e.prototype.setAndMarkRedDot = function(e) {
                var t = this, r = this.getMarkConfigList();
                return this.getMarkConfig(e, r).pipe(s.switchMap(function() {
                    return t.updateRedDotInStorage(), t.doubleSetBehavior(e);
                }));
            }, e.prototype.getConfigList = function() {
                var e = this;
                return [ function(t) {
                    return e.getRedDotInStorage(t);
                }, function(t) {
                    return e.getRedDotByFrontStore(t);
                }, function(t) {
                    return e.getRedDotDataFromOriginalApiAndSet(t);
                }, function(t) {
                    return e.getRedDotDataFromFrontStore(t);
                } ];
            }, e.prototype.getRedDotInfoByInterface = function(e, t, r) {
                var n = this;
                return void 0 === r && (r = {}), (0, t.splice(0, 1)[0])(e).pipe(s.switchMap(function(o) {
                    var i = n.transformService.mergeCache(o, r), a = e.filter(function(e) {
                        return !n.isRedDotCached(e, i);
                    });
                    return n.updateRedDotInMemory(o), 0 === a.length || 0 === t.length ? d.of(i) : n.getRedDotInfoByInterface(a, t, i);
                }));
            }, e.prototype.getQueryRedDotDataFromStorage = function(e, t) {
                var r = this;
                return void 0 === t && (t = {}), e.reduce(function(e, o) {
                    var i, a = o.code, s = o.redDotKey, u = r.transformService.getRecordKey(o), c = t[a], l = null === (i = null == c ? void 0 : c.record) || void 0 === i ? void 0 : i[u];
                    return c && e.push(n.__assign(n.__assign(n.__assign(n.__assign({}, o), c), l), {
                        redDotKey: s,
                        recordKey: u
                    })), e;
                }, []);
            }, e.prototype.getRedDotDataFromOriginalApi = function(e) {
                var t = this;
                return this.splitRedDotParamObs$(e).pipe(s.switchMap(function(e) {
                    var r = e.backEndRedDotList, o = e.cloudRedDotList, i = e.frontStoreRedDotList;
                    return d.forkJoin(t.getRedDotDataFromInterface(r, l.RedDotSource.BACK_END), t.getRedDotDataFromInterface(o, l.RedDotSource.WX_CLOUD), t.getRedDotDataFromInterface(i, l.RedDotSource.FRONT_STORE)).pipe(s.map(function(e) {
                        var t = n.__read(e, 3), r = t[0], o = t[1], i = t[2];
                        return n.__assign(n.__assign(n.__assign({}, r), o), i);
                    }));
                }));
            }, e.prototype.getRedDotDataFromOriginalApiAndSet = function(e) {
                var t = this;
                return this.getRedDotDataFromOriginalApi(e).pipe(s.tap(function(r) {
                    t.setRedDotDataByFrontStore(e, r).subscribe();
                }));
            }, e.prototype.getRedDotDataFromFrontStore = function(e) {
                var t = this;
                return this.getRedDotDataFromInterface(e, l.RedDotSource.FRONT_STORE).pipe(s.tap(function(r) {
                    t.setRedDotDataByFrontStore(e, r).subscribe();
                }));
            }, e.prototype.getRedDotDataFromInterface = function(e, t) {
                var r, n = this, o = ((r = {})[l.RedDotSource.BACK_END] = function(e) {
                    return n.getRedDotByBackEnd(e);
                }, r[l.RedDotSource.WX_CLOUD] = function(e) {
                    return n.getRedDotDataFromCloudApi(e);
                }, r[l.RedDotSource.FRONT_STORE] = function(e) {
                    return n.getRedDotConfigByFrontStore(e);
                }, r);
                return o[t] ? o[t](e) : d.of({});
            }, e.prototype.getRedDotDataFromCloudApi = function(e) {
                var t = this;
                return 0 === e.length ? d.of({}) : this.wxCloudApiService.getRedDotListV2({
                    redDotQueryParamList: e
                }, {
                    defaultData: []
                }).pipe(s.map(function(e) {
                    var r = e.data, n = void 0 === r ? [] : r;
                    return t.transformService.convertRedDotDataToStorageStructure(n || []);
                }));
            }, e.prototype.getRedDotInStorage = function(e) {
                return d.of(this.getRedDotInMemory()).pipe(s.map(function(t) {
                    return e.forEach(function(e) {
                        e.enforceUpdate && delete t[e.code];
                    }), t;
                }));
            }, e.prototype.getRedDotByBackEnd = function(e) {
                var t = this;
                return 0 === e.length ? d.of({}) : this.api.getRedDotListUsingPOST({
                    redDotQueryParamList: e
                }, u.options).pipe(s.map(function(e) {
                    return t.transformService.convertRedDotDataToStorageStructure((null == e ? void 0 : e.data) || []);
                }));
            }, e.prototype.getRedDotByFrontStore = function(e) {
                var t = this, r = e.map(function(e) {
                    return e.code;
                });
                return this.api.frontStoreRedDotListByCodesUsingPOST({
                    codes: r
                }).pipe(s.map(function(e) {
                    var r = e.data;
                    return t.formatFrontStoreRedDotDTO2IMigrateRedDotData(r);
                }), s.switchMap(function(e) {
                    return t.refreshRedDotConfig(r, e);
                }));
            }, e.prototype.formatFrontStoreRedDotDTO2IMigrateRedDotData = function(e) {
                return e ? Object.values(e).reduce(function(e, t) {
                    var r = t.code, o = t.extendJson, i = o && JSON.parse(o);
                    if (i) {
                        var a = n.__assign({
                            code: r
                        }, i);
                        e[r] = a;
                    }
                    return e;
                }, {}) : {};
            }, e.prototype.getRedDotConfigByFrontStore = function(e) {
                var t = this;
                if (0 === e.length) return d.of({});
                var r = e.map(function(e) {
                    return e.code;
                });
                return this.api.frontStoreRedDotConfigListByCodesUsingPOST({
                    codes: r
                }, u.options).pipe(s.map(function(r) {
                    return (r.data || []).reduce(function(r, n) {
                        var o, i, a = t.formatIConfigItem(n), s = n.code, u = n.type, c = (e.find(function(e) {
                            return e.code === s;
                        }) || {}).redDotKey, l = ((o = {})[t.transformService.getRecordKey({
                            code: s,
                            type: u,
                            redDotKey: c
                        })] = {
                            invokerNumber: 0
                        }, o), d = t.getRedDotVersion(s);
                        d && (a.version = d), a.record = l;
                        var p = ((i = {})[s] = a, i);
                        return t.transformService.mergeCache(p, r);
                    }, {});
                }));
            }, e.prototype.formatIConfigItem = function(e) {
                var t = e.code, r = e.expireDate, n = e.cycleDay, o = e.cnName, i = e.enName, a = e.type, s = e.limitNumber, u = e.status;
                return {
                    code: t,
                    cycleDay: n,
                    cName: o,
                    enName: i,
                    type: a,
                    status: u,
                    limitNumber: 5 === u ? 0 : s,
                    expireDate: r
                };
            }, e.prototype.getMarkConfigList = function() {
                var e = this;
                return [ function(t) {
                    return e.getRedDotInStorage(t);
                }, function(t) {
                    return e.getRedDotByFrontStore(t);
                }, function(t) {
                    return e.getRedDotDataFromOriginalApi(t);
                }, function(t) {
                    return e.generateRedDotCacheFromFrontStore(t);
                } ];
            }, e.prototype.getMarkConfig = function(e, t, r) {
                var n = this;
                void 0 === r && (r = {});
                var o = t.splice(0, 1)[0];
                return o ? o(e).pipe(s.map(function(t) {
                    return n.markRedDot(e, t);
                }), s.switchMap(function(o) {
                    var i = n.transformService.mergeCache(o, r), a = e.filter(function(e) {
                        return !n.isRedDotCached(e, i);
                    });
                    return n.updateRedDotInMemory(i), 0 === a.length || 0 === t.length ? d.of(i) : n.getMarkConfig(a, t, i);
                })) : d.of(r);
            }, e.prototype.generateRedDotCacheFromFrontStore = function(e) {
                return void 0 === e && (e = []), 0 === e.length ? d.of({}) : this.getRedDotDataFromInterface(e, l.RedDotSource.FRONT_STORE);
            }, e.prototype.markRedDot = function(e, t) {
                var r = this;
                return e.reduce(function(e, o) {
                    var i, a = o.code, s = t[a];
                    if (s) {
                        var u = r.transformService.getRecordKey(o), c = s.record, l = void 0 === c ? {} : c, d = s.limitNumber, p = l[u] || {}, f = p.invokerNumber, h = void 0 === f ? 0 : f, S = p.lastReadTime;
                        ("number" == typeof d ? h >= d : !!h) || (h += 1), S = String(new Date().getTime());
                        var _ = n.__assign(n.__assign({}, s), {
                            type: o.type || s.type,
                            record: (i = {}, i[u] = {
                                invokerNumber: h,
                                lastReadTime: S
                            }, i)
                        }), E = r.transformService.mergeCacheItem(s, _);
                        e[a] = E;
                    }
                    return e;
                }, t);
            }, e.prototype.doubleSetBehavior = function(e) {
                return d.forkJoin([ this.setRedDotDataByFrontStore(e), this.markRedDotReadFromOriginalApi(e) ]).pipe(s.map(function() {
                    return p;
                }));
            }, e.prototype.markRedDotReadFromOriginalApi = function(e) {
                var t = this;
                return this.splitRedDotParamObs$(e).pipe(s.switchMap(function(e) {
                    var r = e.backEndRedDotList, n = e.cloudRedDotList;
                    return e.frontStoreRedDotList, d.forkJoin(t.setRedDotDataFromInterface(r, l.RedDotSource.BACK_END), t.setRedDotDataFromInterface(n, l.RedDotSource.WX_CLOUD)).pipe(s.map(function() {
                        return p;
                    }));
                }));
            }, e.prototype.setRedDotDataFromInterface = function(e, t) {
                var r, n = this, o = ((r = {})[l.RedDotSource.BACK_END] = function(e) {
                    return n.setRedDotByBackEnd(e);
                }, r[l.RedDotSource.WX_CLOUD] = function(e) {
                    return n.setRedDotDataFromCloudApi(e);
                }, r[l.RedDotSource.FRONT_STORE] = function(e) {
                    return n.setRedDotDataByFrontStore(e);
                }, r);
                return o[t] ? o[t](e) : d.of(p);
            }, e.prototype.setRedDotByBackEnd = function(e) {
                return 0 === e.length ? d.of(p) : this.api.batchEditRedDontInvokerNumber2UsingPOST({
                    redDotParamList: e
                }, u.options);
            }, e.prototype.setRedDotDataFromCloudApi = function(e) {
                return 0 === e.length ? d.of(p) : this.wxCloudApiService.batchMarkReadRedDotV2({
                    redDotQueryParamList: e
                }, {
                    defaultData: p
                });
            }, e.prototype.setRedDotDataByFrontStore = function(e, t) {
                var r = this;
                if (0 === e.length) return d.of(p);
                var n = e.reduce(function(e, n) {
                    var o = n.code, i = (t || r.getRedDotInMemory())[o];
                    return i && (i.version = r.getRedDotVersion(o), e.push({
                        code: o,
                        extendJson: JSON.stringify(i)
                    })), e;
                }, []);
                return n && n.length ? this.api.frontStoreRedDotBatchSaveUsingPOST(n, u.options) : d.of(p);
            }, e.prototype.getRedDotVersion = function(e) {
                var t, r;
                return this.redDotConfigVersion || (this.redDotConfigVersion = (null === (t = this.wx) || void 0 === t ? void 0 : t.getStorageSync(l.RED_DOT_CONFIG_VERSION)) || {}), 
                null === (r = this.redDotConfigVersion[e]) || void 0 === r ? void 0 : r.version;
            }, e.prototype.refreshRedDotConfig = function(e, t) {
                var r = this, n = e.filter(function(e) {
                    return function(e) {
                        var n = t[e], o = null == n ? void 0 : n.version, i = r.getRedDotVersion(e);
                        return n && !!i && i !== o;
                    }(e);
                });
                return (null == n ? void 0 : n.length) ? this.api.frontStoreRedDotConfigListByCodesUsingPOST({
                    codes: n
                }, u.options).pipe(s.map(function(e) {
                    var o = e.data, i = void 0 === o ? [] : o, a = i.map(function(e) {
                        return e.code;
                    });
                    return n.forEach(function(e) {
                        var n = a.indexOf(e);
                        if (-1 !== n) {
                            var o = t[e], s = r.formatIConfigItem(i[n]), u = Object.assign(s, {
                                version: r.getRedDotVersion(e)
                            });
                            t[e] = r.transformService.mergeCacheItem(o, u);
                        } else t[e].status = 5, t[e].limitNumber = 0;
                    }), t;
                })) : d.of(t);
            }, e.prototype.isRedDotCached = function(e, t) {
                var r, n = e.code, o = t[n], i = 5 === (null == o ? void 0 : o.status) || 0 === (null == o ? void 0 : o.limitNumber), a = this.transformService.getRecordKey(e), s = this.getRedDotVersion(n), u = !!s && s !== (null == o ? void 0 : o.version);
                return i || !!(null === (r = null == o ? void 0 : o.record) || void 0 === r ? void 0 : r[a]) && !u;
            }, e.prototype.getRedDotInMemory = function() {
                var e;
                return this.redDotInStorage || (this.redDotInStorage = (null === (e = this.wx) || void 0 === e ? void 0 : e.getStorageSync(l.RED_DOT_STORAGE_KEY)) || {}), 
                this.redDotInStorage;
            }, e.prototype.updateRedDotInMemory = function(e) {
                var t = this.getRedDotInMemory(), r = this.transformService.mergeCache(e, t);
                JSON.stringify(t) === JSON.stringify(r) || (this.redDotInStorage = r);
            }, e.prototype.updateRedDotInStorage = function() {
                var e, t = this.getRedDotInMemory();
                null === (e = this.wx) || void 0 === e || e.setStorage({
                    key: l.RED_DOT_STORAGE_KEY,
                    data: t
                });
            }, e.prototype.splitRedDotParamObs$ = function(e) {
                var t = this;
                return this.grayService.canIUseFeature("2521").pipe(s.map(function(r) {
                    return t.transformService.splitRedDotParam(e, r);
                }));
            }, e = n.__decorate([ o.Injectable(), n.__metadata("design:paramtypes", [ c.WxCloudRedDotMigrateTransformService, i.WxCloudApiService, a.GrayFeatureService ]) ], e);
        }();
        t.WxCloudRedDotMigrateService = f;
    },
    138: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.SHARE_RECORD_EXPIRED_DAY = t.SetDraftBoxOriginEnum = t.DRAFT_BOX_MAX_REQUEST_FORM_SIZE = t.DRAFT_BOX_MAX_LIST_LENGTH_V2 = t.DRAFT_BOX_MAX_LIST_LENGTH = t.SUPPLY_LEADER_SEQ_NAME = t.GROUP_BUY_SEQ_NAME = void 0, 
        t.GROUP_BUY_SEQ_NAME = "团购接龙", t.SUPPLY_LEADER_SEQ_NAME = "选品接龙", t.DRAFT_BOX_MAX_LIST_LENGTH = 20, 
        t.DRAFT_BOX_MAX_LIST_LENGTH_V2 = 50, t.DRAFT_BOX_MAX_REQUEST_FORM_SIZE = 128, function(e) {
            e.APP = "app", e.USER = "user", e.CRASH = "crash";
        }(t.SetDraftBoxOriginEnum || (t.SetDraftBoxOriginEnum = {})), t.SHARE_RECORD_EXPIRED_DAY = 7;
    },
    14: function(e, t, r) {
        var n, o, i, a, s, u, c, l, d, p, f, h, S, _, E, y, T, R, v, g, m, O, A, I, C, D;
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.LeaderOrderManagePageType = t.HelpSaleLeaderManagementTabType = t.PromoterSwitch = t.FreightType = t.ChannelIdMap = t.positiveCreateHomepageChannels = t.ID_DOC_TYPE_TEXT = t.MERCHANT_TYPE_TEXT = t.AdminType = t.AfterSalesShareType = t.ShareInfoType = t.CheckFailStatus = t.ASSOCIATION_PERMISSION_TYPE_TEXT = t.PromotersRewardMode = t.TogetherBuyTypeInProduct = t.TagStatusInVoucherManagement = t.MARKET_ROLE = t.RedDotNameActId = t.RedDotNameGUId = t.RedDotName = t.VERIFY_AUTH_RESULT = t.AFTER_SALE_DESC_OF_GRAND = t.AFTER_SALE_DESC = t.ProductStatus = t.INTERACT_ATTR_EXTENSION_TYPE_TEXT = t.INTERACT_ATTR_LIST_CLASS = t.INTERACT_ATTR_TYPE_TEXT = t.InteractAttrOptionType = t.InteractAttrExtensionType = t.InteractAttrType = t.ASSOCIATION_POSTER_PATH = t.SEQ_TYPE_DETAIL_PATH = t.AFTER_SALE_MANAGE_PATH = t.ActGoodsType = t.InfoRequireType = t.InfoPublicType = t.SEQ_TYPE_EN_TEXT = t.getSeqTypeTextNew = t.SEQ_TYPE_TEXT_NEW = t.SEQ_TYPE_TEXT_FOR_CARD = t.SEQ_TYPE_TEXT = t.homeLogisticsModelNameDict = t.DeliverModeName = t.DeliverModeExpressForLeader = t.LeaderSelectMode = t.DoubleHelpTab = t.ApplyStatusTypeOptions = t.SEQ_STATUS_TEXT = t.GROUP_TYPE_TEXT = t.skipMarkOption = void 0, 
        t.STAR_DETAIL_STATUS_TEXT = t.CreditScoreTypeId = t.ChangeType = t.AfterSalesAuthStatus = t.ChatEntranceScene = t.SeqVisibleModel = t.DURATION = t.OrderTabTypeEnum = t.TemplateFeeType = t.LeaderWelfareActStatus = t.DEFAULT_PAGE_SIZE = t.QjlDefaultAccountType = t.ShoppingSeqType = t.FormOptionType = t.NOT_USE_READ_TEMPLATE_ID = t.SupplyComponentFreezeType = t.DoubleHelpSort = t.HomeBackEndFakeRoleType = t.EvaluationSquareTypeOptions = t.seqAuditStatusText = t.SeqAuditStatus = t.BrandAuditPickupStatus = t.PICKUP_EDIT_TYPE = t.FeedShowFiveStarAfterSaleSeqTypeList = t.RecommendBrandCommissionTypes = t.OrderCancelStatus = t.PrizeGrantMode = t.WinningRuleType = t.LotteryBtnType = t.LotteryStatus = t.competitionTypeEnum = t.SeqGameBonusText = t.FilterCondition = t.noop = void 0, 
        t.skipMarkOption = {
            isSkipPageMarking: !0,
            hideErrorToast: !0
        }, t.GROUP_TYPE_TEXT = ((n = {})[10] = "品牌", n[70] = "品牌", n[20] = "团长", n[105] = "选品团长", 
        n[110] = "货源品牌", n[80] = "团长", n[30] = "个人", n[40] = "私密圈子", n[50] = "社区", n[60] = "社群", 
        n[90] = "社群店", n[100] = "服务商", n), t.SEQ_STATUS_TEXT = ((o = {})[10] = "接龙中", o[8] = "预览中", 
        o[5] = "已结束", o[3] = "已删除", o), function(e) {
            e[e.NO_SIGN_UP = 0] = "NO_SIGN_UP", e[e.IN_REVIEW = 10] = "IN_REVIEW", e[e.NO_REVIEW = 20] = "NO_REVIEW", 
            e[e.QUOTA_FULL = 30] = "QUOTA_FULL", e[e.NO_EVALUATE = 40] = "NO_EVALUATE", e[e.HAS_SEVALUATE = 50] = "HAS_SEVALUATE", 
            e[e.NO_SUBSCRIBE_HELP_SELL = 60] = "NO_SUBSCRIBE_HELP_SELL", e[e.HAS_SUBSCRIBE_HELP_SELL = 70] = "HAS_SUBSCRIBE_HELP_SELL";
        }(t.ApplyStatusTypeOptions || (t.ApplyStatusTypeOptions = {})), function(e) {
            e[e.LEADER_HELP = 0] = "LEADER_HELP", e[e.BRAND_HELP = 1] = "BRAND_HELP", e[e.COLLECTED = 2] = "COLLECTED", 
            e[e.VIEWED = 3] = "VIEWED";
        }(t.DoubleHelpTab || (t.DoubleHelpTab = {})), function(e) {
            e[e.SELECTED_ALL = 10] = "SELECTED_ALL", e[e.SELECTED_PART = 20] = "SELECTED_PART";
        }(t.LeaderSelectMode || (t.LeaderSelectMode = {})), function(e) {
            e[e.EXPRESS = 10] = "EXPRESS", e[e.PICKUP = 20] = "PICKUP";
        }(t.DeliverModeExpressForLeader || (t.DeliverModeExpressForLeader = {})), t.DeliverModeName = ((i = {})[10] = "快递发货", 
        i[20] = "共享提货点自提", i[30] = "团长提货点自提", i[40] = "没有物流", i), t.homeLogisticsModelNameDict = ((a = {})[10] = "快递发货", 
        a[20] = "发货到共享提货点", a[30] = "发货到团长绑定提货点", a), t.SEQ_TYPE_TEXT = ((s = {})[10] = "开团", 
        s[20] = "开团", s[210] = "团购", s[30] = "团购", s[40] = "报名", s[50] = "拼团", s[60] = "互动", 
        s[70] = "阅读", s[80] = "评选", s[90] = "费用", s[110] = "拼团", s[120] = "集市", s[130] = "拼团-开团", 
        s[140] = "拼团", s[150] = "团购", s[160] = "团购", s[170] = "相片", s[180] = "视频", s[190] = "文章", 
        s[200] = "填表", s[-10] = "大赛", s[220] = "抽奖", s[230] = "测评", s[240] = "抽奖", s[250] = "抽奖", 
        s[260] = "主页动态", s), t.SEQ_TYPE_TEXT_FOR_CARD = ((u = {})[10] = "开团接龙", u[20] = "我帮卖的", 
        u[210] = "我帮卖的", u[30] = "团购接龙", u[40] = "报名接龙", u[50] = "拼团接龙", u[60] = "互动接龙", 
        u[70] = "阅读接龙", u[80] = "评选接龙", u[90] = "费用接龙", u[110] = "拼团接龙", u[120] = "集市接龙", 
        u[130] = "拼团-开团", u[140] = "拼团", u[150] = "团购接龙", u[160] = "我帮卖的", u[170] = "相片接龙", 
        u[180] = "视频接龙", u[190] = "文章接龙", u[200] = "填表接龙", u[-10] = "大赛接龙", u[220] = "抽奖接龙", 
        u[230] = "测评接龙", u[240] = "抽奖接龙", u[250] = "抽奖接龙", u), t.SEQ_TYPE_TEXT_NEW = ((c = {})[10] = "开团商品", 
        c[20] = "开团商品", c[210] = "团购商品", c[30] = "团购商品", c[40] = "报名项", c[50] = "拼团商品", 
        c[60] = "互动项", c[70] = "阅读模板", c[80] = "评选项", c[90] = "费用项目", c[110] = "拼团商品", c[120] = "集市商品", 
        c[130] = "拼团商品", c[140] = "拼团商品", c[150] = "团购商品", c[160] = "团购商品", c[170] = "相片", 
        c[180] = "视频", c[190] = "文章", c[200] = "填表项", c[-10] = "大赛供货团长", c[220] = "奖品项", 
        c[230] = "测评商品", c[240] = "奖品项", c[250] = "奖品项", c), t.getSeqTypeTextNew = function(e, r) {
            return 105 === r && 30 === e ? "帮卖商品" : 120 === e ? "举办方的集市商品" : t.SEQ_TYPE_TEXT_NEW[e];
        }, t.SEQ_TYPE_EN_TEXT = ((l = {})[10] = "startGroup", l[20] = "startGroup", l[210] = "startGroupGrandChild", 
        l[30] = "groupBuy", l[40] = "signUp", l[50] = "togetherBuy", l[60] = "interact", 
        l[70] = "read", l[80] = "elect", l[90] = "fee", l[110] = "newTogetherBuy", l[120] = "market", 
        l[130] = "newTogetherBuyParent", l[140] = "newTogetherBuyChild", l[170] = "photo", 
        l[180] = "video", l[190] = "article", l[200] = "form", l[-10] = "game", l[220] = "lottery", 
        l[240] = "lotteryParent", l[250] = "lotteryChild", l), function(e) {
            e[e.PRIVATE = 5] = "PRIVATE", e[e.PUBLIC = 10] = "PUBLIC";
        }(t.InfoPublicType || (t.InfoPublicType = {})), function(e) {
            e[e.NOT_REQUIRE = 5] = "NOT_REQUIRE", e[e.REQUIRE = 10] = "REQUIRE";
        }(t.InfoRequireType || (t.InfoRequireType = {})), function(e) {
            e[e.SECKILL = 20] = "SECKILL", e[e.NONE = 10] = "NONE";
        }(t.ActGoodsType || (t.ActGoodsType = {}));
        var N, L, M = "/pro/pages/seq-detail/detail-dynamic/detail-dynamic";
        t.AFTER_SALE_MANAGE_PATH = "/pro/pages/order-manage/order-after-sales-manage/order-after-sales-manage", 
        t.SEQ_TYPE_DETAIL_PATH = ((d = {})[10] = "/pro/pages/seq-detail/detail-start-group/detail-start-group", 
        d[20] = "/pro/pages/seq-detail/detail-go-group-buy/detail-go-group-buy", d[30] = "/pro/pages/seq-detail/detail-group-buy/detail-group-buy", 
        d[40] = "/pro/pages/seq-detail/detail-sign-up/detail-sign-up", d[50] = "/pro/pages/seq-detail/detail-together-buy/detail-together-buy", 
        d[60] = "/pro/pages/seq-detail/detail-interact/detail-interact", d[70] = "/pro/pages/seq-detail/detail-read/detail-read", 
        d[80] = "/pro/pages/seq-detail/detail-elect/detail-elect", d[90] = "/pro/pages/seq-detail/detail-fee/detail-fee", 
        d[100] = "/pro/pages/detail-pages/community-moment-detail/community-moment-detail", 
        d[110] = "/pro/pages/seq-detail/detail-together-buy-v2/detail-together-buy-v2", 
        d[120] = "/pro/pages/seq-detail/detail-market/detail-market", d[130] = "", d[140] = "/pro/pages/seq-detail/detail-together-buy-v2/detail-together-buy-v2", 
        d[150] = "/pro/pages/seq-detail/detail-mutual-sale-parent/detail-mutual-sale-parent", 
        d[160] = "/pro/pages/seq-detail/detail-mutual-sale-child/detail-mutual-sale-child", 
        d[170] = M, d[180] = M, d[190] = M, d[200] = "/pro/pages/seq-detail/detail-form/detail-form", 
        d[210] = "/pro/pages/seq-detail/detail-start-group-grandchild/detail-start-group-grandchild", 
        d[-10] = "/pro/pages/seq-game/seq-game-landing-page/seq-game-landing-page", d[220] = "/pro/pages/seq-detail/detail-lottery/detail-lottery", 
        d[-50] = "/pro/pages/seq-detail/detail-exhibition/detail-exhibition", d[230] = "/pro/pages/seq-detail/detail-evaluation/detail-evaluation", 
        d[-60] = "/pro/pages/seq-detail/detail-view/detail-view", d[240] = "/pro/pages/seq-detail/detail-lottery-parent/detail-lottery-parent", 
        d[250] = "/pro/pages/seq-detail/detail-lottery-child/detail-lottery-child", d[260] = "/pro/pages/seq-detail-support/detail-gh-moment/detail-gh-moment", 
        d), t.ASSOCIATION_POSTER_PATH = {
            HOME: "/pro/pages/homepage/group-association/home-page/home-page",
            DETAILS: "/pro/pages/homepage/group-association/details-page/details-page",
            TEST: t.SEQ_TYPE_DETAIL_PATH[10]
        }, function(e) {
            e[e.TEXT = 10] = "TEXT", e[e.IMAGE = 20] = "IMAGE", e[e.FEE = 30] = "FEE", e[e.LOCATION = 40] = "LOCATION", 
            e[e.AUDIO = 50] = "AUDIO", e[e.RADIO = 60] = "RADIO", e[e.CHECKBOX = 70] = "CHECKBOX", 
            e[e.DEF = 80] = "DEF";
        }(N = t.InteractAttrType || (t.InteractAttrType = {})), function(e) {
            e[e.NONE = 0] = "NONE", e[e.PHONE = 10] = "PHONE", e[e.DATE = 20] = "DATE", e[e.EMAIL = 30] = "EMAIL", 
            e[e.ID_PHOTO = 40] = "ID_PHOTO", e[e.CONTACT_NAME = 100] = "CONTACT_NAME", e[e.CONTACT_ADDRESS = 110] = "CONTACT_ADDRESS", 
            e[e.CONTACT_PHONE = 120] = "CONTACT_PHONE";
        }(L = t.InteractAttrExtensionType || (t.InteractAttrExtensionType = {})), function(e) {
            e[e.OTHER = 10] = "OTHER";
        }(t.InteractAttrOptionType || (t.InteractAttrOptionType = {})), t.INTERACT_ATTR_TYPE_TEXT = ((p = {})[N.TEXT] = "填写项", 
        p[N.IMAGE] = "图片/视频", p[N.FEE] = "收费项", p[N.LOCATION] = "位置", p[N.AUDIO] = "语音", 
        p[N.RADIO] = "单选", p[N.CHECKBOX] = "多选", p), t.INTERACT_ATTR_LIST_CLASS = ((f = {})[N.TEXT] = "write-icon", 
        f[N.IMAGE] = "img-icon", f[N.FEE] = "cost-icon", f[N.LOCATION] = "position-icon", 
        f[N.AUDIO] = "voice-icon", f[N.RADIO] = "single-icon", f[N.CHECKBOX] = "more-icon", 
        f), t.INTERACT_ATTR_EXTENSION_TYPE_TEXT = ((h = {})[L.PHONE] = "手机号", h[L.DATE] = "日期", 
        h[L.EMAIL] = "邮箱", h[L.CONTACT_NAME] = "填写", h[L.CONTACT_PHONE] = "填写", h[L.CONTACT_ADDRESS] = "填写", 
        h), function(e) {
            e[e.NORMAL = 10] = "NORMAL", e[e.ALREADY_SOLD_OUT = 7] = "ALREADY_SOLD_OUT", e[e.SOLD_OUT = 5] = "SOLD_OUT", 
            e[e.DELETED = 3] = "DELETED";
        }(t.ProductStatus || (t.ProductStatus = {})), t.AFTER_SALE_DESC = ((S = {})[1] = "我已拒绝", 
        S[2] = "摊主已拒绝", S[5] = "团长已拒绝", S[10] = "待团长审核", S[30] = "待退款", S[192] = "已申请退款", 
        S[200] = "退款中", S[31] = "退款失败", S[300] = "已退款", S), t.AFTER_SALE_DESC_OF_GRAND = ((_ = {})[1] = "供货商已拒绝", 
        _[5] = "团长已拒绝", _[10] = "待处理", _[30] = "待供货商退款中", _[300] = "已退款", _[200] = "退款中", 
        _[31] = "退款失败", _), function(e) {
            e[e.VERIFIED = 10] = "VERIFIED", e[e.SHOW_VERIFY_ENTRANCE = 5] = "SHOW_VERIFY_ENTRANCE", 
            e[e.HIDE_VERIFY_ENTRANCE = 0] = "HIDE_VERIFY_ENTRANCE";
        }(t.VERIFY_AUTH_RESULT || (t.VERIFY_AUTH_RESULT = {})), t.RedDotName = ((E = {})[1] = "isShowBackgroundTips", 
        E[3] = "isShowLeaderHelpDot", E[27] = "isShowGuideShareTips", E[25] = "isShowPcGuideTips", 
        E[35] = "isShowHomeInviteTips", E[37] = "isShowAddRemindTips", E[42] = "isShowInputTipsModal", 
        E[52] = "isShowUserDetail", E[53] = "isShowHelpSaleLeaderFristClick", E[54] = "isShowLeaderBrandFristClick", 
        E[55] = "isShowBrandHelpTips", E[59] = "isShowJoinGroupDot", E[68] = "isShowPicturesMovableTips", 
        E[88] = "isShowMoveableTips", E[79] = "isShowSetPromoterGuide", E[81] = "isShowSetPromotersTips", 
        E[65] = "isShowFollowTips", E[94] = "isShowStartGroupMoneyOffTips", E[95] = "isShowMutualSaleMoneyOffTips", 
        E[303] = "isShowMultiplySendRemind", E[319] = "isShowNewCustomerRedPacketTips", 
        E), t.RedDotNameGUId = ((y = {})[100] = "isShowShareActTipsPopup", y[101] = "isShowShareActTips", 
        y[105] = "showClickProfileTips", y[112] = "isShowLeaderCommissionTip", y[113] = "isShowRecommendCommissionTip", 
        y[114] = "isShowWelcomeTips", y[118] = "isShowCommissionTips", y), t.RedDotNameActId = ((T = {})[201] = "isNotOrderShared", 
        T[203] = "isShowHelpSaleGuide", T), function(e) {
            e[e.ORGANIZER = 10] = "ORGANIZER", e[e.SELLER = 20] = "SELLER";
        }(t.MARKET_ROLE || (t.MARKET_ROLE = {})), function(e) {
            e[e.ALL = 0] = "ALL", e[e.CANCEL = 2] = "CANCEL", e[e.MARK = 3] = "MARK", e[e.ALREADY_REFUND = 4] = "ALREADY_REFUND", 
            e[e.TOGETHER_BUY = 5] = "TOGETHER_BUY", e[e.TOGETHER_SUC = 6] = "TOGETHER_SUC", 
            e[e.TOGETHER_FAIL = 7] = "TOGETHER_FAIL", e[e.WAIT_PAY = 18] = "WAIT_PAY", e[e.BRAND_REFUSE = 301] = "BRAND_REFUSE", 
            e[e.LEADER_REFUSE = 305] = "LEADER_REFUSE", e[e.WAIT_LEADER_CHECK = 3010] = "WAIT_LEADER_CHECK", 
            e[e.WAIT_REFUND = 3030] = "WAIT_REFUND", e[e.REFUND_FAIL = 3040] = "REFUND_FAIL", 
            e[e.LOTTERY_WIN = 10] = "LOTTERY_WIN", e[e.LOTTERY_LOSE = 50] = "LOTTERY_LOSE", 
            e[e.LOTTERY_WAIT_OPEN = 30] = "LOTTERY_WAIT_OPEN", e[e.UNSEND = 110] = "UNSEND", 
            e[e.SENT = 120] = "SENT", e[e.PARTIAL_SEND = 111] = "PARTIAL_SEND", e[e.SEND_FAIL = 130] = "SEND_FAIL";
        }(t.TagStatusInVoucherManagement || (t.TagStatusInVoucherManagement = {})), function(e) {
            e[e.COMMON = 10] = "COMMON", e[e.NEED_NEW_USER = 20] = "NEED_NEW_USER";
        }(t.TogetherBuyTypeInProduct || (t.TogetherBuyTypeInProduct = {})), function(e) {
            e[e.INVITATION = 10] = "INVITATION", e[e.PICKUP = 20] = "PICKUP";
        }(t.PromotersRewardMode || (t.PromotersRewardMode = {})), t.ASSOCIATION_PERMISSION_TYPE_TEXT = ((R = {})[10] = "所有人均可访问", 
        R[20] = "非成员仅可浏览前三个动态", R[0] = "非成员不能访问社群", R), function(e) {
            e[e.NONE = -1] = "NONE", e[e.CHECK_PASS = 5] = "CHECK_PASS", e[e.CHECKING = 10] = "CHECKING", 
            e[e.CHECK_FAIL = 20] = "CHECK_FAIL";
        }(t.CheckFailStatus || (t.CheckFailStatus = {})), function(e) {
            e.SINGLE_PRODUCT = "singleProduct", e.HELP_SALE = "helpSale", e.HOME_FRONT_RECOMMEND_COMMISSION = "leaderRecommendBrand", 
            e.SHARE_SELECTOR = "shareSelector", e.OPEN_GRANDCHILD_HELP_SALE = "openGrandchildHelpSale", 
            e.BRAND_INVITE_LEADER = "brandInviteLeader", e.HELP_SALE_RECOMMEND = "helpSaleRecommend", 
            e.INVITE_TOGETHER_BUY = "inviteTogetherBuy", e.SHARE_PARTICIPANT = "shareParticipant", 
            e.SHARE_AFTER_SALES = "shareAfterSales", e.SHARE_ORDER_DETAIL = "shareOrderDetail", 
            e.QW_SEND_ORDER = "qwSendOrder", e.TELL_FRIEND_I_HAVE_SOLITAIRE = "tellFriendIHaveSolitaire";
        }(t.ShareInfoType || (t.ShareInfoType = {})), function(e) {
            e.NORMAL = "1", e.INVITE_ADD_INFO = "2", e.REMIND_PAY_RETURN_SHIPPING_FEE = "3";
        }(t.AfterSalesShareType || (t.AfterSalesShareType = {})), t.AdminType = ((v = {})[10] = 2, 
        v[20] = 101, v[90] = 20, v[60] = 501, v[70] = 20, v[100] = 20, v), t.MERCHANT_TYPE_TEXT = ((g = {})[2401] = "小微商户", 
        g[2500] = "个人卖家", g[4] = "个体工商户", g[2] = "企业", g[3] = "党政、机关及事业单位", g[1708] = "其他组织", 
        g), t.ID_DOC_TYPE_TEXT = ((m = {}).IDENTIFICATION_TYPE_MAINLAND_IDCARD = "中国大陆居民-身份证", 
        m.IDENTIFICATION_TYPE_OVERSEA_PASSPORT = "其他国家或地区居民-护照", m.IDENTIFICATION_TYPE_HONGKONG = "中国香港居民–来往内地通行证 ", 
        m.IDENTIFICATION_TYPE_MACAO = "中国澳门居民–来往内地通行证", m.IDENTIFICATION_TYPE_TAIWAN = "中国台湾居民–来往大陆通行证", 
        m), t.positiveCreateHomepageChannels = [ 1, 2, 7, 8, 9, 10, 11, 18, 19, 50, 51, 55, 57, 63, 111 ], 
        t.ChannelIdMap = {
            hotSaleRank: {
                test: 6,
                prod: 15
            },
            brandPavilion: {
                test: 4,
                prod: 14
            },
            groupStory: {
                test: 17,
                prod: 17
            },
            groupCourse: {
                test: 16,
                prod: 16
            },
            helpSellBanner: {
                test: 20,
                prod: 26
            },
            chatRecord: {
                test: 80,
                prod: 79
            }
        }, function(e) {
            e[e.NONE = -1] = "NONE", e[e.FREE_SHIPPING = 0] = "FREE_SHIPPING", e[e.NEED_FREIGHT = 1] = "NEED_FREIGHT", 
            e[e.NO_DELIVERY = 2] = "NO_DELIVERY", e[e.ERROR_ADDRESS = 3] = "ERROR_ADDRESS", 
            e[e.ERROR_PICKUP = 4] = "ERROR_PICKUP";
        }(t.FreightType || (t.FreightType = {})), function(e) {
            e[e.OFF = 5] = "OFF", e[e.ON = 10] = "ON";
        }(t.PromoterSwitch || (t.PromoterSwitch = {})), function(e) {
            e.DEFAULT = "default", e.FOLLOW_SUPPLY_LEADER = "followSupplyLeader";
        }(t.HelpSaleLeaderManagementTabType || (t.HelpSaleLeaderManagementTabType = {})), 
        function(e) {
            e[e.LEADER = 0] = "LEADER", e[e.BRAND = 1] = "BRAND", e[e.SUPPLY_BRAND = 2] = "SUPPLY_BRAND", 
            e[e.ACT = 3] = "ACT";
        }(t.LeaderOrderManagePageType || (t.LeaderOrderManagePageType = {}));
        var b;
        t.noop = function() {}, function(e) {
            e[e.RECENT = 10] = "RECENT", e[e.VIEW_COUNT = 20] = "VIEW_COUNT", e[e.ORDER_COUNT = 30] = "ORDER_COUNT", 
            e[e.TOTAL_COST = 40] = "TOTAL_COST", e[e.FANS_LEADER = 50] = "FANS_LEADER", e[e.FANS_MANAGER = 60] = "FANS_MANAGER", 
            e[e.FANS_BLOCKED = 70] = "FANS_BLOCKED", e[e.FANS_SUBSCRIBED = 80] = "FANS_SUBSCRIBED", 
            e[e.FOLLOW_TIME = 90] = "FOLLOW_TIME", e[e.BRING_NUMBER = 100] = "BRING_NUMBER", 
            e[e.ALL_MEMBER = 110] = "ALL_MEMBER", e[e.RECENT_CHAT = 120] = "RECENT_CHAT";
        }(t.FilterCondition || (t.FilterCondition = {})), t.SeqGameBonusText = ((O = {})[1] = "榜单", 
        O[2] = "报名", O[3] = "邀请", O), function(e) {
            e[e.AGENT = 10] = "AGENT", e[e.SPONSOR = 20] = "SPONSOR", e[e.CUSTOMER = 30] = "CUSTOMER";
        }(t.competitionTypeEnum || (t.competitionTypeEnum = {})), function(e) {
            e[e.NO_DRAW = 10] = "NO_DRAW", e[e.DRAWING = 20] = "DRAWING", e[e.DREW = 30] = "DREW", 
            e[e.CANCEL_DRAW = 5] = "CANCEL_DRAW";
        }(t.LotteryStatus || (t.LotteryStatus = {})), function(e) {
            e[e.LOADING = -1] = "LOADING", e[e.WANT_TO_DRAW = 0] = "WANT_TO_DRAW", e[e.NO_DRAW = 1] = "NO_DRAW", 
            e[e.DRAWING = 2] = "DRAWING", e[e.WIN = 3] = "WIN", e[e.NOT_WIN = 4] = "NOT_WIN", 
            e[e.END = 5] = "END", e[e.CANCEL_DRAW = 6] = "CANCEL_DRAW";
        }(t.LotteryBtnType || (t.LotteryBtnType = {})), function(e) {
            e[e.COMPLETELY_RANDOM = 10] = "COMPLETELY_RANDOM", e[e.REGULAR_CUSTOMER_BONUS = 20] = "REGULAR_CUSTOMER_BONUS", 
            e[e.HIGH_SELLING_AMOUNT_BONUS = 30] = "HIGH_SELLING_AMOUNT_BONUS";
        }(t.WinningRuleType || (t.WinningRuleType = {})), function(e) {
            e[e.USE_SHIPPING_ADDRESS = 10] = "USE_SHIPPING_ADDRESS", e[e.CONTACT_ME = 20] = "CONTACT_ME", 
            e[e.LEADER_CONTACT_ME = 30] = "LEADER_CONTACT_ME";
        }(t.PrizeGrantMode || (t.PrizeGrantMode = {})), function(e) {
            e[e.START_GROUP_CANCEL = 6] = "START_GROUP_CANCEL", e[e.USER_APPLY_CANCEL = 7] = "USER_APPLY_CANCEL", 
            e[e.INITIATOR_CANCEL = 8] = "INITIATOR_CANCEL";
        }(t.OrderCancelStatus || (t.OrderCancelStatus = {})), t.RecommendBrandCommissionTypes = ((A = {})[0] = 0, 
        A[1] = 2, A[2] = 1, A), t.FeedShowFiveStarAfterSaleSeqTypeList = [ 10, 20, 210, 150, 160, 30 ], 
        function(e) {
            e[e.LEADER_CREATE = 0] = "LEADER_CREATE", e[e.LEADER_EDIT = 1] = "LEADER_EDIT", 
            e[e.BRAND_CREATE = 2] = "BRAND_CREATE", e[e.BRAND_EDIT = 3] = "BRAND_EDIT", e[e.ZONE_CREATE = 4] = "ZONE_CREATE", 
            e[e.ZONE_EDIT = 5] = "ZONE_EDIT";
        }(t.PICKUP_EDIT_TYPE || (t.PICKUP_EDIT_TYPE = {})), function(e) {
            e[e.PASS = 20] = "PASS", e[e.REJECT = 5] = "REJECT";
        }(t.BrandAuditPickupStatus || (t.BrandAuditPickupStatus = {})), function(e) {
            e[e.PROCESSING = 10] = "PROCESSING", e[e.PASSED = 20] = "PASSED", e[e.REJECTED = 30] = "REJECTED", 
            e[e.OUT_OF_STOCK = 40] = "OUT_OF_STOCK";
        }(b = t.SeqAuditStatus || (t.SeqAuditStatus = {})), t.seqAuditStatusText = ((I = {})[b.PROCESSING] = "审核中", 
        I[b.PASSED] = "正在接龙", I[b.REJECTED] = "审核不通过", I[b.OUT_OF_STOCK] = "已下架", I), function(e) {
            e[e.ALL = 0] = "ALL", e[e.TO_APPLY = 10] = "TO_APPLY", e[e.IN_REVIEW = 20] = "IN_REVIEW", 
            e[e.TO_EVALUATE = 30] = "TO_EVALUATE", e[e.HAS_EVALUATE = 40] = "HAS_EVALUATE";
        }(t.EvaluationSquareTypeOptions || (t.EvaluationSquareTypeOptions = {})), t.HomeBackEndFakeRoleType = ((C = {})[0] = "homeBackEndFakeRoleTypeInNone", 
        C[1] = "homeBackEndFakeRoleTypeInHelp", C[2] = "homeBackEndFakeRoleTypeInSupply", 
        C[4] = "homeBackEndFakeRoleTypeInBothOfHelp", C[5] = "homeBackEndFakeRoleTypeInBothOfSupply", 
        C), function(e) {
            e[e.NEW = 0] = "NEW", e[e.USE_MOST = 1] = "USE_MOST", e[e.SALE_MOST = 2] = "SALE_MOST", 
            e[e.COMMISSION_MOST = 3] = "COMMISSION_MOST", e[e.SALE_RATE_MOST = 4] = "SALE_RATE_MOST";
        }(t.DoubleHelpSort || (t.DoubleHelpSort = {})), function(e) {
            e[e.GOODS_PAYMENT = 10] = "GOODS_PAYMENT", e[e.COMMISSION = 30] = "COMMISSION", 
            e[e.AFTER_SALE = 50] = "AFTER_SALE";
        }(t.SupplyComponentFreezeType || (t.SupplyComponentFreezeType = {})), t.NOT_USE_READ_TEMPLATE_ID = 20164, 
        function(e) {
            e[e.COMMON = 0] = "COMMON", e[e.OTHER = 10] = "OTHER";
        }(t.FormOptionType || (t.FormOptionType = {})), t.ShoppingSeqType = new Set([ 10, 20, 210, 150, 160, 30, 110 ]), 
        function(e) {
            e.WECHAT = "wechat", e.NEW = "aip", e.OLD = "qjl";
        }(t.QjlDefaultAccountType || (t.QjlDefaultAccountType = {})), t.DEFAULT_PAGE_SIZE = 10, 
        function(e) {
            e[e.AUDIT = 0] = "AUDIT", e[e.AUDIT_FAIL = 5] = "AUDIT_FAIL", e[e.AUDIT_SUCCESS = 10] = "AUDIT_SUCCESS", 
            e[e.END = 20] = "END", e[e.ACTIVE = 30] = "ACTIVE";
        }(t.LeaderWelfareActStatus || (t.LeaderWelfareActStatus = {})), function(e) {
            e[e.FREE = 10] = "FREE", e[e.NOT_FREE = 20] = "NOT_FREE";
        }(t.TemplateFeeType || (t.TemplateFeeType = {})), function(e) {
            e[e.ORDER = 0] = "ORDER", e[e.AFTER_SALES = 1] = "AFTER_SALES", e[e.START_GROUP_ORDER = 2] = "START_GROUP_ORDER", 
            e[e.VOUCHER_MANAGE = 3] = "VOUCHER_MANAGE";
        }(t.OrderTabTypeEnum || (t.OrderTabTypeEnum = {})), t.DURATION = 5e3, function(e) {
            e[e.HIDDEN = 5] = "HIDDEN", e[e.SHOW = 10] = "SHOW";
        }(t.SeqVisibleModel || (t.SeqVisibleModel = {})), function(e) {
            e.DEFAULT = "DEFAULT", e.ACT_DETAIL = "ACT_DETAIL", e.MEMBER_LIST = "MEMBER_LIST", 
            e.GH_FRONT = "GH_FRONT", e.MSG_LIST = "MSG_LIST", e.ORDER_LIST = "ORDER_LIST", e.ORDER_DETAIL = "ORDER_DETAIL", 
            e.AFTER_SALE_DETAIL = "AFTER_SALE_DETAIL";
        }(t.ChatEntranceScene || (t.ChatEntranceScene = {})), function(e) {
            e[e.UNAUTHORIZED = 5] = "UNAUTHORIZED", e[e.AUTHORIZED = 10] = "AUTHORIZED";
        }(t.AfterSalesAuthStatus || (t.AfterSalesAuthStatus = {})), function(e) {
            e[e.DECREASE = 0] = "DECREASE", e[e.INCREASE = 1] = "INCREASE", e[e.UNCHANGED = 2] = "UNCHANGED", 
            e[e.PUNISH = 3] = "PUNISH";
        }(t.ChangeType || (t.ChangeType = {})), function(e) {
            e[e.CREDIT_SCORE_INIT = -1] = "CREDIT_SCORE_INIT", e[e.CREDIT_SCORE_RECOVERY = -2] = "CREDIT_SCORE_RECOVERY", 
            e[e.WARN = 15] = "WARN", e[e.PUNISH = 16] = "PUNISH";
        }(t.CreditScoreTypeId || (t.CreditScoreTypeId = {})), t.STAR_DETAIL_STATUS_TEXT = ((D = {})[5] = "已下架", 
        D[10] = "展示中", D[15] = "屏蔽中", D);
    },
    140: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.MonoOrderLabelService = t.labelColorList = t.ORDER_CUSTOM_LABEL_COLOR_TYPE = t.noLabelDefaultConfig = void 0;
        var n, o = r(0), i = r(1), a = r(3);
        t.noLabelDefaultConfig = {
            tagId: 0,
            name: "无标签",
            color: 0,
            colorName: "empty",
            colorValue: "#00000033",
            colorType: 0
        }, function(e) {
            e[e.EMPTY = 0] = "EMPTY", e[e.BLUE = 1] = "BLUE", e[e.PRIMARY = 2] = "PRIMARY", 
            e[e.CYAN = 3] = "CYAN", e[e.PURPLE = 4] = "PURPLE", e[e.WARN = 5] = "WARN", e[e.RED = 6] = "RED";
        }(n = t.ORDER_CUSTOM_LABEL_COLOR_TYPE || (t.ORDER_CUSTOM_LABEL_COLOR_TYPE = {})), 
        t.labelColorList = [ {
            colorName: "blue",
            colorValue: "#3388FF",
            colorType: n.BLUE
        }, {
            colorName: "primary",
            colorValue: "#09BA07",
            colorType: n.PRIMARY
        }, {
            colorName: "cyan",
            colorValue: "#00B3B3",
            colorType: n.CYAN
        }, {
            colorName: "purple",
            colorValue: "#742CDA",
            colorType: n.PURPLE
        }, {
            colorName: "warn",
            colorValue: "#F86D10",
            colorType: n.WARN
        }, {
            colorName: "red",
            colorValue: "#FA5151",
            colorType: n.RED
        } ];
        var s = function() {
            function e() {}
            return e.prototype.setApiService = function(e) {
                this.apiService = e;
            }, e.prototype.getOrderLabelColor = function(e) {
                return t.labelColorList.find(function(t) {
                    return t.colorType === e;
                }) || {};
            }, e.prototype.processOrderLabelList = function(e, t, r) {
                var n = this;
                return void 0 === t && (t = []), e && e.length ? e.map(function(e) {
                    return o.__assign(o.__assign(o.__assign({}, e), n.getOrderLabelColor(e.color)), {
                        isSelected: r || t.map(function(e) {
                            return e.tagId;
                        }).includes(e.tagId)
                    });
                }) : [];
            }, e.prototype.initGhCustomLabelListForPc = function(e, t) {
                var r = this;
                return this.apiService.getGhTagListUsingPOST({
                    ghId: e,
                    ghViewType: t
                }).pipe(a.map(function(e) {
                    var t = e.data;
                    return (void 0 === t ? [] : t).map(function(e) {
                        return o.__assign(o.__assign({}, e), r.getOrderLabelColor(e.color));
                    });
                }));
            }, e = o.__decorate([ i.Injectable(), o.__metadata("design:paramtypes", []) ], e);
        }();
        t.MonoOrderLabelService = s;
    },
    148: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.Throttle = void 0, t.Throttle = function(e, t) {
            return void 0 === e && (e = 100), void 0 === t && (t = {
                leading: !0,
                trailing: !1
            }), function(r, n, o) {
                var i, a = o.value, s = 0, u = [];
                o.value = function() {
                    for (var r = this, n = [], o = 0; o < arguments.length; o++) n[o] = arguments[o];
                    s++, u = n, i || (t.leading && a.apply(this, n), i = setTimeout(function() {
                        !t.trailing || t.leading && 1 === s || a.apply(r, u.slice()), i = 0, s = 0, u.length = 0;
                    }, e));
                };
            };
        };
    },
    149: function(e, t, r) {
        var n, o, i;
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.PublishDraftService = t.draftOperationOriginTextMap = t.draftOperationDeviceTextMap = t.draftBoxTabTextMap = t.DraftBoxTab = void 0;
        var a = r(0), s = r(1), u = r(7), c = r(3), l = r(50), d = r(138), p = r(17), f = r(18);
        !function(e) {
            e[e.ALL = 0] = "ALL", e[e.START_GROUP_PARENT = 10] = "START_GROUP_PARENT", e[e.GROUP_BUY = 30] = "GROUP_BUY", 
            e[e.SUPPLY_LEADER = -30] = "SUPPLY_LEADER", e[e.SIGN_UP = 40] = "SIGN_UP", e[e.LOTTERY = 220] = "LOTTERY", 
            e[e.INTERACT = 60] = "INTERACT", e[e.FORM = 200] = "FORM", e[e.READ = 70] = "READ", 
            e[e.ELECT = 80] = "ELECT", e[e.MARKET = 120] = "MARKET";
        }(t.DraftBoxTab || (t.DraftBoxTab = {})), t.draftBoxTabTextMap = ((n = {})[30] = "团购接龙", 
        n[10] = "开团接龙", n[40] = "报名接龙", n[220] = "抽奖接龙", n[60] = "互动接龙", n[200] = "填表接龙", 
        n[70] = "阅读接龙", n[80] = "评选接龙", n[120] = "集市接龙", n[240] = "抽奖接龙", n), t.draftOperationDeviceTextMap = ((o = {}).mini_pc = "客户端小程序", 
        o.mini_phone = "小程序", o.pc = "PC后台", o), t.draftOperationOriginTextMap = ((i = {})[d.SetDraftBoxOriginEnum.APP] = "自动转存旧草稿", 
        i[d.SetDraftBoxOriginEnum.USER] = "保存草稿", i[d.SetDraftBoxOriginEnum.CRASH] = "异常退出的草稿", 
        i);
        var h = function() {
            function e(e, t, r) {
                this.wxCloudApiService = e, this.timeService = t, this.grayService = r;
            }
            return e.prototype.canIUseDraftBoxFeature = function() {
                return this.grayService.canIUseFeature("2193");
            }, e.prototype.canIUseDraftBoxV2Feature = function(e) {
                return this.grayService.canIUseFeatureHybridDimension([ {
                    code: "2388",
                    type: p.GrayFeatureCodeDimension.GROUP
                } ], {
                    groupId: e
                }).pipe(c.map(function(e) {
                    return a.__read(e, 1)[0];
                }));
            }, e.prototype.checkIsDraftExist = function(e) {
                return this.wxCloudApiService.checkSeqDraftExist(e).pipe(c.map(function(e) {
                    return e.data || !1;
                }), c.catchError(function() {
                    return u.of(!1);
                }));
            }, e.prototype.checkIsDeleteDraftAfterPublish = function(e) {
                e && this.deleteDraft({
                    draftId: e
                }).subscribe();
            }, e.prototype.deleteDraft = function(e) {
                return this.wxCloudApiService.deleteSeqDraftBox(e).pipe(c.map(function() {
                    return !0;
                }), c.catchError(function() {
                    return u.of(!1);
                }));
            }, e.prototype.saveDraft = function(e) {
                return this.wxCloudApiService.setSeqDraftBox(e).pipe(c.map(function(e) {
                    return {
                        isSuccess: !0,
                        draftId: e.data
                    };
                }), c.catchError(function() {
                    return u.of({
                        isSuccess: !1
                    });
                }));
            }, e.prototype.getDraftNum = function(e) {
                return this.wxCloudApiService.getSeqDraftBoxLength(e).pipe(c.map(function(e) {
                    return e.data || 0;
                }));
            }, e.prototype.checkIsExceedDraftLimit = function(e) {
                return this.wxCloudApiService.getSeqDraftBoxLength(e).pipe(c.map(function(e) {
                    return e.data || 0;
                }), c.map(function(t) {
                    return t >= (e.isV2 ? d.DRAFT_BOX_MAX_LIST_LENGTH_V2 : d.DRAFT_BOX_MAX_LIST_LENGTH);
                }));
            }, e.prototype.getDraftDetail = function(e) {
                return this.wxCloudApiService.getSeqDraftBoxDetail(e).pipe(c.map(function(e) {
                    return e.data;
                }));
            }, e.prototype.getDraftList = function(e) {
                return this.wxCloudApiService.getSeqDraftBoxList(e);
            }, e.prototype.formatOperationList = function(e) {
                var t = this;
                return e.map(function(e) {
                    return a.__assign(a.__assign({}, e), {
                        formatTime: t.timeService.formatDateTime(t.timeService.newDate(e.time))
                    });
                }).reverse();
            }, e.prototype.formatPicList = function(e, t) {
                var r = this;
                return void 0 === t && (t = 3), 0 === t ? [] : e.reduce(function(e, n) {
                    if (e.length >= t) return e;
                    var o = n.mediaType, i = n.content, s = n.contentList, u = n.goodsInfo;
                    switch (o) {
                      case "multiImg":
                        s.forEach(function(r) {
                            e.length >= t || e.push(r.content);
                        });
                        break;

                      case "goodsInfo":
                        e.push.apply(e, a.__spread(r.formatPicList(u.goodsInfoDetails, t - e.length)));
                        break;

                      case "singleImg":
                        e.push(i);
                    }
                    return e;
                }, []);
            }, e.prototype.formatPrice = function(e) {
                if (0 !== e.length) {
                    var t = e.reduce(function(e, t) {
                        var r, n = t.actGroupBuyPrice, o = t.mutiActGoodsInfoParam;
                        return o ? (null === (r = null == o ? void 0 : o.actGoodsSkuParam) || void 0 === r || r.forEach(function(t) {
                            var r = t.groupBuyPrice;
                            (r || 0 === r) && (r < e.min && (e.min = r), r > e.max && (e.max = r));
                        }), e) : n || 0 === n ? (100 * n < e.min && (e.min = 100 * n), 100 * n > e.max && (e.max = 100 * n), 
                        e) : e;
                    }, {
                        min: 1e17,
                        max: -100
                    }), r = t.min, n = t.max;
                    if (1e17 !== r || -100 !== n) {
                        var o = Number((r / 100).toFixed(2)), i = Number((n / 100).toFixed(2));
                        return i === o ? "" + o : o + "~" + i;
                    }
                }
            }, e = a.__decorate([ s.Injectable(), a.__metadata("design:paramtypes", [ l.WxCloudApiService, f.TimeService, p.GrayFeatureService ]) ], e);
        }();
        t.PublishDraftService = h;
    },
    155: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.MonoOrderRemarkService = void 0;
        var n = r(0), o = r(1), i = r(11), a = function() {
            function e(e) {
                this.monoUtil = e, this.initRemarkRoleTextMap();
            }
            return e.prototype.getRemarkRoleText = function(e, t) {
                var r;
                return 1e3 === t ? "系统" : this.monoUtil.isEmpty(e) || this.monoUtil.isEmpty(t) ? "" : (null === (r = n.__spread(this.remarkRoleTextMap).find(function(r) {
                    var o = n.__read(r, 2), i = o[0];
                    return o[1], i.test(e + "_" + t);
                })) || void 0 === r ? void 0 : r[1]) || "";
            }, e.prototype.formatLastRemarkContentStr = function(e) {
                var t = "", r = (e || []).reduce(function(e, r) {
                    var o = r.content, i = r.type;
                    return "text" === i ? t += (o[0] || "") + " " : e[i] = n.__spread(o || []), e;
                }, {
                    image: [],
                    video: [],
                    logistics: []
                }), o = r.image, i = r.video, a = r.logistics;
                return o.length > 0 && (t += "[图片]" + (o.length > 1 ? "x" + o.length : "") + " "), 
                i.length > 0 && (t += "[视频]" + (i.length > 1 ? "x" + i.length : "") + " "), a.length > 0 && a.forEach(function(e) {
                    t += "[售后物流：" + e.logisticsCompany + "，" + e.logisticsNo + "] ";
                }), t;
            }, e.prototype.getUpdateRemarkInfoContent = function(e, t, r) {
                var o, i = r.type, a = r.content, s = r.targetIndex, u = this.getUpdateRemarkInfoIndex(t, i);
                return "add" === e ? o = n.__spread(t[u].content, a || []) : "replace" === e ? o = a : "remove" === e && (o = n.__spread(t[u].content)).splice(s, 1), 
                o;
            }, e.prototype.getUpdateRemarkInfoIndex = function(e, t) {
                return e.findIndex(function(e) {
                    return e.type === t;
                });
            }, e.prototype.adjustRemarkInfo = function(e, t) {
                var r;
                void 0 === t && (t = !1);
                var n = JSON.parse(JSON.stringify(e));
                if (t) {
                    var o = n.find(function(e) {
                        return "text" === e.type;
                    }), i = this.filterEmptyRemark(JSON.parse(JSON.stringify(e))).length ? "" : "无", a = (null === (r = o.content) || void 0 === r ? void 0 : r[0]) || i;
                    o.content[0] = a ? "#退款备注# " + a : "#退款备注#";
                }
                return this.filterEmptyRemark(n);
            }, e.prototype.filterEmptyRemark = function(e) {
                return e.filter(function(e) {
                    return !!e.content && e.content.filter(function(e) {
                        return "string" == typeof e ? e.trim() : e;
                    }).length > 0;
                });
            }, e.prototype.initRemarkRoleTextMap = function() {
                var e, t = ((e = {})["0_0"] = "我", e["0_40"] = "发起人", e["0_50"] = "发起人", e["0_."] = "团长", 
                e["10_0"] = "顾客", e["10_10"] = "我", e["10_."] = "发起人", e["70_0"] = "顾客", e["70_10"] = "团长", 
                e["70_70"] = "我", e["70_."] = "发起人", e["20_0"] = "顾客", e["20_10"] = "团长", e["20_70"] = "团长", 
                e["20_20"] = "我", e["20_."] = "品牌", e["30_0"] = "顾客", e["30_30"] = "我", e["30_."] = "团长", 
                e["60_0"] = "顾客", e["60_60"] = "我", e["60_."] = "团长", e["40_0"] = "顾客", e["40_40"] = "我", 
                e["40_50"] = "发起人", e["50_0"] = "顾客", e["50_40"] = "摊主", e["50_50"] = "我", e);
                this.remarkRoleTextMap = new Map(Object.entries(t).map(function(e) {
                    var t = n.__read(e, 2), r = t[0], o = t[1];
                    return [ new RegExp("^" + r), o ];
                }));
            }, e = n.__decorate([ o.Injectable(), n.__metadata("design:paramtypes", [ i.MonoUtilService ]) ], e);
        }();
        t.MonoOrderRemarkService = a;
    },
    168: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.MonoImDataService = void 0;
        var n = r(0), o = r(1), i = r(35), a = r(436), s = function() {
            function e(e) {
                this.monoChatUtilsService = e;
            }
            return e.prototype.generateLoginUserId = function(e, t) {
                return i.userType2Prefix[t] + "_" + e;
            }, e.prototype.parseLoginUserId = function(e) {
                var t = e.match(/^(u|g|o)_/);
                if (!t) throw new Error("IM 错误的登录名解析 => loginUserId: " + e);
                var r = t[0].replace("_", "");
                return {
                    userId: e.replace(/^(u|g|o)_/, ""),
                    userType: i.prefix2UserType[r]
                };
            }, e.prototype.getContentByIChat = function(e) {
                var t, r = e.type, n = this.getDescByChat(e);
                return ((t = {})[i.ChatType.IMG] = "[图片]", t[i.ChatType.TEXT] = n, t[i.ChatType.VIDEO] = "[视频]", 
                t[i.ChatType.RADIO] = "[语音]", t[i.ChatType.VOUCHER] = n, t[i.ChatType.ACTIVITY] = n, 
                t[i.ChatType.WAIT_SEND_VOUCHER] = "待发送凭证", t[i.ChatType.WAIT_SEND_ACTIVITY] = "待发送活动", 
                t[i.ChatType.NOTICE] = n, t[i.ChatType.GUIDE_TIPS] = n, t[i.ChatType.BRAND_CARD] = "给您推荐了一个货源品牌", 
                t[i.ChatType.LEADER_CARD] = "给您推荐了一个货源团长", t[i.ChatType.COURSE_CARD] = "[给您推荐了一个精品课程]", 
                t[i.ChatType.FAST_REPLY] = n, t[i.ChatType.GROUP_CARD] = "给您推荐了一个主页", t[i.ChatType.IMG_LIST] = "[图片]", 
                t[i.ChatType.CANCEL_SEQ_CARD] = "[给您发起一个订单]", t[i.ChatType.BUBBLE_ERROR] = "有一条新消息", 
                t[i.ChatType.CARD_ERROR] = "有一条新消息", t[i.ChatType.NEW_ACTIVITY] = n, t[i.ChatType.SEQ_GAME] = "给您推荐了一个接龙大赛", 
                t[i.ChatType.CUSTOM_TEXT] = n, t[i.ChatType.TODAY_BEST_SELLERS] = n, t[i.ChatType.DAILY_DATA_REPORT] = "领取最新的运营日报，点击查看详情", 
                t[i.ChatType.HELP_SALE_ACTIVITY] = n, t[i.ChatType.CREATE_LEADER_AD_CARD] = n, t[i.ChatType.STAR_LEADER_COMMUNITY_CARD] = "给您推荐了一个社群", 
                t[i.ChatType.JOIN_WECHAT_GROUP_CARD] = "[邀请你加入帮卖群，一起帮卖更放心]", t[i.ChatType.NAME_CARD] = "[给你发了联系信息]", 
                t[i.ChatType.COMMON_CARD] = "有一张新的卡片，点击查看详情", t[i.ChatType.DELETE_INVALID_LEADER_CARD] = n, 
                t[i.ChatType.HAS_AUTO_DELETE_CARD] = n, t[i.ChatType.IM_EVALUATION_CARD] = "服务完毕请评价", 
                t[i.ChatType.AFTER_SALE_ORDER_CARD] = "[给您发起一个售后订单]", t[i.ChatType.SEQ_RANKING_CARD] = "今日榜单已更新，热销爆品等你帮卖~", 
                t[i.ChatType.INVITE_BUILD_RELATIONSHIP] = "[给您发起一个邀请]", t[i.ChatType.HELP_SALE_NOTICE_CARD] = "[团长发布了新的帮卖活动]", 
                t[i.ChatType.RICH_TEXT_CARD] = "", t[i.ChatType.NEW_RECOMMEND_CARD] = "给您推荐了一个货源主页", 
                t[i.ChatType.NONE] = "", t)[r];
            }, e.prototype.getDescByChat = function(e) {
                var t = e.type, r = "";
                try {
                    t === i.ChatType.VOUCHER ? r = this.getVoucherMessage(e) : t === i.ChatType.TEXT || t === i.ChatType.CUSTOM_TEXT ? r = this.getTextMessage(e) : t === i.ChatType.NOTICE ? r = this.getNoticeMessage(e) : t === i.ChatType.TODAY_BEST_SELLERS ? r = this.getExtraInfoMessage(e, "今日热卖爆品Top5") : t === i.ChatType.CREATE_LEADER_AD_CARD ? r = this.getExtraInfoMessage(e) : t === i.ChatType.FAST_REPLY ? r = this.getFastReplyInfoMessage(e) : t === i.ChatType.DELETE_INVALID_LEADER_CARD ? r = this.getDeleteInvalidLeaderMessage(e) : t === i.ChatType.HAS_AUTO_DELETE_CARD ? r = this.getHasAutoDeleteMessage(e) : t === i.ChatType.GUIDE_TIPS ? r = this.getGuideTipsMessage(e) : t !== i.ChatType.ACTIVITY && t !== i.ChatType.NEW_ACTIVITY && t !== i.ChatType.HELP_SALE_ACTIVITY || (r = this.getActivityMessage(e));
                } catch (e) {}
                return r;
            }, e.prototype.getTextMessage = function(e) {
                return e.content.resource;
            }, e.prototype.getVoucherMessage = function(e) {
                var t = e.content.voucherInfo, r = t && t.productList.length || 0;
                return r ? "[给你发了" + r + "种商品]" : "[给你发了商品]";
            }, e.prototype.getNoticeMessage = function(e) {
                return e.content.noticeOption.noticeContent || "";
            }, e.prototype.getExtraInfoMessage = function(e, t) {
                void 0 === t && (t = "");
                var r = e.content.extraInfo;
                return r && r.desc || t;
            }, e.prototype.getGuideTipsMessage = function(e) {
                return this.monoChatUtilsService.stringifyGuideTips(e.content.guideTips || "", "");
            }, e.prototype.getFastReplyInfoMessage = function(e) {
                var t = e.content.fastReplyInfo;
                return (null == t ? void 0 : t.title) ? "[给您推荐「" + t.title + "」]" : this.stringifyRichTextList((null == t ? void 0 : t.content) || []);
            }, e.prototype.getDeleteInvalidLeaderMessage = function(e) {
                var t = e.content.deleteInvalidLeader;
                return (null == t ? void 0 : t.title) || "";
            }, e.prototype.getHasAutoDeleteMessage = function(e) {
                var t = e.content.hasAutoDelete;
                return (null == t ? void 0 : t.title) || "";
            }, e.prototype.getActivityMessage = function(e) {
                return "[给你发了1个活动]";
            }, e.prototype.stringifyRichTextList = function(e) {
                return e.map(function(e) {
                    return "text" === e.mediaType ? e.content || "" : "singleImg" === e.mediaType || "multiImg" === e.mediaType ? "[图片]" : "video" === e.mediaType ? "[视频]" : "";
                }).join("");
            }, e = n.__decorate([ o.Injectable(), n.__metadata("design:paramtypes", [ a.MonoChatUtilsService ]) ], e);
        }();
        t.MonoImDataService = s;
    },
    17: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.GrayFeatureService = t.GrayFeatureCodeDimension = void 0;
        var n, o = r(0), i = r(1), a = r(7), s = r(3), u = r(11), c = r(24), l = r(264), d = r(18);
        !function(e) {
            e.USER = "user", e.GROUP = "group";
        }(n = t.GrayFeatureCodeDimension || (t.GrayFeatureCodeDimension = {}));
        var p = function() {
            function e(e, t) {
                this.monoUtilService = e, this.errorService = t, this.grayFeatureListByGroupId = {}, 
                this.isRequesting = !1, this.requestCanIUseByGroupId = {}, this.getUidGraySuccess = !1, 
                this.lastUpdateTime = 0;
            }
            return e.prototype.setApiService = function(e) {
                this.api = e;
            }, e.prototype.canIUseFeature = function(e, t) {
                var r = this;
                return void 0 === t && (t = !1), e ? (this.isRequesting = !0, this.getGrayFeatureListByUidObs(t).pipe(s.map(function() {
                    return r.isRequesting = !1, r.checkIsFeatureEnabled(e);
                }))) : a.of(!1);
            }, e.prototype.canIUseFeatureByMultiply = function(e, t) {
                var r = this;
                return void 0 === t && (t = !1), e && e.length > 0 ? this.getGrayFeatureListByUidObs(t).pipe(s.map(function() {
                    return r.checkFeatureListEnabled(e);
                })) : a.of([]);
            }, e.prototype.canGhUseFeature = function(e, t) {
                var r = {};
                return this.api.canGhsUseUsingPOST({
                    code: Number(e),
                    ghIds: t
                }).pipe(s.map(function(e) {
                    var t, n, i = e.data, a = void 0 === i ? [] : i;
                    try {
                        for (var s = o.__values(a), u = s.next(); !u.done; u = s.next()) {
                            var c = u.value;
                            r[c.ghId] = !!c.canGhUse;
                        }
                    } catch (e) {
                        t = {
                            error: e
                        };
                    } finally {
                        try {
                            u && !u.done && (n = s.return) && n.call(s);
                        } finally {
                            if (t) throw t.error;
                        }
                    }
                    return r;
                }));
            }, e.prototype.canIUseFeatureHybridDimensionUsingMapParams = function(e, t, r) {
                void 0 === t && (t = {}), void 0 === r && (r = !1);
                var n = Object.keys(e), o = Object.values(e);
                return this.canIUseFeatureHybridDimension(o, t, r).pipe(s.map(function(e) {
                    var t = {};
                    return n.forEach(function(r, n) {
                        t[r] = e[n];
                    }), t;
                }));
            }, e.prototype.canIUseFeatureHybridDimension = function(e, t, r) {
                var o = this;
                void 0 === t && (t = {}), void 0 === r && (r = !1);
                var i = e.some(function(e) {
                    return e.type === n.USER;
                }), u = e.some(function(e) {
                    return e.type === n.GROUP;
                }), c = t.groupId, l = [];
                return e && e.length > 0 ? u && !c ? a.of([]) : (i && l.push(this.getGrayFeatureListByUidObs(r)), 
                u && l.push(this.getGrayFeatureListByGidObs(c)), a.forkJoin(l).pipe(s.map(function() {
                    return o.checkFeatureListEnabled(e, t);
                }))) : a.of([]);
            }, e.prototype.updateGrayFeature = function(e) {
                var t = this;
                +new Date() - this.lastUpdateTime > 60 * e * d.MS_SECOND && this.requestCanIUse({
                    isSkipDefaultLoginCheck: !0,
                    isSkipPageMarking: !0,
                    hideErrorToast: !0
                }).subscribe(function(e) {
                    t.grayFeatureList = e || [];
                });
            }, e.prototype.getGrayFeatureSync = function(e) {
                var t = this.grayFeatureList;
                return !!t && -1 !== t.indexOf(e);
            }, e.prototype.checkFeatureListEnabled = function(e, t) {
                var r = this;
                return void 0 === t && (t = {}), e.map(function(e) {
                    return r.isHybridItem(e) ? e.type === n.USER ? r.checkIsFeatureEnabled(e.code) : r.checkIsFeatureEnabledByGroupId(e.code, t.groupId) : r.checkIsFeatureEnabled(e);
                });
            }, e.prototype.checkIsFeatureEnabled = function(e) {
                return -1 !== this.grayFeatureList.indexOf(e);
            }, e.prototype.getGrayFeatureListByUidObs = function(e) {
                var t = this, r = {
                    isSkipDefaultLoginCheck: e,
                    isSkipPageMarking: !0,
                    hideErrorToast: !0
                };
                return this.grayFeatureList ? a.of(this.grayFeatureList) : this.requestCanIUse(r).pipe(s.map(function(e) {
                    return t.grayFeatureList = e || [], t.grayFeatureList;
                }));
            }, e.prototype.getGrayFeatureListByGidObs = function(e) {
                var t = this;
                return this.grayFeatureListByGroupId[e] ? a.of(this.grayFeatureListByGroupId[e]) : this.requestGidCanIUse(e, {
                    isSkipDefaultLoginCheck: !1,
                    isSkipPageMarking: !0,
                    hideErrorToast: !0
                }).pipe(s.map(function(r) {
                    return t.grayFeatureListByGroupId[e] = r || [], t.grayFeatureListByGroupId[e];
                }));
            }, e.prototype.checkIsFeatureEnabledByGroupId = function(e, t) {
                return -1 !== (this.grayFeatureListByGroupId[t] || []).indexOf(e);
            }, e.prototype.requestCanIUse = function(e) {
                var t, r = this;
                return e.isSkipDefaultLoginCheck ? (this.isSkipLoginRequestCanIUse || (this.isSkipLoginRequestCanIUse = l.replayCacheByObs(this.canIUseObs(e))), 
                t = this.isSkipLoginRequestCanIUse) : (this.notSkipLoginRequestCanIUse || (this.notSkipLoginRequestCanIUse = l.replayCacheByObs(this.canIUseObs(e))), 
                t = this.notSkipLoginRequestCanIUse), t.pipe(s.finalize(function() {
                    e.isSkipDefaultLoginCheck ? r.isSkipLoginRequestCanIUse = void 0 : r.notSkipLoginRequestCanIUse = void 0;
                }));
            }, e.prototype.requestGidCanIUse = function(e, t) {
                var r = this.requestCanIUseByGroupId;
                return r[e] || (r[e] = l.replayCacheByObs(this.canGhUseObs(e, t))), r[e].pipe(s.finalize(function() {
                    r[e] = void 0;
                }));
            }, e.prototype.isHybridItem = function(e) {
                return !!e.type;
            }, e.prototype.canIUseObs = function(e) {
                var t = this;
                return this.api.canIUseV2UsingGET(e).pipe(s.map(function(e) {
                    var t = e.data;
                    return (null == t ? void 0 : t.canUseCodes) || [];
                }), s.catchError(function() {
                    return t.api.canIUseUsingGET(e).pipe(s.map(function(e) {
                        var r = e.data;
                        return t.filterResultTrueGrayCode((null == r ? void 0 : r.grayReleasedItemList) || []);
                    }));
                }));
            }, e.prototype.canGhUseObs = function(e, t) {
                var r = this;
                return this.api.canGhUseV2UsingPOST({
                    ghId: e
                }, t).pipe(s.map(function(e) {
                    var t = e.data;
                    return (null == t ? void 0 : t.canUseCodes) || [];
                }), s.catchError(function() {
                    return r.api.canGhUseUsingPOST({
                        ghId: e
                    }, t).pipe(s.map(function(e) {
                        var t = e.data;
                        return r.filterResultTrueGrayCode((null == t ? void 0 : t.grayReleasedItemList) || []);
                    }));
                }));
            }, e.prototype.filterResultTrueGrayCode = function(e) {
                return e.reduce(function(e, t) {
                    return t.canIUse && e.push(t.code), e;
                }, []);
            }, e = o.__decorate([ i.Injectable(), o.__metadata("design:paramtypes", [ u.MonoUtilService, c.ErrorService ]) ], e);
        }();
        t.GrayFeatureService = p;
    },
    175: function(e, t, r) {
        (function(t) {
            var r;
            e.exports = r = r || function(e, r) {
                var n;
                "undefined" != typeof window && window.crypto && (n = window.crypto), !n && "undefined" != typeof window && window.msCrypto && (n = window.msCrypto), 
                !n && void 0 !== t && t.crypto && (n = t.crypto);
                var o = function() {
                    if (n) {
                        if ("function" == typeof n.getRandomValues) try {
                            return n.getRandomValues(new Uint32Array(1))[0];
                        } catch (e) {}
                        if ("function" == typeof n.randomBytes) try {
                            return n.randomBytes(4).readInt32LE();
                        } catch (e) {}
                    }
                    throw new Error("Native crypto module could not be used to get secure random number.");
                }, i = Object.create || function() {
                    function e() {}
                    return function(t) {
                        var r;
                        return e.prototype = t, r = new e(), e.prototype = null, r;
                    };
                }(), a = {}, s = a.lib = {}, u = s.Base = {
                    extend: function(e) {
                        var t = i(this);
                        return e && t.mixIn(e), t.hasOwnProperty("init") && this.init !== t.init || (t.init = function() {
                            t.$super.init.apply(this, arguments);
                        }), t.init.prototype = t, t.$super = this, t;
                    },
                    create: function() {
                        var e = this.extend();
                        return e.init.apply(e, arguments), e;
                    },
                    init: function() {},
                    mixIn: function(e) {
                        for (var t in e) e.hasOwnProperty(t) && (this[t] = e[t]);
                        e.hasOwnProperty("toString") && (this.toString = e.toString);
                    },
                    clone: function() {
                        return this.init.prototype.extend(this);
                    }
                }, c = s.WordArray = u.extend({
                    init: function(e, t) {
                        e = this.words = e || [], this.sigBytes = null != t ? t : 4 * e.length;
                    },
                    toString: function(e) {
                        return (e || d).stringify(this);
                    },
                    concat: function(e) {
                        var t = this.words, r = e.words, n = this.sigBytes, o = e.sigBytes;
                        if (this.clamp(), n % 4) for (var i = 0; i < o; i++) {
                            var a = r[i >>> 2] >>> 24 - i % 4 * 8 & 255;
                            t[n + i >>> 2] |= a << 24 - (n + i) % 4 * 8;
                        } else for (i = 0; i < o; i += 4) t[n + i >>> 2] = r[i >>> 2];
                        return this.sigBytes += o, this;
                    },
                    clamp: function() {
                        var t = this.words, r = this.sigBytes;
                        t[r >>> 2] &= 4294967295 << 32 - r % 4 * 8, t.length = e.ceil(r / 4);
                    },
                    clone: function() {
                        var e = u.clone.call(this);
                        return e.words = this.words.slice(0), e;
                    },
                    random: function(e) {
                        for (var t = [], r = 0; r < e; r += 4) t.push(o());
                        return new c.init(t, e);
                    }
                }), l = a.enc = {}, d = l.Hex = {
                    stringify: function(e) {
                        for (var t = e.words, r = e.sigBytes, n = [], o = 0; o < r; o++) {
                            var i = t[o >>> 2] >>> 24 - o % 4 * 8 & 255;
                            n.push((i >>> 4).toString(16)), n.push((15 & i).toString(16));
                        }
                        return n.join("");
                    },
                    parse: function(e) {
                        for (var t = e.length, r = [], n = 0; n < t; n += 2) r[n >>> 3] |= parseInt(e.substr(n, 2), 16) << 24 - n % 8 * 4;
                        return new c.init(r, t / 2);
                    }
                }, p = l.Latin1 = {
                    stringify: function(e) {
                        for (var t = e.words, r = e.sigBytes, n = [], o = 0; o < r; o++) {
                            var i = t[o >>> 2] >>> 24 - o % 4 * 8 & 255;
                            n.push(String.fromCharCode(i));
                        }
                        return n.join("");
                    },
                    parse: function(e) {
                        for (var t = e.length, r = [], n = 0; n < t; n++) r[n >>> 2] |= (255 & e.charCodeAt(n)) << 24 - n % 4 * 8;
                        return new c.init(r, t);
                    }
                }, f = l.Utf8 = {
                    stringify: function(e) {
                        try {
                            return decodeURIComponent(escape(p.stringify(e)));
                        } catch (e) {
                            throw new Error("Malformed UTF-8 data");
                        }
                    },
                    parse: function(e) {
                        return p.parse(unescape(encodeURIComponent(e)));
                    }
                }, h = s.BufferedBlockAlgorithm = u.extend({
                    reset: function() {
                        this._data = new c.init(), this._nDataBytes = 0;
                    },
                    _append: function(e) {
                        "string" == typeof e && (e = f.parse(e)), this._data.concat(e), this._nDataBytes += e.sigBytes;
                    },
                    _process: function(t) {
                        var r, n = this._data, o = n.words, i = n.sigBytes, a = this.blockSize, s = i / (4 * a), u = (s = t ? e.ceil(s) : e.max((0 | s) - this._minBufferSize, 0)) * a, l = e.min(4 * u, i);
                        if (u) {
                            for (var d = 0; d < u; d += a) this._doProcessBlock(o, d);
                            r = o.splice(0, u), n.sigBytes -= l;
                        }
                        return new c.init(r, l);
                    },
                    clone: function() {
                        var e = u.clone.call(this);
                        return e._data = this._data.clone(), e;
                    },
                    _minBufferSize: 0
                }), S = (s.Hasher = h.extend({
                    cfg: u.extend(),
                    init: function(e) {
                        this.cfg = this.cfg.extend(e), this.reset();
                    },
                    reset: function() {
                        h.reset.call(this), this._doReset();
                    },
                    update: function(e) {
                        return this._append(e), this._process(), this;
                    },
                    finalize: function(e) {
                        return e && this._append(e), this._doFinalize();
                    },
                    blockSize: 16,
                    _createHelper: function(e) {
                        return function(t, r) {
                            return new e.init(r).finalize(t);
                        };
                    },
                    _createHmacHelper: function(e) {
                        return function(t, r) {
                            return new S.HMAC.init(e, r).finalize(t);
                        };
                    }
                }), a.algo = {});
                return a;
            }(Math);
        }).call(this, r(2));
    },
    18: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.TimeService = t.MS_SECOND = void 0;
        var n = r(0), o = r(7), i = r(3), a = r(1);
        t.MS_SECOND = 1e3;
        var s = [ [ "Y", 31536e6 ], [ "M", 2592e6 ], [ "D", 864e5 ], [ "H", 36e5 ], [ "m", 6e4 ], [ "s", 1e3 ], [ "S", 1 ] ], u = function() {
            function e() {
                var e = this;
                this.calCountDown = function(t, r, n, a, s) {
                    return void 0 === r && (r = 1e3), void 0 === n && (n = !0), void 0 === s && (s = !1), 
                    o.timer(1, r).pipe(i.map(function() {
                        return e.getCalCountDownStr(t, r, n, a, s);
                    }));
                }, this.getCalCountDownStr = function(t, r, n, o, i) {
                    void 0 === r && (r = 1e3), void 0 === n && (n = !0), void 0 === i && (i = !1);
                    var a = new Date().getTime(), s = new Date(t).getTime(), u = (s - a) / 1e3;
                    if (u < 0) return "over";
                    var c = 1e3 / r;
                    if (o) {
                        var l = Math.max(s - a, 0);
                        return e.formatDurationStr(l, o);
                    }
                    if (n) {
                        var d = Math.floor(u / 86400), p = e.timeNum(Math.floor(u / 3600 % 24)), f = e.timeNum(Math.floor(u / 60 % 60)), h = e.timeNum(Math.floor(u % 60 * c) / c, 1e3 !== r);
                        return i ? " " + d + " : " + p + " : " + f + " : " + h + " " : " " + d + " 天 " + p + " 小时 " + f + " 分钟 " + h + " 秒";
                    }
                    return " " + (p = e.timeNum(Math.floor(u / 3600))) + " : " + (f = e.timeNum(Math.floor(u / 60 % 60))) + " : " + (h = e.timeNum(Math.floor(u % 60 * c) / c, 1e3 !== r)) + " ";
                };
            }
            return e.prototype.formatDurationStr = function(e, t) {
                var r = e, o = /\[[^\]]*]/g, i = (t.match(o) || []).map(function(e) {
                    return e.slice(1, -1);
                }), a = t.replace(o, "[]"), u = 0;
                return s.reduce(function(e, t) {
                    var o = n.__read(t, 2), i = o[0], a = o[1];
                    if (-1 !== e.indexOf(i)) {
                        var s = Math.floor(r / a);
                        return r -= s * a, e.replace(new RegExp(i + "+", "g"), function(e) {
                            var t = e.length;
                            return s.toString().padStart(t, "0");
                        });
                    }
                    return e;
                }, a).replace(o, function() {
                    var e = i[u];
                    return u += 1, e;
                });
            }, e.prototype.formatDateAndHideCurrentYear = function(e, t) {
                if (void 0 === t && (t = "yyyy年MM月dd日 HH:mm:ss"), "Invalid Date" === String(e)) return "";
                var r = e.getFullYear() === new Date().getFullYear() && t.match(/MM(.*)/)[0] || t;
                return this.formatDateTime(e, r);
            }, e.prototype.formatDateTime = function(e, t) {
                var r = this;
                if (void 0 === t && (t = "yyyy-MM-dd HH:mm:ss"), "Invalid Date" === String(e)) return "";
                var n = {
                    yyyy: e.getFullYear(),
                    yy: String(e.getFullYear()).slice(2),
                    MM: e.getMonth() + 1,
                    dd: e.getDate(),
                    HH: e.getHours(),
                    mm: e.getMinutes(),
                    ss: e.getSeconds(),
                    qq: Math.floor((e.getMonth() + 3) / 3),
                    fff: String(e.getMilliseconds()).padStart(3, "0"),
                    f: Math.floor(e.getMilliseconds() / 100)
                }, o = Reflect.ownKeys(n).reduce(function(e, t, r, n) {
                    return e + t + (r === n.length - 1 ? ")" : "|");
                }, "("), i = new RegExp(o, "g");
                return t.replace(i, function(e, t) {
                    return "fff" === e || "f" === e ? String(parseInt(n[t], 10)) : r.timeNum(parseInt(n[t], 10));
                });
            }, e.prototype.formatDate = function(e) {
                return this.formatDateTime(e, "yyyy-MM-dd");
            }, e.prototype.formatTime = function(e) {
                return this.formatDateTime(e, "HH:mm");
            }, e.prototype.formatTimeSecond = function(e) {
                var t = new Date(1e3 * e);
                return this.formatDateTime(t, "mm:ss");
            }, e.prototype.yesterdayDate = function() {
                return new Date(+new Date() - 864e5);
            }, e.prototype.tomorrowDate = function() {
                return new Date(+new Date() + 864e5);
            }, e.prototype.aWeekLaterDate = function() {
                return new Date(+new Date() + 6048e5);
            }, e.prototype.aWeekBeforeDate = function() {
                return new Date(+new Date() - 6048e5);
            }, e.prototype.aMonthBeforeDate = function() {
                return new Date(+new Date() - 2592e6);
            }, e.prototype.aYearBeforeDate = function() {
                return new Date(+new Date() - 31104e6);
            }, e.prototype.noExpireDate = function() {
                return new Date(+new Date() + 3079296e6);
            }, e.prototype.defaultDeadline = function() {
                var e = this.aWeekLaterDate();
                return {
                    date: this.formatDate(e),
                    time: this.formatTime(e)
                };
            }, e.prototype.restTime = function(e, t, r) {
                void 0 === t && (t = !0), void 0 === r && (r = !1);
                var n = this.newDate(e).getTime(), o = Date.now(), i = n - o;
                if (i < 0 && r && (n = o, i = 0), i < 0) throw new Error("输入的结束时间必须大于当前时间");
                var a = (n - o) / 1e3, s = Math.floor(a / 86400), u = Math.floor(a / 3600 % 24), c = Math.floor(a / 60 % 60), l = Math.floor(a % 60), d = "";
                return s > 0 && (d += s + "天"), u > 0 && (d += (t ? this.timeNum(u) : u) + "小时"), 
                c > 0 && (d += (t ? this.timeNum(c) : c) + "分钟"), l > 0 && (d += (t ? this.timeNum(l) : l) + "秒"), 
                d;
            }, e.prototype.restTimeFormat = function(e, t, r) {
                void 0 === t && (t = !0);
                var n = this.newDate(e).getTime() - Date.now();
                if (n < 0) throw new Error("输入的结束时间必须大于当前时间");
                var o = n / 1e3, i = Math.floor(o / 86400), a = Math.ceil(o / 86400), s = Math.floor(o / 3600 % 24), u = Math.floor(o / 60 % 60), c = Math.floor(o % 60), l = n - 1e3 * Math.floor(o), d = r ? this.formatDateTime(new Date(1900, 0, 1, s, u, c, l), r) : "";
                return {
                    upCeilDay: String(a),
                    day: String(i),
                    hour: t ? this.timeNum(s) : String(s),
                    minute: t ? this.timeNum(u) : String(u),
                    second: t ? this.timeNum(c) : String(c),
                    ms: t ? String(l).padStart(3, "0") : String(l),
                    timeStr: d
                };
            }, e.prototype.isToday = function(e) {
                e = new Date(e);
                var t = new Date(), r = !1, n = t.getTime() - e.getTime();
                return this.getMinutes(n) <= 60 * t.getHours() && (r = !0), r;
            }, e.prototype.passDate = function(e, t, r, n, o) {
                var i = this;
                void 0 === t && (t = 30), void 0 === r && (r = !1), void 0 === n && (n = !1), void 0 === o && (o = !1), 
                t > 60 && (t = 60);
                var a = (e = new Date(e)).getTime(), s = new Date(e).setHours(0, 0, 0, 0), u = [ "年前", "个月前", "天前", "小时前", "分钟前" ], c = new Date().getTime() - a, l = ~~((new Date().setHours(0, 0, 0, 0) - s) / 864e5), d = [ ~~(l / 365), ~~(l / 30), l, ~~(c / 36e5), ~~(c / 6e4) ], p = "";
                return d.every(function(e) {
                    return 0 === e;
                }) ? "刚刚" : (d.some(function(a, s) {
                    if (!a) return !1;
                    if (p = "" + a + u[s], 4 === s && a < t) p = "刚刚"; else if (2 !== s || 1 !== a || r || n) if (0 !== s || 1 !== a || n) {
                        if ([ 3, 4 ].includes(s) && o) {
                            var c = new Date(e), l = i.timeNum(c.getHours()), d = i.timeNum(c.getMinutes());
                            p = l + ":" + d;
                        }
                    } else p = "去年"; else p = "昨天";
                    return !0;
                }), p || e.getMonth() + 1 + "月" + e.getDate() + "日");
            }, e.prototype.calCountDownObs$ = function(e, t) {
                var r = this;
                return void 0 === t && (t = 1e3), o.timer(1, t).pipe(i.map(function() {
                    var n = new Date().getTime(), o = (new Date(e).getTime() - n) / 1e3, i = 1e3 / t;
                    return o < 0 ? "over" : {
                        day: Math.floor(o / 86400),
                        hour: r.timeNum(Math.floor(o / 3600 % 24)),
                        minute: r.timeNum(Math.floor(o / 60 % 60)),
                        seconds: r.timeNum(Math.floor(o % 60 * i) / i, 1e3 !== t)
                    };
                }));
            }, e.prototype.getHours = function(e) {
                return Math.floor(e / 36e5);
            }, e.prototype.getMinutes = function(e) {
                return Math.floor(e / 6e4);
            }, e.prototype.getDays = function(e) {
                return Math.floor(e / 864e5);
            }, e.prototype.timeNum = function(e, t) {
                return void 0 === t && (t = !1), e >= 10 ? Math.floor(e) === e && t ? e + ".0" : "" + e : Math.floor(e) === e && t ? "0" + e + ".0" : "0" + e;
            }, e.prototype.newDate = function(e) {
                return e instanceof Date ? e : "number" == typeof e ? new Date(e) : "string" == typeof e ? new Date(this.iosTimeStr(e)) : new Date();
            }, e.prototype.iosTimeStr = function(e) {
                return e.includes("T") ? e : e.replace(/-/g, "/");
            }, e.prototype.getWeekOfYear = function() {
                var e = new Date(), t = new Date(e.getFullYear(), 0, 1), r = e.getDay();
                0 === r && (r = 7);
                var n = t.getDay();
                0 === n && (n = 7);
                var o = ((e.getTime() - t.getTime()) / 864e5 + n - r) / 7 + 1;
                return Math.floor(o);
            }, e.prototype.getCurrentDay = function() {
                return new Date().getTime() - new Date().getTime() % 864e5;
            }, e.prototype.getRestTimeStr = function(e, t, r) {
                var n = this;
                return void 0 === t && (t = 1e3), o.interval(t).pipe(i.map(function() {
                    var t = n.restTimeFormat(e, !1, r), o = t.day, i = t.hour, a = t.second, s = t.minute, u = t.ms, c = t.timeStr;
                    if (r) return o + "天" + c;
                    var l = "";
                    return [ [ o, "天" ], [ i, "小时" ], [ s, "分钟" ], [ a, "秒" ], [ u, "毫秒" ] ].forEach(function(e) {
                        var t = e[0];
                        (l.length > 0 || 0 !== Number(t)) && (l += "" + t + e[1]);
                    }), l;
                }), i.catchError(function(e) {
                    return o.of("over");
                }));
            }, e.prototype.isLastDayOfMonth = function(e) {
                var t = new Date(e.getFullYear(), e.getMonth() + 1, 0);
                return e.getDate() === t.getDate();
            }, e.prototype.getCurrentMonthFirstDayTime = function(e) {
                return void 0 === e && (e = new Date()), new Date(e.getFullYear(), e.getMonth());
            }, e.prototype.getCurrentMonthLastDayTime = function(e) {
                return void 0 === e && (e = new Date()), new Date(e.getFullYear(), e.getMonth() + 1, 0);
            }, e.prototype.getNextMonthFirstDayTime = function(e) {
                return void 0 === e && (e = new Date()), new Date(e.getFullYear(), e.getMonth() + 1);
            }, e.prototype.getCurrentWeekFirstDayTime = function(e) {
                void 0 === e && (e = new Date());
                var t = e.getDay() || 7;
                return new Date(e.getFullYear(), e.getMonth(), e.getDate() - t + 1);
            }, e.prototype.getCurrentQuarterFirstDayTime = function(e) {
                void 0 === e && (e = new Date());
                var t = new Date(e);
                t.setDate(1);
                var r = t.getMonth(), n = Math.floor(r / 3);
                return t.setMonth(3 * n), t;
            }, e.prototype.getCurrentYearFirstDayTime = function(e) {
                return void 0 === e && (e = new Date()), new Date(e.getFullYear(), 0);
            }, e.prototype.getStartOfTheDay = function(e) {
                return new Date(new Date(e).setHours(0, 0, 0, 0));
            }, e.prototype.getEndOfTheDay = function(e) {
                return new Date(new Date(e).setHours(23, 59, 59, 999));
            }, e.prototype.getPeriodStartTimeStamp = function(e, t, r) {
                void 0 === e && (e = 0);
                var n = r ? new Date(r) : new Date();
                return 1 === e ? n = this.getCurrentWeekFirstDayTime(n) : 2 === e ? n = this.getCurrentMonthFirstDayTime(n) : 3 === e ? n = this.getCurrentQuarterFirstDayTime(n) : 4 === e && (n = this.getCurrentYearFirstDayTime(n)), 
                n.setHours(0), n.setMinutes(0), n.setSeconds(0), (n = t ? this.getOffsetTime(n, t) : n).getTime();
            }, e.prototype.getOffsetTime = function(e, t) {
                var r = t.year, n = void 0 === r ? 0 : r, o = t.month, i = void 0 === o ? 0 : o, a = t.week, s = void 0 === a ? 0 : a, u = t.day, c = void 0 === u ? 0 : u, l = t.hour, d = void 0 === l ? 0 : l, p = t.minute, f = void 0 === p ? 0 : p, h = t.second, S = void 0 === h ? 0 : h;
                return e.setFullYear(e.getFullYear() + n), e.setMonth(e.getMonth() + i), e.setDate(e.getDate() + 7 * s), 
                e.setDate(e.getDate() + c), e.setHours(e.getHours() + d), e.setMinutes(e.getMinutes() + f), 
                e.setSeconds(e.getSeconds() + S), e;
            }, e.prototype.compareEqualTimes = function(e, t) {
                return this.newDate(e).getTime() === this.newDate(t).getTime();
            }, e.prototype.isInSameDay = function(e, t) {
                return this.newDate(e).setHours(0, 0, 0, 0) === this.newDate(t).setHours(0, 0, 0, 0);
            }, e.prototype.isEarlierDate = function(e, t, r, n) {
                void 0 === r && (r = !1);
                var o = this.newDate(e), i = this.newDate(t), a = function(e, t) {
                    return e < t || !!r && e === t;
                };
                switch (n) {
                  case 86400:
                    return a(o.setHours(0, 0, 0, 0), i.setHours(0, 0, 0, 0));

                  case 3600:
                    return a(o.setMinutes(0, 0, 0), i.setMinutes(0, 0, 0));

                  case 60:
                    return a(o.setSeconds(0, 0), i.setSeconds(0, 0));

                  default:
                    return a(o.getTime(), i.getTime());
                }
            }, e = n.__decorate([ a.Injectable() ], e);
        }();
        t.TimeService = u;
    },
    19: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.Lock = void 0, t.Lock = function(e) {
            return void 0 === e && (e = 3e3), function(t, r, n) {
                var o, i, a = !1, s = n.value;
                n.value = function() {
                    for (var t = [], r = 0; r < arguments.length; r++) t[r] = arguments[r];
                    if (a) return i;
                    var n = function() {
                        a = !1;
                    };
                    return a = !0, o && clearTimeout(o), o = setTimeout(n, e), i = s.apply(this, t.concat(n));
                };
            };
        };
    },
    198: function(e, t, r) {
        function n(e, t) {
            var r = (65535 & e) + (65535 & t);
            return (e >> 16) + (t >> 16) + (r >> 16) << 16 | 65535 & r;
        }
        function o(e, t, r, o, i, a) {
            return n((s = n(n(t, e), n(o, a))) << (u = i) | s >>> 32 - u, r);
            var s, u;
        }
        function i(e, t, r, n, i, a, s) {
            return o(t & r | ~t & n, e, t, i, a, s);
        }
        function a(e, t, r, n, i, a, s) {
            return o(t & n | r & ~n, e, t, i, a, s);
        }
        function s(e, t, r, n, i, a, s) {
            return o(t ^ r ^ n, e, t, i, a, s);
        }
        function u(e, t, r, n, i, a, s) {
            return o(r ^ (t | ~n), e, t, i, a, s);
        }
        function c(e, t) {
            var r, o, c, l, d;
            e[t >> 5] |= 128 << t % 32, e[14 + (t + 64 >>> 9 << 4)] = t;
            var p = 1732584193, f = -271733879, h = -1732584194, S = 271733878;
            for (r = 0; r < e.length; r += 16) o = p, c = f, l = h, d = S, p = u(p = s(p = s(p = s(p = s(p = a(p = a(p = a(p = a(p = i(p = i(p = i(p = i(p, f, h, S, e[r], 7, -680876936), f = i(f, h = i(h, S = i(S, p, f, h, e[r + 1], 12, -389564586), p, f, e[r + 2], 17, 606105819), S, p, e[r + 3], 22, -1044525330), h, S, e[r + 4], 7, -176418897), f = i(f, h = i(h, S = i(S, p, f, h, e[r + 5], 12, 1200080426), p, f, e[r + 6], 17, -1473231341), S, p, e[r + 7], 22, -45705983), h, S, e[r + 8], 7, 1770035416), f = i(f, h = i(h, S = i(S, p, f, h, e[r + 9], 12, -1958414417), p, f, e[r + 10], 17, -42063), S, p, e[r + 11], 22, -1990404162), h, S, e[r + 12], 7, 1804603682), f = i(f, h = i(h, S = i(S, p, f, h, e[r + 13], 12, -40341101), p, f, e[r + 14], 17, -1502002290), S, p, e[r + 15], 22, 1236535329), h, S, e[r + 1], 5, -165796510), f = a(f, h = a(h, S = a(S, p, f, h, e[r + 6], 9, -1069501632), p, f, e[r + 11], 14, 643717713), S, p, e[r], 20, -373897302), h, S, e[r + 5], 5, -701558691), f = a(f, h = a(h, S = a(S, p, f, h, e[r + 10], 9, 38016083), p, f, e[r + 15], 14, -660478335), S, p, e[r + 4], 20, -405537848), h, S, e[r + 9], 5, 568446438), f = a(f, h = a(h, S = a(S, p, f, h, e[r + 14], 9, -1019803690), p, f, e[r + 3], 14, -187363961), S, p, e[r + 8], 20, 1163531501), h, S, e[r + 13], 5, -1444681467), f = a(f, h = a(h, S = a(S, p, f, h, e[r + 2], 9, -51403784), p, f, e[r + 7], 14, 1735328473), S, p, e[r + 12], 20, -1926607734), h, S, e[r + 5], 4, -378558), f = s(f, h = s(h, S = s(S, p, f, h, e[r + 8], 11, -2022574463), p, f, e[r + 11], 16, 1839030562), S, p, e[r + 14], 23, -35309556), h, S, e[r + 1], 4, -1530992060), f = s(f, h = s(h, S = s(S, p, f, h, e[r + 4], 11, 1272893353), p, f, e[r + 7], 16, -155497632), S, p, e[r + 10], 23, -1094730640), h, S, e[r + 13], 4, 681279174), f = s(f, h = s(h, S = s(S, p, f, h, e[r], 11, -358537222), p, f, e[r + 3], 16, -722521979), S, p, e[r + 6], 23, 76029189), h, S, e[r + 9], 4, -640364487), f = s(f, h = s(h, S = s(S, p, f, h, e[r + 12], 11, -421815835), p, f, e[r + 15], 16, 530742520), S, p, e[r + 2], 23, -995338651), h, S, e[r], 6, -198630844), 
            f = u(f = u(f = u(f = u(f, h = u(h, S = u(S, p, f, h, e[r + 7], 10, 1126891415), p, f, e[r + 14], 15, -1416354905), S, p, e[r + 5], 21, -57434055), h = u(h, S = u(S, p = u(p, f, h, S, e[r + 12], 6, 1700485571), f, h, e[r + 3], 10, -1894986606), p, f, e[r + 10], 15, -1051523), S, p, e[r + 1], 21, -2054922799), h = u(h, S = u(S, p = u(p, f, h, S, e[r + 8], 6, 1873313359), f, h, e[r + 15], 10, -30611744), p, f, e[r + 6], 15, -1560198380), S, p, e[r + 13], 21, 1309151649), h = u(h, S = u(S, p = u(p, f, h, S, e[r + 4], 6, -145523070), f, h, e[r + 11], 10, -1120210379), p, f, e[r + 2], 15, 718787259), S, p, e[r + 9], 21, -343485551), 
            p = n(p, o), f = n(f, c), h = n(h, l), S = n(S, d);
            return [ p, f, h, S ];
        }
        function l(e) {
            var t, r = "", n = 32 * e.length;
            for (t = 0; t < n; t += 8) r += String.fromCharCode(e[t >> 5] >>> t % 32 & 255);
            return r;
        }
        function d(e) {
            var t, r = [];
            for (r[(e.length >> 2) - 1] = void 0, t = 0; t < r.length; t += 1) r[t] = 0;
            var n = 8 * e.length;
            for (t = 0; t < n; t += 8) r[t >> 5] |= (255 & e.charCodeAt(t / 8)) << t % 32;
            return r;
        }
        function p(e) {
            var t, r, n = "";
            for (r = 0; r < e.length; r += 1) t = e.charCodeAt(r), n += "0123456789abcdef".charAt(t >>> 4 & 15) + "0123456789abcdef".charAt(15 & t);
            return n;
        }
        function f(e) {
            return unescape(encodeURIComponent(e));
        }
        function h(e) {
            return function(e) {
                return l(c(d(e), 8 * e.length));
            }(f(e));
        }
        function S(e, t) {
            return function(e, t) {
                var r, n, o = d(e), i = [], a = [];
                for (i[15] = a[15] = void 0, o.length > 16 && (o = c(o, 8 * e.length)), r = 0; r < 16; r += 1) i[r] = 909522486 ^ o[r], 
                a[r] = 1549556828 ^ o[r];
                return n = c(i.concat(d(t)), 512 + 8 * t.length), l(c(a.concat(n), 640));
            }(f(e), f(t));
        }
        e.exports = {
            md5: function(e, t, r) {
                return t ? r ? S(t, e) : p(S(t, e)) : r ? h(e) : p(h(e));
            }
        };
    },
    20: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.MonoCommonService = t.ConvertSeqTitleTypeEnum = void 0;
        var n, o = r(0), i = r(1), a = r(14), s = r(32), u = r(11);
        !function(e) {
            e[e.NEW_LINE_TO_SPACE = 0] = "NEW_LINE_TO_SPACE", e[e.SPACE_TO_NEW_LINE = 1] = "SPACE_TO_NEW_LINE";
        }(n = t.ConvertSeqTitleTypeEnum || (t.ConvertSeqTitleTypeEnum = {}));
        var c = function() {
            function e() {}
            return e.prototype.getGroupType = function(e) {
                return {
                    isBrand: 10 === e,
                    isLeader: 20 === e,
                    isCustomer: 30 === e,
                    isCommunity: 50 === e,
                    isCircle: 40 === e,
                    isAssociation: 60 === e,
                    isGroupBrand: 70 === e,
                    isGroupLeader: 80 === e,
                    isCommunityStore: 90 === e,
                    isAllBrand: 10 === e || 70 === e || 110 === e,
                    isAllLeader: 20 === e || 80 === e || 90 === e || 105 === e,
                    isStore: 90 === e,
                    isLeaderLike: 20 === e || 90 === e,
                    isNoPayHome: 30 === e || 40 === e,
                    isAgent: 100 === e,
                    isSupplyLeader: 105 === e,
                    isSupplyBrand: 110 === e
                };
            }, e.prototype.getSeqType = function(e) {
                return {
                    isStartGroupParent: 10 === e,
                    isStartGroupChild: 20 === e,
                    isStartGroupGrandchild: 210 === e,
                    isGroupBuy: 30 === e,
                    isSignUp: 40 === e,
                    isTogetherBuy: 50 === e,
                    isInteract: 60 === e,
                    isRead: 70 === e,
                    isElect: 80 === e,
                    isFee: 90 === e,
                    isCommunity: 100 === e,
                    isNewTogetherBuy: 110 === e,
                    isMarket: 120 === e,
                    isNewTogetherBuyParent: 130 === e,
                    isNewTogetherBuyChild: 140 === e,
                    isLeaderHelpParent: 150 === e,
                    isLeaderHelpChild: 160 === e,
                    isForm: 200 === e,
                    isSeqGame: -10 === e,
                    isPhoto: 170 === e,
                    isVideo: 180 === e,
                    isArticle: 190 === e,
                    isLottery: 220 === e,
                    isEvaluation: 230 === e,
                    isLotteryParent: 240 === e,
                    isLotteryChild: 250 === e,
                    isAllLottery: s.LotterySeq.includes(e)
                };
            }, e.prototype.isVideo = function(e) {
                return e.toLowerCase().includes(".mp4");
            }, e.prototype.getRealImgUrl = function(e, t, r, n, o, i) {
                if (void 0 === r && (r = !0), void 0 === n && (n = !1), !t || "null" === t) return "";
                if (0 === t.indexOf("cloud")) return t;
                var a = t.match("http") ? t : e + "/" + t;
                if (a.includes(".svg")) return a;
                var s = o || 360, u = i || 360;
                return a += this.isVideo(t) ? "?x-oss-process=video/snapshot,t_1000,f_jpg,w_" + s + ",h_" + u : r ? "?x-oss-process=image/resize,m_fill,limit_0,w_" + s + ",h_" + u : n ? "?x-oss-process=image/resize,m_lfit,limit_0,w_" + s + ",h_" + u : "", 
                a = this.resolveUrl(a);
            }, e.prototype.addResHost = function(e, t) {
                if (!t || "null" === t) return "";
                if (0 === t.indexOf("cloud")) return t;
                var r = t.match("http") ? t : e + "/" + t;
                return r = this.resolveUrl(r);
            }, e.prototype.getVideoSnapshot = function(e, t, r, n, o, i, a) {
                return void 0 === r && (r = 1e3), void 0 === n && (n = 0), void 0 === o && (o = 0), 
                void 0 === i && (i = "jpg"), void 0 === a && (a = !0), t ? (/^http.*/g.test(t) || (t = e + "/" + t), 
                t + "?x-oss-process=video/snapshot,t_" + r + ",f_" + i + ",w_" + n + ",h_" + o + (a ? ",m_fast" : "")) : "";
            }, e.prototype.getMoney = function(e) {
                return Math.round(100 * Number(e));
            }, e.prototype.sliceEmojiString = function(e, t, r, n) {
                var i, a, s = [];
                try {
                    for (var u = o.__values(e), c = u.next(); !c.done; c = u.next()) {
                        var l = c.value;
                        s.push(l);
                    }
                } catch (e) {
                    i = {
                        error: e
                    };
                } finally {
                    try {
                        c && !c.done && (a = u.return) && a.call(u);
                    } finally {
                        if (i) throw i.error;
                    }
                }
                var d = s.slice(t, r).join("");
                return d === e || n || (d += "..."), d;
            }, e.prototype.getEmojiStringByLen = function(e, t) {
                var r, n, i = 2 * t, a = [];
                try {
                    for (var s = o.__values(e), u = s.next(); !u.done; u = s.next()) {
                        var c = u.value;
                        a.push(c);
                    }
                } catch (e) {
                    r = {
                        error: e
                    };
                } finally {
                    try {
                        u && !u.done && (n = s.return) && n.call(s);
                    } finally {
                        if (r) throw r.error;
                    }
                }
                for (var l = "", d = 0, p = 0; p < i && d < a.length; d++) {
                    var f = a[d];
                    p += (f || "").match(/[x00-xff]/) ? 1 : 2, l += f;
                }
                return l !== e && (l += "…"), l;
            }, e.prototype.emojiStringLength = function(e) {
                var t, r, n = [];
                try {
                    for (var i = o.__values(e), a = i.next(); !a.done; a = i.next()) {
                        var s = a.value;
                        n.push(s);
                    }
                } catch (e) {
                    t = {
                        error: e
                    };
                } finally {
                    try {
                        a && !a.done && (r = i.return) && r.call(i);
                    } finally {
                        if (t) throw t.error;
                    }
                }
                return n.length;
            }, e.prototype.resolveUrl = function(e) {
                return e.replace(/^\/*(?=https?)/, "").replace(/\/{2,}/g, "/").replace(/(https?:\/)/g, "$1/");
            }, e.prototype.hasAdminRights = function(e, t) {
                return !!t && t.some(function(t) {
                    return t.code === e && t.retainPrivilege;
                });
            }, e.prototype.makeLogisticsModelsLabel = function(e, t, r) {
                return void 0 === t && (t = a.DeliverModeName), void 0 === r && (r = {
                    isFilterNoLogistics: !0,
                    delimiter: "/"
                }), e ? this.findLogisticsModelsNames(e, t, r).join(r && r.delimiter || "/") : "";
            }, e.prototype.findLogisticsModelsNames = function(e, t, r) {
                return void 0 === t && (t = a.DeliverModeName), void 0 === r && (r = {
                    isFilterNoLogistics: !0
                }), e ? e.sort(function(e, t) {
                    return e - t;
                }).filter(function(e) {
                    return !r || !r.isFilterNoLogistics || 40 !== e;
                }).map(function(e) {
                    return t[e];
                }).filter(function(e) {
                    return e;
                }) : [];
            }, e.prototype.getEmojiAnonymous = function(e) {
                return !e || this.emojiStringLength(e) < 2 ? e : this.sliceEmojiString(e, 0, 1, !0) + "**";
            }, e.prototype.encryptString = function(e, t, r) {
                var n = this.emojiStringLength(e);
                if (t + r >= n) return e;
                var o = this.sliceEmojiString(e, 0, t, !0), i = this.sliceEmojiString(e, -r, void 0, !0);
                return o + "*".repeat(n - t - r) + i;
            }, e.prototype.checkMediaType = function(e, t) {
                var r = {
                    isSVG: /\.svg/i,
                    isGIF: /\.gif/i,
                    isPNG: /\.png/i
                }["is" + t.toLocaleUpperCase()];
                return !!r && r.test(e);
            }, e.prototype.getUserProtocolUpdateKey = function(e, t) {
                return void 0 === t && (t = ""), "u_" + e + "_v" + t;
            }, e.prototype.convertSeqTitleSymbol = function(e, t, r) {
                if (void 0 === r && (r = !0), !e) return e;
                var o = u.ZERO_WIDTH_SPACE + " ";
                return t === n.NEW_LINE_TO_SPACE ? this.convertUnicodeMarker(e).replace(/\n/g, r ? o : " ") : t === n.SPACE_TO_NEW_LINE ? e.replace(RegExp(o, "g"), r ? "\n" : " ") : e;
            }, e.prototype.convertUnicodeMarker = function(e) {
                if (!e) return e;
                var t = e;
                return t = (t = t.replace(/\u200B|\u200C|\u200D/g, "")).replace(/\u200e|\u200f|\u061c|\u202a|\u202b|\u202c|\u202d|\u202e|\u2066|\u2067|\u2068|\u2069/g, "");
            }, e = o.__decorate([ i.Injectable() ], e);
        }();
        t.MonoCommonService = c;
    },
    214: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.DEFAULT_UNIT_LIST = t.DEFAULT_UNIT_ITEM = t.DEFAULT_UNIT_VALUE_ITEM = t.MoreSizeProductInputType = void 0, 
        function(e) {
            e.GROUP_BUY_PRICE = "0", e.COST_PRICE = "1", e.COMMISSION_PERCENT_PRICE = "2", e.TOTAL_STOCK = "3", 
            e.ORIGIN_PRICE = "4", e.GOODS_NO = "5", e.GOODS_WEIGHT = "6", e.SUPPLY_PRICE = "7", 
            e.GOODS_COST = "8", e.EVALUATION_PRICE = "9";
        }(t.MoreSizeProductInputType || (t.MoreSizeProductInputType = {})), t.DEFAULT_UNIT_VALUE_ITEM = {
            goodsDimensionValueFrontId: 2,
            valueName: ""
        }, t.DEFAULT_UNIT_ITEM = {
            dimensionName: "",
            dimensionValueList: void 0,
            goodsDimensionFrontId: 1
        }, t.DEFAULT_UNIT_LIST = [ {
            templateId: "-1",
            unitName: "颜色",
            unitValueName: [ "红色", "蓝色", "绿色" ]
        }, {
            templateId: "-2",
            unitName: "尺寸",
            unitValueName: [ "S", "M", "L" ]
        }, {
            templateId: "-3",
            unitName: "重量",
            unitValueName: [ "500g", "1kg", "2kg" ]
        }, {
            templateId: "-4",
            unitName: "口味",
            unitValueName: [ "不辣", "微辣", "中辣", "麻辣" ]
        } ];
    },
    226: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var n = r(0);
        n.__exportStar(r(601), t), n.__exportStar(r(602), t), n.__exportStar(r(603), t), 
        n.__exportStar(r(604), t), n.__exportStar(r(605), t), n.__exportStar(r(606), t), 
        n.__exportStar(r(607), t), n.__exportStar(r(608), t), n.__exportStar(r(609), t), 
        n.__exportStar(r(610), t), n.__exportStar(r(611), t), n.__exportStar(r(612), t), 
        n.__exportStar(r(613), t), n.__exportStar(r(614), t), n.__exportStar(r(615), t), 
        n.__exportStar(r(616), t), n.__exportStar(r(617), t), n.__exportStar(r(618), t), 
        n.__exportStar(r(619), t), n.__exportStar(r(620), t), n.__exportStar(r(621), t), 
        n.__exportStar(r(622), t), n.__exportStar(r(623), t), n.__exportStar(r(624), t), 
        n.__exportStar(r(625), t), n.__exportStar(r(626), t), n.__exportStar(r(420), t), 
        n.__exportStar(r(627), t), n.__exportStar(r(628), t), n.__exportStar(r(629), t), 
        n.__exportStar(r(630), t), n.__exportStar(r(631), t), n.__exportStar(r(632), t), 
        n.__exportStar(r(633), t), n.__exportStar(r(634), t), n.__exportStar(r(635), t), 
        n.__exportStar(r(636), t), n.__exportStar(r(637), t), n.__exportStar(r(638), t), 
        n.__exportStar(r(639), t), n.__exportStar(r(640), t), n.__exportStar(r(641), t), 
        n.__exportStar(r(642), t), n.__exportStar(r(643), t), n.__exportStar(r(644), t), 
        n.__exportStar(r(421), t), n.__exportStar(r(645), t), n.__exportStar(r(646), t), 
        n.__exportStar(r(647), t), n.__exportStar(r(648), t), n.__exportStar(r(649), t), 
        n.__exportStar(r(650), t), n.__exportStar(r(651), t), n.__exportStar(r(652), t);
    },
    24: function(t, r, n) {
        Object.defineProperty(r, "__esModule", {
            value: !0
        }), r.ErrorService = void 0;
        var o = n(0), i = n(1), a = n(418), s = [ 401, -1 ], u = [ 5077, 5076, 5004, 5600, 5601, 5610, 5611, 5655, 5030, 1036, 1049, 1401, 1013 ], c = function() {
            function t() {
                this.reportRequestErrorHashList = new Map([]), this.reportOnErrorHashList = new Map([]);
            }
            return Object.defineProperty(t.prototype, "logService", {
                get: function() {
                    if (!this._logService) throw new Error("[errorService]使用前请先调用setLogService");
                    return this._logService;
                },
                set: function(e) {
                    this._logService = e;
                },
                enumerable: !1,
                configurable: !0
            }), Object.defineProperty(t.prototype, "grayFeatService", {
                get: function() {
                    if (!this._grayFeatService) throw new Error("[errorService]使用前请先调用 setGrayFeatureService");
                    return this._grayFeatService;
                },
                set: function(e) {
                    this._grayFeatService = e;
                },
                enumerable: !1,
                configurable: !0
            }), t.prototype.setLogService = function(e) {
                this.logService = e;
            }, t.prototype.setGrayFeatureService = function(e) {
                this.grayFeatService = e;
            }, t.prototype.throwCommonError = function(e) {
                throw this.createErrorForThrow(e);
            }, t.prototype.createCommonError = function(e) {
                var t = e.frontErrorCode, r = e.errorMsg, n = e.error, o = void 0 === n ? {} : n, i = e.extraInfo, s = void 0 === i ? {} : i, u = e.isSkipReport, c = void 0 !== u && u, l = a.FrontEndErrorMsgMap[t] || "noShortMsg";
                return {
                    reportErrorCode: "frontError" + t,
                    error: o,
                    stack: o.stack || new Error().stack,
                    frontErrorCode: t,
                    errorMsg: r,
                    shortMsg: l,
                    isSkipReport: c,
                    extraInfo: s
                };
            }, t.prototype.customReportError = function(e) {
                var t = e.frontErrorCode, r = e.errorMsg, n = e.error, o = void 0 === n ? {} : n, i = e.extraInfo, s = void 0 === i ? {} : i, u = e.isSkipReport, c = a.FrontEndErrorMsgMap[t] || "noShortMsg!", l = a.onlyLogSet.has(t);
                try {
                    this.logService.reportError({
                        hash: "frontError" + t,
                        errorMsg: JSON.stringify({
                            extraInfo: s,
                            error: o,
                            errorMsg: r
                        }),
                        shortMsg: c,
                        isSkipReport: u,
                        isCustomLog: l,
                        isCustomReport: !0
                    });
                } catch (e) {
                    setTimeout(function() {
                        throw e;
                    });
                }
            }, t.prototype.customReportLogByGray = function(e, t) {
                var r = this;
                try {
                    this.grayFeatService.canIUseFeature("2399").subscribe(function(n) {
                        n && r.customReportError({
                            frontErrorCode: 18001,
                            errorMsg: e,
                            extraInfo: t
                        });
                    });
                } catch (r) {
                    this.customReportError({
                        frontErrorCode: 18001,
                        errorMsg: e,
                        error: r,
                        extraInfo: t
                    });
                }
            }, t.prototype.customReportRequest = function(e) {
                if (!s.includes(e.statusCode)) {
                    var t = e.responseErrorInfo.responseErrorType, r = "statusError" === t || "noStatus" === t, n = this.jsonStringifyWithTryCatch(o.__assign(o.__assign({}, e), {
                        data: void 0
                    }), "customReportRequest"), i = r ? "httpStatus" + e.statusCode : "responseCode" + e.code, a = this.getRequestAndOtherErrorHashAndShortMsg(n).hash || String(this.hashCode(n)), c = (this.reportRequestErrorHashList.get(i + a) || 0) + 1;
                    this.reportRequestErrorHashList.set(i + a, c);
                    var l = u.includes(e.code || 0), d = {
                        hash: i,
                        shortMsg: t + (r ? e.statusCode : e.code),
                        errorMsg: n,
                        isCustomReport: !0,
                        count: c,
                        isCustomLog: l
                    };
                    c > 5 && c % 10 || this.logService.reportError(d);
                }
            }, t.prototype.customReportWxCloudRequest = function(e, t, r) {
                var n = {
                    hash: "wxCloud" + e.code,
                    shortMsg: "" + t,
                    errorMsg: this.jsonStringifyWithTryCatch(o.__assign(o.__assign({}, e), {
                        data: void 0,
                        params: r
                    }), "customReportWxCloudRequest"),
                    isCustomReport: !0,
                    isCustomLog: !0
                };
                this.logService.reportError(n);
            }, t.prototype.addErrorMsg = function(t, r, n) {
                void 0 === t && (t = ""), void 0 === r && (r = {}), void 0 === n && (n = !1), "object" != (void 0 === r ? "undefined" : e(r)) && (r = {});
                var i = r.message, a = void 0 === i ? "" : i, s = o.__rest(r, [ "message" ]), u = t + (a ? (n ? "\n" : ",") + a : "");
                return o.__assign(o.__assign({
                    message: u
                }, s), {
                    stack: null == r ? void 0 : r.stack
                });
            }, t.prototype.jsonStringifyWithTryCatch = function(e, t) {
                var r = "";
                try {
                    r = JSON.stringify(e);
                } catch (e) {
                    r = t + " JSON.stringify Fail: " + e + e;
                }
                return r;
            }, t.prototype.reportOnError = function(e) {
                void 0 === e && (e = "");
                var t = this.getHashAndShortMsg(e), r = t.hash, n = void 0 === r ? this.hashCode(e) : r, o = t.shortMsg, i = (this.reportOnErrorHashList.get(n) || 0) + 1;
                this.reportOnErrorHashList.set(n, i), 1 !== i && i % 10 || this.logService.reportError({
                    errorMsg: e,
                    shortMsg: o,
                    count: i,
                    hash: n
                });
            }, t.prototype.hashCode = function(e) {
                var t, r = 0;
                if (0 === e.length) return r;
                for (t = 0; t < e.length; t++) r = (r << 5) - r + e.charCodeAt(t), r |= 0;
                return r;
            }, t.prototype.createErrorForThrow = function(e) {
                var t, r = e.frontErrorCode, n = e.errorMsg, o = e.error, i = void 0 === o ? {} : o, s = e.extraInfo, u = void 0 === s ? {} : s, c = "frontError" + r;
                try {
                    t = JSON.stringify({
                        reportErrorCode: c,
                        frontErrorCode: r,
                        errorMsg: n,
                        extraInfo: u,
                        error: i.message,
                        shortMsg: a.FrontEndErrorMsgMap[r] || "noShortMsg"
                    });
                } catch (e) {
                    t = "throwCommonErrorJsonStringifyFail";
                }
                return {
                    stack: i.stack || new Error().stack,
                    message: t
                };
            }, t.prototype.getHashAndShortMsg = function(e) {
                var t = e.indexOf("reportErrorCode") > -1, r = e.indexOf("cloud.callFunction:fail") > -1, n = e.split("\n").splice(1, 1)[0];
                return t ? this.getFrontErrorHashAndShortMsg(n) : r ? this.getCloudErrorHashAndShortMsg(n) : this.getRequestAndOtherErrorHashAndShortMsg(n);
            }, t.prototype.getFrontErrorHashAndShortMsg = function(e) {
                return {
                    hash: (e.match(/frontError\d{4}/) || [])[0] || 0,
                    shortMsg: (e.match(/(\\*)"shortMsg(\\*)":(\\*)"(.*?)(\\*)"/) || [])[4]
                };
            }, t.prototype.getCloudErrorHashAndShortMsg = function(e) {
                var t = (e.match(/ (-\d{6}) /) || [])[1];
                return t || (t = (e = (e = (e = e.replace(/fail requestID (.*?),/, "")).replace(/\(callId: (.*?)\)/, "")).replace(/\(trace: (.*?)abort\)/, "")) ? this.hashCode(e) : void 0), 
                {
                    hash: t,
                    shortMsg: e
                };
            }, t.prototype.getRequestAndOtherErrorHashAndShortMsg = function(e) {
                return {
                    hash: (e = (e = e.replace(/\b[0-9a-f]{30}\b/, "")).replace(/"timeStamp":"(.*?)"/, '"timeStamp":""')) ? this.hashCode(e) : void 0,
                    shortMsg: e
                };
            }, t = o.__decorate([ i.Injectable(), o.__metadata("design:paramtypes", []) ], t);
        }();
        r.ErrorService = c;
    },
    25: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.DefaultService = void 0;
        var n = r(0), o = r(107), i = r(1), a = function() {
            function e(e) {
                this.httpClient = e;
            }
            function t(e) {
                return "/" + e.map(function(e) {
                    return Array.isArray(e) ? function(e) {
                        return e.map(function(e) {
                            return y[e];
                        }).join("_");
                    }(e) : y[e];
                }).join("/");
            }
            function r(e) {
                var t = "";
                t += y[e[0]] || "";
                for (var r = 1; r < e.length; r++) {
                    var n = y[e[r]];
                    t += n[0].toUpperCase() + n.slice(1);
                }
                return t;
            }
            function a(e) {
                var n, o = e.length;
                return o >= 1 && ("number" == typeof (n = e[0]) && (n = [ n ]), e[0] = Array.isArray(n) ? t(n) : n), 
                o >= 2 && (n = e[1], e[1] = Array.isArray(n) ? r(n) : y[n]), o >= 3 && (n = e[2], 
                e[2] = n.map(function(e) {
                    return Array.isArray(e) ? r(e) : y[e];
                })), o >= 3 && (void 0 === e[3] ? e[3] = 1 : 0 === e[3] && (e[3] = void 0)), e;
            }
            function s(e, t) {
                for (var r = 0; r < t.length; r++) {
                    var n = t[r];
                    n && e.apply(this, a(n));
                }
            }
            var u, c = i.mhttp(e.prototype), l = c.g, d = c.p, p = c.u, f = c.d, h = c.t, S = c.h, _ = c.o, E = c.c, y = [ "gh", "act", "get", "query", "id", "list", "group", "activity", "api", "order", "ghId", "actId", "pageSize", "user", "mina", "company", "sale", "help", "info", "v2", "update", "by", "show", "detail", "goods", "im", "relation", "ghome-major", "ghome", "supply", "create", "param", "ghome-relation", "product", "$0", "subscribe", "feed", "page", "copy", "biz", "pay", "commission", "activity-accessory", "count", "for", "home", "activity-biz", "data", "pay-biz", "add", "msg", "template", "audit", "bank", "category", "brand", "stat", "new", "certificate", "square", "open", "wx", "judge", "is", "buy", "batch", "addr", "type", "apply", "save", "evaluation", "delete", "setting", "child", "dlv", "push", "root", "reply", "card", "aip", "star", "req", "set", "sales", "config", "after", "status", "lottery", "num", "account", "withdraw", "send", "auth", "member", "read", "market", "gho", "memajor", "settings", "sub", "groupId", "ghCompanyId", "ghGroupId", "$1", "comment", "material", "stats", "welfare", "t", "sign", "all", "as", "other", "modify", "allinpay-biz", "check", "code", "group-operation-biz", "address", "funds", "do", "edit", "order-certificate", "no", "uid", "tag", "refund", "release", "fan", "act-data", "share", "order-logistics", "carriage", "red", "deliver", "phone", "confirm", "traffic-to-cash-operation-mina-biz", "opt", "in", "ghome-tags", "ids", "goods-biz", "freeze", "content", "can", "customer", "recommend", "search", "message", "dot", "product-show-mina-biz", "help-sale-square", "allin", "ecommerce", "un", "size", "invite", "o", "logistics", "default", "commend", "period", "auto", "and", "agent", "fast", "switch", "after-sales-biz", "has", "follow", "fans", "remove", "certification", "img", "ghome-feed", "balance", "or", "daily", "record", "bind", "post", "total", "flow", "client", "c", "association", "view", "video", "quick", "leader", "unread", "click", "out", "traffi", "ocashoperation", "ps", "common", "export", "pact", "fund", "result", "close", "sys", "notice", "receive", "bg", "business", "name", "promoter", "frame", "del", "with", "cancel", "of", "bubble", "interactive", "use", "up", "latest", "time", "fee", "last", "top", "mark", "rank", "label", "details", "d", "token", "person", "try", "appraise", "elect", "pro", "verify", "transfer", "unfrozen", "manager", "start", "tip", "key", "hot", "parent", "permission", "book", "g", "chart", "tags", "statistics", "my", "return", "url", "dynamic", "fission", "ghome-fans", "base", "ghome-help-sale-feed", "homehelp", "hb", "to", "history", "order-sign", "orders", "like", "evaluation-biz", "invited", "subject", "test", "actPsSta", "reg", "cooperation", "rel", "email", "find", "good", "story", "recharge", "classify", "course", "guarantee", "placeOrder", "service", "image", "one", "rate", "order-cert", "frozen", "recent", "collection", "share-copy", "v4", "warns", "visit", "express", "corporation", "services", "grand", "son", "entrance", "flag", "front", "link", "prize", "addrs", "process", "upload", "v3", "limit", "cs", "stream", "merchant", "inviter", "mall", "mini", "sort", "v", "i", "notify", "banner", "chat", "exclusive", "ad", "delivery", "riskctl-api", "package", "sta", "ranking", "reward", "role", "owner", "activity-lottery-biz", "follower", "fill", "try-out-square-mina-biz", "gb", "async", "shop", "community", "dynamics", "gray", "remind", "ugc", "personal", "exposure", "item", "input", "pavilion", "circle", "promotion", "activities", "pre", "moment", "live", "authorization", "logistic", "selection", "first", "payment", "spec", "pgh", "extend", "month", "filter", "gat", "gzh", "homepage", "conversation", "administrator", "privilege", "accept", "pv", "current", "unified", "params", "remark", "supply-square", "background", "become", "basic", "wait", "verification", "independent", "enter", "gh-data", "work", "normal", "from", "contact", "log", "ghid", "trade", "groups", "request", "attr", "risk", "qualification", "spread", "price", "signs", "viewer", "winners", "move", "report", "login", "after-sales-broker", "broker", "spot", "warn", "binding", "order-cert-lottery", "order-tag", "sticky", "admin", "today", "ver", "order-export", "output", "related", "v1", "target", "$2", "join", "same", "event", "groupon", "amount", "have", "level", "high", "reputation", "old", "submit", "condition", "watch", "grays", "back", "days", "activity-detail", "activity-detail-user-data", "me", "change", "clear", "brand-biz", "carriage-biz", "non", "wx-work", "analysis", "receipt", "place", "virtual", "single", "staff", "deleted", "user-order", "map", "codes", "action", "m", "invalid", "file", "collect", "deposite", "state", "over", "spots", "icon", "passive", "simple", "gmv", "band", "server", "accepted", "see", "resolution", "recently", "pass", "pull", "messages", "max", "ghdata-biz", "own", "satisfied", "activity-lottery", "sfe", "released", "upgrade", "corp", "wxmp", "init", "trace", "end", "gen", "promote", "evaluation-automation", "ev", "aluationautomation", "start-act", "follow-request", "face", "task", "kf", "pomotion", "user-biz", "snap", "visible", "tech-messages-open-im", "people", "self", "big", "ghData", "stuff", "activate", "re", "access", "adjust", "unbind", "rechargefee", "excel", "track", "acc", "without", "ghs", "focus", "take", "advanced", "publish", "earn", "recom", "popups", "float", "toast", "order-mark", "orderMark", "unique", "session", "off", "line", "dispatch", "commissions", "entry", "escalation", "the", "exist", "inc", "fail", "ext", "front-store", "portrayal", "range", "using", "ds", "identities", "helper", "country", "model", "full", "forbid", "general", "activity-order", "saler", "power", "channel", "leaders", "comssion", "method", "share-image", "files", "form", "submsg", "sell", "restart", "insert", "position", "protect", "multi", "station", "specific", "popup", "between", "free", "lat", "lon", "reference", "more", "award", "managers", "rs", "mask", "settlement", "official", "pagequery", "credit", "docking", "head", "gta", "activation", "recover", "reject", "weak", "resend", "shield", "layer", "2", "contract", "sequence", "red-dot", "qr", "global", "str", "choose", "not", "dto", "external", "b", "wxa-link", "discount", "operate", "acts", "year", "dec", "sec", "kill", "store", "room", "path", "contest", "cost", "double", "encrypt", "gh-goods-data-sta", "display", "hongbao", "summary", "real", "trans", "agreement", "mail", "recycle", "safe", "draw", "n", "greeting", "Id", "app", "break", "ice", "level2", "activity-visit", "manual", "menu", "partial", "validate", "snapshot", "faceid", "preview", "ing", "consumer", "authorized", "lib", "helpsale", "lighting", "gr", "oupoperation", "reading", "reset", "date", "unlike", "silence", "conditions", "progress", "lucky", "go", "reqs", "agree", "amILucky", "invoker", "five", "mixed", "write", "be", "homes", "vip", "allow", "dialog", "internal", "products", "basegh", "into", "father", "coop", "mp", "enum", "guide", "obtain", "core", "qjl", "l", "decr", "decrypt", "gid", "csMsgFloatRecord", "selected", "success", "uni", "dw", "evaluate", "effective", "ecomm", "fetch", "def", "short", "actid", "quota", "fallback", "excl", "support", "group-welfare", "pending", "activity-label", "skip", "keyword", "sync", "news", "transport", "scope", "brief", "p", "V1", "competition", "es", "exception", "decryption", "overstep", "applyment", "eval", "flush", "cache", "ghGoodsSpreadDailyStat", "public", "picker", "ghId", "sharing", "groupCircle", "daliy", "header", "hotGoods", "wechat", "hong", "bao", "two", "months", "shipping", "attrs", "middle", "update-red-dot", "playing", "ways", "bin", "st", "region", "actity", "existed", "pure", "associations", "operation", "superior", "recommended", "likes", "carousel", "at", "dlvAddr", "liked", "packet", "block", "online", "safety", "import", "incr", "invitation", "heel", "accessible", "already", "tips", "expand", "grouprc", "pay-qjl-global-stat", "issue", "main", "collected", "exists", "expire", "been", "origin", "day", "deadline", "users", "faq", "unevaluated", "protected", "rule", "identify", "activity-lottery-detail", "major", "revocation", "creator", "meet", "matched", "mission", "landing", "location", "vests", "movedown", "down", "moveup", "unaudited", "participator", "pause", "hand", "pic", "preview2", "recall", "mem", "force", "div", "about", "website", "activity-certificate", "transaction", "credit-api", "detect", "opportunity", "rules", "exit", "floor", "need", "aggregation", "goose", "connect", "pop", "avatar", "doubt", "little", "identity", "judgment", "part", "unSign", "participation", "sms", "abutment", "limitation", "panel", "contain", "topic", "potential", "match", "logic", "upper", "yun", "refuse", "replace", "required", "resume", "reverse", "revoke", "squad", "activity-order-pillar", "forbidden", "optional", "shielding", "hide", "button", "tabs", "subscrib", "suspect", "fix", "authorize", "undo", "logo", "privacy", "urge", "viewers", "hasBinding", "actPersonLucky", "start-follow", "addActTags", "addGoodsTags", "fansV2", "addSettingCustomTags", "addTemplate", "partner", "opening", "am", "applyRechargeServiceFeeRefund", "balancePay", "number", "dont", "number2", "stars", "scan", "buyGhRegOrderCredence", "calculatePredictFreight", "destination", "provenance", "weight", "u", "isagent", "checkUserMultiEcommerce", "realname", "checkUserRealNameValidV2", "orderrefund", "clearLackBalance", "grade", "coperation", "corpBind", "qjlbizorder", "createPay", "q", "j", "customerSFECancelOrder", "customerSFEOrderPayState", "customerSFEOrderState", "customerSFEPlaceLogisticOrder", "delSettingCustomTags", "saveCancelAction", "delay", "deliverTm", "detailPolling", "customerSignOrder", " ", "doGuaranteePay", "orderNo", "doSelectReleaseFreezeActBalance", "uniGhPay", "uniPay", "second", "merge", "exportEvaluation", "supplyFrozenBalanceDetails", "bo", "getActFollowRankingHasFollowIncome", "goodsid", "count-pending", "list-pending", "getActivityPlaceLogisticOrderStatus", "getAipAccountSettingList", "getBLogisticsOrderInfo", "getBannerByScopeCode", "tel", "print", "zkeyword", "getCorpGhKfParam", "getCorpGhKf", "fro", "byes", "getEffectiveOrderCountOfAct", "getExportEvaluationUrl", "filePath", "oss", "getFillPrizeAddress", "h", "getFirstLevelAccount", "getFloatMsgJudge", "getForbidActLevelListApi", "getFrozenDetails", "ghGoods", "sw", "categories", "List", "group-order", "gh3", "getHongbaoInfoByOrderNo", "imaccount", "imaccountid", "getKfId", "getOnlineShowOrExportFrozenDetails", "order-page", "getParentActivityUpdateRedDotKey", "vo", "getParentUpdateChildView", "include", "getRechargePrePay", "getRechargeRefundAccountItem", "getRechargeRefundOrderItem", "getRechargeRefund", "rechargeServiceFeeRefundAmountDTO", "meta", "area", "getSupplyFreezeTypes", "host", "traffic", "getUnpaidLogisticOrder", "encode", "usersig", "sig", "getVisibleAdIcon", "hasBindingIM", "give", "secret", "handshake", "ios", "activity-creator", "isFollowWxMpV2", "isForbidActUserApi", "isUserVerify", "resource", "sensitive", "judgeQjlSFOrder", "judgeUserClick", "latAndLonResolution", "listAllTemplate", "templateId", "listCooperativeExpressCompany", "activity-good-feed", "materials", "listHongbaoInfoByOrderNo", "actIds", "lock", "local", "association-biz", "on", "noticeClickBySr", "sum", "placeALlLogisticOrders", "placeALlLogisticOrdersV2", "place-all", "apiv3", "allinpay-prepay", "exp", "allocation", "polling", "queryActParticipantList", "queryActTagsList", "retain", "queryFansData", "force-frozen-config", "queryForceFrozenInfo", "queryFreezeRecomCommission", "queryGhNewOrderUserList", "queryGoodsTagsList", "queryGroupTagsListMultiple", "queryHelpSaleHeadData", "hierarchy", "mch", "ttl", "manage", "queryPageGhGoodsRank", "aalysis", "cur", "upstream", "inner", "queryShareTagsConfig", "queryShareTagsListByActId", "queryShareTagsList", "cgh", "srar", "unreadnum", "sys-msg-box", "msgbox", "queryTagsListByGoodsId", "adv", "read-certificate", "wxapp", "refresh-check", "refresh", "version", "reportEnterActDetail", "backgroundCategoryid", "distribution", "saveUserKfInfo", "schedule", "selectFreezeActBalance", "selectFreezeBalances", "selectFreezeCompanies", "setCrmShareTagsConfig", "flg", "setShareTagsConfig", "setShareTagsUse", "copy-as-apply", "copy-as-appraise-elect", "copy-as-chart", "copy-as-group", "copy-as-help-sale-root", "copy-as-interactive", "copy-as-lottery", "copy-as-open", "copy-as-read", "optional-act-goods-list", "optional-gh-home-list", "pre-copy", "stick", "types", "supplyFrozenBalanceList", "supplyFrozenBalances", "V5", "toC", "triggerOrderPayNotify", "uidToExternalUid", "timestamp", "updateActTags", "updateGoodsTags", "title", "updateMessCount", "pickerphone", "args", "userAuth", "suite", "userClickAdIcon", "money" ];
            return s(l, [ [ [ 25, 8, [ 89, 86, 3 ], 34 ], [ 89, 86, 3 ], [ 89 ] ], [ [ 407, [ 1, 2, 292 ] ], [ 1, 2, 292 ], [ 11, [ 408, 67 ] ], 3 ], [ [ 42, 244, [ 17, 16 ], 7, 60, 244 ], [ 7, 60, 244 ], [ 11, [ 312, 124 ] ], 2 ], [ [ 13, [ 0, 15 ], [ 7, 9, 293, 47 ] ], [ 7, 9, 293, 47 ], [ [ 372, 220 ] ], 0 ], [ [ 35, 8, 14, [ 184, 75 ], [ 49, 184, 35, 1 ] ], [ 49, 184, 35, 1 ], [ 11 ] ], [ [ 376, [ 29, 0, 24, 133, 150 ], [ 2, 133, 150, 88 ] ], [ 49, 29, 59 ], [ [ 29, 0, 4 ] ] ], [ [ 114, 79, 89, 90, [ 79, 413, 115, 90, 235, 116 ] ], [ 79, 413, 115, 90, 235, 116 ], [ 10 ] ], [ [ 27, [ 80, 0 ], [ 62, 378, 80, 0 ] ], [ 378, 80, 6 ], [ 10 ] ], [ [ 165, 14, [ 899, 165, 607, 180 ] ], [ 180, 165, 13 ], [ [ 282, 124 ], 124 ], 3 ], [ [ 13, [ 0, 112, 45 ], [ 64, 681, 5 ] ], [ 64, 681, 5 ] ], [ [ 131, 8, 484, 901 ], 901, [ 902, 903, 904 ], 7 ], [ [ 203, [ 340, 485 ], [ 145, 317, 217 ] ], [ 145, 317, 217 ] ], [ [ 203, [ 340, 485 ], [ 145, 317, 217, 19 ] ], [ 145, 317, 217, 19 ] ], [ [ 137, 8, [ 145, 22, 1, 30, 13, 322 ] ], [ 145, 22, 322, 1, 30, 13 ], [ [ 1, 30, 124 ] ] ], [ [ 137, 8, [ 145, 22, 13, 322 ] ], [ 145, 22, 322, 419 ] ], [ [ 137, 8, [ 382, 13, 322, 682 ] ], [ 145, 22, 322, 682 ], [ 124 ] ], [ [ 35, 8, 14, [ 184, 75 ], [ 213, 184, 35, 1 ] ], [ 213, 184, 35, 1 ], [ 11 ] ], [ [ 42, [ 7, 341 ], [ 213, 341, 440 ] ], [ 213, 341, 440 ], [ [ 1, 24, 4 ], 11 ], 3 ], [ [ 48, 40, 119, [ 115, 7, 119, 22 ] ], [ 115, 7, 119, 22 ], [ 11 ] ], [ [ 48, 40, [ 115, 683, 176, 40 ] ], [ 115, 683, 176, 40 ], [ 11 ] ], [ [ 405, [ 115, 354 ] ], [ 115, 354, 85, 83, 406, 39 ], [ [ 92, 609 ] ] ], [ [ 165, 14, [ 115, 22, 266, 283 ] ], [ 115, 22, 266, 283 ] ], [ [ 13, [ 115, 13, 94, 525, 204 ] ], [ 115, 13, 94, 525, 204 ] ], [ [ 48, 40, 119, 520, [ 115, 61, 154 ] ], [ 115, 61, 154 ], [ 10 ], 0 ], [ [ 35, 8, 14, [ 184, 75 ], [ 192, 1, 75, 50 ] ], [ 192, 1, 75, 50 ], [ 11 ] ], [ [ 35, 8, 14, [ 55, 75 ], [ 192, 688, 689, 1 ] ], [ 192, 688, 689, 1 ], [ 11, [ 55, 4 ], [ 50, 116 ] ], 7 ], [ [ 35, 8, 14, [ 6, 178, 75 ], [ 202, 22, 299 ] ], [ 202, 22, 299 ], [ 100 ] ], [ [ 9, [ 0, 41 ], [ 202, 155, 205, 24, 531 ], 34 ], [ 202, 155, 205, 24, 531 ], [ 10 ] ], [ [ 42, 7, [ 0, 26 ], [ 15, 6, 26 ] ], [ 15, 6, 26 ], [ 11 ] ], [ [ 13, [ 0, 15 ], [ 15, 37, 9, 47 ] ], [ 15, 37, 9, 47 ], [ 101 ] ], [ [ 27, [ 0, 6 ], [ 157, 6 ], [ 15, 82, 161, 5 ] ], [ 15, 82, 161, 5, 19 ], [ 102 ] ], [ [ 165, [ 43, 165, 266, 13 ] ], [ 43, 165, 266, 13 ] ], [ [ 27, [ 0, 173 ], [ 43, 24 ] ], [ 43, 0, 173, 24, 96, 97 ], [ 4 ] ], [ [ 13, [ 0, 112, 45 ], [ 43, 28, 139, 386 ] ], [ 43, 28, 139, 386, 86 ] ], [ [ 7, 342, 50, 43, 34 ], [ 43, 50 ], [ 11 ] ], [ [ 35, 8, 14, 488, [ 43, 99, 488 ] ], [ 43, 99, 61, 691 ], [ [ 84, 241, 692 ] ] ], [ [ 13, [ 0, 15 ], [ 30, 0, 293, 47 ] ], [ 30, 0, 293, 47 ], [ [ 0, 67 ], [ 372, 220 ] ], 2 ], [ [ 203, 92, [ 30, 696, 92 ] ], [ 30, 917, 918, 697, 92 ] ], [ [ 27, [ 29, 26 ], [ 30, 29, 26, 157, 116 ] ], [ 30, 29, 26, 157, 116, 96, 97 ], [ [ 0, 116 ] ] ], [ [ 324, 8, 14, [ 283, 52 ], [ 30, 534, 535, 241, 44, 283, 52 ] ], [ 30, 534, 535, 241, 44, 283, 52, 139, 14 ] ], [ [ 324, 8, 14, [ 188, 52 ], [ 30, 534, 535, 241, 44, 188, 52 ] ], [ 30, 534, 535, 241, 44, 188, 52, 139, 14 ] ], [ [ 140, 923 ], 923, [ 4 ] ], [ [ 376, [ 29, 0, 24, 133, 150 ], [ 211, 133, 150, 88 ] ], [ 211, 29, 59 ], [ [ 29, 0, 4 ] ] ], [ [ 35, 8, 14, 701, 924 ], [ 925, 91, 99, 84 ] ], [ [ 42, 1, 23, 215, 927 ], 927, [ 11 ] ], [ [ 48, 40, 0, [ 115, 270, 9, 86 ] ], [ 120, 115, 0, 270, 9, 86 ], [ [ 270, 9, 4 ] ] ], [ [ 9, 146, 928, 34 ], [ 120, 146, 109, 9 ], [ 931 ] ], [ [ 48, 40, 119, 520, [ 2, 250, 119 ] ], [ 120, 2, 250, 119 ], [ 10 ], 0 ], [ [ 122, 8, 14, [ 58, 227 ], [ 113, 702, 74, 18 ], 103, 34 ], [ 120, 113, 9, 58, 702, 74, 18 ], [ [ 74, 4 ], 931 ], 3 ], [ [ 129, 106, [ 1, 60, 6, 214, 15 ], 34 ], [ 120, 60, 6, 214, 15, 249, 1 ], [ 11 ] ], [ [ 129, 106, [ 1, 60, 6, 214, 6 ], 34 ], [ 120, 60, 6, 249, 1 ], [ 11 ] ], [ [ 122, 8, 14, [ 15, 74, 9 ], [ 2, 6, 15, 9, 227, 5 ], 103, 34, 421 ], [ 120, 3, 15, 9, 227, 5 ], [ [ 199, 4 ], [ 360, 4 ], 86, 37, 12 ], 28 ], [ [ 122, 8, 14, [ 58, 227 ], [ 58, 617, 389 ], 103, 34 ], [ 120, 3, 9, 58, 617, 389, 19 ], [ 10, 931, 37, 12 ], 12 ], [ [ 122, 8, 14, [ 15, 74, 9 ], [ 2, 9, 227 ], 34, 103, 421 ], [ 120, 3, 9, 227 ], [ 11, [ 74, 4 ], 86, 37, 12 ], 28 ], [ [ 9, [ 3, 9, 40, 703, 531, 5 ] ], [ 120, 3, 9, 40, 703, 531, 5 ], [ 11, 931 ], 0 ], [ [ 122, 8, 14, [ 58, 227 ], [ 2, 58, 18 ], 34 ], [ 120, 3, 9, 343, 58, 18 ], [ 931 ] ], [ [ 122, 8, 14, [ 58, 227 ], [ 451, 58, 182, 47 ], 34, 421, 103 ], [ 120, 3, 9, 451, 58, 182, 47 ], [ 11, 10, 931, [ 0, 187, 67 ] ], 14 ], [ [ 122, 8, 14, [ 15, 74, 9 ], [ 15, 136, 448, 9, 86 ], 421, 34, 103 ], [ 120, 3, 9, 86, 85, 15, 136, 448 ], [ 11, [ 74, 4 ], [ 360, 4 ] ], 7 ], [ [ 48, 40, 119, [ 198, 89, 119 ] ], [ 198, 89, 119 ], [ [ 619, 362 ], [ 89, 490, 54 ], [ 273, 66 ], 10, [ 544, 620, 67 ], [ 936, 300 ], 931, [ 3, 708 ], [ 91, 273 ] ], 256 ], [ [ 48, 40, 119, [ 198, 7, 119 ] ], [ 198, 7, 119 ], [ 11, [ 619, 362 ], [ 7, 490, 54 ], [ 273, 66 ], 10, [ 544, 620, 67 ], [ 91, 273 ] ], 96 ], [ [ 48, 40, 119, [ 198, 79, 89, 119 ] ], [ 198, 79, 89, 119 ], [ [ 619, 362 ], [ 89, 490, 54 ], [ 53, 4 ], [ 273, 66 ], 10, [ 544, 620, 67 ], 931, [ 3, 708 ], [ 91, 273 ] ], 256 ], [ [ 42, 1, 24, 173, [ 545, 5 ] ], [ 545, 1, 24, 173 ], [ 11 ] ], [ [ 9, [ 709, 9, 86 ], 34 ], [ 709, 9, 86 ], [ 931 ] ], [ [ 9, [ 274, 176, 40, 18 ], 34 ], [ 274, 176, 40 ], [ 931 ] ], [ [ 286, 8, 14, 454, [ 274, 160, 710, 546 ], 34 ], [ 274, 160, 710, 546, 18, 9, 58 ], [ 11 ] ], [ [ 9, [ 274, 345, 43 ], 34 ], [ 274, 345, 43 ], [ 931 ] ], [ [ 48, 40, 119, [ 2, 89, 391, 54 ] ], [ 2, 89, 391, 54 ] ], [ [ 7, [ 30, 7 ], [ 2, 1, 15, 74, 5 ], 34 ], [ 2, 1, 15, 74, 5 ], [ 11 ] ], [ [ 7, [ 30, 7 ], [ 2, 1, 38, 15, 74, 5 ], 34, 103 ], [ 2, 1, 38, 15, 74, 5 ], [ [ 38, 1, 4 ], 10 ], 3 ], [ [ 7, [ 30, 7 ], [ 2, 1, 38, 190, 74, 5 ], 34, 103 ], [ 2, 1, 38, 190, 74, 5 ], [ [ 38, 1, 4 ], 10 ], 3 ], [ [ 7, [ 30, 7 ], [ 2, 1, 38, 190, 5 ], 34, 103 ], [ 2, 1, 38, 190, 5 ], [ [ 38, 1, 4 ], 10 ], 3 ], [ [ 42, [ 1, 23, 187 ], [ 2, 21, 712 ] ], [ 2, 1, 23, 187 ], [ 11 ] ], [ [ 7, [ 30, 7 ], [ 2, 1, 190, 74, 5 ], 34 ], [ 2, 1, 190, 74, 5 ], [ 11 ] ], [ [ 7, [ 30, 7 ], [ 2, 1, 190, 5 ], 34 ], [ 2, 1, 190, 5 ], [ 11 ] ], [ [ 7, 7, [ 1, 548 ] ], [ 2, 1, 548 ], [ 11 ] ], [ [ 7, [ 30, 7 ], [ 2, 7, 206, 174, 51, 5 ], 34 ], [ 2, 7, 206, 174, 51, 5 ], [ 10 ] ], [ [ 42, [ 7, 132 ], 43 ], [ 2, 7, 132, 51, 43 ], [ 11 ], 0 ], [ [ 46, 719, [ 2, 7, 226, 5 ] ], [ 2, 7, 226, 5 ], [ 11 ] ], [ [ 7, [ 7, 5 ], [ 2, 7, 138, 389, 5 ], 34 ], [ 2, 7, 138, 389, 5 ], [ 11, 37, 12 ], 4 ], [ [ 42, [ 720, 394 ] ], [ 2, 7, 720, 394 ], [ 11 ] ], [ [ 48, 40, 119, [ 2, 7, 391, 54 ] ], [ 2, 7, 391, 54 ] ], [ [ 48, 40, 119, [ 2, 165, 89, 391, 54 ] ], [ 2, 165, 89, 391, 54 ] ], [ [ 13, [ 0, 15 ], [ 110, 15, 304, 43 ] ], [ 2, 110, 15, 304, 43 ], [ 101, 721 ], 2 ], [ [ 13, [ 0, 15 ], [ 110, 15, 304 ] ], [ 2, 110, 15, 304 ], [ 101, 721, 37, 12 ], 8 ], [ [ 27, 13, 0, [ 2, 110, 6, 552, 19 ] ], [ 2, 110, 6, 552, 19 ], [ 10 ], 0 ], [ [ 42, [ 7, 346 ], [ 68, 394, 345, 51 ] ], [ 2, 68, 1, 394, 51 ] ], [ [ 46, 7, [ 1, 51, 144, 38 ], [ 2, 68, 7, 38, 23 ], 34, 103 ], [ 2, 68, 7, 38, 23, 1, 51, 144 ], [ [ 38, 1, 4 ], 10 ], 3 ], [ [ 7, [ 30, 68, 1 ], [ 2, 68, 7, 38, 23 ], 34, 103 ], [ 2, 68, 7, 38, 23 ], [ [ 38, 1, 4 ], 10 ], 3 ], [ [ 7, [ 30, 68, 1 ], [ 2, 68, 7, 44, 20 ], 34 ], [ 2, 68, 7, 44, 20 ], [ 11 ] ], [ [ 46, 7, [ 1, 51, 144, 38 ], [ 2, 232, 233, 7, 38, 23 ], 34, 103 ], [ 2, 232, 233, 7, 38, 23, 1, 51, 144 ], [ [ 38, 1, 4 ], 10 ], 3 ], [ [ 7, [ 30, 232, 233, 1 ], [ 2, 232, 233, 7, 38, 23 ], 34, 103 ], [ 2, 232, 233, 7, 38, 23 ], [ [ 38, 1, 4 ], 10 ], 3 ], [ [ 7, [ 30, 232, 233, 1 ], [ 2, 232, 233, 7, 44, 20 ], 34 ], [ 2, 232, 233, 7, 44, 20 ], [ 11 ] ], [ [ 175, [ 28, 36 ], [ 2, 186, 28, 288, 723 ] ], [ 2, 186, 28, 288, 723 ], [ 10 ] ], [ [ 13, [ 186, 45 ], [ 2, 186, 18, 21, 4 ] ], [ 2, 186, 18, 21, 4 ], [ 10 ] ], [ [ 13, [ 186, 45 ], [ 2, 186, 40, 18 ] ], [ 2, 186, 40, 18 ], [ 10 ] ], [ [ 48, 40, 53, [ 2, 78, 5 ] ], [ 2, 53, 78 ], [ 10 ] ], [ [ 48, 40, 53, [ 2, 53, 18, 19 ] ], [ 2, 53, 18, 19 ], [ 10 ] ], [ [ 48, 40, 53, [ 2, 53, 305, 19 ] ], [ 2, 53, 305, 19 ], [ [ 200, 4 ], [ 90, 4 ] ], 0 ], [ [ 152, 319, 947 ], [ 2, 319, 21, 725, 17, 16, 59 ], [ [ 0, 116 ], [ 725, 116 ] ], 3 ], [ [ 27, 167, [ 2, 256, 167, 45, 5 ] ], [ 2, 256, 167, 45, 5 ] ], [ [ 46, [ 55, 297, 298 ], 1, [ 44, 20 ] ], [ 2, 55, 297, 298, 44, 20 ], [ 11 ], 0 ], [ [ 7, [ 30, 335, 1 ], [ 2, 55, 6, 64, 7, 38, 23 ], 34, 103 ], [ 2, 55, 6, 64, 7, 38, 23 ], [ [ 38, 1, 4 ], 10 ], 3 ], [ [ 7, [ 30, 335, 1 ], [ 2, 55, 6, 64, 7, 44, 20 ], 34 ], [ 2, 55, 6, 64, 7, 44, 20 ], [ 11 ] ], [ [ 42, 1, 104, [ 2, 726, 1, 18 ] ], [ 2, 726, 727, 1, 18 ], [ 11 ] ], [ [ 13, [ 499, 92 ], [ 2, 78, 18, 21, 301, 174 ] ], [ 2, 78, 208, 21, 174, 241 ], [ [ 460, 208 ] ], 0 ], [ [ 13, 132, 51, 34 ], [ 2, 132, 51, 21, 51, 4 ], [ 1011 ] ], [ [ 42, [ 7, 346 ], [ 247, 394, 345, 51 ] ], [ 2, 247, 1, 394, 51 ] ], [ [ 46, 7, [ 1, 51, 144, 38 ], [ 2, 247, 7, 38, 23 ], 34, 103 ], [ 2, 247, 1, 44, 38, 1, 51, 144 ], [ 11, 10 ], 3 ], [ [ 7, 247, [ 44, 38 ], 34, 103 ], [ 2, 247, 1, 44, 38 ], [ 11, 10 ], 3 ], [ [ 7, 247, [ 44, 20 ], 34 ], [ 2, 247, 1, 44, 20 ], [ 11 ] ], [ [ 13, [ 0, 112, 45 ], [ 2, 348, 45, 18 ] ], [ 2, 348, 45, 18 ], [ 10 ] ], [ [ 32, [ 17, 16 ], [ 2, 202, 529, 164, 530 ] ], [ 2, 202, 529, 164, 530 ], [ 10 ] ], [ [ 32, 104, [ 2, 104, 21, 4 ] ], [ 2, 104, 21, 4 ], [ [ 104, 4 ] ] ], [ [ 13, [ 0, 112, 45 ], [ 2, 338, 45, 18 ] ], [ 2, 338, 45, 18 ], [ 10 ] ], [ [ 0, 15, 161, [ 15, 4, 5 ] ], [ 2, 15, 161, 4, 5 ] ], [ [ 0, 15, 161, [ 161, 15, 18 ] ], [ 2, 15, 161, 18 ], [ 101, 102 ], 2 ], [ [ 7, [ 30, 7 ], [ 2, 15, 74, 5, 44, 162, 1 ], 34 ], [ 2, 15, 74, 5, 44, 162, 1 ], [ 101, 37, 12, 950 ], 8 ], [ [ 13, [ 0, 112, 45 ], [ 2, 15, 18 ] ], [ 2, 15, 0, 18, 21, 6, 0, 4 ], [ 10 ] ], [ [ 27, [ 0, 6 ], [ 15, 18 ] ], [ 2, 15, 18, 19 ], [ 101 ] ], [ [ 27, [ 0, 15 ], 148, [ 2, 15, 21, 4 ] ], [ 2, 15, 19 ], [ 101 ] ], [ [ 7, [ 271, 64 ], [ 38, 23 ], 34, 103 ], [ 2, 271, 64, 1, 38, 23 ], [ [ 38, 1, 4 ], 10 ], 3 ], [ [ 7, [ 271, 64 ], [ 23, 44, 20 ], 34 ], [ 2, 271, 64, 1, 44, 20 ], [ 11 ] ], [ [ 236, 0, [ 2, 38, 0, 47, 18 ] ], [ 2, 38, 0, 47, 18 ] ], [ [ 236, 0, [ 2, 38, 0, 47, 86 ] ], [ 2, 38, 0, 47, 86 ], [ [ 260, 0, 4 ] ] ], [ [ 203, 554, [ 554, 116, 5 ] ], [ 2, 554, 116, 5 ] ], [ [ 175, [ 6, 17 ], [ 2, 279, 21, 730, 4 ] ], [ 2, 279, 954, 4 ], [ [ 730, 4 ] ] ], [ [ 27, 0, [ 3, 30, 6, 396 ] ], [ 2, 30, 0, 396 ], [ [ 0, 67 ] ] ], [ [ 42, [ 7, 146, 66 ], [ 2, 21, 1, 4 ] ], [ 2, 146, 282, 118, 21, 1, 4 ], [ 11 ] ], [ [ 203, 47, [ 2, 146, 61 ] ], [ 2, 146, 61 ] ], [ [ 13, [ 0, 15 ], [ 2, 732, 545, 0, 208 ] ], [ 2, 732, 545, 0, 208 ], [ 10 ] ], [ [ 27, [ 29, 0 ], [ 2, 160, 143, 437 ] ], [ 2, 160, 143, 437 ], [ 10 ] ], [ [ 13, [ 0, 15 ], [ 2, 71, 45, 18 ] ], [ 2, 71, 45, 18 ], [ 10 ] ], [ [ 27, [ 0, 134, 66 ], 34 ], [ 2, 134, 66, 18, 19 ], [ [ 134, 66, 4 ] ] ], [ [ 48, 61, 154, [ 2, 154, 733 ] ], [ 2, 154, 733 ], [ 10 ] ], [ [ 48, 61, 154, [ 2, 154, 463 ] ], [ 2, 154, 463 ], [ 10 ] ], [ [ 48, 61, 154, [ 2, 154, 13, 18 ] ], [ 2, 154, 13, 18 ], [ 10 ] ], [ [ 9, 955 ], 955, [ 11 ] ], [ [ 203, 629, [ 2, 629, 393, 5 ] ], [ 2, 629, 393, 5 ] ], [ [ 13, [ 2, 383, 95, 13, 552 ] ], [ 2, 383, 95, 13, 552 ], [ 11, [ 610, 67 ] ], 3 ], [ [ 46, 70, 1, [ 44, 20 ] ], [ 2, 70, 1, 44, 20 ], [ 11, 10 ], 0 ], [ [ 25, 8, [ 321, 24, 735, 1, 4 ] ], [ 2, 321, 24, 735, 1, 4 ] ], [ [ 7, [ 30, 221, 1 ], [ 2, 221, 7, 38, 23 ], 34, 103 ], [ 2, 221, 7, 38, 23 ], [ [ 38, 1, 4 ], 10 ], 3 ], [ [ 7, [ 30, 221, 1 ], [ 2, 221, 7, 44, 20 ], 34 ], [ 2, 221, 7, 44, 20 ], [ 11 ] ], [ [ 35, 8, 14, 701, 962 ], 962 ], [ [ 324, 8, 14, [ 557, 13 ], 963 ], 963, [ 11 ], 0 ], [ [ 203, 301, [ 736, 737 ] ], [ 2, 301, 736, 737, 201 ] ], [ [ 13, [ 0, 112, 45 ], [ 2, 0, 304, 182, 43 ] ], [ 2, 0, 304, 182, 43 ], [ 10 ] ], [ [ 32, 0, 52, 72, [ 2, 0, 52, 72, 21, 0, 4 ] ], [ 2, 0, 52, 72 ], [ 10 ] ], [ [ 13, [ 499, 92 ], [ 2, 0, 92, 201, 240 ] ], [ 2, 0, 92, 201, 240 ], [ 102, [ 13, 240, 67 ] ], 3 ], [ [ 257, [ 28, 1, 289 ], [ 2, 0, 289, 88 ] ], [ 2, 0, 289, 88, 246, 258, 16, 36 ], [ [ 0, 116 ] ] ], [ [ 27, 0, [ 2, 30, 6, 396 ] ], [ 2, 0, 30, 396 ] ], [ [ 175, [ 28, 36 ], 421, 103, 34 ], [ 2, 0, 45, 36, 19, 28, 36 ], [ [ 183, 241 ], [ 183, 67 ], 10 ], 7 ], [ [ 27, [ 0, 45 ], 739, 18 ], [ 2, 0, 45, 739, 18, 228, 108, 158, 19 ], [ 10 ] ], [ [ 27, [ 0, 45 ], 112, [ 2, 22, 135, 260, 93, 966 ] ], [ 2, 0, 22, 740, 135, 260, 93, 72 ], [ 10 ] ], [ [ 27, 0, 206, [ 2, 0, 51, 18 ] ], [ 2, 0, 51, 18, 19 ], [ 10 ] ], [ [ 27, 0, 206, [ 2, 0, 51, 5 ] ], [ 2, 0, 51, 5, 19 ], [ 10 ] ], [ [ 27, [ 0, 45 ], 112, [ 2, 28, 256, 18, 21, 0, 4 ] ], [ 2, 28, 256, 18, 21, 0, 4 ], [ 10 ] ], [ [ 27, [ 0, 45 ], 112, [ 2, 28, 251, 285, 23 ] ], [ 2, 28, 251, 285, 23 ], [ 10 ] ], [ [ 27, [ 0, 45 ], 112, [ 2, 28, 251, 285, 179 ] ], [ 2, 28, 251, 285, 179 ], [ 10, [ 37, 88 ] ], 3 ], [ [ 27, [ 0, 45 ], 112, [ 2, 28, 251, 285 ] ], [ 2, 28, 251, 285 ], [ 10 ] ], [ [ 140, [ 2, 28, 742, 631, 18 ] ], [ 2, 28, 742, 631, 18 ], [ 10 ] ], [ [ 24, [ 24, 54 ], [ 2, 24, 54, 5 ], 34 ], [ 2, 24, 54, 5 ], [ 10 ] ], [ [ 27, [ 0, 6 ], [ 2, 66, 208, 5 ] ], [ 2, 6, 66, 208, 5, 19 ], [ 102 ] ], [ [ 7, [ 30, 6, 245, 1 ], [ 2, 6, 245, 7, 38, 23 ], 34, 103 ], [ 2, 6, 245, 7, 38, 23 ], [ [ 38, 1, 4 ], 10 ], 3 ], [ [ 7, [ 30, 6, 245, 1 ], [ 2, 6, 245, 7, 44, 20 ], 34 ], [ 2, 6, 245, 7, 44, 20 ], [ 11 ] ], [ [ 46, 7, [ 1, 51, 144, 38 ], [ 2, 6, 64, 7, 38, 23 ], 34, 103 ], [ 2, 6, 64, 7, 38, 23, 1, 51, 144 ], [ [ 38, 1, 4 ], 10 ], 3 ], [ [ 7, [ 30, 335, 1 ], [ 2, 6, 64, 7, 38, 23 ], 34, 103 ], [ 2, 6, 64, 7, 38, 23 ], [ [ 38, 1, 4 ], 10 ], 3 ], [ [ 7, [ 30, 335, 1 ], [ 2, 6, 64, 7, 44, 20 ], 34 ], [ 2, 6, 64, 7, 44, 20 ], [ 11 ] ], [ [ 286, 8, 14, 969, [ 2, 6, 744, 426 ], 34 ], [ 2, 6, 744, 426, 9, 58 ], [ 10, [ 0, 187, 67 ], [ 22, 143 ] ], 4 ], [ [ 122, 8, 14, [ 6, 74, 9 ], [ 3, 6, 74, 9, 5 ], 103, 34, 421 ], [ 2, 6, 74, 9, 5 ], [ 11, [ 74, 4 ], 86, 37, 12 ], 28 ], [ [ 27, [ 17, 16, 0 ], [ 2, 6, 17, 16, 18 ] ], [ 2, 6, 17, 16, 18, 19 ], [ 10 ] ], [ [ 27, [ 0, 45 ], 112, [ 2, 6, 5, 21, 124, 139, 15 ] ], [ 2, 6, 5, 21, 124, 139, 15, 19 ], [ 101 ] ], [ [ 7, [ 6, 560, 76 ], [ 561, 18 ], 34, 103 ], [ 2, 6, 561, 18 ], [ 11, 10 ], 3 ], [ [ 9, 6, [ 2, 6, 327 ], 34 ], [ 2, 6, 327 ], [ [ 199, 4 ], 37, 12 ], 4 ], [ [ 32, [ 15, 6 ], [ 2, 6, 634, 15, 88 ] ], [ 2, 6, 634, 15, 88, 19 ], [ 102 ] ], [ [ 7, [ 6, 560, 76 ], [ 24, 398 ], 34, 103 ], [ 2, 6, 560, 76, 1, 24, 398 ], [ 11, 10 ], 3 ], [ [ 13, [ 0, 6 ], 148, [ 2, 6, 21, 4 ] ], [ 2, 6 ], [ 102 ] ], [ [ 286, 8, 14, 454, [ 2, 169, 13, 9 ] ], [ 2, 169, 13, 9, 9, 58 ] ], [ [ 257, [ 0, 17, 16, 36 ], [ 17, 16, 7, 223, 18 ] ], [ 2, 17, 16, 7, 223, 18, 19, 246, 258, 16, 36 ], [ 10 ] ], [ [ 46, [ 17, 16, 73 ], 1, [ 44, 20 ] ], [ 2, 17, 16, 73, 1, 44, 20 ], [ 11, 10 ], 0 ], [ [ 27, [ 30, 0 ], [ 2, 17, 16, 6, 249 ] ], [ 2, 17, 16, 6, 249 ] ], [ [ 46, [ 17, 16, 76 ], 1, [ 44, 38 ], 34, 103 ], [ 2, 17, 16, 76, 1, 44, 38 ], [ [ 38, 1, 4 ], 10 ], 3 ], [ [ 46, [ 17, 16, 76 ], 1, [ 44, 170 ], 103, 34 ], [ 2, 17, 16, 76, 1, 44, 170 ], [ 10, [ 239, 1, 4 ] ], 3 ], [ [ 46, [ 17, 16, 76 ], 1, [ 44, 190 ], 103, 34 ], [ 2, 17, 16, 76, 1, 44, 190 ], [ 10, [ 199, 4 ] ], 3 ], [ [ 46, [ 17, 16, 76 ], 1, [ 44, 20 ], 34, 103 ], [ 2, 17, 16, 76, 1, 44, 20 ], [ 11, 10 ], 3 ], [ [ 46, [ 17, 16, 76 ], 1, [ 219, 98 ] ], [ 2, 17, 16, 76, 1, 219, 98 ], [ 10 ], 0 ], [ [ 48, 259, 971 ], 971, [ 931 ], 0 ], [ [ 25, 8, [ 2, 972 ] ], [ 2, 25, 89 ], [ 973 ] ], [ [ 25, 8, 25, 163, 77, [ 2, 25, 163, 77, 72 ] ], [ 2, 25, 163, 77, 72, 25, 268 ], [ [ 330, 4 ] ] ], [ [ 42, [ 7, 346 ], [ 216, 394, 345, 51 ] ], [ 2, 216, 1, 394, 51 ] ], [ [ 46, 7, [ 1, 51, 144, 38 ], [ 2, 216, 7, 38, 23 ], 34, 103 ], [ 2, 216, 7, 38, 23, 1, 51, 144 ], [ [ 38, 1, 4 ], 10 ], 3 ], [ [ 7, [ 30, 216, 1 ], [ 2, 216, 7, 38, 23 ], 34, 103 ], [ 2, 216, 7, 38, 23 ], [ [ 38, 1, 4 ], 10 ], 3 ], [ [ 7, [ 30, 216, 1 ], [ 2, 216, 7, 44, 20 ], 34 ], [ 2, 216, 7, 44, 20 ], [ 11 ] ], [ [ 32, [ 3, 157, 6, 18 ] ], [ 2, 157, 15, 18, 19, 28, 26 ], [ 101 ] ], [ [ 27, [ 0, 15 ], [ 2, 157, 6, 167 ] ], [ 2, 157, 6, 167, 19 ], [ 10 ] ], [ [ 365, 8, 14, 747, 974 ], [ 2, 501, 4, 365 ], [ 562 ], 0 ], [ [ 27, [ 13, 418 ], [ 2, 222, 18 ] ], [ 2, 222, 18, 19 ] ], [ [ 7, [ 30, 7 ], [ 2, 190, 74, 5, 44, 162, 1 ], 34 ], [ 2, 190, 74, 5, 44, 162, 1 ], [ 101, 37, 12, 950 ], 8 ], [ [ 7, [ 30, 7 ], [ 2, 190, 5, 44, 162, 1 ], 34 ], [ 2, 190, 5, 44, 162, 1 ], [ 101, 37, 12, 950 ], 8 ], [ [ 46, 7, [ 1, 51, 144, 38 ], [ 2, 87, 7, 38, 23 ], 34, 103 ], [ 2, 87, 1, 44, 38, 1, 51, 144 ], [ [ 38, 1, 4 ], 10 ], 3 ], [ [ 46, 87, 1, [ 44, 38 ], 34, 103 ], [ 2, 87, 1, 44, 38 ], [ [ 38, 1, 4 ], 10 ], 3 ], [ [ 46, 87, 1, [ 44, 20 ], 34 ], [ 2, 87, 1, 44, 20 ], [ 11 ] ], [ [ 331, [ 87, 73 ], 1, [ 44, 20 ], 34 ], [ 2, 87, 73, 1, 44, 20 ], [ 11 ] ], [ [ 331, [ 87, 76 ], 1, [ 44, 38 ], 34, 103 ], [ 2, 87, 76, 1, 44, 38 ], [ [ 38, 1, 4 ], 10 ], 3 ], [ [ 331, [ 87, 76 ], 1, [ 44, 190 ], 103, 34 ], [ 2, 87, 76, 1, 44, 190 ], [ 102, [ 199, 4 ] ], 3 ], [ [ 331, [ 87, 76 ], 1, [ 44, 20 ], 34 ], [ 2, 87, 76, 1, 44, 20 ], [ 11 ] ], [ [ 46, 95, 1, [ 44, 38 ], 34, 103 ], [ 2, 95, 7, 18, 44, 38 ], [ 11, 10 ], 3 ], [ [ 46, 95, 1, [ 44, 20 ], 34 ], [ 2, 95, 7, 18, 44, 20 ], [ 11 ] ], [ [ 46, 95, 337, [ 2, 95, 24, 18 ] ], [ 2, 95, 24, 44, 68 ], [ 11, 10 ], 0 ], [ [ 42, 95, [ 2, 95, 98 ] ], [ 2, 95, 98 ], [ 11, 10 ], 0 ], [ [ 46, 95, 337, [ 2, 52, 88 ] ], [ 2, 95, 337, 52, 88 ], [ 11, 10 ], 0 ], [ [ 255, 171, [ 2, 93, 23 ] ], [ 2, 93, 23, 19, 28, 171 ], [ 10, 124 ], 0 ], [ [ 27, [ 0, 15 ], [ 2, 555, 214, 15, 19 ] ], [ 2, 555, 214, 15, 19, 96, 97 ], [ 101 ] ], [ [ 46, 352, 1, [ 44, 20 ] ], [ 2, 352, 1, 44, 20 ], [ 11, 10 ], 0 ], [ [ 286, 8, 14, 559, [ 2, 250, 70 ] ], [ 2, 250, 70, 9, 58 ], [ 11 ] ], [ [ 27, 13, [ 0, 15 ], [ 57, 15 ], [ 15, 86 ] ], [ 2, 57, 15, 86, 19 ], [ 101 ] ], [ [ 129, 106, [ 57, 13 ], 632, [ 447, 19 ], 34 ], [ 2, 57, 13, 748, 749, 447, 1 ], [ [ 7, 4 ] ] ], [ [ 32, [ 17, 16 ], [ 2, 123, 17, 464, 750, 751 ] ], [ 2, 123, 17, 464, 750, 751 ], [ [ 360, 4 ] ] ], [ [ 27, 13, 0, [ 2, 386, 0, 5, 21, 30, 124 ] ], [ 2, 386, 0, 5, 21, 30, 124 ] ], [ [ 27, 353, [ 2, 386, 5 ] ], [ 2, 386, 5, 21, 0, 4 ], [ 10 ] ], [ [ 203, 636, [ 30, 15, 398, 204 ] ], [ 2, 204, 164, 398 ] ], [ [ 27, 0, 636, [ 30, 15, 398, 204 ] ], [ 2, 204, 164, 398, 19 ] ], [ [ 27, [ 6, 17, 293 ], [ 2, 88 ] ], [ 2, 88 ] ], [ [ 48, 287, 176, 975 ], 975, [ [ 89, 54 ], [ 39, 9, 123 ], [ 273, 118 ], [ 143, 0, 4, 609 ], [ 143, 67 ], 931 ], 0 ], [ [ 46, [ 60, 6, 73 ], 1, [ 44, 190 ] ], [ 2, 60, 6, 73, 1, 44, 190 ], [ 11 ], 0 ], [ [ 46, [ 60, 6, 73 ], 1, [ 44, 20 ] ], [ 2, 60, 6, 73, 1, 44, 20 ], [ 11, 10 ], 0 ], [ [ 46, [ 60, 6 ], 1, [ 44, 38 ], 34, 103 ], [ 2, 60, 6, 76, 1, 44, 38 ], [ [ 38, 1, 4 ], 10 ], 3 ], [ [ 46, [ 60, 6 ], 1, [ 44, 190 ], 103, 34 ], [ 2, 60, 6, 76, 1, 44, 190 ], [ 102, [ 199, 4 ] ], 3 ], [ [ 46, [ 60, 6 ], 1, [ 44, 20 ], 34 ], [ 2, 60, 6, 76, 1, 44, 20 ], [ 11 ] ], [ [ 42, [ 60, 425 ], [ 561, 18 ], 34 ], [ 2, 60, 425, 561, 18 ], [ 11 ] ], [ [ 42, [ 60, 425 ], [ 24, 398 ], 34 ], [ 2, 60, 425, 76, 1, 24, 398 ], [ 11 ] ], [ [ 257, [ 0, 60, 76, 36 ], [ 3, 60, 76, 7, 223, 18 ] ], [ 2, 60, 76, 7, 223, 18, 246, 258, 16, 36 ], [ 10 ] ], [ [ 131, 8, 159, [ 2, 9, 58, 294, 18 ] ], [ 2, 9, 58, 294, 18, 9, 159 ], [ [ 0, 116 ], 931 ], 3 ], [ [ 503, 13, 118, [ 9, 160, 752, 118 ] ], [ 2, 9, 160, 752, 118 ] ], [ [ 9, [ 2, 9, 392 ], 34 ], [ 2, 9, 392 ], [ 931 ] ], [ [ 13, [ 0, 6 ], [ 2, 9, 242, 465 ] ], [ 2, 9, 242, 465 ], [ 10, [ 0, 187, 67 ] ], 2 ], [ [ 42, 7, 976, [ 2, 7, 753 ] ], [ 2, 9, 37, 7, 753 ], [ 11 ] ], [ [ 416, 8, 14, [ 2, 417, 637, 208 ] ], [ 2, 417, 637, 208 ] ], [ [ 9, [ 2, 464, 16, 18 ], 34 ], [ 2, 464, 16, 18 ], [ 931 ] ], [ [ 42, 755, 977 ], [ 2, 243, 504, 241, 44, 20, 133, 150, 978 ], [ [ 73, 1, 4 ] ] ], [ [ 27, 13, 0, [ 2, 230, 45, 4, 19 ] ], [ 2, 230, 45, 4, 19, 96, 97 ] ], [ [ 27, 0, 189, 128, [ 2, 21, 4, 980, 453 ] ], [ 2, 189, 128, 21, 4, 212, 453 ], [ 4 ] ], [ [ 27, 0, 189, 128, [ 2, 189, 128, 23 ] ], [ 2, 189, 128, 23, 21, 4 ], [ 4 ] ], [ [ 137, [ 0, 41, 285, 84 ], [ 2, 146, 251, 285, 84 ] ], [ 2, 285, 84, 21, 0, 4, 194, 185, 108, 195, 14, 39 ], [ [ 0, 116 ] ] ], [ [ 46, 7, [ 1, 51, 144, 38 ], [ 2, 94, 7, 38, 23 ], 34, 103 ], [ 2, 94, 7, 38, 23, 1, 51, 144 ], [ [ 38, 1, 4 ], 10 ], 3 ], [ [ 7, [ 30, 94, 1 ], [ 2, 94, 7, 38, 23 ], 34, 103 ], [ 2, 94, 7, 38, 23 ], [ [ 38, 1, 4 ], 10 ], 3 ], [ [ 7, [ 30, 94, 1 ], [ 2, 94, 7, 44, 20 ], 34 ], [ 2, 94, 7, 44, 20 ], [ 11 ] ], [ [ 7, [ 30, 94, 1 ], [ 2, 94, 7, 174, 51, 5 ], 19, 34 ], [ 2, 94, 7, 174, 51, 5, 19 ], [ 10 ] ], [ [ 35, 8, 14, 204, 179, [ 21, 204, 4 ] ], [ 2, 179, 21, 204, 4 ], [ [ 204, 4 ] ] ], [ [ 27, [ 0, 45 ], 112, [ 2, 0, 126, 565, 759 ] ], [ 2, 126, 565, 72 ], [ 10 ] ], [ [ 203, 987, [ 760, 455 ] ], [ 2, 760, 455 ] ], [ [ 27, [ 0, 15 ], [ 2, 26, 212, 15 ] ], [ 2, 26, 212, 15, 19 ], [ 10 ] ], [ [ 9, [ 639, 240 ], 34 ], [ 2, 639, 240 ], [ 11 ] ], [ [ 27, [ 0, 6 ], [ 2, 16, 171, 304 ] ], [ 2, 16, 171, 304, 19 ], [ 10, 721, 37, 12 ], 0 ], [ [ 32, [ 0, 161, 41 ], [ 2, 82, 161, 41, 17, 16, 0, 88 ] ], [ 2, 82, 161, 41, 17, 16, 0, 88 ], [ 10 ] ], [ [ 46, 7, 290, 229 ], [ 2, 130, 38, 229 ], [ 11 ] ], [ [ 255, [ 2, 397, 193, 86, 19 ] ], [ 2, 397, 193, 86, 19, 28, 171 ] ], [ [ 27, [ 17, 16, 0 ], [ 2, 80, 17, 16, 0, 56 ] ], [ 2, 80, 17, 16, 0, 56, 18 ], [ 10 ] ], [ [ 35, 8, 14, 569, 8, [ 51, 4, 455 ] ], [ 2, 99, 51, 4, 455 ] ], [ [ 27, [ 29, 15 ], [ 2, 29, 15, 18 ] ], [ 2, 29, 15, 18 ], [ 10 ] ], [ [ 27, [ 30, 0 ], [ 2, 29, 249 ] ], [ 2, 29, 249 ] ], [ [ 27, 167, [ 2, 167, 45, 5, 19 ] ], [ 2, 167, 45, 5, 19 ] ], [ [ 142, [ 24, 54 ], [ 2, 203, 24, 54, 5 ] ], [ 2, 203, 24, 54, 5, 314 ] ], [ [ 7, 38, 229 ], [ 2, 229 ], [ 11 ] ], [ [ 27, [ 30, 0 ], [ 2, 223, 641, 222, 362, 989, 16 ] ], [ 2, 223, 641, 222, 362, 242, 16 ] ], [ [ 32, 0, 26, 52, [ 2, 182, 52, 88, 21, 0, 4 ] ], [ 2, 182, 52, 88, 21, 0, 4 ], [ 10 ] ], [ [ 32, 15, 6, [ 2, 182, 134, 123, 52, 88 ] ], [ 2, 182, 134, 123, 52, 88 ], [ [ 15, 0, 4 ] ] ], [ [ 32, 15, 6, [ 2, 182, 6, 52, 88 ] ], [ 2, 182, 6, 52, 88 ], [ [ 15, 0, 4 ] ] ], [ [ 203, [ 252, 238 ], [ 556, 302 ] ], [ 2, 252, 556, 302 ], [ [ 992, 252 ] ], 0 ], [ [ 13, 118, [ 2, 13, 66, 5 ] ], [ 2, 13, 66, 5 ] ], [ [ 324, 8, 14, [ 2, 13, 4, 78, 67 ] ], [ 2, 13, 4, 78, 67 ] ], [ [ 42, [ 7, 346 ], [ 2, 13, 346 ] ], [ 2, 13, 346 ], [ 10 ], 0 ], [ [ 27, [ 13, 418 ], [ 2, 13, 386, 392 ] ], [ 2, 13, 386, 392, 18 ], [ [ 372, 0, 4 ] ], 0 ], [ [ 13, [ 2, 13, 763, 764 ] ], [ 2, 13, 763, 764 ] ], [ [ 27, 167, [ 2, 13, 133, 150 ] ], [ 2, 13, 133, 150 ] ], [ [ 25, 8, [ 492, 993 ], 34 ], [ 2, 13, 994 ], [ 993 ] ], [ [ 137, 8, [ 322, 466, 84 ], 995 ], [ 2, 505, 322, 466, 194, 185, 108, 195, 14, 39 ] ], [ [ 13, [ 499, 92 ], [ 2, 90, 208 ] ], [ 2, 90, 13, 208 ] ], [ [ 48, 40, 53, [ 2, 61, 53, 5 ] ], [ 2, 61, 53, 5 ] ], [ [ 48, 61, 154, [ 2, 61, 154, 89 ] ], [ 2, 61, 154, 89 ], [ 10 ], 0 ], [ [ 35, 8, 14, [ 61, 209 ], [ 2, 209, 329, 4 ] ], [ 2, 61, 209, 329, 4 ] ], [ [ 48, 40, 61, [ 2, 61, 13, 18 ] ], [ 2, 61, 90, 18 ], [ 10 ] ], [ [ 48, 40, 61, [ 2, 61, 90, 305, 19 ] ], [ 2, 61, 90, 305, 19 ], [ [ 200, 4 ], [ 90, 4 ] ], 0 ], [ [ 13, [ 0, 112, 45 ], [ 0, 304, 5 ] ], [ 0, 304, 5 ], [ 10, 721, 37, 12 ], 8 ], [ [ 203, [ 640, 130, 283 ], [ 0, 61, 116 ], 34 ], [ 0, 130 ], [ 10 ] ], [ [ 152, [ 621, 622, 6 ], [ 24, 769 ] ], [ 24, 769, 17, 16, 59 ], [ 10 ] ], [ [ 42, 1, 24, 173, 571 ], [ 24, 173, 571, 316, 158 ], [ 11 ] ], [ [ 0, 25, 642 ], 642 ], [ [ 27, [ 0, 6 ], [ 6, 770, 15, 304 ] ], [ 6, 770, 15, 304, 19 ], [ 101, 102, 86 ], 7 ], [ [ 13, 636, [ 6, 17, 16, 130, 47 ] ], [ 6, 17, 16, 130, 47 ] ], [ [ 25, 8, [ 17, 570, 6 ], [ 772, 6, 13, 414 ] ], [ 169, 772, 6, 13, 414 ] ], [ [ 42, [ 7, 296, 280 ], [ 169, 82, 296, 280 ] ], [ 169, 82, 296, 280 ], [ 11 ], 0 ], [ [ 42, 328, [ 169, 217, 133, 773 ] ], [ 169, 217, 1, 133, 773 ] ], [ [ 140, 72, 18 ], [ 489, 125, 72 ] ], [ [ 7, 400, [ 266, 507, 5 ] ], [ 266, 507, 5 ], [ 11, 37, 12, 124 ], 8 ], [ [ 13, [ 266, 13, 573 ] ], [ 266, 13, 573 ], [ 101, 102 ], 3 ], [ [ 35, 8, 14, [ 55, 75 ], [ 63, 782, 22, 783 ] ], [ 63, 782, 22, 783 ], [ [ 55, 4 ] ] ], [ [ 13, [ 13, 145, 1e3, 40 ] ], [ 63, 145, 217, 450, 40, 21, 124 ] ], [ [ 35, 8, 14, 488, [ 63, 170, 488, 21, 10 ] ], [ 63, 170, 61, 691, 21, 0, 4 ], [ 10 ] ], [ [ 35, 8, 14, 488, 1002 ], 1002, [ [ 84, 241, 692 ] ] ], [ [ 114, 40, 153, 93, [ 63, 169, 153, 89 ] ], [ 63, 169, 153, 89 ] ], [ [ 32, [ 3, 0, 4, 63, 574 ] ], [ 63, 574, 28, 26 ], [ 10 ] ], [ [ 35, 8, 14, [ 6, 178, 75 ], [ 63, 22, 299, 21, 6, 4 ] ], [ 63, 22, 299, 21, 6, 4 ], [ 100 ] ], [ [ 27, 0, [ 63, 22, 784, 491, 220 ] ], [ 63, 22, 784, 491, 220 ], [ 10 ] ], [ [ 35, 8, 14, 785, [ 470, 99 ], [ 63, 99, 470 ] ], [ 63, 99, 470 ], [ 10 ] ], [ [ 35, 8, 14, [ 309, 50 ], [ 63, 99, 146, 50 ] ], [ 63, 99, 146, 50 ], [ 10 ] ], [ [ 35, 8, 14, [ 309, 50 ], [ 63, 99, 471, 50 ] ], [ 63, 99, 471, 50 ], [ 10 ] ], [ [ 35, 8, 14, [ 6, 99, 107, 84 ], [ 63, 99, 107 ] ], [ 63, 99, 107 ], [ [ 0, 116 ] ] ], [ [ 35, 8, 14, [ 184, 75 ], [ 63, 35, 1 ] ], [ 63, 35, 1 ], [ 11 ] ], [ [ 35, 8, 14, [ 55, 75 ], [ 63, 35, 55, 643 ] ], [ 63, 35, 55, 4 ], [ [ 55, 4 ], 100 ], 3 ], [ [ 35, 8, 14, [ 184, 75 ], [ 63, 35, 6, 643 ] ], [ 63, 35, 6, 4 ], [ 100 ] ], [ [ 35, 8, 14, 70, [ 63, 35 ] ], [ 63, 35, 35 ], [ 11 ] ], [ [ 786, 40, 576, 106, [ 1, 63, 13, 145, 187 ] ], [ 63, 13, 145, 187, 1 ] ], [ [ 324, 8, 14, 1004 ], 1004, [ 124 ] ], [ [ 25, 8, [ 63, 505 ] ], [ 63, 505, 1005 ], [ 10, 1005 ], 3 ], [ [ 27, [ 0, 134, 66 ], [ 62, 66, 472 ] ], [ 62, 66, 472, 19 ], [ [ 134, 66, 4 ] ] ], [ [ 27, 1006, [ 62, 145, 293, 788, 644 ] ], [ 62, 145, 293, 788, 644, 96, 97 ], [ 10 ], 0 ], [ [ 32, [ 6, 16 ], [ 62, 30, 17, 16, 26 ] ], [ 62, 30, 17, 16, 26, 28, 26 ], [ [ 73, 0, 4 ], [ 243, 0, 4 ] ], 3 ], [ [ 168, [ 111, 9, 3 ], [ 62, 300, 21, 98 ] ], [ 62, 300, 21, 72, 85, 83, 39 ], [ 931 ] ], [ (1, 
            u = [ 168, [ 111, 9, 3 ], [ 62, 300, 21, 98, 19 ] ], "1:" + t(u)), [ 62, 300, 21, 72, 85, 83, 39 ], [ [ 30, 67 ], 931 ], 3 ], [ [ 32, [ 6, 16 ], [ 62, 6, 17, 16, 302, 791 ] ], [ 62, 6, 17, 16, 302, 791, 19 ], [ [ 157, 241 ] ] ], [ [ 13, 244, [ 62, 169, 472 ] ], [ 62, 169, 472 ], [ [ 302, 4 ] ], 0 ], [ [ 27, 244, [ 62, 169, 792, 238 ] ], [ 62, 169, 792, 238, 19 ], [ 101 ] ], [ [ 131, 8, 281, 1007 ], 1007, [ [ 724, 123 ], 931 ], 2 ], [ [ 140, [ 62, 22, 80, 6 ] ], [ 62, 22, 80, 6 ], [ 10 ] ], [ [ 27, [ 248, 22, 72 ], [ 62, 22, 86 ] ], [ 62, 22, 86 ], [ 10, [ 125, 67 ] ], 3 ], [ [ 140, [ 62, 80, 0 ] ], [ 62, 80, 6, 19 ], [ 10 ] ], [ [ 137, 8, [ 322, 466, 84 ], 1008 ], [ 62, 13, 192, 194, 185, 108, 195, 14, 39 ] ], [ [ 32, 13, [ 62, 13, 17, 16 ] ], [ 62, 13, 17, 16, 28, 26 ], [ 11 ], 0 ], [ [ 503, 13, [ 219, 794, 169, 9 ] ], [ 219, 794, 169, 9, 13, 39 ] ], [ [ 42, [ 7, 296, 280 ], [ 219, 795, 441, 504, 18 ] ], [ 219, 795, 441, 504, 18 ], [ 11 ], 0 ], [ [ 7, 342, 264, [ 264, 796 ] ], [ 264, 1, 796 ], [ 11 ] ], [ [ 7, 342, 264, [ 264, 43 ], 34 ], [ 264, 43 ], [ 11 ] ], [ [ 7, 342, 50, [ 5, 1, 50, 104 ] ], [ 5, 1, 50, 104, 21, 1, 4 ], [ 11 ] ], [ [ 42, [ 7, 29 ], [ 5, 24, 0 ] ], [ 5, 24, 0 ], [ 11 ], 0 ], [ [ 35, 8, 14, [ 6, 35, 84 ], 5 ], [ 5, 6, 35, 84 ], [ [ 0, 116 ] ] ], [ [ 48, 259, 1015 ], 1015, [ 931 ] ], [ [ 42, 1, [ 105, 54 ], [ 5, 390 ] ], [ 5, 105, 54, 21, 0, 4 ], [ 10, [ 0, 187, 67 ] ], 2 ], [ [ 42, [ 7, 0 ], [ 799, 800, 0, 141 ] ], [ 5, 799, 644, 800, 0, 141, 21, 1, 4 ], [ 11 ] ], [ [ 35, 8, 14, [ 309, 50 ], [ 5, 99, 146, 50, 586 ] ], [ 5, 99, 146, 50, 586 ], [ 10 ] ], [ [ 42, 1, [ 105, 54 ], [ 5, 203 ] ], [ 5, 203, 105, 54 ] ], [ [ 131, 8, 159, [ 355, 15, 5 ] ], [ 355, 15, 5 ] ], [ [ 131, 8, 159, [ 355, 123, 801 ], 34 ], [ 355, 123, 801 ], [ [ 355, 123 ] ] ], [ [ 27, 13, 0, [ 2, 110, 238, 522 ] ], [ 803, 2, 110, 238, 522 ] ], [ [ 27, 808, [ 2, 809, 37, 23 ] ], [ 808, 809, 37, 23, 19 ], [ 10 ] ], [ [ 35, 8, 14, [ 55, 75 ], [ 113, 184, 35, 587 ] ], [ 113, 55, 35, 587 ], [ [ 55, 4 ], 100, [ 99, 67 ] ], 7 ], [ [ 35, 8, 14, [ 184, 75 ], [ 113, 184, 35, 587, 19 ] ], [ 113, 184, 35, 587, 19 ], [ 10, [ 99, 67 ], [ 360, 4 ] ], 6 ], [ [ 13, [ 0, 112, 45 ], [ 57, 93, 43 ] ], [ 57, 93, 43 ], [ 10 ] ], [ [ 7, 400, [ 57, 431, 13, 5 ] ], [ 57, 431, 13, 5 ], [ 11 ] ], [ [ 35, 8, 14, [ 6, 9 ], 72, 2 ], [ 9, 72, 2 ], [ 10 ] ], [ [ 27, 0, 330, [ 115, 0 ] ], [ 330, 2, 0, 18, 96, 97 ], [ 10 ] ], [ [ 7, 342, 50, 37, 34 ], [ 37, 50 ], [ 11, 37, 12 ], 4 ], [ [ 27, [ 0, 45 ], 112, [ 31, 124, 139, 0, 329 ] ], [ 31, 124, 139, 0, 329, 19 ], [ 10, 124 ], 3 ], [ [ 42, [ 7, 346 ], [ 816, 333, 144 ] ], [ 816, 333, 144 ], [ 11, 931 ], 2 ], [ [ 48, 40, 53, [ 40, 413, 115, 90, 235, 116 ] ], [ 40, 413, 115, 90, 235, 116 ], [ 10 ] ], [ [ 27, 244, [ 244, 23, 18 ] ], [ 244, 23, 18, 19 ], [ 10, [ 329, 4 ] ], 3 ], [ [ 27, [ 0, 45 ], 112, [ 230, 139, 0, 329 ] ], [ 230, 139, 0, 329, 19 ], [ 10 ] ], [ [ 27, [ 0, 45 ], 112, [ 230, 434, 0, 37, 18, 57 ] ], [ 230, 434, 0, 37, 18, 57, 19 ], [ 10, [ 157, 124 ], [ 138, 67 ] ], 4 ], [ [ 27, [ 0, 45 ], 112, [ 230, 434, 0, 37, 18 ] ], [ 230, 434, 0, 37, 18, 19 ], [ 10, [ 157, 124 ], [ 138, 67 ] ], 4 ], [ [ 129, 269, [ 196, 1, 56, 198, 200, 183, 5 ] ], [ 196, 1, 56, 198, 200, 183, 5 ], [ 11, [ 273, 118 ], 10, [ 0, 187, 67 ], [ 544, 1028, 67 ], 308, [ 196, 86 ] ], 0 ], [ [ 129, 269, [ 196, 332, 1, 56, 198, 200, 183, 5 ] ], [ 196, 332, 1, 56, 198, 200, 183, 5 ], [ 11, [ 273, 118 ], 10, [ 196, 86 ], [ 239, 200, 183, 363 ] ], 0 ], [ [ 566, 8, 147, 1031 ], 1031, [ 11, [ 0, 116 ] ], 3 ], [ [ 35, 8, 14, [ 6, 1, 657, 84 ], [ 3, 1, 75, 657, 50, 308 ] ], [ 3, 1, 75, 657, 50, 308 ], [ 10 ] ], [ [ 35, 8, 14, [ 184, 75 ], [ 3, 1, 75, 47 ] ], [ 3, 1, 75, 47 ], [ 11 ] ], [ [ 35, 8, 14, [ 6, 1, 84 ], [ 3, 1, 75, 50, 469, 308 ] ], [ 3, 1, 75, 50, 469, 308 ] ], [ [ 35, 8, 14, [ 6, 1, 84 ], [ 3, 1, 75, 50, 308 ] ], [ 3, 1, 75, 50, 308 ], [ 10 ] ], [ [ 35, 8, 14, [ 6, 1, 84 ], [ 3, 1, 75, 50, 479, 308 ] ], [ 3, 1, 75, 50, 479, 308 ] ], [ [ 35, 8, 14, [ 184, 75 ], [ 3, 1, 75, 35, 84 ] ], [ 3, 1, 75, 35, 84 ], [ 11 ] ], [ [ 35, 8, 14, [ 55, 75 ], [ 3, 1, 35, 84 ] ], [ 3, 1, 35, 84 ], [ 11 ] ], [ [ 140, 1032 ], 1032, [ 100 ] ], [ [ 27, 368, [ 3, 369 ] ], [ 3, 368, 369, 92, 19 ], [ [ 413, 124 ], 10 ], 3 ], [ [ 32, [ 29, 15 ], [ 3, 85, 83, 92, 29, 0, 182, 88 ] ], [ 3, 85, 83, 92, 29, 0, 182, 88, 28, 26 ], [ 10 ] ], [ [ 114, 40, 153, 53, [ 3, 79, 53, 5 ] ], [ 3, 79, 53, 5 ] ], [ [ 25, 8, [ 3, 110, 149, 43 ], 34 ], [ 3, 110, 149, 43 ], [ [ 149, 241 ] ] ], [ [ 405, [ 3, 354, 56 ] ], [ 3, 354, 56, 85, 83, 406, 39 ], [ 10 ] ], [ [ 129, 106, [ 1, 3, 509, 6, 249 ], 34 ], [ 3, 509, 6, 249, 1 ], [ 11 ] ], [ [ 654, [ 3, 39, 229 ] ], [ 3, 39, 229 ] ], [ [ 122, 8, 14, [ 58, 227 ], [ 3, 58, 824, 18, 825, 7 ], 34 ], [ 3, 58, 824, 18, 825, 7 ], [ 11 ] ], [ [ 9, 41, [ 3, 41, 91, 201 ], 103, 34 ], [ 3, 41, 91, 201 ], [ [ 336, 4 ], [ 199, 4 ] ], 3 ], [ [ 9, 771, [ 3, 15, 826 ] ], [ 3, 15, 826 ] ], [ [ 35, 8, 14, [ 17, 16, 59, 5, 84 ], [ 3, 84 ] ], [ 3, 84, 35, 8 ], [ [ 0, 116 ] ] ], [ [ 35, 8, 14, [ 184, 75 ], [ 3, 43, 184, 35, 1 ] ], [ 3, 43, 184, 35, 1 ], [ 11 ] ], [ [ 35, 8, 14, [ 184, 75 ], [ 3, 43, 35, 21, 6, 4 ] ], [ 3, 43, 35, 21, 6, 4 ], [ 100 ] ], [ [ 35, 8, 14, [ 55, 75 ], [ 3, 43, 35 ] ], [ 3, 43, 35 ], [ [ 55, 4 ] ] ], [ [ 27, 368, [ 3, 372, 369 ] ], [ 3, 372, 369, 19 ], [ 10 ] ], [ [ 286, 8, 14, 827, [ 3, 146, 372, 1, 219, 58 ], 34 ], [ 3, 146, 372, 1, 219, 58, 9, 58 ], [ 11 ] ], [ [ 35, 8, 14, [ 6, 178, 75 ], [ 3, 178, 75, 84 ] ], [ 3, 178, 75, 84 ], [ 100 ] ], [ [ 829, 14, [ 592, 238 ], [ 3, 23 ] ], [ 3, 23, 592, 8 ], [ 10 ] ], [ [ 654, [ 3, 830, 18 ] ], [ 3, 830, 18 ], [ [ 39, 229 ] ], 0 ], [ [ 122, 8, 14, [ 6, 74, 9 ], [ 3, 74, 9, 18 ], 103, 34, 421 ], [ 3, 74, 9, 18 ], [ 11, [ 74, 4 ], 86 ], 7 ], [ [ 32, [ 147, 80, 0, 26 ], [ 3, 593, 831 ] ], [ 3, 593, 831 ], [ 10 ] ], [ [ 32, [ 147, 80, 0, 26 ], [ 3, 593, 832 ] ], [ 3, 593, 832 ] ], [ [ 27, [ 29, 0 ], [ 3, 543, 29, 0 ] ], [ 3, 543, 29, 0, 96, 97 ] ], [ [ 27, [ 15, 24, 604 ], [ 3, 833, 0 ] ], [ 3, 833, 0, 96, 97 ], [ 10 ] ], [ [ 416, 8, 14, [ 3, 198, 201 ] ], [ 3, 198, 201 ], [ [ 500, 4 ] ] ], [ [ 334, [ 3, 357, 54 ] ], [ 3, 357, 54, 5, 231, 193, 59, 14, 39 ] ], [ [ 35, 8, 14, [ 55, 75 ], [ 3, 170, 1, 35, 84 ] ], [ 3, 170, 1, 35, 84 ], [ 11 ] ], [ [ 384, 8, [ 0, 47 ], [ 3, 0, 47, 72 ], 34 ], [ 3, 0, 47, 72 ], [ 10, [ 0, 187, 67 ] ], 2 ], [ [ 35, 8, 14, [ 6, 1, 84 ], [ 3, 0, 204, 557 ] ], [ 3, 0, 204, 557 ], [ 10 ] ], [ [ 175, [ 28, 36 ], [ 3, 28, 412, 36 ] ], [ 3, 28, 412, 36 ], [ 10, [ 0, 67 ] ], 2 ], [ [ 140, 1039 ], 1039, [ 100 ] ], [ [ 32, [ 0, 41 ], [ 3, 6, 479, 41 ] ], [ 3, 6, 479, 41 ], [ [ 0, 116 ] ] ], [ [ 334, [ 3, 54, 5 ] ], [ 3, 1042, 54, 231, 193, 59, 14, 39 ] ], [ [ 122, 8, 14, [ 343, 58 ], [ 3, 25, 9, 23 ], 34 ], [ 3, 317, 458, 9, 23 ], [ 931 ] ], [ [ 165, 8, 25, [ 3, 25, 155, 94, 50 ] ], [ 3, 25, 155, 94, 50 ], [ 10 ] ], [ [ 27, [ 0, 45 ], [ 189, 388, 18 ], [ 3, 5, 21, 0, 4 ] ], [ 3, 5, 21, 0, 4 ], [ 10, [ 0, 67 ] ], 2 ], [ [ 829, 14, [ 592, 238 ], [ 3, 5 ] ], [ 3, 5, 592, 8 ], [ 10 ] ], [ [ 129, 106, [ 1, 3, 842, 6, 249 ], 34 ], [ 3, 842, 6, 249, 1 ], [ 11 ] ], [ [ 410, 8, 14, 827, [ 3, 146, 372, 1, 219, 58 ], 34 ], [ 3, 87, 254, 219, 58, 9, 58 ], [ 11 ] ], [ [ 286, 8, 14, 454, [ 9, 843, 844 ] ], [ 3, 9, 843, 844, 9, 58 ], [ 931 ] ], [ [ 122, 8, 14, [ 343, 58 ], [ 9, 345 ], 34 ], [ 3, 9, 345 ], [ 931 ] ], [ [ 9, [ 3, 9, 845, 177, 846 ], 34 ], [ 3, 9, 845, 109, 177, 155, 109 ], [ 11 ] ], [ [ 129, 106, [ 1, 3, 509, 6, 249 ], 847, 447, 34 ], [ 3, 847, 1047, 1 ], [ 11 ] ], [ [ 32, [ 147, 80, 0, 26 ], [ 3, 467, 147, 80, 0, 26, 5 ] ], [ 3, 467, 147, 80, 0, 26, 5 ], [ 10 ] ], [ [ 286, 8, 14, 454, [ 3, 343, 9, 23 ] ], [ 3, 343, 9, 23, 9, 58 ], [ 931 ] ], [ [ 152, 291, [ 578, 0, 18 ] ], [ 3, 578, 0, 18 ], [ [ 1048, 0, 4 ], 10 ], 3 ], [ [ 137, [ 3, 349 ], [ 0, 272, 461, 0 ] ], [ 3, 349, 0, 272, 461, 0, 21, 14 ], [ [ 562, 4 ], [ 349, 0, 4 ] ], 3 ], [ [ 152, [ 3, 349, 0, 272, 461, 0 ] ], [ 3, 349, 0, 272, 461, 0, 17, 16, 59 ], [ [ 562, 4 ], [ 349, 0, 4 ] ], 3 ], [ [ 32, [ 574, 1049, 18 ] ], [ 3, 574, 218, 310, 18 ], [ 10 ] ], [ [ 27, [ 3, 396, 0, 18 ] ], [ 3, 396, 0, 18, 96, 97 ] ], [ [ 165, 8, 25, [ 3, 475, 25, 5 ] ], [ 3, 475, 25, 5 ], [ 10, 37, 12 ], 0 ], [ [ 140, [ 3, 26, 594, 18 ] ], [ 3, 26, 594, 18 ], [ [ 0, 116 ] ] ], [ [ 48, 61, 154, [ 3, 589, 373 ] ], [ 3, 589, 373 ], [ 10 ] ], [ [ 140, 1051 ], 1051, [ 100 ] ], [ [ 140, 1052 ], 1052, [ 11 ] ], [ [ 32, [ 0, 321, 41 ], [ 3, 504, 179 ] ], [ 3, 504, 179 ], [ [ 1054, 4 ], [ 360, 4 ] ], 3 ], [ [ 32, [ 1055, 0, 849, 850 ] ], [ 3, 80, 0, 849, 850, 28, 26 ], [ 10 ] ], [ [ 32, [ 29, 0 ], [ 3, 29, 15, 182, 88 ] ], [ 3, 29, 15, 182, 88, 28, 26 ], [ 10 ] ], [ [ 32, [ 29, 0 ], [ 3, 29, 15, 191, 88 ] ], [ 3, 29, 15, 1056, 28, 26 ], [ 10 ] ], [ [ 27, [ 29, 0 ], [ 47, 851 ] ], [ 3, 29, 0, 851, 96, 97 ], [ 10 ] ], [ [ 32, [ 29, 15 ], [ 3, 29, 0, 191, 88 ] ], [ 3, 29, 0, 191, 88, 28, 26 ], [ 10 ] ], [ [ 140, [ 3, 6, 248, 5, 852, 371 ] ], [ 3, 248, 5, 852, 727, 316, 21, 6, 4 ], [ 100, [ 0, 187, 67 ] ], 2 ], [ [ 152, [ 24, 511, 414 ], [ 853, 125 ] ], [ 3, 853, 54, 17, 16, 59 ] ], [ [ 131, 8, 159, [ 3, 490 ] ], [ 3, 490, 9, 159 ], [ [ 159, 15 ], [ 159, 123 ], 931, [ 146, 208 ] ], 14 ], [ [ 27, [ 3, 124, 63, 854, 184 ] ], [ 3, 124, 63, 854, 184, 96, 97 ], [ 10 ] ], [ [ 32, [ 3, 218, 310, 191, 88 ] ], [ 3, 218, 191, 26, 88 ], [ [ 0, 116 ] ] ], [ [ 32, [ 29, 15, 237, 162, 98 ], [ 3, 13, 380, 136, 98 ] ], [ 3, 13, 380, 136, 98, 28, 26 ], [ [ 29, 15, 0, 4 ] ] ], [ [ 480, 8, 1060, 3 ], 3, [ 124 ], 0 ], [ [ 1062, 84, 1063 ], [ 1064, 115 ], [ 1065 ] ], [ [ 42, [ 7, 341 ], [ 341, 440 ] ], [ 341, 440 ], [ [ 1, 24, 4 ], 11 ], 3 ], [ [ 48, 61, 154, [ 148, 112, 53, 208 ] ], [ 148, 112, 53, 208 ], [ 721 ] ], [ [ 503, 13, [ 13, 18 ] ], [ 148, 13, 18, 13, 39 ] ], [ [ 35, 8, 14, [ 184, 75 ], [ 82, 1, 75, 35, 84 ] ], [ 82, 1, 75, 35, 84 ], [ 11, [ 75, 67 ] ], 3 ], [ [ 35, 8, 14, [ 55, 75 ], [ 82, 1, 35, 84 ] ], [ 82, 1, 35, 84 ], [ 11, [ 75, 67 ] ], 3 ], [ [ 140, 1074 ], 1074, [ 1075, 100 ], 3 ], [ [ 35, 8, 14, [ 55, 75 ], [ 82, 170, 1, 35, 84 ] ], [ 82, 170, 1, 35, 84 ], [ 11, [ 75, 67 ] ], 3 ], [ [ 140, 1076 ], 1076, [ 1075, 100 ], 3 ], [ [ 46, 7, 290, 1088 ], [ 130, 38, 868, 0, 45, 5 ], [ [ 38, 1, 4 ] ], 0 ], [ [ 786, 40, 576, 106, [ 576, 56, 872 ] ], [ 576, 56, 872 ] ], [ [ 152, [ 412, 344 ] ], [ 412, 344, 17, 16, 59 ], [ 10 ] ], [ [ 35, 8, 14, 569, 8, [ 99, 602, 179 ] ], [ 99, 602, 179 ] ], [ [ 35, 8, 14, 569, 8, [ 99, 602, 341 ] ], [ 99, 602, 341 ] ], [ [ 27, [ 0, 45 ], 170, [ 873, 0, 45, 5 ] ], [ 873, 0, 45, 5, 19 ], [ 721, 37, 12 ], 0 ], [ [ 48, 287, 176, [ 29, 198, 287 ] ], [ 29, 198, 287 ], [ [ 29, 0, 4 ], [ 89, 54 ], [ 89, 67 ], [ 273, 118 ], [ 491, 666 ], [ 143, 1091 ], 931, [ 239, 666 ] ], 128 ], [ [ 131, 8, 159, [ 519, 875, 1095 ] ], [ 519, 875, 260, 185, 9, 159 ], [ [ 159, 123 ], 931 ], 3 ], [ [ 25, 8, 1102, 103, 34 ], 1102, [ 43, [ 149, 241 ] ], 3 ], [ [ 255, [ 20, 397, 193, 86, 19 ] ], [ 20, 397, 193, 86, 19, 28, 171 ], [ 86 ] ], [ [ 137, 8, [ 322, 466, 84 ], 1107 ], [ 13, 192, 322, 466, 194, 185, 108, 195, 14, 39 ] ], [ [ 13, [ 13, 2, 242, 465 ] ], [ 13, 2, 242, 465 ] ], [ [ 407, [ 13, 2, 292 ] ], [ 13, 2, 292 ], [ [ 408, 67 ] ] ], [ [ 407, [ 13, 0, 2, 292 ] ], [ 13, 0, 2, 292 ], [ 10, [ 408, 67 ] ], 3 ], [ [ 7, 342, 264, [ 13, 63, 264 ], 34 ], [ 13, 264 ], [ 11 ] ], [ [ 13, 235 ], [ 235, 116 ], [ 116, [ 211, 300 ], 135, [ 393, 4 ] ], 15 ], [ [ 7, 400, [ 881, 5 ] ], [ 881, 5 ], [ 11, 37, 12 ], 4 ], [ [ 32, [ 28, 6, 254, 26 ], 19, [ 63, 505 ] ], [ 505, 28, 26 ] ], [ [ 13, [ 499, 92 ], [ 90, 92 ] ], [ 90, 92 ] ], [ [ 48, 61, 154, [ 2, 90 ] ], 90, [ 426, 10 ], 0 ] ]), 
            s(d, [ [ [ 405, [ 370, 354 ] ], [ 370, 354, 85, 83, 406, 39 ], [ 81 ] ], [ [ 13, [ 0, 6 ], [ 370, 15, 157 ] ], [ 370, 15, 157 ], [ 102, 10 ], 3 ], [ [ 25, 8, [ 89, 113 ] ], [ 89, 113 ], [ [ 25, 89, 228, 108, 158 ] ] ], [ [ 168, [ 1, 148 ], 669 ], [ 1, 433, 19, 85, 83, 39 ], [ 81 ] ], [ [ 131, 8, 159, [ 1, 333, 355, 123, 670 ] ], [ 1, 333, 355, 123, 670 ], [ [ 514, 229 ] ], 0 ], [ [ 7, 7, [ 0, 311, 67 ] ], [ 1, 0, 311, 67 ], [ 11 ], 0 ], [ [ 168, [ 1, 148 ], [ 1, 24, 56 ] ], [ 1, 24, 56, 19, 85, 83, 39 ], [ 81 ] ], [ [ 117, 8, [ 85, 16 ], 1, [ 882, 19 ] ], [ 1, 169, 409, 19 ], [ 81 ] ], [ [ 410, 8, 14, 483, 883 ], [ 1, 230, 671, 87, 254 ], [ 31 ] ], [ [ 334, 8, [ 1, 371, 192, 56 ] ], [ 1, 371, 192, 56, 231, 193, 59, 14, 39 ], [ 81 ] ], [ [ 42, 1, 51, [ 1, 356, 37 ] ], [ 1, 356, 37, 7, 51 ] ], [ [ 407, [ 1, 82, 292 ] ], [ 1, 82, 292 ], [ 11, [ 408, 67 ] ], 3 ], [ [ 7, 7, 215 ], [ 7, 215 ], [ [ 215, 31 ] ] ], [ [ 46, 7, 23, 24 ], [ 7, 23, 24, 5 ], [ [ 7, 23, 24, 31 ] ] ], [ [ 265, 8, 14, [ 9, 70 ], [ 7, 70, 56 ] ], [ 7, 70, 56, 70, 39 ], [ [ 7, 70, 56, 31 ] ] ], [ [ 42, 884, [ 672, 170, 244 ] ], [ 7, 170, 244 ], [ [ 672, 170, 244, 31 ] ] ], [ [ 42, 25, 149 ], [ 7, 149 ], [ 11 ] ], [ [ 140, 885 ], 885, [ 81 ] ], [ [ 131, 8, 159, [ 49, 85, 16, 159, 18 ] ], [ 49, 85, 16, 159, 18 ], [ 31 ] ], [ [ 165, 14, [ 49, 165, 266, 13 ] ], [ 49, 165, 266, 13 ], [ 31 ] ], [ [ 7, [ 30, 68, 1 ], [ 49, 68, 7 ] ], [ 49, 68, 7 ], [ [ 30, 68, 1, 31 ] ] ], [ [ 7, [ 30, 232, 233, 1 ], [ 49, 232, 233, 7 ] ], [ 49, 232, 233, 7 ], [ 31 ] ], [ [ 7, [ 30, 335, 1 ], [ 49, 55, 6, 64, 7 ] ], [ 49, 55, 6, 64, 7 ], [ [ 30, 55, 6, 64, 1, 31 ] ] ], [ [ 7, [ 30, 335, 1 ], [ 49, 55, 313, 6, 64, 7 ] ], [ 49, 55, 313, 6, 64, 7 ], [ 31 ] ], [ [ 13, 132, [ 49, 51 ] ], [ 49, 132, 51 ], [ 31 ] ], [ [ 27, [ 28, 7, 278 ], [ 49, 278, 226 ] ], [ 49, 278, 226 ], [ 81 ] ], [ [ 48, 61, 154, [ 49, 154, 373 ] ], [ 49, 154, 373 ], [ 31 ] ], [ [ 131, 8, 159, [ 49, 294, 18 ] ], [ 49, 294, 18 ], [ 374 ] ], [ [ 25, 8, [ 49, 166, 77, 6 ] ], [ 49, 166, 77, 6 ], [ [ 25, 0, 166, 77, 6, 81 ] ] ], [ [ 25, 8, [ 49, 166, 77 ] ], [ 49, 166, 77 ], [ [ 25, 0, 166, 77, 81 ] ] ], [ [ 7, [ 30, 221, 1 ], [ 49, 221, 7 ] ], [ 49, 221, 7 ], [ [ 30, 221, 1, 31 ] ] ], [ [ 48, 40, 53, [ 49, 0, 295, 53, 78 ] ], [ 49, 0, 295, 53, 78 ], [ 31 ] ], [ [ 25, 8, 0, 279, [ 49, 0, 279, 434, 88, 19 ] ], [ 49, 0, 279, 434, 88, 19 ], [ 31 ] ], [ [ 42, [ 0, 296, 280, 51 ], 49 ], [ 49, 0, 296, 280, 51 ], [ 31 ] ], [ [ 411, 8, [ 49, 0, 125 ] ], [ 49, 0, 125 ], [ [ 49, 234, 0, 125, 81 ] ] ], [ [ 142, [ 24, 54 ], [ 49, 24, 54 ] ], [ 49, 24, 54, 314 ], [ [ 24, 54, 49, 31 ] ] ], [ [ 140, 886 ], 886, [ 81 ] ], [ [ 7, [ 30, 6, 245, 1 ], [ 49, 6, 245, 7 ] ], [ 49, 6, 245, 7 ], [ [ 30, 6, 245, 1, 31 ] ] ], [ [ 7, [ 30, 335, 1 ], [ 49, 6, 64, 7 ] ], [ 49, 6, 64, 7 ], [ [ 30, 6, 64, 1, 31 ] ] ], [ [ 32, [ 6, 29 ], [ 49, 6, 29, 435 ] ], [ 49, 6, 29, 435 ], [ 31 ] ], [ [ 7, [ 30, 216, 1 ], [ 49, 216, 7 ] ], [ 49, 216, 7 ], [ 31 ] ], [ [ 42, 1, [ 105, 54 ], 49 ], [ 49, 105, 54 ], [ 31 ] ], [ [ 42, 1, 105, 49 ], [ 49, 105 ], [ 31 ] ], [ [ 255, [ 49, 57, 887 ] ], [ 49, 57, 171, 19, 28, 171 ], [ 31 ] ], [ [ 27, [ 6, 17, 293 ], [ 49, 88 ] ], [ 49, 88 ], [ 31 ] ], [ [ 265, 8, 14, [ 9, 70 ], [ 49, 9, 70 ] ], [ 49, 9, 70, 70, 39 ], [ [ 49, 9, 70, 31 ] ] ], [ [ 411, 8, [ 49, 9, 125 ] ], [ 49, 9, 125 ], [ [ 65, 49, 234, 9, 125, 673 ] ] ], [ [ 7, [ 30, 94, 1 ], [ 49, 94, 7 ] ], [ 49, 94, 7 ], [ 31 ] ], [ [ 140, 888 ], 888, [ 81 ] ], [ [ 117, 8, [ 267, 92 ], 49 ], [ 49, 267, 92 ], [ [ 267, 92, 49, 81 ] ] ], [ [ 131, 8, 281, 889 ], 889, [ 31 ] ], [ [ 13, 118, [ 49, 13, 66 ] ], [ 49, 13, 66 ], [ 31 ] ], [ [ 13, 890, [ 49, 13, 157, 26 ] ], [ 49, 13, 157, 26 ], [ 31 ] ], [ [ 35, 8, 14, [ 61, 209 ], [ 49, 209 ] ], [ 49, 61, 209 ] ], [ [ 27, [ 28, 7, 278 ], [ 515, 278, 226, 315 ] ], [ 515, 278, 226, 315 ], [ 81 ] ], [ [ 175, 436, [ 515, 28, 412, 36 ] ], [ 515, 0, 45, 412, 36 ], [ 31 ] ], [ [ 165, [ 6, 60, 282, 106 ] ], [ 165, 6, 891, 282, 106 ], [ 31 ] ], [ [ 13, [ 0, 6 ], [ 674, 15, 157 ] ], [ 674, 15, 157 ], [ [ 0, 134, 66, 4 ], 102 ], 3 ], [ [ 114, 40, 153, 53, [ 79, 68, 180, 53, 78 ] ], [ 79, 68, 180, 53, 78 ], [ 81 ] ], [ [ 114, 40, 153, 93, [ 79, 180, 135 ] ], [ 79, 180, 135 ], [ 81 ] ], [ [ 114, 79, 89, 90, [ 79, 136, 236, 90 ] ], [ 79, 136, 236, 90 ], [ 81 ] ], [ [ 48, 40, 119, [ 79, 3, 89, 119 ] ], [ 79, 3, 89, 119 ], [ [ 81, 316, 158 ] ] ], [ [ 114, 40, 153, 53, [ 79, 3, 53, 78 ] ], [ 79, 3, 53, 78 ], [ 81 ] ], [ [ 114, 79, 89, 90, [ 79, 3, 53, 18 ] ], [ 79, 3, 53, 18 ], [ 81 ] ], [ [ 114, 79, 89, 90, [ 79, 3, 414, 90, 18 ] ], [ 79, 3, 414, 90, 18 ], [ 81 ] ], [ [ 114, 79, 89, 90, [ 79, 3, 90, 23 ] ], [ 79, 3, 90, 23 ], [ 31 ] ], [ [ 114, 40, 153, 93, [ 79, 91, 135, 415 ] ], [ 79, 91, 135, 415 ], [ 81 ] ], [ [ 114, 40, 153, 53, [ 79, 82, 160, 78, 21, 78, 4 ] ], [ 79, 82, 160, 78, 21, 78, 4 ], [ 81 ] ], [ [ 114, 40, 153, 93, [ 79, 109, 604 ] ], [ 79, 109, 604 ], [ 81 ] ], [ [ 48, 40, 119, [ 79, 56, 89, 119 ] ], [ 79, 56, 89, 119 ], [ [ 81, 316, 158 ] ] ], [ [ 114, 40, 153, 53, [ 79, 516, 53, 78 ] ], [ 79, 516, 53, 78 ], [ 81 ] ], [ [ 114, 40, 153, 93, [ 79, 516, 135 ] ], [ 79, 516, 135 ], [ 81 ] ], [ [ 142, [ 377, 54 ], 110 ], [ 110, 377, 54, 14 ] ], [ [ 410, 8, 14, 483, 675 ], [ 892, 317, 671, 87, 254 ], [ 31 ] ], [ [ 9, 87, 675 ], 675, [ 31 ] ], [ [ 114, 79, 89, 90, [ 8, 181, 90, 53 ] ], [ 8, 181, 90, 53 ], [ 31 ] ], [ [ 0, 25, [ 68, 378, 6, 25 ] ], [ 68, 378, 6, 25 ], [ 31 ] ], [ [ 9, [ 68, 202, 605 ], 34 ], [ 68, 202, 605 ], [ 931 ] ], [ [ 13, [ 0, 6 ], [ 68, 15, 66 ] ], [ 68, 15, 66, 357 ], [ 31 ] ], [ [ 48, 40, 517, 126, 893 ], 893, [ 31 ] ], [ [ 46, 7, 23, 210, 68 ], 68, [ [ 7, 23, 31 ] ] ], [ [ 165, [ 165, 90 ], 120 ], [ 68, 90 ], [ [ 90, 31 ] ] ], [ [ 46, 7, 23, 210, [ 232, 233 ] ], [ 232, 233 ], [ [ 7, 23, 31 ] ] ], [ [ 168, [ 111, 9, 3 ], [ 111, 68, 18, 19 ] ], [ 111, 68, 18, 19, 85, 83, 39 ], [ 31 ] ], [ [ 168, [ 111, 9, 148 ], 19, [ 111, 86, 88 ] ], [ 111, 86, 88, 19, 85, 83, 39 ], [ 81 ] ], [ [ 416, 8, 14, [ 336, 417, 518 ] ], [ 336, 417, 518 ], [ [ 336, 417, 31 ] ] ], [ [ 32, 15, 6, [ 52, 15, 6, 134, 66 ] ], [ 52, 15, 6, 134, 66 ], [ 81 ] ], [ [ 32, 15, 6, [ 52, 15, 6 ] ], [ 52, 15, 6 ], [ 81 ] ], [ [ 13, 17, [ 52, 17, 161, 6 ] ], [ 52, 17, 161, 6 ], [ 31 ] ], [ [ 46, 95, 337, [ 52, 24 ] ], [ 52, 95, 24 ], [ 31 ] ], [ [ 32, [ 29, 0, 143, 358 ], [ 52, 29, 15, 237, 162, 98 ] ], [ 52, 29, 15, 237, 162, 98, 28, 26 ], [ 81 ] ], [ [ 9, 318, 894 ], 894, [ 11, 931 ], 3 ], [ [ 137, [ 319, 320, 144 ], 23 ], [ 319, 320, 144, 23, 194, 185, 108, 195, 14, 39 ], [ 81 ] ], [ [ 265, 59, [ 319, 47 ] ], [ 319, 47, 70, 39 ] ], [ [ 9, [ 0, 41 ], [ 65, 136, 91, 24 ] ], [ 65, 136, 91, 24 ], [ 31 ] ], [ [ 42, 132, [ 65, 211 ] ], [ 65, 211, 132, 51 ], [ 31 ] ], [ [ [ 338, 339 ], [ 65, 121, 186, 339 ] ], [ 65, 121, 186, 339 ], [ 31 ] ], [ [ 606, 133, 150, [ 65, 121, 133, 150, 676, 895 ] ], [ 65, 121, 133, 896, 676, 897 ], [ [ 31, 5 ] ] ], [ [ 27, [ 0, 45 ], 112, [ 65, 2, 28, 256, 18 ] ], [ 65, 2, 28, 256, 18 ], [ 31 ] ], [ [ 140, [ 65, 62, 677, 898, 282, 125 ] ], [ 65, 62, 677, 80, 282, 125 ], [ [ 0, 4, 5 ] ] ], [ [ 27, [ 0, 134, 66 ], [ 65, 5, 15, 134, 66 ] ], [ 65, 5, 15, 134, 66 ], [ [ 65, 5, 0, 134, 66, 81 ] ] ], [ [ 27, [ 0, 134, 66 ], [ 65, 5, 6, 134, 66 ] ], [ 65, 5, 6, 134, 66 ], [ [ 65, 5, 0, 134, 66, 81 ] ] ], [ [ 151, 8, [ 33, 22 ], [ 65, 3, 36, 1, 33, 22 ] ], [ 65, 3, 36, 1, 33, 22, 33, 22, 14, 39 ], [ 81 ] ], [ [ 131, 8, 159, [ 65, 3, 222, 519 ] ], [ 65, 3, 222, 519 ], [ 31 ] ], [ [ 142, 24, [ 65, 418, 132, 51 ] ], [ 65, 418, 132, 51 ], [ 31 ] ], [ [ 32, [ 17, 16 ], [ 65, 172, 15, 6 ] ], [ 65, 172, 15, 6 ], [ 31 ] ], [ [ 32, [ 17, 16 ], [ 65, 172, 17, 16, 26 ] ], [ 65, 172, 17, 16, 26 ], [ 31 ] ], [ [ 32, [ 17, 16 ], [ 65, 172, 26, 678 ] ], [ 65, 172, 26, 678 ], [ 31 ] ], [ [ 32, [ 65, 172, 29, 15, 26 ] ], [ 65, 172, 29, 15, 26 ], [ 81 ] ], [ [ 32, [ 65, 172, 29, 26 ] ], [ 65, 172, 29, 26 ], [ 81 ] ], [ [ 25, 8, 25, 163, 77, [ 65, 69, 25, 163, 77, 50, 315 ] ], [ 65, 69, 25, 163, 77, 50, 315, 25, 268 ], [ 81 ] ], [ [ 32, [ 0, 321, 41 ], [ 65, 82, 321, 41 ] ], [ 65, 82, 321, 41 ], [ 31 ] ], [ [ 32, [ 0, 161, 41 ], [ 65, 82, 312, 41 ] ], [ 65, 82, 312, 41 ], [ 31 ] ], [ [ 32, [ 0, 143, 41, 72 ], [ 65, 20, 143, 41, 437 ] ], [ 65, 20, 143, 41, 437 ], [ 81 ] ], [ [ 27, [ 85, 83 ], [ 65, 679, 85, 83, 92, 29 ] ], [ 65, 679, 85, 83, 92, 29, 96, 97 ], [ 81 ] ], [ [ 13, 244, [ 680, 238, 57 ] ], [ 680, 238, 57 ], [ 31 ] ], [ [ 114, 40, 153, 93, [ 180, 79, 93, 212, 520, 4 ] ], [ 180, 79, 93, 212, 520, 4 ], [ 81 ] ], [ [ 32, [ 608, 26 ], [ 180, 26, 212, 29, 0 ] ], [ 180, 26, 212, 29, 0, 28, 26 ], [ 31 ] ], [ [ 13, [ 180, 13, 135 ] ], [ 180, 13, 135 ], [ [ 13, 135, 180, 31 ] ] ], [ [ 27, [ 85, 83 ], [ 409, 85, 83, 118 ] ], [ 409, 85, 83, 118, 96, 97 ], [ 81 ] ], [ [ 438, 7, 23, 379, 47, [ 55, 297, 298 ] ], [ 55, 297, 298, 23, 379, 47 ], [ 31 ] ], [ [ 439, 7, 23, 13, 47, [ 55, 297, 298 ] ], [ 55, 297, 298, 23, 13, 47 ], [ 31 ] ], [ [ 46, 7, 23, 210, [ 55, 297, 298 ] ], [ 55, 297, 298 ], [ [ 7, 23, 31 ] ] ], [ [ 9, [ 0, 41 ], [ 3, 380, 2, 358, 23 ] ], [ 55, 380, 2, 358, 23 ], [ 31 ] ], [ [ 25, 8, 0, 279, [ 64, 279, 19 ] ], [ 64, 279, 19 ], [ 31 ] ], [ [ 13, [ 0, 6 ], [ 64, 30, 6 ] ], [ 64, 30, 6 ], [ 31 ] ], [ [ 13, [ 0, 6 ], [ 64, 30, 6, 521, 381 ] ], [ 64, 30, 6, 212, 193, 381 ], [ 31 ] ], [ [ 48, 40, 0, 900 ], 900, [ 31 ] ], [ [ 203, [ 340, 485 ], [ 145, 0, 217 ] ], [ 145, 0, 217 ], [ [ 145, 0, 217, 31 ] ] ], [ [ 203, [ 340, 485 ], [ 145, 0, 217, 19 ] ], [ 145, 0, 217, 19 ], [ [ 145, 0, 217, 31 ] ] ], [ [ 203, [ 340, 485 ], [ 145, 522, 217 ] ], [ 145, 522, 217 ], [ 81 ] ], [ [ 42, 244, [ 145, 239, 73, 7 ] ], [ 145, 239, 73, 7 ], [ 31 ] ], [ [ 129, 269, [ 145, 217, 57, 1, 56, 55 ] ], [ 145, 217, 57, 1, 56, 55 ], [ [ 196, 1, 56, 31 ] ] ], [ [ 257, [ 0, 17, 16, 36 ], [ 213, 17, 16, 7, 43 ] ], [ 213, 17, 16, 7, 43, 19, 246, 258, 16, 36 ], [ 10 ] ], [ [ 48, 40, [ 57, 13, 259 ], 213 ], [ 213, 57, 13, 259 ], [ [ 213, 81, 316, 158 ] ] ], [ [ 257, [ 0, 60, 76, 36 ], [ 213, 60, 76, 7, 43 ] ], [ 213, 60, 76, 7, 43, 246, 258, 16, 36 ], [ 10 ] ], [ [ 0, 25, 50, 78, 144, [ 213, 35 ] ], [ 213, 35 ], [ 81 ] ], [ [ 42, 1, 105, [ 213, 223 ] ], [ 213, 223, 105 ], [ 10, [ 105, 4 ] ], 3 ], [ [ 35, 8, 14, 70, [ 441, 35, 67 ] ], [ 441, 35, 86, 35 ], [ 81 ] ], [ [ 35, 8, 14, [ 6, 99, 107, 84 ], [ 441, 107, 99, 86 ] ], [ 441, 107, 35, 86 ], [ 81 ] ], [ [ 46, 7, 23, 210, 247 ], 247, [ [ 7, 23, 31 ] ] ], [ [ 114, 40, 153, 93, [ 115, 153, 93, 270, 86 ] ], [ 115, 153, 93, 270, 86 ], [ [ 115, 270, 86, 81 ] ] ], [ [ 32, 17, 16, [ 115, 52 ] ], [ 115, 52 ], [ [ 115, 52, 31 ] ] ], [ [ 13, [ 0, 112, 45 ], [ 115, 136, 486 ] ], [ 115, 136, 486 ], [ 31 ] ], [ [ 165, 14, [ 115, 905, 906 ] ], [ 115, 63, 165 ] ], [ [ 48, 40, [ 57, 13, 259 ], [ 115, 63, 22, 259, 524, 684 ] ], [ 115, 63, 22, 259, 524, 684 ], [ [ 115, 63, 22, 259, 31 ] ] ], [ [ 32, 17, 16, [ 115, 26, 86 ] ], [ 115, 26, 86 ], [ 31 ] ], [ [ 48, 61, 154, 907 ], 907, [ 31 ] ], [ [ 48, 908, 115, 909 ], 909, [ 31 ] ], [ [ 42, [ 685, 13 ], 115 ], 115 ], [ [ 122, 8, 14, 311, [ 610, 686, 6, 5 ] ], [ 610, 686, 6, 5 ], [ 31 ] ], [ [ 48, 40, 910, 911 ], 911, [ 31 ] ], [ [ 27, 167, [ 442, 57, 383, 0, 133, 150 ] ], [ 442, 57, 0, 133, 150 ] ], [ [ 27, 167, [ 442, 57, 9, 133, 150 ] ], [ 442, 57, 9, 133, 150 ] ], [ [ 27, 167, [ 442, 57, 526, 1, 133, 150 ] ], [ 442, 57, 526, 1, 133, 150 ] ], [ [ 384, 8, 0, 26, 41, 56, [ 192, 0, 527, 528, 41, 240 ] ], [ 192, 0, 527, 528, 41, 240 ], [ [ 687, 45, 47, 31 ] ] ], [ [ 334, [ 192, 3, 231, 193, 9 ] ], [ 192, 3, 231, 193, 9 ], [ 81 ] ], [ [ 443, 14, [ 133, 150 ], [ 192, 133, 150 ] ], [ 192, 133, 150, 55, 39 ], [ 81 ] ], [ [ 9, [ 202, 9 ], 34 ], [ 202, 9 ], [ 931 ] ], [ [ 32, [ 17, 16 ], [ 202, 529, 177, 530 ] ], [ 202, 529, 177, 530 ], [ 31 ] ], [ [ 9, [ 202, 9, 611, 126, 19 ], 103, 34 ], [ 202, 605, 611, 126, 19 ], [ 10, 931, [ 0, 187, 67 ] ], 6 ], [ [ 9, [ 49, 104 ] ], 104, [ [ 49, 104, 31, 228, 108, 158 ] ] ], [ [ 444, [ 0, 197 ], [ 197, 445, 323, 43 ] ], [ 197, 445, 323, 43 ], [ 31 ] ], [ [ 168, [ 111, 9, 148 ], 19, [ 197, 56 ] ], [ 197, 56, 19, 85, 83, 39 ], [ 81 ] ], [ [ 7, 23, [ 338, 339 ] ], [ 338, 339, 7 ], [ [ 7, 23, 31 ] ] ], [ [ 7, 23, [ 338, 45, 339 ] ], [ 338, 45, 339 ], [ [ 7, 23, 31 ] ] ], [ [ 168, [ 111, 9, 138 ], [ 136, 111, 9 ] ], [ 136, 111, 9, 85, 83, 39 ], [ 81 ] ], [ [ 32, [ 284, 241, 71 ], [ 136, 71 ] ], [ 136, 284, 241, 71, 26, 28, 26 ], [ 81 ] ], [ [ 117, 8, [ 267, 92 ], 136 ], [ 136, 267, 92 ], [ 81 ] ], [ [ 114, 8, 236, [ 136, 236 ] ], [ 136, 236 ], [ 31 ] ], [ [ 13, [ 0, 112, 45 ], [ 136, 0, 486, 86 ] ], [ 136, 218, 912, 86 ], [ 31 ] ], [ [ 913, 23, [ 690, 6 ] ], [ 690, 6, 23 ], [ 31 ] ], [ [ 7, 23, [ 271, 64 ] ], [ 271, 64, 7 ], [ [ 7, 23, 31 ] ] ], [ [ 42, 132, [ 38, 132, 51 ] ], [ 38, 132, 51 ], [ 31 ] ], [ [ 236, 0, [ 38, 0, 47 ] ], [ 38, 0, 47 ], [ [ 260, 0, 4 ] ] ], [ [ 7, 38, [ 38, 24 ] ], [ 38, 24 ], [ [ 38, 24, 31 ] ] ], [ [ 446, 8, 14, 914 ], [ 487, 180, 61, 385, 8 ], [ 612 ] ], [ [ 42, [ 0, 7 ], [ 43, 0, 1 ] ], [ 43, 0, 7 ], [ 31 ] ], [ [ 27, [ 0, 173 ], 43 ], [ 43, 0, 173, 96, 97 ], [ [ 0, 4, 81 ] ] ], [ [ 405, [ 30, 1, 354, 44, 613 ] ], [ 30, 1, 354, 44, 613, 85, 83, 406, 39 ], [ 81 ] ], [ [ 13, [ 0, 15 ], [ 30, 66 ] ], [ 30, 66 ], [ [ 0, 134, 66, 31 ] ] ], [ [ 114, 40, 153, 93, [ 30, 110, 139, 93 ] ], [ 30, 110, 139, 93 ], [ [ 79, 89, 270, 18, 614, 158 ] ] ], [ [ 13, [ 186, 45 ], [ 30, 186, 45 ] ], [ 30, 186, 45 ], [ 31 ] ], [ [ 13, [ 186, 45 ], [ 30, 186, 45, 521, 381 ] ], [ 30, 186, 45, 212, 193, 381 ], [ 31 ] ], [ [ 46, [ 55, 297, 298 ], 1, 127 ], [ 30, 55, 297, 298, 1 ], [ 31 ] ], [ [ 32, 15, 6, [ 30, 15, 6 ] ], [ 30, 15, 6 ], [ 31 ] ], [ [ 13, [ 0, 15 ], [ 30, 15 ] ], [ 30, 15 ], [ 31 ] ], [ [ 13, [ 0, 15 ], [ 30, 15, 521, 381 ] ], [ 30, 15, 212, 193, 381 ], [ 31 ] ], [ [ 13, [ 0, 6 ], [ 30, 6, 387, 693 ] ], [ 30, 6, 387, 693 ], [ 31 ] ], [ [ 32, 17, 16, [ 30, 6, 17, 16, 26 ] ], [ 30, 6, 17, 16, 26 ], [ 31 ] ], [ [ 13, [ 0, 6 ], [ 30, 6 ] ], [ 30, 6 ], [ 31 ] ], [ [ 13, [ 0, 6 ], [ 30, 6, 521, 381 ] ], [ 30, 6, 212, 193, 381 ], [ 31 ] ], [ [ 152, [ 30, 694, 607, 116, 179 ] ], [ 30, 694, 607, 116, 179, 17, 16, 59 ], [ 81 ] ], [ [ 168, [ 111, 9, 695 ], [ 30, 111, 9 ] ], [ 30, 9, 85, 83, 39 ], [ 81 ] ], [ [ 532, 8, 14, 533, 30 ], [ 30, 9, 224 ], [ 31 ] ], [ [ 915, 916 ], 916, [ 31 ] ], [ [ 27, [ 29, 0 ], [ 30, 29, 15 ] ], [ 30, 29, 15, 96, 97 ], [ 31 ] ], [ [ 27, [ 29, 26 ], [ 30, 29, 26 ] ], [ 30, 29, 26, 96, 97 ], [ 31 ] ], [ [ 131, 8, 484, 919 ], 919, [ 31 ] ], [ [ 131, 8, 484, 920 ], 920, [ 31 ] ], [ [ 131, 8, 484, 921 ], 921, [ 31 ] ], [ [ 131, 8, 484, 922 ], 922, [ 31 ] ], [ [ 25, 8, [ 698, 536, 537, 149, 43 ] ], [ 698, 536, 537, 149, 43 ], [ [ 25, 43, 612 ] ] ], [ [ 615, 8, [ 699, 60, 700, 19 ] ], [ 699, 60, 700, 19 ], [ 81 ] ], [ [ 140, [ 211, 1, 197, 248 ] ], [ 211, 1, 197, 248 ], [ 81 ] ], [ [ 13, 132, [ 211, 51 ] ], [ 211, 132, 51 ], [ 31 ] ], [ [ 13, [ 0, 45 ], 36, 71 ], [ 211, 0, 45, 36 ], [ 31 ] ], [ [ 42, [ 0, 296, 280, 51 ], 211 ], [ 211, 0, 296, 280, 51 ], [ 31 ] ], [ [ 140, [ 211, 24, 197, 248 ] ], [ 211, 24, 197, 248 ], [ 81 ] ], [ [ 46, 95, 337, [ 211, 24 ] ], [ 211, 95, 24 ], [ 31 ] ], [ [ 7, 342, 50, 211 ], [ 211, 50 ], [ 11, [ 50, 4 ] ], 3 ], [ [ 151, 8, [ 33, 22 ], [ 6, 33, 22, 37 ], [ 1, 325 ], [ 71, 272, 1 ] ], [ 71, 1, 325, 272, 1, 33, 22, 14, 39 ], [ 81 ] ], [ [ 151, 8, [ 33, 22 ], [ 71, 1, 33, 22 ] ], [ 71, 1, 33, 22, 33, 22, 14, 39 ], [ 81 ] ], [ [ 27, [ 28, 7, 278 ], [ 71, 278, 226 ] ], [ 71, 278, 226 ], [ 81 ] ], [ [ 9, [ 71, 104 ], 34 ], [ 71, 104 ], [ [ 9, 50, 4 ] ] ], [ [ 131, 8, 159, [ 71, 294, 18 ] ], [ 71, 294, 18 ], [ 374 ] ], [ [ 25, 8, [ 71, 166, 77, 6 ] ], [ 71, 166, 77, 6 ], [ [ 166, 77, 6, 4, 81 ] ] ], [ [ 25, 8, [ 71, 166, 77 ] ], [ 71, 166, 77 ], [ [ 166, 77, 4, 81 ] ] ], [ [ 27, 0, 206, [ 71, 0, 206, 174 ] ], [ 71, 0, 206, 174, 19 ], [ [ 206, 174, 4 ] ] ], [ [ 411, 8, [ 71, 0, 125 ] ], [ 71, 0, 125 ], [ [ 113, 234, 0, 125, 81 ] ] ], [ [ 142, 28, 359, 71 ], [ 71, 28, 359 ], [ 31 ] ], [ [ 142, [ 24, 54 ], [ 71, 24, 54 ], 34 ], [ 71, 24, 54, 314 ], [ [ 24, 54, 4 ] ] ], [ [ 32, [ 6, 16 ], [ 71, 17, 16, 26 ] ], [ 71, 17, 16, 26, 28, 26 ], [ 31 ] ], [ [ 42, 1, [ 105, 54 ], 71 ], [ 71, 105, 54 ], [ 10, [ 105, 54, 4 ] ], 3 ], [ [ 42, 1, 105, 71 ], [ 71, 105 ], [ 10, [ 105, 4 ] ], 3 ], [ [ 532, 8, 14, 533, 71 ], [ 71, 9, 224 ], [ 31 ] ], [ [ 411, 8, [ 71, 9, 125 ] ], [ 71, 9, 125 ], [ [ 65, 49, 234, 9, 125, 673 ] ] ], [ [ 27, [ 0, 45 ], [ 189, 388, 18 ], 71 ], [ 71, 189, 388, 18 ], [ 81 ] ], [ [ 117, 8, [ 267, 92 ], [ 71, 21, 0, 4 ] ], [ 71, 267, 92, 21, 0, 4 ], [ 81 ] ], [ [ 131, 8, 281, 926 ], 926, [ 31 ] ], [ [ 168, [ 111, 9, 3 ], [ 111, 23 ] ], [ 23, 85, 83, 39 ], [ 81 ] ], [ [ 129, 106, [ 1, 616, 447 ] ], [ 616, 447, 1 ], [ [ 616, 447, 31 ] ] ], [ [ 0, 25, 75, [ 538, 249 ] ], [ 538, 249 ], [ 31 ] ], [ [ 122, 8, 14, [ 6, 74, 9 ], [ 74, 9, 136, 205 ], 103, 34 ], [ 74, 9, 136, 205 ], [ 11, [ 74, 4 ] ], 3 ], [ [ 122, 8, 14, [ 15, 74, 9 ], [ 65, 15, 136, 448 ] ], [ 120, 65, 15, 136, 448 ], [ 31 ] ], [ [ 9, 146, [ 146, 68, 126 ] ], [ 120, 146, 9, 68, 126 ], [ 931 ], 0 ], [ [ 416, 8, 14, [ 120, 198 ] ], [ 120, 198 ], [ 31 ] ], [ [ 48, 40, 0, [ 0, 9, 261 ], 34 ], [ 120, 0, 9, 261 ], [ 10 ] ], [ [ 48, 929, 281 ], [ 120, 0, 270, 449, 9 ], [ [ 270, 9 ] ] ], [ [ 129, 106, [ 1, 6, 64, 214, 15 ], 34 ], [ 120, 6, 64, 214, 15, 249, 1 ], [ 11 ] ], [ [ 48, 40, 930 ], 930, [ [ 280, 9, 123 ], [ 61, 450, 40 ] ], 2 ], [ [ 122, 8, 14, [ 58, 227 ], [ 113, 9, 58, 18 ] ], [ 120, 113, 9, 58, 74, 18 ], [ 31 ] ], [ [ 262, 14, 9, [ 109, 318 ], [ 120, 109, 318 ] ], [ 120, 9, 109, 318 ], [ 31 ] ], [ [ 122, 8, 14, [ 15, 74, 9 ], [ 2, 6, 15, 263 ], 34 ], [ 120, 3, 15, 9, 5 ], [ [ 360, 4 ], 37, 12, 86 ], 8 ], [ [ 9, 41, [ 160, 41, 162, 1 ] ], [ 120, 3, 160, 41, 162, 1 ], [ [ 360, 4 ], 86 ], 0 ], [ [ 9, [ 2, 36, 214, 931 ], 34 ], [ 120, 3, 36, 214, 9, 123 ], [ 931 ] ], [ [ 9, 41, [ 3, 6, 539 ], 34 ], [ 120, 3, 6, 539 ], [ 11, [ 41, 3, 31 ] ], 3 ], [ [ 9, [ 2, 1, 36, 6, 21, 74 ] ], [ 120, 3, 422, 6, 74, 36, 5 ], [ 31 ] ], [ [ 122, 8, 14, [ 7, 58 ], [ 58, 489, 37 ] ], [ 120, 3, 9, 58, 489, 37 ], [ 31 ] ], [ [ 122, 8, 14, [ 15, 74, 9 ], [ 2, 9, 18 ], 34 ], [ 120, 3, 9, 18 ], [ 11, [ 74, 4 ] ], 2 ], [ [ 9, 41, [ 3, 162, 618 ] ], [ 120, 3, 162, 1 ], [ [ 199, 4 ] ], 0 ], [ [ 9, 41, [ 3, 182, 41, 162, 618 ] ], [ 120, 3, 182, 41, 162, 618 ], [ [ 360, 4 ], 86 ], 0 ], [ [ 9, 41, [ 3, 380, 205, 539 ] ], [ 120, 3, 380, 205, 539 ], [ 31 ] ], [ [ 48, 143, 176, [ 120, 127, 143, 1, 176 ] ], [ 120, 127, 143, 1, 176 ], [ 31 ] ], [ [ 48, 143, 176, 932 ], 932, [ 31 ] ], [ [ 9, 41, [ 326, 199, 41 ] ], [ 120, 326, 41, 21, 199 ], [ [ 199, 4 ], [ 360, 4 ], [ 41, 86 ] ], 6 ], [ [ 48, 40, 933 ], [ 120, 704, 0, 40 ], [ [ 270, 9, 4 ], [ 61, 450, 40 ] ], 2 ], [ [ 48, 40, 934 ], [ 120, 704, 40 ], [ 11, 931, [ 217, 176, 40 ] ], 6 ], [ [ 114, 40, 153, 93, [ 705, 49, 135 ] ], [ 705, 49, 135 ], [ 81 ] ], [ [ 168, [ 111, 9, 66 ], [ 121, 118 ] ], [ 121, 118, 85, 83, 39 ], [ 81 ] ], [ [ 13, 132, [ 121, 51 ] ], [ 121, 132, 51 ], [ 31 ] ], [ [ 168, [ 181, 104 ], [ 121, 104 ] ], [ 121, 104, 85, 83, 39 ], [ [ 121, 181, 104, 81 ] ] ], [ [ 131, 8, 159, [ 121, 294, 18 ] ], [ 121, 294, 18 ], [ 374 ] ], [ [ 42, [ 0, 296, 280, 51 ], 121 ], [ 121, 0, 296, 280, 51 ], [ 31 ] ], [ [ 117, 8, [ 267, 92 ], 121 ], [ 121, 267, 92 ], [ [ 267, 92, 121, 81 ] ] ], [ [ 13, 118, [ 121, 13, 66 ] ], [ 121, 13, 66 ], [ 31 ] ], [ [ 27, [ 13, 418 ], [ 383, 45 ] ], [ 383, 45, 19 ] ], [ [ 152, [ 540, 17, 16, 37, 424 ] ], [ 540, 17, 16, 37, 424, 17, 16, 59 ], [ 31 ] ], [ [ 443, 14, [ 55, 17, 16, 59 ], [ 541, 344, 192 ] ], [ 541, 344, 192, 55, 39 ], [ 81 ] ], [ [ 443, 14, [ 55, 29, 59 ], [ 541, 344, 192, 47 ] ], [ 541, 344, 192, 47, 55, 39 ], [ 81 ] ], [ [ 25, 8, 70, [ 706, 452 ] ], [ 706, 452 ], [ 31 ] ], [ [ 265, [ 70, 1, 361 ], [ 43, 21, 390, 542, 423, 362 ] ], [ 70, 1, 43, 21, 0, 4, 542, 423, 362 ], [ 10 ] ], [ [ 265, [ 70, 1, 361 ], [ 43, 21, 124, 542, 423, 362 ] ], [ 70, 1, 43, 21, 124, 542, 423, 362 ] ], [ [ 46, 7, 23, 210, 70 ], 70, [ [ 7, 23, 31 ] ] ], [ [ 142, 24, [ 543, 707, 24 ] ], [ 543, 707, 24 ], [ 31 ] ], [ [ 265, 198, 937 ], [ 198, 70, 70, 39 ], [ [ 198, 70, 31 ] ] ], [ [ 443, 14, [ 55, 621, 622, 6 ], [ 344, 192, 47 ] ], [ 344, 192, 47, 55, 39 ], [ 81 ] ], [ [ 137, [ 361, 57, 17, 16, 491, 220 ] ], [ 361, 57, 17, 16, 491, 220, 194, 185, 108, 195, 14, 39 ], [ 81 ] ], [ [ 7, 23, 221 ], [ 221, 7 ], [ [ 7, 23, 31 ] ] ], [ [ 334, [ 363, 54, 1 ] ], [ 363, 54, 1, 231, 193, 59, 14, 39 ], [ 81 ] ], [ [ 142, [ 29, 59 ], [ 363, 453, 21, 24, 141 ] ], [ 363, 453, 21, 24, 141 ], [ [ 24, 141 ] ] ], [ [ 547, 314, 84, [ 455, 21, 456 ] ], [ 301, 84, 21, 456 ], [ 31 ] ], [ [ 547, 314, 133, 150, [ 65, 69 ] ], [ 301, 623, 133, 150, 65, 69 ], [ 374 ] ], [ [ 547, 314, 133, 150, 84, [ 5, 21, 456 ] ], [ 301, 623, 133, 150, 84, 5, 21, 456 ], [ 31 ] ], [ [ 547, 314, 133, 150, [ 455, 21, 456 ] ], [ 301, 623, 133, 150, 5, 21, 456 ], [ 31 ] ], [ [ 48, 287, 176, 938 ], [ 287, 187, 176, 227 ], [ 31 ] ], [ [ 114, 364, 40, 153, 93, [ 364, 30, 110, 139, 93 ] ], [ 364, 30, 110, 139, 93 ], [ [ 364, 30, 110, 139, 93, 939 ] ] ], [ [ 615, [ 492, 711, 302 ] ], [ 492, 711, 302 ], [ 31 ] ], [ [ 615, [ 492, 252, 302 ] ], [ 492, 252, 302 ], [ 31 ] ], [ [ 42, [ 1, 0, 134 ], [ 1, 15, 134, 66, 392 ] ], [ 2, 1, 15, 134, 66, 392 ], [ 31 ] ], [ [ 137, [ 2, 1, 178, 5, 21, 78 ] ], [ 2, 1, 178, 5, 21, 78, 194, 185, 108, 195, 14, 39 ], [ 81 ] ], [ [ 137, [ 2, 1, 178, 5 ] ], [ 2, 1, 178, 5, 194, 185, 108, 195, 14, 39 ], [ 81 ] ], [ [ 42, 624, [ 2, 625 ] ], [ 2, 1, 23, 624, 625 ], [ 11 ], 0 ], [ [ 265, [ 68, 52 ], [ 70, 713 ] ], [ 2, 1, 70, 713 ], [ 31 ] ], [ [ 42, 1, 41, [ 2, 1, 714, 715, 41 ] ], [ 2, 1, 714, 715, 41 ], [ 31 ] ], [ [ 129, 106, 940 ], 940, [ 31 ] ], [ [ 129, 106, [ 2, 1, 170, 327 ] ], [ 2, 1, 170, 327 ], [ 31 ] ], [ [ 42, 716, 626, [ 24, 5 ] ], [ 2, 1, 24, 36, 5 ], [ 31 ] ], [ [ 42, 716, 626, [ 1, 24, 5 ] ], [ 2, 1, 24, 44, 626, 239 ], [ 31 ] ], [ [ 42, 717, 127, [ 2, 1, 24, 5 ] ], [ 2, 1, 24, 44, 6, 107, 127 ], [ 31 ] ], [ [ 265, [ 24, 260, 1 ], [ 2, 712, 21, 941 ] ], [ 2, 1, 4, 21, 24, 4 ], [ 31 ] ], [ [ 42, [ 685, 13 ], [ 2, 1, 18 ] ], [ 2, 1, 18 ], [ 11 ] ], [ [ 32, 209, [ 2, 1, 123, 207, 16, 128, 5 ] ], [ 2, 1, 123, 207, 16, 128, 5, 19, 28, 26 ], [ 31 ] ], [ [ 46, 87, 303, [ 1, 303 ] ], [ 2, 1, 303 ], [ [ 303, 31 ] ] ], [ [ 42, 493, [ 328, 549 ], 34 ], [ 2, 1, 493, 328, 549 ], [ 11 ] ], [ [ 129, 106, [ 1, 2, 1, 327 ] ], [ 2, 1, 327, 1 ], [ 31 ] ], [ [ 13, 132, [ 1, 550, 51, 47 ] ], [ 2, 1, 550, 132, 51, 47 ], [ 11 ], 0 ], [ [ 494, [ 70, 59 ], 249, [ 2, 457, 43, 21, 6 ] ], [ 2, 457, 43, 21, 6, 495, 496 ], [ 81 ] ], [ [ 7, [ 30, 7 ], [ 2, 7, 38, 5 ] ], [ 2, 7, 38, 5 ], [ [ 7, 38, 5, 3 ], 37, 12 ], 4 ], [ [ 42, [ 7, 43 ], 43 ], [ 2, 7, 43 ], [ 31 ] ], [ [ 46, 497, 498, 942 ], [ 2, 7, 170, 393, 718, 43 ], [ 31 ] ], [ [ 46, 497, 498, 943 ], [ 2, 7, 170, 393, 718, 5 ], [ 31 ] ], [ [ 42, 717, 127, [ 2, 7, 5 ] ], [ 2, 7, 44, 6, 107, 127 ], [ 31 ] ], [ [ 42, [ 7, 38 ], [ 2, 7, 44, 38 ] ], [ 2, 7, 5, 44, 38 ], [ [ 7, 38, 5, 3 ], 37, 12 ], 4 ], [ [ 131, 8, 281, 944 ], 944, [ 31 ] ], [ [ 27, [ 85, 83 ], [ 2, 85, 83, 118 ] ], [ 2, 85, 83, 118, 96, 97 ], [ 81 ] ], [ [ 25, 8, [ 2, 165, 110, 149, 43 ] ], [ 2, 165, 110, 149, 43 ], [ 10 ], 0 ], [ [ 165, 23 ], [ 2, 165, 23 ] ], [ [ 114, 40, 153, 176, 945 ], [ 2, 79, 89, 72, 176, 5 ], [ 31 ] ], [ [ 137, [ 2, 110, 1, 178, 5, 139, 551 ] ], [ 2, 110, 1, 178, 5, 21, 139, 551 ], [ 81 ] ], [ [ 35, 8, 14, [ 61, 209 ], [ 2, 164, 722, 61, 209 ] ], [ 2, 164, 722, 61, 209 ] ], [ [ 0, 25, [ 2, 68, 378, 6, 25, 18 ] ], [ 2, 68, 378, 6, 25, 18 ], [ 31 ] ], [ [ 27, [ 0, 134, 66 ], [ 2, 68, 74, 5, 44, 1 ] ], [ 2, 68, 74, 5, 44, 1, 19 ], [ 31 ] ], [ [ 0, 15, 161, [ 68, 6, 5 ] ], [ 2, 68, 6, 21, 37 ], [ 101, [ 37, 31 ] ], 3 ], [ [ 168, [ 111, 9, 130, 78 ], [ 2, 111, 9, 0, 4, 5, 19 ] ], [ 2, 111, 9, 0, 4, 5, 19, 85, 83, 39 ], [ 31 ] ], [ [ 324, 8, 14, [ 283, 52 ], [ 2, 52, 283, 305 ] ], [ 2, 52, 283, 305, 139, 14 ], [ [ 395, 3, 52, 283, 305, 31 ] ] ], [ [ 324, 8, 14, [ 188, 52 ], [ 2, 52, 188, 305 ] ], [ 2, 52, 188, 305, 139, 14 ], [ [ 395, 3, 52, 188, 305, 31 ] ] ], [ [ 117, 8, [ 267, 92 ], [ 2, 92, 18, 86 ] ], [ 2, 92, 18, 86 ], [ 4 ] ], [ [ 117, 8, [ 267, 92 ], [ 2, 92, 18 ] ], [ 2, 92, 18 ], [ 4 ] ], [ [ 131, 8, 281, 946 ], 946, [ [ 724, 123 ] ] ], [ [ 606, 319, 18, [ 2, 319, 18, 84 ] ], [ 2, 319, 18, 84 ] ], [ [ 0, 25, [ 13, 452, 25 ] ], [ 2, 409, 452, 317, 458 ], [ 31 ] ], [ [ 25, 8, [ 13, 452, 25, 19 ] ], [ 2, 409, 452, 317, 458, 19 ], [ 31 ] ], [ [ 117, 8, [ 55, 347 ], [ 2, 55, 546, 21, 4 ] ], [ 2, 55, 546, 21, 4 ], [ 81 ] ], [ [ 117, 8, [ 55, 347 ], [ 2, 55, 347, 21, 4 ] ], [ 2, 55, 347, 21, 4 ], [ 81 ] ], [ [ 42, 7, 340, [ 1, 0, 340 ] ], [ 2, 207, 1, 340, 0, 300 ], [ 31 ] ], [ [ 13, [ 2, 207, 450, 135, 21, 124 ] ], [ 2, 207, 450, 135, 21, 124 ], [ [ 207, 450, 948, 31 ] ] ], [ [ 32, [ 459, 26, 72 ], [ 2, 21, 390 ] ], [ 2, 21, 0, 4, 28, 26 ], [ 31 ] ], [ [ 13, 132, [ 1, 51 ] ], [ 2, 132, 51, 21, 1, 4 ], [ 11 ], 0 ], [ [ 416, 8, 14, [ 2, 58, 417, 518, 252 ] ], [ 2, 58, 417, 518, 336, 252 ], [ [ 949, 9, 58, 31 ] ] ], [ [ 32, [ 0, 161, 41 ], [ 2, 73, 0, 147, 18 ] ], [ 2, 73, 0, 147, 18 ], [ 31 ] ], [ [ 137, [ 3, 349 ], [ 2, 461, 0, 4 ] ], [ 2, 461, 0 ], [ 81 ] ], [ [ 25, 8, 25, 104, [ 2, 104, 23 ] ], [ 2, 104, 23, 25, 268 ], [ 81 ] ], [ [ 25, 8, 25, 104, [ 2, 104, 23, 728 ] ], [ 2, 104, 23, 419, 25, 268 ], [ 81 ] ], [ [ 9, 41, [ 2, 41, 1, 5 ] ], [ 2, 41, 1, 5 ], [ 31 ] ], [ [ 7, [ 30, 335, 1 ], [ 2, 197, 74, 5, 44, 1 ] ], [ 2, 197, 74, 5, 44, 1 ], [ [ 197, 74, 3 ], 37, 12 ], 4 ], [ [ 444, [ 0, 197 ], [ 2, 197, 445, 323 ] ], [ 2, 197, 445, 323 ], [ 31 ] ], [ [ 7, [ 7, 5 ], [ 15, 350 ] ], [ 2, 15, 350 ], [ 31 ] ], [ [ 32, [ 15, 6 ], [ 2, 15, 134, 66, 5 ] ], [ 2, 15, 134, 66, 5 ], [ 31 ] ], [ [ 32, 15, 6, [ 2, 15, 6, 52, 5 ] ], [ 2, 15, 6, 52, 5 ], [ 31 ] ], [ [ 32, [ 15, 6 ], [ 2, 15, 6, 5, 43, 212, 123, 26 ] ], [ 2, 15, 6, 5, 43, 212, 123, 26 ], [ 31 ] ], [ [ 32, [ 15, 6 ], [ 2, 15, 6, 5 ] ], [ 2, 15, 6, 5 ], [ 31 ] ], [ [ 25, 8, [ 2, 15, 553, 110, 149, 43 ] ], [ 2, 15, 553, 110, 149, 43 ], [ 10 ], 0 ], [ [ 27, [ 0, 15 ], [ 2, 15, 157, 256, 18 ] ], [ 2, 15, 157, 256, 18, 19 ], [ 31 ] ], [ [ 0, 25, [ 2, 729, 21, 4 ] ], [ 2, 729, 18, 21, 4 ], [ 4 ] ], [ [ 9, [ 0, 41 ], [ 2, 136, 205, 91, 41, 201 ] ], [ 2, 136, 205, 91, 41, 201 ], [ [ 500, 4 ] ] ], [ [ 13, [ 7, 38, 51 ] ], [ 2, 38, 7, 51 ] ], [ [ 7, 38, [ 6, 64 ] ], [ 2, 38, 6, 64, 7, 23, 228, 108, 158 ], [ [ 38, 7, 31 ] ] ], [ [ 7, 38, [ 60, 425, 76 ] ], [ 2, 38, 60, 425, 7, 23, 228, 108, 158 ], [ [ 38, 7, 31 ] ] ], [ [ 446, 8, 14, 951 ], [ 2, 487, 0, 501, 31, 61, 385, 8 ], [ 612 ] ], [ [ 446, 8, 14, 952 ], [ 2, 487, 0, 501, 61, 385, 8 ], [ 612 ] ], [ [ 494, [ 70, 59 ], 36, [ 2, 627, 44, 251 ] ], [ 2, 627, 953, 251, 495, 496 ], [ 81 ] ], [ [ 32, [ 17, 16 ], [ 2, 30, 26, 731, 18 ] ], [ 2, 30, 26, 731, 18 ], [ 31 ] ], [ [ 137, [ 0, 41, 285, 84 ], [ 2, 146, 251, 126 ] ], [ 2, 146, 251, 126, 194, 185, 108, 195, 14, 39 ], [ [ 0, 251, 285, 84, 81 ] ] ], [ [ 152, [ 2, 178, 242, 16, 24, 5, 19 ] ], [ 2, 178, 242, 16, 275, 5, 19, 17, 16, 59 ], [ 31 ] ], [ [ 32, [ 0, 161, 41 ], [ 2, 160, 161, 72 ] ], [ 2, 160, 161, 72 ], [ 31 ] ], [ [ 27, [ 0, 143, 160, 72 ], [ 2, 160, 143, 72 ] ], [ 2, 160, 143, 72 ], [ 81 ] ], [ [ 32, 15, 6, [ 2, 134, 66, 52, 5 ] ], [ 2, 134, 66, 52, 5 ], [ 31 ] ], [ [ 27, [ 0, 462 ], [ 2, 462 ] ], [ 2, 462, 96, 97 ], [ 31 ] ], [ [ 27, [ 628, 187 ], [ 2, 628, 187, 29, 26 ] ], [ 2, 628, 187, 29, 26 ], [ 31 ] ], [ [ 48, 61, 154, [ 2, 154, 80 ] ], [ 2, 154, 80 ], [ 10 ] ], [ [ 48, 61, 154, [ 2, 154, 373, 734 ] ], [ 2, 154, 373, 734 ], [ 10 ] ], [ [ 265, [ 70, 1, 361 ], [ 2, 1, 361, 18 ] ], [ 2, 70, 1, 361, 18 ], [ 31 ] ], [ [ 25, 8, 70, [ 2, 70, 18 ] ], [ 2, 70, 18 ], [ 31 ] ], [ [ 42, 24, 321, 5 ], [ 2, 321, 24 ], [ 31 ] ], [ [ 265, 198, 956 ], [ 2, 198, 70, 252, 70, 39 ], [ 31 ] ], [ [ 416, 8, 14, [ 2, 198, 555 ] ], [ 2, 198, 555 ], [ 31 ] ], [ [ 25, 8, [ 2, 166, 77, 164, 6 ] ], [ 2, 166, 77, 164, 6 ], [ [ 166, 77, 4, 81 ] ] ], [ [ 25, 8, [ 2, 166, 77, 6, 5 ] ], [ 2, 166, 77, 6, 5 ], [ [ 0, 4, 81 ] ] ], [ [ 25, 8, [ 2, 166, 77, 5 ] ], [ 2, 166, 77, 5 ], [ [ 166, 77, 6, 4, 81 ] ] ], [ [ 365, 8, 957, 252, [ 2, 460, 625, 21, 67 ], 34 ], [ 2, 460, 21, 67 ], [ [ 460, 67 ] ] ], [ [ 203, 306, [ 2, 460, 556, 252 ] ], [ 2, 460, 556, 252 ], [ [ 351, 958, 31 ] ] ], [ [ 9, 87, 959, 34 ], 959, [ 931 ] ], [ [ 27, [ 0, 45 ], 112, [ 2, 357, 30, 0, 220 ] ], [ 2, 357, 30, 246, 960, 220 ], [ 10 ] ], [ [ 114, 40, 153, 176, 961 ], 961, [ 31 ] ], [ [ 42, [ 17, 16, 76 ], [ 2, 170, 41, 549 ] ], [ 2, 170, 41, 549 ], [ 31 ] ], [ [ 48, 287, 176, 964 ], 964, [ 31 ] ], [ [ 438, 7, 23, [ 558, 210 ] ], [ 2, 558, 23, 210 ], [ [ 7, 23, 31 ] ] ], [ [ 438, 7, 23, [ 558, 24 ] ], [ 2, 558, 23, 24 ], [ [ 7, 23, 31 ] ] ], [ [ 324, 8, 14, [ 2, 0, 92, 201 ] ], [ 2, 0, 92, 201 ], [ [ 3, 0, 92, 31 ] ] ], [ [ 27, [ 0, 173 ], [ 2, 21, 0, 4 ] ], [ 2, 0, 173, 5, 21, 0, 4, 96, 97 ], [ [ 0, 4, 81 ] ] ], [ [ 7, [ 7, 5 ], [ 2, 0, 73, 350 ] ], [ 2, 0, 73, 350 ], [ 31 ] ], [ [ 48, 40, 53, [ 2, 0, 295, 53, 78 ] ], [ 2, 0, 295, 53, 78 ], [ 31 ] ], [ [ 25, 8, 0, 279, [ 2, 0, 279, 23, 19 ] ], [ 2, 0, 279, 23, 19 ], [ 31 ] ], [ [ 255, [ 2, 0, 171, 329, 43, 19 ] ], [ 2, 0, 171, 329, 43, 28, 171 ], [ 31 ] ], [ [ 630, 965, [ 2, 24, 23 ] ], [ 2, 0, 24, 23 ], [ 31 ] ], [ [ 630, 738, [ 2, 0, 24, 397, 56, 5 ] ], [ 2, 0, 24, 397, 56, 5 ], [ 31 ] ], [ [ 630, 738, [ 2, 0, 24, 397, 56 ] ], [ 2, 0, 24, 397, 56 ], [ 31 ] ], [ [ 175, [ 28, 36 ], [ 2, 0, 45, 36, 57 ] ], [ 2, 0, 45, 36, 57, 19, 28, 36 ], [ 31 ] ], [ [ 7, 0, [ 2, 0, 222, 1, 18 ] ], [ 2, 0, 222, 1, 18 ], [ 31 ] ], [ [ 42, 313, [ 2, 0, 313, 1, 47 ] ], [ 2, 0, 313, 1, 47 ], [ [ 0, 313, 1, 47, 31 ] ] ], [ [ 42, 313, [ 2, 0, 313, 1, 4 ] ], [ 2, 0, 313, 1, 4 ], [ [ 0, 313, 1, 47, 31 ] ] ], [ [ 257, [ 28, 288, 187, 1 ], [ 2, 0, 288, 187, 1, 5, 19 ] ], [ 2, 0, 288, 187, 1, 5, 19, 246, 258, 16, 36 ], [ 31 ] ], [ [ 32, [ 0, 161, 41 ], [ 2, 0, 147, 18 ] ], [ 2, 0, 147, 18 ], [ 31 ] ], [ [ 117, 8, [ 0, 276, 188 ], [ 2, 0, 276, 188, 21, 10 ] ], [ 2, 0, 276, 188, 21, 0, 4 ], [ 81 ] ], [ [ 411, 8, [ 2, 0, 125, 5 ] ], [ 2, 0, 125, 5 ], [ [ 9, 125, 0, 4, 81 ] ] ], [ [ 117, 8, [ 0, 107, 1 ], [ 2, 0, 107, 1, 21, 4 ] ], [ 2, 0, 107, 1, 21, 4 ], [ 81 ] ], [ [ 140, [ 2, 28, 248, 5 ] ], [ 2, 28, 248, 21, 0, 4 ], [ 81 ] ], [ [ 142, [ 24, 54 ], 5 ], [ 2, 24, 967, 314 ], [ 3 ] ], [ [ 286, 8, 14, 559, [ 2, 6, 1, 222, 263 ] ], [ 2, 6, 1, 222, 263, 9, 58 ], [ [ 3, 222, 9, 5, 374 ] ] ], [ [ 7, [ 30, 7 ], [ 2, 6, 7, 197, 74, 5 ] ], [ 2, 6, 7, 197, 74, 5 ], [ 3 ] ], [ [ 129, 106, [ 1, 6, 64, 41, 5 ], 34 ], [ 2, 6, 64, 41, 5, 1 ], [ 11, 37, 12 ], 4 ], [ [ 129, 106, [ 1, 6, 64, 632, 5 ], 34 ], [ 2, 6, 64, 632, 5, 1 ], [ 11, 37, 12 ], 4 ], [ [ 129, 106, [ 1, 6, 64, 130, 328 ], 34 ], [ 2, 6, 64, 130, 328, 5, 1 ], [ 11, 37, 12 ], 4 ], [ [ 365, 8, 743, 14, [ 2, 6, 348, 320 ] ], [ 2, 6, 348, 320, 365 ], [ [ 6, 348, 320, 81 ] ] ], [ [ 365, 8, 743, 14, [ 2, 6, 348, 968 ] ], [ 2, 6, 348, 5, 365 ], [ [ 6, 348, 320, 81 ] ] ], [ [ 42, 1, 41, [ 161, 41, 98 ] ], [ 2, 6, 161, 41, 98 ], [ 31 ] ], [ [ 32, [ 28, 6, 254, 26 ], 19, [ 2, 6, 254, 633, 47 ] ], [ 2, 6, 254, 633, 47, 28, 26 ], [ 31 ] ], [ [ 32, [ 17, 16 ], [ 3, 6, 745, 18 ] ], [ 2, 6, 745, 18 ], [ 31 ] ], [ [ 0, 25, [ 2, 6, 17, 16, 18, 21, 4 ] ], [ 2, 6, 17, 16, 18, 21, 4 ], [ 11 ] ], [ [ 32, 17, 16, [ 2, 17, 16, 26, 52, 5 ] ], [ 2, 6, 17, 16, 26, 52, 5 ], [ 31 ] ], [ [ 25, 8, [ 2, 6, 553, 110, 149, 43 ] ], [ 2, 6, 553, 110, 149, 43 ], [ 10 ], 0 ], [ [ 27, [ 0, 45 ], 112, [ 2, 6, 5, 139, 15, 6, 37 ] ], [ 2, 6, 5, 614, 139, 15, 6, 37, 19 ], [ 31 ] ], [ [ 27, [ 0, 45 ], 112, [ 2, 6, 5, 139, 15, 6 ] ], [ 2, 6, 5, 21, 139, 15, 6, 19 ], [ 31 ] ], [ [ 117, 8, [ 0, 107 ], [ 6, 29, 47, 21, 0 ] ], [ 2, 6, 29, 47, 21, 970 ], [ 81 ] ], [ [ 32, [ 6, 29 ], [ 2, 6, 29, 435 ] ], [ 2, 6, 29, 435 ], [ 31 ] ], [ [ 203, [ 635, 47 ], [ 2, 6, 67 ] ], [ 2, 6, 67 ], [ 10 ] ], [ [ 131, 8, 159, [ 2, 17, 333, 256, 18 ] ], [ 2, 17, 333, 256, 18 ], [ [ 514, 229 ] ] ], [ [ 131, 8, 159, [ 2, 17, 333, 159, 514, 229 ] ], [ 2, 17, 333, 159, 514, 229 ], [ 31 ] ], [ [ 46, 7, 23, 210, [ 17, 16, 73 ] ], [ 2, 17, 16, 73, 210 ], [ [ 7, 23, 31 ] ] ], [ [ 46, 7, 23, 210, [ 17, 16, 76 ] ], [ 2, 17, 16, 210 ], [ [ 7, 23, 31 ] ] ], [ [ 257, [ 0, 17, 16, 36 ], [ 3, 17, 16, 5, 307 ] ], [ 2, 17, 16, 5, 307, 246, 258, 16, 36 ], [ 31 ] ], [ [ 42, 1, 746, 5 ], [ 2, 242, 24 ], [ 31 ] ], [ [ 25, 8, 25, [ 25, 89 ], [ 2, 25, 89, 174 ] ], [ 2, 25, 89, 174 ], [ 81 ] ], [ [ 25, 8, 25, 163, 77, [ 2, 25, 163, 77, 50, 5 ] ], [ 2, 25, 163, 77, 50, 5, 25, 268 ], [ 81 ] ], [ [ 42, [ 7, 43 ], [ 157, 6, 55, 1, 43 ] ], [ 2, 157, 6, 55, 1, 43 ], [ 31 ] ], [ [ 7, [ 7, 5 ], [ 157, 6, 55, 36 ] ], [ 2, 157, 6, 55, 350 ], [ 31 ] ], [ [ 32, [ 0, 161, 41 ], [ 2, 312, 41, 5 ] ], [ 2, 312, 41, 5 ], [ 31 ] ], [ [ 32, [ 0, 161, 41 ], [ 2, 312, 41, 5, 19 ] ], [ 2, 312, 41, 5, 19 ], [ 31 ] ], [ [ 32, [ 17, 16 ], [ 2, 63, 427, 0, 17, 16, 26 ] ], [ 2, 63, 427, 0, 17, 16, 26, 21, 0, 141 ], [ 31 ] ], [ [ 117, 8, [ 0, 107, 1 ], [ 2, 219, 0, 107, 1 ] ], [ 2, 219, 0, 107, 1 ], [ 81 ] ], [ [ 32, [ 17, 243, 418 ], 563 ], [ 2, 563, 44, 6, 16 ], [ [ 37, 31 ] ] ], [ [ 32, [ 17, 243, 418 ], [ 563, 19 ] ], [ 2, 563, 44, 6, 16, 19 ], [ [ 37, 31 ] ] ], [ [ 331, [ 87, 73 ], 303, [ 1, 303 ] ], [ 2, 87, 73, 1, 303 ], [ [ 303, 31 ] ] ], [ [ 410, 8, 14, 559, [ 2, 6, 1, 222, 263 ] ], [ 2, 87, 254, 1, 222, 263, 9, 58 ], [ [ 3, 222, 9, 5, 374 ] ] ], [ [ 331, 303, [ 1, 303 ] ], [ 2, 87, 76, 1, 303 ], [ [ 303, 31 ] ] ], [ [ 42, 1, 105, [ 2, 21, 4 ] ], [ 2, 105, 21, 4 ], [ 10, [ 105, 4 ] ], 3 ], [ [ 25, 8, [ 2, 93, 110, 149, 43 ] ], [ 2, 93, 110, 149, 43 ], [ 10 ], 0 ], [ [ 255, 148, [ 2, 93, 43, 464, 16, 426 ] ], [ 2, 93, 43, 464, 16, 426 ], [ 31 ] ], [ [ 255, [ 2, 93, 139, 0, 47, 19 ] ], [ 2, 93, 139, 0, 627, 47, 19, 28, 171 ], [ 31 ] ], [ [ 42, [ 17, 16, 76 ], [ 2, 250, 170, 1, 5 ] ], [ 2, 250, 170, 1, 5 ], [ [ 2, 250, 170, 1, 31 ] ] ], [ [ 42, [ 60, 425 ], [ 2, 250, 17, 16, 1, 214, 243 ] ], [ 2, 250, 17, 16, 1, 214, 243 ], [ [ 2, 250, 17, 16, 1, 31 ] ] ], [ [ 9, 349, [ 2, 250, 9, 5 ] ], [ 2, 250, 502, 9, 5 ], [ 31 ] ], [ [ 129, 106, [ 1, 250, 328, 47 ], 34 ], [ 2, 250, 328, 1 ], [ 11, [ 37, 31 ] ], 3 ], [ [ 203, [ 635, 47 ], [ 33, 260, 7 ] ], [ 2, 57, 7, 18 ], [ [ 635, 1, 33, 31 ] ] ], [ [ 137, [ 2, 57, 17, 16, 147, 252 ] ], [ 2, 57, 17, 16, 147, 252, 194, 185, 108, 195, 14, 39 ], [ 81 ] ], [ [ 9, [ 57, 13 ], 259, 261 ], [ 2, 57, 13, 748, 749, 261 ], [ 31 ] ], [ [ 286, 8, 14, 559, [ 2, 284, 1, 253, 23 ] ], [ 2, 284, 1, 253, 23, 9, 58 ], [ [ 3, 222, 9, 5, 374 ] ] ], [ [ 9, 6, [ 2, 60, 6, 327 ] ], [ 2, 60, 6, 327 ], [ [ 60, 6, 327, 31 ] ] ], [ [ 46, 7, 23, 210, [ 60, 6, 76 ] ], [ 2, 60, 6, 76, 210 ], [ [ 7, 23, 31 ] ] ], [ [ 257, [ 0, 60, 76, 36 ], [ 3, 60, 76, 5, 307 ] ], [ 2, 60, 76, 5, 307, 246, 258, 16, 36 ], [ 31 ] ], [ [ 131, 8, 159, [ 2, 9, 294, 18 ] ], [ 2, 9, 294, 18 ], [ 31 ] ], [ [ 286, 8, 14, [ 9, 130, 78 ], [ 2, 9, 0, 4, 5 ] ], [ 2, 9, 0, 4, 5, 9, 58 ], [ 931 ] ], [ [ 262, 14, 9, 109, 57, [ 138, 109 ] ], [ 2, 9, 399, 466 ], [ 374 ] ], [ [ 411, 8, [ 2, 9, 125, 389, 5 ] ], [ 2, 9, 125, 389, 5 ], [ 81 ] ], [ [ 9, 41, [ 2, 199, 41, 227, 202 ] ], [ 2, 199, 41, 227, 44, 202 ], [ 31 ] ], [ [ 9, 41, [ 2, 199, 41, 227 ] ], [ 2, 199, 41, 227 ], [ 31 ] ], [ [ 9, 41, [ 2, 199, 564, 19 ] ], [ 2, 199, 564, 19 ], [ 31 ] ], [ [ 9, 41, [ 2, 199, 754, 564 ] ], [ 2, 199, 754, 564 ], [ 31 ] ], [ [ 32, [ 0, 161, 41 ], [ 2, 243, 0, 17, 0, 5 ] ], [ 2, 243, 0, 17, 0, 5 ], [ 31 ] ], [ [ 168, [ 1, 148 ], [ 2, 243, 0, 4 ] ], [ 2, 243, 0, 4, 19, 85, 83, 39 ], [ 81 ] ], [ [ 42, 755, 979 ], 979, [ 31 ] ], [ [ 257, [ 0, 17, 16, 36 ], [ 3, 467, 17, 16, 5, 307 ] ], [ 2, 467, 17, 16, 5, 307, 246, 258, 16, 36 ], [ 31 ] ], [ [ 257, [ 0, 60, 76, 36 ], [ 3, 467, 60, 76, 5, 307 ] ], [ 2, 467, 60, 76, 5, 307, 246, 258, 16, 36 ], [ 31 ] ], [ [ 13, [ 756, 757, 7 ] ], [ 2, 756, 757, 7 ], [ [ 1, 67 ], [ 631, 67 ] ], 2 ], [ [ 9, 349, [ 502, 225 ] ], [ 2, 502, 225 ], [ 31 ] ], [ [ 9, 349, [ 2, 502, 328, 23 ] ], [ 2, 502, 328, 23 ], [ 31 ] ], [ [ 129, 269, [ 196, 1, 56, 200, 183, 23 ] ], [ 2, 196, 1, 56, 200, 183, 23 ], [ 31 ] ], [ [ 129, 269, [ 196, 1, 56, 200, 183, 5 ] ], [ 2, 196, 1, 56, 200, 183, 5 ], [ 31 ] ], [ [ 129, 269, [ 196, 1, 56, 200, 183, 56 ] ], [ 2, 196, 1, 56, 200, 183, 56 ], [ 31 ] ], [ [ 129, 269, [ 196, 239, 110, 332, 1, 200, 183, 56 ] ], [ 2, 196, 239, 1, 110, 332, 1, 200, 183, 56 ], [ 31 ] ], [ [ 129, 269, [ 196, 239, 1, 170, 56, 200, 183, 23 ] ], [ 2, 196, 239, 1, 170, 56, 200, 183, 23 ], [ 31 ] ], [ [ 129, 269, [ 196, 239, 332, 1, 200, 183, 56 ] ], [ 2, 196, 239, 1, 332, 1, 200, 183, 56 ], [ 31 ] ], [ [ 27, 0, 189, 128, [ 2, 189, 128, 5 ] ], [ 2, 189, 128, 5 ], [ 31 ] ], [ [ 25, 8, [ 2, 288, 77, 5 ] ], [ 2, 288, 77, 5 ], [ [ 0, 4, 81 ] ] ], [ [ 114, 79, 277, 9, 981 ], 981, [ 31 ] ], [ [ 48, 40, 517, 126, 982 ], 982, [ 31 ] ], [ [ 48, 40, 517, 126, 983 ], 983, [ 31 ] ], [ [ 114, 79, 277, 9, 984 ], 984, [ 31 ] ], [ [ 48, 40, 517, 126, 985 ], [ 2, 277, 282, 221, 126, 426 ], [ 31 ] ], [ [ 25, 8, 147, 1 ], [ 2, 147, 1, 18 ], [ 31 ] ], [ [ 25, 8, [ 321, 24 ] ], [ 2, 147, 321, 24 ], [ 31 ] ], [ [ 25, 8, 147, 0 ], [ 2, 147, 0, 18 ], [ 31 ] ], [ [ 137, 8, [ 78, 986, 197 ], [ 2, 147, 0, 18, 19 ] ], [ 2, 147, 0, 18, 19, 194, 185, 108, 195, 14, 39 ], [ 31 ] ], [ [ 25, 8, 147, 0, 468 ], [ 2, 147, 0, 468, 18 ], [ 81 ] ], [ [ 27, [ 0, 462 ], [ 2, 179 ] ], [ 2, 179, 96, 97 ], [ 31 ] ], [ [ 175, [ 13, 36 ], [ 638, 758 ], 5 ], [ 2, 638, 36, 5, 28, 36 ], [ [ 3, 13, 638, 758, 81 ] ] ], [ [ 606, 133, 150, [ 2, 133, 150, 5 ] ], [ 2, 133, 150, 5 ], [ 31 ] ], [ [ 168, 126, 84 ], [ 2, 126, 84, 85, 83, 39 ], [ 31 ] ], [ [ 9, [ 2, 126, 23, 21, 9 ] ], [ 2, 126, 23, 21, 9 ], [ [ 126, 23, 31 ] ] ], [ [ 255, [ 2, 375, 139, 0, 47, 19 ] ], [ 2, 375, 139, 0, 47, 19, 28, 171 ], [ 31 ] ], [ [ 117, 8, [ 267, 92 ], [ 2, 395, 0 ] ], [ 2, 395, 0 ], [ 10 ] ], [ [ 32, 209, [ 2, 16, 128, 43 ] ], [ 2, 16, 128, 43, 19, 28, 26 ], [ 31 ] ], [ [ 9, 41, [ 2, 91, 41, 201 ] ], [ 2, 91, 41, 201 ], [ [ 336, 500, 4 ] ] ], [ [ 27, [ 0, 282 ], 148, [ 2, 282, 45, 21, 4 ] ], [ 2, 282, 45, 21, 4, 19 ], [ 31 ] ], [ [ 566, 8, 640, 7, [ 2, 761, 174, 18 ] ], [ 2, 130, 174, 18 ], [ 11 ] ], [ [ 566, 8, 640, 7, [ 2, 761, 174, 252, 18, 19 ] ], [ 2, 130, 174, 252, 18, 19 ], [ 81 ] ], [ [ 142, 24, 130, [ 2, 130 ] ], [ 2, 130, 18 ], [ 31 ] ], [ [ 7, 7, [ 468, 23, 18 ] ], [ 2, 468, 7, 23 ], [ 11 ], 0 ], [ [ 7, 7, [ 468, 18 ] ], [ 2, 468, 7 ], [ 11 ], 0 ], [ [ 376, 36, [ 2, 451, 169, 26, 78, 18 ] ], [ 2, 451, 169, 26, 78, 18, 29, 59 ], [ 31 ] ], [ [ 27, 112, 282, 0, [ 2, 80, 567, 256 ] ], [ 2, 80, 567, 256 ], [ 81 ] ], [ [ 27, 112, 282, 0, [ 2, 80, 567, 47 ] ], [ 2, 80, 567, 47 ], [ 81 ] ], [ [ 117, 8, [ 0, 107 ], [ 2, 80, 6, 68, 568 ] ], [ 2, 80, 6, 68, 568 ], [ 81 ] ], [ [ 13, [ 696, 209 ], [ 2, 239, 6, 18, 21, 0, 116 ] ], [ 2, 239, 6, 18, 21, 0, 116 ], [ [ 0, 116 ] ] ], [ [ 48, 287, 176, 988 ], 988, [ 31 ] ], [ [ 137, [ 2, 1, 178, 5, 21, 551 ] ], [ 2, 990, 1, 178, 5, 21, 551, 194, 185, 108, 195, 14, 39 ], [ 81 ] ], [ [ 42, 6, [ 2, 155, 73, 0 ] ], [ 2, 155, 73, 0 ], [ 31 ] ], [ [ 131, 8, 281, 991 ], 991 ], [ [ 27, [ 0, 6 ], [ 2, 13, 762, 423, 0 ] ], [ 2, 13, 762, 423, 0, 19 ], [ 31 ] ], [ [ 25, 8, [ 13, 25, 191, 19 ] ], [ 2, 13, 317, 458, 191, 19 ], [ 31 ] ], [ [ 25, 8, [ 13, 25, 191, 307 ] ], [ 2, 13, 317, 458, 191, 307 ], [ 31 ] ], [ [ 48, 40, 89, [ 2, 13, 135, 18 ] ], [ 2, 13, 135, 18 ], [ 31 ] ], [ [ 13, 61, [ 2, 13, 135 ] ], [ 2, 13, 135 ], [ [ 234, 61, 135, 31 ] ] ], [ [ 13, 132, [ 550, 51 ], [ 1, 47 ] ], [ 2, 550, 132, 51, 1, 47 ], [ 1011 ], 0 ], [ [ 117, 8, [ 0, 107 ], [ 2, 107, 205, 43, 19 ] ], [ 2, 107, 205, 43, 19 ], [ 81 ] ], [ [ 117, 8, [ 0, 107 ], [ 2, 107 ] ], [ 2, 107 ], [ 31 ] ], [ [ 13, 92, [ 2, 90, 230, 52, 201 ] ], [ 2, 90, 230, 52, 201 ] ], [ [ 25, 8, 25, 240, [ 2, 385, 220, 240 ] ], [ 2, 385, 220, 240 ], [ 31 ] ], [ [ 131, 8, 159, [ 2, 61, 294, 229 ] ], [ 2, 61, 294, 229 ], [ 374 ] ], [ [ 9, [ 2, 61, 358, 9, 18 ] ], [ 2, 61, 358, 9, 18 ], [ 931 ] ], [ [ 27, 0, 180, 135 ], [ 0, 7, 135, 19 ], [ 31 ] ], [ [ 32, 209, [ 0, 180, 16, 128, 134 ] ], [ 0, 180, 16, 128, 134, 19, 28, 26 ], [ [ 134, 141 ], [ 128, 124 ], 10 ], 7 ], [ [ 32, 209, [ 0, 213, 16, 128 ] ], [ 0, 213, 16, 128, 19, 28, 26 ], [ 31 ] ], [ [ 444, [ 132, 51 ], [ 0, 132, 43 ] ], [ 0, 132, 43 ], [ 31 ] ], [ [ 168, [ 0, 413, 148 ], 669 ], [ 0, 433, 19, 85, 83, 39 ], [ 81 ] ], [ [ 48, 40, 53, [ 0, 295, 53, 78, 86 ] ], [ 0, 295, 53, 78, 86 ], [ 31 ] ], [ [ 117, 8, [ 0, 25, 409 ], 996 ], [ 0, 169, 409, 317, 458 ], [ 81 ] ], [ [ 137, 8, [ 765, 308 ], 3 ], [ 0, 308, 115, 194, 185, 108, 195, 14, 39 ], [ 81 ] ], [ [ 122, 8, 14, [ 366, 58 ], [ 0, 9, 3, 17, 16, 6, 5 ] ], [ 0, 9, 3, 17, 16, 6, 5 ], [ 31 ] ], [ [ 122, 8, 14, [ 366, 58 ], [ 0, 9, 3, 766, 5 ] ], [ 0, 9, 3, 766, 5 ], [ 31 ] ], [ [ 32, [ 17, 0, 161 ], [ 0, 147, 0, 5 ] ], [ 0, 147, 0, 5 ], [ 31 ] ], [ [ 32, [ 17, 0, 161 ], [ 0, 147, 56 ] ], [ 0, 147, 56 ], [ 31 ] ], [ [ 32, [ 17, 0, 161 ], [ 0, 767, 5 ] ], [ 0, 767, 5 ], [ 31 ] ], [ [ 32, 209, [ 0, 82, 16, 128 ] ], [ 0, 82, 16, 128, 19, 28, 26 ], [ 31 ] ], [ [ 25, 8, [ 17, 570, 6 ], 768 ], [ 997, 768 ], [ 31 ] ], [ [ 137, 8, [ 469, 308, 115 ], 3 ], [ 469, 308, 115, 194, 185, 108, 195, 14, 39 ], [ 81 ] ], [ [ 0, 25, 19, 642 ], [ 642, 19 ], [ 31 ] ], [ [ 13, [ 0, 6 ], [ 6, 370, 157 ] ], [ 6, 370, 157 ], [ 31 ] ], [ [ 7, 23, [ 6, 245 ] ], [ 6, 245, 7 ], [ [ 7, 23, 31 ] ] ], [ [ 439, 7, 23, 13, 47, [ 6, 64 ] ], [ 6, 64, 23, 13, 47 ], [ 31 ] ], [ [ 46, 7, 23, 210, [ 6, 64 ] ], [ 6, 64 ], [ [ 7, 23, 31 ] ] ], [ [ 9, 771, [ 6, 136, 126 ] ], [ 6, 136, 126 ], [ [ 6, 136, 126, 31 ] ] ], [ [ 9, [ 0, 41 ], [ 6, 9, 136, 205 ] ], [ 6, 9, 136, 205 ], [ 31 ] ], [ [ 506, 8, [ 60, 25 ], 998, 999 ], 999 ], [ [ 117, 8, [ 0, 107 ], [ 169, 329, 205, 107 ] ], [ 169, 329, 205, 107 ], [ 31 ] ], [ [ 439, 7, 23, 13, 47, [ 17, 16, 73 ] ], [ 17, 16, 73, 23, 13, 47 ], [ 31 ] ], [ [ 137, [ 3, 17, 16, 275, 1, 774, 124 ] ], [ 17, 16, 275, 1, 774, 124, 5, 194, 185, 108, 195, 14, 39 ], [ 81 ] ], [ [ 9, [ 0, 41 ], [ 17, 16, 6, 136, 205 ] ], [ 17, 16, 6, 136, 205 ], [ 31 ] ], [ [ 439, 7, 23, 13, 47, [ 17, 16, 76 ] ], [ 17, 16, 76, 23, 13, 47 ], [ 31 ] ], [ [ 35, 8, 14, [ 309, 50 ], [ 25, 775 ] ], [ 25, 775 ], [ 81 ] ], [ [ 324, 8, 14, [ 283, 52 ], 52 ], [ 283, 52, 21, 395, 139, 14 ], [ [ 395, 61, 283, 776, 52, 31 ] ] ], [ [ 25, 8, [ 777, 451, 89 ] ], [ 777, 451, 89 ], [ [ 89, 81 ] ] ], [ [ 25, 8, [ 778, 536, 537, 149, 43 ] ], [ 778, 536, 537, 149, 43 ], [ [ 25, 43, 612 ] ] ], [ [ 25, 8, 70, [ 489, 70, 18 ] ], [ 489, 70, 18 ], [ 31 ] ], [ [ 32, 104, [ 572, 104 ] ], [ 572, 104 ], [ [ 572, 104, 31 ] ] ], [ [ 46, 7, 23, 210, 216 ], 216, [ [ 7, 23, 31 ] ] ], [ [ 32, [ 0, 356, 26 ], [ 779, 780, 6 ] ], [ 779, 780, 6, 28, 26 ], [ [ 0, 356, 26, 31 ] ] ], [ [ 27, 13, [ 266, 13, 573 ] ], [ 266, 13, 573 ], [ 81 ] ], [ [ 25, 8, 781, 353, 1 ], [ 63, 781, 353, 1 ], [ 31 ] ], [ [ 131, 8, 159, [ 63, 145, 134 ] ], [ 63, 145, 134 ], [ 11, 31 ], 0 ], [ [ 42, 1001, [ 63, 357, 6, 64 ] ], [ 63, 357, 6, 64, 19 ], [ [ 0, 116 ] ], 0 ], [ [ 324, 8, 14, [ 557, 13 ], 1003 ], 1003, [ 124 ] ], [ [ 35, 8, 14, [ 309, 50 ], [ 63, 99, 146, 50, 65 ] ], [ 63, 99, 146, 50, 65 ], [ [ 0, 141 ] ] ], [ [ 35, 8, 14, [ 309, 50 ], [ 63, 99, 0, 0, 65 ] ], [ 63, 99, 0, 0, 65 ], [ [ 65, 81 ] ] ], [ [ 35, 8, 14, [ 309, 50 ], [ 63, 99, 0, 0 ] ], [ 63, 99, 0, 0 ], [ 81 ] ], [ [ 35, 8, 14, [ 309, 50 ], [ 63, 99, 471, 50, 65 ] ], [ 63, 99, 471, 50, 65 ], [ [ 0, 141 ] ] ], [ [ 35, 8, 14, [ 184, 75 ], [ 63, 35, 21, 575, 6, 141 ] ], [ 63, 35, 21, 575, 6, 4 ], [ 81 ] ], [ [ 35, 8, 14, [ 55, 75 ], [ 63, 35, 575 ] ], [ 63, 35, 575 ], [ 81 ] ], [ [ 7, 342, 50, 787 ], [ 787, 50 ], [ 31 ] ], [ [ 376, 36, [ 62, 145, 473, 577, 125 ] ], [ 62, 145, 473, 577, 125, 29, 59 ], [ 31 ] ], [ [ 257, [ 28, 1, 289 ], [ 62, 789, 86 ] ], [ 62, 789, 86, 246, 258, 16, 36 ], [ 81 ] ], [ [ 32, [ 17, 16 ], [ 62, 790, 17, 16, 26 ] ], [ 62, 790, 17, 16, 26 ], [ 31 ] ], [ [ 168, [ 111, 9, 3 ], [ 62, 300 ] ], [ 62, 300, 85, 83, 39 ], [ 31 ] ], [ [ 137, 8, [ 382, 13 ], [ 62, 382, 13 ] ], [ 62, 382, 13 ] ], [ [ 137, 8, [ 382, 13 ], [ 62, 382, 13, 419 ] ], [ 62, 382, 13, 419 ] ], [ [ 137, [ 62, 57, 30, 6, 0, 145, 578 ] ], [ 62, 57, 30, 6, 0, 145, 578, 194, 185, 108, 195, 14, 39 ], [ 81 ] ], [ [ 137, [ 62, 57, 17, 16, 2, 107 ] ], [ 62, 57, 17, 16, 2, 107, 194, 185, 108, 195, 14, 39 ], [ 81 ] ], [ [ 27, 338, [ 62, 57, 13 ] ], [ 62, 57, 13 ] ], [ [ 151, 8, [ 33, 22 ], [ 33, 22, 37 ], [ 62, 33, 22, 1, 52 ] ], [ 62, 33, 22, 1, 52, 33, 22, 14, 39 ], [ 81 ] ], [ [ 151, 8, [ 33, 22 ], [ 62, 33, 22, 299, 139, 1, 23, 37 ] ], [ 62, 33, 22, 299, 139, 1, 23, 37, 33, 22, 14, 39 ], [ 81 ] ], [ [ 151, 8, [ 33, 22 ], [ 62, 33, 22, 299 ] ], [ 62, 33, 22, 299, 33, 22, 14, 39 ], [ 81 ] ], [ [ 151, 8, [ 33, 22 ], [ 33, 22, 37 ], [ 62, 33, 22, 340, 299 ] ], [ 62, 33, 22, 340, 299, 33, 22, 14, 39 ], [ 81 ] ], [ [ 32, [ 608, 26 ], [ 62, 26, 579, 390, 164, 390 ] ], [ 62, 26, 579, 0, 4, 164, 0, 4, 28, 26 ], [ 31 ] ], [ [ 25, 8, 25, 104, [ 62, 22, 215 ] ], [ 62, 22, 215, 25, 268 ], [ 81 ] ], [ [ 25, 8, 25, 104, [ 62, 22, 215, 728 ] ], [ 62, 22, 215, 419, 25, 268 ], [ 81 ] ], [ [ 117, 8, 0, [ 62, 80 ] ], [ 62, 80 ], [ 81 ] ], [ [ 27, [ 29, 26 ], [ 62, 29, 15, 63, 275, 793 ] ], [ 62, 29, 15, 63, 275, 793, 96, 97 ], [ 31 ] ], [ [ 137, 8, [ 382, 13 ], [ 62, 13, 580, 540 ] ], [ 62, 13, 580, 540 ] ], [ [ 27, [ 0, 45 ], 112, [ 62, 13, 22, 25 ] ], [ 62, 13, 22, 25, 19 ] ], [ [ 140, [ 581, 164, 582, 474, 23, 116 ] ], [ 581, 164, 582, 474, 23, 116 ], [ 10, 81 ], 3 ], [ [ 140, [ 581, 164, 582, 474, 23 ] ], [ 581, 164, 582, 474, 23 ], [ 81 ] ], [ [ 140, 1009 ], 1009, [ 81 ] ], [ [ 42, 313, [ 219, 6, 1, 21, 0 ] ], [ 219, 6, 1, 21, 0, 4 ], [ 31 ] ], [ [ 42, 87, [ 219, 17 ] ], [ 219, 17 ], [ 11 ] ], [ [ 7, 342, 264, [ 264, 1 ] ], [ 264, 1 ], [ 11, [ 264, 765 ] ], 3 ], [ [ 9, 264, 34 ], 264, [ 931 ] ], [ [ 7, 7, [ 5, 1, 44, 583 ] ], [ 5, 1, 44, 583 ], [ [ 0, 7, 31 ] ] ], [ [ 152, [ 645, 646, 5, 1, 24, 21, 1, 141, 291 ] ], [ 5, 1, 24, 21, 1, 141, 291, 17, 16, 59 ], [ 1016 ] ], [ [ 42, [ 24, 7 ], [ 5, 21, 24, 4 ] ], [ 5, 7, 21, 24, 4 ], [ 31 ] ], [ [ 42, 1, [ 51, 54 ], 5 ], [ 5, 7, 51, 54 ], [ 31 ] ], [ [ 131, 8, 281, 1010 ], 1010, [ 31 ] ], [ [ 503, 13, 797, [ 5, 110 ] ], [ 5, 110, 13, 797, 13, 39 ] ], [ [ 117, 8, [ 55, 347 ], [ 5, 55, 347, 24 ] ], [ 5, 55, 347, 24 ], [ 81 ] ], [ [ 117, 8, [ 55, 347 ], [ 5, 55, 347, 37 ] ], [ 5, 55, 347, 37 ], [ 81 ] ], [ [ 42, 1, 51, [ 5, 21, 1, 67 ] ], [ 5, 21, 1, 67, 7, 51 ], [ 31 ] ], [ [ 142, 28, 359, [ 5, 21, 390 ] ], [ 5, 21, 0, 4, 28, 359 ], [ 31 ] ], [ [ 142, 28, 359, [ 5, 21, 390, 1011 ] ], [ 5, 21, 0, 4, 641, 51, 4 ], [ 31 ] ], [ [ 444, [ 132, 51 ], [ 5, 21, 141 ] ], [ 5, 132, 51, 21, 141 ], [ [ 51, 141 ] ] ], [ [ 122, 8, 14, [ 366, 58 ], [ 3, 9, 58, 56, 428, 603 ] ], [ 5, 58, 56, 647 ], [ 3 ] ], [ [ 122, 8, 14, [ 366, 58 ], [ 3, 9, 58, 56 ] ], [ 5, 58, 56 ], [ 3 ] ], [ [ 122, 8, 14, [ 366, 58 ], [ 3, 9, 58, 5 ] ], [ 5, 58 ], [ 3, 37, 12 ], 4 ], [ [ 131, 8, 281, 1012 ], 1012 ], [ [ 262, 14, 9, 109, 57, [ 5, 146, 0, 234, 9, 109 ] ], [ 5, 146, 0, 9, 399 ], [ 374 ] ], [ [ 262, 14, 9, 109, 57, [ 146, 5, 399 ] ], [ 5, 146, 9, 399 ], [ [ 3, 109, 374 ] ] ], [ [ 42, [ 0, 7 ], [ 5, 0, 73, 350, 139, 70 ] ], [ 5, 0, 73, 350, 139, 70 ], [ 31 ] ], [ [ 42, [ 0, 7 ], [ 5, 0, 73, 350 ] ], [ 5, 0, 73, 350 ], [ 31 ] ], [ [ 262, 14, 9, 109, 57, [ 5, 0, 234, 9, 109, 74, 66 ] ], [ 5, 0, 9, 399, 74, 66 ], [ 31 ] ], [ [ 262, 14, 9, 109, 57, [ 5, 0, 234, 9, 109 ] ], [ 5, 0, 9, 399 ], [ [ 3, 0, 109, 374 ] ] ], [ [ 42, [ 0, 296, 280, 51 ], [ 5, 21, 0, 4 ] ], [ 5, 0, 296, 280, 51, 21, 0, 4 ], [ 31 ] ], [ [ 265, [ 0, 70 ], [ 5, 798, 1 ] ], [ 5, 0, 798, 1 ], [ 31 ] ], [ [ 42, 1013, 5 ], [ 5, 24 ], [ 31 ] ], [ [ 25, 8, [ 17, 570, 6 ], 225, 5, 17 ], [ 5, 6, 17, 225 ], [ 31 ] ], [ [ 25, 8, [ 17, 570, 6 ], [ 5, 6, 13 ] ], [ 5, 6, 13 ], [ 31 ] ], [ [ 42, 87, [ 5, 17 ] ], [ 5, 17 ], [ 31 ] ], [ [ 42, 7, 105, 261, 5 ], [ 5, 261, 7, 1014 ], [ 31 ] ], [ [ 42, 24, 746, [ 5, 21, 29, 15 ] ], [ 5, 242, 24, 21, 29, 15 ], [ 31 ] ], [ [ 648, 7, 400, [ 266, 507, 5 ] ], [ 5, 266, 507 ], [ [ 157, 507, 31 ] ] ], [ [ 410, 8, 14, 483, [ 584, 401 ] ], [ 5, 87, 254, 214, 584, 401 ], [ 374 ] ], [ [ 42, 1, 105, [ 5, 21, 141 ] ], [ 5, 105, 21, 141 ], [ 31 ] ], [ [ 9, 87, [ 5, 214, 585, 401 ] ], [ 5, 214, 585, 401 ], [ 374 ] ], [ [ 410, 8, 14, 483, [ 5, 214, 585, 401 ] ], [ 5, 214, 87, 254, 585, 401 ], [ 374 ] ], [ [ 9, 87, [ 584, 401 ] ], [ 5, 214, 584, 401 ], [ 374 ] ], [ [ 262, 14, 9, 109, 57, [ 5, 234, 9, 109, 74, 66 ] ], [ 5, 9, 399, 74, 66 ], [ 31 ] ], [ [ 262, 14, 9, 109, 57, [ 5, 234, 9, 109 ] ], [ 5, 9, 399 ], [ [ 3, 109, 374 ] ] ], [ [ 42, 87, [ 5, 225 ] ], [ 5, 225 ], [ 31 ] ], [ [ 7, 7, [ 5, 583, 1, 21, 1016 ] ], [ 5, 583, 1, 21, 1, 141 ], [ 31 ] ], [ [ 13, 25, [ 5, 13, 18 ] ], [ 5, 13, 18 ], [ 31 ] ], [ [ 27, [ 29, 0 ], [ 1017, 29, 15, 208 ] ], [ 1018, 29, 15, 208, 96, 97 ], [ 31 ] ], [ [ 802, 7, 23, 210, [ 87, 73 ] ], [ 87, 73 ], [ [ 7, 23, 31 ] ] ], [ [ 802, 7, 23, 210, [ 87, 76 ] ], [ 87, 76 ], [ [ 7, 23, 31 ] ] ], [ [ 46, 7, 23, 210, 87 ], 87, [ [ 7, 23, 31 ] ] ], [ [ 140, [ 62, 80, 0, 21, 0, 141 ] ], [ 803, 62, 80, 0, 5, 19 ], [ 81 ] ], [ [ 9, [ 649, 126 ] ], [ 649, 126 ], [ [ 649, 126, 228, 108, 158 ] ] ], [ [ 117, 8, [ 0, 276, 188 ], [ 224, 215 ] ], [ 224, 0, 276, 188, 215 ], [ 81 ] ], [ [ 117, 8, [ 0, 276, 188 ], [ 224, 94 ] ], [ 224, 0, 276, 188, 94 ], [ 81 ] ], [ [ 117, 8, [ 0, 107, 1 ], [ 224, 94 ] ], [ 224, 0, 107, 1, 94 ], [ 81 ] ], [ [ 152, [ 224, 242, 16, 24, 94 ] ], [ 224, 242, 16, 24, 94, 17, 16, 59 ], [ 10 ] ], [ [ 25, 8, [ 224, 94 ] ], [ 224, 94 ], [ [ 224, 94, 81 ] ] ], [ [ 131, 8, 14, 617, [ 224, 804, 9, 65 ] ], [ 224, 804, 9, 65 ], [ 31 ] ], [ [ 46, 7, 23, [ 95, 24 ] ], [ 95, 7, 23, 24, 5 ], [ [ 7, 23, 24, 31 ] ] ], [ [ 42, 95, [ 95, 805, 315, 330 ] ], [ 95, 805, 315, 330 ], [ 31 ] ], [ [ 7, 7, 95, [ 650, 47 ] ], [ 95, 650, 47 ], [ [ 650, 47, 31 ] ] ], [ [ 46, 95, 337, [ 330, 68, 95, 24 ] ], [ 95, 330, 68, 24 ], [ [ 30, 55, 6, 64, 1, 31 ] ] ], [ [ 46, 7, 23, 210, 95 ], 95, [ [ 7, 23, 31 ] ] ], [ [ 42, 1, 105, 23, [ 2, 21, 4 ] ], [ 105, 23 ], [ 31 ] ], [ [ 1019, 8, 186, [ 806, 30, 433 ] ], [ 806, 30, 433 ] ], [ [ 122, 8, 14, 311, [ 274, 263, 56, 428, 603 ] ], [ 311, 274, 263, 56, 647 ], [ 31 ] ], [ [ 122, 8, 14, 311, [ 274, 263, 56 ] ], [ 311, 274, 263, 56 ], [ 31 ] ], [ [ 122, 8, 14, 311, [ 274, 263, 125, 56 ] ], [ 311, 274, 263, 125, 56 ], [ 31 ] ], [ [ 122, 8, 14, 311, [ 274, 263 ] ], [ 311, 274, 263 ], [ 31 ] ], [ [ 142, 24, [ 49, 24 ] ], [ 14, 49, 24 ], [ [ 24, 49, 31 ] ] ], [ [ 25, 8, 25, [ 508, 367 ], [ 14, 367, 18, 5 ] ], [ 14, 367, 18, 5 ], [ 31 ] ], [ [ 25, 8, 25, [ 508, 367 ], [ 14, 367, 18 ] ], [ 14, 367, 18 ], [ 31 ] ], [ [ 25, 8, 25, [ 508, 367 ], [ 14, 367, 5 ] ], [ 14, 367, 5 ], [ 31 ] ], [ [ 142, 24, [ 2, 24, 21, 4 ] ], [ 14, 2, 24, 228, 108, 158, 21, 4 ], [ 31 ] ], [ [ 142, 24, [ 2, 24, 5, 21, 141 ] ], [ 14, 2, 24, 5, 21, 141 ], [ [ 24, 4, 5 ] ] ], [ [ 142, 24, [ 5, 807, 141 ] ], [ 14, 5, 807, 141 ], [ [ 275, 5, 3 ] ] ], [ [ 142, 24, [ 37, 24 ] ], [ 14, 37, 24 ], [ [ 275, 5, 3 ] ] ], [ [ 151, 8, [ 33, 22 ], [ 113, 1, 33, 22 ] ], [ 113, 1, 33, 22, 33, 22, 14, 39 ], [ 81 ] ], [ [ 27, [ 6, 68, 44, 85, 16, 167 ], [ 113, 68, 44, 167, 72 ] ], [ 113, 68, 44, 167, 72 ], [ 81 ] ], [ [ 27, [ 215, 98 ], [ 113, 215, 167 ] ], [ 113, 215, 167 ], [ 81 ] ], [ [ 411, 8, [ 113, 0, 125 ] ], [ 113, 0, 125 ], [ [ 113, 234, 0, 125, 81 ] ] ], [ [ 117, 8, [ 0, 107, 1 ], [ 113, 0, 107, 1 ] ], [ 113, 0, 107, 1 ], [ 81 ] ], [ [ 142, [ 24, 173 ], [ 113, 24, 173 ] ], [ 113, 24, 173, 14 ], [ 31 ] ], [ [ 25, 8, [ 113, 149, 182, 88 ] ], [ 113, 149, 182, 88 ], [ [ 113, 149, 182, 88, 81 ] ] ], [ [ 9, [ 113, 9 ] ], [ 113, 9 ], [ [ 9, 113, 228, 108, 158 ] ] ], [ [ 27, [ 225, 98 ], [ 113, 225, 98 ] ], [ 113, 225, 98 ], [ 81 ] ], [ [ 27, [ 126, 220, 98 ], [ 113, 126, 220, 98 ] ], [ 113, 126, 220, 98, 21, 0, 4 ], [ 81 ] ], [ [ 27, [ 28, 83, 588 ], [ 113, 167, 72 ] ], [ 113, 83, 588, 167, 72 ], [ 81 ] ], [ [ 140, [ 113, 72, 6, 248, 810 ] ], [ 113, 72, 6, 248, 810, 19 ], [ 81 ] ], [ [ 48, 61, 154, [ 113, 589, 373 ] ], [ 113, 589, 373 ], [ 31 ] ], [ [ 438, 7, 23, 379, 47, 352 ], [ 352, 23, 379, 47 ], [ 31 ] ], [ [ 439, 7, 23, 13, 47, 352 ], [ 352, 23, 13, 47 ], [ 31 ] ], [ [ 25, 8, [ 25, 14, 236 ] ], [ 402, 509, 811, 26, 21, 67, 19 ], [ [ 402, 509, 811, 26, 31 ] ] ], [ [ 42, 1, [ 105, 54 ], 812 ], [ 402, 813, 105, 54 ], [ 31 ] ], [ [ 42, 1, 105, 812 ], [ 402, 813, 105 ], [ 31 ] ], [ [ 142, [ 24, 54 ], [ 402, 223, 24, 54 ], 34 ], [ 402, 223, 24, 54, 314 ], [ [ 24, 54, 4 ] ] ], [ [ 42, 1, [ 105, 54 ], 814 ], [ 402, 218, 105, 54 ], [ 31 ] ], [ [ 42, 1, 105, 814 ], [ 402, 218, 105 ], [ 31 ] ], [ [ 42, 25, [ 250, 7, 5 ] ], [ 250, 350, 1020, 320 ], [ 31 ] ], [ [ 152, [ 0, 429, 430 ], [ 57, 300 ] ], [ 57, 300, 17, 16, 59 ], [ 81 ] ], [ [ 48, 40, [ 57, 13, 259 ], 23 ], [ 57, 13, 259, 23 ], [ [ 23, 81, 316, 158 ] ] ], [ [ 13, [ 0, 6 ], [ 123, 66, 6, 370, 157 ] ], [ 123, 66, 6, 370, 157 ], [ 31 ] ], [ [ 152, [ 0, 429, 430 ], [ 123, 17, 16, 1, 88 ] ], [ 123, 17, 16, 1, 88, 17, 16, 59 ], [ 81 ] ], [ [ 35, 8, 14, 204, 1021 ], 1021, [ [ 204, 192, 81 ] ] ], [ [ 27, [ 29, 26 ], [ 590, 147, 30, 29, 26 ] ], [ 590, 147, 30, 29, 26, 96, 97 ], [ 31 ] ], [ [ 129, 269, [ 431, 1, 22, 57, 326 ] ], [ 431, 1, 22, 57, 326 ], [ [ 431, 1, 22, 57, 326, 31 ] ] ], [ [ 438, 7, 23, 379, 47, [ 60, 6, 73 ] ], [ 60, 6, 73, 23, 379, 47 ], [ 31 ] ], [ [ 439, 7, 23, 13, 47, [ 60, 6, 73 ] ], [ 60, 6, 73, 23, 13, 47 ], [ 31 ] ], [ [ 46, 7, 23, 210, [ 60, 6, 73 ] ], [ 60, 6, 73 ], [ [ 7, 23, 31 ] ] ], [ [ 9, [ 0, 41 ], [ 60, 6, 136, 205 ] ], [ 60, 6, 136, 205 ], [ 31 ] ], [ [ 151, 8, [ 33, 22 ], [ 138, 33, 22, 387, 6 ] ], [ 138, 33, 22, 387, 6, 33, 22, 14, 39 ], [ 81 ] ], [ [ 151, 8, [ 33, 22 ], [ 138, 33, 22, 387, 199, 0 ] ], [ 138, 33, 22, 387, 199, 0, 33, 22, 14, 39 ], [ 81 ] ], [ [ 35, 8, 14, [ 309, 50 ], [ 138, 99, 146, 50, 21, 586 ] ], [ 138, 99, 146, 50, 21, 586 ], [ 81 ] ], [ [ 35, 8, 14, [ 309, 50 ], [ 138, 99, 0, 0 ] ], [ 138, 99, 0, 0 ], [ 81 ] ], [ [ 262, 14, 9, 109, 57, [ 234, 9, 651, 109, 138 ] ], [ 9, 345, 651, 109, 138 ], [ [ 651, 109, 374, 228, 108, 158 ] ] ], [ [ 9, [ 9, 138 ] ], [ 9, 138 ], [ 31 ] ], [ [ 9, [ 9, 138 ], 652 ], [ 9, 138, 652 ], [ 31 ] ], [ [ 262, 14, 9, 109, 57, [ 3, 234, 9, 109, 633, 212, 0 ] ], [ 9, 109, 1022, 212, 31 ], [ [ 1, 0, 31, 228, 108, 158 ] ] ], [ [ 152, 291, [ 37, 1, 164, 24, 5 ] ], [ 37, 1, 5, 291, 17, 16, 59 ], [ 81 ] ], [ [ 32, [ 28, 6, 254, 26 ], 19, [ 37, 21, 312, 0, 4 ] ], [ 37, 21, 312, 0, 4, 28, 26 ], [ 31 ] ], [ [ 32, [ 28, 6, 254, 26 ], 19, [ 37, 21, 312, 0, 4, 57 ] ], [ 37, 21, 312, 0, 4, 57, 28, 26 ], [ 31 ] ], [ [ 32, [ 28, 6, 254, 26 ], 19, [ 37, 21, 328, 227 ] ], [ 37, 21, 328, 227, 28, 26 ], [ 31 ] ], [ [ 32, [ 0, 143, 41, 72 ], 37 ], [ 37, 0, 143, 41, 72 ], [ 81 ] ], [ [ 32, [ 459, 26, 179 ], [ 37, 179, 653 ] ], [ 37, 459, 26, 179, 653, 28, 26 ], [ 31 ] ], [ [ 42, [ 87, 76 ], [ 37, 87, 73 ] ], [ 37, 87, 73, 1 ], [ 31 ] ], [ [ 46, 95, 337, [ 37, 24 ] ], [ 37, 95, 24, 37 ], [ [ 95, 24, 37, 31 ] ] ], [ [ 129, 269, [ 37, 196, 170, 1, 56, 200, 183, 5 ] ], [ 37, 196, 332, 1, 56, 200, 183, 5 ], [ 31 ] ], [ [ 444, [ 132, 51 ], [ 37, 51 ] ], [ 37, 3, 132, 51 ], [ 31 ] ], [ [ 13, [ 0, 45 ], 36, [ 5, 475, 453 ] ], [ 37, 475, 71, 36 ], [ [ 3, 36, 31 ] ] ], [ [ 175, [ 28, 36 ], [ 5, 475, 453 ] ], [ 37, 475, 71, 36, 19, 28, 36 ], [ [ 3, 36, 31 ] ] ], [ [ 27, 112, 282, 0, [ 37, 272, 29, 15 ] ], [ 37, 272, 29, 15 ], [ 81 ] ], [ [ 129, 269, [ 37, 332, 1, 200, 183, 326 ] ], [ 37, 239, 1, 332, 200, 183, 326 ], [ 31 ] ], [ [ 265, [ 68, 52 ], [ 37, 815, 0, 6 ] ], [ 37, 815, 0, 6 ], [ 31 ] ], [ [ 48, 40, 119, [ 591, 89, 119 ] ], [ 591, 89, 119 ], [ [ 81, 316, 158 ] ] ], [ [ 48, 40, 119, [ 591, 7, 119 ] ], [ 591, 7, 119 ], [ [ 81, 316, 158 ] ] ], [ [ 46, 497, 498, 476 ], [ 476, 7, 170, 393 ], [ 31 ] ], [ [ 265, [ 68, 52 ], [ 476, 52 ] ], [ 476, 68, 52, 0, 6 ], [ 31 ] ], [ [ 654, [ 230, 818, 819, 235, 19 ] ], [ 230, 818, 819, 235, 19 ], [ 31 ] ], [ [ 131, 8, 281, 1023 ], [ 449, 110, 355, 263 ], [ 31 ] ], [ [ 131, 8, 281, 1024 ], [ 449, 110, 355, 263, 19 ], [ 31 ] ], [ [ 9, 1025 ], [ 449, 110 ], [ [ 9, 449, 228, 108, 158 ] ] ], [ [ 48, 40, 53, [ 181, 78, 211 ] ], [ 181, 53, 78, 211, 138 ], [ [ 78, 4 ], 10 ], 3 ], [ [ 48, 40, 53, [ 181, 78, 49 ] ], [ 181, 53, 78 ], [ 31 ] ], [ [ 48, 40, 53, [ 181, 295, 90, 53 ] ], [ 181, 295, 90, 53 ], [ 31 ] ], [ [ 48, 40, 277, [ 181, 0, 1026 ] ], [ 181, 154, 277 ], [ 31 ] ], [ [ 48, 40, 277, [ 181, 0 ] ], [ 181, 277, 0 ], [ 31 ] ], [ [ 48, 40, 277, [ 181, 13 ] ], [ 181, 277, 13 ], [ 31 ] ], [ [ 48, 40, 277, [ 181, 251, 277, 0 ] ], [ 181, 251, 277, 0 ], [ 31 ] ], [ [ 48, 40, 53, [ 181, 53 ] ], [ 181, 90, 53 ], [ 31 ] ], [ [ 1027, 8, 40, [ 351, 40, 207 ] ], [ 351, 40, 207 ], [ 81 ] ], [ [ 32, [ 0, 356, 26 ], [ 65, 71 ] ], [ 234, 0, 356, 26, 65, 71, 28, 26 ], [ [ 0, 356, 26, 31 ] ] ], [ [ 151, 8, [ 33, 22, 59 ], [ 3, 36 ] ], [ 33, 22, 36, 33, 22, 14, 39 ], [ 31 ] ], [ [ 151, 8, [ 33, 22, 59 ], [ 33, 22, 371, 192, 56 ] ], [ 33, 22, 371, 192, 56, 33, 22, 14, 39 ], [ 81 ] ], [ [ [ 338, 339 ], [ 526, 186, 339 ] ], [ 526, 186, 339 ], [ 31 ] ], [ [ 506, 8, [ 60, 25 ], 50, [ 477, 478 ] ], [ 477, 478 ], [ 31 ] ], [ [ 506, 8, [ 60, 25 ], 50, [ 477, 821, 478 ] ], [ 477, 821, 478 ], [ 31 ] ], [ [ 506, 8, [ 60, 25 ], 50, [ 477, 448, 478 ] ], [ 477, 448, 478 ], [ 31 ] ], [ [ 443, 14, [ 55, 1029 ], [ 75, 7, 325 ] ], [ 75, 7, 325, 55, 39 ], [ 81 ] ], [ [ 168, [ 181, 104 ], [ 75, 104 ] ], [ 75, 104, 85, 83, 39 ], [ [ 69, 181, 104, 81 ] ] ], [ [ 648, 7, 400, [ 371, 5 ] ], [ 371, 5 ], [ [ 371, 5, 31 ] ] ], [ [ 48, 40, 165, [ 3, 89, 18 ] ], [ 3, 89, 18 ], [ 31 ] ], [ [ 137, [ 3, 17, 16, 275, 1, 215 ] ], [ 3, 1, 215, 23, 1030, 194, 185, 108, 195, 14, 39 ], [ [ 1, 4, 5 ] ] ], [ [ 152, [ 621, 622, 6 ], [ 3, 1, 47 ] ], [ 3, 1, 47, 17, 16, 59 ], [ 81 ] ], [ [ 151, 8, [ 33, 22 ], [ 3, 1, 325, 272, 1, 5 ] ], [ 3, 1, 325, 272, 1, 5, 33, 22, 14, 39 ], [ 81 ] ], [ [ 129, 269, [ 3, 1, 326 ] ], [ 3, 1, 326 ], [ [ 196, 1, 56, 31 ] ] ], [ [ 122, 8, 14, [ 7, 58 ], [ 3, 7, 58, 5 ] ], [ 3, 7, 58, 5 ], [ 3, 37, 12 ], 4 ], [ [ 122, 8, 14, [ 7, 58 ], [ 3, 7, 9, 345, 106 ] ], [ 3, 7, 9, 345, 106 ], [ 31 ] ], [ [ 122, 8, 14, [ 7, 58 ], [ 3, 7, 9, 224, 106 ] ], [ 3, 7, 9, 224, 106 ], [ 31 ] ], [ [ 122, 8, 14, [ 7, 58 ], [ 3, 7, 9, 106 ] ], [ 3, 7, 9, 106 ], [ 31 ] ], [ [ 27, 368, [ 3, 1033, 369 ] ], [ 3, 368, 427, 369, 92, 19 ], [ [ 369, 92, 31 ] ] ], [ [ 168, [ 111, 9, 3 ], [ 126, 23 ] ], [ 3, 85, 83, 9, 126, 23, 85, 83, 39 ], [ 81 ] ], [ [ 32, [ 29, 15 ], [ 3, 85, 83, 29, 0, 5 ] ], [ 3, 85, 83, 29, 0, 5, 28, 26 ], [ 81 ] ], [ [ 165, 14, [ 3, 165, 361, 0, 5 ] ], [ 3, 165, 361, 0, 5 ], [ 31 ] ], [ [ 114, 40, 153, 53, [ 3, 79, 53, 78, 18 ] ], [ 3, 79, 53, 78, 18 ], [ 81 ] ], [ [ 114, 40, 153, 93, [ 3, 79, 822, 109, 86 ] ], [ 3, 79, 822, 109, 86 ], [ 81 ] ], [ [ 114, 40, 153, 93, [ 3, 79, 93, 5, 21, 124 ] ], [ 3, 79, 93, 5, 21, 124 ], [ 81 ] ], [ [ 114, 40, 153, 93, [ 3, 79, 270, 18 ] ], [ 3, 79, 270, 18 ] ], [ [ 32, [ 0, 143, 41, 72 ], [ 3, 110, 21, 433 ] ], [ 3, 110, 0, 4, 21, 433 ], [ 81 ] ], [ [ 142, 234, [ 377, 54, 261 ], [ 3, 110, 261 ] ], [ 3, 110, 261, 9, 21, 30, 220 ], [ 10 ] ], [ [ 27, [ 6, 68, 44, 85, 16, 167 ], [ 3, 68, 44, 167, 72 ] ], [ 3, 68, 44, 167, 72 ], [ 81 ] ], [ [ 405, [ 658, 124, 5 ] ], [ 3, 354, 5, 85, 83, 406, 39 ], [ 81 ] ], [ [ 405, [ 658, 1, 5 ] ], [ 3, 658, 1, 5, 85, 83, 406, 39 ], [ 81 ] ], [ [ 175, [ 70, 319 ], [ 3, 47 ] ], [ 3, 319, 47, 28, 36 ] ], [ [ 137, 8, [ 39, 197, 238, 18 ], [ 3, 284 ] ], [ 3, 39, 197, 238, 18, 194, 185, 108, 195, 14, 39 ], [ 81 ] ], [ [ 152, [ 3, 645, 646, 7, 5, 223, 291 ] ], [ 3, 645, 646, 7, 5, 291, 17, 16, 59 ], [ 81 ] ], [ [ 27, [ 215, 98 ], [ 3, 215, 167 ] ], [ 3, 215, 167 ], [ 81 ] ], [ [ 122, 8, 14, [ 343, 58 ], 0, 146, [ 64, 5 ] ], [ 3, 64, 5 ], [ 31 ] ], [ [ 27, [ 207, 118 ], [ 3, 21, 0, 4, 823 ] ], [ 3, 21, 0, 4, 823, 96, 97 ], [ 10 ] ], [ [ 27, [ 207, 118 ], [ 3, 21, 0, 4 ] ], [ 3, 21, 0, 4, 96, 97 ], [ 10 ] ], [ [ 32, [ 0, 356, 26 ], [ 3, 21, 243, 0, 4, 164, 124 ] ], [ 3, 21, 243, 0, 4, 164, 124, 28, 26 ], [ [ 243, 0, 4 ] ] ], [ [ 255, 93, [ 6, 320, 144 ] ], [ 3, 320, 144, 28, 171 ], [ 31 ] ], [ [ 255, 93, [ 6, 320, 144, 80 ] ], [ 3, 320, 144, 80, 28, 171 ], [ 31 ] ], [ [ 48, 143, 176, [ 3, 73, 287, 5 ] ], [ 3, 73, 287, 5 ], [ 31 ] ], [ [ 257, [ 28, 1, 289 ], [ 3, 289, 5 ] ], [ 3, 289, 5, 246, 258, 16, 36 ], [ 31 ] ], [ [ 257, [ 28, 1, 289 ], [ 3, 289, 5, 19 ] ], [ 3, 289, 5, 19, 246, 258, 16, 36 ], [ 31 ] ], [ [ 168, [ 181, 104 ], [ 3, 104 ] ], [ 3, 104, 85, 83, 39 ], [ [ 3, 181, 104, 81 ] ] ], [ [ 32, [ 80, 420 ], [ 3, 15, 0, 5, 28, 80 ] ], [ 3, 15, 0, 5, 28, 80 ], [ 31 ] ], [ [ 32, [ 15, 6 ], [ 3, 15, 0, 5, 28 ] ], [ 3, 15, 0, 5, 28 ], [ 31 ] ], [ [ 32, [ 15, 6 ], [ 3, 15, 0, 5, 182, 43 ] ], [ 3, 15, 0, 5, 182, 43 ], [ 31 ] ], [ [ 122, 8, 14, [ 366, 58 ], [ 3, 15, 9, 5 ] ], [ 3, 15, 9, 5 ], [ 31, 37, 12 ], 4 ], [ [ 122, 8, 14, [ 366, 58 ], [ 3, 15, 9, 56, 428, 603 ] ], [ 3, 15, 9, 56, 647 ], [ 31 ] ], [ [ 122, 8, 14, [ 366, 58 ], [ 3, 15, 9, 56 ] ], [ 3, 15, 9, 56 ], [ 31 ] ], [ [ 0, 25, 50, 78, 144, [ 3, 144, 35, 86 ] ], [ 3, 144, 35, 86 ], [ 81 ] ], [ [ 129, 106, [ 1, 271, 64, 106 ], 34 ], [ 3, 271, 64, 106, 1 ], [ 11 ] ], [ [ 9, 146, [ 3, 9, 828 ] ], [ 3, 146, 9, 828, 227 ], [ 612 ] ], [ [ 27, 353, [ 3, 23, 21, 141 ] ], [ 3, 23, 21, 141 ], [ 81 ] ], [ [ 9, [ 0, 41 ], [ 3, 23, 6, 41, 221 ] ], [ 3, 23, 6, 41, 221 ], [ 31 ] ], [ [ 129, 106, [ 1, 60, 6, 214, 15, 225, 19 ] ], [ 3, 74, 225, 214, 15, 249, 19, 1 ], [ 31 ] ], [ [ 255, 93, [ 6, 253, 144 ] ], [ 3, 253, 144, 28, 171 ], [ 31 ] ], [ [ 175, [ 6, 17 ], [ 3, 253, 36 ] ], [ 3, 253, 36 ], [ 31 ] ], [ [ 27, 70, [ 3, 70, 0, 659, 5 ] ], [ 3, 70, 0, 659, 5, 96, 97 ], [ 31 ] ], [ [ 480, 8, 510, 1034 ], 1034, [ [ 0, 17, 16, 594, 164, 171, 3, 31 ] ] ], [ [ 152, [ 36, 256 ], [ 36, 256, 148 ], [ 3, 5, 21, 1, 141 ] ], [ 3, 36, 256, 21, 1, 141 ], [ 81 ] ], [ [ 137, [ 3, 357, 30, 29, 0 ] ], [ 3, 357, 30, 29, 0 ], [ 81 ] ], [ [ 137, 8, [ 1, 834, 37 ], [ 3, 1, 5 ] ], [ 3, 834, 37, 1, 5, 194, 185, 108, 195, 14, 39 ], [ 81 ] ], [ [ 48, 196, 1035, 1036 ], 1036, [ 31 ] ], [ [ 48, 287, 176, 1037 ], 1037, [ 31 ] ], [ [ 27, 368, [ 3, 0, 368 ] ], [ 3, 0, 368, 19 ], [ 31 ] ], [ [ 494, [ 70, 59 ], 36, [ 3, 0, 68, 396 ] ], [ 3, 0, 68, 396, 495, 496 ], [ 81 ] ], [ [ 384, 8, [ 0, 47 ], [ 3, 0, 207, 47 ] ], [ 3, 0, 207, 47 ], [ [ 0, 207, 47, 31 ] ] ], [ [ 480, 8, 510, 3 ], [ 3, 0, 47 ], [ 31 ] ], [ [ 122, 8, 14, [ 7, 58 ], [ 3, 7, 0, 74, 5 ] ], [ 3, 0, 74, 66, 5 ], [ 31 ] ], [ [ 384, 8, 0, 26, 41, 56, [ 3, 0, 527, 528, 41, 240 ] ], [ 3, 0, 527, 528, 41, 240 ], [ [ 687, 45, 47, 31 ] ] ], [ [ 494, [ 70, 59 ], 36, [ 3, 7, 9, 18 ] ], [ 3, 0, 70, 7, 18, 495, 496 ], [ 81 ] ], [ [ 384, 8, [ 0, 47 ], [ 3, 0, 660, 47 ] ], [ 3, 0, 660, 47 ], [ [ 0, 660, 47, 31 ] ] ], [ [ 384, 8, [ 0, 47 ], [ 3, 0, 261, 469 ] ], [ 3, 0, 261, 469 ], [ 31 ] ], [ [ 0, 25, [ 3, 0, 835, 52 ] ], [ 3, 0, 835, 52 ], [ 10 ] ], [ [ 480, 8, 510, 1038 ], 1038, [ 31 ] ], [ [ 117, 8, [ 0, 276, 188 ], [ 3, 0, 276, 188, 215 ] ], [ 3, 0, 276, 188, 215 ], [ 81 ] ], [ [ 117, 8, [ 0, 276, 188 ], [ 3, 0, 276, 188, 37 ] ], [ 3, 0, 276, 188, 37 ], [ 81 ] ], [ [ 117, 8, [ 0, 107, 1 ], [ 3, 0, 107, 1, 37 ] ], [ 3, 0, 107, 1, 37 ], [ 81 ] ], [ [ 117, 8, [ 0, 107, 1 ], [ 3, 94, 86 ] ], [ 3, 0, 107, 1, 86 ], [ 81 ] ], [ [ 334, [ 3, 28, 21, 141 ] ], [ 3, 28, 21, 141 ], [ 81 ] ], [ [ 175, [ 28, 36 ], [ 3, 28, 36, 436 ] ], [ 3, 28, 36, 436 ], [ 31 ] ], [ [ 175, [ 28, 36 ], [ 3, 28, 36, 436, 19 ] ], [ 3, 28, 36, 436, 19 ], [ 31 ] ], [ [ 175, [ 28, 36 ], [ 3, 28, 36 ] ], [ 3, 28, 36 ], [ 31 ] ], [ [ 175, [ 28, 36 ], [ 3, 28, 36, 19 ] ], [ 3, 28, 36, 19 ], [ 31 ] ], [ [ 152, [ 24, 511, 414 ], [ 3, 24, 836 ] ], [ 3, 24, 836, 17, 16, 59 ], [ 81 ] ], [ [ 152, [ 24, 511, 414 ], [ 3, 24, 511 ] ], [ 3, 24, 511, 17, 16, 59 ], [ 81 ] ], [ [ 137, [ 837, 476, 353 ], [ 353, 1, 18, 5 ] ], [ 3, 837, 476, 353, 624, 1, 5 ], [ 81 ] ], [ [ 175, [ 70, 36 ], [ 3, 6, 64, 36 ] ], [ 3, 6, 64, 36, 28, 36 ], [ 31 ] ], [ [ 175, [ 6, 17 ], [ 3, 6, 838, 36 ] ], [ 3, 6, 838, 36 ], [ 31 ] ], [ [ 175, [ 6, 17 ], [ 3, 6, 279, 36 ] ], [ 3, 6, 279, 36 ], [ 31 ] ], [ [ 151, 8, [ 33, 22 ], [ 6, 33, 22, 37 ], [ 3, 6, 33, 22, 1, 43 ] ], [ 3, 6, 33, 22, 1, 43, 33, 22, 14, 39 ], [ 81 ] ], [ [ 151, 8, [ 33, 22 ], [ 6, 33, 22, 37 ], [ 3, 33, 22, 1, 5 ] ], [ 3, 6, 33, 22, 1, 5, 33, 22, 14, 39 ], [ 81 ] ], [ [ 151, 8, [ 33, 22 ], [ 6, 33, 22, 37 ], [ 3, 155, 94, 33, 22, 88 ] ], [ 3, 6, 33, 22, 1, 155, 94, 33, 22, 88, 33, 22, 14, 39 ], [ 81 ] ], [ [ 140, 1040 ], 1040, [ 81 ] ], [ [ 27, [ 392, 479, 41, 307 ] ], [ 3, 392, 479, 41, 307, 96, 97 ], [ 81 ] ], [ [ 114, 364, 40, 153, 93, [ 3, 595, 79, 270, 18 ] ], [ 3, 595, 79, 270, 18 ] ], [ [ 27, [ 3, 0, 427, 590, 299 ] ], [ 3, 427, 590, 299, 96, 97 ], [ [ 0, 4, 5 ] ] ], [ [ 129, 106, [ 1, 3, 17, 16, 73, 6, 106 ] ], [ 3, 17, 16, 73, 6, 106, 1 ], [ 11, 10 ], 0 ], [ [ 32, [ 17, 16 ], [ 3, 17, 16, 43, 28, 26 ] ], [ 3, 17, 16, 43, 28, 26 ], [ 31 ] ], [ [ 32, [ 17, 16 ], [ 3, 17, 16, 43, 212, 123, 26 ] ], [ 3, 17, 16, 43, 212, 123, 26 ], [ 31 ] ], [ [ 175, [ 70, 36 ], [ 3, 17, 16, 36 ] ], [ 3, 17, 16, 36, 28, 36 ], [ 31 ] ], [ [ 32, [ 17, 16 ], [ 3, 17, 16, 0, 23 ] ], [ 3, 17, 16, 0, 23 ], [ 31 ] ], [ [ 32, [ 17, 16 ], [ 3, 17, 16, 0, 18 ] ], [ 3, 17, 16, 0, 18 ], [ 31 ] ], [ [ 32, [ 80, 420 ], [ 3, 17, 16, 0, 5, 28, 80 ] ], [ 3, 17, 16, 0, 5, 28, 80 ], [ 31 ] ], [ [ 32, [ 17, 16 ], [ 3, 17, 16, 0, 5, 28 ] ], [ 3, 17, 16, 0, 5, 28 ], [ 31 ] ], [ [ 137, [ 3, 17, 16, 275, 1, 5 ] ], [ 3, 17, 16, 275, 16, 1, 5, 194, 185, 108, 195, 14, 39 ], [ 81 ] ], [ [ 480, 8, 510, 1041 ], 1041, [ [ 0, 17, 16, 594, 164, 171, 3, 31 ] ] ], [ [ 129, 106, [ 1, 3, 17, 16, 243, 6, 225 ] ], [ 3, 17, 16, 243, 6, 225, 1 ], [ [ 3, 17, 16, 225, 31 ] ] ], [ [ 129, 106, [ 1, 3, 17, 16, 243, 6, 106 ] ], [ 3, 17, 16, 243, 6, 106, 1 ], [ 11, 10 ], 0 ], [ [ 152, [ 0, 429, 430 ], [ 24, 5, 19 ] ], [ 3, 429, 430, 24, 5, 19, 17, 16, 59 ], [ 81 ] ], [ [ 152, [ 0, 429, 430 ], [ 288, 1, 5 ] ], [ 3, 429, 430, 24, 288, 1, 5, 17, 16, 59 ], [ 10, [ 24, 4 ] ], 3 ], [ [ 152, [ 3, 242, 16, 275, 133, 150, 86 ] ], [ 3, 242, 16, 275, 133, 150, 86, 17, 16, 59 ], [ 10 ] ], [ [ 0, 25, 50, 78, 144, [ 242, 16, 24, 5 ] ], [ 3, 242, 16, 24, 5 ], [ 81 ] ], [ [ 175, [ 70, 36 ], [ 3, 216, 36 ] ], [ 3, 216, 36, 28, 36 ], [ 31 ] ], [ [ 27, [ 207, 118 ], [ 3, 63, 333, 139 ] ], [ 3, 63, 333, 139, 96, 97 ], [ 10 ] ], [ [ 32, [ 28, 6, 254, 26 ], 19, [ 3, 63, 427, 431, 179 ] ], [ 3, 63, 427, 431, 179, 28, 26 ], [ 31 ] ], [ [ 27, [ 207, 118 ], [ 3, 63, 839, 218 ] ], [ 3, 63, 839, 218, 96, 97 ], [ 10 ] ], [ [ 27, [ 207, 118 ], [ 3, 63, 22, 118, 21, 0, 4 ] ], [ 3, 63, 22, 118, 21, 0, 4, 96, 97 ], [ 10 ] ], [ [ 48, 1043, 68, [ 3, 422, 53, 18 ] ], [ 3, 422, 53, 18 ], [ 31 ] ], [ [ 42, 24, 321, [ 3, 226, 5, 21, 226, 54 ] ], [ 3, 226, 5, 21, 54 ], [ 31 ] ], [ [ 152, [ 3, 226, 5, 21, 226, 54, 291 ] ], [ 3, 226, 5, 21, 226, 54, 291, 17, 16, 59 ], [ 31 ] ], [ [ 32, [ 29, 15 ], [ 3, 219, 29, 0, 840, 5, 164, 0, 88 ] ], [ 3, 219, 29, 0, 840, 5, 164, 0, 88, 28, 26 ], [ 81 ] ], [ [ 175, [ 301, 253 ], [ 3, 190, 253, 5, 363, 841 ] ], [ 3, 190, 253, 5, 363, 841 ], [ 31 ] ], [ [ 175, [ 301, 253 ], [ 3, 190, 253, 5 ] ], [ 3, 190, 253, 5 ], [ 31 ] ], [ [ 117, 8, [ 661, 323, 1 ], [ 3, 125, 5 ] ], [ 3, 661, 323, 1, 125, 5, 662, 663, 39 ] ], [ [ 27, [ 28, 7, 278 ], [ 3, 5, 21, 0, 643 ] ], [ 3, 5, 21, 0, 4 ], [ 81 ] ], [ [ 32, [ 0, 356, 26 ], [ 3, 5 ] ], [ 3, 5, 28, 26 ], [ 81 ] ], [ [ 131, 8, 159, [ 3, 159, 18 ] ], [ 3, 159, 18, 21, 31 ], [ 31 ] ], [ [ 129, 106, [ 1, 95, 7, 6, 106 ] ], [ 3, 95, 7, 6, 106, 1 ], [ 11, 10 ], 0 ], [ [ 129, 106, [ 1, 95, 7, 330, 106 ] ], [ 3, 95, 7, 330, 106, 1 ], [ 11 ], 0 ], [ [ 27, [ 29, 15 ], 512, [ 3, 149, 1044 ] ], [ 3, 149, 108, 108, 697, 96, 97 ] ], [ [ 137, [ 3, 1, 493, 105 ] ], [ 3, 57, 17, 16, 147, 1, 105, 194, 185, 108, 195, 14, 39 ], [ 81 ] ], [ [ 137, [ 3, 57, 17, 16, 500, 1, 5 ] ], [ 3, 57, 17, 16, 500, 1, 5, 194, 185, 108, 195, 14, 39 ], [ 81 ] ], [ [ 32, [ 459, 26, 72, 653 ], [ 3, 284 ] ], [ 3, 284, 28, 26 ], [ 31 ] ], [ [ 117, 8, [ 562, 84 ], [ 3, 284 ] ], [ 3, 284 ], [ 81 ] ], [ [ 9, 58, 1045, [ 126, 23 ], 19 ], [ 3, 9, 23 ], [ 31 ] ], [ [ 532, 8, 14, 533, 3 ], [ 3, 9, 224 ], [ 31 ] ], [ [ 262, 14, 9, [ 109, 318 ], [ 3, 9, 318, 91, 389 ] ], [ 3, 9, 318, 91, 389 ], [ 31, 37, 12 ], 4 ], [ [ 286, 8, 14, 454, [ 3, 9, 343, 45, 37 ] ], [ 3, 9, 343, 45, 37, 58, 9, 58 ], [ 31, 37, 12 ], 4 ], [ [ 286, 8, 14, 454, [ 3, 9, 343, 45, 56 ] ], [ 3, 9, 343, 45, 56, 9, 58 ], [ 31 ] ], [ [ 122, 8, 14, [ 366, 58 ], [ 3, 9, 248, 56 ] ], [ 3, 9, 248, 56 ], [ 3 ] ], [ [ 262, 14, 9, [ 109, 318 ], [ 3, 9, 846, 43 ] ], [ 3, 9, 155, 109, 43 ], [ 31 ] ], [ [ 255, 93, [ 6, 112, 144 ] ], [ 3, 112, 144, 28, 171 ], [ 31 ] ], [ [ 151, 8, [ 33, 22 ], [ 3, 481, 169, 33, 22, 37 ] ], [ 3, 481, 169, 33, 22, 37, 33, 22, 14, 39 ], [ 81 ] ], [ [ 151, 8, [ 33, 22 ], [ 6, 33, 22, 37 ], [ 3, 481, 33, 22, 43 ] ], [ 3, 481, 33, 22, 43, 33, 22, 14, 39 ], [ 81 ] ], [ [ 151, 8, [ 33, 22 ], [ 3, 481, 482, 33, 22, 37 ] ], [ 3, 481, 482, 33, 22, 37, 33, 22, 14, 39 ], [ 81 ] ], [ [ 9, [ 3, 132 ] ], [ 3, 199, 9, 253 ], [ [ 132, 3, 31 ] ] ], [ [ 480, 8, 510, 1046 ], 1046, [ [ 0, 24, 225, 3, 31 ] ] ], [ [ 42, 1, 105, [ 3, 37 ] ], [ 3, 37, 105 ], [ 31 ] ], [ [ 151, 8, [ 33, 22 ], [ 33, 22, 37 ], [ 3, 33, 22, 21, 33, 22, 4 ] ], [ 3, 33, 22, 21, 33, 22, 4, 33, 22, 14, 39 ], [ 81 ] ], [ [ 151, 8, [ 33, 22 ], [ 33, 22, 37 ], [ 3, 33, 22, 21, 33, 22, 4, 212, 52 ] ], [ 3, 33, 22, 21, 33, 22, 4, 212, 52, 33, 22, 14, 39 ], [ 81 ] ], [ [ 151, 8, [ 33, 22 ], [ 33, 22, 37 ], [ 3, 33, 22, 5 ] ], [ 3, 33, 22, 5, 33, 22, 14, 39 ], [ 81 ] ], [ [ 151, 8, [ 33, 22 ], [ 33, 22, 37 ], [ 3, 199, 379, 18 ] ], [ 3, 33, 22, 37, 199, 379, 18, 33, 22, 14, 39 ], [ 81 ] ], [ [ 27, [ 225, 98 ], [ 3, 225, 98 ] ], [ 3, 225, 98 ], [ 81 ] ], [ [ 117, 8, [ 0, 276, 188 ], [ 3, 94, 86 ] ], [ 3, 94, 86 ], [ 81 ] ], [ [ 566, 8, 1050, [ 6, 178, 75 ], [ 3, 147, 178, 1 ] ], [ 3, 147, 178, 1 ], [ [ 3, 403, 147, 1, 81 ] ] ], [ [ 117, 8, [ 661, 323, 1 ], [ 3, 147, 0, 5 ] ], [ 3, 147, 0, 5, 662, 663, 39 ], [ [ 0, 141 ] ] ], [ [ 443, 14, [ 133, 150 ], [ 3, 133, 150 ] ], [ 3, 133, 150, 55, 39 ], [ 81 ] ], [ [ 27, [ 126, 220, 98 ], [ 3, 126, 220, 98 ] ], [ 3, 126, 220, 98, 21, 0, 4 ], [ 81 ] ], [ [ 32, [ 608, 26 ], [ 3, 26, 579, 124, 164, 390 ] ], [ 3, 26, 579, 124, 164, 0, 4, 28, 26 ], [ 31 ] ], [ [ 32, [ 0, 41 ], [ 3, 26, 6, 41 ] ], [ 3, 26, 6, 41 ], [ 31 ] ], [ [ 152, 291, [ 26, 17, 16, 36 ], 5 ], [ 3, 26, 17, 16, 36 ], [ 81 ] ], [ [ 27, [ 28, 83, 588 ], [ 3, 167, 72 ] ], [ 3, 83, 588, 167, 72 ], [ 81 ] ], [ [ 384, 8, [ 0, 47 ], [ 3, 83, 327 ] ], [ 3, 83, 327 ], [ [ 83, 225, 31 ] ] ], [ [ 151, 8, [ 33, 22 ], [ 6, 33, 22, 37 ], [ 3, 482, 1, 325, 272, 1, 5 ] ], [ 3, 482, 1, 325, 272, 1, 5, 33, 22, 14, 39 ], [ 81 ] ], [ [ 151, 8, [ 33, 22 ], [ 3, 482, 0, 4 ] ], [ 3, 482, 0, 4, 33, 22, 14, 39 ], [ 81 ] ], [ [ 140, [ 3, 72, 6, 248 ] ], [ 3, 72, 6, 248, 19 ], [ 81 ] ], [ [ 140, 1053 ], 1053, [ 81 ] ], [ [ 262, 14, 9, 109, 57, [ 109, 106 ], 34 ], [ 3, 109, 106 ], [ 10, 11, [ 74, 66, 4 ], [ 0, 187, 67 ], 721 ], 16 ], [ [ 262, 14, 9, [ 109, 318 ], [ 3, 848, 426, 43 ] ], [ 3, 848, 426, 43 ], [ 31 ] ], [ [ 376, 36, [ 3, 577, 125, 36, 5 ] ], [ 3, 577, 125, 36, 5, 29, 59 ], [ 31 ] ], [ [ 494, [ 70, 59 ], 36, [ 3, 59, 36 ] ], [ 3, 59, 36, 495, 496 ], [ 81 ] ], [ [ 152, 291, [ 80, 0, 17, 16, 36 ], 5 ], [ 3, 80, 0, 36 ], [ 81 ] ], [ [ 129, 269, [ 3, 239, 1, 110, 332, 1, 326 ] ], [ 3, 239, 1, 110, 332, 1, 326 ], [ 31 ] ], [ [ 32, [ 29, 0 ], [ 3, 29, 15, 5 ] ], [ 3, 29, 15, 5, 28, 26 ], [ 81 ] ], [ [ 32, [ 29, 0 ], [ 3, 29, 15, 208, 164, 596, 463, 5 ] ], [ 3, 29, 15, 208, 164, 596, 463, 5, 28, 26 ], [ 81 ] ], [ [ 32, [ 29, 0 ], [ 3, 29, 15, 208, 164, 596, 463, 5, 19 ] ], [ 3, 29, 15, 208, 164, 596, 463, 5, 19, 28, 26 ], [ 81 ] ], [ [ 32, [ 29, 15, 237, 162, 98 ], [ 3, 29, 15, 98, 37 ] ], [ 3, 29, 15, 98, 37, 28, 26 ], [ 31 ] ], [ [ 32, [ 29, 0 ], [ 3, 29, 15, 182, 88, 19 ] ], [ 3, 29, 15, 182, 88, 19, 28, 26 ], [ 81 ] ], [ [ 376, [ 70, 36 ], [ 3, 29, 70, 36, 5 ] ], [ 3, 29, 70, 36, 5, 29, 59 ], [ 31 ] ], [ [ 376, 36, 19, [ 3, 29, 36, 5 ] ], [ 3, 29, 36, 5, 19, 29, 59 ], [ 31 ] ], [ [ 137, [ 3, 29, 0, 49, 61 ] ], [ 3, 29, 0, 49, 61 ], [ 81 ] ], [ [ 32, [ 29, 15 ], [ 3, 29, 0, 5 ] ], [ 3, 29, 0, 5, 28, 26 ], [ 81 ] ], [ [ 32, [ 29, 0, 143, 358 ], [ 3, 29, 0, 98, 37 ] ], [ 3, 29, 0, 98, 37, 28, 26 ], [ 81 ] ], [ [ 32, [ 29, 15 ], [ 3, 29, 0, 182, 88, 19 ] ], [ 3, 29, 0, 182, 88, 19, 28, 26 ], [ 81 ] ], [ [ 32, [ 29, 15 ], [ 3, 29, 0, 191, 5 ] ], [ 3, 29, 0, 191, 5, 28, 26 ], [ 31 ] ], [ [ 32, [ 29, 15, 0 ], [ 3, 29, 9, 18 ] ], [ 3, 29, 9, 18, 28, 26 ], [ 31 ] ], [ [ 27, 1057, [ 3, 5 ] ], [ 3, 203, 1058, 5, 96, 97 ], [ 31 ] ], [ [ 140, 1059 ], 1059, [ 81 ] ], [ [ 334, [ 3, 231, 193, 9, 43 ] ], [ 3, 231, 193, 9, 43 ], [ 81 ] ], [ [ 27, [ 3, 124, 855, 403, 856, 19 ] ], [ 3, 124, 855, 403, 856, 19, 96, 97 ], [ 81 ] ], [ [ 48, 143, 176, [ 3, 155, 143, 9, 119 ] ], [ 3, 155, 143, 9, 119 ], [ 31 ] ], [ [ 152, [ 3, 155, 17, 16, 24, 5 ] ], [ 3, 155, 17, 16, 24, 5, 17, 16, 59 ], [ 31 ] ], [ [ 32, [ 80, 420 ], [ 3, 191, 15, 5, 80 ] ], [ 3, 155, 94, 15, 5, 80 ], [ 31 ] ], [ [ 32, [ 15, 6 ], [ 3, 191, 15, 5 ] ], [ 3, 155, 94, 15, 5 ], [ 31 ] ], [ [ 255, 93, [ 3, 191, 171, 5, 80 ] ], [ 3, 155, 94, 171, 5, 80 ], [ 31 ] ], [ [ 255, [ 3, 191, 171, 5 ] ], [ 3, 155, 94, 171, 5 ], [ 31 ] ], [ [ 25, 8, [ 3, 155, 94, 149, 5 ] ], [ 3, 155, 94, 149, 5 ], [ [ 25, 155, 94, 50, 3, 228, 108, 158 ] ] ], [ [ 151, 8, [ 33, 22 ], [ 33, 22, 37 ], [ 3, 155, 130, 33, 22, 0, 5 ] ], [ 3, 155, 130, 33, 22, 0, 5, 33, 22, 14, 39 ], [ 81 ] ], [ [ 32, [ 29, 15, 237, 162, 98 ], [ 3, 160, 98 ] ], [ 3, 237, 162, 160, 98, 28, 26 ], [ 81 ] ], [ [ 32, [ 29, 15, 237, 162, 98 ], [ 3, 98, 179, 5 ] ], [ 3, 237, 162, 98, 179, 5, 28, 26 ], [ 81 ] ], [ [ 32, [ 80, 420 ], [ 3, 191, 26, 5, 80 ] ], [ 3, 191, 26, 5, 80 ], [ 31 ] ], [ [ 32, [ 17, 16 ], [ 3, 191, 26, 5 ] ], [ 3, 191, 26, 5 ], [ 31 ] ], [ [ 32, [ 3, 218, 310, 17, 16, 43 ] ], [ 3, 218, 310, 17, 16, 43, 28, 26 ], [ 81 ] ], [ [ 32, [ 3, 218, 310, 17, 16, 43, 212, 123, 26 ] ], [ 3, 218, 310, 17, 16, 43, 212, 123, 26, 28, 26 ], [ 81 ] ], [ [ 32, [ 80, 420 ], [ 3, 218, 310, 17, 16, 26, 80 ] ], [ 3, 218, 310, 17, 16, 26, 5, 80 ], [ 81 ] ], [ [ 32, [ 3, 218, 310, 17, 16, 26 ] ], [ 3, 218, 310, 17, 16, 26, 5 ], [ 81 ] ], [ [ 32, [ 80, 420 ], [ 3, 218, 310, 191, 5, 80 ] ], [ 3, 218, 191, 26, 5, 80 ], [ 31 ] ], [ [ 32, [ 3, 218, 310, 191, 5 ] ], [ 3, 218, 191, 26, 5 ], [ 31 ] ], [ [ 27, [ 29, 26 ], [ 3, 857, 428, 28, 5 ] ], [ 3, 857, 428, 28, 5, 96, 97 ], [ 31 ] ], [ [ 175, [ 13, 36 ], [ 3, 13, 36, 57 ] ], [ 3, 13, 36, 57 ], [ 31 ] ], [ [ 262, 14, 9, [ 109, 318 ], [ 3, 9, 318, 5 ] ], [ 3, 13, 155, 109, 5 ], [ 31, 37, 12 ], 4 ], [ [ 9, [ 0, 41 ], [ 3, 380, 2, 358, 1, 5 ] ], [ 3, 380, 2, 358, 1, 5 ], [ 31 ] ], [ [ 48, 40, 53, [ 3, 61, 53, 78, 18, 5 ] ], [ 3, 61, 53, 78, 18, 5 ], [ 31 ] ], [ [ 114, 8, 236, [ 513, 351, 236, 415, 116 ] ], [ 513, 351, 236, 415, 116 ], [ 31 ] ], [ [ 114, 79, 89, 90, [ 513, 432, 858, 236, 351, 457 ] ], [ 513, 432, 858, 236, 351, 457 ], [ [ 513, 432, 90, 235, 614, 158 ] ] ], [ [ 151, 8, [ 33, 22 ], [ 94, 219, 57, 169, 33, 22, 1 ] ], [ 94, 219, 57, 169, 33, 22, 1, 33, 22, 14, 39 ], [ 81 ] ], [ [ 286, 8, 1061, 664 ], [ 664, 9, 58 ], [ 31 ] ], [ [ 46, 7, 23, 210, 664 ], 664, [ [ 7, 23, 31 ] ] ], [ [ 9, 41, [ 205, 41, 336 ] ], [ 205, 41, 336 ], [ 31 ] ], [ [ 48, 40, [ 57, 13, 259 ], 205 ], [ 205, 57, 13, 259 ], [ 11 ] ], [ [ 114, 8, 236, [ 277, 351, 236 ] ], [ 277, 351, 236 ], [ 31 ] ], [ [ 7, 7, [ 1, 130, 43 ] ], [ 179, 1, 130 ], [ 11 ] ], [ [ 32, [ 459, 26, 179 ], 597 ], [ 597, 28, 26 ], [ 31 ] ], [ [ 168, [ 111, 9, 138 ], 126 ], [ 126, 85, 83, 39 ], [ 81 ] ], [ [ 168, [ 111, 9, 138 ], [ 859, 111, 9 ] ], [ 859, 111, 9, 85, 83, 39 ], [ 81 ] ], [ [ 46, 497, 498, 598 ], [ 598, 7, 170, 393 ], [ 31 ] ], [ [ 265, [ 68, 52 ], 598 ], [ 598, 68, 52, 0, 6 ], [ 31 ] ], [ [ 7, 247, 127 ], [ 127, 247, 1 ], [ [ 30, 247, 1, 31 ] ] ], [ [ 7, [ 271, 64 ], 127 ], [ 127, 271, 64, 1 ], [ [ 271, 64, 1, 31 ] ] ], [ [ 46, 70, 1, 127 ], [ 127, 70, 1 ], [ 31 ] ], [ [ 46, [ 17, 16, 73 ], 1, 127 ], [ 127, 17, 16, 73, 1 ], [ 31 ] ], [ [ 46, [ 17, 16, 76 ], 1, 127 ], [ 127, 17, 16, 76, 1 ], [ [ 30, 1, 31 ] ] ], [ [ 46, 87, 1, 127 ], [ 127, 87, 1 ], [ 31 ] ], [ [ 331, [ 87, 73 ], 1, 127 ], [ 127, 87, 73, 1 ], [ 31 ] ], [ [ 331, [ 87, 76 ], 1, 127 ], [ 127, 87, 76, 1 ], [ 31 ] ], [ [ 331, [ 231, 9 ], 1, 127 ], [ 127, 87, 231, 9, 1 ], [ 31 ] ], [ [ 46, 95, 1, 127 ], [ 127, 95, 7 ], [ [ 30, 1, 31 ] ] ], [ [ 46, 352, 1, 127 ], [ 127, 352, 1 ], [ 31 ] ], [ [ 46, [ 60, 6, 73 ], 1, 127 ], [ 127, 60, 6, 73, 1 ], [ [ 30, 73, 7, 31 ] ] ], [ [ 46, [ 60, 6 ], 1, 127 ], [ 127, 60, 6, 76, 1 ], [ [ 30, 7, 31 ] ] ], [ [ 46, [ 231, 9 ], 1, 127 ], [ 127, 231, 9, 1 ], [ 31 ] ], [ [ 46, 95, 337, [ 375, 24 ] ], [ 375, 95, 24 ], [ 31 ] ], [ [ 168, [ 111, 9, 148 ], 19, [ 375, 88 ] ], [ 375, 88, 19, 85, 83, 39 ], [ 81 ] ], [ [ 35, 8, 14, [ 6, 9 ], 72, [ 341, 440, 82 ] ], [ 341, 440, 82, 20 ], [ [ 20, 81 ] ] ], [ [ 27, [ 0, 173 ], [ 172, 21, 4 ] ], [ 172, 0, 173, 21, 4, 96, 97 ], [ [ 172, 0, 173, 81 ] ] ], [ [ 25, 8, 25, 163, 77, [ 172, 25, 163, 77, 50 ] ], [ 172, 25, 163, 77, 50, 25, 268 ], [ 81 ] ], [ [ 27, 353, 172 ], [ 172, 353 ], [ 31 ] ], [ [ 27, 0, 189, 128, [ 172, 189, 128 ] ], [ 172, 189, 128 ], [ 555 ] ], [ [ 13, [ 0, 112, 45 ], [ 860, 0, 67 ] ], [ 860, 0, 67 ], [ 31 ] ], [ [ 7, 342, 50, 77 ], [ 77, 50 ], [ 31 ] ], [ [ 446, 8, 14, 1066 ], [ 403, 383, 1, 23, 61, 385, 8 ], [ [ 487, 4 ] ] ], [ [ 152, 344, 403 ], [ 403, 344, 0, 17, 16, 59 ], [ 81 ] ], [ [ 25, 8, [ 403, 166, 77 ] ], [ 403, 166, 77 ], [ [ 25, 0, 288, 77, 81 ] ] ], [ [ 142, [ 24, 173 ], [ 5, 861, 173, 1067 ] ], [ 861, 24, 173, 377, 54, 14 ] ], [ [ 114, 364, 40, 153, 93, [ 600, 180, 135, 53, 78, 50 ] ], [ 600, 180, 135, 53, 78, 50 ], [ 31 ] ], [ [ 114, 40, 153, 53, [ 600, 595, 180, 135, 53, 78, 50 ] ], [ 600, 595, 180, 135, 53, 78, 50 ], [ 31 ] ], [ [ 48, 40, [ 57, 13, 259 ], 665 ], [ 665, 57, 13, 259 ], [ [ 665, 81, 316, 158 ] ] ], [ [ 140, [ 863, 118, 474 ] ], [ 863, 118, 474 ], [ 118, 10 ], 3 ], [ [ 168, [ 111, 9, 695 ], [ 864, 111, 9 ] ], [ 864, 9, 85, 83, 39 ], [ 81 ] ], [ [ 151, 8, [ 33, 22 ], [ 6, 33, 22, 37 ], [ 1, 325 ], [ 69, 272, 1 ] ], [ 69, 1, 325, 272, 1, 33, 22, 14, 39 ], [ 81 ] ], [ [ 151, 8, [ 33, 22 ], [ 69, 1, 33, 22 ] ], [ 69, 1, 33, 22, 33, 22, 14, 39 ], [ 81 ] ], [ [ 257, [ 28, 1, 289 ], [ 69, 289 ] ], [ 69, 289, 246, 258, 16, 36 ], [ 31 ] ], [ [ 25, 8, 25, 104, [ 69, 104 ] ], [ 69, 104, 25, 268 ], [ 81 ] ], [ [ 25, 8, 25, 104, [ 69, 104, 419 ] ], [ 69, 104, 419, 25, 268 ], [ 81 ] ], [ [ 35, 8, 14, [ 17, 16, 59, 5, 84 ], [ 69, 84 ] ], [ 69, 84, 35, 8 ], [ 81 ] ], [ [ 117, 8, [ 0, 107 ], [ 69, 580, 107, 43 ] ], [ 69, 580, 107, 43 ], [ 81 ] ], [ [ 27, [ 0, 173 ], 69 ], [ 69, 0, 173, 96, 97 ], [ [ 69, 0, 173, 81 ] ] ], [ [ 257, [ 28, 288, 187, 1 ], [ 69, 0, 288, 187, 1 ] ], [ 69, 0, 288, 187, 1, 246, 258, 16, 36 ], [ 31 ] ], [ [ 117, 8, [ 0, 107, 1 ], [ 69, 0, 107, 1 ] ], [ 69, 0, 107, 1 ], [ 81 ] ], [ [ 142, 28, 359, 69 ], [ 69, 28, 359 ], [ 31 ] ], [ [ 117, 8, [ 17, 16, 1068 ], [ 69, 17, 16, 512 ] ], [ 69, 17, 16, 512, 662, 663, 39 ], [ 81 ] ], [ [ 25, 8, 25, 163, 77, [ 69, 25, 163, 77, 50 ] ], [ 69, 25, 163, 77, 50, 25, 268 ], [ 81 ] ], [ [ 27, [ 207, 118 ], [ 69, 284 ] ], [ 69, 284, 96, 97 ], [ [ 207, 118, 81 ] ] ], [ [ 142, 234, [ 377, 54, 261 ], [ 69, 177, 20, 54, 261 ] ], [ 69, 177, 20, 54, 261 ], [ [ 234, 377, 54, 261, 228, 108, 158 ] ] ], [ [ 32, [ 0, 161, 41 ], [ 69, 177, 20, 160, 72 ] ], [ 69, 177, 20, 160, 161, 72 ], [ 31 ] ], [ [ 27, [ 0, 143, 160, 72 ], [ 69, 177, 20 ] ], [ 69, 177, 20, 160, 143, 72, 21, 0, 4 ], [ 81 ] ], [ [ 255, 865, [ 69, 177, 20 ] ], [ 69, 177, 20, 28, 171 ], [ 31 ] ], [ [ 32, 865, [ 69, 177, 20 ] ], [ 69, 177, 20, 28, 26 ], [ 31 ] ], [ [ 25, 8, 25, 163, 77, [ 69, 177, 20, 25, 163, 77, 72 ] ], [ 69, 177, 20, 25, 163, 77, 72, 25, 268 ], [ 81 ] ], [ [ 32, [ 459, 26, 72 ], [ 69, 177, 20, 72 ] ], [ 69, 177, 20, 72, 28, 26 ], [ 31 ] ], [ [ 27, [ 207, 118 ], [ 69, 177, 20, 22, 118 ] ], [ 69, 177, 20, 22, 118, 96, 97 ], [ [ 0, 22, 207, 118, 31 ] ] ], [ [ 27, 353, [ 69, 177, 20 ] ], [ 69, 177, 20 ], [ 31 ] ], [ [ 27, [ 0, 45 ], [ 189, 388, 18 ], 69 ], [ 69, 189, 388, 18 ], [ 81 ] ], [ [ 27, 0, 189, 128, [ 69, 189, 128 ] ], [ 69, 189, 128 ], [ 555 ] ], [ [ 27, [ 0, 462 ], [ 69, 179 ] ], [ 69, 179, 96, 97 ], [ 31 ] ], [ [ 117, 8, [ 0, 107 ], [ 69, 80, 6, 68, 568 ] ], [ 69, 80, 6, 68, 568 ], [ 31 ] ], [ [ 365, 8, 14, 747, 1069 ], [ 69, 13, 501, 18, 365 ], [ [ 13, 501, 81 ] ] ], [ [ 131, 8, 281, 1070 ], 1070, [ 31 ] ], [ [ 866, [ 1, 74 ], [ 148, 1, 74 ] ], [ 148, 1, 74 ], [ 31 ] ], [ [ 151, 8, [ 33, 22, 59 ], [ 148, 36 ] ], [ 148, 36, 33, 22, 14, 39 ], [ 31 ] ], [ [ 42, 148, [ 21, 1, 208 ] ], [ 148, 0, 1, 21, 1, 208 ], [ 31 ] ], [ [ 152, 291, [ 148, 201 ] ], [ 148, 201, 17, 16, 59 ], [ [ 148, 21, 721, 81, 291 ] ] ], [ [ 376, 36, 19, [ 148, 29, 36, 5 ] ], [ 148, 29, 36, 5, 19, 29, 59 ], [ 31 ] ], [ [ 334, 148 ], [ 148, 231, 193, 59 ], [ 81 ] ], [ [ 131, 8, 281, 148 ], 148, [ 31 ] ], [ [ 168, [ 111, 9, 148 ], 19, 148 ], [ 148, 19, 85, 83, 39 ], [ 81 ] ], [ [ 151, 8, [ 33, 22 ], [ 473, 33, 22, 387, 6 ] ], [ 473, 33, 22, 387, 6, 33, 22, 14, 39 ], [ 81 ] ], [ [ 151, 8, [ 33, 22, 59 ], [ 473, 33, 22, 59 ] ], [ 473, 33, 22, 59, 33, 22, 14, 39 ], [ 81 ] ], [ [ 48, 143, 176, 1071 ], 1071, [ 31 ] ], [ [ 48, 143, 176, 1072 ], 1072, [ 31 ] ], [ [ 48, 143, 176, 1073 ], 1073, [ 31 ] ], [ [ 117, 8, [ 267, 92 ], [ 91, 273 ] ], [ 91, 92, 273 ], [ 81 ] ], [ [ 25, 8, [ 91, 163, 149 ] ], [ 91, 163, 149 ], [ [ 163, 77, 149, 31 ] ] ], [ [ 42, 6, [ 91, 73, 6, 25, 204 ] ], [ 91, 73, 6, 25, 204 ], [ [ 60, 6, 91, 204, 31 ] ] ], [ [ 42, 6, [ 91, 73, 6, 204 ] ], [ 91, 73, 6, 204 ], [ [ 17, 560, 91, 204, 31 ] ] ], [ [ 9, 41, [ 91, 6, 336 ] ], [ 91, 41, 336 ], [ [ 41, 91, 228, 108, 158 ] ] ], [ [ 9, 41, [ 91, 41 ] ], [ 91, 41 ], [ 31 ] ], [ [ 35, 8, 14, [ 6, 178, 75 ], [ 91, 178, 75, 260, 25 ] ], [ 91, 178, 75, 260, 25 ], [ 666, 100 ], 3 ], [ [ 416, 8, 14, [ 91, 273 ] ], [ 91, 273 ], [ [ 9, 58, 91, 637, 31 ] ] ], [ [ 27, [ 29, 15 ], 512, 91 ], [ 91, 96, 97 ], [ 31 ] ], [ [ 506, 8, [ 60, 25 ], 50, [ 91, 149 ] ], [ 91, 149 ], [ 31 ] ], [ [ 114, 40, 153, 93, [ 91, 50, 415 ] ], [ 91, 50, 415 ], [ [ 91, 50, 415, 81 ] ] ], [ [ 32, [ 284, 241, 71 ], [ 91, 149 ] ], [ 91, 284, 241, 71, 26, 149, 28, 26 ], [ 81 ] ], [ [ 13, [ 91, 135, 116, 0 ] ], [ 91, 135, 116, 44, 0 ], [ 691, [ 554, 116 ] ], 2 ], [ [ 13, [ 91, 135, 116 ] ], [ 91, 135, 116 ], [ [ 116, 67 ], 691 ], 3 ], [ [ 444, [ 0, 197 ], [ 82, 197, 445, 323 ] ], [ 82, 197, 445, 323 ], [ 31 ] ], [ [ 35, 8, 14, [ 6, 178, 75 ], [ 82, 178, 75, 84 ] ], [ 82, 178, 75, 84 ], [ 81 ] ], [ [ 114, 79, 89, 72, [ 82, 160, 89 ] ], [ 82, 160, 89 ], [ 31 ] ], [ [ 48, 40, 53, [ 181, 78, 82, 160 ] ], [ 82, 160, 78, 21, 78, 4 ], [ [ 78, 4 ], 10 ], 3 ], [ [ 27, 368, [ 82, 867, 369 ] ], [ 82, 0, 413, 867, 369, 19 ], [ 31 ] ], [ [ 13, [ 499, 92 ], [ 82, 0, 92, 201, 240 ] ], [ 82, 0, 92, 201, 240 ], [ [ 13, 240, 67 ] ] ], [ [ 140, [ 82, 6, 125, 217 ] ], [ 82, 6, 125, 217, 19 ], [ 81 ] ], [ [ 13, 244, [ 82, 169, 472 ] ], [ 82, 169, 472 ], [ [ 302, 4 ] ] ], [ [ 140, 1077 ], 1077, [ 141 ] ], [ [ 13, [ 0, 15 ], [ 82, 13, 0, 457 ] ], [ 82, 13, 0, 457 ], [ 31 ] ], [ [ 42, [ 7, 346 ], [ 82, 13, 346 ] ], [ 82, 13, 346 ], [ 31 ] ], [ [ 13, 92, [ 82, 90, 230, 52, 201 ] ], [ 82, 90, 230, 52, 201 ], [ [ 179, 4 ] ] ], [ [ 46, 7, 290, 1078 ], [ 130, 38, 111, 68 ], [ 31 ] ], [ [ 46, 7, 290, 1079 ], [ 130, 38, 111, 232, 233 ], [ 31 ] ], [ [ 46, 7, 290, 1080 ], [ 130, 38, 111, 247 ], [ 31 ] ], [ [ 46, 7, 290, [ 1081, 64 ] ], [ 130, 38, 111, 6, 64 ], [ 31 ] ], [ [ 46, 7, 290, 1082 ], [ 130, 38, 111, 17, 16, 76 ], [ 31 ] ], [ [ 46, 7, 290, 1083 ], [ 130, 38, 111, 216 ], [ 31 ] ], [ [ 46, 7, 290, 1084 ], [ 130, 38, 111, 87 ], [ 31 ] ], [ [ 46, 7, 290, [ 1085, 6, 76 ] ], [ 130, 38, 111, 60, 6 ], [ 31 ] ], [ [ 46, 7, 290, 1086 ], [ 130, 38, 111, 94 ], [ 31 ] ], [ [ 42, 132, [ 130, 38, 132, 51 ] ], [ 130, 38, 132, 51 ], [ 31 ] ], [ [ 46, 7, 290, 1087 ], [ 130, 38, 868, 1, 24, 5 ], [ 31 ] ], [ [ 46, 7, 290, 1089 ], [ 130, 38, 351, 38 ], [ 31 ] ], [ [ 0, 639, [ 130, 0, 302, 30, 229 ] ], [ 130, 0, 302, 30, 229 ], [ 31 ] ], [ [ 13, 244, [ 130, 238, 30, 229 ] ], [ 130, 238, 30, 229 ], [ 31 ] ], [ [ 13, [ 0, 45 ], 36, 869 ], [ 601, 13, 36 ], [ [ 183, 241 ], [ 183, 67 ] ], 0 ], [ [ 175, [ 13, 36 ], 869 ], [ 601, 13, 36, 19 ], [ 31 ] ], [ [ 48, 40, 53, [ 22, 0, 295, 53, 78, 871 ] ], [ 22, 0, 295, 53, 78, 871 ], [ 31 ] ], [ [ 152, [ 0, 429, 430 ], [ 22, 35, 125 ] ], [ 22, 35, 125, 17, 16, 59 ], [ 81 ] ], [ [ 48, 40, 61, [ 22, 90, 240 ] ], [ 22, 90, 240 ], [ 31 ] ], [ [ 142, [ 24, 54 ], [ 315, 24, 54 ] ], [ 315, 24, 54, 314 ], [ [ 24, 54, 315, 31 ] ] ], [ [ 46, 95, 337, [ 315, 330, 24 ] ], [ 315, 95, 330, 24 ], [ 31 ] ], [ [ 48, 40, 119, [ 56, 89, 119 ] ], [ 56, 89, 119 ], [ [ 81, 316, 158 ] ] ], [ [ 48, 40, 119, [ 56, 7, 119 ] ], [ 56, 7, 119 ], [ [ 81, 316, 158 ] ] ], [ [ 175, 436, 412 ], [ 1090, 177, 611, 0, 45, 36, 19 ], [ 31 ] ], [ [ 35, 8, 14, 785, [ 470, 99 ], [ 99, 470 ] ], [ 99, 470 ], [ 81 ] ], [ [ 35, 8, 14, [ 309, 50 ], [ 138, 99, 146, 50 ] ], [ 99, 146, 50 ], [ 81 ] ], [ [ 35, 8, 14, 569, 8, [ 99, 201 ] ], [ 99, 201 ], [ 81 ] ], [ [ 35, 8, 14, [ 309, 50 ], [ 138, 99, 471, 50 ] ], [ 99, 471, 50, 81 ], [ 81 ] ], [ [ 46, 497, 498, 432 ], [ 432, 7, 170, 393 ], [ 31 ] ], [ [ 9, [ 432, 86 ] ], [ 432, 86 ], [ 11, 931, [ 193, 391, 123 ], [ 325, 609 ], 86 ], 0 ], [ [ 35, 8, 14, [ 184, 75 ], [ 1, 127 ], [ 35, 14, 204 ] ], [ 35, 1, 127, 14, 204 ], [ 10 ] ], [ [ 0, 25, 50, 78, 144, 35 ], [ 35, 144 ], [ 81 ] ], [ [ 27, [ 29, 26 ], [ 29, 15, 30, 29, 26 ] ], [ 29, 15, 30, 29, 26, 96, 97 ], [ 31 ] ], [ [ 48, 287, 176, 1092 ], 1092, [ 31 ] ], [ [ 48, 287, 176, 1093 ], 1093, [ 31 ] ], [ [ 142, [ 29, 59 ], [ 2, 24, 21, 141 ] ], [ 29, 59, 2, 24, 21, 141 ], [ 31 ] ], [ [ 142, [ 29, 59 ], [ 24, 659 ], 37 ], [ 29, 59, 24, 37 ], [ 31 ] ], [ [ 142, [ 29, 59 ], [ 508, 24, 655 ] ], [ 29, 59, 508, 24, 655 ], [ 31 ] ], [ [ 142, [ 29, 59 ], [ 22, 24, 88 ] ], [ 29, 59, 22, 24, 88 ] ], [ [ 46, 95, 337, [ 524, 24 ] ], [ 524, 95, 24 ], [ 31 ] ], [ [ 142, [ 377, 54 ], [ 223, 428, 363, 874 ] ], [ 223, 428, 377, 54, 363, 874, 14 ] ], [ [ 42, 1, 105, 223 ], [ 223, 105 ], [ 10, [ 105, 4 ], [ 0, 187, 67 ] ], 6 ], [ [ 152, 1094, [ 223, 493, 1, 275, 47 ] ], [ 223, 493, 1, 275, 47, 17, 16, 59 ], [ 81 ] ], [ [ 48, 40, 9, 1096 ], 1096, [ [ 193, 391, 123 ] ] ], [ [ 334, 8, 36, [ 178, 5 ] ], [ 231, 193, 59, 36, 178, 5, 231, 193, 59, 14, 39 ], [ 81 ] ], [ [ 334, 8, 36 ], [ 231, 193, 59, 36, 231, 193, 59, 14, 39 ], [ 81 ] ], [ [ 446, 8, 14, 1097 ], [ 124, 260, 613, 124, 61, 385, 8 ], [ [ 487, 4 ] ] ], [ [ 405, [ 155, 876 ] ], [ 155, 876, 85, 83, 406, 39 ], [ 81 ] ], [ [ 152, [ 667, 80, 0 ] ], [ 155, 264, 80, 0, 17, 16, 59 ], [ [ 667, 80, 0, 81 ] ] ], [ [ 35, 8, 14, [ 61, 209 ], [ 155, 35, 209 ] ], [ 155, 35, 61, 209 ] ], [ [ 32, [ 29, 15, 237, 162, 98 ], [ 877, 98 ] ], [ 877, 237, 162, 98, 28, 26 ], [ 81 ] ], [ [ 9, 667, 34 ], 667, [ 931 ] ], [ [ 175, [ 301, 253 ], [ 155, 94, 301, 253, 43 ] ], [ 191, 301, 253, 43 ], [ 10, [ 0, 67 ], 1098 ], 0 ], [ [ 46, 1, 173, [ 20, 44, 571 ] ], [ 20, 1, 173, 44, 571 ], [ 11 ] ], [ [ 140, 1099 ], 1099, [ 81 ] ], [ [ 46, 719, [ 20, 186 ] ], [ 20, 7, 226, 186 ], [ 31 ] ], [ [ 32, 0, 52, 72, [ 20, 0, 52, 72 ] ], [ 20, 52, 72 ], [ 31 ] ], [ [ 46, [ 55, 297, 298 ], 1, 20 ], [ 20, 55, 297, 298, 1 ], [ 31 ] ], [ [ 27, [ 28, 7, 278 ], [ 20, 278, 226 ] ], [ 20, 278, 226 ], [ 81 ] ], [ [ 32, 104, [ 20, 104 ] ], [ 20, 104 ], [ [ 572, 104, 31 ] ] ], [ [ 27, [ 29, 0 ], [ 20, 160, 143, 437 ] ], [ 20, 160, 143, 437 ], [ 81 ] ], [ [ 46, 70, 1, 20 ], [ 20, 70, 1 ], [ 31 ] ], [ [ 25, 8, [ 20, 166, 77, 6 ] ], [ 20, 166, 77, 6 ], [ [ 25, 0, 166, 77, 6, 81 ] ] ], [ [ 25, 8, [ 20, 166, 77 ] ], [ 20, 166, 77 ], [ [ 25, 0, 166, 77, 81 ] ] ], [ [ 32, 0, 52, 72, [ 20, 0, 52 ] ], [ 20, 0, 52 ], [ 31 ] ], [ [ 27, 0, 206, [ 20, 0, 206, 174 ] ], [ 20, 0, 206, 174, 19 ], [ [ 206, 174, 4 ], 10 ], 3 ], [ [ 27, [ 0, 173 ], 20 ], [ 20, 0, 173, 96, 97 ], [ [ 20, 0, 173, 81 ] ] ], [ [ 48, 40, 53, [ 20, 0, 295, 53, 78 ] ], [ 20, 0, 295, 53, 78 ], [ 31 ] ], [ [ 384, 8, [ 0, 47 ], [ 20, 0, 47, 72 ] ], [ 20, 0, 47, 72 ], [ 31 ] ], [ [ 27, [ 207, 118 ], 20 ], [ 20, 96, 97 ], [ [ 207, 118, 81 ] ] ], [ [ 27, [ 0, 45 ], 112, [ 20, 28, 878 ] ], [ 20, 28, 878, 252 ], [ 31 ] ], [ [ 27, [ 0, 45 ], 112, [ 20, 28, 879 ] ], [ 20, 28, 879 ], [ 31 ] ], [ [ 142, 28, 359, 20 ], [ 20, 28, 359 ], [ 31 ] ], [ [ 142, [ 24, 54 ], [ 20, 24, 54 ] ], [ 20, 24, 54, 314 ], [ [ 24, 54, 20, 31 ] ] ], [ [ 140, 1100 ], 1100, [ 81 ] ], [ [ 35, 8, 14, [ 6, 35, 84 ], 20 ], [ 20, 6, 35, 84 ], [ [ 20, 84, 228, 108, 158 ] ] ], [ [ 32, [ 6, 29 ], [ 20, 6, 29, 435 ] ], [ 20, 6, 29, 435 ], [ 31 ] ], [ [ 46, [ 17, 16, 73 ], 1, 20 ], [ 20, 17, 16, 73, 1 ], [ 31 ] ], [ [ 25, 8, 25, 163, 77, [ 20, 25, 163, 77, 50, 22 ] ], [ 20, 25, 163, 77, 50, 22, 25, 268 ], [ 81 ] ], [ [ 25, 8, 25, 163, 77, [ 20, 25, 163, 77, 50 ] ], [ 20, 25, 163, 77, 50, 1101, 25, 268 ], [ 81 ] ], [ [ 42, 1, [ 105, 54 ], 20 ], [ 20, 105, 54 ], [ 31 ] ], [ [ 42, 1, 105, 20 ], [ 20, 105 ], [ 31 ] ], [ [ 46, 352, 1, 20 ], [ 20, 352, 1 ], [ 31 ] ], [ [ 46, [ 60, 6, 73 ], 1, 20 ], [ 20, 60, 6, 73, 1 ], [ [ 121, 73, 7, 31 ] ] ], [ [ 532, 8, 14, 533, 20 ], [ 20, 9, 224 ], [ 31 ] ], [ [ 27, [ 0, 45 ], [ 189, 388, 18 ], 20 ], [ 20, 189, 388, 18 ], [ [ 388, 18, 228, 108, 158 ] ] ], [ [ 27, 0, 189, 128, [ 20, 189, 128 ] ], [ 20, 189, 128 ], [ 555 ] ], [ [ 27, [ 0, 462 ], [ 20, 179 ] ], [ 20, 179, 96, 97 ], [ 31 ] ], [ [ 27, [ 0, 45 ], 112, [ 20, 0, 126, 565, 759 ] ], [ 20, 126, 565, 72 ], [ 98 ] ], [ [ 27, [ 0, 45 ], 112, [ 20, 22, 1103, 260, 93 ] ], [ 20, 22, 740, 135, 260, 93 ], [ 1104 ] ], [ [ 27, [ 248, 22, 72 ], 20 ], [ 20, 22, 72 ], [ 31 ] ], [ [ 27, [ 29, 15 ], [ 20, 29, 15, 55, 50 ] ], [ 20, 29, 15, 55, 50 ], [ 31 ] ], [ [ 32, [ 29, 15, 237, 162, 98 ], [ 20, 29, 0, 237, 162, 65 ] ], [ 20, 29, 0, 237, 162, 65, 28, 26 ], [ 81 ] ], [ [ 32, [ 29, 0, 143, 358 ], [ 20, 237, 162, 65 ] ], [ 20, 237, 162, 65, 28, 26 ], [ 81 ] ], [ [ 32, [ 29, 15, 237, 162, 98 ], [ 69, 177, 20, 160, 98 ] ], [ 20, 237, 162, 160, 98, 28, 26 ], [ 81 ] ], [ [ 13, [ 20, 202, 525, 220 ] ], [ 20, 13, 202, 525, 220 ] ], [ [ 13, [ 20, 61, 18 ] ], [ 20, 13, 61, 18 ], [ [ 20, 13, 61, 18 ] ] ], [ [ 0, 25, 486, 538 ], [ 486, 538 ] ], [ [ 7, [ 30, 7 ], [ 306, 7, 206, 174 ] ], [ 306, 7, 206, 174 ], [ [ 7, 206, 174, 31 ] ] ], [ [ 168, [ 111, 9, 66 ], [ 306, 118, 19 ] ], [ 306, 111, 118, 19, 85, 83, 39 ], [ 81 ] ], [ [ 410, 8, 14, 483, [ 306, 323, 118 ] ], [ 306, 323, 118 ], [ 31 ] ], [ [ 27, 0, 206, [ 306, 0, 206, 174 ] ], [ 306, 0, 206, 174, 19 ], [ [ 7, 206, 174, 31 ] ] ], [ [ 152, [ 6, 422 ], [ 306, 6, 422, 424 ] ], [ 306, 6, 422, 424 ], [ [ 306, 6, 422, 424, 31 ] ] ], [ [ 168, [ 111, 9, 138 ], 880 ], [ 880, 85, 83, 39 ], [ 81 ] ], [ [ 446, 8, 14, 1105 ], [ 13, 92, 61, 385, 8 ], [ 116, [ 1106, 4 ] ], 3 ], [ [ 32, 209, [ 13, 163, 378, 209 ] ], [ 13, 163, 378, 209, 19, 28, 26 ], [ 31 ] ], [ [ 407, [ 13, 0, 82, 292 ] ], [ 13, 0, 82, 292 ], [ 10, [ 408, 67 ] ], 3 ], [ [ 866, [ 1, 74 ], [ 13, 222, 9, 74 ] ], [ 13, 222, 9, 74 ], [ 31 ] ], [ [ 503, [ 13, 548 ], 18 ], [ 13, 548, 13, 39 ] ], [ [ 13, [ 13, 82, 242, 465 ] ], [ 13, 82, 242, 465 ], [ [ 407, 67 ] ] ], [ [ 407, [ 13, 82, 292 ] ], [ 13, 82, 292 ], [ [ 408, 67 ] ] ], [ [ 438, 7, 23, 424, 13, 293 ], [ 13, 293, 424 ], [ 31 ] ], [ [ 9, 652 ], 652, [ 11, [ 9, 449, 228, 108, 158 ] ], 3 ], [ [ 114, 364, 40, 153, 93, [ 235, 180, 135, 53, 78 ] ], [ 235, 180, 135, 53, 78 ], [ 31 ] ], [ [ 114, 40, 153, 53, [ 235, 364, 180, 135, 53, 78 ] ], [ 235, 364, 180, 135, 53, 78 ], [ 31 ] ], [ [ 27, [ 29, 15 ], 512, 235 ], [ 235, 96, 97 ], [ 31 ] ], [ [ 32, [ 28, 6, 254, 26 ], 235 ], [ 235, 28, 26 ], [ 31 ] ], [ [ 324, 8, 14, [ 188, 52 ], 52 ], [ 188, 52, 21, 395, 139, 14 ], [ [ 395, 61, 188, 776, 52, 31 ] ] ], [ [ 648, 7, 400, [ 400, 5 ] ], [ 400, 5 ], [ 31 ] ], [ [ 48, 61, 154, [ 2, 90, 305, 19 ] ], [ 90, 305, 19 ], [ 393 ] ], [ [ 48, 40, 61, 90 ], 90, [ [ 68, 90, 1108 ], 10, [ 13, 634, 208 ] ], 4 ], [ [ 13, 404, [ 61, 404, 668 ] ], [ 61, 404, 668 ], [ [ 61, 404, 668, 31 ] ] ], [ [ 13, 404, [ 61, 404 ] ], [ 61, 404 ], [ [ 61, 404, 31 ] ] ] ]), 
            s(p, []), s(f, [ [ [ 7, [ 30, 7 ], [ 71, 7, 206, 174 ], 34 ], [ 71, 7, 206, 174 ], [ [ 206, 174, 4 ] ] ], [ [ 13, 118, [ 71, 13, 66 ], 34 ], [ 71, 13, 66 ], [ [ 13, 66, 4 ] ] ], [ [ 142, 24, [ 71, 24 ], 34 ], [ 14, 71, 24 ], [ [ 24, 4 ] ] ] ]), 
            s(h, [ [ [ 13, [ 0, 171 ], [ 49, 375 ] ], [ 49, 375 ], [ [ 128, 124 ], 375, 10 ], 6 ], [ [ 13, [ 49, 293, 88 ] ], [ 49, 293, 88 ] ], [ [ 13, [ 0, 15 ], [ 52, 134, 66 ] ], [ 52, 134, 66 ], [ 31 ] ], [ [ 13, [ 0, 112, 45 ], [ 213, 523, 15 ] ], [ 213, 523, 15 ], [ [ 338, 4 ], [ 15, 4 ] ], 3 ], [ [ 175, [ 13, 36 ], [ 213, 523, 19 ] ], [ 213, 523, 19 ], [ 10 ] ], [ [ 46, 1, 138, 71 ], [ 211, 7 ], [ 11 ] ], [ [ [ 138, 7 ], [ 71, 7 ] ], [ 71, 7 ], [ 11, 10 ], 3 ], [ [ [ 138, 7 ], [ 71, 0, 214, 110, 67 ] ], [ 71, 0, 214, 110, 67 ], [ 31 ] ], [ [ 27, 244, [ 71, 238 ] ], [ 71, 238, 19 ], [ 10, [ 420, 124 ] ], 3 ], [ [ 13, [ 186, 45 ], [ 121, 186, 45 ] ], [ 121, 186, 45 ], [ 31 ] ], [ [ 13, [ 0, 6 ], [ 121, 15, 6, 13, 18, 57 ] ], [ 121, 15, 6, 13, 18, 57 ], [ 31 ] ], [ [ 13, [ 121, 230, 18 ] ], [ 121, 230, 18 ], [ 31 ] ], [ [ 13, [ 0, 15 ], [ 121, 251, 285, 935 ] ], [ 121, 251, 285, 423 ], [ 31 ] ], [ [ 142, 24, [ 20, 24 ] ], [ 14, 20, 24 ], [ [ 24, 20, 31 ] ] ], [ [ [ 138, 7 ], [ 60, 202, 7 ] ], [ 60, 164, 202, 7 ], [ 11, 10, 86 ], 7 ], [ [ 46, 1, 138, [ 60, 177, 202 ] ], [ 60, 177, 202, 7 ], [ 11, 86 ], 3 ], [ [ 42, [ 138, 7 ], [ 817, 7 ] ], [ 817, 7 ], [ 11 ] ], [ [ 7, [ 30, 7 ], [ 655, 260, 656, 7 ] ], [ 820, 656, 7 ], [ [ 820, 656, 7, 31 ] ] ], [ [ [ 138, 7 ], [ 597, 7 ] ], [ 597, 7 ], [ 11 ] ], [ [ 13, [ 0, 15 ], [ 172, 66 ] ], [ 172, 66 ], [ [ 134, 66, 141 ], 101 ], 3 ], [ [ 13, [ 0, 15 ], [ 172, 15, 6, 26 ] ], [ 172, 15, 6, 26 ], [ 101, 102 ], 3 ], [ [ 13, [ 0, 6 ], [ 172, 599, 6, 66 ] ], [ 172, 599, 6, 66 ], [ 101, 102 ], 3 ], [ [ 27, [ 0, 6 ], [ 172, 599, 6, 66 ] ], [ 172, 599, 6, 66, 19 ], [ 101, 102 ], 3 ], [ [ 42, [ 138, 7 ], [ 862, 7 ] ], [ 862, 7 ], [ 11 ] ], [ [ 13, [ 0, 171 ], [ 82, 128, 260, 238 ] ], [ 82, 128, 260, 238 ], [ [ 128, 124 ], 10 ], 3 ], [ [ 13, [ 82, 45, 223 ] ], [ 82, 45, 223 ], [ 10 ] ], [ [ 13, [ 0, 171 ], [ 601, 128 ] ], [ 601, 128 ], [ [ 128, 86 ], [ 128, 124 ], 10 ], 6 ], [ [ [ 138, 7 ], [ 22, 870, 7 ] ], [ 22, 164, 870, 7 ], [ 11, 10, 86 ], 7 ], [ [ 7, [ 30, 68, 1 ], [ 20, 68, 7 ] ], [ 20, 68, 7 ], [ [ 121, 68, 1, 31 ] ] ], [ [ 7, [ 30, 232, 233, 1 ], [ 20, 232, 233, 7 ] ], [ 20, 232, 233, 7 ], [ 31 ] ], [ [ 7, [ 30, 335, 1 ], [ 20, 55, 6, 64, 7 ] ], [ 20, 55, 6, 64, 7 ], [ [ 121, 55, 6, 64, 1, 31 ] ] ], [ [ 7, 247, 20 ], [ 20, 247, 1 ], [ [ 121, 247, 1, 31 ] ] ], [ [ 7, [ 271, 64 ], 20 ], [ 20, 271, 64, 1 ], [ [ 121, 271, 64, 1, 31 ] ] ], [ [ 7, [ 30, 221, 1 ], [ 20, 221, 7 ] ], [ 20, 221, 7 ], [ [ 121, 221, 1, 31 ] ] ], [ [ 7, [ 30, 6, 245, 1 ], [ 20, 6, 245, 7 ] ], [ 20, 6, 245, 7 ], [ [ 121, 6, 245, 1, 31 ] ] ], [ [ 7, [ 30, 335, 1 ], [ 20, 6, 64, 7 ] ], [ 20, 6, 64, 7 ], [ [ 121, 6, 64, 1, 31 ] ] ], [ [ 46, [ 17, 16, 76 ], 1, 20 ], [ 20, 17, 16, 76, 1 ], [ [ 121, 7, 31 ] ] ], [ [ 7, [ 30, 216, 1 ], [ 20, 216, 7 ] ], [ 20, 216, 7 ], [ 31 ] ], [ [ 27, [ 0, 15 ], [ 20, 157, 6, 167 ] ], [ 20, 157, 6, 167, 19 ], [ 10, [ 408, 300 ] ], 3 ], [ [ 27, [ 0, 45 ], 112, [ 20, 222, 383, 0 ] ], [ 20, 222, 383, 0, 19 ], [ 10 ] ], [ [ 46, 87, 1, 20 ], [ 20, 87, 1 ], [ 31 ] ], [ [ 331, [ 87, 73 ], 1, 20 ], [ 20, 87, 73, 1 ], [ 31 ] ], [ [ 331, [ 87, 76 ], 1, 20 ], [ 20, 87, 76, 1 ], [ 31 ] ], [ [ 46, 95, 1, 20 ], [ 20, 95, 7 ], [ [ 121, 1, 31 ] ] ], [ [ 46, [ 60, 6 ], 1, 20 ], [ 20, 60, 6, 76, 1 ], [ [ 121, 7, 31 ] ] ], [ [ 7, [ 30, 94, 1 ], [ 20, 94, 7 ] ], [ 20, 94, 7 ], [ 31 ] ], [ [ 13, [ 0, 112, 45 ], [ 90, 348, 45 ] ], [ 90, 348, 45 ], [ 10 ] ], [ [ 27, [ 0, 45 ], 112, [ 90, 15, 6, 45 ] ], [ 90, 15, 6, 45, 19 ], [ 10 ] ] ]), 
            s(S, []), s(_, []), s(E, []), e = n.__decorate([ i.Injectable(), n.__metadata("design:paramtypes", [ o.ShareHttpClient ]) ], e);
        }();
        t.DefaultService = a;
    },
    264: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.replayCacheByObs = t.replayCache = void 0;
        var n = r(0), o = r(7);
        t.replayCache = function(e) {
            var t;
            return function() {
                for (var r = [], i = 0; i < arguments.length; i++) r[i] = arguments[i];
                if (t) return t.asObservable();
                var a = new o.ReplaySubject();
                t = a;
                var s = e.call.apply(e, n.__spread([ this ], r));
                if (!(s instanceof o.Observable)) throw new Error("传入函数返回值不是Observable");
                var u = !1;
                return s.subscribe(function(e) {
                    u = !0, a.next(e), a.complete();
                }, function(e) {
                    u = !0, a.error(e), t = void 0;
                }, function() {
                    if (!u) {
                        var e = new Error("函数返回的Observable没有调用next函数");
                        a.error(e), t = void 0;
                    }
                }), a.asObservable();
            };
        }, t.replayCacheByObs = function(e) {
            var t = new o.ReplaySubject();
            if (!(e instanceof o.Observable)) throw new Error("传入函数返回值不是Observable");
            var r = !1;
            return e.subscribe(function(e) {
                r = !0, t.next(e), t.complete();
            }, function(e) {
                r = !0, t.error(e);
            }, function() {
                if (!r) {
                    var e = new Error("replayCacheByObs");
                    t.error(e);
                }
            }), t.asObservable();
        };
    },
    268: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.GrayFeatureExtensionsService = void 0;
        var n = r(0), o = r(1), i = r(17), a = r(3), s = function() {
            function e(e) {
                this.grayService = e;
            }
            return e.prototype.canIUseFeatureHybridCodesMixed = function(e, t, r) {
                return void 0 === t && (t = {}), void 0 === r && (r = !1), this.grayService.canIUseFeatureHybridDimension(e, t, r).pipe(a.map(function(t) {
                    return t.reduce(function(t, r, n) {
                        var o = e[n].isInverse || !1;
                        return t && Boolean(+r ^ +o);
                    }, !0);
                }));
            }, e = n.__decorate([ o.Injectable(), n.__metadata("design:paramtypes", [ i.GrayFeatureService ]) ], e);
        }();
        t.GrayFeatureExtensionsService = s;
    },
    27: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.BackendMigrateService = void 0;
        var n = r(0), o = r(1), i = r(17), a = r(3), s = function() {
            function e(e) {
                this.grayService = e;
            }
            return e.prototype.generateMigratingRequestShareCopy = function(e, t) {
                return this.generateMigratingRequest({
                    newApi: e,
                    oldApi: t,
                    grayCode: "2298"
                }, !1);
            }, e.prototype.generateMigratingRequestFeedSpring = function(e, t) {
                return this.generateMigratingRequest({
                    newApi: e,
                    oldApi: t,
                    grayCode: "2318"
                }, !1);
            }, e.prototype.generateMigratingRequestActivityRelatedApi = function(e, t) {
                return this.generateMigratingRequest({
                    newApi: e,
                    oldApi: t,
                    grayCode: "2401"
                }, !1);
            }, e.prototype.generateMigratingRequest = function(e, t) {
                var r = e.newApi, n = e.oldApi, o = e.grayCode;
                return void 0 === t && (t = !0), this.grayService.canIUseFeature(o).pipe(a.switchMap(function(e) {
                    return e ? t ? r.pipe(a.catchError(function() {
                        return n;
                    })) : r : n;
                }));
            }, e = n.__decorate([ o.Injectable(), n.__metadata("design:paramtypes", [ i.GrayFeatureService ]) ], e);
        }();
        t.BackendMigrateService = s;
    },
    28: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.APIS = void 0, r(0).__exportStar(r(25), t);
        var n = r(25);
        t.APIS = [ n.DefaultService ];
    },
    299: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.productSelectData = t.selectGoodsSourceConfig = void 0;
        var n = r(7);
        t.selectGoodsSourceConfig = {
            whetherSelfAndSupplyClash: !1,
            goodsSourceLimitExcludeSelf: 1,
            goodsSourceLimitErrorMsg: "请选择同一货源品牌的商品"
        }, t.productSelectData = {
            selectedCarriageChangeSubject: new n.Subject(),
            templateGoodsMapShared: new Map(),
            isTemplateLimit: !1
        };
    },
    3: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), r(0);
        var n = r(416);
        t.catchError = n.catchError, t.concat = n.concat$1, t.concatAll = n.concatAll, t.concatMap = n.concatMap, 
        t.debounceTime = n.debounceTime, t.delay = n.delay, t.delayWhen = n.delayWhen, t.distinct = n.distinct, 
        t.distinctUntilChanged = n.distinctUntilChanged, t.every = n.every, t.filter = n.filter, 
        t.finalize = n.finalize, t.last = n.last, t.map = n.map, t.mapTo = n.mapTo, t.mergeAll = n.mergeAll, 
        t.mergeMap = n.mergeMap, t.multicast = n.multicast, t.refCount = n.refCount, t.repeatWhen = n.repeatWhen, 
        t.retry = n.retry, t.retryWhen = n.retryWhen, t.scan = n.scan, t.share = n.share, 
        t.skipWhile = n.skipWhile, t.startWith = n.startWith, t.switchAll = n.switchAll, 
        t.switchMap = n.switchMap, t.take = n.take, t.takeUntil = n.takeUntil, t.takeWhile = n.takeWhile, 
        t.tap = n.tap, t.timeout = n.timeout, t.timestamp = n.timestamp;
    },
    30: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.MonoRedDotService = t.STORAGE_RED_DOT_INFO_KEY = void 0;
        var n = r(0), o = r(1), i = r(7), a = r(3), s = r(41), u = r(11), c = r(18), l = r(50), d = r(137);
        t.STORAGE_RED_DOT_INFO_KEY = "RED_DOT_INFO";
        var p = function() {
            function e(e, t, r, n) {
                this.monoUtil = e, this.timeService = t, this.wxCloudApiService = r, this.redDotMigrateService = n, 
                this.serviceRedDotInfo = {};
            }
            return e.prototype.setApiService = function(e, t, r) {
                this.api = e, this.wx = t, this.errorService = r;
            }, e.prototype.getRedDot = function(e) {
                var t = e.map(function(e) {
                    return n.__assign(n.__assign({}, e), {
                        type: s.RedDotType.UID
                    });
                });
                return this.getRedDotMix(t);
            }, e.prototype.getRedDotByGroupId = function(e) {
                var t = e.map(function(e) {
                    return n.__assign(n.__assign({}, e), {
                        type: s.RedDotType.UID_GROUP_ID
                    });
                });
                return this.getRedDotMix(t);
            }, e.prototype.getRedDotByActId = function(e) {
                var t = e.map(function(e) {
                    return n.__assign(n.__assign({}, e), {
                        type: s.RedDotType.UID_ACT_ID
                    });
                });
                return this.getRedDotMix(t);
            }, e.prototype.getRedDotByGroupIdAndActId = function(e) {
                var t = e.map(function(e) {
                    return n.__assign(n.__assign({}, e), {
                        type: s.RedDotType.UID_ACT_ID_GROUP_ID
                    });
                });
                return this.getRedDotMix(t);
            }, e.prototype.getRedDotMix = function(e) {
                var t = this, r = e.map(function(e) {
                    var r = e.code, n = e.type, o = e.enforceUpdate;
                    return {
                        code: r,
                        type: n,
                        redDotKey: t.getMixRedDotKey(e),
                        enforceUpdate: o
                    };
                });
                return this.getRedDotFromBack(r, e);
            }, e.prototype.getRedDotTimeCompare = function(e, t) {
                return this.redDotMigrateService.getRedDotList([ e ]).pipe(a.map(function(e) {
                    var r = (null == e ? void 0 : e[0]) || {}, n = r.invokerNumber, o = r.lastReadTime;
                    return !n || !!(t && t > Number(o));
                }));
            }, e.prototype.getRedDotLastReadTime = function(e) {
                return this.redDotMigrateService.getRedDotList([ e ]).pipe(a.map(function(e) {
                    if (e[0]) {
                        var t = e[0].lastReadTime;
                        return Number(t || 0);
                    }
                    return 0;
                }));
            }, e.prototype.markReadRedDot = function(e) {
                var t = e.map(function(e) {
                    return n.__assign(n.__assign({}, e), {
                        type: s.RedDotType.UID
                    });
                });
                return this.setRedDotMix(t);
            }, e.prototype.markReadRedDotByGroupId = function(e) {
                var t = e.map(function(e) {
                    return n.__assign(n.__assign({}, e), {
                        type: s.RedDotType.UID_GROUP_ID
                    });
                });
                return this.setRedDotMix(t);
            }, e.prototype.markReadRedDotByActId = function(e) {
                var t = e.map(function(e) {
                    return n.__assign(n.__assign({}, e), {
                        type: s.RedDotType.UID_ACT_ID
                    });
                });
                return this.setRedDotMix(t);
            }, e.prototype.markReadRedDotByGroupIdAndActId = function(e) {
                var t = e.map(function(e) {
                    return n.__assign(n.__assign({}, e), {
                        type: s.RedDotType.UID_ACT_ID_GROUP_ID
                    });
                });
                return this.setRedDotMix(t);
            }, e.prototype.setRedDotMix = function(e) {
                var t = this, r = e.map(function(e) {
                    return {
                        code: e.code,
                        type: e.type,
                        redDotKey: t.getMixRedDotKey(e)
                    };
                });
                return this.setRedDotFromBack(r);
            }, e.prototype.setStorageRedDotInfoFromSetFalse = function(e) {
                this.setStorageRedDotInfo(e);
            }, e.prototype.filterNotFalseRedDotInfoStorage = function(e) {
                var t = this;
                return e.filter(function(e) {
                    var r, n = e.code, o = t.getStorageRedDotInfo(e);
                    return !o[n] || (null === (r = o[n]) || void 0 === r ? void 0 : r.result);
                });
            }, e.prototype.getRedDotFromBack = function(e, t) {
                var r = this;
                return this.getInfoFromDifferentBack(e, t).pipe(a.map(function(n) {
                    var o = n.backRes;
                    return n.storageRes, t.map(function(n) {
                        var i = n.code, a = o.find(function(e) {
                            return r.monoUtil.isEmpty(n.customKey) ? e.code === i : e.recordKey === n.code + "_" + n.customKey;
                        }), s = e.find(function(e) {
                            return e.code === n.code;
                        });
                        if (!a) return {
                            code: i,
                            result: !1,
                            type: s.type
                        };
                        var u = r.judgeRedDotResult(a, t);
                        return {
                            code: i,
                            result: u,
                            type: a.type
                        };
                    });
                }));
            }, e.prototype.getInfoFromDifferentBack = function(e, t) {
                var r = this, o = this.getStorageResAndNotStorageParam(e, t), s = o.storageRes, u = o.notStorageParam, c = this.getBackAndCloudParam(u), l = c.wxCloudDotParams, d = c.backDotListParams, p = l.length ? this.redDotMigrateService.getRedDotList(l) : i.of([]), f = d.length ? this.redDotMigrateService.getRedDotList(d).pipe(a.catchError(function(e) {
                    return r.catchErrorAndReportForGetDot(e);
                })) : i.of([]);
                return i.forkJoin([ f, p ]).pipe(a.map(function(e) {
                    var t = n.__read(e, 2), r = t[0], o = t[1];
                    return {
                        backRes: r = r.concat(o),
                        storageRes: s
                    };
                }));
            }, e.prototype.setRedDotFromBack = function(e) {
                var t = this.getBackAndCloudParam(e), r = t.wxCloudDotParams, o = t.backDotListParams, s = {}, u = r.length ? this.redDotMigrateService.setAndMarkRedDot(e) : i.of(s), c = o.length ? this.redDotMigrateService.setAndMarkRedDot(e) : i.of(s);
                return i.forkJoin([ c, u ]).pipe(a.map(function(e) {
                    var t = n.__read(e, 2), r = t[0];
                    return t[1], r;
                }));
            }, e.prototype.judgeRedDotResult = function(e, t) {
                var r = new Date().getTime(), n = e.limitNumber, o = e.invokerNumber, i = e.expireDate, a = e.cycleDay, s = e.lastReadTime, c = Number(s), l = this.getIsTimeOverdue(r, i), d = !this.monoUtil.isEmpty(n) && (o || 0) >= n, p = !1;
                if (!this.monoUtil.isEmpty(a) && !this.monoUtil.isEmpty(c)) {
                    var f = t.find(function(t) {
                        return t.code === e.code;
                    }), h = f && void 0 !== f.resetStateAtHour ? Math.floor(f.resetStateAtHour % 24) : -1;
                    p = r < (-1 === h ? this.timeService.newDate(c).getTime() + a * u.ONE_DAY_TIME : this.timeService.newDate(c).setHours(h, 0, 0, 0) + a * u.ONE_DAY_TIME);
                }
                return !(l || d || p);
            }, e.prototype.getIsTimeOverdue = function(e, t) {
                return !!t && e >= this.timeService.newDate(t).getTime();
            }, e.prototype.getMixRedDotKey = function(e) {
                if (e.type === s.RedDotType.UID_GROUP_ID) {
                    if (!e.groupId) throw new Error("新版红点参数报错：" + e.code + "缺少redDotKey:groupId");
                    return e.groupId;
                }
                if (e.type === s.RedDotType.UID_ACT_ID) {
                    if (!e.actId) throw new Error("新版红点参数报错：" + e.code + "缺少redDotKey:actId");
                    return String(e.actId);
                }
                if (e.type === s.RedDotType.UID_ACT_ID_GROUP_ID) {
                    if (!e.groupId) throw new Error("新版红点参数报错：" + e.code + "缺少redDotKey:groupId");
                    if (!e.actId) throw new Error("新版红点参数报错：" + e.code + "缺少redDotKey:actId");
                    return String(e.actId) + "-" + e.groupId;
                }
                if (e.type === s.RedDotType.UID_CUSTOM) {
                    if (!e.customKey) throw new Error("新版红点参数报错：" + e.code + "缺少redDotKey:customKey");
                    return e.customKey;
                }
            }, e.prototype.getBackAndCloudParam = function(e) {
                return {
                    wxCloudDotParams: e.filter(function(e) {
                        return e.code >= 1e3 && e.code < 2e3;
                    }),
                    backDotListParams: e.filter(function(e) {
                        return e.code < 1e3 || e.code >= 2e3;
                    })
                };
            }, e.prototype.catchErrorAndReportForGetDot = function(e) {
                return i.of([]);
            }, e.prototype.getStorageResAndNotStorageParam = function(e, t) {
                return {
                    storageRes: [],
                    notStorageParam: e
                };
            }, e.prototype.setStorageRedDotInfoFromGetFalse = function(e, t) {
                var r = e.cycleDay;
                this.monoUtil.isEmpty(r) && this.setStorageRedDotInfo(t);
            }, e.prototype.setStorageRedDotInfo = function(e) {
                var t, r, o, i = e.groupId, a = e.actId, s = e.type, u = e.customKey, c = this.getRedDotInfoStorageKey(i, a), l = ((t = {})[this.getStorageCode(e)] = {
                    code: e.code,
                    result: !1,
                    type: s,
                    groupId: i,
                    actId: a,
                    customKey: u
                }, t), d = (null === (r = this.wx) || void 0 === r ? void 0 : r.getStorageSync(c)) || {}, p = n.__assign(n.__assign({}, l), d);
                null === (o = this.wx) || void 0 === o || o.setStorageSync(c, p), this.serviceRedDotInfo[c] = p;
            }, e.prototype.getStorageRedDotInfo = function(e) {
                var t, r = e.groupId, n = e.actId, o = this.getRedDotInfoStorageKey(r, n), i = this.serviceRedDotInfo[o];
                if (i) return i || {};
                var a = (null === (t = this.wx) || void 0 === t ? void 0 : t.getStorageSync(o)) || {};
                return this.serviceRedDotInfo[o] = a, a;
            }, e.prototype.getRedDotInfoStorageKey = function(e, r) {
                return t.STORAGE_RED_DOT_INFO_KEY + (e ? "__" + e : "") + (r ? "__" + r : "");
            }, e.prototype.getStorageCode = function(e) {
                return e.type === s.RedDotType.UID_CUSTOM ? e.code + "_" + e.customKey : e.code;
            }, e = n.__decorate([ o.Injectable(), n.__metadata("design:paramtypes", [ u.MonoUtilService, c.TimeService, l.WxCloudApiService, d.WxCloudRedDotMigrateService ]) ], e);
        }();
        t.MonoRedDotService = p;
    },
    32: function(e, t, r) {
        var n;
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.AuditFollowSupplyLeaderStatus = t.FRONT_DETAIL_ERROR_TYPE = t.errText = t.PublishGoodsOptLimitEnum = t.ALLOW_FOLLOW_STATUS = t.LotterySeq = t.NotTradeSeq = t.TradeSeq = t.InteractiveSeq = t.TogetherBuyAction = t.ShortVideoState = t.SeqCopyType = t.SeqDisplayType = void 0, 
        function(e) {
            e[e.COMMON = 10] = "COMMON", e[e.SHORT_VIDEO = 20] = "SHORT_VIDEO", e[e.MALL = 30] = "MALL";
        }(t.SeqDisplayType || (t.SeqDisplayType = {})), function(e) {
            e[e.COMMON_COPY = 1] = "COMMON_COPY", e[e.SHARE_COPY = 2] = "SHARE_COPY", e[e.SEQ_TEMPLATE_COPY = 3] = "SEQ_TEMPLATE_COPY", 
            e[e.FOLLOW_COPY = 4] = "FOLLOW_COPY";
        }(t.SeqCopyType || (t.SeqCopyType = {})), function(e) {
            e[e.VIDEO_CHOOSING = 1] = "VIDEO_CHOOSING", e[e.VIDEO_NOT_INSERTED = 2] = "VIDEO_NOT_INSERTED", 
            e[e.VIDEO_INSERTED = 3] = "VIDEO_INSERTED";
        }(t.ShortVideoState || (t.ShortVideoState = {})), function(e) {
            e[e.INVITE = 10] = "INVITE", e[e.JOIN = 20] = "JOIN";
        }(t.TogetherBuyAction || (t.TogetherBuyAction = {})), t.InteractiveSeq = [ 40, 60, 70, 80, 200, 100, 170, 180, 190 ], 
        t.TradeSeq = [ 10, 20, 210, 150, 160, 30, 50, 110, 140, 120, 230, -50 ], t.NotTradeSeq = [ 90, 130, 220, -10, -60, 40, 60, 70, 80, 200, 100, 170, 180, 190 ], 
        t.LotterySeq = [ 220, 240, 250 ], function(e) {
            e[e.OPEN = 10] = "OPEN", e[e.CLOSE = 5] = "CLOSE";
        }(t.ALLOW_FOLLOW_STATUS || (t.ALLOW_FOLLOW_STATUS = {})), function(e) {
            e[e.NO_LIMIT = 1] = "NO_LIMIT", e[e.ADD_LIMIT = 2] = "ADD_LIMIT";
        }(t.PublishGoodsOptLimitEnum || (t.PublishGoodsOptLimitEnum = {})), t.errText = ((n = {})[5205] = "开团链接仅限团长访问", 
        n[5206] = "您还不是品牌商的团长，请联系品牌商邀请您加入", n[5207] = "您的加入申请已提交，品牌商审核中", n[5208] = "您未被加入开团范围，请联系品牌商修改设置", 
        n), function(e) {
            e.NOT_ACT_ID = "notActId", e.IS_NOT_TRADE = "isNotTrade";
        }(t.FRONT_DETAIL_ERROR_TYPE || (t.FRONT_DETAIL_ERROR_TYPE = {})), function(e) {
            e[e.NO_RELATIONSHIP = 0] = "NO_RELATIONSHIP", e[e.NEED_AUDIT = 10] = "NEED_AUDIT", 
            e[e.AUDIT = 20] = "AUDIT";
        }(t.AuditFollowSupplyLeaderStatus || (t.AuditFollowSupplyLeaderStatus = {}));
    },
    320: function(e, t, r) {
        var n, o;
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.HttpStatusCode2ErrorMsgMap = t.encryptCodeList = t.FrontEndCode2ErrorMsgMap = t.FrontEndBusinessCodeList = void 0, 
        t.FrontEndBusinessCodeList = [ 16888, 16444, 16234, 16889, 16544, 16555, 16556, 16557, 16560 ], 
        t.FrontEndCode2ErrorMsgMap = ((n = {})[16888] = "你不在当前活动的参与范围，请联系你的团长发送邀请", n[16444] = "您不在本次活动范围内", 
        n[16234] = "非常可惜，你不在本次活动的参与范围内", n[16889] = "主页处于保护期内，暂无法绑定新的关系，如需解除保护，请联系该主页对应选品团长", 
        n[16544] = "该活动存在风险，暂时无法查看，原因：活动发起人暂未实名认证", n[16555] = "抱歉，你没有参与该活动的权限", n[16556] = "您没有访问权限，可申请获得该活动的跟团权限", 
        n[16557] = "您没有访问权限，可申请获得该活动的跟团权限", n[16560] = "非常抱歉，当前活动因违背平台相关规定，已限制其访问能力，限制不影响订单售后权益，您也可以浏览其他活动，详情可咨询客服。", 
        n), t.encryptCodeList = [ 1700, 1701 ], t.HttpStatusCode2ErrorMsgMap = ((o = {})[429] = "活动太火爆啦！ 请稍后试试", 
        o);
    },
    321: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.DEFAULT_IMAGE_INFO = t.DEFAULT_IMAGE_HEIGHT = t.DEFAULT_IMAGE_WIDTH = void 0, 
        t.DEFAULT_IMAGE_WIDTH = 320, t.DEFAULT_IMAGE_HEIGHT = 240, t.DEFAULT_IMAGE_INFO = {
            width: t.DEFAULT_IMAGE_WIDTH,
            height: t.DEFAULT_IMAGE_HEIGHT
        };
    },
    322: function(e, t, r) {
        var n;
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.RedRotKey = void 0, t.RedRotKey = ((n = {})[5] = "isShowRankAnonymousRemindRedDot", 
        n[7] = "isShowGuideModalRedDot", n[19] = "isShowNoviciateQrcodeModal", n[32] = "isHiddenInviteTip", 
        n[36] = "isShowNewBrandGroupGuide", n[35] = "isNeedShowPublishLotteryWarningTip", 
        n[37] = "isShowPublishTypeLotteryGuide", n[38] = "isShowPublishTypeLotteryBubble", 
        n[41] = "isNeedShowLotteryFirstModalRedDot", n[102] = "isShowValidityReminderGuide", 
        n[62] = "isShowEvaluateIntro", n[66] = "isShowSaleOrderGrowthModalRedDot", n[54] = "isShowEntranceIntro", 
        n[67] = "isShowTogetherBuyProductGuide", n[64] = "isShowWriteEvaluationGuide", n[68] = "isShowNameCardInIMRedDot", 
        n[69] = "isShowPrintButtonShake", n[80] = "isShowPublishMultiLogisticsTip", n[79] = "isShowFreightListChargeByWeightGuide", 
        n[81] = "isShowHiddenEntranceTip", n[1e3] = "isShowSupplyGroupGuide", n[1001] = "isShowExclusiveProductGuide", 
        n[1002] = "isShowEvaluationMeetingGuide", n[1003] = "isShowSupplyLeaderPromoterIntroduce", 
        n[1005] = "isShowExclusiveProductListGuide", n[1007] = "isShowOrderManageMarqueeTip", 
        n[1014] = "isShowOrderManageMarqueeTipSupply", n[1008] = "isShowLeaderManageMarqueeTip", 
        n[1015] = "isShowLeaderManageMarqueeTipSupply", n[1011] = "isShowSignManageMarqueeTip", 
        n[1016] = "isShowSignManageMarqueeTipSupply", n[1017] = "isShowBalanceMarqueeTip", 
        n[1018] = "isShowBalanceMarqueeTipSupply", n[1020] = "isShowCollectHelpSaleSeqTips", 
        n[1021] = "isShowHistoryHelpSaleSeqTips", n[1024] = "isShowSeqDetailCollectionGuide", 
        n[1025] = "isShowBrandGoodsSpreadGuide", n[1023] = "isShowPublishAddProductIntro", 
        n[1033] = "isShowUnSendTips", n[1029] = "isShowCopyLinkTips", n[1034] = "isShowAutoReplyTips", 
        n[1039] = "isShowGroupHelpSellGuideModal", n[1036] = "isShowGuide", n[1037] = "isShowGuide", 
        n[1038] = "isShowGuide", n[1040] = "actSeparateParentRedDot", n[1041] = "actSeparateChildRedDot", 
        n[1042] = "isShowGuide", n[1043] = "isShowCopyOrderGuide", n[1045] = "isShowCopyRichTextTip", 
        n[1046] = "isShowRefundRemarkMigration", n[1047] = "isShowActStatisticDetailGuide", 
        n[1054] = "isShowCopySeqGuide", n[1050] = "isShowOneKeyDeliveryGuide", n[1051] = "isShowOneKeyDeliveryTabTips", 
        n[1055] = "isNeedShowSupplyBrandHomebackFrozen", n[1059] = "isShowLeaderFissionBackendTip", 
        n[1056] = "isShowSupplyBrandImGuide", n[1057] = "isShowSupplyLeaderImGuide", n[1049] = "isShowPriceLimitTips", 
        n[1061] = "isNeedShowSupplyLeaderHomebackFrozen", n[1062] = "isShowSupplyLeaderWaitThawPaymentTips", 
        n[1064] = "isShowEvaluationPriceTooltip", n[1065] = "isShowSeqMaterialLibraryHomeTip", 
        n[1070] = "isShowProductSourceGuide", n[1071] = "isShowReturnServiceChargeTip", 
        n[1074] = "isShowTryActTips", n[1081] = "isShowMaterialTip", n[1085] = "isShowAccountManagementPcGuide", 
        n[1084] = "isShowNoDeliveryNewTips", n[1083] = "canShowGoMyVoucherTip", n[1092] = "isTransitApplyStarIntroduce", 
        n[1086] = "isShowPublishStartGroupParentPaymentModeTips", n[1089] = "isShowBrandWaitThawCommissionTips", 
        n[1090] = "isShowBrandWaitThawCommissionTermSetGuide", n[1091] = "isShowBrandHomeBackWaitThawCommissionGuide", 
        n[1093] = "isShowBrandPublishWaitThawCommissionTip", n[1088] = "isShowModifyAdminWithdrawRightsModal", 
        n[1096] = "canLaunchHelpSellSearchModalNotice", n[1102] = "isShowExitReasonModal", 
        n[1103] = "isShowSortByLikeCountTips", n[1107] = "isShowNewOrderDetailCopyGuide", 
        n[1110] = "isShowInviteFollowRedDot", n[1109] = "isShowAfterSalesAuthorityTips", 
        n[1111] = "isShowFeeRebateNotice", n[1112] = "isShowFeeRebateDeadlineNotice", n[1114] = "isShowBackgroundCategoryHistoryGuide", 
        n[1115] = "isShowHelpLeaderHeadNewRevisionTips", n[1119] = "isShowNewLeaderFissionLeaderHelpTip", 
        n[1126] = "isShowFirstShareEntryAndRealName", n[1129] = "isNeedShowHomeSubjectAuthTips", 
        n[1130] = "isShowHomeFrontCategoryFilterTips", n[1131] = "isShowLaunchHelpSellCategoryFilterTips", 
        n[1129] = "isShowHomeSubjectAuthTips", n[1121] = "isShowShareAfterSalesDetailTips", 
        n[1122] = "isShowInviteAfterSalesAddInfoTips", n[1124] = "isShowAfterSalesAddInfoTips", 
        n[1097] = "isShowDraftBoxHeadTips", n[1123] = "isShowProductUnitSwitchTips", n[1139] = "isShowFollowSwitchRankGuide", 
        n[1133] = "isShowCustomerHomepageMyTips", n[1134] = "isShowCustomerHomepageMyAddressTips", 
        n[1135] = "isShowCustomerHomepageMyPhoneTips", n[1152] = "isShowGoodsRelatedCarriageTemplateTips", 
        n[1153] = "isShowGoodsRelatedCarriageTemplateNotice", n[1146] = "isShowViceOrderGuideTip", 
        n[1142] = "isShowSelfAndBrandClashNotice", n[1144] = "isShowPublishManagementStandardTips", 
        n[1149] = "isShowChangeNamePopup", n[1150] = "isShowNicknameTips", n[1161] = "isShowHomeBackendMaterialTips", 
        n[1165] = "isShowPaperworkMaterialTips", n[1166] = "isShowActivityMaterialTips", 
        n[1158] = "isShowDataAnalyseV2OverviewPageGuide", n[1159] = "isShowDataOverviewPageExplainModal", 
        n[1160] = "isShowQjlNewUserGuideModal", n[1162] = "isShowAdvertisement", n[1163] = "isShowWeComContactsImage", 
        n[1155] = "isShowServiceCommitmentTips", n[1157] = "isShowOrderTimeoutOrderCycleTips", 
        n[1164] = "isShowDetailSettingServiceCommitmentTips", n[1171] = "isShowOrderModifyAddressTips", 
        n[1176] = "isShowWithdrawLimitsTimesModal", n[1173] = "isClickSearchRegisterBanner", 
        n[1175] = "hasClickGuideModalHelpSaleBtn", n[1178] = "isShowBackgroundTips", n[2004] = "isShowAfterSalesAuthGuide", 
        n[1179] = "isShowHelpSaleSquareAndTryBuySquareEnterTip", n[2010] = "isShowLeaderHelpMoneyOffBubbles", 
        n[2011] = "isShowLeaderHelpMoneyOffTips", n[2006] = "isShowOrderAfterSalesAddressTips", 
        n[2007] = "isShowPublishAfterSalesAddressTips", n[2002] = "isShowFrontRevisionPopup", 
        n[2003] = "isShowFrontManageTip", n[2008] = "isShowNewTipOnTryBuySquaresTab", n[2009] = "isShowSignManageActTips", 
        n[2012] = "isShowImListAddViewDetailGuide", n[2015] = "isShowSeqPublishActClassify", 
        n[2013] = "isShowRankAnonymousMigrationTip", n[2014] = "isShowRankAddSalesDesensitizationTip", 
        n[2019] = "isShowSeqDetailPickupPointListTips", n[2021] = "isShowPickupPointAddHomeTips", 
        n[2018] = "isShowShippingNotifyTip", n[2022] = "isShowLaunchHelpSellFindGoodTip", 
        n[2023] = "isNeedShowCreditScoreOnlineModal", n[2024] = "isNeedShowCreditScoreChangeModal", 
        n[2026] = "isShowTellFriendIHaveSolitaireTip", n[2028] = "isShowLaunchHelpSellListMarqueeTip", 
        n[2031] = "isShowSupplyLeader2leaderCommissionSettingTips", n[2032] = "isShowBrandLeaderCommissionRenameTips", 
        n[2034] = "isShowHelpSaleSquareAndTryBuySquareEnterSpot", n[2036] = "isShowHomeBackToFrontButtonMoveTips", 
        n[2029] = "isShowDetailSubscribeTips", n[2030] = "isShowDetailRewardModalTips", 
        n[2035] = "isShowServiceCommitmentRequiredModalRedDot", n[2039] = "isShowHomeRecoverActsMoveTips", 
        n[2037] = "isShowDetailShareNewTips", n[2043] = "isShowDetailHideCommissionTips", 
        n[2044] = "isShowSeqRankListRedDot", n[2045] = "isShowMoreUnitFilterTip", n[2040] = "isShowPCPrintRefundGoodsTips", 
        n[2056] = "isShowSupplyBrandThawSettingTips", n[2057] = "isNeedShowSupplyBrandThawSettingModal", 
        n[2047] = "isShowGoodsRelateDlvNewTips", n[2050] = "showNewLeaderExclusiveBannerRedDot", 
        n[2053] = "isShowNewLeaderExclusiveLaunchEnterRedDot", n[2059] = "isShowStarLeaderDetailTips", 
        n[2060] = "isShowOrderExportStatusMiniTips", n[2061] = "isShowOrderExportStatusDefaultSelectTips", 
        n[2062] = "isShowOrderExportStatusCancelExportTips", n[2063] = "isShowOrderExportStatusScreenTips", 
        n[2068] = "isShowExclusiveListHelpSaleBtnTips", n[2069] = "isHomePageShowFollowedPublicAccount", 
        n[2070] = "isShowAllowGroupDeliverGoodsRedDot", n[2072] = "isNeedShowPublishLotteryParentWarningTip", 
        n[2073] = "isShowProductShowListBtnBubble", n[2074] = "isShowProductShowRedDot", 
        n[2076] = "isNeedShowPublishLotteryChildWarningTip", n[2075] = "isShowAfterSalesAddressModal", 
        n[2077] = "isShowSupplyBrandAfterSalesAddressRedDot", n[2079] = "isShowCanSetAfterSalesAddressTips", 
        n[2078] = "isShowGoodsCategorySearchTip", n[2080] = "isShowClassifyUpdateIntroModal", 
        n[2081] = "isShowRefundTypeNewIcon", n[2082] = "isShowChangePickPointBtnTips", n[2083] = "isShowAfterSaleAddressNewIcon", 
        n[2084] = "isShowStartChildGroupCreateSyncModal", n[2085] = "isShowSupplyFollowGroupCreateSyncModal", 
        n[2086] = "isShowSupplyChildOrLotteryGroupCreateSyncModal", n[2087] = "isShowStartGrandGroupCreateSyncModal", 
        n[2088] = "isShowStartGrandGroupEditSyncModal", n[2089] = "isShowSupplyFollowGroupEditSyncModal", 
        n[2090] = "isShowLotteryGroupEditSyncModal", n[2091] = "isShowSupplyChildGroupEditSyncModal", 
        n[2092] = "isShowRevisionNoticeOfSuperiorActivities", n[2093] = "isShowStartGroupParentSyncTips", 
        n[2094] = "isShowParentActSyncCommonTips", n[2098] = "isShowLongPressTip", n[2109] = "isShowPublishLeaderDynamicTip", 
        n[2103] = "isShowPCOrderMoreButtonTips", n[2105] = "isShowShowProductTips", n[2107] = "isShowFirstEditNegotiationRecordTip", 
        n[2108] = "isShowOrderMergeTips", n[2110] = "isShowAddAddressOptionTip", n[2113] = "isFirstResumeSubscribeToB", 
        n);
    },
    331: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.MQTTService = void 0;
        var n = r(0), o = r(1), i = r(107), a = r(332), s = r(333), u = r(7), c = r(3), l = r(811);
        n.__exportStar(r(333), t);
        var d = function() {
            function e(e) {
                this.httpClient = e, this.shouldReport = !0, this.apiURL = "", this.tokenUrl = "", 
                this.mqttClient = null, this.mqttInfo = null, this.rooms = new Map(), this.initClientSubject = new u.ReplaySubject(), 
                this.getTokenCount = 0, this.initializing = !1;
            }
            var t;
            return t = e, e.prototype.getMqttToken = function(e, t, r) {
                var n = this;
                return this.httpClient.post("" + this.tokenUrl, {}, {
                    hideErrorToast: !0,
                    isSkipPageMarking: !0,
                    isSkipDefaultLoginCheck: !0
                }).pipe(c.catchError(function(e) {
                    return e && 403 === e.code && "登录凭证不合法或已过期" === e.msg ? u.of({}) : u.throwError(e);
                }), c.filter(function(e) {
                    return !!e.data;
                }), c.retryWhen(function(e) {
                    return e.pipe(c.delay(2e3), c.take(5));
                }), c.tap(function(e) {
                    n.mqttLoginToken = e.data, n.getTokenCount = n.getTokenCount + 1;
                }), c.takeWhile(function() {
                    return n.getTokenCount < 5;
                }), c.switchMap(function(o) {
                    return e ? n.mqttHttpClientPost(e, t, r) : u.of(o);
                }));
            }, e.prototype.initMqtt = function() {
                var e = this;
                this.initializing || (this.initializing = !0, this.apiURL = t.apiURL, this.tokenUrl = t.tokenUrl, 
                this.getMqttToken().pipe(c.switchMap(function() {
                    return e.initClient();
                })).subscribe(function() {
                    e.keepRoomsAlive(), e.initClientSubject.next();
                }, void 0, function() {
                    return e.initializing = !1;
                }));
            }, e.prototype.destroyToken = function() {
                var e = this;
                return this.mqttHttpClientPost(this.apiURL + "/mqtt/revoke_token").pipe(c.map(function(t) {
                    return "SUCCESS" === t.result && (e.mqttInfo = null, e.mqttClient && e.mqttClient.end(), 
                    e.mqttClient = null), t;
                }));
            }, e.prototype.createSocket = function(e, t) {
                var r, n = this, o = new l.Socket(e, function() {
                    return n.removeSocketFromRoom(o);
                }), i = this.joinSocketToRoom(o);
                if (t && t.throttle) {
                    var a = 0;
                    r = o.pipe(c.filter(function(e, t) {
                        return a <= 600 && (a++, !0);
                    }), c.concatMap(function(e) {
                        return u.timer(t.throttle).pipe(c.mapTo(e));
                    }), c.tap(function() {
                        a--;
                    }), c.share());
                } else r = o.pipe(c.share());
                return r.leave = function() {
                    i && i.unsubscribe(), o.leave();
                }, r.exit = function() {
                    i && i.unsubscribe(), o.exit();
                }, r.room = e, r;
            }, e.prototype.initClient = function() {
                var e = this;
                return this.mqttHttpClientPost(this.apiURL + "/mqtt/apply_token", {}, {
                    hideErrorToast: !0
                }).pipe(c.map(function(e) {
                    var t = e.data;
                    if (!t) throw new Error("empty applyToken");
                    return {
                        mqttServerUrl: t.serverURI,
                        username: t.userName,
                        password: t.password,
                        token: t.token,
                        clientId: t.clientId,
                        expireTime: t.expireTime
                    };
                }), c.switchMap(function(t) {
                    return e.renewMQTTClient(t).pipe(c.map(function() {
                        if (!e.mqttClient) throw Error("has no mqttClient");
                        return e.mqttClient;
                    }));
                }), c.retryWhen(function(e) {
                    return e.pipe(c.mergeMap(function(e, t) {
                        return t < 5 ? u.timer(2e3) : u.throwError(e);
                    }));
                }));
            }, e.prototype.startRefreshToken = function() {
                var e = this;
                u.timer(this.aheadDurationOfTime(this.mqttInfo.expireTime)).pipe(c.takeWhile(function() {
                    return e.hasMQTTInfo();
                }), c.switchMap(function() {
                    return e.mqttHttpClientPost(e.apiURL + "/mqtt/refresh_token", {
                        clientId: e.mqttInfo.clientId,
                        body: {
                            clientId: e.mqttInfo.clientId
                        }
                    });
                }), c.tap(function(t) {
                    var r = t.data;
                    r ? (e.mqttInfo.expireTime = r.expireTime, e.mqttInfo.token = r.token, e.mqttInfo.username = r.userName, 
                    e.mqttInfo.password = r.password, r.clientId && (e.mqttInfo.clientId = r.clientId), 
                    e.renewMQTTClient(e.mqttInfo)) : setTimeout(function() {
                        throw new Error("mqtt刷新token失败");
                    });
                })).subscribe(function() {
                    e.startRefreshToken();
                });
            }, e.prototype.listenMessage = function() {
                var e = this;
                this.mqttClient.on("message", function(t, r) {
                    var o, i;
                    try {
                        var s = a.WorkerHelper.Utf8ArrayToStr(r), u = JSON.parse(s), c = u.room, l = e.rooms.get(c);
                        if (!l || 0 === l.length) return;
                        try {
                            for (var d = n.__values(l), p = d.next(); !p.done; p = d.next()) p.value.next(u.data);
                        } catch (e) {
                            o = {
                                error: e
                            };
                        } finally {
                            try {
                                p && !p.done && (i = d.return) && i.call(d);
                            } finally {
                                if (o) throw o.error;
                            }
                        }
                    } catch (e) {}
                });
            }, e.prototype.renewMQTTClient = function(e) {
                var r = this, o = !1, i = +new Date();
                this.mqttInfo = e;
                var a = "wxs://" + e.mqttServerUrl, l = {
                    clientId: e.clientId,
                    username: e.username,
                    password: e.password
                };
                if (this.mqttClient) return this.mqttClient.changeOptions(l), this.mqttClient.end(!0), 
                u.from(this.mqttClient.reconnect());
                var d = void 0;
                return t.MQTTDynamicLoadingConnector ? (o = !0, d = u.from(t.MQTTDynamicLoadingConnector(a, l))) : d = u.of(s.mqttConnect(a, l)), 
                d.pipe(c.tap(function(e) {
                    r.mqttClient = e, r.mqttClient.on("connect", function() {
                        return n.__awaiter(r, void 0, void 0, function() {
                            var e, t, r, a, s, u, c;
                            return n.__generator(this, function(l) {
                                o && this.shouldReport && (e = +new Date(), t = e - i, this.mqttConnectReports(t), 
                                this.shouldReport = !1), (0, console.warn)("MQTT 连接成功！");
                                try {
                                    for (r = n.__values(Array.from(this.rooms.keys())), a = r.next(); !a.done; a = r.next()) s = a.value, 
                                    this.joinRoom(s).subscribe();
                                } catch (e) {
                                    u = {
                                        error: e
                                    };
                                } finally {
                                    try {
                                        a && !a.done && (c = r.return) && c.call(r);
                                    } finally {
                                        if (u) throw u.error;
                                    }
                                }
                                return [ 2 ];
                            });
                        });
                    }), r.listenMessage(), r.mqttClient.on("error", function(e) {});
                }));
            }, e.prototype.mqttConnectReports = function(e) {
                [ {
                    device: "ios",
                    slowThreshold: 5e3
                }, {
                    device: "android",
                    slowThreshold: 2e3
                } ].forEach(function(r) {
                    var n = r.device, o = r.slowThreshold;
                    if (e > o) {
                        var i = "mqtt connect spend > " + o / 1e3 + "s";
                        t.monitor[n + "Avg"](i, e);
                    }
                    t.monitor[n + "Avg"]("mqtt connect spend", e);
                });
            }, e.prototype.keepRoomsAlive = function() {
                var e = this;
                u.interval(6e4).pipe(c.takeWhile(function() {
                    return e.hasMQTTInfo();
                })).subscribe(function() {
                    var t, r;
                    try {
                        for (var o = n.__values(Array.from(e.rooms.keys())), i = o.next(); !i.done; i = o.next()) {
                            var a = i.value;
                            e.joinRoom(a).subscribe();
                        }
                    } catch (e) {
                        t = {
                            error: e
                        };
                    } finally {
                        try {
                            i && !i.done && (r = o.return) && r.call(o);
                        } finally {
                            if (t) throw t.error;
                        }
                    }
                });
            }, e.prototype.joinSocketToRoom = function(e) {
                var t, r = e.roomName, n = this.rooms.get(r);
                return n || (n = [], t = this.joinRoom(e.roomName).subscribe()), n.push(e), this.rooms.set(r, n), 
                t;
            }, e.prototype.removeSocketFromRoom = function(e) {
                var t = e.roomName, r = this.rooms.get(t);
                if (r) {
                    var n = r.findIndex(function(t) {
                        return t === e;
                    });
                    n < 0 || (r.splice(n, 1), 0 === r.length && (this.rooms.delete(t), this.leaveRoom(e.roomName).subscribe()));
                }
            }, e.prototype.joinRoom = function(e) {
                var t = this;
                return this.initClientSubject.pipe(c.switchMap(function() {
                    return t.hasMQTTInfo() ? t.mqttHttpClientPost(t.apiURL + "/mqtt/join_room?r=" + Math.random(), {
                        body: {
                            clientId: t.mqttInfo.clientId,
                            room: e
                        }
                    }) : u.of();
                }));
            }, e.prototype.leaveRoom = function(e) {
                return this.hasMQTTInfo() ? this.mqttHttpClientPost(this.apiURL + "/mqtt/user_exit_room", {
                    body: {
                        clientId: this.mqttInfo.clientId,
                        room: e
                    }
                }) : u.of();
            }, e.prototype.aheadDurationOfTime = function(e) {
                return Math.floor(.9 * (e - +new Date()));
            }, e.prototype.hasMQTTInfo = function() {
                return !!(this.mqttInfo && this.mqttInfo.token && this.mqttInfo.clientId);
            }, e.prototype.mqttHttpClientPost = function(e, t, r) {
                var n = this, o = {
                    "Mqtt-Auth": this.mqttLoginToken
                };
                return r ? r && !r.headers ? r.headers = o : Object.assign(r.headers, o) : r = {
                    headers: o
                }, r.isSkipDefaultLoginCheck = !0, r.isSkipPageMarking = !0, r.hideErrorToast = !0, 
                this.httpClient.post(e, t, r).pipe(this.catchMqttLoginError(e, t, r), c.tap(function() {
                    return n.getTokenCount = 0;
                }));
            }, e.prototype.catchMqttLoginError = function(e, t, r) {
                var n = this;
                return c.catchError(function(o) {
                    return 401 === o.code ? n.getMqttToken(e, t, r) : u.throwError({
                        mqttErrMsg: o.msg || "mqtt统一error",
                        code: o.code
                    });
                });
            }, e.apiURL = "", e.tokenUrl = "", e.MQTTDynamicLoadingConnector = null, e = t = n.__decorate([ o.Injectable(), n.__metadata("design:paramtypes", [ i.ShareHttpClient ]) ], e);
        }();
        t.MQTTService = d;
    },
    332: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.WorkerHelper = void 0;
        var n = r(0), o = function() {
            function e() {}
            return e.deepObjectForEachKey = function(t, r, o, i) {
                void 0 === i && (i = !1);
                var a = function(t) {
                    return "Object" === e.getType(t) || Array.isArray(t);
                };
                if (a(t)) Object.keys(t).forEach(function(s) {
                    var u = t[s], c = n.__spread(o, [ s ]);
                    a(u) ? e.deepObjectForEachKey(u, r, c.slice()) : r(u, c.slice(), i) && delete t[s];
                }); else {
                    var s = o.slice();
                    r(t, s, i) && delete t[s[0]];
                }
            }, e.getType = function(e) {
                var t = Object.prototype.toString.call(e);
                return t.substring(8, t.length - 1);
            }, e.Utf8ArrayToStr = function(e) {
                for (var t, r, n, o = "", i = 0, a = e.length; i < a; ) switch ((n = e[i++]) >> 4) {
                  case 0:
                  case 1:
                  case 2:
                  case 3:
                  case 4:
                  case 5:
                  case 6:
                  case 7:
                    o += String.fromCharCode(n);
                    break;

                  case 12:
                  case 13:
                    t = e[i++], o += String.fromCharCode((31 & n) << 6 | 63 & t);
                    break;

                  case 14:
                    t = e[i++], r = e[i++], o += String.fromCharCode((15 & n) << 12 | (63 & t) << 6 | (63 & r) << 0);
                }
                return o;
            }, e.spyClient = function(t, r) {
                Object.keys(t).forEach(function(n) {
                    var o = t[n];
                    "function" == typeof o ? Object.defineProperty(t, n, {
                        value: function() {
                            for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
                            r.sendMessage("callMqttClient", {
                                name: n,
                                args: e
                            });
                        }
                    }) : "Object" === e.getType(o) && e.spyClient(o, r);
                });
            }, e;
        }();
        t.WorkerHelper = o;
    },
    333: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.mqttConnect = t.AsyncClient = void 0;
        var n = r(0), o = r(810), i = function(e, t) {
            return function(r, n) {
                r ? t(r) : e(n);
            };
        }, a = function() {
            function e(e) {
                this.mqttClient = e;
            }
            return Object.defineProperty(e.prototype, "handleMessage", {
                get: function() {
                    return this.mqttClient.handleMessage;
                },
                set: function(e) {
                    this.mqttClient.handleMessage = e;
                },
                enumerable: !1,
                configurable: !0
            }), Object.defineProperty(e.prototype, "connected", {
                get: function() {
                    return this.mqttClient.connected;
                },
                enumerable: !1,
                configurable: !0
            }), e.prototype.changeOptions = function(e) {
                Object.assign(this.mqttClient.mqttClient.options || {}, e);
            }, e.prototype.publish = function() {
                for (var e = this, t = [], r = 0; r < arguments.length; r++) t[r] = arguments[r];
                return new Promise(function(r, o) {
                    var a;
                    (a = e.mqttClient).publish.apply(a, n.__spread(t, [ i(r, o) ]));
                });
            }, e.prototype.subscribe = function() {
                for (var e = this, t = [], r = 0; r < arguments.length; r++) t[r] = arguments[r];
                return new Promise(function(r, o) {
                    var a;
                    (a = e.mqttClient).subscribe.apply(a, n.__spread(t, [ i(r, o) ]));
                });
            }, e.prototype.unsubscribe = function() {
                for (var e = this, t = [], r = 0; r < arguments.length; r++) t[r] = arguments[r];
                return new Promise(function(r, o) {
                    var a;
                    (a = e.mqttClient).unsubscribe.apply(a, n.__spread(t, [ i(r, o) ]));
                });
            }, e.prototype.end = function() {
                for (var e = this, t = [], r = 0; r < arguments.length; r++) t[r] = arguments[r];
                return new Promise(function(r, o) {
                    var a;
                    (a = e.mqttClient).end.apply(a, n.__spread(t, [ i(r, o) ]));
                });
            }, e.prototype.reconnect = function() {
                for (var e = this, t = [], r = 0; r < arguments.length; r++) t[r] = arguments[r];
                return new Promise(function(r, o) {
                    var a;
                    (a = e.mqttClient).reconnect.apply(a, n.__spread(t, [ i(r, o) ]));
                });
            }, e.prototype.addListener = function() {
                for (var e, t = [], r = 0; r < arguments.length; r++) t[r] = arguments[r];
                return (e = this.mqttClient).addListener.apply(e, n.__spread(t));
            }, e.prototype.emit = function() {
                for (var e, t = [], r = 0; r < arguments.length; r++) t[r] = arguments[r];
                return (e = this.mqttClient).emit.apply(e, n.__spread(t));
            }, e.prototype.eventNames = function() {
                for (var e, t = [], r = 0; r < arguments.length; r++) t[r] = arguments[r];
                return (e = this.mqttClient).eventNames.apply(e, n.__spread(t));
            }, e.prototype.getMaxListeners = function() {
                for (var e, t = [], r = 0; r < arguments.length; r++) t[r] = arguments[r];
                return (e = this.mqttClient).getMaxListeners.apply(e, n.__spread(t));
            }, e.prototype.listenerCount = function() {
                for (var e, t = [], r = 0; r < arguments.length; r++) t[r] = arguments[r];
                return (e = this.mqttClient).listenerCount.apply(e, n.__spread(t));
            }, e.prototype.listeners = function() {
                for (var e, t = [], r = 0; r < arguments.length; r++) t[r] = arguments[r];
                return (e = this.mqttClient).listeners.apply(e, n.__spread(t));
            }, e.prototype.off = function() {
                for (var e, t = [], r = 0; r < arguments.length; r++) t[r] = arguments[r];
                return (e = this.mqttClient).off.apply(e, n.__spread(t));
            }, e.prototype.on = function() {
                for (var e, t = [], r = 0; r < arguments.length; r++) t[r] = arguments[r];
                return (e = this.mqttClient).on.apply(e, n.__spread(t));
            }, e.prototype.once = function() {
                for (var e, t = [], r = 0; r < arguments.length; r++) t[r] = arguments[r];
                return (e = this.mqttClient).once.apply(e, n.__spread(t));
            }, e.prototype.prependListener = function() {
                for (var e, t = [], r = 0; r < arguments.length; r++) t[r] = arguments[r];
                return (e = this.mqttClient).prependListener.apply(e, n.__spread(t));
            }, e.prototype.prependOnceListener = function() {
                for (var e, t = [], r = 0; r < arguments.length; r++) t[r] = arguments[r];
                return (e = this.mqttClient).prependOnceListener.apply(e, n.__spread(t));
            }, e.prototype.removeAllListeners = function() {
                for (var e, t = [], r = 0; r < arguments.length; r++) t[r] = arguments[r];
                return (e = this.mqttClient).removeAllListeners.apply(e, n.__spread(t));
            }, e.prototype.removeListener = function() {
                for (var e, t = [], r = 0; r < arguments.length; r++) t[r] = arguments[r];
                return (e = this.mqttClient).removeListener.apply(e, n.__spread(t));
            }, e.prototype.setMaxListeners = function() {
                for (var e, t = [], r = 0; r < arguments.length; r++) t[r] = arguments[r];
                return (e = this.mqttClient).setMaxListeners.apply(e, n.__spread(t));
            }, e.prototype.rawListeners = function() {
                for (var e, t = [], r = 0; r < arguments.length; r++) t[r] = arguments[r];
                return (e = this.mqttClient).rawListeners.apply(e, n.__spread(t));
            }, e;
        }();
        t.AsyncClient = a, t.mqttConnect = function(e, t) {
            var r = o.connect(e, t);
            return new a(r);
        };
    },
    35: function(e, t, r) {
        var n, o;
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.InitialActionsType = t.prefix2UserType = t.userType2Prefix = t.SYSTEM_TIM_ID_NUMBER = t.SYSTEM_TIM_ID = t.RelationStatus = t.InviteBuildRelationshipTypeEnum = t.SeqRankListTabType = t.CommonCardActionType = t.ChatType = t.NoticeType = t.ReplyType = t.EvaluationMessageType = t.SuperLinkActionType = t.TipsContentType = t.LoginStatus = void 0, 
        function(e) {
            e[e.OUT_LINE = 0] = "OUT_LINE", e[e.ON_LINE = 1] = "ON_LINE";
        }(t.LoginStatus || (t.LoginStatus = {})), function(e) {
            e[e.TEXT = 0] = "TEXT", e[e.LINK = 1] = "LINK", e[e.FROM_GROUP_NAME = 2] = "FROM_GROUP_NAME", 
            e[e.LINK_AREA = 3] = "LINK_AREA", e[e.SUPER_LINK = 4] = "SUPER_LINK", e[e.TO_GROUP_NAME = 5] = "TO_GROUP_NAME";
        }(t.TipsContentType || (t.TipsContentType = {})), function(e) {
            e[e.SEND_MESSAGE = 10] = "SEND_MESSAGE", e[e.EVALUATE_LEADER = 20] = "EVALUATE_LEADER";
        }(t.SuperLinkActionType || (t.SuperLinkActionType = {})), function(e) {
            e[e.POTENTIAL_BE_STAR = 10] = "POTENTIAL_BE_STAR";
        }(t.EvaluationMessageType || (t.EvaluationMessageType = {})), function(e) {
            e[e.GREETING = 10] = "GREETING", e[e.QUESTION = 20] = "QUESTION";
        }(t.ReplyType || (t.ReplyType = {})), function(e) {
            e.NOTIFICATION_OPTION = "inform users to set customer service notification", e.CUSTOM = "any other notice", 
            e.NO_BACKGROUND = "noBg";
        }(t.NoticeType || (t.NoticeType = {})), function(e) {
            e[e.IMG = 0] = "IMG", e[e.TEXT = 1] = "TEXT", e[e.VIDEO = 2] = "VIDEO", e[e.RADIO = 3] = "RADIO", 
            e[e.VOUCHER = 4] = "VOUCHER", e[e.ACTIVITY = 5] = "ACTIVITY", e[e.WAIT_SEND_VOUCHER = 6] = "WAIT_SEND_VOUCHER", 
            e[e.WAIT_SEND_ACTIVITY = 7] = "WAIT_SEND_ACTIVITY", e[e.NOTICE = 8] = "NOTICE", 
            e[e.GUIDE_TIPS = 9] = "GUIDE_TIPS", e[e.BRAND_CARD = 10] = "BRAND_CARD", e[e.LEADER_CARD = 11] = "LEADER_CARD", 
            e[e.COURSE_CARD = 12] = "COURSE_CARD", e[e.FAST_REPLY = 13] = "FAST_REPLY", e[e.GROUP_CARD = 14] = "GROUP_CARD", 
            e[e.IMG_LIST = 15] = "IMG_LIST", e[e.CANCEL_SEQ_CARD = 16] = "CANCEL_SEQ_CARD", 
            e[e.BUBBLE_ERROR = 17] = "BUBBLE_ERROR", e[e.CARD_ERROR = 18] = "CARD_ERROR", e[e.NEW_ACTIVITY = 19] = "NEW_ACTIVITY", 
            e[e.SEQ_GAME = 20] = "SEQ_GAME", e[e.CUSTOM_TEXT = 21] = "CUSTOM_TEXT", e[e.TODAY_BEST_SELLERS = 22] = "TODAY_BEST_SELLERS", 
            e[e.DAILY_DATA_REPORT = 23] = "DAILY_DATA_REPORT", e[e.HELP_SALE_ACTIVITY = 24] = "HELP_SALE_ACTIVITY", 
            e[e.CREATE_LEADER_AD_CARD = 25] = "CREATE_LEADER_AD_CARD", e[e.STAR_LEADER_COMMUNITY_CARD = 26] = "STAR_LEADER_COMMUNITY_CARD", 
            e[e.JOIN_WECHAT_GROUP_CARD = 27] = "JOIN_WECHAT_GROUP_CARD", e[e.NAME_CARD = 28] = "NAME_CARD", 
            e[e.COMMON_CARD = 29] = "COMMON_CARD", e[e.DELETE_INVALID_LEADER_CARD = 30] = "DELETE_INVALID_LEADER_CARD", 
            e[e.HAS_AUTO_DELETE_CARD = 31] = "HAS_AUTO_DELETE_CARD", e[e.IM_EVALUATION_CARD = 32] = "IM_EVALUATION_CARD", 
            e[e.AFTER_SALE_ORDER_CARD = 33] = "AFTER_SALE_ORDER_CARD", e[e.HELP_SALE_NOTICE_CARD = 34] = "HELP_SALE_NOTICE_CARD", 
            e[e.SEQ_RANKING_CARD = 35] = "SEQ_RANKING_CARD", e[e.INVITE_BUILD_RELATIONSHIP = 36] = "INVITE_BUILD_RELATIONSHIP", 
            e[e.RICH_TEXT_CARD = 37] = "RICH_TEXT_CARD", e[e.NEW_RECOMMEND_CARD = 38] = "NEW_RECOMMEND_CARD", 
            e[e.NONE = 99999] = "NONE";
        }(t.ChatType || (t.ChatType = {})), function(e) {
            e[e.VIEW_IMAGE = 1] = "VIEW_IMAGE", e[e.NAV = 2] = "NAV";
        }(t.CommonCardActionType || (t.CommonCardActionType = {})), function(e) {
            e[e.HOT_SALE_LIST = 10] = "HOT_SALE_LIST", e[e.REPURCHASE_LIST = 20] = "REPURCHASE_LIST", 
            e[e.CONVERSION_LIST = 30] = "CONVERSION_LIST";
        }(t.SeqRankListTabType || (t.SeqRankListTabType = {})), function(e) {
            e.INVITE_SUPPLY = "inviteSupply", e.INVITE_SALE = "inviteHelp";
        }(t.InviteBuildRelationshipTypeEnum || (t.InviteBuildRelationshipTypeEnum = {})), 
        function(e) {
            e[e.NO = 0] = "NO", e[e.BECAME_LEADER = 1] = "BECAME_LEADER", e[e.WAITING_AUDIT = 3] = "WAITING_AUDIT", 
            e[e.REFUND = 5] = "REFUND";
        }(t.RelationStatus || (t.RelationStatus = {})), t.SYSTEM_TIM_ID = "o_0", t.SYSTEM_TIM_ID_NUMBER = "0", 
        t.userType2Prefix = ((n = {})[1] = "g", n[2] = "o", n[0] = "u", n[3] = "g", n[4] = "o", 
        n), t.prefix2UserType = ((o = {})[t.userType2Prefix[1]] = 1, o[t.userType2Prefix[2]] = 2, 
        o[t.userType2Prefix[0]] = 0, o), (t.InitialActionsType || (t.InitialActionsType = {})).FIND_HOT_GOODS = "findHotGoods";
    },
    38: function(e, t, r) {
        var n, o, i, a, s, u, c, l, d, p, f, h, S, _;
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.refundTypeConfigEnum2RefundType = t.RefundTypeConfigEnum = t.AsSearchType = t.OrderExportStatusOptionList = t.orderExportStatusMap = t.LogisticsTextStatusList = t.logisticsPushStatusList = t.tradeStatusTextMap = t.TRADE_STATUS = t.ORDER_TAGS_LEADER_VAL = t.DeliveryDeadlineTextTypeList = t.OPERATE_ORDER_LIMIT_NUM = t.AfterSalesInfoLabel = t.UserAddrDefaultStatus = t.RefundTextStatusList = t.afterSaleStatusTextMap = t.OrderOperationStyle = t.AfterSalesRoleText = t.AfterSalesRole = t.afterSaleTypeMap = t.AfterSaleReturnTextStatusList = t.afterSaleReturnStatusMap = t.AfterSalesTextTypeList = t.itemInfoTab = t.pickUpTimeTab = t.logisticsWayTab = t.LogisticsWay = t.TRY_ORDER = t.EditLogisticMode = t.LogisticsDimension = t.OrderLogisticsStatusDescription = t.OrderLogisticsStatus = t.LotteryOrderStatusMap = t.LotteryOrderStatus = t.VoucherParam = t.CancelBtnType = void 0, 
        function(e) {
            e[e.NONE = 0] = "NONE", e[e.CANCEL_SEQUENCE = 1] = "CANCEL_SEQUENCE", e[e.APPLY_REFUND = 2] = "APPLY_REFUND", 
            e[e.APPLY_CANCEL_SEQUENCE = 3] = "APPLY_CANCEL_SEQUENCE", e[e.APPLY_CANCEL_SEQUENCE_MARKET = 4] = "APPLY_CANCEL_SEQUENCE_MARKET", 
            e[e.CANCEL_SEQUENCE_ELECT = 5] = "CANCEL_SEQUENCE_ELECT";
        }(t.CancelBtnType || (t.CancelBtnType = {})), t.VoucherParam = ((n = {})[10] = "openGroupOrderCertificateInfo", 
        n[20] = "openGroupOrderCertificateInfo", n[210] = "openGroupGrandsonOrderCertificateInfo", 
        n[30] = "groupBuyOrderCertificateInfo", n[40] = "signUpOrderCertificateInfo", n[50] = "joinGroupOrderCertificateInfo", 
        n[60] = "interactiveOrderCertificateInfo", n[70] = "readOrderCertificateInfo", n[80] = "selectionOrderCertificateInfo", 
        n[90] = "feeOrderCertificateInfo", n[110] = "cooperationBuyOrderCertifiacteInfo", 
        n[120] = "marketOrderCertificateInfo", n[140] = "festivalCooperationOrderCertificateInfo", 
        n[150] = "groupsHelpSaleCertificateInfo", n[160] = "groupsHelpSaleCertificateInfo", 
        n[200] = "chartOrderCertificateInfo", n[220] = "lotteryOrderCertificateInfo", n[230] = "evaluationOrderCertificateInfo", 
        n[250] = "lotteryFissionOrderCertificateInfo", n), function(e) {
            e[e.LOSE = 0] = "LOSE", e[e.WIN = 10] = "WIN", e[e.WAIT_OPEN = 30] = "WAIT_OPEN";
        }(f = t.LotteryOrderStatus || (t.LotteryOrderStatus = {})), t.LotteryOrderStatusMap = ((o = {})[f.WAIT_OPEN] = "待开奖", 
        o[f.LOSE] = "未中奖", o[f.WIN] = "已中奖", o), function(e) {
            e[e.UNSEND = 10] = "UNSEND", e[e.PARTIAL_SEND = 15] = "PARTIAL_SEND", e[e.SENT = 20] = "SENT";
        }(h = t.OrderLogisticsStatus || (t.OrderLogisticsStatus = {})), t.OrderLogisticsStatusDescription = ((i = {})[h.UNSEND] = "待发货", 
        i[h.PARTIAL_SEND] = "部分发货", i[h.SENT] = "已发货", i), function(e) {
            e[e.ORDER = 10] = "ORDER", e[e.PRODUCT = 20] = "PRODUCT";
        }(t.LogisticsDimension || (t.LogisticsDimension = {})), function(e) {
            e[e.CREATE = 1] = "CREATE", e[e.ADD = 2] = "ADD", e[e.EDIT = 3] = "EDIT";
        }(t.EditLogisticMode || (t.EditLogisticMode = {})), t.TRY_ORDER = 10, function(e) {
            e[e.SF_SUPER = 1] = "SF_SUPER", e[e.SF_STANDARD = 2] = "SF_STANDARD", e[e.SF_EXPRESS = 3] = "SF_EXPRESS";
        }(t.LogisticsWay || (t.LogisticsWay = {})), t.logisticsWayTab = {
            title: "快递服务",
            operateName: "handleTapLogisticsWay"
        }, t.pickUpTimeTab = {
            title: "取件时间",
            operateName: "handleTapPickUpTime"
        }, t.itemInfoTab = {
            title: "物品信息",
            operateName: "handleTapItemInfo"
        }, t.AfterSalesTextTypeList = [ {
            label: "仅退款",
            value: 1
        }, {
            label: "退款退货",
            value: 2
        } ], t.afterSaleReturnStatusMap = ((a = {})[-1] = "全部", a[10] = "待寄回", a[20] = "待签收", 
        a[30] = "已签收", a[0] = "其他", a), t.AfterSaleReturnTextStatusList = [ {
            label: t.afterSaleReturnStatusMap[20],
            value: 20
        }, {
            label: t.afterSaleReturnStatusMap[30],
            value: 30
        } ], t.afterSaleTypeMap = ((s = {})[0] = "全部", s[1] = "仅退款", s[2] = "退货退款", s), 
        function(e) {
            e[e.UN_KNOW = 0] = "UN_KNOW", e[e.SOURCE_OF_GOODS = 10] = "SOURCE_OF_GOODS", e[e.MIDDLEMAN_SOURCE = 20] = "MIDDLEMAN_SOURCE", 
            e[e.MIDDLEMAN_FOLLOW = 21] = "MIDDLEMAN_FOLLOW", e[e.MIDDLEMAN_START = 22] = "MIDDLEMAN_START", 
            e[e.MIDDLEMAN_SELLER = 30] = "MIDDLEMAN_SELLER", e[e.CUSTOMER = 40] = "CUSTOMER", 
            e[e.GRANT = 50] = "GRANT";
        }(t.AfterSalesRole || (t.AfterSalesRole = {})), function(e) {
            e.SOURCE_OF_GOODS = "供货商", e.GRANT = "团长", e.MIDDLEMAN = "团长", e.MIDDLEMAN_SELLER = "团长", 
            e.MIDDLEMAN_SOURCE = "团长", e.CUSTOMER = "顾客", e.ME = "我";
        }(t.AfterSalesRoleText || (t.AfterSalesRoleText = {})), function(e) {
            e.NORMAL_BTN = "grey-border border-line-pixel", e.PRIMARY_BTN = "green", e.PRIMARY_LINER_BTN = "border-line-pixel", 
            e.DANGER_LINER_BTN = "red-border border-line-pixel";
        }(t.OrderOperationStyle || (t.OrderOperationStyle = {})), t.afterSaleStatusTextMap = ((u = {})[10] = "团长处理中", 
        u[20] = "用户处理中", u[30] = "团长拒绝", u[40] = "团长拒绝", u[50] = "团长拒绝", u[60] = "用户撤销", 
        u[61] = "用户撤销", u[100] = "退款成功", u[110] = "用户确认", u[120] = "售后成功", u), t.RefundTextStatusList = [ {
            label: "全额退款",
            value: 20
        }, {
            label: "部分退款",
            value: 10
        }, {
            label: "未退款",
            value: 0
        } ], function(e) {
            e[e.NO = 0] = "NO", e[e.YES = 1] = "YES";
        }(t.UserAddrDefaultStatus || (t.UserAddrDefaultStatus = {})), t.AfterSalesInfoLabel = ((c = {}).TYPE = "售后类型", 
        c.APPLY_REFUND_AMOUNT = "申请退款金额", c.REAL_REFUND_AMOUNT = "已退金额", c.ORDER_TIME = "接龙时间", 
        c.ACT_ORDER_NUMBER = "接龙号", c.USER_NAME = "顾客昵称", c.ORDER_NUMBER = "订单号", c.ORDER_STATUS = "订单状态", 
        c.CARRIAGE_INFO = "快递信息", c.RECEIPT_INFO = "收货信息", c.AFTER_SALES_REASON = "售后原因", 
        c.APPLY_AFTER_SALES_TIME = "申请时间", c.DLV_NAME = "自提点信息", c.LINK_INFO = "联系信息", c.REMARK = "备注", 
        c.SUPPLIER = "供货商", c.HELP_SALE_LEADER = "帮卖团长", c.SUPPLY_LEADER = "选品团长", c.ORDER_TOTAL_FEE = "订单总金额", 
        c.ORDER_TOTAL_REFUND_FEE = "总退款金额", c), t.OPERATE_ORDER_LIMIT_NUM = 1e4, t.DeliveryDeadlineTextTypeList = [ {
            label: "已超时",
            value: 10
        }, {
            label: "即将超时",
            value: 11
        } ], function(e) {
            e[e.ALL = 0] = "ALL", e[e.HAS_BEEN_CANCEL = 20] = "HAS_BEEN_CANCEL", e[e.REFUNDS_MADE = 30] = "REFUNDS_MADE", 
            e[e.NOTES = 40] = "NOTES", e[e.REFUNDS_FAIL = 50] = "REFUNDS_FAIL", e[e.REFUNDS_WAIT = 60] = "REFUNDS_WAIT", 
            e[e.LEADER_REJECTED = 70] = "LEADER_REJECTED", e[e.REJECTED = 80] = "REJECTED", 
            e[e.TOTAL_REJECT = 150] = "TOTAL_REJECT", e[e.UNSEND = 110] = "UNSEND", e[e.SENT = 120] = "SENT", 
            e[e.UN_SHOW = -99] = "UN_SHOW";
        }(t.ORDER_TAGS_LEADER_VAL || (t.ORDER_TAGS_LEADER_VAL = {})), function(e) {
            e[e.TRANSACTION_NOT_COMPLETED = 0] = "TRANSACTION_NOT_COMPLETED", e[e.TRANSACTION_COMPLETED = 1] = "TRANSACTION_COMPLETED", 
            e[e.IN_AFTER_SALES = 2] = "IN_AFTER_SALES";
        }(S = t.TRADE_STATUS || (t.TRADE_STATUS = {})), t.tradeStatusTextMap = ((l = {})[S.TRANSACTION_NOT_COMPLETED] = "交易未完成", 
        l[S.TRANSACTION_COMPLETED] = "交易完成", l[S.IN_AFTER_SALES] = "售后中", l), t.logisticsPushStatusList = [ {
            label: "揽收",
            value: 10
        }, {
            label: "在途",
            value: 20
        }, {
            label: "派件",
            value: 30
        }, {
            label: "签收",
            value: 40
        }, {
            label: "退回/转投/清关",
            value: 50
        }, {
            label: "派签异常",
            value: 60
        }, {
            label: "长时间未揽收",
            value: 70
        }, {
            label: "其他异常",
            value: 80
        } ], t.LogisticsTextStatusList = [ {
            label: "揽收",
            value: 10
        }, {
            label: "在途",
            value: 20
        }, {
            label: "派件",
            value: 30
        }, {
            label: "签收",
            value: 40
        }, {
            label: "退回/转投/清关",
            value: 50
        }, {
            label: "派签异常",
            value: 60
        }, {
            label: "长时间待揽收",
            value: 70
        }, {
            label: "其他异常",
            value: 80
        } ], t.orderExportStatusMap = ((d = {})[20] = "已导单", d[30] = "已撤单", d[10] = "未导单", 
        d), t.OrderExportStatusOptionList = [ 20, 30, 10 ].map(function(e) {
            return {
                label: t.orderExportStatusMap[e],
                value: e
            };
        }), function(e) {
            e[e.HOMEPAGE = 10] = "HOMEPAGE", e[e.ACTIVITY = 20] = "ACTIVITY";
        }(t.AsSearchType || (t.AsSearchType = {})), function(e) {
            e[e.NONE = 0] = "NONE", e[e.RETURN_MONEY_AND_GOODS = 10] = "RETURN_MONEY_AND_GOODS", 
            e[e.RETURN_MONEY = 20] = "RETURN_MONEY";
        }(_ = t.RefundTypeConfigEnum || (t.RefundTypeConfigEnum = {})), t.refundTypeConfigEnum2RefundType = ((p = {})[_.NONE] = 2, 
        p[_.RETURN_MONEY_AND_GOODS] = 0, p[_.RETURN_MONEY] = 1, p);
    },
    41: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.RED_DOT_CONFIG_VERSION = t.RED_DOT_STORAGE_KEY = t.RedDotSource = t.RedDotType = void 0, 
        function(e) {
            e[e.UID = 10] = "UID", e[e.UID_GROUP_ID = 20] = "UID_GROUP_ID", e[e.UID_ACT_ID = 30] = "UID_ACT_ID", 
            e[e.UID_ACT_ID_GROUP_ID = 40] = "UID_ACT_ID_GROUP_ID", e[e.UID_CUSTOM = 50] = "UID_CUSTOM";
        }(t.RedDotType || (t.RedDotType = {})), function(e) {
            e[e.WX_CLOUD = 1] = "WX_CLOUD", e[e.BACK_END = 2] = "BACK_END", e[e.FRONT_STORE = 3] = "FRONT_STORE";
        }(t.RedDotSource || (t.RedDotSource = {})), t.RED_DOT_STORAGE_KEY = "RED_DOT_STORAGE_KEY_V2", 
        t.RED_DOT_CONFIG_VERSION = "RED_DOT_CONFIG_VERSION";
    },
    416: function(t, r, n) {
        function o(e) {
            return "function" == typeof e;
        }
        function i(t) {
            t && t.isSkipReport || setTimeout(function() {
                if (!t || -1 !== t.code && 403 !== t.code) {
                    try {
                        t ? "object" != (void 0 === t ? "undefined" : e(t)) ? t = new Error(t) : t instanceof Error || (t = new Error(JSON.stringify(t))) : t = new Error("报错信息为空");
                    } catch (e) {
                        t = new Error("序列化报错信息失败");
                    }
                    throw t.message = "rxjs抛出的错误:" + (t.message || ""), t;
                }
            });
        }
        function a(t) {
            return null !== t && "object" == (void 0 === t ? "undefined" : e(t));
        }
        function s(e) {
            return e.reduce(function(e, t) {
                return e.concat(t instanceof Q ? t.errors : t);
            }, []);
        }
        function u() {}
        function c(e) {
            return e ? 1 === e.length ? e[0] : function(t) {
                return e.reduce(function(e, t) {
                    return t(e);
                }, t);
            } : u;
        }
        function l(e) {
            if (!(e = e || Promise)) throw new Error("no Promise impl found");
            return e;
        }
        function d() {
            return function(e) {
                return e.lift(new ue(e));
            };
        }
        function p(e) {
            return e ? (t = e, new re(function(e) {
                return t.schedule(function() {
                    return e.complete();
                });
            })) : ye;
            var t;
        }
        function f(e) {
            return e && "function" == typeof e.schedule;
        }
        function h(e, t) {
            return new re(function(r) {
                var n = new J(), o = 0;
                return n.add(t.schedule(function() {
                    o !== e.length ? (r.next(e[o++]), r.closed || n.add(this.schedule())) : r.complete();
                })), n;
            });
        }
        function S(e, t) {
            return t ? h(e, t) : new re(Te(e));
        }
        function _() {
            for (var e = arguments, t = [], r = 0; r < arguments.length; r++) t[r] = e[r];
            var n = t[t.length - 1];
            return f(n) ? (t.pop(), h(t, n)) : S(t);
        }
        function E(e, t) {
            return new re(t ? function(r) {
                return t.schedule(y, 0, {
                    error: e,
                    subscriber: r
                });
            } : function(t) {
                return t.error(e);
            });
        }
        function y(e) {
            var t = e.error;
            e.subscriber.error(t);
        }
        function T(e) {
            return e;
        }
        function R(e, t) {
            return function(r) {
                if ("function" != typeof e) throw new TypeError("argument is not a function. Are you looking for `mapTo()`?");
                return r.lift(new Ne(e, t));
            };
        }
        function v(e) {
            return !!e && "function" != typeof e.subscribe && "function" == typeof e.then;
        }
        function g(e, t, r, n, o) {
            if (void 0 === o && (o = new be(e, r, n)), !o.closed) return t instanceof re ? t.subscribe(o) : Ue(t)(o);
        }
        function m(t, r) {
            if (null != t) {
                if (function(e) {
                    return e && "function" == typeof e[te];
                }(t)) return n = t, o = r, new re(function(e) {
                    var t = new J();
                    return t.add(o.schedule(function() {
                        var r = n[te]();
                        t.add(r.subscribe({
                            next: function(r) {
                                t.add(o.schedule(function() {
                                    return e.next(r);
                                }));
                            },
                            error: function(r) {
                                t.add(o.schedule(function() {
                                    return e.error(r);
                                }));
                            },
                            complete: function() {
                                t.add(o.schedule(function() {
                                    return e.complete();
                                }));
                            }
                        }));
                    })), t;
                });
                if (v(t)) return function(e, t) {
                    return new re(function(r) {
                        var n = new J();
                        return n.add(t.schedule(function() {
                            return e.then(function(e) {
                                n.add(t.schedule(function() {
                                    r.next(e), n.add(t.schedule(function() {
                                        return r.complete();
                                    }));
                                }));
                            }, function(e) {
                                n.add(t.schedule(function() {
                                    return r.error(e);
                                }));
                            });
                        })), n;
                    });
                }(t, r);
                if (we(t)) return h(t, r);
                if (function(e) {
                    return e && "function" == typeof e[Pe];
                }(t) || "string" == typeof t) return function(e, t) {
                    if (!e) throw new Error("Iterable cannot be null");
                    return new re(function(r) {
                        var n, o = new J();
                        return o.add(function() {
                            n && "function" == typeof n.return && n.return();
                        }), o.add(t.schedule(function() {
                            n = e[Pe](), o.add(t.schedule(function() {
                                if (!r.closed) {
                                    var e, t;
                                    try {
                                        var o = n.next();
                                        e = o.value, t = o.done;
                                    } catch (e) {
                                        return void r.error(e);
                                    }
                                    t ? r.complete() : (r.next(e), this.schedule());
                                }
                            }));
                        })), o;
                    });
                }(t, r);
            }
            var n, o;
            throw new TypeError((null !== t && (void 0 === t ? "undefined" : e(t)) || t) + " is not observable");
        }
        function O(e, t) {
            return t ? m(e, t) : e instanceof re ? e : new re(Ue(e));
        }
        function A(e, t, r) {
            return void 0 === r && (r = Number.POSITIVE_INFINITY), "function" == typeof t ? function(n) {
                return n.pipe(A(function(r, n) {
                    return O(e(r, n)).pipe(R(function(e, o) {
                        return t(r, e, n, o);
                    }));
                }, r));
            } : ("number" == typeof t && (r = t), function(t) {
                return t.lift(new Ge(e, r));
            });
        }
        function I(e) {
            return void 0 === e && (e = Number.POSITIVE_INFINITY), A(T, e);
        }
        function C() {
            return I(1);
        }
        function D() {
            for (var e = arguments, t = [], r = 0; r < arguments.length; r++) t[r] = e[r];
            return C()(_.apply(void 0, t));
        }
        function N(e) {
            return new re(function(t) {
                var r;
                try {
                    r = e();
                } catch (r) {
                    return void t.error(r);
                }
                return (r ? O(r) : p()).subscribe(t);
            });
        }
        function L(e, t) {
            return new re(function(r) {
                var n = e.length;
                if (0 !== n) for (var o = new Array(n), i = 0, a = 0, s = 0; s < n; s++) !function(s) {
                    var u = O(e[s]), c = !1;
                    r.add(u.subscribe({
                        next: function(e) {
                            c || (c = !0, a++), o[s] = e;
                        },
                        error: function(e) {
                            return r.error(e);
                        },
                        complete: function() {
                            ++i !== n && c || (a === n && r.next(t ? t.reduce(function(e, t, r) {
                                return e[t] = o[r], e;
                            }, {}) : o), r.complete());
                        }
                    }));
                }(s); else r.complete();
            });
        }
        function M(e) {
            return !z(e) && 0 <= e - parseFloat(e) + 1;
        }
        function b(e) {
            var t = e.subscriber, r = e.counter, n = e.period;
            t.next(r), this.schedule({
                subscriber: t,
                counter: r + 1,
                period: n
            }, n);
        }
        function P(e, t) {
            return function(r) {
                return r.lift(new je(e, t));
            };
        }
        function w(e) {
            var t = e.index, r = e.period, n = e.subscriber;
            if (n.next(t), !n.closed) {
                if (-1 === r) return n.complete();
                e.index = t + 1, this.schedule(e, r);
            }
        }
        function U(e) {
            e.debouncedNext();
        }
        function x(e) {
            return void 0 === e && (e = null), function(t) {
                return t.lift(new tt(e));
            };
        }
        function F(e) {
            return e instanceof Date && !isNaN(+e);
        }
        function k(e) {
            return void 0 === e && (e = G), function(t) {
                return t.lift(new ht(e));
            };
        }
        function G() {
            return new Ce();
        }
        function B(e) {
            return function(t) {
                return 0 === e ? p() : t.lift(new gt(e));
            };
        }
        function H(e, t) {
            return function(r) {
                var n;
                if (n = "function" == typeof e ? e : function() {
                    return e;
                }, "function" == typeof t) return r.lift(new Dt(n, t));
                var o = Object.create(r, le);
                return o.source = r, o.subjectFactory = n, o;
            };
        }
        function j() {
            return new ae();
        }
        function W(e, t) {
            return "function" == typeof t ? function(r) {
                return r.pipe(W(function(r, n) {
                    return O(e(r, n)).pipe(R(function(e, o) {
                        return t(r, e, n, o);
                    }));
                }));
            } : function(t) {
                return t.lift(new Ft(e));
            };
        }
        var Y, V = n(0), q = !1, K = {
            Promise: void 0,
            set useDeprecatedSynchronousErrorHandling(e) {
                e && new Error().stack, q = e;
            },
            get useDeprecatedSynchronousErrorHandling() {
                return q;
            }
        }, X = {
            closed: !0,
            next: function(e) {},
            error: function(e) {
                if (K.useDeprecatedSynchronousErrorHandling) throw e;
                i(e);
            },
            complete: function() {}
        }, z = Array.isArray || function(e) {
            return e && "number" == typeof e.length;
        }, Q = function() {
            function e(e) {
                return Error.call(this), this.message = e ? e.length + " errors occurred during unsubscription:\n" + e.map(function(e, t) {
                    return t + 1 + ") " + e.toString();
                }).join("\n  ") : "", this.name = "UnsubscriptionError", this.errors = e, this;
            }
            return e.prototype = Object.create(Error.prototype), e;
        }(), J = function() {
            function t(e) {
                this.closed = !1, this._parentOrParents = null, this._subscriptions = null, e && (this._unsubscribe = e);
            }
            var r;
            return t.prototype.unsubscribe = function() {
                var e;
                if (!this.closed) {
                    var r = this, n = r._parentOrParents, i = r._unsubscribe, u = r._subscriptions;
                    if (this.closed = !0, this._parentOrParents = null, this._subscriptions = null, 
                    n instanceof t) n.remove(this); else if (null !== n) for (var c = 0; c < n.length; ++c) n[c].remove(this);
                    if (o(i)) try {
                        i.call(this);
                    } catch (r) {
                        e = r instanceof Q ? s(r.errors) : [ r ];
                    }
                    if (z(u)) {
                        c = -1;
                        for (var l = u.length; ++c < l; ) {
                            var d = u[c];
                            if (a(d)) try {
                                d.unsubscribe();
                            } catch (r) {
                                e = e || [], r instanceof Q ? e = e.concat(s(r.errors)) : e.push(r);
                            }
                        }
                    }
                    if (e) throw new Q(e);
                }
            }, t.prototype.add = function(r) {
                var n = r;
                if (!r) return t.EMPTY;
                switch (void 0 === r ? "undefined" : e(r)) {
                  case "function":
                    n = new t(r);

                  case "object":
                    if (n === this || n.closed || "function" != typeof n.unsubscribe) return n;
                    if (this.closed) return n.unsubscribe(), n;
                    if (!(n instanceof t)) {
                        var o = n;
                        (n = new t())._subscriptions = [ o ];
                    }
                    break;

                  default:
                    throw new Error("unrecognized teardown " + r + " added to Subscription.");
                }
                var i = n._parentOrParents;
                if (null === i) n._parentOrParents = this; else if (i instanceof t) {
                    if (i === this) return n;
                    n._parentOrParents = [ i, this ];
                } else {
                    if (-1 !== i.indexOf(this)) return n;
                    i.push(this);
                }
                var a = this._subscriptions;
                return null === a ? this._subscriptions = [ n ] : a.push(n), n;
            }, t.prototype.remove = function(e) {
                var t = this._subscriptions;
                if (t) {
                    var r = t.indexOf(e);
                    -1 !== r && t.splice(r, 1);
                }
            }, t.EMPTY = ((r = new t()).closed = !0, r), t;
        }(), $ = "function" == typeof Symbol ? Symbol("rxSubscriber") : "@@rxSubscriber_" + Math.random(), Z = function(t) {
            function r(n, o, i) {
                var a = t.call(this) || this;
                switch (a.syncErrorValue = null, a.syncErrorThrown = !1, a.syncErrorThrowable = !1, 
                a.isStopped = !1, arguments.length) {
                  case 0:
                    a.destination = X;
                    break;

                  case 1:
                    if (!n) {
                        a.destination = X;
                        break;
                    }
                    if ("object" == (void 0 === n ? "undefined" : e(n))) {
                        n instanceof r ? (a.syncErrorThrowable = n.syncErrorThrowable, (a.destination = n).add(a)) : (a.syncErrorThrowable = !0, 
                        a.destination = new ee(a, n));
                        break;
                    }

                  default:
                    a.syncErrorThrowable = !0, a.destination = new ee(a, n, o, i);
                }
                return a;
            }
            return V.__extends(r, t), r.prototype[$] = function() {
                return this;
            }, r.create = function(e, t, n) {
                var o = new r(e, t, n);
                return o.syncErrorThrowable = !1, o;
            }, r.prototype.next = function(e) {
                this.isStopped || this._next(e);
            }, r.prototype.error = function(e) {
                this.isStopped || (this.isStopped = !0, this._error(e));
            }, r.prototype.complete = function() {
                this.isStopped || (this.isStopped = !0, this._complete());
            }, r.prototype.unsubscribe = function() {
                this.closed || (this.isStopped = !0, t.prototype.unsubscribe.call(this));
            }, r.prototype._next = function(e) {
                this.destination.next(e);
            }, r.prototype._error = function(e) {
                this.destination.error(e), this.unsubscribe();
            }, r.prototype._complete = function() {
                this.destination.complete(), this.unsubscribe();
            }, r.prototype._unsubscribeAndRecycle = function() {
                var e = this._parentOrParents;
                return this._parentOrParents = null, this.unsubscribe(), this.closed = !1, this.isStopped = !1, 
                this._parentOrParents = e, this;
            }, r;
        }(J), ee = function(e) {
            function t(t, r, n, i) {
                var a, s = e.call(this) || this;
                s._parentSubscriber = t;
                var u = s;
                return o(r) ? a = r : r && (a = r.next, n = r.error, i = r.complete, r !== X && (o((u = Object.create(r)).unsubscribe) && s.add(u.unsubscribe.bind(u)), 
                u.unsubscribe = s.unsubscribe.bind(s))), s._context = u, s._next = a, s._error = n, 
                s._complete = i, s;
            }
            return V.__extends(t, e), t.prototype.next = function(e) {
                if (!this.isStopped && this._next) {
                    var t = this._parentSubscriber;
                    K.useDeprecatedSynchronousErrorHandling && t.syncErrorThrowable ? this.__tryOrSetError(t, this._next, e) && this.unsubscribe() : this.__tryOrUnsub(this._next, e);
                }
            }, t.prototype.error = function(e) {
                if (!this.isStopped) {
                    var t = this._parentSubscriber, r = K.useDeprecatedSynchronousErrorHandling;
                    if (this._error) r && t.syncErrorThrowable ? this.__tryOrSetError(t, this._error, e) : this.__tryOrUnsub(this._error, e), 
                    this.unsubscribe(); else if (t.syncErrorThrowable) r ? (t.syncErrorValue = e, t.syncErrorThrown = !0) : i(e), 
                    this.unsubscribe(); else {
                        if (this.unsubscribe(), r) throw e;
                        i(e);
                    }
                }
            }, t.prototype.complete = function() {
                var e = this;
                if (!this.isStopped) {
                    var t = this._parentSubscriber;
                    if (this._complete) {
                        var r = function() {
                            return e._complete.call(e._context);
                        };
                        K.useDeprecatedSynchronousErrorHandling && t.syncErrorThrowable ? this.__tryOrSetError(t, r) : this.__tryOrUnsub(r), 
                        this.unsubscribe();
                    } else this.unsubscribe();
                }
            }, t.prototype.__tryOrUnsub = function(e, t) {
                try {
                    e.call(this._context, t);
                } catch (e) {
                    if (this.unsubscribe(), K.useDeprecatedSynchronousErrorHandling) throw e;
                    i(e);
                }
            }, t.prototype.__tryOrSetError = function(e, t, r) {
                if (!K.useDeprecatedSynchronousErrorHandling) throw new Error("bad call");
                try {
                    t.call(this._context, r);
                } catch (t) {
                    return K.useDeprecatedSynchronousErrorHandling ? (e.syncErrorValue = t, e.syncErrorThrown = !0) : (i(t), 
                    !0);
                }
                return !1;
            }, t.prototype._unsubscribe = function() {
                var e = this._parentSubscriber;
                this._context = null, this._parentSubscriber = null, e.unsubscribe();
            }, t;
        }(Z), te = "function" == typeof Symbol && Symbol.observable || "@@observable", re = function() {
            function e(e) {
                this._isScalar = !1, e && (this._subscribe = e);
            }
            return e.prototype.lift = function(t) {
                var r = new e();
                return r.source = this, r.operator = t, r;
            }, e.prototype.subscribe = function(e, t, r) {
                var n = this.operator, o = function(e, t, r) {
                    if (e) {
                        if (e instanceof Z) return e;
                        if (e[$]) return e[$]();
                    }
                    return e || t || r ? new Z(e, t, r) : new Z(X);
                }(e, t, r);
                if (n ? o.add(n.call(o, this.source)) : o.add(this.source || K.useDeprecatedSynchronousErrorHandling && !o.syncErrorThrowable ? this._subscribe(o) : this._trySubscribe(o)), 
                K.useDeprecatedSynchronousErrorHandling && o.syncErrorThrowable && (o.syncErrorThrowable = !1, 
                o.syncErrorThrown)) throw o.syncErrorValue;
                return o;
            }, e.prototype._trySubscribe = function(e) {
                try {
                    return this._subscribe(e);
                } catch (t) {
                    K.useDeprecatedSynchronousErrorHandling && (e.syncErrorThrown = !0, e.syncErrorValue = t), 
                    function(e) {
                        for (;e; ) {
                            var t = e, r = t.closed, n = t.destination, o = t.isStopped;
                            if (r || o) return !1;
                            e = n && n instanceof Z ? n : null;
                        }
                        return !0;
                    }(e) && e.error(t);
                }
            }, e.prototype.forEach = function(e, t) {
                var r = this;
                return new (t = l(t))(function(t, n) {
                    var o;
                    o = r.subscribe(function(t) {
                        try {
                            e(t);
                        } catch (t) {
                            n(t), o && o.unsubscribe();
                        }
                    }, n, t);
                });
            }, e.prototype._subscribe = function(e) {
                var t = this.source;
                return t && t.subscribe(e);
            }, e.prototype[te] = function() {
                return this;
            }, e.prototype.pipe = function() {
                for (var e = arguments, t = [], r = 0; r < arguments.length; r++) t[r] = e[r];
                return 0 === t.length ? this : c(t)(this);
            }, e.prototype.toPromise = function(e) {
                var t = this;
                return new (e = l(e))(function(e, r) {
                    var n;
                    t.subscribe(function(e) {
                        return n = e;
                    }, function(e) {
                        return r(e);
                    }, function() {
                        return e(n);
                    });
                });
            }, e.create = function(t) {
                return new e(t);
            }, e;
        }(), ne = function() {
            function e() {
                return Error.call(this), this.message = "object unsubscribed", this.name = "ObjectUnsubscribedError", 
                this;
            }
            return e.prototype = Object.create(Error.prototype), e;
        }(), oe = function(e) {
            function t(t, r) {
                var n = e.call(this) || this;
                return n.subject = t, n.subscriber = r, n.closed = !1, n;
            }
            return V.__extends(t, e), t.prototype.unsubscribe = function() {
                if (!this.closed) {
                    this.closed = !0;
                    var e = this.subject, t = e.observers;
                    if (this.subject = null, t && 0 !== t.length && !e.isStopped && !e.closed) {
                        var r = t.indexOf(this.subscriber);
                        -1 !== r && t.splice(r, 1);
                    }
                }
            }, t;
        }(J), ie = function(e) {
            function t(t) {
                var r = e.call(this, t) || this;
                return r.destination = t, r;
            }
            return V.__extends(t, e), t;
        }(Z), ae = function(e) {
            function t() {
                var t = e.call(this) || this;
                return t.observers = [], t.closed = !1, t.isStopped = !1, t.hasError = !1, t.thrownError = null, 
                t;
            }
            return V.__extends(t, e), t.prototype[$] = function() {
                return new ie(this);
            }, t.prototype.lift = function(e) {
                var t = new se(this, this);
                return t.operator = e, t;
            }, t.prototype.next = function(e) {
                if (this.closed) throw new ne();
                if (!this.isStopped) for (var t = this.observers, r = t.length, n = t.slice(), o = 0; o < r; o++) n[o].next(e);
            }, t.prototype.error = function(e) {
                if (this.closed) throw new ne();
                this.hasError = !0, this.thrownError = e, this.isStopped = !0;
                for (var t = this.observers, r = t.length, n = t.slice(), o = 0; o < r; o++) n[o].error(e);
                this.observers.length = 0;
            }, t.prototype.complete = function() {
                if (this.closed) throw new ne();
                this.isStopped = !0;
                for (var e = this.observers, t = e.length, r = e.slice(), n = 0; n < t; n++) r[n].complete();
                this.observers.length = 0;
            }, t.prototype.unsubscribe = function() {
                this.isStopped = !0, this.closed = !0, this.observers = null;
            }, t.prototype._trySubscribe = function(t) {
                if (this.closed) throw new ne();
                return e.prototype._trySubscribe.call(this, t);
            }, t.prototype._subscribe = function(e) {
                if (this.closed) throw new ne();
                return this.hasError ? (e.error(this.thrownError), J.EMPTY) : this.isStopped ? (e.complete(), 
                J.EMPTY) : (this.observers.push(e), new oe(this, e));
            }, t.prototype.asObservable = function() {
                var e = new re();
                return e.source = this, e;
            }, t.create = function(e, t) {
                return new se(e, t);
            }, t;
        }(re), se = function(e) {
            function t(t, r) {
                var n = e.call(this) || this;
                return n.destination = t, n.source = r, n;
            }
            return V.__extends(t, e), t.prototype.next = function(e) {
                var t = this.destination;
                t && t.next && t.next(e);
            }, t.prototype.error = function(e) {
                var t = this.destination;
                t && t.error && this.destination.error(e);
            }, t.prototype.complete = function() {
                var e = this.destination;
                e && e.complete && this.destination.complete();
            }, t.prototype._subscribe = function(e) {
                return this.source ? this.source.subscribe(e) : J.EMPTY;
            }, t;
        }(ae), ue = function() {
            function e(e) {
                this.connectable = e;
            }
            return e.prototype.call = function(e, t) {
                var r = this.connectable;
                r._refCount++;
                var n = new ce(e, r), o = t.subscribe(n);
                return n.closed || (n.connection = r.connect()), o;
            }, e;
        }(), ce = function(e) {
            function t(t, r) {
                var n = e.call(this, t) || this;
                return n.connectable = r, n;
            }
            return V.__extends(t, e), t.prototype._unsubscribe = function() {
                var e = this.connectable;
                if (e) {
                    this.connectable = null;
                    var t = e._refCount;
                    if (t <= 0) this.connection = null; else if (e._refCount = t - 1, 1 < t) this.connection = null; else {
                        var r = this.connection, n = e._connection;
                        this.connection = null, !n || r && n !== r || n.unsubscribe();
                    }
                } else this.connection = null;
            }, t;
        }(Z), le = {
            operator: {
                value: null
            },
            _refCount: {
                value: 0,
                writable: !0
            },
            _subject: {
                value: null,
                writable: !0
            },
            _connection: {
                value: null,
                writable: !0
            },
            _subscribe: {
                value: (Y = function(e) {
                    function t(t, r) {
                        var n = e.call(this) || this;
                        return n.source = t, n.subjectFactory = r, n._refCount = 0, n._isComplete = !1, 
                        n;
                    }
                    return V.__extends(t, e), t.prototype._subscribe = function(e) {
                        return this.getSubject().subscribe(e);
                    }, t.prototype.getSubject = function() {
                        var e = this._subject;
                        return e && !e.isStopped || (this._subject = this.subjectFactory()), this._subject;
                    }, t.prototype.connect = function() {
                        var e = this._connection;
                        return e || (this._isComplete = !1, (e = this._connection = new J()).add(this.source.subscribe(new de(this.getSubject(), this))), 
                        e.closed && (this._connection = null, e = J.EMPTY)), e;
                    }, t.prototype.refCount = function() {
                        return d()(this);
                    }, t;
                }(re).prototype)._subscribe
            },
            _isComplete: {
                value: Y._isComplete,
                writable: !0
            },
            getSubject: {
                value: Y.getSubject
            },
            connect: {
                value: Y.connect
            },
            refCount: {
                value: Y.refCount
            }
        }, de = function(e) {
            function t(t, r) {
                var n = e.call(this, t) || this;
                return n.connectable = r, n;
            }
            return V.__extends(t, e), t.prototype._error = function(t) {
                this._unsubscribe(), e.prototype._error.call(this, t);
            }, t.prototype._complete = function() {
                this.connectable._isComplete = !0, this._unsubscribe(), e.prototype._complete.call(this);
            }, t.prototype._unsubscribe = function() {
                var e = this.connectable;
                if (e) {
                    this.connectable = null;
                    var t = e._connection;
                    e._refCount = 0, e._subject = null, e._connection = null, t && t.unsubscribe();
                }
            }, t;
        }(ie), pe = function(e) {
            function t(t) {
                var r = e.call(this) || this;
                return r._value = t, r;
            }
            return V.__extends(t, e), Object.defineProperty(t.prototype, "value", {
                get: function() {
                    return this.getValue();
                },
                enumerable: !0,
                configurable: !0
            }), t.prototype._subscribe = function(t) {
                var r = e.prototype._subscribe.call(this, t);
                return r && !r.closed && t.next(this._value), r;
            }, t.prototype.getValue = function() {
                if (this.hasError) throw this.thrownError;
                if (this.closed) throw new ne();
                return this._value;
            }, t.prototype.next = function(t) {
                e.prototype.next.call(this, this._value = t);
            }, t;
        }(ae), fe = function(e) {
            function t(t, r) {
                var n = e.call(this, t, r) || this;
                return n.scheduler = t, n.work = r, n.pending = !1, n;
            }
            return V.__extends(t, e), t.prototype.schedule = function(e, t) {
                if (void 0 === t && (t = 0), this.closed) return this;
                this.state = e;
                var r = this.id, n = this.scheduler;
                return null != r && (this.id = this.recycleAsyncId(n, r, t)), this.pending = !0, 
                this.delay = t, this.id = this.id || this.requestAsyncId(n, this.id, t), this;
            }, t.prototype.requestAsyncId = function(e, t, r) {
                return void 0 === r && (r = 0), setInterval(e.flush.bind(e, this), r);
            }, t.prototype.recycleAsyncId = function(e, t, r) {
                if (void 0 === r && (r = 0), null !== r && this.delay === r && !1 === this.pending) return t;
                clearInterval(t);
            }, t.prototype.execute = function(e, t) {
                if (this.closed) return new Error("executing a cancelled action");
                this.pending = !1;
                var r = this._execute(e, t);
                if (r) return r;
                !1 === this.pending && null != this.id && (this.id = this.recycleAsyncId(this.scheduler, this.id, null));
            }, t.prototype._execute = function(e, t) {
                var r = !1, n = void 0;
                try {
                    this.work(e);
                } catch (e) {
                    r = !0, n = !!e && e || new Error(e);
                }
                if (r) return this.unsubscribe(), n;
            }, t.prototype._unsubscribe = function() {
                var e = this.id, t = this.scheduler, r = t.actions, n = r.indexOf(this);
                this.work = null, this.state = null, this.pending = !1, this.scheduler = null, -1 !== n && r.splice(n, 1), 
                null != e && (this.id = this.recycleAsyncId(t, e, null)), this.delay = null;
            }, t;
        }(function(e) {
            function t(t, r) {
                return e.call(this) || this;
            }
            return V.__extends(t, e), t.prototype.schedule = function(e, t) {
                return this;
            }, t;
        }(J)), he = function(e) {
            function t(t, r) {
                var n = e.call(this, t, r) || this;
                return n.scheduler = t, n.work = r, n;
            }
            return V.__extends(t, e), t.prototype.schedule = function(t, r) {
                return void 0 === r && (r = 0), 0 < r ? e.prototype.schedule.call(this, t, r) : (this.delay = r, 
                this.state = t, this.scheduler.flush(this), this);
            }, t.prototype.execute = function(t, r) {
                return 0 < r || this.closed ? e.prototype.execute.call(this, t, r) : this._execute(t, r);
            }, t.prototype.requestAsyncId = function(t, r, n) {
                return void 0 === n && (n = 0), null !== n && 0 < n || null === n && 0 < this.delay ? e.prototype.requestAsyncId.call(this, t, r, n) : t.flush(this);
            }, t;
        }(fe), Se = function() {
            function e(t, r) {
                void 0 === r && (r = e.now), this.SchedulerAction = t, this.now = r;
            }
            return e.prototype.schedule = function(e, t, r) {
                return void 0 === t && (t = 0), new this.SchedulerAction(this, e).schedule(r, t);
            }, e.now = function() {
                return Date.now();
            }, e;
        }(), _e = function(e) {
            function t(r, n) {
                void 0 === n && (n = Se.now);
                var o = e.call(this, r, function() {
                    return t.delegate && t.delegate !== o ? t.delegate.now() : n();
                }) || this;
                return o.actions = [], o.active = !1, o.scheduled = void 0, o;
            }
            return V.__extends(t, e), t.prototype.schedule = function(r, n, o) {
                return void 0 === n && (n = 0), t.delegate && t.delegate !== this ? t.delegate.schedule(r, n, o) : e.prototype.schedule.call(this, r, n, o);
            }, t.prototype.flush = function(e) {
                var t = this.actions;
                if (this.active) t.push(e); else {
                    var r;
                    this.active = !0;
                    do {
                        if (r = e.execute(e.state, e.delay)) break;
                    } while (e = t.shift());
                    if (this.active = !1, r) {
                        for (;e = t.shift(); ) e.unsubscribe();
                        throw r;
                    }
                }
            }, t;
        }(Se), Ee = new (function(e) {
            function t() {
                return null !== e && e.apply(this, arguments) || this;
            }
            return V.__extends(t, e), t;
        }(_e))(he), ye = new re(function(e) {
            return e.complete();
        }), Te = function(e) {
            return function(t) {
                for (var r = 0, n = e.length; r < n && !t.closed; r++) t.next(e[r]);
                t.complete();
            };
        }, Re = function() {
            function e(e, t, r) {
                this.kind = e, this.value = t, this.error = r, this.hasValue = "N" === e;
            }
            return e.prototype.observe = function(e) {
                switch (this.kind) {
                  case "N":
                    return e.next && e.next(this.value);

                  case "E":
                    return e.error && e.error(this.error);

                  case "C":
                    return e.complete && e.complete();
                }
            }, e.prototype.do = function(e, t, r) {
                switch (this.kind) {
                  case "N":
                    return e && e(this.value);

                  case "E":
                    return t && t(this.error);

                  case "C":
                    return r && r();
                }
            }, e.prototype.accept = function(e, t, r) {
                return e && "function" == typeof e.next ? this.observe(e) : this.do(e, t, r);
            }, e.prototype.toObservable = function() {
                switch (this.kind) {
                  case "N":
                    return _(this.value);

                  case "E":
                    return E(this.error);

                  case "C":
                    return p();
                }
                throw new Error("unexpected notification kind value");
            }, e.createNext = function(t) {
                return void 0 !== t ? new e("N", t) : e.undefinedValueNotification;
            }, e.createError = function(t) {
                return new e("E", void 0, t);
            }, e.createComplete = function() {
                return e.completeNotification;
            }, e.completeNotification = new e("C"), e.undefinedValueNotification = new e("N", void 0), 
            e;
        }(), ve = function(e) {
            function t(t, r, n) {
                void 0 === n && (n = 0);
                var o = e.call(this, t) || this;
                return o.scheduler = r, o.delay = n, o;
            }
            return V.__extends(t, e), t.dispatch = function(e) {
                var t = e.notification, r = e.destination;
                t.observe(r), this.unsubscribe();
            }, t.prototype.scheduleMessage = function(e) {
                this.destination.add(this.scheduler.schedule(t.dispatch, this.delay, new ge(e, this.destination)));
            }, t.prototype._next = function(e) {
                this.scheduleMessage(Re.createNext(e));
            }, t.prototype._error = function(e) {
                this.scheduleMessage(Re.createError(e)), this.unsubscribe();
            }, t.prototype._complete = function() {
                this.scheduleMessage(Re.createComplete()), this.unsubscribe();
            }, t;
        }(Z), ge = function(e, t) {
            this.notification = e, this.destination = t;
        }, me = function(e) {
            function t(t, r, n) {
                void 0 === t && (t = Number.POSITIVE_INFINITY), void 0 === r && (r = Number.POSITIVE_INFINITY);
                var o = e.call(this) || this;
                return o.scheduler = n, o._events = [], o._infiniteTimeWindow = !1, o._bufferSize = t < 1 ? 1 : t, 
                o._windowTime = r < 1 ? 1 : r, r === Number.POSITIVE_INFINITY ? (o._infiniteTimeWindow = !0, 
                o.next = o.nextInfiniteTimeWindow) : o.next = o.nextTimeWindow, o;
            }
            return V.__extends(t, e), t.prototype.nextInfiniteTimeWindow = function(t) {
                var r = this._events;
                r.push(t), r.length > this._bufferSize && r.shift(), e.prototype.next.call(this, t);
            }, t.prototype.nextTimeWindow = function(t) {
                this._events.push(new Oe(this._getNow(), t)), this._trimBufferThenGetEvents(), e.prototype.next.call(this, t);
            }, t.prototype._subscribe = function(e) {
                var t, r = this._infiniteTimeWindow, n = r ? this._events : this._trimBufferThenGetEvents(), o = this.scheduler, i = n.length;
                if (this.closed) throw new ne();
                if (t = this.isStopped || this.hasError ? J.EMPTY : (this.observers.push(e), new oe(this, e)), 
                o && e.add(e = new ve(e, o)), r) for (var a = 0; a < i && !e.closed; a++) e.next(n[a]); else for (a = 0; a < i && !e.closed; a++) e.next(n[a].value);
                return this.hasError ? e.error(this.thrownError) : this.isStopped && e.complete(), 
                t;
            }, t.prototype._getNow = function() {
                return (this.scheduler || Ee).now();
            }, t.prototype._trimBufferThenGetEvents = function() {
                for (var e = this._getNow(), t = this._bufferSize, r = this._windowTime, n = this._events, o = n.length, i = 0; i < o && !(e - n[i].time < r); ) i++;
                return t < o && (i = Math.max(i, o - t)), 0 < i && n.splice(0, i), n;
            }, t;
        }(ae), Oe = function(e, t) {
            this.time = e, this.value = t;
        }, Ae = new _e(fe), Ie = function() {
            function e() {
                return Error.call(this), this.message = "argument out of range", this.name = "ArgumentOutOfRangeError", 
                this;
            }
            return e.prototype = Object.create(Error.prototype), e;
        }(), Ce = function() {
            function e() {
                return Error.call(this), this.message = "no elements in sequence", this.name = "EmptyError", 
                this;
            }
            return e.prototype = Object.create(Error.prototype), e;
        }(), De = function() {
            function e() {
                return Error.call(this), this.message = "Timeout has occurred", this.name = "TimeoutError", 
                this;
            }
            return e.prototype = Object.create(Error.prototype), e;
        }(), Ne = function() {
            function e(e, t) {
                this.project = e, this.thisArg = t;
            }
            return e.prototype.call = function(e, t) {
                return t.subscribe(new Le(e, this.project, this.thisArg));
            }, e;
        }(), Le = function(e) {
            function t(t, r, n) {
                var o = e.call(this, t) || this;
                return o.project = r, o.count = 0, o.thisArg = n || o, o;
            }
            return V.__extends(t, e), t.prototype._next = function(e) {
                var t;
                try {
                    t = this.project.call(this.thisArg, e, this.count++);
                } catch (e) {
                    return void this.destination.error(e);
                }
                this.destination.next(t);
            }, t;
        }(Z), Me = function(e) {
            function t() {
                return null !== e && e.apply(this, arguments) || this;
            }
            return V.__extends(t, e), t.prototype.notifyNext = function(e, t, r, n, o) {
                this.destination.next(t);
            }, t.prototype.notifyError = function(e, t) {
                this.destination.error(e);
            }, t.prototype.notifyComplete = function(e) {
                this.destination.complete();
            }, t;
        }(Z), be = function(e) {
            function t(t, r, n) {
                var o = e.call(this) || this;
                return o.parent = t, o.outerValue = r, o.outerIndex = n, o.index = 0, o;
            }
            return V.__extends(t, e), t.prototype._next = function(e) {
                this.parent.notifyNext(this.outerValue, e, this.outerIndex, this.index++, this);
            }, t.prototype._error = function(e) {
                this.parent.notifyError(e, this), this.unsubscribe();
            }, t.prototype._complete = function() {
                this.parent.notifyComplete(this), this.unsubscribe();
            }, t;
        }(Z), Pe = "function" == typeof Symbol && Symbol.iterator ? Symbol.iterator : "@@iterator", we = function(e) {
            return e && "number" == typeof e.length && "function" != typeof e;
        }, Ue = function(e) {
            if (e && "function" == typeof e[te]) return t = e, function(e) {
                var r = t[te]();
                if ("function" != typeof r.subscribe) throw new TypeError("Provided object does not correctly implement Symbol.observable");
                return r.subscribe(e);
            };
            var t, r;
            if (we(e)) return Te(e);
            if (v(e)) return function(e) {
                return function(t) {
                    return e.then(function(e) {
                        t.closed || (t.next(e), t.complete());
                    }, function(e) {
                        return t.error(e);
                    }).then(null, i), t;
                };
            }(e);
            if (e && "function" == typeof e[Pe]) return r = e, function(e) {
                for (var t = r[Pe](); ;) {
                    var n = t.next();
                    if (n.done) {
                        e.complete();
                        break;
                    }
                    if (e.next(n.value), e.closed) break;
                }
                return "function" == typeof t.return && e.add(function() {
                    t.return && t.return();
                }), e;
            };
            var n = a(e) ? "an invalid object" : "'" + e + "'";
            throw new TypeError("You provided " + n + " where a stream was expected. You can provide an Observable, Promise, Array, or Iterable.");
        }, xe = {}, Fe = function() {
            function e(e) {
                this.resultSelector = e;
            }
            return e.prototype.call = function(e, t) {
                return t.subscribe(new ke(e, this.resultSelector));
            }, e;
        }(), ke = function(e) {
            function t(t, r) {
                var n = e.call(this, t) || this;
                return n.resultSelector = r, n.active = 0, n.values = [], n.observables = [], n;
            }
            return V.__extends(t, e), t.prototype._next = function(e) {
                this.values.push(xe), this.observables.push(e);
            }, t.prototype._complete = function() {
                var e = this.observables, t = e.length;
                if (0 === t) this.destination.complete(); else {
                    this.active = t, this.toRespond = t;
                    for (var r = 0; r < t; r++) {
                        var n = e[r];
                        this.add(g(this, n, n, r));
                    }
                }
            }, t.prototype.notifyComplete = function(e) {
                0 == (this.active -= 1) && this.destination.complete();
            }, t.prototype.notifyNext = function(e, t, r, n, o) {
                var i = this.values, a = i[r], s = this.toRespond ? a === xe ? --this.toRespond : this.toRespond : 0;
                i[r] = t, 0 === s && (this.resultSelector ? this._tryResultSelector(i) : this.destination.next(i.slice()));
            }, t.prototype._tryResultSelector = function(e) {
                var t;
                try {
                    t = this.resultSelector.apply(this, e);
                } catch (e) {
                    return void this.destination.error(e);
                }
                this.destination.next(t);
            }, t;
        }(Me), Ge = function() {
            function e(e, t) {
                void 0 === t && (t = Number.POSITIVE_INFINITY), this.project = e, this.concurrent = t;
            }
            return e.prototype.call = function(e, t) {
                return t.subscribe(new Be(e, this.project, this.concurrent));
            }, e;
        }(), Be = function(e) {
            function t(t, r, n) {
                void 0 === n && (n = Number.POSITIVE_INFINITY);
                var o = e.call(this, t) || this;
                return o.project = r, o.concurrent = n, o.hasCompleted = !1, o.buffer = [], o.active = 0, 
                o.index = 0, o;
            }
            return V.__extends(t, e), t.prototype._next = function(e) {
                this.active < this.concurrent ? this._tryNext(e) : this.buffer.push(e);
            }, t.prototype._tryNext = function(e) {
                var t, r = this.index++;
                try {
                    t = this.project(e, r);
                } catch (e) {
                    return void this.destination.error(e);
                }
                this.active++, this._innerSub(t, e, r);
            }, t.prototype._innerSub = function(e, t, r) {
                var n = new be(this, void 0, void 0);
                this.destination.add(n), g(this, e, t, r, n);
            }, t.prototype._complete = function() {
                this.hasCompleted = !0, 0 === this.active && 0 === this.buffer.length && this.destination.complete(), 
                this.unsubscribe();
            }, t.prototype.notifyNext = function(e, t, r, n, o) {
                this.destination.next(t);
            }, t.prototype.notifyComplete = function(e) {
                var t = this.buffer;
                this.remove(e), this.active--, 0 < t.length ? this._next(t.shift()) : 0 === this.active && this.hasCompleted && this.destination.complete();
            }, t;
        }(Me), He = new re(u), je = function() {
            function e(e, t) {
                this.predicate = e, this.thisArg = t;
            }
            return e.prototype.call = function(e, t) {
                return t.subscribe(new We(e, this.predicate, this.thisArg));
            }, e;
        }(), We = function(e) {
            function t(t, r, n) {
                var o = e.call(this, t) || this;
                return o.predicate = r, o.thisArg = n, o.count = 0, o;
            }
            return V.__extends(t, e), t.prototype._next = function(e) {
                var t;
                try {
                    t = this.predicate.call(this.thisArg, e, this.count++);
                } catch (e) {
                    return void this.destination.error(e);
                }
                t && this.destination.next(e);
            }, t;
        }(Z), Ye = function() {
            function e() {}
            return e.prototype.call = function(e, t) {
                return t.subscribe(new Ve(e));
            }, e;
        }(), Ve = function(e) {
            function t(t) {
                var r = e.call(this, t) || this;
                return r.hasFirst = !1, r.observables = [], r.subscriptions = [], r;
            }
            return V.__extends(t, e), t.prototype._next = function(e) {
                this.observables.push(e);
            }, t.prototype._complete = function() {
                var e = this.observables, t = e.length;
                if (0 === t) this.destination.complete(); else {
                    for (var r = 0; r < t && !this.hasFirst; r++) {
                        var n = e[r], o = g(this, n, n, r);
                        this.subscriptions && this.subscriptions.push(o), this.add(o);
                    }
                    this.observables = null;
                }
            }, t.prototype.notifyNext = function(e, t, r, n, o) {
                if (!this.hasFirst) {
                    this.hasFirst = !0;
                    for (var i = 0; i < this.subscriptions.length; i++) if (i !== r) {
                        var a = this.subscriptions[i];
                        a.unsubscribe(), this.remove(a);
                    }
                    this.subscriptions = null;
                }
                this.destination.next(t);
            }, t;
        }(Me), qe = function() {
            function e(e) {
                this.resultSelector = e;
            }
            return e.prototype.call = function(e, t) {
                return t.subscribe(new Ke(e, this.resultSelector));
            }, e;
        }(), Ke = function(e) {
            function t(t, r, n) {
                void 0 === n && (n = Object.create(null));
                var o = e.call(this, t) || this;
                return o.iterators = [], o.active = 0, o.resultSelector = "function" == typeof r ? r : null, 
                o.values = n, o;
            }
            return V.__extends(t, e), t.prototype._next = function(e) {
                var t = this.iterators;
                z(e) ? t.push(new ze(e)) : "function" == typeof e[Pe] ? t.push(new Xe(e[Pe]())) : t.push(new Qe(this.destination, this, e));
            }, t.prototype._complete = function() {
                var e = this.iterators, t = e.length;
                if (this.unsubscribe(), 0 !== t) {
                    this.active = t;
                    for (var r = 0; r < t; r++) {
                        var n = e[r];
                        n.stillUnsubscribed ? this.destination.add(n.subscribe(n, r)) : this.active--;
                    }
                } else this.destination.complete();
            }, t.prototype.notifyInactive = function() {
                0 == --this.active && this.destination.complete();
            }, t.prototype.checkIterators = function() {
                for (var e = this.iterators, t = e.length, r = this.destination, n = 0; n < t; n++) if ("function" == typeof (a = e[n]).hasValue && !a.hasValue()) return;
                var o = !1, i = [];
                for (n = 0; n < t; n++) {
                    var a, s = (a = e[n]).next();
                    if (a.hasCompleted() && (o = !0), s.done) return void r.complete();
                    i.push(s.value);
                }
                this.resultSelector ? this._tryresultSelector(i) : r.next(i), o && r.complete();
            }, t.prototype._tryresultSelector = function(e) {
                var t;
                try {
                    t = this.resultSelector.apply(this, e);
                } catch (e) {
                    return void this.destination.error(e);
                }
                this.destination.next(t);
            }, t;
        }(Z), Xe = function() {
            function e(e) {
                this.iterator = e, this.nextResult = e.next();
            }
            return e.prototype.hasValue = function() {
                return !0;
            }, e.prototype.next = function() {
                var e = this.nextResult;
                return this.nextResult = this.iterator.next(), e;
            }, e.prototype.hasCompleted = function() {
                var e = this.nextResult;
                return e && e.done;
            }, e;
        }(), ze = function() {
            function e(e) {
                this.array = e, this.index = 0, this.length = 0, this.length = e.length;
            }
            return e.prototype[Pe] = function() {
                return this;
            }, e.prototype.next = function(e) {
                var t = this.index++, r = this.array;
                return t < this.length ? {
                    value: r[t],
                    done: !1
                } : {
                    value: null,
                    done: !0
                };
            }, e.prototype.hasValue = function() {
                return this.array.length > this.index;
            }, e.prototype.hasCompleted = function() {
                return this.array.length === this.index;
            }, e;
        }(), Qe = function(e) {
            function t(t, r, n) {
                var o = e.call(this, t) || this;
                return o.parent = r, o.observable = n, o.stillUnsubscribed = !0, o.buffer = [], 
                o.isComplete = !1, o;
            }
            return V.__extends(t, e), t.prototype[Pe] = function() {
                return this;
            }, t.prototype.next = function() {
                var e = this.buffer;
                return 0 === e.length && this.isComplete ? {
                    value: null,
                    done: !0
                } : {
                    value: e.shift(),
                    done: !1
                };
            }, t.prototype.hasValue = function() {
                return 0 < this.buffer.length;
            }, t.prototype.hasCompleted = function() {
                return 0 === this.buffer.length && this.isComplete;
            }, t.prototype.notifyComplete = function() {
                0 < this.buffer.length ? (this.isComplete = !0, this.parent.notifyInactive()) : this.destination.complete();
            }, t.prototype.notifyNext = function(e, t, r, n, o) {
                this.buffer.push(t), this.parent.checkIterators();
            }, t.prototype.subscribe = function(e, t) {
                return g(this, this.observable, this, t);
            }, t;
        }(Me), Je = function() {
            function e(e) {
                this.selector = e;
            }
            return e.prototype.call = function(e, t) {
                return t.subscribe(new $e(e, this.selector, this.caught));
            }, e;
        }(), $e = function(e) {
            function t(t, r, n) {
                var o = e.call(this, t) || this;
                return o.selector = r, o.caught = n, o;
            }
            return V.__extends(t, e), t.prototype.error = function(t) {
                if (!this.isStopped) {
                    var r = void 0;
                    try {
                        r = this.selector(t, this.caught);
                    } catch (t) {
                        return void e.prototype.error.call(this, t);
                    }
                    this._unsubscribeAndRecycle();
                    var n = new be(this, void 0, void 0);
                    this.add(n), g(this, r, void 0, void 0, n);
                }
            }, t;
        }(Me), Ze = function() {
            function e(e, t) {
                this.dueTime = e, this.scheduler = t;
            }
            return e.prototype.call = function(e, t) {
                return t.subscribe(new et(e, this.dueTime, this.scheduler));
            }, e;
        }(), et = function(e) {
            function t(t, r, n) {
                var o = e.call(this, t) || this;
                return o.dueTime = r, o.scheduler = n, o.debouncedSubscription = null, o.lastValue = null, 
                o.hasValue = !1, o;
            }
            return V.__extends(t, e), t.prototype._next = function(e) {
                this.clearDebounce(), this.lastValue = e, this.hasValue = !0, this.add(this.debouncedSubscription = this.scheduler.schedule(U, this.dueTime, this));
            }, t.prototype._complete = function() {
                this.debouncedNext(), this.destination.complete();
            }, t.prototype.debouncedNext = function() {
                if (this.clearDebounce(), this.hasValue) {
                    var e = this.lastValue;
                    this.lastValue = null, this.hasValue = !1, this.destination.next(e);
                }
            }, t.prototype.clearDebounce = function() {
                var e = this.debouncedSubscription;
                null !== e && (this.remove(e), e.unsubscribe(), this.debouncedSubscription = null);
            }, t;
        }(Z), tt = function() {
            function e(e) {
                this.defaultValue = e;
            }
            return e.prototype.call = function(e, t) {
                return t.subscribe(new rt(e, this.defaultValue));
            }, e;
        }(), rt = function(e) {
            function t(t, r) {
                var n = e.call(this, t) || this;
                return n.defaultValue = r, n.isEmpty = !0, n;
            }
            return V.__extends(t, e), t.prototype._next = function(e) {
                this.isEmpty = !1, this.destination.next(e);
            }, t.prototype._complete = function() {
                this.isEmpty && this.destination.next(this.defaultValue), this.destination.complete();
            }, t;
        }(Z), nt = function() {
            function e(e, t) {
                this.delay = e, this.scheduler = t;
            }
            return e.prototype.call = function(e, t) {
                return t.subscribe(new ot(e, this.delay, this.scheduler));
            }, e;
        }(), ot = function(e) {
            function t(t, r, n) {
                var o = e.call(this, t) || this;
                return o.delay = r, o.scheduler = n, o.queue = [], o.active = !1, o.errored = !1, 
                o;
            }
            return V.__extends(t, e), t.dispatch = function(e) {
                for (var t = e.source, r = t.queue, n = e.scheduler, o = e.destination; 0 < r.length && r[0].time - n.now() <= 0; ) r.shift().notification.observe(o);
                if (0 < r.length) {
                    var i = Math.max(0, r[0].time - n.now());
                    this.schedule(e, i);
                } else this.unsubscribe(), t.active = !1;
            }, t.prototype._schedule = function(e) {
                this.active = !0, this.destination.add(e.schedule(t.dispatch, this.delay, {
                    source: this,
                    destination: this.destination,
                    scheduler: e
                }));
            }, t.prototype.scheduleNotification = function(e) {
                if (!0 !== this.errored) {
                    var t = this.scheduler, r = new it(t.now() + this.delay, e);
                    this.queue.push(r), !1 === this.active && this._schedule(t);
                }
            }, t.prototype._next = function(e) {
                this.scheduleNotification(Re.createNext(e));
            }, t.prototype._error = function(e) {
                this.errored = !0, this.queue = [], this.destination.error(e), this.unsubscribe();
            }, t.prototype._complete = function() {
                this.scheduleNotification(Re.createComplete()), this.unsubscribe();
            }, t;
        }(Z), it = function(e, t) {
            this.time = e, this.notification = t;
        }, at = function() {
            function e(e) {
                this.delayDurationSelector = e;
            }
            return e.prototype.call = function(e, t) {
                return t.subscribe(new st(e, this.delayDurationSelector));
            }, e;
        }(), st = function(e) {
            function t(t, r) {
                var n = e.call(this, t) || this;
                return n.delayDurationSelector = r, n.completed = !1, n.delayNotifierSubscriptions = [], 
                n.index = 0, n;
            }
            return V.__extends(t, e), t.prototype.notifyNext = function(e, t, r, n, o) {
                this.destination.next(e), this.removeSubscription(o), this.tryComplete();
            }, t.prototype.notifyError = function(e, t) {
                this._error(e);
            }, t.prototype.notifyComplete = function(e) {
                var t = this.removeSubscription(e);
                t && this.destination.next(t), this.tryComplete();
            }, t.prototype._next = function(e) {
                var t = this.index++;
                try {
                    var r = this.delayDurationSelector(e, t);
                    r && this.tryDelay(r, e);
                } catch (e) {
                    this.destination.error(e);
                }
            }, t.prototype._complete = function() {
                this.completed = !0, this.tryComplete(), this.unsubscribe();
            }, t.prototype.removeSubscription = function(e) {
                e.unsubscribe();
                var t = this.delayNotifierSubscriptions.indexOf(e);
                return -1 !== t && this.delayNotifierSubscriptions.splice(t, 1), e.outerValue;
            }, t.prototype.tryDelay = function(e, t) {
                var r = g(this, e, t);
                r && !r.closed && (this.destination.add(r), this.delayNotifierSubscriptions.push(r));
            }, t.prototype.tryComplete = function() {
                this.completed && 0 === this.delayNotifierSubscriptions.length && this.destination.complete();
            }, t;
        }(Me), ut = function(e) {
            function t(t, r) {
                var n = e.call(this) || this;
                return n.source = t, n.subscriptionDelay = r, n;
            }
            return V.__extends(t, e), t.prototype._subscribe = function(e) {
                this.subscriptionDelay.subscribe(new ct(e, this.source));
            }, t;
        }(re), ct = function(e) {
            function t(t, r) {
                var n = e.call(this) || this;
                return n.parent = t, n.source = r, n.sourceSubscribed = !1, n;
            }
            return V.__extends(t, e), t.prototype._next = function(e) {
                this.subscribeToSource();
            }, t.prototype._error = function(e) {
                this.unsubscribe(), this.parent.error(e);
            }, t.prototype._complete = function() {
                this.unsubscribe(), this.subscribeToSource();
            }, t.prototype.subscribeToSource = function() {
                this.sourceSubscribed || (this.sourceSubscribed = !0, this.unsubscribe(), this.source.subscribe(this.parent));
            }, t;
        }(Z), lt = function() {
            function e(e, t) {
                this.keySelector = e, this.flushes = t;
            }
            return e.prototype.call = function(e, t) {
                return t.subscribe(new dt(e, this.keySelector, this.flushes));
            }, e;
        }(), dt = function(e) {
            function t(t, r, n) {
                var o = e.call(this, t) || this;
                return o.keySelector = r, o.values = new Set(), n && o.add(g(o, n)), o;
            }
            return V.__extends(t, e), t.prototype.notifyNext = function(e, t, r, n, o) {
                this.values.clear();
            }, t.prototype.notifyError = function(e, t) {
                this._error(e);
            }, t.prototype._next = function(e) {
                this.keySelector ? this._useKeySelector(e) : this._finalizeNext(e, e);
            }, t.prototype._useKeySelector = function(e) {
                var t, r = this.destination;
                try {
                    t = this.keySelector(e);
                } catch (e) {
                    return void r.error(e);
                }
                this._finalizeNext(t, e);
            }, t.prototype._finalizeNext = function(e, t) {
                var r = this.values;
                r.has(e) || (r.add(e), this.destination.next(t));
            }, t;
        }(Me), pt = function() {
            function e(e, t) {
                this.compare = e, this.keySelector = t;
            }
            return e.prototype.call = function(e, t) {
                return t.subscribe(new ft(e, this.compare, this.keySelector));
            }, e;
        }(), ft = function(e) {
            function t(t, r, n) {
                var o = e.call(this, t) || this;
                return o.keySelector = n, o.hasKey = !1, "function" == typeof r && (o.compare = r), 
                o;
            }
            return V.__extends(t, e), t.prototype.compare = function(e, t) {
                return e === t;
            }, t.prototype._next = function(e) {
                var t;
                try {
                    var r = this.keySelector;
                    t = r ? r(e) : e;
                } catch (e) {
                    return this.destination.error(e);
                }
                var n = !1;
                if (this.hasKey) try {
                    n = (0, this.compare)(this.key, t);
                } catch (e) {
                    return this.destination.error(e);
                } else this.hasKey = !0;
                n || (this.key = t, this.destination.next(e));
            }, t;
        }(Z), ht = function() {
            function e(e) {
                this.errorFactory = e;
            }
            return e.prototype.call = function(e, t) {
                return t.subscribe(new St(e, this.errorFactory));
            }, e;
        }(), St = function(e) {
            function t(t, r) {
                var n = e.call(this, t) || this;
                return n.errorFactory = r, n.hasValue = !1, n;
            }
            return V.__extends(t, e), t.prototype._next = function(e) {
                this.hasValue = !0, this.destination.next(e);
            }, t.prototype._complete = function() {
                if (this.hasValue) return this.destination.complete();
                var e = void 0;
                try {
                    e = this.errorFactory();
                } catch (t) {
                    e = t;
                }
                this.destination.error(e);
            }, t;
        }(Z), _t = function() {
            function e(e) {
                if (this.total = e, this.total < 0) throw new Ie();
            }
            return e.prototype.call = function(e, t) {
                return t.subscribe(new Et(e, this.total));
            }, e;
        }(), Et = function(e) {
            function t(t, r) {
                var n = e.call(this, t) || this;
                return n.total = r, n.count = 0, n;
            }
            return V.__extends(t, e), t.prototype._next = function(e) {
                var t = this.total, r = ++this.count;
                r <= t && (this.destination.next(e), r === t && (this.destination.complete(), this.unsubscribe()));
            }, t;
        }(Z), yt = function() {
            function e(e, t, r) {
                this.predicate = e, this.thisArg = t, this.source = r;
            }
            return e.prototype.call = function(e, t) {
                return t.subscribe(new Tt(e, this.predicate, this.thisArg, this.source));
            }, e;
        }(), Tt = function(e) {
            function t(t, r, n, o) {
                var i = e.call(this, t) || this;
                return i.predicate = r, i.thisArg = n, i.source = o, i.index = 0, i.thisArg = n || i, 
                i;
            }
            return V.__extends(t, e), t.prototype.notifyComplete = function(e) {
                this.destination.next(e), this.destination.complete();
            }, t.prototype._next = function(e) {
                var t = !1;
                try {
                    t = this.predicate.call(this.thisArg, e, this.index++, this.source);
                } catch (e) {
                    return void this.destination.error(e);
                }
                t || this.notifyComplete(!1);
            }, t.prototype._complete = function() {
                this.notifyComplete(!0);
            }, t;
        }(Z), Rt = function() {
            function e(e) {
                this.callback = e;
            }
            return e.prototype.call = function(e, t) {
                return t.subscribe(new vt(e, this.callback));
            }, e;
        }(), vt = function(e) {
            function t(t, r) {
                var n = e.call(this, t) || this;
                return n.add(new J(r)), n;
            }
            return V.__extends(t, e), t;
        }(Z), gt = function() {
            function e(e) {
                if (this.total = e, this.total < 0) throw new Ie();
            }
            return e.prototype.call = function(e, t) {
                return t.subscribe(new mt(e, this.total));
            }, e;
        }(), mt = function(e) {
            function t(t, r) {
                var n = e.call(this, t) || this;
                return n.total = r, n.ring = new Array(), n.count = 0, n;
            }
            return V.__extends(t, e), t.prototype._next = function(e) {
                var t = this.ring, r = this.total, n = this.count++;
                t.length < r ? t.push(e) : t[n % r] = e;
            }, t.prototype._complete = function() {
                var e = this.destination, t = this.count;
                if (0 < t) for (var r = this.count >= this.total ? this.total : this.count, n = this.ring, o = 0; o < r; o++) {
                    var i = t++ % r;
                    e.next(n[i]);
                }
                e.complete();
            }, t;
        }(Z), Ot = function() {
            function e(e) {
                this.value = e;
            }
            return e.prototype.call = function(e, t) {
                return t.subscribe(new At(e, this.value));
            }, e;
        }(), At = function(e) {
            function t(t, r) {
                var n = e.call(this, t) || this;
                return n.value = r, n;
            }
            return V.__extends(t, e), t.prototype._next = function(e) {
                this.destination.next(this.value);
            }, t;
        }(Z), It = function() {
            function e(e, t, r) {
                void 0 === r && (r = !1), this.accumulator = e, this.seed = t, this.hasSeed = r;
            }
            return e.prototype.call = function(e, t) {
                return t.subscribe(new Ct(e, this.accumulator, this.seed, this.hasSeed));
            }, e;
        }(), Ct = function(e) {
            function t(t, r, n, o) {
                var i = e.call(this, t) || this;
                return i.accumulator = r, i._seed = n, i.hasSeed = o, i.index = 0, i;
            }
            return V.__extends(t, e), Object.defineProperty(t.prototype, "seed", {
                get: function() {
                    return this._seed;
                },
                set: function(e) {
                    this.hasSeed = !0, this._seed = e;
                },
                enumerable: !0,
                configurable: !0
            }), t.prototype._next = function(e) {
                if (this.hasSeed) return this._tryNext(e);
                this.seed = e, this.destination.next(e);
            }, t.prototype._tryNext = function(e) {
                var t, r = this.index++;
                try {
                    t = this.accumulator(this.seed, e, r);
                } catch (e) {
                    this.destination.error(e);
                }
                this.seed = t, this.destination.next(t);
            }, t;
        }(Z), Dt = function() {
            function e(e, t) {
                this.subjectFactory = e, this.selector = t;
            }
            return e.prototype.call = function(e, t) {
                var r = this.selector, n = this.subjectFactory(), o = r(n).subscribe(e);
                return o.add(t.subscribe(n)), o;
            }, e;
        }(), Nt = function() {
            function e(e) {
                this.notifier = e;
            }
            return e.prototype.call = function(e, t) {
                return t.subscribe(new Lt(e, this.notifier, t));
            }, e;
        }(), Lt = function(e) {
            function t(t, r, n) {
                var o = e.call(this, t) || this;
                return o.notifier = r, o.source = n, o.sourceIsBeingSubscribedTo = !0, o;
            }
            return V.__extends(t, e), t.prototype.notifyNext = function(e, t, r, n, o) {
                this.sourceIsBeingSubscribedTo = !0, this.source.subscribe(this);
            }, t.prototype.notifyComplete = function(t) {
                if (!1 === this.sourceIsBeingSubscribedTo) return e.prototype.complete.call(this);
            }, t.prototype.complete = function() {
                if (this.sourceIsBeingSubscribedTo = !1, !this.isStopped) {
                    if (this.retries || this.subscribeToRetries(), !this.retriesSubscription || this.retriesSubscription.closed) return e.prototype.complete.call(this);
                    this._unsubscribeAndRecycle(), this.notifications.next();
                }
            }, t.prototype._unsubscribe = function() {
                var e = this.notifications, t = this.retriesSubscription;
                e && (e.unsubscribe(), this.notifications = null), t && (t.unsubscribe(), this.retriesSubscription = null), 
                this.retries = null;
            }, t.prototype._unsubscribeAndRecycle = function() {
                var t = this._unsubscribe;
                return this._unsubscribe = null, e.prototype._unsubscribeAndRecycle.call(this), 
                this._unsubscribe = t, this;
            }, t.prototype.subscribeToRetries = function() {
                var t;
                this.notifications = new ae();
                try {
                    t = (0, this.notifier)(this.notifications);
                } catch (t) {
                    return e.prototype.complete.call(this);
                }
                this.retries = t, this.retriesSubscription = g(this, t);
            }, t;
        }(Me), Mt = function() {
            function e(e, t) {
                this.count = e, this.source = t;
            }
            return e.prototype.call = function(e, t) {
                return t.subscribe(new bt(e, this.count, this.source));
            }, e;
        }(), bt = function(e) {
            function t(t, r, n) {
                var o = e.call(this, t) || this;
                return o.count = r, o.source = n, o;
            }
            return V.__extends(t, e), t.prototype.error = function(t) {
                if (!this.isStopped) {
                    var r = this.source, n = this.count;
                    if (0 === n) return e.prototype.error.call(this, t);
                    -1 < n && (this.count = n - 1), r.subscribe(this._unsubscribeAndRecycle());
                }
            }, t;
        }(Z), Pt = function() {
            function e(e, t) {
                this.notifier = e, this.source = t;
            }
            return e.prototype.call = function(e, t) {
                return t.subscribe(new wt(e, this.notifier, this.source));
            }, e;
        }(), wt = function(e) {
            function t(t, r, n) {
                var o = e.call(this, t) || this;
                return o.notifier = r, o.source = n, o;
            }
            return V.__extends(t, e), t.prototype.error = function(t) {
                if (!this.isStopped) {
                    var r = this.errors, n = this.retries, o = this.retriesSubscription;
                    if (n) this.errors = null, this.retriesSubscription = null; else {
                        r = new ae();
                        try {
                            n = (0, this.notifier)(r);
                        } catch (t) {
                            return e.prototype.error.call(this, t);
                        }
                        o = g(this, n);
                    }
                    this._unsubscribeAndRecycle(), this.errors = r, this.retries = n, this.retriesSubscription = o, 
                    r.next(t);
                }
            }, t.prototype._unsubscribe = function() {
                var e = this.errors, t = this.retriesSubscription;
                e && (e.unsubscribe(), this.errors = null), t && (t.unsubscribe(), this.retriesSubscription = null), 
                this.retries = null;
            }, t.prototype.notifyNext = function(e, t, r, n, o) {
                var i = this._unsubscribe;
                this._unsubscribe = null, this._unsubscribeAndRecycle(), this._unsubscribe = i, 
                this.source.subscribe(this);
            }, t;
        }(Me), Ut = function() {
            function e(e) {
                this.predicate = e;
            }
            return e.prototype.call = function(e, t) {
                return t.subscribe(new xt(e, this.predicate));
            }, e;
        }(), xt = function(e) {
            function t(t, r) {
                var n = e.call(this, t) || this;
                return n.predicate = r, n.skipping = !0, n.index = 0, n;
            }
            return V.__extends(t, e), t.prototype._next = function(e) {
                var t = this.destination;
                this.skipping && this.tryCallPredicate(e), this.skipping || t.next(e);
            }, t.prototype.tryCallPredicate = function(e) {
                try {
                    var t = this.predicate(e, this.index++);
                    this.skipping = Boolean(t);
                } catch (e) {
                    this.destination.error(e);
                }
            }, t;
        }(Z), Ft = function() {
            function e(e) {
                this.project = e;
            }
            return e.prototype.call = function(e, t) {
                return t.subscribe(new kt(e, this.project));
            }, e;
        }(), kt = function(e) {
            function t(t, r) {
                var n = e.call(this, t) || this;
                return n.project = r, n.index = 0, n;
            }
            return V.__extends(t, e), t.prototype._next = function(e) {
                var t, r = this.index++;
                try {
                    t = this.project(e, r);
                } catch (e) {
                    return void this.destination.error(e);
                }
                this._innerSub(t, e, r);
            }, t.prototype._innerSub = function(e, t, r) {
                var n = this.innerSubscription;
                n && n.unsubscribe();
                var o = new be(this, void 0, void 0);
                this.destination.add(o), this.innerSubscription = g(this, e, t, r, o);
            }, t.prototype._complete = function() {
                var t = this.innerSubscription;
                t && !t.closed || e.prototype._complete.call(this), this.unsubscribe();
            }, t.prototype._unsubscribe = function() {
                this.innerSubscription = null;
            }, t.prototype.notifyComplete = function(t) {
                this.destination.remove(t), this.innerSubscription = null, this.isStopped && e.prototype._complete.call(this);
            }, t.prototype.notifyNext = function(e, t, r, n, o) {
                this.destination.next(t);
            }, t;
        }(Me), Gt = function() {
            function e(e) {
                this.notifier = e;
            }
            return e.prototype.call = function(e, t) {
                var r = new Bt(e), n = g(r, this.notifier);
                return n && !r.seenValue ? (r.add(n), t.subscribe(r)) : r;
            }, e;
        }(), Bt = function(e) {
            function t(t) {
                var r = e.call(this, t) || this;
                return r.seenValue = !1, r;
            }
            return V.__extends(t, e), t.prototype.notifyNext = function(e, t, r, n, o) {
                this.seenValue = !0, this.complete();
            }, t.prototype.notifyComplete = function() {}, t;
        }(Me), Ht = function() {
            function e(e, t) {
                this.predicate = e, this.inclusive = t;
            }
            return e.prototype.call = function(e, t) {
                return t.subscribe(new jt(e, this.predicate, this.inclusive));
            }, e;
        }(), jt = function(e) {
            function t(t, r, n) {
                var o = e.call(this, t) || this;
                return o.predicate = r, o.inclusive = n, o.index = 0, o;
            }
            return V.__extends(t, e), t.prototype._next = function(e) {
                var t, r = this.destination;
                try {
                    t = this.predicate(e, this.index++);
                } catch (e) {
                    return void r.error(e);
                }
                this.nextOrComplete(e, t);
            }, t.prototype.nextOrComplete = function(e, t) {
                var r = this.destination;
                Boolean(t) ? r.next(e) : (this.inclusive && r.next(e), r.complete());
            }, t;
        }(Z), Wt = function() {
            function e(e, t, r) {
                this.nextOrObserver = e, this.error = t, this.complete = r;
            }
            return e.prototype.call = function(e, t) {
                return t.subscribe(new Yt(e, this.nextOrObserver, this.error, this.complete));
            }, e;
        }(), Yt = function(e) {
            function t(t, r, n, i) {
                var a = e.call(this, t) || this;
                return a._tapNext = u, a._tapError = u, a._tapComplete = u, a._tapError = n || u, 
                a._tapComplete = i || u, o(r) ? (a._context = a)._tapNext = r : r && (a._context = r, 
                a._tapNext = r.next || u, a._tapError = r.error || u, a._tapComplete = r.complete || u), 
                a;
            }
            return V.__extends(t, e), t.prototype._next = function(e) {
                try {
                    this._tapNext.call(this._context, e);
                } catch (e) {
                    return void this.destination.error(e);
                }
                this.destination.next(e);
            }, t.prototype._error = function(e) {
                try {
                    this._tapError.call(this._context, e);
                } catch (e) {
                    return void this.destination.error(e);
                }
                this.destination.error(e);
            }, t.prototype._complete = function() {
                try {
                    this._tapComplete.call(this._context);
                } catch (e) {
                    return void this.destination.error(e);
                }
                return this.destination.complete();
            }, t;
        }(Z), Vt = function() {
            function e(e, t, r, n) {
                this.waitFor = e, this.absoluteTimeout = t, this.withObservable = r, this.scheduler = n;
            }
            return e.prototype.call = function(e, t) {
                return t.subscribe(new qt(e, this.absoluteTimeout, this.waitFor, this.withObservable, this.scheduler));
            }, e;
        }(), qt = function(e) {
            function t(t, r, n, o, i) {
                var a = e.call(this, t) || this;
                return a.absoluteTimeout = r, a.waitFor = n, a.withObservable = o, a.scheduler = i, 
                a.action = null, a.scheduleTimeout(), a;
            }
            return V.__extends(t, e), t.dispatchTimeout = function(e) {
                var t = e.withObservable;
                e._unsubscribeAndRecycle(), e.add(g(e, t));
            }, t.prototype.scheduleTimeout = function() {
                var e = this.action;
                e ? this.action = e.schedule(this, this.waitFor) : this.add(this.action = this.scheduler.schedule(t.dispatchTimeout, this.waitFor, this));
            }, t.prototype._next = function(t) {
                this.absoluteTimeout || this.scheduleTimeout(), e.prototype._next.call(this, t);
            }, t.prototype._unsubscribe = function() {
                this.action = null, this.scheduler = null, this.withObservable = null;
            }, t;
        }(Me), Kt = function(e, t) {
            this.value = e, this.timestamp = t;
        };
        r.BehaviorSubject = pe, r.Observable = re, r.ReplaySubject = me, r.Subject = ae, 
        r.Subscriber = Z, r.Subscription = J, r.TimeoutError = De, r.catchError = function(e) {
            return function(t) {
                var r = new Je(e), n = t.lift(r);
                return r.caught = n;
            };
        }, r.combineLatest = function() {
            for (var e = arguments, t = [], r = 0; r < arguments.length; r++) t[r] = e[r];
            var n = null, o = null;
            return f(t[t.length - 1]) && (o = t.pop()), "function" == typeof t[t.length - 1] && (n = t.pop()), 
            1 === t.length && z(t[0]) && (t = t[0]), S(t, o).lift(new Fe(n));
        }, r.concat = D, r.concat$1 = function() {
            for (var e = arguments, t = [], r = 0; r < arguments.length; r++) t[r] = e[r];
            return function(e) {
                return e.lift.call(D.apply(void 0, [ e ].concat(t)));
            };
        }, r.concatAll = C, r.concatMap = function(e, t) {
            return A(e, t, 1);
        }, r.debounceTime = function(e, t) {
            return void 0 === t && (t = Ae), function(r) {
                return r.lift(new Ze(e, t));
            };
        }, r.defer = N, r.delay = function(e, t) {
            void 0 === t && (t = Ae);
            var r = F(e) ? +e - t.now() : Math.abs(e);
            return function(e) {
                return e.lift(new nt(r, t));
            };
        }, r.delayWhen = function(e, t) {
            return t ? function(r) {
                return new ut(r, t).lift(new at(e));
            } : function(t) {
                return t.lift(new at(e));
            };
        }, r.distinct = function(e, t) {
            return function(r) {
                return r.lift(new lt(e, t));
            };
        }, r.distinctUntilChanged = function(e, t) {
            return function(r) {
                return r.lift(new pt(e, t));
            };
        }, r.empty = p, r.every = function(e, t) {
            return function(r) {
                return r.lift(new yt(e, t, r));
            };
        }, r.filter = P, r.finalize = function(e) {
            return function(t) {
                return t.lift(new Rt(e));
            };
        }, r.forkJoin = function() {
            for (var e = arguments, t = [], r = 0; r < arguments.length; r++) t[r] = e[r];
            if (1 === t.length) {
                var n = t[0];
                if (z(n)) return L(n, null);
                if (a(n) && Object.getPrototypeOf(n) === Object.prototype) {
                    var o = Object.keys(n);
                    return L(o.map(function(e) {
                        return n[e];
                    }), o);
                }
            }
            if ("function" != typeof t[t.length - 1]) return L(t, null);
            var i = t.pop();
            return L(t = 1 === t.length && z(t[0]) ? t[0] : t, null).pipe(R(function(e) {
                return i.apply(void 0, e);
            }));
        }, r.from = O, r.iif = function(e, t, r) {
            return void 0 === t && (t = ye), void 0 === r && (r = ye), N(function() {
                return e() ? t : r;
            });
        }, r.interval = function(e, t) {
            return void 0 === e && (e = 0), void 0 === t && (t = Ae), (!M(e) || e < 0) && (e = 0), 
            t && "function" == typeof t.schedule || (t = Ae), new re(function(r) {
                return r.add(t.schedule(b, e, {
                    subscriber: r,
                    counter: 0,
                    period: e
                })), r;
            });
        }, r.isObservable = function(e) {
            return !!e && (e instanceof re || "function" == typeof e.lift && "function" == typeof e.subscribe);
        }, r.last = function(e, t) {
            var r = 2 <= arguments.length;
            return function(n) {
                return n.pipe(e ? P(function(t, r) {
                    return e(t, r, n);
                }) : T, B(1), r ? x(t) : k(function() {
                    return new Ce();
                }));
            };
        }, r.map = R, r.mapTo = function(e) {
            return function(t) {
                return t.lift(new Ot(e));
            };
        }, r.merge = function() {
            for (var e = arguments, t = [], r = 0; r < arguments.length; r++) t[r] = e[r];
            var n = Number.POSITIVE_INFINITY, o = null, i = t[t.length - 1];
            return f(i) ? (o = t.pop(), 1 < t.length && "number" == typeof t[t.length - 1] && (n = t.pop())) : "number" == typeof i && (n = t.pop()), 
            null === o && 1 === t.length && t[0] instanceof re ? t[0] : I(n)(S(t, o));
        }, r.mergeAll = I, r.mergeMap = A, r.multicast = H, r.never = function() {
            return He;
        }, r.noop = u, r.observable = te, r.of = _, r.race = function() {
            for (var e = arguments, t = [], r = 0; r < arguments.length; r++) t[r] = e[r];
            if (1 === t.length) {
                if (!z(t[0])) return t[0];
                t = t[0];
            }
            return S(t, void 0).lift(new Ye());
        }, r.refCount = d, r.repeatWhen = function(e) {
            return function(t) {
                return t.lift(new Nt(e));
            };
        }, r.retry = function(e) {
            return void 0 === e && (e = -1), function(t) {
                return t.lift(new Mt(e, t));
            };
        }, r.retryWhen = function(e) {
            return function(t) {
                return t.lift(new Pt(e, t));
            };
        }, r.scan = function(e, t) {
            var r = !1;
            return 2 <= arguments.length && (r = !0), function(n) {
                return n.lift(new It(e, t, r));
            };
        }, r.share = function() {
            return function(e) {
                return d()(H(j)(e));
            };
        }, r.skipWhile = function(e) {
            return function(t) {
                return t.lift(new Ut(e));
            };
        }, r.startWith = function() {
            for (var e = arguments, t = [], r = 0; r < arguments.length; r++) t[r] = e[r];
            var n = t[t.length - 1];
            return f(n) ? (t.pop(), function(e) {
                return D(t, e, n);
            }) : function(e) {
                return D(t, e);
            };
        }, r.switchAll = function() {
            return W(T);
        }, r.switchMap = W, r.take = function(e) {
            return function(t) {
                return 0 === e ? p() : t.lift(new _t(e));
            };
        }, r.takeUntil = function(e) {
            return function(t) {
                return t.lift(new Gt(e));
            };
        }, r.takeWhile = function(e, t) {
            return void 0 === t && (t = !1), function(r) {
                return r.lift(new Ht(e, t));
            };
        }, r.tap = function(e, t, r) {
            return function(n) {
                return n.lift(new Wt(e, t, r));
            };
        }, r.throwError = E, r.timeout = function(e, t) {
            return void 0 === t && (t = Ae), r = e, n = E(new De()), void 0 === (o = t) && (o = Ae), 
            function(e) {
                var t = F(r), i = t ? +r - o.now() : Math.abs(r);
                return e.lift(new Vt(i, t, n, o));
            };
            var r, n, o;
        }, r.timer = function(e, t, r) {
            void 0 === e && (e = 0);
            var n = -1;
            return M(t) ? n = Number(t) < 1 ? 1 : Number(t) : f(t) && (r = t), f(r) || (r = Ae), 
            new re(function(t) {
                var o = M(e) ? e : +e - r.now();
                return r.schedule(w, o, {
                    index: 0,
                    period: n,
                    subscriber: t
                });
            });
        }, r.timestamp = function(e) {
            return void 0 === e && (e = Ae), R(function(t) {
                return new Kt(t, e.now());
            });
        }, r.zip = function() {
            for (var e = arguments, t = [], r = 0; r < arguments.length; r++) t[r] = e[r];
            var n = t[t.length - 1];
            return "function" == typeof n && t.pop(), S(t, void 0).lift(new qe(n));
        };
    },
    418: function(e, t, r) {
        var n;
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.FrontEndErrorMsgMap = t.onlyLogSet = t.onErrorWhiteList = void 0, t.onErrorWhiteList = [ 4001, 4002 ], 
        t.onlyLogSet = new Set([ 4011, 6022, 13e3, 4013, 4014, 15e3, 2002, 16002, 16003, 17001, 17001 ]), 
        t.FrontEndErrorMsgMap = ((n = {})[1e3] = "前端校验图片错误，包含在 UploadError 中", n[1001] = "图片上传到 OSS 失败", 
        n[1002] = "wx.chooseImage 失败回调，且不是取消选择", n[1003] = "wx.chooseImage 成功回调，但 res 有问题", 
        n[1004] = "未知的图片上传失败", n[1005] = "wx.uploadFile 报错", n[1006] = "前端校验视频错误", n[1007] = "视频上传到 OSS 失败", 
        n[1008] = "视频 getFormData 失败", n[1009] = "wx.chooseVideo 失败回调，且不是取消选择", n[1010] = "wx.chooseVideo 成功回调，但 res 有问题", 
        n[1011] = "get_pre_oss_info 报错", n[1012] = "取消选择", n[1013] = "保存视频失败", n[1014] = "错误的文件路径", 
        n[1015] = "上传超时", n[1016] = "wx.chooseMedia 失败回调，且不是取消选择", n[1017] = "获取图片信息失败", 
        n[1018] = "选择多媒体失败", n[1019] = "多媒体校验错误", n[1020] = "未知的上传多媒体错误", n[1021] = "多媒体上传到 OSS 失败", 
        n[2e3] = "微信跳转页面方法报错", n[2001] = "页面栈爆栈", n[2002] = "用相同的参数连续跳两次", n[2003] = "pageNotFound 统一收集报错", 
        n[2004] = "pageNotFound 但实际有页面 ", n[2005] = "错误的页面参数", n[2006] = "获取页面参数失败", n[2007] = "群接龙+ 跳转 群接龙 小程序报错", 
        n[2008] = "跳转到其他小程序错误", n[2009] = "跳转小程序分享错误", n[2010] = "小程序推广员声明失败", n[2011] = "小程序推广员打开失败", 
        n[3e3] = "双帮ghId搜索团长缺少团长名称", n[3001] = "主页后台消息即服务，出现异常空消息", n[3002] = "没有优先调用getPrivateCustomerService", 
        n[3003] = "云函数getBannerActInfo执行失败", n[3004] = "云函数updateBannerActTapTimes执行失败", 
        n[3005] = "双帮搜索不良结果上报", n[3006] = "云函数getSupplyGhBetaActId执行失败", n[3007] = "云函数setSubmitSatisfactionEvaluation执行失败", 
        n[3008] = "帮卖广场明星品牌/团长缺少二维码", n[3009] = "邀请货源品牌，未获取到主页相关信息", n[3010] = "邀请选品团长，未获取到主页相关信息", 
        n[3011] = "团长裂变-邀请新人，未获取到主页相关信息", n[3012] = "通联提现灰度关闭", n[3013] = "与明星团长建立关系方法tap未执行", 
        n[3014] = "播放明星团长视频失败", n[4e3] = "富文本列表出现错误", n[4001] = "找不到商品 Tab", n[4002] = "在全部商品列表中找不到商品", 
        n[4003] = "标签操作错误", n[4004] = "参数错误", n[4005] = "缺少必要参数错误", n[4006] = "没有对应的发布活动接口", 
        n[4007] = "发布校验错误", n[4008] = "找不到对应的商品列表", n[4009] = "图片排序错误", n[4010] = "发布页灰度接口报错", 
        n[4011] = "发布页前端校验，无需关心", n[4012] = "商品库操作商品时找不到商品", n[4013] = "发布页崩溃草稿出现LOG", n[4014] = "发布页旧草稿使用LOG", 
        n[4015] = "撤销/重做时找不到id", n[4016] = "没有设置获取卡片的API", n[4017] = "富文本内容异常（例如类型内容没对上、以http(s)开头）", 
        n[4018] = "多规格数量太多了", n[4019] = "发布页旧草稿迁移至云数据库失败", n[4026] = "发布页崩溃草稿迁移至云数据库失败", 
        n[4020] = "onShow 的时候没有 groupId", n[4021] = "富文本错误", n[4022] = "phone 字段可能有异常", 
        n[4023] = "发布页setGrayInfo, 排查完就删", n[4024] = "想用集市接龙", n[4025] = "真的想用集市接龙", n[4027] = "实名认证跑马灯缺少创建者uid", 
        n[4028] = "复制活动分享失败", n[4029] = "编辑运费模板出现异常报错", n[4030] = "发布页获取草稿失败", n[5e3] = "非法邀请UID", 
        n[5001] = "获取用户信息失败 - getUserProfile - 获取用户信息非拒绝报错 ", n[5002] = "获取用户信息失败 - getUserInfo", 
        n[5003] = "相同主页id绑定关系", n[5005] = "个人主页登录失败", n[5006] = "未加密groupId触发次数", n[6e3] = "IM登录账号问题", 
        n[6001] = "没有绑定的客服Id", n[6002] = "自研IM发送消息失败", n[6005] = "卡片消息获取错误", n[6003] = "登出超时7s", 
        n[6004] = "登录超时10s", n[6006] = "在发送消息之后很久没有收到 command 7", n[6007] = "socket 收到 error", 
        n[6008] = "wx.connectSocket fail", n[6009] = "socket 连接中的未知错误", n[6010] = "wx.closeSocket fail", 
        n[6011] = "尝试在socket断开的时候发消息", n[6012] = "中间件报错", n[6013] = "获取 keyPairs 错误", n[6014] = "登录太频繁", 
        n[6015] = "登录超时", n[6016] = "未知的 socket 错误", n[6017] = "this.socket 没有值", n[6018] = "消息中的id与实际不符", 
        n[6019] = "客户端主动出发了close", n[6020] = "im底层播出的错误", n[6021] = "自研im service播出的错误", 
        n[6022] = "自研im 的log", n[6023] = "chat page onload init fail", n[6024] = "获取历史消息错误", 
        n[6025] = "获取用户信息错误", n[6026] = "播出消息错误", n[7e3] = "开孙团但是没有可以开的主页", n[7001] = "没有主办方的场景", 
        n[7002] = "详情长列表报错相关", n[7004] = "帮卖绑定关系没有ghId也没有邀请key", n[7005] = "帮卖详情返回的团长列表含有没绑定的团长", 
        n[7006] = "详情页绑定团长但是没有返回团长信息", n[7003] = "详情绑定但是没有对应的主页 - 废弃", n[7007] = "微信物流插件引入失败", 
        n[7008] = "单天生成短链超过50万上限", n[7012] = "没有选择的团长信息", n[7009] = "小程序版本库低，不能获取直播信息", 
        n[7010] = "小程序版本库低，不能跳转直播", n[7011] = "运营后台海报转发给了非目标客户", n[7013] = "选择团长关系常规报错处理监控", 
        n[7014] = "选择团长关系异常报错处理监控", n[7015] = "详情页选择团长超过5s没有数据返回", n[7016] = "需要绑定提货点才能发布子团", 
        n[7017] = "未知的团长福利活动状态", n[7018] = "下单成功没有订单号", n[7019] = "分享图没有订单号", n[7020] = "地址大于100个", 
        n[7021] = "查询物流异常调用快递100", n[8e3] = "解密数据失败", n[8001] = "加密数据失败", n[8002] = "请求中的其他错误", 
        n[8004] = "接口没有返回数据", n[8003] = "请求过程中的正常错误", n[8005] = "wx.getExptInfoSync 返回结果异常", 
        n[8006] = "200<=请求码 <400 但是responseCode < 200", n[8007] = "云函数获取请求200但是code非200不处理白名单报错", 
        n[8008] = "返回了非加密的个人主页id", n[8009] = "主页维度灰度两个接口返回值不一致", n[8010] = "意料之外的报错，要看一下原因", 
        n[9e3] = "realUse 失败", n[9001] = "set 失败", n[9002] = "assign 失败", n[9003] = "replace 失败", 
        n[9004] = "push 失败", n[9005] = "路径错误", n[9006] = "setData 失败", n[9007] = "callback 执行失败", 
        n[9008] = "内部 callback 执行失败", n[9009] = "assign 存在属性值 undefined", n[1e4] = "编辑评论错误", 
        n[11e3] = "没有胶囊数据", n[11001] = "拿不到 pageWrapperToast", n[11002] = "无法跳转拿到别的小程序", 
        n[11003] = "无法拿到进入小程序的群聊信息", n[12e3] = "列表下一页仍有数据，但当前页返回的数据条数小于pageSize", n[12001] = "列表接口未返回hasNext，无法翻页", 
        n[12002] = "自动加载下一页的次数超出限制", n[13e3] = "内存告警", n[13001] = "微信登录报错", n[14e3] = "从本地读mqtt缓存失败", 
        n[14001] = "未知的mqtt初始化失败", n[15e3] = "getFirstProductSeqIndex 异常捕获", n[15001] = "退款页面初始化时无 groupId", 
        n[15002] = "退款页面没有商品列表", n[15003] = "未知的订单操作", n[15004] = "接口未返回订单详情", n[15005] = "售后详情错误", 
        n[15006] = "售后详情协商记录错误", n[15007] = "售后列表接口错误", n[15008] = "售后列表列表数据", n[15009] = "售后列表数据为空", 
        n[15010] = "旧顾客订单列表页", n[15011] = "旧团长订单列表页", n[15012] = "旧拼团凭证详情页", n[15013] = "团长列表错误", 
        n[15014] = "PC自动打单lodop加载失败", n[16e3] = "日志存储错误", n[16001] = "发送日志错误", n[16002] = "日志存储服务初始化错误", 
        n[16003] = "获取日志文件错误", n[16004] = "删除日志文件错误", n[17002] = "授权失败", n[17001] = "授权信息错误", 
        n[18001] = "自定义log", n[18002] = "自定义warn", n[19001] = "429请求cdn成功", n[19002] = "429请求cdn失败", 
        n[20001] = "微信插屏广告加载错误", n[20002] = "微信Banner广告加载错误", n[21001] = "无效的日期", n);
    },
    420: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.ModifyMessageTotalNumReq = void 0, (t.ModifyMessageTotalNumReq || (t.ModifyMessageTotalNumReq = {})).EntranceEnum = {
            PERSON: "PERSON",
            GROUPMEMBER: "GROUP_MEMBER",
            GROUPHELPER: "GROUP_HELPER",
            COMPANYHELPER: "COMPANY_HELPER",
            SERVICEHOME: "SERVICE_HOME"
        };
    },
    421: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.QueryExclusiveGoodsParam = void 0, (t.QueryExclusiveGoodsParam || (t.QueryExclusiveGoodsParam = {})).SortEnum = {
            LATEST: "LATEST",
            TOTALSALES: "TOTAL_SALES",
            THIRTYDAYSALES: "THIRTY_DAY_SALES",
            YESTERDAYSALES: "YESTERDAY_SALES",
            HELPSALERATE: "HELP_SALE_RATE",
            CONVERSIONRATE: "CONVERSION_RATE"
        };
    },
    423: function(e, t, r) {
        var n, o, i;
        !function(a) {
            if (null != t && "number" != typeof t.nodeType) e.exports = a(); else if (null != r(657)) o = [], 
            void 0 === (i = "function" == typeof (n = a) ? n.apply(t, o) : n) || (e.exports = i); else {
                var s = a(), u = "undefined" != typeof self ? self : $.global;
                "function" != typeof u.btoa && (u.btoa = s.btoa), "function" != typeof u.atob && (u.atob = s.atob);
            }
        }(function() {
            function e(e) {
                this.message = e;
            }
            var t = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
            return e.prototype = new Error(), e.prototype.name = "InvalidCharacterError", {
                btoa: function(r) {
                    for (var n, o, i = String(r), a = 0, s = t, u = ""; i.charAt(0 | a) || (s = "=", 
                    a % 1); u += s.charAt(63 & n >> 8 - a % 1 * 8)) {
                        if ((o = i.charCodeAt(a += .75)) > 255) throw new e("'btoa' failed: The string to be encoded contains characters outside of the Latin1 range.");
                        n = n << 8 | o;
                    }
                    return u;
                },
                atob: function(r) {
                    var n = String(r).replace(/[=]+$/, "");
                    if (n.length % 4 == 1) throw new e("'atob' failed: The string to be decoded is not correctly encoded.");
                    for (var o, i, a = 0, s = 0, u = ""; i = n.charAt(s++); ~i && (o = a % 4 ? 64 * o + i : i, 
                    a++ % 4) ? u += String.fromCharCode(255 & o >> (-2 * a & 6)) : 0) i = t.indexOf(i);
                    return u;
                }
            };
        });
    },
    424: function(e, t, r) {
        var n;
        e.exports = (n = r(175), r(658), r(659), r(425), r(662), function() {
            var e = n, t = e.lib.BlockCipher, r = e.algo, o = [], i = [], a = [], s = [], u = [], c = [], l = [], d = [], p = [], f = [];
            !function() {
                for (var e = [], t = 0; t < 256; t++) e[t] = t < 128 ? t << 1 : t << 1 ^ 283;
                var r = 0, n = 0;
                for (t = 0; t < 256; t++) {
                    var h = n ^ n << 1 ^ n << 2 ^ n << 3 ^ n << 4;
                    h = h >>> 8 ^ 255 & h ^ 99, o[r] = h, i[h] = r;
                    var S = e[r], _ = e[S], E = e[_], y = 257 * e[h] ^ 16843008 * h;
                    a[r] = y << 24 | y >>> 8, s[r] = y << 16 | y >>> 16, u[r] = y << 8 | y >>> 24, c[r] = y, 
                    y = 16843009 * E ^ 65537 * _ ^ 257 * S ^ 16843008 * r, l[h] = y << 24 | y >>> 8, 
                    d[h] = y << 16 | y >>> 16, p[h] = y << 8 | y >>> 24, f[h] = y, r ? (r = S ^ e[e[e[E ^ S]]], 
                    n ^= e[e[n]]) : r = n = 1;
                }
            }();
            var h = [ 0, 1, 2, 4, 8, 16, 32, 64, 128, 27, 54 ], S = r.AES = t.extend({
                _doReset: function() {
                    if (!this._nRounds || this._keyPriorReset !== this._key) {
                        for (var e = this._keyPriorReset = this._key, t = e.words, r = e.sigBytes / 4, n = 4 * ((this._nRounds = r + 6) + 1), i = this._keySchedule = [], a = 0; a < n; a++) a < r ? i[a] = t[a] : (c = i[a - 1], 
                        a % r ? r > 6 && a % r == 4 && (c = o[c >>> 24] << 24 | o[c >>> 16 & 255] << 16 | o[c >>> 8 & 255] << 8 | o[255 & c]) : (c = o[(c = c << 8 | c >>> 24) >>> 24] << 24 | o[c >>> 16 & 255] << 16 | o[c >>> 8 & 255] << 8 | o[255 & c], 
                        c ^= h[a / r | 0] << 24), i[a] = i[a - r] ^ c);
                        for (var s = this._invKeySchedule = [], u = 0; u < n; u++) {
                            if (a = n - u, u % 4) var c = i[a]; else c = i[a - 4];
                            s[u] = u < 4 || a <= 4 ? c : l[o[c >>> 24]] ^ d[o[c >>> 16 & 255]] ^ p[o[c >>> 8 & 255]] ^ f[o[255 & c]];
                        }
                    }
                },
                encryptBlock: function(e, t) {
                    this._doCryptBlock(e, t, this._keySchedule, a, s, u, c, o);
                },
                decryptBlock: function(e, t) {
                    var r = e[t + 1];
                    e[t + 1] = e[t + 3], e[t + 3] = r, this._doCryptBlock(e, t, this._invKeySchedule, l, d, p, f, i), 
                    r = e[t + 1], e[t + 1] = e[t + 3], e[t + 3] = r;
                },
                _doCryptBlock: function(e, t, r, n, o, i, a, s) {
                    for (var u = this._nRounds, c = e[t] ^ r[0], l = e[t + 1] ^ r[1], d = e[t + 2] ^ r[2], p = e[t + 3] ^ r[3], f = 4, h = 1; h < u; h++) {
                        var S = n[c >>> 24] ^ o[l >>> 16 & 255] ^ i[d >>> 8 & 255] ^ a[255 & p] ^ r[f++], _ = n[l >>> 24] ^ o[d >>> 16 & 255] ^ i[p >>> 8 & 255] ^ a[255 & c] ^ r[f++], E = n[d >>> 24] ^ o[p >>> 16 & 255] ^ i[c >>> 8 & 255] ^ a[255 & l] ^ r[f++], y = n[p >>> 24] ^ o[c >>> 16 & 255] ^ i[l >>> 8 & 255] ^ a[255 & d] ^ r[f++];
                        c = S, l = _, d = E, p = y;
                    }
                    S = (s[c >>> 24] << 24 | s[l >>> 16 & 255] << 16 | s[d >>> 8 & 255] << 8 | s[255 & p]) ^ r[f++], 
                    _ = (s[l >>> 24] << 24 | s[d >>> 16 & 255] << 16 | s[p >>> 8 & 255] << 8 | s[255 & c]) ^ r[f++], 
                    E = (s[d >>> 24] << 24 | s[p >>> 16 & 255] << 16 | s[c >>> 8 & 255] << 8 | s[255 & l]) ^ r[f++], 
                    y = (s[p >>> 24] << 24 | s[c >>> 16 & 255] << 16 | s[l >>> 8 & 255] << 8 | s[255 & d]) ^ r[f++], 
                    e[t] = S, e[t + 1] = _, e[t + 2] = E, e[t + 3] = y;
                },
                keySize: 8
            });
            e.AES = t._createHelper(S);
        }(), n);
    },
    425: function(e, t, r) {
        var n, o, i, a, s, u, c, l;
        e.exports = (l = r(175), r(660), r(661), o = (n = l).lib, i = o.Base, a = o.WordArray, 
        s = n.algo, u = s.MD5, c = s.EvpKDF = i.extend({
            cfg: i.extend({
                keySize: 4,
                hasher: u,
                iterations: 1
            }),
            init: function(e) {
                this.cfg = this.cfg.extend(e);
            },
            compute: function(e, t) {
                for (var r, n = this.cfg, o = n.hasher.create(), i = a.create(), s = i.words, u = n.keySize, c = n.iterations; s.length < u; ) {
                    r && o.update(r), r = o.update(e).finalize(t), o.reset();
                    for (var l = 1; l < c; l++) r = o.finalize(r), o.reset();
                    i.concat(r);
                }
                return i.sigBytes = 4 * u, i;
            }
        }), n.EvpKDF = function(e, t, r) {
            return c.create(r).compute(e, t);
        }, l.EvpKDF);
    },
    426: function(e, t, r) {
        var n, o;
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.MessageType = t.LogDescription = t.LogLevel = void 0, function(e) {
            e[e.DEBUG = 1] = "DEBUG", e[e.INFO = 2] = "INFO", e[e.WARN = 3] = "WARN", e[e.ERROR = 4] = "ERROR", 
            e[e.FATAL = 5] = "FATAL";
        }(o = t.LogLevel || (t.LogLevel = {})), t.LogDescription = ((n = {})[o.DEBUG] = "Debug", 
        n[o.INFO] = "Info", n[o.WARN] = "Warn", n[o.ERROR] = "Error", n[o.FATAL] = "Fatal", 
        n), function(e) {
            e.API = "api", e.BEHAVIOR = "behavior", e.CALL = "call", e.ROUTE = "route", e.LIFETIME = "lifetime", 
            e.UNKNOWN = "unknown";
        }(t.MessageType || (t.MessageType = {}));
    },
    427: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.LogStorageService = void 0;
        var n = r(0), o = r(1), i = function() {
            function e() {}
            return e.prototype.save = function(e) {
                throw new Error("请实现 save 方法");
            }, e.prototype.delete = function(e) {
                throw new Error("请实现 delete 方法");
            }, e.prototype.deleteAll = function() {
                this.delete({
                    before: Date.now()
                });
            }, e.prototype.find = function(e) {
                throw new Error("请实现 find 方法");
            }, e = n.__decorate([ o.Injectable() ], e);
        }();
        t.LogStorageService = i;
    },
    428: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.MonoRxCloudService = void 0;
        var n = r(0), o = r(1), i = function() {
            function e() {}
            return e.prototype.setCloudApi = function(e) {
                this.cloudApi = e;
            }, e.prototype.rxCloud = function(e, t, r) {
                if (void 0 === r && (r = {}), !this.cloudApi) throw new Error("MonoRxCloudService 没有初始化 setCloudApi");
                return this.cloudApi.rxCloud(e, t, r);
            }, e = n.__decorate([ o.Injectable(), n.__metadata("design:paramtypes", []) ], e);
        }();
        t.MonoRxCloudService = i;
    },
    434: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.Abstract = t.createMixin = void 0;
        var n = Symbol("isAbstract");
        t.createMixin = function(e) {
            return void 0 === e && (e = {}), function(t, r, o, i, a, s, u) {
                var c = e.beforeMixin, l = e.beforeFinishMixin, d = [ t, r, o, i, a, s, u ].filter(function(e) {
                    return e;
                });
                c && c(d);
                var p = function() {
                    Object.getPrototypeOf(this).constructor.name, d.forEach(function(e) {
                        if (e) {
                            var t = [];
                            Object.keys(e.prototype).forEach(function(r) {
                                e.prototype[r] && e.prototype[r][n] && t.push(r);
                            }), t.forEach(function(e) {});
                        }
                    });
                };
                return d.filter(function(e) {
                    return !!e;
                }).forEach(function(t) {
                    !function e(t, r, n) {
                        if (t && t.prototype) {
                            var o = n.prototypeWillApply, i = n.prototypeDidApply;
                            o && o(t, r);
                            var a = r.prototype.__extendedClasses__;
                            if (!a || !a.has(t)) {
                                var s = t.__proto__;
                                s && e(s, r, n), Object.assign(r.prototype, t.prototype);
                                var u = new t();
                                Object.assign(r.prototype, u), r.prototype.__extendedClasses__ = (r.prototype.__extendedClasses__ || new Set()).add(t), 
                                i && i(t, r, u);
                            }
                        }
                    }(t, p, e);
                }), delete p.prototype.__extendedClasses__, l && l(d, p), p;
            };
        }, t.Abstract = function() {
            return function(e, t, r) {
                e[t][n] = !0;
            };
        };
    },
    435: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.MonoFileService = void 0;
        var n = r(0), o = r(1), i = r(7), a = r(321), s = r(3), u = r(24), c = r(20), l = {
            isSkipPageMarking: !0,
            hideErrorToast: !0,
            hideErrorToastForBusinessError: !0
        }, d = function() {
            function e(e, t) {
                this.errorService = e, this.monoCommonService = t;
            }
            return e.prototype.setConfig = function(e) {
                Object.assign(this, e), this.resHost.endsWith("/") && (this.resHost = this.resHost.slice(0, -1));
            }, e.prototype.getAliYunImageInfoBatch = function(e) {
                var t = this;
                return i.forkJoin(e.map(function(e) {
                    return t.getAliYunImageInfo(e);
                })).pipe(s.timeout(2e4), s.catchError(function(e) {
                    return i.of([]);
                }));
            }, e.prototype.getAliYunImageInfo = function(e) {
                var t = this, r = !e || "null" === e;
                return this.monoCommonService.checkMediaType(e, "svg") || r ? i.of(n.__assign(n.__assign({}, a.DEFAULT_IMAGE_INFO), {
                    url: e
                })) : this.httpClient.get(this.resHost + "/" + e + "?x-oss-process=image/info", {}, l).pipe(s.map(function(t) {
                    return {
                        url: e,
                        height: Number(t.ImageHeight.value || a.DEFAULT_IMAGE_HEIGHT),
                        width: Number(t.ImageWidth.value || a.DEFAULT_IMAGE_WIDTH)
                    };
                }), s.catchError(function(r) {
                    return t.errorService.customReportError({
                        frontErrorCode: 1017,
                        error: r
                    }), i.of(n.__assign({
                        url: e
                    }, a.DEFAULT_IMAGE_INFO));
                }));
            }, e = n.__decorate([ o.Injectable({
                providedIn: "root"
            }), n.__metadata("design:paramtypes", [ u.ErrorService, c.MonoCommonService ]) ], e);
        }();
        t.MonoFileService = d;
    },
    436: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.MonoChatUtilsService = t.TipsContentType = void 0;
        var n = r(0), o = r(1), i = r(11), a = r(35);
        Object.defineProperty(t, "TipsContentType", {
            enumerable: !0,
            get: function() {
                return a.TipsContentType;
            }
        });
        var s = r(18), u = function() {
            function e(e, t) {
                this.monoUtil = e, this.timeService = t;
            }
            return e.prototype.stringifyGuideTips = function(e, t) {
                return ("string" == typeof e ? JSON.parse(this.monoUtil.deleteStrangeCharacters(e) || "[]") || [] : e).reduce(function(e, r, n, o) {
                    if (r.type === a.TipsContentType.TEXT) return e + r.content;
                    if (r.type === a.TipsContentType.FROM_GROUP_NAME) return e + t;
                    if (r.type === a.TipsContentType.LINK) return e + r.content;
                    if (r.type === a.TipsContentType.LINK_AREA) return e + " " + r.content.join(" | ") + " ";
                    if (r.type === a.TipsContentType.SUPER_LINK) return e + r.content.text;
                    throw new Error("无法识别的文本类型");
                }, "");
            }, e.prototype.convertToTimeString = function(e) {
                return this.timeService.passDate(e, 1, !0, !1, !0);
            }, e = n.__decorate([ o.Injectable(), n.__metadata("design:paramtypes", [ i.MonoUtilService, s.TimeService ]) ], e);
        }();
        t.MonoChatUtilsService = u;
    },
    44: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.Debounce = void 0;
        var n = r(0);
        t.Debounce = function(e) {
            return void 0 === e && (e = 100), function(t, r, o) {
                var i, a = o.value;
                o.value = function() {
                    for (var t = this, r = [], o = 0; o < arguments.length; o++) r[o] = arguments[o];
                    i && clearTimeout(i), i = setTimeout(function() {
                        a.call.apply(a, n.__spread([ t ], r));
                    }, e);
                };
            };
        };
    },
    46: function(e, t, r) {
        var n;
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.LockProductSourceNameResult = t.SPU_NUMBER_PROPS = t.SPU_REQUIRED_PROPS = t.SPU_SINGLE_PROPS = t.CertificationAuditStatusEnum = t.SupplyBrandBindRelationStatusEnum = t.PRICE_LIMIT_MODE_OPTIONS = t.PriceLimitMode = t.PROPERTY_KEY_2_NAME_MAP = t.ProductSourceType = t.DEFAULT_CATEGORIES_NAME = t.DEFAULT_CATEGORIES_ID = t.ProductStatus = void 0, 
        function(e) {
            e[e.NORMAL = 10] = "NORMAL", e[e.SOLD_OUT = 5] = "SOLD_OUT", e[e.DELETED = 3] = "DELETED";
        }(t.ProductStatus || (t.ProductStatus = {})), function(e) {
            e[e.ALL = -1] = "ALL", e[e.UNCATEGORIZED = 0] = "UNCATEGORIZED";
        }(t.DEFAULT_CATEGORIES_ID || (t.DEFAULT_CATEGORIES_ID = {})), function(e) {
            e.ALL = "全部", e.UNCATEGORIZED = "未分类";
        }(t.DEFAULT_CATEGORIES_NAME || (t.DEFAULT_CATEGORIES_NAME = {})), function(e) {
            e[e.NOT_BOUND = 0] = "NOT_BOUND", e[e.OWN = 10] = "OWN", e[e.SUPPLY_COMPANY = 20] = "SUPPLY_COMPANY";
        }(t.ProductSourceType || (t.ProductSourceType = {})), t.PROPERTY_KEY_2_NAME_MAP = {
            actGoodsName: "商品名称",
            actGoodsUnit: "商品规格"
        }, function(e) {
            e[e.UNLIMITED = 0] = "UNLIMITED", e[e.NOT_LOWER_THAN_RECOMMENDED = 10] = "NOT_LOWER_THAN_RECOMMENDED", 
            e[e.MUST_USE_RECOMMENDED = 20] = "MUST_USE_RECOMMENDED";
        }(n = t.PriceLimitMode || (t.PriceLimitMode = {})), t.PRICE_LIMIT_MODE_OPTIONS = [ {
            label: "不限",
            value: n.UNLIMITED
        }, {
            label: "不低于建议价",
            value: n.NOT_LOWER_THAN_RECOMMENDED
        } ], function(e) {
            e[e.BING = 10] = "BING", e[e.UN_BIND = 5] = "UN_BIND";
        }(t.SupplyBrandBindRelationStatusEnum || (t.SupplyBrandBindRelationStatusEnum = {})), 
        function(e) {
            e[e.FAIL = 3] = "FAIL", e[e.PROCESS = 5] = "PROCESS", e[e.SUCCESS = 10] = "SUCCESS";
        }(t.CertificationAuditStatusEnum || (t.CertificationAuditStatusEnum = {})), t.SPU_SINGLE_PROPS = [ "goodsNo", "supplyPrice", "originalPrice", "costPrice", "evaluationPrice", "goodsWeight", "costPriceModel", "goodsStatus", "useStock", "groupBuyPrice", "totalStock", "commissionPercent", "goodsCost", "coopGroupPrice", "grandSonSaleCommission", "grandSonSaleCommissionPercent", "promoterCommission", "promoterCommissionPercent", "actGoodsStatus", "recommendedPrice", "realIncome", "followCommissionPercent" ], 
        t.SPU_REQUIRED_PROPS = new Set([ "costPriceModel", "groupBuyPrice", "totalStock", "actGoodsStatus" ]), 
        t.SPU_NUMBER_PROPS = new Set([ "supplyPrice", "originalPrice", "costPrice", "goodsWeight", "useStock", "groupBuyPrice", "totalStock", "commissionPercent", "goodsCost" ]), 
        function(e) {
            e[e.ALREADY_LOCK_NAME = 1] = "ALREADY_LOCK_NAME", e[e.EXISTS_NAME = 2] = "EXISTS_NAME", 
            e[e.LOCK_SUCCESS = 3] = "LOCK_SUCCESS", e[e.LOCK_FAIL = 4] = "LOCK_FAIL";
        }(t.LockProductSourceNameResult || (t.LockProductSourceNameResult = {}));
    },
    47: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.WxAdvertisementPositionType = t.WxAdvertisementBizType = t.WxAdvertisementType = void 0, 
        function(e) {
            e.CUSTOM = "CUSTOM", e.BANNER = "BANNER", e.BANNER_WITH_GUIDE = "BANNER_WITH_GUIDE";
        }(t.WxAdvertisementType || (t.WxAdvertisementType = {})), function(e) {
            e[e.INDEPENDENT_ONLY_CUSTOMER_HOMEPAGE = 1] = "INDEPENDENT_ONLY_CUSTOMER_HOMEPAGE";
        }(t.WxAdvertisementBizType || (t.WxAdvertisementBizType = {})), function(e) {
            e[e.UNDER_FIRST_ORDER_OF_JOINED_LIST = 1] = "UNDER_FIRST_ORDER_OF_JOINED_LIST", 
            e[e.UNDER_JOIN_SUCCESS_MODAL = 2] = "UNDER_JOIN_SUCCESS_MODAL", e[e.UNDER_WANT_JOIN_SEQ_BTN = 3] = "UNDER_WANT_JOIN_SEQ_BTN", 
            e[e.ON_MEMBER_LIST_SEARCH = 4] = "ON_MEMBER_LIST_SEARCH", e[e.BOTTOM_OF_REST_MONEY = 5] = "BOTTOM_OF_REST_MONEY", 
            e[e.ON_QR_CODE_OF_PROFILE_SETTINGS = 6] = "ON_QR_CODE_OF_PROFILE_SETTINGS", e[e.UNDER_PUBLISH_SUCCESS_MODAL = 7] = "UNDER_PUBLISH_SUCCESS_MODAL", 
            e[e.UNDER_REVENUE_ANALYSIS = 8] = "UNDER_REVENUE_ANALYSIS", e[e.ON_FIRST_ORDER_OF_ALL_SEQ_ORDER = 9] = "ON_FIRST_ORDER_OF_ALL_SEQ_ORDER", 
            e[e.ON_USER_LIST = 10] = "ON_USER_LIST", e[e.TAP_ANYONE_CREATE_SEQ = 11] = "TAP_ANYONE_CREATE_SEQ", 
            e[e.TAP_BTN_OF_SEQ_LIST_CARD = 12] = "TAP_BTN_OF_SEQ_LIST_CARD", e[e.PAN_COMMUNITY_ACTIVITY_CONTENT = 13] = "PAN_COMMUNITY_ACTIVITY_CONTENT";
        }(t.WxAdvertisementPositionType || (t.WxAdvertisementPositionType = {}));
    },
    5: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.DefaultService = void 0;
        var n = r(0), o = r(28);
        Object.defineProperty(t, "DefaultService", {
            enumerable: !0,
            get: function() {
                return o.DefaultService;
            }
        }), n.__exportStar(r(226), t);
    },
    50: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.WxCloudApiService = void 0;
        var n = r(0), o = r(428), i = r(1), a = function() {
            function e(e) {
                this.rxCloudService = e;
            }
            return e.prototype.batchMarkReadRedDotV2 = function(e, t) {
                return this.rxCloudService.rxCloud("batchMarkReadRedDotV2", e, t);
            }, e.prototype.deleteSeqDraftBox = function(e, t) {
                return this.rxCloudService.rxCloud("deleteSeqDraftBox", e, t);
            }, e.prototype.appsCanIUse = function(e, t) {
                return this.rxCloudService.rxCloud("appsCanIUse", e, t);
            }, e.prototype.deleteFreightShareRecord = function(e, t) {
                return this.rxCloudService.rxCloud("deleteFreightShareRecord", e, t);
            }, e.prototype.getAdvertisementList = function(e, t) {
                return this.rxCloudService.rxCloud("getAdvertisementList", e, t);
            }, e.prototype.getAgreementConfig = function(e, t) {
                return this.rxCloudService.rxCloud("getAgreementConfig", e, t);
            }, e.prototype.getBannerActInfo = function(e, t) {
                return this.rxCloudService.rxCloud("getBannerActInfo", e, t);
            }, e.prototype.getEvaluationMeetingConfig = function(e, t) {
                return this.rxCloudService.rxCloud("getEvaluationMeetingConfig", e, t);
            }, e.prototype.getFakeSeparateMarqueeText = function(e, t) {
                return this.rxCloudService.rxCloud("getFakeSeparateMarqueeText", e, t);
            }, e.prototype.getFreightShareRecord = function(e, t) {
                return this.rxCloudService.rxCloud("getFreightShareRecord", e, t);
            }, e.prototype.getIsInExclusiveProductWarehouseWhiteList = function(e, t) {
                return this.rxCloudService.rxCloud("getIsInExclusiveProductWarehouseWhiteList", e, t);
            }, e.prototype.getLatestUpdateTimes = function(e, t) {
                return this.rxCloudService.rxCloud("getLatestUpdateTimes", e, t);
            }, e.prototype.getHomeBackendBanners = function(e, t) {
                return this.rxCloudService.rxCloud("getHomeBackendBanners", e, t);
            }, e.prototype.getModelInfoByQJLV2 = function(e, t) {
                return this.rxCloudService.rxCloud("getModelInfoByQJLV2", e, t);
            }, e.prototype.getPageSeparateMarqueeText = function(e, t) {
                return this.rxCloudService.rxCloud("getPageSeparateMarqueeText", e, t);
            }, e.prototype.getPublishSeqMenu = function(e, t) {
                return this.rxCloudService.rxCloud("getPublishSeqMenu", e, t);
            }, e.prototype.getRedDotListV2 = function(e, t) {
                return this.rxCloudService.rxCloud("getRedDotListV2", e, t);
            }, e.prototype.getRemoteActionList = function(e, t) {
                return this.rxCloudService.rxCloud("getRemoteActionList", e, t);
            }, e.prototype.getSeqDraftBoxList = function(e, t) {
                return this.rxCloudService.rxCloud("getSeqDraftBoxList", e, t);
            }, e.prototype.getSeqDraftBoxDetail = function(e, t) {
                return this.rxCloudService.rxCloud("getSeqDraftBoxDetail", e, t);
            }, e.prototype.getRoomOpenGid = function(e, t) {
                return this.rxCloudService.rxCloud("getRoomOpenGid", e, t);
            }, e.prototype.getSeqDraftBoxLength = function(e, t) {
                return this.rxCloudService.rxCloud("getSeqDraftBoxLength", e, t);
            }, e.prototype.getShortLink = function(e, t) {
                return this.rxCloudService.rxCloud("getShortLink", e, t);
            }, e.prototype.getSupplyGhBetaActId = function(e, t) {
                return this.rxCloudService.rxCloud("getSupplyGhBetaActId", e, t);
            }, e.prototype.getSmartParsingAddress = function(e, t) {
                return this.rxCloudService.rxCloud("getSmartParsingAddress", e, t);
            }, e.prototype.getTransferPageConfig = function(e, t) {
                return this.rxCloudService.rxCloud("getTransferPageConfig", e, t);
            }, e.prototype.getTempMiniAppid = function(e, t) {
                return this.rxCloudService.rxCloud("getTempMiniAppid", e, t);
            }, e.prototype.getUrlLink = function(e, t) {
                return this.rxCloudService.rxCloud("getUrlLink", e, t);
            }, e.prototype.getWxGuideModalInfo = function(e, t) {
                return this.rxCloudService.rxCloud("getWxGuideModalInfo", e, t);
            }, e.prototype.operateShortLinkCache = function(e, t) {
                return this.rxCloudService.rxCloud("operateShortLinkCache", e, t);
            }, e.prototype.operateUrlLinkCache = function(e, t) {
                return this.rxCloudService.rxCloud("operateUrlLinkCache", e, t);
            }, e.prototype.setFreightShareRecord = function(e, t) {
                return this.rxCloudService.rxCloud("setFreightShareRecord", e, t);
            }, e.prototype.setModelInfoByQJLV2 = function(e, t) {
                return this.rxCloudService.rxCloud("setModelInfoByQJLV2", e, t);
            }, e.prototype.appsCanIUseChange = function(e, t) {
                return this.rxCloudService.rxCloud("appsCanIUseChange", e, t);
            }, e.prototype.checkSeqDraftExist = function(e, t) {
                return this.rxCloudService.rxCloud("checkSeqDraftExist", e, t);
            }, e.prototype.setSubmitSatisfactionEvaluation = function(e, t) {
                return this.rxCloudService.rxCloud("setSubmitSatisfactionEvaluation", e, t);
            }, e.prototype.setSeqDraftBox = function(e, t) {
                return this.rxCloudService.rxCloud("setSeqDraftBox", e, t);
            }, e.prototype.updateBannerActTapTimes = function(e, t) {
                return this.rxCloudService.rxCloud("updateBannerActTapTimes", e, t);
            }, e = n.__decorate([ i.Injectable(), n.__metadata("design:paramtypes", [ o.MonoRxCloudService ]) ], e);
        }();
        t.WxCloudApiService = a;
    },
    519: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.ImDataProcessService = void 0;
        var n = r(0), o = r(1), i = r(35), a = r(168), s = function() {
            function e(e) {
                this.monoImDataService = e;
            }
            return e.prototype.extractIChatInfo = function(e) {
                var t = JSON.parse(e.chatContent || "{}");
                return void 0 === t.type && (t.type = i.ChatType.NONE), void 0 === t.content && (t.content = {}), 
                {
                    type: t.type,
                    content: this.monoImDataService.getContentByIChat(t),
                    time: t.time,
                    clientMessageId: t.clientMessageId || "",
                    contentInfo: {
                        fromId: t.fromId,
                        toId: t.toId
                    }
                };
            }, e = n.__decorate([ o.Injectable(), n.__metadata("design:paramtypes", [ a.MonoImDataService ]) ], e);
        }();
        t.ImDataProcessService = s;
    },
    55: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.Throttle = void 0, t.Throttle = function(e, t) {
            return void 0 === e && (e = 100), void 0 === t && (t = {
                leading: !0,
                trailing: !1
            }), function(r, n, o) {
                var i, a = o.value, s = 0, u = [];
                o.value = function() {
                    for (var r = this, n = [], o = 0; o < arguments.length; o++) n[o] = arguments[o];
                    u = n, s++, i || (t.leading && a.apply(this, n), i = setTimeout(function() {
                        !t.trailing || t.leading && 1 === s || (a.apply(r, u.slice()), u.length = 0), i = null, 
                        s = 0;
                    }, e));
                };
            };
        };
    },
    59: function(e, t, r) {
        var n, o;
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.RichTextItemMode = t.SeqStatusText = t.NameCardType = t.ActivityOwnerRole = t.RICH_TEXT_NAME_OBJ = t.RichTextContentMediaType = void 0, 
        function(e) {
            e.IMG = "img", e.VIDEO = "video", e.TXT = "txt";
        }(t.RichTextContentMediaType || (t.RichTextContentMediaType = {})), t.RICH_TEXT_NAME_OBJ = ((n = {}).text = "文字", 
        n.singleImg = "大图", n.multiImg = "小图", n.video = "视频", n.link = "链接", n.tag = "标签", 
        n.activity = "其他接龙", n.nameCard = "快捷加粉", n.position = "位置", n.liveCard = "直播活动", 
        n.wechatChannels = "视频号", n.serviceCommitment = "团长承诺", n), function(e) {
            e[e.PARENT = 1] = "PARENT", e[e.CHILD = 2] = "CHILD", e[e.GRANDCHILD = 3] = "GRANDCHILD";
        }(t.ActivityOwnerRole || (t.ActivityOwnerRole = {})), function(e) {
            e[e.WECHAT_NUM = 0] = "WECHAT_NUM", e[e.WECHAT_GROUP = 1] = "WECHAT_GROUP", e[e.OFFICIAL_ACCOUNT = 2] = "OFFICIAL_ACCOUNT";
        }(t.NameCardType || (t.NameCardType = {})), t.SeqStatusText = ((o = {})[10] = "正在接龙", 
        o[8] = "未发布", o[9] = "未开始", o[5] = "已结束", o), function(e) {
            e.NORMAL = "normal", e.SERVICE_COMMITMENT = "serviceCommitment";
        }(t.RichTextItemMode || (t.RichTextItemMode = {}));
    },
    601: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.ActStatQueryParam = void 0, (t.ActStatQueryParam || (t.ActStatQueryParam = {})).StatQueryTypeEnum = {
            ORIAMOUNT: "ORI_AMOUNT",
            AMOUNT: "AMOUNT",
            ACTUALAMOUNT: "ACTUAL_AMOUNT",
            REFUNDAMOUNT: "REFUND_AMOUNT",
            USEAMOUNT: "USE_AMOUNT"
        };
    },
    602: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.AgentInvitedGroupParam = void 0, function(e) {
            e.GroupPageTypeEnumEnum = {
                ALL: "ALL",
                GHTYPECOMPANY: "GH_TYPE_COMPANY",
                GHTYPEGROUP: "GH_TYPE_GROUP",
                GHTYPECIRCLE: "GH_TYPE_CIRCLE",
                PERSON: "PERSON",
                COMMUNITY: "COMMUNITY",
                ASSOCIATIONHOME: "ASSOCIATION_HOME",
                GHTYPEGROUPCOMPANY: "GH_TYPE_GROUP_COMPANY",
                GHTYPEGROUPGROUP: "GH_TYPE_GROUP_GROUP",
                GHTYPESTORE: "GH_TYPE_STORE",
                DLVTYPECOMPANY: "DLV_TYPE_COMPANY",
                DLVTYPEGROUP: "DLV_TYPE_GROUP"
            }, e.GroupStatusEnumEnum = {
                ALL: "ALL",
                USESTATUSUSING: "USE_STATUS_USING",
                USESTATUSTRYING: "USE_STATUS_TRYING",
                USESTATUSEXPIREOPEN: "USE_STATUS_EXPIRE_OPEN",
                USESTATUSEXPIRETRY: "USE_STATUS_EXPIRE_TRY",
                USESTATUSEXPIRE: "USE_STATUS_EXPIRE"
            };
        }(t.AgentInvitedGroupParam || (t.AgentInvitedGroupParam = {}));
    },
    603: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.AgentWithDrawApplyVo = void 0, function(e) {
            e.WithdrawStatusEnumEnum = {
                CREATE: "CREATE",
                EXPENDSUCCESS: "EXPEND_SUCCESS",
                EXPENDFAIL: "EXPEND_FAIL",
                APPLYSUCCESS: "APPLY_SUCCESS",
                APPLYFAIL: "APPLY_FAIL",
                APPLYNOTEXIST: "APPLY_NOT_EXIST",
                ENTRYSUCCESS: "ENTRY_SUCCESS",
                ENTRYFAIL: "ENTRY_FAIL"
            }, e.ReturnStatusEnumEnum = {
                UNRETURN: "UN_RETURN",
                RETURNED: "RETURNED"
            };
        }(t.AgentWithDrawApplyVo || (t.AgentWithDrawApplyVo = {}));
    },
    604: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.AppraisalDetailResp = void 0, (t.AppraisalDetailResp || (t.AppraisalDetailResp = {})).StatusEnumEnum = {
            INIT: "INIT",
            REVIEWED: "REVIEWED",
            BAN: "BAN"
        };
    },
    605: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.AppraisalPostReq = void 0, function(e) {
            e.LogisticsServicesEnum = {
                VERYPOOR: "VERY_POOR",
                ORDINARY: "ORDINARY",
                PRETTYGOOD: "PRETTY_GOOD",
                SATISFACTION: "SATISFACTION",
                VERYGOOD: "VERY_GOOD"
            }, e.ProductQualityEnum = {
                VERYPOOR: "VERY_POOR",
                ORDINARY: "ORDINARY",
                PRETTYGOOD: "PRETTY_GOOD",
                SATISFACTION: "SATISFACTION",
                VERYGOOD: "VERY_GOOD"
            }, e.BrandServiceEnum = {
                VERYPOOR: "VERY_POOR",
                ORDINARY: "ORDINARY",
                PRETTYGOOD: "PRETTY_GOOD",
                SATISFACTION: "SATISFACTION",
                VERYGOOD: "VERY_GOOD"
            };
        }(t.AppraisalPostReq || (t.AppraisalPostReq = {}));
    },
    606: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.AuditTextResultParam = void 0, (t.AuditTextResultParam || (t.AuditTextResultParam = {})).AuditTextStatusEnumEnum = {
            SUC: "SUC",
            FAIL: "FAIL",
            ING: "ING"
        };
    },
    607: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.BannerConfigDTO = void 0, (t.BannerConfigDTO || (t.BannerConfigDTO = {})).ActionTypeEnum = {
            MINI: "MINI",
            H5: "H5",
            MODAL: "MODAL",
            IMAGE: "IMAGE",
            THIRDPARTY: "THIRDPARTY"
        };
    },
    608: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.BindAgentGhInfoVO = void 0, (t.BindAgentGhInfoVO || (t.BindAgentGhInfoVO = {})).BindStatusEnum = {
            NOTEXIST: "NOT_EXIST",
            BIND: "BIND",
            UNBIND: "UN_BIND"
        };
    },
    609: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.BindAgentUserInfoVO = void 0, (t.BindAgentUserInfoVO || (t.BindAgentUserInfoVO = {})).BindStatusEnum = {
            NOTEXIST: "NOT_EXIST",
            BIND: "BIND",
            UNBIND: "UN_BIND"
        };
    },
    610: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.ChatDataReq = void 0, (t.ChatDataReq || (t.ChatDataReq = {})).TimeRangeEnum = {
            Today: "today",
            Yesterday: "yesterday",
            Seven: "seven",
            Thirty: "thirty",
            His: "his"
        };
    },
    611: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.ChatFansExportReq = void 0, (t.ChatFansExportReq || (t.ChatFansExportReq = {})).TimeRangeEnum = {
            Today: "today",
            Yesterday: "yesterday",
            Seven: "seven",
            Thirty: "thirty",
            His: "his"
        };
    },
    612: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.CommissionSendDTO = void 0, (t.CommissionSendDTO || (t.CommissionSendDTO = {})).SelectTypeEnum = {
            FORWARD: "FORWARD",
            BACKWARD: "BACKWARD"
        };
    },
    613: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.CompanyConfirmReceiptParam = void 0, (t.CompanyConfirmReceiptParam || (t.CompanyConfirmReceiptParam = {})).SelectTypeEnum = {
            FORWARD: "FORWARD",
            BACKWARD: "BACKWARD"
        };
    },
    614: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.ConfirmReceiveCommissionParam = void 0, (t.ConfirmReceiveCommissionParam || (t.ConfirmReceiveCommissionParam = {})).SelectTypeEnum = {
            FORWARD: "FORWARD",
            BACKWARD: "BACKWARD"
        };
    },
    615: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.CustomerOrderQueryParamDTO = void 0, function(e) {
            e.ResultHandleTypeEnum = {
                PREVIEW: "PRE_VIEW",
                SENDEMAIL: "SEND_EMAIL"
            }, e.ExportDimensionEnum = {
                ORDEREACHROW: "ORDER_EACH_ROW",
                GOODSEACHROW: "GOODS_EACH_ROW",
                BOTH: "BOTH"
            };
        }(t.CustomerOrderQueryParamDTO || (t.CustomerOrderQueryParamDTO = {}));
    },
    616: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.FansBuyGoodsReq = void 0, (t.FansBuyGoodsReq || (t.FansBuyGoodsReq = {})).TimeRangeEnum = {
            Today: "today",
            Yesterday: "yesterday",
            Seven: "seven",
            Thirty: "thirty",
            His: "his"
        };
    },
    617: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.GetFansListReq = void 0, (t.GetFansListReq || (t.GetFansListReq = {})).TimeRangeEnum = {
            Today: "today",
            Yesterday: "yesterday",
            Seven: "seven",
            Thirty: "thirty",
            His: "his"
        };
    },
    618: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.GhDataSettingItemVO = void 0, function(e) {
            e.DataItemEnum = {
                ORDERNUM: "ORDER_NUM",
                PAYMENTAMOUNT: "PAYMENT_AMOUNT",
                COMMISSIONINCOME: "COMMISSION_INCOME",
                COMMISSIONOUTCOME: "COMMISSION_OUTCOME",
                GHUV: "GH_UV",
                PARTICIPANTSNUM: "PARTICIPANTS_NUM",
                CONVERSIONRATE: "CONVERSION_RATE",
                SALESVOLUME: "SALES_VOLUME",
                REFUNDAMOUNT: "REFUND_AMOUNT",
                CUSTOMERPRICE: "CUSTOMER_PRICE",
                REPURCHASERATE: "REPURCHASE_RATE",
                NEWORDERNUM: "NEW_ORDERNUM",
                PAYGOODSPRICE: "PAY_GOODSPRICE"
            }, e.SettingEnum = {
                ON: "ON",
                OFF: "OFF"
            };
        }(t.GhDataSettingItemVO || (t.GhDataSettingItemVO = {}));
    },
    619: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.GhGoodsSaleDataReq = void 0, (t.GhGoodsSaleDataReq || (t.GhGoodsSaleDataReq = {})).TimeRangeEnum = {
            Today: "today",
            Yesterday: "yesterday",
            Seven: "seven",
            Thirty: "thirty",
            His: "his"
        };
    },
    620: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.IMAccountDTO = void 0, (t.IMAccountDTO || (t.IMAccountDTO = {})).AccountStatusEnumEnum = {
            ONLINE: "ONLINE",
            PUSHONLINE: "PUSH_ONLINE",
            OFFLINE: "OFFLINE"
        };
    },
    621: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.ImOnlineReq = void 0, (t.ImOnlineReq || (t.ImOnlineReq = {})).GpsTypeEnum = {
            CO: "CO",
            GH: "GH",
            OP: "OP"
        };
    },
    622: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.JoinPayMchCategoryDTO = void 0, (t.JoinPayMchCategoryDTO || (t.JoinPayMchCategoryDTO = {})).MerchantTypeEnum = {
            _2: "2",
            _3: "3"
        };
    },
    623: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.JoinPayMchCategoryParam = void 0, (t.JoinPayMchCategoryParam || (t.JoinPayMchCategoryParam = {})).MerchantTypeEnum = {
            _2: "2",
            _3: "3"
        };
    },
    624: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.KfSceneParamDTO = void 0, (t.KfSceneParamDTO || (t.KfSceneParamDTO = {})).SceneEnum = {
            ACTDETAIL: "ACT_DETAIL",
            MEMBERLIST: "MEMBER_LIST",
            GHFRONT: "GH_FRONT",
            MSGLIST: "MSG_LIST",
            ORDERLIST: "ORDER_LIST",
            ORDERDETAIL: "ORDER_DETAIL",
            AFTERSALEDETAIL: "AFTER_SALE_DETAIL",
            DEFAULT: "DEFAULT"
        };
    },
    625: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.KfUserInfoDTO = void 0, (t.KfUserInfoDTO || (t.KfUserInfoDTO = {})).SceneEnum = {
            ACTDETAIL: "ACT_DETAIL",
            MEMBERLIST: "MEMBER_LIST",
            GHFRONT: "GH_FRONT",
            MSGLIST: "MSG_LIST",
            ORDERLIST: "ORDER_LIST",
            ORDERDETAIL: "ORDER_DETAIL",
            AFTERSALEDETAIL: "AFTER_SALE_DETAIL",
            DEFAULT: "DEFAULT"
        };
    },
    626: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.MerchantOrderCustomParam = void 0, function(e) {
            e.ResultHandleTypeEnum = {
                PREVIEW: "PRE_VIEW",
                SENDEMAIL: "SEND_EMAIL"
            }, e.ExportTypeEnumEnum = {
                COMMON: "ORDER_EXPORT_COMMON",
                SUPPLYBRAND: "ORDER_EXPORT_SUPPLY_BRAND",
                FOLLOWGROUP: "ORDER_EXPORT_FOLLOW_GROUP",
                All: "ORDER_EXPORT_All"
            }, e.ExportModelEnum = {
                SIMPLE: "SIMPLE",
                CUSTOMIZED: "CUSTOMIZED",
                FULL: "FULL"
            }, e.LogisticsTemplateEnumEnum = {
                NONETEMPLATE: "NONE_TEMPLATE",
                FIXEDTEMPLATE: "FIXED_TEMPLATE",
                CUSTOMTEMPLATE: "CUSTOM_TEMPLATE"
            }, e.ExportDimensionEnum = {
                ORDEREACHROW: "ORDER_EACH_ROW",
                GOODSEACHROW: "GOODS_EACH_ROW",
                BOTH: "BOTH"
            };
        }(t.MerchantOrderCustomParam || (t.MerchantOrderCustomParam = {}));
    },
    627: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.OfflineMsgDTO = void 0, (t.OfflineMsgDTO || (t.OfflineMsgDTO = {})).SendTypeEnum = {
            GHTOC: "GH_TO_C",
            CTOGH: "C_TO_GH",
            GHTOGH: "GH_TO_GH",
            CTOC: "C_TO_C",
            OPTOC: "OP_TO_C",
            CTOOP: "C_TO_OP",
            GHTOOP: "GH_TO_OP",
            OPTOGH: "OP_TO_GH"
        };
    },
    628: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.OneChatDataReq = void 0, (t.OneChatDataReq || (t.OneChatDataReq = {})).TimeRangeEnum = {
            Today: "today",
            Yesterday: "yesterday",
            Seven: "seven",
            Thirty: "thirty",
            His: "his"
        };
    },
    629: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.OptAgentStatusParam = void 0, (t.OptAgentStatusParam || (t.OptAgentStatusParam = {})).OptEnumEnum = {
            STOP: "STOP",
            START: "START"
        };
    },
    630: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.OptItemReq = void 0, (t.OptItemReq || (t.OptItemReq = {})).OptSubEnum = {
            SUB: "SUB",
            UNSUB: "UN_SUB"
        };
    },
    631: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.OptOfflinePaymentSubReq = void 0, (t.OptOfflinePaymentSubReq || (t.OptOfflinePaymentSubReq = {})).OptSubEnum = {
            SUB: "SUB",
            UNSUB: "UN_SUB"
        };
    },
    632: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.OrderExportModelDTO = void 0, function(e) {
            e.ExportModelEnum = {
                SIMPLE: "SIMPLE",
                CUSTOMIZED: "CUSTOMIZED",
                FULL: "FULL"
            }, e.LogisticsTemplateEnumEnum = {
                NONETEMPLATE: "NONE_TEMPLATE",
                FIXEDTEMPLATE: "FIXED_TEMPLATE",
                CUSTOMTEMPLATE: "CUSTOM_TEMPLATE"
            }, e.ExportDimensionEnum = {
                ORDEREACHROW: "ORDER_EACH_ROW",
                GOODSEACHROW: "GOODS_EACH_ROW",
                BOTH: "BOTH"
            };
        }(t.OrderExportModelDTO || (t.OrderExportModelDTO = {}));
    },
    633: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.OrderExportModelQueryParam = void 0, function(e) {
            e.ExportTypeEnumEnum = {
                COMMON: "ORDER_EXPORT_COMMON",
                SUPPLYBRAND: "ORDER_EXPORT_SUPPLY_BRAND",
                FOLLOWGROUP: "ORDER_EXPORT_FOLLOW_GROUP",
                All: "ORDER_EXPORT_All"
            }, e.OrderExportBusinessDimensionEnum = {
                ORDEREXPORTBUSINESSDIMENSION: "ORDER_EXPORT_BUSINESS_DIMENSION",
                LOGISTICSEXPORTBUSINESS: "LOGISTICS_EXPORT_BUSINESS"
            };
        }(t.OrderExportModelQueryParam || (t.OrderExportModelQueryParam = {}));
    },
    634: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.OrderExportQueryParam = void 0, function(e) {
            e.ResultHandleTypeEnum = {
                PREVIEW: "PRE_VIEW",
                SENDEMAIL: "SEND_EMAIL"
            }, e.ExportDimensionEnum = {
                ORDEREACHROW: "ORDER_EACH_ROW",
                GOODSEACHROW: "GOODS_EACH_ROW",
                BOTH: "BOTH"
            }, e.OrderTypeExportEnumEnum = {
                NORMALPCORDER: "NORMAL_PC_ORDER",
                GROUPPCORDER: "GROUP_PC_ORDER"
            }, e.ExportModelEnum = {
                SIMPLE: "SIMPLE",
                CUSTOMIZED: "CUSTOMIZED",
                FULL: "FULL"
            }, e.LogisticsTemplateEnumEnum = {
                NONETEMPLATE: "NONE_TEMPLATE",
                FIXEDTEMPLATE: "FIXED_TEMPLATE",
                CUSTOMTEMPLATE: "CUSTOM_TEMPLATE"
            };
        }(t.OrderExportQueryParam || (t.OrderExportQueryParam = {}));
    },
    635: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.OrderExportResultDTO = void 0, (t.OrderExportResultDTO || (t.OrderExportResultDTO = {})).StatusEnum = {
            WAITING: "WAITING",
            EXPORTING: "EXPORTING",
            EXPORTSUCCESS: "EXPORT_SUCCESS",
            EXPORTFAIL: "EXPORT_FAIL"
        };
    },
    636: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.OrderRemindMeUpdateReq = void 0, (t.OrderRemindMeUpdateReq || (t.OrderRemindMeUpdateReq = {})).RemindMeEnumEnum = {
            DONREMIND: "DON_REMIND",
            REMIND: "REMIND"
        };
    },
    637: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.OrderReturnOptResDTO = void 0, function(e) {
            e.OptResultEnumEnum = {
                DATANOTFOUND: "DATA_NOT_FOUND",
                BALANCELACK: "BALANCE_LACK",
                VAILFAIL: "VAIL_FAIL",
                SERVICERETURNFAIL: "SERVICE_RETURN_FAIL",
                CUTPAYMENTFAIL: "CUT_PAYMENT_FAIL",
                GATEWAYREFUNDFAIL: "GATE_WAY_REFUND_FAIL",
                SUCCESS: "SUCCESS"
            }, e.OrderReturnDealResultEnum = {
                INPROGRESS: "IN_PROGRESS",
                SUCCESS: "SUCCESS",
                FAIL: "FAIL"
            };
        }(t.OrderReturnOptResDTO || (t.OrderReturnOptResDTO = {}));
    },
    638: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.OrderReturnOptResultDTO = void 0, function(e) {
            e.OptResultEnumEnum = {
                DATANOTFOUND: "DATA_NOT_FOUND",
                BALANCELACK: "BALANCE_LACK",
                VAILFAIL: "VAIL_FAIL",
                SERVICERETURNFAIL: "SERVICE_RETURN_FAIL",
                CUTPAYMENTFAIL: "CUT_PAYMENT_FAIL",
                GATEWAYREFUNDFAIL: "GATE_WAY_REFUND_FAIL",
                SUCCESS: "SUCCESS"
            }, e.OrderReturnDealResultEnum = {
                INPROGRESS: "IN_PROGRESS",
                SUCCESS: "SUCCESS",
                FAIL: "FAIL"
            };
        }(t.OrderReturnOptResultDTO || (t.OrderReturnOptResultDTO = {}));
    },
    639: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.OrderReturnOptResultDTOV2 = void 0, function(e) {
            e.OptResultEnumEnum = {
                DATANOTFOUND: "DATA_NOT_FOUND",
                BALANCELACK: "BALANCE_LACK",
                VAILFAIL: "VAIL_FAIL",
                SERVICERETURNFAIL: "SERVICE_RETURN_FAIL",
                CUTPAYMENTFAIL: "CUT_PAYMENT_FAIL",
                GATEWAYREFUNDFAIL: "GATE_WAY_REFUND_FAIL",
                SUCCESS: "SUCCESS"
            }, e.OrderReturnDealResultEnum = {
                INPROGRESS: "IN_PROGRESS",
                SUCCESS: "SUCCESS",
                FAIL: "FAIL"
            };
        }(t.OrderReturnOptResultDTOV2 || (t.OrderReturnOptResultDTOV2 = {}));
    },
    640: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.OrderSettingRsp = void 0, function(e) {
            e.OrderMsgSettingEnumEnum = {
                NOPERMISSION: "NO_PERMISSION",
                UNSET: "UN_SET",
                SENDPER: "SEND_PER",
                SENDPER10: "SEND_PER_10",
                SHUTDOWN: "SHUTDOWN"
            }, e.RemindMeEnumEnum = {
                DONREMIND: "DON_REMIND",
                REMIND: "REMIND"
            };
        }(t.OrderSettingRsp || (t.OrderSettingRsp = {}));
    },
    641: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.OrderSettingUpdateReq = void 0, (t.OrderSettingUpdateReq || (t.OrderSettingUpdateReq = {})).OrderMsgSettingEnumEnum = {
            NOPERMISSION: "NO_PERMISSION",
            UNSET: "UN_SET",
            SENDPER: "SEND_PER",
            SENDPER10: "SEND_PER_10",
            SHUTDOWN: "SHUTDOWN"
        };
    },
    642: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.PullMyMessageParam = void 0, (t.PullMyMessageParam || (t.PullMyMessageParam = {})).DirectionEnum = {
            ASC: "ASC",
            DESC: "DESC"
        };
    },
    643: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.PullRecallMessageParam = void 0, (t.PullRecallMessageParam || (t.PullRecallMessageParam = {})).DirectionEnum = {
            ASC: "ASC",
            DESC: "DESC"
        };
    },
    644: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.PullReceiptMessageParam = void 0, (t.PullReceiptMessageParam || (t.PullReceiptMessageParam = {})).DirectionEnum = {
            ASC: "ASC",
            DESC: "DESC"
        };
    },
    645: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.SubBandReq = void 0, (t.SubBandReq || (t.SubBandReq = {})).OptSubEnum = {
            SUB: "SUB",
            UNSUB: "UN_SUB"
        };
    },
    646: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.SubCustomerMsgReq = void 0, (t.SubCustomerMsgReq || (t.SubCustomerMsgReq = {})).OptSubEnum = {
            SUB: "SUB",
            UNSUB: "UN_SUB"
        };
    },
    647: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.SubServerMsgReq = void 0, (t.SubServerMsgReq || (t.SubServerMsgReq = {})).OptSubEnum = {
            SUB: "SUB",
            UNSUB: "UN_SUB"
        };
    },
    648: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.TextAuditResult = void 0, (t.TextAuditResult || (t.TextAuditResult = {})).TextAuditResultEnumEnum = {
            SUCCESS: "SUCCESS",
            FAIL: "FAIL",
            PASSTHENAUDIT: "PASS_THEN_AUDIT",
            NOEDIT: "NO_EDIT"
        };
    },
    649: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.UpdateGhDataSettingParam = void 0, function(e) {
            e.UpdateSettingEnum = {
                ON: "ON",
                OFF: "OFF"
            }, e.UpdateDataItemEnum = {
                ORDERNUM: "ORDER_NUM",
                PAYMENTAMOUNT: "PAYMENT_AMOUNT",
                COMMISSIONINCOME: "COMMISSION_INCOME",
                COMMISSIONOUTCOME: "COMMISSION_OUTCOME",
                GHUV: "GH_UV",
                PARTICIPANTSNUM: "PARTICIPANTS_NUM",
                CONVERSIONRATE: "CONVERSION_RATE",
                SALESVOLUME: "SALES_VOLUME",
                REFUNDAMOUNT: "REFUND_AMOUNT",
                CUSTOMERPRICE: "CUSTOMER_PRICE",
                REPURCHASERATE: "REPURCHASE_RATE",
                NEWORDERNUM: "NEW_ORDERNUM",
                PAYGOODSPRICE: "PAY_GOODSPRICE"
            };
        }(t.UpdateGhDataSettingParam || (t.UpdateGhDataSettingParam = {}));
    },
    650: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.VirtualTelParam = void 0, (t.VirtualTelParam || (t.VirtualTelParam = {})).VirTualTelSceneEnum = {
            USERACCOUNT: "USER_ACCOUNT",
            GHHOME: "GH_HOME",
            ACTIVITY: "ACTIVITY",
            MARKETOWNER: "MARKET_OWNER"
        };
    },
    651: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.WelfareSubReq = void 0, (t.WelfareSubReq || (t.WelfareSubReq = {})).OptSubEnum = {
            UNSET: "UN_SET",
            UNSUB: "UN_SUB",
            SUB: "SUB"
        };
    },
    652: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.WithdrawStatusDTO = void 0, (t.WithdrawStatusDTO || (t.WithdrawStatusDTO = {})).ImageEnum = {
            ING: "ING",
            FAIL: "FAIL",
            SUCCESS: "SUCCESS",
            GREEN: "GREEN",
            GRAY: "GRAY"
        };
    },
    658: function(e, t, r) {
        var n, o, i;
        e.exports = (i = r(175), o = (n = i).lib.WordArray, n.enc.Base64 = {
            stringify: function(e) {
                var t = e.words, r = e.sigBytes, n = this._map;
                e.clamp();
                for (var o = [], i = 0; i < r; i += 3) for (var a = (t[i >>> 2] >>> 24 - i % 4 * 8 & 255) << 16 | (t[i + 1 >>> 2] >>> 24 - (i + 1) % 4 * 8 & 255) << 8 | t[i + 2 >>> 2] >>> 24 - (i + 2) % 4 * 8 & 255, s = 0; s < 4 && i + .75 * s < r; s++) o.push(n.charAt(a >>> 6 * (3 - s) & 63));
                var u = n.charAt(64);
                if (u) for (;o.length % 4; ) o.push(u);
                return o.join("");
            },
            parse: function(e) {
                var t = e.length, r = this._map, n = this._reverseMap;
                if (!n) {
                    n = this._reverseMap = [];
                    for (var i = 0; i < r.length; i++) n[r.charCodeAt(i)] = i;
                }
                var a = r.charAt(64);
                if (a) {
                    var s = e.indexOf(a);
                    -1 !== s && (t = s);
                }
                return function(e, t, r) {
                    for (var n = [], i = 0, a = 0; a < t; a++) if (a % 4) {
                        var s = r[e.charCodeAt(a - 1)] << a % 4 * 2 | r[e.charCodeAt(a)] >>> 6 - a % 4 * 2;
                        n[i >>> 2] |= s << 24 - i % 4 * 8, i++;
                    }
                    return o.create(n, i);
                }(e, t, n);
            },
            _map: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/="
        }, i.enc.Base64);
    },
    659: function(e, t, r) {
        var n;
        e.exports = (n = r(175), function(e) {
            function t(e, t, r, n, o, i, a) {
                var s = e + (t & r | ~t & n) + o + a;
                return (s << i | s >>> 32 - i) + t;
            }
            function r(e, t, r, n, o, i, a) {
                var s = e + (t & n | r & ~n) + o + a;
                return (s << i | s >>> 32 - i) + t;
            }
            function o(e, t, r, n, o, i, a) {
                var s = e + (t ^ r ^ n) + o + a;
                return (s << i | s >>> 32 - i) + t;
            }
            function i(e, t, r, n, o, i, a) {
                var s = e + (r ^ (t | ~n)) + o + a;
                return (s << i | s >>> 32 - i) + t;
            }
            var a = n, s = a.lib, u = s.WordArray, c = s.Hasher, l = a.algo, d = [];
            !function() {
                for (var t = 0; t < 64; t++) d[t] = 4294967296 * e.abs(e.sin(t + 1)) | 0;
            }();
            var p = l.MD5 = c.extend({
                _doReset: function() {
                    this._hash = new u.init([ 1732584193, 4023233417, 2562383102, 271733878 ]);
                },
                _doProcessBlock: function(e, n) {
                    for (var a = 0; a < 16; a++) {
                        var s = n + a, u = e[s];
                        e[s] = 16711935 & (u << 8 | u >>> 24) | 4278255360 & (u << 24 | u >>> 8);
                    }
                    var c = this._hash.words, l = e[n + 0], p = e[n + 1], f = e[n + 2], h = e[n + 3], S = e[n + 4], _ = e[n + 5], E = e[n + 6], y = e[n + 7], T = e[n + 8], R = e[n + 9], v = e[n + 10], g = e[n + 11], m = e[n + 12], O = e[n + 13], A = e[n + 14], I = e[n + 15], C = c[0], D = c[1], N = c[2], L = c[3];
                    C = i(C = o(C = o(C = o(C = o(C = r(C = r(C = r(C = r(C = t(C = t(C = t(C = t(C, D, N, L, l, 7, d[0]), D = t(D, N = t(N, L = t(L, C, D, N, p, 12, d[1]), C, D, f, 17, d[2]), L, C, h, 22, d[3]), N, L, S, 7, d[4]), D = t(D, N = t(N, L = t(L, C, D, N, _, 12, d[5]), C, D, E, 17, d[6]), L, C, y, 22, d[7]), N, L, T, 7, d[8]), D = t(D, N = t(N, L = t(L, C, D, N, R, 12, d[9]), C, D, v, 17, d[10]), L, C, g, 22, d[11]), N, L, m, 7, d[12]), D = t(D, N = t(N, L = t(L, C, D, N, O, 12, d[13]), C, D, A, 17, d[14]), L, C, I, 22, d[15]), N, L, p, 5, d[16]), D = r(D, N = r(N, L = r(L, C, D, N, E, 9, d[17]), C, D, g, 14, d[18]), L, C, l, 20, d[19]), N, L, _, 5, d[20]), D = r(D, N = r(N, L = r(L, C, D, N, v, 9, d[21]), C, D, I, 14, d[22]), L, C, S, 20, d[23]), N, L, R, 5, d[24]), D = r(D, N = r(N, L = r(L, C, D, N, A, 9, d[25]), C, D, h, 14, d[26]), L, C, T, 20, d[27]), N, L, O, 5, d[28]), D = r(D, N = r(N, L = r(L, C, D, N, f, 9, d[29]), C, D, y, 14, d[30]), L, C, m, 20, d[31]), N, L, _, 4, d[32]), D = o(D, N = o(N, L = o(L, C, D, N, T, 11, d[33]), C, D, g, 16, d[34]), L, C, A, 23, d[35]), N, L, p, 4, d[36]), D = o(D, N = o(N, L = o(L, C, D, N, S, 11, d[37]), C, D, y, 16, d[38]), L, C, v, 23, d[39]), N, L, O, 4, d[40]), D = o(D, N = o(N, L = o(L, C, D, N, l, 11, d[41]), C, D, h, 16, d[42]), L, C, E, 23, d[43]), N, L, R, 4, d[44]), D = o(D, N = o(N, L = o(L, C, D, N, m, 11, d[45]), C, D, I, 16, d[46]), L, C, f, 23, d[47]), N, L, l, 6, d[48]), 
                    D = i(D = i(D = i(D = i(D, N = i(N, L = i(L, C, D, N, y, 10, d[49]), C, D, A, 15, d[50]), L, C, _, 21, d[51]), N = i(N, L = i(L, C = i(C, D, N, L, m, 6, d[52]), D, N, h, 10, d[53]), C, D, v, 15, d[54]), L, C, p, 21, d[55]), N = i(N, L = i(L, C = i(C, D, N, L, T, 6, d[56]), D, N, I, 10, d[57]), C, D, E, 15, d[58]), L, C, O, 21, d[59]), N = i(N, L = i(L, C = i(C, D, N, L, S, 6, d[60]), D, N, g, 10, d[61]), C, D, f, 15, d[62]), L, C, R, 21, d[63]), 
                    c[0] = c[0] + C | 0, c[1] = c[1] + D | 0, c[2] = c[2] + N | 0, c[3] = c[3] + L | 0;
                },
                _doFinalize: function() {
                    var t = this._data, r = t.words, n = 8 * this._nDataBytes, o = 8 * t.sigBytes;
                    r[o >>> 5] |= 128 << 24 - o % 32;
                    var i = e.floor(n / 4294967296), a = n;
                    r[15 + (o + 64 >>> 9 << 4)] = 16711935 & (i << 8 | i >>> 24) | 4278255360 & (i << 24 | i >>> 8), 
                    r[14 + (o + 64 >>> 9 << 4)] = 16711935 & (a << 8 | a >>> 24) | 4278255360 & (a << 24 | a >>> 8), 
                    t.sigBytes = 4 * (r.length + 1), this._process();
                    for (var s = this._hash, u = s.words, c = 0; c < 4; c++) {
                        var l = u[c];
                        u[c] = 16711935 & (l << 8 | l >>> 24) | 4278255360 & (l << 24 | l >>> 8);
                    }
                    return s;
                },
                clone: function() {
                    var e = c.clone.call(this);
                    return e._hash = this._hash.clone(), e;
                }
            });
            a.MD5 = c._createHelper(p), a.HmacMD5 = c._createHmacHelper(p);
        }(Math), n.MD5);
    },
    660: function(e, t, r) {
        var n, o, i, a, s, u, c, l;
        e.exports = (l = r(175), o = (n = l).lib, i = o.WordArray, a = o.Hasher, s = n.algo, 
        u = [], c = s.SHA1 = a.extend({
            _doReset: function() {
                this._hash = new i.init([ 1732584193, 4023233417, 2562383102, 271733878, 3285377520 ]);
            },
            _doProcessBlock: function(e, t) {
                for (var r = this._hash.words, n = r[0], o = r[1], i = r[2], a = r[3], s = r[4], c = 0; c < 80; c++) {
                    if (c < 16) u[c] = 0 | e[t + c]; else {
                        var l = u[c - 3] ^ u[c - 8] ^ u[c - 14] ^ u[c - 16];
                        u[c] = l << 1 | l >>> 31;
                    }
                    var d = (n << 5 | n >>> 27) + s + u[c];
                    d += c < 20 ? 1518500249 + (o & i | ~o & a) : c < 40 ? 1859775393 + (o ^ i ^ a) : c < 60 ? (o & i | o & a | i & a) - 1894007588 : (o ^ i ^ a) - 899497514, 
                    s = a, a = i, i = o << 30 | o >>> 2, o = n, n = d;
                }
                r[0] = r[0] + n | 0, r[1] = r[1] + o | 0, r[2] = r[2] + i | 0, r[3] = r[3] + a | 0, 
                r[4] = r[4] + s | 0;
            },
            _doFinalize: function() {
                var e = this._data, t = e.words, r = 8 * this._nDataBytes, n = 8 * e.sigBytes;
                return t[n >>> 5] |= 128 << 24 - n % 32, t[14 + (n + 64 >>> 9 << 4)] = Math.floor(r / 4294967296), 
                t[15 + (n + 64 >>> 9 << 4)] = r, e.sigBytes = 4 * t.length, this._process(), this._hash;
            },
            clone: function() {
                var e = a.clone.call(this);
                return e._hash = this._hash.clone(), e;
            }
        }), n.SHA1 = a._createHelper(c), n.HmacSHA1 = a._createHmacHelper(c), l.SHA1);
    },
    661: function(e, t, r) {
        var n, o, i, a;
        e.exports = (n = r(175), i = (o = n).lib.Base, a = o.enc.Utf8, void (o.algo.HMAC = i.extend({
            init: function(e, t) {
                e = this._hasher = new e.init(), "string" == typeof t && (t = a.parse(t));
                var r = e.blockSize, n = 4 * r;
                t.sigBytes > n && (t = e.finalize(t)), t.clamp();
                for (var o = this._oKey = t.clone(), i = this._iKey = t.clone(), s = o.words, u = i.words, c = 0; c < r; c++) s[c] ^= 1549556828, 
                u[c] ^= 909522486;
                o.sigBytes = i.sigBytes = n, this.reset();
            },
            reset: function() {
                var e = this._hasher;
                e.reset(), e.update(this._iKey);
            },
            update: function(e) {
                return this._hasher.update(e), this;
            },
            finalize: function(e) {
                var t = this._hasher, r = t.finalize(e);
                return t.reset(), t.finalize(this._oKey.clone().concat(r));
            }
        })));
    },
    662: function(e, t, r) {
        var n, o, i, a, s, u, c, l, d, p, f, h, S, _, E, y, T, R, v;
        e.exports = (n = r(175), r(425), void (n.lib.Cipher || (o = n, i = o.lib, a = i.Base, 
        s = i.WordArray, u = i.BufferedBlockAlgorithm, (c = o.enc).Utf8, l = c.Base64, d = o.algo.EvpKDF, 
        p = i.Cipher = u.extend({
            cfg: a.extend(),
            createEncryptor: function(e, t) {
                return this.create(this._ENC_XFORM_MODE, e, t);
            },
            createDecryptor: function(e, t) {
                return this.create(this._DEC_XFORM_MODE, e, t);
            },
            init: function(e, t, r) {
                this.cfg = this.cfg.extend(r), this._xformMode = e, this._key = t, this.reset();
            },
            reset: function() {
                u.reset.call(this), this._doReset();
            },
            process: function(e) {
                return this._append(e), this._process();
            },
            finalize: function(e) {
                return e && this._append(e), this._doFinalize();
            },
            keySize: 4,
            ivSize: 4,
            _ENC_XFORM_MODE: 1,
            _DEC_XFORM_MODE: 2,
            _createHelper: function() {
                function e(e) {
                    return "string" == typeof e ? v : T;
                }
                return function(t) {
                    return {
                        encrypt: function(r, n, o) {
                            return e(n).encrypt(t, r, n, o);
                        },
                        decrypt: function(r, n, o) {
                            return e(n).decrypt(t, r, n, o);
                        }
                    };
                };
            }()
        }), i.StreamCipher = p.extend({
            _doFinalize: function() {
                return this._process(!0);
            },
            blockSize: 1
        }), f = o.mode = {}, h = i.BlockCipherMode = a.extend({
            createEncryptor: function(e, t) {
                return this.Encryptor.create(e, t);
            },
            createDecryptor: function(e, t) {
                return this.Decryptor.create(e, t);
            },
            init: function(e, t) {
                this._cipher = e, this._iv = t;
            }
        }), S = f.CBC = function() {
            function e(e, t, r) {
                var n, o = this._iv;
                o ? (n = o, this._iv = void 0) : n = this._prevBlock;
                for (var i = 0; i < r; i++) e[t + i] ^= n[i];
            }
            var t = h.extend();
            return t.Encryptor = t.extend({
                processBlock: function(t, r) {
                    var n = this._cipher, o = n.blockSize;
                    e.call(this, t, r, o), n.encryptBlock(t, r), this._prevBlock = t.slice(r, r + o);
                }
            }), t.Decryptor = t.extend({
                processBlock: function(t, r) {
                    var n = this._cipher, o = n.blockSize, i = t.slice(r, r + o);
                    n.decryptBlock(t, r), e.call(this, t, r, o), this._prevBlock = i;
                }
            }), t;
        }(), _ = (o.pad = {}).Pkcs7 = {
            pad: function(e, t) {
                for (var r = 4 * t, n = r - e.sigBytes % r, o = n << 24 | n << 16 | n << 8 | n, i = [], a = 0; a < n; a += 4) i.push(o);
                var u = s.create(i, n);
                e.concat(u);
            },
            unpad: function(e) {
                var t = 255 & e.words[e.sigBytes - 1 >>> 2];
                e.sigBytes -= t;
            }
        }, i.BlockCipher = p.extend({
            cfg: p.cfg.extend({
                mode: S,
                padding: _
            }),
            reset: function() {
                var e;
                p.reset.call(this);
                var t = this.cfg, r = t.iv, n = t.mode;
                this._xformMode == this._ENC_XFORM_MODE ? e = n.createEncryptor : (e = n.createDecryptor, 
                this._minBufferSize = 1), this._mode && this._mode.__creator == e ? this._mode.init(this, r && r.words) : (this._mode = e.call(n, this, r && r.words), 
                this._mode.__creator = e);
            },
            _doProcessBlock: function(e, t) {
                this._mode.processBlock(e, t);
            },
            _doFinalize: function() {
                var e, t = this.cfg.padding;
                return this._xformMode == this._ENC_XFORM_MODE ? (t.pad(this._data, this.blockSize), 
                e = this._process(!0)) : (e = this._process(!0), t.unpad(e)), e;
            },
            blockSize: 4
        }), E = i.CipherParams = a.extend({
            init: function(e) {
                this.mixIn(e);
            },
            toString: function(e) {
                return (e || this.formatter).stringify(this);
            }
        }), y = (o.format = {}).OpenSSL = {
            stringify: function(e) {
                var t = e.ciphertext, r = e.salt;
                return (r ? s.create([ 1398893684, 1701076831 ]).concat(r).concat(t) : t).toString(l);
            },
            parse: function(e) {
                var t, r = l.parse(e), n = r.words;
                return 1398893684 == n[0] && 1701076831 == n[1] && (t = s.create(n.slice(2, 4)), 
                n.splice(0, 4), r.sigBytes -= 16), E.create({
                    ciphertext: r,
                    salt: t
                });
            }
        }, T = i.SerializableCipher = a.extend({
            cfg: a.extend({
                format: y
            }),
            encrypt: function(e, t, r, n) {
                n = this.cfg.extend(n);
                var o = e.createEncryptor(r, n), i = o.finalize(t), a = o.cfg;
                return E.create({
                    ciphertext: i,
                    key: r,
                    iv: a.iv,
                    algorithm: e,
                    mode: a.mode,
                    padding: a.padding,
                    blockSize: e.blockSize,
                    formatter: n.format
                });
            },
            decrypt: function(e, t, r, n) {
                return n = this.cfg.extend(n), t = this._parse(t, n.format), e.createDecryptor(r, n).finalize(t.ciphertext);
            },
            _parse: function(e, t) {
                return "string" == typeof e ? t.parse(e, this) : e;
            }
        }), R = (o.kdf = {}).OpenSSL = {
            execute: function(e, t, r, n) {
                n || (n = s.random(8));
                var o = d.create({
                    keySize: t + r
                }).compute(e, n), i = s.create(o.words.slice(t), 4 * r);
                return o.sigBytes = 4 * t, E.create({
                    key: o,
                    iv: i,
                    salt: n
                });
            }
        }, v = i.PasswordBasedCipher = T.extend({
            cfg: T.cfg.extend({
                kdf: R
            }),
            encrypt: function(e, t, r, n) {
                var o = (n = this.cfg.extend(n)).kdf.execute(r, e.keySize, e.ivSize);
                n.iv = o.iv;
                var i = T.encrypt.call(this, e, t, o.key, n);
                return i.mixIn(o), i;
            },
            decrypt: function(e, t, r, n) {
                n = this.cfg.extend(n), t = this._parse(t, n.format);
                var o = n.kdf.execute(r, e.keySize, e.ivSize, t.salt);
                return n.iv = o.iv, T.decrypt.call(this, e, t, o.key, n);
            }
        }))));
    },
    663: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.LocalLogService = t.LOG_CONFIG = void 0;
        var n = r(0), o = r(1), i = r(7), a = r(426), s = r(427), u = r(3);
        t.LOG_CONFIG = {
            LOG_SEND_URL: "/api/log",
            KEEP_DAYS: 7,
            SEND_DAYS: 3
        };
        var c = function() {
            function e(e) {
                this.logStorageService = e, this.logSendUrl = t.LOG_CONFIG.LOG_SEND_URL, this.keepDays = t.LOG_CONFIG.KEEP_DAYS, 
                this.sendDays = t.LOG_CONFIG.SEND_DAYS, this.initLocalLog();
            }
            var r;
            return r = e, e.create = function(e) {
                return new r(e);
            }, e.prototype.debug = function(e, t) {
                this.writeLogDelay(a.LogLevel.DEBUG, e, t);
            }, e.prototype.info = function(e, t) {
                this.writeLogDelay(a.LogLevel.INFO, e, t);
            }, e.prototype.warn = function(e, t) {
                this.writeLogDelay(a.LogLevel.WARN, e, t);
            }, e.prototype.error = function(e, t) {
                this.writeLogDelay(a.LogLevel.ERROR, e, t);
            }, e.prototype.fatal = function(e, t) {
                this.writeLogDelay(a.LogLevel.FATAL, e, t);
            }, e.prototype.send = function(e) {
                var t = this, r = 24 * this.sendDays * 60 * 60 * 1e3;
                this.logStorageService.find({
                    after: Date.now() - r
                }).pipe(u.switchMap(function(r) {
                    return e(t.logSendUrl, r);
                })).subscribe(function(e) {});
            }, e.prototype.cleanAll = function() {
                this.logStorageService.deleteAll();
            }, e.prototype.writeLog = function(e, t, r) {
                var o = "[" + a.LogDescription[e] + "]";
                "string" == typeof r && (r = {
                    message: r
                }), this.logStorageService.save(n.__assign({
                    prefix: o,
                    date: Date.now(),
                    level: e,
                    messageType: t
                }, r));
            }, e.prototype.writeLogDelay = function(e, t, r) {
                var n = this;
                setTimeout(function() {
                    n.writeLog(e, t, r);
                }, 0);
            }, e.prototype.initLocalLog = function() {
                this.startDeletePeriod();
            }, e.prototype.startDeletePeriod = function() {
                var e = this, t = 24 * this.keepDays * 60 * 60 * 1e3;
                i.timer(1e3, 18e5).subscribe(function() {
                    e.logStorageService.delete({
                        before: Date.now() - t
                    });
                });
            }, e = r = n.__decorate([ o.Injectable(), n.__metadata("design:paramtypes", [ s.LogStorageService ]) ], e);
        }();
        t.LocalLogService = c;
    },
    666: function(e, t, r) {
        function n(e, t) {
            if (!Array.isArray(e)) throw new Error("没有传 expressions");
            return e.some(function(e) {
                return e instanceof RegExp ? e.test(t) : e === t;
            });
        }
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.canUseWithList = void 0, t.canUseWithList = function(e, t) {
            if (!t) return !0;
            var r = t.whiteList, o = t.blackList;
            return !(r && r.length > 0 && !n(r, e) || n(o || [], e));
        };
    },
    682: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.MonoRichTextCorrector = void 0;
        var n, o, i = r(0), a = r(59);
        !function(e) {
            e.NORMAL = "Normal", e.MEDIA_TYPE_CONTENT_UNMATCHED = "MediaTypeContentUnmatched", 
            e.RICH_TEXT_CONTENT_EMPTY = "RichTextContentEmpty", e.URL_START_WITH_PROTOCOL = "UrlStartWithProtocol";
        }(n || (n = {})), function(e) {
            e.REPAIRED = "MediaTypeRepaired", e.UNREPAIRED = "MediaTypeUnrepaired";
        }(o || (o = {}));
        var s = function() {
            function e(e) {
                this.errorService = e;
            }
            return e.prototype.correctRichTextList = function(e) {
                var t = this;
                return e.reduce(function(e, r) {
                    var n = t.correctRichTextItem(r);
                    return n && e.push(n), e;
                }, []);
            }, e.prototype.correctRichTextItem = function(e) {
                var t, r, a = i.__assign({}, e), s = this.checkRichTextContentException(e);
                if (s === n.NORMAL) return e;
                if (s === n.RICH_TEXT_CONTENT_EMPTY) {
                    var u = this.tryToFixEmptyRichTextContent(e);
                    return this.reportRichTextException(s, a, u), u;
                }
                if (s === n.MEDIA_TYPE_CONTENT_UNMATCHED) {
                    try {
                        for (var c = i.__values(this.getFallbackMediaTypes(e.mediaType)), l = c.next(); !l.done; l = c.next()) {
                            var d = l.value;
                            if (this.checkMediaTypeCorrect(e, d)) return e.mediaType = d, this.reportRichTextException(o.REPAIRED, a, e), 
                            e;
                        }
                    } catch (e) {
                        t = {
                            error: e
                        };
                    } finally {
                        try {
                            l && !l.done && (r = c.return) && r.call(c);
                        } finally {
                            if (t) throw t.error;
                        }
                    }
                    return this.reportRichTextException(o.UNREPAIRED, e), e;
                }
                return s === n.URL_START_WITH_PROTOCOL && (e = this.fixRichTextWithProtocol(e), 
                this.reportRichTextException(s, a, e)), e;
            }, e.prototype.reportRichTextException = function(e, t, r) {
                this.errorService.customReportError({
                    frontErrorCode: 4017,
                    errorMsg: e,
                    extraInfo: {
                        originInfo: t,
                        fixedInfo: r
                    }
                });
            }, e.prototype.checkRichTextContentException = function(e) {
                return this.checkIsContentEmpty(e) ? n.RICH_TEXT_CONTENT_EMPTY : this.checkMediaTypeCorrect(e, e.mediaType) ? this.checkIsContentStartWithProtocol(e) ? n.URL_START_WITH_PROTOCOL : n.NORMAL : n.MEDIA_TYPE_CONTENT_UNMATCHED;
            }, e.prototype.checkMediaTypeCorrect = function(e, t) {
                return "text" === t ? this.checkIsText(e) && !this.checkIsImg(e) && !this.checkIsVideo(e) : "singleImg" === t ? this.checkIsImg(e) : "video" === t ? this.checkIsVideo(e) : "multiImg" === t ? this.checkIsMultiImg(e) : "tag" === t ? this.checkIsTag(e) : "activity" === t ? this.checkIsActivityCard(e) : "nameCard" === t ? this.checkIsNameCard(e) : "liveCard" === t ? this.checkIsLiveCard(e) : "goodsInfo" !== t || this.checkIsProductIntro(e);
            }, e.prototype.checkIsContentStartWithProtocol = function(e) {
                var t, r = this;
                return [ "singleImg", "video" ].includes(e.mediaType) && e.content ? this.checkIsStartWithProtocol(e.content) : !("multiImg" !== e.mediaType || !(null === (t = e.contentList) || void 0 === t ? void 0 : t.length)) && e.contentList.some(function(e) {
                    return r.checkIsStartWithProtocol(e.content);
                });
            }, e.prototype.checkIsContentEmpty = function(e) {
                var t;
                switch (e.mediaType) {
                  case "singleImg":
                  case "video":
                    return !e.content;

                  case "activity":
                    return !e.activityCardInfo;

                  case "nameCard":
                    return !e.nameCardInfo;

                  case "liveCard":
                    return !e.liveCardInfo;

                  case "goodsInfo":
                    return !e.goodsInfo;

                  case "multiImg":
                    return !!(null === (t = e.contentList) || void 0 === t ? void 0 : t.length) && e.contentList.some(function(e) {
                        return !e || !e.content;
                    });

                  default:
                    return !1;
                }
            }, e.prototype.checkIsText = function(e) {
                return "string" == typeof e.content;
            }, e.prototype.checkIsImg = function(e) {
                return this.checkIsText(e) && this.checkIsUrlImg(e.content);
            }, e.prototype.checkIsVideo = function(e) {
                return this.checkIsText(e) && this.checkIsUrlVideo(e.content);
            }, e.prototype.checkIsMultiImg = function(e) {
                var t = this;
                return !!e.contentList && e.contentList.every(function(e) {
                    return e.mediaType === a.RichTextContentMediaType.IMG && t.checkIsUrlImg(e.content) || e.mediaType === a.RichTextContentMediaType.VIDEO && t.checkIsUrlVideo(e.content);
                });
            }, e.prototype.checkIsTag = function(e) {
                return !!e.contentList && e.contentList.every(function(e) {
                    return e.mediaType === a.RichTextContentMediaType.TXT && e.content;
                });
            }, e.prototype.checkIsActivityCard = function(e) {
                return !!e.activityCardInfo;
            }, e.prototype.checkIsNameCard = function(e) {
                return !!e.nameCardInfo;
            }, e.prototype.checkIsLiveCard = function(e) {
                return !!e.liveCardInfo;
            }, e.prototype.checkIsProductIntro = function(e) {
                return !!e.goodsInfo;
            }, e.prototype.getFallbackMediaTypes = function(e) {
                return [ "activity", "nameCard", "liveCard", "goodsInfo", "multiImg", "tag", "singleImg", "video", "text" ].filter(function(t) {
                    return t !== e;
                });
            }, e.prototype.checkIsUrlImg = function(e) {
                return void 0 === e && (e = ""), /^(https?:\/\/[\w\.]+\/)?\/*([1-9\w-]+\/)+[1-9\w-]+\.(jpg|jpeg|png|gif|svg|webp)$/i.test(e);
            }, e.prototype.checkIsUrlVideo = function(e) {
                return void 0 === e && (e = ""), /^(https?:\/\/[\w\.]+\/)?\/*([1-9\w-]+\/)+[1-9\w-]+\.(mp4)$/i.test(e);
            }, e.prototype.checkIsStartWithProtocol = function(e) {
                return /^https?:\/\/\w+/.test(e);
            }, e.prototype.fixRichTextWithProtocol = function(e) {
                var t, r, n = i.__assign({}, e), o = n.mediaType;
                if ("singleImg" === o || "video" === o) n = i.__assign(i.__assign({}, n), {
                    mediaType: "singleImg",
                    content: "ss/app/image/plus/img24.png"
                }); else if ("multiImg" === o) try {
                    for (var s = i.__values(n.contentList), u = s.next(); !u.done; u = s.next()) {
                        var c = u.value;
                        this.checkIsStartWithProtocol(c.content) && (c = i.__assign(i.__assign({}, c), {
                            mediaType: a.RichTextContentMediaType.IMG,
                            content: "ss/app/image/plus/img24.png"
                        }));
                    }
                } catch (e) {
                    t = {
                        error: e
                    };
                } finally {
                    try {
                        u && !u.done && (r = s.return) && r.call(s);
                    } finally {
                        if (t) throw t.error;
                    }
                }
                return n;
            }, e.prototype.tryToFixEmptyRichTextContent = function(e) {
                var t;
                if ("multiImg" === e.mediaType && (null === (t = e.contentList) || void 0 === t ? void 0 : t.length)) return e.contentList = e.contentList.filter(function(e) {
                    return !!e && !!e.content;
                }), e;
            }, e;
        }();
        t.MonoRichTextCorrector = s;
    },
    69: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.Throttle = void 0, t.Throttle = function(e) {
            return void 0 === e && (e = 100), function(t, r, n) {
                var o, i, a = n.value;
                n.value = function() {
                    for (var t = this, r = [], n = 0; n < arguments.length; n++) r[n] = arguments[n];
                    var s = +new Date();
                    i && s < i + e ? (clearTimeout(o), o = setTimeout(function() {
                        i = s, a.apply(t, r);
                    }, e)) : (i = s, a.apply(this, r));
                };
            };
        };
    },
    691: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.options = void 0, t.options = {
            isSkipPageMarking: !0,
            hideErrorToast: !0
        };
    },
    692: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.WxCloudRedDotMigrateTransformService = void 0;
        var n = r(0), o = r(1), i = r(41), a = function() {
            function e() {}
            return e.prototype.splitRedDotParam = function(e, t) {
                var r = this;
                void 0 === t && (t = !1);
                var n = [], o = [], a = [];
                return e.forEach(function(e) {
                    var s = e.code, u = r.code2RedDotSource(s);
                    u === i.RedDotSource.FRONT_STORE || t ? a.push(e) : u === i.RedDotSource.WX_CLOUD ? o.push(e) : u === i.RedDotSource.BACK_END && n.push(e);
                }), {
                    backEndRedDotList: n,
                    cloudRedDotList: o,
                    frontStoreRedDotList: a
                };
            }, e.prototype.code2RedDotSource = function(e) {
                return e < 1e3 ? i.RedDotSource.BACK_END : e < 2e3 ? i.RedDotSource.WX_CLOUD : i.RedDotSource.FRONT_STORE;
            }, e.prototype.mergeCacheItem = function(e, t) {
                var r = t.code, o = t.cycleDay, i = t.ename, a = t.cname, s = t.expireDate, u = t.type, c = t.limitNumber, l = t.status, d = t.record, p = t.version, f = Object.keys(d || {}).reduce(function(t, r) {
                    var n, o = d[r], i = null === (n = e.record) || void 0 === n ? void 0 : n[r];
                    return !((null == i ? void 0 : i.invokerNumber) && !o.invokerNumber) && (t[r] = o), 
                    t;
                }, {}), h = function(e) {
                    return void 0 === e;
                };
                return {
                    code: r || e.code,
                    cycleDay: h(o) ? e.cycleDay : o,
                    ename: i || e.ename,
                    cname: a || e.cname,
                    expireDate: h(s) ? e.expireDate : s,
                    type: u || e.type,
                    limitNumber: "number" == typeof c ? c : c || e.limitNumber,
                    status: l || e.status,
                    record: n.__assign(n.__assign({}, e.record || {}), f),
                    version: p
                };
            }, e.prototype.mergeCache = function(e, t) {
                var r = this, n = JSON.parse(JSON.stringify(t));
                return Object.keys(e).forEach(function(t) {
                    var o = n[t], i = e[t];
                    n[t] = o ? r.mergeCacheItem(o, i) : i;
                }), n;
            }, e.prototype.convertRedDotDataToStorageStructure = function(e) {
                var t = this;
                return e.reduce(function(e, r) {
                    var n, o = r.code, i = t.formatIGetRedDotInfo2IRedDotConfigData(r), a = ((n = {})[o] = i, 
                    n);
                    return t.mergeCache(a, e);
                }, {});
            }, e.prototype.getRecordKey = function(e) {
                if (!e.type || 10 === e.type) return String(e.code);
                if (!e.redDotKey) throw new Error("code: " + e.code + "，错误的type或错误的key");
                return e.code + "_" + e.redDotKey;
            }, e.prototype.formatIGetRedDotInfo2IRedDotConfigData = function(e) {
                var t, r = e.code, n = e.cycleDay, o = e.ename, i = e.cname, a = e.enName, s = e.cName, u = e.expireDate, c = e.type, l = e.limitNumber, d = e.invokerNumber, p = e.lastReadTime, f = e.redDotKey, h = e.recordKey;
                return {
                    code: r,
                    cycleDay: n,
                    ename: o,
                    cname: i,
                    enName: a,
                    cName: s,
                    expireDate: u,
                    type: c,
                    limitNumber: l,
                    status: e.status,
                    record: ((t = {})[h || this.getRecordKey({
                        code: r,
                        type: c,
                        redDotKey: f
                    })] = {
                        invokerNumber: d,
                        lastReadTime: p
                    }, t)
                };
            }, e = n.__decorate([ o.Injectable(), n.__metadata("design:paramtypes", []) ], e);
        }();
        t.WxCloudRedDotMigrateTransformService = a;
    },
    7: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), r(0);
        var n = r(416);
        t.BehaviorSubject = n.BehaviorSubject, t.Observable = n.Observable, t.ReplaySubject = n.ReplaySubject, 
        t.Subject = n.Subject, t.Subscriber = n.Subscriber, t.Subscription = n.Subscription, 
        t.TimeoutError = n.TimeoutError, t.combineLatest = n.combineLatest, t.concat = n.concat, 
        t.defer = n.defer, t.empty = n.empty, t.forkJoin = n.forkJoin, t.from = n.from, 
        t.iif = n.iif, t.interval = n.interval, t.isObservable = n.isObservable, t.merge = n.merge, 
        t.never = n.never, t.noop = n.noop, t.observable = n.observable, t.of = n.of, t.race = n.race, 
        t.throwError = n.throwError, t.timer = n.timer, t.zip = n.zip;
    },
    70: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.MonoOrderManageService = t.HelpSaleOrderRefundStatus = t.StartGrandchildOrderRefundStatus = t.VoucherDetailOrderRefundStatusOfMarketCreator = t.VoucherDetailOrderRefundStatus = t.OrderManageOrderRefundStatus = t.VoucherSingleChildrenOrderRefundStatus = t.VoucherSingleOrderRefundStatus = void 0;
        var n, o, i = r(0), a = r(1), s = r(20), u = r(32);
        !function(e) {
            e.isDealing = "待处理", e.isRefunding = "退款中", e.isRejected = "已拒绝", e.isFinishedRefund = "已退款", 
            e.isRefundFailed = "退款失败";
        }(n || (n = {})), function(e) {
            e.isDealing = "待退款，待发起人确认", e.isRefunding = "退款中", e.isRejected = "已拒绝退款", e.isFinishedRefund = "已退款", 
            e.isRefundFailed = "退款失败";
        }(t.VoucherSingleOrderRefundStatus || (t.VoucherSingleOrderRefundStatus = {})), 
        function(e) {
            e.isDealing = "待退款，待发起人确认", e.isRefunding = "退款中", e.isRejected = "已拒绝退款", e.isFinishedRefund = "已退款", 
            e.isRefundFailed = "退款失败";
        }(t.VoucherSingleChildrenOrderRefundStatus || (t.VoucherSingleChildrenOrderRefundStatus = {})), 
        function(e) {
            e.isDealing = "用户申请退款", e.isRefunding = "退款中", e.isRejected = "已拒绝退款", e.isFinishedRefund = "已退款", 
            e.isRefundFailed = "退款失败";
        }(t.OrderManageOrderRefundStatus || (t.OrderManageOrderRefundStatus = {})), function(e) {
            e.isDealing = "待退款", e.isRefunding = "退款中", e.isRejected = "我已拒绝", e.isFinishedRefund = "已退款", 
            e.isRefundFailed = "退款失败";
        }(t.VoucherDetailOrderRefundStatus || (t.VoucherDetailOrderRefundStatus = {})), 
        function(e) {
            e.isDealing = "待退款", e.isRefunding = "退款中", e.isRejected = "摊主已拒绝", e.isFinishedRefund = "已退款", 
            e.isRefundFailed = "退款失败";
        }(t.VoucherDetailOrderRefundStatusOfMarketCreator || (t.VoucherDetailOrderRefundStatusOfMarketCreator = {})), 
        function(e) {
            e.isDealingWithByLeader = "待团长审核", e.isRejectedByLeader = "团长已拒绝", e.isAgreedByLeader = "待品牌商退款", 
            e.isRejectedByBrand = "品牌已拒绝", e.isRefunding = "退款处理中", e.isRejected = "申请被拒绝", 
            e.isFinishedRefund = "完成退款", e.isRefundFailed = "退款失败", e.isDealing = "处理中";
        }(o || (o = {})), function(e) {
            e.isDealingWithByLeader = "待处理", e.isRejectedByLeader = "团长已拒绝", e.isAgreedByLeader = "待供货商退款中", 
            e.isRejectedByBrand = "供货商已拒绝", e.isRefunding = "退款中", e.isRejected = "申请被拒绝", e.isFinishedRefund = "已退款", 
            e.isRefundFailed = "退款失败", e.isDealing = "处理中";
        }(t.StartGrandchildOrderRefundStatus || (t.StartGrandchildOrderRefundStatus = {})), 
        function(e) {
            e.isDealingWithByLeader = "待团长审核", e.isRejectedByLeader = "团长已拒绝", e.isAgreedByLeader = "待供货商审核", 
            e.isRejectedByBrand = "供货商已拒绝", e.isRefunding = "退款处理中", e.isRejected = "申请被拒绝", 
            e.isFinishedRefund = "完成退款", e.isRefundFailed = "退款失败", e.isDealing = "处理中";
        }(t.HelpSaleOrderRefundStatus || (t.HelpSaleOrderRefundStatus = {}));
        var c = function() {
            function e(e) {
                this.commonService = e, this.defaultOrderTab = {
                    title: "全部",
                    index: 1,
                    handleId: 0
                }, this.signingStatusTabsInOrderDetail = [ {
                    title: "全部",
                    handleId: 0,
                    isShowCount: !1
                }, {
                    title: "待核销",
                    handleId: 20,
                    isShowCount: !0,
                    countKey: "unSignCount"
                }, {
                    title: "已核销",
                    handleId: 30,
                    isShowCount: !0,
                    countKey: "signCount"
                } ], this.leaderRefundTabList = [ {
                    title: "待处理",
                    index: 1,
                    handleId: 10
                }, {
                    title: "退款中",
                    index: 2,
                    handleId: 20
                }, {
                    title: "已退款",
                    index: 3,
                    handleId: 30
                }, {
                    title: "已拒绝",
                    index: 4,
                    handleId: 40
                } ], this.brandOrdersTabList = [ {
                    title: "开团中",
                    index: 2,
                    handleId: 10
                }, {
                    title: "待发货",
                    index: 3,
                    handleId: 20
                }, {
                    title: "已发货",
                    index: 4,
                    handleId: 25
                }, {
                    title: "已完成",
                    index: 5,
                    handleId: 30
                } ], this.leaderOrdersTabList = [ {
                    title: "开团中",
                    index: 2,
                    handleId: 10
                }, {
                    title: "待收货",
                    index: 3,
                    handleId: 20
                }, {
                    title: "已完成",
                    index: 4,
                    handleId: 30
                } ], this.clientOrderTabList = [ {
                    title: "待核销",
                    index: 3,
                    handleId: 10
                }, {
                    title: "已完成",
                    index: 4,
                    handleId: 20
                }, {
                    title: "退款/售后",
                    index: 5,
                    handleId: 30
                } ], this.baseOrderTabList = [ this.defaultOrderTab ];
            }
            return e.prototype.generateOrderTabList = function(e) {
                var t = [], r = this.commonService.getGroupType(e), n = r.isAllBrand, o = r.isAllLeader;
                return t = n ? this.brandOrdersTabList : o ? this.leaderOrdersTabList : this.clientOrderTabList, 
                (t = i.__spread(t, this.baseOrderTabList)).sort(function(e, t) {
                    return e.index - t.index;
                }), this.defaultOrderTab = t[0], t;
            }, e.prototype.generateCustomerOrderStatus = function(e, t) {
                void 0 === t && (t = !1);
                var r = this.generateOrderRefundStatus(e.refundStatus);
                return this.generateOrderStatus(i.__assign({
                    isWaitingReceipt: 10 === e.status,
                    isFinished: 20 === e.status,
                    isRefunded: t
                }, r));
            }, e.prototype.generateOrderRefundStatus = function(e) {
                return this.generateOrderStatus({
                    isDealingWithByLeader: 10 === e,
                    isRejectedByLeader: 5 === e,
                    isAgreedByLeader: 30 === e,
                    isNotSufficientFunds: 31 === e,
                    isExceptionByBrand: 32 === e,
                    isAgreedByBrand: 100 === e,
                    isSysAgree: 200 === e,
                    isRejectedByBrand: 1 === e,
                    isDealingWithByJPGY: 230 === e,
                    isFailByJPGY: 320 === e,
                    isWaitingRefund: 100 === e,
                    isFailAcceptByJPGY: 310 === e,
                    isFinishedRefund: 300 === e,
                    isRefundFailed: [ 31, 32, 210, 320, 311, 310, 401, 402, 330 ].includes(e),
                    isRejected: [ 5, 1, 2 ].includes(e),
                    isRefunding: [ 100, 200, 230, 110, 120, 130, 140, 220 ].includes(e),
                    isDealing: [ 10, 30, 192 ].includes(e),
                    isRefundFailAndConnectCustomerService: [ 320, 311, 310, 401, 402 ].includes(e),
                    isRefundFailDealt: 330 === e
                });
            }, e.prototype.generateLeaderOrderStatus = function(e) {
                return this.generateOrderStatus({
                    isRunning: 10 === e.status,
                    isWaitSend: 15 === e.status,
                    isWaitingReceipt: 20 === e.status,
                    isReceiptedByLeader: 30 === e.status
                });
            }, e.prototype.generateLeaderOrderStatusByBrand = function(e) {
                return this.generateOrderStatus({
                    isRunning: 10 === e.status,
                    isWaitSend: 20 === e.status,
                    isWaitingReceipt: 25 === e.status,
                    isReceiptedByLeader: 30 === e.status
                });
            }, e.prototype.generateSeqVoucherStatus = function(e, t) {
                void 0 === t && (t = !1);
                var r = this.generateOrderRefundStatus(e.refundStatus);
                return this.generateOrderStatus(i.__assign({
                    isWaitingReceipt: 20 === e.status,
                    isFinished: 30 === e.status,
                    isRefunded: t
                }, r));
            }, e.prototype.getCommonOrderStr = function(e) {
                var t = this.getStatusSimpleData(e), r = this.getKey(t);
                return n[r] || "";
            }, e.prototype.getStatusSimpleData = function(e) {
                var t = this.generateOrderRefundStatus(e);
                return {
                    isFinishedRefund: t.isFinishedRefund,
                    isRefundFailed: t.isRefundFailed,
                    isRejected: t.isRejected,
                    isRefunding: t.isRefunding,
                    isDealing: t.isDealing
                };
            }, e.prototype.getVoucherManagementStatusStr = function(e, t) {
                void 0 === t && (t = o);
                var r = this.getChildVoucherManagementStatus(e);
                return t[this.getKey(r)] || "";
            }, e.prototype.getRefundedStr = function(e, t) {
                void 0 === t && (t = n);
                var r = this.getStatusSimpleData(e);
                return t[this.getKey(r)] || "";
            }, e.prototype.generateRemarkStr = function(e) {
                var t = function(e, t) {
                    return t > 1 ? e + "x" + t : t > 0 ? e : "";
                };
                return e.map(function(e) {
                    var r = e.content && e.content.length;
                    return "text" === e.type ? e.content.join() : "image" === e.type ? t("[图片]", r) : "video" === e.type ? t("[视频]", r) : "logistics" === e.type && r > 0 ? e.content.map(function(e) {
                        return " [售后物流: " + e.logisticsCompany + ", " + e.logisticsNo + "]";
                    }).join("") : "";
                }).filter(function(e) {
                    return e;
                }).join(" ");
            }, e.prototype.addRefundFlag = function(e) {
                if (e && 0 !== e.length) {
                    var t = e.findIndex(function(e) {
                        return "text" === e.type;
                    });
                    if (t > -1) {
                        var r = e[t].content[0] || "无";
                        e[t].content[0] = "#退款备注#" + r;
                    } else e.unshift({
                        type: "text",
                        content: [ "#退款备注#" ]
                    });
                }
            }, e.prototype.isHiddenActOrder = function(e) {
                void 0 === e && (e = {});
                var t = e.sysGeneratedType;
                return 5 === e.allowGroupMemberLottery || [ 10, 20, 30 ].includes(t);
            }, e.prototype.checkCanModifyAddress = function(e) {
                var t = e.canIEditAddress, r = e.hasAddress, n = e.groupType, o = e.seqType, i = e.logisticsStatus, a = e.isPromoter, s = e.isPC;
                return !(!t || 110 === n || a || (s ? 30 === i : !(u.LotterySeq.includes(o) && r || o && u.TradeSeq.includes(o) && 30 !== i)));
            }, e.prototype.getChildVoucherManagementStatus = function(e) {
                var t = this.generateOrderRefundStatus(e);
                return {
                    isDealingWithByLeader: t.isDealingWithByLeader,
                    isRejectedByLeader: t.isRejectedByLeader,
                    isAgreedByLeader: t.isAgreedByLeader,
                    isRejectedByBrand: t.isRejectedByBrand,
                    isRefunding: t.isRefunding,
                    isRejected: t.isRejected,
                    isFinishedRefund: t.isFinishedRefund,
                    isRefundFailed: t.isRefundFailed,
                    isDealing: t.isDealing
                };
            }, e.prototype.generateOrderStatus = function(e) {
                return Object.keys(e).forEach(function(t) {
                    void 0 === e[t] && (e[t] = !1);
                }), e;
            }, e.prototype.getKey = function(e) {
                return Object.keys(e).find(function(t) {
                    return e[t];
                });
            }, e = i.__decorate([ a.Injectable(), i.__metadata("design:paramtypes", [ s.MonoCommonService ]) ], e);
        }();
        t.MonoOrderManageService = c;
    },
    748: function(e, t, r) {
        var n, o = function() {
            function e(e, t) {
                if (!o[e]) {
                    o[e] = {};
                    for (var r = 0; r < e.length; r++) o[e][e.charAt(r)] = r;
                }
                return o[e][t];
            }
            var t = String.fromCharCode, r = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=", n = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+-$", o = {}, i = {
                compressToBase64: function(e) {
                    if (null == e) return "";
                    var t = i._compress(e, 6, function(e) {
                        return r.charAt(e);
                    });
                    switch (t.length % 4) {
                      default:
                      case 0:
                        return t;

                      case 1:
                        return t + "===";

                      case 2:
                        return t + "==";

                      case 3:
                        return t + "=";
                    }
                },
                decompressFromBase64: function(t) {
                    return null == t ? "" : "" == t ? null : i._decompress(t.length, 32, function(n) {
                        return e(r, t.charAt(n));
                    });
                },
                compressToUTF16: function(e) {
                    return null == e ? "" : i._compress(e, 15, function(e) {
                        return t(e + 32);
                    }) + " ";
                },
                decompressFromUTF16: function(e) {
                    return null == e ? "" : "" == e ? null : i._decompress(e.length, 16384, function(t) {
                        return e.charCodeAt(t) - 32;
                    });
                },
                compressToUint8Array: function(e) {
                    for (var t = i.compress(e), r = new Uint8Array(2 * t.length), n = 0, o = t.length; n < o; n++) {
                        var a = t.charCodeAt(n);
                        r[2 * n] = a >>> 8, r[2 * n + 1] = a % 256;
                    }
                    return r;
                },
                decompressFromUint8Array: function(e) {
                    if (null == e) return i.decompress(e);
                    for (var r = new Array(e.length / 2), n = 0, o = r.length; n < o; n++) r[n] = 256 * e[2 * n] + e[2 * n + 1];
                    var a = [];
                    return r.forEach(function(e) {
                        a.push(t(e));
                    }), i.decompress(a.join(""));
                },
                compressToEncodedURIComponent: function(e) {
                    return null == e ? "" : i._compress(e, 6, function(e) {
                        return n.charAt(e);
                    });
                },
                decompressFromEncodedURIComponent: function(t) {
                    return null == t ? "" : "" == t ? null : (t = t.replace(/ /g, "+"), i._decompress(t.length, 32, function(r) {
                        return e(n, t.charAt(r));
                    }));
                },
                compress: function(e) {
                    return i._compress(e, 16, function(e) {
                        return t(e);
                    });
                },
                _compress: function(e, t, r) {
                    if (null == e) return "";
                    var n, o, i, a = {}, s = {}, u = "", c = "", l = "", d = 2, p = 3, f = 2, h = [], S = 0, _ = 0;
                    for (i = 0; i < e.length; i += 1) if (u = e.charAt(i), Object.prototype.hasOwnProperty.call(a, u) || (a[u] = p++, 
                    s[u] = !0), c = l + u, Object.prototype.hasOwnProperty.call(a, c)) l = c; else {
                        if (Object.prototype.hasOwnProperty.call(s, l)) {
                            if (l.charCodeAt(0) < 256) {
                                for (n = 0; n < f; n++) S <<= 1, _ == t - 1 ? (_ = 0, h.push(r(S)), S = 0) : _++;
                                for (o = l.charCodeAt(0), n = 0; n < 8; n++) S = S << 1 | 1 & o, _ == t - 1 ? (_ = 0, 
                                h.push(r(S)), S = 0) : _++, o >>= 1;
                            } else {
                                for (o = 1, n = 0; n < f; n++) S = S << 1 | o, _ == t - 1 ? (_ = 0, h.push(r(S)), 
                                S = 0) : _++, o = 0;
                                for (o = l.charCodeAt(0), n = 0; n < 16; n++) S = S << 1 | 1 & o, _ == t - 1 ? (_ = 0, 
                                h.push(r(S)), S = 0) : _++, o >>= 1;
                            }
                            0 == --d && (d = Math.pow(2, f), f++), delete s[l];
                        } else for (o = a[l], n = 0; n < f; n++) S = S << 1 | 1 & o, _ == t - 1 ? (_ = 0, 
                        h.push(r(S)), S = 0) : _++, o >>= 1;
                        0 == --d && (d = Math.pow(2, f), f++), a[c] = p++, l = String(u);
                    }
                    if ("" !== l) {
                        if (Object.prototype.hasOwnProperty.call(s, l)) {
                            if (l.charCodeAt(0) < 256) {
                                for (n = 0; n < f; n++) S <<= 1, _ == t - 1 ? (_ = 0, h.push(r(S)), S = 0) : _++;
                                for (o = l.charCodeAt(0), n = 0; n < 8; n++) S = S << 1 | 1 & o, _ == t - 1 ? (_ = 0, 
                                h.push(r(S)), S = 0) : _++, o >>= 1;
                            } else {
                                for (o = 1, n = 0; n < f; n++) S = S << 1 | o, _ == t - 1 ? (_ = 0, h.push(r(S)), 
                                S = 0) : _++, o = 0;
                                for (o = l.charCodeAt(0), n = 0; n < 16; n++) S = S << 1 | 1 & o, _ == t - 1 ? (_ = 0, 
                                h.push(r(S)), S = 0) : _++, o >>= 1;
                            }
                            0 == --d && (d = Math.pow(2, f), f++), delete s[l];
                        } else for (o = a[l], n = 0; n < f; n++) S = S << 1 | 1 & o, _ == t - 1 ? (_ = 0, 
                        h.push(r(S)), S = 0) : _++, o >>= 1;
                        0 == --d && (d = Math.pow(2, f), f++);
                    }
                    for (o = 2, n = 0; n < f; n++) S = S << 1 | 1 & o, _ == t - 1 ? (_ = 0, h.push(r(S)), 
                    S = 0) : _++, o >>= 1;
                    for (;;) {
                        if (S <<= 1, _ == t - 1) {
                            h.push(r(S));
                            break;
                        }
                        _++;
                    }
                    return h.join("");
                },
                decompress: function(e) {
                    return null == e ? "" : "" == e ? null : i._decompress(e.length, 32768, function(t) {
                        return e.charCodeAt(t);
                    });
                },
                _decompress: function(e, r, n) {
                    var o, i, a, s, u, c, l, d = [], p = 4, f = 4, h = 3, S = "", _ = [], E = {
                        val: n(0),
                        position: r,
                        index: 1
                    };
                    for (o = 0; o < 3; o += 1) d[o] = o;
                    for (a = 0, u = Math.pow(2, 2), c = 1; c != u; ) s = E.val & E.position, E.position >>= 1, 
                    0 == E.position && (E.position = r, E.val = n(E.index++)), a |= (s > 0 ? 1 : 0) * c, 
                    c <<= 1;
                    switch (a) {
                      case 0:
                        for (a = 0, u = Math.pow(2, 8), c = 1; c != u; ) s = E.val & E.position, E.position >>= 1, 
                        0 == E.position && (E.position = r, E.val = n(E.index++)), a |= (s > 0 ? 1 : 0) * c, 
                        c <<= 1;
                        l = t(a);
                        break;

                      case 1:
                        for (a = 0, u = Math.pow(2, 16), c = 1; c != u; ) s = E.val & E.position, E.position >>= 1, 
                        0 == E.position && (E.position = r, E.val = n(E.index++)), a |= (s > 0 ? 1 : 0) * c, 
                        c <<= 1;
                        l = t(a);
                        break;

                      case 2:
                        return "";
                    }
                    for (d[3] = l, i = l, _.push(l); ;) {
                        if (E.index > e) return "";
                        for (a = 0, u = Math.pow(2, h), c = 1; c != u; ) s = E.val & E.position, E.position >>= 1, 
                        0 == E.position && (E.position = r, E.val = n(E.index++)), a |= (s > 0 ? 1 : 0) * c, 
                        c <<= 1;
                        switch (l = a) {
                          case 0:
                            for (a = 0, u = Math.pow(2, 8), c = 1; c != u; ) s = E.val & E.position, E.position >>= 1, 
                            0 == E.position && (E.position = r, E.val = n(E.index++)), a |= (s > 0 ? 1 : 0) * c, 
                            c <<= 1;
                            d[f++] = t(a), l = f - 1, p--;
                            break;

                          case 1:
                            for (a = 0, u = Math.pow(2, 16), c = 1; c != u; ) s = E.val & E.position, E.position >>= 1, 
                            0 == E.position && (E.position = r, E.val = n(E.index++)), a |= (s > 0 ? 1 : 0) * c, 
                            c <<= 1;
                            d[f++] = t(a), l = f - 1, p--;
                            break;

                          case 2:
                            return _.join("");
                        }
                        if (0 == p && (p = Math.pow(2, h), h++), d[l]) S = d[l]; else {
                            if (l !== f) return null;
                            S = i + i.charAt(0);
                        }
                        _.push(S), d[f++] = i + S.charAt(0), i = S, 0 == --p && (p = Math.pow(2, h), h++);
                    }
                }
            };
            return i;
        }();
        void 0 === (n = function() {
            return o;
        }.call(t, r, t, e)) || (e.exports = n);
    },
    750: function(e, t, r) {
        var n, o;
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.appIdInfoTypeMap = t.AppIdType = void 0, function(e) {
            e.QJL_OLD = "wx059cd327295ab444", e.QJL_PRO = "wx7d1304df49306ae4", e.QJL_PLUS = "wx4e882f509b425d94", 
            e.QJL_ACT_SHARE = "wx974b793334f3667b";
        }(o = t.AppIdType || (t.AppIdType = {})), t.appIdInfoTypeMap = ((n = {})[o.QJL_OLD] = "群接龙", 
        n[o.QJL_PRO] = "群接龙pro", n[o.QJL_ACT_SHARE] = "群接龙活动", n[o.QJL_PLUS] = "群接龙+", n);
    },
    77: function(e, t, r) {
        var n, o;
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.PickupDetailOperateMode = t.clickRenewalModalConfirmBtnPageName = t.HOME_ASYNC_DATA_WAIT_TIME = t.RebateCardStatus = t.supplyBrandOriginTypeText = t.SupplyBrandOriginType = void 0, 
        function(e) {
            e[e.NATURAL = 20] = "NATURAL", e[e.INVITE = 25] = "INVITE", e[e.SUPPLY_LEADER_INVITE = 30] = "SUPPLY_LEADER_INVITE", 
            e[e.SUPPLY_BRAND_INVITE = 35] = "SUPPLY_BRAND_INVITE";
        }(o = t.SupplyBrandOriginType || (t.SupplyBrandOriginType = {})), t.supplyBrandOriginTypeText = ((n = {})[o.NATURAL] = "自主创建", 
        n[o.INVITE] = "邀请加入", n[o.SUPPLY_LEADER_INVITE] = "邀请加入", n[o.SUPPLY_BRAND_INVITE] = "对方邀请", 
        n), function(e) {
            e[e.OVERDUE = 1] = "OVERDUE", e[e.NORMAL = 10] = "NORMAL", e[e.STOP = 20] = "STOP";
        }(t.RebateCardStatus || (t.RebateCardStatus = {})), t.HOME_ASYNC_DATA_WAIT_TIME = 50, 
        function(e) {
            e[e.GROUP_HELP_SALE = 0] = "GROUP_HELP_SALE", e[e.GROUP_WELFARE = 1] = "GROUP_WELFARE", 
            e[e.GROUP_PRAISED = 2] = "GROUP_PRAISED", e[e.EVALUATION_SQUARE = 3] = "EVALUATION_SQUARE", 
            e[e.BECOME_LEADER = 4] = "BECOME_LEADER", e[e.DETAIL = 5] = "DETAIL";
        }(t.clickRenewalModalConfirmBtnPageName || (t.clickRenewalModalConfirmBtnPageName = {})), 
        function(e) {
            e[e.NONE = 0] = "NONE", e[e.EDIT = 1] = "EDIT", e[e.SIGN_POSTER_AND_EDIT = 2] = "SIGN_POSTER_AND_EDIT", 
            e[e.AUDIT = 3] = "AUDIT", e[e.SELECT = 4] = "SELECT";
        }(t.PickupDetailOperateMode || (t.PickupDetailOperateMode = {}));
    },
    803: function(t, r) {
        Promise || (Promise = function() {
            function t(e) {
                return Boolean(e && void 0 !== e.length);
            }
            function r() {}
            function n(e) {
                if (!(this instanceof n)) throw new TypeError("Promises must be constructed via new");
                if ("function" != typeof e) throw new TypeError("not a function");
                this._state = 0, this._handled = !1, this._value = void 0, this._deferreds = [], 
                c(e, this);
            }
            function o(e, t) {
                for (;3 === e._state; ) e = e._value;
                0 !== e._state ? (e._handled = !0, n._immediateFn(function() {
                    var r = 1 === e._state ? t.onFulfilled : t.onRejected;
                    if (null !== r) {
                        var n;
                        try {
                            n = r(e._value);
                        } catch (e) {
                            return void a(t.promise, e);
                        }
                        i(t.promise, n);
                    } else (1 === e._state ? i : a)(t.promise, e._value);
                })) : e._deferreds.push(t);
            }
            function i(t, r) {
                try {
                    if (r === t) throw new TypeError("A promise cannot be resolved with itself.");
                    if (r && ("object" == (void 0 === r ? "undefined" : e(r)) || "function" == typeof r)) {
                        var o = r.then;
                        if (r instanceof n) return t._state = 3, t._value = r, void s(t);
                        if ("function" == typeof o) return void c((i = o, u = r, function() {
                            i.apply(u, arguments);
                        }), t);
                    }
                    t._state = 1, t._value = r, s(t);
                } catch (r) {
                    a(t, r);
                }
                var i, u;
            }
            function a(e, t) {
                e._state = 2, e._value = t, s(e);
            }
            function s(e) {
                2 === e._state && 0 === e._deferreds.length && n._immediateFn(function() {
                    e._handled || n._unhandledRejectionFn(e._value);
                });
                for (var t = 0, r = e._deferreds.length; t < r; t++) o(e, e._deferreds[t]);
                e._deferreds = null;
            }
            function u(e, t, r) {
                this.onFulfilled = "function" == typeof e ? e : null, this.onRejected = "function" == typeof t ? t : null, 
                this.promise = r;
            }
            function c(e, t) {
                var r = !1;
                try {
                    e(function(e) {
                        r || (r = !0, i(t, e));
                    }, function(e) {
                        r || (r = !0, a(t, e));
                    });
                } catch (e) {
                    if (r) return;
                    r = !0, a(t, e);
                }
            }
            var l = setTimeout;
            return n.prototype.catch = function(e) {
                return this.then(null, e);
            }, n.prototype.then = function(e, t) {
                var n = new this.constructor(r);
                return o(this, new u(e, t, n)), n;
            }, n.prototype.finally = function(e) {
                var t = this.constructor;
                return this.then(function(r) {
                    return t.resolve(e()).then(function() {
                        return r;
                    });
                }, function(r) {
                    return t.resolve(e()).then(function() {
                        return t.reject(r);
                    });
                });
            }, n.all = function(r) {
                return new n(function(n, o) {
                    function i(t, r) {
                        try {
                            if (r && ("object" == (void 0 === r ? "undefined" : e(r)) || "function" == typeof r)) {
                                var u = r.then;
                                if ("function" == typeof u) return void u.call(r, function(e) {
                                    i(t, e);
                                }, o);
                            }
                            a[t] = r, 0 == --s && n(a);
                        } catch (t) {
                            o(t);
                        }
                    }
                    if (!t(r)) return o(new TypeError("Promise.all accepts an array"));
                    var a = Array.prototype.slice.call(r);
                    if (0 === a.length) return n([]);
                    for (var s = a.length, u = 0; u < a.length; u++) i(u, a[u]);
                });
            }, n.resolve = function(t) {
                return t && "object" == (void 0 === t ? "undefined" : e(t)) && t.constructor === n ? t : new n(function(e) {
                    e(t);
                });
            }, n.reject = function(e) {
                return new n(function(t, r) {
                    r(e);
                });
            }, n.race = function(e) {
                return new n(function(r, o) {
                    if (!t(e)) return o(new TypeError("Promise.race accepts an array"));
                    for (var i = 0, a = e.length; i < a; i++) n.resolve(e[i]).then(r, o);
                });
            }, n._immediateFn = function(e) {
                l(e, 0);
            }, n._unhandledRejectionFn = function(e) {
                "undefined" != typeof console && console;
            }, n;
        }());
    },
    805: function(e, t) {
        !function() {
            function e(e) {
                !function(e) {
                    try {
                        if (!e || !e.scene) return;
                        decodeURIComponent(e.scene).split("&").forEach(function(t, r) {
                            var n = t.split("=");
                            2 == n.length && (e[n[0]] = n[1]);
                        });
                    } catch (e) {}
                }(e);
            }
            function t(e, t) {}
            var r = Page;
            Page = function(n) {
                !function(e, t, r) {
                    if (e[t]) {
                        var n = e[t];
                        e[t] = function(e) {
                            r.call(this, e, t), n.call(this, e);
                        };
                    } else e[t] = function(e) {
                        r.call(this, e, t);
                    };
                }(n, "onLoad", e), void 0 !== n.onShareAppMessage && function(e, t, r) {
                    if (e[t]) {
                        var n = e[t];
                        e[t] = function(e) {
                            void 0 !== this.beforeShareMessage && this.beforeShareMessage(e);
                            var o = n.call(this, e);
                            return r.call(this, [ e, o ], t), o;
                        };
                    } else e[t] = function(e) {
                        r.call(this, e, t);
                    };
                }(n, "onShareAppMessage", t), r(n);
            };
        }();
    },
    806: function(e, t) {
        Array.prototype.includes || Object.defineProperty(Array.prototype, "includes", {
            value: function(e, t) {
                if (null == this) throw new TypeError('"this" is null or not defined');
                var r = Object(this), n = r.length >>> 0;
                if (0 === n) return !1;
                for (var o = 0 | t, i = Math.max(o >= 0 ? o : n - Math.abs(o), 0); i < n; ) {
                    if (r[i] === e) return !0;
                    i++;
                }
                return !1;
            }
        });
    },
    807: function(e, t) {
        Array.prototype.every || (Array.prototype.every = function(e) {
            if (null == this) throw new TypeError();
            var t = Object(this), r = t.length >>> 0;
            if ("function" != typeof e) throw new TypeError();
            for (var n = arguments.length >= 2 ? arguments[1] : void 0, o = 0; o < r; o++) if (o in t && !e.call(n, t[o], o, t)) return !1;
            return !0;
        });
    },
    808: function(e, t) {
        function r(e, t, r) {
            return e >>= 0, t = String(void 0 !== t ? t : " "), this.length > e ? String(this) : ((e -= this.length) > t.length && (t += t.repeat(e / t.length)), 
            t = t.slice(0, e), ("padStart" === r ? t : "") + String(this) + ("padEnd" === r ? t : ""));
        }
        String.prototype.padEnd || (String.prototype.padEnd = function(e, t) {
            return r.call(this, e, t, "padEnd");
        }), String.prototype.padStart || (String.prototype.padStart = function(e, t) {
            return r.call(this, e, t, "padStart");
        });
    },
    809: function(e, t) {
        Object.entries || (Object.entries = function(e) {
            for (var t = Object.keys(e), r = t.length, n = new Array(r); r--; ) n[r] = [ t[r], e[t[r]] ];
            return n;
        });
    },
    810: function(e, t) {
        e.exports = {};
    },
    811: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.Socket = void 0;
        var n = r(0), o = function(e) {
            function t(t, r) {
                var n = e.call(this) || this;
                return n.room = t, n.leave = r, n;
            }
            return n.__extends(t, e), Object.defineProperty(t.prototype, "roomName", {
                get: function() {
                    return this.room;
                },
                enumerable: !1,
                configurable: !0
            }), t.prototype.exit = function() {
                this.leave();
            }, t;
        }(r(7).Subject);
        t.Socket = o;
    },
    817: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var n = r(0), o = function() {
            function e() {
                this.listeners = {};
            }
            return e.prototype.addListener = function(e, t) {
                return this.listeners[e] = this.listeners[e] || [], this.listeners[e].push(t), this;
            }, e.prototype.on = function(e, t) {
                return this.addListener(e, t);
            }, e.prototype.once = function(e, t) {
                var r = this;
                this.listeners[e] = this.listeners[e] || [];
                return this.listeners[e].push(function o() {
                    for (var i = [], a = 0; a < arguments.length; a++) i[a] = arguments[a];
                    t.apply(void 0, n.__spread(i)), r.off(e, o);
                }), this;
            }, e.prototype.off = function(e, t) {
                return this.removeListener(e, t);
            }, e.prototype.removeListener = function(e, t) {
                var r = this.listeners[e];
                if (!r) return this;
                for (var n = r.length - 1; n >= 0; n--) if (r[n] === t) {
                    r.splice(n, 1);
                    break;
                }
                return this;
            }, e.prototype.emit = function(e) {
                for (var t = [], r = 1; r < arguments.length; r++) t[r - 1] = arguments[r];
                var o = this.listeners[e];
                return !!o && (o.forEach(function(e) {
                    e.apply(void 0, n.__spread(t));
                }), !0);
            }, e.prototype.listenerCount = function(e) {
                return (this.listeners[e] || []).length;
            }, e.prototype.rawListeners = function(e) {
                return this.listeners[e];
            }, e;
        }();
        t.default = o;
    },
    84: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.mixin = t.mixinOptions = void 0;
        var n = r(434), o = {};
        t.mixinOptions = {
            prototypeDidApply: function(e, t, r) {
                Object.assign(o, e.prototype.computed, r.mixinComputed, r.computed);
            },
            beforeFinishMixin: function(e, t) {
                Object.keys(o).length && (t.prototype.mixinComputed = o, o = {});
            }
        }, t.mixin = n.createMixin(t.mixinOptions);
    }
} ]);