var e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
};

require("./../../../../runtime"), require("./../../../../mono"), require("./../../../../common"), 
function(e, t) {
    for (var i in t) e[i] = t[i];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 567 ], {
    2: function(t, i) {
        var a;
        a = function() {
            return this;
        }();
        try {
            a = a || new Function("return this")();
        } catch (t) {
            "object" == ("undefined" == typeof window ? "undefined" : e(window)) && (a = window);
        }
        t.exports = a;
    },
    443: function(e, t, i) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.customerHomepagePriorityComputed = t.customerHomePagePrioritySort = void 0, 
        t.customerHomePagePrioritySort = {
            isShowNewUserGiftModal: 900,
            isShowSearchRegisterNewUserShuntModal: 600,
            isShowCreditScoreChangeModal: 500
        }, t.customerHomepagePriorityComputed = {
            curShowKey: function(e) {
                if (this.modalPriorityManage) {
                    var t = e.isNeedShowCreditScoreChangeModal;
                    this.modalPriorityManage.listen("isShowCreditScoreChangeModal", t);
                }
            }
        };
    },
    791: function(e, t, i) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var a = i(0), o = i(1), r = i(792), s = i(5), n = i(6), c = i(233), d = i(15), h = i(10), u = i(14), l = i(23), p = i(7), m = i(3), g = i(798), S = i(17), v = i(445), f = i(33), y = i(98), T = i(446), w = i(799), D = i(160), M = i(20), I = i(273), P = i(40), C = i(63), _ = i(202), b = i(18), U = i(19), H = i(118), A = i(30), R = i(201), G = i(26), x = i(330), N = i(16), L = i(60), O = i(270), E = i(13), k = i(27), q = i(53), B = i(24), F = i(58), j = i(45), z = i(37), V = i(29), W = i(9), K = i(327), J = i(800), Q = i(92), Z = i(447), Y = i(158), $ = i(801), X = i(8), ee = i(139), te = i(443), ie = i(34);
        !function(e) {
            function t(t, i, a, o, r, s, n, c, d, h, u, l, p, m, g, S, v, f, y, T, w, D, M, I, P, C, _, b, U, H, A, R) {
                var G = e.call(this) || this;
                return G.apiService = t, G.utils = i, G.commonService = a, G.routeService = o, G.grayService = r, 
                G.monitor = s, G.processMonitor = n, G.posterService = c, G.common = d, G.seqService = h, 
                G.chatUtilService = u, G.timeService = l, G.actPosterService = p, G.homeTagService = m, 
                G.monoRedDotService = g, G.userInfoService = S, G.homepageService = v, G.userCardInfoService = f, 
                G.imService = y, G.lotteryPosterService = T, G.migrateService = w, G.urlService = D, 
                G.errorService = M, G.fileService = I, G.actUidBlockedService = P, G.customerHomepageService = C, 
                G.loginService = _, G.homeCreditScoreService = b, G.homeNavbarService = U, G.tagIconService = H, 
                G.scopeFileService = A, G.homeFakeSeparateService = R, G.data = {
                    groupType: 30,
                    isCustomerHomepageLoading: !0,
                    isSeqMenuExpanded: !1,
                    searchRegisterWithTimeBizCode: $.SEARCH_REGISTER_WITH_TIME_BIZ_CODE
                }, G.computed = te.customerHomepagePriorityComputed, G.PUBLISH_URL = "/pro/pages/seq-publish/publish-start-group/publish-start-group", 
                G.isFirstProcessOnShow = !0, G;
            }
            a.__extends(t, e);
            var i = t.prototype;
            i.onLoad = function(t) {
                var i = this;
                e.prototype.onLoad.call(this, t), this.monitor.timeStart("个人主页静默登录白屏时间"), this.initGrayPageStyle(), 
                this.reportCustomerHomeLoadTime(), this.loadParams = t, this.navHome = !!t.navHome, 
                this.enterType = Number(t.enterType || 0), this.onUploadSessionLoad(), this.initModalPriorityManage(), 
                this.initGrayPageStyle(), this.getGrayInfo(), this.onPosterLoad();
                var a = this.utils.apiImage("/sys/draw_share_image/gh_share");
                this.initTimeline(t, {
                    imgContent: a
                }, function() {
                    return {
                        title: i.data.userName + "邀请您发个群接龙~ 7000万人都在用"
                    };
                }), this.initSeqFetcher(), this.initSeqMenuExpandStatus();
                var o = this.checkHasAuthorized();
                if (this.utils.setGlobalData("homeDataInfo", {
                    groupId: "",
                    groupType: 30
                }), !o) return this.loginAndRefreshPage(), void this.setData({
                    seqTypeList: r.DefaultSeqTypeList,
                    emptyList: new Array(1)
                });
                this.onLoadRefreshAfterLogin();
            }, i.onUnload = function() {
                e.prototype.onUnload.call(this), this.scopeFileService.clearUploader(), this.tagIconService.clearTagSettingList(), 
                this.clearActDynamicTextInterval(), this.stopRandomInterval(), this.disconnectVirtualListObserver(), 
                this.clearBannerTimer();
            }, i.onShow = function() {
                e.prototype.onShow.call(this), this.scopeFileService.setUploader(this), this.initVisitData(), 
                this.initShowActDynamicText(), this.isFirstProcessOnShow || this.judgeHideBanner(), 
                this.getBusinessList().length && this.startObserveVirtualList(".seq-vlist"), this.data.hasAuthorized ? this.onShowRefreshAfterLogin() : this.updateHasAuthorized();
            }, i.onHide = function() {
                e.prototype.onHide.call(this), this.clearActDynamicTextInterval(), this.stopRandomInterval(), 
                this.disconnectVirtualListObserver(), this.clearBannerTimer();
            }, i.onPullDownRefresh = function() {
                this.data.hasAuthorized ? (this.getUserHeader(), this.seqFetcher.reloadDataList(), 
                this.homeNavbarService.confirmUpdateSwitch(), this.refreshPersonalImRedDot(), this.refreshUserCardData()) : wx.stopPullDownRefresh({});
            }, i.onShareAppMessage = function(e) {
                var t, i, a, o, r, s, n, c, d, h, l, p;
                if (e.target && e.target.dataset.seqItem) return this.onShareSeqMessage(e);
                if ((null === (a = null === (i = null === (t = e.target) || void 0 === t ? void 0 : t.dataset) || void 0 === i ? void 0 : i.shareData) || void 0 === a ? void 0 : a.type) === u.ShareInfoType.SHARE_SELECTOR) {
                    if (!(null === (s = null === (r = null === (o = e.target) || void 0 === o ? void 0 : o.dataset) || void 0 === r ? void 0 : r.shareData) || void 0 === s ? void 0 : s.shareInfo)) throw new Error("未获取到分享参数");
                    return null === (d = null === (c = null === (n = e.target) || void 0 === n ? void 0 : n.dataset) || void 0 === c ? void 0 : c.shareData) || void 0 === d ? void 0 : d.shareInfo;
                }
                if ((null === (p = null === (l = null === (h = e.target) || void 0 === h ? void 0 : h.dataset) || void 0 === l ? void 0 : l.shareData) || void 0 === p ? void 0 : p.type) === u.ShareInfoType.INVITE_TOGETHER_BUY) return this.getTogetherBuyInviteMessage(e);
                var m = this.data, g = m.userName;
                return {
                    title: g ? g + "邀请您发个群接龙" : "做社群,就用群接龙",
                    path: "/pro/pages/homepage/customer-homepage/customer-homepage?groupType=30&navHome=1",
                    imageUrl: m.homeShareImg
                };
            }, i.onReachBottom = function() {
                this.data.hasAuthorized && this.seqFetcher.loadMoreDataList();
            }, i.onPageScroll = function(e) {
                var t = Number(e.scrollTop >= 2500), i = this.data.isShowBackTopBtn;
                t ^ Number(i) && this.setData({
                    isShowBackTopBtn: !i
                });
            }, i.handleTapBackTop = function() {
                wx.pageScrollTo({
                    scrollTop: 0,
                    duration: 300
                });
            }, i.handleTapBanner = function() {
                var e = this;
                this.grayService.canIUseFeature("2219").subscribe(function(t) {
                    e.data.hasAuthorized ? e.personalGroupId && (t ? e.routeService.goHomeCreateHomepageMultitypeCreateHome({
                        data: {
                            navType: 10
                        }
                    }) : e.routeService.goHomeCreateHomepageHomepageIntroduce({
                        data: {
                            groupId: e.personalGroupId
                        }
                    })) : e.goAuthorization();
                });
            }, i.handleTapSeqType = function(e) {
                var t = e.currentTarget.dataset.type;
                this.utils.navigateTo(this.PUBLISH_URL, {
                    groupId: this.personalGroupId,
                    seqType: t
                });
            }, i.handleTapNavCase = function(e) {
                var t = e.currentTarget.dataset.type;
                this.personalGroupId && this.routeService.goHomeSeqCaseList({
                    data: {
                        type: t,
                        groupId: this.personalGroupId,
                        groupType: this.data.groupType
                    }
                });
            }, i.handleSearchBarExpand = function(e) {
                this.setData({
                    isSearchBarExpand: e.detail.isExpand
                });
            }, i.handleTapSearch = function(e) {
                this.data.hasAuthorized && (this.data.searchKeyWord = e.detail.value, this.setData({
                    isCustomerHomepageLoading: !0
                }), this.seqFetcher.reloadDataList());
            }, i.handleTapCancel = function() {
                this.data.hasAuthorized && (this.data.searchKeyWord = "", this.seqFetcher.reloadDataList());
            }, i.handleRefreshList = function(e) {
                this.seqFetcher.refreshCurrentPage(e.detail.index);
            }, i.handleReloadList = function() {
                this.seqFetcher.reloadDataList();
            }, i.handleSelectChatHome = function(e) {
                var t = e.detail.zoneItem.ghId;
                this.setData({
                    isShowSelectHomeModal: !1
                });
                var i = this.data, a = i.isToOfficialProxy, o = i.isToImFindHotGoods;
                a ? this.goToOfficialProxyChatPage(this.loadParams.groupId, t) : o ? this.goToImFindHotGoodsChatPage(t) : this.goChatPage(!1, t);
            }, i.handleAuthorizeSuccess = function() {
                this.updateHasAuthorized(), this.handleCloseAuthorizationPopup();
            }, i.handleTapPublish = function() {
                this.data.hasAuthorized ? this.setData({
                    isShowSeqModal: !0
                }) : this.goAuthorization();
            }, i.handleClosePublishModal = function() {}, i.handleTapJoinNumIcon = function(e) {
                var t = e.detail;
                this.userCardInfoService.clearUserCardRedDot(t), "newEnterGhNum" === t && this.goToJoinedCommunitiesPage(), 
                "newOrderNum" === t && this.goToCustomerOrderManagePage(), "newPublishActNum" === t && this.navToMyPublish();
            }, i.handleToggleSeqMenuStatus = function(e) {
                var t = e.detail.isExpanded;
                this.setData({
                    isSeqMenuExpanded: t
                });
            }, i.handleSaveCustomerPoster = function(e) {
                this.handleAuthorizeSaveImage(e);
            }, i.handleGetMsg = function(e) {
                var t = e.detail.msgNum;
                this.setData({
                    newMsgNum: t
                });
            }, i.handleCloseNewUserGiftModal = function() {
                this.data.isShowQjlNewUserGuideModal && (this.markReadRedDotByUid([ {
                    code: 1160
                } ]), this.modalPriorityManage.remove("isShowNewUserGiftModal"));
            }, i.handleTapNewUserGiftModal = function() {
                this.data.isShowQjlNewUserGuideModal && this.markReadRedDotByUid([ {
                    code: 1160
                } ]);
                var e = "ss/app/image/plus/code21.png";
                this.fileService.viewImages([ e ], e), this.modalPriorityManage.remove("isShowNewUserGiftModal");
            }, i.handleCloseCreditScoreOnlineModal = function() {
                this.markReadRedDotByUid([ {
                    code: 2023
                } ]);
            }, i.handleCloseCreditScoreChangeModal = function() {
                this.hideCreditScoreChangeModal();
            }, i.handleGoToCreditScore = function() {
                this.hideCreditScoreChangeModal(), this.routeService.goProfileCreditScore({
                    data: {
                        groupId: this.data.personalGroupId
                    }
                });
            }, i.hideCreditScoreChangeModal = function() {
                this.markReadRedDotByGroupId([ {
                    code: 2024,
                    groupId: this.data.personalGroupId
                } ]);
            }, i.refreshAfterLogin = function() {
                this.onLoadRefreshAfterLogin(), this.onShowRefreshAfterLogin();
            }, i.onLoadRefreshAfterLogin = function() {
                this.updateHasAuthorized(), this.setData({
                    actId: Number(this.loadParams.actId || 0),
                    actIdForSearchVoucherSign: Number(this.loadParams.actIdForSearchVoucherSign) || null,
                    orderNoFromNotification: this.loadParams.orderNo,
                    homeShareImg: this.utils.apiImage("/sys/draw_share_image/gh_share")
                }), this.listenUserInfoUpdate();
            }, i.onShowRefreshAfterLogin = function() {
                this.getUserHeader(), this.getUserCardRedDots(), this.refreshPersonalImRedDot(), 
                this.refreshUserCardData(), this.isFirstProcessOnShow = !1;
            }, i.getBusinessList = function() {
                return this.data.seqList || [];
            }, i.updateBusinessList = function(e) {
                var t = this, i = {};
                Object.keys(e).forEach(function(a) {
                    t.data.seqList[a] && (i["seqList[" + a + "].vState$$"] = e[a]);
                }), this.setData(i);
            }, i.getUserHeader = function() {
                var e = this;
                this.getUserCardRedDots(), this.apiService.searchUserInfoUserBizUsingGET(E.skipErrorOptions).pipe(m.map(function(e) {
                    return e.data;
                }), m.takeUntil(this.unloadObservable)).subscribe(function(t) {
                    e.personalGroupId = t.personGhId;
                    var i = t.personGhId, a = t.nickname, o = t.uid, r = t.balance, s = t.fansNum, n = t.follows, c = t.orderCount, d = t.createTime, h = e.loginService.matchRandomNickname(a);
                    e.setData({
                        personalGroupId: i,
                        userName: a,
                        uid: o,
                        balance: r,
                        fansNum: s,
                        subscribeNum: n,
                        orderCount: c,
                        headerInfo: {
                            pic: t.headimgurl,
                            name: a
                        },
                        isDefaultNickname: h,
                        createTime: d
                    }, function() {
                        var t, i, a;
                        e.checkReportContent(e.loadParams), 1 === e.enterType ? e.getShareActTipsPopup() : e.getShareActTips(), 
                        e.getAllRedDotTips(), e.checkCustomerPageAllWxShowModals(), "true" === (null === (t = e.loadParams) || void 0 === t ? void 0 : t.isRouteMASChatPage) && e.getUserHomePage();
                        var o = "true" === (null === (i = e.loadParams) || void 0 === i ? void 0 : i.isToOfficialProxyChatPage);
                        o && (e.processToOfficialProxyMode(e.loadParams.groupId), e.setData({
                            isToOfficialProxy: o
                        }));
                        var r = "true" === (null === (a = e.loadParams) || void 0 === a ? void 0 : a.isToImFindHotGoodsChatPage);
                        r && (e.processGoToImFindHotGoodsChatPage(), e.setData({
                            isToImFindHotGoods: r
                        }));
                    });
                });
            }, i.initSeqFetcher = function() {
                var e = this;
                this.timeStart("个人首页 feed 流 -> 渲染时间"), this.seqFetcher = new l.DataList3(function(t) {
                    1 === t && (e.lastRowKey = void 0, e.setData({
                        isCustomerHomepageLoading: !0
                    })), e.showDataListLoading();
                    var i = {
                        page: t,
                        pageSize: 10
                    }, o = e.data.searchKeyWord ? {
                        keyword: e.data.searchKeyWord
                    } : null;
                    return e.apiService.queryUserFeedNewUsingPOST(a.__assign(a.__assign(a.__assign({}, i), o), {
                        lastRowKey: e.lastRowKey
                    })).pipe(m.map(function(t) {
                        var i = t.data, a = void 0 === i ? {} : i, o = a.feedItemDTOList, r = void 0 === o ? [] : o, s = a.hasNextPage, n = a.lastRowKeyId, c = a.isOfficialRecommend && (e.data.seqList || r).length;
                        return c || (e.lastRowKey = n), e.setTopAct(r), e.setData({
                            isShowOfficialRecommendTitle: c
                        }), {
                            list: r,
                            hasNext: s
                        };
                    }), m.tap(function(t) {
                        var i = t.list;
                        if (e.processMonitor.timeStop("appOnShow -> appOnFetch"), e.processMonitor.timeLaunch("appOnFetch -> appOnRendered"), 
                        0 !== i.length) {
                            var o = i.map(function(e) {
                                var t;
                                return null === (t = e.actItemDTO) || void 0 === t ? void 0 : t.ghId;
                            });
                            e.homepageService.checkIsStarGroups(o, e.data.personalGroupId).subscribe(function(t) {
                                var i = a.__read(t, 2), o = i[0], r = i[1];
                                e.setData({
                                    feedStarGroup: a.__assign(a.__assign({}, e.data.feedStarGroup), o),
                                    feedStarGroupChecked: a.__assign(a.__assign({}, e.data.feedStarGroupChecked), r)
                                });
                            });
                        }
                    }), m.finalize(function() {
                        e.hideDataListLoading(), e.setData({
                            isCustomerHomepageLoading: !1
                        });
                    }));
                }, function(t, i, a) {
                    wx.stopPullDownRefresh({}), wx.hideLoading({}), (null == t ? void 0 : t[0]) && (e.homepageService.customerFirstFeed = null == t ? void 0 : t[0]), 
                    e.utils.getApp().globalData.isPc && e.monitor.sum("个人首页 feed 流 setData"), e.setData({
                        seqList: t,
                        isShowQjlTool: e.seqFetcher.isFinished
                    }, function() {
                        e.virtualListChange(".seq-vlist"), e.tagIconService.checkTagIcon(a), e.timeEnd("个人首页 feed 流 -> 渲染时间");
                    });
                }, 10);
            }, i.setTopAct = function(e) {
                var t = this;
                if (1 === this.enterType) {
                    var i = e.findIndex(function(e) {
                        return !!e.actItemDTO && e.actItemDTO.actId === t.data.actId;
                    });
                    if (-1 !== i) {
                        var a = e[i];
                        e.splice(i, 1), e.unshift(a);
                    }
                    this.setData({
                        actId: 0
                    });
                }
            }, i.updateHasAuthorized = function() {
                var e = this.checkHasAuthorized();
                this.setData({
                    hasAuthorized: e
                }), this.afterAuthorized();
            }, i.afterAuthorized = function() {
                if (this.data.hasAuthorized) {
                    if (!this.navHome && !this.isJumpChecked) return this.isJumpChecked = !0, void this.isNavToOtherPage(this.loadParams).subscribe();
                    this.setData({
                        isShowPage: !0,
                        seqTypeList: r.PreviewSeqTypeList
                    }), this.initNewUserGuideProcess(), this.reportCustomerWhitePageEnd(), this.getPageData(), 
                    this.showPageModal(), this.getOtherInfo(), this.initHomeCreditScore();
                }
            }, i.getPageData = function() {
                this.getUserHeader(), this.reportComeHome(), this.seqFetcher.reloadDataList();
            }, i.getOtherInfo = function() {
                var e = this;
                this.tagIconService.groupIconObs.pipe(m.takeUntil(this.unloadObservable)).subscribe(function() {
                    var t = e.tagIconService.setTagIcon(e.data.seqList || []);
                    e.setData({
                        seqList: t
                    });
                }), this.setData({
                    isGrayShowViewCount: !0
                }), this.initCanIUseWxCustomerService(), this.judgeSendCustomerUpgradeInfo(), this.dataStatisticsManager();
            }, i.getGrayInfo = function() {
                var e = this;
                this.grayService.canIUseFeatureByMultiply([ "2349", "2393" ]).subscribe(function(t) {
                    var i = a.__read(t, 2), o = i[0], r = i[1];
                    e.setData({
                        isShowIceBreakerEntrance: r
                    }), o && e.apiService.getBannerInfoConfigUsingPOST(E.skipErrorOptions).subscribe(function(t) {
                        var i;
                        (null === (i = t.data) || void 0 === i ? void 0 : i.open) && e.setData({
                            isHomepageNavigateToEventPlanning: !0
                        });
                    });
                });
            }, i.loginAndRefreshPage = function(e) {
                var t = this;
                if (this.utils.getUid()) return this.setData({
                    isShowPage: !0
                }), void this.reportCustomerWhitePageEnd();
                this.utils.getApp().login().pipe(m.catchError(function(e) {
                    return t.customReportError({
                        frontErrorCode: 5005,
                        error: e
                    }), p.throwError(e);
                }), m.finalize(function() {
                    e();
                })).subscribe(function(e) {
                    if (!(null == e ? void 0 : e.authorization)) return t.customReport({
                        functionName: "customerHomepageNotLogin",
                        methodParams: e
                    }), t.setData({
                        isShowPage: !0
                    }), void t.reportCustomerWhitePageEnd();
                    t.refreshAfterLogin();
                });
            }, i.refreshPersonalImRedDot = function() {
                this.setData({
                    isRefreshCustomerServiceMessage: !this.data.isRefreshCustomerServiceMessage
                });
            }, i.initSeqMenuExpandStatus = function() {
                var e = this;
                this.apiService.judgeNewUserUsingPOST().pipe(m.map(function(e) {
                    return !!e.data;
                }), m.switchMap(function(t) {
                    return t ? p.of(!0) : e.apiService.latestDayHasOrderUserBizUsingGET().pipe(m.map(function(e) {
                        return !e.data;
                    }));
                })).subscribe(function(t) {
                    var i = e.data, a = i.isSearchRegisterUserToMcnVision, o = i.isShowGuideBanner;
                    e.setData({
                        isSeqMenuExpanded: a && o && t
                    });
                });
            }, i.refreshUserCardData = function() {
                var e = this.selectComponent("#customer-homepage-user-card-id");
                e && e.refreshSystemMsgBoxList();
            }, i.listenUserInfoUpdate = function() {
                var e = this;
                this.customerHomepageService.updateUserInfoOb.pipe(m.takeUntil(this.unloadObservable)).subscribe(function() {
                    e.seqFetcher.reloadDataList(), e.homeNavbarService.confirmUpdateSwitch();
                });
            }, i.initGrayPageStyle = function() {
                var e = this;
                this.grayService.canIUseFeature("2454").subscribe(function(t) {
                    t && e.showGrayPageStyle();
                });
            }, i.initHomeCreditScore = function() {
                var e = this, t = this.data.personalGroupId;
                t && this.homeCreditScoreService.initHomeCreditScoreModal(t).subscribe(function(t) {
                    if (t) {
                        var i = t.creditScoreModalTips, a = t.isNeedShowCreditScoreChangeModal;
                        e.setData({
                            creditScoreModalTips: i,
                            isNeedShowCreditScoreChangeModal: a
                        });
                    }
                });
            }, a.__decorate([ N.Toggle("isShowSeqModal", !1), a.__metadata("design:type", Function), a.__metadata("design:paramtypes", []), a.__metadata("design:returntype", void 0) ], t.prototype, "handleClosePublishModal", null), 
            a.__decorate([ N.Toggle("isNeedShowCreditScoreOnlineModal", !1), a.__metadata("design:type", Function), a.__metadata("design:paramtypes", []), a.__metadata("design:returntype", void 0) ], t.prototype, "handleCloseCreditScoreOnlineModal", null), 
            a.__decorate([ N.Toggle("isNeedShowCreditScoreChangeModal", !1), a.__metadata("design:type", Function), a.__metadata("design:paramtypes", []), a.__metadata("design:returntype", void 0) ], t.prototype, "hideCreditScoreChangeModal", null), 
            a.__decorate([ U.Lock(3e3), a.__metadata("design:type", Function), a.__metadata("design:paramtypes", [ Function ]), a.__metadata("design:returntype", void 0) ], t.prototype, "loginAndRefreshPage", null), 
            t = a.__decorate([ o.wxPage(), f.PagePerfTrack("CUSTOMER_PROFILE"), a.__metadata("design:paramtypes", [ s.DefaultService, n.UtilService, d.CommonService, h.RouteService, S.GrayFeatureService, f.PerformanceMonitorService, y.PerformanceProcessMonitorService, D.HomepagePosterService, M.MonoCommonService, P.SequenceService, C.ChatUtilService, b.TimeService, _.ActivityPosterService, H.HomeTagService, A.MonoRedDotService, R.UserInfoService, G.HomepageService, x.UserCardInfoService, L.ImService, O.LotteryPosterService, k.BackendMigrateService, q.UrlService, B.ErrorService, V.FileService, Q.ActUidBlockedService, Z.CustomerHomepageService, Y.LoginService, ee.HomeCreditScoreService, c.HomeNavbarService, v.SetSeqTagIconService, z.ScopeFileService, ie.HomeFakeSeparateService ]) ], t);
        }(W.miniMixin(r.CustomerCommon, g.AccessData, T.ReadReportContent, w.Nav, I.ShareTimeline, X.SuperPage, W.miniMixin(F.VirtualListMixin, j.UploadSessionMixin, K.ChatCustomerServiceWxMixin, J.CustomerHomepageRouteMixin, $.CustomerHomeBannerMixin)));
    },
    792: function(e, t, i) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.CustomerCommon = t.DefaultSeqTypeList = t.PreviewSeqTypeList = void 0;
        var a = i(0), o = i(3), r = i(7), s = i(6), n = i(5), c = i(14), d = i(15), h = i(22), u = i(66), l = i(160), p = i(12), m = i(20), g = i(161), S = i(63), v = i(442), f = i(10), y = i(21), T = i(16), w = i(330), D = i(60), M = i(13), I = i(53), P = i(24), C = i(27), _ = i(9), b = i(1), U = i(26), H = i(795), A = i(796), R = i(85), G = i(443), x = i(444);
        t.PreviewSeqTypeList = [ {
            activityName: "",
            activityLogoUrl: "",
            activityDesc: ""
        }, {
            activityName: "",
            activityLogoUrl: "",
            activityDesc: ""
        }, {
            activityName: "",
            activityLogoUrl: "",
            activityDesc: ""
        } ], t.DefaultSeqTypeList = [ {
            activityName: "团购接龙",
            activityLogoUrl: "/ss/app/image/plus/publish_icon01.png",
            activityDesc: "开展团购活动"
        }, {
            activityName: "填表接龙",
            activityLogoUrl: "/ss/app/image/plus/publish_icon08.png",
            activityDesc: "信息收集"
        }, {
            activityName: "报名接龙",
            activityLogoUrl: "/ss/app/image/plus/publish_icon04.png",
            activityDesc: "报名活动统计"
        }, {
            activityName: "互动接龙",
            activityLogoUrl: "/ss/app/image/plus/publish_icon05.png",
            activityDesc: "话题观点交流"
        }, {
            activityName: "拼团接龙",
            activityLogoUrl: "/ss/app/image/plus/publish_icon02.png",
            activityDesc: "快速拉新裂变"
        }, {
            activityName: "集市接龙",
            activityLogoUrl: "/ss/app/image/plus/publish_icon06.png",
            activityDesc: "开展线上集市"
        }, {
            activityName: "阅读接龙",
            activityLogoUrl: "/ss/app/image/plus/publish_icon03.png",
            activityDesc: "发布文章和通知"
        }, {
            activityName: "评选接龙",
            activityLogoUrl: "/ss/app/image/plus/publish_icon07.png",
            activityDesc: "投票评选"
        } ];
        var N = function(e) {
            function t(t, i, a, o, r, s, n, c, d, h, u, l, p, m) {
                var g = e.call(this) || this;
                return g.utils = t, g.apiService = i, g.routeService = a, g.commonService = o, g.posterService = r, 
                g.userCardInfoService = s, g.monoCommonService = n, g.chatUtilService = c, g.imService = d, 
                g.urlService = h, g.errorService = u, g.migrateService = l, g.homepageService = p, 
                g.commonPosterService = m, g.isShowVoucherList = !1, g.isShowSeqModal = !1, g.isShowUserHomePage = !1, 
                g;
            }
            a.__extends(t, e);
            var i = t.prototype;
            return i.onShareSeqMessage = function(e) {
                var t = e.target.dataset.seqItem, i = t.actId, a = t.activityType, o = c.SEQ_TYPE_DETAIL_PATH[a] + "?actId=" + i + "&groupId=" + this.data.personalGroupId + "&inviteUid=" + this.data.uid, r = this.data.userName + "邀请" + (10 === a ? "你开团" : "您参与接龙") + "~";
                return 170 === a ? r = t.nickName + "社群分享给你" + (t.feedDTO.totalPicCount || 1) + "张相片" : 180 === a ? r = t.nickName + "社群分享给你1个视频" : 190 === a && (r = t.nickName + "社群刚刚发布了一篇文章"), 
                {
                    title: r,
                    path: o,
                    imageUrl: h.config.resHost + "/" + t.shareUrl
                };
            }, i.initModalPriorityManage = function() {
                var e = this;
                this.modalPriorityManage = new x.ModalPriorityManage(G.customerHomePagePrioritySort), 
                this.modalPriorityManage.priorityManageObs.pipe(o.takeUntil(this.unloadObservable)).subscribe(function(t) {
                    var i = t.oldKey, a = t.newKey;
                    i && e.use().set(i, !1), a && e.use().set(a, !0);
                });
            }, i.handleEditNickname = function() {
                this.hideNicknameTips(), this.routeService.goProfileEdit({
                    data: {
                        groupId: this.data.personalGroupId,
                        groupType: 30
                    }
                });
            }, i.handleTapGoToMyPublishPage = function(e) {
                var t = this.data.personalGroupId;
                this.routeService.goHomeHomepageMyPublish({
                    data: {
                        groupId: t
                    }
                });
            }, i.getTogetherBuyInviteMessage = function(e) {
                var t = e.target.dataset.shareData.shareInfo, i = t.actId, a = (t.price, t.productName, 
                t.orderGroupId), o = t.actGoodsId, r = this.data.userName || this.utils.getGlobalData("person_nick_name", !0), s = r.length > 15 ? r.slice(0, 15) + "..." : r, n = this.data.uid, c = this.urlService.setParams("/pro/pages/seq-detail/join-together-buy/join-together-buy", {
                    actId: i,
                    inviteUid: n,
                    orderGroupId: a
                }), d = new Date().getTime();
                return {
                    title: "[" + s + "@我]一起拼",
                    imageUrl: this.utils.apiImage(this.urlService.setParams("/share-image/api/draw/activity/invite_join_group_v2", {
                        actId: i,
                        timeStamp: d,
                        actGoodsId: o
                    })),
                    path: c
                };
            }, i.handleShowShareHomeModal = function() {
                if (!this.data.hasAuthorized) return this.goAuthorization();
                this.toggleBoolean("isShowShareHomeModal", !0);
            }, i.handleHideShareHomeModal = function() {}, i.handleShowHomeSharePosterModal = function() {
                var e = this, t = this.utils.imgUrl("/ss/app/image/plus/poster06.jpg", !0);
                p.rxwx.getImageInfo({
                    src: t
                }).subscribe(function(t) {
                    var i, a = t.path, o = ((i = {
                        sharePosterUrl: a
                    })["authMode.options.filePath"] = a, i);
                    wx.showShareImageMenu || Object.assign(o, {
                        isShowShareHomeModal: !1,
                        isShowPosterModal: !0
                    }), e.setData(o), e.commonPosterService.sharePictureByWxShareImageMenu({
                        path: a,
                        successFn: function() {
                            return e.setData({
                                isShowShareHomeModal: !1
                            });
                        }
                    });
                });
            }, i.handleGenerateSharePoster = function(e) {
                var t = this, i = e.detail.editItem, a = this.posterService.getFirstImageUrl(i);
                a ? p.rxwx.getImageInfo({
                    src: a
                }).subscribe(function(e) {
                    var a = e.height / e.width, o = t.posterService.getPosterConfig(i, a);
                    t.drawPoster(o);
                }) : this.drawPoster(this.posterService.getPosterConfig(i));
            }, i.handleTapDataStatistics = function() {
                this.routeService.goHomeCustomerProfileTotalDataStatistics();
            }, i.handleHideShareActPopup = function() {
                this.setRedDotGuId(this.data.personalGroupId, "100");
            }, i.handleHideShareActTips = function() {
                this.setRedDotGuId(this.data.personalGroupId, "101");
            }, i.handleTapExpandSeqTypeList = function() {
                this.setData({
                    isSeqTypeListExpand: !this.data.isSeqTypeListExpand
                });
            }, i.handleTapPublishSeq = function(e) {
                if (this.data.hasAuthorized) {
                    var t = e.currentTarget.dataset.item, i = t.activityName, o = t.activityType, r = this.data.headerInfo ? {
                        ghName: encodeURIComponent(this.data.headerInfo.name),
                        logoUrl: this.data.headerInfo.pic
                    } : null;
                    if ("复制接龙" !== i) o && (-10 !== o ? this.routeService.goSeqPublishPublishStartGroup({
                        type: "navigateTo",
                        data: a.__assign({
                            seqType: o,
                            groupId: this.data.personalGroupId,
                            groupType: 30
                        }, r)
                    }) : this.routeService.goSeqPublishPublishStartGroup({
                        data: a.__assign(a.__assign({
                            seqType: -10,
                            groupType: 30
                        }, r), {
                            groupCreatorUid: this.utils.getUid()
                        })
                    })); else {
                        var s = a.__assign({
                            groupId: this.data.personalGroupId,
                            groupType: 30
                        }, r);
                        this.routeService.goSeqPublishCopySeq({
                            data: s
                        });
                    }
                } else this.goAuthorization();
            }, i.handleTapMyPublish = function() {
                this.navToMyPublish();
            }, i.navToMyPublish = function() {
                var e = this.data, t = e.hasAuthorized, i = e.personalGroupId;
                t ? i && this.routeService.goHomeHomepageMyPublish({
                    data: {
                        groupId: i
                    }
                }) : this.goAuthorization();
            }, i.handleShowSeqModal = function() {
                this.setData({
                    isShowSeqModal: !0
                });
            }, i.handleTapHideSeqModal = function() {
                this.setData({
                    isShowSeqModal: !1
                });
            }, i.handleTapLogin = function() {
                this.data.hasAuthorized || this.goAuthorization();
            }, i.handleTapVoucher = function() {
                this.goToCustomerOrderManagePage();
            }, i.handleTapEventPlanning = function() {
                this.commonService.goToDetail({
                    seqType: 200,
                    actId: 0x7d67db67b7c24
                });
            }, i.handleTapIceBreakerEvent = function() {
                this.routeService.goOperationDedicatedPagesIceBreaker();
            }, i.goToCustomerOrderManagePage = function() {
                this.data.hasAuthorized ? (this.routeService.goOrderManageCustomerOrderManage({
                    data: {
                        orderNo: this.data.orderNoFromNotification,
                        actIdForSearchVoucherSign: this.data.actIdForSearchVoucherSign
                    }
                }), this.setData({
                    actIdForSearchVoucherSign: null,
                    orderNoFromNotification: null
                })) : this.goAuthorization();
            }, i.goToJoinedCommunitiesPage = function() {
                this.data.hasAuthorized ? this.routeService.goHomeHomepageJoinedCommunities() : this.goAuthorization();
            }, i.handleCloseAuthorizationPopup = function() {}, i.getUserCardRedDots = function() {
                var e = this;
                this.userCardInfoService.getUserCardRedDot(function(t) {
                    e.setData({
                        userRedDotNum: t
                    });
                });
            }, i.checkHasAuthorized = function() {
                var e = !!this.utils.getUid(), t = !!this.utils.getToken(), i = this.utils.getAuthorized();
                return e && t && i;
            }, i.reportComeHome = function() {
                this.apiService.enterHomeV2UsingPOST(M.skipErrorOptions).subscribe();
            }, i.reportCustomerHomeLoadTime = function() {
                try {
                    1 === this.getLoadedCount() ? this.monitor.timeEnd("启动小程序到进入个人主页的时间") : this.monitor.dropTimeKey("启动小程序到进入个人主页的时间");
                } catch (e) {}
            }, i.reportCustomerWhitePageEnd = function() {
                this.monitor.timeEnd("个人主页静默登录白屏时间"), this.monitor.timeEnd("启动小程序进入首页加载首屏时间"), this.monitor.dropTimeKey("启动小程序进入主页加载首屏时间");
            }, i.dataStatisticsManager = function() {
                var e = this;
                this.apiService.isUserCanViewActUsingGET().subscribe(function(t) {
                    e.setData({
                        isDataStatisticsManager: t.data || !1
                    });
                });
            }, i.getShareActTipsPopup = function() {
                this.getRedDotGuId(this.data.personalGroupId, "100");
            }, i.getShareActTips = function() {
                this.getRedDotGuId(this.data.personalGroupId, "101");
            }, i.showPageModal = function() {
                var e, t, i = null === (e = this.loadParams) || void 0 === e ? void 0 : e.isShowMyVoucher, a = "true" === (null === (t = this.loadParams) || void 0 === t ? void 0 : t.isShowSeqPublish);
                i && (this.isShowVoucherList = !0), this.isShowVoucherList && this.goToCustomerOrderManagePage(), 
                a && this.handleShowSeqModal(), 2 === this.enterType && (this.showVoucherGuideTips(), 
                this.isShowCollectTips());
            }, i.getUserHomePage = function() {
                var e = this;
                this.isShowUserHomePage || this.homepageService.getAllManagerGhsObs().subscribe(function(t) {
                    void 0 === t && (t = []), e.isShowUserHomePage = !0;
                    var i = t.filter(function(e) {
                        return 30 !== e.ghType;
                    }), a = 0 === i.length, o = 1 === i.length;
                    if (a || o) {
                        var r = a ? e.data.personalGroupId : i[0].ghId;
                        e.goChatPage(a, r);
                    } else e.setData({
                        isShowSelectHomeModal: !0,
                        userHomeList: i
                    });
                });
            }, i.goChatPage = function(e, t) {
                var i = this;
                if (!t) throw new Error("未获取到当前用户的groupId，无法获取对应imAccountId");
                this.grayService.canIUseFeature("2158").pipe(o.switchMap(function(e) {
                    return e ? i.apiService.getBindingStaffIMV2UsingPOST({
                        ghId: t
                    }, c.skipMarkOption) : i.apiService.getBindingStaffIMUsingPOST({
                        ghId: t
                    }, c.skipMarkOption);
                })).subscribe(function(a) {
                    var o, r = null === (o = a.data) || void 0 === o ? void 0 : o.imAccountId;
                    if (!r) throw new Error("未获取到对话ID");
                    var s = {
                        toId: r,
                        isFromMASCode: !0,
                        toUserType: 2
                    };
                    s.fromUserType = e ? 0 : 1, e || (s.fromId = t), i.commonService.goCustomerServiceOrChatPage({
                        data: s
                    });
                });
            }, i.judgeSendCustomerUpgradeInfo = function() {
                var e = wx.getStorageSync("guideUpdateDate"), t = new Date().getTime(), i = e && t - Number(e) > 6048e5;
                e && !i || this.sendUpgradeGuideTips(t);
            }, i.goAuthorization = function() {}, i.sendUpgradeGuideTips = function(e) {
                this.apiService.upgradeDispatchUsingPOST().subscribe(function(t) {
                    t.data && wx.setStorage({
                        key: "guideUpdateDate",
                        data: String(e)
                    });
                });
            }, i.isShowCollectTips = function() {
                var e = this;
                this.getRedDotObs("37").pipe(o.filter(function(e) {
                    return e;
                })).subscribe(function() {
                    var t;
                    e.setData(((t = {})[c.RedDotName[37]] = !0, t), function() {
                        setTimeout(function() {
                            e.setRedDot("37");
                        }, 5e3);
                    });
                });
            }, i.showVoucherGuideTips = function() {
                var e = this;
                this.setData({
                    isShowVoucherGuideTips: !0
                }, function() {
                    r.timer(5e3).subscribe(function() {
                        e.setData({
                            isShowVoucherGuideTips: !1
                        });
                    });
                });
            }, i.drawPoster = function(e) {
                this.setData({
                    posterConfig: e,
                    isShowPosterModal: !0
                }), this.createPoster(!0);
            }, a.__decorate([ T.Toggle("isShowShareHomeModal", !1), a.__metadata("design:type", Function), a.__metadata("design:paramtypes", []), a.__metadata("design:returntype", void 0) ], t.prototype, "handleHideShareHomeModal", null), 
            a.__decorate([ T.Toggle("isShowAuthorizationPopup", !1), a.__metadata("design:type", Function), a.__metadata("design:paramtypes", []), a.__metadata("design:returntype", void 0) ], t.prototype, "handleCloseAuthorizationPopup", null), 
            a.__decorate([ T.Toggle("isShowAuthorizationPopup", !0), a.__metadata("design:type", Function), a.__metadata("design:paramtypes", []), a.__metadata("design:returntype", void 0) ], t.prototype, "goAuthorization", null), 
            t = a.__decorate([ b.MixinClass(), a.__metadata("design:paramtypes", [ s.UtilService, n.DefaultService, f.RouteService, d.CommonService, l.HomepagePosterService, w.UserCardInfoService, m.MonoCommonService, S.ChatUtilService, D.ImService, I.UrlService, P.ErrorService, C.BackendMigrateService, U.HomepageService, R.CommonPosterService ]) ], t);
        }(_.miniMixin(u.GenerateSharePoster, g.SeqPosterMixin, v.HomePageMixin, H.CustomerRedDotMixin, y.NewRedDotMixin, A.CustomerWxShowModalManageMixin));
        t.CustomerCommon = N;
    },
    795: function(e, t, i) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.CustomerRedDotMixin = void 0;
        var a = i(0), o = i(21), r = i(1), s = i(9), n = i(30), c = function(e) {
            function t(t) {
                var i = e.call(this) || this;
                return i.monoRedDotService = t, i;
            }
            a.__extends(t, e);
            var i = t.prototype;
            return i.getAllRedDotTips = function() {
                this.getNicknameTips();
            }, i.handleHideNicknameTips = function() {
                this.hideNicknameTips();
            }, i.hideNicknameTips = function() {
                this.data.isShowNicknameTips && this.markReadRedDotByUid([ {
                    code: 1150
                } ]);
            }, i.getNicknameTips = function() {
                this.data.isDefaultNickname && this.getRedDotAndSetData([ {
                    code: 1150
                } ]);
            }, t = a.__decorate([ r.MixinClass(), a.__metadata("design:paramtypes", [ n.MonoRedDotService ]) ], t);
        }(s.miniMixin(o.NewRedDotMixin));
        t.CustomerRedDotMixin = c;
    },
    796: function(e, t, i) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.CustomerWxShowModalManageMixin = void 0;
        var a = i(0), o = i(92), r = i(10), s = i(1), n = i(9), c = i(8), d = i(5), h = i(797), u = function(e) {
            function t(t, i, a) {
                var o = e.call(this) || this;
                return o.apiService = t, o.routeService = i, o.actUidBlockedService = a, o.isShowModalsChecked = !1, 
                o;
            }
            a.__extends(t, e);
            var i = t.prototype;
            return i.checkCustomerPageAllWxShowModals = function() {
                var e = this;
                this.isShowModalsChecked || (this.isShowModalsChecked = !0, this.showAuthModalObs().subscribe(function(t) {
                    var i = !t;
                    e.initCustomerHomeSubjectAuthStatus(i);
                }));
            }, i.showAuthModalObs = function() {
                var e = this.data.personalGroupId;
                return this.actUidBlockedService.checkBlockLevelAndShowAuthRealNameAndAipModalObs(e, 30, !0);
            }, t = a.__decorate([ s.MixinClass(), a.__metadata("design:paramtypes", [ d.DefaultService, r.RouteService, o.ActUidBlockedService ]) ], t);
        }(n.miniMixin(h.CustomerHomeSubjectAuthMixin, c.SuperPage));
        t.CustomerWxShowModalManageMixin = u;
    },
    797: function(e, t, i) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.CustomerHomeSubjectAuthMixin = void 0;
        var a = i(0), o = i(179), r = i(10), s = i(1), n = i(8), c = i(13), d = i(30), h = i(5), u = i(18), l = function(e) {
            function t(t, i, a, o, r) {
                var s = e.call(this) || this;
                return s.apiService = t, s.routeService = i, s.timeService = a, s.monoRedDotService = o, 
                s.homepageSubjectAuthService = r, s.isHomeSubjectAuthedRequested = !1, s;
            }
            return a.__extends(t, e), t.prototype.initCustomerHomeSubjectAuthStatus = function(e) {
                var t = this, i = this.data.personalGroupId;
                this.isHomeSubjectAuthedRequested || this.homepageSubjectAuthService.getHomeSubjectAuthInfo(i, c.skipErrorOptions).subscribe(function(a) {
                    var r = a.auditStatus, s = a.auditTime, n = a.refuseReason;
                    t.isHomeSubjectAuthedRequested = !0;
                    var c = r === o.HomeSubjectAuthStatus.PASSED;
                    t.setData({
                        isHomeSubjectAuthed: c
                    }), e && (r === o.HomeSubjectAuthStatus.REFUSED ? t.homepageSubjectAuthService.checkIsShowRefusedModal(i, 30, s ? +t.timeService.newDate(s) : void 0, n) : r || t.homepageSubjectAuthService.checkIsShowSubjectAuthModal(i, 30));
                }, function() {
                    t.setData({
                        isHomeSubjectAuthed: !1
                    });
                });
            }, t = a.__decorate([ s.MixinClass(), a.__metadata("design:paramtypes", [ h.DefaultService, r.RouteService, u.TimeService, d.MonoRedDotService, o.HomepageSubjectAuthService ]) ], t);
        }(n.SuperPage);
        t.CustomerHomeSubjectAuthMixin = l;
    },
    798: function(e, t, i) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.AccessData = void 0;
        var a = i(0), o = i(8), r = i(7), s = i(3), n = function(e) {
            function t(t, i) {
                var a = e.call(this) || this;
                return a.homepageService = t, a.apiService = i, a.currentTipsArr = [], a.isStop = !1, 
                a;
            }
            a.__extends(t, e);
            var i = t.prototype;
            return i.initVisitData = function() {
                this.isStop = !1, this.getData(), this.randomTimer(1200, 3e3, this.getData);
            }, i.stopRandomInterval = function() {
                this.isStop = !0;
            }, i.initShowActDynamicText = function() {
                var e = this;
                this.showActDynamicTextInterval = r.interval(3e3).subscribe(function() {
                    if (e.currentTipsArr.length) {
                        var t = Math.floor(Math.random() * e.currentTipsArr.length), i = e.currentTipsArr.splice(t, 1)[0];
                        e.homepageService.broadcastActDynamicList(e.currentTipsArr);
                        var a = e.data.actDynamicList || [];
                        a.push(i.tipContent), e.setData({
                            actDynamicList: a
                        }), e.homepageService.showingDynamicList = a;
                    }
                });
            }, i.abandonShowedItem = function() {
                this.data.actDynamicList.shift(), this.setData({
                    actDynamicList: this.data.actDynamicList,
                    currentShowIndex: 0
                }), this.homepageService.showingDynamicList = this.data.actDynamicList;
            }, i.clearActDynamicTextInterval = function() {
                this.showActDynamicTextInterval && (this.showActDynamicTextInterval.unsubscribe(), 
                this.showActDynamicTextInterval = void 0);
            }, i.randomTimer = function(e, t, i) {
                var a = this;
                if (!this.isStop) {
                    var o = Math.random() * (t - e) + e;
                    setTimeout(function() {
                        i && i(), a.randomTimer(e, t, i);
                    }, o);
                }
            }, i.getData = function() {
                var e = this;
                this.isStop || (this.homepageService.actDynamicListObs.pipe(s.takeUntil(this.unloadObservable)).subscribe(function(t) {
                    e.currentTipsArr = t;
                }), this.homepageService.fetchActDynamicData().subscribe(function(t) {
                    e.setData({
                        actDataObj: t.data
                    });
                }, function() {
                    e.stopRandomInterval();
                }));
            }, t;
        }(o.SuperPage);
        t.AccessData = n;
    },
    799: function(e, t, i) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.Nav = void 0;
        var a = i(0), o = i(8), r = i(5), s = i(15), n = i(10), c = i(33), d = i(3), h = i(27), u = i(13), l = function(e) {
            function t(t, i, a, o, r) {
                var s = e.call(this) || this;
                return s.apiService = t, s.commonService = i, s.routeService = a, s.monitor = o, 
                s.migrateService = r, s;
            }
            a.__extends(t, e);
            var i = t.prototype;
            return i.isNavToOtherPage = function(e) {
                return this.hidePageWrapperNavbar(), this.goToLastHome(e);
            }, i.refreshAfterLogin = function() {}, i.goToLastHome = function(e) {
                var t = this;
                return this.timeStart("从后端获取上一个逗留的主体的信息", 2006), this.apiService.getLastInfoV2UsingGET(u.skipErrorOptions).pipe(d.map(function(e) {
                    return e.data || {};
                }), d.map(function(i) {
                    return t.dealWithLastGoHomeData(i, e);
                }));
            }, i.dealWithLastGoHomeData = function(e, t) {
                return this.timeEnd("从后端获取上一个逗留的主体的信息"), t && t.from ? (this.specialRoute(t.from), 
                this.monitor.dropTimeKey("启动小程序进入主页加载首屏时间"), !1) : e ? 5 === e.indexControl ? e.roleType || 100 === e.lastEnterGhType ? (this.commonService.goToHome(e.lastEnterGhId, e.lastEnterGhType, "redirectTo", {
                    isHomeBackEnd: !0
                }), 30 !== e.lastEnterGhType) : (this.refreshAfterLogin(), !1) : (e.indexControl, 
                this.refreshAfterLogin(), !1) : (this.setPageStatus("FAIL", 404), this.setFailMessage("跳转信息获取失败"), 
                this.monitor.dropTimeKey("启动小程序进入主页加载首屏时间"), !1);
            }, i.specialRoute = function(e) {
                "customerProfile" === e && this.refreshAfterLogin();
            }, t = a.__decorate([ c.PagePerfTrack("NAV"), a.__metadata("design:paramtypes", [ r.DefaultService, s.CommonService, n.RouteService, c.PerformanceMonitorService, h.BackendMigrateService ]) ], t);
        }(o.SuperPage);
        t.Nav = l;
    },
    800: function(e, t, i) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.CustomerHomepageRouteMixin = void 0;
        var a = i(0), o = i(1), r = i(25), s = i(10), n = i(96), c = i(35), d = i(60), h = i(26), u = i(3), l = i(7), p = function(e) {
            function t(t, i, a, o) {
                var r = e.call(this) || this;
                return r.apiService = t, r.routeService = i, r.imService = a, r.homepageService = o, 
                r.isShowSelectHomeModal = !1, r.processedImHotGood = !1, r;
            }
            a.__extends(t, e);
            var i = t.prototype;
            return i.processToOfficialProxyMode = function(e) {
                var t = this;
                this.isShowSelectHomeModal || this.apiService.getAllGroupIdentitiesV2UsingGET(e).subscribe(function(i) {
                    t.isShowSelectHomeModal = !0;
                    var a = (i.data || []).filter(function(e) {
                        return e.related;
                    });
                    a.length ? 1 !== a.length ? t.setData({
                        userHomeList: a,
                        isShowSelectHomeModal: !0
                    }) : t.goToOfficialProxyChatPage(e, a[0].ghId) : wx.showModal({
                        title: "温馨提示",
                        content: "你与该团长暂未搭建关系，无法进入会话",
                        showCancel: !1
                    });
                });
            }, i.goToOfficialProxyChatPage = function(e, t) {
                this.routeService.goCustomerServiceChatPage({
                    data: {
                        chatUserType: "5",
                        fromId: t,
                        toId: "s-" + e
                    }
                }), this.setData({
                    isShowSelectHomeModal: !1
                });
            }, i.processGoToImFindHotGoodsChatPage = function() {
                var e = this;
                this.processedImHotGood || (this.processedImHotGood = !0, this.homepageService.getAllManagerLeaderGhsObs().pipe(u.map(function(e) {
                    return e.filter(function(e) {
                        return 105 !== e.ghType;
                    });
                }), u.switchMap(function(t) {
                    return t.length ? e.apiService.queryHaveOfficialEntranceGhoMemajorUsingPOST(t.map(function(e) {
                        return e.ghId;
                    }), h.OFFICIAL_ENTRANCE_API_OPTIONS).pipe(u.map(function(e) {
                        var i = e.data, a = void 0 === i ? {} : i;
                        return t.filter(function(e) {
                            var t = e.ghId;
                            return a[t];
                        });
                    })) : l.of(t);
                })).subscribe(function(t) {
                    t.length ? 1 !== t.length ? e.setData({
                        userHomeList: t,
                        isShowSelectHomeModal: !0
                    }) : e.goToImFindHotGoodsChatPage(t[0].ghId) : wx.showModal({
                        title: "温馨提示",
                        content: "暂时无法提供该功能",
                        showCancel: !1
                    });
                }));
            }, i.goToImFindHotGoodsChatPage = function(e) {
                this.imService.goCustomServiceChatPage({
                    groupId: e,
                    extraParam: {
                        initSendMsg: "我要找货",
                        actionsType: c.InitialActionsType.FIND_HOT_GOODS
                    }
                });
            }, t = a.__decorate([ o.MixinClass(), a.__metadata("design:paramtypes", [ r.DefaultService, s.RouteService, d.ImService, h.HomepageService ]) ], t);
        }(n.SuperSetData);
        t.CustomerHomepageRouteMixin = p;
    },
    801: function(e, t, i) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.CustomerHomeBannerMixin = t.SEARCH_REGISTER_WITH_TIME_BIZ_CODE = void 0;
        var a = i(0), o = i(1), r = i(8), s = i(13), n = i(5), c = i(7), d = i(137), h = i(3), u = i(18), l = i(17), p = i(21), m = i(9), g = i(6), S = i(117);
        t.SEARCH_REGISTER_WITH_TIME_BIZ_CODE = "SearchRegisterWithTime";
        var v = function(e) {
            function t(t, i, a, o, r, s) {
                var n = e.call(this) || this;
                return n.apiService = t, n.timeService = i, n.grayService = a, n.utils = o, n.wxCloudRedDotMigrateService = r, 
                n.homeNewWxGuideService = s, n.countDownTime = 0, n;
            }
            a.__extends(t, e);
            var i = t.prototype;
            return i.initNewUserGuideProcess = function() {
                var e = this;
                this.grayService.canIUseFeatureByMultiply([ "2448", "2408" ]).subscribe(function(t) {
                    var i = a.__read(t, 2), o = i[0], r = i[1];
                    e.setData({
                        isSearchRegisterUserToMcnVision: o
                    }), o ? e.initSearchRegisterUserToMcnVisionGuideBanner() : r && e.initGuideBannerAndNewUserGiftModal();
                });
            }, i.judgeHideBanner = function() {
                var e = this;
                this.data.isSearchRegisterUserToMcnVision && this.data.isShowGuideBanner && c.forkJoin([ this.apiService.judgeIndependentUserV1UsingPOST(s.skipErrorOptions), this.getRedDotTimeCompareOneDaysObs({
                    code: 1173,
                    type: 10,
                    redDotKey: this.data.personalGroupId
                }) ]).subscribe(function(t) {
                    var i = a.__read(t, 2), o = i[0], r = i[1];
                    o.data && !r ? e.countDownTime > 0 && e.countTime() : e.setData({
                        isShowGuideBanner: !1,
                        isSeqMenuExpanded: r || e.data.isSeqMenuExpanded
                    });
                });
            }, i.handleTapDynamicBanner = function() {
                this.data.isSearchRegisterUserToMcnVision && !this.data.isClickSearchRegisterBanner && (this.setData({
                    isClickSearchRegisterBanner: !0
                }), this.markReadRedDotByUid([ {
                    code: 1173
                } ]));
            }, i.clearBannerTimer = function() {
                this.timer && (clearInterval(this.timer), this.timer = null);
            }, i.handleTapWelFareOfficer = function() {
                var e = this.homeNewWxGuideService.getWxGuideQrCode(70);
                this.processShowImgObs(e), this.modalPriorityManage.remove("isShowSearchRegisterNewUserShuntModal");
            }, i.handleTapLittleAssistant = function() {
                var e = this.homeNewWxGuideService.getWxGuideQrCode(80);
                this.processShowImgObs(e), this.modalPriorityManage.remove("isShowSearchRegisterNewUserShuntModal");
            }, i.handleTapActivityPoster = function() {
                wx.previewImage({
                    urls: [ this.utils.imgUrl("ss/app/image/plus/poster07.png", !0) ]
                }), this.modalPriorityManage.remove("isShowSearchRegisterNewUserShuntModal");
            }, i.handleCloseSearchRegisterNewUserShuntModal = function() {
                this.modalPriorityManage.remove("isShowSearchRegisterNewUserShuntModal");
            }, i.initGuideBannerAndNewUserGiftModal = function() {
                var e = this;
                this.apiService.judgeIndependentUserUsingPOST(s.skipErrorOptions).pipe(h.map(function(e) {
                    return e.data;
                })).subscribe(function(t) {
                    t && (e.getRedDotAndSetData([ {
                        code: 1160
                    } ], function() {
                        e.data.isShowQjlNewUserGuideModal && (e.customReport({
                            functionName: "ShowNewUserGiftModal"
                        }), e.modalPriorityManage.add("isShowNewUserGiftModal"));
                    }), e.setData({
                        isShowGuideBanner: !0
                    }, function() {
                        e.customReport({
                            functionName: "ShowGuideBanner"
                        });
                    }));
                });
            }, i.initSearchRegisterUserToMcnVisionGuideBanner = function() {
                var e = this;
                c.forkJoin([ this.apiService.judgeUserFreeEntryUsingPOST(s.skipErrorOptions), this.apiService.judgeIndependentUserV1UsingPOST(s.skipErrorOptions), this.getRedDotTimeCompareOneDaysObs({
                    code: 1173,
                    type: 10,
                    redDotKey: this.data.personalGroupId
                }) ]).subscribe(function(t) {
                    var i = a.__read(t, 3), o = i[0], r = i[1], s = i[2];
                    if (o.data && r.data && !s) {
                        var n = e.utils.getGlobalData("isOnline", !0);
                        e.countTime(), e.setData({
                            isShowGuideBanner: !0,
                            isSeqMenuExpanded: !1,
                            firstUseSeqActId: n ? 0x71cefa08104f7 : 0x7235da8616a42
                        });
                        var c = new Date().getTime() - e.data.createTime;
                        e.customReport({
                            functionName: "ShowGuideBanner",
                            methodParams: {
                                isCountDownTimeBanner: c <= 864e5
                            }
                        }), e.getRedDotAndSetData([ {
                            code: 1160
                        } ], function() {
                            e.data.isShowQjlNewUserGuideModal && (e.customReport({
                                functionName: "showSearchRegisterNewUserShuntModal"
                            }), e.modalPriorityManage.add("isShowSearchRegisterNewUserShuntModal"), e.markReadRedDotByUid([ {
                                code: 1160
                            } ]));
                        });
                    } else e.setData({
                        isShowGuideBanner: !1
                    });
                });
            }, i.countTime = function() {
                var e = this, t = this.data.createTime, i = void 0 === t ? 0 : t, a = new Date().getTime() - i;
                a >= 864e5 || (this.countDownTime = 864e5 - a, this.timer = setInterval(function() {
                    var t = new Date().getTime(), i = e.timeService.restTimeFormat(e.countDownTime + t, !0, "HH:mm:ss");
                    e.setData({
                        bannerExtraParam: {
                            countDownTime: i.timeStr
                        }
                    }), e.countDownTime -= 1e3, e.countDownTime <= 0 && (e.clearBannerTimer(), e.setData({
                        bannerExtraParam: {
                            countDownTime: ""
                        }
                    }), e.customReport({
                        functionName: "ShowGuideBanner",
                        methodParams: {
                            isCountDownTimeBanner: !1
                        }
                    }));
                }, 1e3));
            }, i.getRedDotTimeCompareOneDaysObs = function(e) {
                return this.wxCloudRedDotMigrateService.getRedDotList([ e ]).pipe(h.map(function(e) {
                    var t = (null == e ? void 0 : e[0]) || {}, i = t.lastReadTime;
                    return !!t.invokerNumber && new Date().getTime() - Number(i) >= 864e5;
                }));
            }, i.processShowImgObs = function(e) {
                e.subscribe(function(e) {
                    e ? wx.previewImage({
                        urls: [ e.qrCode ]
                    }) : wx.showToast({
                        title: "图片加载失败",
                        icon: "none"
                    });
                }, function() {
                    wx.showToast({
                        title: "图片加载失败",
                        icon: "none"
                    });
                });
            }, t = a.__decorate([ o.MixinClass(), a.__metadata("design:paramtypes", [ n.DefaultService, u.TimeService, l.GrayFeatureService, g.UtilService, d.WxCloudRedDotMigrateService, S.HomeNewWxGuideService ]) ], t);
        }(m.miniMixin(r.SuperPage, p.NewRedDotMixin));
        t.CustomerHomeBannerMixin = v;
    }
}, [ [ 791, 0, 2, 1 ] ] ]));