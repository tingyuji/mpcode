var e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
};

require("./../../../../../runtime"), require("./../../../../../mono"), require("./../../../../../common"), 
function(e, t) {
    for (var o in t) e[o] = t[o];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 566 ], {
    2: function(t, o) {
        var i;
        i = function() {
            return this;
        }();
        try {
            i = i || new Function("return this")();
        } catch (t) {
            "object" == ("undefined" == typeof window ? "undefined" : e(window)) && (i = window);
        }
        t.exports = i;
    },
    763: function(e, t, o) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var i = o(0), n = o(4), r = o(1), a = o(5), s = o(18), u = o(10), d = o(21), c = o(9), p = o(6), l = o(11), h = o(17), m = o(439), y = {
            disableFetch: Boolean,
            userRedDotNum: Object,
            logoUrl: String,
            name: String,
            isShowReddot: Boolean,
            hasAuthorized: {
                type: Boolean,
                value: !0
            },
            personalGroupId: String,
            useSimpleStyle: {
                type: Boolean,
                value: !1
            },
            showHomeSwitch: {
                type: Boolean,
                value: !1
            },
            groupType: String
        };
        !function(e) {
            function t(t, o, i, n, r, a) {
                var s = e.call(this) || this;
                return s.apiService = t, s.timeService = o, s.routeService = i, s.utils = n, s.monoUtil = r, 
                s.grayService = a, s.properties = y, s.data = {
                    ISystemMsgBoxType: m.ISystemMsgBoxType
                }, s.computed = {
                    isShowAvatarRedDot: function(e) {
                        return e.isShowCustomerHomepageMyTips;
                    }
                }, s;
            }
            i.__extends(t, e);
            var o = t.prototype;
            o.attached = function() {
                e.prototype.attached.call(this), this.data.disableFetch || (this.getRedDotByGroupIdAndSetData([ {
                    code: 1129,
                    groupId: "0"
                } ]), this.getRedDotAndSetData([ {
                    code: 1133
                } ]));
            }, o.handleTapMyProfile = function() {
                this.data.isNeedShowHomeSubjectAuthTips && this.markReadRedDotByGroupId([ {
                    code: 1129,
                    groupId: "0"
                } ]), this.data.isShowCustomerHomepageMyTips && this.markReadRedDotByUid([ {
                    code: 1133
                } ]), this.data.hasAuthorized ? this.triggerEvent("tapProfile") : this.triggerEvent("login");
            }, o.handleTapJoinNumIcon = function(e) {
                var t, o = e.currentTarget.dataset.type;
                this.setData(((t = {})["userRedDotNum." + o] = 0, t)), this.triggerEvent("tapJoinNumIcon", o);
            }, o.handleTapPublish = function() {
                this.triggerEvent("publish");
            }, o.handleLogin = function() {
                this.triggerEvent("login");
            }, o.handleUpdatePublishSeqLotteryGuide = function() {
                this.triggerEvent("tapGuide");
            }, o.handleCloseHomeSubjectAuthTips = function() {
                this.markReadRedDotByGroupId([ {
                    code: 1129,
                    groupId: "0"
                } ]);
            }, o.refreshSystemMsgBoxList = function() {
                var e, t = this.selectComponent("#system-msg-box-id");
                null === (e = null == t ? void 0 : t.initSystemMsgBoxList) || void 0 === e || e.call(t);
            }, t = i.__decorate([ r.wxComponent(), i.__metadata("design:paramtypes", [ a.DefaultService, s.TimeService, u.RouteService, p.UtilService, l.MonoUtilService, h.GrayFeatureService ]) ], t);
        }(c.miniMixin(d.NewRedDotMixin, n.SuperComponent));
    }
}, [ [ 763, 0, 2, 1 ] ] ]));