var e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
};

require("./../../../../../runtime"), require("./../../../../../mono"), require("./../../../../../common"), 
function(e, t) {
    for (var r in t) e[r] = t[r];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 563 ], {
    2: function(t, r) {
        var i;
        i = function() {
            return this;
        }();
        try {
            i = i || new Function("return this")();
        } catch (t) {
            "object" == ("undefined" == typeof window ? "undefined" : e(window)) && (i = window);
        }
        t.exports = i;
    },
    769: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var i = r(0), a = r(4), o = r(1), s = r(10), n = r(40), h = r(15), p = r(88), c = {
            groupId: String,
            options: {
                type: null,
                value: {
                    hasSlot: !1
                }
            },
            isShowShareActTipsPopup: {
                type: Boolean,
                observer: function(e, t) {
                    e && this.setData({
                        isShowShareActTips: !1
                    });
                }
            },
            isShowShareActTips: {
                type: Boolean,
                value: !1
            },
            seqItem: Object,
            isUseSharePreview: Boolean,
            startGroupShareSkipAuth: Boolean,
            isFiveStarsAfterSale: Boolean
        };
        !function(e) {
            function t(t, r, i, a) {
                var o = e.call(this) || this;
                return o.routeService = t, o.seqService = r, o.commonService = i, o.appsTransferJumpService = a, 
                o.properties = c, o.data = {}, o;
            }
            i.__extends(t, e);
            var r = t.prototype;
            r.ready = function() {
                e.prototype.ready.call(this);
            }, r.catchForbid = function() {}, r.handleTapSharePoster = function() {
                this.hideShareModal(), this.triggerEvent("poster", {
                    seqItem: this.data.seqItem,
                    isFiveStarsAfterSale: this.data.isFiveStarsAfterSale
                });
            }, r.handleTapShareActPopupClose = function() {
                this.triggerEvent("hideShareTipsPopup");
            }, r.handleTapShareActClose = function() {
                this.triggerEvent("hideShareTips");
            }, r.handleShowShareModal = function() {
                var e = this;
                if (this.data.isUseSharePreview) {
                    var t = this.data, r = t.seqItem, i = t.startGroupShareSkipAuth, a = r.ghId;
                    10 === r.activityType && i ? this.commonService.getShareLinkToken(a, 3).subscribe(function(t) {
                        r.inviterToken = t, e.triggerEvent("poster", {
                            seqItem: r,
                            isFiveStarsAfterSale: e.data.isFiveStarsAfterSale
                        });
                    }) : this.triggerEvent("poster", {
                        seqItem: r,
                        isFiveStarsAfterSale: this.data.isFiveStarsAfterSale
                    });
                } else this.setData({
                    isShowShareModal: !0
                });
            }, r.handleHideShareModal = function() {
                this.hideShareModal();
            }, r.handleTapInsertOffical = function() {
                var e = this;
                this.seqService.setSeqItem(this.data.seqItem), this.setData({
                    isShowShareModal: !1
                });
                var t = this.data.seqItem.shareObj;
                this.appsTransferJumpService.getJumpAppidHasDefaultByActCreator(this.data.seqItem.actId).subscribe(function(r) {
                    e.routeService.goProfileEmbedPublicAccount({
                        data: {
                            appId: r,
                            groupId: e.data.groupId,
                            posterType: 2,
                            shareObj: t && JSON.stringify(t)
                        }
                    });
                });
            }, r.hideShareModal = function() {
                this.setData({
                    isShowShareModal: !1
                });
            }, t = i.__decorate([ o.wxComponent(), i.__metadata("design:paramtypes", [ s.RouteService, n.SequenceService, h.CommonService, p.AppsTransferJumpService ]) ], t);
        }(a.SuperComponent);
    }
}, [ [ 769, 0, 2, 1 ] ] ]));