var e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
};

require("./../../../../../runtime"), require("./../../../../../mono"), require("./../../../../../common"), 
function(e, t) {
    for (var i in t) e[i] = t[i];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 562 ], {
    2: function(t, i) {
        var o;
        o = function() {
            return this;
        }();
        try {
            o = o || new Function("return this")();
        } catch (t) {
            "object" == ("undefined" == typeof window ? "undefined" : e(window)) && (o = window);
        }
        t.exports = o;
    },
    762: function(e, t, i) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var o, a = i(0), n = i(4), r = i(1), s = i(10), u = i(9), p = i(21), d = i(30), c = i(7), h = i(3), l = i(16);
        !function(e) {
            e[e.STOP = 0] = "STOP", e[e.CHANGING_TO_RANK = 1] = "CHANGING_TO_RANK", e[e.CHANGED_TO_RANK = 2] = "CHANGED_TO_RANK", 
            e[e.CHANGING_TO_SETTING = 3] = "CHANGING_TO_SETTING", e[e.CHANGED_TO_SETTING = 4] = "CHANGED_TO_SETTING";
        }(o || (o = {}));
        var m = {
            disableFetch: Boolean,
            settingEntranceText: {
                type: String,
                value: "主页设置"
            },
            changedDistanceRank: {
                type: null,
                observer: function(e, t) {
                    if (null !== e) {
                        var i = e > 0;
                        i !== t > 0 && (i ? this.animateChangeToRank() : this.animateChangeToSetting());
                    }
                }
            },
            distanceTags: String,
            name: {
                type: String,
                value: ""
            },
            logoUrl: {
                type: String,
                value: ""
            },
            groupId: {
                type: String
            },
            groupType: {
                type: Number,
                observer: function(e) {
                    if (e) {
                        var t = ![ 20, 105, 10 ].includes(e);
                        this.setData({
                            groupType: e,
                            isStarChecked: t
                        });
                    }
                }
            },
            isShowReddot: Boolean,
            isShowHomeSwitch: {
                type: Boolean,
                value: !0
            },
            isStarGroup: {
                type: null,
                observer: function(e) {
                    this.setData({
                        isStarChecked: !0
                    });
                }
            },
            isShowHomeSetVerifyTips: {
                type: Boolean,
                observer: function(e) {
                    this.setData({
                        isShowHomeSetVerifyTips: e
                    });
                }
            }
        };
        !function(e) {
            function t(t, i) {
                var a = e.call(this) || this;
                return a.routeService = t, a.monoRedDotService = i, a.properties = m, a.data = {
                    isEndActivity: !1,
                    RankAnimateStatus: o
                }, a.computed = {
                    isShowHomeSubjectAuthTips: function(e) {
                        var t = e.isNeedShowHomeSubjectAuthTips, i = e.isShowHomeSetVerifyTips, o = e.isClosedHomeSetVerifyTips;
                        return !(!t || i && !o);
                    }
                }, a.scrollOutTime = 800, a;
            }
            a.__extends(t, e);
            var i = t.prototype;
            i.attached = function() {
                e.prototype.attached.call(this), this.data.disableFetch || this.getRedDotByGroupIdAndSetData([ {
                    code: 1129,
                    groupId: this.data.groupId
                } ]);
            }, i.handleTapName = function() {
                this.triggerEvent("tapName");
            }, i.handleGoProfileHomepageSettings = function() {
                var e = this.data, t = e.groupId, i = e.groupType;
                t && "0" !== t && (this.data.isShowHomeSubjectAuthTips && this.markReadRedDotByGroupId([ {
                    code: 1129,
                    groupId: "0"
                } ]), this.data.isShowReddot && this.triggerEvent("tapBar"), this.routeService.goProfileHomepageSettings({
                    data: {
                        groupId: t,
                        groupType: i
                    }
                }));
            }, i.handleTapAuthRealNameAndAip = function() {
                this.triggerEvent("tapAuthRealNameAndAip");
            }, i.handleCloseHomeSetVerifyTips = function() {}, i.handleCloseHomeSubjectAuthTips = function() {
                this.markReadRedDotByGroupId([ {
                    code: 1129,
                    groupId: this.data.groupId
                } ]);
            }, i.setMessage = function() {
                var e = this.data.endTime, t = new Date().getTime() > Number(e);
                this.setData({
                    isEndActivity: t
                });
            }, i.animateChangeToRank = function() {
                var e = this;
                this.setData({
                    animateStatus: o.CHANGING_TO_RANK
                }), c.timer(this.scrollOutTime).pipe(h.takeUntil(this.unloadObservable)).subscribe(function() {
                    e.setData({
                        animateStatus: o.CHANGED_TO_RANK
                    });
                });
            }, i.animateChangeToSetting = function() {
                var e = this;
                this.setData({
                    animateStatus: o.CHANGING_TO_SETTING
                }), c.timer(this.scrollOutTime).pipe(h.takeUntil(this.unloadObservable)).subscribe(function() {
                    e.setData({
                        animateStatus: o.CHANGED_TO_SETTING
                    });
                });
            }, a.__decorate([ l.Toggle("isClosedHomeSetVerifyTips", !0), a.__metadata("design:type", Function), a.__metadata("design:paramtypes", []), a.__metadata("design:returntype", void 0) ], t.prototype, "handleGoProfileHomepageSettings", null), 
            a.__decorate([ l.Toggle("isClosedHomeSetVerifyTips", !0), a.__metadata("design:type", Function), a.__metadata("design:paramtypes", []), a.__metadata("design:returntype", void 0) ], t.prototype, "handleCloseHomeSetVerifyTips", null), 
            t = a.__decorate([ r.wxComponent(), a.__metadata("design:paramtypes", [ s.RouteService, d.MonoRedDotService ]) ], t);
        }(u.miniMixin(p.NewRedDotMixin, n.SuperComponent));
    }
}, [ [ 762, 0, 2, 1 ] ] ]));