var t = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
    return typeof t;
} : function(t) {
    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
};

require("./../../../../../runtime"), require("./../../../../../mono"), require("./../../../../../common"), 
function(t, e) {
    for (var p in e) t[p] = e[p];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 555 ], {
    2: function(e, p) {
        var n;
        n = function() {
            return this;
        }();
        try {
            n = n || new Function("return this")();
        } catch (e) {
            "object" == ("undefined" == typeof window ? "undefined" : t(window)) && (n = window);
        }
        e.exports = n;
    },
    718: function(t, e, p) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        });
        var n = p(0), o = p(4), a = p(1), i = p(437), r = p(3), c = {};
        !function(t) {
            function e(e) {
                var p = t.call(this) || this;
                return p.appUpdateService = e, p.properties = c, p.data = {}, p;
            }
            n.__extends(e, t);
            var p = e.prototype;
            p.attached = function() {
                t.prototype.attached.call(this), this.listenAppUpdate();
            }, p.ready = function() {
                t.prototype.ready.call(this);
            }, p.listenAppUpdate = function() {
                var t = this;
                this.appUpdateService.appUpdateObs.pipe(r.takeUntil(this.unloadObservable)).subscribe(function(e) {
                    t.setData({
                        isShowAppUpdateModal: e
                    });
                });
            }, p.handleTapConfirmUpdate = function() {
                this.setData({
                    isShowAppUpdateModal: !1
                }), this.appUpdateService.applyAppUpdate();
            }, p.handleTapCancelUpdate = function() {
                this.setData({
                    isShowAppUpdateModal: !1
                }), this.appUpdateService.cancelAppUpdate();
            }, e = n.__decorate([ a.wxComponent(), n.__metadata("design:paramtypes", [ i.AppUpdateService ]) ], e);
        }(o.SuperComponent);
    }
}, [ [ 718, 0, 2, 1 ] ] ]));