var e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
};

require("./../../../../../runtime"), require("./../../../../../mono"), require("./../../../../../common"), 
function(e, t) {
    for (var o in t) e[o] = t[o];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 565 ], {
    2: function(t, o) {
        var a;
        a = function() {
            return this;
        }();
        try {
            a = a || new Function("return this")();
        } catch (t) {
            "object" == ("undefined" == typeof window ? "undefined" : e(window)) && (a = window);
        }
        t.exports = a;
    },
    739: function(e, t, o) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var a = o(0), i = o(4), n = o(1), r = o(10), p = o(5), s = o(17), d = o(16), u = o(9), l = o(21), m = o(3), y = o(7), g = {
            disableFetch: Boolean,
            isShowEntranceIntro: Boolean,
            groupId: String,
            groupType: Number,
            isFakeSupply: Boolean,
            groupName: String,
            isStarGroup: Boolean,
            userAvatar: String,
            supplyBrandsNum: Number,
            supplyPromoterNum: Number,
            refresh: {
                type: Boolean,
                observer: function(e, t) {
                    e !== t && this.getBrandNum();
                }
            },
            canUseSupplyLeaderSeq: Boolean,
            supplyBrandUnreadImNum: Number,
            adminRights: Array,
            isHideSupplyLeaderViewBrand: Boolean,
            isHideInSuperPage: Boolean,
            isShowHomeSetVerifyTips: {
                type: Boolean,
                observer: function(e) {
                    this.setData({
                        isShowHomeSetVerifyTips: e
                    });
                }
            },
            isHideGoodsBrandEntrance: Boolean
        };
        !function(e) {
            function t(t, o, a) {
                var i = e.call(this) || this;
                return i.routeService = t, i.apiService = o, i.grayService = a, i.options = {
                    multipleSlots: !0
                }, i.properties = g, i.data = {}, i.computed = {
                    isShowHomeSubjectAuthTips: function(e) {
                        var t = e.isNeedShowHomeSubjectAuthTips, o = e.isShowHomeSetVerifyTips, a = e.isClosedHomeSetVerifyTips;
                        return !(!t || o && !a);
                    }
                }, i;
            }
            a.__extends(t, e);
            var o = t.prototype;
            o.attached = function() {
                e.prototype.attached.call(this), this.data.disableFetch || (this.getRedDotByGroupIdAndSetData([ {
                    code: 1129,
                    groupId: this.data.groupId
                } ]), this.getSoleCommissionGrayAndRedDot());
            }, o.handleGoSupplyBrands = function() {
                var e = this.data, t = e.groupId, o = e.groupType, a = e.groupName, i = void 0 === a ? "" : a, n = e.isFakeSupply;
                e.canUseSupplyLeaderSeq || !n ? this.routeService.goHomeHomepageSupplyBrands({
                    type: "navigateTo",
                    data: {
                        groupId: t,
                        groupType: o,
                        groupName: encodeURIComponent(i)
                    }
                }) : wx.showModal({
                    title: "敬请期待",
                    content: "",
                    showCancel: !1
                });
            }, o.handleCloseSupplyLeader2leaderCommissionSettingTips = function() {
                this.data.isShowSupplyLeader2leaderCommissionSettingTips && this.markReadRedDotByUid([ {
                    code: 2031
                } ]);
            }, o.handleGoMyBrandsIm = function() {
                var e = this.data, t = e.groupId, o = e.groupType;
                this.routeService.goHomeBrandHelpMyBrandListIm({
                    type: "navigateTo",
                    data: {
                        groupId: t,
                        groupType: o
                    }
                });
            }, o.handleGoHomePromoters = function() {
                var e = this.data, t = e.groupId, o = e.groupType;
                this.routeService.goHomeRelationshipSupplyLeaderPromoterManagement({
                    type: "navigateTo",
                    data: {
                        groupId: t,
                        groupType: o
                    }
                });
            }, o.handleGoProfileHomepageSettings = function() {
                var e = this.data, t = e.groupId, o = e.groupType;
                this.data.isShowHomeSubjectAuthTips && this.markReadRedDotByGroupId([ {
                    code: 1129,
                    groupId: "0"
                } ]), this.routeService.goProfileHomepageSettings({
                    data: {
                        groupId: t,
                        groupType: o
                    }
                });
            }, o.handleCloseHomeSubjectAuthTips = function() {
                this.markReadRedDotByGroupId([ {
                    code: 1129,
                    groupId: this.data.groupId
                } ]);
            }, o.handleTapAuthRealNameAndAip = function() {
                this.triggerEvent("tapAuthRealNameAndAip");
            }, o.handleCloseHomeSetVerifyTips = function() {}, o.getBrandNum = function() {
                var e = this, t = {
                    ghId: this.data.groupId,
                    page: 1,
                    pageSize: 1,
                    ghType: 105
                };
                y.forkJoin([ this.apiService.queryCompanyGhListTotalCountUsingPOST(a.__assign(a.__assign({}, t), {
                    hasRelation: !0
                }), {
                    replayOnceTime: 5e3
                }).pipe(m.map(function(e) {
                    var t = e.data;
                    return void 0 === t ? 0 : t;
                })), this.apiService.queryCompanyGhListTotalCountUsingPOST(a.__assign(a.__assign({}, t), {
                    hasRelation: !1
                }), {
                    replayOnceTime: 5e3
                }).pipe(m.map(function(e) {
                    var t = e.data;
                    return void 0 === t ? 0 : t;
                })) ]).pipe(m.takeUntil(this.unloadObservable)).subscribe(function(t) {
                    var o = a.__read(t, 2), i = o[0], n = i + o[1];
                    e.setData({
                        brandNum: i,
                        isShowBrand: n > 0
                    });
                });
            }, o.getSoleCommissionGrayAndRedDot = function() {
                var e = this, t = this.data.groupId;
                this.grayService.canIUseFeatureHybridDimension([ {
                    code: "2509",
                    type: s.GrayFeatureCodeDimension.GROUP
                } ], {
                    groupId: t
                }).subscribe(function(t) {
                    a.__read(t, 1)[0] && e.getRedDotAndSetData([ {
                        code: 2031
                    } ]);
                });
            }, a.__decorate([ d.Toggle("isShowSupplyLeader2leaderCommissionSettingTips", !1), a.__metadata("design:type", Function), a.__metadata("design:paramtypes", []), a.__metadata("design:returntype", void 0) ], t.prototype, "handleCloseSupplyLeader2leaderCommissionSettingTips", null), 
            a.__decorate([ d.Toggle("isClosedHomeSetVerifyTips", !0), a.__metadata("design:type", Function), a.__metadata("design:paramtypes", []), a.__metadata("design:returntype", void 0) ], t.prototype, "handleGoProfileHomepageSettings", null), 
            a.__decorate([ d.Toggle("isClosedHomeSetVerifyTips", !0), a.__metadata("design:type", Function), a.__metadata("design:paramtypes", []), a.__metadata("design:returntype", void 0) ], t.prototype, "handleCloseHomeSetVerifyTips", null), 
            t = a.__decorate([ n.wxComponent(), a.__metadata("design:paramtypes", [ r.RouteService, p.DefaultService, s.GrayFeatureService ]) ], t);
        }(u.miniMixin(l.NewRedDotMixin, i.SuperComponent));
    }
}, [ [ 739, 0, 2, 1 ] ] ]));