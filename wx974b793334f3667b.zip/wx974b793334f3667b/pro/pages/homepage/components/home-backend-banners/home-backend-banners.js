var e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
};

require("./../../../../../runtime"), require("./../../../../../mono"), require("./../../../../../common"), 
function(e, o) {
    for (var a in o) e[a] = o[a];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 558 ], {
    2: function(o, a) {
        var t;
        t = function() {
            return this;
        }();
        try {
            t = t || new Function("return this")();
        } catch (o) {
            "object" == ("undefined" == typeof window ? "undefined" : e(window)) && (t = window);
        }
        o.exports = t;
    },
    693: function(e, o, a) {
        Object.defineProperty(o, "__esModule", {
            value: !0
        });
        var t = a(0), n = a(4), i = a(1), r = a(16), u = a(5), s = a(10), d = a(15), p = a(17), l = a(30), c = a(60), h = a(27), g = a(6), S = a(18), v = a(50), y = a(117), m = a(13), w = {
            groupId: String,
            groupType: Number,
            isStarGroup: Boolean,
            isFakeHelp: Boolean,
            isFakeSupply: Boolean,
            isLeader: Boolean,
            isSupplyLeader: Boolean,
            canUsePublishEvaluationSquare: Boolean,
            hideAllBanners: Boolean,
            bannerHeight: Number,
            isHighIntention: Boolean,
            isShowTaskNewWxModalTrigger: {
                type: Boolean,
                observer: function(e) {
                    e && this.showTaskNewWxModal();
                }
            },
            isShowEvaluationMeetingBanner: Boolean,
            isShowDoubleHelpBanner: Boolean,
            isShowFlashDeliverBanner: Boolean,
            isShowExProductBanner: {
                type: Boolean,
                observer: function(e) {
                    e && this.getExclusiveProductTopSalesList();
                }
            },
            isNeedShowEvaluationSquareBanner: {
                type: Boolean,
                observer: function(e) {
                    e && this.getEvaluationSquareData();
                }
            },
            evaSquareBannerTitleType: Number,
            channelType: Number,
            isShowGoodStuffTodayBanner: Boolean
        };
        !function(e) {
            function o(o, a, t, n, i, r, u, s, d, p, l) {
                var c = e.call(this) || this;
                return c.apiService = o, c.routeService = a, c.commonService = t, c.grayFeatureService = n, 
                c.monoRedDotService = i, c.imService = r, c.migrateService = u, c.utilService = s, 
                c.timeService = d, c.wxCloudApiService = p, c.homeNewWxGuideService = l, c.properties = w, 
                c.data = {}, c.computed = {
                    isShowIndicatorDots: function(e) {
                        var o = 0;
                        return [ e.isShowEvaluationMeetingBanner, e.isShowDoubleHelpBanner, e.isShowFlashDeliverBanner, e.isShowExProductBanner, e.isShowEvaluationSquareBanner ].forEach(function(e) {
                            e && (o += 1);
                        }), o > 1;
                    }
                }, c;
            }
            t.__extends(o, e);
            var a = o.prototype;
            a.ready = function() {
                e.prototype.ready.call(this), this.getHomeBackEndBanners(), this.getWxGuideModalBgAndQrCode();
            }, a.handleTapMeetingBanner = function() {
                this.goEvaluationSquare();
            }, a.handleTapDoubleHelpBanner = function() {
                this.routeService.goHomeGroupHelpSell({
                    data: {
                        groupId: this.data.groupId,
                        groupType: this.data.groupType
                    }
                });
            }, a.handleTapFlashDeliverBanner = function() {
                this.routeService.goHomeSupportLaunchFlashDeliver({
                    data: {
                        groupId: this.data.groupId,
                        groupType: this.data.groupType
                    }
                });
            }, a.handleTapExProductBanner = function() {
                this.routeService.goCustomerServiceExclusiveProductWarehouse({
                    data: {
                        groupId: this.data.groupId,
                        groupType: this.data.groupType,
                        source: "9"
                    }
                });
            }, a.handleTapEvaluationSquareBanner = function() {
                this.goEvaluationSquare();
            }, a.showTaskNewWxModal = function() {}, a.handleCloseTaskNewWxModal = function() {
                this.triggerEvent("closeBannersModal");
            }, a.handleTapHighIntentionAddWx = function() {
                this.showWxQrCode();
            }, a.handleTapAddNewWx = function() {
                this.showWxQrCode();
            }, a.getHomeBackEndBanners = function() {
                var e = this, o = this.data, a = o.groupType, t = o.isFakeSupply, n = o.hideAllBanners;
                [ 20, 10 ].includes(a) && (n || t || this.wxCloudApiService.getHomeBackendBanners({
                    groupType: a
                }, {
                    useStorageOptions: {
                        isUseCache: !0
                    }
                }).subscribe(function(o) {
                    var a = o.data || {}, t = a.evaluationInfo;
                    e.setData({
                        evaluationBannerInfo: t
                    });
                }));
            }, a.refreshEvaluationSquareData = function() {
                this.getEvaluationSquareData();
            }, a.handleTapGoodStuffTodayBanner = function() {
                this.routeService.goHomeSupportLandingPage({
                    data: {
                        groupId: this.data.groupId,
                        groupType: this.data.groupType
                    }
                });
            }, a.getEvaluationSquareData = function() {
                var e = this;
                this.apiService.getActionCountByGroupEvAluationautomationUsingPOST({
                    ghId: this.data.groupId
                }, m.skipErrorOptions).subscribe(function(o) {
                    var a = o.data, t = void 0 === a ? {} : a;
                    e.setData({
                        evaSquareData: t,
                        isShowEvaluationSquareBanner: Boolean(t.canApplyCount || t.waitCommentCount || t.auditingCount)
                    });
                });
            }, a.getExclusiveProductTopSalesList = function() {
                var e = this;
                this.apiService.getExclusiveGoodsUsingPOST({
                    ghId: this.data.groupId,
                    sort: u.QueryExclusiveGoodsParam.SortEnum.THIRTYDAYSALES
                }).subscribe(function(o) {
                    var a = o.data, t = (void 0 === a ? {} : a).items || [];
                    e.setData({
                        exclusiveProductTopSalesList: t.slice(0, 3)
                    });
                });
            }, a.goEvaluationSquare = function() {
                this.routeService.goHomeSupportEvaluationSquare({
                    data: t.__assign({
                        groupId: this.data.groupId,
                        groupType: this.data.groupType
                    }, this.data.isFakeSupply ? {
                        isFakeSupply: !0
                    } : null)
                });
            }, a.getWxGuideModalBgAndQrCode = function() {
                this.setData({
                    highIntentionBg: "/ss/app/image/plus/home_bg03.png"
                });
            }, a.showWxQrCode = function() {
                var e = this, o = this.data, a = o.isHighIntention, t = o.groupType, n = o.isSupplyLeader, i = a ? t : null, r = this.data.channelType || 10;
                this.homeNewWxGuideService.getWxGuideQrCode(r, i).subscribe(function(o) {
                    o ? (wx.previewImage({
                        urls: [ o.qrCode ]
                    }), n && (e.setData({
                        isShowTaskNewWxModal: !1
                    }), e.triggerEvent("closeBannersModal", {
                        noJudgeShowTips: !0
                    }))) : wx.showToast({
                        title: "图片加载失败",
                        icon: "none"
                    });
                }, function() {
                    wx.showToast({
                        title: "图片加载失败",
                        icon: "none"
                    });
                });
            }, t.__decorate([ r.Toggle("isShowTaskNewWxModal", !0), t.__metadata("design:type", Function), t.__metadata("design:paramtypes", []), t.__metadata("design:returntype", void 0) ], o.prototype, "showTaskNewWxModal", null), 
            t.__decorate([ r.Toggle("isShowTaskNewWxModal", !1), t.__metadata("design:type", Function), t.__metadata("design:paramtypes", []), t.__metadata("design:returntype", void 0) ], o.prototype, "handleCloseTaskNewWxModal", null), 
            o = t.__decorate([ i.wxComponent(), t.__metadata("design:paramtypes", [ u.DefaultService, s.RouteService, d.CommonService, p.GrayFeatureService, l.MonoRedDotService, c.ImService, h.BackendMigrateService, g.UtilService, S.TimeService, v.WxCloudApiService, y.HomeNewWxGuideService ]) ], o);
        }(n.SuperComponent);
    }
}, [ [ 693, 0, 2, 1 ] ] ]));