var e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
};

require("./../../../../../runtime"), require("./../../../../../mono"), require("./../../../../../common"), 
function(e, t) {
    for (var o in t) e[o] = t[o];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 557 ], {
    2: function(t, o) {
        var a;
        a = function() {
            return this;
        }();
        try {
            a = a || new Function("return this")();
        } catch (t) {
            "object" == ("undefined" == typeof window ? "undefined" : e(window)) && (a = window);
        }
        t.exports = a;
    },
    757: function(e, t, o) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var a = o(0), i = o(4), r = o(1), n = o(14), d = o(5), s = o(10), p = o(17), u = o(21), h = o(9), g = o(16), c = o(13), m = {
            disableFetch: Boolean,
            isShowEntranceIntro: Boolean,
            groupId: String,
            groupType: Number,
            groupName: String,
            isStarGroup: Boolean,
            userAvatar: String,
            ghFansCount: Number,
            memberHeadList: {
                type: Array,
                observer: function(e) {
                    void 0 === e && (e = []), e.length && this.setData({
                        groupAvatarList: e.map(function(e) {
                            return e.mememberHeadUrl;
                        })
                    });
                }
            },
            newFansMsg: Number,
            canFansShare: Boolean,
            refresh: {
                type: Boolean,
                observer: function(e, t) {
                    e !== t && (this.getLeaderRedDotNum(), this.getBrandRedDotNum(), this.getLeaderNum(), 
                    this.getBrandNum());
                }
            },
            isHideInSuperPage: Boolean,
            isHasHeadOfHelp: Boolean,
            isShowHomeSetVerifyTips: {
                type: Boolean,
                observer: function(e) {
                    this.setData({
                        isShowHomeSetVerifyTips: e
                    });
                }
            },
            adminRights: Array
        };
        !function(e) {
            function t(t, o, a) {
                var i = e.call(this) || this;
                return i.apiService = t, i.routeService = o, i.grayFeatureService = a, i.properties = m, 
                i.data = {}, i.computed = {
                    isShowHomeSubjectAuthTips: function(e) {
                        var t = e.isNeedShowHomeSubjectAuthTips, o = e.isShowHomeSetVerifyTips, a = e.isClosedHomeSetVerifyTips;
                        return !(!t || o && !a);
                    }
                }, i;
            }
            a.__extends(t, e);
            var o = t.prototype;
            o.attached = function() {
                e.prototype.attached.call(this), this.data.disableFetch || (this.getLeaderRedDotNum(), 
                this.getBrandRedDotNum(), this.getLeaderNum(), this.getBrandNum(), this.getIsShowNewRevisionTips());
            }, o.handleGoProfileHomepageSettings = function() {
                var e = this.data, t = e.groupId, o = e.groupType;
                this.data.isShowHomeSubjectAuthTips && this.markReadRedDotByGroupId([ {
                    code: 1129,
                    groupId: "0"
                } ]), this.routeService.goProfileHomepageSettings({
                    data: {
                        groupId: t,
                        groupType: o
                    }
                });
            }, o.handleTapAuthRealNameAndAip = function() {
                this.triggerEvent("tapAuthRealNameAndAip");
            }, o.handleCloseHomeSetVerifyTips = function() {}, o.handleCloseHomeSubjectAuthTips = function() {
                this.markReadRedDotByGroupId([ {
                    code: 1129,
                    groupId: this.data.groupId
                } ]);
            }, o.handleGoMyBrandsIm = function() {
                var e = this.data, t = e.groupId, o = e.groupType;
                this.routeService.goHomeBrandHelpMyBrandListIm({
                    type: "navigateTo",
                    data: {
                        groupId: t,
                        groupType: o
                    }
                });
            }, o.handleGoLeaders = function() {
                var e = this.data, t = e.groupId, o = e.groupType;
                this.routeService.goHomeHomepageSupplyLeadersFakeHelp({
                    type: "navigateTo",
                    data: {
                        groupId: t,
                        groupType: o
                    }
                });
            }, o.handleTapGoGroupHelpSellPage = function() {
                this.triggerEvent("closeLeaderFissionBackendTip"), this.routeService.goHomeSupportHeadOfHelp({
                    data: {
                        myGroupId: this.data.groupId,
                        myGroupType: this.data.groupType
                    }
                }), this.data.isShowGroupLeaderHelpRedDot && this.hideShowGroupLeaderHelpRedDot(), 
                this.data.isShowHelpLeaderHeadNewRevisionTips && this.markReadRedDotByUid([ {
                    code: 1115
                } ]);
            }, o.handleTapCloseNewRevisionTips = function() {
                this.markReadRedDotByUid([ {
                    code: 1115
                } ]);
            }, o.getGroupLeaderHeadRedDot = function() {
                var e = this;
                this.apiService.queryGhStoryVideoBubbleUsingPOST({
                    ghId: this.data.groupId
                }, c.skipErrorOptions).subscribe(function(t) {
                    t.data && e.setData({
                        isShowGroupLeaderHelpRedDot: t.data
                    });
                });
            }, o.getLeaderRedDotNum = function() {
                var e = this, t = this.data.groupId;
                this.apiService.queryUpUnreadRelationNumUsingGET(t, n.skipMarkOption).subscribe(function(t) {
                    var o = t.data;
                    e.setData({
                        leaderMsgNum: o
                    });
                });
            }, o.getBrandRedDotNum = function() {
                var e = this;
                this.apiService.getCompanyHelperAllMessageCountUsingPOST(this.data.groupId, n.skipMarkOption).subscribe(function(t) {
                    var o = t.data;
                    e.setData({
                        brandMsgNum: o
                    });
                });
            }, o.getLeaderNum = function() {
                var e = this, t = this.data.groupId;
                this.apiService.queryUpStreamHelpSaleCountGhomeRelationUsingPOST({
                    ghId: t
                }).subscribe(function(t) {
                    e.setData({
                        leaderNum: t.data || 0
                    });
                });
            }, o.getBrandNum = function() {
                var e = this, t = {
                    ghId: this.data.groupId,
                    page: 1,
                    pageSize: 1
                };
                this.apiService.queryCompanyGhListTotalCountUsingPOST(t).subscribe(function(t) {
                    e.setData({
                        brandNum: t.data || 0
                    });
                });
            }, o.hideShowGroupLeaderHelpRedDot = function() {
                this.apiService.markGhStoryVideoBubbleUsingPOST({
                    ghId: this.data.groupId
                }, c.skipErrorOptions).subscribe();
            }, o.getIsShowNewRevisionTips = function() {
                this.getRedDotAndSetData([ {
                    code: 1115
                } ]), this.getRedDotByGroupIdAndSetData([ {
                    code: 1129,
                    groupId: this.data.groupId
                } ]);
            }, a.__decorate([ g.Toggle("isClosedHomeSetVerifyTips", !0), a.__metadata("design:type", Function), a.__metadata("design:paramtypes", []), a.__metadata("design:returntype", void 0) ], t.prototype, "handleGoProfileHomepageSettings", null), 
            a.__decorate([ g.Toggle("isClosedHomeSetVerifyTips", !0), a.__metadata("design:type", Function), a.__metadata("design:paramtypes", []), a.__metadata("design:returntype", void 0) ], t.prototype, "handleCloseHomeSetVerifyTips", null), 
            a.__decorate([ g.Toggle("isShowHelpLeaderHeadNewRevisionTips", !1), a.__metadata("design:type", Function), a.__metadata("design:paramtypes", []), a.__metadata("design:returntype", void 0) ], t.prototype, "handleTapCloseNewRevisionTips", null), 
            a.__decorate([ g.Toggle("isShowGroupLeaderHelpRedDot", !1), a.__metadata("design:type", Function), a.__metadata("design:paramtypes", []), a.__metadata("design:returntype", void 0) ], t.prototype, "hideShowGroupLeaderHelpRedDot", null), 
            t = a.__decorate([ r.wxComponent(), a.__metadata("design:paramtypes", [ d.DefaultService, s.RouteService, p.GrayFeatureService ]) ], t);
        }(h.miniMixin(u.NewRedDotMixin, i.SuperComponent));
    }
}, [ [ 757, 0, 2, 1 ] ] ]));