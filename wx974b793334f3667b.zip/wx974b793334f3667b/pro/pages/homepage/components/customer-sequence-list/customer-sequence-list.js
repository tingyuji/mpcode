var e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
};

require("./../../../../../runtime"), require("./../../../../../mono"), require("./../../../../../common"), 
function(e, t) {
    for (var i in t) e[i] = t[i];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 556 ], {
    2: function(t, i) {
        var a;
        a = function() {
            return this;
        }();
        try {
            a = a || new Function("return this")();
        } catch (t) {
            "object" == ("undefined" == typeof window ? "undefined" : e(window)) && (a = window);
        }
        t.exports = a;
    },
    772: function(e, t, i) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.CustomerSequenceListEventNameMap = void 0;
        var a = i(0), o = i(4), n = i(1), r = i(6), s = i(5), c = i(12), d = i(15), u = i(76), p = i(10), h = i(40), l = i(20), g = i(159), v = i(17), S = i(16), m = i(19), f = i(7), y = i(3), T = i(13), w = i(27), b = i(11), A = i(91), E = i(75), I = i(56), O = i(232), _ = i(32), P = {
            seqItem: {
                type: Object,
                observer: function(e, t) {
                    this.formatSeqItem(e);
                }
            },
            seqIndex: Number,
            groupType: {
                type: Number
            },
            groupId: String,
            isManagerOrCreator: {
                type: Boolean,
                value: !0
            },
            isHideSearch: {
                type: Boolean,
                value: !1
            },
            isHideHeadImg: {
                type: Boolean,
                value: !1
            },
            isNotMember: {
                type: Boolean,
                value: !1
            },
            isAdminOrCreator: {
                type: Boolean,
                value: !1
            },
            isHomeOtherBrowse: {
                type: Boolean,
                value: !1
            },
            isShowShareActTipsPopup: Boolean,
            isShowShareActTips: Boolean,
            isGrayShowViewCount: Boolean,
            feedStarGroup: Object,
            feedStarGroupChecked: Object
        };
        t.CustomerSequenceListEventNameMap = {
            MODULE_NAME: "customer-sequence-list",
            OPERATE_SEQ: "OPERATE-SEQ-MORE"
        }, I.default(t.CustomerSequenceListEventNameMap), function(e) {
            function i(i, o, n, r, s, c, d, u, p, h, l, g, v) {
                var S = e.call(this) || this;
                return S.utils = i, S.apiService = o, S.homeSeqService = n, S.commonService = r, 
                S.seqService = s, S.routeService = c, S.monoCommonService = d, S.detailPreloadService = u, 
                S.grayService = p, S.migrateService = h, S.monoUtil = l, S.appsJumpPageRouteService = g, 
                S.sequenceActionSheetService = v, S.properties = P, S.data = a.__assign({}, t.CustomerSequenceListEventNameMap), 
                S;
            }
            a.__extends(i, e);
            var o = i.prototype;
            o.created = function() {
                e.prototype.created.call(this);
            }, o.ready = function() {
                e.prototype.ready.call(this), this.setData({
                    isUseSharePreview: !0
                });
            }, o.formatSeqItem = function(e) {
                if (e) {
                    var t = this.homeSeqService.mapFeedActItemDTOToFeedItemInPage(e, 30);
                    this.setData({
                        item: t
                    });
                }
            }, o.action = function(e) {
                var t = e.currentTarget.dataset.clickValue ? "/" + e.currentTarget.dataset.clickValue : "";
                this.utils.navigateTo(t);
            }, o.handleTapCheckDetail = function(e) {
                if (!this.data.isNotMember) {
                    var t = e.currentTarget.dataset.item;
                    if (1 !== t.flowType) {
                        var i = String(t.actId), o = t.activityType || 20, n = t.ghId, r = t.shareObj || {}, s = encodeURIComponent(this.monoCommonService.sliceEmojiString(t.nickName, 0, 5)), c = encodeURIComponent(this.monoCommonService.sliceEmojiString(t.activityName, 0, 10));
                        this.commonService.goToDetailPossiblyJumpApp({
                            actId: i,
                            seqType: o,
                            extraOption: a.__assign(a.__assign({}, r), {
                                nickName: s,
                                seqName: c,
                                groupId: n
                            })
                        });
                    }
                }
            }, o.catcaTapOtherPersonPage = function(e) {
                if (!this.data.isNotMember) {
                    var t = e.currentTarget.dataset.item, i = t.ghId, a = t.ghType;
                    this.commonService.goHomePage(i, a, !1, "navigateTo", {
                        isShowBackButton: !0,
                        isRoleSelectModalCustomerAvailable: 1
                    });
                }
            }, o.handleSearch = function(e) {
                this.triggerEvent("search", {
                    value: e.detail.value
                });
            }, o.handleCancel = function(e) {
                this.triggerEvent("cancel");
            }, o.catchTapOperateSeq = function(e) {
                var t = this, i = e.currentTarget.dataset.index, a = e.currentTarget.dataset.item, o = a.flowKey, n = a.flowType, r = a.ghId, s = a.isFeedManager, d = a.nickName, u = void 0 === d ? "" : d;
                if (s || this.data.isAdminOrCreator && 10 !== a.feedActFlag) this.showOperateSeqList(a, i); else {
                    var p = [ "不看这个接龙了", "取消关注 " + (u.length < 14 ? u : this.monoCommonService.sliceEmojiString(u, 0, 14) + "...") ];
                    c.rxwx.showActionSheet({
                        itemList: p
                    }).subscribe(function(e) {
                        var a = e.tapIndex;
                        0 === a ? t.migrateService.generateMigratingRequestFeedSpring(t.apiService.shieldUserFeedV2UsingPOST({
                            flowKey: o,
                            flowType: n
                        }, T.skipAllToastOptions), t.apiService.shieldUserFeedUsingPOST(o, n, T.skipAllToastOptions)).subscribe(function() {
                            t.triggerEvent("refresh", {
                                index: i
                            });
                        }, function() {
                            wx.showToast({
                                title: "操作失败，请稍后再试",
                                icon: "none"
                            });
                        }) : 1 === a && c.rxwx.showModal({
                            title: "",
                            content: "取消关注后，您将不再收到他/她发布的活动信息",
                            cancelText: "我再想想",
                            confirmText: "取消关注",
                            confirmColor: "#FF0000"
                        }).subscribe(function(e) {
                            e.confirm && (t.customReport({
                                functionName: "unbindHome",
                                methodParams: {
                                    ghId: r
                                }
                            }), t.apiService.cancelFocusV2UsingPUT(r, T.skipErrorOptions).subscribe(function() {
                                c.rxwx.showToast({
                                    title: "已取消关注",
                                    icon: "success"
                                }).subscribe(), t.triggerEvent("reload");
                            }));
                        });
                    });
                }
            }, o.handleHideShareActPopup = function() {
                this.triggerEvent("hideShareTipsPopup");
            }, o.handleHideShareActTips = function() {
                this.triggerEvent("hideShareTips");
            }, o.handleTapGeneratePoster = function() {
                this.triggerEvent("poster", {
                    editItem: this.data.editItem
                });
            }, o.handleTapSharePoster = function(e) {
                this.triggerEvent(this.data.isUseSharePreview ? "selectPoster" : "poster", {
                    editItem: e.detail.seqItem,
                    isFiveStarsAfterSale: e.detail.isFiveStarsAfterSale
                });
            }, o.handleHideUnableUsePublishModal = function() {
                this.setData({
                    isUnableUsePublish: !1
                });
            }, o.handleTapActionSheet = function(e) {
                var t = e.detail.text, i = this.data, a = i.operateItem, o = i.operateIndex;
                if (!a) throw new Error("未获取到当前操作feed信息");
                "结束接龙" === t || "开启接龙" === t ? this.endAct(a, o) : "修改接龙" === t ? this.goUpdateAct(a) : "显示接龙" === t || "隐藏接龙" === t ? this.hideOrShowAct(a, o) : "删除接龙" === t ? this.deleteAct(a, o) : "复制接龙" === t ? this.goCopyAct(a) : "操作记录" === t ? this.goSeqDetailActOperateLog(a) : "暂停接龙" === t ? this.pauseAct(a, o) : "继续接龙" === t && this.continueAct(a, o);
            }, o.handleTapRestore = function(e, t) {
                var i = this;
                if (!this.data.isAdminOrCreator) return t();
                wx.showLoading();
                var a = e.currentTarget.dataset.actId;
                this.apiService.recoverActivityUsingPUT(a.toString()).pipe(y.finalize(function() {
                    t();
                })).subscribe(function(e) {
                    wx.hideLoading(), e.success ? i.setData({
                        isShowRestoreModal: !0
                    }) : wx.showToast({
                        title: "无法恢复当前接龙",
                        icon: "none"
                    });
                });
            }, o.handleCloseRestoreModal = function() {
                this.triggerEvent("reload");
            }, o.handleTapCheckDetailOnRestoreModal = function(e) {
                var t = this;
                f.timer(300).subscribe(function() {
                    t.handleCloseRestoreModal();
                }), this.handleTapCheckDetail(e);
            }, o.showOperateSeqList = function(e, t) {
                var i = this.homeSeqService.getActSheetList(e), a = i.findIndex(function(e) {
                    return e.name.includes("置顶");
                });
                -1 !== a && i.splice(a, 1), i.filter(function(e) {
                    return "售后授权" === e.name;
                });
                var o = i.map(function(e) {
                    return e.name;
                }), n = 20 === e.activityType, r = this.checkCanEdit(e);
                n && !r || o.unshift("修改接龙");
                var s = new Array(o.length);
                this.setData({
                    isShowActionSheet: !0,
                    actionSheetConfigList: o,
                    actionSheetStyleList: s,
                    operateItem: e,
                    operateIndex: t
                });
            }, o.checkCanEdit = function(e) {
                var t = 20 === e.feedDTO.titleEditModel, i = 10 === e.feedDTO.activityModel, a = 10 === e.feedDTO.allowGroupSelectGoods, o = 30 === e.activityDoubtStatus || 50 === e.activityType;
                return (t || a || !i) && !o;
            }, o.goUpdateAct = function(e) {
                this.goToEditPage(e);
            }, o.goCopyAct = function(e) {
                this.goToEditPage(e, !0);
            }, o.goSeqDetailActOperateLog = function(e) {
                this.routeService.goSeqDetailActOperateLog({
                    data: {
                        actId: e.actId
                    }
                });
            }, o.goToEditPage = function(e, t) {
                void 0 === t && (t = !1);
                var i = e.ghId, a = this.data.groupType, o = {
                    groupId: i,
                    seqType: e.activityType,
                    groupType: a
                };
                t ? o.copySeqId = e.actId : o.actId = e.actId, [ 20, 160, 250, 210 ].includes(e.activityType) && (o.isChildEdit = 1), 
                o.ghViewType = e.ghViewType, o.isChildEdit ? this.routeService.goSeqPublishPublishStartGroup({
                    data: o
                }) : t ? this.appsJumpPageRouteService.navToPublishStartGroupByUserType({
                    groupId: i,
                    groupType: a
                }, o) : this.appsJumpPageRouteService.navToEditStartGroupByUserType({
                    groupId: i,
                    groupType: a
                }, o);
            }, o.pauseAct = function(e, t) {
                var i = this;
                this.seqService.pauseActivity(e.activityType, String(e.actId)).subscribe(function() {
                    i.triggerEvent("refresh", {
                        index: t
                    });
                });
            }, o.continueAct = function(e, t) {
                var i = this;
                this.seqService.continueActivity(String(e.actId)).subscribe(function() {
                    i.triggerEvent("refresh", {
                        index: t
                    });
                });
            }, o.endAct = function(e, t) {
                var i = this;
                this.sequenceActionSheetService.restartOrEndAct(String(e.actId), this.data.groupId, this.data.groupType, e.activityType || -10, e.activityStatus, _.ALLOW_FOLLOW_STATUS.CLOSE, e.ghViewType, !1, function() {
                    return i.triggerEvent("refresh", {
                        index: t
                    });
                }, function(e) {
                    "forbidPublish" === e.type && i.setData({
                        isUnableUsePublish: !0,
                        unableUsePublishTips: e.errTips
                    });
                });
            }, o.hideOrShowAct = function(e, t) {
                var i = this, a = 5 === e.visibleModel, o = a ? "显示" : "隐藏";
                wx.showModal({
                    title: "确认提示",
                    content: "请确认是否" + o + "该接龙？",
                    success: function(n) {
                        if (!n.cancel) {
                            var r = a ? 10 : 5;
                            i.apiService.showAndHideActivityUsingPUT(e.actId + "", i.data.groupId, r + "").subscribe(function() {
                                wx.showToast({
                                    title: o + "接龙成功"
                                }), i.triggerEvent("refresh", {
                                    index: t
                                });
                            });
                        }
                    }
                });
            }, o.deleteAct = function(e, t) {
                var i = this;
                wx.showModal({
                    title: "是否确认删除接龙",
                    content: "只能恢复近30天内删除的接龙",
                    confirmText: "删除",
                    confirmColor: "#FF0000",
                    success: function(a) {
                        a.cancel || (wx.showLoading(), i.migrateService.generateMigratingRequestActivityRelatedApi(i.apiService.delActivityUsingPUT(e.actId + ""), i.apiService.deleteActivityUsingPUT(e.actId + "", i.data.groupId)).subscribe(function() {
                            wx.hideLoading(), wx.showToast({
                                title: "删除接龙成功"
                            }), i.triggerEvent("refresh", {
                                index: t
                            });
                        }));
                    }
                });
            }, a.__decorate([ E.BindEvent(t.CustomerSequenceListEventNameMap.OPERATE_SEQ), a.__metadata("design:type", Function), a.__metadata("design:paramtypes", [ Object ]), a.__metadata("design:returntype", void 0) ], i.prototype, "catchTapOperateSeq", null), 
            a.__decorate([ m.Lock(), a.__metadata("design:type", Function), a.__metadata("design:paramtypes", [ Object, Function ]), a.__metadata("design:returntype", void 0) ], i.prototype, "handleTapRestore", null), 
            a.__decorate([ S.Toggle("isShowRestoreModal", !1), a.__metadata("design:type", Function), a.__metadata("design:paramtypes", []), a.__metadata("design:returntype", void 0) ], i.prototype, "handleCloseRestoreModal", null), 
            i = a.__decorate([ n.wxComponent(), a.__metadata("design:paramtypes", [ r.UtilService, s.DefaultService, u.HomeSequenceListService, d.CommonService, h.SequenceService, p.RouteService, l.MonoCommonService, g.DetailPreloadService, v.GrayFeatureService, w.BackendMigrateService, b.MonoUtilService, A.AppsJumpPageRouteService, O.SequenceActionSheetService ]) ], i);
        }(o.SuperComponent);
    }
}, [ [ 772, 0, 2, 1 ] ] ]));