var t = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
    return typeof t;
} : function(t) {
    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
};

require("./../../../../../runtime"), require("./../../../../../mono"), require("./../../../../../common"), 
function(t, e) {
    for (var n in e) t[n] = e[n];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 560 ], {
    2: function(e, n) {
        var o;
        o = function() {
            return this;
        }();
        try {
            o = o || new Function("return this")();
        } catch (e) {
            "object" == ("undefined" == typeof window ? "undefined" : t(window)) && (o = window);
        }
        e.exports = o;
    },
    764: function(t, e, n) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        });
        var o = n(0), i = n(4), r = n(1), a = n(20), s = n(438), u = n(9), c = {
            groupId: {
                type: String,
                observer: function(t) {
                    t && this.refreshDataWhenGroupChange();
                }
            },
            groupType: Number,
            isExpanded: {
                type: Boolean,
                value: !1
            },
            disableListenMigrateCrashDraft: {
                type: Boolean,
                value: !1
            }
        };
        !function(t) {
            function e(e) {
                var n = t.call(this) || this;
                return n.monoCommonService = e, n.properties = c, n.data = {}, n;
            }
            o.__extends(e, t);
            var n = e.prototype;
            n.attached = function() {
                t.prototype.attached.call(this), this.commonOnload(), this.getSeqTypeList(!0), this.initRedDot();
            }, n.detached = function() {
                t.prototype.detached.call(this), this.cancelListenMigrateCrashDraft();
            }, n.show = function() {
                this.getCopySeqNum(), this.getOfficialAccount(), this.listenMigrateCrashDraft();
            }, n.hide = function() {
                this.cancelListenMigrateCrashDraft();
            }, n.handleTapLogin = function(t) {
                this.triggerEvent("login");
            }, n.handleToggleMenuStatus = function(t) {
                var e = t.currentTarget.dataset.isExpanded;
                this.triggerEvent("toggle", {
                    isExpanded: e
                });
            }, n.refreshDataWhenGroupChange = function() {
                var t = this.monoCommonService.getGroupType(Number(this.data.groupType));
                this.setData({
                    groupTypeObj: t
                }), this.getSeqTypeList(!0), this.getCanUseSeqTemplateFeature(), this.getOfficialAccount(), 
                this.listenMigrateCrashDraft();
            }, e = o.__decorate([ r.wxComponent(), o.__metadata("design:paramtypes", [ a.MonoCommonService ]) ], e);
        }(u.miniMixin(s.PublishTypeModalMixin, i.SuperComponent));
    }
}, [ [ 764, 0, 2, 1 ] ] ]));