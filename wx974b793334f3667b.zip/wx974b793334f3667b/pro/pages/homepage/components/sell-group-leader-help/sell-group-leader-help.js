var e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
};

require("./../../../../../runtime"), require("./../../../../../mono"), require("./../../../../../common"), 
function(e, o) {
    for (var t in o) e[t] = o[t];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 561 ], {
    2: function(o, t) {
        var i;
        i = function() {
            return this;
        }();
        try {
            i = i || new Function("return this")();
        } catch (o) {
            "object" == ("undefined" == typeof window ? "undefined" : e(window)) && (i = window);
        }
        o.exports = i;
    },
    752: function(e, o, t) {
        var i;
        Object.defineProperty(o, "__esModule", {
            value: !0
        });
        var r = t(0), a = t(4), n = t(1), s = t(5), p = t(10), u = t(14), d = t(20), m = t(15), c = t(26), h = ((i = {}).helpMeLeaders = "帮卖团长", 
        i.leaders = "帮卖团长", i.fans = "成员", i), g = {
            groupId: {
                type: String
            },
            groupType: {
                type: Number
            },
            disableFetch: Boolean,
            viewType: String,
            groupAvatarList: Array,
            groupSum: Number,
            groupRedNum: Number,
            canFansShare: Boolean,
            refresh: {
                type: Boolean,
                observer: function(e, o) {
                    if (e !== o) {
                        var t = this.data.viewType;
                        "leaders" !== t && "helpMeLeaders" !== t || this.getLeadersData(), this.getLeaderPermit();
                    }
                }
            },
            adminRights: Array,
            isShowSupplyLeader2leaderCommissionSettingTips: Boolean
        };
        !function(e) {
            function o(o, t, i, r, a) {
                var n = e.call(this) || this;
                return n.routeService = o, n.apiService = t, n.monoCommonService = i, n.commonService = r, 
                n.homepageService = a, n.properties = g, n.data = {
                    viewTypeText: h
                }, n;
            }
            r.__extends(o, e);
            var t = o.prototype;
            t.handleTapGoToHelpSaleImPage = function() {
                var e = this, o = this.data, t = o.groupId, i = o.groupType;
                this.homepageService.judgedHaveAdminRights(this.data.groupId).subscribe(function(o) {
                    var r = e.monoCommonService.hasAdminRights(4010, o), a = e.monoCommonService.hasAdminRights(80010, o);
                    r ? a && (e.routeService.goHomeGroupHelpSaleHelpSaleLeadersIm({
                        data: {
                            groupId: t,
                            groupType: i
                        }
                    }), e.closeSupplyLeader2leaderCommissionSettingTips()) : e.commonService.showHasNotRightsModel();
                });
            }, t.handleTapGoFansImPage = function() {
                this.routeService.goHomeFansManagementNew({
                    data: {
                        groupId: this.data.groupId,
                        groupType: this.data.groupType,
                        canShare: this.data.canFansShare
                    }
                });
            }, t.handleCloseSupplyLeader2leaderCommissionSettingTips = function() {
                this.closeSupplyLeader2leaderCommissionSettingTips();
            }, t.getLeadersData = function() {
                var e = this;
                if (!this.data.disableFetch) {
                    var o = this.data, t = o.groupId;
                    o.viewType, this.apiService.queryRelationHeadInfoUsingGET(t, u.skipMarkOption).subscribe(function(o) {
                        var t = o.data || {};
                        e.use().set("groupSum", t.helpSaleNum || 0), e.use().set("groupRedNum", t.unReadMessage || 0), 
                        e.use().set("groupAvatarList", t.logoUrls || []);
                    });
                }
            }, t.getLeaderPermit = function() {
                var e = this;
                "fans" !== this.data.viewType ? this.homepageService.judgedHaveAdminRights(this.data.groupId).subscribe(function(o) {
                    var t = e.monoCommonService.hasAdminRights(80010, o);
                    e.setData({
                        isShowSupplyLeaderViewLeader: t
                    });
                }) : this.setData({
                    isShowSupplyLeaderViewLeader: !0
                });
            }, t.closeSupplyLeader2leaderCommissionSettingTips = function() {
                this.triggerEvent("closeTip");
            }, o = r.__decorate([ n.wxComponent(), r.__metadata("design:paramtypes", [ p.RouteService, s.DefaultService, d.MonoCommonService, m.CommonService, c.HomepageService ]) ], o);
        }(a.SuperComponent);
    }
}, [ [ 752, 0, 2, 1 ] ] ]));