var e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
};

require("./../../../../../runtime"), require("./../../../../../mono"), require("./../../../../../common"), 
function(e, t) {
    for (var a in t) e[a] = t[a];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 564 ], {
    2: function(t, a) {
        var o;
        o = function() {
            return this;
        }();
        try {
            o = o || new Function("return this")();
        } catch (t) {
            "object" == ("undefined" == typeof window ? "undefined" : e(window)) && (o = window);
        }
        t.exports = o;
    },
    737: function(e, t, a) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var o = a(0), i = a(4), r = a(1), n = a(10), s = a(5), d = a(16), p = a(9), u = a(21), l = a(17), c = {
            disableFetch: Boolean,
            isShowEntranceIntro: Boolean,
            groupId: String,
            groupType: Number,
            groupName: String,
            userAvatar: String,
            refresh: {
                type: Boolean,
                observer: function(e, t) {
                    e !== t && (this.getSelectionLeaderInfoList(), this.getSupplyLeaderUnreadImNum());
                }
            },
            isHideInSuperPage: Boolean,
            isShowHomeSetVerifyTips: Boolean,
            isShowAfterSalesAuthGuide: Boolean
        };
        !function(e) {
            function t(t, a, o) {
                var i = e.call(this) || this;
                return i.routeService = t, i.apiService = a, i.grayService = o, i.options = {
                    multipleSlots: !0
                }, i.properties = c, i.data = {
                    avatarNum: 5
                }, i;
            }
            o.__extends(t, e);
            var a = t.prototype;
            a.attached = function() {
                e.prototype.attached.call(this), this.data.disableFetch || this.getAfterSaleAddressRedDot();
            }, a.ready = function() {
                e.prototype.ready.call(this);
            }, a.handleGoProfileHomepageSettings = function() {
                this.closeCanSetAfterSalesAddressTips();
                var e = this.data, t = e.groupId, a = e.groupType;
                this.routeService.goProfileHomepageSettings({
                    data: {
                        groupId: t,
                        groupType: a
                    }
                });
            }, a.handleTapAuthRealNameAndAip = function() {
                this.triggerEvent("tapAuthRealNameAndAip");
            }, a.handleCloseHomeSetVerifyTips = function() {}, a.handleTapSelectionLeader = function() {
                this.triggerEvent("closeASAuthGuide"), this.routeService.goHomeHomepageSupplyLeaders({
                    data: {
                        groupId: this.data.groupId
                    }
                });
            }, a.handleTapCloseAfterSalesAuthGuide = function() {
                this.triggerEvent("closeASAuthGuide");
            }, a.handleTapCloseCanSetAfterSalesAddressTips = function() {
                this.closeCanSetAfterSalesAddressTips();
            }, a.getSelectionLeaderInfoList = function() {
                var e = this, t = {
                    latestNum: 5,
                    supplyCompanyId: this.data.groupId
                };
                this.apiService.queryLatestSupplyGhAvatarListAndGhNumGhomeRelationUsingPOST(t).subscribe(function(t) {
                    var a = t.data, o = a.supplyGhAvatarRespList, i = void 0 === o ? [] : o, r = a.supplyGhNum, n = void 0 === r ? 0 : r;
                    e.setData({
                        supplyGhAvatarRespList: i,
                        supplyGhNum: n
                    });
                });
            }, a.getSupplyLeaderUnreadImNum = function() {
                var e = this;
                this.apiService.querySupplyGhUnreadNumGhomeRelationUsingGET(this.data.groupId).subscribe(function(t) {
                    var a = t.data, o = void 0 === a ? 0 : a;
                    e.setData({
                        supplyLeaderUnreadImNum: o
                    });
                });
            }, a.closeCanSetAfterSalesAddressTips = function() {
                this.data.isShowCanSetAfterSalesAddressTips && (this.setData({
                    isShowCanSetAfterSalesAddressTips: !1
                }), this.markReadRedDotByUid([ {
                    code: 2079
                } ]));
            }, a.getAfterSaleAddressRedDot = function() {
                var e = this;
                this.grayService.canIUseFeatureHybridDimension([ {
                    code: "2559",
                    type: l.GrayFeatureCodeDimension.GROUP
                } ], {
                    groupId: this.data.groupId
                }).subscribe(function(t) {
                    o.__read(t, 1)[0] && e.getRedDotAndSetData([ {
                        code: 2079
                    } ]);
                });
            }, o.__decorate([ d.Toggle("isClosedHomeSetVerifyTips", !0), o.__metadata("design:type", Function), o.__metadata("design:paramtypes", []), o.__metadata("design:returntype", void 0) ], t.prototype, "handleGoProfileHomepageSettings", null), 
            o.__decorate([ d.Toggle("isClosedHomeSetVerifyTips", !0), o.__metadata("design:type", Function), o.__metadata("design:paramtypes", []), o.__metadata("design:returntype", void 0) ], t.prototype, "handleCloseHomeSetVerifyTips", null), 
            t = o.__decorate([ r.wxComponent(), o.__metadata("design:paramtypes", [ n.RouteService, s.DefaultService, l.GrayFeatureService ]) ], t);
        }(p.miniMixin(u.NewRedDotMixin, i.SuperComponent));
    }
}, [ [ 737, 0, 2, 1 ] ] ]));