var e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
};

require("./../../../../../runtime"), require("./../../../../../mono"), require("./../../../../../common"), 
function(e, a) {
    for (var t in a) e[t] = a[t];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 559 ], {
    2: function(a, t) {
        var i;
        i = function() {
            return this;
        }();
        try {
            i = i || new Function("return this")();
        } catch (a) {
            "object" == ("undefined" == typeof window ? "undefined" : e(window)) && (i = window);
        }
        a.exports = i;
    },
    751: function(e, a, t) {
        Object.defineProperty(a, "__esModule", {
            value: !0
        });
        var i = t(0), r = t(4), o = t(14), n = t(1), s = t(5), d = t(109), p = t(6), u = t(10), c = t(20), g = t(9), l = t(21), m = t(30), h = t(15), v = t(17), S = t(16), y = t(13), f = t(26), T = t(7), B = {
            disableFetch: Boolean,
            panelList: {
                type: Array,
                value: [],
                observer: function(e, a) {
                    (null == e ? void 0 : e.length) && this.setData({
                        cardList: e,
                        cardIdList: e.map(function(e) {
                            return e.id;
                        })
                    });
                }
            },
            groupId: {
                type: String
            },
            adminRights: Array,
            useStatus: {
                type: Number
            },
            groupType: {
                type: Number,
                observer: function(e, a) {
                    e && this.setData(this.monoCommonService.getGroupType(e));
                }
            },
            fakeRoleType: Number,
            isFakeHelp: Boolean,
            isFakeSupply: Boolean,
            panelStyle: String,
            isRelationLeader: Boolean,
            newFansMsg: Number,
            agentMessageCount: Number,
            isNewUserHasTwoAct: Boolean,
            relatedLeaderAmount: Number,
            relatedBrandAmount: Number,
            isFinishedBrandHomepageBasicGuide: Boolean,
            isShowLeaderFissionBackendTip: Boolean,
            isShowPublishEvaluationEnter: Boolean,
            isShowSeqMaterialLibraryHomeTip: Boolean,
            isShowOrderMergeTips: Boolean
        };
        !function(e) {
            function a(a, t, i, r, o, n, s, d, p) {
                var u = e.call(this) || this;
                return u.monoCommonService = a, u.useTimeService = t, u.monoRedDotService = i, u.apiService = r, 
                u.utils = o, u.routeService = n, u.commonService = s, u.grayService = d, u.homepageService = p, 
                u.properties = B, u.data = {
                    cardList: [],
                    cardIdList: [],
                    newBrandGuideStep: 1
                }, u;
            }
            i.__extends(a, e);
            var t = a.prototype;
            t.ready = function() {
                e.prototype.ready.call(this);
                var a = this.data, t = a.disableFetch, i = a.isAllBrand, r = (a.isLeader, a.isBrand);
                !t && i && (this.getBrandHomepageGuideRedDot(), r && this.getBrandHomepageGoodsSpreadGuideRedDot()), 
                this.getCanIUsePanelItems();
            }, t.handleClickNavigateBtn = function(e) {
                var a = this, t = e.currentTarget.dataset.item, r = e.currentTarget.dataset.icon, o = t.url;
                this.triggerEvent("tapPanel", r), o && this.homepageService.judgedHaveAdminRights(this.data.groupId).subscribe(function(e) {
                    var n = a.monoCommonService.hasAdminRights(3e3, e), s = a.monoCommonService.hasAdminRights(4e3, e), d = a.monoCommonService.hasAdminRights(1020, e);
                    "/ss/app/image/plus/money25.svg" === r && !n || "/ss/app/image/plus/data08.svg" === r && !s || "/ss/app/image/plus/order10.svg" === r && !d || "/ss/app/image/plus/money26.svg" === r && !d ? a.commonService.showHasNotRightsModel() : a.homepageService.makeOrderSplitGrayGhViewTypeObs({
                        isFakeSupply: a.data.isFakeSupply,
                        isFakeHelp: a.data.isFakeHelp
                    }).subscribe(function(e) {
                        var n = a.data, s = n.groupId, d = n.groupType, p = n.isFakeSupply, u = Object.assign({
                            groupId: s,
                            groupType: d,
                            ghViewType: e,
                            orderNoticeIsFakeSupply: p
                        }, t.params);
                        if ("/ss/app/image/plus/data08.svg" !== r) {
                            if (2 === t.id && a.triggerEvent("closeOrderMergeTips"), 20 === t.id) return a.setNavParams(u, d), 
                            void a.utils.navigateTo(o, u);
                            a.utils.navigateTo(o, u);
                        } else T.forkJoin([ a.grayService.canIUseFeatureByMultiply([ "2185" ]), a.homepageService.getCanUseDataAnalysisV2(d) ]).subscribe(function(e) {
                            var t = i.__read(e, 2), r = i.__read(t[0], 1)[0];
                            i.__read(t[1], 1)[0] ? a.homepageService.goToNewDataAnalyseWithGray(s, d) : (r && (o = "/pro/pages/data-analyse/data-analyse-leader-v2/data-analyse-leader"), 
                            a.utils.navigateTo(o, u));
                        });
                    });
                });
            }, t.setNavParams = function(e, a) {
                var t;
                if (e.selectedTags = "待退款", void 0 !== a) {
                    var i = ((t = {})[10] = o.LeaderOrderManagePageType.BRAND, t[70] = o.LeaderOrderManagePageType.BRAND, 
                    t[20] = o.LeaderOrderManagePageType.LEADER, t[80] = o.LeaderOrderManagePageType.LEADER, 
                    t[90] = o.LeaderOrderManagePageType.LEADER, t[105] = o.LeaderOrderManagePageType.LEADER, 
                    t[110] = o.LeaderOrderManagePageType.SUPPLY_BRAND, t);
                    e.pageType = i[a];
                }
            }, t.handleTapHideSeqModal = function() {
                this.setData({
                    isShowSeqModal: !1
                });
            }, t.handleNavGoAgentMessageList = function() {
                var e = this.data, a = e.groupId, t = e.groupType;
                this.routeService.goHomeAgentHomeHomeAgentMessageList({
                    data: {
                        groupId: a,
                        groupType: t
                    }
                });
            }, t.handleTapBrandGuideNextStep = function() {
                1 === this.data.newBrandGuideStep ? this.setData({
                    newBrandGuideStep: 2
                }) : (this.setData({
                    isShowNewBrandGroupGuide: !1,
                    newBrandGuideStep: 1
                }), this.triggerEvent("showBrandHomepageGuide"));
            }, t.handleTapCloseBrandGoodsSpreadGuide = function() {
                var e = this.data.groupId;
                this.markReadRedDotByGroupId([ {
                    groupId: e,
                    code: 1025
                } ]);
            }, t.handleCloseRecomCommissionFeeTip = function() {
                this.triggerEvent("closeRecomCommissionFeeTip");
            }, t.handleCloseSeqMaterialLibraryHomeTip = function() {
                this.triggerEvent("closeSeqMaterialLibraryHomeTip");
            }, t.handleTapCloseMergeTips = function() {
                this.triggerEvent("closeOrderMergeTips");
            }, t.forbidPublish = function() {
                return this.isPremiumExpired() || this.isTrialExpired();
            }, t.isPremiumExpired = function() {
                return 4 === this.data.useStatus;
            }, t.isTrialExpired = function() {
                return 3 === this.data.useStatus;
            }, t.getBrandHomepageGuideRedDot = function() {
                var e = this, a = this.data.groupId;
                this.getRedDotByGroupIdAndSetData([ {
                    groupId: a,
                    code: 36
                } ], function() {
                    var a = e.data.isShowNewBrandGroupGuide;
                    e.setData({
                        isFinishedBrandHomepageBasicGuide: !a
                    });
                });
            }, t.getBrandHomepageGoodsSpreadGuideRedDot = function() {
                var e = this, a = this.data.groupId;
                this.getRedDotByGroupIdAndSetData([ {
                    groupId: a,
                    code: 1025
                } ], function() {
                    e.data.isShowBrandGoodsSpreadGuide && e.checkBrandHasGoodsSpread();
                });
            }, t.checkBrandHasGoodsSpread = function() {
                var e = this, a = this.data.groupId;
                this.apiService.queryExitGhGhoMemajorUsingGET(a, y.skipToastAndMarkOptions).subscribe(function(a) {
                    var t = a.data, i = void 0 !== t && t;
                    e.setData({
                        isBrandHasGoodsSpread: i
                    });
                });
            }, t.getCanIUsePanelItems = function() {
                var e = this;
                this.grayService.canIUseFeatureByMultiply([ "2172" ]).subscribe(function(a) {
                    var t = i.__read(a, 1)[0];
                    e.setData({
                        canIUseLeaderHelp: t
                    });
                });
            }, i.__decorate([ S.Toggle("isShowBrandGoodsSpreadGuide", !1), i.__metadata("design:type", Function), i.__metadata("design:paramtypes", []), i.__metadata("design:returntype", void 0) ], a.prototype, "handleTapCloseBrandGoodsSpreadGuide", null), 
            a = i.__decorate([ n.wxComponent(), i.__metadata("design:paramtypes", [ c.MonoCommonService, d.HomepageUseTimeService, m.MonoRedDotService, s.DefaultService, p.UtilService, u.RouteService, h.CommonService, v.GrayFeatureService, f.HomepageService ]) ], a);
        }(g.miniMixin(l.NewRedDotMixin, r.SuperComponent));
    }
}, [ [ 751, 0, 2, 1 ] ] ]));