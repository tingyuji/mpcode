var e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
};

require("./../../../runtime"), require("./../../../mono"), require("./../../../common"), 
function(e, t) {
    for (var i in t) e[i] = t[i];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 82 ], {
    2: function(t, i) {
        var n;
        n = function() {
            return this;
        }();
        try {
            n = n || new Function("return this")();
        } catch (t) {
            "object" == ("undefined" == typeof window ? "undefined" : e(window)) && (n = window);
        }
        t.exports = n;
    },
    712: function(e, t, i) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var n = i(0), o = i(8), r = i(1), a = i(6), s = i(158), u = i(17), c = i(323), d = i(9), l = i(24), p = i(12), f = i(19), v = [ "/pro/pages/homepage/customer-homepage/customer-homepage" ];
        !function(e) {
            function t(t, i, n, o) {
                var r = e.call(this) || this;
                return r.utils = t, r.loginService = i, r.grayService = n, r.errorService = o, r.data = {}, 
                r.isBackPrevPage = !1, r;
            }
            n.__extends(t, e);
            var i = t.prototype;
            i.onLoad = function(t) {
                e.prototype.onLoad.call(this), this.init(t), this.checkHasNavbar(), t && (this.isBackPrevPage = "true" === t.backToPrevPage), 
                this.getUseGetWxAvatarAndNicknameMethod();
            }, i.onUnload = function() {
                e.prototype.onUnload.call(this);
            }, i.handleFormLogin = function(e, t) {
                var i = this.selectComponent("#loginForm").getUserNicknameAndAvatar(), n = i.userNickname, o = i.userAvatar;
                if (!n) return this.setErrorTips("昵称不能为空"), t();
                var r = {
                    avatarUrl: o,
                    nickName: n,
                    language: "zh_CN",
                    city: "",
                    country: "",
                    province: "",
                    gender: 0
                };
                this.updateUserInfoAndLogin({
                    userInfo: r
                }, r, !1);
            }, i.handleTapGetUserProfile = function(e) {
                var t = this;
                this.useUserProfile(e).subscribe(function(e) {
                    if ("userInfo" in e) {
                        var i = e, n = e.userInfo;
                        t.updateUserInfoAndLogin(i, n, !1);
                    }
                }, function(e) {
                    t.processProfileError(e, "001");
                });
            }, i.onGotUserInfo = function(e) {
                var t = e.detail, i = t.userInfo;
                i ? this.updateUserInfoAndLogin(t, i, !0) : wx.showToast({
                    title: "授权失败，请重新授权",
                    icon: "none",
                    mask: !1
                });
            }, i.updateUserInfoAndLogin = function(e, t, i) {
                var n = this;
                void 0 === i && (i = !1);
                var o = function(e) {
                    var t, i = (null === (t = e.data) || void 0 === t ? void 0 : t.authorization) || 0;
                    n.utils.getApp().setStorage("authorization", i), p.rxwx.showToast({
                        title: "登录成功",
                        mask: !0,
                        duration: 800
                    }).subscribe(function() {
                        n.isBackPrevPage ? n.utils.navigateBack() : wx[n.data.navType || "redirectTo"]({
                            url: n.data.dirUrl
                        });
                    });
                };
                t && e ? (this.utils.setGlobalData("headimgurl", t.avatarUrl), this.utils.setGlobalData("nickname", t.nickName), 
                this.utils.setGlobalData("city", t.city), this.utils.setGlobalData("sex", t.gender), 
                this.loginService.wxAuthorized(e, i).subscribe(o)) : this.loginService.wxAuthorized(void 0, i).subscribe(o);
            }, i.init = function(e) {
                this.setPageStatus("SUCCESS"), this.setData({
                    dirUrl: decodeURIComponent(e.redirectUrl),
                    navType: e.navType
                });
            }, i.checkHasNavbar = function() {
                var e = this.utils.getPrevPage();
                if (e) {
                    var t = v.find(function(t) {
                        return t.indexOf(e.route || "") > -1;
                    });
                    this.setData({
                        isShowNavbar: void 0 === t
                    });
                }
            }, n.__decorate([ f.Lock(500), n.__metadata("design:type", Function), n.__metadata("design:paramtypes", [ Object, Function ]), n.__metadata("design:returntype", void 0) ], t.prototype, "handleFormLogin", null), 
            t = n.__decorate([ r.wxPage(), n.__metadata("design:paramtypes", [ a.UtilService, s.LoginService, u.GrayFeatureService, l.ErrorService ]) ], t);
        }(d.miniMixin(o.SuperPage, c.LoginMixin));
    }
}, [ [ 712, 0, 2, 1 ] ] ]));