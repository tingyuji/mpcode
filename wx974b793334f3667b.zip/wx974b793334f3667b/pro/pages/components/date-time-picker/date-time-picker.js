var e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
};

require("./../../../../runtime"), require("./../../../../mono"), require("./../../../../common"), 
function(e, t) {
    for (var r in t) e[r] = t[r];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 98 ], {
    2: function(t, r) {
        var i;
        i = function() {
            return this;
        }();
        try {
            i = i || new Function("return this")();
        } catch (t) {
            "object" == ("undefined" == typeof window ? "undefined" : e(window)) && (i = window);
        }
        t.exports = i;
    },
    741: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var i = r(0), a = r(4), n = r(1), o = r(18), u = r(44), m = r(24), s = {
            type: String,
            placeHolder: {
                type: String,
                value: "请选择时间"
            },
            placeHolderClass: {
                type: String,
                value: "text-bright"
            },
            value: {
                type: String,
                value: "emit_by_trigger",
                observer: function(e) {
                    "emit_by_trigger" !== e && (this.lastSelectTime = e, this.setData({
                        selectedTime: e
                    }));
                }
            },
            parentLimit: {
                type: Array,
                value: [],
                observer: function(e) {
                    if (e[0] && e[1]) {
                        var t = this.initTimePicker(), r = t.timePickerArray, i = t.selectedIndexList;
                        this.setData({
                            timePickerArray: r,
                            selectedIndexList: i
                        });
                    }
                }
            },
            clear: {
                type: Boolean,
                observer: function(e) {
                    e && this.clearValue();
                }
            },
            disabled: Boolean,
            dateTimeRange: {
                type: String,
                value: "DATE_TIME"
            },
            defaultTime: {
                type: String,
                optionalTypes: [ Number, Object ],
                value: "",
                observer: function(e) {
                    if (e && this.data.parentLimit && this.data.parentLimit.length) {
                        var t = this.initTimePicker(), r = t.timePickerArray, i = t.selectedIndexList;
                        this.setData({
                            timePickerArray: r,
                            selectedIndexList: i
                        });
                    }
                }
            }
        };
        !function(e) {
            function t(t, r) {
                var i = e.call(this) || this;
                return i.timeService = t, i.errorService = r, i.properties = s, i.data = {}, i.lastSelectTime = "", 
                i.defaultTimeArray = [], i;
            }
            i.__extends(t, e);
            var r = t.prototype;
            r.ready = function() {
                e.prototype.ready.call(this);
            }, r.changeDateTime = function(e) {
                var t = this;
                this.checkValidAndReport(e.detail.value);
                var r = this.formatTimeSelectResult(e.detail.value);
                this.lastSelectTime = r, "emit_by_trigger" === this.data.value ? this.setData({
                    selectedTime: r
                }, function() {
                    t.triggerEvent("changeTime", {
                        value: r
                    });
                }) : this.triggerEvent("changeTime", {
                    value: r
                });
            }, r.handleChangeColumn = function(e) {
                var t = this.data, r = t.selectedIndexList, i = t.timePickerArray;
                r[e.detail.column] = e.detail.value;
                var a = i.map(function(e, t) {
                    return e[r[t]];
                }), n = this.buildTimePickerArray(a);
                this.setData({
                    timePickerArray: n,
                    selectedIndexList: r
                });
            }, r.initTimePicker = function(e) {
                var t = this.getTimeArray(e || this.data.defaultTime || new Date());
                "start" !== this.data.type || this.data.defaultTime || (t[3] = 0, t[4] = 0), this.defaultTimeArray = t;
                var r = this.buildTimePickerArray();
                return {
                    timePickerArray: r,
                    selectedIndexList: r.map(function(e, r) {
                        var i = e.indexOf(t[r]);
                        return -1 === i ? e.length - 1 : i;
                    })
                };
            }, r.clearValue = function() {
                this.lastSelectTime = "", this.setData({
                    selectedTime: ""
                });
            }, r.buildTimePickerArray = function(e) {
                var t = [], r = i.__read(e || this.defaultTimeArray, 4), a = r[0], n = r[1], o = r[2], u = r[3], m = this.data.dateTimeRange, s = "DATE" === m || "DATE_TIME" === m, h = "DATE_TIME" === m;
                return t.push(this.getAndFilterNumArray("year")), t.push(this.getAndFilterNumArray("month", {
                    year: a
                })), s && t.push(this.getAndFilterNumArray("date", {
                    year: a,
                    month: n
                })), h && (t.push(this.getAndFilterNumArray("hour", {
                    year: a,
                    month: n,
                    date: o
                })), t.push(this.getAndFilterNumArray("minus", {
                    year: a,
                    month: n,
                    date: o,
                    hour: u
                }))), t;
            }, r.getLoopArray = function(e, t) {
                void 0 === e && (e = 0), void 0 === t && (t = 1);
                for (var r = [], i = e; i <= t; i++) r.push(i);
                return r;
            }, r.getAndFilterNumArray = function(e, t) {
                var r, i = this.getDateLimit(), a = i.maxYear, n = i.maxMonth, o = i.maxDate, u = i.maxHour, m = i.maxMinus, s = i.minYear, h = i.minMonth, l = i.minDate, c = i.minHour, d = i.minMinus;
                if (t) {
                    var y = t.year, p = t.month, f = t.date, g = t.hour, v = y === a && y === s, A = v && p === n && p === h, T = A && f === o && f === l, b = T && g === u && g === c, x = y >= a, D = y <= s, S = x && p >= n, _ = D && p <= h, L = S && f >= o, k = _ && f <= l, M = L && g >= u, E = k && g <= c, N = ((r = {}).month = [ e, v, x, D, n, h ], 
                    r.date = [ e, A, S, _, o, l, {
                        year: y,
                        month: p
                    } ], r.hour = [ e, T, L, k, u, c ], r.minus = [ e, b, M, E, m, d ], r);
                    return this.applyFilterStratas.apply(this, N[e]);
                }
                return this.getLoopArray(s, a);
            }, r.applyFilterStratas = function(e, t, r, i, a, n, o) {
                var u, m = ((u = {}).month = {
                    only: [ n, a ],
                    max: [ 1, a ],
                    min: [ n, 12 ],
                    other: [ 1, 12 ]
                }, u.date = {
                    only: [ n, a ],
                    max: [ 1, a ]
                }, u.hour = {
                    only: [ n, a ],
                    max: [ 0, a ],
                    min: [ n, 23 ],
                    other: [ 0, 23 ]
                }, u.minus = {
                    only: [ n, a ],
                    max: [ 0, a ],
                    min: [ n, 59 ],
                    other: [ 0, 59 ]
                }, u);
                if (t) return this.getLoopArray.apply(this, m[e].only);
                if (r) return this.getLoopArray.apply(this, m[e].max);
                if (i) {
                    if ("date" === e) {
                        var s = this.getFullMonthDay(o.year, o.month).pop();
                        return this.getLoopArray(n, s);
                    }
                    return this.getLoopArray.apply(this, m[e].min);
                }
                return "date" === e ? this.getFullMonthDay(o.year, o.month) : this.getLoopArray.apply(this, m[e].other);
            }, r.getDateLimit = function() {
                var e = this.data.parentLimit, t = this.matchDate(e[1]), r = t.year, i = t.month, a = t.date, n = t.hour, o = t.minus, u = this.matchDate(e[0]);
                return {
                    maxYear: r,
                    maxMonth: i,
                    maxDate: a,
                    maxHour: n,
                    maxMinus: o,
                    minYear: u.year,
                    minMonth: u.month,
                    minDate: u.date,
                    minHour: u.hour,
                    minMinus: u.minus
                };
            }, r.matchDate = function(e) {
                var t = ("DATE_TIME" === this.data.dateTimeRange ? /^([0-9]{4})-([0-9]{2})-([0-9]{2})\s([0-9]{2}):([0-9]{2})/ : /^([0-9]{4})-([0-9]{2})-([0-9]{2})/).exec(e);
                return {
                    year: Number(t[1]),
                    month: Number(t[2]),
                    date: Number(t[3]),
                    hour: Number(t[4]),
                    minus: Number(t[5])
                };
            }, r.getFullMonthDay = function(e, t) {
                var r = e % 400 == 0 || e % 4 == 0 && e % 100 != 0, i = this.getLoopArray.bind(this);
                return [ 1, 3, 5, 7, 8, 10, 12 ].includes(Number(t)) ? i(1, 31) : [ 4, 6, 9, 11 ].includes(Number(t)) ? i(1, 30) : i(1, r ? 29 : 28);
            }, r.getTimeArray = function(e) {
                var t = this.timeService.newDate(e);
                return [ t.getFullYear(), t.getMonth() + 1, t.getDate(), t.getHours(), t.getMinutes() ];
            }, r.formatTimeSelectResult = function(e) {
                var t = this, r = this.data.timePickerArray.map(function(r, i) {
                    return String(t.timeService.timeNum(r[e[i]]));
                }), i = [ "-", "-", " ", ":" ];
                return r.reduce(function(e, t) {
                    return e + i.shift() + t;
                });
            }, r.checkValidAndReport = function(e) {
                var t = this, r = this.data, i = r.timePickerArray, a = r.dateTimeRange;
                if ("DATE" === a || "DATE_TIME" === a) {
                    var n = i.map(function(r, i) {
                        return String(t.timeService.timeNum(r[e[i]]));
                    }), o = n[0] + "-" + n[1] + "-" + n[2];
                    this.timeService.newDate(o).getDate() === Number(o.substring(o.length - 2)) || this.errorService.customReportError({
                        frontErrorCode: 21001,
                        extraInfo: {
                            selectedIndexList: e,
                            date: o
                        }
                    });
                }
            }, i.__decorate([ u.Debounce(50), i.__metadata("design:type", Function), i.__metadata("design:paramtypes", [ Object ]), i.__metadata("design:returntype", void 0) ], t.prototype, "handleChangeColumn", null), 
            t = i.__decorate([ n.wxComponent(), i.__metadata("design:paramtypes", [ o.TimeService, m.ErrorService ]) ], t);
        }(a.SuperComponent);
    }
}, [ [ 741, 0, 2, 1 ] ] ]));