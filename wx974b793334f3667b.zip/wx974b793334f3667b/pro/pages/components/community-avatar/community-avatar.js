var e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
};

require("./../../../../runtime"), require("./../../../../mono"), require("./../../../../common"), 
function(e, t) {
    for (var n in t) e[n] = t[n];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 90 ], {
    2: function(t, n) {
        var o;
        o = function() {
            return this;
        }();
        try {
            o = o || new Function("return this")();
        } catch (t) {
            "object" == ("undefined" == typeof window ? "undefined" : e(window)) && (o = window);
        }
        t.exports = o;
    },
    325: function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.referenceTypeEnum = void 0;
        var o, r = n(0), i = n(4), a = n(1), u = n(10), s = n(20), c = n(11);
        !function(e) {
            e.HOME_PAGE = "HOME_PAGE", e.DETAIL_MODAL = "DETAIL_MODAL";
        }(o = t.referenceTypeEnum || (t.referenceTypeEnum = {}));
        var p = {
            tagList: Array,
            user: {
                type: Object,
                observer: function(e) {
                    this.renderWhenUserChange(e);
                }
            },
            quickContactList: Array,
            isAdminOrCreator: Boolean,
            verifyResult: Number,
            groupId: String,
            groupType: Number,
            isSubscribe: Boolean,
            referenceType: String,
            isSwitch: {
                type: Boolean,
                value: !1
            },
            isHomeSubjectAuthed: Boolean
        };
        !function(e) {
            function t(t, n, r) {
                var i = e.call(this) || this;
                return i.routeService = t, i.monoCommonService = n, i.monoUtilService = r, i.properties = p, 
                i.data = {
                    referenceTypeEnum: o
                }, i;
            }
            r.__extends(t, e);
            var n = t.prototype;
            n.handleWatchMoreMessage = function() {
                this.data.referenceType !== o.DETAIL_MODAL && this.triggerEvent("openDetailModal");
            }, n.handleTapInviteEvent = function() {
                this.data.referenceType !== o.DETAIL_MODAL && this.triggerEvent("tapInvite");
            }, n.handleTapPositionEvent = function() {
                if (this.data.referenceType !== o.DETAIL_MODAL) {
                    var e = this.data.user, t = e.lat, n = e.lon, r = e.position, i = void 0 === r ? "" : r, a = e.positionDetail, u = void 0 === a ? "" : a;
                    wx.openLocation({
                        latitude: t || 0,
                        longitude: n || 0,
                        name: i,
                        address: u
                    });
                }
            }, n.handleTapMemberListEvent = function() {
                this.data.isAdminOrCreator && this.routeService.goHomeFansManagementNew({
                    data: {
                        groupId: this.data.groupId,
                        groupType: this.data.groupType
                    }
                });
            }, n.renderWhenUserChange = function(e) {
                var t;
                if (e) {
                    var n = 37, o = e.introduce || "", r = this.monoCommonService.emojiStringLength(o), i = o.replace(RegExp("\\n", "g"), " "), a = r > n;
                    this.monoUtilService.isEmojiChar(i.substring(n - 1, n + 1)) && (n += 1);
                    var u = i.substring(0, n) + (a ? "..." : ""), s = (null === (t = e.memberHeadList) || void 0 === t ? void 0 : t.map(function(e) {
                        return e.mememberHeadUrl;
                    })) || [];
                    this.setData({
                        introduceStr: u,
                        isShowMoreIntroduceBtn: a,
                        memberImageList: s.slice(0, 5)
                    });
                }
            }, t = r.__decorate([ a.wxComponent(), r.__metadata("design:paramtypes", [ u.RouteService, s.MonoCommonService, c.MonoUtilService ]) ], t);
        }(i.SuperComponent);
    }
}, [ [ 325, 0, 2, 1 ] ] ]));