var e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
};

require("./../../../../runtime"), require("./../../../../mono"), require("./../../../../common"), 
function(e, t) {
    for (var a in t) e[a] = t[a];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 119 ], {
    2: function(t, a) {
        var i;
        i = function() {
            return this;
        }();
        try {
            i = i || new Function("return this")();
        } catch (t) {
            "object" == ("undefined" == typeof window ? "undefined" : e(window)) && (i = window);
        }
        t.exports = i;
    },
    678: function(e, t, a) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var i = a(0), o = a(1), n = a(4), r = a(29), s = a(22), d = a(37), p = {
            types: {
                type: Array,
                value: [ "图片", "视频" ]
            },
            medias: {
                type: Array,
                value: []
            },
            maxUploadMediaCount: {
                type: Number,
                value: 9
            },
            className: {
                type: String,
                value: ""
            },
            videoMaxDuration: {
                type: Number,
                value: 60
            },
            limitSelectedTime: Number,
            isOperate: {
                type: Boolean,
                value: !1
            },
            isShowModel: {
                type: Boolean,
                value: !0
            },
            isInteract: {
                type: Boolean,
                value: !1
            },
            canAddMedia: {
                type: Boolean,
                value: !0
            },
            useAddMediaSlot: {
                type: Boolean,
                value: !1
            },
            useStyleOnly: {
                type: Boolean,
                value: !1
            }
        };
        !function(e) {
            function t(t, a) {
                var i = e.call(this) || this;
                return i.fileService = t, i.scopeFileService = a, i.properties = p, i.data = {
                    medias: [],
                    resHost: s.config.resHost
                }, i;
            }
            i.__extends(t, e);
            var a = t.prototype;
            a.attached = function() {
                e.prototype.attached.call(this), this.data.isOperate && (this.setData({
                    isShowModel: !1
                }), this.handleUploadOrChangeMedia(0, 1));
            }, a.detached = function() {
                this.setData({
                    medias: [],
                    isOperate: !1
                }), this.triggerEvent("mediaschange", this.data.medias);
            }, a.handleTapUploadMedia = function() {
                this.data.useStyleOnly ? this.triggerEvent("tap-upload-media") : this.handleUploadOrChangeMedia(-1, this.data.maxUploadMediaCount - this.data.medias.length);
            }, a.handleTapChangeMedia = function(e) {
                var t = e.currentTarget.dataset.index;
                this.data.useStyleOnly ? this.triggerEvent("tap-replace-media", {
                    index: t
                }) : this.handleUploadOrChangeMedia(t, 1);
            }, a.handleDeleteMedia = function(e) {
                var t = e.currentTarget.dataset.index, a = this.data, i = a.medias;
                a.useStyleOnly ? this.triggerEvent("tap-remove-media", {
                    index: t
                }) : (i.splice(t, 1), this.triggerEvent("mediaschange", i));
            }, a.handleUploadOrChangeMedia = function(e, t) {
                var a = this;
                void 0 === t && (t = 9);
                var i = 1 === this.data.types.length, o = this.data.types[0];
                if (i) if ("图片" === o) {
                    var n = this.scopeFileService.uploadImages({
                        count: t
                    });
                    if (!n) return;
                    n.subscribe(function(t) {
                        a.processUploaded(t.map(function(e) {
                            return e.path;
                        }), e), a.setData({
                            isShowModel: !0
                        });
                    });
                } else "视频" === o && this.fileService.uploadVideo({
                    maxDuration: this.data.videoMaxDuration || 60
                }, {
                    videoMaxDuration: this.data.limitSelectedTime
                }).subscribe(function(t) {
                    a.processUploaded(t.path, e);
                }); else wx.showActionSheet({
                    itemList: this.data.types,
                    success: function(i) {
                        var o = i.tapIndex, n = a.data.types[o];
                        if ("图片" === n) {
                            var r = a.scopeFileService.uploadImages({
                                count: t
                            });
                            if (!r) return;
                            r.subscribe(function(t) {
                                a.processUploaded(t.map(function(e) {
                                    return e.path;
                                }), e);
                            });
                        } else "视频" === n && a.scopeFileService.uploadVideo({
                            maxDuration: a.data.videoMaxDuration || 60
                        }, {
                            videoMaxDuration: a.data.limitSelectedTime
                        }).subscribe(function(t) {
                            a.processUploaded(t.path, e);
                        });
                    }
                });
            }, a.processUploaded = function(e, t) {
                var a = i.__spread(this.data.medias);
                e = "string" == typeof e ? [ e ] : e, t < 0 ? a.push.apply(a, i.__spread(e)) : a[t] = e[0], 
                this.triggerEvent("mediaschange", a);
            }, t = i.__decorate([ o.wxComponent(), i.__metadata("design:paramtypes", [ r.FileService, d.ScopeFileService ]) ], t);
        }(n.SuperComponent);
    }
}, [ [ 678, 0, 2, 1 ] ] ]));