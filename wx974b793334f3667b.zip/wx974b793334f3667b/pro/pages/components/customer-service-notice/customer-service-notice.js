var e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
};

require("./../../../../runtime"), require("./../../../../mono"), require("./../../../../common"), 
function(e, t) {
    for (var i in t) e[i] = t[i];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 97 ], {
    2: function(t, i) {
        var a;
        a = function() {
            return this;
        }();
        try {
            a = a || new Function("return this")();
        } catch (t) {
            "object" == ("undefined" == typeof window ? "undefined" : e(window)) && (a = window);
        }
        t.exports = a;
    },
    756: function(e, t, i) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var a = i(0), o = i(4), n = i(1), r = i(60), s = i(6), u = i(9), d = i(21), c = i(3), p = i(15), h = {
            disableFetch: Boolean,
            groupId: String,
            groupType: Number,
            groupName: {
                type: String,
                observer: function(e) {
                    this.setGroupName(e);
                }
            },
            channelType: Number,
            isHideInSuperPage: {
                type: Boolean,
                value: !1,
                observer: function(e) {
                    this.data.disableFetch || (e ? this.stopPollingUnreadStatus() : this.pollingUnreadStatus());
                }
            },
            hidePopup: Boolean,
            hideFloatWindow: Boolean,
            isShowEntranceIntro: Boolean,
            isStaticPos: {
                type: Boolean,
                value: !1
            },
            isCustom: {
                type: Boolean,
                value: !1
            },
            useDefaultAvatar: {
                type: Boolean,
                value: !1
            },
            hasPosition: {
                type: Boolean,
                value: !1
            }
        };
        !function(e) {
            function t(t, i, a) {
                var o = e.call(this) || this;
                return o.utilService = t, o.imService = i, o.commonService = a, o.properties = h, 
                o.data = {
                    unreadNum: 0,
                    msgQueue: []
                }, o.isNewGroup = !1, o.unreadNumFromApi = 0, o;
            }
            a.__extends(t, e);
            var i = t.prototype;
            i.ready = function() {
                var t = this;
                if (e.prototype.ready.call(this), !this.data.disableFetch) {
                    var i = this.data, a = i.groupId, o = i.groupType;
                    if (!a || !o) throw new Error("消息即服务组件必须传入groupId和groupType");
                    this.initPrivateCustomerServiceBasic(function() {
                        t.pollingUnreadStatus();
                    }), this.getFloatWindowRedDot();
                }
            }, i.detached = function() {
                e.prototype.detached.call(this), this.data.disableFetch || this.stopPollingUnreadStatus();
            }, i.setGroupName = function(e) {
                this.imService.setCurrentUserName(e);
            }, i.handleTapFloatWindow = function() {
                this.data.isCustom || this.data.unreadNum ? this.checkMessage() : this.commonService.goServiceCenter(this.data.groupId);
            }, i.handlePopupCheckout = function() {
                this.checkMessage();
            }, i.initPrivateCustomerServiceBasic = function(e) {
                var t = this, i = this.data, a = i.groupId, o = i.groupType, n = i.channelType;
                this.imService.getPrivateCustomerService(a, o, n).pipe(c.takeUntil(this.unloadObservable)).subscribe(function(i) {
                    i && (t.isNewGroup = i.isNewGroup, t.setData({
                        privateCustomerService: i
                    }, function() {
                        t.receiveNewUserMsg(i), e();
                    }));
                });
            }, i.pollingUnreadStatus = function() {
                var e = this, t = this.data, i = t.groupId, a = t.groupType, o = t.privateCustomerService;
                if (null == o ? void 0 : o.imAccountId) {
                    var n = 30 === a ? {
                        uid: this.utilService.getUid()
                    } : {
                        ghId: i
                    };
                    this.imService.pollingUnreadStatus(n, o.imAccountId).subscribe(function(t) {
                        if (t) {
                            var i = "ONLINE" === t.onlineStatus;
                            i !== e.data.isOnline && e.setData({
                                isOnline: i
                            }), e.receiveUnreadStatus(t);
                        }
                    });
                }
            }, i.stopPollingUnreadStatus = function() {
                this.imService.stopPollingUnreadStatus();
            }, i.handleAfterNoticeShowUp = function(e) {
                var t = e.currentTarget.dataset.index;
                this.isIndexOfLastMessage(t) && this.setData({
                    msgQueue: this.data.msgQueue.slice(-1)
                });
            }, i.handleNoticeHide = function(e) {
                var t = e.currentTarget.dataset.index;
                this.isIndexOfLastMessage(t) && this.clearMsgQueue();
            }, i.receiveNewUserMsg = function(e) {
                this.isNewGroup && (e.msg && !this.data.hidePopup ? this.pushNewMessage(e.msg) : this.updateUnreadAmount());
            }, i.receiveUnreadStatus = function(e) {
                var t = e.msg, i = e.unread;
                this.unreadNumFromApi === i && !t || (0 === i || this.data.hidePopup || !t ? this.updateUnreadAmount(i) : this.pushNewMessage(t), 
                this.unreadNumFromApi = i);
            }, i.pushNewMessage = function(e) {
                if (!this.data.hidePopup) {
                    var t = Array.from(e);
                    t.length > 28 && (e = t.slice(0, 28).join("") + "..."), this.use("msgQueue").push({
                        content: e,
                        timestamp: new Date().getTime()
                    }), this.customReport({
                        functionName: "showCustomerServiceNotice"
                    });
                }
            }, i.updateUnreadAmount = function(e) {
                var t = this.data.unreadNum, i = e || (this.isNewGroup ? 1 : 0);
                i > t && this.addUnreadDotWithAnimate(i - t), i < t && this.setData({
                    unreadNum: i
                });
            }, i.addUnreadDotWithAnimate = function(e) {
                var t = this;
                this.setData({
                    animateUnreadNum: e
                }, function() {
                    t.animate(".animate-spot", [ {
                        ease: "ease-in",
                        opacity: 0,
                        top: "-100%"
                    }, {
                        ease: "ease-in",
                        opacity: 1,
                        top: "-12rpx"
                    } ], 600), t.animate(".animate-wrap", [ {
                        ease: "linear",
                        opacity: 0,
                        left: "20%"
                    }, {
                        ease: "linear",
                        opacity: 1,
                        left: "50%"
                    } ], 600, function() {
                        t.clearAnimation(".animate-wrap");
                        var i = t.data.unreadNum;
                        t.setData({
                            unreadNum: i + e
                        });
                    });
                });
            }, i.isIndexOfLastMessage = function(e) {
                var t = this.data.msgQueue;
                return (null == t ? void 0 : t.length) === e + 1;
            }, i.checkMessage = function() {
                this.isNewGroup = !1, this.goChatPage(), this.clearMsgQueue();
            }, i.clearMsgQueue = function() {
                this.setData({
                    msgQueue: []
                }), this.updateUnreadAmount(this.unreadNumFromApi);
            }, i.goChatPage = function() {
                var e = this.data, t = e.groupId, i = e.groupType, o = e.privateCustomerService, n = 30 === i, r = a.__assign({
                    toId: null == o ? void 0 : o.imAccountId,
                    chatUserType: n ? "3" : "5"
                }, n ? null : {
                    fromId: t
                });
                this.markReadRedDotByGroupId([ {
                    code: 54,
                    groupId: this.data.groupId
                } ]), this.commonService.goCustomerServiceOrChatPage({
                    data: r,
                    isToChatPageDirectly: !!this.data.unreadNum
                });
            }, i.getFloatWindowRedDot = function() {
                var e = this.data, t = e.groupId;
                e.hideFloatWindow || this.getRedDotByGroupIdAndSetData([ {
                    code: 54,
                    groupId: t
                } ]);
            }, t = a.__decorate([ n.wxComponent(), a.__metadata("design:paramtypes", [ s.UtilService, r.ImService, p.CommonService ]) ], t);
        }(u.miniMixin(d.NewRedDotMixin, o.SuperComponent));
    }
}, [ [ 756, 0, 2, 1 ] ] ]));