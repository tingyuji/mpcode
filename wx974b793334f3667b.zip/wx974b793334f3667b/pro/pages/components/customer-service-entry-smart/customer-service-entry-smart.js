var t = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
    return typeof t;
} : function(t) {
    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
};

require("./../../../../runtime"), require("./../../../../mono"), require("./../../../../common"), 
function(t, e) {
    for (var i in e) t[i] = e[i];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 95 ], {
    2: function(e, i) {
        var r;
        r = function() {
            return this;
        }();
        try {
            r = r || new Function("return this")();
        } catch (e) {
            "object" == ("undefined" == typeof window ? "undefined" : t(window)) && (r = window);
        }
        e.exports = r;
    },
    784: function(t, e, i) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        });
        var r = i(0), o = i(4), a = i(1), n = i(5), s = i(6), u = i(3), c = i(11), f = i(13), d = i(27), p = i(17), h = i(327), l = i(9), m = i(60), v = {
            isForceToIm: Boolean,
            isForceToWx: Boolean,
            groupType: Number,
            actId: String,
            chatUserType: String,
            fromId: String,
            toId: String,
            seqType: Number,
            orderNo: String,
            pactId: String,
            extraParams: Object,
            customScene: {
                type: String,
                observer: function(t) {
                    this.setCustomScene(t);
                }
            },
            entranceScene: String
        };
        !function(t) {
            function e(e, i, r, o, a, n) {
                var s = t.call(this) || this;
                return s.apiService = e, s.imService = i, s.util = r, s.monoUtil = o, s.migrateService = a, 
                s.grayFeatureService = n, s.properties = v, s.data = {}, s;
            }
            r.__extends(e, t);
            var i = e.prototype;
            i.ready = function() {
                t.prototype.ready.call(this), this.validateRouterChatPageParams() && this.initData();
            }, i.validateRouterChatPageParams = function() {
                var t, e = this.data, i = e.toId, r = e.fromId, o = e.chatUserType;
                if (!o || "-1" === o) throw new Error("请完成数据初始化");
                if ("6" === o || "4" === o) throw new Error("IM登录异常");
                return ((t = {})[1] = !!r && !!i, t[5] = !!r, t[0] = !!r && !!Number(i), t[3] = !0, 
                t[2] = !!i, t)[o];
            }, i.initData = function() {
                var t = this.data.chatUserType;
                "5" === t ? this.setGroup2OfficialInitData() : "3" === t ? this.setUser2OfficialInitData() : "2" === t && this.setUser2GroupInitData(), 
                this.setGroupType();
            }, i.setGroup2OfficialInitData = function() {
                if (!this.data.toId) {
                    var t = this.data.fromId || "";
                    this.setToIdByOfficialId(t);
                }
            }, i.setUser2OfficialInitData = function() {
                var t = this, e = this.data, i = e.toId, r = e.fromId;
                if (i || this.imService.getPersonalGroupId().subscribe(function(e) {
                    t.setToIdByOfficialId(e);
                }), !r) {
                    var o = this.util.getLocalStorage("plus_uid");
                    this.setData({
                        fromId: o
                    });
                }
            }, i.setUser2GroupInitData = function() {
                if (!this.data.fromId) {
                    var t = this.util.getLocalStorage("plus_uid");
                    this.setData({
                        fromId: t
                    });
                }
            }, i.setToIdByOfficialId = function(t) {
                var e = this;
                t && this.getOfficialImId(t).subscribe(function(t) {
                    var i;
                    if (!t) {
                        var r = null === (i = e.util.getPage()) || void 0 === i ? void 0 : i.route, o = e.util.getUid();
                        e.throwCommonError({
                            frontErrorCode: 6001,
                            extraInfo: {
                                path: r,
                                uid: o
                            }
                        });
                    }
                    e.setData({
                        toId: String(t)
                    });
                });
            }, i.getOfficialImId = function(t) {
                return this.apiService.getBindingStaffIMV2UsingPOST({
                    ghId: t
                }).pipe(u.map(function(t) {
                    var e;
                    return null === (e = t.data) || void 0 === e ? void 0 : e.imAccountId;
                }));
            }, i.setGroupType = function() {
                var t = this, e = this.data, i = e.groupType, r = e.fromId, o = e.chatUserType;
                if (!i) {
                    var a = "1" === o || "5" === o || "0" === o ? r : "";
                    a ? this.apiService.getGhomeBaseInfoByGhIdUsingGET(a, f.skipErrorOptions).subscribe(function(e) {
                        var i;
                        t.setData({
                            groupType: null === (i = e.data) || void 0 === i ? void 0 : i.ghType
                        });
                    }) : this.setData({
                        groupType: 30
                    });
                }
            }, e = r.__decorate([ a.wxComponent(), r.__metadata("design:paramtypes", [ n.DefaultService, m.ImService, s.UtilService, c.MonoUtilService, d.BackendMigrateService, p.GrayFeatureService ]) ], e);
        }(l.miniMixin(o.SuperComponent, h.ChatCustomerServiceWxMixin));
    }
}, [ [ 784, 0, 2, 1 ] ] ]));