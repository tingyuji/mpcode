var t = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
    return typeof t;
} : function(t) {
    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
};

require("./../../../../runtime"), require("./../../../../mono"), require("./../../../../common"), 
function(t, e) {
    for (var n in e) t[n] = e[n];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 155 ], {
    2: function(e, n) {
        var o;
        o = function() {
            return this;
        }();
        try {
            o = o || new Function("return this")();
        } catch (e) {
            "object" == ("undefined" == typeof window ? "undefined" : t(window)) && (o = window);
        }
        e.exports = o;
    },
    788: function(t, e, n) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        });
        var o = n(0), i = n(1), r = n(7), a = n(3), c = n(4), s = n(6), u = n(14);
        !function(t) {
            function e(e) {
                var n = t.call(this) || this;
                return n.util = e, n.properties = {
                    duration: {
                        type: Number,
                        value: u.DURATION
                    },
                    content: {
                        type: String,
                        value: "",
                        observer: function(t) {
                            t && this.contentChange.next(t);
                        }
                    }
                }, n.data = {
                    visible: !1
                }, n;
            }
            o.__extends(e, t);
            var n = e.prototype;
            n.attached = function() {
                var t = this.util.getApp();
                this.setData({
                    navH: t.globalData.navHeight
                });
            }, n.created = function() {
                t.prototype.created.call(this), this.contentChange = new r.Subject(), this.contentObservable = this.contentChange.asObservable();
            }, n.ready = function() {
                var t = this;
                this.contentObservable.pipe(a.takeUntil(this.unloadObservable), a.tap(function(e) {
                    t.setData({
                        content: e,
                        visible: !0
                    });
                }), a.debounceTime(this.data.duration)).subscribe(function() {
                    t.setData({
                        visible: !1,
                        content: ""
                    }), t.triggerEvent("close");
                });
            }, e = o.__decorate([ i.wxComponent(), o.__metadata("design:paramtypes", [ s.UtilService ]) ], e);
        }(c.SuperComponent);
    }
}, [ [ 788, 0, 2, 1 ] ] ]));