var e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
};

require("./../../../../runtime"), require("./../../../../mono"), require("./../../../../common"), 
function(e, t) {
    for (var i in t) e[i] = t[i];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 83 ], {
    2: function(t, i) {
        var r;
        r = function() {
            return this;
        }();
        try {
            r = r || new Function("return this")();
        } catch (t) {
            "object" == ("undefined" == typeof window ? "undefined" : e(window)) && (r = window);
        }
        t.exports = r;
    },
    672: function(e, t, i) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var r = i(0), n = i(4), o = i(1), s = i(89), a = i(3), c = i(10), d = i(228), u = i(176), p = i(6), f = {
            routeOptions: Object,
            isRouteInComponent: Boolean,
            addressId: {
                type: Number,
                observer: function(e) {
                    this.data.addressId = e, this.initEvent();
                }
            }
        };
        !function(e) {
            function t(t, i, r, n) {
                var o = e.call(this) || this;
                return o.stateManagementService = t, o.orderPayService = i, o.routeService = r, 
                o.utilService = n, o.properties = f, o;
            }
            r.__extends(t, e);
            var i = t.prototype;
            i.ready = function() {
                e.prototype.ready.call(this), this.initEvent();
            }, i.handleTapGoAddressLibrary = function() {
                var e = this.data, t = e.isRouteInComponent, i = e.routeOptions, n = this.utilService.getLocalStorage("person_group_id");
                t ? this.routeService.goPublicPagesAddressLibrary(r.__assign(r.__assign({}, i), {
                    groupId: n
                })) : this.myTriggerEvent(d.AddressLibraryButtonEventNameMap.GO_LIBRARY, {
                    receiptInfoId: this.curReceiptId
                });
            }, i.initEvent = function() {
                this.initLogistics(), this.onSelectedAddressChange();
            }, i.initLogistics = function() {
                this.data.addressId && (this.curReceiptId = this.data.addressId), this.curReceiptId || (this.curReceiptId = this.stateManagementService.getNewPickupLocationId());
            }, i.onSelectedAddressChange = function() {
                var e = this;
                this.orderPayService.currentAddrObservable.pipe(a.filter(function(t) {
                    return t.receiptInfoId === e.curReceiptId;
                }), a.takeUntil(this.unloadObservable)).subscribe(function(t) {
                    e.myTriggerEvent(d.AddressLibraryButtonEventNameMap.SELECT_ADDRESS, t);
                });
            }, t = r.__decorate([ o.wxComponent(), r.__metadata("design:paramtypes", [ u.StateManagementService, s.OrderPayService, c.RouteService, p.UtilService ]) ], t);
        }(n.SuperComponent);
    }
}, [ [ 672, 0, 2, 1 ] ] ]));