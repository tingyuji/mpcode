var e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
};

require("./../../../../runtime"), require("./../../../../mono"), require("./../../../../common"), 
function(e, t) {
    for (var n in t) e[n] = t[n];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 125 ], {
    2: function(t, n) {
        var r;
        r = function() {
            return this;
        }();
        try {
            r = r || new Function("return this")();
        } catch (t) {
            "object" == ("undefined" == typeof window ? "undefined" : e(window)) && (r = window);
        }
        t.exports = r;
    },
    726: function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var r = n(0), o = n(4), i = n(1), s = n(43), c = {
            templateSceneArr: {
                type: Array,
                observer: function(e, t) {
                    e && this.getTemplateId(e);
                }
            }
        };
        !function(e) {
            function t(t) {
                var n = e.call(this) || this;
                return n.msgSubService = t, n.properties = c, n.data = {}, n.templateIdObj = [], 
                n;
            }
            r.__extends(t, e);
            var n = t.prototype;
            n.ready = function() {
                e.prototype.ready.call(this);
            }, n.getTemplateId = function(e) {
                var t = this;
                this.msgSubService.getTemplateIdByMultiply(e).subscribe(function(n) {
                    t.templateIdObj = e.map(function(e, t) {
                        return {
                            key: e,
                            templateId: n[t]
                        };
                    });
                });
            }, n.handleTapMessageSubscribe = function() {
                var e = this, t = this.msgSubService.canUseMultipleTempleId(), n = this.templateIdObj.map(function(e) {
                    return e.templateId;
                });
                0 !== n.length && (t ? this.msgSubService.requestSubscribeMessageWhenIsArr(n).subscribe(function(t) {
                    if (t.length) {
                        var n = t.map(function(t, n) {
                            return {
                                key: e.templateIdObj[n].key,
                                result: t.data
                            };
                        });
                        e.commonTriggerEvent("success", n);
                    } else e.commonTriggerEvent("fail"), e.errorProcessing(t);
                }, function() {
                    e.commonTriggerEvent("fail");
                }) : this.msgSubService.requestSubscribeMessage(n[0]).subscribe(function(t) {
                    var n = [ {
                        key: e.templateIdObj[0].key,
                        result: t.data
                    } ];
                    e.commonTriggerEvent("success", n);
                }, function() {
                    e.commonTriggerEvent("fail");
                }));
            }, n.commonTriggerEvent = function(e, t) {
                this.triggerEvent("subscribe", {
                    type: e,
                    data: t
                });
            }, n.errorProcessing = function(e) {
                20004 === Number(e.errCode) && wx.showModal({
                    title: "订阅失败",
                    content: "由于关闭了订阅通知总开关，该操作失败；若需要订阅，请点击确认前往设置打开开关",
                    success: function(e) {
                        e.confirm && wx.openSetting({});
                    }
                });
            }, t = r.__decorate([ i.wxComponent(), r.__metadata("design:paramtypes", [ s.MessageSubscribeService ]) ], t);
        }(o.SuperComponent);
    }
}, [ [ 726, 0, 2, 1 ] ] ]));