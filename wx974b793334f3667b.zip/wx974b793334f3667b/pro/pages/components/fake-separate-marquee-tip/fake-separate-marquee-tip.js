var t = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
    return typeof t;
} : function(t) {
    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
};

require("./../../../../runtime"), require("./../../../../mono"), require("./../../../../common"), 
function(t, e) {
    for (var i in e) t[i] = e[i];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 102 ], {
    2: function(e, i) {
        var o;
        o = function() {
            return this;
        }();
        try {
            o = o || new Function("return this")();
        } catch (e) {
            "object" == ("undefined" == typeof window ? "undefined" : t(window)) && (o = window);
        }
        e.exports = o;
    },
    778: function(t, e, i) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        });
        var o = i(0), a = i(1), n = i(4), r = i(6), s = i(17), l = i(50), u = i(7), c = {
            type: Number,
            title: String,
            styleStr: String,
            isAbsoluteTop: {
                type: Boolean,
                value: !1
            },
            placeholderHeight: {
                type: Number,
                value: 0
            },
            isClosable: {
                type: Boolean,
                value: !0
            },
            showHornIcon: {
                type: Boolean,
                value: !0
            },
            customLinkText: String,
            customBtnText: String,
            isStopMove: {
                type: Boolean,
                value: !1
            },
            isCustomShowDetail: Boolean
        };
        !function(t) {
            function e(e, i, o) {
                var a = t.call(this) || this;
                return a.wxCloudApiService = e, a.utils = i, a.grayService = o, a.properties = c, 
                a.options = {
                    multipleSlots: !0
                }, a.data = {}, a.isDetached = !1, a.route = "", a;
            }
            o.__extends(e, t), i = e;
            var i, n = e.prototype;
            n.attached = function() {
                t.prototype.attached.call(this), this.initTextConfig();
            }, n.ready = function() {
                t.prototype.ready.call(this);
            }, n.detached = function() {
                this.isDetached = !0;
            }, n.handleTapCloseTip = function() {
                this.route && i.routeClosedList.push(this.route), this.setData({
                    title: ""
                }), this.triggerEvent("close");
            }, n.handleTapTextLink = function() {
                this.triggerEvent("chain");
            }, n.handleTapCustomBtn = function() {
                this.triggerEvent("btnClick");
            }, n.handleTapShowDetail = function() {
                if (this.data.isCustomShowDetail) this.triggerEvent("showDetail"); else {
                    var t = this.data.title;
                    wx.showModal({
                        title: "",
                        content: "" + t,
                        showCancel: !1
                    });
                }
            }, n.initTextConfig = function() {
                var t = this;
                if (!this.data.title) {
                    var e = this.data.type;
                    (e ? this.wxCloudApiService.getFakeSeparateMarqueeText(void 0, {
                        useStorageOptions: {
                            isUseCache: !0
                        }
                    }) : this.wxCloudApiService.getPageSeparateMarqueeText(void 0, {
                        useStorageOptions: {
                            isUseCache: !0
                        }
                    })).subscribe(function(i) {
                        if (void 0 === i && (i = {}), !t.isDetached && i.data) if (e) {
                            var o = i.data[e] || "";
                            t.setData({
                                title: o
                            });
                        } else t.handleRouteConfig(i.data);
                    });
                }
            }, n.handleRouteConfig = function(t) {
                var e, o = this, a = (null === (e = this.utils.getPage()) || void 0 === e ? void 0 : e.route) || "";
                if (-1 === i.routeClosedList.indexOf(a)) {
                    var n = t[a] || {}, r = n.title || "";
                    n.isShow && r && (n.grayCode ? this.grayService.canIUseFeature(n.grayCode) : u.of(!0)).subscribe(function(t) {
                        if (t) {
                            var e = n.style || "", i = n.top || 0;
                            o.setPlaceholderHeightWithRouteConfig(n), e = "top:" + (o.data.navHeight + i) + "px; " + o.data.styleStr + "; " + e, 
                            o.route = a, o.setData({
                                title: r,
                                styleStr: e
                            });
                        }
                    });
                }
            }, n.setPlaceholderHeightWithRouteConfig = function(t) {
                if (!this.data.placeholderHeight) {
                    var e = t.withPlaceholder ? t.placeholderHeight || 68 : 0;
                    this.setData({
                        placeholderHeight: e
                    });
                }
            }, e.routeClosedList = [], e = i = o.__decorate([ a.wxComponent(), o.__metadata("design:paramtypes", [ l.WxCloudApiService, r.UtilService, s.GrayFeatureService ]) ], e);
        }(n.SuperComponent);
    }
}, [ [ 778, 0, 2, 1 ] ] ]));