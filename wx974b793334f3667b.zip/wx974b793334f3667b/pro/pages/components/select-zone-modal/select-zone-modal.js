var e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
};

require("./../../../../runtime"), require("./../../../../mono"), require("./../../../../common"), 
function(e, t) {
    for (var n in t) e[n] = t[n];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 147 ], {
    2: function(t, n) {
        var o;
        o = function() {
            return this;
        }();
        try {
            o = o || new Function("return this")();
        } catch (t) {
            "object" == ("undefined" == typeof window ? "undefined" : e(window)) && (o = window);
        }
        t.exports = o;
    },
    724: function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var o = n(0), i = n(4), r = n(1), a = n(11), c = n(26), s = {
            title: {
                type: String,
                value: "请选择主页"
            },
            zoneList: {
                type: Array,
                value: [],
                observer: function(e) {
                    this.data.smart && 1 === e.length && this.autoSelect(e[0]);
                }
            },
            isUseProtectGh: Boolean,
            selectedItemIndex: null,
            canCloseModal: Boolean,
            isShowSupplyIconByFakeRole: Boolean,
            isShowSupplyIconByFakeRoleBoolKey: Boolean,
            showCancelBtn: Boolean,
            cancelText: String,
            smart: Boolean,
            confirmText: String,
            isExpired: Boolean,
            canShowExpiredText: Boolean,
            isBindRelationship: Boolean
        };
        !function(e) {
            function t(t, n) {
                var o = e.call(this) || this;
                return o.monoUtilService = t, o.homepageService = n, o.properties = s, o.data = {}, 
                o;
            }
            o.__extends(t, e);
            var n = t.prototype;
            n.attached = function() {
                e.prototype.attached.call(this), this.initSelectedItemIndex();
            }, n.handleChangeSelectItem = function(e) {
                var t = e.currentTarget.dataset.index, n = this.data.zoneList[t];
                if (this.data.isUseProtectGh && (null == n ? void 0 : n.isProtectedGh)) {
                    var o = this.selectComponent("#custom-toast"), i = n.ghId || n.groupId;
                    this.homepageService.getProtectedGroupTips(i).subscribe(function(e) {
                        return o.showToast({
                            content: e,
                            duration: 4e3
                        });
                    });
                } else this.setData({
                    selectedItemIndex: t
                });
            }, n.handleTapConfirmSelect = function() {
                var e = this.data, t = e.selectedItemIndex, n = e.zoneList;
                if (n.length && !this.monoUtilService.isUndefinedOrNull(t) && -1 !== t) {
                    var o = n[t];
                    this.triggerEvent("confirm", {
                        zoneItem: o
                    });
                }
            }, n.handleTapCancel = function() {
                this.triggerEvent("cancel");
            }, n.autoSelect = function(e) {
                this.triggerEvent("confirm", {
                    zoneItem: e
                });
            }, n.initSelectedItemIndex = function() {
                var e = this.data.zoneList.findIndex(function(e) {
                    return !e.isProtectedGh;
                });
                this.setData({
                    selectedItemIndex: e
                });
            }, t = o.__decorate([ r.wxComponent(), o.__metadata("design:paramtypes", [ a.MonoUtilService, c.HomepageService ]) ], t);
        }(i.SuperComponent);
    }
}, [ [ 724, 0, 2, 1 ] ] ]));