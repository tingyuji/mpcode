var t = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
    return typeof t;
} : function(t) {
    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
};

require("./../../../../runtime"), require("./../../../../mono"), require("./../../../../common"), 
function(t, e) {
    for (var o in e) t[o] = e[o];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 110 ], {
    2: function(e, o) {
        var n;
        n = function() {
            return this;
        }();
        try {
            n = n || new Function("return this")();
        } catch (e) {
            "object" == ("undefined" == typeof window ? "undefined" : t(window)) && (n = window);
        }
        e.exports = n;
    },
    777: function(t, e, o) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.Navbar = e.NAVBAR_TYPE = void 0;
        var n, i = o(0), a = o(1), r = o(4), u = o(6), p = o(79);
        !function(t) {
            t[t.INDEX = 0] = "INDEX", t[t.NORMAL = 1] = "NORMAL", t[t.TRANSPARENT = 2] = "TRANSPARENT", 
            t[t.TRANSPARENT_PLACEHOLDER = 3] = "TRANSPARENT_PLACEHOLDER";
        }(n = e.NAVBAR_TYPE || (e.NAVBAR_TYPE = {}));
        var l = {
            title: {
                type: String,
                value: ""
            },
            groupId: {
                type: String,
                value: ""
            },
            groupType: {
                type: Number
            },
            mode: {
                type: Number,
                value: n.TRANSPARENT
            },
            css: {
                type: String,
                value: ""
            },
            whiteIcon: {
                type: String,
                value: ""
            },
            isShowBackButton: {
                type: Boolean,
                value: !1
            }
        }, s = function(t) {
            function e(e) {
                var o = t.call(this) || this;
                return o.utils = e, o.properties = l, o;
            }
            i.__extends(e, t);
            var o = e.prototype;
            return o.attached = function() {
                var e;
                t.prototype.attached.call(this);
                var o = this.utils.getApp(), n = (null === (e = this.utils.getPage()) || void 0 === e ? void 0 : e.route) || "", i = this.data.title;
                try {
                    var a = __wxConfig && __wxConfig.page && __wxConfig.page[n + ".html"] && __wxConfig.page[n + ".html"].window && __wxConfig.page[n + ".html"].window.navigationBarTitleText, r = __wxConfig && __wxConfig.pages && __wxConfig.pages[n + ".html"] && __wxConfig.pages[n + ".html"].window && __wxConfig.pages[n + ".html"].window.navigationBarTitleText;
                    i = i || a || r;
                } catch (t) {
                    p.wxlog.error("nav-error => ", JSON.stringify(t));
                }
                this.setData({
                    isCustomerHome: 30 === this.data.groupType,
                    backIcon: getCurrentPages().length <= 1 ? "home" : "back",
                    navH: o.globalData.navHeight,
                    title: i
                });
            }, o.ready = function() {
                t.prototype.ready.call(this);
            }, o.handleNavBack = function() {
                this.utils.navigateBack();
            }, e = i.__decorate([ a.wxComponent(), i.__metadata("design:paramtypes", [ u.UtilService ]) ], e);
        }(r.SuperComponent);
        e.Navbar = s;
    }
}, [ [ 777, 0, 2, 1 ] ] ]));