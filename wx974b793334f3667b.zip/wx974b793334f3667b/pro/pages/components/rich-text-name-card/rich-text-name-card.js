var e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
};

require("./../../../../runtime"), require("./../../../../mono"), require("./../../../../common"), 
function(e, t) {
    for (var o in t) e[o] = t[o];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 140 ], {
    2: function(t, o) {
        var i;
        i = function() {
            return this;
        }();
        try {
            i = i || new Function("return this")();
        } catch (t) {
            "object" == ("undefined" == typeof window ? "undefined" : e(window)) && (i = window);
        }
        t.exports = i;
    },
    690: function(e, t, o) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var i = o(0), a = o(4), n = o(1), r = o(59), d = o(6), s = o(21), c = o(9), m = o(30), u = o(16), l = o(22), p = o(20), f = {
            actId: Number,
            img: String,
            name: String,
            description: String,
            disableTap: Boolean,
            type: {
                type: Number,
                observer: function() {
                    this.initNameCard();
                }
            },
            nameCardInfo: Object,
            isLineLimit: Boolean
        };
        !function(e) {
            function t(t, o, i) {
                var a = e.call(this) || this;
                return a.monoRedDotService = t, a.monoCommonService = o, a.utilService = i, a.properties = f, 
                a.data = {
                    NameCardType: r.NameCardType,
                    isShowActInActQrcodeModal: !0
                }, a;
            }
            i.__extends(t, e);
            var o = t.prototype;
            o.attached = function() {
                if (e.prototype.attached.call(this), this.data.nameCardInfo) {
                    var t = this.data.nameCardInfo, o = t.id, i = t.qrCodeUrl, a = t.quote, n = t.url, r = t.selectName, d = t.selectType;
                    this.setData({
                        cardId: o,
                        name: r,
                        img: i,
                        description: a,
                        toDetailUrl: n,
                        type: d
                    });
                }
                this.initNameCard(), this.setCustomServiceMsgInfo();
            }, o.initNameCard = function() {
                var e, t = ((e = {})[r.NameCardType.WECHAT_NUM] = {
                    modalTitle: "点击下方图片，长按识别添加我的微信",
                    btnText: "点击联系"
                }, e[r.NameCardType.WECHAT_GROUP] = {
                    modalTitle: "点击下方图片，长按识别加入我的微信群",
                    btnText: "点击进群"
                }, e[r.NameCardType.OFFICIAL_ACCOUNT] = {
                    modalTitle: "点击下方图片，长按识别关注我的公众号",
                    btnText: "点击关注公众号"
                }, e);
                this.setData(i.__assign({}, t[this.data.type]));
            }, o.handleShowPreviewPicture = function(e) {
                var t = this.monoCommonService.getRealImgUrl(this.data.resHost, this.data.img, !1, !1);
                wx.previewImage({
                    current: t,
                    urls: [ t ]
                });
            }, o.handleTapToggleQrCodeModal = function() {}, o.handleTapToCustomService = function() {
                this.setData({
                    isShowQrcodeModal: !1
                });
            }, o.getParam = function(e, t) {
                if (!e || e.indexOf("?") < 0 || !t) return "";
                var o = e.substr(e.indexOf("?") + 1), i = new RegExp("(^|&)" + t + "=([^&]*)(&|$)", "i"), a = o.match(i) || [];
                return a.length <= 3 ? "" : a[2];
            }, o.setCustomServiceMsgInfo = function() {
                var e, t = l.config.resHost + "/ss/app/image/plus/discern_QRcode.jpg", o = (null === (e = this.utilService.getPage()) || void 0 === e ? void 0 : e.route) || "";
                if (/^\//.test(o) || (o = "/" + o), !this.data.disableTap && (null == o ? void 0 : o.includes("pages/seq-detail"))) {
                    var i = {
                        path: o = this.utilService.setUrlParams(o, {
                            actId: this.data.actId,
                            scene: "FANS",
                            qrcodeId: this.data.cardId
                        }),
                        title: "长按识别二维码",
                        img: t
                    };
                    this.setData({
                        customServiceMsgInfo: i
                    });
                }
            }, i.__decorate([ u.Toggle("isShowQrcodeModal"), i.__metadata("design:type", Function), i.__metadata("design:paramtypes", []), i.__metadata("design:returntype", void 0) ], t.prototype, "handleTapToggleQrCodeModal", null), 
            t = i.__decorate([ n.wxComponent(), i.__metadata("design:paramtypes", [ m.MonoRedDotService, p.MonoCommonService, d.UtilService ]) ], t);
        }(c.miniMixin(s.NewRedDotMixin, a.SuperComponent));
    }
}, [ [ 690, 0, 2, 1 ] ] ]));