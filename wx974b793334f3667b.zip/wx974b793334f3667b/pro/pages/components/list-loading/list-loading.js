var t = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
    return typeof t;
} : function(t) {
    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
};

require("./../../../../runtime"), require("./../../../../mono"), require("./../../../../common"), 
function(t, e) {
    for (var o in e) t[o] = e[o];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 123 ], {
    2: function(e, o) {
        var n;
        n = function() {
            return this;
        }();
        try {
            n = n || new Function("return this")();
        } catch (e) {
            "object" == ("undefined" == typeof window ? "undefined" : t(window)) && (n = window);
        }
        e.exports = n;
    },
    786: function(t, e, o) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        });
        var n = o(0), r = o(4), i = o(1), a = {
            isLoading: {
                type: Boolean,
                value: !1
            },
            loadingText: {
                type: String,
                value: "正在加载中..."
            },
            isFixedHeight: {
                type: Boolean,
                value: !1
            },
            useAnimation: {
                type: Boolean,
                value: !0
            }
        };
        !function(t) {
            function e() {
                var e = t.call(this) || this;
                return e.properties = a, e.data = {}, e;
            }
            n.__extends(e, t);
            var o = e.prototype;
            o.attached = function() {
                t.prototype.attached.call(this);
            }, o.ready = function() {
                t.prototype.ready.call(this);
            }, e = n.__decorate([ i.wxComponent(), n.__metadata("design:paramtypes", []) ], e);
        }(r.SuperComponent);
    }
}, [ [ 786, 0, 2, 1 ] ] ]));