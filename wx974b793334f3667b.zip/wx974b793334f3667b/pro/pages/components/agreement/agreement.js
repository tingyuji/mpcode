var e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
};

require("./../../../../runtime"), require("./../../../../mono"), require("./../../../../common"), 
function(e, t) {
    for (var n in t) e[n] = t[n];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 85 ], {
    2: function(t, n) {
        var o;
        o = function() {
            return this;
        }();
        try {
            o = o || new Function("return this")();
        } catch (t) {
            "object" == ("undefined" == typeof window ? "undefined" : e(window)) && (o = window);
        }
        t.exports = o;
    },
    779: function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var o = n(0), r = n(1), i = n(4), a = n(93);
        !function(e) {
            function t(t) {
                var n = e.call(this) || this;
                return n.agreementService = t, n.externalClasses = [ "custom-class" ], n.properties = {
                    value: Boolean,
                    fontSize: String,
                    protocolType: {
                        type: Number,
                        value: 0
                    },
                    protocolTypeList: {
                        type: Array,
                        value: []
                    },
                    isNeedUserCheck: {
                        type: Boolean,
                        value: !0
                    },
                    tip: String
                }, n.data = {}, n;
            }
            o.__extends(t, e);
            var n = t.prototype;
            n.attached = function() {
                e.prototype.attached.call(this), this.initAgreementConfig();
            }, n.handleCheck = function() {
                this.triggerEvent("change", {
                    value: !this.data.value
                });
            }, n.handleClickAgreement = function(e) {
                var t = e.currentTarget.dataset.type;
                this.agreementService.showProtocolDetail(t);
            }, n.initAgreementConfig = function() {
                var e = this;
                this.agreementService.getAllProtocolInfo().subscribe(function(t) {
                    e.setData({
                        agreementConfig: t
                    });
                });
            }, t = o.__decorate([ r.wxComponent(), o.__metadata("design:paramtypes", [ a.AgreementService ]) ], t);
        }(i.SuperComponent);
    }
}, [ [ 779, 0, 2, 1 ] ] ]));