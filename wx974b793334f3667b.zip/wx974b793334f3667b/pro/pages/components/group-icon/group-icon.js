var o = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
    return typeof o;
} : function(o) {
    return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
};

require("./../../../../runtime"), require("./../../../../mono"), require("./../../../../common"), 
function(o, e) {
    for (var t in e) o[t] = e[t];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 108 ], {
    2: function(e, t) {
        var n;
        n = function() {
            return this;
        }();
        try {
            n = n || new Function("return this")();
        } catch (e) {
            "object" == ("undefined" == typeof window ? "undefined" : o(window)) && (n = window);
        }
        e.exports = n;
    },
    774: function(o, e, t) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        });
        var n = t(0), r = t(4), i = t(1), p = {
            groupType: Number,
            isOfficial: Boolean,
            isSponsor: Boolean,
            isStarGroup: Boolean,
            iconSize: {
                type: String,
                value: ""
            },
            isLabel: {
                type: Boolean,
                value: !1
            },
            isFakeHelp: Boolean
        };
        !function(o) {
            function e() {
                var e = o.call(this) || this;
                return e.properties = p, e.data = {}, e;
            }
            n.__extends(e, o), e.prototype.ready = function() {
                o.prototype.ready.call(this);
            }, e = n.__decorate([ i.wxComponent(), n.__metadata("design:paramtypes", []) ], e);
        }(r.SuperComponent);
    }
}, [ [ 774, 0, 2, 1 ] ] ]));