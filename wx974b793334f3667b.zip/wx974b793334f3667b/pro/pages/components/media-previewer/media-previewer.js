var e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
};

require("./../../../../runtime"), require("./../../../../mono"), require("./../../../../common"), 
function(e, t) {
    for (var n in t) e[n] = t[n];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 124 ], {
    2: function(t, n) {
        var o;
        o = function() {
            return this;
        }();
        try {
            o = o || new Function("return this")();
        } catch (t) {
            "object" == ("undefined" == typeof window ? "undefined" : e(window)) && (o = window);
        }
        t.exports = o;
    },
    599: function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var o = n(0), r = n(4), i = n(1), a = {
            medias: Array,
            isMin: Boolean,
            mediaShape: String,
            isDivision: {
                type: Boolean,
                value: !0
            }
        };
        !function(e) {
            function t() {
                var t = e.call(this) || this;
                return t.properties = a, t.data = {}, t;
            }
            o.__extends(t, e);
            var n = t.prototype;
            n.ready = function() {
                e.prototype.ready.call(this);
            }, n.handleTapImage = function(e) {
                var t = this, n = e.currentTarget.dataset.src, o = this.getAllImageUrls();
                wx.previewImage({
                    urls: o.map(function(e) {
                        return t.data.resHost + e;
                    }),
                    current: this.data.resHost + n
                });
            }, n.handleTapVideo = function(e) {
                var t = e.currentTarget.dataset.src;
                this.setData({
                    videoUrl: t,
                    isPlayVideo: !0
                });
            }, n.handleCloseVideo = function(e) {
                this.setData({
                    videoUrl: "",
                    isPlayVideo: !1
                });
            }, n.getAllImageUrls = function() {
                return this.data.medias.filter(function(e) {
                    return e.match(/(.jpeg)|(.jpg)|(.png)|(.webp)/i);
                });
            }, t = o.__decorate([ i.wxComponent(), o.__metadata("design:paramtypes", []) ], t);
        }(r.SuperComponent);
    }
}, [ [ 599, 0, 2, 1 ] ] ]));