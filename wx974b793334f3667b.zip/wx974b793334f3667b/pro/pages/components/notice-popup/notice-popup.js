var n = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(n) {
    return typeof n;
} : function(n) {
    return n && "function" == typeof Symbol && n.constructor === Symbol && n !== Symbol.prototype ? "symbol" : typeof n;
};

require("./../../../../runtime"), require("./../../../../mono"), require("./../../../../common"), 
function(n, t) {
    for (var e in t) n[e] = t[e];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 129 ], {
    2: function(t, e) {
        var o;
        o = function() {
            return this;
        }();
        try {
            o = o || new Function("return this")();
        } catch (t) {
            "object" == ("undefined" == typeof window ? "undefined" : n(window)) && (o = window);
        }
        t.exports = o;
    },
    755: function(n, t, e) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var o = e(0), i = e(4), r = e(1), u = {
            fromUserAvatar: String,
            fromUserName: String,
            isOfficial: Boolean,
            content: String,
            duration: {
                type: Number,
                value: 5e3
            }
        };
        !function(n) {
            function t() {
                var t = n.call(this) || this;
                return t.properties = u, t.data = {}, t;
            }
            o.__extends(t, n);
            var e = t.prototype;
            e.handleShowAnimationFinish = function() {
                this.triggerEvent("showAnimationFinish");
            }, e.handleHideAnimationFinish = function() {
                this.triggerEvent("hide");
            }, e.handleTouchEndCheckout = function() {
                this.triggerEvent("checkout");
            }, t = o.__decorate([ r.wxComponent(), o.__metadata("design:paramtypes", []) ], t);
        }(i.SuperComponent);
    }
}, [ [ 755, 0, 2, 1 ] ] ]));