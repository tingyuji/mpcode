var t = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
    return typeof t;
} : function(t) {
    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
};

require("./../../../../runtime"), require("./../../../../mono"), require("./../../../../common"), 
function(t, e) {
    for (var o in e) t[o] = e[o];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 137 ], {
    2: function(e, o) {
        var i;
        i = function() {
            return this;
        }();
        try {
            i = i || new Function("return this")();
        } catch (e) {
            "object" == ("undefined" == typeof window ? "undefined" : t(window)) && (i = window);
        }
        e.exports = i;
    },
    685: function(t, e, o) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        });
        var i = o(0), n = o(4), a = o(1), r = o(14), c = o(59), s = o(17), u = {
            activityInfo: {
                type: Object,
                observer: function(t) {
                    this.generateActivityTypeDesc(t);
                }
            },
            disableTap: Boolean,
            backgroundColor: String,
            buttonText: String,
            showSeqType: Boolean,
            isGhostButton: Boolean,
            isShowAddedTag: Boolean
        };
        !function(t) {
            function e(e) {
                var o = t.call(this) || this;
                return o.grayFeatureService = e, o.properties = u, o.data = {
                    SeqStatusText: c.SeqStatusText
                }, o;
            }
            i.__extends(e, t);
            var o = e.prototype;
            o.ready = function() {
                t.prototype.ready.call(this), this.getActCardGrayInfo();
            }, o.handleTapNavToDetail = function() {
                var t;
                (null === (t = this.data.activityInfo) || void 0 === t ? void 0 : t.actId) && !this.data.disableTap && this.unlimitedNavigateTo(r.SEQ_TYPE_DETAIL_PATH[this.data.activityInfo.activityType], {
                    actId: this.data.activityInfo.actId,
                    isUnlimited: 1
                });
            }, o.generateActivityTypeDesc = function(t) {
                var e = t.activityType, o = t.ghViewType, i = 150 === e && 10 === o ? "选品接龙" : r.SEQ_TYPE_TEXT_FOR_CARD[e];
                this.setData({
                    activityTypeDesc: i
                });
            }, o.getActCardGrayInfo = function() {
                var t = this;
                this.grayFeatureService.canIUseFeatureByMultiply([ "2181" ]).subscribe(function(e) {
                    var o = i.__read(e, 1)[0];
                    t.setData({
                        isGrayShowViewCount: o
                    });
                });
            }, e = i.__decorate([ a.wxComponent(), i.__metadata("design:paramtypes", [ s.GrayFeatureService ]) ], e);
        }(n.SuperComponent);
    }
}, [ [ 685, 0, 2, 1 ] ] ]));