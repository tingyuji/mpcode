var t = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
    return typeof t;
} : function(t) {
    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
};

require("./../../../../runtime"), require("./../../../../mono"), require("./../../../../common"), 
function(t, e) {
    for (var o in e) t[o] = e[o];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 150 ], {
    2: function(e, o) {
        var n;
        n = function() {
            return this;
        }();
        try {
            n = n || new Function("return this")();
        } catch (e) {
            "object" == ("undefined" == typeof window ? "undefined" : t(window)) && (n = window);
        }
        e.exports = n;
    },
    744: function(t, e, o) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        });
        var n = o(0), r = o(4), i = o(1), a = o(123), s = {
            activeItem: {
                type: Object,
                observer: function(t) {
                    this.setData({
                        selectedItem: t
                    });
                }
            },
            isScrollToLeft: {
                type: Boolean,
                observer: function() {
                    this.setData({
                        scrollLeftPos: 0
                    });
                }
            },
            optionList: {
                type: Array,
                required: !0
            },
            isLabel: {
                type: Boolean,
                value: !1
            },
            isLittleSpacing: {
                type: Boolean,
                value: !1
            }
        };
        !function(t) {
            function e() {
                var e = t.call(this) || this;
                return e.properties = s, e.data = {
                    SortCondition: a.SortCondition
                }, e;
            }
            n.__extends(e, t);
            var o = e.prototype;
            o.ready = function() {
                t.prototype.ready.call(this);
            }, o.handleTapItem = function(t) {
                var e = n.__assign({}, t.currentTarget.dataset.item), o = this.data.selectedItem, r = a.SortCondition.DESCEND;
                if (e.isSortable) {
                    var i = e.status === (null == o ? void 0 : o.status);
                    e.sort = i ? o.sort === a.SortCondition.DESCEND ? a.SortCondition.ASCEND : a.SortCondition.DESCEND : r;
                }
                this.setData({
                    selectedItem: e
                }), this.triggerEvent("select", e);
            }, e = n.__decorate([ i.wxComponent(), n.__metadata("design:paramtypes", []) ], e);
        }(r.SuperComponent);
    }
}, [ [ 744, 0, 2, 1 ] ] ]));