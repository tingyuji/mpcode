var e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
};

require("./../../../../runtime"), require("./../../../../mono"), require("./../../../../common"), 
function(e, t) {
    for (var r in t) e[r] = t[r];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 149 ], {
    2: function(t, r) {
        var i;
        i = function() {
            return this;
        }();
        try {
            i = i || new Function("return this")();
        } catch (t) {
            "object" == ("undefined" == typeof window ? "undefined" : e(window)) && (i = window);
        }
        t.exports = i;
    },
    728: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var i, o = r(0), n = r(4), a = r(1), s = r(14), h = r(50), c = r(12), p = r(7), d = r(3), u = r(20), l = r(24), S = r(16), g = r(9), v = r(21), f = r(17), y = r(6), w = r(88), m = r(5), L = r(83), P = r(22), T = r(92), k = r(230), M = r(85), x = r(53);
        !function(e) {
            e[e.URL_LINK = 1] = "URL_LINK", e[e.SHORT_LINK = 2] = "SHORT_LINK";
        }(i || (i = {}));
        var A = {
            sharingSeqInfo: {
                type: Object,
                observer: function(e) {
                    this.setData(o.__assign({}, e));
                }
            },
            previewList: {
                type: Array,
                observer: function(e, t) {
                    if (e && e.length) {
                        var r = e[0], i = {
                            type: s.ShareInfoType.SHARE_SELECTOR,
                            shareInfo: r
                        };
                        this.setData({
                            shareData: i
                        }), this.checkIsNeedToOtherMiniApp();
                    }
                }
            },
            configList: Array,
            isUsePagePoster: Boolean,
            isUseTitleSlot: Boolean,
            previewTitle: {
                type: String,
                value: "分享预览"
            },
            previewShareFriendText: {
                type: String,
                value: "分享给好友"
            },
            isShowShareWx: {
                type: Boolean,
                value: !0
            },
            isShowSharePoster: {
                type: Boolean,
                value: !0
            },
            isShowInsertPublicAccount: Boolean,
            isUsePreviewModal: {
                type: Boolean,
                value: !0
            },
            isUsePreviewSlot: Boolean,
            customShareInfo: Object,
            isShowCopyShortLink: Boolean,
            posterRadius: Number,
            posterBoxWidth: String,
            isUseCustomSaveBtn: Boolean,
            groupId: String,
            groupType: Number,
            isCreator: Boolean,
            previewModalPaddingBottomClass: {
                type: String,
                value: "pb-greater"
            },
            isShowPosterDirectly: Boolean,
            disableUseModalMaskBackground: Boolean
        };
        !function(e) {
            function t(t, r, o, n, a, s, h, c, p, d, u) {
                var l = e.call(this) || this;
                return l.apiService = t, l.wxCloudApiService = r, l.monoCommonService = o, l.grayFeatureService = n, 
                l.utils = a, l.actUidBlockedService = s, l.commonPosterService = h, l.errorService = c, 
                l.appsTransferJumpService = p, l.actShareReportService = d, l.urlService = u, l.properties = A, 
                l.options = {
                    multipleSlots: !0
                }, l.data = {
                    currentIndex: 0,
                    noPosterUrl: !0,
                    authMode: {
                        method: "saveImageToPhotosAlbum",
                        scope: "writePhotosAlbum",
                        hint: "保存到相册",
                        options: {
                            filePath: ""
                        },
                        isAuthorize: !0
                    },
                    LinkType: i,
                    currentLinkType: i.SHORT_LINK,
                    isNeedToOtherMiniApp: !1
                }, l.clickedGeneratePosterUnloadFail = !1, l;
            }
            o.__extends(t, e);
            var r = t.prototype;
            r.attached = function() {
                var t = this;
                e.prototype.attached.call(this);
                var r = this.data, i = r.isShowPosterDirectly, o = r.configList;
                if (o && o.length) {
                    var n = new Array((o || []).length), a = this.getPosterSize(o), s = a.posterMaxHeight, h = a.posterWidth;
                    this.setData({
                        posterMaxHeight: s,
                        posterWidth: h,
                        posterUrlList: n,
                        isShowPoster: !0,
                        isShowPreviewModal: !i
                    }, function() {
                        t.selectComponent("#poster-0").onCreate(!0, 0);
                    }), this.checkIsNeedToOtherMiniApp(), this.getIsShowCopyLinkTips(), i && this.processGeneratePoster();
                } else this.setData({
                    isShowPreviewModal: !i
                });
            }, r.ready = function() {
                e.prototype.ready.call(this);
            }, r.handleTapShareToFriends = function(e) {
                var t = this.data, r = t.shareData, i = t.configList;
                this.actShareReportService.reportOnSavePosterOrShare(r, i, !1);
            }, r.checkIsNeedToOtherMiniApp = function() {
                var e = this;
                if (L.currentAppId !== P.config.mirrorAppid && this.utils.getPage()) {
                    var t = this.getCurrentPageShareInfo(), r = this.data.sharingSeqInfo || {}, i = r.actId, o = r.seqType, n = [ 20, 160, 250, 210 ].includes(o) && L.currentAppId === P.config.mirrorAppid;
                    if (!i || n || !(null == t ? void 0 : t.path)) return void this.changeNeedToOtherMiniApp(!1);
                    if (this.requestActId === i) return;
                    this.requestActId = i, this.appsTransferJumpService.getProtectedAppRuleGhIdByActId(i).pipe(d.finalize(function() {
                        return e.requestActId = void 0;
                    }), d.catchError(function(t) {
                        return e.changeNeedToOtherMiniApp(!1), p.throwError(t);
                    })).subscribe(function(t) {
                        if (t) {
                            var r = t.map(function(e) {
                                return {
                                    groupId: e
                                };
                            });
                            e.appsTransferJumpService.getJumpAppidByMultiUserType(r).subscribe(function(t) {
                                t ? (e.toOtherMiniAppid = t, e.changeNeedToOtherMiniApp(!0)) : e.changeNeedToOtherMiniApp(!1);
                            });
                        }
                    });
                }
            }, r.changeNeedToOtherMiniApp = function(e) {
                this.data.isNeedToOtherMiniApp !== e && this.setData({
                    isNeedToOtherMiniApp: e
                });
            }, r.handleDiyShare = function(e) {
                var t = this.data, r = t.shareWithTransfer;
                t.isNeedToOtherMiniApp ? this.utils.getPage().shareByOtherMiniApp(e, this.toOtherMiniAppid) : r && this.handleShareWhenNotBtn(e);
            }, r.handleSelectShareImg = function(e) {
                var t = e.detail.current, r = this.data.previewList[t], i = {
                    type: s.ShareInfoType.SHARE_SELECTOR,
                    shareInfo: r
                };
                this.setData({
                    shareData: i
                });
            }, r.handleSelectSharePoster = function(e) {
                var t, r = e.detail.current, i = this.data.posterUrlList[r];
                this.setData(((t = {
                    noPosterUrl: !i,
                    currentIndex: r
                })["authMode.options.filePath"] = i, t));
            }, r.handleToggleCopyLinkModal = function() {
                this.setIsShowCopyLinkTips();
            }, r.handleHideCopyLinkTips = function() {
                this.setIsShowCopyLinkTips();
            }, r.handleTapCopyLink = function() {
                var e = this.data.currentLinkType;
                e && (e === i.SHORT_LINK ? this.handleTapCopyShortLink() : this.handleTapCopyUrlLink());
            }, r.handleSelectedLinkType = function(e) {
                var t = e.currentTarget.dataset.linkType;
                this.setData({
                    currentLinkType: t
                });
            }, r.handleCloseModal = function() {
                this.processCloseModal();
            }, r.handleTapInsertOffical = function() {
                this.triggerEvent("insert");
            }, r.handleGeneratePoster = function() {
                this.processGeneratePoster();
            }, r.handlePosterSuccess = function(e) {
                var t, r = this, i = e.detail, n = i.url, a = i.index, s = this.data, h = s.configList, c = s.posterUrlList, p = void 0 === c ? [] : c, d = s.currentIndex, u = void 0 === d ? 0 : d, l = s.shareData, S = (null == h ? void 0 : h.length) || 0;
                p[a] = n;
                var g = {
                    noPosterUrl: a === u ? !n : !p[u],
                    posterUrlList: p
                }, v = a === u ? o.__assign(o.__assign({}, g), ((t = {})["authMode.options.filePath"] = n, 
                t)) : o.__assign({}, g);
                if (this.setData(o.__assign({}, v)), 1 === p.length && wx.showShareImageMenu && this.clickedGeneratePosterUnloadFail && (wx.hideLoading({}), 
                this.clickedGeneratePosterUnloadFail = !1, this.commonPosterService.sharePictureByWxShareImageMenu({
                    path: p[0],
                    successFn: function() {
                        r.triggerEvent("showShareMenuSuc"), r.triggerEvent("close"), r.actShareReportService.reportOnSavePosterOrShare(l, h, !0);
                    },
                    failFn: function() {
                        r.data.isShowPosterDirectly && r.processCloseModal();
                    }
                })), a < S - 1) {
                    var f = a + 1;
                    this.selectComponent("#poster-" + f).onCreate(!0, f);
                }
            }, r.handlePosterFail = function(e) {}, r.handleAuthorizeSaveImage = function(e) {
                var t = this;
                this.processAuthInfo(), this.setData({
                    isShowPosterModal: !1,
                    isShowPoster: !1
                }), c.rxwx.showToast({
                    title: "已成功保存至本地相册",
                    icon: "none",
                    duration: 650
                }).subscribe(function() {
                    t.closeModalAndCheckFirstShare();
                });
                var r = this.data, i = r.shareData, o = r.configList;
                this.actShareReportService.reportOnSavePosterOrShare(i, o, !0);
            }, r.handleTapCopyShortLink = function() {
                var e = this;
                wx.showLoading({
                    title: "正在生成链接"
                });
                var t = this.data, r = t.seqType, i = t.actId, o = !1;
                this.transferPagePathWhenNeed(i, r).subscribe(function(t) {
                    var r = e.getShareAppId() + i;
                    e.getShortLinkStorageNotExpired(r).pipe(d.switchMap(function(r) {
                        var i, n = (null === (i = r.data) || void 0 === i ? void 0 : i.shortLink) || "";
                        if (o = !!n) {
                            var a = {
                                link: n
                            };
                            return p.of(a);
                        }
                        var s = {
                            pageTitle: "",
                            pageUrl: t,
                            appId: e.getShareAppId(),
                            isPermanent: !1
                        };
                        return e.genShortLink(s);
                    })).subscribe(function(t) {
                        wx.hideLoading();
                        var i = t || {}, n = i.errCode, a = i.link;
                        !n && a ? (o || e.setShortLinkStorage(r, a), e.afterGetShortLink(a || "")) : 45009 === n ? (e.errorService.customReportError({
                            frontErrorCode: 7008
                        }), wx.showToast({
                            title: "今日链接生成次数已用完，请明日再试",
                            icon: "none"
                        })) : wx.showToast({
                            title: "复制链接失败",
                            icon: "none"
                        });
                    }, function(e) {
                        wx.hideLoading(), wx.showToast({
                            title: "复制链接失败",
                            icon: "none"
                        });
                    });
                }, function(e) {
                    wx.hideLoading(), wx.showToast({
                        title: "预处理链接失败",
                        icon: "none"
                    });
                });
            }, r.genShortLink = function(e) {
                var t = this;
                return this.grayFeatureService.canIUseFeature("2363").pipe(d.switchMap(function(r) {
                    return r ? t.apiService.genShortLinkUsingPOST(e).pipe(d.map(function(e) {
                        return e.data;
                    })) : t.genShortLinkByCloud(e);
                }));
            }, r.genShortLinkByCloud = function(e) {
                return this.wxCloudApiService.getShortLink(e).pipe(d.map(function(e) {
                    var t, r, i;
                    return {
                        errCode: null === (t = e.data) || void 0 === t ? void 0 : t.errcode,
                        errMsg: null === (r = e.data) || void 0 === r ? void 0 : r.errmsg,
                        link: null === (i = e.data) || void 0 === i ? void 0 : i.link
                    };
                }));
            }, r.handleTapCopyUrlLink = function() {
                var e = this;
                wx.showLoading({
                    title: "正在生成链接"
                });
                var t = this.data, r = t.seqType, i = t.actId, o = !1;
                this.transferPagePathWhenNeed(i, r).subscribe(function(t) {
                    var r = e.getShareAppId() + i;
                    e.getUrlLinkStorageNotExpired(r).pipe(d.switchMap(function(r) {
                        var i, n = (null === (i = r.data) || void 0 === i ? void 0 : i.urlLink) || "";
                        if (o = !!n) {
                            var a = {
                                urlLink: n
                            };
                            return p.of(a);
                        }
                        var s = {
                            appId: e.getShareAppId(),
                            path: t.slice(0, t.indexOf("?")),
                            query: t.slice(t.indexOf("?") + 1),
                            expireType: 1,
                            expireInterval: 30
                        };
                        return e.genUrlLink(s);
                    })).subscribe(function(t) {
                        wx.hideLoading();
                        var i = t || {}, n = i.errCode, a = i.urlLink;
                        !n && a ? (o || e.setUrlLinkStorage(r, a), e.afterGetUrlLink(a || "")) : 45009 === n ? (e.errorService.customReportError({
                            frontErrorCode: 7008
                        }), wx.showToast({
                            title: "今日链接生成次数已用完，请明日再试",
                            icon: "none"
                        })) : wx.showToast({
                            title: "复制链接失败",
                            icon: "none"
                        });
                    }, function(e) {
                        wx.hideLoading(), wx.showToast({
                            title: "复制链接失败",
                            icon: "none"
                        });
                    });
                }, function(e) {
                    wx.hideLoading(), wx.showToast({
                        title: "预处理链接失败",
                        icon: "none"
                    });
                });
            }, r.genUrlLink = function(e) {
                var t = this;
                return this.grayFeatureService.canIUseFeatureByMultiply([ "2363", "2365" ]).pipe(d.switchMap(function(r) {
                    var i = o.__read(r, 2), n = i[0];
                    if (i[1]) {
                        var a = e.appId, s = e.path, h = e.query, c = P.config.shareH5Host, u = "?appId=" + a + "&ghName=" + (P.config.ghNameMap[a] || "") + "&miniFullPath=" + encodeURIComponent(s + "?" + h);
                        return p.of({
                            urlLink: c + "jump-mp.html" + u
                        });
                    }
                    return n ? t.apiService.genUrlLinkUsingPOST(e).pipe(d.map(function(e) {
                        return e.data;
                    })) : t.genUrlLinkByCloud(e);
                }));
            }, r.genUrlLinkByCloud = function(e) {
                return this.wxCloudApiService.getUrlLink(e).pipe(d.map(function(e) {
                    var t, r, i;
                    return {
                        errCode: null === (t = e.data) || void 0 === t ? void 0 : t.errcode,
                        errMsg: null === (r = e.data) || void 0 === r ? void 0 : r.errmsg,
                        urlLink: null === (i = e.data) || void 0 === i ? void 0 : i.urlLink
                    };
                }));
            }, r.transferPagePathWhenNeed = function(e, t) {
                var r = this;
                return new p.Observable(function(i) {
                    var o = r.data.previewList, n = (void 0 === o ? [] : o)[0].path || "", a = r.urlService.getParams(n), h = s.SEQ_TYPE_DETAIL_PATH[t] || "";
                    h = h.replace(/^\//, ""), /^pro/.test(h) || (h = "pro/" + h);
                    var c = r.utils.getUid(), p = {
                        actId: e,
                        inviteUid: c,
                        fromShare: 1,
                        shareByLink: 1
                    };
                    Object.assign(a, p), h = r.urlService.setParams(h, a), r.grayFeatureService.canIUseFeature("2294").subscribe(function(e) {
                        if (!e) return i.next(h), void i.complete();
                        r.wxCloudApiService.getTransferPageConfig({
                            id: "changeShare"
                        }, {
                            useStorageOptions: {
                                isUseCache: !0
                            }
                        }).subscribe(function(e) {
                            var t, o, n, a;
                            try {
                                var s = null === (o = null === (t = null == e ? void 0 : e.data) || void 0 === t ? void 0 : t.data) || void 0 === o ? void 0 : o.needChangePagePathList, c = null === (a = null === (n = null == e ? void 0 : e.data) || void 0 === n ? void 0 : n.data) || void 0 === a ? void 0 : a.transferPageId, p = -1 !== h.indexOf("?") ? h.indexOf("?") : h.length;
                                s && c && -1 !== s.indexOf(h.slice(0, p)) && (h = r._transferPagePath(h, c)), i.next(h), 
                                i.complete();
                            } catch (e) {
                                i.error(e);
                            }
                        });
                    });
                });
            }, r._transferPagePath = function(e, t) {
                var r = 0 === e.indexOf("pro"), i = "";
                if (e.indexOf("?") > 0) {
                    var o = e.split("?");
                    i = (i = o[1]) + (i ? "&" : "") + "originPath=/" + o[0];
                } else i = "originPath=" + e;
                return e = this.getTempPageByIsPro(r, t) + "?" + i;
            }, r.getTempPageByIsPro = function(e, t) {
                return (e ? "pro" : "") + "/pages/transfer/page" + t + "/page" + t;
            }, r.processAuthInfo = function() {
                var e = this;
                wx.getSetting({
                    success: function(t) {
                        var r, i, o = null === (i = e.data.authMode) || void 0 === i ? void 0 : i.scope;
                        if (void 0 !== t.authSetting["scope." + o]) {
                            var n = t.authSetting["scope." + o];
                            e.setData(((r = {})["authMode.isAuthorize"] = n, r));
                        } else e.errorService.customReportError({
                            frontErrorCode: 17001,
                            errorMsg: "scope: " + o,
                            error: t.authSetting
                        });
                    },
                    fail: function(t) {
                        e.errorService.customReportError({
                            frontErrorCode: 17002,
                            errorMsg: t.errMsg,
                            error: t
                        });
                    }
                });
            }, r.processCloseModal = function() {
                this.setData({
                    posterUrlList: [],
                    isShowSelectShareLinkModal: !1
                }), this.triggerEvent("close");
            }, r.processGeneratePoster = function() {
                var e, t = this, r = this.data, i = r.isUsePagePoster, o = r.configList, n = r.posterUrlList, a = void 0 === n ? [] : n, s = r.shareData;
                if (i) this.triggerEvent("generatePoster"); else if (o && o.length) return 1 === a.length && wx.showShareImageMenu ? a[0] ? void this.commonPosterService.sharePictureByWxShareImageMenu({
                    path: a[0],
                    successFn: function() {
                        t.triggerEvent("showShareMenuSuc"), t.triggerEvent("close"), t.actShareReportService.reportOnSavePosterOrShare(s, o, !0);
                    },
                    failFn: function() {
                        t.data.isShowPosterDirectly && t.processCloseModal();
                    }
                }, null === (e = o[0]) || void 0 === e ? void 0 : e.posterType) : (wx.showLoading({
                    title: "海报加载中"
                }), void (this.clickedGeneratePosterUnloadFail = !0)) : void this.setData({
                    isShowPreviewModal: !1,
                    isShowPosterModal: !0
                });
            }, r.getPosterSize = function(e) {
                var t = wx.getSystemInfoSync(), r = t.screenHeight / t.screenWidth * 750 * .65, i = Math.max.apply(Math, o.__spread(e.map(function(e) {
                    return e.height / e.width * 560;
                }))), n = i > r;
                return {
                    posterWidth: n ? r / i * 560 : 560,
                    posterMaxHeight: n ? r : i
                };
            }, r.getShortLinkStorageNotExpired = function(e) {
                return this.wxCloudApiService.operateShortLinkCache({
                    type: "GET",
                    getParams: {
                        onlyKey: e,
                        createTime: new Date().getTime()
                    }
                });
            }, r.setShortLinkStorage = function(e, t) {
                this.wxCloudApiService.operateShortLinkCache({
                    type: "SET",
                    setParams: {
                        shortLink: t,
                        onlyKey: e
                    }
                }).subscribe();
            }, r.afterGetShortLink = function(e) {
                var t = this;
                if (e) {
                    var r = this.monoCommonService.sliceEmojiString("【群接龙】" + this.data.seqName, 0, 40);
                    c.rxwx.setClipboardData({
                        data: "" + r + e
                    }).subscribe(function() {
                        wx.showToast({
                            title: "复制成功，可分享朋友圈给更多好友，30天有效",
                            icon: "none"
                        }), t.handleCloseModal();
                    });
                }
            }, r.getUrlLinkStorageNotExpired = function(e) {
                return this.wxCloudApiService.operateUrlLinkCache({
                    type: "GET",
                    getParams: {
                        onlyKey: e,
                        createTime: new Date().getTime()
                    }
                });
            }, r.setUrlLinkStorage = function(e, t) {
                this.wxCloudApiService.operateUrlLinkCache({
                    type: "SET",
                    setParams: {
                        urlLink: t,
                        onlyKey: e
                    }
                }).subscribe();
            }, r.afterGetUrlLink = function(e) {
                var t = this;
                e && c.rxwx.setClipboardData({
                    data: "" + e
                }).subscribe(function() {
                    wx.showToast({
                        title: "复制成功，可分享至微信外部给更多好友，30天有效",
                        icon: "none"
                    }), t.handleCloseModal();
                });
            }, r.getIsShowCopyLinkTips = function() {
                this.getRedDotAndSetData([ {
                    code: 1029
                } ]);
            }, r.setIsShowCopyLinkTips = function() {
                this.markReadRedDotByUid([ {
                    code: 1029
                } ]);
            }, r.checkFirstShareAuthAndRealName = function() {
                var e = this.data, t = e.groupId, r = e.groupType, i = e.isCreator;
                this.actUidBlockedService.checkFirstShareBlockLevelShowAuthRealNameAndAipModalObs(t, r, i).subscribe();
            }, r.closeModalAndCheckFirstShare = function() {
                this.handleCloseModal(), this.checkFirstShareAuthAndRealName();
            }, r.getCurrentPageShareInfo = function() {
                var e = this.utils.getPage();
                if (!e || "function" != typeof e.onShareAppMessage) return {};
                var t = this.data, r = {
                    shareInfo: t.customShareInfo,
                    shareData: t.shareData
                }, i = {
                    currentTarget: {
                        dataset: r
                    },
                    target: {
                        dataset: r
                    }
                };
                return e.onShareAppMessage(i);
            }, r.getShareAppId = function() {
                return this.data.isNeedToOtherMiniApp && this.toOtherMiniAppid ? this.toOtherMiniAppid : L.currentAppId;
            }, o.__decorate([ S.Toggle("isShowSelectShareLinkModal"), o.__metadata("design:type", Function), o.__metadata("design:paramtypes", []), o.__metadata("design:returntype", void 0) ], t.prototype, "handleToggleCopyLinkModal", null), 
            t = o.__decorate([ a.wxComponent(), o.__metadata("design:paramtypes", [ m.DefaultService, h.WxCloudApiService, u.MonoCommonService, f.GrayFeatureService, y.UtilService, T.ActUidBlockedService, M.CommonPosterService, l.ErrorService, w.AppsTransferJumpService, k.ActShareReportService, x.UrlService ]) ], t);
        }(g.miniMixin(v.NewRedDotMixin, n.SuperComponent));
    }
}, [ [ 728, 0, 2, 1 ] ] ]));