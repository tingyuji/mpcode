var e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
};

require("./../../../../runtime"), require("./../../../../mono"), require("./../../../../common"), 
function(e, t) {
    for (var a in t) e[a] = t[a];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 122, 105 ], {
    2: function(t, a) {
        var i;
        i = function() {
            return this;
        }();
        try {
            i = i || new Function("return this")();
        } catch (t) {
            "object" == ("undefined" == typeof window ? "undefined" : e(window)) && (i = window);
        }
        t.exports = i;
    },
    675: function(e, t, a) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.InfoForm = void 0;
        var i = a(0), r = a(4), n = a(1), o = a(433), s = a(29), c = a(12), u = a(5), l = a(6), d = a(11), h = a(147), v = a(7), f = a(36), p = a(68), g = a(37), m = a(676), y = a(9), C = a(3), b = a(19), T = {
            form: {
                type: Object
            },
            oldValue: {
                type: Object
            },
            isEdit: {
                type: Boolean,
                value: !1
            },
            hasTips: {
                type: Boolean,
                value: !1
            }
        }, I = function(e) {
            function t(t, a, i, r, n, o, s) {
                var c = e.call(this) || this;
                return c.customValidator = t, c.fileService = a, c.apiService = i, c.utilService = r, 
                c.monoUtil = n, c.formService = o, c.scopeFileService = s, c.properties = T, c.value = {}, 
                c.errorList = [], c.valid = !1, c.data = {
                    leftTimeToGetVerifyCode: -1,
                    authMode: f.getAuthConfiguration(2)
                }, c.options = {
                    multipleSlots: !0
                }, c.externalClasses = [ "custom-img-class" ], c.leftTimeToGetVerifyCodeTimer = null, 
                c;
            }
            i.__extends(t, e);
            var a = t.prototype;
            return a.ready = function() {
                var t;
                e.prototype.ready.call(this), this.setData({
                    defaultArea: {
                        code: p.CHINA_PHONE_CODE,
                        label: "中国大陆"
                    },
                    inputCursorSpacing: (null === (t = this.data.form) || void 0 === t ? void 0 : t.inputCursorSpacing) || 0
                }), this.initData(), this.initLocationAuthInfo(), this.startCheckLeftTimeToGetVerifyCode();
            }, a.detached = function() {
                var t;
                e.prototype.detached.call(this), null === (t = this.leftTimeToGetVerifyCodeTimer) || void 0 === t || t.unsubscribe();
            }, a.handleChange = function(e) {
                this.setBooleanTrueAndSetTimeoutFalse("isHideRealButton");
                var t = e.detail.value, a = e.currentTarget.dataset.key, i = this.getProperty(e).formType;
                this.setValueData(a, t, "textarea" === i), this.changeEvent();
            }, a.handleChangeOutSide = function(e, t, a) {
                void 0 === a && (a = !1), this.setBooleanTrueAndSetTimeoutFalse("isHideRealButton"), 
                this.setValueData(e, t, a), this.changeEvent();
            }, a.handleChangePicker = function(e) {
                var t = e.currentTarget.dataset.key, a = e.detail.value, i = this.getProperty(e).enum[a].value;
                this.setValueData(t, i), this.changeEvent();
            }, a.handleChangeRadio = function(e) {
                var t = e.currentTarget.dataset, a = t.key, i = t.value;
                this.setValueData(a, i), this.changeEvent();
            }, a.handleChangeRegionPicker = function(e) {
                var t = e.currentTarget.dataset.key, a = e.detail;
                this.setValueData(t, a.value), this.setValueData(t + "Code", a.code), this.changeEvent();
            }, a.handleTapCustomActionButton = function(e) {
                this.triggerEvent("tapInputAction", {
                    key: e.currentTarget.dataset.key
                });
            }, a.handleChangeSwitch = function(e) {
                var t = e.currentTarget.dataset.key, a = e.detail.value, i = this.getProperty(e).enum;
                if (i) {
                    var r = i.find(function(e) {
                        return e.res === a;
                    });
                    this.setValueData(t, r ? r.value : void 0);
                } else this.setValueData(t, a);
                this.changeEvent();
            }, a.handleTapShowImageActionSheets = function(e) {
                var t = this, a = e.currentTarget.dataset, i = a.disabled, r = a.deletable;
                if (!i) {
                    var n = [ "查看", "更换" ];
                    !1 !== r && n.push("删除"), wx.showActionSheet({
                        itemList: n,
                        success: function(a) {
                            var i = n[a.tapIndex];
                            "查看" === i ? t.handleTapCheckImage(e) : "更换" === i ? t.handleTapUploadAnImage(e) : "删除" === i && t.handleTapDeleteImage(e);
                        }
                    });
                }
            }, a.handleTapCheckImage = function(e) {
                var t, a, i = this, r = e.currentTarget.dataset.key, n = (null === (t = this.data.value) || void 0 === t ? void 0 : t[r + "PreviewPath"]) || (null === (a = this.data.value) || void 0 === a ? void 0 : a[r]) || [];
                n.length && (Array.isArray(n) || (n = [ n ]), n = n.map(function(e) {
                    return i.utilService.imgUrl(e, !0);
                }), wx.previewImage({
                    urls: n
                }));
            }, a.handleTapUploadAnImage = function(e) {
                var t = this, a = e.currentTarget.dataset, i = a.disabled, r = a.key, n = a.scope;
                if (!i) {
                    var o = this.scopeFileService.checkUploader() ? this.scopeFileService.uploadAnImage({}, {}, n) : this.fileService.uploadAnImage({}, {}, n);
                    o && o.subscribe(function(e) {
                        var a = e.path;
                        "private" === n && t.getPrivateImgPreviewPath(r, a), t.setValueData(r, a), t.changeEvent();
                    });
                }
            }, a.handleChooseAvatar = function(e) {
                var t = this, a = e.currentTarget.dataset, i = a.disabled, r = a.key, n = a.scope;
                if (!i) {
                    var o = e.detail.avatarUrl;
                    this.fileService.upload(o, {}, n).subscribe(function(e) {
                        var a = e.path;
                        "private" === n && t.getPrivateImgPreviewPath(r, a), t.setValueData(r, a), t.changeEvent();
                    });
                }
            }, a.handleTapUploadImages = function(e) {
                var t = this, a = e.currentTarget.dataset, i = a.key;
                a.scope, (this.scopeFileService.checkUploader() ? this.scopeFileService.uploadImages() : this.fileService.uploadImages()) && this.fileService.uploadImages().subscribe(function(e) {
                    t.setValueData(i, (t.value && t.value[i] || []).concat(e)), t.changeEvent();
                });
            }, a.handleTapDeleteImage = function(e) {
                var t = e.currentTarget.dataset, a = t.disabled, i = t.key, r = t.scope;
                a || ("private" === r && this.setValueData(i + "PreviewPath", ""), this.setValueData(i, ""), 
                this.changeEvent());
            }, a.handleTapPhoneButton = function(e) {
                this.setBooleanTrueAndSetTimeoutFalse("isShowMask");
            }, a.getPhoneNumber = function(e) {
                var t = this, a = e.detail;
                if (wx.hideLoading({}), "getPhoneNumber:ok" === a.errMsg) {
                    var i = function() {
                        t.utilService.getApp().login().subscribe(function() {
                            t.setPhoneFromWeChat(e, a.encryptedData, a.iv);
                        });
                    };
                    c.rxwx.checkSession({}).subscribe(function(r) {
                        "checkSession:ok" === r.errMsg ? t.setPhoneFromWeChat(e, a.encryptedData, a.iv) : i();
                    }, function() {
                        i();
                    });
                } else this.showError("微信授权手机号失败");
            }, a.handleGetVerifyCode = function(e, t) {
                var a, i = this, r = this.getProperty(e), n = r.relativeKey, o = this.data.value[n], s = this.data.form.properties.find(function(e) {
                    return e.key === n;
                }), c = this.data.value[n + "Area"];
                if (!o) return this.showError("请输入电话号码"), t();
                if (!this.checkIsForeignPhone(s) && !this.monoUtil.isPhone(o)) return this.showError("请输入正确的电话号码"), 
                t();
                r.key !== r.relativeKey && this.setData(((a = {})["isFocusInput." + r.key] = !0, 
                a));
                var u = this.formService.getLeftTimeToGetVerifyCode();
                this.setData({
                    leftTimeToGetVerifyCode: u
                }), (r.codeType ? this.formService.getVerifyCode(o, r.codeType, r.captchaParams) : this.formService.getGhVerifyCode(o, c || "")).pipe(C.finalize(t)).subscribe(function(e) {
                    e.success && i.setValueData("requestId", e.requestId);
                });
            }, a.handleTapShowGlobalPhoneAreaCodeList = function(e) {
                var t, a, i = e.currentTarget.dataset, r = i.key, n = i.area;
                a = n && n !== this.data.defaultArea.code ? n === (null === (t = this.data.currentArea) || void 0 === t ? void 0 : t.code) ? this.data.currentArea : {
                    code: n
                } : this.data.defaultArea, this.setData({
                    isShowGlobalPhoneAreaCodeModal: !0,
                    currentAreaKey: r,
                    currentArea: a
                }), this.triggerEvent("toggleGlobalPhoneModal", !0);
            }, a.handleTapConfirmSelectPhoneArea = function(e) {
                var t = this, a = this.data.value || {}, i = e.detail;
                a[this.data.currentAreaKey] = i.code, this.setData({
                    isShowGlobalPhoneAreaCodeModal: !1,
                    currentArea: i,
                    value: a
                }, function() {
                    t.changeEvent();
                }), this.triggerEvent("toggleGlobalPhoneModal", !1);
            }, a.handleTapCancelSelectPhoneArea = function(e) {
                this.setData({
                    isShowGlobalPhoneAreaCodeModal: !1
                }), this.triggerEvent("toggleGlobalPhoneModal", !1);
            }, a.getAuthInfo = function() {
                var e = this;
                f.getAuthSettingInfo().subscribe(function(t) {
                    var a, i = e.data.authMode;
                    if (void 0 !== t.authSetting["scope." + i.scope]) {
                        var r = t.authSetting["scope." + i.scope];
                        e.setData(((a = {})["authMode.isAuthorize"] = r, a));
                    }
                });
            }, a.handleAuthorizeLocationResult = function(e) {
                this.getAuthInfo();
                var t = e.detail, a = e.currentTarget.dataset.key;
                t && (this.setValueData(a, t), this.changeEvent());
            }, a.handleInputLocationName = function(e) {
                var t = e.detail.value || "", a = e.currentTarget.dataset.key;
                return this.setValueData(a, i.__assign(i.__assign({}, this.value[a]), {
                    name: t
                })), this.changeEvent(), e.detail.value;
            }, a.handleBlurInput = function(e) {
                var t, a = e.currentTarget.dataset.key;
                this.setData(((t = {})["isFocusInput." + a] = !1, t));
            }, a.handleFocusInput = function(e) {
                var t, a = e.currentTarget.dataset.key;
                this.setData(((t = {})["isFocusInput." + a] = !0, t));
            }, a.handleTapOptional = function(e) {
                var t = e.currentTarget.dataset.eventName;
                t && this.triggerEvent(t);
            }, a.refreshData = function() {
                this.initData();
            }, a.setFormData = function(e) {
                var t = this;
                void 0 === e && (e = {}), this.data.form.properties.forEach(function(a) {
                    "private" === a.imgUploadScope && e[a.key] && t.getPrivateImgPreviewPath(a.key, e[a.key]);
                }), Object.assign(this.value, e), this.setData({
                    value: this.value
                }), this.changeEvent();
            }, a.initData = function() {
                this.data.isEdit && this.hackEmptyPhoneCode();
                var e = this.mergeInitData(this.data.isEdit);
                this.value = e, this.setData({
                    value: e
                }), this.changeEvent();
            }, a.initLocationAuthInfo = function() {
                this.data.form.properties.some(function(e) {
                    return e.formType.toString().toLowerCase().includes("location");
                }) && this.getAuthInfo();
            }, a.showError = function(e) {
                this.triggerEvent("showError", {
                    errMsg: e
                });
            }, a.getProperty = function(e) {
                var t = e.currentTarget.dataset.index;
                return this.data.form.properties[t];
            }, a.mergeInitData = function(e) {
                var t = this;
                void 0 === e && (e = !1);
                var a = {};
                return (this.data.form.properties || []).forEach(function(e) {
                    var i;
                    e.default && (a[e.key] = e.default), e.isGlobalPhone && (a[e.key + "Area"] = t.data.defaultArea.code), 
                    "private" === e.imgUploadScope && t.getPrivateImgPreviewPath(e.key, null === (i = t.data.oldValue) || void 0 === i ? void 0 : i[e.key]);
                }), Object.assign(a, e ? this.data.oldValue : {}, this.value);
            }, a.hackEmptyPhoneCode = function() {
                var e = this, t = this.data.oldValue;
                t && ((this.data.form.properties || []).forEach(function(a) {
                    a.isGlobalPhone && !t[a.key + "Area"] && (t[a.key + "Area"] = e.data.defaultArea.code);
                }), this.setData({
                    oldValue: t
                }));
            }, a.startCheckLeftTimeToGetVerifyCode = function() {
                var e = this;
                this.leftTimeToGetVerifyCodeTimer = v.interval(1e3).subscribe(function() {
                    var t = e.formService.getLeftTimeToGetVerifyCode();
                    e.setData({
                        leftTimeToGetVerifyCode: t
                    });
                });
            }, a.setBooleanTrueAndSetTimeoutFalse = function(e, t) {
                var a, i = this;
                void 0 === t && (t = 1e3), this.setData(((a = {})[e] = !0, a)), setTimeout(function() {
                    var t;
                    i.setData(((t = {})[e] = !1, t));
                }, t);
            }, a.setPhoneFromWeChat = function(e, t, a) {
                var i = this;
                this.apiService.getUserPhoneUsingPOST({
                    encryptedData: t,
                    iv: a
                }, {
                    isShowLoading: !0
                }).subscribe(function(t) {
                    var a, r = t.data, n = r.purePhoneNumber, o = r.countryCode;
                    if (n) {
                        var s = e.currentTarget.dataset.key;
                        i.setData(((a = {})["value." + s] = n, a["value." + s + "Area"] = o || p.CHINA_PHONE_CODE, 
                        a)), i.changeEvent();
                    }
                });
            }, a.getPrivateImgPreviewPath = function(e, t) {
                var a = this;
                t && this.fileService.getPrivateImagePreviewPath(t).subscribe(function(t) {
                    a.setValueData(e + "PreviewPath", t), a.changeEvent();
                });
            }, i.__decorate([ b.Lock(), i.__metadata("design:type", Function), i.__metadata("design:paramtypes", [ Object, Function ]), i.__metadata("design:returntype", void 0) ], t.prototype, "handleGetVerifyCode", null), 
            t = i.__decorate([ n.wxComponent(), i.__metadata("design:paramtypes", [ o.CustomValidatorService, s.FileService, u.DefaultService, l.UtilService, d.MonoUtilService, h.FormService, g.ScopeFileService ]) ], t);
        }(y.miniMixin(m.InfoFormSetValueMixin, r.SuperComponent));
        t.InfoForm = I;
    },
    676: function(e, t, a) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.InfoFormSetValueMixin = void 0;
        var i = a(0), r = a(9), n = a(4), o = a(68), s = a(677), c = function(e) {
            function t(t) {
                var a = e.call(this) || this;
                return a.customValidator = t, a;
            }
            i.__extends(t, e);
            var a = t.prototype;
            return a.setValueData = function(e, t, a) {
                var i;
                void 0 === a && (a = !1), "string" != typeof t || a || (t = t.trim()), this.value[e] = t, 
                this.setData(((i = {})["value." + e] = t, i));
            }, a.changeEvent = function() {
                this.validatorValue();
                var e = {
                    value: this.value,
                    errorList: this.errorList,
                    valid: !this.errorList.length,
                    requiredValid: !this.errorList.filter(function(e) {
                        return !e.priority;
                    }).length,
                    changeValue: this.data.isEdit ? this.comparedChange() : void 0
                };
                this.triggerEvent("changeData", {
                    formReturn: e
                });
            }, a.comparedChange = function() {
                var e = this, t = {}, a = this.value, i = this.data.oldValue;
                return this.data.form.properties.forEach(function(r) {
                    var n = r.key, s = i[n], c = a[n];
                    if (r.isGlobalPhone) {
                        var u = n + "Area", l = !i[u] || i[u] === o.CHINA_PHONE_CODE;
                        (l && e.value[u] !== o.CHINA_PHONE_CODE || !l && i[u] !== e.value[u]) && (t[u] = e.value[u]);
                    }
                    if ("location" !== r.formType && "editableLocation" !== r.formType) c !== s && ("captcha" === r.formType && a.requestId !== i.requestId && (t.requestId = a.requestId), 
                    t[n] = c); else {
                        var d = e.comparedLocationChange(c, s);
                        t[n] = d ? c : void 0;
                    }
                }), t;
            }, a.comparedLocationChange = function(e, t) {
                return e && t ? [ "address", "latitude", "longitude", "name" ].some(function(a) {
                    return e[a] !== t[a];
                }) : e !== t;
            }, t;
        }(r.miniMixin(s.InfoFormValidatorMixin, n.SuperComponent));
        t.InfoFormSetValueMixin = c;
    },
    677: function(e, t, a) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.InfoFormValidatorMixin = void 0;
        var i = a(0), r = a(4), n = a(68), o = function(e) {
            function t(t) {
                var a = e.call(this) || this;
                return a.customValidator = t, a;
            }
            i.__extends(t, e);
            var a = t.prototype;
            return a.validatorValue = function() {
                var e = this, t = [], a = this.data.form.properties, i = this.value;
                a.forEach(function(a) {
                    var r = "editableLocation" === a.formType, n = i[a.key];
                    if (e.getIfShow(a, i)) {
                        var o = e.checkEmpty(r ? null == n ? void 0 : n.name : n);
                        a.required && !e.checkIsRelativeKeyNotRequiredAndValueEmpty(a) && o && t.push(e.getError(a.requiredErrMsg || a.title + "为必填项", 0, "required", a.key)), 
                        o || ("phone" !== a.formType || e.checkIsForeignPhone(a) || e.validatorCustom(n, t, "phoneValidator", a), 
                        "captcha" === a.formType && e.validatorCustom(n, t, "captchaValidator", a), a.validators && a.validators.length && a.validators.forEach(function(i) {
                            e.validatorCustom(n, t, i, a);
                        }));
                    }
                }), this.errorList = t;
            }, a.checkIsForeignPhone = function(e) {
                var t = this.data.value;
                return !(!t[e.key + "Area"] || t[e.key + "Area"] === n.CHINA_PHONE_CODE);
            }, a.getError = function(e, t, a, i) {
                return {
                    errMsg: e,
                    priority: t,
                    type: a,
                    key: i
                };
            }, a.getIfShow = function(e, t) {
                return !e.if || e.if.keyValueMap["EVERY" === e.if.type ? "every" : "some"](function(e) {
                    var a = t[e.key] === e.value;
                    return e.reverse ? !a : a;
                });
            }, a.checkEmpty = function(e) {
                return 0 !== e && !1 !== e && !e;
            }, a.checkIsRelativeKeyNotRequiredAndValueEmpty = function(e) {
                var t = e.relativeKey, a = void 0 === t ? "" : t;
                if (!a) return !1;
                var i = (this.data.form.properties.find(function(e) {
                    return e.key === a;
                }) || {}).required;
                return !(void 0 !== i && i) && this.checkEmpty(this.data.value[a]);
            }, a.validatorCustom = function(e, t, a, i) {
                if (this.customValidator[a]) {
                    var r = this.customValidator[a](e, i);
                    r && t.push(r);
                }
            }, t;
        }(r.SuperComponent);
        t.InfoFormValidatorMixin = o;
    },
    68: function(e, t, a) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.CHINA_PHONE_CODE = void 0;
        var i, r = a(0), n = a(4), o = a(1), s = a(69), c = a(28);
        t.CHINA_PHONE_CODE = "86", function(e) {
            e[e.COMMON = 0] = "COMMON", e[e.LIST = 1] = "LIST";
        }(i || (i = {}));
        var u = {
            isVisible: {
                type: Boolean,
                observer: function(e) {
                    var t;
                    e && ((null === (t = this.data.capitalAreaCodeList) || void 0 === t ? void 0 : t.length) ? (this.initCurrentSelected(), 
                    this.createIntersectionObserverInstance()) : this.initPhoneAreaList());
                }
            },
            currentArea: Object
        };
        !function(e) {
            function a(a) {
                var i = e.call(this) || this;
                return i.apiService = a, i.properties = u, i.data = {
                    commonAreaCodeList: [ {
                        code: t.CHINA_PHONE_CODE,
                        label: "中国大陆"
                    }, {
                        code: "852",
                        label: "中国香港"
                    }, {
                        code: "853",
                        label: "中国澳门"
                    }, {
                        code: "886",
                        label: "中国台湾"
                    }, {
                        code: "1",
                        label: "美国"
                    }, {
                        code: "65",
                        label: "新加坡"
                    }, {
                        code: "81",
                        label: "日本"
                    }, {
                        code: "60",
                        label: "马来西亚"
                    }, {
                        code: "1",
                        label: "加拿大"
                    }, {
                        code: "82",
                        label: "韩国"
                    } ]
                }, i.indexListPositionTop = 0, i.indexItemHeight = 0, i;
            }
            r.__extends(a, e);
            var i = a.prototype;
            i.detached = function() {
                e.prototype.detached.call(this), this.disconnectIntersectionObserver();
            }, i.initPhoneAreaList = function() {
                var e = this;
                this.apiService.getCountryCodeListUsingGET().subscribe(function(t) {
                    var a = t.data || [], i = e.formatAreaCodeList(a);
                    e.setData({
                        currentCapital: i[0].capital,
                        capitalAreaCodeList: i
                    }, function() {
                        e.initCurrentSelected(), e.createIntersectionObserverInstance(), setTimeout(function() {
                            e.computeIndexListSize();
                        }, 500);
                    });
                });
            }, i.handleTapSelectArea = function(e) {
                this.triggerEvent("selectArea", e.currentTarget.dataset.area);
            }, i.handleTapCancel = function() {
                this.triggerEvent("cancel");
            }, i.handleScrollToCapital = function(e) {
                var t = e.changedTouches[0].clientY, a = Math.floor((t - this.indexListPositionTop) / this.indexItemHeight);
                this.scrollToCapital(a);
            }, i.scrollToCapital = function(e) {
                var t, a = (null === (t = this.data.capitalAreaCodeList[e]) || void 0 === t ? void 0 : t.capital) || "";
                a && this.setData({
                    currentCapital: a,
                    currentScrollView: "capital-" + (0 === e ? "0" : a)
                });
            }, i.initCurrentSelected = function() {
                var e = this.data.currentArea;
                e && -1 === this.data.commonAreaCodeList.findIndex(function(t) {
                    return t.code === e.code && t.label === e.label;
                }) ? this.setData({
                    currentScrollView: encodeURI("area-" + e.label + e.code).replace(/%/g, "")
                }) : this.scrollToCapital(0);
            }, i.createIntersectionObserverInstance = function() {
                var e = this;
                this.IntersectionObserverInstance = this.createIntersectionObserver({
                    initialRatio: 0,
                    observeAll: !0
                }), this.IntersectionObserverInstance.relativeTo("#capitalSticky", {
                    top: 0,
                    bottom: 0
                }), this.IntersectionObserverInstance.observe(".capital-box", function(t) {
                    return e.intersectionObserverCallback(t);
                });
            }, i.computeIndexListSize = function() {
                var e = this;
                this.createSelectorQuery().select("#indexList").boundingClientRect(function(t) {
                    e.indexListPositionTop = t.top, e.indexItemHeight = t.height / e.data.capitalAreaCodeList.length;
                }).exec();
            }, i.intersectionObserverCallback = function(e) {
                if (e.intersectionRatio > 0) {
                    var t = e.id.split("-")[1];
                    this.setData({
                        currentCapital: t
                    });
                }
            }, i.disconnectIntersectionObserver = function() {
                var e;
                "function" == typeof (null === (e = this.IntersectionObserverInstance) || void 0 === e ? void 0 : e.disconnect) && this.IntersectionObserverInstance.disconnect();
            }, i.formatAreaCodeList = function(e) {
                for (var t = [], a = {}, i = 0, r = 0, n = e.length; r < n; r++) {
                    var o = e[r];
                    if (o.index) {
                        var s = {
                            label: o.countryName,
                            code: o.phoneCode,
                            id: encodeURI("area-" + o.countryName + o.phoneCode).replace(/%/g, "")
                        }, c = o.index.toUpperCase();
                        a.hasOwnProperty(c) ? t[a[c]].areaList.push(s) : (a[c] = i++, t.push({
                            capital: c,
                            areaList: [ s ]
                        }));
                    }
                }
                return t;
            }, r.__decorate([ s.Throttle(100), r.__metadata("design:type", Function), r.__metadata("design:paramtypes", [ Object ]), r.__metadata("design:returntype", void 0) ], a.prototype, "handleScrollToCapital", null), 
            a = r.__decorate([ o.wxComponent(), r.__metadata("design:paramtypes", [ c.DefaultService ]) ], a);
        }(n.SuperComponent);
    }
}, [ [ 675, 0, 2, 1 ] ] ]));