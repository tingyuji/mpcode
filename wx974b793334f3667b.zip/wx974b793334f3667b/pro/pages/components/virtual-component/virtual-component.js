var o = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
    return typeof o;
} : function(o) {
    return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
};

require("./../../../../runtime"), require("./../../../../mono"), require("./../../../../common"), 
function(o, e) {
    for (var n in e) o[n] = e[n];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 157 ], {
    2: function(e, n) {
        var t;
        t = function() {
            return this;
        }();
        try {
            t = t || new Function("return this")();
        } catch (e) {
            "object" == ("undefined" == typeof window ? "undefined" : o(window)) && (t = window);
        }
        e.exports = t;
    },
    719: function(o, e, n) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        });
        var t = n(0), r = n(4), i = n(1), c = n(98);
        !function(o) {
            function e(e) {
                var n = o.call(this) || this;
                return n.processMonitor = e, n;
            }
            t.__extends(e, o), e.prototype.ready = function() {
                this.processMonitor.end();
            }, e = t.__decorate([ i.wxComponent(), t.__metadata("design:paramtypes", [ c.PerformanceProcessMonitorService ]) ], e);
        }(r.SuperComponent);
    }
}, [ [ 719, 0, 2, 1 ] ] ]));