var e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
};

require("./../../../../runtime"), require("./../../../../mono"), require("./../../../../common"), 
function(e, t) {
    for (var i in t) e[i] = t[i];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 96 ], {
    2: function(t, i) {
        var r;
        r = function() {
            return this;
        }();
        try {
            r = r || new Function("return this")();
        } catch (t) {
            "object" == ("undefined" == typeof window ? "undefined" : e(window)) && (r = window);
        }
        t.exports = r;
    },
    761: function(e, t, i) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var r = i(0), a = i(4), s = i(1), o = i(10), n = i(5), c = i(6), u = i(17), d = i(151), p = i(7), v = i(15), l = i(3), g = i(44), m = i(75), y = i(440), S = i(60), h = i(11), f = {
            isGoNews: {
                type: Boolean,
                observer: function(e) {
                    this.initData();
                }
            },
            isShowRedDot: {
                type: Boolean,
                value: !1
            },
            isShowText: {
                type: Boolean,
                value: !1
            },
            isShowIcon: {
                type: Boolean,
                value: !0
            },
            isGetUidMessage: {
                type: Boolean,
                value: !1
            },
            isTwoIdentities: {
                type: Boolean,
                value: !1
            },
            groupId: {
                type: String
            },
            groupType: {
                type: Number
            },
            actId: {
                type: String
            },
            chatUserType: {
                type: String
            },
            fromId: {
                type: String
            },
            toId: {
                type: String
            },
            seqType: {
                type: Number
            },
            orderNo: {
                type: String
            },
            iconShape: {
                type: String,
                value: ""
            },
            iconSize: {
                type: String,
                value: ""
            },
            spotDirection: {
                type: String,
                value: ""
            },
            textColor: {
                type: String,
                value: ""
            },
            isSpotRight: {
                type: Boolean,
                value: !1
            },
            isBackstage: {
                type: Boolean,
                value: !1
            },
            isCustomerServiceList: {
                type: Boolean,
                value: !1
            },
            isSlot: {
                type: Boolean,
                value: !1
            },
            customerServiceMessageNumber: Number,
            isRefreshCustomerServiceMessage: {
                type: Boolean,
                observer: function(e) {
                    this.initData();
                }
            },
            isOnShowRefresh: Boolean,
            isOnPullDownRefreshMessage: {
                type: Boolean,
                observer: function(e) {
                    e && (this.setData({
                        isOnPullDownRefreshMessage: !1
                    }), this.initData());
                }
            },
            pactId: String,
            showRedDotOrRedNumber: {
                type: Boolean,
                value: !0
            },
            entranceScene: String,
            imTypeParams: Object,
            asOrderNo: String,
            extraParams: Object,
            textValue: String
        };
        !function(e) {
            function t(t, i, a, s, o, n, c, u) {
                var d = e.call(this) || this;
                return d.routerService = t, d.apiService = i, d.util = a, d.grayService = s, d.customerServiceMessageService = o, 
                d.commonService = n, d.imService = c, d.monoUtilService = u, d.properties = f, d.data = r.__assign({}, y.CustomerServiceEntryEventNameMap), 
                d;
            }
            r.__extends(t, e);
            var i = t.prototype;
            i.ready = function() {
                e.prototype.ready.call(this), this.data.isOnShowRefresh || this.initData();
            }, i.handleTapCustomerServiceTalk = function() {
                var e = this;
                this.imService.getChatUserTypeAndToId(this.data.chatUserType, this.data.toId, this.data.imTypeParams).subscribe(function(t) {
                    var i = e.data, a = i.actId, s = i.seqType, o = i.orderNo, n = i.pactId, c = i.fromId, u = i.entranceScene, d = i.asOrderNo, p = t.chatUserType, v = t.toId, l = t.hasBindingOfficial, g = t.fromUserType, m = t.toUserType, y = !a || [ "3", "5" ].includes(p) && !o ? null : {
                        actId: a
                    }, S = e.monoUtilService.isEmpty(g) || e.monoUtilService.isEmpty(m) || l ? {
                        chatUserType: p
                    } : {
                        fromUserType: g,
                        toUserType: m
                    };
                    e.routerService.goCustomerServiceChatPage({
                        type: "navigateTo",
                        data: r.__assign(r.__assign(r.__assign(r.__assign(r.__assign(r.__assign(r.__assign(r.__assign(r.__assign({}, S), {
                            toId: v
                        }), c ? {
                            fromId: c
                        } : null), s ? {
                            seqType: s
                        } : null), o ? {
                            orderNo: o
                        } : null), n ? {
                            pactId: n
                        } : null), y), u ? {
                            entranceScene: u
                        } : null), d ? {
                            asOrderNo: d
                        } : null)
                    }), e.setData({
                        customerServiceMessageNumber: 0
                    }), e.data.isCustomerServiceList && e.customerServiceMessageService.tapCustomerServiceMessage(e.data.toId + "");
                });
            }, i.handleTapCustomerServiceNews = function() {
                this.routerService.goCustomerServiceMessageList({
                    type: "navigateTo",
                    data: {
                        groupId: this.data.groupId,
                        groupType: this.data.groupType
                    }
                });
            }, i.initData = function() {
                this.uid = String(this.util.getUid()), this.data.isCustomerServiceList || (this.data.isGoNews ? this.getAllMessage() : this.getUnReadMessage());
            }, i.getUnReadMessage = function() {
                var e = this;
                this.setData({
                    customerServiceMessageNumber: 0
                });
                var t = this.getReceiverIdAndSenderIdList(), i = t.receiverId, r = t.senderIdList;
                this.apiService.queryUnReadMessageListUsingPOST({
                    receiverId: i,
                    senderIdList: r
                }).subscribe(function(t) {
                    var i = t.data || [];
                    e.setData({
                        customerServiceMessageNumber: i[0]
                    });
                });
            }, i.getReceiverIdAndSenderIdList = function() {
                var e, t;
                if ("1" === this.data.chatUserType) e = 1, t = 1; else if ("0" === this.data.chatUserType) e = 1, 
                t = 0; else if ("4" === this.data.chatUserType) e = 2, t = 0; else if ("2" === this.data.chatUserType) e = 0, 
                t = 1; else if ("3" === this.data.chatUserType) e = 0, t = 2; else if ("5" === this.data.chatUserType) e = 1, 
                t = 2; else {
                    if ("6" !== this.data.chatUserType) throw new Error("错误的类型");
                    e = 2, t = 1;
                }
                return {
                    receiverId: this.commonService.generateTIMLoginId(this.data.fromId || "", e),
                    senderIdList: [ this.commonService.generateTIMLoginId(this.data.toId || "", t) ]
                };
            }, i.getAllMessage = function() {
                var e = this;
                this.setData({
                    customerServiceMessageNumber: 0
                });
                var t = function(t) {
                    var i = e.commonService.generateTIMLoginId, a = 1 === t ? [ e.data.groupId, 1 ] : [ e.uid, 0 ];
                    return a[0] ? e.apiService.queryAllMessageCountUsingGET(i.apply(void 0, r.__spread(a))).pipe(l.map(function(e) {
                        return e.data || 0;
                    })) : p.of(0);
                }, i = [];
                this.data.isTwoIdentities ? (i.push(t(0)), i.push(t(1))) : this.data.isGetUidMessage ? i.push(t(0)) : i.push(t(1)), 
                p.forkJoin(i).subscribe(function(t) {
                    var i = t.reduce(function(e, t) {
                        return e + t;
                    }, 0);
                    e.setData({
                        customerServiceMessageNumber: i
                    }), e.triggerEvent("msgNumChange", {
                        msgNum: i
                    });
                });
            }, r.__decorate([ m.BindEvent(y.CustomerServiceEntryEventNameMap.GO_CHAT_PAGE, y.CustomerServiceEntryEventNameMap), r.__metadata("design:type", Function), r.__metadata("design:paramtypes", []), r.__metadata("design:returntype", void 0) ], t.prototype, "handleTapCustomerServiceTalk", null), 
            r.__decorate([ g.Debounce(300), r.__metadata("design:type", Function), r.__metadata("design:paramtypes", []), r.__metadata("design:returntype", void 0) ], t.prototype, "getUnReadMessage", null), 
            t = r.__decorate([ s.wxComponent(), r.__metadata("design:paramtypes", [ o.RouteService, n.DefaultService, c.UtilService, u.GrayFeatureService, d.CustomerServiceMessageService, v.CommonService, S.ImService, h.MonoUtilService ]) ], t);
        }(a.SuperComponent);
    }
}, [ [ 761, 0, 2, 1 ] ] ]));