var t = Object.assign || function(t) {
    for (var i = 1; i < arguments.length; i++) {
        var e = arguments[i];
        for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
    }
    return t;
};

require("./../../../../runtime"), function(t, i) {
    for (var e in i) t[e] = i[e];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 120 ], {
    767: function(i, e) {
        var o = {
            drawBlock: function(t) {
                var i = t.text, e = t.width, o = void 0 === e ? 0 : e, s = t.height, n = t.x, r = t.y, h = t.paddingLeft, a = void 0 === h ? 0 : h, c = t.paddingRight, x = void 0 === c ? 0 : c, d = t.borderWidth, l = t.backgroundColor, u = t.borderColor, f = t.borderRadius, g = void 0 === f ? 0 : f, P = t.opacity, v = void 0 === P ? 1 : P, p = 0, w = 0, m = 0;
                if (void 0 !== i) {
                    var b = this._getTextWidth("string" == typeof i.text ? i : i.text);
                    p = b > o ? b : o, p += a + a;
                    var y = i.textAlign, I = void 0 === y ? "left" : y, S = (i.text, i.fontSize);
                    m = s / 2 + (i.lineHeight || S) / 2 + r, w = "left" === I ? n + a : "center" === I ? p / 2 + n : n + p - x;
                } else p = o;
                l && (this.ctx.save(), this.ctx.setGlobalAlpha(v), this.ctx.setFillStyle(l), g > 0 ? (this._drawRadiusRect(n, r, p, s, g), 
                this.ctx.fill()) : this.ctx.fillRect(this.toPx(n), this.toPx(r), this.toPx(p), this.toPx(s)), 
                this.ctx.restore()), d && (this.ctx.save(), this.ctx.setGlobalAlpha(v), this.ctx.setStrokeStyle(u), 
                this.ctx.setLineWidth(this.toPx(d)), g > 0 ? (this._drawRadiusRect(n, r, p, s, g), 
                this.ctx.stroke()) : this.ctx.strokeRect(this.toPx(n), this.toPx(r), this.toPx(p), this.toPx(s)), 
                this.ctx.restore()), i && this.drawText(Object.assign(i, {
                    x: w,
                    y: m
                }));
            },
            drawText: function(i) {
                var e = this, o = i.x, s = i.y, n = (i.fontSize, i.color, i.baseLine), r = (i.textAlign, 
                i.text);
                i.opacity, i.width, i.lineNum, i.lineHeight;
                if ("[object Array]" === Object.prototype.toString.call(r)) {
                    var h = {
                        x: o,
                        y: s,
                        baseLine: n
                    };
                    r.forEach(function(i) {
                        h.x += i.marginLeft || 0;
                        var o = e._drawSingleText(Object.assign(i, t({}, h)));
                        h.x += o + (i.marginRight || 0);
                    });
                } else this._drawSingleText(i);
            },
            drawImage: function(t) {
                var i = t.imgPath, e = t.x, o = t.y, s = t.w, n = t.h, r = t.sx, h = t.sy, a = t.sw, c = t.sh, x = t.borderRadius, d = void 0 === x ? 0 : x, l = t.borderWidth, u = void 0 === l ? 0 : l, f = t.borderColor, g = t.circle, P = t.backgroundColor;
                this.ctx.save(), d > 0 ? (this._drawRadiusRect(e, o, s, n, d), this.ctx.clip(), 
                this.ctx.drawImage(i, this.toPx(r), this.toPx(h), this.toPx(a), this.toPx(c), this.toPx(e), this.toPx(o), this.toPx(s), this.toPx(n)), 
                u > 0 && (this.ctx.setStrokeStyle(f), this.ctx.setLineWidth(this.toPx(u)), this.ctx.stroke())) : (g && (this.ctx.beginPath(), 
                this.ctx.arc(this.toPx(e + s / 2), this.toPx(o + s / 2), this.toPx(s / 2 + u), 0, 2 * Math.PI), 
                this.ctx.setFillStyle(P), this.ctx.fill(), this.ctx.clip()), this.ctx.drawImage(i, this.toPx(r), this.toPx(h), this.toPx(a), this.toPx(c), this.toPx(e), this.toPx(o), this.toPx(s), this.toPx(n))), 
                this.ctx.restore();
            },
            drawLine: function(t) {
                var i = t.startX, e = t.startY, o = t.endX, s = t.endY, n = t.color, r = t.width;
                this.ctx.save(), this.ctx.beginPath(), this.ctx.setStrokeStyle(n), this.ctx.setLineWidth(this.toPx(r)), 
                this.ctx.moveTo(this.toPx(i), this.toPx(e)), this.ctx.lineTo(this.toPx(o), this.toPx(s)), 
                this.ctx.stroke(), this.ctx.closePath(), this.ctx.restore();
            },
            downloadResource: function() {
                var t = this, i = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [], e = [];
                return this.drawArr = [], i.forEach(function(i, o) {
                    return e.push(t._downloadImageAndInfo(i, o));
                }), Promise.all(e);
            },
            initCanvas: function(t, i, e) {
                var o = this;
                return new Promise(function(s) {
                    o.setData({
                        pxWidth: o.toPx(t),
                        pxHeight: o.toPx(i),
                        debug: e
                    }, s);
                });
            }
        }, s = {
            _drawRadiusRect: function(t, i, e, o, s) {
                var n = s / 2;
                this.ctx.beginPath(), this.ctx.moveTo(this.toPx(t + n), this.toPx(i)), this.ctx.lineTo(this.toPx(t + e - n), this.toPx(i)), 
                this.ctx.arc(this.toPx(t + e - n), this.toPx(i + n), this.toPx(n), 2 * Math.PI * .75, 2 * Math.PI * 1), 
                this.ctx.lineTo(this.toPx(t + e), this.toPx(i + o - n)), this.ctx.arc(this.toPx(t + e - n), this.toPx(i + o - n), this.toPx(n), 0, 2 * Math.PI * .25), 
                this.ctx.lineTo(this.toPx(t + n), this.toPx(i + o)), this.ctx.arc(this.toPx(t + n), this.toPx(i + o - n), this.toPx(n), 2 * Math.PI * .25, 2 * Math.PI * .5), 
                this.ctx.lineTo(this.toPx(t), this.toPx(i + n)), this.ctx.arc(this.toPx(t + n), this.toPx(i + n), this.toPx(n), 2 * Math.PI * .5, 2 * Math.PI * .75);
            },
            _getTextWidth: function(t) {
                var i = this, e = [];
                "[object Object]" === Object.prototype.toString.call(t) ? e.push(t) : e = t;
                var o = 0;
                return e.forEach(function(t) {
                    var e = t.fontSize, s = t.text, n = t.marginLeft, r = void 0 === n ? 0 : n, h = t.marginRight, a = void 0 === h ? 0 : h;
                    i.ctx.setFontSize(i.toPx(e)), o += i.ctx.measureText(s).width + r + a;
                }), this.toRpx(o);
            },
            _drawSingleText: function(t) {
                var i = this, e = t.x, o = t.y, s = t.fontSize, n = t.color, r = t.baseLine, h = t.textAlign, a = void 0 === h ? "left" : h, c = t.text, x = t.opacity, d = void 0 === x ? 1 : x, l = t.textDecoration, u = void 0 === l ? "none" : l, f = t.width, g = t.lineNum, P = void 0 === g ? 1 : g, v = t.lineHeight, p = void 0 === v ? 0 : v, w = t.fontWeight, m = void 0 === w ? "normal" : w, b = t.fontStyle, y = void 0 === b ? "normal" : b, I = t.fontFamily, S = void 0 === I ? "sans-serif" : I;
                this.ctx.save(), this.ctx.beginPath(), this.ctx.font = y + " " + m + " " + this.toPx(s, !0) + "px " + S, 
                this.ctx.setGlobalAlpha(d), this.ctx.setFillStyle(n), this.ctx.setTextBaseline(r), 
                this.ctx.setTextAlign(a);
                var T = this.toRpx(this.ctx.measureText(c).width), R = [];
                if (T > f) {
                    var k = "", _ = 1, A = 0, z = !0, C = !1, E = void 0;
                    try {
                        for (var L, j = c[Symbol.iterator](); !(z = (L = j.next()).done); z = !0) {
                            var M = L.value;
                            k += M, A += M.length, this.toRpx(this.ctx.measureText(k).width) >= f ? (_ === P && A !== c.length && (k = k.substring(0, k.length - M.length) + "..."), 
                            _ <= P && R.push(k), k = "", _++) : _ <= P && A === c.length && R.push(k);
                        }
                    } catch (t) {
                        C = !0, E = t;
                    } finally {
                        try {
                            !z && j.return && j.return();
                        } finally {
                            if (C) throw E;
                        }
                    }
                    T = f;
                } else R.push(c);
                if (R.forEach(function(t, n) {
                    i.ctx.fillText(t, i.toPx(e), i.toPx(o + (p || s) * n));
                }), this.ctx.restore(), "none" !== u) {
                    var O = o;
                    "line-through" === u && (O = o), this.ctx.save(), this.ctx.moveTo(this.toPx(e), this.toPx(O)), 
                    this.ctx.lineTo(this.toPx(e) + this.toPx(T), this.toPx(O)), this.ctx.setStrokeStyle(n), 
                    this.ctx.stroke(), this.ctx.restore();
                }
                return T;
            }
        }, n = {
            _downloadImageAndInfo: function(t, i) {
                var e = this;
                return new Promise(function(o, s) {
                    var n = t.x, r = t.y, h = t.url, a = t.zIndex, c = h;
                    e._downImage(c, i).then(function(t) {
                        return e._getImageInfo(t, i);
                    }).then(function(s) {
                        var h = s.imgPath, c = s.imgInfo, x = void 0, d = void 0, l = t.borderRadius || 0, u = t.width, f = t.height, g = e.toRpx(c.width), P = e.toRpx(c.height);
                        g / P <= u / f ? (x = 0, d = (P - g / u * f) / 2) : (d = 0, x = (g - P / f * u) / 2), 
                        e.drawArr.push({
                            type: "image",
                            circle: t.circle,
                            borderRadius: l,
                            borderWidth: t.borderWidth,
                            borderColor: t.borderColor,
                            backgroundColor: t.backgroundColor,
                            zIndex: void 0 !== a ? a : i,
                            imgPath: h,
                            sx: x,
                            sy: d,
                            sw: g - 2 * x,
                            sh: P - 2 * d,
                            x: n,
                            y: r,
                            w: u,
                            h: f
                        }), o();
                    }).catch(function(t) {
                        o();
                    });
                });
            },
            _downImage: function(t) {
                return new Promise(function(i, e) {
                    /^http/.test(t) && !new RegExp(wx.env.USER_DATA_PATH).test(t) ? wx.downloadFile({
                        url: t,
                        success: function(t) {
                            200 === t.statusCode ? i(t.tempFilePath) : e(t.errMsg);
                        },
                        fail: function(t) {
                            e(t);
                        }
                    }) : i(t);
                });
            },
            _getImageInfo: function(t, i) {
                return new Promise(function(e, o) {
                    wx.getImageInfo({
                        src: t,
                        success: function(o) {
                            e({
                                imgPath: t,
                                imgInfo: o,
                                index: i
                            });
                        },
                        fail: function(t) {
                            o(t);
                        }
                    });
                });
            },
            toPx: function(t, i) {
                return i ? parseInt(t * this.factor) : t * this.factor;
            },
            toRpx: function(t, i) {
                return i ? parseInt(t / this.factor) : t / this.factor;
            },
            _mapHttpToHttps: function(t) {
                if (t.indexOf(":") < 0) return t;
                var i = t.split(":");
                return 2 === i.length && "http" === i[0] ? (i[0] = "https", i[0] + ":" + i[1]) : t;
            }
        };
        Component({
            properties: {},
            created: function() {
                var t = wx.getSystemInfoSync().screenWidth;
                this.factor = t / 750;
            },
            methods: Object.assign({
                getHeight: function(i) {
                    var e = function(t) {
                        var i = t.lineHeight || t.fontSize;
                        return "top" === t.baseLine ? i : "middle" === t.baseLine ? i / 2 : 0;
                    }, o = [];
                    (i.blocks || []).forEach(function(t) {
                        o.push(t.y + t.height);
                    }), (i.texts || []).forEach(function(i) {
                        var s = void 0;
                        "[object Array]" === Object.prototype.toString.call(i.text) ? i.text.forEach(function(n) {
                            s = e(t({}, n, {
                                baseLine: i.baseLine
                            })), o.push(i.y + s);
                        }) : (s = e(i), o.push(i.y + s));
                    }), (i.images || []).forEach(function(t) {
                        o.push(t.y + t.height);
                    }), (i.lines || []).forEach(function(t) {
                        o.push(t.startY), o.push(t.endY);
                    });
                    var s = o.sort(function(t, i) {
                        return i - t;
                    }), n = 0;
                    return s.length > 0 && (n = s[0]), i.height < n || !i.height ? n : i.height;
                },
                create: function(t) {
                    var i = this;
                    this.ctx = wx.createCanvasContext("canvasid", this);
                    var e = this.getHeight(t);
                    this.initCanvas(t.width, e, t.debug).then(function() {
                        t.backgroundColor && (i.ctx.save(), i.ctx.setFillStyle(t.backgroundColor), i.ctx.fillRect(0, 0, i.toPx(t.width), i.toPx(e)), 
                        i.ctx.restore());
                        var o = t.texts, s = void 0 === o ? [] : o, n = (t.images, t.blocks), r = void 0 === n ? [] : n, h = t.lines, a = void 0 === h ? [] : h, c = i.drawArr.concat(s.map(function(t) {
                            return t.type = "text", t.zIndex = t.zIndex || 0, t;
                        })).concat(r.map(function(t) {
                            return t.type = "block", t.zIndex = t.zIndex || 0, t;
                        })).concat(a.map(function(t) {
                            return t.type = "line", t.zIndex = t.zIndex || 0, t;
                        }));
                        c.sort(function(t, i) {
                            return t.zIndex - i.zIndex;
                        }), c.forEach(function(t) {
                            "image" === t.type ? i.drawImage(t) : "text" === t.type ? i.drawText(t) : "block" === t.type ? i.drawBlock(t) : "line" === t.type && i.drawLine(t);
                        });
                        var x = 300;
                        "android" === wx.getSystemInfoSync().platform && (x = 700), i.ctx.draw(!1, function(t) {
                            setTimeout(function() {
                                wx.canvasToTempFilePath({
                                    canvasId: "canvasid",
                                    success: function(t) {
                                        i.triggerEvent("success", t.tempFilePath);
                                    },
                                    fail: function(e) {
                                        i.triggerEvent("fail", e);
                                        var o = !1;
                                        e && e.errMsg && (o = !!e.errMsg.match(/(empty)|(canvasId)/)), o || setTimeout(function() {
                                            throw new Error("generatePosterFail001 生成海报失败 " + JSON.stringify({
                                                err: e,
                                                canvasRes: t
                                            }));
                                        });
                                    }
                                }, i);
                            }, x);
                        });
                    }).catch(function(t) {
                        wx.showToast({
                            icon: "none",
                            title: t.errMsg || "生成失败"
                        });
                    });
                }
            }, o, s, n)
        });
    }
}, [ [ 767, 0 ] ] ]));