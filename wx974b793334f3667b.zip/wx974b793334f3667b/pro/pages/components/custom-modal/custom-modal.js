var t = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
    return typeof t;
} : function(t) {
    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
};

require("./../../../../runtime"), require("./../../../../mono"), require("./../../../../common"), 
function(t, e) {
    for (var a in e) t[a] = e[a];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 92 ], {
    2: function(e, a) {
        var n;
        n = function() {
            return this;
        }();
        try {
            n = n || new Function("return this")();
        } catch (e) {
            "object" == ("undefined" == typeof window ? "undefined" : t(window)) && (n = window);
        }
        e.exports = n;
    },
    787: function(t, e, a) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        });
        var n = a(0), i = a(4), o = a(1), s = a(43), l = a(6), c = a(329), p = {
            mask: {
                type: Boolean,
                value: !0
            },
            modalBackground: {
                type: String,
                value: ""
            },
            title: String,
            type: String,
            position: {
                type: String,
                value: "middle"
            },
            customWidth: {
                type: String,
                value: ""
            },
            borderRadius: {
                type: String,
                value: ""
            },
            background: {
                type: String,
                value: ""
            },
            isIndex: {
                type: Boolean,
                value: !1
            },
            isNoPadding: {
                type: Boolean,
                value: !1
            },
            showCloseBtn: {
                type: Boolean,
                value: !0
            },
            isBlurryCloseBtn: {
                type: Boolean,
                value: !1
            },
            isAnimation: Boolean,
            isNewAnimation: {
                type: Boolean,
                value: !1
            },
            isToPositionAnimation: {
                type: Boolean,
                value: !1
            },
            startTopPosition: {
                type: String,
                value: ""
            },
            endTopPosition: {
                type: String,
                value: ""
            },
            endLeftPosition: {
                type: String,
                value: ""
            },
            animateSpeed: {
                type: Number,
                value: 100
            },
            isCatchTouchMove: {
                type: Boolean,
                value: !0
            },
            setBindTouchMove: Boolean,
            canCloseWhenMask: {
                type: Boolean,
                value: !0
            },
            containerStyle: String,
            flex: Boolean,
            customKey: String,
            curQJLModalKey: String
        };
        !function(t) {
            function e(e, a, n) {
                var i = t.call(this) || this;
                return i.messageSubService = e, i.utils = a, i.qjlModalService = n, i.properties = p, 
                i.data = {}, i.computed = {
                    animateClassName: function(t) {
                        var e = t.canIUseNewBottomAnimation, a = t.isShowModalWhenNewAnimation, n = t.position;
                        return "right" === n ? a ? "animate openSideContent" : "animate closeSideContent" : "top" === n ? a ? "animate openTopContent" : "animate closeTopContent" : e ? a ? "animate openContent" : "animate closeContent" : "no-animate";
                    }
                }, i;
            }
            n.__extends(e, t);
            var a = e.prototype;
            a.attached = function() {
                t.prototype.attached.call(this), this.data.isNewAnimation || "right" === this.data.position ? this.setData({
                    canIUseNewBottomAnimation: !0,
                    isShowModalWhenNewAnimation: !0
                }) : this.data.isAnimation && this.handleAnimate();
            }, a.handleCloseWhenClickMask = function(t) {
                this.data.canCloseWhenMask && this.handleClose(t);
            }, a.handleClose = function(t) {
                var e = this;
                this.data.isNewAnimation || "right" === this.data.position ? this.setData({
                    isShowModalWhenNewAnimation: !1
                }, function() {
                    return setTimeout(function() {
                        return e.closeModal();
                    }, 400);
                }) : this.data.isAnimation && this.animate ? this.setData({
                    canIUse: !0
                }, function() {
                    e.handleEndAnimate();
                }) : this.data.isToPositionAnimation && this.animate ? this.setData({
                    canIUse: !0
                }, function() {
                    e.setEndAnimateToPosition();
                }) : this.setData({
                    canIUse: !1
                }, function() {
                    e.closeModal();
                });
            }, a.handleAnimate = function() {
                var t = this, e = Math.ceil(this.data.animateSpeed || 100), a = Math.ceil(3.33 * e);
                this.animate ? (this.setData({
                    canIUse: !0
                }), this.animate(".popup", [ {
                    opacity: 0
                }, {
                    opacity: 1
                } ], e, function() {
                    t.animate(".popupContainer", [ {
                        opacity: 1,
                        translateY: 686,
                        ease: "ease"
                    }, {
                        opacity: 1,
                        translateY: 0,
                        ease: "ease"
                    } ], a);
                })) : this.setData({
                    canIUse: !1
                });
            }, a.handleEndAnimate = function() {
                var t = this, e = Math.ceil(3 * (this.data.animateSpeed || 100));
                this.animate(".popup", [ {
                    opacity: 1
                }, {
                    opacity: 0
                } ], e), this.animate(".popupContainer", [ {
                    opacity: 1,
                    translateY: 0,
                    ease: "ease"
                }, {
                    opacity: 1,
                    translateY: 686,
                    ease: "ease"
                } ], e, function() {
                    t.closeModal();
                });
            }, a.setEndAnimateToPosition = function() {
                var t = this, e = Math.ceil(3 * (this.data.animateSpeed || 100));
                this.animate(".popup", [ {
                    opacity: 1
                }, {
                    opacity: 0
                } ], e), this.animate(".popupContainer", [ {
                    opacity: 1,
                    scaleX: 1,
                    scaleY: 1,
                    top: this.data.startTopPosition || "15%",
                    left: 0,
                    ease: "ease"
                }, {
                    opacity: 1,
                    scaleX: 0,
                    scaleY: 0,
                    top: this.data.endTopPosition || "50%",
                    left: this.data.endLeftPosition || "55%",
                    ease: "ease"
                } ], e, function() {
                    t.closeModal();
                });
            }, a.closeModal = function() {
                this.triggerEvent("close");
                var t = this.data.customKey, e = void 0 === t ? "" : t;
                if (e) {
                    var a = this.utils.getPage().instanceId;
                    this.qjlModalService.noticeModalEvent({
                        key: e,
                        operate: "cancel",
                        pageId: a
                    });
                }
            }, e = n.__decorate([ o.wxComponent(), n.__metadata("design:paramtypes", [ s.MessageSubscribeService, l.UtilService, c.QJLModalService ]) ], e);
        }(i.SuperComponent);
    }
}, [ [ 787, 0, 2, 1 ] ] ]));