var t = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
    return typeof t;
} : function(t) {
    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
};

require("./../../../../runtime"), require("./../../../../mono"), require("./../../../../common"), 
function(t, e) {
    for (var o in e) t[o] = e[o];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 101 ], {
    2: function(e, o) {
        var n;
        n = function() {
            return this;
        }();
        try {
            n = n || new Function("return this")();
        } catch (e) {
            "object" == ("undefined" == typeof window ? "undefined" : t(window)) && (n = window);
        }
        e.exports = n;
    },
    695: function(t, e, o) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        });
        var n = o(0), r = o(4), i = o(1), a = o(80), u = {
            point: {
                type: Number,
                observer: function(t) {
                    this.setStarList(t);
                }
            },
            count: {
                type: Number,
                value: 5
            }
        };
        !function(t) {
            function e(e) {
                var o = t.call(this) || this;
                return o.evaluationService = e, o.properties = u, o.data = {}, o;
            }
            n.__extends(e, t);
            var o = e.prototype;
            o.attached = function() {
                t.prototype.attached.call(this), this.setStarList(this.data.point);
            }, o.ready = function() {
                t.prototype.ready.call(this);
            }, o.setStarList = function(t) {
                var e = this.evaluationService.getStarList(t, this.data.count);
                this.setData({
                    starList: e
                });
            }, e = n.__decorate([ i.wxComponent(), n.__metadata("design:paramtypes", [ a.EvaluationService ]) ], e);
        }(r.SuperComponent);
    }
}, [ [ 695, 0, 2, 1 ] ] ]));