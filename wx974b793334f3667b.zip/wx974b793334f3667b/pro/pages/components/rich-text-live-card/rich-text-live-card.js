var e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
};

require("./../../../../runtime"), require("./../../../../mono"), require("./../../../../common"), 
function(e, t) {
    for (var o in t) e[o] = t[o];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 138 ], {
    2: function(t, o) {
        var n;
        n = function() {
            return this;
        }();
        try {
            n = n || new Function("return this")();
        } catch (t) {
            "object" == ("undefined" == typeof window ? "undefined" : e(window)) && (n = window);
        }
        t.exports = n;
    },
    683: function(e, t, o) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var n = o(0), i = o(4), r = o(1), a = o(177), s = {
            name: String,
            roomNo: String,
            coverUrl: String,
            liveStatus: Number,
            liveCardInfo: Object,
            disableTap: Boolean
        };
        !function(e) {
            function t(t) {
                var o = e.call(this) || this;
                return o.channelsLiveService = t, o.properties = s, o.data = {
                    ChannelsLiveInfoStatus: a.ChannelsLiveInfoStatus
                }, o;
            }
            n.__extends(t, e);
            var o = t.prototype;
            o.attached = function() {
                var t = this;
                e.prototype.attached.call(this);
                var o = this.data.liveCardInfo;
                if (o) {
                    var n = o.roomNumber, i = o.roomName, r = o.liveCover;
                    this.setData({
                        roomNo: n,
                        name: i,
                        coverUrl: r
                    }), this.channelsLiveService.getChannelsLiveInfo(n || "").subscribe(function(e) {
                        t.setData({
                            liveRoomInfo: e,
                            liveStatus: e.status
                        });
                    }, function(e) {});
                } else this.setData({
                    liveStatus: a.ChannelsLiveInfoStatus.WAIT_START
                });
            }, o.ready = function() {
                e.prototype.ready.call(this);
            }, o.handleTapGoLiveRoom = function() {
                var e = this.data, t = e.liveRoomInfo, o = e.liveCardInfo;
                if (t && o && !this.data.disableTap) {
                    var n = o.roomNumber, i = void 0 === n ? "" : n, r = t.feedId, a = t.nonceId;
                    this.channelsLiveService.openChannelsLive(i, r, a).subscribe();
                }
            }, t = n.__decorate([ r.wxComponent(), n.__metadata("design:paramtypes", [ a.ChannelsLiveService ]) ], t);
        }(i.SuperComponent);
    }
}, [ [ 683, 0, 2, 1 ] ] ]));