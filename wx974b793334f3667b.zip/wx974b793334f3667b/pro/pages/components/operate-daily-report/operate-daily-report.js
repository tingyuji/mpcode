var t = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
    return typeof t;
} : function(t) {
    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
};

require("./../../../../runtime"), require("./../../../../mono"), require("./../../../../common"), 
function(t, i) {
    for (var e in i) t[e] = i[e];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 131 ], {
    2: function(i, e) {
        var a;
        a = function() {
            return this;
        }();
        try {
            a = a || new Function("return this")();
        } catch (i) {
            "object" == ("undefined" == typeof window ? "undefined" : t(window)) && (a = window);
        }
        i.exports = a;
    },
    731: function(t, i, e) {
        Object.defineProperty(i, "__esModule", {
            value: !0
        });
        var a = e(0), o = e(4), n = e(1), r = e(15), s = e(28), c = e(13), u = {
            ok: Boolean,
            isShowTips: Boolean,
            groupId: String
        };
        !function(t) {
            function i(i, e) {
                var a = t.call(this) || this;
                return a.commonService = i, a.apiService = e, a.properties = u, a.data = {}, a;
            }
            a.__extends(i, t);
            var e = i.prototype;
            e.ready = function() {
                t.prototype.ready.call(this), this.getContent(), this.initConfig();
            }, e.handleToggleSubscribe = function() {
                var t = this;
                this.apiService.setDailyPushConfigUsingPOST({
                    groupId: this.data.groupId,
                    hourOrderPush: this.switchConfig.hourOrderPush,
                    opDataPush: this.data.isUnsubscribed ? 20 : 10
                }, c.skipErrorOptions).subscribe(function() {
                    t.setData({
                        isUnsubscribed: !t.data.isUnsubscribed
                    });
                });
            }, e.handleTapActivityDetail = function() {
                this.commonService.goToDetail({
                    actId: String(this.data.activityInfo.actId),
                    seqType: this.data.activityInfo.actType
                });
            }, e.handleCloseReportDataModal = function() {
                this.setData({
                    isShowDataReport: !1
                });
            }, e.getContent = function() {
                var t = this;
                this.apiService.queryRecommendDailyActUsingPOST({
                    ghCode: this.data.groupId,
                    thirtyDaysGmv: !!this.data.isShowTips
                }).subscribe(function(i) {
                    if (i.data) {
                        var e = 20 === i.data.reportType;
                        e || t.getParticipantList(i.data.queryRecommendActRsp);
                        var a = new Date(i.data.titleTime);
                        t.setData({
                            isDailyReport: e,
                            activityInfo: i.data.queryRecommendActRsp,
                            reportDay: a.getDate(),
                            reportMonth: a.getMonth() + 1,
                            isShowDataReport: !0
                        });
                    }
                });
            }, e.getParticipantList = function(t) {
                var i = this, e = t.actId, a = t.owId, o = String(a);
                this.apiService.queryActParticipantListUsingGET(e, o).subscribe(function(t) {
                    var e = t.data && t.data.list ? t.data.list : [];
                    i.setData({
                        participantList: e
                    });
                });
            }, e.initConfig = function() {
                var t = this;
                this.apiService.queryDailyPushConfigUsingGET(this.data.groupId, c.skipErrorOptions).subscribe(function(i) {
                    i.data && (t.switchConfig = i.data, t.setData({
                        isUnsubscribed: 10 === i.data.opDataPush
                    }));
                });
            }, i = a.__decorate([ n.wxComponent(), a.__metadata("design:paramtypes", [ r.CommonService, s.DefaultService ]) ], i);
        }(o.SuperComponent);
    }
}, [ [ 731, 0, 2, 1 ] ] ]));