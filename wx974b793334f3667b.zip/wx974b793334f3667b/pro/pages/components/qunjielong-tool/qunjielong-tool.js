var e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
};

require("./../../../../runtime"), require("./../../../../mono"), require("./../../../../common"), 
function(e, t) {
    for (var o in t) e[o] = t[o];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 136 ], {
    2: function(t, o) {
        var n;
        n = function() {
            return this;
        }();
        try {
            n = n || new Function("return this")();
        } catch (t) {
            "object" == ("undefined" == typeof window ? "undefined" : e(window)) && (n = window);
        }
        t.exports = n;
    },
    732: function(e, t, o) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var n = o(0), r = o(4), i = o(1), u = {
            ok: Boolean,
            test: {
                type: Number
            },
            isHideText: {
                type: Boolean,
                value: !1
            }
        };
        !function(e) {
            function t() {
                var t = e.call(this) || this;
                return t.properties = u, t.data = {}, t;
            }
            n.__extends(t, e), t.prototype.ready = function() {
                e.prototype.ready.call(this);
            }, t = n.__decorate([ i.wxComponent(), n.__metadata("design:paramtypes", []) ], t);
        }(r.SuperComponent);
    }
}, [ [ 732, 0, 2, 1 ] ] ]));