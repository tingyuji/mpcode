var t = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
    return typeof t;
} : function(t) {
    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
};

require("./../../../../runtime"), require("./../../../../mono"), require("./../../../../common"), 
function(t, o) {
    for (var e in o) t[e] = o[e];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 93 ], {
    2: function(o, e) {
        var n;
        n = function() {
            return this;
        }();
        try {
            n = n || new Function("return this")();
        } catch (o) {
            "object" == ("undefined" == typeof window ? "undefined" : t(window)) && (n = window);
        }
        o.exports = n;
    },
    782: function(t, o, e) {
        Object.defineProperty(o, "__esModule", {
            value: !0
        }), o.CustomToast = void 0;
        var n = e(0), r = e(4), i = e(1), a = e(3), u = e(6), c = {}, s = function(t) {
            function o(o) {
                var e = t.call(this) || this;
                return e.utilService = o, e.properties = c, e.data = {}, e;
            }
            n.__extends(o, t);
            var e = o.prototype;
            return e.attached = function() {
                t.prototype.attached.call(this);
            }, e.ready = function() {
                t.prototype.ready.call(this);
            }, e.showToast = function(t) {
                var o, e = this;
                try {
                    wx.hideToast({});
                    var n = t.content, r = void 0 === n ? "" : n, i = t.autoCalDuration, u = t.duration, c = void 0 === u ? 2e3 : u, s = i ? Math.max(Math.ceil(r.length / 15 * 1e3), 2e3) : c;
                    this.data.isShow && (null === (o = this.toastSubscription) || void 0 === o || o.unsubscribe()), 
                    this.toastSubscription = this.rxSetData({
                        isShow: !0,
                        content: r
                    }).pipe(a.delay(s), a.switchMap(function() {
                        return e.rxSetData({
                            isShow: !1,
                            content: ""
                        });
                    })).subscribe({
                        next: function() {
                            return e.utilService.customReport({
                                functionName: "customShowToastSuccess",
                                methodParams: t
                            });
                        },
                        error: function(t) {
                            return e.utilService.customReport({
                                functionName: "customShowToastFail",
                                methodParams: {
                                    err: t
                                }
                            });
                        }
                    });
                } catch (t) {
                    this.utilService.customReport({
                        functionName: "customShowToastFail",
                        methodParams: {
                            err: t
                        }
                    });
                }
            }, o = n.__decorate([ i.wxComponent(), n.__metadata("design:paramtypes", [ u.UtilService ]) ], o);
        }(r.SuperComponent);
        o.CustomToast = s;
    }
}, [ [ 782, 0, 2, 1 ] ] ]));