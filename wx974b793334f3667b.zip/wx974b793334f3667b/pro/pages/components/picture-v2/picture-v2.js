var e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
};

require("./../../../../runtime"), require("./../../../../mono"), require("./../../../../common"), 
function(e, t) {
    for (var i in t) e[i] = t[i];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 133 ], {
    2: function(t, i) {
        var n;
        n = function() {
            return this;
        }();
        try {
            n = n || new Function("return this")();
        } catch (t) {
            "object" == ("undefined" == typeof window ? "undefined" : e(window)) && (n = window);
        }
        t.exports = n;
    },
    688: function(e, t, i) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var n = i(0), o = i(4), r = i(1), a = i(6), s = i(22), u = i(13), c = i(17), h = i(3), f = i(20), l = i(29), m = {
            mode: {
                type: String,
                value: "widthFix"
            },
            isUseInfoFromOutSide: Boolean,
            info: {
                type: Object,
                observer: function(e) {
                    e && this.setImageInfo(e);
                }
            },
            src: {
                type: String,
                observer: function(e) {
                    this.getImageInfo(e), this.setPictureUrl(e), this.setIsDynamicPictures(e);
                }
            }
        };
        !function(e) {
            function t(t, i, n, o) {
                var r = e.call(this) || this;
                return r.utilService = t, r.httpClient = i, r.grayFeatureService = n, r.monoCommonService = o, 
                r.properties = m, r.data = {}, r;
            }
            n.__extends(t, e);
            var i = t.prototype;
            i.attached = function() {
                e.prototype.attached.call(this);
            }, i.ready = function() {
                e.prototype.ready.call(this);
            }, i.setIsDynamicPictures = function(e) {
                var t = !!e.match(/.gif$/);
                this.setData({
                    isDynamicPictures: t
                });
            }, i.setImageInfo = function(e) {
                var t, i, n = Number((null === (t = e.ImageWidth) || void 0 === t ? void 0 : t.value) || e.width || 320), o = Number((null === (i = e.ImageHeight) || void 0 === i ? void 0 : i.value) || e.height || 240);
                this.setData({
                    imageInfo: {
                        width: n,
                        height: o
                    }
                });
            }, i.getImageInfo = function(e) {
                var t = this;
                if (!this.data.isUseInfoFromOutSide) {
                    var i = this.getConnector(e);
                    if (this.monoCommonService.checkMediaType(e, "svg") || !e || "null" === e) return this.setDefaultImageInfo();
                    var n = s.config.resHost + "/" + e + i + "x-oss-process=image/info";
                    this.httpClient.get(n, {}, u.skipErrorOptions).subscribe(function(e) {
                        var i, n, o = Number((null === (i = null == e ? void 0 : e.ImageWidth) || void 0 === i ? void 0 : i.value) || 320), r = Number((null === (n = null == e ? void 0 : e.ImageHeight) || void 0 === n ? void 0 : n.value) || 240);
                        t.setData({
                            imageInfo: {
                                width: o,
                                height: r
                            }
                        });
                    }, function() {
                        t.setData({
                            src: "ss/app/image/plus/check-fail.jpg",
                            imageInfo: {
                                width: 320,
                                height: 240
                            }
                        });
                    });
                }
            }, i.handleWxRealSize = function(e) {
                var t = this, i = e.detail, n = this.data.imageInfo, o = n.width / n.height, r = i.width / i.height;
                if (!this.data.isDynamicPictures) {
                    var a = r / o, s = Math.abs(Math.round(100 * a) - 100) >= 5;
                    s && this.grayFeatureService.canIUseFeature("2366").subscribe(function(e) {
                        e || s && t.setData({
                            imageInfo: {
                                width: i.width,
                                height: i.height
                            }
                        });
                    });
                }
            }, i.setPictureUrl = function(e) {
                var t = this;
                this.getOriginalPicture(e).subscribe(function(i) {
                    t.setData({
                        thumbnailUrl: t.getThumbnailUrl(e),
                        originalUrl: i
                    });
                });
            }, i.handleOriginLoad = function() {
                this.setData({
                    hasOriginLoaded: !0
                });
            }, i.getOriginalPicture = function(e) {
                var t = this;
                return this.grayFeatureService.canIUseFeature("2211").pipe(h.map(function(i) {
                    var n = s.config.resHost, o = t.utilService.getScreenInfo(), r = t.getConnector(e), a = i ? 600 : o.width;
                    return e && "null" !== e ? n + "/" + e + r + "x-oss-process=image/resize,m_lfit,w_" + a : "";
                }));
            }, i.getThumbnailUrl = function(e) {
                return s.config.resHost + "/" + e + this.getConnector(e) + "x-oss-process=image/resize,m_lfit,w_36";
            }, i.getConnector = function(e) {
                return void 0 === e && (e = ""), e.includes("?") ? "&" : "?";
            }, i.setDefaultImageInfo = function() {
                this.setData({
                    src: "ss/app/image/plus/check-fail.jpg",
                    imageInfo: l.DEFAULT_IMAGE_INFO
                });
            }, t = n.__decorate([ r.wxComponent(), n.__metadata("design:paramtypes", [ a.UtilService, u.HttpClient, c.GrayFeatureService, f.MonoCommonService ]) ], t);
        }(o.SuperComponent);
    }
}, [ [ 688, 0, 2, 1 ] ] ]));