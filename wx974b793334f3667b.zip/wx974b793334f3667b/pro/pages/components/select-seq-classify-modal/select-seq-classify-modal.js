var e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
};

require("./../../../../runtime"), require("./../../../../mono"), require("./../../../../common"), 
function(e, t) {
    for (var a in t) e[a] = t[a];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 146 ], {
    2: function(t, a) {
        var i;
        i = function() {
            return this;
        }();
        try {
            i = i || new Function("return this")();
        } catch (t) {
            "object" == ("undefined" == typeof window ? "undefined" : e(window)) && (i = window);
        }
        t.exports = i;
    },
    694: function(e, t, a) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var i = a(0), s = a(4), n = a(1), o = a(5), l = a(14), r = a(10), c = a(12), d = a(229), u = a(16), f = a(20), y = a(199), p = a(3), h = {
            groupId: String,
            groupType: Number,
            showCurrentLeaderView: Boolean,
            classifyLabelList: Array
        };
        !function(e) {
            function t(t, a, s, n) {
                var o = e.call(this) || this;
                return o.apiService = t, o.routeService = a, o.classifyManageService = s, o.monoCommonService = n, 
                o.properties = h, o.data = i.__assign({}, y.SelectSeqClassifyEventNameMap), o;
            }
            i.__extends(t, e);
            var a = t.prototype;
            a.attached = function() {
                e.prototype.attached.call(this);
            }, a.ready = function() {
                e.prototype.ready.call(this), this.initClassify(), this.listenClassifyManageChange();
            }, a.getClassifyList = function() {
                var e = this, t = this.data, a = t.groupId, i = t.groupType, s = t.selectSeqClassifyIds, n = {
                    ghId: a,
                    ghType: i,
                    queryCount: !1
                };
                this.apiService.queryListByGhIdUsingPOST(n, l.skipMarkOption).subscribe(function(t) {
                    var a = t.data;
                    if (a) {
                        var i = a.filter(function(e) {
                            return -1 !== e.labelId;
                        }), n = i.filter(function(e) {
                            return s.includes(e.labelId);
                        });
                        e.setData({
                            classifyManagementList: i,
                            selectSeqClassifyList: n
                        });
                    }
                });
            }, a.handleTapSeqClassify = function(e) {
                var t = e.currentTarget.dataset.item, a = !1, i = this.data.selectSeqClassifyList.filter(function(e) {
                    return e.labelId !== t.labelId || (a = !0, !1);
                });
                a || i.push(t);
                var s = i.map(function(e) {
                    return e.labelId;
                });
                this.setData({
                    selectSeqClassifyList: i,
                    selectSeqClassifyIds: s
                });
            }, a.handleBindLabelName = function(e) {
                var t = e.detail.value;
                this.setData({
                    activeLabelName: t
                });
            }, a.handleToggleAddClassify = function() {
                this.setData({
                    isShowAddClassifyModal: !this.data.isShowAddClassifyModal,
                    activeLabelName: ""
                });
            }, a.handleAddClassify = function() {
                var e = this, t = this.data, a = t.groupId, i = t.groupType, s = t.classifyManagementList;
                if (this.monoCommonService.emojiStringLength(this.data.activeLabelName) > 6) c.rxwx.showToast({
                    title: "分类名称不能超过6个字",
                    icon: "none"
                }).subscribe(); else if (s.length >= 100) c.rxwx.showToast({
                    title: "最多支持100个分类",
                    icon: "none"
                }).subscribe(); else {
                    var n = {
                        ghId: a,
                        ghType: i,
                        showStatus: 10,
                        labelName: this.data.activeLabelName
                    };
                    this.apiService.addClassifyLabelUsingPOST(n).subscribe(function(t) {
                        t.data ? (e.setData({
                            isShowAddClassifyModal: !1,
                            activeLabelName: ""
                        }), c.rxwx.showToast({
                            title: "添加成功"
                        }).subscribe(), e.getClassifyList()) : c.rxwx.showToast({
                            title: "添加失败,请稍后重试",
                            icon: "none"
                        }).subscribe();
                    });
                }
            }, a.handleGoToClassifyManagement = function(e) {
                var t = this.data, a = t.groupId, i = {
                    groupType: t.groupType,
                    groupId: a
                };
                this.routeService.goSeqManageOptionsClassifyManage({
                    data: i
                });
            }, a.handleTapClassifyGuide = function(e) {}, a.handleCloseClassifyGuide = function(e) {}, 
            a.handleConfirmClassifySelect = function(e) {
                var t = this.data.selectSeqClassifyList;
                this.triggerEvent("confirmSelectClassify", t), this.myTriggerEvent(y.SelectSeqClassifyEventNameMap.CONFIRM_SELECT_CLASSIFY, t);
            }, a.handleTapCloseModal = function(e) {
                this.triggerEvent("closeSelectClassifyModal");
            }, a.listenClassifyManageChange = function() {
                var e = this;
                this.classifyManageService.classifyManageChangeObs.pipe(p.takeUntil(this.unloadObservable)).subscribe(function() {
                    e.getClassifyList();
                });
            }, a.initClassify = function() {
                this.setSelectSeqClassifyIds(), this.getClassifyList();
            }, a.setSelectSeqClassifyIds = function() {
                var e = (this.data.classifyLabelList || []).map(function(e) {
                    return e.labelId;
                });
                this.setData({
                    selectSeqClassifyIds: e
                });
            }, i.__decorate([ u.Toggle("isShowClassifyGuide", !0), i.__metadata("design:type", Function), i.__metadata("design:paramtypes", [ Object ]), i.__metadata("design:returntype", void 0) ], t.prototype, "handleTapClassifyGuide", null), 
            i.__decorate([ u.Toggle("isShowClassifyGuide", !1), i.__metadata("design:type", Function), i.__metadata("design:paramtypes", [ Object ]), i.__metadata("design:returntype", void 0) ], t.prototype, "handleCloseClassifyGuide", null), 
            t = i.__decorate([ n.wxComponent(), i.__metadata("design:paramtypes", [ o.DefaultService, r.RouteService, d.ClassifyManageService, f.MonoCommonService ]) ], t);
        }(s.SuperComponent);
    }
}, [ [ 694, 0, 2, 1 ] ] ]));