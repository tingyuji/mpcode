var e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
};

require("./../../../../runtime"), require("./../../../../mono"), require("./../../../../common"), 
function(e, t) {
    for (var o in t) e[o] = t[o];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 156 ], {
    2: function(t, o) {
        var i;
        i = function() {
            return this;
        }();
        try {
            i = i || new Function("return this")();
        } catch (t) {
            "object" == ("undefined" == typeof window ? "undefined" : e(window)) && (i = window);
        }
        t.exports = i;
    },
    686: function(e, t, o) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var i = o(0), n = o(4), a = o(1), r = o(6), s = o(12), d = o(36), c = o(7), u = o(3), h = o(24), l = o(418), p = o(687), f = {
            videoUrl: String,
            videoHeight: String,
            autoplay: Boolean,
            autoFullscreen: Boolean,
            showFullscreenBtn: {
                type: Boolean,
                value: !0
            },
            showMuteBtn: {
                type: Boolean,
                value: !0
            },
            disSave: Boolean
        };
        !function(e) {
            function t(t, o, i) {
                var n = e.call(this) || this;
                return n.utils = t, n.errorService = o, n.videoWrapperService = i, n.properties = f, 
                n.data = {
                    currentVideoIndex: -1,
                    componentState: 0,
                    authMode: d.getAuthConfiguration(10)
                }, n.wrapperRatio = 660 / 446, n.isFullScreen = !1, n.loadedMetadataComparable = !1, 
                n;
            }
            i.__extends(t, e);
            var o = t.prototype;
            o.attached = function() {
                e.prototype.attached.call(this), this.videoId = this.videoWrapperService.generateUniqueId(), 
                this.loadedMetadataComparable = this.utils.compareVersion("2.7.0");
            }, o.ready = function() {
                e.prototype.ready.call(this), this.videoContext = wx.createVideoContext("videoCtx"), 
                this.listenVideoPlayChange(), this.data.autoFullscreen ? this.fullScreenVideo() : this.data.autoplay && this.playVideo();
            }, o.handleVideoEnded = function() {
                this.isFullScreen ? this.setData({
                    componentState: 3
                }) : this.videoWrapperService.notifyPlayIdChange(-1);
            }, o.handleDataLoaded = function() {
                this.setData({
                    componentState: 2
                });
            }, o.handlePlayVideo = function(e) {
                this.playVideo();
            }, o.handleFullScreenChange = function(e) {
                this.isFullScreen = e.detail.fullScreen, this.isFullScreen || 3 !== this.data.componentState || this.videoWrapperService.notifyPlayIdChange(-1), 
                this.triggerEvent("fullscreen", e.detail);
            }, o.handleSnapshotLoad = function(e) {
                if (!this.isSnapshotRatioInit()) {
                    var t = e.detail, o = t.width, i = t.height;
                    this.snapshotRatio = o / i, this.checkBackgroundMode();
                }
            }, o.handleLongTapVideo = function(e) {
                var t = this;
                this.data.disSave || s.rxwx.showActionSheet({
                    itemList: [ "保存视频" ]
                }).subscribe(function(e) {
                    0 === e.tapIndex && t.selectComponent("#authFallBack").openSetting();
                });
            }, o.handleTapSaveVideo = function(e) {
                this.data.videoUrl && this.saveVideo();
            }, o.processAuthInfo = function() {
                var e = this;
                s.rxwx.getSetting({}).subscribe(function(t) {
                    var o;
                    if (void 0 !== t.authSetting["scope." + e.data.authMode.scope]) {
                        var i = t.authSetting["scope." + e.data.authMode.scope];
                        e.setData(((o = {})["authMode.isAuthorize"] = i, o)), i && e.data.videoUrl && e.saveVideo();
                    }
                });
            }, o.fullScreenVideo = function() {
                var e = this;
                this.playVideo(function() {
                    var t, o;
                    null === (o = (t = e.videoContext).requestFullScreen) || void 0 === o || o.call(t, {});
                });
            }, o.playVideo = function(e) {
                this.videoWrapperService.notifyPlayIdChange(this.videoId), this.setData({
                    componentState: this.loadedMetadataComparable ? 1 : 2
                }, function() {
                    null == e || e();
                });
            }, o.checkBackgroundMode = function() {
                this.setData({
                    isHideBlackBackground: this.snapshotRatio < this.wrapperRatio,
                    isHideBlurBackground: this.snapshotRatio >= this.wrapperRatio
                });
            }, o.isSnapshotRatioInit = function() {
                return "number" == typeof this.snapshotRatio;
            }, o.saveVideo = function() {
                this.downLoadVideo(this.data.videoUrl).pipe(u.switchMap(function(e) {
                    return wx.hideLoading({}), s.rxwx.saveVideoToPhotosAlbum({
                        filePath: e.tempFilePath
                    });
                })).subscribe(function(e) {
                    return wx.showToast({
                        title: "保存成功"
                    });
                });
            }, o.downLoadVideo = function(e) {
                var t = this;
                e || this.errorService.throwCommonError({
                    frontErrorCode: 1014
                }), wx.showLoading({
                    title: "视频下载中"
                });
                var o = this.utils.videoPlayUrl(e, !1);
                return s.rxwx.downloadFile({
                    url: o
                }).pipe(u.catchError(function(e) {
                    var i = t.errorService.createCommonError({
                        frontErrorCode: 1013,
                        error: e,
                        extraInfo: {
                            url: o,
                            errTip: JSON.stringify(e)
                        }
                    });
                    return wx.hideLoading(), wx.showToast({
                        title: l.FrontEndErrorMsgMap[1013],
                        icon: "none"
                    }), c.throwError(i);
                }));
            }, o.listenVideoPlayChange = function() {
                var e = this;
                this.videoWrapperService.listenPlayIdChange().pipe(u.takeUntil(this.unloadObservable)).subscribe(function(t) {
                    t !== e.videoId && 0 !== e.data.componentState && e.setData({
                        componentState: 0
                    });
                });
            }, t = i.__decorate([ a.wxComponent(), i.__metadata("design:paramtypes", [ r.UtilService, h.ErrorService, p.VideoWrapperService ]) ], t);
        }(n.SuperComponent);
    },
    687: function(e, t, o) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.VideoWrapperService = void 0;
        var i = o(0), n = o(1), a = o(7), r = function() {
            function e() {}
            var t = e.prototype;
            return t.notifyPlayIdChange = function(e) {
                this.playIdChangeSubject = this.playIdChangeSubject || new a.Subject(), this.playIdChangeSubject.next(e);
            }, t.listenPlayIdChange = function() {
                return this.playIdChangeSubject = this.playIdChangeSubject || new a.Subject(), this.playIdChangeSubject.asObservable();
            }, t.generateUniqueId = function() {
                return "number" != typeof this.nextId && (this.nextId = Math.floor(1e3 * Math.random())), 
                this.nextId++;
            }, e = i.__decorate([ n.Injectable(), i.__metadata("design:paramtypes", []) ], e);
        }();
        t.VideoWrapperService = r;
    }
}, [ [ 686, 0, 2, 1 ] ] ]));