var t = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
    return typeof t;
} : function(t) {
    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
};

require("./../../../../runtime"), require("./../../../../mono"), require("./../../../../common"), 
function(t, e) {
    for (var n in e) t[n] = e[n];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 126 ], {
    2: function(e, n) {
        var o;
        o = function() {
            return this;
        }();
        try {
            o = o || new Function("return this")();
        } catch (e) {
            "object" == ("undefined" == typeof window ? "undefined" : t(window)) && (o = window);
        }
        e.exports = o;
    },
    790: function(t, e, n) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        }), e.Navbar = e.NAVBAR_TYPE = void 0;
        var o, a = n(0), i = n(1), r = n(4), s = n(6), l = n(15), c = n(79);
        !function(t) {
            t[t.INDEX = 0] = "INDEX", t[t.NORMAL = 1] = "NORMAL", t[t.TRANSPARENT = 2] = "TRANSPARENT", 
            t[t.TRANSPARENT_PLACEHOLDER = 3] = "TRANSPARENT_PLACEHOLDER", t[t.SHOW_LOGO = 4] = "SHOW_LOGO";
        }(o = e.NAVBAR_TYPE || (e.NAVBAR_TYPE = {}));
        var u = function(t) {
            function e(e, n) {
                var a = t.call(this) || this;
                return a.commonService = e, a.utils = n, a.properties = {
                    title: {
                        type: String,
                        value: "",
                        observer: function(t) {
                            t || this.setData({
                                title: this.getDefaultPageTitle()
                            });
                        }
                    },
                    mode: {
                        type: Number,
                        value: o.NORMAL
                    },
                    css: {
                        type: String,
                        value: ""
                    },
                    whiteIcon: {
                        type: String,
                        value: ""
                    },
                    noPlaceholder: {
                        type: String,
                        value: ""
                    },
                    isShowBackIcon: {
                        type: Boolean,
                        value: !0
                    },
                    isCustomBackBtn: {
                        type: Boolean,
                        value: !1
                    },
                    isShowSlot: {
                        type: Boolean,
                        value: !1
                    },
                    clouded: {
                        type: String,
                        value: ""
                    },
                    tabs: Array,
                    tabActiveType: Number,
                    backHomeType: {
                        type: String,
                        value: "navigateTo"
                    },
                    iconTips: String,
                    showIconTips: Boolean,
                    bubbleTips: String
                }, a;
            }
            a.__extends(e, t);
            var n = e.prototype;
            return n.attached = function() {
                t.prototype.attached.call(this);
                var e = this.utils.getApp(), n = this.data.title;
                try {
                    n = n || this.getDefaultPageTitle();
                } catch (t) {
                    c.wxlog.error("nav-error => ", JSON.stringify(t));
                }
                this.setData({
                    backIcon: getCurrentPages().length <= 1 ? "home" : "back",
                    backIconClass: getCurrentPages().length <= 1 ? "backHome" : "",
                    navH: e.globalData.navHeight,
                    title: n,
                    showBubbleTips: !0
                });
            }, n.navBack = function() {
                wx.navigateBack({
                    delta: 1
                });
            }, n.navHome = function() {
                this.commonService.backHome(this.data.backHomeType), this.triggerEvent("navHome");
            }, n.handleTapCustomBack = function() {
                this.triggerEvent("customBack");
            }, n.handleTapNavTab = function(t) {
                var e = t.currentTarget.dataset.type;
                this.data.tabActiveType !== e && this.triggerEvent("tapNavTab", e);
            }, n.handleTapHideIconTips = function(t) {
                this.triggerEvent("hideIconTips");
            }, n.getDefaultPageTitle = function() {
                var t, e = (null === (t = this.utils.getPage()) || void 0 === t ? void 0 : t.route) || "", n = __wxConfig && __wxConfig.page && __wxConfig.page[e + ".html"] && __wxConfig.page[e + ".html"].window && __wxConfig.page[e + ".html"].window.navigationBarTitleText, o = __wxConfig && __wxConfig.pages && __wxConfig.pages[e + ".html"] && __wxConfig.pages[e + ".html"].window && __wxConfig.pages[e + ".html"].window.navigationBarTitleText;
                return n || o;
            }, n.handleCloseBubble = function(t) {
                this.handleClose(t);
            }, n.handleClose = function(t) {
                this.setData({
                    showBubbleTips: !1
                }), this.triggerEvent("close");
            }, e = a.__decorate([ i.wxComponent(), a.__metadata("design:paramtypes", [ l.CommonService, s.UtilService ]) ], e);
        }(r.SuperComponent);
        e.Navbar = u;
    }
}, [ [ 790, 0, 2, 1 ] ] ]));