var e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
};

require("./../../../../runtime"), require("./../../../../mono"), require("./../../../../common"), 
function(e, t) {
    for (var a in t) e[a] = t[a];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 127 ], {
    2: function(t, a) {
        var i;
        i = function() {
            return this;
        }();
        try {
            i = i || new Function("return this")();
        } catch (t) {
            "object" == ("undefined" == typeof window ? "undefined" : e(window)) && (i = window);
        }
        t.exports = i;
    },
    720: function(e, t, a) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var i = a(0), n = a(4), r = a(1), o = a(158), s = a(29), c = a(7), u = a(16), h = a(6), v = {
            nickname: {
                type: String,
                observer: function(e) {
                    e && e !== this.data.userNickname && this.setData({
                        userNickname: e
                    });
                }
            },
            avatar: {
                type: String,
                observer: function(e) {
                    e && e !== this.data.userAvatar && this.setData({
                        userAvatar: e
                    });
                }
            }
        };
        !function(e) {
            function t(t, a, i) {
                var n = e.call(this) || this;
                return n.loginService = t, n.fileService = a, n.utilService = i, n.properties = v, 
                n.data = {
                    userNickname: "",
                    userAvatar: ""
                }, n;
            }
            i.__extends(t, e);
            var a = t.prototype;
            a.attached = function() {
                e.prototype.attached.call(this), this.avatarSubject = new c.Subject();
                var t = this.utilService.getApp(), a = t.getStorage("person_nick_name");
                this.setData({
                    userNickname: a || this.loginService.genRandomNickname(),
                    userAvatar: a ? t.getStorage("person_head_image") : this.loginService.genRandomAvatar()
                });
            }, a.getUserNicknameAndAvatar = function() {
                var e = this.data;
                return {
                    userNickname: e.userNickname,
                    userAvatar: e.userAvatar
                };
            }, a.handleTapAvatar = function(e) {
                var t = this;
                c.timer(300).subscribe(function() {
                    t.setData({
                        isShowAvatarTips: !0
                    }), c.race(c.timer(2700), t.avatarSubject.asObservable()).subscribe(function() {
                        t.setData({
                            isShowAvatarTips: !1
                        });
                    });
                });
            }, a.handleChooseAvatar = function(e) {
                var t = this, a = e.detail.avatarUrl;
                this.fileService.upload(a).subscribe(function(e) {
                    var a = e.path;
                    t.closeAvatarTips(), t.setData({
                        userAvatar: a
                    });
                });
            }, a.handleTapNicknameIcon = function() {
                this.closeAvatarTips();
            }, a.handleCloseAvatarTips = function() {
                this.closeAvatarTips();
            }, a.handleNicknameChange = function(e) {
                var t = e.detail.value || "";
                this.setData({
                    userNickname: t.trim(),
                    nicknameHeight: t ? 0 : 80
                });
            }, a.handleNicknameBlur = function(e) {
                var t = e.detail.value || "";
                this.setData({
                    userNickname: t.trim(),
                    keyboardHeight: 0,
                    nicknameHeight: 0
                }), this.triggerEvent("changeKeyboardHeight", {
                    height: 0
                });
            }, a.handleNicknameKeyboard = function(e) {
                this.closeAvatarTips();
                var t = e.detail.height;
                t !== this.data.keyboardHeight && (this.setData({
                    keyboardHeight: t,
                    nicknameHeight: 80
                }), this.triggerEvent("changeKeyboardHeight", {
                    height: t
                }));
            }, a.closeAvatarTips = function() {
                this.avatarSubject.next();
            }, i.__decorate([ u.Toggle("isNicknameFocus", !0), i.__metadata("design:type", Function), i.__metadata("design:paramtypes", []), i.__metadata("design:returntype", void 0) ], t.prototype, "handleTapNicknameIcon", null), 
            t = i.__decorate([ r.wxComponent(), i.__metadata("design:paramtypes", [ o.LoginService, s.FileService, h.UtilService ]) ], t);
        }(n.SuperComponent);
    }
}, [ [ 720, 0, 2, 1 ] ] ]));