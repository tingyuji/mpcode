var o = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(o) {
    return typeof o;
} : function(o) {
    return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
};

require("./../../../../runtime"), require("./../../../../mono"), require("./../../../../common"), 
function(o, t) {
    for (var e in t) o[e] = t[e];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 161 ], {
    2: function(t, e) {
        var n;
        n = function() {
            return this;
        }();
        try {
            n = n || new Function("return this")();
        } catch (t) {
            "object" == ("undefined" == typeof window ? "undefined" : o(window)) && (n = window);
        }
        t.exports = n;
    },
    733: function(o, t, e) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var n = e(0), i = e(1), r = e(4), u = e(79), c = e(19), a = e(36);
        !function(o) {
            function t() {
                var t = null !== o && o.apply(this, arguments) || this;
                return t.properties = {
                    mode: {
                        type: Object,
                        value: {
                            method: "chooseLocation",
                            scope: "userLocation",
                            hint: "地理位置",
                            options: {},
                            isAuthorize: !0
                        }
                    },
                    isShowButton: {
                        type: Boolean,
                        value: !0
                    },
                    isNoZIndex: {
                        type: Boolean,
                        value: !1
                    }
                }, t;
            }
            n.__extends(t, o);
            var e = t.prototype;
            e.openSetting = function() {
                var o = this;
                u.wxlog.info("1. auth-fallback组件 点击授权"), a.getAuthSettingInfo().subscribe(function(t) {
                    if (!1 === t.authSetting["scope." + o.data.mode.scope]) return u.wxlog.info("2. 拒绝授权"), 
                    void o.failCallback();
                    u.wxlog.info("3. 调用授权方法 getAuthorizeGroup"), o.getAuthorizeGroup();
                });
            }, e.failCallback = function() {
                var o = this;
                u.wxlog.info("1. 授权失败，显示modal"), wx.showModal({
                    title: "授权失败",
                    content: "由于没有授权" + this.data.mode.hint + "，该操作失败；若需要授权，请点击确认前往",
                    success: function(t) {
                        t.confirm && wx.openSetting({
                            success: function(t) {
                                t.authSetting["scope." + o.data.mode.scope] && o.getAuthorizeGroup();
                            }
                        });
                    }
                });
            }, e.getAuthorizeGroup = function() {
                var o = this;
                u.wxlog.info("1. 获取配置参数，调用wx的接口");
                var t = this.data.mode.method, e = this.data.mode.options;
                return this.wxAuthorizeGroup(t, e).then(function(t) {
                    u.wxlog.info("3. 调用接口成功，触发成功事件"), o.triggerEvent("onAuthSuccess", t);
                }).catch(function(t) {
                    u.wxlog.info("4. 调用接口失败，触发验证事件"), o.triggerEvent("getAuthInfo");
                });
            }, e.wxAuthorizeGroup = function(o, t) {
                return void 0 === t && (t = {}), u.wxlog.info("2. 调用wx接口"), new Promise(function(e, n) {
                    wx[o](Object.assign({
                        success: function(o) {
                            u.wxlog.info("2-1. 调用wx接口成功"), e(o);
                        },
                        fail: function(o) {
                            u.wxlog.info("2-2. 调用wx接口失败"), n(o);
                        }
                    }, t));
                });
            }, n.__decorate([ c.Lock(1500), n.__metadata("design:type", Function), n.__metadata("design:paramtypes", []), n.__metadata("design:returntype", void 0) ], t.prototype, "openSetting", null), 
            t = n.__decorate([ i.wxComponent() ], t);
        }(r.SuperComponent);
    }
}, [ [ 733, 0, 2, 1 ] ] ]));