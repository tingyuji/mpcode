var t = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
    return typeof t;
} : function(t) {
    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
};

require("./../../../../runtime"), require("./../../../../mono"), require("./../../../../common"), 
function(t, e) {
    for (var o in e) t[o] = e[o];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 88 ], {
    2: function(e, o) {
        var n;
        n = function() {
            return this;
        }();
        try {
            n = n || new Function("return this")();
        } catch (e) {
            "object" == ("undefined" == typeof window ? "undefined" : t(window)) && (n = window);
        }
        e.exports = n;
    },
    717: function(t, e, o) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        });
        var n = o(0), r = o(4), i = o(1), u = o(12), a = {
            text: String,
            hideCopyText: Boolean
        };
        !function(t) {
            function e() {
                var e = t.call(this) || this;
                return e.properties = a, e.data = {}, e;
            }
            n.__extends(e, t), e.prototype.handleCopyValue = function(t) {
                var e = this.data.text;
                e && u.rxwx.setClipboardData({
                    data: e
                }).subscribe(function() {
                    wx.showToast({
                        title: "复制成功",
                        icon: "success"
                    });
                });
            }, e = n.__decorate([ i.wxComponent(), n.__metadata("design:paramtypes", []) ], e);
        }(r.SuperComponent);
    }
}, [ [ 717, 0, 2, 1 ] ] ]));