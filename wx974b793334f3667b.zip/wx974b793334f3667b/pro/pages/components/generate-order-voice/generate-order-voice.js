var e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
};

require("./../../../../runtime"), require("./../../../../mono"), require("./../../../../common"), 
function(e, t) {
    for (var o in t) e[o] = t[o];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 104 ], {
    2: function(t, o) {
        var r;
        r = function() {
            return this;
        }();
        try {
            r = r || new Function("return this")();
        } catch (t) {
            "object" == ("undefined" == typeof window ? "undefined" : e(window)) && (r = window);
        }
        t.exports = r;
    },
    674: function(e, t, o) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var r = o(0), n = o(4), i = o(1), a = o(7), c = o(12), s = o(432), d = o(3), u = {
            path: String,
            isOnlyVoice: {
                type: Boolean,
                value: !1
            },
            seconds: Number,
            isShowDelete: {
                type: Boolean,
                value: !1
            },
            isShow: {
                type: Boolean,
                value: !0
            },
            uniqueKey: Number
        };
        !function(e) {
            function t(t) {
                var o = e.call(this) || this;
                return o.audioManagementService = t, o.properties = u, o.data = {}, o.recorderId = "", 
                o;
            }
            r.__extends(t, e);
            var o = t.prototype;
            o.attached = function() {
                e.prototype.attached.call(this), this.setData({
                    voiceTempFilePath: ""
                }), this.recorderId = String(new Date().getTime()) + this.data.uniqueKey, this.noticeChangeVoicePath("", "attached"), 
                this.stopCountDownSubject = new a.Subject(), this.stopCountDownObs$ = this.stopCountDownSubject.asObservable(), 
                this.listenRecorderEvent();
            }, o.ready = function() {
                e.prototype.ready.call(this);
            }, o.detached = function() {
                e.prototype.detached.call(this), this.recorderId = "", this.stopRecord();
            }, o.handleTapDeleteRecord = function() {
                this.triggerEvent("isShowDelete");
            }, o.handleTapStartRecord = function() {
                this.audioManagementService.startRecorder(this.recorderId, {
                    duration: 6e5,
                    sampleRate: 8e3,
                    numberOfChannels: 1,
                    encodeBitRate: 48e3,
                    format: "mp3"
                });
            }, o.handleTapStopRecord = function() {
                this.data.recordTime < 3 || this.stopRecord();
            }, o.handleDeleteVoice = function() {
                var e = this;
                this.setData({
                    path: "",
                    voiceTempFilePath: "",
                    recordTime: 0
                }, function() {
                    e.noticeChangeVoicePath("");
                });
            }, o.stopRecord = function() {
                this.audioManagementService.stopRecorder();
            }, o.listenRecorderEvent = function() {
                var e = this, t = this.recorderId;
                this.audioManagementService.listenRecorderEvent().pipe(d.takeUntil(this.unloadObservable)).subscribe(function(o) {
                    var r = o.res, n = o.type;
                    o.id === t && ("start" === n ? e.startRecordCallBack(r) : "error" === n ? e.recordErrorCallBack(r) : "frameRecorded" === n ? e.frameRecordedRecordCallBack(r) : "pause" === n ? e.pauseRecordCallBack(r) : "resume" === n ? e.resumeRecordCallBack(r) : "stop" === n && e.stopRecordCallBack(r));
                });
            }, o.startRecordCallBack = function(e) {
                this.triggerEvent("isStartVoice"), this.recordOnStart();
            }, o.recordOnStart = function() {
                var e;
                this.setData({
                    voiceRecording: !0
                }), this.markRecordTime(), null === (e = wx.setKeepScreenOn) || void 0 === e || e.call(wx, {
                    keepScreenOn: !0
                });
            }, o.markRecordTime = function() {
                var e = this;
                this.recorderTimeObs = a.interval(1e3).pipe(d.takeUntil(this.stopCountDownObs$ || this.unloadObservable)).subscribe(function() {
                    e.setData({
                        recordTime: (e.data.recordTime || 0) + 1
                    }), e.data.recordTime > 599 && e.recorderManager.stop();
                });
            }, o.stopRecordCallBack = function(e) {
                this.triggerEvent("isStoptVoice"), this.saveRecord(e);
            }, o.saveRecord = function(e) {
                var t, o, r = this;
                null === (t = this.stopCountDownSubject) || void 0 === t || t.next(!0), this.setData({
                    voiceRecording: !1,
                    voiceTempFilePath: e.tempFilePath
                }, function() {
                    r.noticeChangeVoicePath();
                }), null === (o = wx.setKeepScreenOn) || void 0 === o || o.call(wx, {
                    keepScreenOn: !1
                });
            }, o.pauseRecordCallBack = function(e) {
                this.stopRecord();
            }, o.resumeRecordCallBack = function(e) {}, o.frameRecordedRecordCallBack = function(e) {
                this.triggerEvent("isStartVoice"), this.recordOnStart();
            }, o.recordErrorCallBack = function(e) {
                var t = this;
                e.errMsg.indexOf("auth deny") > -1 || e.errMsg.indexOf("auth denied") > -1 ? c.rxwx.openSetting({}).subscribe(function(e) {
                    e.authSetting["scope.record"] && t.handleTapStartRecord();
                }, function() {}) : "other Recorder is Recording" === e.errMsg && this.pleaseStopOtherRecorder();
            }, o.pleaseStopOtherRecorder = function() {
                wx.showToast({
                    title: "请先结束录制中的语音",
                    icon: "none",
                    duration: 1500
                });
            }, o.noticeChangeVoicePath = function(e, t) {
                var o = this.data, r = {
                    tempFilePath: o.voiceTempFilePath,
                    seconds: o.recordTime,
                    type: t,
                    path: e
                };
                this.triggerEvent("changeVoicePath", r);
            }, t = r.__decorate([ i.wxComponent(), r.__metadata("design:paramtypes", [ s.AudioManagementService ]) ], t);
        }(n.SuperComponent);
    }
}, [ [ 674, 0, 2, 1 ] ] ]));