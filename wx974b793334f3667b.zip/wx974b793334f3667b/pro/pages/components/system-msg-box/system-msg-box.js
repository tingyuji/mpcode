var t = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
    return typeof t;
} : function(t) {
    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
};

require("./../../../../runtime"), require("./../../../../mono"), require("./../../../../common"), 
function(t, e) {
    for (var i in e) t[i] = e[i];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 152 ], {
    2: function(e, i) {
        var r;
        r = function() {
            return this;
        }();
        try {
            r = r || new Function("return this")();
        } catch (e) {
            "object" == ("undefined" == typeof window ? "undefined" : t(window)) && (r = window);
        }
        e.exports = r;
    },
    760: function(t, e, i) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        });
        var r = i(0), o = i(4), n = i(1), s = i(13), a = i(3), u = i(25), p = i(18), c = i(10), m = i(6), d = i(11), y = i(439), l = i(14), f = {
            groupId: String,
            groupType: Number,
            ghViewType: {
                type: Number,
                value: 0
            },
            templateId: String,
            disableFetch: Boolean
        };
        !function(t) {
            function e(e, i, r, o, n) {
                var s = t.call(this) || this;
                return s.apiService = e, s.timeService = i, s.routeService = r, s.utils = o, s.monoUtil = n, 
                s.properties = f, s.data = {
                    ISystemMsgBoxType: y.ISystemMsgBoxType
                }, s;
            }
            r.__extends(e, t);
            var i = e.prototype;
            i.attached = function() {
                t.prototype.attached.call(this), this.data.disableFetch || this.initSystemMsgBoxList();
            }, i.ready = function() {
                t.prototype.ready.call(this);
            }, i.handleTapGoPage = function(t) {
                var e = this, i = t.currentTarget.dataset.url;
                if (i) {
                    var o = r.__read(i.split("?"), 2), n = o[0], s = o[1];
                    n.startsWith("pages/") && (n = "/" + n), this.getIsPathWithPro() && (n = "/pro" + n);
                    var a = s.split("&").reduce(function(t, i) {
                        var o, n = r.__read(i.split("="), 2), s = n[0], a = n[1];
                        return t[s] = "{" + s + "}" === a ? null === (o = e.data) || void 0 === o ? void 0 : o[s] : a, 
                        t;
                    }, {});
                    this.utils.navigateTo(n, a);
                }
            }, i.initSystemMsgBoxList = function() {
                var t = this;
                this.apiService.querySysMsgboxListGhoMemajorUsingPOST(this.getQueryParams(), s.skipErrorOptions).pipe(a.map(function(t) {
                    var e = t.data;
                    return void 0 === e ? [] : e;
                }), a.map(function(e) {
                    return e.map(function(e) {
                        return r.__assign(r.__assign({}, e), t.getSystemMsgBoxContent(e.msgContent));
                    });
                })).subscribe(function(e) {
                    t.setData({
                        systemMsgBoxList: e
                    });
                });
            }, i.getSystemMsgBoxContent = function(t) {
                void 0 === t && (t = "{}");
                var e = this.monoUtil.safeJSONParse(t, {}), i = e.createTime, r = e.msgId, o = e.templateId, n = e.msg;
                return {
                    createTime: i,
                    msgId: r,
                    templateId: o,
                    msg: void 0 === n ? {} : n
                };
            }, i.getQueryParams = function() {
                return this.data.templateId === y.ISystemMsgBoxType.CUSTOMER_HOMEPAGE ? {
                    uid: this.utils.getUid()
                } : {};
            }, i.getIsPathWithPro = function() {
                return l.AFTER_SALE_MANAGE_PATH.startsWith("/pro");
            }, e = r.__decorate([ n.wxComponent(), r.__metadata("design:paramtypes", [ u.DefaultService, p.TimeService, c.RouteService, m.UtilService, d.MonoUtilService ]) ], e);
        }(o.SuperComponent);
    }
}, [ [ 760, 0, 2, 1 ] ] ]));