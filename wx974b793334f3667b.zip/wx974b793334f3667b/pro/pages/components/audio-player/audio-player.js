var t = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
    return typeof t;
} : function(t) {
    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
};

require("./../../../../runtime"), require("./../../../../mono"), require("./../../../../common"), 
function(t, e) {
    for (var i in e) t[i] = e[i];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 86 ], {
    2: function(e, i) {
        var o;
        o = function() {
            return this;
        }();
        try {
            o = o || new Function("return this")();
        } catch (e) {
            "object" == ("undefined" == typeof window ? "undefined" : t(window)) && (o = window);
        }
        e.exports = o;
    },
    673: function(t, e, i) {
        var o;
        Object.defineProperty(e, "__esModule", {
            value: !0
        });
        var n = i(0), a = i(22), s = i(4), r = i(1), u = i(3), d = i(432), c = {
            seconds: Number,
            path: {
                type: String,
                observer: function(t, e) {
                    t !== e && this.initInnerAudioContext(t);
                }
            },
            urlPlay: String,
            voiceId: String,
            playingVoiceId: {
                type: String,
                observer: function(t) {
                    t && 1 === this.data.voicePlayStatus && t !== this.data.voiceId && this.stopPlayVoice();
                }
            },
            max: {
                type: Number,
                value: 60
            },
            maxLen: {
                type: Number,
                value: 320
            },
            lenStyle: {
                type: Number,
                value: 3
            }
        }, p = ((o = {})[1] = 378, o[2] = 444, o[3] = 0, o);
        !function(t) {
            function e(e) {
                var i = t.call(this) || this;
                return i.audioManagementService = e, i.properties = c, i.data = {
                    Style2LenMap: p
                }, i;
            }
            n.__extends(e, t);
            var i = e.prototype;
            i.ready = function() {
                t.prototype.ready.call(this);
            }, i.attached = function() {
                t.prototype.attached.call(this), this.data.path && !this.innerAudioContext && this.initInnerAudioContext(this.data.path), 
                this.audioId = String(new Date().getTime()) + this.data.path, this.listenStopAudio();
            }, i.detached = function() {
                t.prototype.detached.call(this), this.stopPlayVoice(), this.destroyAudioContext(), 
                this.audioId = "";
            }, i.hide = function() {
                this.stopPlayVoice();
            }, i.listenStopAudio = function() {
                var t = this;
                this.audioManagementService.listenAudioStop().pipe(u.takeUntil(this.unloadObservable)).subscribe(function(e) {
                    e.id === t.audioId && t.stopPlayVoice();
                });
            }, i.playVoice = function(t) {
                if (this.data.voicePlayStatus) return this.triggerEvent("voiceStopPlay", {
                    voiceId: this.data.voiceId
                }, {
                    bubbles: !0,
                    composed: !0
                }), this.stopPlayVoice(), void this.audioManagementService.stopAudio(this.audioId);
                this.setData({
                    played: !0
                }), this.triggerEvent("voicePlay", {
                    voiceId: this.data.voiceId
                }, {
                    bubbles: !0,
                    composed: !0
                }), this.audioManagementService.playAudio(this.audioId);
                var e = this.innerAudioContext;
                e && (e.seek(0), e.play());
            }, i.stopPlayVoice = function() {
                this.innerAudioContext && (this.innerAudioContext.stop(), this.setVoicePlayStatus(0));
            }, i.destroyAudioContext = function() {
                this.innerAudioContext && (this.innerAudioContext.destroy(), this.innerAudioContext = void 0);
            }, i.initInnerAudioContext = function(t) {
                var e = this;
                this.destroyAudioContext();
                var i = t.includes("://"), o = t.includes("wxfile"), n = i || o ? t : a.config.resHost + "/" + t;
                this.setData({
                    played: !1
                }), this.innerAudioContext = wx.createInnerAudioContext(), this.innerAudioContext.src = n, 
                wx.setInnerAudioOption({
                    obeyMuteSwitch: !1
                }), this.innerAudioContext.onTimeUpdate(function() {
                    e.data.urlPlay && e.data.urlPlay !== e.data.path && e.stopPlayVoice();
                }), this.innerAudioContext.onPlay(function() {
                    return e.setVoicePlayStatus(1);
                }), this.innerAudioContext.onStop(function() {
                    return e.setVoicePlayStatus(0);
                }), this.innerAudioContext.onPause(function() {
                    return e.stopPlayVoice();
                }), this.innerAudioContext.onEnded(function() {
                    e.setVoicePlayStatus(0);
                }), this.innerAudioContext.onError(function() {
                    return e.setVoicePlayStatus(0);
                });
            }, i.setVoicePlayStatus = function(t) {
                this.setData({
                    voicePlayStatus: t
                });
            }, e = n.__decorate([ r.wxComponent(), n.__metadata("design:paramtypes", [ d.AudioManagementService ]) ], e);
        }(s.SuperComponent);
    }
}, [ [ 673, 0, 2, 1 ] ] ]));