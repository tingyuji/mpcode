var t = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
    return typeof t;
} : function(t) {
    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
};

require("./../../../../runtime"), require("./../../../../mono"), require("./../../../../common"), 
function(t, e) {
    for (var n in e) t[n] = e[n];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 158 ], {
    2: function(e, n) {
        var o;
        o = function() {
            return this;
        }();
        try {
            o = o || new Function("return this")();
        } catch (e) {
            "object" == ("undefined" == typeof window ? "undefined" : t(window)) && (o = window);
        }
        e.exports = o;
    },
    759: function(t, e, n) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        });
        var o = n(0), r = n(4), i = n(1), s = {
            overRenderScreenCount: {
                type: Number,
                value: .5
            },
            dev: {
                type: Boolean,
                value: !1
            }
        };
        !function(t) {
            function e() {
                var e = t.call(this) || this;
                return e.properties = s, e.data = {
                    show: !0
                }, e;
            }
            o.__extends(e, t);
            var n = e.prototype;
            n.attached = function() {
                t.prototype.attached.call(this);
            }, n.detached = function() {
                t.prototype.detached.call(this), this.disconnectIntersectionObserver();
            }, n.ready = function() {
                t.prototype.ready.call(this), this.createIntersectionObserverInstance();
            }, n.createIntersectionObserverInstance = function() {
                var t = this, e = this.initIntersectionObserverOptions().margins;
                this.IntersectionObserverInstance = this.createIntersectionObserver({
                    initialRatio: 0
                }), this.IntersectionObserverInstance.relativeToViewport(e), this.IntersectionObserverInstance.observe(".virtual-item", function(e) {
                    return t.intersectionObserverCallback(e);
                });
            }, n.intersectionObserverCallback = function(t) {
                var e = this.data.virtualHeight, n = {
                    show: t.intersectionRatio > 0
                };
                e !== t.boundingClientRect.height && (n.virtualHeight = t.boundingClientRect.height), 
                this.setData(n);
            }, n.initIntersectionObserverOptions = function() {
                var t = {}, e = wx.getSystemInfoSync().windowHeight, n = this.data.overRenderScreenCount * e || 0;
                return t.top = t.bottom = n, {
                    margins: t
                };
            }, n.disconnectIntersectionObserver = function() {
                var t;
                "function" == typeof (null === (t = this.IntersectionObserverInstance) || void 0 === t ? void 0 : t.disconnect) && this.IntersectionObserverInstance.disconnect();
            }, n.log = function() {
                for (var t = [], e = 0; e < arguments.length; e++) t[e] = arguments[e];
                this.data.dev && console.log.apply(console, o.__spread(t));
            }, n.genRandomStr = function(t) {
                return void 0 === t && (t = 4), Number(Math.random().toString().substr(3, t) + Date.now()).toString(36);
            }, e = o.__decorate([ i.wxComponent(), o.__metadata("design:paramtypes", []) ], e);
        }(r.SuperComponent);
    }
}, [ [ 759, 0, 2, 1 ] ] ]));