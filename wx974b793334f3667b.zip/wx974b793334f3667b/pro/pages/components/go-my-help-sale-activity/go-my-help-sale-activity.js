var t = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
    return typeof t;
} : function(t) {
    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
};

require("./../../../../runtime"), require("./../../../../mono"), require("./../../../../common"), 
function(t, e) {
    for (var i in e) t[i] = e[i];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 106 ], {
    2: function(e, i) {
        var o;
        o = function() {
            return this;
        }();
        try {
            o = o || new Function("return this")();
        } catch (e) {
            "object" == ("undefined" == typeof window ? "undefined" : t(window)) && (o = window);
        }
        e.exports = o;
    },
    725: function(t, e, i) {
        var o;
        Object.defineProperty(e, "__esModule", {
            value: !0
        });
        var n = i(0), a = i(4), r = i(1), c = i(5), s = i(15), p = i(20), d = i(18), u = i(3), l = ((o = {})[0] = "帮卖活动", 
        o[1] = "帮卖活动", o[2] = "跟团活动", o), h = {
            groupId: String,
            parentActId: Number,
            actListType: {
                type: Number,
                value: 0
            }
        };
        !function(t) {
            function e(e, i, o, n) {
                var a = t.call(this) || this;
                return a.apiService = e, a.commonService = i, a.monoCommonService = o, a.timeService = n, 
                a.properties = h, a.data = {
                    myHelpSaleActListTitleMap: l
                }, a;
            }
            n.__extends(e, t);
            var i = e.prototype;
            i.ready = function() {
                t.prototype.ready.call(this);
            }, i.handleTapGoMyHelpSaleActivity = function(t) {
                var e, i = this, o = this.data, a = o.groupId, r = o.parentActId, c = o.actListType;
                ((e = {})[0] = this.apiService.getGhChildActivitiesUsingPOST({
                    pactId: r,
                    ghId: a
                }).pipe(u.map(function(t) {
                    var e = t.data;
                    return void 0 === e ? [] : e;
                })), e[1] = this.apiService.listGhChildActivitiesInEvaluationUsingPOST({
                    ghGroupId: a,
                    actId: r
                }).pipe(u.map(function(t) {
                    var e = t.data;
                    return void 0 === e ? [] : e;
                })), e[2] = this.apiService.getMyFollowActListUsingPOST({
                    startActId: r,
                    groupId: a
                }).pipe(u.map(function(t) {
                    var e = t.data;
                    return void 0 === e ? [] : e;
                })), e)[c].subscribe(function(t) {
                    var e = t.map(function(t) {
                        var e = i.monoCommonService.sliceEmojiString(t.activityName || "", 0, 13), o = t.publishTime, a = 5 === t.activityStatus ? "已结束" : "正在接龙", r = 5 === t.activityStatus;
                        return n.__assign(n.__assign({}, t), {
                            seqName: e,
                            publishStr: o,
                            seqStatusStr: a,
                            isEnd: r
                        });
                    });
                    i.processActInfoList(e);
                });
            }, i.handleTapActInfo = function(t) {
                var e = t.currentTarget.dataset.actInfo;
                this.goHelpSaleChild(e), this.hideSelectedModal();
            }, i.handleHideSelectedModal = function() {
                this.hideSelectedModal();
            }, i.hideSelectedModal = function() {
                this.setData({
                    showSelectedModal: !1
                });
            }, i.processActInfoList = function(t) {
                var e = t.length;
                if (1 === e) this.goHelpSaleChild(t[0]); else {
                    if (!(e > 1)) throw wx.showToast({
                        title: "暂未查询到" + l[this.data.actListType] + "，请咨询客服",
                        icon: "none"
                    }), new Error("请求有误，没有任何存在活动");
                    this.setData({
                        showSelectedModal: !0,
                        actInfoList: t
                    });
                }
            }, i.goHelpSaleChild = function(t) {
                var e = t, i = e.actId, o = e.activityType, n = 2 === this.data.actListType ? 150 : 160;
                this.commonService.goToDetailPossiblyJumpApp({
                    seqType: o || n,
                    actId: String(i)
                });
            }, e = n.__decorate([ r.wxComponent(), n.__metadata("design:paramtypes", [ c.DefaultService, s.CommonService, p.MonoCommonService, d.TimeService ]) ], e);
        }(a.SuperComponent);
    }
}, [ [ 725, 0, 2, 1 ] ] ]));