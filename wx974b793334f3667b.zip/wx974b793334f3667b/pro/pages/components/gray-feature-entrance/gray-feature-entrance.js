var e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
};

require("./../../../../runtime"), require("./../../../../mono"), require("./../../../../common"), 
function(e, t) {
    for (var o in t) e[o] = t[o];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 107 ], {
    2: function(t, o) {
        var r;
        r = function() {
            return this;
        }();
        try {
            r = r || new Function("return this")();
        } catch (t) {
            "object" == ("undefined" == typeof window ? "undefined" : e(window)) && (r = window);
        }
        t.exports = r;
    },
    729: function(e, t, o) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var r = o(0), n = o(4), a = o(1), i = o(17), u = {
            ok: Boolean,
            grayFeatureCode: {
                type: String
            }
        };
        !function(e) {
            function t(t) {
                var o = e.call(this) || this;
                return o.grayFeatureService = t, o.properties = u, o.data = {}, o;
            }
            r.__extends(t, e), t.prototype.ready = function() {
                var t = this;
                e.prototype.ready.call(this), this.data.grayFeatureCode && this.grayFeatureService.canIUseFeature(this.data.grayFeatureCode).subscribe(function(e) {
                    t.setData({
                        canUse: e
                    });
                });
            }, t = r.__decorate([ a.wxComponent(), r.__metadata("design:paramtypes", [ i.GrayFeatureService ]) ], t);
        }(n.SuperComponent);
    }
}, [ [ 729, 0, 2, 1 ] ] ]));