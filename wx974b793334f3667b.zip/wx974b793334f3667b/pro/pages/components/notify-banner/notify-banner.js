var t = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
    return typeof t;
} : function(t) {
    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
};

require("./../../../../runtime"), require("./../../../../mono"), require("./../../../../common"), 
function(t, i) {
    for (var e in i) t[e] = i[e];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 130 ], {
    2: function(i, e) {
        var n;
        n = function() {
            return this;
        }();
        try {
            n = n || new Function("return this")();
        } catch (i) {
            "object" == ("undefined" == typeof window ? "undefined" : t(window)) && (n = window);
        }
        i.exports = n;
    },
    754: function(t, i, e) {
        Object.defineProperty(i, "__esModule", {
            value: !0
        });
        var n = e(0), a = e(4), o = e(1), r = e(7), s = e(3), u = e(6), h = e(69), c = {
            slotHeight: {
                type: Number,
                require: !0
            },
            initialTop: {
                type: Number,
                value: -13
            },
            duration: Number,
            animateDuration: {
                type: Number,
                value: 300,
                observer: function(t) {
                    this.setData({
                        animateDuration: t
                    });
                }
            }
        };
        !function(t) {
            function i(i) {
                var e = t.call(this) || this;
                return e.utilService = i, e.properties = c, e.data = {
                    hide: !0,
                    isTouching: !1
                }, e.computed = {
                    toggleAnimation: function(t) {
                        return t.isTouching ? "" : "transition: transform " + t.animateDuration / 1e3 + "s linear;";
                    }
                }, e;
            }
            n.__extends(i, t);
            var e = i.prototype;
            e.attached = function() {
                t.prototype.attached.call(this);
                var i = -this.utilService.getPx(this.data.slotHeight) - this.data.navHeight;
                this.setData({
                    hidePosition: i,
                    top: this.data.initialTop
                });
            }, e.ready = function() {
                var i = this;
                t.prototype.ready.call(this), this.initObservable(), this.setAutoHideTimer(), wx.nextTick(function() {
                    i.setData({
                        hide: !1
                    }), r.timer(i.data.animateDuration).pipe(s.takeUntil(i.unloadObservable)).subscribe(function() {
                        i.triggerEvent("show");
                    });
                });
            }, e.handleTouchStart = function(t) {
                var i;
                if (!this.data.hide && (this.setData({
                    isTouching: !0
                }), null === (i = t.changedTouches) || void 0 === i ? void 0 : i[0])) {
                    var e = t.changedTouches[0], n = e.clientX, a = e.clientY;
                    this.touchStartPoint = {
                        x: n,
                        y: a
                    }, this.touchStartTime = new Date().getTime();
                }
            }, e.handleTouchMove = function(t) {
                var i, e;
                if (!this.data.hide && this.data.isTouching && (null === (i = t.changedTouches) || void 0 === i ? void 0 : i[0]) && (null === (e = this.touchStartPoint) || void 0 === e ? void 0 : e.y)) {
                    var n = t.changedTouches[0].clientY - this.touchStartPoint.y, a = this.data;
                    n < a.hidePosition + a.initialTop + 30 || this.setData({
                        top: this.data.initialTop + (n < 0 ? n : 0)
                    });
                }
            }, e.handleTouchEnd = function(t) {
                var i, e = this;
                if (!this.data.hide && (null === (i = t.changedTouches) || void 0 === i ? void 0 : i[0]) && this.touchStartPoint) {
                    this.setData({
                        isTouching: !1
                    });
                    var n = t.changedTouches[0], a = n.clientX, o = n.clientY, r = this.touchStartPoint, s = r.x, u = r.y;
                    if (void 0 !== s && void 0 !== a) {
                        var h = Math.abs(s - a), c = u - o, d = h < 30 && Math.abs(c) < 30 && new Date().getTime() - this.touchStartTime < 400, l = this.data, p = l.initialTop, v = l.hidePosition;
                        d ? this.triggerEvent("confirm") : h < 200 && c > (p - v) / 6 ? wx.nextTick(function() {
                            e.hideWithAnimation();
                        }) : (this.use().set("top", p), this.setAutoHideTimer());
                    }
                }
            }, e.initObservable = function() {
                this.hideSubject = new r.Subject();
            }, e.setAutoHideTimer = function() {
                var t, i = this, e = this.data.duration;
                e && (null === (t = this.autoHideSubscription) || void 0 === t || t.unsubscribe(), 
                this.autoHideSubscription = r.timer(e).pipe(s.takeUntil(this.hideSubject), s.takeUntil(this.unloadObservable)).subscribe(function() {
                    i.data.isTouching || i.hideWithAnimation();
                }));
            }, e.hideWithAnimation = function() {
                var t = this;
                this.hideSubject.next(), this.setData({
                    hide: !0
                }), r.timer(this.data.animateDuration).pipe(s.takeUntil(this.unloadObservable)).subscribe(function() {
                    t.triggerEvent("hide");
                });
            }, n.__decorate([ h.Throttle(16.666666), n.__metadata("design:type", Function), n.__metadata("design:paramtypes", [ Object ]), n.__metadata("design:returntype", void 0) ], i.prototype, "handleTouchMove", null), 
            i = n.__decorate([ o.wxComponent(), n.__metadata("design:paramtypes", [ u.UtilService ]) ], i);
        }(a.SuperComponent);
    }
}, [ [ 754, 0, 2, 1 ] ] ]));