var e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
};

require("./../../../../runtime"), require("./../../../../mono"), require("./../../../../common"), 
function(e, t) {
    for (var n in t) e[n] = t[n];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 105 ], {
    2: function(t, n) {
        var i;
        i = function() {
            return this;
        }();
        try {
            i = i || new Function("return this")();
        } catch (t) {
            "object" == ("undefined" == typeof window ? "undefined" : e(window)) && (i = window);
        }
        t.exports = i;
    },
    68: function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.CHINA_PHONE_CODE = void 0;
        var i, o = n(0), a = n(4), r = n(1), c = n(69), s = n(28);
        t.CHINA_PHONE_CODE = "86", function(e) {
            e[e.COMMON = 0] = "COMMON", e[e.LIST = 1] = "LIST";
        }(i || (i = {}));
        var l = {
            isVisible: {
                type: Boolean,
                observer: function(e) {
                    var t;
                    e && ((null === (t = this.data.capitalAreaCodeList) || void 0 === t ? void 0 : t.length) ? (this.initCurrentSelected(), 
                    this.createIntersectionObserverInstance()) : this.initPhoneAreaList());
                }
            },
            currentArea: Object
        };
        !function(e) {
            function n(n) {
                var i = e.call(this) || this;
                return i.apiService = n, i.properties = l, i.data = {
                    commonAreaCodeList: [ {
                        code: t.CHINA_PHONE_CODE,
                        label: "中国大陆"
                    }, {
                        code: "852",
                        label: "中国香港"
                    }, {
                        code: "853",
                        label: "中国澳门"
                    }, {
                        code: "886",
                        label: "中国台湾"
                    }, {
                        code: "1",
                        label: "美国"
                    }, {
                        code: "65",
                        label: "新加坡"
                    }, {
                        code: "81",
                        label: "日本"
                    }, {
                        code: "60",
                        label: "马来西亚"
                    }, {
                        code: "1",
                        label: "加拿大"
                    }, {
                        code: "82",
                        label: "韩国"
                    } ]
                }, i.indexListPositionTop = 0, i.indexItemHeight = 0, i;
            }
            o.__extends(n, e);
            var i = n.prototype;
            i.detached = function() {
                e.prototype.detached.call(this), this.disconnectIntersectionObserver();
            }, i.initPhoneAreaList = function() {
                var e = this;
                this.apiService.getCountryCodeListUsingGET().subscribe(function(t) {
                    var n = t.data || [], i = e.formatAreaCodeList(n);
                    e.setData({
                        currentCapital: i[0].capital,
                        capitalAreaCodeList: i
                    }, function() {
                        e.initCurrentSelected(), e.createIntersectionObserverInstance(), setTimeout(function() {
                            e.computeIndexListSize();
                        }, 500);
                    });
                });
            }, i.handleTapSelectArea = function(e) {
                this.triggerEvent("selectArea", e.currentTarget.dataset.area);
            }, i.handleTapCancel = function() {
                this.triggerEvent("cancel");
            }, i.handleScrollToCapital = function(e) {
                var t = e.changedTouches[0].clientY, n = Math.floor((t - this.indexListPositionTop) / this.indexItemHeight);
                this.scrollToCapital(n);
            }, i.scrollToCapital = function(e) {
                var t, n = (null === (t = this.data.capitalAreaCodeList[e]) || void 0 === t ? void 0 : t.capital) || "";
                n && this.setData({
                    currentCapital: n,
                    currentScrollView: "capital-" + (0 === e ? "0" : n)
                });
            }, i.initCurrentSelected = function() {
                var e = this.data.currentArea;
                e && -1 === this.data.commonAreaCodeList.findIndex(function(t) {
                    return t.code === e.code && t.label === e.label;
                }) ? this.setData({
                    currentScrollView: encodeURI("area-" + e.label + e.code).replace(/%/g, "")
                }) : this.scrollToCapital(0);
            }, i.createIntersectionObserverInstance = function() {
                var e = this;
                this.IntersectionObserverInstance = this.createIntersectionObserver({
                    initialRatio: 0,
                    observeAll: !0
                }), this.IntersectionObserverInstance.relativeTo("#capitalSticky", {
                    top: 0,
                    bottom: 0
                }), this.IntersectionObserverInstance.observe(".capital-box", function(t) {
                    return e.intersectionObserverCallback(t);
                });
            }, i.computeIndexListSize = function() {
                var e = this;
                this.createSelectorQuery().select("#indexList").boundingClientRect(function(t) {
                    e.indexListPositionTop = t.top, e.indexItemHeight = t.height / e.data.capitalAreaCodeList.length;
                }).exec();
            }, i.intersectionObserverCallback = function(e) {
                if (e.intersectionRatio > 0) {
                    var t = e.id.split("-")[1];
                    this.setData({
                        currentCapital: t
                    });
                }
            }, i.disconnectIntersectionObserver = function() {
                var e;
                "function" == typeof (null === (e = this.IntersectionObserverInstance) || void 0 === e ? void 0 : e.disconnect) && this.IntersectionObserverInstance.disconnect();
            }, i.formatAreaCodeList = function(e) {
                for (var t = [], n = {}, i = 0, o = 0, a = e.length; o < a; o++) {
                    var r = e[o];
                    if (r.index) {
                        var c = {
                            label: r.countryName,
                            code: r.phoneCode,
                            id: encodeURI("area-" + r.countryName + r.phoneCode).replace(/%/g, "")
                        }, s = r.index.toUpperCase();
                        n.hasOwnProperty(s) ? t[n[s]].areaList.push(c) : (n[s] = i++, t.push({
                            capital: s,
                            areaList: [ c ]
                        }));
                    }
                }
                return t;
            }, o.__decorate([ c.Throttle(100), o.__metadata("design:type", Function), o.__metadata("design:paramtypes", [ Object ]), o.__metadata("design:returntype", void 0) ], n.prototype, "handleScrollToCapital", null), 
            n = o.__decorate([ r.wxComponent(), o.__metadata("design:paramtypes", [ s.DefaultService ]) ], n);
        }(a.SuperComponent);
    }
}, [ [ 68, 0, 2, 1 ] ] ]));