var e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
};

require("./../../../../runtime"), require("./../../../../mono"), require("./../../../../common"), 
function(e, t) {
    for (var o in t) e[o] = t[o];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 84 ], {
    2: function(t, o) {
        var n;
        n = function() {
            return this;
        }();
        try {
            n = n || new Function("return this")();
        } catch (t) {
            "object" == ("undefined" == typeof window ? "undefined" : e(window)) && (n = window);
        }
        t.exports = n;
    },
    780: function(e, t, o) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var n = o(0), r = o(4), i = o(1), a = o(93), c = {
            isShow: Boolean,
            protocolTypeList: Array
        };
        !function(e) {
            function t(t) {
                var o = e.call(this) || this;
                return o.agreementService = t, o.properties = c, o.data = {}, o.computed = {
                    agreementTexts: function(e) {
                        var t = e.protocolTypeList, o = void 0 === t ? [] : t, n = e.agreementConfig, r = void 0 === n ? {} : n;
                        return o.map(function(e) {
                            var t;
                            return "《" + (null === (t = r[e]) || void 0 === t ? void 0 : t.title) + "》";
                        }).join("");
                    }
                }, o;
            }
            n.__extends(t, e);
            var o = t.prototype;
            o.attached = function() {
                var t = this;
                e.prototype.attached.call(this), this.agreementService.getAllProtocolInfo().subscribe(function(e) {
                    t.setData({
                        agreementConfig: e
                    });
                });
            }, o.handleTapCloseModal = function() {
                this.triggerEvent("close");
            }, o.handleTapCancel = function() {
                this.triggerEvent("close");
            }, o.handleTapConfirm = function() {
                this.triggerEvent("confirm");
            }, t = n.__decorate([ i.wxComponent(), n.__metadata("design:paramtypes", [ a.AgreementService ]) ], t);
        }(r.SuperComponent);
    }
}, [ [ 780, 0, 2, 1 ] ] ]));