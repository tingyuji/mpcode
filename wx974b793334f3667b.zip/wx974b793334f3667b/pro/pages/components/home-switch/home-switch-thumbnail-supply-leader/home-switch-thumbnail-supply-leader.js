var e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
};

require("./../../../../../runtime"), require("./../../../../../mono"), require("./../../../../../common"), 
function(e, t) {
    for (var r in t) e[r] = t[r];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 118 ], {
    2: function(t, r) {
        var n;
        n = function() {
            return this;
        }();
        try {
            n = n || new Function("return this")();
        } catch (t) {
            "object" == ("undefined" == typeof window ? "undefined" : e(window)) && (n = window);
        }
        t.exports = n;
    },
    740: function(e, t, r) {
        var n;
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var o = r(0), i = r(4), a = r(1), s = r(20), p = r(200), c = r(267), u = r(61), y = r(7), m = r(3), l = ((n = {})[0] = "balance", 
        n[1] = "commission", n[2] = "payment", n[3] = "unDeliverOrderNum", n[4] = "todayOrderNum", 
        n[5] = "unRefund", n[6] = "receivedCommission", n[7] = "saleVolume", n[8] = "todayOrderNum", 
        n[9] = "cancelOrderNum", n), d = {
            preloadData: {
                type: Object,
                observer: function(e, t) {
                    var r = this;
                    if (e) {
                        var n = this.monoCommonService.getGroupType(e.ghType), i = "isFakeSupply" === e.homeFakeRoleBoolKey ? 105 : e.ghType, a = this.reportBarService.getMenuList(i) || [];
                        this.getPanelList(n.isAssociation, e).subscribe(function(e) {
                            r.setData(o.__assign(o.__assign({}, n), {
                                panelList: e,
                                menuList: a
                            }));
                        });
                    }
                }
            },
            isNewLeaderAndBrandHelp: Boolean,
            canUseSeqMaterialLibrary: Boolean
        };
        !function(e) {
            function t(t, r, n) {
                var o = e.call(this) || this;
                return o.monoCommonService = t, o.reportBarService = r, o.activitySeparateService = n, 
                o.properties = d, o.data = {
                    statisticsDataKey: l
                }, o;
            }
            o.__extends(t, e), t.prototype.getPanelList = function(e, t) {
                var r = t.useStatus, n = t.isExpired, o = t.ghType, i = t.homeFakeRoleBoolKey, a = t.ghCode, s = this.data.canUseSeqMaterialLibrary;
                if (!o) return y.of([]);
                var c = 10 === r && !n, u = "isFakeHelp" === i, l = "isFakeSupply" === i;
                return this.activitySeparateService.getCanUseSignManagement(a, o).pipe(m.map(function(t) {
                    var r = t.canUseSignManagement, n = p.getGroupPanelConfig({
                        groupType: o,
                        isFakeHelp: u,
                        isFakeSupply: l,
                        canUseActivitySeparation: r,
                        canUseSeqMaterialLibrary: s
                    });
                    return n ? c && e ? n.upgrade || [] : n.basic : [];
                }));
            }, t = o.__decorate([ a.wxComponent(), o.__metadata("design:paramtypes", [ s.MonoCommonService, c.ReportBarService, u.ActivitySeparateService ]) ], t);
        }(i.SuperComponent);
    }
}, [ [ 740, 0, 2, 1 ] ] ]));