var e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
};

require("./../../../../runtime"), require("./../../../../mono"), require("./../../../../common"), 
function(e, t) {
    for (var i in t) e[i] = t[i];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 111 ], {
    2: function(t, i) {
        var o;
        o = function() {
            return this;
        }();
        try {
            o = o || new Function("return this")();
        } catch (t) {
            "object" == ("undefined" == typeof window ? "undefined" : e(window)) && (o = window);
        }
        t.exports = o;
    },
    776: function(e, t, i) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var o = i(0), a = i(4), s = i(1), r = i(5), n = i(233), h = i(3), c = i(6), l = i(7), p = i(77), m = i(234), u = i(15), S = i(13), g = i(34), d = i(328), v = i(17), f = {
            groupId: String,
            groupType: Number,
            useSlot: Boolean,
            disableFetch: Boolean,
            isHomeFront: Boolean,
            isArea: {
                type: Boolean,
                value: !0
            }
        };
        !function(e) {
            function t(t, i, o, a, s, r, n, h) {
                var c = e.call(this) || this;
                return c.apiService = t, c.utilService = i, c.commonService = o, c.grayService = a, 
                c.homeNavbarService = s, c.preloadHomeService = r, c.homeSwitchService = n, c.homeFakeSeparateService = h, 
                c.properties = f, c.data = {
                    pagesStartPosition: 0,
                    pagesItemHeight: 0
                }, c.computed = {
                    isCustomerHome: function(e) {
                        return 30 === e.groupType;
                    }
                }, c.homeList = [], c;
            }
            o.__extends(t, e);
            var i = t.prototype;
            i.attached = function() {
                var t = this;
                e.prototype.attached.call(this);
                var i = this.data.isIPad ? 128 : this.utilService.getPx(254), o = .4346 * this.utilService.getApp().globalData.windowHeight + this.utilService.getPx(144);
                this.use().set("titleTopPadding", this.data.navHeight + this.utilService.getPx(24)), 
                this.use().set("pagesStartPosition", this.data.navHeight + i), this.use().set("pagesItemHeight", o), 
                this.use().set("isMacOS", this.utilService.getSystemInfo().system.toLowerCase().includes("macos")), 
                this.data.disableFetch || (this.listenHomepageSwitchRefresh(), l.timer(p.HOME_ASYNC_DATA_WAIT_TIME).pipe(h.takeUntil(this.unloadObservable)).subscribe(function() {
                    t.getHomeList();
                }));
            }, i.handleTapShowHomepageList = function() {
                var e = this;
                this.triggerEvent("showModal"), this.setData({
                    isShowHomeSwitchModal: !0
                }), setTimeout(function() {
                    e.selectComponent("#homeSwitchPage").setData({
                        homeList: e.homeList
                    }), e.setData({
                        isShowDelayHomeSwitchModal: !0
                    });
                }, 1);
            }, i.handleTapHideShowHomepageList = function() {
                this.triggerEvent("hideModal"), this.hideHomepageList();
            }, i.handleSwitchHome = function(e) {
                this.switchHomepage(e.detail);
            }, i.switchHomepage = function(e) {
                var t, i, a, s;
                if (e && e.ghCode) {
                    var r = this.data, n = r.groupId, h = r.groupType, c = r.isHomeFront, l = e.ghCode, p = e.ghType, m = e.ghName, u = e.logoUrl, S = e.homeFakeRoleBoolKey, g = {
                        ghId: l,
                        ghType: p,
                        ghName: m,
                        logoUrl: u
                    };
                    if (l === n && p === h && (null === (a = this.homeFakeSeparateService.getCacheRoleInfo(l)) || void 0 === a ? void 0 : a.homeFakeRoleBoolKey) === S) this.hideHomepageList(); else {
                        var d = {
                            isHomeBackEnd: !0,
                            routeTime: +new Date()
                        }, v = Boolean(null === (s = this.utilService.getPage()) || void 0 === s ? void 0 : s.options.isKeepSwitchFront) || c, f = !!this.homeSwitchService.checkShowFrontHomeSwitchButton(p) && v, y = "";
                        e.homeFakeRoleBoolKey && f && (y = ((t = {}).isFakeHelp = "isFrontFakeHelp", t.isFakeSupply = "isFrontFakeSupply", 
                        t)[e.homeFakeRoleBoolKey]), this.effectSwitchHome(g, e, f), this.commonService.goHomePage(l, p, !0, "redirectTo", o.__assign(o.__assign(o.__assign(o.__assign({}, d), {
                            isHomeBackEnd: !f
                        }), v ? {
                            isKeepSwitchFront: 1
                        } : {}), y ? ((i = {})[y] = 1, i) : {}));
                    }
                }
            }, i.hideHomepageList = function() {
                this.setData({
                    isShowHomeSwitchModal: !1,
                    isShowDelayHomeSwitchModal: !1
                });
            }, i.listenHomepageSwitchRefresh = function() {
                var e = this;
                this.homeNavbarService.updateSwitchOb.pipe(h.takeUntil(this.unloadObservable)).subscribe(function() {
                    e.getHomeList();
                });
            }, i.effectSwitchHome = function(e, t, i) {
                void 0 === i && (i = !1);
                var o = e.ghId, a = e.ghType, s = e.ghName;
                if (t.homeFakeRoleBoolKey && this.homeFakeSeparateService.setCacheRole(o, t.fakeRoleType, t.homeFakeRoleBoolKey), 
                80 === a) {
                    var r = s.indexOf("（");
                    if (r > -1) {
                        var n = s.slice(0, r);
                        e.ghName = n;
                    }
                }
                i || [ 100, 30 ].includes(a) || this.preloadHomeService.setHomePreloadResource(e), 
                this.apiService.setHomeTopUsingPUT(o, S.skipErrorOptions).subscribe(), this.apiService.updateLastEnterGhV2UsingPUT(o, S.skipErrorOptions).subscribe();
            }, i.getHomeList = function() {
                var e = this;
                this.apiService.getSwitchHomeListV2UsingGET().subscribe(function(t) {
                    var i = t.data, a = i.normalHomeList, s = void 0 === a ? [] : a, r = i.expireHomeList, n = (void 0 === r ? [] : r).map(function(e) {
                        return Object.assign({}, e, {
                            isExpired: !0
                        });
                    }), h = o.__spread(s, n);
                    e.homeFakeSeparateService.batchGetFakeSeparateHomeSwitchInfoObs(h).subscribe(function(t) {
                        for (var i, a = t.length - 1; a >= 0; a--) {
                            var s = t[a], r = e.homeFakeSeparateService.batchGetCacheRoleInfo();
                            3 === s.fakeRoleType && ("isFakeSupply" === (null === (i = r[s.ghCode]) || void 0 === i ? void 0 : i.homeFakeRoleBoolKey) ? t.splice(a, 0, o.__assign(o.__assign({}, s), {
                                homeFakeRoleBoolKey: "isFakeSupply"
                            })) : (s.homeFakeRoleBoolKey = "isFakeSupply", t.splice(a, 0, o.__assign(o.__assign({}, s), {
                                homeFakeRoleBoolKey: "isFakeHelp"
                            }))));
                        }
                        e.homeList = t, e.setData({
                            homeListLength: t.length
                        });
                    }, function() {
                        e.homeList = h, e.setData({
                            homeListLength: h.length
                        });
                    });
                });
            }, t = o.__decorate([ s.wxComponent(), o.__metadata("design:paramtypes", [ r.DefaultService, c.UtilService, u.CommonService, v.GrayFeatureService, n.HomeNavbarService, m.HomePreloadService, d.HomeSwitchService, g.HomeFakeSeparateService ]) ], t);
        }(a.SuperComponent);
    }
}, [ [ 776, 0, 2, 1 ] ] ]));