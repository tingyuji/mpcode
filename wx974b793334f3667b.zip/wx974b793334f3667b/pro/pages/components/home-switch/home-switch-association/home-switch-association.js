var t = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
    return typeof t;
} : function(t) {
    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
};

require("./../../../../../runtime"), require("./../../../../../mono"), require("./../../../../../common"), 
function(t, o) {
    for (var e in o) t[e] = o[e];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 112 ], {
    2: function(o, e) {
        var n;
        n = function() {
            return this;
        }();
        try {
            n = n || new Function("return this")();
        } catch (o) {
            "object" == ("undefined" == typeof window ? "undefined" : t(window)) && (n = window);
        }
        o.exports = n;
    },
    736: function(t, o, e) {
        Object.defineProperty(o, "__esModule", {
            value: !0
        });
        var n = e(0), r = e(4), i = e(1), a = {
            preloadData: {
                type: Object,
                observer: function(t) {
                    this.renderAndTransformData(t);
                }
            },
            groupId: String
        };
        !function(t) {
            function o() {
                var o = t.call(this) || this;
                return o.properties = a, o.data = {}, o;
            }
            n.__extends(o, t);
            var e = o.prototype;
            e.attached = function() {
                t.prototype.attached.call(this);
            }, e.ready = function() {
                t.prototype.ready.call(this);
            }, e.renderAndTransformData = function(t) {
                var o, e = {
                    logoUrl: t.logoUrl,
                    ghName: t.ghName,
                    introduce: t.ghIntro,
                    ghBackGround: t.ghBackGround,
                    positionDetail: t.positionDetail,
                    position: t.position
                };
                this.setData({
                    user: e,
                    tagList: (null === (o = null == t ? void 0 : t.tags) || void 0 === o ? void 0 : o.map(function(t) {
                        return {
                            label: t
                        };
                    })) || [],
                    verifyResult: t.realAuthFlag
                });
            }, o = n.__decorate([ i.wxComponent(), n.__metadata("design:paramtypes", []) ], o);
        }(r.SuperComponent);
    }
}, [ [ 736, 0, 2, 1 ] ] ]));