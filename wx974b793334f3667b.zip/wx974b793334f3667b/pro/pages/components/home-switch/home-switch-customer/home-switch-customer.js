var e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
};

require("./../../../../../runtime"), require("./../../../../../mono"), require("./../../../../../common"), 
function(e, t) {
    for (var i in t) e[i] = t[i];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 113 ], {
    2: function(t, i) {
        var r;
        r = function() {
            return this;
        }();
        try {
            r = r || new Function("return this")();
        } catch (t) {
            "object" == ("undefined" == typeof window ? "undefined" : e(window)) && (r = window);
        }
        t.exports = r;
    },
    773: function(e, t, i) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var r = i(0), o = i(4), n = i(1), a = i(10), c = i(26), s = i(5), u = i(27), p = {
            personalGroupId: String,
            headimgurl: String,
            nickname: String
        };
        !function(e) {
            function t(t, i, r, o) {
                var n = e.call(this) || this;
                return n.apiService = t, n.routeService = i, n.homepageService = r, n.migrateService = o, 
                n.properties = p, n.data = {}, n;
            }
            r.__extends(t, e);
            var i = t.prototype;
            i.attached = function() {
                e.prototype.attached.call(this), this.getCurrentShowingDynamicData(), this.getFirstFeedItem();
            }, i.handleNavHome = function() {
                this.routeService.goHomepageCustomerHomepage({
                    type: "reLaunch",
                    data: {
                        navHome: 1
                    }
                });
            }, i.getCurrentShowingDynamicData = function() {
                var e = this, t = this.homepageService.getCurrentShowingDynamicText(), i = this.homepageService.getActVisitData();
                t && i ? this.setData({
                    actDynamicText: t,
                    actVisitData: i
                }) : this.homepageService.fetchActDynamicData().subscribe(function(t) {
                    var i, o = t.data || {}, n = o.tips, a = void 0 === n ? [] : n, c = r.__rest(o, [ "tips" ]);
                    e.setData({
                        actDynamicText: (null === (i = a[0]) || void 0 === i ? void 0 : i.tipContent) || "",
                        actVisitData: c
                    });
                });
            }, i.getFirstFeedItem = function() {
                if (this.homepageService.customerFirstFeed) return this.setData({
                    firstFeedItem: this.homepageService.customerFirstFeed
                });
            }, t = r.__decorate([ n.wxComponent(), r.__metadata("design:paramtypes", [ s.DefaultService, a.RouteService, c.HomepageService, u.BackendMigrateService ]) ], t);
        }(o.SuperComponent);
    }
}, [ [ 773, 0, 2, 1 ] ] ]));