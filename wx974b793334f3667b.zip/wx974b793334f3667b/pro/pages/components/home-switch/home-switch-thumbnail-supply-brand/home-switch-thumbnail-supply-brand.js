var e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
};

require("./../../../../../runtime"), require("./../../../../../mono"), require("./../../../../../common"), 
function(e, t) {
    for (var r in t) e[r] = t[r];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 117 ], {
    2: function(t, r) {
        var o;
        o = function() {
            return this;
        }();
        try {
            o = o || new Function("return this")();
        } catch (t) {
            "object" == ("undefined" == typeof window ? "undefined" : e(window)) && (o = window);
        }
        t.exports = o;
    },
    738: function(e, t, r) {
        var o;
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var n = r(0), i = r(4), a = r(1), s = r(20), u = r(200), c = r(267), p = ((o = {})[0] = "balance", 
        o[1] = "commission", o[2] = "payment", o[3] = "unDeliverOrderNum", o[4] = "todayOrderNum", 
        o[5] = "unRefund", o[6] = "receivedCommission", o[7] = "saleVolume", o[8] = "todayOrderNum", 
        o[9] = "cancelOrderNum", o), m = {
            preloadData: {
                type: Object,
                observer: function(e, t) {
                    if (e) {
                        var r = this.monoCommonService.getGroupType(e.ghType), o = this.reportBarService.getMenuList(e.ghType) || [], i = this.getPanelList(r.isAssociation, e);
                        this.setData(n.__assign(n.__assign({}, r), {
                            panelList: i,
                            menuList: o
                        }));
                    }
                }
            },
            isNewLeaderAndBrandHelp: Boolean,
            canUseSeqMaterialLibrary: Boolean
        };
        !function(e) {
            function t(t, r) {
                var o = e.call(this) || this;
                return o.monoCommonService = t, o.reportBarService = r, o.properties = m, o.data = {
                    statisticsDataKey: p
                }, o;
            }
            n.__extends(t, e), t.prototype.getPanelList = function(e, t) {
                var r = t.useStatus, o = t.isExpired, n = t.ghType, i = this.data.canUseSeqMaterialLibrary;
                if (n) {
                    var a = 10 === r && !o, s = u.getGroupPanelConfig({
                        groupType: n,
                        canUseSeqMaterialLibrary: i
                    });
                    return s ? a && e ? s.upgrade : s.basic : [];
                }
            }, t = n.__decorate([ a.wxComponent(), n.__metadata("design:paramtypes", [ s.MonoCommonService, c.ReportBarService ]) ], t);
        }(i.SuperComponent);
    }
}, [ [ 738, 0, 2, 1 ] ] ]));