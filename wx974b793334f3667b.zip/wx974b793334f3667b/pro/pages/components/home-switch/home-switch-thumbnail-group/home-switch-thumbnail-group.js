var e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
};

require("./../../../../../runtime"), require("./../../../../../mono"), require("./../../../../../common"), 
function(e, t) {
    for (var o in t) e[o] = t[o];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 116 ], {
    2: function(t, o) {
        var r;
        r = function() {
            return this;
        }();
        try {
            r = r || new Function("return this")();
        } catch (t) {
            "object" == ("undefined" == typeof window ? "undefined" : e(window)) && (r = window);
        }
        t.exports = r;
    },
    758: function(e, t, o) {
        var r;
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var n = o(0), i = o(4), a = o(1), s = o(20), u = o(200), p = o(267), c = ((r = {})[0] = "balance", 
        r[1] = "commission", r[2] = "payment", r[3] = "unDeliverOrderNum", r[4] = "todayOrderNum", 
        r[5] = "unRefund", r[6] = "receivedCommission", r[7] = "saleVolume", r[8] = "todayOrderNum", 
        r[9] = "cancelOrderNum", r), m = {
            preloadData: {
                type: Object,
                observer: function(e, t) {
                    if (e) {
                        var o = this.monoCommonService.getGroupType(e.ghType), r = this.reportBarService.getMenuList(e.ghType) || [], i = this.getPanelList(o.isAssociation, e);
                        this.setData(n.__assign(n.__assign({}, o), {
                            panelList: i,
                            menuList: r
                        }));
                    }
                }
            },
            canUseSeqMaterialLibrary: Boolean
        };
        !function(e) {
            function t(t, o) {
                var r = e.call(this) || this;
                return r.monoCommonService = t, r.reportBarService = o, r.properties = m, r.data = {
                    statisticsDataKey: c
                }, r;
            }
            n.__extends(t, e), t.prototype.getPanelList = function(e, t) {
                var o = t.useStatus, r = t.isExpired, n = t.ghType, i = t.homeFakeRoleBoolKey;
                if (n) {
                    var a = this.data.canUseSeqMaterialLibrary, s = 10 === o && !r, p = "isFakeHelp" === i, c = "isFakeSupply" === i, m = u.getGroupPanelConfig({
                        groupType: n,
                        isFakeHelp: p,
                        isFakeSupply: c,
                        canUseSeqMaterialLibrary: a
                    });
                    return m ? s && e ? m.upgrade : m.basic : [];
                }
            }, t = n.__decorate([ a.wxComponent(), n.__metadata("design:paramtypes", [ s.MonoCommonService, p.ReportBarService ]) ], t);
        }(i.SuperComponent);
    }
}, [ [ 758, 0, 2, 1 ] ] ]));