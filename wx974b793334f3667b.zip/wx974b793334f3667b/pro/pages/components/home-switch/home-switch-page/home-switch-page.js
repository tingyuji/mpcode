var e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
};

require("./../../../../../runtime"), require("./../../../../../mono"), require("./../../../../../common"), 
function(e, t) {
    for (var r in t) e[r] = t[r];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 114 ], {
    2: function(t, r) {
        var o;
        o = function() {
            return this;
        }();
        try {
            o = o || new Function("return this")();
        } catch (t) {
            "object" == ("undefined" == typeof window ? "undefined" : e(window)) && (o = window);
        }
        t.exports = o;
    },
    775: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var o = r(0), a = r(4), i = r(3), n = r(1), c = r(10), s = r(5), u = r(201), h = r(34), p = r(17), m = r(26), d = r(6), l = {
            groupId: String,
            groupType: Number,
            isMacOS: Boolean,
            isCustomerHome: Boolean,
            isShowItemDetail: Boolean
        };
        !function(e) {
            function t(t, r, o, a, i, n, c) {
                var s = e.call(this) || this;
                return s.homeFakeSeparateService = t, s.routeService = r, s.userInfoService = o, 
                s.grayService = a, s.apiService = i, s.homepageService = n, s.utilService = c, s.properties = l, 
                s.data = {
                    currentIndex: 1,
                    homeThumbnailMap: {}
                }, s;
            }
            o.__extends(t, e);
            var r = t.prototype;
            r.attached = function() {
                var t = this;
                e.prototype.attached.call(this), this.getUserInfo(), this.initHomeSwitchPageGray(), 
                this.homeFakeSeparateService.getFakeRoleInfoObs(this.data.groupId, this.data.groupType, !0).subscribe(function(e) {
                    var r = e.homeFakeRoleBoolKey;
                    t.setData({
                        homeFakeRoleBoolKey: r
                    });
                });
            }, r.handleNavHome = function() {
                var e = this.utilService.getLocalStorage("person_group_id") || "0";
                this.triggerEvent("switchHome", {
                    ghCode: e,
                    ghType: 30
                });
            }, r.handleSwitchHomepage = function(e) {
                var t = this.data.homeList[e.currentTarget.dataset.index];
                this.triggerEvent("switchHome", t);
            }, r.handleTapCreateHomepage = function() {
                var e = this;
                this.grayService.canIUseFeature("2219").subscribe(function(t) {
                    t ? e.routeService.goHomeCreateHomepageMultitypeCreateHome({
                        data: {
                            navType: 20
                        }
                    }) : e.routeService.goHomeCreateHomepageHomepageIntroduce();
                });
            }, r.handleScrollToFirstPage = function() {
                this.setData({
                    currentIndex: 1
                });
            }, r.handleScrollIndexChange = function(e) {
                var t = e.currentIndex;
                this.data.homeList, this.use().set("currentIndex", t);
            }, r.getUserInfo = function() {
                var e = this;
                this.userInfoService.getCachedUserInfoSubject().pipe(i.takeUntil(this.unloadObservable)).subscribe(function(t) {
                    var r = t.uid, o = t.headimgurl, a = t.nickname, i = t.fansNum, n = t.personGhId;
                    r && e.setData({
                        headimgurl: o,
                        nickname: a,
                        fansNum: i,
                        personGhId: n
                    });
                });
            }, r.initHomeSwitchPageGray = function() {
                var e = this;
                this.grayService.canIUseFeatureByMultiply([ "2273", "2377" ]).subscribe(function(t) {
                    var r = o.__read(t, 2), a = r[0], i = r[1];
                    e.setData({
                        canUseSeqMaterialLibrary: a,
                        canUseNewAssociation: i
                    });
                });
            }, t = o.__decorate([ n.wxComponent(), o.__metadata("design:paramtypes", [ h.HomeFakeSeparateService, c.RouteService, u.UserInfoService, p.GrayFeatureService, s.DefaultService, m.HomepageService, d.UtilService ]) ], t);
        }(a.SuperComponent);
    }
}, [ [ 775, 0, 2, 1 ] ] ]));