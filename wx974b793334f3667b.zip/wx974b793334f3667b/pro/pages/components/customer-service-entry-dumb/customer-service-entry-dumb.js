var e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
};

require("./../../../../runtime"), require("./../../../../mono"), require("./../../../../common"), 
function(e, t) {
    for (var r in t) e[r] = t[r];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 94 ], {
    2: function(t, r) {
        var o;
        o = function() {
            return this;
        }();
        try {
            o = o || new Function("return this")();
        } catch (t) {
            "object" == ("undefined" == typeof window ? "undefined" : e(window)) && (o = window);
        }
        t.exports = o;
    },
    783: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var o = r(0), n = r(4), i = r(1), a = r(10), c = r(6), s = r(60), p = r(11), u = {
            groupType: Number,
            actId: String,
            chatUserType: String,
            fromId: String,
            toId: String,
            seqType: Number,
            orderNo: String,
            pactId: String,
            extraParams: Object,
            entranceScene: String
        };
        !function(e) {
            function t(t, r, o, n) {
                var i = e.call(this) || this;
                return i.routerService = t, i.util = r, i.imService = o, i.monoUtilService = n, 
                i.properties = u, i.data = {}, i;
            }
            o.__extends(t, e);
            var r = t.prototype;
            r.ready = function() {
                e.prototype.ready.call(this);
            }, r.handleTapCustomerServiceTalk = function() {
                var e, t = this, r = this.data, n = r.fromId, i = r.toId, a = r.actId, c = r.seqType, s = r.orderNo, p = r.pactId, u = r.groupType, d = r.chatUserType, y = r.entranceScene, m = "";
                if (d && "-1" !== d ? n ? i || (m = "错误的IM toId => 点击页面：") : m = "错误的IM fromId => 点击页面：" : m = "错误的IM 聊天类型 => 点击页面：", 
                m) throw m += null === (e = this.util.getPage()) || void 0 === e ? void 0 : e.route, 
                new Error(m);
                var f = o.__assign(o.__assign({
                    fromId: n,
                    groupType: u,
                    seqType: c,
                    orderNo: s,
                    pactId: p
                }, this.data.extraParams), y ? {
                    entranceScene: y
                } : null);
                this.imService.getChatUserTypeAndToId(d, i).subscribe(function(e) {
                    var r = e.chatUserType, n = e.toId, i = e.hasBindingOfficial, c = e.fromUserType, p = e.toUserType, u = !a || [ "3", "5" ].includes(r) && !s ? null : {
                        actId: a
                    }, d = t.monoUtilService.isEmpty(c) || t.monoUtilService.isEmpty(p) || i ? {
                        chatUserType: r
                    } : {
                        fromUserType: c,
                        toUserType: p
                    };
                    t.routerService.goCustomerServiceChatPage({
                        type: "navigateTo",
                        data: o.__assign(o.__assign(o.__assign(o.__assign({}, d), n ? {
                            toId: n
                        } : null), f), u)
                    });
                });
            }, t = o.__decorate([ i.wxComponent(), o.__metadata("design:paramtypes", [ a.RouteService, c.UtilService, s.ImService, p.MonoUtilService ]) ], t);
        }(n.SuperComponent);
    }
}, [ [ 783, 0, 2, 1 ] ] ]));