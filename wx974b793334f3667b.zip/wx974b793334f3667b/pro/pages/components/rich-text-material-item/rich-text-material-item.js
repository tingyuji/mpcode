var e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
};

require("./../../../../runtime"), require("./../../../../mono"), require("./../../../../common"), 
function(e, t) {
    for (var i in t) e[i] = t[i];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 139 ], {
    2: function(t, i) {
        var a;
        a = function() {
            return this;
        }();
        try {
            a = a || new Function("return this")();
        } catch (t) {
            "object" == ("undefined" == typeof window ? "undefined" : e(window)) && (a = window);
        }
        t.exports = a;
    },
    681: function(e, t, i) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var a, o = i(0), r = i(4), n = i(1), c = i(116), l = i(18), s = i(11), u = i(10), p = i(127);
        !function(e) {
            e[e.TOP = 10] = "TOP", e[e.NORMAL = 3] = "NORMAL";
        }(a || (a = {}));
        var h = {
            isSelectable: Boolean,
            isSelected: Boolean,
            isDisabled: Boolean,
            isCopy: Boolean,
            groupId: String,
            materialInfo: {
                type: Object,
                observer: function() {
                    this.initMaterialInfo();
                }
            }
        };
        !function(e) {
            function t(t, i, o, r) {
                var n = e.call(this) || this;
                return n.richTextService = t, n.timeService = i, n.monoUtilService = o, n.routeService = r, 
                n.options = {
                    multipleSlots: !0
                }, n.properties = h, n.data = {
                    MaterialTopStatusEnum: a
                }, n;
            }
            o.__extends(t, e);
            var i = t.prototype;
            i.attached = function() {
                e.prototype.attached.call(this), this.initMaterialInfo();
            }, i.handleTapSelectMaterial = function() {
                this.data.isSelectable && this.triggerEvent("selectMaterial");
            }, i.handleTapViewMaterial = function() {
                var e = this.data.materialInfo, t = e.materialId, i = e.materialName;
                this.routeService.goSeqPublishRichTextShowPage({
                    data: {
                        materialId: t,
                        title: encodeURIComponent(i),
                        type: this.data.isCopy ? p.RichTextShowPageType.COPY : p.RichTextShowPageType.PURE_PREVIEW,
                        authorGroupId: this.data.groupId
                    }
                });
            }, i.handleTapShowDetail = function() {
                this.triggerEvent("showDetail");
            }, i.initMaterialInfo = function() {
                if (this.data.materialInfo) {
                    var e = this.monoUtilService.safeJSONParse(this.data.materialInfo.materialDetail, []), t = this.richTextService.getMaterialInfoForShow(e || []), i = t.firstText, a = t.mediaList, o = this.timeService.formatDateTime(new Date(this.data.materialInfo.createTime));
                    this.setData({
                        materialDesc: i,
                        materialImgs: a,
                        materialTime: o
                    });
                }
            }, t = o.__decorate([ n.wxComponent(), o.__metadata("design:paramtypes", [ c.MonoRichTextService, l.TimeService, s.MonoUtilService, u.RouteService ]) ], t);
        }(r.SuperComponent);
    }
}, [ [ 681, 0, 2, 1 ] ] ]));