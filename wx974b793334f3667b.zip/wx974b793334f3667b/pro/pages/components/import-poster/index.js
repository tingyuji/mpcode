require("./../../../../runtime"), function(t, e) {
    for (var n in e) t[n] = e[n];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 121 ], {
    768: function(t, e) {
        Component({
            properties: {
                config: {
                    type: Object,
                    value: {}
                },
                preload: {
                    type: Boolean,
                    value: !1
                },
                hideLoading: {
                    type: Boolean,
                    value: !1
                },
                isShowImg: {
                    type: Boolean,
                    value: !1
                }
            },
            ready: function() {
                var t = this;
                if (this.data.preload) {
                    var e = this.selectComponent("#poster");
                    this.downloadStatus = "doing", e.downloadResource(this.data.config.images).then(function() {
                        t.downloadStatus = "success", t.trigger("downloadSuccess");
                    }).catch(function(e) {
                        t.downloadStatus = "fail", t.trigger("downloadFail", e);
                    });
                }
            },
            methods: {
                trigger: function(t, e) {
                    this.listener && "function" == typeof this.listener[t] && this.listener[t](e);
                },
                once: function(t, e) {
                    void 0 === this.listener && (this.listener = {}), this.listener[t] = e;
                },
                downloadResource: function(t) {
                    var e = this;
                    return new Promise(function(n, o) {
                        t && (e.downloadStatus = null);
                        var i = e.selectComponent("#poster");
                        e.downloadStatus && "fail" !== e.downloadStatus && e.images === JSON.stringify(e.data.config.images) ? "success" === e.downloadStatus ? n() : (e.once("downloadSuccess", function() {
                            return n();
                        }), e.once("downloadFail", function(t) {
                            return o(t);
                        })) : (e.images = JSON.stringify(e.data.config.images), i.downloadResource(e.data.config.images).then(function() {
                            e.downloadStatus = "success", n();
                        }).catch(function(t) {
                            return o(t);
                        }));
                    });
                },
                onCreate: function() {
                    var t = this, e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0], n = arguments[1];
                    return this.index = n, !this.data.hideLoading && wx.showLoading({
                        mask: !0,
                        title: "图片生成中"
                    }), this.downloadResource("boolean" == typeof e && e).then(function() {
                        t.selectComponent("#poster").create(t.data.config);
                    }).catch(function(e) {
                        !t.data.hideLoading && wx.hideLoading(), wx.showToast({
                            icon: "none",
                            title: e.errMsg || "生成失败"
                        }), t.triggerEvent("fail", e);
                    });
                },
                onCreateSuccess: function(t) {
                    var e = t.detail, n = "number" == typeof this.index, o = {
                        url: e,
                        index: this.index
                    };
                    !this.data.hideLoading && wx.hideLoading(), this.triggerEvent("success", n ? o : e);
                },
                onCreateFail: function(t) {
                    this.triggerEvent("fail", t);
                }
            }
        });
    }
}, [ [ 768, 0 ] ] ]));