var e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
};

require("./../../../../runtime"), require("./../../../../mono"), require("./../../../../common"), 
function(e, t) {
    for (var r in t) e[r] = t[r];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 100 ], {
    2: function(t, r) {
        var n;
        n = function() {
            return this;
        }();
        try {
            n = n || new Function("return this")();
        } catch (t) {
            "object" == ("undefined" == typeof window ? "undefined" : e(window)) && (n = window);
        }
        t.exports = n;
    },
    716: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var n, i = r(0), a = r(4), o = r(1), s = r(7), c = r(3), p = r(10), u = r(5), l = r(13), d = r(29), f = r(17), v = r(83), y = r(11);
        !function(e) {
            e.CAROUSEL = "carousel", e.SLIDER = "slider";
        }(n || (n = {}));
        var g = {
            groupId: String,
            groupType: Number,
            scopeCode: {
                type: String,
                observer: "initData"
            },
            bannerHeight: Number,
            isShowDots: {
                type: Boolean,
                value: !0
            },
            customClass: {
                type: String,
                value: ""
            },
            radius: {
                type: String,
                value: "24"
            },
            extraParam: Object,
            customBannerConfig: {
                type: Array,
                observer: function(e) {
                    this.setData({
                        bannerList: e
                    });
                }
            },
            outerBannerIds: {
                type: Array,
                value: []
            }
        };
        !function(e) {
            function t(t, r, i, a, o, s) {
                var c = e.call(this) || this;
                return c.apiService = t, c.routeService = r, c.fileService = i, c.httpClient = a, 
                c.grayService = o, c.monoUtilService = s, c.properties = g, c.data = {
                    swiperCurrent: 1,
                    uiType: n.CAROUSEL,
                    ScopeUiTypeEnum: n
                }, c.canUseTapReqAction = !1, c;
            }
            i.__extends(t, e);
            var r = t.prototype;
            r.attached = function() {
                e.prototype.attached.call(this);
            }, r.ready = function() {
                e.prototype.ready.call(this), this.initData();
            }, r.handleTapBanner = function(e) {
                var t = e.currentTarget.dataset.banner, r = t.actionType, n = t.pageUrl, i = t.actionList, a = void 0 === i ? [] : i;
                if (n) {
                    var o = this.data, s = o.groupId, c = o.groupType;
                    this.canUseTapReqAction && this.processActionList(a);
                    var p = n.indexOf("?") > -1 ? "&" : "?";
                    if (r === u.BannerConfigDTO.ActionTypeEnum.MINI) wx.navigateTo({
                        url: "" + n + p + "groupId=" + s + "&groupType=" + c
                    }); else if (r === u.BannerConfigDTO.ActionTypeEnum.H5) {
                        var l = encodeURIComponent("" + n + p + "groupId=" + s + "&groupType=" + c);
                        this.routeService.goWebViewPage({
                            data: {
                                path: l,
                                groupId: s,
                                groupType: c
                            }
                        });
                    } else r === u.BannerConfigDTO.ActionTypeEnum.IMAGE ? this.fileService.viewImages([ n ], n) : r === u.BannerConfigDTO.ActionTypeEnum.THIRDPARTY && this.goToMiniProgram(n);
                }
            }, r.handleSwiperChange = function(e) {
                var t = e.detail.current;
                this.setData({
                    swiperCurrent: t !== this.data.bannerList.length - 1 ? t + 1 : 0
                });
            }, r.initData = function() {
                var e = this;
                this.setDrayFeature(), this.setBannerStyle(), this.getBannerConfiguration().subscribe(function(t) {
                    var r;
                    if (t.length) {
                        e.triggerEvent("reqBannerList", t);
                        var n = e.monoUtilService.safeJSONParse(null === (r = t[0]) || void 0 === r ? void 0 : r.scopeExtraParams, {});
                        n.readMoreUrl && e.triggerEvent("getReadMoreUrl", {
                            readMoreUrl: n.readMoreUrl
                        }), e.triggerEvent("getBannerList", {
                            bannerList: t
                        }), e.setData({
                            bannerList: t,
                            uiType: n.uiType || e.data.uiType
                        });
                    }
                });
            }, r.setBannerStyle = function() {
                var e = this.data, t = e.bannerHeight, r = e.radius;
                this.setData({
                    bannerImgMode: t ? "scaleToFill" : "widthFix",
                    bannerStyleStr: [ "border-radius:" + r + "rpx", t ? "height:" + t + "rpx" : "" ].join(";")
                });
            }, r.getBannerConfiguration = function() {
                var e = this.data, t = e.groupId, r = e.scopeCode, n = e.customBannerConfig;
                return t && r ? this.apiService.getBannerByScopeHelpSaleSquareUsingGET(t, r, l.skipErrorOptions).pipe(c.map(function(e) {
                    return e.data || [];
                }), c.map(function(e) {
                    return e.map(function(e) {
                        var t = e.actionType, r = e.url, n = e.content;
                        return {
                            id: e.bizCode,
                            imgUrl: n,
                            actionType: t,
                            pageUrl: r,
                            actionList: e.actionList,
                            scopeExtraParams: e.scopeExtraParams
                        };
                    });
                }), c.catchError(function() {
                    return s.of([]);
                })) : s.of(n || []);
            }, r.setDrayFeature = function() {
                var e = this;
                this.grayService.canIUseFeature("2425").subscribe(function(t) {
                    e.canUseTapReqAction = t;
                });
            }, r.processActionList = function(e) {
                var t = this, r = this.data.groupId;
                try {
                    e.forEach(function(e) {
                        var n = e.actionMethod, i = void 0 === n ? "" : n, a = e.actionParams, o = void 0 === a ? "" : a, s = e.actionUrl, c = void 0 === s ? "" : s;
                        if (i && c) {
                            var p = o.replace(/\$\{(.+?)\}/, r || ""), u = t.monoUtilService.safeJSONParse(p);
                            t.httpClient[i.toLowerCase()](c, {
                                body: u
                            }, l.skipErrorOptions).subscribe();
                        }
                    });
                } catch (e) {}
            }, r.goToMiniProgram = function(e) {
                var t, r;
                if (-1 !== e.indexOf("?")) try {
                    var n = i.__read(e.split("?"), 2), a = n[0], o = n[1].split("&"), s = "", c = "";
                    try {
                        for (var p = i.__values(o), u = p.next(); !u.done; u = p.next()) {
                            var l = u.value;
                            /^extraParams/.test(l) ? s = l.split("=")[1] : /^appId/.test(l) && (c = l.split("=")[1]);
                        }
                    } catch (e) {
                        t = {
                            error: e
                        };
                    } finally {
                        try {
                            u && !u.done && (r = p.return) && r.call(p);
                        } finally {
                            if (t) throw t.error;
                        }
                    }
                    var d = a + "?" + decodeURIComponent(s);
                    c === v.currentAppId ? wx.navigateTo({
                        url: d
                    }) : wx.navigateToMiniProgram({
                        appId: c,
                        path: d
                    });
                } catch (e) {}
            }, t = i.__decorate([ o.wxComponent(), i.__metadata("design:paramtypes", [ u.DefaultService, p.RouteService, d.FileService, l.HttpClient, f.GrayFeatureService, y.MonoUtilService ]) ], t);
        }(a.SuperComponent);
    }
}, [ [ 716, 0, 2, 1 ] ] ]));