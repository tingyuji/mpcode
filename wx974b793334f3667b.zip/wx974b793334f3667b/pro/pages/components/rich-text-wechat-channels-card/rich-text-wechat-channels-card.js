var r = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(r) {
    return typeof r;
} : function(r) {
    return r && "function" == typeof Symbol && r.constructor === Symbol && r !== Symbol.prototype ? "symbol" : typeof r;
};

require("./../../../../runtime"), require("./../../../../mono"), require("./../../../../common"), 
function(r, e) {
    for (var o in e) r[o] = e[o];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 143 ], {
    2: function(e, o) {
        var t;
        t = function() {
            return this;
        }();
        try {
            t = t || new Function("return this")();
        } catch (e) {
            "object" == ("undefined" == typeof window ? "undefined" : r(window)) && (t = window);
        }
        e.exports = t;
    },
    680: function(r, e, o) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        });
        var t = o(0), n = o(4), i = o(1), a = o(177), c = o(24), s = {
            feedId: String,
            name: String,
            coverUrl: String,
            disableTap: Boolean
        };
        !function(r) {
            function e(e) {
                var o = r.call(this) || this;
                return o.errorService = e, o.properties = s, o.data = {}, o;
            }
            t.__extends(e, r);
            var o = e.prototype;
            o.attached = function() {
                r.prototype.attached.call(this);
            }, o.ready = function() {
                r.prototype.ready.call(this);
            }, o.handleTapNavToChannelsDetail = function() {
                var r = this;
                this.data.disableTap || (this.data.feedId || this.errorService.throwCommonError({
                    frontErrorCode: 3014,
                    errorMsg: "视频号跳转失败，缺少参数feedId"
                }), wx.openChannelsActivity || (wx.showToast({
                    title: "当前版本较低，请升级客户端后再试",
                    icon: "none"
                }), this.errorService.throwCommonError({
                    frontErrorCode: 3014,
                    errorMsg: "用户版本较低，无法跳转视频号内容"
                })), wx.openChannelsActivity({
                    finderUserName: a.QJL_VIDEO_ROOM_ID,
                    feedId: this.data.feedId,
                    fail: function(e) {
                        r.errorService.customReportError({
                            frontErrorCode: 3014,
                            error: e,
                            errorMsg: "打开视频号视频失败"
                        });
                    }
                }));
            }, e = t.__decorate([ i.wxComponent(), t.__metadata("design:paramtypes", [ c.ErrorService ]) ], e);
        }(n.SuperComponent);
    }
}, [ [ 680, 0, 2, 1 ] ] ]));