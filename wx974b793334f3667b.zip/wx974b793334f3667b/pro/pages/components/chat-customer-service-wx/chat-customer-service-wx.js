var e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
};

require("./../../../../runtime"), require("./../../../../mono"), require("./../../../../common"), 
function(e, o) {
    for (var t in o) e[t] = o[t];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 89 ], {
    2: function(o, t) {
        var n;
        n = function() {
            return this;
        }();
        try {
            n = n || new Function("return this")();
        } catch (o) {
            "object" == ("undefined" == typeof window ? "undefined" : e(window)) && (n = window);
        }
        o.exports = n;
    },
    753: function(e, o, t) {
        Object.defineProperty(o, "__esModule", {
            value: !0
        });
        var n = t(0), r = t(4), i = t(1), u = t(5), a = t(9), c = t(327), p = t(15), s = {
            groupId: String,
            isStaticPos: {
                type: Boolean,
                value: !1
            },
            isCustom: {
                type: Boolean,
                value: !1
            },
            useDefaultAvatar: {
                type: Boolean,
                value: !1
            }
        };
        !function(e) {
            function o(o, t) {
                var n = e.call(this) || this;
                return n.apiService = o, n.commonService = t, n.properties = s, n.data = {}, n.account = "", 
                n;
            }
            n.__extends(o, e), o = n.__decorate([ i.wxComponent(), n.__metadata("design:paramtypes", [ u.DefaultService, p.CommonService ]) ], o);
        }(a.miniMixin(r.SuperComponent, c.ChatCustomerServiceWxMixin));
    }
}, [ [ 753, 0, 2, 1 ] ] ]));