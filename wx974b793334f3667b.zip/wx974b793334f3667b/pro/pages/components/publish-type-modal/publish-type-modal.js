var e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
};

require("./../../../../runtime"), require("./../../../../mono"), require("./../../../../common"), 
function(e, t) {
    for (var i in t) e[i] = t[i];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 135 ], {
    2: function(t, i) {
        var o;
        o = function() {
            return this;
        }();
        try {
            o = o || new Function("return this")();
        } catch (t) {
            "object" == ("undefined" == typeof window ? "undefined" : e(window)) && (o = window);
        }
        t.exports = o;
    },
    746: function(e, t, i) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var o = i(0), a = i(1), r = i(17), n = i(5), s = i(10), c = i(6), u = i(11), p = i(15), h = i(9), l = i(41), y = i(50), d = i(34), S = i(27), m = i(138), v = i(61), g = i(20), f = i(326), T = i(438), b = {
            groupId: {
                type: String,
                observer: function(e, t) {
                    t && this.refreshDataWhenGroupChange();
                }
            },
            groupType: Number,
            logoUrl: String,
            ghName: String,
            seqType: Number,
            isShowModal: {
                type: Boolean,
                value: !1,
                observer: function(e) {
                    e && this.refreshDataWhenGroupChange();
                }
            },
            isShowModalReal: {
                type: Boolean,
                value: !0
            },
            isOverdueLeader: {
                type: Boolean,
                value: !1
            },
            isCustomTapSeq: {
                type: Boolean,
                value: !1
            },
            isShowDynamicPublish: Boolean,
            isRefreshCopyNum: {
                type: Boolean,
                observer: function(e, t) {
                    e !== t && this.getCopySeqNum();
                }
            }
        };
        !function(e) {
            function t(t, i, o, a, r, n, s, c, u, p, h, l) {
                var y = e.call(this) || this;
                return y.apiService = t, y.grayService = i, y.routeService = o, y.monoUtil = a, 
                y.activitySeparateService = r, y.publishTypeModalService = n, y.common = s, y.util = c, 
                y.migrateService = u, y.cloudApiService = p, y.homeFakeSeparateService = h, y.monoCommonService = l, 
                y.properties = b, y.data = {
                    SUPPLY_LEADER_SEQ_NAME: m.SUPPLY_LEADER_SEQ_NAME
                }, y;
            }
            o.__extends(t, e);
            var i = t.prototype;
            i.attached = function() {
                e.prototype.attached.call(this), this.commonOnload(), this.initCommonData(), this.initGrayService(), 
                this.initRedDot();
            }, i.detached = function() {
                e.prototype.detached.call(this), this.cancelListenMigrateCrashDraft();
            }, i.show = function() {
                this.listenMigrateCrashDraft();
            }, i.hide = function() {
                this.cancelListenMigrateCrashDraft();
            }, i.refreshDataWhenGroupChange = function() {
                var e = this.monoCommonService.getGroupType(Number(this.data.groupType));
                this.setData({
                    groupTypeObj: e
                }), this.getSeqTypeList(), this.getCanUseSeqTemplateFeature(), this.getSeqTemplateList(), 
                this.getCopySeqNum(), this.listenMigrateCrashDraft();
            }, i.handleTapCloseSeqList = function(e) {
                this.triggerEvent("close", {
                    isTapClose: !!e && !!e.currentTarget.dataset.isTap
                });
            }, i.handleTapNavPublishDynamic = function() {
                var e = this, t = this.data, i = t.groupId, o = t.groupType;
                this.homeFakeSeparateService.getGhViewType(i, o).subscribe(function(t) {
                    e.routeService.goSeqPublishPublishDynamic({
                        data: {
                            groupId: i,
                            groupType: o,
                            ghViewType: t
                        }
                    });
                });
            }, i.handleOpenDynamicIntro = function() {
                this.common.goToDetail({
                    actId: 0x830a888713723,
                    seqType: 60
                });
            }, i.handleTapNavPublishAssociation = function(e) {
                this.routeService.goHomepageGroupAssociationPublishPage({
                    data: {
                        groupId: this.data.groupId,
                        groupType: this.data.groupType
                    }
                });
            }, i.handleTapNavPublishOldAssociation = function(e) {
                var t = e.currentTarget.dataset.type;
                this.routeService.goSeqPublishPublishExpression({
                    data: {
                        groupId: this.data.groupId,
                        groupType: this.data.groupType,
                        publishType: t
                    }
                });
            }, i.handleTapNavToLotteryIntro = function() {
                this.common.goToDetail({
                    actId: "2305060502657454",
                    seqType: 70
                });
            }, i.initCommonData = function() {
                this.setData({
                    RedDotType: l.RedDotType,
                    GROUP_TYPE_ASSOCIATION: 60
                }), this.getOfficialAccount();
            }, i.initGrayService = function() {
                var e = this;
                this.grayService.canIUseFeature("2377").subscribe(function(t) {
                    e.setData({
                        canUseNewAssociation: t
                    });
                });
            }, t = o.__decorate([ a.wxComponent(), o.__metadata("design:paramtypes", [ n.DefaultService, r.GrayFeatureService, s.RouteService, u.MonoUtilService, v.ActivitySeparateService, f.PublishTypeModalService, p.CommonService, c.UtilService, S.BackendMigrateService, y.WxCloudApiService, d.HomeFakeSeparateService, g.MonoCommonService ]) ], t);
        }(h.miniMixin(T.PublishTypeModalMixin));
    }
}, [ [ 746, 0, 2, 1 ] ] ]));