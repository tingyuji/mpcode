var e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
};

require("./../../../../runtime"), require("./../../../../mono"), require("./../../../../common"), 
function(e, t) {
    for (var o in t) e[o] = t[o];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 132 ], {
    2: function(t, o) {
        var n;
        n = function() {
            return this;
        }();
        try {
            n = n || new Function("return this")();
        } catch (t) {
            "object" == ("undefined" == typeof window ? "undefined" : e(window)) && (n = window);
        }
        t.exports = n;
    },
    789: function(e, t, o) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var n = o(0), i = o(4), r = o(1), a = o(3), s = o(7), l = o(13), u = o(6), c = o(265), d = o(320), g = o(15), p = o(60), S = {
            status: {
                type: String,
                value: "SUCCESS",
                observer: function(e) {
                    this.delayShowLoading(e);
                }
            },
            statusCode: {
                type: Number,
                observer: function(e) {
                    this.setData({
                        isFrontEndError: d.FrontEndBusinessCodeList.includes(e)
                    });
                }
            },
            failMessage: String,
            customFail: Boolean,
            errorTips: String,
            isDataListLoading: Boolean,
            showBackHomeButton: Boolean,
            showJumpProgramButton: Boolean,
            hideNavbar: Boolean,
            backgroundColor: String,
            pageWrapperRequestErrorMsg: String,
            disableGlobalTipRouteConfig: Boolean,
            showGoVerifyIdentityAgreementButton: Boolean,
            isShowGrayPageStyle: Boolean,
            isShowSuperAgreementModal: Boolean
        };
        !function(e) {
            function t(t, o, n, i, r) {
                var a = e.call(this) || this;
                return a.httpClient = t, a.httpErrorService = o, a.commonService = n, a.utils = i, 
                a.imService = r, a.externalClasses = [ "bottom-loading-wrapper", "bottom-loading" ], 
                a.options = {
                    multipleSlots: !0
                }, a.properties = S, a.data = {
                    isSinglePage: a.utils.isFromSinglePage(),
                    isStopScroll: !1,
                    frontEndBusinessCodeList: d.FrontEndBusinessCodeList
                }, a;
            }
            n.__extends(t, e);
            var o = t.prototype;
            o.handleClickRetry = function() {
                this.triggerEvent("retry");
            }, o.handleBackPersonHome = function() {
                this.triggerEvent("backPersonHome");
            }, o.handleClickContinue = function() {
                this.triggerEvent("continue");
            }, o.handleGoVerifyIdentityAgreement = function() {
                this.triggerEvent("goVerifyIdentityAgreement");
            }, o.handleToggleScroll = function(e) {
                this.setData({
                    isStopScroll: e.detail.isStopScroll
                });
            }, o.delayShowLoading = function(e) {
                "LOADING" === e ? this.setDelayLoadingSub() : this.unsubscribeDelayLoading();
            }, o.handleContactService = function() {
                this.imService.goCustomServiceChatPage();
            }, o.handleCloseSuperAgreementModal = function() {
                this.triggerEvent("cancelSuperAgreement");
            }, o.handleConfirmSuperAgreementModal = function() {
                this.triggerEvent("confirmSuperAgreement");
            }, o.setDelayLoadingSub = function() {
                var e = this;
                this.delayLoadingSub$ || (this.delayLoadingSub$ = s.timer(300).pipe(a.takeUntil(this.unloadObservable)).subscribe(function() {
                    e.httpErrorService.isTryToReload || wx.showLoading({
                        title: "加载中"
                    });
                }));
            }, o.unsubscribeDelayLoading = function() {
                wx.hideLoading({}), this.delayLoadingSub$ && (this.delayLoadingSub$.unsubscribe(), 
                delete this.delayLoadingSub$);
            }, t = n.__decorate([ r.wxComponent(), n.__metadata("design:paramtypes", [ l.HttpClient, c.HttpErrorService, g.CommonService, u.UtilService, p.ImService ]) ], t);
        }(i.SuperComponent);
    }
}, [ [ 789, 0, 2, 1 ] ] ]));