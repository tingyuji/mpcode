var e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
};

require("./../../../../runtime"), require("./../../../../mono"), require("./../../../../common"), 
function(e, i) {
    for (var t in i) e[t] = i[t];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 109 ], {
    2: function(i, t) {
        var s;
        s = function() {
            return this;
        }();
        try {
            s = s || new Function("return this")();
        } catch (i) {
            "object" == ("undefined" == typeof window ? "undefined" : e(window)) && (s = window);
        }
        i.exports = s;
    },
    735: function(e, i, t) {
        var s;
        Object.defineProperty(i, "__esModule", {
            value: !0
        });
        var r = t(0), o = t(1), a = t(4), n = t(12), c = t(17), u = t(102), b = t(3), S = t(7), d = t(20), p = t(28), h = t(226), l = t(15), f = t(13), m = t(30), T = t(324), v = t(43), y = t(19), I = ((s = {})[u.Subscription.SUBSCRIPTION] = "退订", 
        s[u.Subscription.UNSUBSCTIPTION] = "订阅", s[u.Subscription.UNSET] = "", s), O = {
            subscribeType: {
                type: Number,
                observer: function(e, i) {
                    var t = this;
                    e !== u.SubscribeType.HOME_2_HOME || this.data.canUseSubscribe || this.setData({
                        canUseSubscribe: !0
                    }), this.data.status !== u.Subscription.UNSET && this.setData({
                        subscribeType: e
                    }, function() {
                        return t.polling();
                    });
                }
            },
            isLeaderToBrand: Boolean,
            subscribeStyleType: Number,
            isUseSlot: Boolean,
            subscribeId: String,
            subordinateId: {
                type: String,
                observer: function(e, i) {
                    !!i && e !== i && this.polling();
                }
            },
            subscriptionStatus: {
                type: Number,
                observer: function(e) {
                    this.setSubscribeInfoByStatus(e);
                }
            },
            subscribeImage: String,
            subscribeName: {
                type: String,
                observer: function(e) {
                    var i = this.monoCommonService.sliceEmojiString(e, 0, 4);
                    this.setData({
                        filterName: i
                    });
                }
            },
            groupBrandName: String,
            isCanShowSubscribeBrandTips: Boolean,
            isRight: Boolean,
            type: {
                type: String,
                observer: function(e) {
                    e && this.updateComponentStatus();
                }
            },
            isUseExternalData: Boolean,
            isSubscribeNotice: {
                type: Boolean,
                value: !0
            },
            officialType: Number,
            isShowUnsubscribe: Boolean,
            isShowGuideToast: {
                type: Boolean,
                value: !0
            },
            isNeedCancelConfirm: Boolean,
            pghId: String,
            canUseSubscribe: Boolean,
            isBubbleBottom: Boolean
        };
        !function(e) {
            function i(i, t, s, r, o, a, n, c, b) {
                var S = e.call(this) || this;
                return S.grayFeatureService = i, S.commonNoticeService = t, S.monoCommonService = s, 
                S.apiService = r, S.commonService = o, S.grayService = a, S.monoRedDotService = n, 
                S.commonSubscribeService = c, S.messageSubService = b, S.properties = O, S.data = {
                    status: u.Subscription.UNSET,
                    statusText: I[u.Subscription.UNSET]
                }, S.productUpdateTemplateId = "", S;
            }
            r.__extends(i, e);
            var t = i.prototype;
            t.ready = function() {
                e.prototype.ready.call(this), this.pageOnShowSubject = new S.Subject();
                var i = "detail" === this.data.type ? "detail" : "belowHeader";
                this.setData({
                    analysisType: i
                }), this.polling();
            }, t.detached = function() {
                e.prototype.detached.call(this);
            }, t.show = function() {
                var e = this.data, i = e.subscribeType, t = e.status;
                i === u.SubscribeType.HOME_2_HOME && t === u.Subscription.SUBSCRIPTION && this.pageOnShowSubject.next();
            }, t.polling = function() {
                var e, i = this, t = this.data, s = t.subscribeStyleType, r = t.subscribeType, o = t.subordinateId, a = t.subscribeId, n = t.isUseSlot;
                return r && (s || n) && ((e = {})[u.SubscribeType.HOME_2_CUSTOMER] = a, e[u.SubscribeType.HOME_2_HOME] = o && a, 
                e[u.SubscribeType.HOME_2_OFFICIAL] = o, e)[r] ? (this.updateComponentStatus(), this.subscribeNotice(), 
                this.getMsgTemplateIds(), void this.initProductUpdateNoticeRedDot()) : void S.timer(300).pipe(b.takeUntil(i.unloadObservable)).subscribe(function() {
                    i.polling();
                });
            }, t.updateComponentStatus = function() {
                this.getGrayFeatureSetting();
            }, t.setSubscribeInfoByStatus = function(e, i) {
                if (void 0 === i && (i = !1), e !== this.data.status) {
                    var t = I[e];
                    i && this.triggerTapSubscribe({
                        isSubscribe: e === u.Subscription.SUBSCRIPTION
                    }), this.setData({
                        status: e,
                        statusText: t
                    });
                }
            }, t.handleTapSubscription = function(e, i) {
                var t, s, r = this, o = e.currentTarget.dataset.subType;
                if (-10 !== o) {
                    var a = void 0 === o ? this.data.status === u.Subscription.UNSUBSCTIPTION ? 20 : 10 : o, c = ((t = {})[u.SubscribeType.HOME_2_CUSTOMER] = function(e) {
                        r.modifySubscriptionWhenHome2Customer(e, i);
                    }, t[u.SubscribeType.HOME_2_HOME] = function(e) {
                        r.modifySubscriptionWhenHome2Home(e, i);
                    }, t[u.SubscribeType.HOME_2_OFFICIAL] = function(e) {
                        r.modifySubscriptionWhenHome2Official(e, i);
                    }, t), b = ((s = {})[u.SubscribeType.HOME_2_CUSTOMER] = "退订主页，你将不能收到我的活动发布通知哦", 
                    s[u.SubscribeType.HOME_2_HOME] = "退订主页，你将不能收到我的最新" + (this.data.isLeaderToBrand ? "开团" : "帮卖") + "活动的通知哦", 
                    s[u.SubscribeType.HOME_2_OFFICIAL] = "是否确定退订", s), S = c[this.data.subscribeType];
                    10 === a && this.data.isNeedCancelConfirm ? n.rxwx.showModal({
                        title: "",
                        content: b[this.data.subscribeType],
                        confirmText: "退订",
                        confirmColor: "#FA5151"
                    }).subscribe(function(e) {
                        if (!e.confirm) return i();
                        S(a);
                    }) : S(a);
                } else this.optSubProductUpdateNotice(i);
            }, t.handleHideSubscribeSucModal = function() {
                this.setData({
                    isShowSubscribeSucModal: !1
                });
            }, t.handleHideSubscribeOfficialSucModal = function() {
                this.setData({
                    isShowSubscribeOfficialSucModal: !1
                });
            }, t.handleCloseDetailSubscribe = function() {
                this.triggerEvent("closeSubscribeEntry");
            }, t.handleTapCloseProductUpdateNoticeGuide = function() {
                this.markProductUpdateNoticeRedDot();
            }, t.handleOnlyForDataReport = function() {}, t.subscribeNotice = function() {
                var e = this;
                this.data.isSubscribeNotice && (this.data.isUseExternalData || this.commonNoticeService.subscriptionNoticeObs.pipe(b.takeUntil(this.unloadObservable)).subscribe(function(i) {
                    var t;
                    e.data.subscribeType === i.type && ((t = {})[u.SubscribeType.HOME_2_CUSTOMER] = e.data.subscribeId === i.subscribeId, 
                    t[u.SubscribeType.HOME_2_HOME] = e.data.subscribeId === i.subscribeId && e.data.subordinateId === i.subordinateId, 
                    t[u.SubscribeType.HOME_2_OFFICIAL] = e.data.subordinateId === i.subordinateId, t)[e.data.subscribeType] && e.setSubscribeInfoByStatus(i.status, !0);
                }));
            }, t.noticeSubscribeChange = function(e) {
                var i = this.data, t = i.subscribeType, s = i.subscribeId, r = i.subordinateId;
                this.commonNoticeService.noticeModifySubscribe({
                    type: t,
                    subscribeId: s,
                    subordinateId: r,
                    status: e
                });
            }, t.getGrayFeatureSetting = function() {
                var e, i = this, t = this.data.subscribeType;
                if (t) {
                    var s = ((e = {})[u.SubscribeType.HOME_2_CUSTOMER] = "2587", e[u.SubscribeType.HOME_2_HOME] = "1027", 
                    e[u.SubscribeType.HOME_2_OFFICIAL] = "1039", e)[t];
                    this.grayFeatureService.canIUseFeature(s).subscribe(function(e) {
                        i.setData({
                            isShowSubscription: e
                        }, function() {
                            i.getSubscriptionStatus(t);
                        });
                    });
                }
            }, t.getSubscriptionStatus = function(e) {
                var i, t = this;
                this.data.isShowSubscription && (this.data.isUseExternalData || (0, ((i = {})[u.SubscribeType.HOME_2_CUSTOMER] = function() {
                    return t.getIsSubscribeWhenHome2Customer();
                }, i[u.SubscribeType.HOME_2_HOME] = function() {
                    return t.getIsSubscribeWhenHome2Home();
                }, i[u.SubscribeType.HOME_2_OFFICIAL] = function() {
                    return t.getIsSubscribeWhenHome2Official();
                }, i)[e])());
            }, t.getIsSubscribeWhenHome2Customer = function() {
                var e = this, i = r.__assign(r.__assign({}, f.skipErrorOptions), {
                    replayOnceTime: 5e3
                });
                this.apiService.isSubscribeGroupIdUsingGET(this.data.subscribeId, i).subscribe(function(i) {
                    e.setSubscribeInfo(i);
                });
            }, t.getIsSubscribeWhenHome2Home = function() {
                var e = this;
                this.data.subscribeId && this.data.subordinateId && (this.data.isCanShowSubscribeBrandTips && this.getBrandSubscribeTips(), 
                this.apiService.isSubscribeBrandIdUsingGET(this.data.subscribeId, this.data.subordinateId, f.skipErrorOptions).subscribe(function(i) {
                    e.setSubscribeInfo(i);
                }));
            }, t.getBrandSubscribeTips = function() {
                var e = this;
                this.apiService.isAlreadyShowTipsUsingGET(this.data.subscribeId, f.skipErrorOptions).subscribe(function(i) {
                    e.setData({
                        isShowSubscribeBrandTips: !i.data
                    });
                });
            }, t.getIsSubscribeWhenHome2Official = function() {
                var e = this;
                this.apiService.isSubBandUsingGET(this.data.subordinateId, f.skipErrorOptions).subscribe(function(i) {
                    e.setSubscribeInfo(i);
                });
            }, t.setSubscribeInfo = function(e) {
                var i = e.data ? u.Subscription.SUBSCRIPTION : u.Subscription.UNSUBSCTIPTION;
                e.data ? this.getSubscribeWxOfficialAccountsFunc().subscribe() : this.triggerTapSubscribe({
                    isSubscribe: !1
                }), this.setSubscribeInfoByStatus(i);
            }, t.modifySubscriptionWhenHome2Customer = function(e, i) {
                var t = this;
                this.apiService.modifyClientSubscribeRsV2UsingGET(this.data.subscribeId, String(e), this.data.pghId, f.skipErrorOptions).subscribe(function(s) {
                    i(), t.setSubscribeStatusCallback(e, s);
                }, function() {
                    i();
                });
            }, t.modifySubscriptionWhenHome2Home = function(e, i) {
                var t = this;
                this.data.subordinateId && this.data.subscribeId && this.apiService.modifyBrandSubscribeRsUsingGET(this.data.subscribeId, this.data.subordinateId, String(e), f.skipErrorOptions).subscribe(function(s) {
                    i(), t.triggerEvent("operate", {
                        isSub: t.data.status === u.Subscription.UNSUBSCTIPTION,
                        targetId: t.data.subscribeId
                    }), t.setSubscribeStatusCallback(e, s);
                }, function() {
                    i();
                });
            }, t.modifySubscriptionWhenHome2Official = function(e, i) {
                var t = this, s = 20 === e ? h.SubBandReq.OptSubEnum.SUB : h.SubBandReq.OptSubEnum.UNSUB;
                this.apiService.subBandUsingPOST({
                    ghId: this.data.subordinateId,
                    optSub: s
                }, f.skipErrorOptions).subscribe(function(s) {
                    i(), t.setSubscribeStatusCallback(e, s);
                }, function() {
                    i();
                });
            }, t.setSubscribeStatusCallback = function(e, i) {
                return 20 === e ? this.subscribeCallback(i) : this.unsubscribeCallback(i);
            }, t.unsubscribeCallback = function(e) {
                e.ok && (this.triggerTapSubscribe({
                    isSubscribe: !1
                }), this.data.isShowGuideToast && !this.data.isNeedCancelConfirm && n.rxwx.showToast({
                    title: "已退订",
                    icon: "none"
                }).subscribe(), this.noticeSubscribeChange(u.Subscription.UNSUBSCTIPTION), this.data.isSubscribeNotice || this.setData({
                    status: u.Subscription.UNSUBSCTIPTION,
                    statusText: I[u.Subscription.UNSUBSCTIPTION]
                }));
            }, t.subscribeCallback = function(e) {
                this.getIsSubscribeWxOfficialAccounts();
            }, t.getIsSubscribeWxOfficialAccounts = function() {
                var e = this, i = {};
                this.data.isSubscribeNotice || (i.status = u.Subscription.SUBSCRIPTION, i.statusText = I[u.Subscription.SUBSCRIPTION]), 
                this.noticeSubscribeChange(u.Subscription.SUBSCRIPTION), this.data.isShowGuideToast && wx.showToast({
                    title: "订阅成功，我发布活动后将第一时间通知你",
                    icon: "none"
                }), this.setData(i, function() {
                    e.triggerEvent("subscribeChange");
                }), this.openWXPromoterWhenB2BCallBack();
            }, t.openWXPromoterWhenB2BCallBack = function() {
                var e = this;
                this.data.subscribeType === u.SubscribeType.HOME_2_HOME && this.monoRedDotService.getRedDot([ {
                    code: 2114
                } ]).subscribe(function(i) {
                    var t;
                    !!(null === (t = i[0]) || void 0 === t ? void 0 : t.result) && e.commonSubscribeService.declOrOpenWXPromoter(function() {
                        e.commonSubscribeService.refreshWXPromoterAuthStatusObs().pipe(b.takeUntil(e.unloadObservable)).subscribe();
                    }, function() {
                        e.monoRedDotService.markReadRedDot([ {
                            code: 2114
                        } ]).subscribe(), e.pageOnShowSubject.asObservable().pipe(b.take(1), b.takeUntil(e.unloadObservable)).subscribe(function() {
                            e.commonSubscribeService.refreshWXPromoterAuthStatusObs().pipe(b.takeUntil(e.unloadObservable)).subscribe();
                        });
                    });
                });
            }, t.getSubscribeWxOfficialAccountsFunc = function() {
                var e = this;
                return this.apiService.isFollowWxMpV2UsingGET("QJL", f.skipErrorCacheOptions).pipe(b.tap(function(i) {
                    e.triggerTapSubscribe({
                        isSubscribe: !0,
                        isFollow: i.data
                    });
                }));
            }, t.triggerTapSubscribe = function(e) {
                this.triggerEvent("tapSubscribe", e);
            }, t.getMsgTemplateIds = function() {
                var e = this;
                this.data.subscribeType === u.SubscribeType.HOME_2_CUSTOMER && this.messageSubService.getTemplateId("ACTIVITY_BUILD").pipe(b.takeUntil(this.unloadObservable)).subscribe(function(i) {
                    e.productUpdateTemplateId = i;
                });
            }, t.optSubProductUpdateNotice = function(e) {
                var i = this;
                this.markProductUpdateNoticeRedDot(), this.setData({
                    isShowSubscribeGuideModal: !0
                }), this.messageSubService.requestSubscribeMessage(this.productUpdateTemplateId).subscribe(function(t) {
                    e(), i.setData({
                        isShowSubscribeGuideModal: !1
                    }), t.data && (wx.showToast({
                        title: "已成功订阅，上新通知+1",
                        icon: "none"
                    }), i.apiService.subscribeActReleaseMinaNoticeUsingPOST(i.data.subscribeId).subscribe());
                }, function() {
                    e();
                });
            }, t.initProductUpdateNoticeRedDot = function() {
                var e = this;
                this.data.subscribeType === u.SubscribeType.HOME_2_CUSTOMER && this.monoRedDotService.getRedDot([ {
                    code: 2117
                } ]).subscribe(function(i) {
                    var t;
                    e.setData({
                        isShowProductUpdateNoticeGuide: !!(null === (t = i[0]) || void 0 === t ? void 0 : t.result)
                    });
                });
            }, t.markProductUpdateNoticeRedDot = function() {
                this.data.isShowProductUpdateNoticeGuide && (this.setData({
                    isShowProductUpdateNoticeGuide: !1
                }), this.monoRedDotService.markReadRedDot([ {
                    code: 2117
                } ]).subscribe());
            }, r.__decorate([ y.Lock(), r.__metadata("design:type", Function), r.__metadata("design:paramtypes", [ Object, Function ]), r.__metadata("design:returntype", void 0) ], i.prototype, "handleTapSubscription", null), 
            i = r.__decorate([ o.wxComponent(), r.__metadata("design:paramtypes", [ c.GrayFeatureService, u.CommonNoticeService, d.MonoCommonService, p.DefaultService, l.CommonService, c.GrayFeatureService, m.MonoRedDotService, T.CommonSubscribeService, v.MessageSubscribeService ]) ], i);
        }(a.SuperComponent);
    }
}, [ [ 735, 0, 2, 1 ] ] ]));