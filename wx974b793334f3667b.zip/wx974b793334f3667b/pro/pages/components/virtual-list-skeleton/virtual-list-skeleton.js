var t = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
    return typeof t;
} : function(t) {
    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
};

require("./../../../../runtime"), require("./../../../../mono"), require("./../../../../common"), 
function(t, o) {
    for (var e in o) t[e] = o[e];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 159 ], {
    2: function(o, e) {
        var n;
        n = function() {
            return this;
        }();
        try {
            n = n || new Function("return this")();
        } catch (o) {
            "object" == ("undefined" == typeof window ? "undefined" : t(window)) && (n = window);
        }
        o.exports = n;
    },
    722: function(t, o, e) {
        Object.defineProperty(o, "__esModule", {
            value: !0
        });
        var n = e(0), r = e(4), i = e(1), u = {
            loadingText: {
                type: String,
                value: "加载中..."
            }
        };
        !function(t) {
            function o() {
                var o = t.call(this) || this;
                return o.options = {
                    virtualHost: !0
                }, o.properties = u, o.data = {}, o;
            }
            n.__extends(o, t), o = n.__decorate([ i.wxComponent(), n.__metadata("design:paramtypes", []) ], o);
        }(r.SuperComponent);
    }
}, [ [ 722, 0, 2, 1 ] ] ]));