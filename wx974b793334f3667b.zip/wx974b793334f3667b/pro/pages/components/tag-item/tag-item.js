var e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
};

require("./../../../../runtime"), require("./../../../../mono"), require("./../../../../common"), 
function(e, t) {
    for (var s in t) e[s] = t[s];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 153 ], {
    2: function(t, s) {
        var a;
        a = function() {
            return this;
        }();
        try {
            a = a || new Function("return this")();
        } catch (t) {
            "object" == ("undefined" == typeof window ? "undefined" : e(window)) && (a = window);
        }
        t.exports = a;
    },
    734: function(e, t, s) {
        var a, p, o, r;
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var n = s(0), i = s(4), g = s(1), u = {
            tagColor: {
                type: String,
                value: ""
            },
            isBorder: {
                type: Boolean,
                value: !0
            },
            isBold: {
                type: Boolean,
                value: !0
            },
            tagSize: {
                type: String,
                value: ""
            },
            tag: {
                type: Object,
                observer: function(e, t) {
                    this.getTagType(e);
                }
            }
        }, l = "/ss/app/image/plus/data07.svg", v = ((a = {})[3] = "/ss/app/image/plus/star05.svg", 
        a[2] = "/ss/app/image/plus/star05.svg", a[6] = "/ss/app/image/plus/prove07.svg", 
        a[4] = l, a[5] = l, a[9] = l, a[7] = "/ss/app/image/plus/zan12.svg", a[8] = "/ss/app/image/plus/star15.svg", 
        a), c = ((p = {})[3] = "/ss/app/image/plus/star35.svg", p[2] = "/ss/app/image/plus/star35.svg", 
        p[6] = "/ss/app/image/plus/prove05.svg", p[4] = "/ss/app/image/plus/rank04.svg", 
        p[5] = "/ss/app/image/plus/person33.svg", p[9] = "/ss/app/image/plus/person33.svg", 
        p[7] = "/ss/app/image/plus/zan23.svg", p[8] = "/ss/app/image/plus/prove18.svg", 
        p), m = ((o = {})[""] = c, o.white = c, o.green = v, o), y = ((r = {})[3] = "star-bg", 
        r[2] = "star-bg", r[4] = "rank-bg", r[5] = "person-bg", r[9] = "person-bg", r[7] = "goods-bg", 
        r[8] = "prove-bg", r);
        !function(e) {
            function t() {
                var t = e.call(this) || this;
                return t.properties = u, t.data = {
                    colorfulBgMap: y
                }, t;
            }
            n.__extends(t, e);
            var s = t.prototype;
            s.ready = function() {
                e.prototype.ready.call(this), this.data.tag && this.getTagType(this.data.tag);
            }, s.getTagType = function(e) {
                var t, s = this.data.tagColor, a = e.type, p = void 0 === a ? "" : a, o = e.iconGreen, r = void 0 === o ? "" : o, n = e.iconWhite, i = void 0 === n ? "" : n, g = "";
                (g = p ? m[s][p] : ((t = {})[""] = i, t.white = r, t.green = r, t)[s] || "") && this.setData({
                    iconImg: g
                });
            }, t = n.__decorate([ g.wxComponent(), n.__metadata("design:paramtypes", []) ], t);
        }(i.SuperComponent);
    }
}, [ [ 734, 0, 2, 1 ] ] ]));