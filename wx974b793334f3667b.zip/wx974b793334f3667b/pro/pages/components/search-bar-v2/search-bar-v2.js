var e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
};

require("./../../../../runtime"), require("./../../../../mono"), require("./../../../../common"), 
function(e, t) {
    for (var n in t) e[n] = t[n];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 144 ], {
    2: function(t, n) {
        var a;
        a = function() {
            return this;
        }();
        try {
            a = a || new Function("return this")();
        } catch (t) {
            "object" == ("undefined" == typeof window ? "undefined" : e(window)) && (a = window);
        }
        t.exports = a;
    },
    765: function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var a = n(0), i = n(4), o = n(1), r = n(31), s = n(16), d = {
            isExpand: {
                type: Boolean
            },
            foldPlaceHolder: {
                type: String,
                value: "搜索"
            },
            expandPlaceholder: {
                type: String,
                value: "搜索"
            },
            focus: {
                type: Boolean,
                value: !0
            },
            isGrey: {
                type: Boolean,
                value: !1
            },
            foldGrey: {
                type: Boolean,
                value: !1
            },
            disabled: Boolean,
            searchKeyword: {
                type: String,
                observer: function(e, t) {
                    e && (this.setData({
                        isExpand: !0,
                        searchKeyword: e,
                        animateFinish: !0
                    }), this.triggerEvent("expand", {
                        isExpand: !0
                    }));
                }
            }
        };
        !function(e) {
            function t() {
                var t = e.call(this) || this;
                return t.animateFinishTimer = null, t.properties = d, t.data = {}, t;
            }
            a.__extends(t, e);
            var n = t.prototype;
            n.ready = function() {
                e.prototype.ready.call(this);
            }, n.clearInputValue = function() {
                this.setData({
                    searchKeyword: ""
                });
            }, n.processCancel = function() {
                this.data.searchKeyword || (this.expendToggle(!1), this.handleSearch());
            }, n.getFocus = function() {
                this.data.isExpand || this.data.focus || this.setData({
                    focus: !0
                }), this.expendToggle(!0);
            }, n.handleInputBlur = function() {}, n.handleInputSearchKeyword = function(e) {
                this.triggerEvent("input", {
                    value: e.detail.value
                });
            }, n.handleConfirmSearch = function(e) {
                this.triggerEvent("search", {
                    value: e.detail.value
                });
            }, n.handleSearch = function() {
                this.triggerEvent("search", {
                    value: this.data.searchKeyword,
                    isExpand: this.data.isExpand
                });
            }, n.handleTapCancelSearch = function() {
                var e = this;
                this.setData({
                    searchKeyword: void 0,
                    isExpand: !1
                }, function() {
                    e.processCancel();
                });
            }, n.expendToggle = function(e) {
                var t = this;
                this.animateFinishTimer && clearTimeout(this.animateFinishTimer), this.animateFinishTimer = setTimeout(function() {
                    return t.setData({
                        animateFinish: e
                    });
                }, 200), this.setData({
                    isExpand: e
                }), this.triggerEvent("expand", {
                    isExpand: e
                });
            }, a.__decorate([ s.Toggle("focus", !1), a.__metadata("design:type", Function), a.__metadata("design:paramtypes", []), a.__metadata("design:returntype", void 0) ], t.prototype, "handleInputBlur", null), 
            a.__decorate([ r.DataBind("searchKeyword"), a.__metadata("design:type", Function), a.__metadata("design:paramtypes", [ Object ]), a.__metadata("design:returntype", void 0) ], t.prototype, "handleInputSearchKeyword", null), 
            t = a.__decorate([ o.wxComponent(), a.__metadata("design:paramtypes", []) ], t);
        }(i.SuperComponent);
    }
}, [ [ 765, 0, 2, 1 ] ] ]));