var t = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
    return typeof t;
} : function(t) {
    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
};

require("./../../../../runtime"), require("./../../../../mono"), require("./../../../../common"), 
function(t, e) {
    for (var i in e) t[i] = e[i];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 160 ], {
    2: function(e, i) {
        var s;
        s = function() {
            return this;
        }();
        try {
            s = s || new Function("return this")();
        } catch (e) {
            "object" == ("undefined" == typeof window ? "undefined" : t(window)) && (s = window);
        }
        e.exports = s;
    },
    723: function(t, e, i) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        });
        var s = i(0), n = i(4), r = i(1), o = {
            list: {
                type: Array,
                value: [],
                observer: function(t, e) {
                    (null == t ? void 0 : t.length) && this.observeVirtualList();
                }
            }
        };
        !function(t) {
            function e() {
                var e = t.call(this) || this;
                return e.options = {
                    multipleSlots: !0
                }, e.properties = o, e.data = {
                    virtualListItemClass: "v_list-item_wrapper"
                }, e.virtualListIntersectionObserverInstance = null, e.toBeUpdateBusinessItemMap = {}, 
                e.updateBusinessItemTimer = null, e;
            }
            s.__extends(e, t);
            var i = e.prototype;
            i.show = function() {
                this.observeVirtualList();
            }, i.hide = function() {
                this.disconnectVirtualListObserver();
            }, i.detached = function() {
                this.disconnectVirtualListObserver();
            }, i.observeVirtualList = function() {
                var t = this;
                this.virtualListIntersectionObserverInstance && this.virtualListIntersectionObserverInstance.disconnect(), 
                this.virtualListIntersectionObserverInstance = this.createIntersectionObserver({
                    observeAll: !0,
                    initialRatio: 0
                }), this.virtualListIntersectionObserverInstance.relativeToViewport({
                    top: 1600,
                    bottom: 1600
                }).observe(".v_list-item_wrapper", function(e) {
                    var i = e || {}, s = i.dataset, n = void 0 === s ? {} : s, r = i.intersectionRatio, o = i.boundingClientRect, a = n.virtualItemIndex;
                    "number" == typeof a && t.diffVirtualHeightAndInvokeUpdate(a, o.height, r > 0);
                });
            }, i.disconnectVirtualListObserver = function() {
                var t;
                null === (t = this.virtualListIntersectionObserverInstance) || void 0 === t || t.disconnect();
            }, i.diffVirtualHeightAndInvokeUpdate = function(t, e, i) {
                var n = this, r = this.data.list;
                if (Array.isArray(r)) {
                    var o = r[t];
                    if (o) {
                        var a = this.toBeUpdateBusinessItemMap[t] || o.vState$$;
                        a || (a = {}), (a = s.__assign({}, a)).virtualHeight = e, a.virtualState = Number(i), 
                        this.toBeUpdateBusinessItemMap[t] = a, this.updateBusinessItemTimer || (this.flushToBeUpdateBusinessItemQueue(), 
                        this.updateBusinessItemTimer = setTimeout(function() {
                            n.flushToBeUpdateBusinessItemQueue(), n.updateBusinessItemTimer = null;
                        }, 200));
                    }
                }
            }, i.flushToBeUpdateBusinessItemQueue = function() {
                var t = this.toBeUpdateBusinessItemMap;
                if (Object.keys(t).length) {
                    var e = {}, i = this.data.list;
                    Object.keys(t).forEach(function(s) {
                        i[s] && (e["list[" + s + "].vState$$"] = t[s]);
                    }), this.setData(e), this.toBeUpdateBusinessItemMap = {};
                }
            }, e = s.__decorate([ r.wxComponent(), s.__metadata("design:paramtypes", []) ], e);
        }(n.SuperComponent);
    }
}, [ [ 723, 0, 2, 1 ] ] ]));