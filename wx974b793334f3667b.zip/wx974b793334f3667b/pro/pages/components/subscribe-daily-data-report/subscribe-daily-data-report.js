var t = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
    return typeof t;
} : function(t) {
    return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
};

require("./../../../../runtime"), require("./../../../../mono"), require("./../../../../common"), 
function(t, e) {
    for (var a in e) t[a] = e[a];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 151 ], {
    2: function(e, a) {
        var n;
        n = function() {
            return this;
        }();
        try {
            n = n || new Function("return this")();
        } catch (e) {
            "object" == ("undefined" == typeof window ? "undefined" : t(window)) && (n = window);
        }
        e.exports = n;
    },
    730: function(t, e, a) {
        Object.defineProperty(e, "__esModule", {
            value: !0
        });
        var n = a(0), o = a(4), i = a(1), r = a(3), s = a(7), c = a(28), u = a(13), p = a(15), h = {
            ok: Boolean,
            test: {
                type: Number
            },
            groupId: {
                type: String
            },
            groupType: {
                type: Number
            },
            entranceType: {
                type: Number,
                value: 0
            },
            fontClass: {
                type: String,
                value: "heavy-font"
            },
            isInHomePage: {
                type: Boolean,
                value: !1
            },
            boxShape: {
                type: String
            }
        };
        !function(t) {
            function e(e, a) {
                var n = t.call(this) || this;
                return n.apiService = e, n.commonService = a, n.properties = h, n.data = {
                    grayFeatureCode: "1022"
                }, n;
            }
            n.__extends(e, t);
            var a = e.prototype;
            a.ready = function() {
                t.prototype.ready.call(this), this.initSwitches();
            }, a.handleCancelEntrance = function() {
                var t = this;
                this.apiService.closeShowEntranceUsingGET(this.data.groupId, u.skipErrorOptions).subscribe(function() {
                    t.setData({
                        canShowEntrance: !1
                    });
                });
            }, a.handleToggleSwitch = function(t) {
                var e, a = this, n = t.currentTarget.dataset.type, o = t.detail.value;
                this.setData(((e = {})[n] = o, e), function() {
                    a.checkIsModalType() || a.updateSwitchStatusToServer();
                });
            }, a.handleShowModal = function() {
                this.setData({
                    isShowSwitchModal: !0
                });
            }, a.handleCloseSwitchModal = function() {
                this.setData({
                    isShowSwitchModal: !1
                });
            }, a.handleTapSubscribeBtn = function() {
                this.data.opDataPush && (this.updateSwitchStatusToServer(), this.setData({
                    canShowEntrance: !1,
                    isShowSwitchModal: !1
                }));
            }, a.updateSwitchStatusToServer = function() {
                var t = this, e = {
                    opDataPush: this.transformSwitchStatusToParams(this.data.opDataPush),
                    groupId: this.data.groupId
                };
                this.updateSubscriptionStatus(e).subscribe(function(e) {
                    e && t.checkIsModalType() && wx.showToast({
                        title: "已订阅"
                    }), e || t.checkIsAllOff() || t.commonService.followWeChatOfficialAccounts();
                });
            }, a.transformSwitchStatusToParams = function(t) {
                return t ? 20 : 10;
            }, a.transformConfigToSwitchStatus = function(t) {
                return 20 === t;
            }, a.checkIsModalType = function() {
                return 0 === this.data.entranceType;
            }, a.checkIsAllOff = function() {
                return !this.data.opDataPush;
            }, a.initSwitches = function() {
                var t = this, e = this.data.groupId;
                this.checkCanShowEntrance(e).pipe(r.filter(function(t) {
                    return t;
                }), r.switchMap(function() {
                    return t.apiService.queryDailyPushConfigUsingGET(e, u.skipErrorOptions);
                })).subscribe(function(e) {
                    if (t.setData({
                        canShowEntrance: !0
                    }), e.data) if (0 === e.data.hourOrderPush && t.checkIsModalType()) t.setData({
                        hourOrderPush: !0,
                        opDataPush: !0
                    }); else {
                        var a = e.data.opDataPush;
                        t.setData({
                            opDataPush: t.transformConfigToSwitchStatus(a)
                        });
                    }
                });
            }, a.updateSubscriptionStatus = function(t) {
                return this.apiService.setDailyPushConfigUsingPOST(t, u.skipErrorOptions).pipe(r.map(function(t) {
                    return !!t.data && 20 === t.data.followWxMp;
                }));
            }, a.checkCanShowEntrance = function(t) {
                return t ? this.checkIsModalType() ? this.apiService.isShowEntranceByGroupIdUsingGET(t, u.skipErrorOptions).pipe(r.map(function(t) {
                    return t.data || !1;
                })) : s.of(!0) : s.of(!1);
            }, e = n.__decorate([ i.wxComponent(), n.__metadata("design:paramtypes", [ c.DefaultService, p.CommonService ]) ], e);
        }(o.SuperComponent);
    }
}, [ [ 730, 0, 2, 1 ] ] ]));