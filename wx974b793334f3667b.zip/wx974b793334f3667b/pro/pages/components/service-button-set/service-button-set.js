var e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
};

require("./../../../../runtime"), require("./../../../../mono"), require("./../../../../common"), 
function(e, t) {
    for (var n in t) e[n] = t[n];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 148 ], {
    2: function(t, n) {
        var o;
        o = function() {
            return this;
        }();
        try {
            o = o || new Function("return this")();
        } catch (t) {
            "object" == ("undefined" == typeof window ? "undefined" : e(window)) && (o = window);
        }
        t.exports = o;
    },
    785: function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var o = n(0), r = n(4), i = n(1), a = {
            openType: String
        };
        !function(e) {
            function t() {
                var t = e.call(this) || this;
                return t.properties = a, t.data = {}, t;
            }
            o.__extends(t, e), t.prototype.ready = function() {
                e.prototype.ready.call(this);
                var t = wx.getStorageSync("person_head_image"), n = wx.getStorageSync("person_nick_name");
                this.setData({
                    avatar: t,
                    nickname: n
                });
            }, t = o.__decorate([ i.wxComponent(), o.__metadata("design:paramtypes", []) ], t);
        }(r.SuperComponent);
    }
}, [ [ 785, 0, 2, 1 ] ] ]));