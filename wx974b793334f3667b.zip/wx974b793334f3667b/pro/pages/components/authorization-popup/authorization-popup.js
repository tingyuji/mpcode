var e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
};

require("./../../../../runtime"), require("./../../../../mono"), require("./../../../../common"), 
function(e, t) {
    for (var o in t) e[o] = t[o];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 87 ], {
    2: function(t, o) {
        var i;
        i = function() {
            return this;
        }();
        try {
            i = i || new Function("return this")();
        } catch (t) {
            "object" == ("undefined" == typeof window ? "undefined" : e(window)) && (i = window);
        }
        t.exports = i;
    },
    721: function(e, t, o) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var i = o(0), r = o(4), n = o(1), a = o(15), u = o(6), s = o(17), c = o(9), d = o(323), h = o(24), l = o(158), p = o(12), f = o(19), v = {
            showPopup: Boolean,
            showNotLogin: {
                type: Boolean,
                value: !0
            }
        };
        !function(e) {
            function t(t, o, i, r, n) {
                var a = e.call(this) || this;
                return a.loginService = t, a.commonService = o, a.utils = i, a.grayService = r, 
                a.errorService = n, a.properties = v, a.data = {}, a;
            }
            i.__extends(t, e);
            var o = t.prototype;
            o.ready = function() {
                e.prototype.ready.call(this), this.getUseGetWxAvatarAndNicknameMethod();
            }, o.handleFormLogin = function(e, t) {
                var o = this.selectComponent("#loginForm").getUserNicknameAndAvatar(), i = o.userNickname, r = o.userAvatar;
                if (!i) return this.utils.getPage().setErrorTips("昵称不能为空"), t();
                var n = {
                    avatarUrl: r,
                    nickName: i,
                    language: "zh_CN",
                    city: "",
                    country: "",
                    province: "",
                    gender: 0
                };
                this.wxAuthorized({
                    userInfo: n
                }, !1);
            }, o.handleAuthorizeUserInfo = function(e) {
                var t = this, o = e.detail;
                this.loginService.wxAuthorized(o, !0).subscribe(function(e) {
                    t.wxAuthorizedSuccessCallBack(e);
                });
            }, o.handleTapGetUserProfile = function(e) {
                var t = this;
                this.useUserProfile(e).subscribe(function(e) {
                    t.wxAuthorized(e, !1);
                }, function(e) {
                    t.processProfileError(e, "002");
                });
            }, o.handleHideAuthorizePopup = function(e) {
                this.triggerEvent("hideModal");
            }, o.handleNicknameKeyboardHeightChange = function(e) {
                var t = e.detail.height > 0;
                t !== this.data.isKeyboardShow && this.setData({
                    isKeyboardShow: t
                });
            }, o.wxAuthorized = function(e, t) {
                var o = this;
                void 0 === t && (t = !1), this.loginService.wxAuthorized(e, t).subscribe(function(e) {
                    o.wxAuthorizedSuccessCallBack(e);
                });
            }, o.wxAuthorizedSuccessCallBack = function(e) {
                var t, o = this, i = (null === (t = e.data) || void 0 === t ? void 0 : t.authorization) || 0;
                p.rxwx.showToast({
                    title: "登录成功",
                    mask: !0,
                    duration: 800
                }).subscribe(function() {
                    o.utils.getApp().setStorage("authorization", i), o.triggerEvent("authorizeSuccess");
                });
            }, i.__decorate([ f.Lock(500), i.__metadata("design:type", Function), i.__metadata("design:paramtypes", [ Object, Function ]), i.__metadata("design:returntype", void 0) ], t.prototype, "handleFormLogin", null), 
            t = i.__decorate([ n.wxComponent(), i.__metadata("design:paramtypes", [ l.LoginService, a.CommonService, u.UtilService, s.GrayFeatureService, h.ErrorService ]) ], t);
        }(c.miniMixin(r.SuperComponent, d.LoginMixin));
    }
}, [ [ 721, 0, 2, 1 ] ] ]));