var e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
};

require("./runtime"), require("./mono"), require("./common"), function(e, t) {
    for (var r in t) e[r] = t[r];
}(exports, (wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 19 ], {
    2: function(t, r) {
        var i;
        i = function() {
            return this;
        }();
        try {
            i = i || new Function("return this")();
        } catch (t) {
            "object" == ("undefined" == typeof window ? "undefined" : e(window)) && (i = window);
        }
        t.exports = i;
    },
    448: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.CloudCacheService = void 0;
        var i = r(0), n = r(1), o = r(6), a = r(12), s = r(24), c = r(157), u = r(83), p = r(5), l = r(14), d = r(3), h = r(7), g = r(17), v = r(449), f = r(41), m = [ "getPageSeparateMarqueeText", "getTempMiniAppid", "getAgreementConfig", "setModelInfoByQJLV2", "getRedDotListV2", "batchMarkReadRedDotV2", "getPublishSeqMenu", "appsCanIUse" ], S = function() {
            function e(e, t, r, i, n) {
                this.utilService = e, this.errorService = t, this.apiService = r, this.grayService = i, 
                this.cloudMigrateService = n, this.paramsMap = {}, this.cacheMap = {}, this.latestUpdateTimes = {};
            }
            var t = e.prototype;
            return t.getQJLConfig = function() {
                this.getCloudUpdateTime().subscribe(), this.getRedDotConfig();
            }, t.getRedDotConfig = function() {
                var e = this;
                this.cloudMigrateService.getConfigFromBackServer("getRedDotConfigVersion").subscribe(function(t) {
                    e.utilService.setLocalStorage(f.RED_DOT_CONFIG_VERSION, t);
                });
            }, t.getCloudUpdateTime = function() {
                var e = this;
                if (this.latestUpdateTimes && Object.keys(this.latestUpdateTimes).length) return h.of(this.latestUpdateTimes);
                if (this.updateTimeSubject) return this.updateTimeSubject.asObservable();
                this.updateTimeSubject = new h.ReplaySubject();
                var t = this.updateTimeSubject.asObservable();
                return this.grayService.canIUseFeature("2437").pipe(d.switchMap(function(t) {
                    return t ? e.getCloudLatestUpdateTimesV2() : e.getCloudLatestUpdateTimes();
                })).subscribe(function(t) {
                    e.latestUpdateTimes = t, e.processUpdateTimes(t), e.updateTimeSubject.next(t), e.updateTimeSubject.complete(), 
                    e.updateTimeSubject = void 0;
                }, function(t) {
                    e.updateTimeSubject.next({}), e.updateTimeSubject.complete(), e.updateTimeSubject = void 0;
                }), t;
            }, t.getCloudLatestUpdateTimesV2 = function() {
                var e = this;
                return this.apiService.frontConfigByCodesUsingPOST({
                    codes: [ "getLatestUpdateTimes" ]
                }, l.skipMarkOption).pipe(d.map(function(t) {
                    var r, i = (null === (r = null == t ? void 0 : t.data) || void 0 === r ? void 0 : r.getLatestUpdateTimes) || "{}";
                    try {
                        return JSON.parse(i);
                    } catch (t) {
                        return e.errorService.customReportWxCloudRequest({
                            msg: "错误的latestUpdateTimes格式",
                            code: 1005
                        }, "getCloudLatestUpdateTimesV2", {}), {};
                    }
                }), d.catchError(function(t) {
                    return e.errorService.customReportWxCloudRequest({
                        msg: t.errMsg,
                        error: t,
                        code: t.code || 1004
                    }, "getCloudLatestUpdateTimesV2", {}), h.throwError(t);
                }));
            }, t.getCloudLatestUpdateTimes = function() {
                var e = this;
                return h.Observable.create(function(t) {
                    try {
                        c.myCloud.callFunction({
                            name: "getLatestUpdateTimes",
                            success: function(e) {
                                var r, i = (null === (r = e.result) || void 0 === r ? void 0 : r.data) || {};
                                t.next(i), t.complete();
                            },
                            fail: function(r) {
                                e.errorService.customReportWxCloudRequest({
                                    msg: r.errMsg,
                                    error: r,
                                    code: r.code || -1
                                }, "getCloudLatestUpdateTimes", {}), t.error(r);
                            }
                        });
                    } catch (e) {
                        t.error(e);
                    }
                });
            }, t.checkFuncNameInBlackList = function(e) {
                void 0 === e && (e = "");
                var t = e.split(":")[1] || "";
                return m.indexOf(t) >= 0;
            }, t.getValidCache = function(e, t, r) {
                var i, n, o = this.getStorageKey(e, t);
                if (o) {
                    var a = this.cacheMap[o] || this.utilService.getLocalStorage(o);
                    if (a) {
                        var s = new Date().getTime(), c = a.timeStamp, u = a.cloudUpdateTime;
                        if (u) {
                            var p = null === (i = this.latestUpdateTimes) || void 0 === i ? void 0 : i[e];
                            if (p && p === u) {
                                var l = null === (n = r.useStorageOptions) || void 0 === n ? void 0 : n.expireMilliseconds;
                                return void 0 !== l && c + l > s && (a = void 0), this.cacheMap[o] || (this.cacheMap[o] = a), 
                                a;
                            }
                        }
                    }
                }
            }, t.getCloudFuncLastUpdateTime = function(e) {
                return this.latestUpdateTimes && this.latestUpdateTimes[e] || +new Date(new Date().setHours(0, 0, 0, 0));
            }, t.setCache = function(e, t, r, i) {
                var n = r.result;
                if (n && 200 === n.code && this.latestUpdateTimes[e]) {
                    var o = {
                        funcName: e,
                        params: t,
                        data: n.data,
                        cloudUpdateTime: this.latestUpdateTimes[e],
                        timeStamp: new Date().getTime(),
                        expireMilliseconds: i.expireMilliseconds
                    }, a = this.getStorageKey(e, t);
                    a && (this.cacheMap[a] = o, this.utilService.setLocalStorage(a, o));
                }
            }, t.getStorageKey = function(e, t) {
                try {
                    return "cloud:" + e + ":" + (t ? this.utilService.md5(JSON.stringify(t)) : u.currentAppId);
                } catch (e) {
                    return "";
                }
            }, t.checkNeedRefresh = function(e, t) {
                var r = t[e.funcName], i = e.cloudUpdateTime, n = e.expireMilliseconds, o = e.timeStamp, a = new Date().getTime();
                return i !== r || void 0 !== n && o + n > a;
            }, t.checkNeedRemove = function(e, t) {
                return !t[e.funcName];
            }, t.removeCache = function(e) {
                this.utilService.removeStorage(e);
            }, t.refreshCache = function(e) {
                var t = this, r = e.funcName, i = e.params, n = e.expireMilliseconds;
                this.cloudMigrateService.judgeRequestServer(r, i).subscribe(function(e) {
                    t.setCache(r, i, e, {
                        expireMilliseconds: n
                    });
                }, function(e) {
                    t.errorService.customReportWxCloudRequest({
                        msg: e.errMsg,
                        error: e,
                        code: e.code || -1
                    }, "refreshCache" + r, i);
                });
            }, t.processUpdateTimes = function(e) {
                var t = this;
                a.rxwx.getStorageInfo({}).subscribe(function(r) {
                    r.keys.forEach(function(r) {
                        if (r.startsWith("cloud:") && !t.checkFuncNameInBlackList(r)) {
                            var i = t.utilService.getLocalStorage(r);
                            if (t.checkNeedRemove(i, e)) return t.removeCache(r);
                            t.checkNeedRefresh(i, e) && (t.removeCache(r), t.refreshCache(i));
                        }
                    });
                });
            }, e = i.__decorate([ n.Injectable(), i.__metadata("design:paramtypes", [ o.UtilService, s.ErrorService, p.DefaultService, g.GrayFeatureService, v.CloudFunctionMigrateService ]) ], e);
        }();
        t.CloudCacheService = S;
    },
    449: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.CloudFunctionMigrateService = t.configCloudFuncNameList = void 0;
        var i = r(0), n = r(1), o = r(14), a = r(5), s = r(7), c = r(3), u = r(157), p = r(17);
        t.configCloudFuncNameList = [ "getPublishSeqMenu", "getBannerActInfo", "getFakeSeparateMarqueeText", "getPageSeparateMarqueeText", "getTempMiniAppid", "getAdvertisementList" ];
        var l = function() {
            function e(e, t) {
                this.apiService = e, this.grayService = t, this.redDotSubjectList = [], this.redDotParamsList = [];
            }
            var r = e.prototype;
            return r.getConfigFromBackServer = function(e) {
                return this.apiService.frontConfigByCodesUsingPOST({
                    codes: [ e ]
                }, o.skipMarkOption).pipe(c.map(function(t) {
                    var r, i = null === (r = t.data) || void 0 === r ? void 0 : r[e];
                    if (!i) throw new Error("未获取到函数" + e + "配置，请先到运营后台进行配置");
                    return JSON.parse(i);
                }));
            }, r.judgeRequestServer = function(e, r) {
                var i = this;
                return -1 === t.configCloudFuncNameList.indexOf(e) ? "getRedDotListV2" === e ? this.cloudRedDotRequest(r) : this.cloudRequest(e, r) : this.grayService.canIUseFeature("2428").pipe(c.switchMap(function(t) {
                    return t ? i.callFuncByName(e, r) : i.cloudRequest(e, r);
                }));
            }, r.callFuncByName = function(e, t) {
                var r = this, i = this[e];
                if (!i) throw new Error("CloudFunctionMigrateService中未找到" + e + "对应函数");
                var n = e;
                return this.getConfigFromBackServer(n).pipe(c.switchMap(function(e) {
                    return i.call(r, t, e);
                }));
            }, r.cloudRequest = function(e, t) {
                return s.Observable.create(function(r) {
                    u.myCloud.callFunction({
                        name: e,
                        data: t,
                        success: function(e) {
                            r.next(e), r.complete();
                        },
                        fail: function(e) {
                            r.error(e), r.complete();
                        }
                    });
                });
            }, r.cloudRedDotRequest = function(e) {
                var t = this, r = new Date().getTime(), n = new s.Subject();
                this.lastTime && r - this.lastTime < 1e3 && this.timer && clearTimeout(this.timer);
                var o = e.redDotQueryParamList;
                return this.lastTime = r, this.redDotParamsList.push(o), this.redDotSubjectList.push({
                    params: o,
                    subject: n
                }), this.timer = setTimeout(function() {
                    var e = t.redDotParamsList.reduce(function(e, t) {
                        return e.concat(t);
                    }, []), r = t.redDotSubjectList;
                    t.lastTime = void 0, t.redDotParamsList = [], t.redDotSubjectList = [], t.cloudRequest("getRedDotListV2", {
                        redDotQueryParamList: e
                    }).subscribe(function(e) {
                        var t = e.result;
                        r.forEach(function(r) {
                            var n = t.data || [], o = r.params.map(function(e) {
                                return n.find(function(t) {
                                    return t.code === e.code;
                                });
                            }), a = i.__assign(i.__assign({}, e.result || {}), {
                                data: o
                            });
                            r.subject.next({
                                result: a,
                                errMsg: e.errMsg
                            }), r.subject.complete();
                        });
                    }, function(e) {
                        r.forEach(function(t) {
                            t.subject.error(e);
                        });
                    });
                }, 1e3), n.asObservable();
            }, r.getPublishSeqMenu = function(e, t) {
                var r = e.groupType, n = e.useSpecialConfig, o = void 0 !== n && n, a = t.COMMON_MENU, s = (t[r] || a).map(function(e) {
                    var n = t[e.configName], a = i.__assign(i.__assign(i.__assign({}, n), o && n.specialConfigs && n.specialConfigs[r] ? n.specialConfigs[r] : null), e);
                    return delete a.specialConfigs, delete a.configName, a;
                });
                return this.processSuccessRes(s, t.VERSION);
            }, r.getBannerActInfo = function(e, t) {
                var r = t[e.id];
                return this.processSuccessRes(r, t.VERSION);
            }, r.getFakeSeparateMarqueeText = function(e, t) {
                return this.processSuccessRes(t, t.VERSION);
            }, r.getPageSeparateMarqueeText = function(e, t) {
                return this.processSuccessRes(t, t.VERSION);
            }, r.getTempMiniAppid = function(e, t) {
                return this.processSuccessRes(t, t.VERSION);
            }, r.getAdvertisementList = function(e, t) {
                var r, i = e.id;
                if (!i) return s.of({
                    result: {
                        code: 400,
                        msg: "云函数缺少请求参数id"
                    },
                    errMsg: "fail"
                });
                var n = {
                    adList: null === (r = t[i]) || void 0 === r ? void 0 : r.adList
                };
                return this.processSuccessRes(n, t.VERSION);
            }, r.processSuccessRes = function(e, t) {
                var r = {
                    code: 200,
                    data: e
                };
                return t && (r.version = t), s.of({
                    result: r,
                    errMsg: "success"
                });
            }, e = i.__decorate([ n.Injectable(), i.__metadata("design:paramtypes", [ a.DefaultService, p.GrayFeatureService ]) ], e);
        }();
        t.CloudFunctionMigrateService = l;
    },
    802: function(e, t, r) {
        function i() {
            try {
                return "new" === (wx.getStorageSync("currentApp") || "old");
            } catch (e) {
                return !1;
            }
        }
        r(803);
        var n = r(804).QunjielongApp, o = {
            onLaunch: function() {},
            onShow: function() {},
            globalData: {}
        }, a = [ "onLaunch", "onShow", "globalData", "data" ], s = function(e, t) {
            var r = Object.assign({}, e);
            return Object.keys(t).forEach(function(n) {
                a.includes(n) || (void 0 !== r[n] ? Object.defineProperty(r, n, {
                    configurable: !0,
                    enumerable: !0,
                    get: function() {
                        return i() ? t[n] : e[n];
                    },
                    set: function(r) {
                        i() ? t[n] = r : e[n] = r;
                    }
                }) : r[n] = t[n]);
            }), r;
        }(o, n);
        s.onLaunch = function(e) {
            this.setCurrentAppByPageOptions(e), o.onLaunch.call(this, e), n.onLaunch.call(this, e);
        }, s.onShow = function(e) {
            this.setCurrentAppByPageOptions(e), i() ? n.onShow.call(this, e) : o.onShow.call(this, e);
        }, s.setCurrentAppByPageOptions = function(e) {
            "common-nav/common-nav" !== e.path && (0 === e.path.indexOf("pro/pages") ? wx.setStorageSync("currentApp", "new") : wx.setStorageSync("currentApp", "old"));
        }, s.handleSwitchMiniProgram = function(e) {
            var t = "old" === e.currentTarget.dataset.to;
            wx.setStorageSync("currentApp", t ? "old" : "new"), t ? wx.reLaunch({
                url: "/pages/index/nav"
            }) : wx.reLaunch({
                url: "/pro/pages/nav/nav"
            });
        }, s.globalData = Object.assign({}, o.globalData || {}, n.globalData || {}), App(s);
    },
    804: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.QunjielongApp = void 0;
        var i = r(0), n = r(107), o = r(13), a = r(1), s = r(7), c = r(3);
        r(805), r(806), r(807), r(808), r(809);
        var u = r(22), p = r(12), l = r(6), d = r(331), h = r(5), g = r(19), v = r(79), f = r(812), m = r(334), S = r(17), y = r(33), b = r(98), C = r(158), M = r(30), T = r(813), w = r(24), _ = r(265), I = r(428), A = r(814), R = r(448), O = r(437), P = r(815), x = r(27), D = r(150), L = r(266), F = r(818), k = r(435), U = r(227), q = r(50), E = r(83);
        r(157);
        var j = r(819), N = r(103), W = r(137), B = r(140), G = r(15), H = r(820), V = r(422), Q = r(821), J = r(9), z = r(822), K = r(823);
        Number.isNaN || Object.defineProperty(Number.prototype, "isNaN", {
            value: function(e) {
                var t = Number(e);
                return t != t;
            }
        });
        var $ = +new Date();
        wx.setBackgroundColor || (wx.setBackgroundColor = function() {}), p.rxwx.init();
        var X = {
            appFunction: App,
            pageFunction: Page,
            componentFunction: Component,
            statsHost: u.config.logHost,
            reportUrl: "/userAction",
            actPeriod: 6,
            hbPeriod: 15,
            onHidePeriod: 60,
            appName: "qunjielong",
            version: "1.0.0",
            clientType: "wxMini",
            canReport: !1,
            getUid: function() {
                return parseInt(wx.getStorageSync("plus_uid"), 10);
            },
            appid: E.currentAppId
        }, Y = {
            logHost: u.config.logHost,
            reportErrorUrl: "/frontLog/pushErrorLog"
        }, Z = parseInt(wx.getStorageSync("plus_uid"), 10), ee = new f.ReportEvent();
        ee.initProcessApp(X, Z), ee.changeCanReport(!0), o.cloudTimerData.startTime = +new Date();
        var te = function(e) {
            function t(t, r, i, n, o, a, s, c, p, l, h, g, v, f, m, S, y, b, C, M, T, w, _, I, A, R, O, P, x, D, L, F, k, U, q) {
                var j = e.call(this) || this;
                return j.shareHttpClient = t, j.httpClient = r, j.utils = i, j.apiService = n, j.proMqtt = o, 
                j.logService = a, j.grayFeatService = s, j.monitor = c, j.commonService = p, j.processMonitor = l, 
                j.migrateService = h, j.loginService = g, j.monoRedDotService = v, j.processPage = f, 
                j.errorService = m, j.httpErrorService = S, j.monoRxCloud = y, j.rxCloud = b, j.cloudCacheService = C, 
                j.appUpdateService = M, j.dynamicMqtt = T, j.publishDraftMiniService = w, j.localLogService = _, 
                j.monoFileService = I, j.remoteActionService = A, j.appsTransferCanIUseService = R, 
                j.wxCloudApiService = O, j.entryRoomOpenGidService = P, j.monoOrderAfterSalesService = x, 
                j.redDotMigrateService = D, j.monoOrderLabelService = L, j.appReportService = F, 
                j.loginInfoService = k, j.ancientAppService = U, j.pageNotFoundService = q, j.globalData = {
                    appid: E.currentAppId
                }, j.ignoreUrlList = [ "/nav/nav", "/authorization/authorization", "login/login" ], 
                j.loginFailCount = 0, j.logService.initLogService(Y), j.shareHttpClient.setClient(j.httpClient), 
                j.grayFeatService.setApiService(j.apiService), j.monoOrderAfterSalesService.setApiService(j.apiService), 
                j.monoRedDotService.setApiService(j.apiService, wx), j.redDotMigrateService.setApiService(j.apiService, wx), 
                j.monoOrderLabelService.setApiService(j.apiService), j.monoRxCloud.setCloudApi(j.rxCloud), 
                j.errorService.setLogService(j.logService), j.errorService.setGrayFeatureService(j.grayFeatService), 
                j.monoFileService.setConfig({
                    httpClient: j.httpClient,
                    resHost: u.config.resHost
                }), d.MQTTService.apiURL = u.config.mqttServerUrl, d.MQTTService.tokenUrl = "/sys/mqtt/login", 
                d.MQTTService.monitor = c, j.processPage.spyOnShareAppMessage(), j.processMonitor.startMonitorNavigation(), 
                j;
            }
            i.__extends(t, e);
            var r = t.prototype;
            return r.onLaunch = function(e) {
                var t = this;
                v.wxlog.info("1. app onLaunch start"), this.appReportService.reportMonitor(e, $), 
                this.setStorage("total-loading-images", "799"), this.updateSystemInfo(), this.initDataByOptions(e), 
                this.listenEventInApp(), setTimeout(function() {
                    t.loginInfoService.initToken(), t.initCloudFunction(), t.httpErrorService.getNeedToEncryptList(), 
                    t.ancientAppService.checkFlushCache(), t.localLogService.initCanLocalLog(), t.initMqtt(), 
                    t.loginInfoService.updatePersonGroupInfo().subscribe(), t.appUpdateService.checkAppUpdateInPlus(), 
                    t.publishDraftMiniService.migrateCrashDraft(), t.publishDraftMiniService.migrateAutoSaveForm(), 
                    t.initNavigatorMiniAppid(), t.initUseComputedV2(), setTimeout(function() {
                        t.appReportService.initOnMemoryWarning();
                    }, 2e4);
                }), this.loginByQyWx();
            }, r.onShow = function(e) {
                var t, r, i = this;
                v.wxlog.info("1. app onShow start"), this.updateSceneInfoWhenOnShow(e, ee), this.utils.updateIsFromSinglePage(), 
                this.updateShareTraceId(e), v.wxlog.info("2. app onShow end"), setTimeout(function() {
                    i.remoteActionService.executeRemoteAction(), i.entryRoomOpenGidService.initWechatGidSubject(e.scene).subscribe(function(e) {
                        i.globalData.opengid = e;
                    }), i.grayFeatService.updateGrayFeature(30);
                }), (null === (r = null === (t = e.referrerInfo) || void 0 === t ? void 0 : t.extraData) || void 0 === r ? void 0 : r.isToManuallyRealNameVerify) && this.utils.navigateTo("/pro/pages/verify-identity/verify-identity");
            }, r.onHide = function() {
                this.proMqtt.shouldReport = !1;
            }, r.getCanShare = function() {
                var e = this;
                this.appsTransferCanIUseService.canIUseFeature(1).subscribe(function(t) {
                    e.globalData.canShare = !t;
                });
            }, r.onError = function(e) {
                void 0 === e && (e = ""), this.appReportService.appErrorReport(e);
            }, r.onPageNotFound = function(e) {
                var t = this.pageNotFoundService.getRoutePage(e), r = t.path, i = t.options;
                this.utils.redirectTo(r, i);
            }, r.getMonitor = function() {
                return this.monitor;
            }, r.getProcessMonitor = function() {
                return this.processMonitor;
            }, r.getReportEvent = function() {
                return ee;
            }, r.login = function(e) {
                var t = this;
                return 1154 === this.globalData.enterScene ? s.of({}) : this.loginInfoService.wxLogin().pipe(c.map(function(r) {
                    return !!r.authorization || t.loginService.authorizationProgram({
                        url: null == e ? void 0 : e.url,
                        loginFailCount: t.loginFailCount
                    }), r;
                }));
            }, r.getStorage = function(e) {
                try {
                    var t = this.globalData[e];
                    return void 0 === t && (t = wx.getStorageSync(e), this.globalData[e] = t), t;
                } catch (e) {
                    return v.wxlog.error("App getStorage 函数报错!"), "";
                }
            }, r.setStorage = function(e, t, r) {
                void 0 === r && (r = !0), r && (this.globalData[e] = t), wx.setStorage({
                    key: e,
                    data: t
                });
            }, r.removeStorage = function(e) {
                delete this.globalData[e], wx.removeStorage({
                    key: e
                });
            }, r.getCurrentPageUrlWithArgs = function() {
                var e = this.utils.getCurrentPageRouteInfo(), t = e.isSuc, r = e.route, i = e.params;
                return t ? i ? "/" + r + "?" + i : "/" + r : "";
            }, r.updatePersonGroupIdObs = function() {
                var e = this;
                return this.apiService.searchUserInfoUserBizUsingGET(o.skipErrorOptions).pipe(c.map(function(e) {
                    return e.data;
                }), c.map(function(t) {
                    return t.personGhId ? (e.setStorage("person_head_image", t.headimgurl), e.setStorage("person_group_id", t.personGhId), 
                    e.setStorage("person_nick_name", t.nickname), e.setStorage("person_real_auth", t.realAuthFlag), 
                    t) : t;
                }));
            }, r.initMqtt = function() {
                var e = this;
                this.dynamicMqtt.canIUseDynamicMqtt(this.globalData.isPc, this.globalData.system, this.isFromTimeLines).subscribe(function(t) {
                    t && e.dynamicMqtt.initDynamicMqtt(function() {
                        return e.proMqtt.initMqtt();
                    });
                });
            }, r.getPage = function() {
                return getCurrentPages()[getCurrentPages().length - 1];
            }, r.loginByQyWx = function() {
                var e = this;
                p.isQyWx && u.config.suiteIdMap && u.config.suiteIdMap[E.currentAppId] && wx.qy.login({
                    suiteId: u.config.suiteIdMap[E.currentAppId] || "",
                    success: function(t) {
                        var r = t.code;
                        e.apiService.userAuthWxWorkApiUsingPOST(r, u.config.suiteIdMap[E.currentAppId]).subscribe(function(e) {});
                    },
                    fail: function(e) {}
                });
            }, r.initCloudFunction = function() {
                return wx.cloud ? this.cloudCacheService.getQJLConfig() : this.monitor.sum("不能使用云函数"), 
                !0;
            }, r.listenEventInApp = function() {
                this.listenLoginSuc();
            }, r.listenLoginSuc = function() {
                var e = this;
                return !!this.loginInfoService.loginSucObservable && (this.loginInfoService.loginSucObservable.subscribe(function(t) {
                    var r = t.uid, n = void 0 === r ? -1 : r, o = t.firstLogin, a = e.globalData, s = a.inviteUid, c = void 0 === s ? 0 : s, p = a.scene, l = e.isOfficial, d = void 0 === l ? 0 : l;
                    e.appReportService.reportNewUser({
                        httpClient: e.httpClient,
                        isFirstLogin: 1 === o,
                        uid: n,
                        inviteUid: c,
                        scene: p,
                        isOfficial: d,
                        logHost: u.config.logHost
                    }), e.loginInfoService.getUserInfo(!0).subscribe(function(t) {
                        e.globalData.userInfo = i.__assign(i.__assign({}, t), {
                            uid: n
                        });
                    }), e.loginInfoService.updatePersonGroupInfo().subscribe();
                }), !0);
            }, r.initUseComputedV2 = function() {
                var e = this;
                this.grayFeatService.canIUseFeature("2571").subscribe(function(t) {
                    e.setStorage("use_computed_v2", t || "");
                });
            }, r.initNavigatorMiniAppid = function() {
                var e = this;
                this.wxCloudApiService.getTempMiniAppid(void 0, {
                    useStorageOptions: {
                        isUseCache: !0
                    }
                }).subscribe(function(t) {
                    var r = t.data.tempMiniAppid;
                    r && (e.globalData.tempMiniAppid = r, e.getReportEvent().customEventReport({
                        functionName: "getTempMiniAppidRes",
                        methodParams: {
                            tempMiniAppid: r
                        }
                    }));
                });
            }, i.__decorate([ g.Lock(1500), i.__metadata("design:type", Function), i.__metadata("design:paramtypes", [ Object ]), i.__metadata("design:returntype", s.Observable) ], t.prototype, "login", null), 
            t = i.__decorate([ a.wxApp({
                plainObject: !0
            }), i.__metadata("design:paramtypes", [ n.ShareHttpClient, o.HttpClient, l.UtilService, h.DefaultService, d.MQTTService, m.LogService, S.GrayFeatureService, y.PerformanceMonitorService, G.CommonService, b.PerformanceProcessMonitorService, x.BackendMigrateService, C.LoginService, M.MonoRedDotService, T.ProcessPageService, w.ErrorService, _.HttpErrorService, I.MonoRxCloudService, A.RxCloudService, R.CloudCacheService, O.AppUpdateService, P.DynamicMqttService, D.PublishDraftMiniService, L.MiniLocalLogService, k.MonoFileService, F.RemoteActionService, U.AppsTransferCanIUseService, q.WxCloudApiService, j.EntryRoomOpenGidService, N.MonoOrderAfterSalesService, W.WxCloudRedDotMigrateService, B.MonoOrderLabelService, H.AppReportService, V.LoginInfoService, Q.AncientAppService, K.PageNotFoundService ]) ], t);
        }(J.miniMixin(z.AppFormatMixin));
        t.QunjielongApp = te;
    },
    812: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.ReportEvent = void 0;
        var i = r(0), n = r(1), o = r(7), a = r(22), s = r(28), c = r(13), u = r(235), p = [ "onLoad", "onReady", "onShow", "onHide", "onUnload", "onPullDownRefresh", "onReachBottom", "onShareAppMessage", "onPageScroll", "onResize", "onTabItemTap" ], l = function() {
            function e() {
                this.actCache = [], this.subtractHeartBeatCount = 0, this.isHiddenTimeOut = !1, 
                this.actCount = 0, this.heartBeatCount = 0, this.ignoreArray = [ [ "*", "noop" ], [ "*", "handleTimeChange" ], [ "*", "handleOriginLoad" ], [ "*", "abandonShowedItem" ], [ "*", "handleTouchStart" ], [ "*", "handleTouchMove" ], [ "*", "handleTouchEnd" ], [ "*", "handleBindScroll" ], [ "*", "onDrag" ], [ "*", "teo" ], [ "*", "e" ], [ "*", "handleListenActGoodsListScroll" ], [ "pages/homepage/group-homepage/group-homepage", "handleMoveFeed" ], [ "pages/homepage/group-homepage/group-homepage", "handleLoadError" ], [ "pages/customer-service/chat-page/chat-page", "handleBubbleListScroll" ], [ "/pro/pages/home/fans-management-new/fans-management-new", "handleScrollFansList" ] ], 
                this.personalInfoData = {
                    userInfo: null,
                    location: null
                }, this.whiteListObject = {
                    reportHb: !1,
                    reportInfo: !0,
                    reportErrorUidMod: 10
                }, this.canReport = !1, this.isNotLogin = !1, this.getUid = function() {
                    return null;
                }, this.queryString = function(e) {
                    var t, r, n = [];
                    if (e) try {
                        for (var o = i.__values(Object.entries(e)), a = o.next(); !a.done; a = o.next()) {
                            var s = i.__read(a.value, 2), c = s[0], u = s[1];
                            [ null, void 0 ].includes(u) || n.push(c + "=" + u);
                        }
                    } catch (e) {
                        t = {
                            error: e
                        };
                    } finally {
                        try {
                            a && !a.done && (r = o.return) && r.call(o);
                        } finally {
                            if (t) throw t.error;
                        }
                    }
                    return n.join("&");
                }, this.apiService = n.getInstanceByServiceOrCacheIfNotExist(s.DefaultService), 
                this.actionRecorderService = n.getInstanceByServiceOrCacheIfNotExist(u.ActionRecorderService);
            }
            var t = e.prototype;
            return t.initProcessApp = function(e, t) {
                Object.assign(this, e), this.uid = t, this.processApp(), this.processPage(), this.processComponent();
            }, t.changeCanReport = function(e) {
                this.canReport = e;
            }, t.customEventReport = function(e) {
                var t = "";
                try {
                    var r = this.getCurrentPage();
                    t = (null == r ? void 0 : r.route) || "no_current_page_route";
                } catch (e) {}
                this.reportAct(t, "custom", e);
            }, t.customChangePageOptions = function() {
                var e = "";
                try {
                    var t = this.getCurrentPage();
                    e = (null == t ? void 0 : t.route) || "no_current_page_route";
                } catch (e) {}
                this.reportAct(e, "changeOptions", {});
            }, t.setScene = function(e) {
                this.scene = e;
            }, t.processPage = function() {
                var e = this;
                Page = function(t) {
                    var r = t.onShow, n = t.onShareAppMessage;
                    t.onShow = function() {
                        for (var n, o = [], a = 0; a < arguments.length; a++) o[a] = arguments[a];
                        var s = e.getCurrentPage(), c = (null === (n = s) || void 0 === n ? void 0 : n.options) || {}, u = e.getGroupId(s);
                        e.reportAct(this.route, "web", i.__assign(i.__assign({}, c), {
                            groupId: u,
                            constructorName: t.constructorName
                        })), r && r.apply(this, o);
                    }, e.traversePageFunction(t), n && (t.onShareAppMessage = function() {
                        for (var r = [], o = 0; o < arguments.length; o++) r[o] = arguments[o];
                        var a = e.getCurrentPage(), s = e.getGroupId(a), c = n.apply(this, r);
                        return e.reportAct(this.route, "tap", {
                            type: "share",
                            functionName: "onShareAppMessage",
                            groupId: s,
                            methodParams: i.__assign(i.__assign({}, r[0]), {
                                result: c
                            }),
                            constructorName: t.constructorName
                        }), c;
                    }), e.pageFunction(t);
                };
            }, t.processApp = function() {
                var e = this;
                App = function(t) {
                    var r = e, n = t.onShow, o = t.onLaunch, a = t.onHide, s = null;
                    t.onLaunch = function(e) {
                        o && o.call(t, e), r.initInterval(), r.reportAct(null == e ? void 0 : e.path, "launch", i.__assign({
                            methodParams: i.__assign({}, e)
                        }, e));
                    }, t.onShow = function(e) {
                        if (n && n.call(this, e), s) return clearInterval(s), void (s = null);
                        r.heartBeatCount = 0, r.session = null, r.actCount = 0, r.isHiddenTimeOut = !0, 
                        r.getInitialData();
                    }, t.onHide = function() {
                        a && a.call(this), r.actCache.length > 0 && (r.postReport("act", r.actCache), r.actCache = []), 
                        s = setTimeout(function() {
                            s = null;
                        }, 6e4);
                    }, e.appFunction(t);
                };
            }, t.processComponent = function() {
                var e = this;
                Component = function(t) {
                    t.methods && e.traversePageFunction(t.methods, !0), e.componentFunction(t);
                };
            }, t.initInterval = function() {
                if (this.actTimer) throw new Error("定时器已经开启");
                this.initActTimer(this.actPeriod), this.initHbTimer(this.hbPeriod);
            }, t.initActTimer = function(e) {
                var t = this;
                this.actTimer = o.interval(1e3 * e), this.actTimer.subscribe(function() {
                    0 !== t.actCache.length && (t.updateUid(), t.uid && (t.postReport("act", t.actCache), 
                    t.actCache = []));
                });
            }, t.initHbTimer = function(e) {
                var t = this;
                this.whiteListObject.reportHb && (this.hbTimer = o.interval(1e3 * e), this.hbTimer.subscribe(function(e) {
                    t.isHiddenTimeOut && (t.subtractHeartBeatCount = t.heartBeatCount, t.isHiddenTimeOut = !1), 
                    t.heartBeatCount = e + 1;
                    var r = {
                        ts: Date.now(),
                        heartBeatCount: t.heartBeatCount - t.subtractHeartBeatCount
                    };
                    t.postReport("hb", [ r ]);
                }));
            }, t.reportAct = function(e, t, r) {
                var i = this;
                setTimeout(function() {
                    var n, o = JSON.stringify(r.methodParams || {}), a = i.getCurrentPageOptions();
                    r.methodParams && delete r.methodParams;
                    var s = getCurrentPages(), c = s.slice(0, -1).map(function(e) {
                        return e.route;
                    }), u = "";
                    try {
                        u = (null === (n = s[s.length - 1].__displayReporter) || void 0 === n ? void 0 : n.showReferpagepath.replace(/\.html.*/, "")) || "";
                    } catch (e) {
                        u = "来源页面上报异常";
                    }
                    var p = r.groupId, l = void 0 === p ? "" : p, d = r.functionName, h = void 0 === d ? "" : d, g = r.eventId, v = void 0 === g ? "" : g;
                    if (!i.isIgnoreAction(e, h)) {
                        i.actCount = i.actCount + 1, i.actCache.push({
                            ts: Date.now(),
                            actName: e,
                            actType: t,
                            actCount: i.actCount,
                            queryString: i.queryString(r),
                            options: i.queryString(a),
                            functionName: h,
                            groupId: l,
                            methodParams: o,
                            prevPage: u,
                            prevPages: c,
                            eventId: String(v)
                        });
                        var f = null == s ? void 0 : s[s.length - 1];
                        f && i.actionRecorderService.addRecord({
                            ts: Date.now(),
                            actName: e,
                            functionName: h,
                            queryString: i.queryString(r),
                            groupId: l,
                            actType: t,
                            actCount: i.actCount,
                            methodParams: o,
                            prevPage: u,
                            prevPages: c,
                            options: i.queryString(a),
                            pageId: f.instanceId,
                            constructorName: r.constructorName
                        });
                    }
                });
            }, t.reportUserAllInfo = function() {
                if (this.whiteListObject.reportInfo) {
                    var e = {
                        ts: Date.now(),
                        infoData: this.personalInfoData
                    };
                    this.postReport("info", [ e ]);
                }
            }, t.postReport = function(e, t) {
                var r = Date.now();
                this.updateUid();
                var i = this.scene;
                if (this.uid) {
                    this.isNotLogin && (this.isNotLogin = !1, this.getInitialData());
                    var n = this.session ? this.session : "" + this.uid + this.appName + r;
                    this.session = n;
                    var o = {
                        uid: this.uid,
                        clientType: "wxMini",
                        version: a.config.version || "-1",
                        contentSize: t.length,
                        content: t,
                        appid: this.appid,
                        msgType: e,
                        sendTime: r,
                        session: n,
                        scene: i
                    };
                    this.reportUrl && this.statsHost && this.canReport && wx.request({
                        url: "" + this.statsHost + this.reportUrl,
                        method: "POST",
                        data: o,
                        header: {
                            contentType: "application/json"
                        },
                        success: function(e) {}
                    });
                } else this.isNotLogin = !0;
            }, t.getInitialData = function() {
                var e = this;
                this.getSystemInfo();
                var t = this.getSetting(), r = this.getNetworkType();
                Promise.all([ t, r ]).then(function() {
                    e.reportUserAllInfo();
                });
            }, t.getSetting = function() {
                var e = this;
                return new Promise(function(t) {
                    wx.getSetting({
                        success: function(r) {
                            e.authSetting = r.authSetting;
                            var i = e.getUserInfo(), n = e.getLocation();
                            Promise.all([ i, n ]).then(function() {
                                t();
                            });
                        }
                    });
                });
            }, t.getSystemInfo = function() {
                this.personalInfoData.system = wx.getSystemInfoSync();
            }, t.getNetworkType = function() {
                var e = this;
                return new Promise(function(t) {
                    wx.getNetworkType({
                        success: function(r) {
                            e.personalInfoData.networkType = r.networkType, t();
                        },
                        fail: function() {
                            e.personalInfoData.networkType = "fail", t();
                        }
                    });
                });
            }, t.getUserInfo = function() {
                var e = this;
                return new Promise(function(t) {
                    e.apiService.userPortrayalUserBizUsingPOST(c.skipErrorOptions).subscribe(function(r) {
                        if (r.data) {
                            var i = r.data, n = i.nickName, o = i.avatarUrl, a = i.gender, s = i.country, c = i.province, u = i.city, p = i.language;
                            e.personalInfoData.userInfo = {
                                nickName: n,
                                avatarUrl: o,
                                gender: a,
                                country: s,
                                province: c,
                                city: u,
                                language: p
                            }, t();
                        } else e.personalInfoData.userInfo = null, t();
                    });
                });
            }, t.getLocation = function() {
                var e = this;
                return new Promise(function(t) {
                    e.authSetting["scope.userLocation"] ? wx.getLocation({
                        type: "gcj02",
                        success: function(r) {
                            e.personalInfoData.location = r, t();
                        },
                        fail: function() {
                            e.personalInfoData.location = null, t();
                        }
                    }) : t();
                });
            }, t.traversePageFunction = function(e, t) {
                void 0 === t && (t = !1);
                var r = this;
                Object.keys(e).forEach(function(i) {
                    if ("function" == typeof e[i]) {
                        if (!e[i]) return;
                        if (p.some(function(e) {
                            return e === i;
                        })) return;
                        var n = e[i];
                        e[i] = function() {
                            for (var e, o = [], a = 0; a < arguments.length; a++) o[a] = arguments[a];
                            if (!o.length) return n.apply(this, o);
                            var s = {};
                            if (t && this.data && this.data.componentReportType && (s = {
                                componentReportType: this.data.componentReportType
                            }), o[0] && o[0].target && o[0].type) {
                                var c = o[0], u = r.getCurrentPage(), p = r.getGroupId(u), l = {
                                    dataset: Object.assign((null === (e = c.currentTarget) || void 0 === e ? void 0 : e.dataset) || {}, s),
                                    detail: c.detail || {}
                                };
                                "submit" === c.type && (l.dataset = c.detail.target.dataset);
                                var d = l.dataset, h = d.ignoreReport, g = d.eventId;
                                h || r.reportAct((null == u ? void 0 : u.route) || "", "tap", {
                                    type: c.type,
                                    functionName: i,
                                    constructorName: this.constructorName,
                                    groupId: p,
                                    methodParams: l,
                                    eventId: g
                                });
                            }
                            return n.apply(this, o);
                        };
                    }
                });
            }, t.getGroupId = function(e) {
                if (!e) return "";
                var t = e.options || {}, r = e.data || {};
                return t.groupId || e.groupId || r.groupId || "";
            }, t.getCurrentPage = function() {
                return getCurrentPages()[getCurrentPages().length - 1];
            }, t.getCurrentPageOptions = function() {
                var e = this.getCurrentPage();
                return e && ((null == e ? void 0 : e.customOptions) || (null == e ? void 0 : e.options)) || {};
            }, t.updateUid = function() {
                this.uid = this.uid || this.getUid();
            }, t.isIgnoreAction = function(e, t) {
                return this.ignoreArray.some(function(r) {
                    var n = i.__read(r, 2), o = n[0], a = n[1];
                    return ("*" === o || "pro/" + o === e) && a === t;
                });
            }, e = i.__decorate([ n.Injectable(), i.__metadata("design:paramtypes", []) ], e);
        }();
        t.ReportEvent = l;
    },
    813: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.ProcessPageService = void 0;
        var i = r(0), n = r(6), o = r(1), a = function() {
            function e(e) {
                this.utilsService = e;
            }
            return e.prototype.spyOnShareAppMessage = function() {
                var e = this, t = Page;
                Page = function(r) {
                    if (r.onShareAppMessage) {
                        var i = r.onShareAppMessage;
                        r.onShareAppMessage = function() {
                            for (var t = [], r = 0; r < arguments.length; r++) t[r] = arguments[r];
                            var n = i.apply(this, t);
                            if (!n.path) {
                                var o = e.utilsService.getCurrentPageRouteInfo();
                                n.path = "/" + o.route + "?" + o.params;
                            }
                            var a = n.path, s = "inviteUid", c = e.utilsService.getUid(), u = e.utilsService.getGlobalData("shareTraceId", !0) || c + "-" + Date.now();
                            if (a && !a.includes(s)) {
                                var p = s + "=" + c;
                                n.path += (a.includes("?") ? "&" : "?") + p;
                            }
                            return n.path += "&shareTraceId=" + u, n;
                        };
                    }
                    t(r);
                };
            }, e = i.__decorate([ o.Injectable(), i.__metadata("design:paramtypes", [ n.UtilService ]) ], e);
        }();
        t.ProcessPageService = a;
    },
    814: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.RxCloudService = void 0;
        var i = r(0), n = r(1), o = r(7), a = r(3), s = r(24), c = r(11), u = r(448), p = r(13), l = r(22), d = r(17), h = r(449), g = [ "getTempMiniAppid", "getPageSeparateMarqueeText" ], v = function() {
            function e(e, t, r, i, n, o) {
                this.errorService = e, this.monoUtilService = t, this.cloudCacheService = r, this.httpClient = i, 
                this.grayService = n, this.cloudMigrateService = o;
            }
            var t = e.prototype;
            return t.rxCloud = function(e, t, r) {
                var i, n = this;
                return ((null === (i = r.useStorageOptions) || void 0 === i ? void 0 : i.isUseCache) ? this.cloudCacheService.getCloudUpdateTime() : o.of({})).pipe(a.switchMap(function() {
                    return n.rxCloudRequest(e, t, r);
                }));
            }, t.rxCloudRequest = function(e, t, r) {
                var i = this;
                return o.Observable.create(function(n) {
                    var o;
                    if (null === (o = r.useStorageOptions) || void 0 === o ? void 0 : o.isUseCache) {
                        var a = i.cloudCacheService.getValidCache(e, t, r);
                        if (a) return n.next({
                            code: 200,
                            data: a.data
                        }), void n.complete();
                    }
                    i.requestByCloudOrCdnInWhiteList(e, t).subscribe(function(o) {
                        var a, s, c = o.result;
                        (null === (a = r.cloudErrorReportOptions) || void 0 === a ? void 0 : a.isEmptyNotCheck) || !i.monoUtilService.isEmpty(c) ? 200 === c.code ? (n.next(c), 
                        n.complete(), (null === (s = r.useStorageOptions) || void 0 === s ? void 0 : s.isUseCache) && i.cloudCacheService.setCache(e, t, o, r.useStorageOptions)) : n.error(c) : n.error({
                            code: -3,
                            msg: "云函数返回值为空"
                        });
                    }, function(e) {
                        n.error({
                            msg: e.errMsg,
                            error: e,
                            code: -1
                        }), n.complete();
                    });
                }).pipe(this.cloudCatchError(e, t, r));
            }, t.cdnRequest = function(e, t) {
                var r = this.cloudCacheService.getCloudFuncLastUpdateTime(e);
                return this.httpClient.get(l.config.resHost + "/frontend_config/cloud_function/" + e + ".json?t=" + r).pipe(a.map(function(e) {
                    return e;
                }));
            }, t.requestByCloudOrCdnInGray = function(e, t) {
                var r = this;
                return this.grayService.canIUseFeature("2421").pipe(a.switchMap(function(i) {
                    return i ? r.cdnRequest(e, t) : r.cloudCacheService.getCloudUpdateTime().pipe(a.switchMap(function() {
                        return r.cloudMigrateService.judgeRequestServer(e, t);
                    }));
                }));
            }, t.requestByCloudOrCdnInWhiteList = function(e, t) {
                var r = this;
                return g.indexOf(e) >= 0 ? this.requestByCloudOrCdnInGray(e, t) : this.cloudCacheService.getCloudUpdateTime().pipe(a.switchMap(function() {
                    return r.cloudMigrateService.judgeRequestServer(e, t);
                }));
            }, t.cloudCatchError = function(e, t, r) {
                var i = this;
                return a.catchError(function(n) {
                    return n.code, n.error, n.isSkipReport = !0, i.errorService.customReportWxCloudRequest(n, e, t), 
                    r.defaultData ? o.of({
                        code: 200,
                        data: r.defaultData
                    }) : o.throwError(n);
                });
            }, e = i.__decorate([ n.Injectable(), i.__metadata("design:paramtypes", [ s.ErrorService, c.MonoUtilService, u.CloudCacheService, p.HttpClient, d.GrayFeatureService, h.CloudFunctionMigrateService ]) ], e);
        }();
        t.RxCloudService = v;
    },
    815: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.DynamicMqttService = void 0;
        var i = r(0), n = r(1), o = r(816), a = r(331), s = r(22), c = r(332), u = r(333), p = r(33), l = r(7), d = r(17), h = r(3), g = r(24), v = function() {
            function e(e, t, r) {
                this.monitor = e, this.errorService = t, this.grayFeatService = r, this.mqttCacheFilePath = wx.env.USER_DATA_PATH + "/MQTT_BINARY", 
                this.mqttErrorTimeLocalStorageKey = "MQTT_WRITE_BUFFER_ERROR_TIME";
            }
            var t = e.prototype;
            return t.canIUseDynamicMqtt = function(e, t, r) {
                return l.forkJoin([ this.grayFeatService.canIUseFeature("2038"), this.grayFeatService.canIUseFeature("10011") ]).pipe(h.map(function(t) {
                    var n = i.__read(t, 2), o = n[0], a = n[1];
                    return o && !a && !r && !e;
                }));
            }, t.initDynamicMqtt = function(e) {
                var t = this;
                try {
                    this.qjlWorker = new o.QJLWorker();
                } catch (e) {
                    return void this.monitor.sum("qjlWorker init fail");
                }
                a.MQTTService.MQTTDynamicLoadingConnector = this.getWorkerMqttConnector(), this.monitor.timeStart("setupWorker 耗时"), 
                this.listenWorkerEvent(), this.monitor.timeEnd("setupWorker 耗时");
                var r = wx.getFileSystemManager(), i = function() {
                    return t.fetchMqttBinaryFromRemote().subscribe({
                        next: function(r) {
                            t.emitMqttBinaryByWorker(r, e), t.cacheMqttBinary(r);
                        },
                        error: function(e) {
                            var r = {
                                frontErrorCode: 14001,
                                error: e,
                                errorMsg: "mqtt二进制远端获取失败"
                            };
                            t.errorService.customReportError(r);
                        }
                    });
                };
                if (this.getErrorTimeFromLocalStorage() > 5) i(); else try {
                    r.accessSync(this.mqttCacheFilePath), this.getMqttBinaryFromCache().subscribe({
                        next: function(r) {
                            return t.emitMqttBinaryByWorker(r, e);
                        },
                        error: function(e) {
                            i();
                            var r = {
                                frontErrorCode: 14001,
                                error: e,
                                errorMsg: "mqtt二进制获取失败"
                            };
                            t.errorService.customReportError(r), t.incrementErrorTimeToLocalStorage();
                        }
                    });
                } catch (e) {
                    i();
                }
            }, t.getMqttBinaryFromCache = function() {
                var e = this;
                return new l.Observable(function(t) {
                    var r = wx.getFileSystemManager();
                    r.readFile({
                        filePath: e.mqttCacheFilePath,
                        success: function(i) {
                            var n = i.data, o = c.WorkerHelper.getType(n);
                            "ArrayBuffer" === o ? t.next(n) : (r.unlink({
                                filePath: e.mqttCacheFilePath,
                                success: function() {}
                            }), t.error("读取缓存的数据格式不对, dataType:" + o)), t.complete();
                        },
                        fail: function(e) {
                            void 0 === e && (e = {}), t.error(e), t.complete();
                        }
                    });
                });
            }, t.fetchMqttBinaryFromRemote = function() {
                return new l.Observable(function(e) {
                    wx.request({
                        url: s.config.resHost + "/ss/app/mqtt-binary",
                        responseType: "arraybuffer",
                        method: "GET",
                        success: function(t) {
                            var r = t.data;
                            e.next(r), e.complete();
                        },
                        fail: function(t) {
                            e.error(t), e.complete();
                        }
                    });
                });
            }, t.cacheMqttBinary = function(e) {
                var t = this;
                this.getErrorTimeFromLocalStorage() > 5 || wx.getFileSystemManager().writeFile({
                    filePath: this.mqttCacheFilePath,
                    data: e,
                    success: function() {},
                    fail: function(e) {
                        t.errorService.customReportError({
                            frontErrorCode: 14e3,
                            error: e,
                            errorMsg: "缓存mqtt失败"
                        }), t.incrementErrorTimeToLocalStorage();
                    }
                });
            }, t.incrementErrorTimeToLocalStorage = function() {
                var e = this.getErrorTimeFromLocalStorage();
                wx.setStorageSync(this.mqttErrorTimeLocalStorageKey, e + 1);
            }, t.getErrorTimeFromLocalStorage = function() {
                return wx.getStorageSync(this.mqttErrorTimeLocalStorageKey) || 0;
            }, t.listenWorkerEvent = function() {
                var e, t = this;
                this.qjlWorker.on("wxApi", function(e) {
                    var t = e.data, r = t.arg, i = t.name;
                    wx[i](r);
                }), this.qjlWorker.on("monitor", function(e) {
                    var r, n = e.data, o = n.name, a = n.args;
                    (r = t.monitor)[o].apply(r, i.__spread(a));
                }), this.qjlWorker.on("connectSocket", function(r) {
                    (e = wx.connectSocket(r.data)).onOpen(function(e) {
                        t.qjlWorker.sendMessage("socketOpen", {
                            data: e
                        });
                    }), e.onMessage(function(e) {
                        t.qjlWorker.sendMessage("onMessage", {
                            data: e
                        });
                    });
                }), this.qjlWorker.on("socketTask", function(t) {
                    var r = t.data, i = r.arg, n = r.name;
                    e && e[n](i);
                }), this.qjlWorker.on("workerError", function(e) {
                    throw new Error(e.data);
                });
            }, t.emitMqttBinaryByWorker = function(e, t) {
                this.qjlWorker.sendMessage("mqttBuffer", {
                    buffer: e,
                    success: function() {
                        t();
                    }
                }, !0);
            }, t.getWorkerMqttConnector = function() {
                var e = this;
                return function(t, r) {
                    return new Promise(function(i) {
                        e.qjlWorker.sendMessage("mqttConnect", {
                            brokerURL: t,
                            opts: r,
                            success: function(t) {
                                c.WorkerHelper.spyClient(t.client, e.qjlWorker);
                                var r = new u.AsyncClient(t.client);
                                r.changeOptions = function(t) {
                                    return e.qjlWorker.sendMessage("changeMqttConnect", t);
                                }, i(r);
                            }
                        }, !0);
                    });
                };
            }, e = i.__decorate([ n.Injectable(), i.__metadata("design:paramtypes", [ p.PerformanceMonitorService, g.ErrorService, d.GrayFeatureService ]) ], e);
        }();
        t.DynamicMqttService = v;
    },
    816: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.Receiver = t.Sender = t.QJLWorker = void 0;
        var i = r(0), n = r(817), o = r(332), a = function() {
            function e() {
                this.initWorker(), this.emitter = new n.default(), this.sender = new s(this), this.receiver = new c(this);
            }
            var t = e.prototype;
            return t.initWX = function() {
                var e = this;
                [ "" ].forEach(function(t) {
                    e.wxApi[t] = function(t) {
                        e.receiver.execute(t);
                    };
                });
            }, t.initWorker = function() {
                e.workerInstance || (e.workerInstance = wx.createWorker("workers/index.js")), this.worker = e.workerInstance;
            }, t.sendMessage = function(e, t, r) {
                void 0 === r && (r = !1), s.event = e, this.sender.execute(t, r);
            }, t.onMessage = function(e) {
                var t = e.event;
                this.emitter.emit(t, e);
            }, t.on = function(e, t) {
                this.emitter.on(e, t);
            }, t.once = function(e, t) {
                this.emitter.once(e, t);
            }, e.transferCacheSeed = 0, e;
        }();
        t.QJLWorker = a;
        var s = function() {
            function e(t) {
                var r = this;
                this.deepObjectForEachKeyReviver = function(e, t, i) {
                    return !!r.recordArrayBufferMetaDataAndMoveToRoot(e, t.slice()) || (r.recordFunctionMetaDataAndListen(e, t.slice(), i), 
                    !1);
                }, this.recordArrayBufferMetaDataAndMoveToRoot = function(t, i) {
                    var n = ArrayBuffer.isView(t);
                    if ("ArrayBuffer" === o.WorkerHelper.getType(t) || n) {
                        a.transferCacheSeed++, i = i.slice();
                        var s = "bf" + a.transferCacheSeed;
                        return i.push([ o.WorkerHelper.getType(t), t.byteOffset, t.byteLength ]), i.push(s), 
                        r.result.bufferMetadata.push(i), e.senderTransferCacheMap.set(s, n ? t.buffer : t), 
                        !0;
                    }
                    return !1;
                }, this.recordFunctionMetaDataAndListen = function(t, i, n) {
                    if ("function" == typeof t) {
                        e.functionId++;
                        var o = String(e.functionId);
                        return (i = i.slice()).push(o), r.result.functionMetadata.push(i), n ? r.qjlWorker.once(o, t) : r.qjlWorker.on(o, t), 
                        !0;
                    }
                    return !1;
                }, this.qjlWorker = t, this.emitter = this.qjlWorker.emitter, this.qjlWorker.on("cb", function(e) {
                    var t, n = e.data;
                    (t = r.emitter).emit.apply(t, i.__spread([ n.callbackId ], n.args));
                });
            }
            var t = e.prototype;
            return t.execute = function(t, r) {
                var i = this;
                this.resetFilter();
                try {
                    o.WorkerHelper.deepObjectForEachKey(t, this.deepObjectForEachKeyReviver, [ "data" ], r);
                } catch (e) {}
                this.result.data = t, this.result.event = e.event, e.event = "", e.senderTransferCacheMap.forEach(function(e, t) {
                    i.qjlWorker.worker.postMessage({
                        data: e,
                        key$$: t,
                        isBuffer$$: !0
                    });
                }), e.senderTransferCacheMap.clear(), this.qjlWorker.worker.postMessage(this.result);
            }, t.resetFilter = function() {
                e.bufferId = 0, this.result = {
                    event: "",
                    functionMetadata: [],
                    bufferMetadata: [],
                    data: null
                };
            }, e.senderTransferCacheMap = new Map(), e.functionId = 0, e.bufferId = 0, e;
        }();
        t.Sender = s;
        var c = function() {
            function e(t) {
                var r = this;
                this.qjlWorker = t, this.emitter = this.qjlWorker.emitter, this.qjlWorker.worker.onMessage(function(t) {
                    var i = t;
                    i.isBuffer$$ ? e.receiverTransferCacheMap.set(i.key$$, i.data) : r.qjlWorker.onMessage(r.execute(t));
                });
            }
            var t = e.prototype;
            return t.execute = function(t) {
                try {
                    this.restoreBufferByMetadata(t), this.setFakeFunctionByMetadata(t);
                } catch (t) {
                    e.receiverTransferCacheMap.clear();
                }
                return t;
            }, t.restoreBufferByMetadata = function(t) {
                t.bufferMetadata.forEach(function(r) {
                    var n = r.slice(r.length - 2), o = i.__read(n[0], 3), a = o[0], s = o[1], c = o[2], u = n[1], p = e.receiverTransferCacheMap.get(u);
                    e.receiverTransferCacheMap.delete(u);
                    var l = {
                        Uint8Array: Uint8Array,
                        Uint16Array: Uint16Array,
                        Uint32Array: Uint32Array,
                        Uint8ClampedArray: Uint8ClampedArray,
                        Float32Array: Float32Array,
                        Float64Array: Float64Array,
                        Int32Array: Int32Array,
                        Int16Array: Int16Array,
                        Int8Array: Int8Array
                    };
                    l[a] && (p = new l[a](p, s, c)), r = r.slice(0, r.length - 2);
                    for (var d = t; r.length > 1; ) d = d[r.shift()];
                    d[r[0]] = p;
                });
            }, t.setFakeFunctionByMetadata = function(e) {
                var t = this, r = e.functionMetadata, i = e.event;
                r.forEach(function(r) {
                    for (var n = r.slice(0, r.length - 1), o = e; n.length > 1; ) o = o[n.shift()];
                    o[n[0]] = function() {
                        for (var e = [], n = 0; n < arguments.length; n++) e[n] = arguments[n];
                        var o = r[r.length - 1];
                        t.qjlWorker.sendMessage("cb", {
                            callbackId: o,
                            args: e,
                            sourceEvent: i
                        });
                    };
                });
            }, e.receiverTransferCacheMap = new Map(), e;
        }();
        t.Receiver = c;
    },
    818: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.RemoteActionService = void 0;
        var i = r(0), n = r(6), o = r(1), a = r(50), s = r(7), c = r(3), u = r(19), p = r(266), l = r(17), d = function() {
            function e(e, t, r, i) {
                var n;
                this.wxCloudApiService = e, this.localLogService = t, this.grayFeatService = r, 
                this.utils = i, this.reducers = ((n = {}).send_local_log = this.sendLocalLogReducer, 
                n.delete_all_log = this.deleteAllLogReducer, n);
            }
            var t = e.prototype;
            return t.executeRemoteAction = function() {
                var e = this;
                this.grayFeatService.canIUseFeature("2261").subscribe(function(t) {
                    t && e.runRequiredActions({
                        uid: e.utils.getUid()
                    });
                });
            }, t.runRequiredActions = function(e) {
                var t = this;
                this.getRequiredActions(e).subscribe(function(e) {
                    e.forEach(function(e, r) {
                        setTimeout(function() {
                            t.runReducer(e).subscribe();
                        }, 100 * (r + 1));
                    });
                });
            }, t.getRequiredActions = function(e) {
                return this.wxCloudApiService.getRemoteActionList(e).pipe(c.map(function(e) {
                    return e.data || [];
                }));
            }, t.runReducer = function(e) {
                var t = this.getReducer(e.type);
                return t ? t.call(this, e) : s.of(!1);
            }, t.getReducer = function(e) {
                return this.reducers[e];
            }, t.sendLocalLogReducer = function(e) {
                return "send_local_log" === e.type && e.payload ? (this.localLogService.sendLocalLog({
                    isSilent: !0
                }), s.of(!0)) : s.of(!1);
            }, t.deleteAllLogReducer = function(e) {
                return "delete_all_log" !== e.type ? s.of(!1) : (this.localLogService.cleanAll(), 
                s.of(!0));
            }, i.__decorate([ u.Lock(15e5), i.__metadata("design:type", Function), i.__metadata("design:paramtypes", [ Object ]), i.__metadata("design:returntype", void 0) ], e.prototype, "runRequiredActions", null), 
            e = i.__decorate([ o.Injectable(), i.__metadata("design:paramtypes", [ a.WxCloudApiService, p.MiniLocalLogService, l.GrayFeatureService, n.UtilService ]) ], e);
        }();
        t.RemoteActionService = d;
    },
    819: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.EntryRoomOpenGidService = void 0;
        var i = r(0), n = r(157), o = r(1), a = r(24), s = r(5), c = r(50), u = r(7), p = r(6), l = r(3), d = r(14), h = r(12), g = function() {
            function e(e, t, r, i) {
                this.wxCloudApiService = e, this.utilService = t, this.errorService = r, this.apiService = i, 
                this.opengid = "", this.cloudID = "";
            }
            var t = e.prototype;
            return t.initWechatGidSubject = function(e) {
                var t = new u.ReplaySubject();
                return this.wechatGidSubject = t, wx.getGroupEnterInfo && -1 !== [ "1007", "1008" ].indexOf(e + "") ? this.getOpenGid() : (t.next(""), 
                t.complete()), t.asObservable();
            }, t.getOpenGid = function() {
                var e = this;
                this.checkSession().pipe(l.switchMap(function() {
                    return e.decryptOpenGid();
                }), l.switchMap(function(t) {
                    return (null == t ? void 0 : t.data) ? u.of(t) : e.retryDecryptOpenGid();
                }), l.retryWhen(function(e) {
                    return e.pipe(l.delay(5e3), l.take(3));
                })).subscribe(function(t) {
                    var r;
                    if (t.data || !e.cloudID) {
                        var i = (null === (r = null == t ? void 0 : t.data) || void 0 === r ? void 0 : r.opengid) || "";
                        e.opengid = i, e.wechatGidSubject.next(i), e.wechatGidSubject.complete();
                    } else e.getOpenGidFromCloud(e.cloudID);
                }, function(t) {
                    e.cloudID ? e.getOpenGidFromCloud(e.cloudID) : (e.wechatGidSubject.next(""), e.wechatGidSubject.complete(), 
                    "getGroupEnterInfo:fail invalid scene" !== (null == t ? void 0 : t.errMsg) && e.errorService.customReportError({
                        error: t,
                        frontErrorCode: 11003
                    }));
                });
            }, t.checkSession = function() {
                var e = this;
                return h.rxwx.checkSession({}).pipe(l.switchMap(function(t) {
                    return "checkSession:ok" !== t.errMsg ? e.reLogin() : u.of({});
                }));
            }, t.decryptOpenGid = function() {
                var e = this;
                return h.rxwx.getGroupEnterInfo({}).pipe(l.switchMap(function(t) {
                    if (e.cloudID && e.cloudID === (null == t ? void 0 : t.cloudID) && e.opengid) {
                        var r = {
                            opengid: e.opengid
                        };
                        return u.of({
                            data: r
                        });
                    }
                    e.cloudID = null == t ? void 0 : t.cloudID;
                    var i = t || {}, n = i.encryptedData, o = i.iv;
                    return e.apiService.decryptOpenGidV2UsingPOST({
                        encryptedData: n,
                        iv: o
                    }, d.skipMarkOption);
                }));
            }, t.retryDecryptOpenGid = function() {
                var e = this;
                return this.reLogin().pipe(l.switchMap(function() {
                    return e.decryptOpenGid();
                }));
            }, t.reLogin = function() {
                return this.utilService.getApp().login();
            }, t.getOpenGidFromCloud = function(e) {
                var t = this;
                n.myCloudInitObs.pipe(l.switchMap(function() {
                    return t.wxCloudApiService.getRoomOpenGid({
                        opengidData: n.myCloud.CloudID(e)
                    }, {
                        useStorageOptions: {
                            isUseCache: !0
                        }
                    });
                })).subscribe(function(e) {
                    var r, i = (null === (r = null == e ? void 0 : e.data) || void 0 === r ? void 0 : r.opengid) || "";
                    t.opengid = i, t.wechatGidSubject.next(i), t.wechatGidSubject.complete();
                }, function(e) {
                    t.wechatGidSubject.next(""), t.wechatGidSubject.complete();
                });
            }, e = i.__decorate([ o.Injectable(), i.__metadata("design:paramtypes", [ c.WxCloudApiService, p.UtilService, a.ErrorService, s.DefaultService ]) ], e);
        }();
        t.EntryRoomOpenGidService = g;
    },
    820: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.AppReportService = void 0;
        var i = r(0), n = r(1), o = r(98), a = r(33), s = r(13), c = r(24), u = r(6), p = r(79), l = function() {
            function e(e, t, r, i) {
                this.processMonitor = e, this.monitor = t, this.errorService = r, this.utils = i;
            }
            var t = e.prototype;
            return t.initOnMemoryWarning = function() {
                var e = this, t = 0;
                wx.onMemoryWarning(function(r) {
                    t++, e.errorService.customReportError({
                        frontErrorCode: 13e3,
                        extraInfo: {
                            warning: r,
                            warnTimeNum: t
                        }
                    }), e.monitor.sum("内存告警次数"), t > 10 && e.monitor.sum("内存告警次数大于10");
                });
            }, t.reportMonitor = function(e, t) {
                this.processMonitor.timeAppUtilLaunch(e.path, t, +new Date()), this.processMonitor.timeLaunch("appOnLaunch -> appOnLoad", e.path), 
                this.monitor.timeStart("开始 onLaunch -> 开始 onLoad 时间", 2001), this.monitor.timeStart("开始 onLaunch -> 开始 nav onLoad 时间", 2002), 
                this.monitor.timeStart("开始 onLaunch -> onLoad -> 结束 onShow 时间", 2003), e.path.includes("pages/homepage/customer-homepage/customer-homepage") && (this.monitor.timeStart("启动小程序到进入个人主页的时间"), 
                this.monitor.timeStart("启动小程序进入首页加载首屏时间"), this.monitor.timeStart("启动小程序进入主页加载首屏时间"));
            }, t.reportNewUser = function(e) {
                var t = e.httpClient, r = e.isFirstLogin, i = e.uid, n = e.inviteUid, o = e.scene, a = e.isOfficial, c = e.logHost, u = n && /\D+/.test(String(n));
                u && this.errorService.customReportError({
                    frontErrorCode: 5e3,
                    extraInfo: {
                        inviteUid: n
                    }
                }), u || r || t.get(c + "/registeredSource", {
                    uid: i,
                    scene: o,
                    isOfficial: a,
                    inviteUid: n
                }, s.skipToastAndMarkOptions).subscribe();
            }, t.appErrorReport = function(e) {
                p.wxlog.setFilterMsg("app_onError");
                var t = this.getCurrentPageUrlWithArgs();
                p.wxlog.error("app onError", e, t || "没有页面栈"), this.errorService.reportOnError(e);
            }, t.getCurrentPageUrlWithArgs = function() {
                var e = this.utils.getCurrentPageRouteInfo(), t = e.isSuc, r = e.route, i = e.params;
                return t ? i ? "/" + r + "?" + i : "/" + r : "";
            }, e = i.__decorate([ n.Injectable(), i.__metadata("design:paramtypes", [ o.PerformanceProcessMonitorService, a.PerformanceMonitorService, c.ErrorService, u.UtilService ]) ], e);
        }();
        t.AppReportService = l;
    },
    821: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.AncientAppService = void 0;
        var i = r(0), n = r(1), o = r(28), a = r(98), s = r(6), c = r(265), u = r(15), p = r(24), l = function() {
            function e(e, t, r, i, n) {
                this.apiService = e, this.processMonitor = t, this.utils = r, this.commonService = i, 
                this.errorService = n;
            }
            var t = e.prototype;
            return t.checkFlushCache = function() {
                var e = this;
                this.utils.getToken() && this.apiService.getFrontFlushCacheResultUsingGET().subscribe(function(t) {
                    var r;
                    if (!t.data) {
                        e.errorService.customReportError({
                            frontErrorCode: 5006
                        });
                        var i = e.getStorage("person_group_id");
                        e.utils.getGlobalData("homeDataInfo");
                        var n = getCurrentPages(), o = n[n.length - 1], a = null == o ? void 0 : o.route, s = null === (r = o) || void 0 === r ? void 0 : r.options;
                        if (a) {
                            var u = Number(s.groupId);
                            u && (s.groupId && u === Number(i) ? (s.groupId = e.getStorage("person_group_id"), 
                            e.utils.redirectTo(a, s)) : c.needShowErrorSceneList.includes(e.utils.getGlobalData("enterScene", !0) || 0) || e.commonService.goCustomerHome("redirectTo"));
                        } else e.commonService.goCustomerHome("redirectTo");
                    }
                });
            }, t.getStorage = function(e) {
                return getApp().getStorage(e);
            }, e = i.__decorate([ n.Injectable(), i.__metadata("design:paramtypes", [ o.DefaultService, a.PerformanceProcessMonitorService, s.UtilService, u.CommonService, p.ErrorService ]) ], e);
        }();
        t.AncientAppService = l;
    },
    822: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.AppFormatMixin = void 0;
        var i = r(0), n = r(1), o = r(79), a = r(83), s = r(22), c = function() {
            function e() {
                this.isFromTimeLines = !1, this.isOfficial = 0, this.isFirstTimeOnshow = !0;
            }
            var t = e.prototype;
            return t.initDataByOptions = function(e) {
                this.globalData.appid = a.currentAppId, this.globalData.isOnline = s.config.host.indexOf("mina") < 0, 
                this.globalData.chatType = e.chatType, this.globalData.initUrl = e.path, this.globalData.scene = e.scene, 
                this.isFromTimeLines = 1154 === e.scene, this.updateShareTraceId(e), this.globalData.tempMiniAppid = "wx974b793334f3667b", 
                this.globalData.enterSceneOnLaunch = e.scene;
            }, t.updateSceneInfoWhenOnShow = function(e, t) {
                var r = e.scene, i = e.chatType, n = e.path, o = e.query;
                t.setScene(r), this.globalData.enterScene = r, this.globalData.chatType = i, this.globalData.initUrl = "/" === n[0] ? n : "/" + n, 
                this.globalData.query = o, o && (this.globalData.inviteUid = o.inviteUid, this.globalData.qrSource = o.source), 
                this.isOfficial = "true" === o.isOfficial ? 1 : 0, this.isFirstTimeOnshow && (this.isFirstTimeOnshow = !1);
            }, t.updateSystemInfo = function() {
                var e = this;
                wx.getSystemInfo({
                    success: function(t) {
                        var r = t.system, i = void 0 === r ? "" : r, n = t.benchmarkLevel, a = t.brand, s = t.model, c = t.windowHeight, u = t.statusBarHeight, p = t.platform, l = i.toLowerCase().indexOf("ios") >= 0;
                        e.globalData.system = l ? "ios" : "android", e.globalData.benchmarkLevel = null != n ? n : -1, 
                        e.globalData.phoneType = a + " " + s, e.globalData.isIPhoneX = /iphone\s?(x|12|13|14|unknown)/i.test(s), 
                        e.globalData.isIPad = s.includes("iPad"), e.globalData.windowHeight = c, e.globalData.statusBarHeight = u, 
                        e.globalData.navHeight = u + 46;
                        var d = i.toLowerCase().indexOf("win") >= 0, h = i.toLowerCase().indexOf("macos") >= 0;
                        e.globalData.isPc = d || h, e.globalData.isDevTools = "devtools" === p, e.globalData.systemInfo = t, 
                        o.wxlog.info("2. app onLaunch end");
                    }
                });
            }, t.updateShareTraceId = function(e) {
                var t = e.query.shareTraceId;
                this.globalData.shareTraceId = t;
            }, e = i.__decorate([ n.MixinClass(), i.__metadata("design:paramtypes", []) ], e);
        }();
        t.AppFormatMixin = c;
    },
    823: function(e, t, r) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.PageNotFoundService = void 0;
        var i = r(0), n = r(1), o = r(14), a = r(24), s = r(15), c = r(6), u = {
            path: "/pro/pages/homepage/customer-homepage/customer-homepage",
            options: {
                navHome: 1,
                groupType: 30
            }
        }, p = [ "/index/index", "/zone/home/home", "/index/nav", "/community_group/home/index" ], l = function() {
            function e(e, t) {
                this.errorService = e, this.utils = t;
            }
            var t = e.prototype;
            return t.getRoutePage = function(e) {
                var t, r, n = (null == e ? void 0 : e.path) || "", a = !!(null === (r = null === (t = e) || void 0 === t ? void 0 : t.page) || void 0 === r ? void 0 : r.window), c = {
                    path: "pages/no-page-tips/no-page-tips",
                    options: i.__assign(i.__assign({}, e), {
                        isCorrectPage: a
                    })
                };
                if (p.some(function(e) {
                    return n.indexOf(e) > -1;
                }) || "index" === n) return u;
                if (this.reportError(e, a), !n) return c;
                var l = n.startsWith("/") ? n : "/" + n, d = Object.values(o.SEQ_TYPE_DETAIL_PATH).includes(l), h = Object.values(s.HomePath).includes(l), g = l.indexOf("seq-detail-v2") > -1;
                return d || h ? this.goMsgServiceBannedPage(e, a) : g ? this.goOriginDetailPage(e, a) : c;
            }, t.reportError = function(e, t) {
                try {
                    this.errorService.customReportError({
                        frontErrorCode: t ? 2004 : 2003,
                        extraInfo: i.__assign({}, e)
                    });
                } catch (e) {}
            }, t.goMsgServiceBannedPage = function(e, t) {
                var r = e || {}, n = r.path, o = r.query, a = void 0 === o ? {} : o, s = Object.keys(a).reduce(function(e, t) {
                    return e[t.replace(/amp;/, "")] = a[t], e;
                }, {});
                return this.utils.customReport({
                    functionName: "msgServicePageNotFound",
                    methodParams: {
                        res: e,
                        realPath: n
                    }
                }), {
                    path: n,
                    options: i.__assign(i.__assign({}, s), {
                        isCorrectPage: t
                    })
                };
            }, t.goOriginDetailPage = function(e, t) {
                var r = e || {}, n = r.path, o = r.query, a = void 0 === o ? {} : o, s = n.replace(/seq\-detail\-v2/, "seq-detail");
                return this.utils.customReport({
                    functionName: "seqDetailV2PageNotFound",
                    methodParams: {
                        res: e,
                        realPath: s
                    }
                }), {
                    path: s,
                    options: i.__assign(i.__assign({}, a), {
                        isCorrectPage: t
                    })
                };
            }, e = i.__decorate([ n.Injectable(), i.__metadata("design:paramtypes", [ a.ErrorService, c.UtilService ]) ], e);
        }();
        t.PageNotFoundService = l;
    }
}, [ [ 802, 0, 2, 1 ] ] ]));