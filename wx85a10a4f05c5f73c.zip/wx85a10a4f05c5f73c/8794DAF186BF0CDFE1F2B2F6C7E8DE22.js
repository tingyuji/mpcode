var n = require("883143E186BF0CDFEE572BE690F8DE22.js");

require("1AB8A93786BF0CDF7CDEC130B759DE22.js");

module.exports = {
    openid: function() {
        return new Promise(function(t, o) {
            n.call("router", "openid").then(function(n) {
                t(n);
            }).catch(function(n) {
                o(n);
            });
        });
    },
    uploadFormId: function(t) {
        return new Promise(function(o, e) {
            n.call("router", "uploadFormId", {
                formId: t
            }).then(function() {
                o({});
            }).catch(function(n) {
                e(n);
            });
        });
    },
    getFormId: function(t) {
        return new Promise(function(o, e) {
            n.call("router", "getFormId", {
                openId: t
            }).then(function(n) {
                o(n);
            }).catch(function(n) {
                e(n);
            });
        });
    },
    sendTplMsg: function(t) {
        return new Promise(function(o, e) {
            n.call("router", "sendTplMsg", {
                msgBody: t
            }).then(function(n) {
                o();
            }).catch(function(n) {
                e(n);
            });
        });
    },
    score: function(t) {
        return new Promise(function(o, e) {
            n.call("router", "score", t).then(function() {
                o({});
            }).catch(function(n) {
                e(n);
            });
        });
    },
    newThings: function() {
        return new Promise(function(t, o) {
            n.call("router", "newThings").then(function(n) {
                t(n);
            }).catch(function(n) {
                o(n);
            });
        });
    },
    ads: function(t) {
        return new Promise(function(o, e) {
            n.call("router", "ads", {
                type: t
            }).then(function(n) {
                o(n);
            }).catch(function(n) {
                e(n);
            });
        });
    },
    in2020hotAnimas: function() {
        return new Promise(function(t, o) {
            n.call("router", "in2020hot-anima").then(function(n) {
                t(n);
            }).catch(function(n) {
                o(n);
            });
        });
    },
    in2020hotDoFire: function(t) {
        return new Promise(function(o, e) {
            n.call("router", "in2020hot-fire", {
                name: t
            }).then(function(n) {
                o(n);
            }).catch(function(n) {
                e(n);
            });
        });
    }
};