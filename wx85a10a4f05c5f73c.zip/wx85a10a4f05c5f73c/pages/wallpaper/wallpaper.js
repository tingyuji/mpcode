var t = require("../../68D45E1786BF0CDF0EB2361085D8DE22.js"), a = getApp();

Page({
    data: {
        serialStr: "2021年02月",
        wallpaper: []
    },
    onLoad: function(t) {
        this._init();
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {},
    bindSerialChange: function(t) {
        var a = this.data.histories;
        this.setData({
            serialStr: a[t.detail.value].v
        }), this._wallpaper(a[t.detail.value].k);
    },
    onWallpaperTap: function(n) {
        a.playAppTapAudio();
        var e = this, o = n.currentTarget.dataset.id, i = n.currentTarget.dataset.costPoint, r = n.currentTarget.dataset.url, c = e.data.point;
        Number(i).valueOf() <= Number(c).valueOf() ? wx.showModal({
            title: "兑换",
            content: "确定使用" + i + "积分兑换?",
            confirmText: "确定",
            cancelText: "取消",
            success: function(a) {
                a.confirm && t.pointCost(i, "兑换壁纸[" + o + "]").then(function(t) {
                    wx.showModal({
                        title: "兑换成功",
                        content: "恭喜成功兑换壁纸",
                        confirmText: "查看图片",
                        cancelText: "取消",
                        success: function(t) {
                            t.confirm && wx.previewImage({
                                urls: [ r ]
                            });
                        }
                    }), e.setData({
                        point: t
                    });
                }).catch(function(t) {
                    wx.showToast({
                        icon: "none",
                        title: "兑换失败",
                        duration: 300
                    }), console.log(t);
                });
            }
        }) : wx.showModal({
            title: "积分不足",
            content: "需要" + i + "积分才能兑换",
            cancelColor: "#3f4757",
            confirmColor: "#ffce00",
            cancelText: "好的",
            confirmText: "看攻略",
            success: function(t) {
                t.confirm ? (a.playAppTapAudio(), wx.redirectTo({
                    url: "/pages/intro/intro"
                })) : t.cancel && a.playAppTapAudio();
            }
        });
    },
    _init: function() {
        var a = this;
        a._updateUserData();
        var n = a._getCurrentSerial();
        t.wallpaperHistory().then(function(t) {
            a.setData({
                histories: t
            });
            for (var e = !1, o = 0, i = t.length; o < i; o++) {
                var r = t[o];
                r.k == n && (e = !0, a.setData({
                    serialStr: r.v
                }));
            }
            e ? a._wallpaper(n) : a._wallpaper("202102");
        }).catch(function(t) {
            console.log(t);
        });
    },
    _updateUserData: function() {
        var a = this;
        t.userData().then(function(t) {
            a.setData({
                point: t.point
            });
        }).catch(function(t) {
            console.log(t);
        });
    },
    _wallpaper: function(a) {
        var n = this;
        t.wallpaperData(a).then(function(t) {
            for (var a = t, e = t.length, o = e % 3 == 0 ? e / 3 : Math.floor(e / 3 + 1), i = [], r = 0; r < o; r++) {
                var c = a.slice(3 * r, 3 * r + 3);
                i.push(c);
            }
            n.setData({
                wallpaper: i
            });
        }).catch(function(t) {
            console.log(t);
        });
    },
    _getCurrentSerial: function() {
        var t = new Date(), a = t.getFullYear(), n = t.getMonth() + 1;
        return a + "" + (n < 10 ? "0" + n : n);
    }
});