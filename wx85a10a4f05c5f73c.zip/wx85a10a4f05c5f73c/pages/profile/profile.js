var n = require("../../68D45E1786BF0CDF0EB2361085D8DE22.js");

Page({
    data: {},
    onLoad: function(n) {},
    onReady: function() {},
    onShow: function() {
        this._updateUserData();
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {},
    _updateUserData: function() {
        var o = this;
        n.userData().then(function(n) {
            o.setData({
                levelName: n.levelName,
                point: n.point
            });
        }).catch(function(n) {
            console.log(n);
        });
    }
});