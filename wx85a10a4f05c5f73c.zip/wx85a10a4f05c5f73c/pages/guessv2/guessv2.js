var t = require("../../@babel/runtime/helpers/defineProperty"), i = require("../../68D45E1786BF0CDF0EB2361085D8DE22.js"), n = require("../../934F6EA386BF0CDFF52906A43749DE22.js"), a = getApp(), o = null;

Page({
    timer: null,
    animationCountDown: null,
    adEvent: "",
    data: {
        timeLeft: 10,
        qCat: "",
        qMission: 0,
        qMissionCount: 0,
        qArray: [],
        qIndex: -1,
        qPic: null,
        qQ: null,
        qPicLoadOk: !1,
        qPicLoadError: !1,
        qAnswerDone: !1,
        qRecords: [],
        optionCss: [],
        pointTotal: 0,
        pointChangePic: 3,
        loading: !0
    },
    onLoad: function(t) {
        var i = wx.createAnimation({
            duration: 300,
            timingFunction: "ease-in"
        });
        this.animationCountDown = i;
        var n = t.cat;
        this._loadQuestion(n), this._loadUserPoint(), this.masker = this.selectComponent("#masker"), 
        this._initAd();
    },
    onReady: function() {},
    onShow: function() {
        this.data.pageHide && !this.data.qAnswerDone && this._resume(), this.setData({
            pageHide: !1
        });
    },
    onHide: function() {
        this._pause(), this.setData({
            pageHide: !0
        });
    },
    onUnload: function() {
        this._stop();
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {},
    picLoadOk: function(t) {
        this.setData({
            qPicLoadError: !1,
            qPicLoadOk: !0,
            loading: !1
        }), this._start(10);
    },
    picLoadError: function() {
        this.setData({
            qPicLoadError: !0,
            qPicLoadOk: !1
        }), this._stop();
    },
    reloadPic: function(t) {
        var i = this.data.qQ.anima.pics, n = this.data.qPic.idx, a = new Date(), o = i[n].pic + "?v=" + a.getTime();
        this.setData({
            qPic: {
                url: o,
                idx: n
            },
            timeLeft: 10
        });
    },
    onOptionTap: function(i) {
        a.playAppTapAudio();
        var n, o, e = this.data.qCat, s = this.data.qArray, r = this.data.qIndex, c = this.data.qQ, d = c.rightAnswerIndex, u = i.currentTarget.dataset.option_idx, h = 10 - this.data.timeLeft, p = u == d, l = "optionCss[" + r + "][" + u + "]", f = "optionCss[" + r + "][" + d + "]";
        p ? this.setData((t(n = {}, l, "option-select-right"), t(n, "qAnswerDone", !0), 
        n)) : this.setData((t(o = {}, l, "shake option-select-wrong"), t(o, f, ""), t(o, "qAnswerDone", !0), 
        o));
        this._stop(), this._doNext(e, s, r, c, u, h, p);
    },
    onGoBackTap: function(t) {
        a.playAppTapAudio(), wx.navigateBack();
    },
    onClearTap: function(t) {
        var i = this.data.qCat;
        a.playAppTapAudio(), a.cacheMission(i, 0, 0), wx.navigateBack();
    },
    onChangePicTap: function(t) {
        a.playAppTapAudio();
        var i = this;
        i.setData({
            changingPic: !0
        }), i._pause(), i.data.pointTotal >= i.data.pointChangePic ? i._pointCost().then(function(t) {
            i.setData({
                pointTotal: t
            }), i._nextPic();
        }).catch(function(t) {
            i._showRewardedVideoAd(o, "changPic");
        }) : i._showRewardedVideoAd(o, "changPic");
    },
    onOverTap: function(t) {
        a.playAppTapAudio(), wx.navigateBack();
    },
    onGameOverTap: function(t) {
        a.playAppTapAudio();
        this.masker.hide(), wx.navigateBack();
    },
    onRetryTap: function(t) {
        a.playAppTapAudio();
        this.setData({
            retrying: !0
        }), this._pause(), this._showRewardedVideoAd(o, "retry");
    },
    onNextMisssionTap: function(t) {
        a.playAppTapAudio();
        var i = this.data.qCat;
        this.masker.hide(), this.setData({
            timeLeft: 10,
            qCat: "",
            qArray: [],
            qIndex: -1,
            qPic: null,
            qQ: null,
            qPicLoadOk: !1,
            qPicLoadError: !1,
            qAnswerDone: !1,
            qRecords: [],
            optionCss: []
        }), this._loadQuestion(i);
    },
    _loadQuestion: function(t) {
        var n = this, o = a.getLastMission(t), e = 0;
        o && (e = 0 == o.status ? o.mission : o.mission + 1), i.missionData(t, e).then(function(i) {
            var o = i.questions || [];
            e >= i.missionCount ? wx.showModal({
                title: "提示",
                content: "你已经玩过所有关卡，重新来过？",
                cancelColor: "#3f4757",
                confirmColor: "#ffce00",
                cancelText: "取消",
                confirmText: "重来",
                success: function(i) {
                    i.confirm ? (a.playAppTapAudio(), a.cacheMission(t, 0, 0), n._loadQuestion(t)) : i.cancel && (a.playAppTapAudio(), 
                    wx.navigateBack());
                }
            }) : (n.setData({
                qCat: t,
                qArray: o,
                qMission: i.mission,
                qMissionCount: i.missionCount
            }), n._nextQuestion(n.data.qIndex, n.data.qArray));
        }).catch(function(t) {
            console.log(t);
        });
    },
    _loadUserPoint: function() {
        var t = this;
        i.userData().then(function(i) {
            t.setData({
                pointTotal: i.point
            });
        }).catch(function(i) {
            t.setData({
                pointTotal: 0
            });
        });
    },
    _doNext: function(t, i, o, e, s, r, c) {
        var d = this;
        d._record(t, e, s, r);
        var u = n.getScore(d.data.qRecords);
        d.setData({
            score: u,
            passed: u.correctCount == i.length
        }), o == i.length - 1 ? (setTimeout(function() {
            d.masker.show();
        }, 300), d.data.passed ? d._missionPass() : d._missionFail()) : c ? (a.playCorrectAudio(), 
        setTimeout(function() {
            d._nextQuestion(o, i);
        }, 800)) : (a.playWrongAudio(), setTimeout(function() {
            d.masker.show();
        }, 300), d._missionFail());
    },
    _nextQuestion: function(t, i) {
        var n = t + 1;
        if (i && i.length && n != i.length) {
            var a = i[n], o = this._randomPic(a.anima.pics);
            this._stop(), this.setData({
                qIndex: n,
                qPic: o,
                qQ: a,
                qPicLoadOk: !1,
                qPicLoadError: !1,
                qAnswerDone: !1,
                animationCountDown: null,
                timeLeft: 10,
                changingPic: !1,
                loading: !1
            });
        }
    },
    _animationCountDown: function() {
        this.animationCountDown.scale(2, 2).opacity(0).step().scale(1, 1).opacity(1).step({
            duration: 0
        }), this.setData({
            animationCountDown: this.animationCountDown.export()
        });
    },
    _countdown: function() {
        var t = this.data.timeLeft;
        t <= 0 ? this._timeup() : this._start(t);
    },
    _timeup: function() {
        var t = this.data.qCat, i = this.data.qArray, n = this.data.qIndex, a = this.data.qQ;
        this.setData({
            qAnswerDone: !0
        }), this._stop(), this._doNext(t, i, n, a, -1, 10, !1);
    },
    _start: function(t) {
        var i = this;
        if (!(t <= 0)) {
            i.setData({
                timeLeft: t
            });
            var n = t - 1;
            i.timer = setTimeout(function() {
                i.setData({
                    timeLeft: n
                }), n <= 5 && n > 0 && (i._animationCountDown(), a.playCountdownAudio()), i._countdown();
            }, 1e3);
        }
    },
    _pause: function() {
        clearTimeout(this.timer), this.timer = null;
    },
    _resume: function() {
        var t = this.data.timeLeft;
        this._start(t);
    },
    _stop: function() {
        clearTimeout(this.timer), this.timer = null;
    },
    _nextPic: function() {
        var t = this.data.qQ.anima.pics, i = (this.data.qPic.idx + 1) % t.length, n = t[i].pic;
        this.setData({
            qPic: {
                url: n,
                idx: i
            },
            timeLeft: 10,
            changingPic: !1
        });
    },
    _randomPic: function(t) {
        var i = Math.floor(Math.random() * t.length);
        return {
            url: t[i].pic,
            idx: i
        };
    },
    _record: function(t, i, n, a) {
        var o = {}, e = i.rightAnswerIndex == n;
        o.question = i, o.correct = e, o.myAnswer = n, o.correctAnswer = i.rightAnswerIndex, 
        o.elapsedTime = a;
        var s = this.data.qRecords || [];
        s.push(o), this.setData({
            qRecords: s
        });
    },
    _missionPass: function() {
        a.playCorrectAudio();
        var t = this;
        i.missionPass(t.data.qCat).then(function(i) {
            console.log("过关数据上报成功, 积分：" + i), t.setData({
                pointTotal: i
            });
        }).catch(function(t) {
            console.log(t);
        }), a.cacheMission(t.data.qCat, t.data.qMission, 1);
    },
    _missionFail: function() {
        a.playWrongAudio();
        a.cacheMission(this.data.qCat, this.data.qMission, 0);
    },
    _pointCost: function() {
        return new Promise(function(t, n) {
            i.pointCost(3, "使用3积分换张图片").then(function(i) {
                console.log("使用3积分换张图片, 还剩积分" + i), t(i);
            }).catch(function(t) {
                console.log(t), n(0);
            });
        });
    },
    _initAd: function() {
        var i = this, n = {
            changPic: function() {
                i._nextPic();
            },
            retry: function() {
                var n;
                i.masker.hide();
                var a = "optionCss[" + i.data.qIndex + "]";
                i.setData((t(n = {}, a, [ "", "", "", "" ]), t(n, "qAnswerDone", !1), n)), i._start(10);
            }
        }, a = {
            changPic: function() {
                i._resume();
            },
            retry: function() {}
        }, e = {
            changPic: function() {
                i.setData({
                    changingPic: !1
                });
            },
            retry: function() {
                i.setData({
                    retrying: !1
                });
            }
        };
        o = i._initRewardedVideoAd(n, a, e);
    },
    _initRewardedVideoAd: function(t, i, n) {
        var a = this, o = null;
        return wx.createRewardedVideoAd && ((o = wx.createRewardedVideoAd({
            adUnitId: "adunit-bd3b9ee9df9d9720"
        })).onLoad(function() {}), o.onError(function(t) {
            console.log(t), a.setData({
                rewardedVideoAdError: !0
            });
        }), o.onClose(function(o) {
            var e = a.adEvent;
            o && o.isEnded || void 0 === o ? t[e] && t[e]() : i[e] && i[e](), n[e] && n[e]();
        })), o;
    },
    _showRewardedVideoAd: function(t, i) {
        t && (this.adEvent = i, t.show().catch(function() {
            t.load().then(function() {
                return t.show();
            }).catch(function(t) {
                console.error(t), console.log("激励视频 广告显示失败");
            });
        }));
    }
});