var n = require("../../68D45E1786BF0CDF0EB2361085D8DE22.js"), t = getApp(), o = null;

Page({
    data: {
        unlockStr: ""
    },
    onLoad: function(t) {
        var o = this, e = wx.createAnimation({
            delay: 300,
            duration: 500,
            timingFunction: "ease"
        });
        wx.createAnimation({
            duration: 300,
            timingFunction: "ease-in"
        });
        o.animation3xPoint = e, this.animate("#img-3xpoint", [ {
            opacity: 0,
            translateY: -100
        } ], 0), setTimeout(function() {
            o.animate("#img-3xpoint", [ {
                opacity: 0,
                translateY: -50
            }, {
                opacity: .5,
                translateY: -30
            }, {
                opacity: 1,
                translateY: 0
            }, {
                opacity: 1,
                translateY: -10
            }, {
                opacity: 1,
                translateY: 0
            }, {
                opacity: 1,
                translateY: -5
            }, {
                opacity: 1,
                translateY: 0
            }, {
                opacity: 1,
                translateY: -3
            }, {
                opacity: 1,
                translateY: 0
            } ], 1e3, function() {
                o.clearAnimation("#img-3xpoint");
            }.bind(o));
        }, 1e3), o._initAd3xPoint(function() {
            n.pointGet(3, "首页看广告3倍积分").then(function(n) {
                o.setData({
                    point: n
                });
            }).catch(function(n) {
                console.log(n);
            });
        });
    },
    onShow: function() {
        this._updateUserData(), this.setData({
            missions: t.getLastMissionByGroup(),
            todayKnowlegeDone: t.isToadyKnowlegeDone(),
            todayCheckInDone: t.isCheckInDone()
        });
    },
    onShareAppMessage: function() {
        return {
            title: "来挑战猜个动画",
            path: "/pages/home/home",
            success: function(n) {
                console.log("转发成功");
            },
            fail: function(n) {
                console.log("转发失败");
            }
        };
    },
    onCallRankTap: function() {
        t.playAppTapAudio(), wx.navigateTo({
            url: "/pages/rank/rank"
        });
    },
    onVsTap: function() {
        t.playAppTapAudio();
    },
    onHotTap: function() {
        t.playAppTapAudio(), wx.navigateTo({
            url: "/pages/new/in2020"
        });
    },
    onPlayRuleTap: function() {
        t.playAppTapAudio(), wx.navigateTo({
            url: "/pages/intro/intro"
        });
    },
    onPlayTap: function(n) {
        t.playAppTapAudio();
        var o = n.currentTarget.dataset.cat, e = n.currentTarget.dataset.unlockPoint, a = Number(e).valueOf(), i = Number(this.data.point).valueOf(), c = "";
        switch (o) {
          case "random":
            return void wx.redirectTo({
                url: "/pages/guessv2/guessv2?cat=" + o
            });

          case "knowledge":
            return void wx.navigateTo({
                url: "/pages/guessv2-text/guessv2?cat=" + o
            });

          case "picture":
            return void wx.navigateTo({
                url: "/pages/wallpaper/wallpaper"
            });

          case "mvoice":
            c = "/pages/guessv2-audio/guessv2?cat=" + o;
            break;

          default:
            c = "/pages/guessv2/guessv2?cat=" + o;
        }
        this.data.unlock["" + o] || 0 == a ? wx.navigateTo({
            url: c
        }) : a > i ? this._morePointTip(a) : this._usePoint(a, o);
    },
    getUserInfo: function(n) {
        var o = n.currentTarget.dataset.source;
        if (console.log("%o", n.detail), console.log(o), "getUserInfo:fail auth deny" !== n.detail.errMsg) {
            var e = n.detail.userInfo;
            t.globalData.userInfo = e, wx.setStorageSync("userInfo", e), "checkIn" === o && (console.log("checkIn trigger"), 
            this.checkIn(e));
        }
    },
    checkIn: function(o) {
        var e = this;
        t.playAppTapAudio(), e.setData({
            checkInProcessing: !0
        }), t.isCheckInDone() ? e.setData({
            checkInProcessing: !1
        }) : n.checkin(o, "首页签到1积分").then(function(n) {
            e.setData({
                point: n,
                todayCheckInDone: !0,
                checkInProcessing: !1
            }), t.checkIn();
        }).catch(function(n) {
            console.log(n), e.setData({
                checkInProcessing: !1
            });
        });
    },
    get3xPoint: function() {
        t.playAppTapAudio(), this._showAd(o);
    },
    onProfileTap: function() {
        t.playAppTapAudio();
    },
    _updateUserData: function() {
        var t = this;
        n.userData().then(function(n) {
            for (var o = n.unlock, e = {}, a = 0, i = o.length; a < i; a++) e[o[a]] = !0;
            t.setData({
                levelName: n.levelName,
                point: n.point,
                unlock: e
            });
        }).catch(function(n) {
            throw console.log(n), n;
        });
    },
    _morePointTip: function(n) {
        var o = this;
        wx.showModal({
            title: "解锁",
            content: "需要" + n + "积分才能解锁哦",
            cancelColor: "#3f4757",
            confirmColor: "#ffce00",
            cancelText: "好的",
            confirmText: "看攻略",
            success: function(n) {
                n.confirm ? o.onPlayRuleTap() : n.cancel && t.playAppTapAudio();
            }
        });
    },
    _usePoint: function(t, o) {
        var e = this;
        wx.showModal({
            title: "解锁",
            content: "使用" + t + "积分,解锁此关卡吗？",
            confirmText: "确定",
            success: function(t) {
                t.confirm && n.missionUnlock(o).then(function(n) {
                    e._updateUserData();
                }).catch(function(n) {
                    console.log(n);
                });
            }
        });
    },
    _initAd3xPoint: function(n, t, e) {
        wx.createRewardedVideoAd && ((o = wx.createRewardedVideoAd({
            adUnitId: "adunit-55b9e1e213e5dfe1"
        })).onLoad(function() {}), o.onError(function(n) {}), o.onClose(function(o) {
            o && o.isEnded || void 0 === o ? n && n() : t && t(), e && e();
        }));
    },
    _showAd: function(n) {
        n && n.show().catch(function() {
            n.load().then(function() {
                return n.show();
            }).catch(function(n) {
                console.error(n), console.log("激励视频 广告显示失败");
            });
        });
    }
});