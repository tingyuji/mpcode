var n = require("../../@babel/runtime/helpers/defineProperty"), o = require("../../68D45E1786BF0CDF0EB2361085D8DE22.js"), t = (require("../../1AB8A93786BF0CDF7CDEC130B759DE22.js"), 
require("../../1751F2B286BF0CDF71379AB56319DE22.js"), getApp()), i = null;

Page({
    data: {
        qCat: "",
        qQ: null,
        qPicLoadOk: !1,
        qPicLoadError: !1,
        qAnswerDone: !1,
        optionCss: []
    },
    onLoad: function(n) {
        var o = this, t = wx.createAnimation({
            duration: 300,
            timingFunction: "ease-in"
        });
        o.animationPic = t;
        var i = n.cat;
        o._loadQuestion(i), o.masker = this.selectComponent("#masker"), o._initAd(function() {
            o._uploadData();
        }, function() {}, function() {
            o.masker.hide(), wx.navigateBack();
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {},
    picLoadOk: function(n) {
        this.setData({
            qPicLoadError: !1,
            qPicLoadOk: !0
        });
    },
    picLoadError: function() {
        this.setData({
            qPicLoadError: !0,
            qPicLoadOk: !1
        });
    },
    reloadPic: function(n) {
        this.setData({
            qQ: this.data.qQ
        });
    },
    onOptionTap: function(o) {
        t.playAppTapAudio();
        var i, a, e = this.data.qQ.rightAnswerIndex, s = o.currentTarget.dataset.option_idx, c = "optionCss[" + s + "]", r = "optionCss[" + e + "]";
        s == e ? this.setData((n(i = {}, c, "option-select-right"), n(i, "qAnswerDone", !0), 
        n(i, "passed", !0), i)) : this.setData((n(a = {}, c, "shake option-select-wrong"), 
        n(a, r, ""), n(a, "qAnswerDone", !0), n(a, "passed", !1), a));
        this.masker.show(), this._uploadData(), this._todayIsDone();
    },
    onGoBackTap: function(n) {
        t.playAppTapAudio(), wx.navigateBack();
    },
    onMorePointTap: function(n) {
        t.playAppTapAudio();
        this._showAd();
    },
    onOverTap: function(n) {
        t.playAppTapAudio();
        wx.navigateBack();
    },
    _init: function() {
        this.setData({
            qCat: "",
            qQ: null,
            qPicLoadOk: !1,
            qPicLoadError: !1,
            qAnswerDone: !1,
            optionCss: []
        });
    },
    _loadQuestion: function(n) {
        var t = this;
        o.question(n).then(function(o) {
            var i = o || [];
            t.setData({
                qCat: n,
                qQ: i[0]
            });
        });
    },
    _animationPic: function() {
        this.animationPic.scale(2, 2).opacity(0).step().scale(1, 1).opacity(1).step({
            duration: 0
        }), this.setData({
            animationPic: this.animationPic.export()
        });
    },
    _uploadData: function() {
        this.data.passed && o.missionPass(this.data.qCat).then(function(n) {
            console.log("过关数据上报成功," + n);
        }).catch(function(n) {
            console.log(n);
        });
    },
    _initAd: function(n, o, t) {
        wx.createRewardedVideoAd && ((i = wx.createRewardedVideoAd({
            adUnitId: "adunit-df99903fd510c974"
        })).onLoad(function() {}), i.onError(function(n) {}), i.onClose(function(i) {
            i && i.isEnded || void 0 === i ? n() : o(), t();
        }));
    },
    _showAd: function() {
        i && i.show().catch(function() {
            i.load().then(function() {
                return i.show();
            }).catch(function(n) {
                console.error(n), console.log("激励视频 广告显示失败");
            });
        });
    },
    _todayIsDone: function() {
        t.cacheTodayKnowlegeIsDone();
    }
});