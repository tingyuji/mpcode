var t = require("../../@babel/runtime/helpers/defineProperty"), n = require("../../68D45E1786BF0CDF0EB2361085D8DE22.js"), o = require("../../934F6EA386BF0CDFF52906A43749DE22.js"), a = getApp(), i = null;

Page({
    data: {
        qCat: "",
        qArray: [],
        qIndex: -1,
        qQ: null,
        qAnswerDone: !1,
        qRecords: [],
        optionCss: [],
        pointTotal: 0,
        pointReplay: 3
    },
    onLoad: function(t) {
        this._init();
        var n = t.cat;
        this._loadQuestion(n), this._loadUserPoint(), this.masker = this.selectComponent("#masker");
    },
    onReady: function() {},
    onShow: function() {
        this.data.pageHide && !this.data.qAnswerDone && this._resumeMusic(), this.setData({
            pageHide: !1
        });
    },
    onHide: function() {
        this._pauseMusic(), this.setData({
            pageHide: !0
        });
    },
    onUnload: function() {
        this._stopMusic();
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {},
    onOptionTap: function(n) {
        a.playAppTapAudio();
        var o, i, e = this.data.qCat, s = this.data.qArray, r = this.data.qIndex, c = this.data.qQ, u = c.rightAnswerIndex, h = n.currentTarget.dataset.option_idx, d = "optionCss[" + r + "][" + h + "]", p = "optionCss[" + r + "][" + u + "]";
        h == u ? this.setData((t(o = {}, d, "option-select-right"), t(o, "qAnswerDone", !0), 
        o)) : this.setData((t(i = {}, d, "shake option-select-wrong"), t(i, p, ""), t(i, "qAnswerDone", !0), 
        i));
        this._stopMusic(), this._doNext(e, s, r, c, h);
    },
    onGoBackTap: function(t) {
        a.playAppTapAudio(), wx.navigateBack();
    },
    onReListenTap: function(t) {
        a.playAppTapAudio();
        var n = this;
        n.data.pointTotal >= n.data.pointReplay ? n._pointCost().then(function(t) {
            n.setData({
                pointTotal: t
            }), n._startMusic();
        }).catch(function(t) {}) : wx.showToast({
            icon: "none",
            title: "积分不足",
            duration: 800
        });
    },
    onOverTap: function(t) {
        a.playAppTapAudio(), wx.navigateBack();
    },
    _init: function() {
        this.setData({
            qCat: "",
            qArray: [],
            qIndex: -1,
            qQ: null,
            qAnswerDone: !1,
            qRecords: [],
            optionCss: []
        }), this._initInnerAudioContext();
    },
    _initInnerAudioContext: function() {
        var t = this;
        (i = wx.createInnerAudioContext()).onCanplay(function() {
            t.setData({
                showWave: !0
            });
        }), i.onPlay(function() {
            t.setData({
                showWave: !0
            });
        }), i.onWaiting(function() {
            t.setData({
                showWave: !1
            });
        }), i.onStop(function() {
            t.setData({
                showWave: !1
            });
        }), i.onEnded(function() {
            t.setData({
                showWave: !1
            });
        }), i.onError(function(n) {
            console.log("%o", n), t.setData({
                showWave: !1
            });
        });
    },
    _loadQuestion: function(t) {
        var o = this;
        console.log(t), n.question(t).then(function(n) {
            var a = n || [];
            o.setData({
                qCat: t,
                qArray: a
            }), o._nextQuestion(o.data.qIndex, o.data.qArray);
        });
    },
    _doNext: function(t, n, a, i, e) {
        var s = this;
        if (s._record(t, i, e, 0), a == n.length - 1) {
            wx.showToast({
                title: "答完了"
            });
            var r = o.getScore(s.data.qRecords);
            s.setData({
                score: r,
                passed: r.correctCount == n.length
            }), setTimeout(function() {
                s.masker.show();
            }, 500), s._missionPass();
        } else setTimeout(function() {
            s._nextQuestion(a, n);
        }, 500);
    },
    _nextQuestion: function(t, n) {
        var o = t + 1;
        if (n && n.length && o != n.length) {
            var a = n[o];
            this.setData({
                qIndex: o,
                qQ: a,
                qAnswerDone: !1
            }), this._startMusic();
        }
    },
    _pauseMusic: function() {
        this.data.qQ.anima.isAudio && i.pause();
    },
    _stopMusic: function() {
        this.data.qQ.anima.isAudio && i.stop();
    },
    _startMusic: function() {
        var t = this.data.qQ.anima;
        t.isAudio && (i.stop(), i.src = t.audio, i.play());
    },
    _resumeMusic: function() {
        this.data.qQ.anima.isAudio && i.play();
    },
    _record: function(t, n, o, a) {
        var i = {}, e = n.rightAnswerIndex == o;
        i.question = n, i.correct = e, i.myAnswer = o, i.correctAnswer = n.rightAnswerIndex, 
        i.elapsedTime = a;
        var s = this.data.qRecords || [];
        s.push(i), this.setData({
            qRecords: s
        });
    },
    _missionPass: function() {
        this.data.passed && n.missionPass(this.data.qCat).then(function(t) {
            console.log("过关数据上报成功," + t);
        }).catch(function(t) {
            console.log(t);
        });
    },
    _loadUserPoint: function() {
        var t = this;
        n.userData().then(function(n) {
            t.setData({
                pointTotal: n.point
            });
        }).catch(function(n) {
            t.setData({
                pointTotal: 0
            });
        });
    },
    _pointCost: function() {
        return new Promise(function(t, o) {
            n.pointCost(3, "使用3积分再听一次").then(function(n) {
                console.log("使用3积分再听一次, 还剩积分" + n), t(n);
            }).catch(function(t) {
                console.log(t), o(0);
            });
        });
    }
});