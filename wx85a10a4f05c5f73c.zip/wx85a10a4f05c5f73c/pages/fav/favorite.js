var t = require("../../@babel/runtime/helpers/defineProperty"), a = getApp();

Page({
    data: {
        favorites: [],
        currentIndex: -1
    },
    onLoad: function(t) {
        this._init();
    },
    onReady: function() {
        var t = this;
        t.bam = wx.getBackgroundAudioManager(), t.bam.onEnded(function() {
            t._stopAll();
        }), t.bam.onPause(function() {
            t.currentTime = t.bam.currentTime;
        });
    },
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {},
    onItemLongTap: function(t) {
        var n = this, i = t.currentTarget.dataset.index;
        n.data.favorites;
        wx.showActionSheet({
            itemList: [ "删除" ],
            success: function(t) {
                0 == t.tapIndex && (a.removeFavAudio(i), n._init());
            }
        });
    },
    onAudioPlayTap: function(t) {
        var a = this.data.currentIndex, n = t.currentTarget.dataset.index;
        console.log(a, n), -1 === a || a == n || this._stopCurrent(), this._start(n);
    },
    _init: function() {
        var t = this;
        wx.getStorage({
            key: "favAudios",
            success: function(a) {
                t.setData({
                    favorites: a.data || []
                });
            }
        });
    },
    _stopAll: function() {
        for (var t = this.data.favorites, a = 0, n = t.length; a < n; a++) t[a].playing = !1;
        this.setData({
            favorites: t,
            currentIndex: -1
        });
    },
    _stopCurrent: function() {
        var a = this.data.favorites, n = this.data.currentIndex;
        if (n > -1) {
            var i;
            a[n].playing;
            this.bam.stop();
            var e = "favorites[" + n + "].playing";
            this.setData((t(i = {}, e, !1), t(i, "currentIndex", -1), i));
        }
    },
    _start: function(a) {
        var n = this.data.favorites;
        console.log(n);
        var i = this.data.currentIndex, e = n[a], r = e.playing, s = a;
        -1 === i ? (this.bam.src = e.anima.audio, this.bam.title = e.anima.audioName, this.currentTime = 0) : i == a ? r ? this.bam.pause() : this.currentTime > 0 ? (this.bam.seek(this.currentTime), 
        this.bam.play()) : this.bam.play() : (this.bam.src = e.anima.audio, this.bam.title = e.anima.audioName, 
        this.currentTime = 0), this.setData({
            currentIndex: s
        });
        var o = "favorites[" + a + "].playing";
        this.setData(t({}, o, !r));
    }
});