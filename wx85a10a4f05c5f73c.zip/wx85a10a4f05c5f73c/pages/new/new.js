var t = require("../../8794DAF186BF0CDFE1F2B2F6C7E8DE22.js"), n = require("../../3552B01486BF0CDF5334D8137E39DE22.js"), e = getApp();

Page({
    data: {
        recList: [],
        showModal: !1,
        videoSrc: null,
        quotes: n.quotes
    },
    onLoad: function(t) {},
    onReady: function() {
        this.videoContext = wx.createVideoContext("myVideo"), this.randomWords(), this.initPage();
    },
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {
        this.initPage(), setTimeout(function() {
            wx.stopPullDownRefresh();
        }, 2e3);
    },
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return {
            title: "新动画，热门动画推荐",
            path: "/pages/new/new",
            success: function(t) {
                console.log("转发成功");
            },
            fail: function(t) {
                console.log("转发失败");
            }
        };
    },
    onImageViewTap: function(t) {
        for (var n = t.currentTarget.dataset.src, e = this.data.recList, o = [], i = 0, a = e.length; i < a; i++) o.push(e[i].image);
        wx.previewImage({
            current: n,
            urls: o
        });
    },
    go2020: function(t) {
        wx.navigateTo({
            url: "/pages/new/in2020"
        });
    },
    onWatchVideoTap: function(t) {
        t.currentTarget.dataset.src;
        var n = t.currentTarget.dataset.id;
        wx.navigateTo({
            url: "/pages/acg/video-detail?id=" + n
        });
    },
    onVideoDialogCloseTap: function(t) {
        var n = this;
        t.currentTarget.dataset.code;
        setTimeout(function() {
            n.videoContext.pause();
        }, 300), n.setData({
            showModal: !1,
            videoSrc: ""
        });
    },
    onAnimationFinish: function(t) {
        this.randomWords();
    },
    initPage: function() {
        var t = this;
        t.getRecList().then(function(n) {
            t.setData({
                recList: n || []
            }), wx.hideNavigationBarLoading();
        });
    },
    getRecList: function() {
        return wx.showLoading({
            title: "加载中"
        }), new Promise(function(n, e) {
            t.newThings().then(function(t) {
                wx.hideLoading(), n(t);
            }).catch(function(t) {
                n([]);
            });
        });
    },
    randomWords: function() {
        var t = this.data.quotes, n = e.getRandomNum(0, t.length - 1);
        this.setData({
            words: t[n].words
        });
    }
});