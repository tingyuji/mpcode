var t = require("../../@babel/runtime/helpers/defineProperty"), n = require("../../68D45E1786BF0CDF0EB2361085D8DE22.js"), a = require("../../FDA6F48286BF0CDF9BC09C85AB29DE22.js");

Page({
    data: {
        tabs: [ "国漫", "日漫", "欧美" ],
        currentTab: 0,
        favoritesCn: [],
        favoritesJa: [],
        favoritesWe: []
    },
    onLoad: function(t) {
        this._init();
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {},
    contentChange: function(t) {
        var n = t.detail.current;
        this.setData({
            currentTab: n
        });
    },
    onTabItemTap: function(t) {
        var n = t.currentTarget.dataset.idx;
        this.data.currentTab != n && this.setData({
            currentTab: n
        });
    },
    onHotTap: function(a) {
        var o, e = a.currentTarget.dataset.index, r = this.data.currentTab, i = [];
        0 == r ? i = this.data.favoritesCn : 1 == r ? i = this.data.favoritesJa : 2 == r && (i = this.data.favoritesWe);
        var h = i[e];
        if (h.dohot) wx.showToast({
            title: "已加火了",
            icon: "none"
        }); else {
            var s = "", f = "";
            0 == r ? (s = "favoritesCn[" + e + "].dohot", f = "favoritesCn[" + e + "].hot") : 1 == r ? (s = "favoritesJa[" + e + "].dohot", 
            f = "favoritesJa[" + e + "].hot") : 2 == r && (s = "favoritesWe[" + e + "].dohot", 
            f = "favoritesWe[" + e + "].hot"), this.setData((t(o = {}, s, !0), t(o, f, h.hot + 1), 
            o)), n.hotAnimaFire(h.name).then(function(t) {});
        }
    },
    _init: function() {
        var t = this, o = a.favin[0], e = a.favin[1], r = a.favin[2];
        wx.showLoading({
            title: "加载中"
        }), n.hotAnimas().then(function(n) {
            for (var a = 0, i = o.length; a < i; a++) for (var h = o[a].name, s = 0, f = n.length; s < f; s++) h == n[s].name && (o[a].hot = n[s].hot);
            for (var u = 0, v = e.length; u < v; u++) for (var c = e[u].name, d = 0, l = n.length; d < l; d++) c == n[d].name && (e[u].hot = n[d].hot);
            for (var g = 0, m = r.length; g < m; g++) for (var T = r[g].name, b = 0, p = n.length; b < p; b++) T == n[b].name && (r[g].hot = n[b].hot);
            t.setData({
                favoritesCn: o.sort(function(t, n) {
                    return n.hot - t.hot;
                }),
                favoritesJa: e.sort(function(t, n) {
                    return n.hot - t.hot;
                }),
                favoritesWe: r.sort(function(t, n) {
                    return n.hot - t.hot;
                }),
                hots: n
            }, function() {
                wx.hideLoading();
            });
        });
    }
});