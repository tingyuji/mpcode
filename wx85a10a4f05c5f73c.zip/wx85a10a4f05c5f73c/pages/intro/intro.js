Page({
    data: {
        rules: {
            add: {
                randomPassed: 1,
                knowledgePassed: 1,
                otherPassed: 1,
                checkin: 1,
                ad: 3
            },
            reduce: {
                unlock: 10,
                help: 3
            }
        }
    },
    onLoad: function(n) {},
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});