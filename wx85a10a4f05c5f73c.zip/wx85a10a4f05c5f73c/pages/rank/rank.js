var n = require("../../68D45E1786BF0CDF0EB2361085D8DE22.js");

getApp();

Page({
    pageIndex: 0,
    data: {
        myscore: {},
        list: []
    },
    onLoad: function(o) {
        var e = this;
        wx.showLoading({
            title: "加载中"
        }), n.myrank().then(function(n) {
            e.setData({
                myRankNum: n.myRankNum,
                myBestLevel: n.myBestLevel,
                myBestLevelName: n.myBestLevelName,
                myUnlock: n.myUnlock
            });
        }).catch(function(n) {
            wx.hideLoading();
        }), n.rank().then(function(n) {
            e.setData({
                list: n
            }), wx.hideLoading();
        }).catch(function(n) {
            wx.hideLoading();
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onScrollToLower: function(n) {}
});