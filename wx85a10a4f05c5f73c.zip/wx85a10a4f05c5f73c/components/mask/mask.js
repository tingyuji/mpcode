Component({
    options: {
        multipleSlots: !0
    },
    properties: {
        showAct: {
            type: Boolean,
            value: !1
        },
        isModal: {
            type: Boolean,
            value: !1
        },
        bg: {
            type: String,
            value: "white"
        }
    },
    data: {
        show: !1
    },
    methods: {
        show: function() {
            this.setData({
                show: !0
            });
        },
        hide: function() {
            this.setData({
                show: !1
            });
        },
        _onMaskTap: function() {
            this.data.isModal || this.hide();
        },
        _onTouchMove: function() {}
    }
});