require("@babel/runtime/helpers/Arrayincludes.js");

var e = function(e) {
    return (e = e.toString())[1] ? e : "0" + e;
};

module.exports = {
    formatDate: function(t) {
        return [ t.getFullYear(), t.getMonth() + 1, t.getDate() ].map(e).join("/");
    },
    formatTime: function(t) {
        var n = t.getFullYear(), r = t.getMonth() + 1, u = t.getDate(), o = t.getHours(), a = t.getMinutes(), i = t.getSeconds();
        return [ n, r, u ].map(e).join("/") + " " + [ o, a, i ].map(e).join(":");
    },
    randomInt: function(e, t) {
        return e = Math.ceil(e), t = Math.floor(t), Math.floor(Math.random() * (t - e)) + e;
    },
    season: function() {
        var e = new Date().getMonth() + 1;
        return [ 3, 4, 5 ].includes(e) ? "spring" : [ 6, 7, 8 ].includes(e) ? "summer" : [ 9, 10, 11 ].includes(e) ? "autumn" : [ 12, 1, 2 ].includes(e) ? "winter" : "unkown";
    }
};