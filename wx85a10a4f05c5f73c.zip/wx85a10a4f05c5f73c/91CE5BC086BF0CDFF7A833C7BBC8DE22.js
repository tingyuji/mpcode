require("@babel/runtime/helpers/Arrayincludes.js");

var e = require("06447A2186BF0CDF60221226F209DE22.js"), t = (getApp(), new Map());

function o(e) {
    return "?" + n(e);
}

function n(e) {
    return Object.keys(e).map(function(t) {
        return [ t, e[t] ].map(encodeURIComponent).join("=");
    }).join("&");
}

function a(e, o, n, s, r, u, i, c, l) {
    var d = Date.now(), m = void 0, g = t.get(e) || 0, p = function(t) {
        403 == t.statusCode && t.data && console.log("Auth failed.", t);
        var m = Date.now() - d;
        console.log("Invoke " + e + " failed, latency=" + m + "ms, url=" + o, t), c -= 1, 
        (l -= m) < 0 ? (console.log("Request timed out!"), i({
            reason: "Request timed out!",
            lastRes: t
        })) : c < 0 ? (console.log("Request exceeds max retry count!"), i({
            reason: "Request exceeds max retry count!",
            lastRes: t
        })) : (console.log("Retrying request. Remaining retry count: ", c), a(e, o, n, s, r, u, i, c, l));
    }, y = wx.request({
        url: o,
        data: n,
        header: Object.assign(r, {
            "Content-Type": "application/json",
            token: wx.getStorageSync("skey") || ""
        }),
        method: s,
        success: function(t) {
            t.statusCode.toString().startsWith("2") ? function(t) {
                var n = t.statusCode, a = Date.now() - d;
                console.log("[" + n + "] Invoked " + e + ", latency=" + a + "ms, url=" + o);
                var s = t.data;
                console.log(s), s.data && s.data.tokenStatus && ("HEADER_TOKEN_MISSED" === s.data.tokenStatus || "HEADER_TOKEN_UNKNOWN" === s.data.tokenStatus || "HEADER_TOKEN_EXPIRED" === s.data.tokenStatus) ? (wx.setStorageSync("skey", ""), 
                wx.setStorageSync("openid", ""), wx.redirectTo({
                    url: "/pages/splash/splash"
                })) : u(t.data);
            }(t) : p(t);
        },
        fail: function(e) {
            p(e);
        },
        complete: function(o) {
            clearTimeout(m), g++, t.set(e, g);
        }
    });
    return m = setTimeout(function() {
        y.error && y.abort(), i({
            reason: "Request timed out!"
        });
    }, l), y;
}

var s = {
    httpRequest: function(t, s, r, u, i, c, l) {
        var d = arguments.length > 7 && void 0 !== arguments[7] ? arguments[7] : {}, m = d.retrying, g = d.timeoutPeriod, p = d.maxRetryCount, y = void 0 !== m && m, R = void 0 === g ? e.default_timeout_mills : g, f = void 0 === p ? e.max_retry_count : p, v = y ? f : 0;
        return console.log("retryCount=" + v + ", timeout=" + R), "GET" === u && r && (s.includes("?") ? s += n(r) : s += o(r), 
        r = ""), a(t, s, r, u, i, c, l, v, R);
    }
};

module.exports = {
    httpRequest: s.httpRequest
};