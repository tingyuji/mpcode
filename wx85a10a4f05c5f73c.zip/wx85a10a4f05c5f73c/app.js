var n = wx.getUpdateManager();

App({
    innerAudioContext: null,
    globalData: {
        userInfo: null,
        gloabalFomIds: null,
        favAudios: null,
        animaNames: null,
        canRank: !1
    },
    onLaunch: function() {
        n.onCheckForUpdate(function(n) {}), n.onUpdateReady(function() {
            wx.showModal({
                title: "更新提示",
                content: "新版本已经准备好，是否重启应用？",
                success: function(t) {
                    t.confirm && n.applyUpdate();
                }
            });
        }), n.onUpdateFailed(function() {
            wx.showModal({
                title: "新版本更新失败",
                content: "发现新版本，但下载失败。如需体验新版本，请删除当前小程序，重新搜索打开"
            });
        }), this.innerAudioContextRight = wx.createInnerAudioContext(), this.innerAudioContextWrong = wx.createInnerAudioContext(), 
        this.innerAudioContextCountDown = wx.createInnerAudioContext();
    },
    onShow: function(n) {},
    onHide: function() {},
    onError: function(n) {
        console.log(n);
    },
    playAppTapAudio: function() {
        this.innerAudioContext || (this.innerAudioContext = wx.createInnerAudioContext()), 
        this.innerAudioContext.src = "/audio/press25.mp3", this.innerAudioContext.stop(), 
        this.innerAudioContext.play();
    },
    playCorrectAudio: function() {
        this.innerAudioContext || (this.innerAudioContext = wx.createInnerAudioContext()), 
        this.innerAudioContext.src = "/audio/correct.mp3", this.innerAudioContext.stop(), 
        this.innerAudioContext.play();
    },
    playWrongAudio: function() {
        this.innerAudioContext || (this.innerAudioContext = wx.createInnerAudioContext()), 
        this.innerAudioContext.src = "/audio/wrong.mp3", this.innerAudioContext.stop(), 
        this.innerAudioContext.play();
    },
    playCountdownAudio: function() {
        this.innerAudioContext || (this.innerAudioContext = wx.createInnerAudioContext()), 
        this.innerAudioContext.src = "/audio/countdown.mp3", this.innerAudioContext.stop(), 
        this.innerAudioContext.play();
    },
    shareApp: function(n) {
        return {
            title: "猜猜这是哪部动画片？",
            path: null != n && null != n ? n : "/pages/index/index",
            success: function(n) {
                console.log("转发成功");
            },
            fail: function(n) {
                console.log("转发失败");
            }
        };
    },
    setWxUserInfo: function(n) {
        wx.setStorageSync("wxUserInfo", n);
    },
    getWxUserInfo: function() {
        return wx.getStorageSync("wxUserInfo");
    },
    cacheTodayKnowlegeIsDone: function() {
        var n = new Date(), t = n.getFullYear() + "" + (n.getMonth() + 1) + n.getDate();
        wx.setStorageSync("answer.record.knowlege", t);
    },
    isToadyKnowlegeDone: function() {
        var n = wx.getStorageSync("answer.record.knowlege"), t = new Date(), e = t.getFullYear(), o = t.getMonth() + 1, i = t.getDate();
        return !!n && e + "" + o + i == n;
    },
    checkIn: function() {
        var n = new Date(), t = n.getFullYear() + "" + (n.getMonth() + 1) + n.getDate();
        wx.setStorageSync("app.task.checkin", t);
    },
    isCheckInDone: function() {
        var n = wx.getStorageSync("app.task.checkin"), t = new Date(), e = t.getFullYear(), o = t.getMonth() + 1, i = t.getDate();
        return !!n && e + "" + o + i == n;
    },
    cacheMission: function(n, t, e) {
        var o = this.globalData.missions || [];
        0 == o.length && (o = wx.getStorageSync("missions") || []);
        for (var i = !1, a = -1, r = 0, s = o.length; r < s; r++) {
            if (o[r].category == n) {
                i = !0, a = r;
                break;
            }
        }
        i ? (o[a].mission = t, o[a].status = e) : o.push({
            category: n,
            mission: t,
            status: e
        }), this.globalData.missions = o, wx.setStorageSync("missions", o);
    },
    getLastMission: function(n) {
        for (var t = wx.getStorageSync("missions") || [], e = null, o = 0, i = t.length; o < i; o++) {
            var a = t[o];
            if (a.category == n) {
                e = a;
                break;
            }
        }
        return e;
    },
    getLastMissionByGroup: function() {
        for (var n = wx.getStorageSync("missions") || [], t = {}, e = 0, o = n.length; e < o; e++) {
            var i = n[e];
            t[i.category] = i.status ? i.mission + 1 : i.mission;
        }
        return t;
    },
    cacheFavAudios: function(n) {
        var t = this.globalData.favAudios || [];
        0 == t.length && (t = wx.getStorageSync("favAudios") || []);
        for (var e = !1, o = 0, i = t.length; o < i; o++) {
            if (t[o].anima.audio == n.anima.audio) {
                e = !0;
                break;
            }
        }
        e || t.push(n), this.globalData.favAudios = t, wx.setStorageSync("favAudios", t);
    },
    removeFavAudio: function(n) {
        var t = wx.getStorageSync("favAudios");
        if (t) {
            for (var e = 0, o = t.length; e < o; e++) n == e && t.splice(e, 1);
            wx.setStorageSync("favAudios", t);
        }
    },
    getRandomNum: function(n, t) {
        var e = t - n, o = Math.random();
        return n + Math.round(o * e);
    },
    randomArray: function(n) {
        for (var t = n.slice(), e = 0, o = 0, i = null, a = 0; a < t.length; a++) (e = this.getRandomNum(0, t.length - 1)) != (o = this.getRandomNum(0, t.length - 1)) && (i = t[e], 
        t[e] = t[o], t[o] = i);
        return t;
    }
});