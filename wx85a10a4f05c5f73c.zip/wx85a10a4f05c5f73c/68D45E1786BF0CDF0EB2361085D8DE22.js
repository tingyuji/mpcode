var n = require("883143E186BF0CDFEE572BE690F8DE22.js");

require("1AB8A93786BF0CDF7CDEC130B759DE22.js");

module.exports = {
    ads: function(t) {
        return new Promise(function(i, c) {
            n.call("router", "ads", {
                type: t
            }).then(function(n) {
                i(n);
            }).catch(function(n) {
                c(n);
            });
        });
    },
    question: function(t) {
        return new Promise(function(i, c) {
            n.call("guessv2", "question", {
                category: t
            }).then(function(n) {
                i(n);
            }).catch(function(n) {
                c(n);
            });
        });
    },
    userData: function() {
        return new Promise(function(t, i) {
            n.call("guessv2", "user-data").then(function(n) {
                t(n);
            }).catch(function(n) {
                i(n);
            });
        });
    },
    missionData: function(t) {
        var i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0, c = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 5;
        return new Promise(function(e, o) {
            n.call("guessv2", "mission-question", {
                category: t,
                mission: i,
                size: c
            }).then(function(n) {
                e(n);
            }).catch(function(n) {
                o(n);
            });
        });
    },
    missionUnlock: function(t) {
        return new Promise(function(i, c) {
            n.call("guessv2", "mission-unlock", {
                mission: t
            }).then(function(n) {
                i(n);
            }).catch(function(n) {
                c(n);
            });
        });
    },
    missionPass: function(t) {
        return new Promise(function(i, c) {
            n.call("guessv2", "mission-pass", {
                mission: t
            }).then(function(n) {
                i(n);
            }).catch(function(n) {
                c(n);
            });
        });
    },
    pointCost: function(t) {
        var i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "使用" + t + "积分";
        return new Promise(function(c, e) {
            n.call("guessv2", "point-cost", {
                point: t,
                desc: i
            }).then(function(n) {
                c(n);
            }).catch(function(n) {
                e(n);
            });
        });
    },
    pointGet: function(t) {
        var i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "获得" + t + "积分";
        return new Promise(function(c, e) {
            n.call("guessv2", "point-get", {
                point: t,
                desc: i
            }).then(function(n) {
                c(n);
            }).catch(function(n) {
                e(n);
            });
        });
    },
    wallpaper: function() {
        return new Promise(function(t, i) {
            n.call("guessv2", "wallpaper").then(function(n) {
                t(n);
            }).catch(function(n) {
                i(n);
            });
        });
    },
    wallpaperHistory: function() {
        return new Promise(function(t, i) {
            n.call("guessv2", "wallpaper-history").then(function(n) {
                t(n);
            }).catch(function(n) {
                i(n);
            });
        });
    },
    wallpaperData: function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "202002";
        return new Promise(function(i, c) {
            n.call("guessv2", "wallpaper-data", {
                serial: t
            }).then(function(n) {
                i(n);
            }).catch(function(n) {
                c(n);
            });
        });
    },
    checkin: function(t) {
        var i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "签到";
        return new Promise(function(c, e) {
            n.call("guessv2", "checkin", {
                userinfo: t,
                desc: i
            }).then(function(n) {
                c(n);
            }).catch(function(n) {
                e(n);
            });
        });
    },
    animateRank: function() {
        return new Promise(function(t, i) {
            n.call("guessv2", "animate-rank").then(function(n) {
                t(n);
            }).catch(function(n) {
                i(n);
            });
        });
    },
    rank: function() {
        return new Promise(function(t, i) {
            n.call("guessv2", "rank").then(function(n) {
                t(n);
            }).catch(function(n) {
                i(n);
            });
        });
    },
    myrank: function() {
        return new Promise(function(t, i) {
            n.call("guessv2", "myrank").then(function(n) {
                t(n);
            }).catch(function(n) {
                i(n);
            });
        });
    },
    hotAnimas: function() {
        return new Promise(function(t, i) {
            n.call("guessv2", "hot-anima").then(function(n) {
                t(n);
            }).catch(function(n) {
                i(n);
            });
        });
    },
    hotAnimaFire: function(t) {
        return new Promise(function(i, c) {
            n.call("guessv2", "hot-anima-fire", {
                name: t
            }).then(function(n) {
                i(n);
            }).catch(function(n) {
                c(n);
            });
        });
    }
};