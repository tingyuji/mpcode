var o = {
    favinChinese: [ {
        typeName: "电影动画",
        name: "雄狮少年",
        desc: "2021-12-17",
        director: "导演: 孙海鹏",
        tags: "",
        tips: "正在热播",
        thumb: "https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2702755317.jpg",
        image: "https://img1.doubanio.com/view/photo/l/public/p2702755317.jpg",
        hot: 0
    }, {
        typeName: "剧集动画",
        name: "凡人修仙传：魔道争锋",
        desc: "2021-11-14",
        director: "导演: 王裕仁 / 赵侠",
        tags: "",
        tips: "正在热播",
        thumb: "https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2710137149.jpg",
        image: "https://img1.doubanio.com/view/photo/l/public/p2710137149.jpg",
        hot: 0
    }, {
        typeName: "剧集动画",
        name: "斗破苍穹 三年之约",
        desc: "2021-10-31",
        director: "导演: 赵丙乐",
        tags: "",
        tips: "正在热播",
        thumb: "https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2675958135.jpg",
        image: "https://img9.doubanio.com/view/photo/l/public/p2675958135.jpg",
        hot: 0
    }, {
        typeName: "剧集动画",
        name: "紫川",
        desc: "2021-12-21",
        director: "",
        tags: "",
        tips: "正在热播",
        thumb: "https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2616542555.jpg",
        image: "https://img9.doubanio.com/view/photo/l/public/p2616542555.jpg",
        hot: 0
    }, {
        typeName: "剧集动画",
        name: "斗罗大陆 海神之光",
        desc: "2021-02-20 上映",
        director: "导演: 沈乐平",
        tags: "",
        tips: "热播中",
        thumb: "https://img3.doubanio.com/view/photo/s_ratio_poster/public/p2653968030.jpg",
        image: "https://img3.doubanio.com/view/photo/l/public/p2653968030.jpg",
        hot: 0
    } ],
    favinJa: [ {
        typeName: "剧集动画",
        name: "国王排名",
        desc: "2021-10-15 上映",
        director: "",
        tags: "",
        tips: "",
        thumb: "https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2681362557.jpg",
        image: "https://img1.doubanio.com/view/photo/l/public/p2681362557.jpg",
        video: "",
        hot: 0
    }, {
        typeName: "剧场版动画",
        name: "鬼灭之刃 游郭篇",
        desc: "2021-12-05(日本) 上映",
        director: "",
        tags: "",
        tips: "",
        thumb: "https://img2.doubanio.com/view/photo/s_ratio_poster/public/p2670418692.jpg",
        image: "https://img2.doubanio.com/view/photo/l/public/p2670418692.jpg",
        video: "",
        hot: 0
    }, {
        typeName: "剧集动画",
        name: "平家物语",
        desc: "2021-09-15(日本网络) 上映",
        director: "",
        tags: "",
        tips: "",
        thumb: "https://img3.doubanio.com/view/photo/s_ratio_poster/public/p2682264910.jpg",
        image: "https://img3.doubanio.com/view/photo/l/public/p2682264910.jpg",
        video: "",
        hot: 0
    }, {
        typeName: "剧集动画",
        name: "漂流少年",
        desc: "2021-07-15 上映",
        director: "",
        tags: "",
        tips: "",
        thumb: "https://img2.doubanio.com/view/photo/s_ratio_poster/public/p2659821253.jpg",
        image: "https://img2.doubanio.com/view/photo/l/public/p2659821253.jpg",
        video: "",
        hot: 0
    } ],
    favinWestern: [ {
        typeName: "剧集动画",
        name: "英雄联盟：双城之战 第一季",
        desc: "2021-11-07 上映",
        director: "",
        tags: "",
        thumb: "https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2714077426.jpg",
        image: "https://img9.doubanio.com/view/photo/l/public/p2714077426.jpg",
        video: "",
        hot: 0
    }, {
        typeName: "动画电影",
        name: "疯狂原始人：家谱",
        desc: "2021-09-23 上映",
        director: "",
        tags: "",
        thumb: "https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2682121465.jpg",
        image: "https://img9.doubanio.com/view/photo/l/public/p2682121465.jpg",
        video: "",
        hot: 0
    }, {
        typeName: "动画电影",
        name: "星球大战：幻境",
        desc: "2021-09-22 上映",
        director: "",
        tags: "",
        thumb: "https://img2.doubanio.com/view/photo/s_ratio_poster/public/p2681213622.jpg",
        image: "https://img2.doubanio.com/view/photo/l/public/p2681213622.jpg",
        video: "",
        hot: 0
    }, {
        typeName: "剧集动画",
        name: "假如…？第一季",
        desc: "2021-08-11 上映",
        director: "",
        tags: "",
        thumb: "https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2669066997.jpg",
        image: "https://img1.doubanio.com/view/photo/l/public/p2669066997.jpg",
        video: "",
        hot: 0
    }, {
        typeName: "动画电影",
        name: "夏日友晴天 Luca",
        desc: "2021-07 上映",
        director: "",
        tags: "",
        thumb: "https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2633883449.jpg",
        image: "https://img1.doubanio.com/view/photo/l/public/p2633883449.jpg",
        video: "",
        hot: 0
    }, {
        typeName: "剧集动画",
        name: "瑞克和莫蒂 第五季",
        desc: "2021-06-20 上映",
        director: "",
        tags: "",
        thumb: "https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2631497095.jpg",
        image: "https://img9.doubanio.com/view/photo/l/public/p2631497095.jpg",
        video: "",
        hot: 0
    }, {
        typeName: "剧集动画",
        name: "爱，死亡和机器人 第二季",
        desc: "2021-05-14 上映",
        director: "",
        tags: "",
        thumb: "https://img3.doubanio.com/view/photo/s_ratio_poster/public/p2641221021.jpg",
        image: "https://img3.doubanio.com/view/photo/l/public/p2641221021.jpg",
        video: "",
        hot: 0
    }, {
        typeName: "剧集动画",
        name: "外星也难民 第二季",
        desc: "2021-03-26 上映",
        director: "",
        tags: "",
        thumb: "https://img3.doubanio.com/view/photo/s_ratio_poster/public/p2633924081.jpg",
        image: "https://img3.doubanio.com/view/photo/l/public/p2633924081.jpg",
        video: "",
        hot: 0
    } ]
};

module.exports = {
    favin: [ o.favinChinese, o.favinJa, o.favinWestern ]
};