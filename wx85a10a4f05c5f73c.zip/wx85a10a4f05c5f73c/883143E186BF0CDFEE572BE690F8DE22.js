var n = function(n, o, e) {
    var c = Object.assign({
        $url: o
    }, e);
    return new Promise(function(o, e) {
        wx.cloud.callFunction({
            name: n,
            data: c
        }).then(function(n) {
            console.log("call success, %o", n);
            var c = n.errMsg;
            n.requestID;
            if ("cloud.callFunction:ok" === c) {
                var l = n.result, t = l.code;
                0 === t ? o(l.data) : e(t + ", " + l.message);
            } else e(c);
        }).catch(function(n) {
            console.error("call fail, %o", n), e(n);
        });
    });
};

wx.cloud.init({
    env: "fans-guess-pro-965c9b"
}), module.exports = {
    call: function(o, e, c) {
        var l = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 3, t = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : 500;
        return new Promise(function(s, u) {
            !function a() {
                n(o, e, c).then(s).catch(function(n) {
                    l--, console.log("Call %s Failed, %o", o + "/" + e, n), console.log("Remaining retry count: %s", l), 
                    0 == l ? u(n) : setTimeout(function() {
                        a();
                    }, t);
                });
            }();
        });
    },
    cloudCall: n
};