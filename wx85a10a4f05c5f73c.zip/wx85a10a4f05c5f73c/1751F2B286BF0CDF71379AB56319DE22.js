module.exports = {
    ON: "on",
    OFF: "off",
    AD_INTERSTITIAL: "interstitial",
    AD_REWARDED: "rewarded",
    AD_BANNER: "banner",
    AD_VIDEO: "video"
};