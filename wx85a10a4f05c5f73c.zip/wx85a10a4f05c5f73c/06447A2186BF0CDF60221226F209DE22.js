var e = "cloud://fans-guess-pro-965c9b.6661-fans-guess-pro-965c9b-1258588518/", s = {
    default_timeout_mills: 1e3,
    max_retry_count: 3,
    appResPath: {
        knowledge: e + "res-knowledge/",
        audio: e + "res-audio/",
        wp: e + "res-wallpaper/",
        wpthumb: e + "res-wallpaper/thumb/"
    }
};

module.exports = s;