var o = {
    favin2020: [ {
        typeName: "剧集动画",
        name: "吞噬星空",
        desc: "2020-11-29",
        director: "导演: 沈乐平",
        tags: "",
        tips: "热播中",
        thumb: "https://img2.doubanio.com/view/photo/s_ratio_poster/public/p2616542123.jpg",
        image: "https://img2.doubanio.com/view/photo/l/public/p2616542123.jpg",
        hot: 0
    }, {
        typeName: "动画电影",
        name: "新神榜：哪吒重生",
        desc: "2021-02-12",
        director: "导演: 赵霁",
        tags: "",
        tips: "大年初一",
        thumb: "https://img3.doubanio.com/view/photo/s_ratio_poster/public/p2622496681.jpg",
        image: "https://img3.doubanio.com/view/photo/l/public/p2622496681.jpg",
        hot: 0
    }, {
        typeName: "剧集动画",
        name: "天官赐福",
        desc: "2020-10-31\n哔哩哔哩 独播",
        director: "导演: 李豪凌",
        tags: "",
        tips: "热播中",
        thumb: "https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2621050857.jpg",
        image: "https://img1.doubanio.com/view/photo/l/public/p2621050857.jpg",
        hot: 0
    }, {
        typeName: "剧集动画",
        name: "秦侠",
        desc: "2020-10-16\n哔哩哔哩 独播",
        director: "导演: 陈烨",
        tags: "",
        tips: "热播中",
        thumb: "https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2621131618.jpg",
        image: "https://img1.doubanio.com/view/photo/l/public/p2621131618.jpg",
        hot: 0
    }, {
        typeName: "剧集动画",
        name: "一念永恒",
        desc: "2020-08-12\n腾讯视频 独播",
        director: "导演: 苏晓光",
        tags: "",
        tips: "热播中",
        thumb: "https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2601245445.jpg",
        image: "https://img9.doubanio.com/view/photo/l/public/p2601245445.jpg",
        hot: 0
    }, {
        typeName: "剧集动画",
        name: "灵笼",
        desc: "2019-07-13\n哔哩哔哩 独播",
        director: "导演: 董相博",
        tags: "",
        tips: "有更新",
        thumb: "https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2562904016.jpg",
        image: "https://img9.doubanio.com/view/photo/l/public/p2562904016.jpg",
        hot: 0
    }, {
        typeName: "动画电影",
        name: "大护法2",
        desc: "2020上映",
        director: "导演: 不思凡",
        tags: "",
        tips: "即将上映",
        thumb: "https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2494291309.jpg",
        image: "https://img1.doubanio.com/view/photo/l/public/p2494291309.jpg",
        hot: 0
    }, {
        typeName: "动画电影",
        name: "深海",
        desc: "2020上映",
        director: "导演: 田晓鹏",
        tags: "",
        tips: "即将上映",
        thumb: "https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2546196247.jpg",
        image: "https://img1.doubanio.com/view/photo/l/public/p2546196247.jpg",
        hot: 0
    }, {
        typeName: "动画电影",
        name: "鬼列车",
        desc: "2020上映",
        director: "导演: 景绍宗",
        tags: "",
        tips: "即将上映",
        thumb: "https://img3.doubanio.com/view/photo/s_ratio_poster/public/p2568969401.jpg",
        image: "https://img3.doubanio.com/view/photo/l/public/p2568969401.jpg",
        hot: 0
    }, {
        typeName: "剧场版",
        name: "星游记之冲出地球",
        desc: "2020上映",
        director: "导演: 胡一泊",
        tags: "",
        tips: "即将上映",
        thumb: "https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2507002156.jpg",
        image: "https://img9.doubanio.com/view/photo/l/public/p2507002156.jpg",
        hot: 0
    }, {
        typeName: "动画电影",
        name: "西游记之大圣闹天宫",
        desc: "2020上映",
        director: "导演: 田晓鹏",
        tags: "",
        tips: "即将上映",
        thumb: "https://img3.doubanio.com/view/photo/s_ratio_poster/public/p2277313703.jpg",
        image: "https://img3.doubanio.com/view/photo/l/public/p2277313703.jpg",
        hot: 0
    }, {
        typeName: "剧集动画",
        name: "凡人修仙传",
        desc: "2020.07.25 \n哔哩哔哩 播出",
        director: "凡人风起天南",
        tags: "",
        tips: "连播中",
        thumb: "https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2610801866.jpg",
        image: "https://img9.doubanio.com/view/photo/l/public/p2610801866.jpg",
        hot: 0
    }, {
        typeName: "剧集动画",
        name: "这世界有兽",
        desc: "2020上映",
        director: "导演: 毕维",
        tags: "",
        tips: "即将上映",
        thumb: "https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2528646587.jpg",
        image: "https://img1.doubanio.com/view/photo/l/public/p2528646587.jpg",
        hot: 0
    }, {
        typeName: "剧集动画",
        name: "少年歌行 风花雪月篇",
        desc: "2020上映",
        director: "导演: 郭勇/陈升垚",
        tags: "",
        tips: "即将上映",
        thumb: "https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2578234939.jpg",
        image: "https://img1.doubanio.com/view/photo/l/public/p2578234939.jpg",
        hot: 0
    }, {
        typeName: "剧集动画",
        name: "雾山五行",
        desc: "2020.07.26 \n哔哩哔哩 首映",
        director: "导演: 林魂",
        tags: "",
        tips: "连播中",
        thumb: "https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2542263049.jpg",
        image: "https://img1.doubanio.com/view/photo/l/public/p2542263049.jpg",
        hot: 0
    }, {
        typeName: "剧集动画",
        name: "民调局异闻录",
        desc: "2020.08.07\n腾讯视频 首播",
        director: "导演: 熊可",
        tags: "",
        tips: "连播中",
        thumb: "https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2574954027.jpg",
        image: "https://img1.doubanio.com/view/photo/l/public/p2574954027.jpg",
        hot: 0
    }, {
        typeName: "剧集动画",
        name: "天宝伏妖录",
        desc: "2020.07.05 \n哔哩哔哩 播出",
        director: "出品: 玄机科技",
        tags: "",
        tips: "连播中",
        thumb: "https://img3.doubanio.com/view/photo/s_ratio_poster/public/p2579312073.jpg",
        image: "https://img3.doubanio.com/view/photo/l/public/p2579312073.jpg",
        hot: 0
    }, {
        typeName: "剧集动画",
        name: "火凤燎原",
        desc: "2020年上映",
        director: "导演: 毛启超",
        tags: "",
        tips: "预告中",
        thumb: "https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2578251138.jpg",
        image: "https://img1.doubanio.com/view/photo/l/public/p2578251138.jpg",
        hot: 0
    }, {
        typeName: "剧集动画",
        name: "朔风—破阵子",
        desc: "预告",
        director: "好传动画",
        tags: "",
        tips: "预告中",
        thumb: "https://bkimg.cdn.bcebos.com/pic/d043ad4bd11373f082020f3424465cfbfbedab64ae4d",
        image: "https://bkimg.cdn.bcebos.com/pic/d043ad4bd11373f082020f3424465cfbfbedab64ae4d",
        hot: 0
    }, {
        typeName: "剧集动画",
        name: "全职高手 第二季",
        desc: "2020.09.25\n腾讯视频 首播",
        director: "",
        tags: "",
        tips: "连播中",
        thumb: "https://img3.doubanio.com/view/photo/s_ratio_poster/public/p2554925461.jpg",
        image: "https://img3.doubanio.com/view/photo/l/public/p2554925461.jpg",
        hot: 0
    }, {
        typeName: "剧集动画",
        name: "我为歌狂之旋律重启",
        desc: "2020.10.02上映",
        director: "",
        tags: "",
        tips: "连播中",
        thumb: "https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2614331694.jpg",
        image: "https://img9.doubanio.com/view/photo/l/public/p2614331694.jpg",
        hot: 0
    }, {
        typeName: "剧集动画",
        name: "我的师父姜子牙",
        desc: "2020上映",
        director: "",
        tags: "",
        tips: "即将上映",
        thumb: "https://img3.doubanio.com/view/photo/s_ratio_poster/public/p2190216230.jpg",
        image: "https://img3.doubanio.com/view/photo/l/public/p2190216230.jpg",
        hot: 0
    } ],
    favin2020Ja: [ {
        typeName: "剧场版动画",
        name: "鬼灭之刃 剧场版 无限列车篇",
        desc: "2020-10-16上映",
        director: "",
        tags: "",
        tips: "热播中",
        thumb: "https://img3.doubanio.com/view/photo/s_ratio_poster/public/p2595123270.jpg",
        image: "https://img3.doubanio.com/view/photo/l/public/p2595123270.jpg",
        video: "",
        hot: 0
    }, {
        typeName: "剧集动画",
        name: "我的青春恋爱物语果然有问题",
        desc: "2020-07-09上映",
        director: "",
        tags: "",
        thumb: "https://img3.doubanio.com/view/photo/s_ratio_poster/public/p2586078403.jpg",
        image: "https://img3.doubanio.com/view/photo/l/public/p2586078403.jpg",
        video: "",
        hot: 0
    }, {
        typeName: "剧集动画",
        name: "异兽魔都 ドロヘドロ",
        desc: "2020-01-12上映",
        director: "",
        tags: "",
        thumb: "https://img3.doubanio.com/view/photo/s_ratio_poster/public/p2571185490.jpg",
        image: "https://img3.doubanio.com/view/photo/l/public/p2571185490.jpg",
        video: "",
        hot: 0
    }, {
        typeName: "剧集动画",
        name: "异度侵入 イド：インヴェイデッド",
        desc: "2020-01-06上映",
        director: "",
        tags: "",
        thumb: "https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2584476257.jpg",
        image: "https://img1.doubanio.com/view/photo/l/public/p2584476257.jpg",
        video: "",
        hot: 0
    }, {
        typeName: "剧集动画",
        name: "辉夜大小姐想让我告白：天才们的恋爱头脑战",
        desc: "2020-04-11上映",
        director: "畠山守",
        tags: "喜剧,爱情",
        thumb: "https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2589123238.jpg",
        image: "https://img1.doubanio.com/view/photo/l/public/p2589123238.jpg",
        video: "",
        hot: 0
    }, {
        typeName: "剧集动画",
        name: "别对映像研出手！ 映像研には手を出すな！",
        desc: "2020-01-05上映",
        director: "",
        tags: "",
        thumb: "https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2584313356.jpg",
        image: "https://img9.doubanio.com/view/photo/l/public/p2584313356.jpg",
        video: "",
        hot: 0
    }, {
        typeName: "剧集动画",
        name: "房间露营△ へやキャン△",
        desc: "2020-01-06上映",
        director: "",
        tags: "",
        thumb: "https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2574296707.jpg",
        image: "https://img1.doubanio.com/view/photo/l/public/p2574296707.jpg",
        video: "",
        hot: 0
    }, {
        typeName: "剧集动画",
        name: "破晓之翼 薄明の翼",
        desc: "2020-01-15上映",
        director: "",
        tags: "",
        thumb: "https://img3.doubanio.com/view/photo/s_ratio_poster/public/p2578646981.jpg",
        image: "https://img3.doubanio.com/view/photo/l/public/p2578646981.jpg",
        video: "",
        hot: 0
    }, {
        typeName: "剧集动画",
        name: "放学后海堤日记 放課後ていぼう日誌",
        desc: "2020-04-07上映",
        director: "",
        tags: "",
        thumb: "https://img3.doubanio.com/view/photo/s_ratio_poster/public/p2571473750.jpg",
        image: "https://img3.doubanio.com/view/photo/l/public/p2571473750.jpg",
        video: "",
        hot: 0
    }, {
        typeName: "剧集动画",
        name: "安达与岛村 安達としまむら",
        desc: "2020-10上映",
        director: "",
        tags: "",
        thumb: "https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2578721106.jpg",
        image: "https://img9.doubanio.com/view/photo/l/public/p2578721106.jpg",
        video: "",
        hot: 0
    }, {
        typeName: "剧集动画",
        name: "地球外少年少女",
        desc: "2020上映",
        director: "",
        tags: "",
        tips: "即将上映",
        thumb: "https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2522729917.jpg",
        image: "https://img1.doubanio.com/view/photo/l/public/p2522729917.jpg",
        video: "",
        hot: 0
    }, {
        typeName: "剧集动画",
        name: "隐瞒之事 かくしごと",
        desc: "2020-04-02上映",
        director: "",
        tags: "",
        thumb: "https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2591707576.jpg",
        image: "https://img9.doubanio.com/view/photo/l/public/p2591707576.jpg",
        video: "",
        hot: 0
    }, {
        typeName: "剧集动画",
        name: "大欺诈师 GREAT PRETENDER",
        desc: "2020-04-11上映",
        director: "镝木宏",
        tags: "剧情",
        tips: "连播中",
        thumb: "https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2581845346.jpg",
        image: "https://img9.doubanio.com/view/photo/l/public/p2581845346.jpg",
        video: "",
        hot: 0
    }, {
        typeName: "剧集动画",
        name: "动物新世代 BNA ビー・エヌ・エー",
        desc: "2020-03-21上映",
        director: "",
        tags: "剧情",
        thumb: "https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2561805747.jpg",
        image: "https://img1.doubanio.com/view/photo/l/public/p2561805747.jpg",
        video: "",
        hot: 0
    }, {
        typeName: "剧集动画",
        name: "没落要塞 デカダンス DACE DENCE",
        desc: "2020-06-28\n哔哩哔哩 播出",
        director: "",
        tags: "",
        tips: "已完结",
        thumb: "https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2602997835.jpg",
        image: "https://img9.doubanio.com/view/photo/l/public/p2602997835.jpg",
        video: "",
        hot: 0
    }, {
        typeName: "剧集动画",
        name: "進撃の巨人 The Final Season",
        desc: "2020-10 上映",
        director: "",
        tags: "",
        tips: "即将上映",
        thumb: "https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2605274206.jpg",
        image: "https://img9.doubanio.com/view/photo/l/public/p2605274206.jpg",
        video: "",
        hot: 0
    }, {
        typeName: "剧集动画",
        name: "咒术回战 呪術廻戦",
        desc: "2020-10 上映",
        director: "",
        tags: "",
        tips: "热播中",
        thumb: "https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2604449799.jpg",
        image: "https://img1.doubanio.com/view/photo/l/public/p2604449799.jpg",
        video: "",
        hot: 0
    }, {
        typeName: "剧集动画",
        name: "池袋西口公园",
        desc: "2020-10-06首播（日本）",
        director: "",
        tags: "",
        tips: "连播中",
        thumb: "https://img3.doubanio.com/view/photo/s_ratio_poster/public/p2609587731.jpg",
        image: "https://img3.doubanio.com/view/photo/l/public/p2609587731.jpg",
        video: "https://vt1.doubanio.com/202009202233/aa4779cb6309d962c357de90d42450fc/view/movie/M/402650965.mp4",
        hot: 0
    } ],
    favin2020Western: [ {
        typeName: "动画电影",
        name: "狼行者 Wolfwalkers ",
        desc: "2020-10上映",
        director: "汤姆·摩尔 / 罗斯·斯图尔特",
        tags: "",
        thumb: "https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2619738857.jpg",
        image: "https://img1.doubanio.com/view/photo/l/public/p2619738857.jpg",
        video: "",
        hot: 0
    }, {
        typeName: "剧集动画",
        name: "探险活宝：遥远国度",
        desc: "2020-06-25上映",
        director: "",
        tags: "",
        thumb: "https://img3.doubanio.com/view/photo/s_ratio_poster/public/p2572351660.jpg",
        image: "https://img3.doubanio.com/view/photo/l/public/p2572351660.jpg",
        video: "",
        hot: 0
    }, {
        typeName: "剧集动画",
        name: "哈莉·奎茵 第二季",
        desc: "2020-04-03上映",
        director: "",
        tags: "",
        thumb: "https://img3.doubanio.com/view/photo/s_ratio_poster/public/p2593127752.jpg",
        image: "https://img3.doubanio.com/view/photo/l/public/p2593127752.jpg",
        video: "",
        hot: 0
    }, {
        typeName: "剧集动画",
        name: "外星也难民 第一季",
        desc: "2020-05-08上映",
        director: "",
        tags: "",
        thumb: "https://img3.doubanio.com/view/photo/s_ratio_poster/public/p2600469202.jpg",
        image: "https://img3.doubanio.com/view/photo/l/public/p2600469202.jpg",
        video: "",
        hot: 0
    }, {
        typeName: "剧集动画",
        name: "午夜福音",
        desc: "2020-04-20上映",
        director: "",
        tags: "",
        thumb: "https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2594587144.jpg",
        image: "https://img9.doubanio.com/view/photo/l/public/p2594587144.jpg",
        video: "",
        hot: 0
    }, {
        typeName: "剧集动画",
        name: "颤抖的真相 第二季",
        desc: "2020-05-10上映",
        director: "",
        tags: "",
        thumb: "https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2604748384.jpg",
        image: "https://img9.doubanio.com/view/photo/l/public/p2604748384.jpg",
        video: "",
        hot: 0
    }, {
        typeName: "剧集动画",
        name: "天堂镇警局 第二季",
        desc: "2020-03-06上映",
        director: "",
        tags: "",
        thumb: "https://img3.doubanio.com/view/photo/s_ratio_poster/public/p2591758902.jpg",
        image: "https://img3.doubanio.com/view/photo/l/public/p2591758902.jpg",
        video: "",
        hot: 0
    }, {
        typeName: "剧集动画",
        name: "奇波和神奇动物的时代 第一季",
        desc: "2020-01-14上映",
        director: "",
        tags: "",
        thumb: "https://img3.doubanio.com/view/photo/s_ratio_poster/public/p2580869910.jpg",
        image: "https://img3.doubanio.com/view/photo/l/public/p2580869910.jpg",
        video: "",
        hot: 0
    }, {
        typeName: "剧集动画",
        name: "无尽列车 第二季",
        desc: "2020-01-06上映",
        director: "",
        tags: "",
        thumb: "https://img3.doubanio.com/view/photo/s_ratio_poster/public/p2580657133.jpg",
        image: "https://img3.doubanio.com/view/photo/l/public/p2580657133.jpg",
        video: "",
        hot: 0
    }, {
        typeName: "剧集动画",
        name: "爱，死亡和机器人 第二季",
        desc: "2020上映",
        director: "",
        tags: "",
        tips: "即将上映",
        thumb: "https://img1.doubanio.com/view/photo/s_ratio_poster/public/p2578042737.jpg",
        image: "https://img1.doubanio.com/view/photo/l/public/p2578042737.jpg",
        video: "",
        hot: 0
    }, {
        typeName: "剧集动画",
        name: "怪兽上班 Monsters at Work",
        desc: "2020上映\n《怪兽电力公司》衍生剧集",
        director: "",
        tags: "",
        tips: "预告中",
        thumb: "https://img9.doubanio.com/view/photo/s_ratio_poster/public/p2559368535.jpg",
        image: "https://img9.doubanio.com/view/photo/l/public/p2559368535.jpg",
        video: "",
        hot: 0
    } ]
};

module.exports = {
    favin2020: [ o.favin2020, o.favin2020Ja, o.favin2020Western ]
};